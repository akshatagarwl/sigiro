import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Id = string;
export type DraftVersion = string;
export type AgentAliasArn = string;
export interface AgentDescriptor {
    aliasArn?: string;
}
export declare const AgentDescriptor: S.Schema<AgentDescriptor>;
export type Name = string;
export type CollaborationInstruction = string | redacted.Redacted<string>;
export type RelayConversationHistory = "TO_COLLABORATOR" | "DISABLED" | (string & {});
export declare const RelayConversationHistory: any;
export type ClientToken = string;
export interface AssociateAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    agentDescriptor: AgentDescriptor;
    collaboratorName: string;
    collaborationInstruction: string | redacted.Redacted<string>;
    relayConversationHistory?: RelayConversationHistory;
    clientToken?: string;
}
export declare const AssociateAgentCollaboratorRequest: S.Schema<AssociateAgentCollaboratorRequest>;
export type Version = string;
export interface AgentCollaborator {
    agentId: string;
    agentVersion: string;
    agentDescriptor: AgentDescriptor;
    collaboratorId: string;
    collaborationInstruction: string | redacted.Redacted<string>;
    collaboratorName: string;
    createdAt: Date;
    lastUpdatedAt: Date;
    relayConversationHistory?: RelayConversationHistory;
    clientToken?: string;
}
export declare const AgentCollaborator: S.Schema<AgentCollaborator>;
export interface AssociateAgentCollaboratorResponse {
    agentCollaborator: AgentCollaborator;
}
export declare const AssociateAgentCollaboratorResponse: S.Schema<AssociateAgentCollaboratorResponse>;
export type Description = string;
export type KnowledgeBaseState = "ENABLED" | "DISABLED" | (string & {});
export declare const KnowledgeBaseState: any;
export interface AssociateAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
    description: string;
    knowledgeBaseState?: KnowledgeBaseState;
}
export declare const AssociateAgentKnowledgeBaseRequest: S.Schema<AssociateAgentKnowledgeBaseRequest>;
export interface AgentKnowledgeBase {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
    description: string;
    createdAt: Date;
    updatedAt: Date;
    knowledgeBaseState: KnowledgeBaseState;
}
export declare const AgentKnowledgeBase: S.Schema<AgentKnowledgeBase>;
export interface AssociateAgentKnowledgeBaseResponse {
    agentKnowledgeBase: AgentKnowledgeBase;
}
export declare const AssociateAgentKnowledgeBaseResponse: S.Schema<AssociateAgentKnowledgeBaseResponse>;
export type Instruction = string | redacted.Redacted<string>;
export type ModelIdentifier = string;
export type OrchestrationType = "DEFAULT" | "CUSTOM_ORCHESTRATION" | (string & {});
export declare const OrchestrationType: any;
export type LambdaArn = string;
export type OrchestrationExecutor = {
    lambda: string;
};
export declare const OrchestrationExecutor: any;
export interface CustomOrchestration {
    executor?: OrchestrationExecutor;
}
export declare const CustomOrchestration: S.Schema<CustomOrchestration>;
export type SessionTTL = number;
export type AgentRoleArn = string;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export type PromptType = "PRE_PROCESSING" | "ORCHESTRATION" | "POST_PROCESSING" | "KNOWLEDGE_BASE_RESPONSE_GENERATION" | "MEMORY_SUMMARIZATION" | (string & {});
export declare const PromptType: any;
export type CreationMode = "DEFAULT" | "OVERRIDDEN" | (string & {});
export declare const CreationMode: any;
export type PromptState = "ENABLED" | "DISABLED" | (string & {});
export declare const PromptState: any;
export type BasePromptTemplate = string | redacted.Redacted<string>;
export type Temperature = number;
export type TopP = number;
export type TopK = number;
export type MaximumLength = number;
export type StopSequences = string[];
export declare const StopSequences: any;
export interface InferenceConfiguration {
    temperature?: number;
    topP?: number;
    topK?: number;
    maximumLength?: number;
    stopSequences?: string[];
}
export declare const InferenceConfiguration: S.Schema<InferenceConfiguration>;
export interface PromptConfiguration {
    promptType?: PromptType;
    promptCreationMode?: CreationMode;
    promptState?: PromptState;
    basePromptTemplate?: string | redacted.Redacted<string>;
    inferenceConfiguration?: InferenceConfiguration;
    parserMode?: CreationMode;
    foundationModel?: string;
    additionalModelRequestFields?: any;
}
export declare const PromptConfiguration: S.Schema<PromptConfiguration>;
export type PromptConfigurations = PromptConfiguration[];
export declare const PromptConfigurations: any;
export interface PromptOverrideConfiguration {
    promptConfigurations: PromptConfiguration[];
    overrideLambda?: string;
}
export declare const PromptOverrideConfiguration: S.Schema<PromptOverrideConfiguration>;
export type GuardrailIdentifier = string;
export type GuardrailVersion = string;
export interface GuardrailConfiguration {
    guardrailIdentifier?: string;
    guardrailVersion?: string;
}
export declare const GuardrailConfiguration: S.Schema<GuardrailConfiguration>;
export type MemoryType = "SESSION_SUMMARY" | (string & {});
export declare const MemoryType: any;
export type EnabledMemoryTypes = MemoryType[];
export declare const EnabledMemoryTypes: any;
export type StorageDays = number;
export type MaxRecentSessions = number;
export interface SessionSummaryConfiguration {
    maxRecentSessions?: number;
}
export declare const SessionSummaryConfiguration: S.Schema<SessionSummaryConfiguration>;
export interface MemoryConfiguration {
    enabledMemoryTypes: MemoryType[];
    storageDays?: number;
    sessionSummaryConfiguration?: SessionSummaryConfiguration;
}
export declare const MemoryConfiguration: S.Schema<MemoryConfiguration>;
export type AgentCollaboration = "SUPERVISOR" | "SUPERVISOR_ROUTER" | "DISABLED" | (string & {});
export declare const AgentCollaboration: any;
export interface CreateAgentRequest {
    agentName: string;
    clientToken?: string;
    instruction?: string | redacted.Redacted<string>;
    foundationModel?: string;
    description?: string;
    orchestrationType?: OrchestrationType;
    customOrchestration?: CustomOrchestration;
    idleSessionTTLInSeconds?: number;
    agentResourceRoleArn?: string;
    customerEncryptionKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    promptOverrideConfiguration?: PromptOverrideConfiguration;
    guardrailConfiguration?: GuardrailConfiguration;
    memoryConfiguration?: MemoryConfiguration;
    agentCollaboration?: AgentCollaboration;
}
export declare const CreateAgentRequest: S.Schema<CreateAgentRequest>;
export type AgentArn = string;
export type AgentStatus = "CREATING" | "PREPARING" | "PREPARED" | "NOT_PREPARED" | "DELETING" | "FAILED" | "VERSIONING" | "UPDATING" | (string & {});
export declare const AgentStatus: any;
export type FailureReason = string;
export type FailureReasons = string[];
export declare const FailureReasons: any;
export type RecommendedAction = string;
export type RecommendedActions = string[];
export declare const RecommendedActions: any;
export interface Agent {
    agentId: string;
    agentName: string;
    agentArn: string;
    agentVersion?: string;
    clientToken?: string;
    instruction?: string | redacted.Redacted<string>;
    agentStatus: AgentStatus;
    foundationModel?: string;
    description?: string;
    orchestrationType?: OrchestrationType;
    customOrchestration?: CustomOrchestration;
    idleSessionTTLInSeconds: number;
    agentResourceRoleArn: string;
    customerEncryptionKeyArn?: string;
    createdAt: Date;
    updatedAt: Date;
    preparedAt?: Date;
    failureReasons?: string[];
    recommendedActions?: string[];
    promptOverrideConfiguration?: PromptOverrideConfiguration;
    guardrailConfiguration?: GuardrailConfiguration;
    memoryConfiguration?: MemoryConfiguration;
    agentCollaboration?: AgentCollaboration;
}
export declare const Agent: S.Schema<Agent>;
export interface CreateAgentResponse {
    agent: Agent;
}
export declare const CreateAgentResponse: S.Schema<CreateAgentResponse>;
export type ActionGroupSignature = "AMAZON.UserInput" | "AMAZON.CodeInterpreter" | "ANTHROPIC.Computer" | "ANTHROPIC.Bash" | "ANTHROPIC.TextEditor" | (string & {});
export declare const ActionGroupSignature: any;
export type ActionGroupSignatureParams = {
    [key: string]: string | undefined;
};
export declare const ActionGroupSignatureParams: any;
export type CustomControlMethod = "RETURN_CONTROL" | (string & {});
export declare const CustomControlMethod: any;
export type ActionGroupExecutor = {
    lambda: string;
    customControl?: never;
} | {
    lambda?: never;
    customControl: CustomControlMethod;
};
export declare const ActionGroupExecutor: any;
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3Identifier {
    s3BucketName?: string;
    s3ObjectKey?: string;
}
export declare const S3Identifier: S.Schema<S3Identifier>;
export type Payload = string | redacted.Redacted<string>;
export type APISchema = {
    s3: S3Identifier;
    payload?: never;
} | {
    s3?: never;
    payload: string | redacted.Redacted<string>;
};
export declare const APISchema: any;
export type ActionGroupState = "ENABLED" | "DISABLED" | (string & {});
export declare const ActionGroupState: any;
export type FunctionDescription = string;
export type ParameterDescription = string;
export type Type = "string" | "number" | "integer" | "boolean" | "array" | (string & {});
export declare const Type: any;
export interface ParameterDetail {
    description?: string;
    type: Type;
    required?: boolean;
}
export declare const ParameterDetail: S.Schema<ParameterDetail>;
export type ParameterMap = {
    [key: string]: ParameterDetail | undefined;
};
export declare const ParameterMap: any;
export type RequireConfirmation = "ENABLED" | "DISABLED" | (string & {});
export declare const RequireConfirmation: any;
export interface Function {
    name: string;
    description?: string;
    parameters?: {
        [key: string]: ParameterDetail | undefined;
    };
    requireConfirmation?: RequireConfirmation;
}
export declare const Function: S.Schema<Function>;
export type Functions = Function[];
export declare const Functions: any;
export type FunctionSchema = {
    functions: Function[];
};
export declare const FunctionSchema: any;
export interface CreateAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupName: string;
    clientToken?: string;
    description?: string;
    parentActionGroupSignature?: ActionGroupSignature;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    };
    actionGroupExecutor?: ActionGroupExecutor;
    apiSchema?: APISchema;
    actionGroupState?: ActionGroupState;
    functionSchema?: FunctionSchema;
}
export declare const CreateAgentActionGroupRequest: S.Schema<CreateAgentActionGroupRequest>;
export interface AgentActionGroup {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
    actionGroupName: string;
    clientToken?: string;
    description?: string;
    createdAt: Date;
    updatedAt: Date;
    parentActionSignature?: ActionGroupSignature;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    };
    actionGroupExecutor?: ActionGroupExecutor;
    apiSchema?: APISchema;
    functionSchema?: FunctionSchema;
    actionGroupState: ActionGroupState;
}
export declare const AgentActionGroup: S.Schema<AgentActionGroup>;
export interface CreateAgentActionGroupResponse {
    agentActionGroup: AgentActionGroup;
}
export declare const CreateAgentActionGroupResponse: S.Schema<CreateAgentActionGroupResponse>;
export type ProvisionedModelIdentifier = string;
export interface AgentAliasRoutingConfigurationListItem {
    agentVersion?: string;
    provisionedThroughput?: string;
}
export declare const AgentAliasRoutingConfigurationListItem: S.Schema<AgentAliasRoutingConfigurationListItem>;
export type AgentAliasRoutingConfiguration = AgentAliasRoutingConfigurationListItem[];
export declare const AgentAliasRoutingConfiguration: any;
export interface CreateAgentAliasRequest {
    agentId: string;
    agentAliasName: string;
    clientToken?: string;
    description?: string;
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAgentAliasRequest: S.Schema<CreateAgentAliasRequest>;
export type AgentAliasId = string;
export interface AgentAliasHistoryEvent {
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[];
    endDate?: Date;
    startDate?: Date;
}
export declare const AgentAliasHistoryEvent: S.Schema<AgentAliasHistoryEvent>;
export type AgentAliasHistoryEvents = AgentAliasHistoryEvent[];
export declare const AgentAliasHistoryEvents: any;
export type AgentAliasStatus = "CREATING" | "PREPARED" | "FAILED" | "UPDATING" | "DELETING" | "DISSOCIATED" | (string & {});
export declare const AgentAliasStatus: any;
export type AliasInvocationState = "ACCEPT_INVOCATIONS" | "REJECT_INVOCATIONS" | (string & {});
export declare const AliasInvocationState: any;
export interface AgentAlias {
    agentId: string;
    agentAliasId: string;
    agentAliasName: string;
    agentAliasArn: string;
    clientToken?: string;
    description?: string;
    routingConfiguration: AgentAliasRoutingConfigurationListItem[];
    createdAt: Date;
    updatedAt: Date;
    agentAliasHistoryEvents?: AgentAliasHistoryEvent[];
    agentAliasStatus: AgentAliasStatus;
    failureReasons?: string[];
    aliasInvocationState?: AliasInvocationState;
}
export declare const AgentAlias: S.Schema<AgentAlias>;
export interface CreateAgentAliasResponse {
    agentAlias: AgentAlias;
}
export declare const CreateAgentAliasResponse: S.Schema<CreateAgentAliasResponse>;
export type DataSourceType = "S3" | "WEB" | "CONFLUENCE" | "SALESFORCE" | "SHAREPOINT" | "CUSTOM" | "REDSHIFT_METADATA" | "MANAGED_KNOWLEDGE_BASE_CONNECTOR" | (string & {});
export declare const DataSourceType: any;
export type EnabledOrDisabledState = "ENABLED" | "DISABLED" | (string & {});
export declare const EnabledOrDisabledState: any;
export interface DeletionProtectionConfiguration {
    deletionProtectionStatus: EnabledOrDisabledState;
    deletionProtectionThreshold?: number;
}
export declare const DeletionProtectionConfiguration: S.Schema<DeletionProtectionConfiguration>;
export interface ImageExtractionConfiguration {
    imageExtractionStatus: EnabledOrDisabledState;
}
export declare const ImageExtractionConfiguration: S.Schema<ImageExtractionConfiguration>;
export interface AudioExtractionConfiguration {
    audioExtractionStatus: EnabledOrDisabledState;
}
export declare const AudioExtractionConfiguration: S.Schema<AudioExtractionConfiguration>;
export interface VideoExtractionConfiguration {
    videoExtractionStatus: EnabledOrDisabledState;
}
export declare const VideoExtractionConfiguration: S.Schema<VideoExtractionConfiguration>;
export interface MediaExtractionConfiguration {
    imageExtractionConfiguration?: ImageExtractionConfiguration;
    audioExtractionConfiguration?: AudioExtractionConfiguration;
    videoExtractionConfiguration?: VideoExtractionConfiguration;
}
export declare const MediaExtractionConfiguration: S.Schema<MediaExtractionConfiguration>;
export interface DailySchedule {
}
export declare const DailySchedule: S.Schema<DailySchedule>;
export type DayOfWeek = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export declare const DayOfWeek: any;
export interface WeeklySchedule {
    dayOfWeek: DayOfWeek;
}
export declare const WeeklySchedule: S.Schema<WeeklySchedule>;
export type DayOfMonthNumber = number;
export interface LastDayOfMonth {
}
export declare const LastDayOfMonth: S.Schema<LastDayOfMonth>;
export type DayOfMonth = {
    dayNumber: number;
    lastDayOfMonth?: never;
} | {
    dayNumber?: never;
    lastDayOfMonth: LastDayOfMonth;
};
export declare const DayOfMonth: any;
export interface MonthlySchedule {
    dayOfMonth: DayOfMonth;
}
export declare const MonthlySchedule: S.Schema<MonthlySchedule>;
export type SyncSchedule = {
    daily: DailySchedule;
    weekly?: never;
    monthly?: never;
} | {
    daily?: never;
    weekly: WeeklySchedule;
    monthly?: never;
} | {
    daily?: never;
    weekly?: never;
    monthly: MonthlySchedule;
};
export declare const SyncSchedule: any;
export interface ManagedKnowledgeBaseConnectorConfiguration {
    deletionProtectionConfiguration?: DeletionProtectionConfiguration;
    mediaExtractionConfiguration?: MediaExtractionConfiguration;
    connectorParameters?: any;
    syncSchedule?: SyncSchedule;
}
export declare const ManagedKnowledgeBaseConnectorConfiguration: S.Schema<ManagedKnowledgeBaseConnectorConfiguration>;
export type S3BucketArn = string;
export type S3Prefix = string | redacted.Redacted<string>;
export type S3Prefixes = (string | redacted.Redacted<string>)[];
export declare const S3Prefixes: any;
export type BucketOwnerAccountId = string;
export interface S3DataSourceConfiguration {
    bucketArn: string;
    inclusionPrefixes?: (string | redacted.Redacted<string>)[];
    bucketOwnerAccountId?: string;
}
export declare const S3DataSourceConfiguration: S.Schema<S3DataSourceConfiguration>;
export type Url = string;
export interface SeedUrl {
    url?: string;
}
export declare const SeedUrl: S.Schema<SeedUrl>;
export type SeedUrls = SeedUrl[];
export declare const SeedUrls: any;
export interface UrlConfiguration {
    seedUrls?: SeedUrl[];
}
export declare const UrlConfiguration: S.Schema<UrlConfiguration>;
export interface WebSourceConfiguration {
    urlConfiguration: UrlConfiguration;
}
export declare const WebSourceConfiguration: S.Schema<WebSourceConfiguration>;
export interface WebCrawlerLimits {
    rateLimit?: number;
    maxPages?: number;
}
export declare const WebCrawlerLimits: S.Schema<WebCrawlerLimits>;
export type FilterPattern = string | redacted.Redacted<string>;
export type FilterList = (string | redacted.Redacted<string>)[];
export declare const FilterList: any;
export type WebScopeType = "HOST_ONLY" | "SUBDOMAINS" | (string & {});
export declare const WebScopeType: any;
export type UserAgent = string | redacted.Redacted<string>;
export type UserAgentHeader = string | redacted.Redacted<string>;
export interface WebCrawlerConfiguration {
    crawlerLimits?: WebCrawlerLimits;
    inclusionFilters?: (string | redacted.Redacted<string>)[];
    exclusionFilters?: (string | redacted.Redacted<string>)[];
    scope?: WebScopeType;
    userAgent?: string | redacted.Redacted<string>;
    userAgentHeader?: string | redacted.Redacted<string>;
}
export declare const WebCrawlerConfiguration: S.Schema<WebCrawlerConfiguration>;
export interface WebDataSourceConfiguration {
    sourceConfiguration: WebSourceConfiguration;
    crawlerConfiguration?: WebCrawlerConfiguration;
}
export declare const WebDataSourceConfiguration: S.Schema<WebDataSourceConfiguration>;
export type HttpsUrl = string;
export type ConfluenceHostType = "SAAS" | (string & {});
export declare const ConfluenceHostType: any;
export type ConfluenceAuthType = "BASIC" | "OAUTH2_CLIENT_CREDENTIALS" | (string & {});
export declare const ConfluenceAuthType: any;
export type SecretArn = string;
export interface ConfluenceSourceConfiguration {
    hostUrl: string;
    hostType: ConfluenceHostType;
    authType: ConfluenceAuthType;
    credentialsSecretArn: string;
}
export declare const ConfluenceSourceConfiguration: S.Schema<ConfluenceSourceConfiguration>;
export type CrawlFilterConfigurationType = "PATTERN" | (string & {});
export declare const CrawlFilterConfigurationType: any;
export type FilteredObjectType = string | redacted.Redacted<string>;
export interface PatternObjectFilter {
    objectType: string | redacted.Redacted<string>;
    inclusionFilters?: (string | redacted.Redacted<string>)[];
    exclusionFilters?: (string | redacted.Redacted<string>)[];
}
export declare const PatternObjectFilter: S.Schema<PatternObjectFilter>;
export type PatternObjectFilterList = PatternObjectFilter[];
export declare const PatternObjectFilterList: any;
export interface PatternObjectFilterConfiguration {
    filters: PatternObjectFilter[];
}
export declare const PatternObjectFilterConfiguration: S.Schema<PatternObjectFilterConfiguration>;
export interface CrawlFilterConfiguration {
    type: CrawlFilterConfigurationType;
    patternObjectFilter?: PatternObjectFilterConfiguration;
}
export declare const CrawlFilterConfiguration: S.Schema<CrawlFilterConfiguration>;
export interface ConfluenceCrawlerConfiguration {
    filterConfiguration?: CrawlFilterConfiguration;
}
export declare const ConfluenceCrawlerConfiguration: S.Schema<ConfluenceCrawlerConfiguration>;
export interface ConfluenceDataSourceConfiguration {
    sourceConfiguration: ConfluenceSourceConfiguration;
    crawlerConfiguration?: ConfluenceCrawlerConfiguration;
}
export declare const ConfluenceDataSourceConfiguration: S.Schema<ConfluenceDataSourceConfiguration>;
export type SalesforceAuthType = "OAUTH2_CLIENT_CREDENTIALS" | (string & {});
export declare const SalesforceAuthType: any;
export interface SalesforceSourceConfiguration {
    hostUrl: string;
    authType: SalesforceAuthType;
    credentialsSecretArn: string;
}
export declare const SalesforceSourceConfiguration: S.Schema<SalesforceSourceConfiguration>;
export interface SalesforceCrawlerConfiguration {
    filterConfiguration?: CrawlFilterConfiguration;
}
export declare const SalesforceCrawlerConfiguration: S.Schema<SalesforceCrawlerConfiguration>;
export interface SalesforceDataSourceConfiguration {
    sourceConfiguration: SalesforceSourceConfiguration;
    crawlerConfiguration?: SalesforceCrawlerConfiguration;
}
export declare const SalesforceDataSourceConfiguration: S.Schema<SalesforceDataSourceConfiguration>;
export type Microsoft365TenantId = string;
export type SharePointDomain = string;
export type SharePointSiteUrls = string[];
export declare const SharePointSiteUrls: any;
export type SharePointHostType = "ONLINE" | (string & {});
export declare const SharePointHostType: any;
export type SharePointAuthType = "OAUTH2_CLIENT_CREDENTIALS" | "OAUTH2_SHAREPOINT_APP_ONLY_CLIENT_CREDENTIALS" | (string & {});
export declare const SharePointAuthType: any;
export interface SharePointSourceConfiguration {
    tenantId?: string;
    domain: string;
    siteUrls: string[];
    hostType: SharePointHostType;
    authType: SharePointAuthType;
    credentialsSecretArn: string;
}
export declare const SharePointSourceConfiguration: S.Schema<SharePointSourceConfiguration>;
export interface SharePointCrawlerConfiguration {
    filterConfiguration?: CrawlFilterConfiguration;
}
export declare const SharePointCrawlerConfiguration: S.Schema<SharePointCrawlerConfiguration>;
export interface SharePointDataSourceConfiguration {
    sourceConfiguration: SharePointSourceConfiguration;
    crawlerConfiguration?: SharePointCrawlerConfiguration;
}
export declare const SharePointDataSourceConfiguration: S.Schema<SharePointDataSourceConfiguration>;
export interface DataSourceConfiguration {
    type: DataSourceType;
    managedKnowledgeBaseConnectorConfiguration?: ManagedKnowledgeBaseConnectorConfiguration;
    s3Configuration?: S3DataSourceConfiguration;
    webConfiguration?: WebDataSourceConfiguration;
    confluenceConfiguration?: ConfluenceDataSourceConfiguration;
    salesforceConfiguration?: SalesforceDataSourceConfiguration;
    sharePointConfiguration?: SharePointDataSourceConfiguration;
}
export declare const DataSourceConfiguration: S.Schema<DataSourceConfiguration>;
export type DataDeletionPolicy = "RETAIN" | "DELETE" | (string & {});
export declare const DataDeletionPolicy: any;
export interface ServerSideEncryptionConfiguration {
    kmsKeyArn?: string;
}
export declare const ServerSideEncryptionConfiguration: S.Schema<ServerSideEncryptionConfiguration>;
export type ChunkingStrategy = "FIXED_SIZE" | "NONE" | "HIERARCHICAL" | "SEMANTIC" | (string & {});
export declare const ChunkingStrategy: any;
export interface FixedSizeChunkingConfiguration {
    maxTokens: number;
    overlapPercentage: number;
}
export declare const FixedSizeChunkingConfiguration: S.Schema<FixedSizeChunkingConfiguration>;
export interface HierarchicalChunkingLevelConfiguration {
    maxTokens: number;
}
export declare const HierarchicalChunkingLevelConfiguration: S.Schema<HierarchicalChunkingLevelConfiguration>;
export type HierarchicalChunkingLevelConfigurations = HierarchicalChunkingLevelConfiguration[];
export declare const HierarchicalChunkingLevelConfigurations: any;
export interface HierarchicalChunkingConfiguration {
    levelConfigurations: HierarchicalChunkingLevelConfiguration[];
    overlapTokens: number;
}
export declare const HierarchicalChunkingConfiguration: S.Schema<HierarchicalChunkingConfiguration>;
export interface SemanticChunkingConfiguration {
    maxTokens: number;
    bufferSize: number;
    breakpointPercentileThreshold: number;
}
export declare const SemanticChunkingConfiguration: S.Schema<SemanticChunkingConfiguration>;
export interface ChunkingConfiguration {
    chunkingStrategy: ChunkingStrategy;
    fixedSizeChunkingConfiguration?: FixedSizeChunkingConfiguration;
    hierarchicalChunkingConfiguration?: HierarchicalChunkingConfiguration;
    semanticChunkingConfiguration?: SemanticChunkingConfiguration;
}
export declare const ChunkingConfiguration: S.Schema<ChunkingConfiguration>;
export type S3BucketUri = string;
export interface S3Location {
    uri: string;
}
export declare const S3Location: S.Schema<S3Location>;
export interface IntermediateStorage {
    s3Location: S3Location;
}
export declare const IntermediateStorage: S.Schema<IntermediateStorage>;
export interface TransformationLambdaConfiguration {
    lambdaArn: string;
}
export declare const TransformationLambdaConfiguration: S.Schema<TransformationLambdaConfiguration>;
export interface TransformationFunction {
    transformationLambdaConfiguration: TransformationLambdaConfiguration;
}
export declare const TransformationFunction: S.Schema<TransformationFunction>;
export type StepType = "POST_CHUNKING" | (string & {});
export declare const StepType: any;
export interface Transformation {
    transformationFunction: TransformationFunction;
    stepToApply: StepType;
}
export declare const Transformation: S.Schema<Transformation>;
export type Transformations = Transformation[];
export declare const Transformations: any;
export interface CustomTransformationConfiguration {
    intermediateStorage: IntermediateStorage;
    transformations: Transformation[];
}
export declare const CustomTransformationConfiguration: S.Schema<CustomTransformationConfiguration>;
export type ParsingStrategy = "BEDROCK_FOUNDATION_MODEL" | "BEDROCK_DATA_AUTOMATION" | "SMART_PARSING" | (string & {});
export declare const ParsingStrategy: any;
export type BedrockModelArn = string;
export type ParsingPromptText = string;
export interface ParsingPrompt {
    parsingPromptText: string;
}
export declare const ParsingPrompt: S.Schema<ParsingPrompt>;
export type ParsingModality = "MULTIMODAL" | (string & {});
export declare const ParsingModality: any;
export interface BedrockFoundationModelConfiguration {
    modelArn: string;
    parsingPrompt?: ParsingPrompt;
    parsingModality?: ParsingModality;
}
export declare const BedrockFoundationModelConfiguration: S.Schema<BedrockFoundationModelConfiguration>;
export interface BedrockDataAutomationConfiguration {
    parsingModality?: ParsingModality;
}
export declare const BedrockDataAutomationConfiguration: S.Schema<BedrockDataAutomationConfiguration>;
export interface ParsingConfiguration {
    parsingStrategy: ParsingStrategy;
    bedrockFoundationModelConfiguration?: BedrockFoundationModelConfiguration;
    bedrockDataAutomationConfiguration?: BedrockDataAutomationConfiguration;
}
export declare const ParsingConfiguration: S.Schema<ParsingConfiguration>;
export type ContextEnrichmentType = "BEDROCK_FOUNDATION_MODEL" | (string & {});
export declare const ContextEnrichmentType: any;
export type EnrichmentStrategyMethod = "CHUNK_ENTITY_EXTRACTION" | (string & {});
export declare const EnrichmentStrategyMethod: any;
export interface EnrichmentStrategyConfiguration {
    method: EnrichmentStrategyMethod;
}
export declare const EnrichmentStrategyConfiguration: S.Schema<EnrichmentStrategyConfiguration>;
export interface BedrockFoundationModelContextEnrichmentConfiguration {
    enrichmentStrategyConfiguration: EnrichmentStrategyConfiguration;
    modelArn: string;
}
export declare const BedrockFoundationModelContextEnrichmentConfiguration: S.Schema<BedrockFoundationModelContextEnrichmentConfiguration>;
export interface ContextEnrichmentConfiguration {
    type: ContextEnrichmentType;
    bedrockFoundationModelConfiguration?: BedrockFoundationModelContextEnrichmentConfiguration;
}
export declare const ContextEnrichmentConfiguration: S.Schema<ContextEnrichmentConfiguration>;
export interface VectorIngestionConfiguration {
    chunkingConfiguration?: ChunkingConfiguration;
    customTransformationConfiguration?: CustomTransformationConfiguration;
    parsingConfiguration?: ParsingConfiguration;
    contextEnrichmentConfiguration?: ContextEnrichmentConfiguration;
}
export declare const VectorIngestionConfiguration: S.Schema<VectorIngestionConfiguration>;
export interface CreateDataSourceRequest {
    knowledgeBaseId: string;
    clientToken?: string;
    name: string;
    description?: string;
    dataSourceConfiguration: DataSourceConfiguration;
    dataDeletionPolicy?: DataDeletionPolicy;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    vectorIngestionConfiguration?: VectorIngestionConfiguration;
}
export declare const CreateDataSourceRequest: S.Schema<CreateDataSourceRequest>;
export type DataSourceStatus = "AVAILABLE" | "DELETING" | "DELETE_UNSUCCESSFUL" | "CREATING" | "UPDATING" | "FAILED" | (string & {});
export declare const DataSourceStatus: any;
export interface DataSource {
    knowledgeBaseId: string;
    dataSourceId: string;
    name: string;
    status: DataSourceStatus;
    description?: string;
    dataSourceConfiguration: DataSourceConfiguration;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    vectorIngestionConfiguration?: VectorIngestionConfiguration;
    dataDeletionPolicy?: DataDeletionPolicy;
    createdAt: Date;
    updatedAt: Date;
    failureReasons?: string[];
}
export declare const DataSource: S.Schema<DataSource>;
export interface CreateDataSourceResponse {
    dataSource: DataSource;
}
export declare const CreateDataSourceResponse: S.Schema<CreateDataSourceResponse>;
export type FlowName = string;
export type FlowDescription = string;
export type FlowExecutionRoleArn = string;
export type FlowNodeName = string;
export type FlowNodeType = "Input" | "Output" | "KnowledgeBase" | "Condition" | "Lex" | "Prompt" | "LambdaFunction" | "Storage" | "Agent" | "Retrieval" | "Iterator" | "Collector" | "InlineCode" | "Loop" | "LoopInput" | "LoopController" | (string & {});
export declare const FlowNodeType: any;
export interface InputFlowNodeConfiguration {
}
export declare const InputFlowNodeConfiguration: S.Schema<InputFlowNodeConfiguration>;
export interface OutputFlowNodeConfiguration {
}
export declare const OutputFlowNodeConfiguration: S.Schema<OutputFlowNodeConfiguration>;
export type FlowKnowledgeBaseId = string;
export type KnowledgeBaseModelIdentifier = string;
export type KnowledgeBaseTextPrompt = string | redacted.Redacted<string>;
export interface KnowledgeBasePromptTemplate {
    textPromptTemplate?: string | redacted.Redacted<string>;
}
export declare const KnowledgeBasePromptTemplate: S.Schema<KnowledgeBasePromptTemplate>;
export interface PromptModelInferenceConfiguration {
    temperature?: number;
    topP?: number;
    maxTokens?: number;
    stopSequences?: string[];
}
export declare const PromptModelInferenceConfiguration: S.Schema<PromptModelInferenceConfiguration>;
export type PromptInferenceConfiguration = {
    text: PromptModelInferenceConfiguration;
};
export declare const PromptInferenceConfiguration: any;
export type VectorSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export declare const VectorSearchRerankingConfigurationType: any;
export type BedrockRerankingModelArn = string;
export type AdditionalModelRequestFieldsKey = string;
export type AdditionalModelRequestFieldsValue = unknown;
export type AdditionalModelRequestFields = {
    [key: string]: any | undefined;
};
export declare const AdditionalModelRequestFields: any;
export interface VectorSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
}
export declare const VectorSearchBedrockRerankingModelConfiguration: S.Schema<VectorSearchBedrockRerankingModelConfiguration>;
export type RerankingMetadataSelectionMode = "SELECTIVE" | "ALL" | (string & {});
export declare const RerankingMetadataSelectionMode: any;
export interface FieldForReranking {
    fieldName: string;
}
export declare const FieldForReranking: S.Schema<FieldForReranking>;
export type FieldsForReranking = FieldForReranking[];
export declare const FieldsForReranking: any;
export type RerankingMetadataSelectiveModeConfiguration = {
    fieldsToInclude: FieldForReranking[];
    fieldsToExclude?: never;
} | {
    fieldsToInclude?: never;
    fieldsToExclude: FieldForReranking[];
};
export declare const RerankingMetadataSelectiveModeConfiguration: any;
export interface MetadataConfigurationForReranking {
    selectionMode: RerankingMetadataSelectionMode;
    selectiveModeConfiguration?: RerankingMetadataSelectiveModeConfiguration;
}
export declare const MetadataConfigurationForReranking: S.Schema<MetadataConfigurationForReranking>;
export interface VectorSearchBedrockRerankingConfiguration {
    modelConfiguration: VectorSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number;
    metadataConfiguration?: MetadataConfigurationForReranking;
}
export declare const VectorSearchBedrockRerankingConfiguration: S.Schema<VectorSearchBedrockRerankingConfiguration>;
export interface VectorSearchRerankingConfiguration {
    type: VectorSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: VectorSearchBedrockRerankingConfiguration;
}
export declare const VectorSearchRerankingConfiguration: S.Schema<VectorSearchRerankingConfiguration>;
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export declare const PerformanceConfigLatency: any;
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency;
}
export declare const PerformanceConfiguration: S.Schema<PerformanceConfiguration>;
export interface KnowledgeBaseOrchestrationConfiguration {
    promptTemplate?: KnowledgeBasePromptTemplate;
    inferenceConfig?: PromptInferenceConfiguration;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    };
    performanceConfig?: PerformanceConfiguration;
}
export declare const KnowledgeBaseOrchestrationConfiguration: S.Schema<KnowledgeBaseOrchestrationConfiguration>;
export interface KnowledgeBaseFlowNodeConfiguration {
    knowledgeBaseId: string;
    modelId?: string;
    guardrailConfiguration?: GuardrailConfiguration;
    numberOfResults?: number;
    promptTemplate?: KnowledgeBasePromptTemplate;
    inferenceConfiguration?: PromptInferenceConfiguration;
    rerankingConfiguration?: VectorSearchRerankingConfiguration;
    orchestrationConfiguration?: KnowledgeBaseOrchestrationConfiguration;
}
export declare const KnowledgeBaseFlowNodeConfiguration: S.Schema<KnowledgeBaseFlowNodeConfiguration>;
export type FlowConditionName = string;
export type FlowConditionExpression = string | redacted.Redacted<string>;
export interface FlowCondition {
    name: string;
    expression?: string | redacted.Redacted<string>;
}
export declare const FlowCondition: S.Schema<FlowCondition>;
export type FlowConditions = FlowCondition[];
export declare const FlowConditions: any;
export interface ConditionFlowNodeConfiguration {
    conditions: FlowCondition[];
}
export declare const ConditionFlowNodeConfiguration: S.Schema<ConditionFlowNodeConfiguration>;
export type FlowLexBotAliasArn = string;
export type FlowLexBotLocaleId = string;
export interface LexFlowNodeConfiguration {
    botAliasArn: string;
    localeId: string;
}
export declare const LexFlowNodeConfiguration: S.Schema<LexFlowNodeConfiguration>;
export type FlowPromptArn = string;
export interface PromptFlowNodeResourceConfiguration {
    promptArn: string;
}
export declare const PromptFlowNodeResourceConfiguration: S.Schema<PromptFlowNodeResourceConfiguration>;
export type PromptTemplateType = "TEXT" | "CHAT" | (string & {});
export declare const PromptTemplateType: any;
export type TextPrompt = string | redacted.Redacted<string>;
export type CachePointType = "default" | (string & {});
export declare const CachePointType: any;
export interface CachePointBlock {
    type: CachePointType;
}
export declare const CachePointBlock: S.Schema<CachePointBlock>;
export type PromptInputVariableName = string;
export interface PromptInputVariable {
    name?: string;
}
export declare const PromptInputVariable: S.Schema<PromptInputVariable>;
export type PromptInputVariablesList = PromptInputVariable[];
export declare const PromptInputVariablesList: any;
export interface TextPromptTemplateConfiguration {
    text: string | redacted.Redacted<string>;
    cachePoint?: CachePointBlock;
    inputVariables?: PromptInputVariable[];
}
export declare const TextPromptTemplateConfiguration: S.Schema<TextPromptTemplateConfiguration>;
export type ConversationRole = "user" | "assistant" | (string & {});
export declare const ConversationRole: any;
export type ContentBlock = {
    text: string;
    cachePoint?: never;
} | {
    text?: never;
    cachePoint: CachePointBlock;
};
export declare const ContentBlock: any;
export type ContentBlocks = ContentBlock[];
export declare const ContentBlocks: any;
export interface Message {
    role: ConversationRole;
    content: ContentBlock[];
}
export declare const Message: S.Schema<Message>;
export type Messages = Message[];
export declare const Messages: any;
export type NonEmptyString = string;
export type SystemContentBlock = {
    text: string;
    cachePoint?: never;
} | {
    text?: never;
    cachePoint: CachePointBlock;
};
export declare const SystemContentBlock: any;
export type SystemContentBlocks = SystemContentBlock[];
export declare const SystemContentBlocks: any;
export type ToolName = string;
export type ToolInputSchema = {
    json: any;
};
export declare const ToolInputSchema: any;
export interface ToolSpecification {
    name: string;
    description?: string;
    inputSchema: ToolInputSchema;
    strict?: boolean;
}
export declare const ToolSpecification: S.Schema<ToolSpecification>;
export type Tool = {
    toolSpec: ToolSpecification;
    cachePoint?: never;
} | {
    toolSpec?: never;
    cachePoint: CachePointBlock;
};
export declare const Tool: any;
export type Tools = Tool[];
export declare const Tools: any;
export interface AutoToolChoice {
}
export declare const AutoToolChoice: S.Schema<AutoToolChoice>;
export interface AnyToolChoice {
}
export declare const AnyToolChoice: S.Schema<AnyToolChoice>;
export interface SpecificToolChoice {
    name: string;
}
export declare const SpecificToolChoice: S.Schema<SpecificToolChoice>;
export type ToolChoice = {
    auto: AutoToolChoice;
    any?: never;
    tool?: never;
} | {
    auto?: never;
    any: AnyToolChoice;
    tool?: never;
} | {
    auto?: never;
    any?: never;
    tool: SpecificToolChoice;
};
export declare const ToolChoice: any;
export interface ToolConfiguration {
    tools: Tool[];
    toolChoice?: ToolChoice;
}
export declare const ToolConfiguration: S.Schema<ToolConfiguration>;
export interface ChatPromptTemplateConfiguration {
    messages: Message[];
    system?: SystemContentBlock[];
    inputVariables?: PromptInputVariable[];
    toolConfiguration?: ToolConfiguration;
}
export declare const ChatPromptTemplateConfiguration: S.Schema<ChatPromptTemplateConfiguration>;
export type PromptTemplateConfiguration = {
    text: TextPromptTemplateConfiguration;
    chat?: never;
} | {
    text?: never;
    chat: ChatPromptTemplateConfiguration;
};
export declare const PromptTemplateConfiguration: any;
export type FlowPromptModelIdentifier = string;
export interface PromptFlowNodeInlineConfiguration {
    templateType: PromptTemplateType;
    templateConfiguration: PromptTemplateConfiguration;
    modelId: string;
    inferenceConfiguration?: PromptInferenceConfiguration;
    additionalModelRequestFields?: any;
}
export declare const PromptFlowNodeInlineConfiguration: S.Schema<PromptFlowNodeInlineConfiguration>;
export type PromptFlowNodeSourceConfiguration = {
    resource: PromptFlowNodeResourceConfiguration;
    inline?: never;
} | {
    resource?: never;
    inline: PromptFlowNodeInlineConfiguration;
};
export declare const PromptFlowNodeSourceConfiguration: any;
export interface PromptFlowNodeConfiguration {
    sourceConfiguration: PromptFlowNodeSourceConfiguration;
    guardrailConfiguration?: GuardrailConfiguration;
}
export declare const PromptFlowNodeConfiguration: S.Schema<PromptFlowNodeConfiguration>;
export type FlowLambdaArn = string;
export interface LambdaFunctionFlowNodeConfiguration {
    lambdaArn: string;
}
export declare const LambdaFunctionFlowNodeConfiguration: S.Schema<LambdaFunctionFlowNodeConfiguration>;
export type FlowS3BucketName = string;
export interface StorageFlowNodeS3Configuration {
    bucketName: string;
}
export declare const StorageFlowNodeS3Configuration: S.Schema<StorageFlowNodeS3Configuration>;
export type StorageFlowNodeServiceConfiguration = {
    s3: StorageFlowNodeS3Configuration;
};
export declare const StorageFlowNodeServiceConfiguration: any;
export interface StorageFlowNodeConfiguration {
    serviceConfiguration: StorageFlowNodeServiceConfiguration;
}
export declare const StorageFlowNodeConfiguration: S.Schema<StorageFlowNodeConfiguration>;
export type FlowAgentAliasArn = string;
export interface AgentFlowNodeConfiguration {
    agentAliasArn: string;
}
export declare const AgentFlowNodeConfiguration: S.Schema<AgentFlowNodeConfiguration>;
export interface RetrievalFlowNodeS3Configuration {
    bucketName: string;
}
export declare const RetrievalFlowNodeS3Configuration: S.Schema<RetrievalFlowNodeS3Configuration>;
export type RetrievalFlowNodeServiceConfiguration = {
    s3: RetrievalFlowNodeS3Configuration;
};
export declare const RetrievalFlowNodeServiceConfiguration: any;
export interface RetrievalFlowNodeConfiguration {
    serviceConfiguration: RetrievalFlowNodeServiceConfiguration;
}
export declare const RetrievalFlowNodeConfiguration: S.Schema<RetrievalFlowNodeConfiguration>;
export interface IteratorFlowNodeConfiguration {
}
export declare const IteratorFlowNodeConfiguration: S.Schema<IteratorFlowNodeConfiguration>;
export interface CollectorFlowNodeConfiguration {
}
export declare const CollectorFlowNodeConfiguration: S.Schema<CollectorFlowNodeConfiguration>;
export type InlineCode = string | redacted.Redacted<string>;
export type SupportedLanguages = "Python_3" | (string & {});
export declare const SupportedLanguages: any;
export interface InlineCodeFlowNodeConfiguration {
    code: string | redacted.Redacted<string>;
    language: SupportedLanguages;
}
export declare const InlineCodeFlowNodeConfiguration: S.Schema<InlineCodeFlowNodeConfiguration>;
export interface LoopFlowNodeConfiguration {
    definition: FlowDefinition;
}
export declare const LoopFlowNodeConfiguration: S.Schema<LoopFlowNodeConfiguration>;
export interface LoopInputFlowNodeConfiguration {
}
export declare const LoopInputFlowNodeConfiguration: S.Schema<LoopInputFlowNodeConfiguration>;
export interface LoopControllerFlowNodeConfiguration {
    continueCondition: FlowCondition;
    maxIterations?: number;
}
export declare const LoopControllerFlowNodeConfiguration: S.Schema<LoopControllerFlowNodeConfiguration>;
export type FlowNodeConfiguration = {
    input: InputFlowNodeConfiguration;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output: OutputFlowNodeConfiguration;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase: KnowledgeBaseFlowNodeConfiguration;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition: ConditionFlowNodeConfiguration;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex: LexFlowNodeConfiguration;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt: PromptFlowNodeConfiguration;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction: LambdaFunctionFlowNodeConfiguration;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage: StorageFlowNodeConfiguration;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent: AgentFlowNodeConfiguration;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval: RetrievalFlowNodeConfiguration;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator: IteratorFlowNodeConfiguration;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector: CollectorFlowNodeConfiguration;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode: InlineCodeFlowNodeConfiguration;
    loop?: never;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop: LoopFlowNodeConfiguration;
    loopInput?: never;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput: LoopInputFlowNodeConfiguration;
    loopController?: never;
} | {
    input?: never;
    output?: never;
    knowledgeBase?: never;
    condition?: never;
    lex?: never;
    prompt?: never;
    lambdaFunction?: never;
    storage?: never;
    agent?: never;
    retrieval?: never;
    iterator?: never;
    collector?: never;
    inlineCode?: never;
    loop?: never;
    loopInput?: never;
    loopController: LoopControllerFlowNodeConfiguration;
};
export declare const FlowNodeConfiguration: S.Schema<FlowNodeConfiguration>;
export type FlowNodeInputName = string;
export type FlowNodeIODataType = "String" | "Number" | "Boolean" | "Object" | "Array" | (string & {});
export declare const FlowNodeIODataType: any;
export type FlowNodeInputExpression = string | redacted.Redacted<string>;
export type FlowNodeInputCategory = "LoopCondition" | "ReturnValueToLoopStart" | "ExitLoop" | (string & {});
export declare const FlowNodeInputCategory: any;
export interface FlowNodeInput {
    name: string;
    type: FlowNodeIODataType;
    expression: string | redacted.Redacted<string>;
    category?: FlowNodeInputCategory;
}
export declare const FlowNodeInput: S.Schema<FlowNodeInput>;
export type FlowNodeInputs = FlowNodeInput[];
export declare const FlowNodeInputs: any;
export type FlowNodeOutputName = string;
export interface FlowNodeOutput {
    name: string;
    type: FlowNodeIODataType;
}
export declare const FlowNodeOutput: S.Schema<FlowNodeOutput>;
export type FlowNodeOutputs = FlowNodeOutput[];
export declare const FlowNodeOutputs: any;
export interface FlowNode {
    name: string;
    type: FlowNodeType;
    configuration?: FlowNodeConfiguration;
    inputs?: FlowNodeInput[];
    outputs?: FlowNodeOutput[];
}
export declare const FlowNode: S.Schema<FlowNode>;
export type FlowNodes = FlowNode[];
export declare const FlowNodes: S.Schema<FlowNodes>;
export type FlowConnectionType = "Data" | "Conditional" | (string & {});
export declare const FlowConnectionType: any;
export type FlowConnectionName = string;
export interface FlowDataConnectionConfiguration {
    sourceOutput: string;
    targetInput: string;
}
export declare const FlowDataConnectionConfiguration: S.Schema<FlowDataConnectionConfiguration>;
export interface FlowConditionalConnectionConfiguration {
    condition: string;
}
export declare const FlowConditionalConnectionConfiguration: S.Schema<FlowConditionalConnectionConfiguration>;
export type FlowConnectionConfiguration = {
    data: FlowDataConnectionConfiguration;
    conditional?: never;
} | {
    data?: never;
    conditional: FlowConditionalConnectionConfiguration;
};
export declare const FlowConnectionConfiguration: any;
export interface FlowConnection {
    type: FlowConnectionType;
    name: string;
    source: string;
    target: string;
    configuration?: FlowConnectionConfiguration;
}
export declare const FlowConnection: S.Schema<FlowConnection>;
export type FlowConnections = FlowConnection[];
export declare const FlowConnections: any;
export interface FlowDefinition {
    nodes?: FlowNode[];
    connections?: FlowConnection[];
}
export declare const FlowDefinition: S.Schema<FlowDefinition>;
export interface CreateFlowRequest {
    name: string;
    description?: string;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string;
    definition?: FlowDefinition;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFlowRequest: S.Schema<CreateFlowRequest>;
export type FlowId = string;
export type FlowArn = string;
export type FlowStatus = "Failed" | "Prepared" | "Preparing" | "NotPrepared" | (string & {});
export declare const FlowStatus: any;
export interface CreateFlowResponse {
    name: string;
    description?: string;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
    definition?: FlowDefinition;
}
export declare const CreateFlowResponse: S.Schema<CreateFlowResponse>;
export interface FlowAliasRoutingConfigurationListItem {
    flowVersion?: string;
}
export declare const FlowAliasRoutingConfigurationListItem: S.Schema<FlowAliasRoutingConfigurationListItem>;
export type FlowAliasRoutingConfiguration = FlowAliasRoutingConfigurationListItem[];
export declare const FlowAliasRoutingConfiguration: any;
export type ConcurrencyType = "Automatic" | "Manual" | (string & {});
export declare const ConcurrencyType: any;
export interface FlowAliasConcurrencyConfiguration {
    type: ConcurrencyType;
    maxConcurrency?: number;
}
export declare const FlowAliasConcurrencyConfiguration: S.Schema<FlowAliasConcurrencyConfiguration>;
export type FlowIdentifier = string;
export interface CreateFlowAliasRequest {
    name: string;
    description?: string;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration;
    flowIdentifier: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFlowAliasRequest: S.Schema<CreateFlowAliasRequest>;
export type FlowAliasId = string;
export type FlowAliasArn = string;
export interface CreateFlowAliasResponse {
    name: string;
    description?: string;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const CreateFlowAliasResponse: S.Schema<CreateFlowAliasResponse>;
export interface CreateFlowVersionRequest {
    flowIdentifier: string;
    description?: string;
    clientToken?: string;
}
export declare const CreateFlowVersionRequest: S.Schema<CreateFlowVersionRequest>;
export type NumericalVersion = string;
export interface CreateFlowVersionResponse {
    name: string;
    description?: string;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    version: string;
    definition?: FlowDefinition;
}
export declare const CreateFlowVersionResponse: S.Schema<CreateFlowVersionResponse>;
export type KnowledgeBaseRoleArn = string;
export type KnowledgeBaseType = "VECTOR" | "KENDRA" | "SQL" | "MANAGED" | (string & {});
export declare const KnowledgeBaseType: any;
export type BedrockEmbeddingModelArn = string;
export type Dimensions = number;
export type EmbeddingDataType = "FLOAT32" | "BINARY" | (string & {});
export declare const EmbeddingDataType: any;
export interface AudioSegmentationConfiguration {
    fixedLengthDuration: number;
}
export declare const AudioSegmentationConfiguration: S.Schema<AudioSegmentationConfiguration>;
export interface AudioConfiguration {
    segmentationConfiguration: AudioSegmentationConfiguration;
}
export declare const AudioConfiguration: S.Schema<AudioConfiguration>;
export type AudioConfigurations = AudioConfiguration[];
export declare const AudioConfigurations: any;
export interface VideoSegmentationConfiguration {
    fixedLengthDuration: number;
}
export declare const VideoSegmentationConfiguration: S.Schema<VideoSegmentationConfiguration>;
export interface VideoConfiguration {
    segmentationConfiguration: VideoSegmentationConfiguration;
}
export declare const VideoConfiguration: S.Schema<VideoConfiguration>;
export type VideoConfigurations = VideoConfiguration[];
export declare const VideoConfigurations: any;
export interface BedrockEmbeddingModelConfiguration {
    dimensions?: number;
    embeddingDataType?: EmbeddingDataType;
    audio?: AudioConfiguration[];
    video?: VideoConfiguration[];
}
export declare const BedrockEmbeddingModelConfiguration: S.Schema<BedrockEmbeddingModelConfiguration>;
export interface EmbeddingModelConfiguration {
    bedrockEmbeddingModelConfiguration?: BedrockEmbeddingModelConfiguration;
}
export declare const EmbeddingModelConfiguration: S.Schema<EmbeddingModelConfiguration>;
export type SupplementalDataStorageLocationType = "S3" | (string & {});
export declare const SupplementalDataStorageLocationType: any;
export interface SupplementalDataStorageLocation {
    type: SupplementalDataStorageLocationType;
    s3Location?: S3Location;
}
export declare const SupplementalDataStorageLocation: S.Schema<SupplementalDataStorageLocation>;
export type SupplementalDataStorageLocations = SupplementalDataStorageLocation[];
export declare const SupplementalDataStorageLocations: any;
export interface SupplementalDataStorageConfiguration {
    storageLocations: SupplementalDataStorageLocation[];
}
export declare const SupplementalDataStorageConfiguration: S.Schema<SupplementalDataStorageConfiguration>;
export interface VectorKnowledgeBaseConfiguration {
    embeddingModelArn: string;
    embeddingModelConfiguration?: EmbeddingModelConfiguration;
    supplementalDataStorageConfiguration?: SupplementalDataStorageConfiguration;
}
export declare const VectorKnowledgeBaseConfiguration: S.Schema<VectorKnowledgeBaseConfiguration>;
export type EmbeddingModelType = "CUSTOM" | "MANAGED" | (string & {});
export declare const EmbeddingModelType: any;
export interface ManagedKnowledgeBaseConfiguration {
    embeddingModelType?: EmbeddingModelType;
    embeddingModelArn?: string;
    embeddingModelConfiguration?: EmbeddingModelConfiguration;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
}
export declare const ManagedKnowledgeBaseConfiguration: S.Schema<ManagedKnowledgeBaseConfiguration>;
export type KendraIndexArn = string;
export interface KendraKnowledgeBaseConfiguration {
    kendraIndexArn: string;
}
export declare const KendraKnowledgeBaseConfiguration: S.Schema<KendraKnowledgeBaseConfiguration>;
export type QueryEngineType = "REDSHIFT" | (string & {});
export declare const QueryEngineType: any;
export type RedshiftQueryEngineStorageType = "REDSHIFT" | "AWS_DATA_CATALOG" | (string & {});
export declare const RedshiftQueryEngineStorageType: any;
export type AwsDataCatalogTableName = string;
export type AwsDataCatalogTableNames = string[];
export declare const AwsDataCatalogTableNames: any;
export interface RedshiftQueryEngineAwsDataCatalogStorageConfiguration {
    tableNames: string[];
}
export declare const RedshiftQueryEngineAwsDataCatalogStorageConfiguration: S.Schema<RedshiftQueryEngineAwsDataCatalogStorageConfiguration>;
export type RedshiftDatabase = string;
export interface RedshiftQueryEngineRedshiftStorageConfiguration {
    databaseName: string;
}
export declare const RedshiftQueryEngineRedshiftStorageConfiguration: S.Schema<RedshiftQueryEngineRedshiftStorageConfiguration>;
export interface RedshiftQueryEngineStorageConfiguration {
    type: RedshiftQueryEngineStorageType;
    awsDataCatalogConfiguration?: RedshiftQueryEngineAwsDataCatalogStorageConfiguration;
    redshiftConfiguration?: RedshiftQueryEngineRedshiftStorageConfiguration;
}
export declare const RedshiftQueryEngineStorageConfiguration: S.Schema<RedshiftQueryEngineStorageConfiguration>;
export type RedshiftQueryEngineStorageConfigurations = RedshiftQueryEngineStorageConfiguration[];
export declare const RedshiftQueryEngineStorageConfigurations: any;
export type RedshiftQueryEngineType = "SERVERLESS" | "PROVISIONED" | (string & {});
export declare const RedshiftQueryEngineType: any;
export type WorkgroupArn = string;
export type RedshiftServerlessAuthType = "IAM" | "USERNAME_PASSWORD" | (string & {});
export declare const RedshiftServerlessAuthType: any;
export interface RedshiftServerlessAuthConfiguration {
    type: RedshiftServerlessAuthType;
    usernamePasswordSecretArn?: string;
}
export declare const RedshiftServerlessAuthConfiguration: S.Schema<RedshiftServerlessAuthConfiguration>;
export interface RedshiftServerlessConfiguration {
    workgroupArn: string;
    authConfiguration: RedshiftServerlessAuthConfiguration;
}
export declare const RedshiftServerlessConfiguration: S.Schema<RedshiftServerlessConfiguration>;
export type RedshiftClusterIdentifier = string;
export type RedshiftProvisionedAuthType = "IAM" | "USERNAME_PASSWORD" | "USERNAME" | (string & {});
export declare const RedshiftProvisionedAuthType: any;
export interface RedshiftProvisionedAuthConfiguration {
    type: RedshiftProvisionedAuthType;
    databaseUser?: string;
    usernamePasswordSecretArn?: string;
}
export declare const RedshiftProvisionedAuthConfiguration: S.Schema<RedshiftProvisionedAuthConfiguration>;
export interface RedshiftProvisionedConfiguration {
    clusterIdentifier: string;
    authConfiguration: RedshiftProvisionedAuthConfiguration;
}
export declare const RedshiftProvisionedConfiguration: S.Schema<RedshiftProvisionedConfiguration>;
export interface RedshiftQueryEngineConfiguration {
    type: RedshiftQueryEngineType;
    serverlessConfiguration?: RedshiftServerlessConfiguration;
    provisionedConfiguration?: RedshiftProvisionedConfiguration;
}
export declare const RedshiftQueryEngineConfiguration: S.Schema<RedshiftQueryEngineConfiguration>;
export type QueryExecutionTimeoutSeconds = number;
export type QueryGenerationTableName = string;
export type DescriptionString = string;
export type IncludeExclude = "INCLUDE" | "EXCLUDE" | (string & {});
export declare const IncludeExclude: any;
export type QueryGenerationColumnName = string;
export interface QueryGenerationColumn {
    name?: string;
    description?: string;
    inclusion?: IncludeExclude;
}
export declare const QueryGenerationColumn: S.Schema<QueryGenerationColumn>;
export type QueryGenerationColumns = QueryGenerationColumn[];
export declare const QueryGenerationColumns: any;
export interface QueryGenerationTable {
    name: string;
    description?: string;
    inclusion?: IncludeExclude;
    columns?: QueryGenerationColumn[];
}
export declare const QueryGenerationTable: S.Schema<QueryGenerationTable>;
export type QueryGenerationTables = QueryGenerationTable[];
export declare const QueryGenerationTables: any;
export type NaturalLanguageString = string;
export type SqlString = string;
export interface CuratedQuery {
    naturalLanguage: string;
    sql: string;
}
export declare const CuratedQuery: S.Schema<CuratedQuery>;
export type CuratedQueries = CuratedQuery[];
export declare const CuratedQueries: any;
export interface QueryGenerationContext {
    tables?: QueryGenerationTable[];
    curatedQueries?: CuratedQuery[];
}
export declare const QueryGenerationContext: S.Schema<QueryGenerationContext>;
export interface QueryGenerationConfiguration {
    executionTimeoutSeconds?: number;
    generationContext?: QueryGenerationContext;
}
export declare const QueryGenerationConfiguration: S.Schema<QueryGenerationConfiguration>;
export interface RedshiftConfiguration {
    storageConfigurations: RedshiftQueryEngineStorageConfiguration[];
    queryEngineConfiguration: RedshiftQueryEngineConfiguration;
    queryGenerationConfiguration?: QueryGenerationConfiguration;
}
export declare const RedshiftConfiguration: S.Schema<RedshiftConfiguration>;
export interface SqlKnowledgeBaseConfiguration {
    type: QueryEngineType;
    redshiftConfiguration?: RedshiftConfiguration;
}
export declare const SqlKnowledgeBaseConfiguration: S.Schema<SqlKnowledgeBaseConfiguration>;
export interface KnowledgeBaseConfiguration {
    type: KnowledgeBaseType;
    vectorKnowledgeBaseConfiguration?: VectorKnowledgeBaseConfiguration;
    managedKnowledgeBaseConfiguration?: ManagedKnowledgeBaseConfiguration;
    kendraKnowledgeBaseConfiguration?: KendraKnowledgeBaseConfiguration;
    sqlKnowledgeBaseConfiguration?: SqlKnowledgeBaseConfiguration;
}
export declare const KnowledgeBaseConfiguration: S.Schema<KnowledgeBaseConfiguration>;
export type KnowledgeBaseStorageType = "OPENSEARCH_SERVERLESS" | "PINECONE" | "REDIS_ENTERPRISE_CLOUD" | "RDS" | "MONGO_DB_ATLAS" | "NEPTUNE_ANALYTICS" | "OPENSEARCH_MANAGED_CLUSTER" | "S3_VECTORS" | (string & {});
export declare const KnowledgeBaseStorageType: any;
export type OpenSearchServerlessCollectionArn = string;
export type OpenSearchServerlessIndexName = string;
export type FieldName = string;
export interface OpenSearchServerlessFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export declare const OpenSearchServerlessFieldMapping: S.Schema<OpenSearchServerlessFieldMapping>;
export interface OpenSearchServerlessConfiguration {
    collectionArn: string;
    vectorIndexName: string;
    fieldMapping: OpenSearchServerlessFieldMapping;
}
export declare const OpenSearchServerlessConfiguration: S.Schema<OpenSearchServerlessConfiguration>;
export type OpenSearchManagedClusterDomainEndpoint = string;
export type OpenSearchManagedClusterDomainArn = string;
export type OpenSearchManagedClusterIndexName = string | redacted.Redacted<string>;
export interface OpenSearchManagedClusterFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export declare const OpenSearchManagedClusterFieldMapping: S.Schema<OpenSearchManagedClusterFieldMapping>;
export interface OpenSearchManagedClusterConfiguration {
    domainEndpoint: string;
    domainArn: string;
    vectorIndexName: string | redacted.Redacted<string>;
    fieldMapping: OpenSearchManagedClusterFieldMapping;
}
export declare const OpenSearchManagedClusterConfiguration: S.Schema<OpenSearchManagedClusterConfiguration>;
export type PineconeConnectionString = string;
export type PineconeNamespace = string;
export interface PineconeFieldMapping {
    textField: string;
    metadataField: string;
}
export declare const PineconeFieldMapping: S.Schema<PineconeFieldMapping>;
export interface PineconeConfiguration {
    connectionString: string;
    credentialsSecretArn: string;
    namespace?: string;
    fieldMapping: PineconeFieldMapping;
}
export declare const PineconeConfiguration: S.Schema<PineconeConfiguration>;
export type RedisEnterpriseCloudEndpoint = string;
export type RedisEnterpriseCloudIndexName = string;
export interface RedisEnterpriseCloudFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export declare const RedisEnterpriseCloudFieldMapping: S.Schema<RedisEnterpriseCloudFieldMapping>;
export interface RedisEnterpriseCloudConfiguration {
    endpoint: string;
    vectorIndexName: string;
    credentialsSecretArn: string;
    fieldMapping: RedisEnterpriseCloudFieldMapping;
}
export declare const RedisEnterpriseCloudConfiguration: S.Schema<RedisEnterpriseCloudConfiguration>;
export type RdsArn = string;
export type RdsDatabaseName = string;
export type RdsTableName = string;
export type ColumnName = string;
export interface RdsFieldMapping {
    primaryKeyField: string;
    vectorField: string;
    textField: string;
    metadataField: string;
    customMetadataField?: string;
}
export declare const RdsFieldMapping: S.Schema<RdsFieldMapping>;
export interface RdsConfiguration {
    resourceArn: string;
    credentialsSecretArn: string;
    databaseName: string;
    tableName: string;
    fieldMapping: RdsFieldMapping;
}
export declare const RdsConfiguration: S.Schema<RdsConfiguration>;
export type MongoDbAtlasEndpoint = string;
export type MongoDbAtlasDatabaseName = string;
export type MongoDbAtlasCollectionName = string;
export type MongoDbAtlasIndexName = string;
export interface MongoDbAtlasFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export declare const MongoDbAtlasFieldMapping: S.Schema<MongoDbAtlasFieldMapping>;
export type MongoDbAtlasEndpointServiceName = string;
export interface MongoDbAtlasConfiguration {
    endpoint: string;
    databaseName: string;
    collectionName: string;
    vectorIndexName: string;
    credentialsSecretArn: string;
    fieldMapping: MongoDbAtlasFieldMapping;
    endpointServiceName?: string;
    textIndexName?: string;
}
export declare const MongoDbAtlasConfiguration: S.Schema<MongoDbAtlasConfiguration>;
export type GraphArn = string | redacted.Redacted<string>;
export interface NeptuneAnalyticsFieldMapping {
    textField: string;
    metadataField: string;
}
export declare const NeptuneAnalyticsFieldMapping: S.Schema<NeptuneAnalyticsFieldMapping>;
export interface NeptuneAnalyticsConfiguration {
    graphArn: string | redacted.Redacted<string>;
    fieldMapping: NeptuneAnalyticsFieldMapping;
}
export declare const NeptuneAnalyticsConfiguration: S.Schema<NeptuneAnalyticsConfiguration>;
export type VectorBucketArn = string | redacted.Redacted<string>;
export type IndexArn = string | redacted.Redacted<string>;
export type IndexName = string | redacted.Redacted<string>;
export interface S3VectorsConfiguration {
    vectorBucketArn?: string | redacted.Redacted<string>;
    indexArn?: string | redacted.Redacted<string>;
    indexName?: string | redacted.Redacted<string>;
}
export declare const S3VectorsConfiguration: S.Schema<S3VectorsConfiguration>;
export interface StorageConfiguration {
    type: KnowledgeBaseStorageType;
    opensearchServerlessConfiguration?: OpenSearchServerlessConfiguration;
    opensearchManagedClusterConfiguration?: OpenSearchManagedClusterConfiguration;
    pineconeConfiguration?: PineconeConfiguration;
    redisEnterpriseCloudConfiguration?: RedisEnterpriseCloudConfiguration;
    rdsConfiguration?: RdsConfiguration;
    mongoDbAtlasConfiguration?: MongoDbAtlasConfiguration;
    neptuneAnalyticsConfiguration?: NeptuneAnalyticsConfiguration;
    s3VectorsConfiguration?: S3VectorsConfiguration;
}
export declare const StorageConfiguration: S.Schema<StorageConfiguration>;
export interface CreateKnowledgeBaseRequest {
    clientToken?: string;
    name: string;
    description?: string;
    roleArn: string;
    knowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    storageConfiguration?: StorageConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateKnowledgeBaseRequest: S.Schema<CreateKnowledgeBaseRequest>;
export type KnowledgeBaseArn = string;
export type KnowledgeBaseStatus = "CREATING" | "ACTIVE" | "DELETING" | "UPDATING" | "FAILED" | "DELETE_UNSUCCESSFUL" | "UPDATE_UNSUCCESSFUL" | (string & {});
export declare const KnowledgeBaseStatus: any;
export interface KnowledgeBase {
    knowledgeBaseId: string;
    name: string;
    knowledgeBaseArn: string;
    description?: string;
    roleArn: string;
    knowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    storageConfiguration?: StorageConfiguration;
    status: KnowledgeBaseStatus;
    createdAt: Date;
    updatedAt: Date;
    failureReasons?: string[];
}
export declare const KnowledgeBase: S.Schema<KnowledgeBase>;
export interface CreateKnowledgeBaseResponse {
    knowledgeBase: KnowledgeBase;
}
export declare const CreateKnowledgeBaseResponse: S.Schema<CreateKnowledgeBaseResponse>;
export type PromptName = string;
export type PromptDescription = string;
export type PromptVariantName = string;
export type PromptModelIdentifier = string;
export type PromptMetadataKey = string | redacted.Redacted<string>;
export type PromptMetadataValue = string | redacted.Redacted<string>;
export interface PromptMetadataEntry {
    key: string | redacted.Redacted<string>;
    value: string | redacted.Redacted<string>;
}
export declare const PromptMetadataEntry: S.Schema<PromptMetadataEntry>;
export type PromptMetadataList = PromptMetadataEntry[];
export declare const PromptMetadataList: any;
export interface PromptAgentResource {
    agentIdentifier: string;
}
export declare const PromptAgentResource: S.Schema<PromptAgentResource>;
export type PromptGenAiResource = {
    agent: PromptAgentResource;
};
export declare const PromptGenAiResource: any;
export interface PromptVariant {
    name: string;
    templateType: PromptTemplateType;
    templateConfiguration: PromptTemplateConfiguration;
    modelId?: string;
    inferenceConfiguration?: PromptInferenceConfiguration;
    metadata?: PromptMetadataEntry[];
    additionalModelRequestFields?: any;
    genAiResource?: PromptGenAiResource;
}
export declare const PromptVariant: S.Schema<PromptVariant>;
export type PromptVariantList = PromptVariant[];
export declare const PromptVariantList: any;
export interface CreatePromptRequest {
    name: string;
    description?: string;
    customerEncryptionKeyArn?: string;
    defaultVariant?: string;
    variants?: PromptVariant[];
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePromptRequest: S.Schema<CreatePromptRequest>;
export type PromptId = string;
export type PromptArn = string;
export interface CreatePromptResponse {
    name: string;
    description?: string;
    customerEncryptionKeyArn?: string;
    defaultVariant?: string;
    variants?: PromptVariant[];
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const CreatePromptResponse: S.Schema<CreatePromptResponse>;
export type PromptIdentifier = string;
export interface CreatePromptVersionRequest {
    promptIdentifier: string;
    description?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePromptVersionRequest: S.Schema<CreatePromptVersionRequest>;
export interface CreatePromptVersionResponse {
    name: string;
    description?: string;
    customerEncryptionKeyArn?: string;
    defaultVariant?: string;
    variants?: PromptVariant[];
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const CreatePromptVersionResponse: S.Schema<CreatePromptVersionResponse>;
export interface DeleteAgentRequest {
    agentId: string;
    skipResourceInUseCheck?: boolean;
}
export declare const DeleteAgentRequest: S.Schema<DeleteAgentRequest>;
export interface DeleteAgentResponse {
    agentId: string;
    agentStatus: AgentStatus;
}
export declare const DeleteAgentResponse: S.Schema<DeleteAgentResponse>;
export interface DeleteAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
    skipResourceInUseCheck?: boolean;
}
export declare const DeleteAgentActionGroupRequest: S.Schema<DeleteAgentActionGroupRequest>;
export interface DeleteAgentActionGroupResponse {
}
export declare const DeleteAgentActionGroupResponse: S.Schema<DeleteAgentActionGroupResponse>;
export interface DeleteAgentAliasRequest {
    agentId: string;
    agentAliasId: string;
}
export declare const DeleteAgentAliasRequest: S.Schema<DeleteAgentAliasRequest>;
export interface DeleteAgentAliasResponse {
    agentId: string;
    agentAliasId: string;
    agentAliasStatus: AgentAliasStatus;
}
export declare const DeleteAgentAliasResponse: S.Schema<DeleteAgentAliasResponse>;
export interface DeleteAgentVersionRequest {
    agentId: string;
    agentVersion: string;
    skipResourceInUseCheck?: boolean;
}
export declare const DeleteAgentVersionRequest: S.Schema<DeleteAgentVersionRequest>;
export interface DeleteAgentVersionResponse {
    agentId: string;
    agentVersion: string;
    agentStatus: AgentStatus;
}
export declare const DeleteAgentVersionResponse: S.Schema<DeleteAgentVersionResponse>;
export interface DeleteDataSourceRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
}
export declare const DeleteDataSourceRequest: S.Schema<DeleteDataSourceRequest>;
export interface DeleteDataSourceResponse {
    knowledgeBaseId: string;
    dataSourceId: string;
    status: DataSourceStatus;
}
export declare const DeleteDataSourceResponse: S.Schema<DeleteDataSourceResponse>;
export interface DeleteFlowRequest {
    flowIdentifier: string;
    skipResourceInUseCheck?: boolean;
}
export declare const DeleteFlowRequest: S.Schema<DeleteFlowRequest>;
export interface DeleteFlowResponse {
    id: string;
}
export declare const DeleteFlowResponse: S.Schema<DeleteFlowResponse>;
export type FlowAliasIdentifier = string;
export interface DeleteFlowAliasRequest {
    flowIdentifier: string;
    aliasIdentifier: string;
}
export declare const DeleteFlowAliasRequest: S.Schema<DeleteFlowAliasRequest>;
export interface DeleteFlowAliasResponse {
    flowId: string;
    id: string;
}
export declare const DeleteFlowAliasResponse: S.Schema<DeleteFlowAliasResponse>;
export interface DeleteFlowVersionRequest {
    flowIdentifier: string;
    flowVersion: string;
    skipResourceInUseCheck?: boolean;
}
export declare const DeleteFlowVersionRequest: S.Schema<DeleteFlowVersionRequest>;
export interface DeleteFlowVersionResponse {
    id: string;
    version: string;
}
export declare const DeleteFlowVersionResponse: S.Schema<DeleteFlowVersionResponse>;
export interface DeleteKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export declare const DeleteKnowledgeBaseRequest: S.Schema<DeleteKnowledgeBaseRequest>;
export interface DeleteKnowledgeBaseResponse {
    knowledgeBaseId: string;
    status: KnowledgeBaseStatus;
}
export declare const DeleteKnowledgeBaseResponse: S.Schema<DeleteKnowledgeBaseResponse>;
export type ContentDataSourceType = "CUSTOM" | "S3" | (string & {});
export declare const ContentDataSourceType: any;
export interface CustomDocumentIdentifier {
    id: string;
}
export declare const CustomDocumentIdentifier: S.Schema<CustomDocumentIdentifier>;
export interface DocumentIdentifier {
    dataSourceType: ContentDataSourceType;
    s3?: S3Location;
    custom?: CustomDocumentIdentifier;
}
export declare const DocumentIdentifier: S.Schema<DocumentIdentifier>;
export type DocumentIdentifiers = DocumentIdentifier[];
export declare const DocumentIdentifiers: any;
export interface DeleteKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    clientToken?: string;
    documentIdentifiers: DocumentIdentifier[];
}
export declare const DeleteKnowledgeBaseDocumentsRequest: S.Schema<DeleteKnowledgeBaseDocumentsRequest>;
export type DocumentStatus = "INDEXED" | "PARTIALLY_INDEXED" | "PENDING" | "FAILED" | "METADATA_PARTIALLY_INDEXED" | "METADATA_UPDATE_FAILED" | "IGNORED" | "NOT_FOUND" | "STARTING" | "IN_PROGRESS" | "DELETING" | "DELETE_IN_PROGRESS" | (string & {});
export declare const DocumentStatus: any;
export interface KnowledgeBaseDocumentDetail {
    knowledgeBaseId: string;
    dataSourceId: string;
    status: DocumentStatus;
    identifier: DocumentIdentifier;
    statusReason?: string;
    updatedAt?: Date;
}
export declare const KnowledgeBaseDocumentDetail: S.Schema<KnowledgeBaseDocumentDetail>;
export type KnowledgeBaseDocumentDetails = KnowledgeBaseDocumentDetail[];
export declare const KnowledgeBaseDocumentDetails: any;
export interface DeleteKnowledgeBaseDocumentsResponse {
    documentDetails?: KnowledgeBaseDocumentDetail[];
}
export declare const DeleteKnowledgeBaseDocumentsResponse: S.Schema<DeleteKnowledgeBaseDocumentsResponse>;
export interface DeletePromptRequest {
    promptIdentifier: string;
    promptVersion?: string;
}
export declare const DeletePromptRequest: S.Schema<DeletePromptRequest>;
export interface DeletePromptResponse {
    id: string;
    version?: string;
}
export declare const DeletePromptResponse: S.Schema<DeletePromptResponse>;
export type ResourceArn = string;
export type RevisionId = string;
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
    expectedRevisionId?: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
    resourceArn: string;
    revisionId?: string;
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DisassociateAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
}
export declare const DisassociateAgentCollaboratorRequest: S.Schema<DisassociateAgentCollaboratorRequest>;
export interface DisassociateAgentCollaboratorResponse {
}
export declare const DisassociateAgentCollaboratorResponse: S.Schema<DisassociateAgentCollaboratorResponse>;
export interface DisassociateAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
}
export declare const DisassociateAgentKnowledgeBaseRequest: S.Schema<DisassociateAgentKnowledgeBaseRequest>;
export interface DisassociateAgentKnowledgeBaseResponse {
}
export declare const DisassociateAgentKnowledgeBaseResponse: S.Schema<DisassociateAgentKnowledgeBaseResponse>;
export interface GetAgentRequest {
    agentId: string;
}
export declare const GetAgentRequest: S.Schema<GetAgentRequest>;
export interface GetAgentResponse {
    agent: Agent;
}
export declare const GetAgentResponse: S.Schema<GetAgentResponse>;
export interface GetAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
}
export declare const GetAgentActionGroupRequest: S.Schema<GetAgentActionGroupRequest>;
export interface GetAgentActionGroupResponse {
    agentActionGroup: AgentActionGroup;
}
export declare const GetAgentActionGroupResponse: S.Schema<GetAgentActionGroupResponse>;
export interface GetAgentAliasRequest {
    agentId: string;
    agentAliasId: string;
}
export declare const GetAgentAliasRequest: S.Schema<GetAgentAliasRequest>;
export interface GetAgentAliasResponse {
    agentAlias: AgentAlias;
}
export declare const GetAgentAliasResponse: S.Schema<GetAgentAliasResponse>;
export interface GetAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
}
export declare const GetAgentCollaboratorRequest: S.Schema<GetAgentCollaboratorRequest>;
export interface GetAgentCollaboratorResponse {
    agentCollaborator: AgentCollaborator;
}
export declare const GetAgentCollaboratorResponse: S.Schema<GetAgentCollaboratorResponse>;
export interface GetAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
}
export declare const GetAgentKnowledgeBaseRequest: S.Schema<GetAgentKnowledgeBaseRequest>;
export interface GetAgentKnowledgeBaseResponse {
    agentKnowledgeBase: AgentKnowledgeBase;
}
export declare const GetAgentKnowledgeBaseResponse: S.Schema<GetAgentKnowledgeBaseResponse>;
export interface GetAgentVersionRequest {
    agentId: string;
    agentVersion: string;
}
export declare const GetAgentVersionRequest: S.Schema<GetAgentVersionRequest>;
export interface AgentVersion {
    agentId: string;
    agentName: string;
    agentArn: string;
    version: string;
    instruction?: string | redacted.Redacted<string>;
    agentStatus: AgentStatus;
    foundationModel?: string;
    description?: string;
    idleSessionTTLInSeconds: number;
    agentResourceRoleArn: string;
    customerEncryptionKeyArn?: string;
    createdAt: Date;
    updatedAt: Date;
    failureReasons?: string[];
    recommendedActions?: string[];
    promptOverrideConfiguration?: PromptOverrideConfiguration;
    guardrailConfiguration?: GuardrailConfiguration;
    memoryConfiguration?: MemoryConfiguration;
    agentCollaboration?: AgentCollaboration;
}
export declare const AgentVersion: S.Schema<AgentVersion>;
export interface GetAgentVersionResponse {
    agentVersion: AgentVersion;
}
export declare const GetAgentVersionResponse: S.Schema<GetAgentVersionResponse>;
export interface GetDataSourceRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
}
export declare const GetDataSourceRequest: S.Schema<GetDataSourceRequest>;
export interface GetDataSourceResponse {
    dataSource: DataSource;
}
export declare const GetDataSourceResponse: S.Schema<GetDataSourceResponse>;
export type IncludedData = "ALL_DATA" | "METADATA_ONLY" | (string & {});
export declare const IncludedData: any;
export interface GetFlowRequest {
    flowIdentifier: string;
    includedData?: IncludedData;
}
export declare const GetFlowRequest: S.Schema<GetFlowRequest>;
export type NonBlankString = string;
export type FlowValidationSeverity = "Warning" | "Error" | (string & {});
export declare const FlowValidationSeverity: any;
export interface CyclicConnectionFlowValidationDetails {
    connection: string;
}
export declare const CyclicConnectionFlowValidationDetails: S.Schema<CyclicConnectionFlowValidationDetails>;
export interface DuplicateConnectionsFlowValidationDetails {
    source: string;
    target: string;
}
export declare const DuplicateConnectionsFlowValidationDetails: S.Schema<DuplicateConnectionsFlowValidationDetails>;
export interface DuplicateConditionExpressionFlowValidationDetails {
    node: string;
    expression: string | redacted.Redacted<string>;
}
export declare const DuplicateConditionExpressionFlowValidationDetails: S.Schema<DuplicateConditionExpressionFlowValidationDetails>;
export interface UnreachableNodeFlowValidationDetails {
    node: string;
}
export declare const UnreachableNodeFlowValidationDetails: S.Schema<UnreachableNodeFlowValidationDetails>;
export interface UnknownConnectionSourceFlowValidationDetails {
    connection: string;
}
export declare const UnknownConnectionSourceFlowValidationDetails: S.Schema<UnknownConnectionSourceFlowValidationDetails>;
export interface UnknownConnectionSourceOutputFlowValidationDetails {
    connection: string;
}
export declare const UnknownConnectionSourceOutputFlowValidationDetails: S.Schema<UnknownConnectionSourceOutputFlowValidationDetails>;
export interface UnknownConnectionTargetFlowValidationDetails {
    connection: string;
}
export declare const UnknownConnectionTargetFlowValidationDetails: S.Schema<UnknownConnectionTargetFlowValidationDetails>;
export interface UnknownConnectionTargetInputFlowValidationDetails {
    connection: string;
}
export declare const UnknownConnectionTargetInputFlowValidationDetails: S.Schema<UnknownConnectionTargetInputFlowValidationDetails>;
export interface UnknownConnectionConditionFlowValidationDetails {
    connection: string;
}
export declare const UnknownConnectionConditionFlowValidationDetails: S.Schema<UnknownConnectionConditionFlowValidationDetails>;
export type ErrorMessage = string;
export interface MalformedConditionExpressionFlowValidationDetails {
    node: string;
    condition: string;
    cause: string;
}
export declare const MalformedConditionExpressionFlowValidationDetails: S.Schema<MalformedConditionExpressionFlowValidationDetails>;
export interface MalformedNodeInputExpressionFlowValidationDetails {
    node: string;
    input: string;
    cause: string;
}
export declare const MalformedNodeInputExpressionFlowValidationDetails: S.Schema<MalformedNodeInputExpressionFlowValidationDetails>;
export interface MismatchedNodeInputTypeFlowValidationDetails {
    node: string;
    input: string;
    expectedType: FlowNodeIODataType;
}
export declare const MismatchedNodeInputTypeFlowValidationDetails: S.Schema<MismatchedNodeInputTypeFlowValidationDetails>;
export interface MismatchedNodeOutputTypeFlowValidationDetails {
    node: string;
    output: string;
    expectedType: FlowNodeIODataType;
}
export declare const MismatchedNodeOutputTypeFlowValidationDetails: S.Schema<MismatchedNodeOutputTypeFlowValidationDetails>;
export interface IncompatibleConnectionDataTypeFlowValidationDetails {
    connection: string;
}
export declare const IncompatibleConnectionDataTypeFlowValidationDetails: S.Schema<IncompatibleConnectionDataTypeFlowValidationDetails>;
export interface MissingConnectionConfigurationFlowValidationDetails {
    connection: string;
}
export declare const MissingConnectionConfigurationFlowValidationDetails: S.Schema<MissingConnectionConfigurationFlowValidationDetails>;
export interface MissingDefaultConditionFlowValidationDetails {
    node: string;
}
export declare const MissingDefaultConditionFlowValidationDetails: S.Schema<MissingDefaultConditionFlowValidationDetails>;
export interface MissingEndingNodesFlowValidationDetails {
}
export declare const MissingEndingNodesFlowValidationDetails: S.Schema<MissingEndingNodesFlowValidationDetails>;
export interface MissingNodeConfigurationFlowValidationDetails {
    node: string;
}
export declare const MissingNodeConfigurationFlowValidationDetails: S.Schema<MissingNodeConfigurationFlowValidationDetails>;
export interface MissingNodeInputFlowValidationDetails {
    node: string;
    input: string;
}
export declare const MissingNodeInputFlowValidationDetails: S.Schema<MissingNodeInputFlowValidationDetails>;
export interface MissingNodeOutputFlowValidationDetails {
    node: string;
    output: string;
}
export declare const MissingNodeOutputFlowValidationDetails: S.Schema<MissingNodeOutputFlowValidationDetails>;
export interface MissingStartingNodesFlowValidationDetails {
}
export declare const MissingStartingNodesFlowValidationDetails: S.Schema<MissingStartingNodesFlowValidationDetails>;
export interface MultipleNodeInputConnectionsFlowValidationDetails {
    node: string;
    input: string;
}
export declare const MultipleNodeInputConnectionsFlowValidationDetails: S.Schema<MultipleNodeInputConnectionsFlowValidationDetails>;
export interface UnfulfilledNodeInputFlowValidationDetails {
    node: string;
    input: string;
}
export declare const UnfulfilledNodeInputFlowValidationDetails: S.Schema<UnfulfilledNodeInputFlowValidationDetails>;
export interface UnsatisfiedConnectionConditionsFlowValidationDetails {
    connection: string;
}
export declare const UnsatisfiedConnectionConditionsFlowValidationDetails: S.Schema<UnsatisfiedConnectionConditionsFlowValidationDetails>;
export interface UnspecifiedFlowValidationDetails {
}
export declare const UnspecifiedFlowValidationDetails: S.Schema<UnspecifiedFlowValidationDetails>;
export interface UnknownNodeInputFlowValidationDetails {
    node: string;
    input: string;
}
export declare const UnknownNodeInputFlowValidationDetails: S.Schema<UnknownNodeInputFlowValidationDetails>;
export interface UnknownNodeOutputFlowValidationDetails {
    node: string;
    output: string;
}
export declare const UnknownNodeOutputFlowValidationDetails: S.Schema<UnknownNodeOutputFlowValidationDetails>;
export interface MissingLoopInputNodeFlowValidationDetails {
    loopNode: string;
}
export declare const MissingLoopInputNodeFlowValidationDetails: S.Schema<MissingLoopInputNodeFlowValidationDetails>;
export interface MissingLoopControllerNodeFlowValidationDetails {
    loopNode: string;
}
export declare const MissingLoopControllerNodeFlowValidationDetails: S.Schema<MissingLoopControllerNodeFlowValidationDetails>;
export interface MultipleLoopInputNodesFlowValidationDetails {
    loopNode: string;
}
export declare const MultipleLoopInputNodesFlowValidationDetails: S.Schema<MultipleLoopInputNodesFlowValidationDetails>;
export interface MultipleLoopControllerNodesFlowValidationDetails {
    loopNode: string;
}
export declare const MultipleLoopControllerNodesFlowValidationDetails: S.Schema<MultipleLoopControllerNodesFlowValidationDetails>;
export type IncompatibleLoopNodeType = "Input" | "Condition" | "Iterator" | "Collector" | (string & {});
export declare const IncompatibleLoopNodeType: any;
export interface LoopIncompatibleNodeTypeFlowValidationDetails {
    node: string;
    incompatibleNodeType: IncompatibleLoopNodeType;
    incompatibleNodeName: string;
}
export declare const LoopIncompatibleNodeTypeFlowValidationDetails: S.Schema<LoopIncompatibleNodeTypeFlowValidationDetails>;
export interface InvalidLoopBoundaryFlowValidationDetails {
    connection: string;
    source: string;
    target: string;
}
export declare const InvalidLoopBoundaryFlowValidationDetails: S.Schema<InvalidLoopBoundaryFlowValidationDetails>;
export type FlowValidationDetails = {
    cyclicConnection: CyclicConnectionFlowValidationDetails;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections: DuplicateConnectionsFlowValidationDetails;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression: DuplicateConditionExpressionFlowValidationDetails;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode: UnreachableNodeFlowValidationDetails;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource: UnknownConnectionSourceFlowValidationDetails;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput: UnknownConnectionSourceOutputFlowValidationDetails;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget: UnknownConnectionTargetFlowValidationDetails;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput: UnknownConnectionTargetInputFlowValidationDetails;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition: UnknownConnectionConditionFlowValidationDetails;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression: MalformedConditionExpressionFlowValidationDetails;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression: MalformedNodeInputExpressionFlowValidationDetails;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType: MismatchedNodeInputTypeFlowValidationDetails;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType: MismatchedNodeOutputTypeFlowValidationDetails;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType: IncompatibleConnectionDataTypeFlowValidationDetails;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration: MissingConnectionConfigurationFlowValidationDetails;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition: MissingDefaultConditionFlowValidationDetails;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes: MissingEndingNodesFlowValidationDetails;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration: MissingNodeConfigurationFlowValidationDetails;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput: MissingNodeInputFlowValidationDetails;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput: MissingNodeOutputFlowValidationDetails;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes: MissingStartingNodesFlowValidationDetails;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections: MultipleNodeInputConnectionsFlowValidationDetails;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput: UnfulfilledNodeInputFlowValidationDetails;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions: UnsatisfiedConnectionConditionsFlowValidationDetails;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified: UnspecifiedFlowValidationDetails;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput: UnknownNodeInputFlowValidationDetails;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput: UnknownNodeOutputFlowValidationDetails;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode: MissingLoopInputNodeFlowValidationDetails;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode: MissingLoopControllerNodeFlowValidationDetails;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes: MultipleLoopInputNodesFlowValidationDetails;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes: MultipleLoopControllerNodesFlowValidationDetails;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType: LoopIncompatibleNodeTypeFlowValidationDetails;
    invalidLoopBoundary?: never;
} | {
    cyclicConnection?: never;
    duplicateConnections?: never;
    duplicateConditionExpression?: never;
    unreachableNode?: never;
    unknownConnectionSource?: never;
    unknownConnectionSourceOutput?: never;
    unknownConnectionTarget?: never;
    unknownConnectionTargetInput?: never;
    unknownConnectionCondition?: never;
    malformedConditionExpression?: never;
    malformedNodeInputExpression?: never;
    mismatchedNodeInputType?: never;
    mismatchedNodeOutputType?: never;
    incompatibleConnectionDataType?: never;
    missingConnectionConfiguration?: never;
    missingDefaultCondition?: never;
    missingEndingNodes?: never;
    missingNodeConfiguration?: never;
    missingNodeInput?: never;
    missingNodeOutput?: never;
    missingStartingNodes?: never;
    multipleNodeInputConnections?: never;
    unfulfilledNodeInput?: never;
    unsatisfiedConnectionConditions?: never;
    unspecified?: never;
    unknownNodeInput?: never;
    unknownNodeOutput?: never;
    missingLoopInputNode?: never;
    missingLoopControllerNode?: never;
    multipleLoopInputNodes?: never;
    multipleLoopControllerNodes?: never;
    loopIncompatibleNodeType?: never;
    invalidLoopBoundary: InvalidLoopBoundaryFlowValidationDetails;
};
export declare const FlowValidationDetails: any;
export type FlowValidationType = "CyclicConnection" | "DuplicateConnections" | "DuplicateConditionExpression" | "UnreachableNode" | "UnknownConnectionSource" | "UnknownConnectionSourceOutput" | "UnknownConnectionTarget" | "UnknownConnectionTargetInput" | "UnknownConnectionCondition" | "MalformedConditionExpression" | "MalformedNodeInputExpression" | "MismatchedNodeInputType" | "MismatchedNodeOutputType" | "IncompatibleConnectionDataType" | "MissingConnectionConfiguration" | "MissingDefaultCondition" | "MissingEndingNodes" | "MissingNodeConfiguration" | "MissingNodeInput" | "MissingNodeOutput" | "MissingStartingNodes" | "MultipleNodeInputConnections" | "UnfulfilledNodeInput" | "UnsatisfiedConnectionConditions" | "Unspecified" | "UnknownNodeInput" | "UnknownNodeOutput" | "MissingLoopInputNode" | "MissingLoopControllerNode" | "MultipleLoopInputNodes" | "MultipleLoopControllerNodes" | "LoopIncompatibleNodeType" | "InvalidLoopBoundary" | (string & {});
export declare const FlowValidationType: any;
export interface FlowValidation {
    message: string;
    severity: FlowValidationSeverity;
    details?: FlowValidationDetails;
    type?: FlowValidationType;
}
export declare const FlowValidation: S.Schema<FlowValidation>;
export type FlowValidations = FlowValidation[];
export declare const FlowValidations: any;
export interface GetFlowResponse {
    name: string;
    description?: string;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
    definition?: FlowDefinition;
    validations?: FlowValidation[];
}
export declare const GetFlowResponse: S.Schema<GetFlowResponse>;
export interface GetFlowAliasRequest {
    flowIdentifier: string;
    aliasIdentifier: string;
}
export declare const GetFlowAliasRequest: S.Schema<GetFlowAliasRequest>;
export interface GetFlowAliasResponse {
    name: string;
    description?: string;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const GetFlowAliasResponse: S.Schema<GetFlowAliasResponse>;
export interface GetFlowVersionRequest {
    flowIdentifier: string;
    flowVersion: string;
    includedData?: IncludedData;
}
export declare const GetFlowVersionRequest: S.Schema<GetFlowVersionRequest>;
export interface GetFlowVersionResponse {
    name: string;
    description?: string;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    version: string;
    definition?: FlowDefinition;
}
export declare const GetFlowVersionResponse: S.Schema<GetFlowVersionResponse>;
export interface GetIngestionJobRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
}
export declare const GetIngestionJobRequest: S.Schema<GetIngestionJobRequest>;
export type IngestionJobStatus = "STARTING" | "IN_PROGRESS" | "COMPLETE" | "FAILED" | "STOPPING" | "STOPPED" | (string & {});
export declare const IngestionJobStatus: any;
export interface IngestionJobStatistics {
    numberOfDocumentsScanned?: number;
    numberOfMetadataDocumentsScanned?: number;
    numberOfNewDocumentsIndexed?: number;
    numberOfModifiedDocumentsIndexed?: number;
    numberOfMetadataDocumentsModified?: number;
    numberOfDocumentsDeleted?: number;
    numberOfDocumentsFailed?: number;
    numberOfDocumentsSkipped?: number;
}
export declare const IngestionJobStatistics: S.Schema<IngestionJobStatistics>;
export interface IngestionJob {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
    description?: string;
    status: IngestionJobStatus;
    statistics?: IngestionJobStatistics;
    failureReasons?: string[];
    startedAt: Date;
    updatedAt: Date;
}
export declare const IngestionJob: S.Schema<IngestionJob>;
export interface GetIngestionJobResponse {
    ingestionJob: IngestionJob;
}
export declare const GetIngestionJobResponse: S.Schema<GetIngestionJobResponse>;
export interface GetKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export declare const GetKnowledgeBaseRequest: S.Schema<GetKnowledgeBaseRequest>;
export interface GetKnowledgeBaseResponse {
    knowledgeBase: KnowledgeBase;
}
export declare const GetKnowledgeBaseResponse: S.Schema<GetKnowledgeBaseResponse>;
export interface GetKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentIdentifiers: DocumentIdentifier[];
}
export declare const GetKnowledgeBaseDocumentsRequest: S.Schema<GetKnowledgeBaseDocumentsRequest>;
export interface GetKnowledgeBaseDocumentsResponse {
    documentDetails?: KnowledgeBaseDocumentDetail[];
}
export declare const GetKnowledgeBaseDocumentsResponse: S.Schema<GetKnowledgeBaseDocumentsResponse>;
export interface GetPromptRequest {
    promptIdentifier: string;
    promptVersion?: string;
    includedData?: IncludedData;
}
export declare const GetPromptRequest: S.Schema<GetPromptRequest>;
export interface GetPromptResponse {
    name: string;
    description?: string;
    customerEncryptionKeyArn?: string;
    defaultVariant?: string;
    variants?: PromptVariant[];
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const GetPromptResponse: S.Schema<GetPromptResponse>;
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export type ResourcePolicy = string;
export interface GetResourcePolicyResponse {
    resourceArn: string;
    policy: string;
    revisionId: string;
}
export declare const GetResourcePolicyResponse: S.Schema<GetResourcePolicyResponse>;
export type MetadataSourceType = "IN_LINE_ATTRIBUTE" | "S3_LOCATION" | (string & {});
export declare const MetadataSourceType: any;
export type Key = string | redacted.Redacted<string>;
export type MetadataValueType = "BOOLEAN" | "NUMBER" | "STRING" | "STRING_LIST" | (string & {});
export declare const MetadataValueType: any;
export type NumberValue = number;
export type StringValue = string | redacted.Redacted<string>;
export type StringListValue = (string | redacted.Redacted<string>)[];
export declare const StringListValue: any;
export interface MetadataAttributeValue {
    type: MetadataValueType;
    numberValue?: number;
    booleanValue?: boolean;
    stringValue?: string | redacted.Redacted<string>;
    stringListValue?: (string | redacted.Redacted<string>)[];
}
export declare const MetadataAttributeValue: S.Schema<MetadataAttributeValue>;
export interface MetadataAttribute {
    key: string | redacted.Redacted<string>;
    value: MetadataAttributeValue;
}
export declare const MetadataAttribute: S.Schema<MetadataAttribute>;
export type MetadataAttributes = MetadataAttribute[];
export declare const MetadataAttributes: any;
export type S3ObjectUri = string;
export interface CustomS3Location {
    uri: string;
    bucketOwnerAccountId?: string;
}
export declare const CustomS3Location: S.Schema<CustomS3Location>;
export type AccessControlPrincipalType = "USER" | (string & {});
export declare const AccessControlPrincipalType: any;
export type AccessControlAccess = "ALLOW" | "DENY" | (string & {});
export declare const AccessControlAccess: any;
export interface DocumentAccessControlEntry {
    name: string;
    type: AccessControlPrincipalType;
    access: AccessControlAccess;
}
export declare const DocumentAccessControlEntry: S.Schema<DocumentAccessControlEntry>;
export type DocumentAccessControlList = DocumentAccessControlEntry[];
export declare const DocumentAccessControlList: any;
export interface DocumentMetadata {
    type: MetadataSourceType;
    inlineAttributes?: MetadataAttribute[];
    s3Location?: CustomS3Location;
    accessControlList?: DocumentAccessControlEntry[];
}
export declare const DocumentMetadata: S.Schema<DocumentMetadata>;
export type CustomSourceType = "IN_LINE" | "S3_LOCATION" | (string & {});
export declare const CustomSourceType: any;
export type InlineContentType = "BYTE" | "TEXT" | (string & {});
export declare const InlineContentType: any;
export type ByteContentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ByteContentDoc {
    mimeType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const ByteContentDoc: S.Schema<ByteContentDoc>;
export type Data = string | redacted.Redacted<string>;
export interface TextContentDoc {
    data: string | redacted.Redacted<string>;
}
export declare const TextContentDoc: S.Schema<TextContentDoc>;
export interface InlineContent {
    type: InlineContentType;
    byteContent?: ByteContentDoc;
    textContent?: TextContentDoc;
}
export declare const InlineContent: S.Schema<InlineContent>;
export interface CustomContent {
    customDocumentIdentifier: CustomDocumentIdentifier;
    sourceType: CustomSourceType;
    s3Location?: CustomS3Location;
    inlineContent?: InlineContent;
}
export declare const CustomContent: S.Schema<CustomContent>;
export interface S3Content {
    s3Location: S3Location;
}
export declare const S3Content: S.Schema<S3Content>;
export interface DocumentContent {
    dataSourceType: ContentDataSourceType;
    custom?: CustomContent;
    s3?: S3Content;
}
export declare const DocumentContent: S.Schema<DocumentContent>;
export interface KnowledgeBaseDocument {
    metadata?: DocumentMetadata;
    content: DocumentContent;
}
export declare const KnowledgeBaseDocument: S.Schema<KnowledgeBaseDocument>;
export type KnowledgeBaseDocuments = KnowledgeBaseDocument[];
export declare const KnowledgeBaseDocuments: any;
export interface IngestKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    clientToken?: string;
    documents: KnowledgeBaseDocument[];
}
export declare const IngestKnowledgeBaseDocumentsRequest: S.Schema<IngestKnowledgeBaseDocumentsRequest>;
export interface IngestKnowledgeBaseDocumentsResponse {
    documentDetails?: KnowledgeBaseDocumentDetail[];
}
export declare const IngestKnowledgeBaseDocumentsResponse: S.Schema<IngestKnowledgeBaseDocumentsResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListAgentActionGroupsRequest {
    agentId: string;
    agentVersion: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentActionGroupsRequest: S.Schema<ListAgentActionGroupsRequest>;
export interface ActionGroupSummary {
    actionGroupId: string;
    actionGroupName: string;
    actionGroupState: ActionGroupState;
    description?: string;
    updatedAt: Date;
}
export declare const ActionGroupSummary: S.Schema<ActionGroupSummary>;
export type ActionGroupSummaries = ActionGroupSummary[];
export declare const ActionGroupSummaries: any;
export interface ListAgentActionGroupsResponse {
    actionGroupSummaries: ActionGroupSummary[];
    nextToken?: string;
}
export declare const ListAgentActionGroupsResponse: S.Schema<ListAgentActionGroupsResponse>;
export interface ListAgentAliasesRequest {
    agentId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentAliasesRequest: S.Schema<ListAgentAliasesRequest>;
export interface AgentAliasSummary {
    agentAliasId: string;
    agentAliasName: string;
    description?: string;
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[];
    agentAliasStatus: AgentAliasStatus;
    createdAt: Date;
    updatedAt: Date;
    aliasInvocationState?: AliasInvocationState;
}
export declare const AgentAliasSummary: S.Schema<AgentAliasSummary>;
export type AgentAliasSummaries = AgentAliasSummary[];
export declare const AgentAliasSummaries: any;
export interface ListAgentAliasesResponse {
    agentAliasSummaries: AgentAliasSummary[];
    nextToken?: string;
}
export declare const ListAgentAliasesResponse: S.Schema<ListAgentAliasesResponse>;
export interface ListAgentCollaboratorsRequest {
    agentId: string;
    agentVersion: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentCollaboratorsRequest: S.Schema<ListAgentCollaboratorsRequest>;
export interface AgentCollaboratorSummary {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
    agentDescriptor: AgentDescriptor;
    collaborationInstruction: string | redacted.Redacted<string>;
    relayConversationHistory: RelayConversationHistory;
    collaboratorName: string;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export declare const AgentCollaboratorSummary: S.Schema<AgentCollaboratorSummary>;
export type AgentCollaboratorSummaries = AgentCollaboratorSummary[];
export declare const AgentCollaboratorSummaries: any;
export interface ListAgentCollaboratorsResponse {
    agentCollaboratorSummaries: AgentCollaboratorSummary[];
    nextToken?: string;
}
export declare const ListAgentCollaboratorsResponse: S.Schema<ListAgentCollaboratorsResponse>;
export interface ListAgentKnowledgeBasesRequest {
    agentId: string;
    agentVersion: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentKnowledgeBasesRequest: S.Schema<ListAgentKnowledgeBasesRequest>;
export interface AgentKnowledgeBaseSummary {
    knowledgeBaseId: string;
    description?: string;
    knowledgeBaseState: KnowledgeBaseState;
    updatedAt: Date;
}
export declare const AgentKnowledgeBaseSummary: S.Schema<AgentKnowledgeBaseSummary>;
export type AgentKnowledgeBaseSummaries = AgentKnowledgeBaseSummary[];
export declare const AgentKnowledgeBaseSummaries: any;
export interface ListAgentKnowledgeBasesResponse {
    agentKnowledgeBaseSummaries: AgentKnowledgeBaseSummary[];
    nextToken?: string;
}
export declare const ListAgentKnowledgeBasesResponse: S.Schema<ListAgentKnowledgeBasesResponse>;
export interface ListAgentsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentsRequest: S.Schema<ListAgentsRequest>;
export interface AgentSummary {
    agentId: string;
    agentName: string;
    agentStatus: AgentStatus;
    description?: string;
    updatedAt: Date;
    latestAgentVersion?: string;
    guardrailConfiguration?: GuardrailConfiguration;
}
export declare const AgentSummary: S.Schema<AgentSummary>;
export type AgentSummaries = AgentSummary[];
export declare const AgentSummaries: any;
export interface ListAgentsResponse {
    agentSummaries: AgentSummary[];
    nextToken?: string;
}
export declare const ListAgentsResponse: S.Schema<ListAgentsResponse>;
export interface ListAgentVersionsRequest {
    agentId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAgentVersionsRequest: S.Schema<ListAgentVersionsRequest>;
export interface AgentVersionSummary {
    agentName: string;
    agentStatus: AgentStatus;
    agentVersion: string;
    createdAt: Date;
    updatedAt: Date;
    description?: string;
    guardrailConfiguration?: GuardrailConfiguration;
}
export declare const AgentVersionSummary: S.Schema<AgentVersionSummary>;
export type AgentVersionSummaries = AgentVersionSummary[];
export declare const AgentVersionSummaries: any;
export interface ListAgentVersionsResponse {
    agentVersionSummaries: AgentVersionSummary[];
    nextToken?: string;
}
export declare const ListAgentVersionsResponse: S.Schema<ListAgentVersionsResponse>;
export interface ListDataSourcesRequest {
    knowledgeBaseId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDataSourcesRequest: S.Schema<ListDataSourcesRequest>;
export interface DataSourceSummary {
    knowledgeBaseId: string;
    dataSourceId: string;
    name: string;
    status: DataSourceStatus;
    description?: string;
    updatedAt: Date;
}
export declare const DataSourceSummary: S.Schema<DataSourceSummary>;
export type DataSourceSummaries = DataSourceSummary[];
export declare const DataSourceSummaries: any;
export interface ListDataSourcesResponse {
    dataSourceSummaries: DataSourceSummary[];
    nextToken?: string;
}
export declare const ListDataSourcesResponse: S.Schema<ListDataSourcesResponse>;
export interface ListFlowAliasesRequest {
    flowIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFlowAliasesRequest: S.Schema<ListFlowAliasesRequest>;
export interface FlowAliasSummary {
    name: string;
    description?: string;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const FlowAliasSummary: S.Schema<FlowAliasSummary>;
export type FlowAliasSummaries = FlowAliasSummary[];
export declare const FlowAliasSummaries: any;
export interface ListFlowAliasesResponse {
    flowAliasSummaries: FlowAliasSummary[];
    nextToken?: string;
}
export declare const ListFlowAliasesResponse: S.Schema<ListFlowAliasesResponse>;
export interface ListFlowsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFlowsRequest: S.Schema<ListFlowsRequest>;
export interface FlowSummary {
    name: string;
    description?: string;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
}
export declare const FlowSummary: S.Schema<FlowSummary>;
export type FlowSummaries = FlowSummary[];
export declare const FlowSummaries: any;
export interface ListFlowsResponse {
    flowSummaries: FlowSummary[];
    nextToken?: string;
}
export declare const ListFlowsResponse: S.Schema<ListFlowsResponse>;
export interface ListFlowVersionsRequest {
    flowIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListFlowVersionsRequest: S.Schema<ListFlowVersionsRequest>;
export interface FlowVersionSummary {
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    version: string;
}
export declare const FlowVersionSummary: S.Schema<FlowVersionSummary>;
export type FlowVersionSummaries = FlowVersionSummary[];
export declare const FlowVersionSummaries: any;
export interface ListFlowVersionsResponse {
    flowVersionSummaries: FlowVersionSummary[];
    nextToken?: string;
}
export declare const ListFlowVersionsResponse: S.Schema<ListFlowVersionsResponse>;
export type IngestionJobFilterAttribute = "STATUS" | (string & {});
export declare const IngestionJobFilterAttribute: any;
export type IngestionJobFilterOperator = "EQ" | (string & {});
export declare const IngestionJobFilterOperator: any;
export type IngestionJobFilterValue = string;
export type IngestionJobFilterValues = string[];
export declare const IngestionJobFilterValues: any;
export interface IngestionJobFilter {
    attribute: IngestionJobFilterAttribute;
    operator: IngestionJobFilterOperator;
    values: string[];
}
export declare const IngestionJobFilter: S.Schema<IngestionJobFilter>;
export type IngestionJobFilters = IngestionJobFilter[];
export declare const IngestionJobFilters: any;
export type IngestionJobSortByAttribute = "STATUS" | "STARTED_AT" | (string & {});
export declare const IngestionJobSortByAttribute: any;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SortOrder: any;
export interface IngestionJobSortBy {
    attribute: IngestionJobSortByAttribute;
    order: SortOrder;
}
export declare const IngestionJobSortBy: S.Schema<IngestionJobSortBy>;
export interface ListIngestionJobsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    filters?: IngestionJobFilter[];
    sortBy?: IngestionJobSortBy;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListIngestionJobsRequest: S.Schema<ListIngestionJobsRequest>;
export interface IngestionJobSummary {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
    description?: string;
    status: IngestionJobStatus;
    startedAt: Date;
    updatedAt: Date;
    statistics?: IngestionJobStatistics;
}
export declare const IngestionJobSummary: S.Schema<IngestionJobSummary>;
export type IngestionJobSummaries = IngestionJobSummary[];
export declare const IngestionJobSummaries: any;
export interface ListIngestionJobsResponse {
    ingestionJobSummaries: IngestionJobSummary[];
    nextToken?: string;
}
export declare const ListIngestionJobsResponse: S.Schema<ListIngestionJobsResponse>;
export interface ListKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListKnowledgeBaseDocumentsRequest: S.Schema<ListKnowledgeBaseDocumentsRequest>;
export interface ListKnowledgeBaseDocumentsResponse {
    documentDetails: KnowledgeBaseDocumentDetail[];
    nextToken?: string;
}
export declare const ListKnowledgeBaseDocumentsResponse: S.Schema<ListKnowledgeBaseDocumentsResponse>;
export interface ListKnowledgeBasesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListKnowledgeBasesRequest: S.Schema<ListKnowledgeBasesRequest>;
export interface KnowledgeBaseSummary {
    knowledgeBaseId: string;
    name: string;
    description?: string;
    status: KnowledgeBaseStatus;
    updatedAt: Date;
}
export declare const KnowledgeBaseSummary: S.Schema<KnowledgeBaseSummary>;
export type KnowledgeBaseSummaries = KnowledgeBaseSummary[];
export declare const KnowledgeBaseSummaries: any;
export interface ListKnowledgeBasesResponse {
    knowledgeBaseSummaries: KnowledgeBaseSummary[];
    nextToken?: string;
}
export declare const ListKnowledgeBasesResponse: S.Schema<ListKnowledgeBasesResponse>;
export interface ListPromptsRequest {
    promptIdentifier?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPromptsRequest: S.Schema<ListPromptsRequest>;
export interface PromptSummary {
    name: string;
    description?: string;
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PromptSummary: S.Schema<PromptSummary>;
export type PromptSummaries = PromptSummary[];
export declare const PromptSummaries: any;
export interface ListPromptsResponse {
    promptSummaries: PromptSummary[];
    nextToken?: string;
}
export declare const ListPromptsResponse: S.Schema<ListPromptsResponse>;
export type TaggableResourcesArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PrepareAgentRequest {
    agentId: string;
}
export declare const PrepareAgentRequest: S.Schema<PrepareAgentRequest>;
export interface PrepareAgentResponse {
    agentId: string;
    agentStatus: AgentStatus;
    agentVersion: string;
    preparedAt: Date;
}
export declare const PrepareAgentResponse: S.Schema<PrepareAgentResponse>;
export interface PrepareFlowRequest {
    flowIdentifier: string;
}
export declare const PrepareFlowRequest: S.Schema<PrepareFlowRequest>;
export interface PrepareFlowResponse {
    id: string;
    status: FlowStatus;
}
export declare const PrepareFlowResponse: S.Schema<PrepareFlowResponse>;
export interface PutResourcePolicyRequest {
    resourceArn: string;
    policy: string;
    expectedRevisionId?: string;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResponse {
    resourceArn: string;
    revisionId: string;
}
export declare const PutResourcePolicyResponse: S.Schema<PutResourcePolicyResponse>;
export interface StartIngestionJobRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    clientToken?: string;
    description?: string;
}
export declare const StartIngestionJobRequest: S.Schema<StartIngestionJobRequest>;
export interface StartIngestionJobResponse {
    ingestionJob: IngestionJob;
}
export declare const StartIngestionJobResponse: S.Schema<StartIngestionJobResponse>;
export interface StopIngestionJobRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
}
export declare const StopIngestionJobRequest: S.Schema<StopIngestionJobRequest>;
export interface StopIngestionJobResponse {
    ingestionJob: IngestionJob;
}
export declare const StopIngestionJobResponse: S.Schema<StopIngestionJobResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAgentRequest {
    agentId: string;
    agentName: string;
    instruction?: string | redacted.Redacted<string>;
    foundationModel?: string;
    description?: string;
    orchestrationType?: OrchestrationType;
    customOrchestration?: CustomOrchestration;
    idleSessionTTLInSeconds?: number;
    agentResourceRoleArn: string;
    customerEncryptionKeyArn?: string;
    promptOverrideConfiguration?: PromptOverrideConfiguration;
    guardrailConfiguration?: GuardrailConfiguration;
    memoryConfiguration?: MemoryConfiguration;
    agentCollaboration?: AgentCollaboration;
}
export declare const UpdateAgentRequest: S.Schema<UpdateAgentRequest>;
export interface UpdateAgentResponse {
    agent: Agent;
}
export declare const UpdateAgentResponse: S.Schema<UpdateAgentResponse>;
export interface UpdateAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
    actionGroupName: string;
    description?: string;
    parentActionGroupSignature?: ActionGroupSignature;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    };
    actionGroupExecutor?: ActionGroupExecutor;
    actionGroupState?: ActionGroupState;
    apiSchema?: APISchema;
    functionSchema?: FunctionSchema;
}
export declare const UpdateAgentActionGroupRequest: S.Schema<UpdateAgentActionGroupRequest>;
export interface UpdateAgentActionGroupResponse {
    agentActionGroup: AgentActionGroup;
}
export declare const UpdateAgentActionGroupResponse: S.Schema<UpdateAgentActionGroupResponse>;
export interface UpdateAgentAliasRequest {
    agentId: string;
    agentAliasId: string;
    agentAliasName: string;
    description?: string;
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[];
    aliasInvocationState?: AliasInvocationState;
}
export declare const UpdateAgentAliasRequest: S.Schema<UpdateAgentAliasRequest>;
export interface UpdateAgentAliasResponse {
    agentAlias: AgentAlias;
}
export declare const UpdateAgentAliasResponse: S.Schema<UpdateAgentAliasResponse>;
export interface UpdateAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
    agentDescriptor: AgentDescriptor;
    collaboratorName: string;
    collaborationInstruction: string | redacted.Redacted<string>;
    relayConversationHistory?: RelayConversationHistory;
}
export declare const UpdateAgentCollaboratorRequest: S.Schema<UpdateAgentCollaboratorRequest>;
export interface UpdateAgentCollaboratorResponse {
    agentCollaborator: AgentCollaborator;
}
export declare const UpdateAgentCollaboratorResponse: S.Schema<UpdateAgentCollaboratorResponse>;
export interface UpdateAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
    description?: string;
    knowledgeBaseState?: KnowledgeBaseState;
}
export declare const UpdateAgentKnowledgeBaseRequest: S.Schema<UpdateAgentKnowledgeBaseRequest>;
export interface UpdateAgentKnowledgeBaseResponse {
    agentKnowledgeBase: AgentKnowledgeBase;
}
export declare const UpdateAgentKnowledgeBaseResponse: S.Schema<UpdateAgentKnowledgeBaseResponse>;
export interface UpdateDataSourceRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    name: string;
    description?: string;
    dataSourceConfiguration: DataSourceConfiguration;
    dataDeletionPolicy?: DataDeletionPolicy;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration;
    vectorIngestionConfiguration?: VectorIngestionConfiguration;
}
export declare const UpdateDataSourceRequest: S.Schema<UpdateDataSourceRequest>;
export interface UpdateDataSourceResponse {
    dataSource: DataSource;
}
export declare const UpdateDataSourceResponse: S.Schema<UpdateDataSourceResponse>;
export interface UpdateFlowRequest {
    name: string;
    description?: string;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string;
    definition?: FlowDefinition;
    flowIdentifier: string;
}
export declare const UpdateFlowRequest: S.Schema<UpdateFlowRequest>;
export interface UpdateFlowResponse {
    name: string;
    description?: string;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
    definition?: FlowDefinition;
}
export declare const UpdateFlowResponse: S.Schema<UpdateFlowResponse>;
export interface UpdateFlowAliasRequest {
    name: string;
    description?: string;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration;
    flowIdentifier: string;
    aliasIdentifier: string;
}
export declare const UpdateFlowAliasRequest: S.Schema<UpdateFlowAliasRequest>;
export interface UpdateFlowAliasResponse {
    name: string;
    description?: string;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const UpdateFlowAliasResponse: S.Schema<UpdateFlowAliasResponse>;
export interface UpdateKnowledgeBaseRequest {
    knowledgeBaseId: string;
    name: string;
    description?: string;
    roleArn: string;
    knowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    storageConfiguration?: StorageConfiguration;
}
export declare const UpdateKnowledgeBaseRequest: S.Schema<UpdateKnowledgeBaseRequest>;
export interface UpdateKnowledgeBaseResponse {
    knowledgeBase: KnowledgeBase;
}
export declare const UpdateKnowledgeBaseResponse: S.Schema<UpdateKnowledgeBaseResponse>;
export interface UpdatePromptRequest {
    name: string;
    description?: string;
    customerEncryptionKeyArn?: string;
    defaultVariant?: string;
    variants?: PromptVariant[];
    promptIdentifier: string;
}
export declare const UpdatePromptRequest: S.Schema<UpdatePromptRequest>;
export interface UpdatePromptResponse {
    name: string;
    description?: string;
    customerEncryptionKeyArn?: string;
    defaultVariant?: string;
    variants?: PromptVariant[];
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const UpdatePromptResponse: S.Schema<UpdatePromptResponse>;
export interface ValidateFlowDefinitionRequest {
    definition: FlowDefinition;
}
export declare const ValidateFlowDefinitionRequest: S.Schema<ValidateFlowDefinitionRequest>;
export interface ValidateFlowDefinitionResponse {
    validations: FlowValidation[];
}
export declare const ValidateFlowDefinitionResponse: S.Schema<ValidateFlowDefinitionResponse>;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AssociateAgentCollaboratorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Makes an agent a collaborator for another agent.
 */
export declare const associateAgentCollaborator: API.OperationMethod<AssociateAgentCollaboratorRequest, AssociateAgentCollaboratorResponse, AssociateAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type AssociateAgentKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a knowledge base with an agent. If a knowledge base is associated and its `indexState` is set to `Enabled`, the agent queries the knowledge base for information to augment its response to the user.
 */
export declare const associateAgentKnowledgeBase: API.OperationMethod<AssociateAgentKnowledgeBaseRequest, AssociateAgentKnowledgeBaseResponse, AssociateAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type CreateAgentError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an agent that orchestrates interactions between foundation models, data sources, software applications, user conversations, and APIs to carry out tasks to help customers.
 *
 * - Specify the following fields for security purposes.
 *
 * - `agentResourceRoleArn` – The Amazon Resource Name (ARN) of the role with permissions to invoke API operations on an agent.
 *
 * - (Optional) `customerEncryptionKeyArn` – The Amazon Resource Name (ARN) of a KMS key to encrypt the creation of the agent.
 *
 * - (Optional) `idleSessionTTLinSeconds` – Specify the number of seconds for which the agent should maintain session information. After this time expires, the subsequent `InvokeAgent` request begins a new session.
 *
 * - To enable your agent to retain conversational context across multiple sessions, include a `memoryConfiguration` object. For more information, see Configure memory.
 *
 * - To override the default prompt behavior for agent orchestration and to use advanced prompts, include a `promptOverrideConfiguration` object. For more information, see Advanced prompts.
 *
 * - If your agent fails to be created, the response returns a list of `failureReasons` alongside a list of `recommendedActions` for you to troubleshoot.
 *
 * - The agent instructions will not be honored if your agent has only one knowledge base, uses default prompts, has no action group, and user input is disabled.
 */
export declare const createAgent: API.OperationMethod<CreateAgentRequest, CreateAgentResponse, CreateAgentError, Credentials | HttpClient.HttpClient>;
export type CreateAgentActionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an action group for an agent. An action group represents the actions that an agent can carry out for the customer by defining the APIs that an agent can call and the logic for calling them.
 *
 * To allow your agent to request the user for additional information when trying to complete a task, add an action group with the `parentActionGroupSignature` field set to `AMAZON.UserInput`.
 *
 * To allow your agent to generate, run, and troubleshoot code when trying to complete a task, add an action group with the `parentActionGroupSignature` field set to `AMAZON.CodeInterpreter`.
 *
 * You must leave the `description`, `apiSchema`, and `actionGroupExecutor` fields blank for this action group. During orchestration, if your agent determines that it needs to invoke an API in an action group, but doesn't have enough information to complete the API request, it will invoke this action group instead and return an Observation reprompting the user for more information.
 */
export declare const createAgentActionGroup: API.OperationMethod<CreateAgentActionGroupRequest, CreateAgentActionGroupResponse, CreateAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateAgentAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an alias of an agent that can be used to deploy the agent.
 */
export declare const createAgentAlias: API.OperationMethod<CreateAgentAliasRequest, CreateAgentAliasResponse, CreateAgentAliasError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Connects a knowledge base to a data source. You specify the configuration for the specific data source service in the `dataSourceConfiguration` field.
 *
 * You can't change the `chunkingConfiguration` after you create the data source connector.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a prompt flow that you can use to send an input through various steps to yield an output. Configure nodes, each of which corresponds to a step of the flow, and create connections between the nodes to create paths to different outputs. For more information, see How it works and Create a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type CreateFlowAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an alias of a flow for deployment. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createFlowAlias: API.OperationMethod<CreateFlowAliasRequest, CreateFlowAliasResponse, CreateFlowAliasError, Credentials | HttpClient.HttpClient>;
export type CreateFlowVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a version of the flow that you can deploy. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createFlowVersion: API.OperationMethod<CreateFlowVersionRequest, CreateFlowVersionResponse, CreateFlowVersionError, Credentials | HttpClient.HttpClient>;
export type CreateKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a knowledge base. A knowledge base contains your data sources so that Large Language Models (LLMs) can use your data. To create a knowledge base, you must first set up your data sources and configure a supported vector store. For more information, see Set up a knowledge base.
 *
 * To create a managed knowledge base, provide a `managedKnowledgeBaseConfiguration` during creation. For more information, see Build a managed knowledge base.
 *
 * - Provide the `name` and an optional `description`.
 *
 * - Provide the Amazon Resource Name (ARN) with permissions to create a knowledge base in the `roleArn` field.
 *
 * - For managed knowledge bases, set `embeddingModelType` to `MANAGED` to use the service-managed embedding model, or `CUSTOM` with an `embeddingModelArn` to use your own. To use your own KMS key for encryption, provide the ARN in `serverSideEncryptionConfiguration`. No vector store configuration is required for managed knowledge bases.
 *
 * - For self-managed knowledge bases, provide the embedding model to use in the `embeddingModelArn` field in the `knowledgeBaseConfiguration` object.
 *
 * - For self-managed knowledge bases, provide the configuration for your vector store in the `storageConfiguration` object.
 *
 * - For an Amazon OpenSearch Service database, use the `opensearchServerlessConfiguration` object. For more information, see Create a vector store in Amazon OpenSearch Service.
 *
 * - For an Amazon Aurora database, use the `RdsConfiguration` object. For more information, see Create a vector store in Amazon Aurora.
 *
 * - For a Pinecone database, use the `pineconeConfiguration` object. For more information, see Create a vector store in Pinecone.
 *
 * - For a Redis Enterprise Cloud database, use the `redisEnterpriseCloudConfiguration` object. For more information, see Create a vector store in Redis Enterprise Cloud.
 */
export declare const createKnowledgeBase: API.OperationMethod<CreateKnowledgeBaseRequest, CreateKnowledgeBaseResponse, CreateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type CreatePromptError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a prompt in your prompt library that you can add to a flow. For more information, see Prompt management in Amazon Bedrock, Create a prompt using Prompt management and Prompt flows in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createPrompt: API.OperationMethod<CreatePromptRequest, CreatePromptResponse, CreatePromptError, Credentials | HttpClient.HttpClient>;
export type CreatePromptVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a static snapshot of your prompt that can be deployed to production. For more information, see Deploy prompts using Prompt management by creating versions in the Amazon Bedrock User Guide.
 */
export declare const createPromptVersion: API.OperationMethod<CreatePromptVersionRequest, CreatePromptVersionResponse, CreatePromptVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an agent.
 */
export declare const deleteAgent: API.OperationMethod<DeleteAgentRequest, DeleteAgentResponse, DeleteAgentError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentActionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an action group in an agent.
 */
export declare const deleteAgentActionGroup: API.OperationMethod<DeleteAgentActionGroupRequest, DeleteAgentActionGroupResponse, DeleteAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentAliasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an alias of an agent.
 */
export declare const deleteAgentAlias: API.OperationMethod<DeleteAgentAliasRequest, DeleteAgentAliasResponse, DeleteAgentAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a version of an agent.
 */
export declare const deleteAgentVersion: API.OperationMethod<DeleteAgentVersionRequest, DeleteAgentVersionResponse, DeleteAgentVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a data source from a knowledge base.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a flow.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an alias of a flow.
 */
export declare const deleteFlowAlias: API.OperationMethod<DeleteFlowAliasRequest, DeleteFlowAliasResponse, DeleteFlowAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a version of a flow.
 */
export declare const deleteFlowVersion: API.OperationMethod<DeleteFlowVersionRequest, DeleteFlowVersionResponse, DeleteFlowVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a knowledge base. Before deleting a knowledge base, you should disassociate the knowledge base from any agents that it is associated with by making a DisassociateAgentKnowledgeBase request.
 */
export declare const deleteKnowledgeBase: API.OperationMethod<DeleteKnowledgeBaseRequest, DeleteKnowledgeBaseResponse, DeleteKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type DeleteKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes documents from a data source and syncs the changes to the knowledge base that is connected to it. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const deleteKnowledgeBaseDocuments: API.OperationMethod<DeleteKnowledgeBaseDocumentsRequest, DeleteKnowledgeBaseDocumentsResponse, DeleteKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient>;
export type DeletePromptError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a prompt or a version of it, depending on whether you include the `promptVersion` field or not. For more information, see Delete prompts from the Prompt management tool and Delete a version of a prompt from the Prompt management tool in the Amazon Bedrock User Guide.
 */
export declare const deletePrompt: API.OperationMethod<DeletePromptRequest, DeletePromptResponse, DeletePromptError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the resource policy associated with a knowledge base. After deletion, other AWS accounts can no longer access the knowledge base using cross-account permissions.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DisassociateAgentCollaboratorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an agent collaborator.
 */
export declare const disassociateAgentCollaborator: API.OperationMethod<DisassociateAgentCollaboratorRequest, DisassociateAgentCollaboratorResponse, DisassociateAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type DisassociateAgentKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a knowledge base from an agent.
 */
export declare const disassociateAgentKnowledgeBase: API.OperationMethod<DisassociateAgentKnowledgeBaseRequest, DisassociateAgentKnowledgeBaseResponse, DisassociateAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetAgentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an agent.
 */
export declare const getAgent: API.OperationMethod<GetAgentRequest, GetAgentResponse, GetAgentError, Credentials | HttpClient.HttpClient>;
export type GetAgentActionGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an action group for an agent.
 */
export declare const getAgentActionGroup: API.OperationMethod<GetAgentActionGroupRequest, GetAgentActionGroupResponse, GetAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type GetAgentAliasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an alias of an agent.
 */
export declare const getAgentAlias: API.OperationMethod<GetAgentAliasRequest, GetAgentAliasResponse, GetAgentAliasError, Credentials | HttpClient.HttpClient>;
export type GetAgentCollaboratorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an agent's collaborator.
 */
export declare const getAgentCollaborator: API.OperationMethod<GetAgentCollaboratorRequest, GetAgentCollaboratorResponse, GetAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type GetAgentKnowledgeBaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a knowledge base associated with an agent.
 */
export declare const getAgentKnowledgeBase: API.OperationMethod<GetAgentKnowledgeBaseRequest, GetAgentKnowledgeBaseResponse, GetAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetAgentVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a version of an agent.
 */
export declare const getAgentVersion: API.OperationMethod<GetAgentVersionRequest, GetAgentVersionResponse, GetAgentVersionError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a data source.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceRequest, GetDataSourceResponse, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetFlowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a flow. For more information, see Manage a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const getFlow: API.OperationMethod<GetFlowRequest, GetFlowResponse, GetFlowError, Credentials | HttpClient.HttpClient>;
export type GetFlowAliasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a flow. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const getFlowAlias: API.OperationMethod<GetFlowAliasRequest, GetFlowAliasResponse, GetFlowAliasError, Credentials | HttpClient.HttpClient>;
export type GetFlowVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a version of a flow. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const getFlowVersion: API.OperationMethod<GetFlowVersionRequest, GetFlowVersionResponse, GetFlowVersionError, Credentials | HttpClient.HttpClient>;
export type GetIngestionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a data ingestion job. Data sources are ingested into your knowledge base so that Large Language Models (LLMs) can use your data.
 */
export declare const getIngestionJob: API.OperationMethod<GetIngestionJobRequest, GetIngestionJobResponse, GetIngestionJobError, Credentials | HttpClient.HttpClient>;
export type GetKnowledgeBaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a knowledge base.
 */
export declare const getKnowledgeBase: API.OperationMethod<GetKnowledgeBaseRequest, GetKnowledgeBaseResponse, GetKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves specific documents from a data source that is connected to a knowledge base. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const getKnowledgeBaseDocuments: API.OperationMethod<GetKnowledgeBaseDocumentsRequest, GetKnowledgeBaseDocumentsResponse, GetKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient>;
export type GetPromptError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the working draft (`DRAFT` version) of a prompt or a version of it, depending on whether you include the `promptVersion` field or not. For more information, see View information about prompts using Prompt management and View information about a version of your prompt in the Amazon Bedrock User Guide.
 */
export declare const getPrompt: API.OperationMethod<GetPromptRequest, GetPromptResponse, GetPromptError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource policy associated with a knowledge base.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type IngestKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Ingests documents directly into the knowledge base that is connected to the data source. The `dataSourceType` specified in the content for each document must match the type of the data source that you specify in the header. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const ingestKnowledgeBaseDocuments: API.OperationMethod<IngestKnowledgeBaseDocumentsRequest, IngestKnowledgeBaseDocumentsResponse, IngestKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient>;
export type ListAgentActionGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the action groups for an agent and information about each one.
 */
export declare const listAgentActionGroups: API.PaginatedOperationMethod<ListAgentActionGroupsRequest, ListAgentActionGroupsResponse, ListAgentActionGroupsError, Credentials | HttpClient.HttpClient, ActionGroupSummary>;
export type ListAgentAliasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the aliases of an agent and information about each one.
 */
export declare const listAgentAliases: API.PaginatedOperationMethod<ListAgentAliasesRequest, ListAgentAliasesResponse, ListAgentAliasesError, Credentials | HttpClient.HttpClient, AgentAliasSummary>;
export type ListAgentCollaboratorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve a list of an agent's collaborators.
 */
export declare const listAgentCollaborators: API.PaginatedOperationMethod<ListAgentCollaboratorsRequest, ListAgentCollaboratorsResponse, ListAgentCollaboratorsError, Credentials | HttpClient.HttpClient, AgentCollaboratorSummary>;
export type ListAgentKnowledgeBasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists knowledge bases associated with an agent and information about each one.
 */
export declare const listAgentKnowledgeBases: API.PaginatedOperationMethod<ListAgentKnowledgeBasesRequest, ListAgentKnowledgeBasesResponse, ListAgentKnowledgeBasesError, Credentials | HttpClient.HttpClient, AgentKnowledgeBaseSummary>;
export type ListAgentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the agents belonging to an account and information about each agent.
 */
export declare const listAgents: API.PaginatedOperationMethod<ListAgentsRequest, ListAgentsResponse, ListAgentsError, Credentials | HttpClient.HttpClient, AgentSummary>;
export type ListAgentVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the versions of an agent and information about each version.
 */
export declare const listAgentVersions: API.PaginatedOperationMethod<ListAgentVersionsRequest, ListAgentVersionsResponse, ListAgentVersionsError, Credentials | HttpClient.HttpClient, AgentVersionSummary>;
export type ListDataSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data sources in a knowledge base and information about each one.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSourceSummary>;
export type ListFlowAliasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of aliases for a flow.
 */
export declare const listFlowAliases: API.PaginatedOperationMethod<ListFlowAliasesRequest, ListFlowAliasesResponse, ListFlowAliasesError, Credentials | HttpClient.HttpClient, FlowAliasSummary>;
export type ListFlowsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of flows and information about each flow. For more information, see Manage a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsRequest, ListFlowsResponse, ListFlowsError, Credentials | HttpClient.HttpClient, FlowSummary>;
export type ListFlowVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of information about each flow. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const listFlowVersions: API.PaginatedOperationMethod<ListFlowVersionsRequest, ListFlowVersionsResponse, ListFlowVersionsError, Credentials | HttpClient.HttpClient, FlowVersionSummary>;
export type ListIngestionJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data ingestion jobs for a data source. The list also includes information about each job.
 */
export declare const listIngestionJobs: API.PaginatedOperationMethod<ListIngestionJobsRequest, ListIngestionJobsResponse, ListIngestionJobsError, Credentials | HttpClient.HttpClient, IngestionJobSummary>;
export type ListKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all the documents contained in a data source that is connected to a knowledge base. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const listKnowledgeBaseDocuments: API.PaginatedOperationMethod<ListKnowledgeBaseDocumentsRequest, ListKnowledgeBaseDocumentsResponse, ListKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient, KnowledgeBaseDocumentDetail>;
export type ListKnowledgeBasesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the knowledge bases in an account. The list also includesinformation about each knowledge base.
 */
export declare const listKnowledgeBases: API.PaginatedOperationMethod<ListKnowledgeBasesRequest, ListKnowledgeBasesResponse, ListKnowledgeBasesError, Credentials | HttpClient.HttpClient, KnowledgeBaseSummary>;
export type ListPromptsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns either information about the working draft (`DRAFT` version) of each prompt in an account, or information about of all versions of a prompt, depending on whether you include the `promptIdentifier` field or not. For more information, see View information about prompts using Prompt management in the Amazon Bedrock User Guide.
 */
export declare const listPrompts: API.PaginatedOperationMethod<ListPromptsRequest, ListPromptsResponse, ListPromptsError, Credentials | HttpClient.HttpClient, PromptSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all the tags for the resource you specify.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PrepareAgentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a `DRAFT` version of the agent that can be used for internal testing.
 */
export declare const prepareAgent: API.OperationMethod<PrepareAgentRequest, PrepareAgentResponse, PrepareAgentError, Credentials | HttpClient.HttpClient>;
export type PrepareFlowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Prepares the `DRAFT` version of a flow so that it can be invoked. For more information, see Test a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const prepareFlow: API.OperationMethod<PrepareFlowRequest, PrepareFlowResponse, PrepareFlowError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a resource policy with a knowledge base. A resource policy allows other AWS accounts to access the knowledge base. For more information, see Cross-account access for knowledge bases.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Begins a data ingestion job. Data sources are ingested into your knowledge base so that Large Language Models (LLMs) can use your data.
 */
export declare const startIngestionJob: API.OperationMethod<StartIngestionJobRequest, StartIngestionJobResponse, StartIngestionJobError, Credentials | HttpClient.HttpClient>;
export type StopIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a currently running data ingestion job. You can send a `StartIngestionJob` request again to ingest the rest of your data when you are ready.
 */
export declare const stopIngestionJob: API.OperationMethod<StopIngestionJobRequest, StopIngestionJobResponse, StopIngestionJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate tags with a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an agent.
 */
export declare const updateAgent: API.OperationMethod<UpdateAgentRequest, UpdateAgentResponse, UpdateAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentActionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration for an action group for an agent.
 */
export declare const updateAgentActionGroup: API.OperationMethod<UpdateAgentActionGroupRequest, UpdateAgentActionGroupResponse, UpdateAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates configurations for an alias of an agent.
 */
export declare const updateAgentAlias: API.OperationMethod<UpdateAgentAliasRequest, UpdateAgentAliasResponse, UpdateAgentAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentCollaboratorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an agent's collaborator.
 */
export declare const updateAgentCollaborator: API.OperationMethod<UpdateAgentCollaboratorRequest, UpdateAgentCollaboratorResponse, UpdateAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration for a knowledge base that has been associated with an agent.
 */
export declare const updateAgentKnowledgeBase: API.OperationMethod<UpdateAgentKnowledgeBaseRequest, UpdateAgentKnowledgeBaseResponse, UpdateAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configurations for a data source connector.
 *
 * You can't change the `chunkingConfiguration` after you create the data source connector. Specify the existing `chunkingConfiguration`.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies a flow. Include both fields that you want to keep and fields that you want to change. For more information, see How it works and Create a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the alias of a flow. Include both fields that you want to keep and ones that you want to change. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const updateFlowAlias: API.OperationMethod<UpdateFlowAliasRequest, UpdateFlowAliasResponse, UpdateFlowAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a knowledge base with the fields that you specify. Because all fields will be overwritten, you must include the same values for fields that you want to keep the same.
 *
 * You can change the following fields:
 *
 * - `name`
 *
 * - `description`
 *
 * - `roleArn`
 *
 * You can't change the `knowledgeBaseConfiguration` or `storageConfiguration` fields, so you must specify the same configurations as when you created the knowledge base. You can send a GetKnowledgeBase request and copy the same configurations.
 */
export declare const updateKnowledgeBase: API.OperationMethod<UpdateKnowledgeBaseRequest, UpdateKnowledgeBaseResponse, UpdateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type UpdatePromptError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies a prompt in your prompt library. Include both fields that you want to keep and fields that you want to replace. For more information, see Prompt management in Amazon Bedrock and Edit prompts in your prompt library in the Amazon Bedrock User Guide.
 */
export declare const updatePrompt: API.OperationMethod<UpdatePromptRequest, UpdatePromptResponse, UpdatePromptError, Credentials | HttpClient.HttpClient>;
export type ValidateFlowDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Validates the definition of a flow.
 */
export declare const validateFlowDefinition: API.OperationMethod<ValidateFlowDefinitionRequest, ValidateFlowDefinitionResponse, ValidateFlowDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-agent.d.ts.map