import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AlreadyCreatedException_base: S.Class<AlreadyCreatedException, S.TaggedStruct<"AlreadyCreatedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AlreadyCreatedException extends /*@__PURE__*/ AlreadyCreatedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type IdentityCenterInstanceArn = string;
export interface IdentityCenter {
    instanceArn: string;
}
export declare const IdentityCenter: S.Schema<IdentityCenter>;
export type IdentitySource = {
    identityCenter: IdentityCenter;
};
export declare const IdentitySource: any;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export interface CreateApplicationRequest {
    identitySource: IdentitySource;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type ApplicationArn = string;
export interface CreateApplicationResponse {
    applicationArn: string;
}
export declare const CreateApplicationResponse: S.Schema<CreateApplicationResponse>;
export type UserId = string;
export type GroupId = string;
export type IdentityCenterPrincipal = {
    userId: string;
    groupId?: never;
} | {
    userId?: never;
    groupId: string;
};
export declare const IdentityCenterPrincipal: any;
export type Principal = {
    identityCenter: IdentityCenterPrincipal;
};
export declare const Principal: any;
export type RoleArn = string;
export interface PrincipalRoleEntitlement {
    principal: Principal;
    roleArn: string;
}
export declare const PrincipalRoleEntitlement: S.Schema<PrincipalRoleEntitlement>;
export type Entitlement = {
    principalRole: PrincipalRoleEntitlement;
};
export declare const Entitlement: any;
export interface CreateEntitlementRequest {
    applicationArn: string;
    entitlement: Entitlement;
}
export declare const CreateEntitlementRequest: S.Schema<CreateEntitlementRequest>;
export interface CreateEntitlementResponse {
    entitlementId: string;
}
export declare const CreateEntitlementResponse: S.Schema<CreateEntitlementResponse>;
export interface DeleteApplicationRequest {
    applicationArn: string;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export interface DeleteEntitlementRequest {
    applicationArn: string;
    entitlementId: string;
}
export declare const DeleteEntitlementRequest: S.Schema<DeleteEntitlementRequest>;
export interface DeleteEntitlementResponse {
}
export declare const DeleteEntitlementResponse: S.Schema<DeleteEntitlementResponse>;
export interface GetApplicationRequest {
    applicationArn: string;
}
export declare const GetApplicationRequest: S.Schema<GetApplicationRequest>;
export type IdentityCenterApplicationArn = string;
export interface IdentityCenterDetails {
    instanceArn: string;
    applicationArn?: string;
}
export declare const IdentityCenterDetails: S.Schema<IdentityCenterDetails>;
export type IdentitySourceDetails = {
    identityCenter: IdentityCenterDetails;
};
export declare const IdentitySourceDetails: any;
export type Status = "CREATE_IN_PROGRESS" | "ACTIVE" | "DELETE_IN_PROGRESS" | "CREATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const Status: any;
export type ErrorCode = "AUTHORIZATION_ERROR" | "RESOURCE_NOT_FOUND_ERROR" | "SERVICE_QUOTA_EXCEEDED_ERROR" | "INTERNAL_SERVICE_ERROR" | (string & {});
export declare const ErrorCode: any;
export interface ErrorDetails {
    code: ErrorCode;
    message: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export interface GetApplicationResponse {
    identitySource: IdentitySourceDetails;
    status: Status;
    tenantId?: string;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    error?: ErrorDetails;
}
export declare const GetApplicationResponse: S.Schema<GetApplicationResponse>;
export interface GetEntitlementRequest {
    applicationArn: string;
    entitlementId: string;
}
export declare const GetEntitlementRequest: S.Schema<GetEntitlementRequest>;
export type Account = string;
export interface PrincipalRoleEntitlementDetails {
    principal: Principal;
    roleArn: string;
    account: string;
    accountName?: string;
}
export declare const PrincipalRoleEntitlementDetails: S.Schema<PrincipalRoleEntitlementDetails>;
export type EntitlementDetails = {
    principalRole: PrincipalRoleEntitlementDetails;
};
export declare const EntitlementDetails: any;
export interface GetEntitlementResponse {
    applicationArn: string;
    entitlementId: string;
    entitlement: EntitlementDetails;
    createdAt: Date;
}
export declare const GetEntitlementResponse: S.Schema<GetEntitlementResponse>;
export interface ListApplicationsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListApplicationsRequest: S.Schema<ListApplicationsRequest>;
export interface ApplicationSummary {
    applicationArn: string;
    tenantId?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const ApplicationSummary: S.Schema<ApplicationSummary>;
export type ApplicationList = ApplicationSummary[];
export declare const ApplicationList: any;
export interface ListApplicationsResponse {
    applications: ApplicationSummary[];
    nextToken?: string;
}
export declare const ListApplicationsResponse: S.Schema<ListApplicationsResponse>;
export type IdentityCenterPrincipalFilter = {
    userId: string;
    groupId?: never;
} | {
    userId?: never;
    groupId: string;
};
export declare const IdentityCenterPrincipalFilter: any;
export type PrincipalFilter = {
    identityCenter: IdentityCenterPrincipalFilter;
};
export declare const PrincipalFilter: any;
export interface PrincipalRoleEntitlementFilter {
    principal?: PrincipalFilter;
    roleArn?: string;
    account?: string;
}
export declare const PrincipalRoleEntitlementFilter: S.Schema<PrincipalRoleEntitlementFilter>;
export interface EntitlementFilter {
    principalRole?: PrincipalRoleEntitlementFilter;
}
export declare const EntitlementFilter: S.Schema<EntitlementFilter>;
export interface ListEntitlementsRequest {
    applicationArn: string;
    filter: EntitlementFilter;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEntitlementsRequest: S.Schema<ListEntitlementsRequest>;
export interface PrincipalRoleEntitlementSummary {
    principal: Principal;
    roleArn: string;
    account: string;
    accountName?: string;
}
export declare const PrincipalRoleEntitlementSummary: S.Schema<PrincipalRoleEntitlementSummary>;
export type EntitlementSummary = {
    principalRole: PrincipalRoleEntitlementSummary;
};
export declare const EntitlementSummary: any;
export interface EntitlementsListMember {
    entitlementId: string;
    entitlement: EntitlementSummary;
    createdAt: Date;
}
export declare const EntitlementsListMember: S.Schema<EntitlementsListMember>;
export type EntitlementsList = EntitlementsListMember[];
export declare const EntitlementsList: any;
export interface ListEntitlementsResponse {
    entitlements: EntitlementsListMember[];
    nextToken?: string;
}
export declare const ListEntitlementsResponse: S.Schema<ListEntitlementsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type CreateApplicationError = AccessDeniedException | AlreadyCreatedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an account access manager instance and its Amazon Web Services account access application in the associated IAM Identity Center instance. This operation is idempotent; calling it multiple times with the same parameters returns the existing application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateEntitlementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an entitlement (assignment) in account access manager. An entitlement (assignment) grants a principal (IAM Identity Center user or group) permission to assume a specified IAM role in an Amazon Web Services account. This operation is idempotent.
 */
export declare const createEntitlement: API.OperationMethod<CreateEntitlementRequest, CreateEntitlementResponse, CreateEntitlementError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an account access manager application. This operation is idempotent; deleting an application that has already been deleted does not return an error.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteEntitlementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an entitlement from an account access manager application. This operation is idempotent; deleting an entitlement that has already been deleted does not return an error.
 */
export declare const deleteEntitlement: API.OperationMethod<DeleteEntitlementRequest, DeleteEntitlementResponse, DeleteEntitlementError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an account access manager application, including its status, identity source, and tags.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetEntitlementError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific entitlement for an account access manager application, including the principal, IAM role, and target account.
 */
export declare const getEntitlement: API.OperationMethod<GetEntitlementRequest, GetEntitlementResponse, GetEntitlementError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the account access manager applications in your account. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListEntitlementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the entitlements for a specified account access manager application. You can filter results by principal, IAM role, or account. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listEntitlements: API.PaginatedOperationMethod<ListEntitlementsRequest, ListEntitlementsResponse, ListEntitlementsError, Credentials | HttpClient.HttpClient, EntitlementsListMember>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with an account access manager resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to an account access manager resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from an account access manager resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=account-access.d.ts.map