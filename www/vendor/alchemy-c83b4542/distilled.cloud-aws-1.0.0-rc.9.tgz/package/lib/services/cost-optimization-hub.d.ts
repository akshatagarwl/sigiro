import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface GetPreferencesRequest {
}
export declare const GetPreferencesRequest: S.Schema<GetPreferencesRequest>;
export type SavingsEstimationMode = "BeforeDiscounts" | "AfterDiscounts" | (string & {});
export declare const SavingsEstimationMode: any;
export type MemberAccountDiscountVisibility = "All" | "None" | (string & {});
export declare const MemberAccountDiscountVisibility: any;
export type Term = "OneYear" | "ThreeYears" | (string & {});
export declare const Term: any;
export type PaymentOption = "AllUpfront" | "PartialUpfront" | "NoUpfront" | (string & {});
export declare const PaymentOption: any;
export interface PreferredCommitment {
    term?: Term;
    paymentOption?: PaymentOption;
}
export declare const PreferredCommitment: S.Schema<PreferredCommitment>;
export interface GetPreferencesResponse {
    savingsEstimationMode?: SavingsEstimationMode;
    memberAccountDiscountVisibility?: MemberAccountDiscountVisibility;
    preferredCommitment?: PreferredCommitment;
}
export declare const GetPreferencesResponse: S.Schema<GetPreferencesResponse>;
export interface GetRecommendationRequest {
    recommendationId: string;
}
export declare const GetRecommendationRequest: S.Schema<GetRecommendationRequest>;
export type ResourceType = "Ec2Instance" | "LambdaFunction" | "EbsVolume" | "EcsService" | "Ec2AutoScalingGroup" | "Ec2InstanceSavingsPlans" | "ComputeSavingsPlans" | "SageMakerSavingsPlans" | "Ec2ReservedInstances" | "RdsReservedInstances" | "OpenSearchReservedInstances" | "RedshiftReservedInstances" | "ElastiCacheReservedInstances" | "RdsDbInstanceStorage" | "RdsDbInstance" | "AuroraDbClusterStorage" | "DynamoDbReservedCapacity" | "MemoryDbReservedInstances" | "NatGateway" | "DynamoDBTable" | "ElastiCacheCluster" | "MemoryDBCluster" | "DocumentDBCluster" | "WorkSpaces" | "SageMakerEndpoint" | (string & {});
export declare const ResourceType: any;
export type Source = "ComputeOptimizer" | "CostExplorer" | (string & {});
export declare const Source: any;
export type Datetime = Date;
export type ImplementationEffort = "VeryLow" | "Low" | "Medium" | "High" | "VeryHigh" | (string & {});
export declare const ImplementationEffort: any;
export type ActionType = "Rightsize" | "Stop" | "Upgrade" | "PurchaseSavingsPlans" | "PurchaseReservedInstances" | "MigrateToGraviton" | "Delete" | "ScaleIn" | (string & {});
export declare const ActionType: any;
export interface ComputeConfiguration {
    vCpu?: number;
    memorySizeInMB?: number;
    architecture?: string;
    platform?: string;
}
export declare const ComputeConfiguration: S.Schema<ComputeConfiguration>;
export interface LambdaFunctionConfiguration {
    compute?: ComputeConfiguration;
}
export declare const LambdaFunctionConfiguration: S.Schema<LambdaFunctionConfiguration>;
export interface Usage {
    usageType?: string;
    usageAmount?: number;
    operation?: string;
    productCode?: string;
    unit?: string;
}
export declare const Usage: S.Schema<Usage>;
export type UsageList = Usage[];
export declare const UsageList: any;
export interface EstimatedDiscounts {
    savingsPlansDiscount?: number;
    reservedInstancesDiscount?: number;
    otherDiscount?: number;
}
export declare const EstimatedDiscounts: S.Schema<EstimatedDiscounts>;
export interface ResourcePricing {
    estimatedCostBeforeDiscounts?: number;
    estimatedNetUnusedAmortizedCommitments?: number;
    estimatedDiscounts?: EstimatedDiscounts;
    estimatedCostAfterDiscounts?: number;
}
export declare const ResourcePricing: S.Schema<ResourcePricing>;
export interface ResourceCostCalculation {
    usages?: Usage[];
    pricing?: ResourcePricing;
}
export declare const ResourceCostCalculation: S.Schema<ResourceCostCalculation>;
export interface LambdaFunction {
    configuration?: LambdaFunctionConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const LambdaFunction: S.Schema<LambdaFunction>;
export interface EcsServiceConfiguration {
    compute?: ComputeConfiguration;
}
export declare const EcsServiceConfiguration: S.Schema<EcsServiceConfiguration>;
export interface EcsService {
    configuration?: EcsServiceConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const EcsService: S.Schema<EcsService>;
export interface InstanceConfiguration {
    type?: string;
}
export declare const InstanceConfiguration: S.Schema<InstanceConfiguration>;
export interface Ec2InstanceConfiguration {
    instance?: InstanceConfiguration;
}
export declare const Ec2InstanceConfiguration: S.Schema<Ec2InstanceConfiguration>;
export interface Ec2Instance {
    configuration?: Ec2InstanceConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const Ec2Instance: S.Schema<Ec2Instance>;
export interface StorageConfiguration {
    type?: string;
    sizeInGb?: number;
}
export declare const StorageConfiguration: S.Schema<StorageConfiguration>;
export interface BlockStoragePerformanceConfiguration {
    iops?: number;
    throughput?: number;
}
export declare const BlockStoragePerformanceConfiguration: S.Schema<BlockStoragePerformanceConfiguration>;
export interface EbsVolumeConfiguration {
    storage?: StorageConfiguration;
    performance?: BlockStoragePerformanceConfiguration;
    attachmentState?: string;
}
export declare const EbsVolumeConfiguration: S.Schema<EbsVolumeConfiguration>;
export interface EbsVolume {
    configuration?: EbsVolumeConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const EbsVolume: S.Schema<EbsVolume>;
export interface MixedInstanceConfiguration {
    type?: string;
}
export declare const MixedInstanceConfiguration: S.Schema<MixedInstanceConfiguration>;
export type MixedInstanceConfigurationList = MixedInstanceConfiguration[];
export declare const MixedInstanceConfigurationList: any;
export type Ec2AutoScalingGroupType = "SingleInstanceType" | "MixedInstanceTypes" | (string & {});
export declare const Ec2AutoScalingGroupType: any;
export type AllocationStrategy = "Prioritized" | "LowestPrice" | (string & {});
export declare const AllocationStrategy: any;
export interface Ec2AutoScalingGroupConfiguration {
    instance?: InstanceConfiguration;
    mixedInstances?: MixedInstanceConfiguration[];
    type?: Ec2AutoScalingGroupType;
    allocationStrategy?: AllocationStrategy;
}
export declare const Ec2AutoScalingGroupConfiguration: S.Schema<Ec2AutoScalingGroupConfiguration>;
export interface Ec2AutoScalingGroup {
    configuration?: Ec2AutoScalingGroupConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const Ec2AutoScalingGroup: S.Schema<Ec2AutoScalingGroup>;
export interface Ec2ReservedInstancesConfiguration {
    accountScope?: string;
    service?: string;
    term?: string;
    paymentOption?: string;
    reservedInstancesRegion?: string;
    upfrontCost?: string;
    monthlyRecurringCost?: string;
    normalizedUnitsToPurchase?: string;
    numberOfInstancesToPurchase?: string;
    offeringClass?: string;
    instanceFamily?: string;
    instanceType?: string;
    currentGeneration?: string;
    platform?: string;
    tenancy?: string;
    sizeFlexEligible?: boolean;
}
export declare const Ec2ReservedInstancesConfiguration: S.Schema<Ec2ReservedInstancesConfiguration>;
export interface ReservedInstancesPricing {
    estimatedOnDemandCost?: number;
    monthlyReservationEligibleCost?: number;
    savingsPercentage?: number;
    estimatedMonthlyAmortizedReservationCost?: number;
}
export declare const ReservedInstancesPricing: S.Schema<ReservedInstancesPricing>;
export interface ReservedInstancesCostCalculation {
    pricing?: ReservedInstancesPricing;
}
export declare const ReservedInstancesCostCalculation: S.Schema<ReservedInstancesCostCalculation>;
export interface Ec2ReservedInstances {
    configuration?: Ec2ReservedInstancesConfiguration;
    costCalculation?: ReservedInstancesCostCalculation;
}
export declare const Ec2ReservedInstances: S.Schema<Ec2ReservedInstances>;
export interface RdsReservedInstancesConfiguration {
    accountScope?: string;
    service?: string;
    term?: string;
    paymentOption?: string;
    reservedInstancesRegion?: string;
    upfrontCost?: string;
    monthlyRecurringCost?: string;
    normalizedUnitsToPurchase?: string;
    numberOfInstancesToPurchase?: string;
    instanceFamily?: string;
    instanceType?: string;
    sizeFlexEligible?: boolean;
    currentGeneration?: string;
    licenseModel?: string;
    databaseEdition?: string;
    databaseEngine?: string;
    deploymentOption?: string;
}
export declare const RdsReservedInstancesConfiguration: S.Schema<RdsReservedInstancesConfiguration>;
export interface RdsReservedInstances {
    configuration?: RdsReservedInstancesConfiguration;
    costCalculation?: ReservedInstancesCostCalculation;
}
export declare const RdsReservedInstances: S.Schema<RdsReservedInstances>;
export interface ElastiCacheReservedInstancesConfiguration {
    accountScope?: string;
    service?: string;
    term?: string;
    paymentOption?: string;
    reservedInstancesRegion?: string;
    upfrontCost?: string;
    monthlyRecurringCost?: string;
    normalizedUnitsToPurchase?: string;
    numberOfInstancesToPurchase?: string;
    instanceFamily?: string;
    instanceType?: string;
    currentGeneration?: string;
    sizeFlexEligible?: boolean;
}
export declare const ElastiCacheReservedInstancesConfiguration: S.Schema<ElastiCacheReservedInstancesConfiguration>;
export interface ElastiCacheReservedInstances {
    configuration?: ElastiCacheReservedInstancesConfiguration;
    costCalculation?: ReservedInstancesCostCalculation;
}
export declare const ElastiCacheReservedInstances: S.Schema<ElastiCacheReservedInstances>;
export interface OpenSearchReservedInstancesConfiguration {
    accountScope?: string;
    service?: string;
    term?: string;
    paymentOption?: string;
    reservedInstancesRegion?: string;
    upfrontCost?: string;
    monthlyRecurringCost?: string;
    normalizedUnitsToPurchase?: string;
    numberOfInstancesToPurchase?: string;
    instanceType?: string;
    currentGeneration?: string;
    sizeFlexEligible?: boolean;
}
export declare const OpenSearchReservedInstancesConfiguration: S.Schema<OpenSearchReservedInstancesConfiguration>;
export interface OpenSearchReservedInstances {
    configuration?: OpenSearchReservedInstancesConfiguration;
    costCalculation?: ReservedInstancesCostCalculation;
}
export declare const OpenSearchReservedInstances: S.Schema<OpenSearchReservedInstances>;
export interface RedshiftReservedInstancesConfiguration {
    accountScope?: string;
    service?: string;
    term?: string;
    paymentOption?: string;
    reservedInstancesRegion?: string;
    upfrontCost?: string;
    monthlyRecurringCost?: string;
    normalizedUnitsToPurchase?: string;
    numberOfInstancesToPurchase?: string;
    instanceFamily?: string;
    instanceType?: string;
    sizeFlexEligible?: boolean;
    currentGeneration?: string;
}
export declare const RedshiftReservedInstancesConfiguration: S.Schema<RedshiftReservedInstancesConfiguration>;
export interface RedshiftReservedInstances {
    configuration?: RedshiftReservedInstancesConfiguration;
    costCalculation?: ReservedInstancesCostCalculation;
}
export declare const RedshiftReservedInstances: S.Schema<RedshiftReservedInstances>;
export interface Ec2InstanceSavingsPlansConfiguration {
    accountScope?: string;
    term?: string;
    paymentOption?: string;
    hourlyCommitment?: string;
    instanceFamily?: string;
    savingsPlansRegion?: string;
}
export declare const Ec2InstanceSavingsPlansConfiguration: S.Schema<Ec2InstanceSavingsPlansConfiguration>;
export interface SavingsPlansPricing {
    monthlySavingsPlansEligibleCost?: number;
    estimatedMonthlyCommitment?: number;
    savingsPercentage?: number;
    estimatedOnDemandCost?: number;
}
export declare const SavingsPlansPricing: S.Schema<SavingsPlansPricing>;
export interface SavingsPlansCostCalculation {
    pricing?: SavingsPlansPricing;
}
export declare const SavingsPlansCostCalculation: S.Schema<SavingsPlansCostCalculation>;
export interface Ec2InstanceSavingsPlans {
    configuration?: Ec2InstanceSavingsPlansConfiguration;
    costCalculation?: SavingsPlansCostCalculation;
}
export declare const Ec2InstanceSavingsPlans: S.Schema<Ec2InstanceSavingsPlans>;
export interface ComputeSavingsPlansConfiguration {
    accountScope?: string;
    term?: string;
    paymentOption?: string;
    hourlyCommitment?: string;
}
export declare const ComputeSavingsPlansConfiguration: S.Schema<ComputeSavingsPlansConfiguration>;
export interface ComputeSavingsPlans {
    configuration?: ComputeSavingsPlansConfiguration;
    costCalculation?: SavingsPlansCostCalculation;
}
export declare const ComputeSavingsPlans: S.Schema<ComputeSavingsPlans>;
export interface SageMakerSavingsPlansConfiguration {
    accountScope?: string;
    term?: string;
    paymentOption?: string;
    hourlyCommitment?: string;
}
export declare const SageMakerSavingsPlansConfiguration: S.Schema<SageMakerSavingsPlansConfiguration>;
export interface SageMakerSavingsPlans {
    configuration?: SageMakerSavingsPlansConfiguration;
    costCalculation?: SavingsPlansCostCalculation;
}
export declare const SageMakerSavingsPlans: S.Schema<SageMakerSavingsPlans>;
export interface DbInstanceConfiguration {
    dbInstanceClass?: string;
}
export declare const DbInstanceConfiguration: S.Schema<DbInstanceConfiguration>;
export interface RdsDbInstanceConfiguration {
    instance?: DbInstanceConfiguration;
}
export declare const RdsDbInstanceConfiguration: S.Schema<RdsDbInstanceConfiguration>;
export interface RdsDbInstance {
    configuration?: RdsDbInstanceConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const RdsDbInstance: S.Schema<RdsDbInstance>;
export interface RdsDbInstanceStorageConfiguration {
    storageType?: string;
    allocatedStorageInGb?: number;
    iops?: number;
    storageThroughput?: number;
}
export declare const RdsDbInstanceStorageConfiguration: S.Schema<RdsDbInstanceStorageConfiguration>;
export interface RdsDbInstanceStorage {
    configuration?: RdsDbInstanceStorageConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const RdsDbInstanceStorage: S.Schema<RdsDbInstanceStorage>;
export interface AuroraDbClusterStorageConfiguration {
    storageType?: string;
}
export declare const AuroraDbClusterStorageConfiguration: S.Schema<AuroraDbClusterStorageConfiguration>;
export interface AuroraDbClusterStorage {
    configuration?: AuroraDbClusterStorageConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const AuroraDbClusterStorage: S.Schema<AuroraDbClusterStorage>;
export interface DynamoDbReservedCapacityConfiguration {
    accountScope?: string;
    service?: string;
    term?: string;
    paymentOption?: string;
    reservedInstancesRegion?: string;
    upfrontCost?: string;
    monthlyRecurringCost?: string;
    numberOfCapacityUnitsToPurchase?: string;
    capacityUnits?: string;
}
export declare const DynamoDbReservedCapacityConfiguration: S.Schema<DynamoDbReservedCapacityConfiguration>;
export interface DynamoDbReservedCapacity {
    configuration?: DynamoDbReservedCapacityConfiguration;
    costCalculation?: ReservedInstancesCostCalculation;
}
export declare const DynamoDbReservedCapacity: S.Schema<DynamoDbReservedCapacity>;
export interface MemoryDbReservedInstancesConfiguration {
    accountScope?: string;
    service?: string;
    term?: string;
    paymentOption?: string;
    reservedInstancesRegion?: string;
    upfrontCost?: string;
    monthlyRecurringCost?: string;
    normalizedUnitsToPurchase?: string;
    numberOfInstancesToPurchase?: string;
    instanceType?: string;
    instanceFamily?: string;
    sizeFlexEligible?: boolean;
    currentGeneration?: string;
}
export declare const MemoryDbReservedInstancesConfiguration: S.Schema<MemoryDbReservedInstancesConfiguration>;
export interface MemoryDbReservedInstances {
    configuration?: MemoryDbReservedInstancesConfiguration;
    costCalculation?: ReservedInstancesCostCalculation;
}
export declare const MemoryDbReservedInstances: S.Schema<MemoryDbReservedInstances>;
export interface NatGatewayConfiguration {
    activeConnectionCount?: number;
    packetsInFromSource?: number;
    packetsInFromDestination?: number;
}
export declare const NatGatewayConfiguration: S.Schema<NatGatewayConfiguration>;
export interface NatGateway {
    configuration?: NatGatewayConfiguration;
    costCalculation?: ResourceCostCalculation;
}
export declare const NatGateway: S.Schema<NatGateway>;
export interface DynamoDbTable {
    costCalculation?: ResourceCostCalculation;
}
export declare const DynamoDbTable: S.Schema<DynamoDbTable>;
export interface ElastiCacheCluster {
    costCalculation?: ResourceCostCalculation;
}
export declare const ElastiCacheCluster: S.Schema<ElastiCacheCluster>;
export interface MemoryDbCluster {
    costCalculation?: ResourceCostCalculation;
}
export declare const MemoryDbCluster: S.Schema<MemoryDbCluster>;
export interface DocumentDbCluster {
    costCalculation?: ResourceCostCalculation;
}
export declare const DocumentDbCluster: S.Schema<DocumentDbCluster>;
export interface WorkSpaces {
    costCalculation?: ResourceCostCalculation;
}
export declare const WorkSpaces: S.Schema<WorkSpaces>;
export interface SageMakerEndpoint {
    costCalculation?: ResourceCostCalculation;
}
export declare const SageMakerEndpoint: S.Schema<SageMakerEndpoint>;
export type ResourceDetails = {
    lambdaFunction: LambdaFunction;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService: EcsService;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance: Ec2Instance;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume: EbsVolume;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup: Ec2AutoScalingGroup;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances: Ec2ReservedInstances;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances: RdsReservedInstances;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances: ElastiCacheReservedInstances;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances: OpenSearchReservedInstances;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances: RedshiftReservedInstances;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans: Ec2InstanceSavingsPlans;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans: ComputeSavingsPlans;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans: SageMakerSavingsPlans;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance: RdsDbInstance;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage: RdsDbInstanceStorage;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage: AuroraDbClusterStorage;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity: DynamoDbReservedCapacity;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances: MemoryDbReservedInstances;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway: NatGateway;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable: DynamoDbTable;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster: ElastiCacheCluster;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster: MemoryDbCluster;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster: DocumentDbCluster;
    workSpaces?: never;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces: WorkSpaces;
    sageMakerEndpoint?: never;
} | {
    lambdaFunction?: never;
    ecsService?: never;
    ec2Instance?: never;
    ebsVolume?: never;
    ec2AutoScalingGroup?: never;
    ec2ReservedInstances?: never;
    rdsReservedInstances?: never;
    elastiCacheReservedInstances?: never;
    openSearchReservedInstances?: never;
    redshiftReservedInstances?: never;
    ec2InstanceSavingsPlans?: never;
    computeSavingsPlans?: never;
    sageMakerSavingsPlans?: never;
    rdsDbInstance?: never;
    rdsDbInstanceStorage?: never;
    auroraDbClusterStorage?: never;
    dynamoDbReservedCapacity?: never;
    memoryDbReservedInstances?: never;
    natGateway?: never;
    dynamoDbTable?: never;
    elastiCacheCluster?: never;
    memoryDbCluster?: never;
    documentDbCluster?: never;
    workSpaces?: never;
    sageMakerEndpoint: SageMakerEndpoint;
};
export declare const ResourceDetails: any;
export interface Tag {
    key?: string;
    value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface GetRecommendationResponse {
    recommendationId?: string;
    resourceId?: string;
    resourceArn?: string;
    accountId?: string;
    currencyCode?: string;
    recommendationLookbackPeriodInDays?: number;
    costCalculationLookbackPeriodInDays?: number;
    estimatedSavingsPercentage?: number;
    estimatedSavingsOverCostCalculationLookbackPeriod?: number;
    currentResourceType?: ResourceType;
    recommendedResourceType?: ResourceType;
    region?: string;
    source?: Source;
    lastRefreshTimestamp?: Date;
    estimatedMonthlySavings?: number;
    estimatedMonthlyCost?: number;
    implementationEffort?: ImplementationEffort;
    restartNeeded?: boolean;
    actionType?: ActionType;
    rollbackPossible?: boolean;
    currentResourceDetails?: ResourceDetails;
    recommendedResourceDetails?: ResourceDetails;
    tags?: Tag[];
}
export declare const GetRecommendationResponse: S.Schema<GetRecommendationResponse>;
export type GranularityType = "Daily" | "Monthly" | (string & {});
export declare const GranularityType: any;
export interface TimePeriod {
    start: string;
    end: string;
}
export declare const TimePeriod: S.Schema<TimePeriod>;
export type MaxResults = number;
export type Order = "Asc" | "Desc" | (string & {});
export declare const Order: any;
export interface OrderBy {
    dimension?: string;
    order?: Order;
}
export declare const OrderBy: S.Schema<OrderBy>;
export interface ListEfficiencyMetricsRequest {
    groupBy?: string;
    granularity: GranularityType;
    timePeriod: TimePeriod;
    maxResults?: number;
    orderBy?: OrderBy;
    nextToken?: string;
}
export declare const ListEfficiencyMetricsRequest: S.Schema<ListEfficiencyMetricsRequest>;
export interface MetricsByTime {
    score?: number;
    savings?: number;
    spend?: number;
    timestamp?: string;
}
export declare const MetricsByTime: S.Schema<MetricsByTime>;
export type MetricsByTimeList = MetricsByTime[];
export declare const MetricsByTimeList: any;
export interface EfficiencyMetricsByGroup {
    metricsByTime?: MetricsByTime[];
    group?: string;
    message?: string;
}
export declare const EfficiencyMetricsByGroup: S.Schema<EfficiencyMetricsByGroup>;
export type EfficiencyMetricsByGroupList = EfficiencyMetricsByGroup[];
export declare const EfficiencyMetricsByGroupList: any;
export interface ListEfficiencyMetricsResponse {
    efficiencyMetricsByGroup?: EfficiencyMetricsByGroup[];
    nextToken?: string;
}
export declare const ListEfficiencyMetricsResponse: S.Schema<ListEfficiencyMetricsResponse>;
export type AccountId = string;
export interface ListEnrollmentStatusesRequest {
    includeOrganizationInfo?: boolean;
    accountId?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEnrollmentStatusesRequest: S.Schema<ListEnrollmentStatusesRequest>;
export type EnrollmentStatus = "Active" | "Inactive" | (string & {});
export declare const EnrollmentStatus: any;
export interface AccountEnrollmentStatus {
    accountId?: string;
    status?: EnrollmentStatus;
    lastUpdatedTimestamp?: Date;
    createdTimestamp?: Date;
}
export declare const AccountEnrollmentStatus: S.Schema<AccountEnrollmentStatus>;
export type AccountEnrollmentStatuses = AccountEnrollmentStatus[];
export declare const AccountEnrollmentStatuses: any;
export interface ListEnrollmentStatusesResponse {
    items?: AccountEnrollmentStatus[];
    includeMemberAccounts?: boolean;
    nextToken?: string;
}
export declare const ListEnrollmentStatusesResponse: S.Schema<ListEnrollmentStatusesResponse>;
export type ImplementationEffortList = ImplementationEffort[];
export declare const ImplementationEffortList: any;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export type RegionList = string[];
export declare const RegionList: any;
export type ResourceTypeList = ResourceType[];
export declare const ResourceTypeList: any;
export type ActionTypeList = ActionType[];
export declare const ActionTypeList: any;
export type ResourceIdList = string[];
export declare const ResourceIdList: any;
export type ResourceArnList = string[];
export declare const ResourceArnList: any;
export type RecommendationIdList = string[];
export declare const RecommendationIdList: any;
export interface Filter {
    restartNeeded?: boolean;
    rollbackPossible?: boolean;
    implementationEfforts?: ImplementationEffort[];
    accountIds?: string[];
    regions?: string[];
    resourceTypes?: ResourceType[];
    actionTypes?: ActionType[];
    tags?: Tag[];
    resourceIds?: string[];
    resourceArns?: string[];
    recommendationIds?: string[];
}
export declare const Filter: S.Schema<Filter>;
export interface ListRecommendationsRequest {
    filter?: Filter;
    orderBy?: OrderBy;
    includeAllRecommendations?: boolean;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecommendationsRequest: S.Schema<ListRecommendationsRequest>;
export interface Recommendation {
    recommendationId?: string;
    accountId?: string;
    region?: string;
    resourceId?: string;
    resourceArn?: string;
    currentResourceType?: string;
    recommendedResourceType?: string;
    estimatedMonthlySavings?: number;
    estimatedSavingsPercentage?: number;
    estimatedMonthlyCost?: number;
    currencyCode?: string;
    implementationEffort?: string;
    restartNeeded?: boolean;
    actionType?: string;
    rollbackPossible?: boolean;
    currentResourceSummary?: string;
    recommendedResourceSummary?: string;
    lastRefreshTimestamp?: Date;
    recommendationLookbackPeriodInDays?: number;
    source?: Source;
    tags?: Tag[];
}
export declare const Recommendation: S.Schema<Recommendation>;
export type RecommendationList = Recommendation[];
export declare const RecommendationList: any;
export interface ListRecommendationsResponse {
    items?: Recommendation[];
    nextToken?: string;
}
export declare const ListRecommendationsResponse: S.Schema<ListRecommendationsResponse>;
export type SummaryMetrics = "SavingsPercentage" | (string & {});
export declare const SummaryMetrics: any;
export type SummaryMetricsList = SummaryMetrics[];
export declare const SummaryMetricsList: any;
export interface ListRecommendationSummariesRequest {
    filter?: Filter;
    groupBy: string;
    maxResults?: number;
    metrics?: SummaryMetrics[];
    nextToken?: string;
}
export declare const ListRecommendationSummariesRequest: S.Schema<ListRecommendationSummariesRequest>;
export interface RecommendationSummary {
    group?: string;
    estimatedMonthlySavings?: number;
    recommendationCount?: number;
}
export declare const RecommendationSummary: S.Schema<RecommendationSummary>;
export type RecommendationSummariesList = RecommendationSummary[];
export declare const RecommendationSummariesList: any;
export interface SummaryMetricsResult {
    savingsPercentage?: string;
}
export declare const SummaryMetricsResult: S.Schema<SummaryMetricsResult>;
export interface ListRecommendationSummariesResponse {
    estimatedTotalDedupedSavings?: number;
    items?: RecommendationSummary[];
    groupBy?: string;
    currencyCode?: string;
    metrics?: SummaryMetricsResult;
    nextToken?: string;
}
export declare const ListRecommendationSummariesResponse: S.Schema<ListRecommendationSummariesResponse>;
export interface UpdateEnrollmentStatusRequest {
    status: EnrollmentStatus;
    includeMemberAccounts?: boolean;
}
export declare const UpdateEnrollmentStatusRequest: S.Schema<UpdateEnrollmentStatusRequest>;
export interface UpdateEnrollmentStatusResponse {
    status?: string;
}
export declare const UpdateEnrollmentStatusResponse: S.Schema<UpdateEnrollmentStatusResponse>;
export interface UpdatePreferencesRequest {
    savingsEstimationMode?: SavingsEstimationMode;
    memberAccountDiscountVisibility?: MemberAccountDiscountVisibility;
    preferredCommitment?: PreferredCommitment;
}
export declare const UpdatePreferencesRequest: S.Schema<UpdatePreferencesRequest>;
export interface UpdatePreferencesResponse {
    savingsEstimationMode?: SavingsEstimationMode;
    memberAccountDiscountVisibility?: MemberAccountDiscountVisibility;
    preferredCommitment?: PreferredCommitment;
}
export declare const UpdatePreferencesResponse: S.Schema<UpdatePreferencesResponse>;
export type ValidationExceptionReason = "FieldValidationFailed" | "Other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionDetail {
    fieldName: string;
    message: string;
}
export declare const ValidationExceptionDetail: S.Schema<ValidationExceptionDetail>;
export type ValidationExceptionDetails = ValidationExceptionDetail[];
export declare const ValidationExceptionDetails: any;
export type GetPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a set of preferences for an account in order to add account-specific preferences into the service. These preferences impact how the savings associated with recommendations are presented—estimated savings after discounts or estimated savings before discounts, for example.
 */
export declare const getPreferences: API.OperationMethod<GetPreferencesRequest, GetPreferencesResponse, GetPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns both the current and recommended resource configuration and the estimated cost impact for a recommendation.
 *
 * The `recommendationId` is only valid for up to a maximum of 24 hours as recommendations are refreshed daily. To retrieve the `recommendationId`, use the `ListRecommendations` API.
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type ListEfficiencyMetricsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns cost efficiency metrics aggregated over time and optionally grouped by a specified dimension. The metrics provide insights into your cost optimization progress by tracking estimated savings, spending, and measures how effectively you're optimizing your Cloud resources.
 *
 * The operation supports both daily and monthly time granularities and allows grouping results by account ID, Amazon Web Services Region. Results are returned as time-series data, enabling you to analyze trends in your cost optimization performance over the specified time period.
 */
export declare const listEfficiencyMetrics: API.PaginatedOperationMethod<ListEfficiencyMetricsRequest, ListEfficiencyMetricsResponse, ListEfficiencyMetricsError, Credentials | HttpClient.HttpClient, EfficiencyMetricsByGroup>;
export type ListEnrollmentStatusesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the enrollment status for an account. It can also return the list of accounts that are enrolled under the organization.
 */
export declare const listEnrollmentStatuses: API.PaginatedOperationMethod<ListEnrollmentStatusesRequest, ListEnrollmentStatusesResponse, ListEnrollmentStatusesError, Credentials | HttpClient.HttpClient, AccountEnrollmentStatus>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of recommendations.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, Recommendation>;
export type ListRecommendationSummariesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a concise representation of savings estimates for resources. Also returns de-duped savings across different types of recommendations.
 *
 * The following filters are not supported for this API: `recommendationIds`, `resourceArns`, and `resourceIds`.
 */
export declare const listRecommendationSummaries: API.PaginatedOperationMethod<ListRecommendationSummariesRequest, ListRecommendationSummariesResponse, ListRecommendationSummariesError, Credentials | HttpClient.HttpClient, RecommendationSummary>;
export type UpdateEnrollmentStatusError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the enrollment (opt in and opt out) status of an account to the Cost Optimization Hub service.
 *
 * If the account is a management account of an organization, this action can also be used to enroll member accounts of the organization.
 *
 * You must have the appropriate permissions to opt in to Cost Optimization Hub and to view its recommendations. When you opt in, Cost Optimization Hub automatically creates a service-linked role in your account to access its data.
 */
export declare const updateEnrollmentStatus: API.OperationMethod<UpdateEnrollmentStatusRequest, UpdateEnrollmentStatusResponse, UpdateEnrollmentStatusError, Credentials | HttpClient.HttpClient>;
export type UpdatePreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a set of preferences for an account in order to add account-specific preferences into the service. These preferences impact how the savings associated with recommendations are presented.
 */
export declare const updatePreferences: API.OperationMethod<UpdatePreferencesRequest, UpdatePreferencesResponse, UpdatePreferencesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cost-optimization-hub.d.ts.map