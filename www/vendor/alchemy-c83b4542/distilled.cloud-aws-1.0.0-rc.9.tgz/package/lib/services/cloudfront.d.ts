import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDenied_base: S.Class<AccessDenied, S.TaggedStruct<"AccessDenied", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDenied extends /*@__PURE__*/ AccessDenied_base {
}
declare const BatchTooLarge_base: S.Class<BatchTooLarge, S.TaggedStruct<"BatchTooLarge", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BatchTooLarge extends /*@__PURE__*/ BatchTooLarge_base {
}
declare const CachePolicyAlreadyExists_base: S.Class<CachePolicyAlreadyExists, S.TaggedStruct<"CachePolicyAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CachePolicyAlreadyExists extends /*@__PURE__*/ CachePolicyAlreadyExists_base {
}
declare const CachePolicyInUse_base: S.Class<CachePolicyInUse, S.TaggedStruct<"CachePolicyInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CachePolicyInUse extends /*@__PURE__*/ CachePolicyInUse_base {
}
declare const CannotChangeImmutablePublicKeyFields_base: S.Class<CannotChangeImmutablePublicKeyFields, S.TaggedStruct<"CannotChangeImmutablePublicKeyFields", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CannotChangeImmutablePublicKeyFields extends /*@__PURE__*/ CannotChangeImmutablePublicKeyFields_base {
}
declare const CannotDeleteEntityWhileInUse_base: S.Class<CannotDeleteEntityWhileInUse, S.TaggedStruct<"CannotDeleteEntityWhileInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CannotDeleteEntityWhileInUse extends /*@__PURE__*/ CannotDeleteEntityWhileInUse_base {
}
declare const CannotUpdateEntityWhileInUse_base: S.Class<CannotUpdateEntityWhileInUse, S.TaggedStruct<"CannotUpdateEntityWhileInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CannotUpdateEntityWhileInUse extends /*@__PURE__*/ CannotUpdateEntityWhileInUse_base {
}
declare const CloudFrontOriginAccessIdentityAlreadyExists_base: S.Class<CloudFrontOriginAccessIdentityAlreadyExists, S.TaggedStruct<"CloudFrontOriginAccessIdentityAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CloudFrontOriginAccessIdentityAlreadyExists extends /*@__PURE__*/ CloudFrontOriginAccessIdentityAlreadyExists_base {
}
declare const CloudFrontOriginAccessIdentityInUse_base: S.Class<CloudFrontOriginAccessIdentityInUse, S.TaggedStruct<"CloudFrontOriginAccessIdentityInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CloudFrontOriginAccessIdentityInUse extends /*@__PURE__*/ CloudFrontOriginAccessIdentityInUse_base {
}
declare const CNAMEAlreadyExists_base: S.Class<CNAMEAlreadyExists, S.TaggedStruct<"CNAMEAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CNAMEAlreadyExists extends /*@__PURE__*/ CNAMEAlreadyExists_base {
}
declare const ContinuousDeploymentPolicyAlreadyExists_base: S.Class<ContinuousDeploymentPolicyAlreadyExists, S.TaggedStruct<"ContinuousDeploymentPolicyAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ContinuousDeploymentPolicyAlreadyExists extends /*@__PURE__*/ ContinuousDeploymentPolicyAlreadyExists_base {
}
declare const ContinuousDeploymentPolicyInUse_base: S.Class<ContinuousDeploymentPolicyInUse, S.TaggedStruct<"ContinuousDeploymentPolicyInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ContinuousDeploymentPolicyInUse extends /*@__PURE__*/ ContinuousDeploymentPolicyInUse_base {
}
declare const DistributionAlreadyExists_base: S.Class<DistributionAlreadyExists, S.TaggedStruct<"DistributionAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DistributionAlreadyExists extends /*@__PURE__*/ DistributionAlreadyExists_base {
}
declare const DistributionNotDisabled_base: S.Class<DistributionNotDisabled, S.TaggedStruct<"DistributionNotDisabled", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DistributionNotDisabled extends /*@__PURE__*/ DistributionNotDisabled_base {
}
declare const EntityAlreadyExists_base: S.Class<EntityAlreadyExists, S.TaggedStruct<"EntityAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EntityAlreadyExists extends /*@__PURE__*/ EntityAlreadyExists_base {
}
declare const EntityLimitExceeded_base: S.Class<EntityLimitExceeded, S.TaggedStruct<"EntityLimitExceeded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class EntityLimitExceeded extends /*@__PURE__*/ EntityLimitExceeded_base {
}
declare const EntityNotFound_base: S.Class<EntityNotFound, S.TaggedStruct<"EntityNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EntityNotFound extends /*@__PURE__*/ EntityNotFound_base {
}
declare const EntitySizeLimitExceeded_base: S.Class<EntitySizeLimitExceeded, S.TaggedStruct<"EntitySizeLimitExceeded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class EntitySizeLimitExceeded extends /*@__PURE__*/ EntitySizeLimitExceeded_base {
}
declare const FieldLevelEncryptionConfigAlreadyExists_base: S.Class<FieldLevelEncryptionConfigAlreadyExists, S.TaggedStruct<"FieldLevelEncryptionConfigAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FieldLevelEncryptionConfigAlreadyExists extends /*@__PURE__*/ FieldLevelEncryptionConfigAlreadyExists_base {
}
declare const FieldLevelEncryptionConfigInUse_base: S.Class<FieldLevelEncryptionConfigInUse, S.TaggedStruct<"FieldLevelEncryptionConfigInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class FieldLevelEncryptionConfigInUse extends /*@__PURE__*/ FieldLevelEncryptionConfigInUse_base {
}
declare const FieldLevelEncryptionProfileAlreadyExists_base: S.Class<FieldLevelEncryptionProfileAlreadyExists, S.TaggedStruct<"FieldLevelEncryptionProfileAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FieldLevelEncryptionProfileAlreadyExists extends /*@__PURE__*/ FieldLevelEncryptionProfileAlreadyExists_base {
}
declare const FieldLevelEncryptionProfileInUse_base: S.Class<FieldLevelEncryptionProfileInUse, S.TaggedStruct<"FieldLevelEncryptionProfileInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class FieldLevelEncryptionProfileInUse extends /*@__PURE__*/ FieldLevelEncryptionProfileInUse_base {
}
declare const FieldLevelEncryptionProfileSizeExceeded_base: S.Class<FieldLevelEncryptionProfileSizeExceeded, S.TaggedStruct<"FieldLevelEncryptionProfileSizeExceeded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FieldLevelEncryptionProfileSizeExceeded extends /*@__PURE__*/ FieldLevelEncryptionProfileSizeExceeded_base {
}
declare const FunctionAlreadyExists_base: S.Class<FunctionAlreadyExists, S.TaggedStruct<"FunctionAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FunctionAlreadyExists extends /*@__PURE__*/ FunctionAlreadyExists_base {
}
declare const FunctionInUse_base: S.Class<FunctionInUse, S.TaggedStruct<"FunctionInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class FunctionInUse extends /*@__PURE__*/ FunctionInUse_base {
}
declare const FunctionSizeLimitExceeded_base: S.Class<FunctionSizeLimitExceeded, S.TaggedStruct<"FunctionSizeLimitExceeded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class FunctionSizeLimitExceeded extends /*@__PURE__*/ FunctionSizeLimitExceeded_base {
}
declare const IllegalDelete_base: S.Class<IllegalDelete, S.TaggedStruct<"IllegalDelete", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalDelete extends /*@__PURE__*/ IllegalDelete_base {
}
declare const IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior_base: S.Class<IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior, S.TaggedStruct<"IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior extends /*@__PURE__*/ IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior_base {
}
declare const IllegalOriginAccessConfiguration_base: S.Class<IllegalOriginAccessConfiguration, S.TaggedStruct<"IllegalOriginAccessConfiguration", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalOriginAccessConfiguration extends /*@__PURE__*/ IllegalOriginAccessConfiguration_base {
}
declare const IllegalUpdate_base: S.Class<IllegalUpdate, S.TaggedStruct<"IllegalUpdate", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalUpdate extends /*@__PURE__*/ IllegalUpdate_base {
}
declare const InconsistentQuantities_base: S.Class<InconsistentQuantities, S.TaggedStruct<"InconsistentQuantities", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InconsistentQuantities extends /*@__PURE__*/ InconsistentQuantities_base {
}
declare const InvalidArgument_base: S.Class<InvalidArgument, S.TaggedStruct<"InvalidArgument", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArgument extends /*@__PURE__*/ InvalidArgument_base {
}
declare const InvalidAssociation_base: S.Class<InvalidAssociation, S.TaggedStruct<"InvalidAssociation", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidAssociation extends /*@__PURE__*/ InvalidAssociation_base {
}
declare const InvalidDefaultRootObject_base: S.Class<InvalidDefaultRootObject, S.TaggedStruct<"InvalidDefaultRootObject", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDefaultRootObject extends /*@__PURE__*/ InvalidDefaultRootObject_base {
}
declare const InvalidDomainNameForOriginAccessControl_base: S.Class<InvalidDomainNameForOriginAccessControl, S.TaggedStruct<"InvalidDomainNameForOriginAccessControl", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDomainNameForOriginAccessControl extends /*@__PURE__*/ InvalidDomainNameForOriginAccessControl_base {
}
declare const InvalidErrorCode_base: S.Class<InvalidErrorCode, S.TaggedStruct<"InvalidErrorCode", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidErrorCode extends /*@__PURE__*/ InvalidErrorCode_base {
}
declare const InvalidForwardCookies_base: S.Class<InvalidForwardCookies, S.TaggedStruct<"InvalidForwardCookies", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidForwardCookies extends /*@__PURE__*/ InvalidForwardCookies_base {
}
declare const InvalidFunctionAssociation_base: S.Class<InvalidFunctionAssociation, S.TaggedStruct<"InvalidFunctionAssociation", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFunctionAssociation extends /*@__PURE__*/ InvalidFunctionAssociation_base {
}
declare const InvalidGeoRestrictionParameter_base: S.Class<InvalidGeoRestrictionParameter, S.TaggedStruct<"InvalidGeoRestrictionParameter", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGeoRestrictionParameter extends /*@__PURE__*/ InvalidGeoRestrictionParameter_base {
}
declare const InvalidHeadersForS3Origin_base: S.Class<InvalidHeadersForS3Origin, S.TaggedStruct<"InvalidHeadersForS3Origin", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidHeadersForS3Origin extends /*@__PURE__*/ InvalidHeadersForS3Origin_base {
}
declare const InvalidIfMatchVersion_base: S.Class<InvalidIfMatchVersion, S.TaggedStruct<"InvalidIfMatchVersion", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidIfMatchVersion extends /*@__PURE__*/ InvalidIfMatchVersion_base {
}
declare const InvalidLambdaFunctionAssociation_base: S.Class<InvalidLambdaFunctionAssociation, S.TaggedStruct<"InvalidLambdaFunctionAssociation", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLambdaFunctionAssociation extends /*@__PURE__*/ InvalidLambdaFunctionAssociation_base {
}
declare const InvalidLocationCode_base: S.Class<InvalidLocationCode, S.TaggedStruct<"InvalidLocationCode", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLocationCode extends /*@__PURE__*/ InvalidLocationCode_base {
}
declare const InvalidMinimumProtocolVersion_base: S.Class<InvalidMinimumProtocolVersion, S.TaggedStruct<"InvalidMinimumProtocolVersion", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidMinimumProtocolVersion extends /*@__PURE__*/ InvalidMinimumProtocolVersion_base {
}
declare const InvalidOrigin_base: S.Class<InvalidOrigin, S.TaggedStruct<"InvalidOrigin", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOrigin extends /*@__PURE__*/ InvalidOrigin_base {
}
declare const InvalidOriginAccessControl_base: S.Class<InvalidOriginAccessControl, S.TaggedStruct<"InvalidOriginAccessControl", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginAccessControl extends /*@__PURE__*/ InvalidOriginAccessControl_base {
}
declare const InvalidOriginAccessIdentity_base: S.Class<InvalidOriginAccessIdentity, S.TaggedStruct<"InvalidOriginAccessIdentity", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginAccessIdentity extends /*@__PURE__*/ InvalidOriginAccessIdentity_base {
}
declare const InvalidOriginKeepaliveTimeout_base: S.Class<InvalidOriginKeepaliveTimeout, S.TaggedStruct<"InvalidOriginKeepaliveTimeout", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginKeepaliveTimeout extends /*@__PURE__*/ InvalidOriginKeepaliveTimeout_base {
}
declare const InvalidOriginReadTimeout_base: S.Class<InvalidOriginReadTimeout, S.TaggedStruct<"InvalidOriginReadTimeout", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOriginReadTimeout extends /*@__PURE__*/ InvalidOriginReadTimeout_base {
}
declare const InvalidProtocolSettings_base: S.Class<InvalidProtocolSettings, S.TaggedStruct<"InvalidProtocolSettings", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidProtocolSettings extends /*@__PURE__*/ InvalidProtocolSettings_base {
}
declare const InvalidQueryStringParameters_base: S.Class<InvalidQueryStringParameters, S.TaggedStruct<"InvalidQueryStringParameters", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidQueryStringParameters extends /*@__PURE__*/ InvalidQueryStringParameters_base {
}
declare const InvalidRelativePath_base: S.Class<InvalidRelativePath, S.TaggedStruct<"InvalidRelativePath", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRelativePath extends /*@__PURE__*/ InvalidRelativePath_base {
}
declare const InvalidRequiredProtocol_base: S.Class<InvalidRequiredProtocol, S.TaggedStruct<"InvalidRequiredProtocol", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequiredProtocol extends /*@__PURE__*/ InvalidRequiredProtocol_base {
}
declare const InvalidResponseCode_base: S.Class<InvalidResponseCode, S.TaggedStruct<"InvalidResponseCode", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidResponseCode extends /*@__PURE__*/ InvalidResponseCode_base {
}
declare const InvalidTagging_base: S.Class<InvalidTagging, S.TaggedStruct<"InvalidTagging", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTagging extends /*@__PURE__*/ InvalidTagging_base {
}
declare const InvalidTTLOrder_base: S.Class<InvalidTTLOrder, S.TaggedStruct<"InvalidTTLOrder", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTTLOrder extends /*@__PURE__*/ InvalidTTLOrder_base {
}
declare const InvalidViewerCertificate_base: S.Class<InvalidViewerCertificate, S.TaggedStruct<"InvalidViewerCertificate", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidViewerCertificate extends /*@__PURE__*/ InvalidViewerCertificate_base {
}
declare const InvalidWebACLId_base: S.Class<InvalidWebACLId, S.TaggedStruct<"InvalidWebACLId", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidWebACLId extends /*@__PURE__*/ InvalidWebACLId_base {
}
declare const KeyGroupAlreadyExists_base: S.Class<KeyGroupAlreadyExists, S.TaggedStruct<"KeyGroupAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class KeyGroupAlreadyExists extends /*@__PURE__*/ KeyGroupAlreadyExists_base {
}
declare const MissingBody_base: S.Class<MissingBody, S.TaggedStruct<"MissingBody", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MissingBody extends /*@__PURE__*/ MissingBody_base {
}
declare const MonitoringSubscriptionAlreadyExists_base: S.Class<MonitoringSubscriptionAlreadyExists, S.TaggedStruct<"MonitoringSubscriptionAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class MonitoringSubscriptionAlreadyExists extends /*@__PURE__*/ MonitoringSubscriptionAlreadyExists_base {
}
declare const NoSuchCachePolicy_base: S.Class<NoSuchCachePolicy, S.TaggedStruct<"NoSuchCachePolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchCachePolicy extends /*@__PURE__*/ NoSuchCachePolicy_base {
}
declare const NoSuchCloudFrontOriginAccessIdentity_base: S.Class<NoSuchCloudFrontOriginAccessIdentity, S.TaggedStruct<"NoSuchCloudFrontOriginAccessIdentity", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchCloudFrontOriginAccessIdentity extends /*@__PURE__*/ NoSuchCloudFrontOriginAccessIdentity_base {
}
declare const NoSuchContinuousDeploymentPolicy_base: S.Class<NoSuchContinuousDeploymentPolicy, S.TaggedStruct<"NoSuchContinuousDeploymentPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchContinuousDeploymentPolicy extends /*@__PURE__*/ NoSuchContinuousDeploymentPolicy_base {
}
declare const NoSuchDistribution_base: S.Class<NoSuchDistribution, S.TaggedStruct<"NoSuchDistribution", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchDistribution extends /*@__PURE__*/ NoSuchDistribution_base {
}
declare const NoSuchFieldLevelEncryptionConfig_base: S.Class<NoSuchFieldLevelEncryptionConfig, S.TaggedStruct<"NoSuchFieldLevelEncryptionConfig", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchFieldLevelEncryptionConfig extends /*@__PURE__*/ NoSuchFieldLevelEncryptionConfig_base {
}
declare const NoSuchFieldLevelEncryptionProfile_base: S.Class<NoSuchFieldLevelEncryptionProfile, S.TaggedStruct<"NoSuchFieldLevelEncryptionProfile", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchFieldLevelEncryptionProfile extends /*@__PURE__*/ NoSuchFieldLevelEncryptionProfile_base {
}
declare const NoSuchFunctionExists_base: S.Class<NoSuchFunctionExists, S.TaggedStruct<"NoSuchFunctionExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchFunctionExists extends /*@__PURE__*/ NoSuchFunctionExists_base {
}
declare const NoSuchInvalidation_base: S.Class<NoSuchInvalidation, S.TaggedStruct<"NoSuchInvalidation", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchInvalidation extends /*@__PURE__*/ NoSuchInvalidation_base {
}
declare const NoSuchMonitoringSubscription_base: S.Class<NoSuchMonitoringSubscription, S.TaggedStruct<"NoSuchMonitoringSubscription", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchMonitoringSubscription extends /*@__PURE__*/ NoSuchMonitoringSubscription_base {
}
declare const NoSuchOrigin_base: S.Class<NoSuchOrigin, S.TaggedStruct<"NoSuchOrigin", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchOrigin extends /*@__PURE__*/ NoSuchOrigin_base {
}
declare const NoSuchOriginAccessControl_base: S.Class<NoSuchOriginAccessControl, S.TaggedStruct<"NoSuchOriginAccessControl", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchOriginAccessControl extends /*@__PURE__*/ NoSuchOriginAccessControl_base {
}
declare const NoSuchOriginRequestPolicy_base: S.Class<NoSuchOriginRequestPolicy, S.TaggedStruct<"NoSuchOriginRequestPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchOriginRequestPolicy extends /*@__PURE__*/ NoSuchOriginRequestPolicy_base {
}
declare const NoSuchPublicKey_base: S.Class<NoSuchPublicKey, S.TaggedStruct<"NoSuchPublicKey", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchPublicKey extends /*@__PURE__*/ NoSuchPublicKey_base {
}
declare const NoSuchRealtimeLogConfig_base: S.Class<NoSuchRealtimeLogConfig, S.TaggedStruct<"NoSuchRealtimeLogConfig", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchRealtimeLogConfig extends /*@__PURE__*/ NoSuchRealtimeLogConfig_base {
}
declare const NoSuchResource_base: S.Class<NoSuchResource, S.TaggedStruct<"NoSuchResource", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchResource extends /*@__PURE__*/ NoSuchResource_base {
}
declare const NoSuchResponseHeadersPolicy_base: S.Class<NoSuchResponseHeadersPolicy, S.TaggedStruct<"NoSuchResponseHeadersPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchResponseHeadersPolicy extends /*@__PURE__*/ NoSuchResponseHeadersPolicy_base {
}
declare const NoSuchStreamingDistribution_base: S.Class<NoSuchStreamingDistribution, S.TaggedStruct<"NoSuchStreamingDistribution", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoSuchStreamingDistribution extends /*@__PURE__*/ NoSuchStreamingDistribution_base {
}
declare const OriginAccessControlAlreadyExists_base: S.Class<OriginAccessControlAlreadyExists, S.TaggedStruct<"OriginAccessControlAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OriginAccessControlAlreadyExists extends /*@__PURE__*/ OriginAccessControlAlreadyExists_base {
}
declare const OriginAccessControlInUse_base: S.Class<OriginAccessControlInUse, S.TaggedStruct<"OriginAccessControlInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class OriginAccessControlInUse extends /*@__PURE__*/ OriginAccessControlInUse_base {
}
declare const OriginRequestPolicyAlreadyExists_base: S.Class<OriginRequestPolicyAlreadyExists, S.TaggedStruct<"OriginRequestPolicyAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OriginRequestPolicyAlreadyExists extends /*@__PURE__*/ OriginRequestPolicyAlreadyExists_base {
}
declare const OriginRequestPolicyInUse_base: S.Class<OriginRequestPolicyInUse, S.TaggedStruct<"OriginRequestPolicyInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class OriginRequestPolicyInUse extends /*@__PURE__*/ OriginRequestPolicyInUse_base {
}
declare const PreconditionFailed_base: S.Class<PreconditionFailed, S.TaggedStruct<"PreconditionFailed", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PreconditionFailed extends /*@__PURE__*/ PreconditionFailed_base {
}
declare const PublicKeyAlreadyExists_base: S.Class<PublicKeyAlreadyExists, S.TaggedStruct<"PublicKeyAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class PublicKeyAlreadyExists extends /*@__PURE__*/ PublicKeyAlreadyExists_base {
}
declare const PublicKeyInUse_base: S.Class<PublicKeyInUse, S.TaggedStruct<"PublicKeyInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class PublicKeyInUse extends /*@__PURE__*/ PublicKeyInUse_base {
}
declare const QueryArgProfileEmpty_base: S.Class<QueryArgProfileEmpty, S.TaggedStruct<"QueryArgProfileEmpty", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryArgProfileEmpty extends /*@__PURE__*/ QueryArgProfileEmpty_base {
}
declare const RealtimeLogConfigAlreadyExists_base: S.Class<RealtimeLogConfigAlreadyExists, S.TaggedStruct<"RealtimeLogConfigAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class RealtimeLogConfigAlreadyExists extends /*@__PURE__*/ RealtimeLogConfigAlreadyExists_base {
}
declare const RealtimeLogConfigInUse_base: S.Class<RealtimeLogConfigInUse, S.TaggedStruct<"RealtimeLogConfigInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class RealtimeLogConfigInUse extends /*@__PURE__*/ RealtimeLogConfigInUse_base {
}
declare const RealtimeLogConfigOwnerMismatch_base: S.Class<RealtimeLogConfigOwnerMismatch, S.TaggedStruct<"RealtimeLogConfigOwnerMismatch", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class RealtimeLogConfigOwnerMismatch extends /*@__PURE__*/ RealtimeLogConfigOwnerMismatch_base {
}
declare const ResourceInUse_base: S.Class<ResourceInUse, S.TaggedStruct<"ResourceInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ResourceInUse extends /*@__PURE__*/ ResourceInUse_base {
}
declare const ResourceNotDisabled_base: S.Class<ResourceNotDisabled, S.TaggedStruct<"ResourceNotDisabled", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotDisabled extends /*@__PURE__*/ ResourceNotDisabled_base {
}
declare const ResponseHeadersPolicyAlreadyExists_base: S.Class<ResponseHeadersPolicyAlreadyExists, S.TaggedStruct<"ResponseHeadersPolicyAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResponseHeadersPolicyAlreadyExists extends /*@__PURE__*/ ResponseHeadersPolicyAlreadyExists_base {
}
declare const ResponseHeadersPolicyInUse_base: S.Class<ResponseHeadersPolicyInUse, S.TaggedStruct<"ResponseHeadersPolicyInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ResponseHeadersPolicyInUse extends /*@__PURE__*/ ResponseHeadersPolicyInUse_base {
}
declare const StagingDistributionInUse_base: S.Class<StagingDistributionInUse, S.TaggedStruct<"StagingDistributionInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class StagingDistributionInUse extends /*@__PURE__*/ StagingDistributionInUse_base {
}
declare const StreamingDistributionAlreadyExists_base: S.Class<StreamingDistributionAlreadyExists, S.TaggedStruct<"StreamingDistributionAlreadyExists", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class StreamingDistributionAlreadyExists extends /*@__PURE__*/ StreamingDistributionAlreadyExists_base {
}
declare const StreamingDistributionNotDisabled_base: S.Class<StreamingDistributionNotDisabled, S.TaggedStruct<"StreamingDistributionNotDisabled", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class StreamingDistributionNotDisabled extends /*@__PURE__*/ StreamingDistributionNotDisabled_base {
}
declare const TestFunctionFailed_base: S.Class<TestFunctionFailed, S.TaggedStruct<"TestFunctionFailed", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class TestFunctionFailed extends /*@__PURE__*/ TestFunctionFailed_base {
}
declare const TooLongCSPInResponseHeadersPolicy_base: S.Class<TooLongCSPInResponseHeadersPolicy, S.TaggedStruct<"TooLongCSPInResponseHeadersPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooLongCSPInResponseHeadersPolicy extends /*@__PURE__*/ TooLongCSPInResponseHeadersPolicy_base {
}
declare const TooManyCacheBehaviors_base: S.Class<TooManyCacheBehaviors, S.TaggedStruct<"TooManyCacheBehaviors", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCacheBehaviors extends /*@__PURE__*/ TooManyCacheBehaviors_base {
}
declare const TooManyCachePolicies_base: S.Class<TooManyCachePolicies, S.TaggedStruct<"TooManyCachePolicies", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCachePolicies extends /*@__PURE__*/ TooManyCachePolicies_base {
}
declare const TooManyCertificates_base: S.Class<TooManyCertificates, S.TaggedStruct<"TooManyCertificates", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCertificates extends /*@__PURE__*/ TooManyCertificates_base {
}
declare const TooManyCloudFrontOriginAccessIdentities_base: S.Class<TooManyCloudFrontOriginAccessIdentities, S.TaggedStruct<"TooManyCloudFrontOriginAccessIdentities", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCloudFrontOriginAccessIdentities extends /*@__PURE__*/ TooManyCloudFrontOriginAccessIdentities_base {
}
declare const TooManyContinuousDeploymentPolicies_base: S.Class<TooManyContinuousDeploymentPolicies, S.TaggedStruct<"TooManyContinuousDeploymentPolicies", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyContinuousDeploymentPolicies extends /*@__PURE__*/ TooManyContinuousDeploymentPolicies_base {
}
declare const TooManyCookieNamesInWhiteList_base: S.Class<TooManyCookieNamesInWhiteList, S.TaggedStruct<"TooManyCookieNamesInWhiteList", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCookieNamesInWhiteList extends /*@__PURE__*/ TooManyCookieNamesInWhiteList_base {
}
declare const TooManyCookiesInCachePolicy_base: S.Class<TooManyCookiesInCachePolicy, S.TaggedStruct<"TooManyCookiesInCachePolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCookiesInCachePolicy extends /*@__PURE__*/ TooManyCookiesInCachePolicy_base {
}
declare const TooManyCookiesInOriginRequestPolicy_base: S.Class<TooManyCookiesInOriginRequestPolicy, S.TaggedStruct<"TooManyCookiesInOriginRequestPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCookiesInOriginRequestPolicy extends /*@__PURE__*/ TooManyCookiesInOriginRequestPolicy_base {
}
declare const TooManyCustomHeadersInResponseHeadersPolicy_base: S.Class<TooManyCustomHeadersInResponseHeadersPolicy, S.TaggedStruct<"TooManyCustomHeadersInResponseHeadersPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyCustomHeadersInResponseHeadersPolicy extends /*@__PURE__*/ TooManyCustomHeadersInResponseHeadersPolicy_base {
}
declare const TooManyDistributionCNAMEs_base: S.Class<TooManyDistributionCNAMEs, S.TaggedStruct<"TooManyDistributionCNAMEs", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionCNAMEs extends /*@__PURE__*/ TooManyDistributionCNAMEs_base {
}
declare const TooManyDistributions_base: S.Class<TooManyDistributions, S.TaggedStruct<"TooManyDistributions", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributions extends /*@__PURE__*/ TooManyDistributions_base {
}
declare const TooManyDistributionsAssociatedToCachePolicy_base: S.Class<TooManyDistributionsAssociatedToCachePolicy, S.TaggedStruct<"TooManyDistributionsAssociatedToCachePolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToCachePolicy extends /*@__PURE__*/ TooManyDistributionsAssociatedToCachePolicy_base {
}
declare const TooManyDistributionsAssociatedToFieldLevelEncryptionConfig_base: S.Class<TooManyDistributionsAssociatedToFieldLevelEncryptionConfig, S.TaggedStruct<"TooManyDistributionsAssociatedToFieldLevelEncryptionConfig", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToFieldLevelEncryptionConfig extends /*@__PURE__*/ TooManyDistributionsAssociatedToFieldLevelEncryptionConfig_base {
}
declare const TooManyDistributionsAssociatedToKeyGroup_base: S.Class<TooManyDistributionsAssociatedToKeyGroup, S.TaggedStruct<"TooManyDistributionsAssociatedToKeyGroup", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToKeyGroup extends /*@__PURE__*/ TooManyDistributionsAssociatedToKeyGroup_base {
}
declare const TooManyDistributionsAssociatedToOriginAccessControl_base: S.Class<TooManyDistributionsAssociatedToOriginAccessControl, S.TaggedStruct<"TooManyDistributionsAssociatedToOriginAccessControl", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToOriginAccessControl extends /*@__PURE__*/ TooManyDistributionsAssociatedToOriginAccessControl_base {
}
declare const TooManyDistributionsAssociatedToOriginRequestPolicy_base: S.Class<TooManyDistributionsAssociatedToOriginRequestPolicy, S.TaggedStruct<"TooManyDistributionsAssociatedToOriginRequestPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToOriginRequestPolicy extends /*@__PURE__*/ TooManyDistributionsAssociatedToOriginRequestPolicy_base {
}
declare const TooManyDistributionsAssociatedToResponseHeadersPolicy_base: S.Class<TooManyDistributionsAssociatedToResponseHeadersPolicy, S.TaggedStruct<"TooManyDistributionsAssociatedToResponseHeadersPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsAssociatedToResponseHeadersPolicy extends /*@__PURE__*/ TooManyDistributionsAssociatedToResponseHeadersPolicy_base {
}
declare const TooManyDistributionsWithFunctionAssociations_base: S.Class<TooManyDistributionsWithFunctionAssociations, S.TaggedStruct<"TooManyDistributionsWithFunctionAssociations", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsWithFunctionAssociations extends /*@__PURE__*/ TooManyDistributionsWithFunctionAssociations_base {
}
declare const TooManyDistributionsWithLambdaAssociations_base: S.Class<TooManyDistributionsWithLambdaAssociations, S.TaggedStruct<"TooManyDistributionsWithLambdaAssociations", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsWithLambdaAssociations extends /*@__PURE__*/ TooManyDistributionsWithLambdaAssociations_base {
}
declare const TooManyDistributionsWithSingleFunctionARN_base: S.Class<TooManyDistributionsWithSingleFunctionARN, S.TaggedStruct<"TooManyDistributionsWithSingleFunctionARN", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyDistributionsWithSingleFunctionARN extends /*@__PURE__*/ TooManyDistributionsWithSingleFunctionARN_base {
}
declare const TooManyFieldLevelEncryptionConfigs_base: S.Class<TooManyFieldLevelEncryptionConfigs, S.TaggedStruct<"TooManyFieldLevelEncryptionConfigs", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionConfigs extends /*@__PURE__*/ TooManyFieldLevelEncryptionConfigs_base {
}
declare const TooManyFieldLevelEncryptionContentTypeProfiles_base: S.Class<TooManyFieldLevelEncryptionContentTypeProfiles, S.TaggedStruct<"TooManyFieldLevelEncryptionContentTypeProfiles", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionContentTypeProfiles extends /*@__PURE__*/ TooManyFieldLevelEncryptionContentTypeProfiles_base {
}
declare const TooManyFieldLevelEncryptionEncryptionEntities_base: S.Class<TooManyFieldLevelEncryptionEncryptionEntities, S.TaggedStruct<"TooManyFieldLevelEncryptionEncryptionEntities", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionEncryptionEntities extends /*@__PURE__*/ TooManyFieldLevelEncryptionEncryptionEntities_base {
}
declare const TooManyFieldLevelEncryptionFieldPatterns_base: S.Class<TooManyFieldLevelEncryptionFieldPatterns, S.TaggedStruct<"TooManyFieldLevelEncryptionFieldPatterns", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionFieldPatterns extends /*@__PURE__*/ TooManyFieldLevelEncryptionFieldPatterns_base {
}
declare const TooManyFieldLevelEncryptionProfiles_base: S.Class<TooManyFieldLevelEncryptionProfiles, S.TaggedStruct<"TooManyFieldLevelEncryptionProfiles", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionProfiles extends /*@__PURE__*/ TooManyFieldLevelEncryptionProfiles_base {
}
declare const TooManyFieldLevelEncryptionQueryArgProfiles_base: S.Class<TooManyFieldLevelEncryptionQueryArgProfiles, S.TaggedStruct<"TooManyFieldLevelEncryptionQueryArgProfiles", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFieldLevelEncryptionQueryArgProfiles extends /*@__PURE__*/ TooManyFieldLevelEncryptionQueryArgProfiles_base {
}
declare const TooManyFunctionAssociations_base: S.Class<TooManyFunctionAssociations, S.TaggedStruct<"TooManyFunctionAssociations", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFunctionAssociations extends /*@__PURE__*/ TooManyFunctionAssociations_base {
}
declare const TooManyFunctions_base: S.Class<TooManyFunctions, S.TaggedStruct<"TooManyFunctions", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFunctions extends /*@__PURE__*/ TooManyFunctions_base {
}
declare const TooManyHeadersInCachePolicy_base: S.Class<TooManyHeadersInCachePolicy, S.TaggedStruct<"TooManyHeadersInCachePolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyHeadersInCachePolicy extends /*@__PURE__*/ TooManyHeadersInCachePolicy_base {
}
declare const TooManyHeadersInForwardedValues_base: S.Class<TooManyHeadersInForwardedValues, S.TaggedStruct<"TooManyHeadersInForwardedValues", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyHeadersInForwardedValues extends /*@__PURE__*/ TooManyHeadersInForwardedValues_base {
}
declare const TooManyHeadersInOriginRequestPolicy_base: S.Class<TooManyHeadersInOriginRequestPolicy, S.TaggedStruct<"TooManyHeadersInOriginRequestPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyHeadersInOriginRequestPolicy extends /*@__PURE__*/ TooManyHeadersInOriginRequestPolicy_base {
}
declare const TooManyInvalidationsInProgress_base: S.Class<TooManyInvalidationsInProgress, S.TaggedStruct<"TooManyInvalidationsInProgress", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyInvalidationsInProgress extends /*@__PURE__*/ TooManyInvalidationsInProgress_base {
}
declare const TooManyKeyGroups_base: S.Class<TooManyKeyGroups, S.TaggedStruct<"TooManyKeyGroups", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyKeyGroups extends /*@__PURE__*/ TooManyKeyGroups_base {
}
declare const TooManyKeyGroupsAssociatedToDistribution_base: S.Class<TooManyKeyGroupsAssociatedToDistribution, S.TaggedStruct<"TooManyKeyGroupsAssociatedToDistribution", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyKeyGroupsAssociatedToDistribution extends /*@__PURE__*/ TooManyKeyGroupsAssociatedToDistribution_base {
}
declare const TooManyLambdaFunctionAssociations_base: S.Class<TooManyLambdaFunctionAssociations, S.TaggedStruct<"TooManyLambdaFunctionAssociations", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyLambdaFunctionAssociations extends /*@__PURE__*/ TooManyLambdaFunctionAssociations_base {
}
declare const TooManyOriginAccessControls_base: S.Class<TooManyOriginAccessControls, S.TaggedStruct<"TooManyOriginAccessControls", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginAccessControls extends /*@__PURE__*/ TooManyOriginAccessControls_base {
}
declare const TooManyOriginCustomHeaders_base: S.Class<TooManyOriginCustomHeaders, S.TaggedStruct<"TooManyOriginCustomHeaders", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginCustomHeaders extends /*@__PURE__*/ TooManyOriginCustomHeaders_base {
}
declare const TooManyOriginGroupsPerDistribution_base: S.Class<TooManyOriginGroupsPerDistribution, S.TaggedStruct<"TooManyOriginGroupsPerDistribution", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginGroupsPerDistribution extends /*@__PURE__*/ TooManyOriginGroupsPerDistribution_base {
}
declare const TooManyOriginRequestPolicies_base: S.Class<TooManyOriginRequestPolicies, S.TaggedStruct<"TooManyOriginRequestPolicies", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOriginRequestPolicies extends /*@__PURE__*/ TooManyOriginRequestPolicies_base {
}
declare const TooManyOrigins_base: S.Class<TooManyOrigins, S.TaggedStruct<"TooManyOrigins", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyOrigins extends /*@__PURE__*/ TooManyOrigins_base {
}
declare const TooManyPublicKeys_base: S.Class<TooManyPublicKeys, S.TaggedStruct<"TooManyPublicKeys", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPublicKeys extends /*@__PURE__*/ TooManyPublicKeys_base {
}
declare const TooManyPublicKeysInKeyGroup_base: S.Class<TooManyPublicKeysInKeyGroup, S.TaggedStruct<"TooManyPublicKeysInKeyGroup", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPublicKeysInKeyGroup extends /*@__PURE__*/ TooManyPublicKeysInKeyGroup_base {
}
declare const TooManyQueryStringParameters_base: S.Class<TooManyQueryStringParameters, S.TaggedStruct<"TooManyQueryStringParameters", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyQueryStringParameters extends /*@__PURE__*/ TooManyQueryStringParameters_base {
}
declare const TooManyQueryStringsInCachePolicy_base: S.Class<TooManyQueryStringsInCachePolicy, S.TaggedStruct<"TooManyQueryStringsInCachePolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyQueryStringsInCachePolicy extends /*@__PURE__*/ TooManyQueryStringsInCachePolicy_base {
}
declare const TooManyQueryStringsInOriginRequestPolicy_base: S.Class<TooManyQueryStringsInOriginRequestPolicy, S.TaggedStruct<"TooManyQueryStringsInOriginRequestPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyQueryStringsInOriginRequestPolicy extends /*@__PURE__*/ TooManyQueryStringsInOriginRequestPolicy_base {
}
declare const TooManyRealtimeLogConfigs_base: S.Class<TooManyRealtimeLogConfigs, S.TaggedStruct<"TooManyRealtimeLogConfigs", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyRealtimeLogConfigs extends /*@__PURE__*/ TooManyRealtimeLogConfigs_base {
}
declare const TooManyRemoveHeadersInResponseHeadersPolicy_base: S.Class<TooManyRemoveHeadersInResponseHeadersPolicy, S.TaggedStruct<"TooManyRemoveHeadersInResponseHeadersPolicy", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyRemoveHeadersInResponseHeadersPolicy extends /*@__PURE__*/ TooManyRemoveHeadersInResponseHeadersPolicy_base {
}
declare const TooManyResponseHeadersPolicies_base: S.Class<TooManyResponseHeadersPolicies, S.TaggedStruct<"TooManyResponseHeadersPolicies", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyResponseHeadersPolicies extends /*@__PURE__*/ TooManyResponseHeadersPolicies_base {
}
declare const TooManyStreamingDistributionCNAMEs_base: S.Class<TooManyStreamingDistributionCNAMEs, S.TaggedStruct<"TooManyStreamingDistributionCNAMEs", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyStreamingDistributionCNAMEs extends /*@__PURE__*/ TooManyStreamingDistributionCNAMEs_base {
}
declare const TooManyStreamingDistributions_base: S.Class<TooManyStreamingDistributions, S.TaggedStruct<"TooManyStreamingDistributions", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyStreamingDistributions extends /*@__PURE__*/ TooManyStreamingDistributions_base {
}
declare const TooManyTrustedSigners_base: S.Class<TooManyTrustedSigners, S.TaggedStruct<"TooManyTrustedSigners", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTrustedSigners extends /*@__PURE__*/ TooManyTrustedSigners_base {
}
declare const TrustedKeyGroupDoesNotExist_base: S.Class<TrustedKeyGroupDoesNotExist, S.TaggedStruct<"TrustedKeyGroupDoesNotExist", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustedKeyGroupDoesNotExist extends /*@__PURE__*/ TrustedKeyGroupDoesNotExist_base {
}
declare const TrustedSignerDoesNotExist_base: S.Class<TrustedSignerDoesNotExist, S.TaggedStruct<"TrustedSignerDoesNotExist", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrustedSignerDoesNotExist extends /*@__PURE__*/ TrustedSignerDoesNotExist_base {
}
declare const UnsupportedOperation_base: S.Class<UnsupportedOperation, S.TaggedStruct<"UnsupportedOperation", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperation extends /*@__PURE__*/ UnsupportedOperation_base {
}
export interface AssociateAliasRequest {
    TargetDistributionId: string;
    Alias: string;
}
export declare const AssociateAliasRequest: S.Schema<AssociateAliasRequest>;
export interface AssociateAliasResponse {
}
export declare const AssociateAliasResponse: S.Schema<AssociateAliasResponse>;
export interface AssociateDistributionTenantWebACLRequest {
    Id: string;
    WebACLArn: string;
    IfMatch?: string;
}
export declare const AssociateDistributionTenantWebACLRequest: S.Schema<AssociateDistributionTenantWebACLRequest>;
export interface AssociateDistributionTenantWebACLResult {
    Id?: string;
    WebACLArn?: string;
    ETag?: string;
}
export declare const AssociateDistributionTenantWebACLResult: S.Schema<AssociateDistributionTenantWebACLResult>;
export interface AssociateDistributionWebACLRequest {
    Id: string;
    WebACLArn: string;
    IfMatch?: string;
}
export declare const AssociateDistributionWebACLRequest: S.Schema<AssociateDistributionWebACLRequest>;
export interface AssociateDistributionWebACLResult {
    Id?: string;
    WebACLArn?: string;
    ETag?: string;
}
export declare const AssociateDistributionWebACLResult: S.Schema<AssociateDistributionWebACLResult>;
export interface CopyDistributionRequest {
    PrimaryDistributionId: string;
    Staging?: boolean;
    IfMatch?: string;
    CallerReference: string;
    Enabled?: boolean;
}
export declare const CopyDistributionRequest: S.Schema<CopyDistributionRequest>;
export type KeyPairIdList = string[];
export declare const KeyPairIdList: any;
export interface KeyPairIds {
    Quantity: number;
    Items?: string[];
}
export declare const KeyPairIds: S.Schema<KeyPairIds>;
export interface Signer {
    AwsAccountNumber?: string;
    KeyPairIds?: KeyPairIds;
}
export declare const Signer: S.Schema<Signer>;
export type SignerList = Signer[];
export declare const SignerList: any;
export interface ActiveTrustedSigners {
    Enabled: boolean;
    Quantity: number;
    Items?: Signer[];
}
export declare const ActiveTrustedSigners: S.Schema<ActiveTrustedSigners>;
export interface KGKeyPairIds {
    KeyGroupId?: string;
    KeyPairIds?: KeyPairIds;
}
export declare const KGKeyPairIds: S.Schema<KGKeyPairIds>;
export type KGKeyPairIdsList = KGKeyPairIds[];
export declare const KGKeyPairIdsList: any;
export interface ActiveTrustedKeyGroups {
    Enabled: boolean;
    Quantity: number;
    Items?: KGKeyPairIds[];
}
export declare const ActiveTrustedKeyGroups: S.Schema<ActiveTrustedKeyGroups>;
export type AliasList = string[];
export declare const AliasList: any;
export interface Aliases {
    Quantity: number;
    Items?: string[];
}
export declare const Aliases: S.Schema<Aliases>;
export type SensitiveStringType = string | redacted.Redacted<string>;
export interface OriginCustomHeader {
    HeaderName: string;
    HeaderValue: string | redacted.Redacted<string>;
}
export declare const OriginCustomHeader: S.Schema<OriginCustomHeader>;
export type OriginCustomHeadersList = OriginCustomHeader[];
export declare const OriginCustomHeadersList: any;
export interface CustomHeaders {
    Quantity: number;
    Items?: OriginCustomHeader[];
}
export declare const CustomHeaders: S.Schema<CustomHeaders>;
export interface S3OriginConfig {
    OriginAccessIdentity?: string;
    OriginReadTimeout?: number;
}
export declare const S3OriginConfig: S.Schema<S3OriginConfig>;
export type OriginProtocolPolicy = "http-only" | "match-viewer" | "https-only" | (string & {});
export declare const OriginProtocolPolicy: any;
export type SslProtocol = "SSLv3" | "TLSv1" | "TLSv1.1" | "TLSv1.2" | (string & {});
export declare const SslProtocol: any;
export type SslProtocolsList = SslProtocol[];
export declare const SslProtocolsList: any;
export interface OriginSslProtocols {
    Quantity: number;
    Items: SslProtocol[];
}
export declare const OriginSslProtocols: S.Schema<OriginSslProtocols>;
export type IpAddressType = "ipv4" | "ipv6" | "dualstack" | (string & {});
export declare const IpAddressType: any;
export interface OriginMtlsConfig {
    ClientCertificateArn: string;
}
export declare const OriginMtlsConfig: S.Schema<OriginMtlsConfig>;
export interface CustomOriginConfig {
    HTTPPort: number;
    HTTPSPort: number;
    OriginProtocolPolicy: OriginProtocolPolicy;
    OriginSslProtocols?: OriginSslProtocols;
    OriginReadTimeout?: number;
    OriginKeepaliveTimeout?: number;
    IpAddressType?: IpAddressType;
    OriginMtlsConfig?: OriginMtlsConfig;
}
export declare const CustomOriginConfig: S.Schema<CustomOriginConfig>;
export interface VpcOriginConfig {
    VpcOriginId: string;
    OwnerAccountId?: string;
    OriginReadTimeout?: number;
    OriginKeepaliveTimeout?: number;
}
export declare const VpcOriginConfig: S.Schema<VpcOriginConfig>;
export type OriginShieldRegion = string;
export interface OriginShield {
    Enabled: boolean;
    OriginShieldRegion?: string;
}
export declare const OriginShield: S.Schema<OriginShield>;
export interface Origin {
    Id: string;
    DomainName: string;
    OriginPath?: string;
    CustomHeaders?: CustomHeaders;
    S3OriginConfig?: S3OriginConfig;
    CustomOriginConfig?: CustomOriginConfig;
    VpcOriginConfig?: VpcOriginConfig;
    ConnectionAttempts?: number;
    ConnectionTimeout?: number;
    ResponseCompletionTimeout?: number;
    OriginShield?: OriginShield;
    OriginAccessControlId?: string;
}
export declare const Origin: S.Schema<Origin>;
export type OriginList = Origin[];
export declare const OriginList: any;
export interface Origins {
    Quantity: number;
    Items: Origin[];
}
export declare const Origins: S.Schema<Origins>;
export type StatusCodeList = number[];
export declare const StatusCodeList: any;
export interface StatusCodes {
    Quantity: number;
    Items: number[];
}
export declare const StatusCodes: S.Schema<StatusCodes>;
export interface OriginGroupFailoverCriteria {
    StatusCodes: StatusCodes;
}
export declare const OriginGroupFailoverCriteria: S.Schema<OriginGroupFailoverCriteria>;
export interface OriginGroupMember {
    OriginId: string;
}
export declare const OriginGroupMember: S.Schema<OriginGroupMember>;
export type OriginGroupMemberList = OriginGroupMember[];
export declare const OriginGroupMemberList: any;
export interface OriginGroupMembers {
    Quantity: number;
    Items: OriginGroupMember[];
}
export declare const OriginGroupMembers: S.Schema<OriginGroupMembers>;
export type OriginGroupSelectionCriteria = "default" | "media-quality-based" | (string & {});
export declare const OriginGroupSelectionCriteria: any;
export interface OriginGroup {
    Id: string;
    FailoverCriteria: OriginGroupFailoverCriteria;
    Members: OriginGroupMembers;
    SelectionCriteria?: OriginGroupSelectionCriteria;
}
export declare const OriginGroup: S.Schema<OriginGroup>;
export type OriginGroupList = OriginGroup[];
export declare const OriginGroupList: any;
export interface OriginGroups {
    Quantity: number;
    Items?: OriginGroup[];
}
export declare const OriginGroups: S.Schema<OriginGroups>;
export type AwsAccountNumberList = string[];
export declare const AwsAccountNumberList: any;
export interface TrustedSigners {
    Enabled: boolean;
    Quantity: number;
    Items?: string[];
}
export declare const TrustedSigners: S.Schema<TrustedSigners>;
export type TrustedKeyGroupIdList = string[];
export declare const TrustedKeyGroupIdList: any;
export interface TrustedKeyGroups {
    Enabled: boolean;
    Quantity: number;
    Items?: string[];
}
export declare const TrustedKeyGroups: S.Schema<TrustedKeyGroups>;
export type ViewerProtocolPolicy = "allow-all" | "https-only" | "redirect-to-https" | (string & {});
export declare const ViewerProtocolPolicy: any;
export type Method = "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "OPTIONS" | "DELETE" | (string & {});
export declare const Method: any;
export type MethodsList = Method[];
export declare const MethodsList: any;
export interface CachedMethods {
    Quantity: number;
    Items: Method[];
}
export declare const CachedMethods: S.Schema<CachedMethods>;
export interface AllowedMethods {
    Quantity: number;
    Items: Method[];
    CachedMethods?: CachedMethods;
}
export declare const AllowedMethods: S.Schema<AllowedMethods>;
export type LambdaFunctionARN = string;
export type EventType = "viewer-request" | "viewer-response" | "origin-request" | "origin-response" | (string & {});
export declare const EventType: any;
export interface LambdaFunctionAssociation {
    LambdaFunctionARN: string;
    EventType: EventType;
    IncludeBody?: boolean;
}
export declare const LambdaFunctionAssociation: S.Schema<LambdaFunctionAssociation>;
export type LambdaFunctionAssociationList = LambdaFunctionAssociation[];
export declare const LambdaFunctionAssociationList: any;
export interface LambdaFunctionAssociations {
    Quantity: number;
    Items?: LambdaFunctionAssociation[];
}
export declare const LambdaFunctionAssociations: S.Schema<LambdaFunctionAssociations>;
export type FunctionARN = string;
export interface FunctionAssociation {
    FunctionARN: string;
    EventType: EventType;
}
export declare const FunctionAssociation: S.Schema<FunctionAssociation>;
export type FunctionAssociationList = FunctionAssociation[];
export declare const FunctionAssociationList: any;
export interface FunctionAssociations {
    Quantity: number;
    Items?: FunctionAssociation[];
}
export declare const FunctionAssociations: S.Schema<FunctionAssociations>;
export interface GrpcConfig {
    Enabled: boolean;
}
export declare const GrpcConfig: S.Schema<GrpcConfig>;
export type ItemSelection = "none" | "whitelist" | "all" | (string & {});
export declare const ItemSelection: any;
export type CookieNameList = string[];
export declare const CookieNameList: any;
export interface CookieNames {
    Quantity: number;
    Items?: string[];
}
export declare const CookieNames: S.Schema<CookieNames>;
export interface CookiePreference {
    Forward: ItemSelection;
    WhitelistedNames?: CookieNames;
}
export declare const CookiePreference: S.Schema<CookiePreference>;
export type HeaderList = string[];
export declare const HeaderList: any;
export interface Headers {
    Quantity: number;
    Items?: string[];
}
export declare const Headers: S.Schema<Headers>;
export type QueryStringCacheKeysList = string[];
export declare const QueryStringCacheKeysList: any;
export interface QueryStringCacheKeys {
    Quantity: number;
    Items?: string[];
}
export declare const QueryStringCacheKeys: S.Schema<QueryStringCacheKeys>;
export interface ForwardedValues {
    QueryString: boolean;
    Cookies: CookiePreference;
    Headers?: Headers;
    QueryStringCacheKeys?: QueryStringCacheKeys;
}
export declare const ForwardedValues: S.Schema<ForwardedValues>;
export interface DefaultCacheBehavior {
    TargetOriginId: string;
    TrustedSigners?: TrustedSigners;
    TrustedKeyGroups?: TrustedKeyGroups;
    ViewerProtocolPolicy: ViewerProtocolPolicy;
    AllowedMethods?: AllowedMethods;
    SmoothStreaming?: boolean;
    Compress?: boolean;
    LambdaFunctionAssociations?: LambdaFunctionAssociations;
    FunctionAssociations?: FunctionAssociations;
    FieldLevelEncryptionId?: string;
    RealtimeLogConfigArn?: string;
    CachePolicyId?: string;
    OriginRequestPolicyId?: string;
    ResponseHeadersPolicyId?: string;
    GrpcConfig?: GrpcConfig;
    ForwardedValues?: ForwardedValues;
    MinTTL?: number;
    DefaultTTL?: number;
    MaxTTL?: number;
}
export declare const DefaultCacheBehavior: S.Schema<DefaultCacheBehavior>;
export interface CacheBehavior {
    PathPattern: string;
    TargetOriginId: string;
    TrustedSigners?: TrustedSigners;
    TrustedKeyGroups?: TrustedKeyGroups;
    ViewerProtocolPolicy: ViewerProtocolPolicy;
    AllowedMethods?: AllowedMethods;
    SmoothStreaming?: boolean;
    Compress?: boolean;
    LambdaFunctionAssociations?: LambdaFunctionAssociations;
    FunctionAssociations?: FunctionAssociations;
    FieldLevelEncryptionId?: string;
    RealtimeLogConfigArn?: string;
    CachePolicyId?: string;
    OriginRequestPolicyId?: string;
    ResponseHeadersPolicyId?: string;
    GrpcConfig?: GrpcConfig;
    ForwardedValues?: ForwardedValues;
    MinTTL?: number;
    DefaultTTL?: number;
    MaxTTL?: number;
}
export declare const CacheBehavior: S.Schema<CacheBehavior>;
export type CacheBehaviorList = CacheBehavior[];
export declare const CacheBehaviorList: any;
export interface CacheBehaviors {
    Quantity: number;
    Items?: CacheBehavior[];
}
export declare const CacheBehaviors: S.Schema<CacheBehaviors>;
export interface CustomErrorResponse {
    ErrorCode: number;
    ResponsePagePath?: string;
    ResponseCode?: string;
    ErrorCachingMinTTL?: number;
}
export declare const CustomErrorResponse: S.Schema<CustomErrorResponse>;
export type CustomErrorResponseList = CustomErrorResponse[];
export declare const CustomErrorResponseList: any;
export interface CustomErrorResponses {
    Quantity: number;
    Items?: CustomErrorResponse[];
}
export declare const CustomErrorResponses: S.Schema<CustomErrorResponses>;
export type CommentType = string | redacted.Redacted<string>;
export interface LoggingConfig {
    Enabled?: boolean;
    IncludeCookies?: boolean;
    Bucket?: string;
    Prefix?: string;
}
export declare const LoggingConfig: S.Schema<LoggingConfig>;
export type PriceClass = "PriceClass_100" | "PriceClass_200" | "PriceClass_All" | "None" | (string & {});
export declare const PriceClass: any;
export type ServerCertificateId = string;
export type SSLSupportMethod = "sni-only" | "vip" | "static-ip" | (string & {});
export declare const SSLSupportMethod: any;
export type MinimumProtocolVersion = "SSLv3" | "TLSv1" | "TLSv1_2016" | "TLSv1.1_2016" | "TLSv1.2_2018" | "TLSv1.2_2019" | "TLSv1.2_2021" | "TLSv1.3_2025" | "TLSv1.2_2025" | (string & {});
export declare const MinimumProtocolVersion: any;
export type CertificateSource = "cloudfront" | "iam" | "acm" | (string & {});
export declare const CertificateSource: any;
export interface ViewerCertificate {
    CloudFrontDefaultCertificate?: boolean;
    IAMCertificateId?: string;
    ACMCertificateArn?: string;
    SSLSupportMethod?: SSLSupportMethod;
    MinimumProtocolVersion?: MinimumProtocolVersion;
    Certificate?: string;
    CertificateSource?: CertificateSource;
}
export declare const ViewerCertificate: S.Schema<ViewerCertificate>;
export type GeoRestrictionType = "blacklist" | "whitelist" | "none" | (string & {});
export declare const GeoRestrictionType: any;
export type LocationList = string[];
export declare const LocationList: any;
export interface GeoRestriction {
    RestrictionType: GeoRestrictionType;
    Quantity: number;
    Items?: string[];
}
export declare const GeoRestriction: S.Schema<GeoRestriction>;
export interface Restrictions {
    GeoRestriction: GeoRestriction;
}
export declare const Restrictions: S.Schema<Restrictions>;
export type HttpVersion = "http1.1" | "http2" | "http3" | "http2and3" | "HTTP1.1" | "HTTP2" | "HTTP3" | "HTTP2AND3" | (string & {});
export declare const HttpVersion: any;
export type ParameterName = string;
export type ParameterValue = string;
export interface StringSchemaConfig {
    Comment?: string | redacted.Redacted<string>;
    DefaultValue?: string;
    Required: boolean;
}
export declare const StringSchemaConfig: S.Schema<StringSchemaConfig>;
export interface ParameterDefinitionSchema {
    StringSchema?: StringSchemaConfig;
}
export declare const ParameterDefinitionSchema: S.Schema<ParameterDefinitionSchema>;
export interface ParameterDefinition {
    Name: string;
    Definition: ParameterDefinitionSchema;
}
export declare const ParameterDefinition: S.Schema<ParameterDefinition>;
export type ParameterDefinitions = ParameterDefinition[];
export declare const ParameterDefinitions: any;
export interface TenantConfig {
    ParameterDefinitions?: ParameterDefinition[];
}
export declare const TenantConfig: S.Schema<TenantConfig>;
export type ConnectionMode = "direct" | "tenant-only" | (string & {});
export declare const ConnectionMode: any;
export type ViewerMtlsMode = "required" | "optional" | "passthrough" | (string & {});
export declare const ViewerMtlsMode: any;
export interface TrustStoreConfig {
    TrustStoreId: string;
    AdvertiseTrustStoreCaNames?: boolean;
    IgnoreCertificateExpiry?: boolean;
}
export declare const TrustStoreConfig: S.Schema<TrustStoreConfig>;
export interface ViewerMtlsConfig {
    Mode?: ViewerMtlsMode;
    TrustStoreConfig?: TrustStoreConfig;
}
export declare const ViewerMtlsConfig: S.Schema<ViewerMtlsConfig>;
export type ResourceId = string;
export interface ConnectionFunctionAssociation {
    Id: string;
}
export declare const ConnectionFunctionAssociation: S.Schema<ConnectionFunctionAssociation>;
export interface CacheTagConfig {
    HeaderName: string;
}
export declare const CacheTagConfig: S.Schema<CacheTagConfig>;
export interface DistributionConfig {
    CallerReference: string;
    Aliases?: Aliases;
    DefaultRootObject?: string;
    Origins: Origins;
    OriginGroups?: OriginGroups;
    DefaultCacheBehavior: DefaultCacheBehavior;
    CacheBehaviors?: CacheBehaviors;
    CustomErrorResponses?: CustomErrorResponses;
    Comment: string | redacted.Redacted<string>;
    Logging?: LoggingConfig;
    PriceClass?: PriceClass;
    Enabled: boolean;
    ViewerCertificate?: ViewerCertificate;
    Restrictions?: Restrictions;
    WebACLId?: string;
    HttpVersion?: HttpVersion;
    IsIPV6Enabled?: boolean;
    ContinuousDeploymentPolicyId?: string;
    Staging?: boolean;
    AnycastIpListId?: string;
    TenantConfig?: TenantConfig;
    ConnectionMode?: ConnectionMode;
    ViewerMtlsConfig?: ViewerMtlsConfig;
    ConnectionFunctionAssociation?: ConnectionFunctionAssociation;
    CacheTagConfig?: CacheTagConfig;
}
export declare const DistributionConfig: S.Schema<DistributionConfig>;
export type ICPRecordalStatus = "APPROVED" | "SUSPENDED" | "PENDING" | (string & {});
export declare const ICPRecordalStatus: any;
export interface AliasICPRecordal {
    CNAME?: string;
    ICPRecordalStatus?: ICPRecordalStatus;
}
export declare const AliasICPRecordal: S.Schema<AliasICPRecordal>;
export type AliasICPRecordals = AliasICPRecordal[];
export declare const AliasICPRecordals: any;
export interface Distribution {
    Id: string;
    ARN: string;
    Status: string;
    LastModifiedTime: Date;
    InProgressInvalidationBatches: number;
    DomainName: string;
    ActiveTrustedSigners?: ActiveTrustedSigners;
    ActiveTrustedKeyGroups?: ActiveTrustedKeyGroups;
    DistributionConfig: DistributionConfig;
    AliasICPRecordals?: AliasICPRecordal[];
}
export declare const Distribution: S.Schema<Distribution>;
export interface CopyDistributionResult {
    Distribution?: Distribution;
    Location?: string;
    ETag?: string;
}
export declare const CopyDistributionResult: S.Schema<CopyDistributionResult>;
export type AnycastIpListName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface Tags {
    Items?: Tag[];
}
export declare const Tags: S.Schema<Tags>;
export type IpamCidrStatus = "provisioned" | "failed-provision" | "provisioning" | "deprovisioned" | "failed-deprovision" | "deprovisioning" | "advertised" | "failed-advertise" | "advertising" | "withdrawn" | "failed-withdraw" | "withdrawing" | (string & {});
export declare const IpamCidrStatus: any;
export interface IpamCidrConfig {
    Cidr: string;
    IpamPoolArn: string;
    AnycastIp?: string;
    Status?: IpamCidrStatus;
}
export declare const IpamCidrConfig: S.Schema<IpamCidrConfig>;
export type IpamCidrConfigList = IpamCidrConfig[];
export declare const IpamCidrConfigList: any;
export interface CreateAnycastIpListRequest {
    Name: string;
    IpCount: number;
    Tags?: Tags;
    IpAddressType?: IpAddressType;
    IpamCidrConfigs?: IpamCidrConfig[];
}
export declare const CreateAnycastIpListRequest: S.Schema<CreateAnycastIpListRequest>;
export interface IpamConfig {
    Quantity: number;
    IpamCidrConfigs: IpamCidrConfig[];
}
export declare const IpamConfig: S.Schema<IpamConfig>;
export type AnycastIps = string[];
export declare const AnycastIps: any;
export interface AnycastIpList {
    Id: string;
    Name: string;
    Status: string;
    Arn: string;
    IpAddressType?: IpAddressType;
    IpamConfig?: IpamConfig;
    AnycastIps: string[];
    IpCount: number;
    LastModifiedTime: Date;
}
export declare const AnycastIpList: S.Schema<AnycastIpList>;
export interface CreateAnycastIpListResult {
    AnycastIpList?: AnycastIpList;
    ETag?: string;
}
export declare const CreateAnycastIpListResult: S.Schema<CreateAnycastIpListResult>;
export type CachePolicyHeaderBehavior = "none" | "whitelist" | (string & {});
export declare const CachePolicyHeaderBehavior: any;
export interface CachePolicyHeadersConfig {
    HeaderBehavior: CachePolicyHeaderBehavior;
    Headers?: Headers;
}
export declare const CachePolicyHeadersConfig: S.Schema<CachePolicyHeadersConfig>;
export type CachePolicyCookieBehavior = "none" | "whitelist" | "allExcept" | "all" | (string & {});
export declare const CachePolicyCookieBehavior: any;
export interface CachePolicyCookiesConfig {
    CookieBehavior: CachePolicyCookieBehavior;
    Cookies?: CookieNames;
}
export declare const CachePolicyCookiesConfig: S.Schema<CachePolicyCookiesConfig>;
export type CachePolicyQueryStringBehavior = "none" | "whitelist" | "allExcept" | "all" | (string & {});
export declare const CachePolicyQueryStringBehavior: any;
export type QueryStringNamesList = string[];
export declare const QueryStringNamesList: any;
export interface QueryStringNames {
    Quantity: number;
    Items?: string[];
}
export declare const QueryStringNames: S.Schema<QueryStringNames>;
export interface CachePolicyQueryStringsConfig {
    QueryStringBehavior: CachePolicyQueryStringBehavior;
    QueryStrings?: QueryStringNames;
}
export declare const CachePolicyQueryStringsConfig: S.Schema<CachePolicyQueryStringsConfig>;
export interface ParametersInCacheKeyAndForwardedToOrigin {
    EnableAcceptEncodingGzip: boolean;
    EnableAcceptEncodingBrotli?: boolean;
    HeadersConfig: CachePolicyHeadersConfig;
    CookiesConfig: CachePolicyCookiesConfig;
    QueryStringsConfig: CachePolicyQueryStringsConfig;
}
export declare const ParametersInCacheKeyAndForwardedToOrigin: S.Schema<ParametersInCacheKeyAndForwardedToOrigin>;
export interface CachePolicyConfig {
    Comment?: string;
    Name: string;
    DefaultTTL?: number;
    MaxTTL?: number;
    MinTTL: number;
    ParametersInCacheKeyAndForwardedToOrigin?: ParametersInCacheKeyAndForwardedToOrigin;
}
export declare const CachePolicyConfig: S.Schema<CachePolicyConfig>;
export interface CreateCachePolicyRequest {
    CachePolicyConfig: CachePolicyConfig;
}
export declare const CreateCachePolicyRequest: S.Schema<CreateCachePolicyRequest>;
export interface CachePolicy {
    Id: string;
    LastModifiedTime: Date;
    CachePolicyConfig: CachePolicyConfig;
}
export declare const CachePolicy: S.Schema<CachePolicy>;
export interface CreateCachePolicyResult {
    CachePolicy?: CachePolicy;
    Location?: string;
    ETag?: string;
}
export declare const CreateCachePolicyResult: S.Schema<CreateCachePolicyResult>;
export interface CloudFrontOriginAccessIdentityConfig {
    CallerReference: string;
    Comment: string;
}
export declare const CloudFrontOriginAccessIdentityConfig: S.Schema<CloudFrontOriginAccessIdentityConfig>;
export interface CreateCloudFrontOriginAccessIdentityRequest {
    CloudFrontOriginAccessIdentityConfig: CloudFrontOriginAccessIdentityConfig;
}
export declare const CreateCloudFrontOriginAccessIdentityRequest: S.Schema<CreateCloudFrontOriginAccessIdentityRequest>;
export interface CloudFrontOriginAccessIdentity {
    Id: string;
    S3CanonicalUserId: string;
    CloudFrontOriginAccessIdentityConfig?: CloudFrontOriginAccessIdentityConfig;
}
export declare const CloudFrontOriginAccessIdentity: S.Schema<CloudFrontOriginAccessIdentity>;
export interface CreateCloudFrontOriginAccessIdentityResult {
    CloudFrontOriginAccessIdentity?: CloudFrontOriginAccessIdentity;
    Location?: string;
    ETag?: string;
}
export declare const CreateCloudFrontOriginAccessIdentityResult: S.Schema<CreateCloudFrontOriginAccessIdentityResult>;
export type FunctionName = string;
export type FunctionRuntime = "cloudfront-js-1.0" | "cloudfront-js-2.0" | (string & {});
export declare const FunctionRuntime: any;
export type KeyValueStoreARN = string;
export interface KeyValueStoreAssociation {
    KeyValueStoreARN: string;
}
export declare const KeyValueStoreAssociation: S.Schema<KeyValueStoreAssociation>;
export type KeyValueStoreAssociationList = KeyValueStoreAssociation[];
export declare const KeyValueStoreAssociationList: any;
export interface KeyValueStoreAssociations {
    Quantity: number;
    Items?: KeyValueStoreAssociation[];
}
export declare const KeyValueStoreAssociations: S.Schema<KeyValueStoreAssociations>;
export interface FunctionConfig {
    Comment?: string;
    Runtime: FunctionRuntime;
    KeyValueStoreAssociations?: KeyValueStoreAssociations;
}
export declare const FunctionConfig: S.Schema<FunctionConfig>;
export type FunctionBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface CreateConnectionFunctionRequest {
    Name: string;
    ConnectionFunctionConfig: FunctionConfig;
    ConnectionFunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
    Tags?: Tags;
}
export declare const CreateConnectionFunctionRequest: S.Schema<CreateConnectionFunctionRequest>;
export type FunctionStage = "DEVELOPMENT" | "LIVE" | (string & {});
export declare const FunctionStage: any;
export interface ConnectionFunctionSummary {
    Name: string;
    Id: string;
    ConnectionFunctionConfig: FunctionConfig;
    ConnectionFunctionArn: string;
    Status: string;
    Stage: FunctionStage;
    CreatedTime: Date;
    LastModifiedTime: Date;
}
export declare const ConnectionFunctionSummary: S.Schema<ConnectionFunctionSummary>;
export interface CreateConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    Location?: string;
    ETag?: string;
}
export declare const CreateConnectionFunctionResult: S.Schema<CreateConnectionFunctionResult>;
export interface CreateConnectionGroupRequest {
    Name: string;
    Ipv6Enabled?: boolean;
    Tags?: Tags;
    AnycastIpListId?: string;
    Enabled?: boolean;
}
export declare const CreateConnectionGroupRequest: S.Schema<CreateConnectionGroupRequest>;
export interface ConnectionGroup {
    Id?: string;
    Name?: string;
    Arn?: string;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    Tags?: Tags;
    Ipv6Enabled?: boolean;
    RoutingEndpoint?: string;
    AnycastIpListId?: string;
    Status?: string;
    Enabled?: boolean;
    IsDefault?: boolean;
}
export declare const ConnectionGroup: S.Schema<ConnectionGroup>;
export interface CreateConnectionGroupResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export declare const CreateConnectionGroupResult: S.Schema<CreateConnectionGroupResult>;
export type StagingDistributionDnsNameList = string[];
export declare const StagingDistributionDnsNameList: any;
export interface StagingDistributionDnsNames {
    Quantity: number;
    Items?: string[];
}
export declare const StagingDistributionDnsNames: S.Schema<StagingDistributionDnsNames>;
export interface SessionStickinessConfig {
    IdleTTL: number;
    MaximumTTL: number;
}
export declare const SessionStickinessConfig: S.Schema<SessionStickinessConfig>;
export interface ContinuousDeploymentSingleWeightConfig {
    Weight: number;
    SessionStickinessConfig?: SessionStickinessConfig;
}
export declare const ContinuousDeploymentSingleWeightConfig: S.Schema<ContinuousDeploymentSingleWeightConfig>;
export interface ContinuousDeploymentSingleHeaderConfig {
    Header: string;
    Value: string;
}
export declare const ContinuousDeploymentSingleHeaderConfig: S.Schema<ContinuousDeploymentSingleHeaderConfig>;
export type ContinuousDeploymentPolicyType = "SingleWeight" | "SingleHeader" | (string & {});
export declare const ContinuousDeploymentPolicyType: any;
export interface TrafficConfig {
    SingleWeightConfig?: ContinuousDeploymentSingleWeightConfig;
    SingleHeaderConfig?: ContinuousDeploymentSingleHeaderConfig;
    Type: ContinuousDeploymentPolicyType;
}
export declare const TrafficConfig: S.Schema<TrafficConfig>;
export interface ContinuousDeploymentPolicyConfig {
    StagingDistributionDnsNames: StagingDistributionDnsNames;
    Enabled: boolean;
    TrafficConfig?: TrafficConfig;
}
export declare const ContinuousDeploymentPolicyConfig: S.Schema<ContinuousDeploymentPolicyConfig>;
export interface CreateContinuousDeploymentPolicyRequest {
    ContinuousDeploymentPolicyConfig: ContinuousDeploymentPolicyConfig;
}
export declare const CreateContinuousDeploymentPolicyRequest: S.Schema<CreateContinuousDeploymentPolicyRequest>;
export interface ContinuousDeploymentPolicy {
    Id: string;
    LastModifiedTime: Date;
    ContinuousDeploymentPolicyConfig: ContinuousDeploymentPolicyConfig;
}
export declare const ContinuousDeploymentPolicy: S.Schema<ContinuousDeploymentPolicy>;
export interface CreateContinuousDeploymentPolicyResult {
    ContinuousDeploymentPolicy?: ContinuousDeploymentPolicy;
    Location?: string;
    ETag?: string;
}
export declare const CreateContinuousDeploymentPolicyResult: S.Schema<CreateContinuousDeploymentPolicyResult>;
export interface CreateDistributionRequest {
    DistributionConfig: DistributionConfig;
}
export declare const CreateDistributionRequest: S.Schema<CreateDistributionRequest>;
export interface CreateDistributionResult {
    Distribution?: Distribution;
    Location?: string;
    ETag?: string;
}
export declare const CreateDistributionResult: S.Schema<CreateDistributionResult>;
export interface DomainItem {
    Domain: string;
}
export declare const DomainItem: S.Schema<DomainItem>;
export type DomainList = DomainItem[];
export declare const DomainList: any;
export type CustomizationActionType = "override" | "disable" | (string & {});
export declare const CustomizationActionType: any;
export interface WebAclCustomization {
    Action: CustomizationActionType;
    Arn?: string;
}
export declare const WebAclCustomization: S.Schema<WebAclCustomization>;
export interface Certificate {
    Arn: string;
}
export declare const Certificate: S.Schema<Certificate>;
export interface GeoRestrictionCustomization {
    RestrictionType: GeoRestrictionType;
    Locations?: string[];
}
export declare const GeoRestrictionCustomization: S.Schema<GeoRestrictionCustomization>;
export interface Customizations {
    WebAcl?: WebAclCustomization;
    Certificate?: Certificate;
    GeoRestrictions?: GeoRestrictionCustomization;
}
export declare const Customizations: S.Schema<Customizations>;
export interface Parameter {
    Name: string;
    Value: string;
}
export declare const Parameter: S.Schema<Parameter>;
export type Parameters = Parameter[];
export declare const Parameters: any;
export type ValidationTokenHost = "cloudfront" | "self-hosted" | (string & {});
export declare const ValidationTokenHost: any;
export type CertificateTransparencyLoggingPreference = "enabled" | "disabled" | (string & {});
export declare const CertificateTransparencyLoggingPreference: any;
export interface ManagedCertificateRequest {
    ValidationTokenHost: ValidationTokenHost;
    PrimaryDomainName?: string;
    CertificateTransparencyLoggingPreference?: CertificateTransparencyLoggingPreference;
}
export declare const ManagedCertificateRequest: S.Schema<ManagedCertificateRequest>;
export interface CreateDistributionTenantRequest {
    DistributionId: string;
    Name: string;
    Domains: DomainItem[];
    Tags?: Tags;
    Customizations?: Customizations;
    Parameters?: Parameter[];
    ConnectionGroupId?: string;
    ManagedCertificateRequest?: ManagedCertificateRequest;
    Enabled?: boolean;
}
export declare const CreateDistributionTenantRequest: S.Schema<CreateDistributionTenantRequest>;
export type DomainStatus = "active" | "inactive" | (string & {});
export declare const DomainStatus: any;
export interface DomainResult {
    Domain: string;
    Status?: DomainStatus;
}
export declare const DomainResult: S.Schema<DomainResult>;
export type DomainResultList = DomainResult[];
export declare const DomainResultList: any;
export interface DistributionTenant {
    Id?: string;
    DistributionId?: string;
    Name?: string;
    Arn?: string;
    Domains?: DomainResult[];
    Tags?: Tags;
    Customizations?: Customizations;
    Parameters?: Parameter[];
    ConnectionGroupId?: string;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    Enabled?: boolean;
    Status?: string;
}
export declare const DistributionTenant: S.Schema<DistributionTenant>;
export interface CreateDistributionTenantResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export declare const CreateDistributionTenantResult: S.Schema<CreateDistributionTenantResult>;
export interface DistributionConfigWithTags {
    DistributionConfig: DistributionConfig;
    Tags: Tags;
}
export declare const DistributionConfigWithTags: S.Schema<DistributionConfigWithTags>;
export interface CreateDistributionWithTagsRequest {
    DistributionConfigWithTags: DistributionConfigWithTags;
}
export declare const CreateDistributionWithTagsRequest: S.Schema<CreateDistributionWithTagsRequest>;
export interface CreateDistributionWithTagsResult {
    Distribution?: Distribution;
    Location?: string;
    ETag?: string;
}
export declare const CreateDistributionWithTagsResult: S.Schema<CreateDistributionWithTagsResult>;
export interface QueryArgProfile {
    QueryArg: string;
    ProfileId: string;
}
export declare const QueryArgProfile: S.Schema<QueryArgProfile>;
export type QueryArgProfileList = QueryArgProfile[];
export declare const QueryArgProfileList: any;
export interface QueryArgProfiles {
    Quantity: number;
    Items?: QueryArgProfile[];
}
export declare const QueryArgProfiles: S.Schema<QueryArgProfiles>;
export interface QueryArgProfileConfig {
    ForwardWhenQueryArgProfileIsUnknown: boolean;
    QueryArgProfiles?: QueryArgProfiles;
}
export declare const QueryArgProfileConfig: S.Schema<QueryArgProfileConfig>;
export type Format = "URLEncoded" | (string & {});
export declare const Format: any;
export interface ContentTypeProfile {
    Format: Format;
    ProfileId?: string;
    ContentType: string;
}
export declare const ContentTypeProfile: S.Schema<ContentTypeProfile>;
export type ContentTypeProfileList = ContentTypeProfile[];
export declare const ContentTypeProfileList: any;
export interface ContentTypeProfiles {
    Quantity: number;
    Items?: ContentTypeProfile[];
}
export declare const ContentTypeProfiles: S.Schema<ContentTypeProfiles>;
export interface ContentTypeProfileConfig {
    ForwardWhenContentTypeIsUnknown: boolean;
    ContentTypeProfiles?: ContentTypeProfiles;
}
export declare const ContentTypeProfileConfig: S.Schema<ContentTypeProfileConfig>;
export interface FieldLevelEncryptionConfig {
    CallerReference: string;
    Comment?: string;
    QueryArgProfileConfig?: QueryArgProfileConfig;
    ContentTypeProfileConfig?: ContentTypeProfileConfig;
}
export declare const FieldLevelEncryptionConfig: S.Schema<FieldLevelEncryptionConfig>;
export interface CreateFieldLevelEncryptionConfigRequest {
    FieldLevelEncryptionConfig: FieldLevelEncryptionConfig;
}
export declare const CreateFieldLevelEncryptionConfigRequest: S.Schema<CreateFieldLevelEncryptionConfigRequest>;
export interface FieldLevelEncryption {
    Id: string;
    LastModifiedTime: Date;
    FieldLevelEncryptionConfig: FieldLevelEncryptionConfig;
}
export declare const FieldLevelEncryption: S.Schema<FieldLevelEncryption>;
export interface CreateFieldLevelEncryptionConfigResult {
    FieldLevelEncryption?: FieldLevelEncryption;
    Location?: string;
    ETag?: string;
}
export declare const CreateFieldLevelEncryptionConfigResult: S.Schema<CreateFieldLevelEncryptionConfigResult>;
export type FieldPatternList = string[];
export declare const FieldPatternList: any;
export interface FieldPatterns {
    Quantity: number;
    Items?: string[];
}
export declare const FieldPatterns: S.Schema<FieldPatterns>;
export interface EncryptionEntity {
    PublicKeyId: string;
    ProviderId: string;
    FieldPatterns: FieldPatterns;
}
export declare const EncryptionEntity: S.Schema<EncryptionEntity>;
export type EncryptionEntityList = EncryptionEntity[];
export declare const EncryptionEntityList: any;
export interface EncryptionEntities {
    Quantity: number;
    Items?: EncryptionEntity[];
}
export declare const EncryptionEntities: S.Schema<EncryptionEntities>;
export interface FieldLevelEncryptionProfileConfig {
    Name: string;
    CallerReference: string;
    Comment?: string;
    EncryptionEntities: EncryptionEntities;
}
export declare const FieldLevelEncryptionProfileConfig: S.Schema<FieldLevelEncryptionProfileConfig>;
export interface CreateFieldLevelEncryptionProfileRequest {
    FieldLevelEncryptionProfileConfig: FieldLevelEncryptionProfileConfig;
}
export declare const CreateFieldLevelEncryptionProfileRequest: S.Schema<CreateFieldLevelEncryptionProfileRequest>;
export interface FieldLevelEncryptionProfile {
    Id: string;
    LastModifiedTime: Date;
    FieldLevelEncryptionProfileConfig: FieldLevelEncryptionProfileConfig;
}
export declare const FieldLevelEncryptionProfile: S.Schema<FieldLevelEncryptionProfile>;
export interface CreateFieldLevelEncryptionProfileResult {
    FieldLevelEncryptionProfile?: FieldLevelEncryptionProfile;
    Location?: string;
    ETag?: string;
}
export declare const CreateFieldLevelEncryptionProfileResult: S.Schema<CreateFieldLevelEncryptionProfileResult>;
export interface CreateFunctionRequest {
    Name: string;
    FunctionConfig: FunctionConfig;
    FunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
    Tags?: Tags;
}
export declare const CreateFunctionRequest: S.Schema<CreateFunctionRequest>;
export interface FunctionMetadata {
    FunctionARN: string;
    Stage?: FunctionStage;
    CreatedTime?: Date;
    LastModifiedTime: Date;
}
export declare const FunctionMetadata: S.Schema<FunctionMetadata>;
export interface FunctionSummary {
    Name: string;
    Status?: string;
    FunctionConfig: FunctionConfig;
    FunctionMetadata: FunctionMetadata;
}
export declare const FunctionSummary: S.Schema<FunctionSummary>;
export interface CreateFunctionResult {
    FunctionSummary?: FunctionSummary;
    Location?: string;
    ETag?: string;
}
export declare const CreateFunctionResult: S.Schema<CreateFunctionResult>;
export type PathList = string[];
export declare const PathList: any;
export interface Paths {
    Quantity: number;
    Items?: string[];
}
export declare const Paths: S.Schema<Paths>;
export interface InvalidationBatch {
    Paths: Paths;
    CallerReference: string;
}
export declare const InvalidationBatch: S.Schema<InvalidationBatch>;
export interface CreateInvalidationRequest {
    DistributionId: string;
    InvalidationBatch: InvalidationBatch;
}
export declare const CreateInvalidationRequest: S.Schema<CreateInvalidationRequest>;
export interface Invalidation {
    Id: string;
    Status: string;
    CreateTime: Date;
    InvalidationBatch: InvalidationBatch;
}
export declare const Invalidation: S.Schema<Invalidation>;
export interface CreateInvalidationResult {
    Location?: string;
    Invalidation?: Invalidation;
}
export declare const CreateInvalidationResult: S.Schema<CreateInvalidationResult>;
export interface CreateInvalidationForDistributionTenantRequest {
    Id: string;
    InvalidationBatch: InvalidationBatch;
}
export declare const CreateInvalidationForDistributionTenantRequest: S.Schema<CreateInvalidationForDistributionTenantRequest>;
export interface CreateInvalidationForDistributionTenantResult {
    Location?: string;
    Invalidation?: Invalidation;
}
export declare const CreateInvalidationForDistributionTenantResult: S.Schema<CreateInvalidationForDistributionTenantResult>;
export type PublicKeyIdList = string[];
export declare const PublicKeyIdList: any;
export interface KeyGroupConfig {
    Name: string;
    Items: string[];
    Comment?: string;
}
export declare const KeyGroupConfig: S.Schema<KeyGroupConfig>;
export interface CreateKeyGroupRequest {
    KeyGroupConfig: KeyGroupConfig;
}
export declare const CreateKeyGroupRequest: S.Schema<CreateKeyGroupRequest>;
export interface KeyGroup {
    Id: string;
    LastModifiedTime: Date;
    KeyGroupConfig: KeyGroupConfig;
}
export declare const KeyGroup: S.Schema<KeyGroup>;
export interface CreateKeyGroupResult {
    KeyGroup?: KeyGroup;
    Location?: string;
    ETag?: string;
}
export declare const CreateKeyGroupResult: S.Schema<CreateKeyGroupResult>;
export type KeyValueStoreName = string;
export type KeyValueStoreComment = string;
export type ImportSourceType = "S3" | (string & {});
export declare const ImportSourceType: any;
export interface ImportSource {
    SourceType: ImportSourceType;
    SourceARN: string;
}
export declare const ImportSource: S.Schema<ImportSource>;
export interface CreateKeyValueStoreRequest {
    Name: string;
    Comment?: string;
    ImportSource?: ImportSource;
    Tags?: Tags;
}
export declare const CreateKeyValueStoreRequest: S.Schema<CreateKeyValueStoreRequest>;
export interface KeyValueStore {
    Name: string;
    Id: string;
    Comment?: string;
    ARN: string;
    Status?: string;
    LastModifiedTime: Date;
}
export declare const KeyValueStore: S.Schema<KeyValueStore>;
export interface CreateKeyValueStoreResult {
    KeyValueStore?: KeyValueStore;
    ETag?: string;
    Location?: string;
}
export declare const CreateKeyValueStoreResult: S.Schema<CreateKeyValueStoreResult>;
export type RealtimeMetricsSubscriptionStatus = "Enabled" | "Disabled" | (string & {});
export declare const RealtimeMetricsSubscriptionStatus: any;
export interface RealtimeMetricsSubscriptionConfig {
    RealtimeMetricsSubscriptionStatus: RealtimeMetricsSubscriptionStatus;
}
export declare const RealtimeMetricsSubscriptionConfig: S.Schema<RealtimeMetricsSubscriptionConfig>;
export interface MonitoringSubscription {
    RealtimeMetricsSubscriptionConfig?: RealtimeMetricsSubscriptionConfig;
}
export declare const MonitoringSubscription: S.Schema<MonitoringSubscription>;
export interface CreateMonitoringSubscriptionRequest {
    DistributionId: string;
    MonitoringSubscription: MonitoringSubscription;
}
export declare const CreateMonitoringSubscriptionRequest: S.Schema<CreateMonitoringSubscriptionRequest>;
export interface CreateMonitoringSubscriptionResult {
    MonitoringSubscription?: MonitoringSubscription;
}
export declare const CreateMonitoringSubscriptionResult: S.Schema<CreateMonitoringSubscriptionResult>;
export type OriginAccessControlSigningProtocols = "sigv4" | "sigv4a" | (string & {});
export declare const OriginAccessControlSigningProtocols: any;
export type OriginAccessControlSigningBehaviors = "never" | "always" | "no-override" | (string & {});
export declare const OriginAccessControlSigningBehaviors: any;
export type OriginAccessControlOriginTypes = "s3" | "mediastore" | "mediapackagev2" | "lambda" | (string & {});
export declare const OriginAccessControlOriginTypes: any;
export interface OriginAccessControlConfig {
    Name: string;
    Description?: string;
    SigningProtocol: OriginAccessControlSigningProtocols;
    SigningBehavior: OriginAccessControlSigningBehaviors;
    OriginAccessControlOriginType: OriginAccessControlOriginTypes;
}
export declare const OriginAccessControlConfig: S.Schema<OriginAccessControlConfig>;
export interface CreateOriginAccessControlRequest {
    OriginAccessControlConfig: OriginAccessControlConfig;
}
export declare const CreateOriginAccessControlRequest: S.Schema<CreateOriginAccessControlRequest>;
export interface OriginAccessControl {
    Id: string;
    OriginAccessControlConfig?: OriginAccessControlConfig;
}
export declare const OriginAccessControl: S.Schema<OriginAccessControl>;
export interface CreateOriginAccessControlResult {
    OriginAccessControl?: OriginAccessControl;
    Location?: string;
    ETag?: string;
}
export declare const CreateOriginAccessControlResult: S.Schema<CreateOriginAccessControlResult>;
export type OriginRequestPolicyHeaderBehavior = "none" | "whitelist" | "allViewer" | "allViewerAndWhitelistCloudFront" | "allExcept" | (string & {});
export declare const OriginRequestPolicyHeaderBehavior: any;
export interface OriginRequestPolicyHeadersConfig {
    HeaderBehavior: OriginRequestPolicyHeaderBehavior;
    Headers?: Headers;
}
export declare const OriginRequestPolicyHeadersConfig: S.Schema<OriginRequestPolicyHeadersConfig>;
export type OriginRequestPolicyCookieBehavior = "none" | "whitelist" | "all" | "allExcept" | (string & {});
export declare const OriginRequestPolicyCookieBehavior: any;
export interface OriginRequestPolicyCookiesConfig {
    CookieBehavior: OriginRequestPolicyCookieBehavior;
    Cookies?: CookieNames;
}
export declare const OriginRequestPolicyCookiesConfig: S.Schema<OriginRequestPolicyCookiesConfig>;
export type OriginRequestPolicyQueryStringBehavior = "none" | "whitelist" | "all" | "allExcept" | (string & {});
export declare const OriginRequestPolicyQueryStringBehavior: any;
export interface OriginRequestPolicyQueryStringsConfig {
    QueryStringBehavior: OriginRequestPolicyQueryStringBehavior;
    QueryStrings?: QueryStringNames;
}
export declare const OriginRequestPolicyQueryStringsConfig: S.Schema<OriginRequestPolicyQueryStringsConfig>;
export interface OriginRequestPolicyConfig {
    Comment?: string;
    Name: string;
    HeadersConfig: OriginRequestPolicyHeadersConfig;
    CookiesConfig: OriginRequestPolicyCookiesConfig;
    QueryStringsConfig: OriginRequestPolicyQueryStringsConfig;
}
export declare const OriginRequestPolicyConfig: S.Schema<OriginRequestPolicyConfig>;
export interface CreateOriginRequestPolicyRequest {
    OriginRequestPolicyConfig: OriginRequestPolicyConfig;
}
export declare const CreateOriginRequestPolicyRequest: S.Schema<CreateOriginRequestPolicyRequest>;
export interface OriginRequestPolicy {
    Id: string;
    LastModifiedTime: Date;
    OriginRequestPolicyConfig: OriginRequestPolicyConfig;
}
export declare const OriginRequestPolicy: S.Schema<OriginRequestPolicy>;
export interface CreateOriginRequestPolicyResult {
    OriginRequestPolicy?: OriginRequestPolicy;
    Location?: string;
    ETag?: string;
}
export declare const CreateOriginRequestPolicyResult: S.Schema<CreateOriginRequestPolicyResult>;
export interface PublicKeyConfig {
    CallerReference: string;
    Name: string;
    EncodedKey: string;
    Comment?: string;
}
export declare const PublicKeyConfig: S.Schema<PublicKeyConfig>;
export interface CreatePublicKeyRequest {
    PublicKeyConfig: PublicKeyConfig;
}
export declare const CreatePublicKeyRequest: S.Schema<CreatePublicKeyRequest>;
export interface PublicKey {
    Id: string;
    CreatedTime: Date;
    PublicKeyConfig: PublicKeyConfig;
}
export declare const PublicKey: S.Schema<PublicKey>;
export interface CreatePublicKeyResult {
    PublicKey?: PublicKey;
    Location?: string;
    ETag?: string;
}
export declare const CreatePublicKeyResult: S.Schema<CreatePublicKeyResult>;
export interface KinesisStreamConfig {
    RoleARN: string;
    StreamARN: string;
}
export declare const KinesisStreamConfig: S.Schema<KinesisStreamConfig>;
export interface EndPoint {
    StreamType: string;
    KinesisStreamConfig?: KinesisStreamConfig;
}
export declare const EndPoint: S.Schema<EndPoint>;
export type EndPointList = EndPoint[];
export declare const EndPointList: any;
export type FieldList = string[];
export declare const FieldList: any;
export interface CreateRealtimeLogConfigRequest {
    EndPoints: EndPoint[];
    Fields: string[];
    Name: string;
    SamplingRate: number;
}
export declare const CreateRealtimeLogConfigRequest: S.Schema<CreateRealtimeLogConfigRequest>;
export interface RealtimeLogConfig {
    ARN: string;
    Name: string;
    SamplingRate: number;
    EndPoints: EndPoint[];
    Fields: string[];
}
export declare const RealtimeLogConfig: S.Schema<RealtimeLogConfig>;
export interface CreateRealtimeLogConfigResult {
    RealtimeLogConfig?: RealtimeLogConfig;
}
export declare const CreateRealtimeLogConfigResult: S.Schema<CreateRealtimeLogConfigResult>;
export type AccessControlAllowOriginsList = string[];
export declare const AccessControlAllowOriginsList: any;
export interface ResponseHeadersPolicyAccessControlAllowOrigins {
    Quantity: number;
    Items: string[];
}
export declare const ResponseHeadersPolicyAccessControlAllowOrigins: S.Schema<ResponseHeadersPolicyAccessControlAllowOrigins>;
export type AccessControlAllowHeadersList = string[];
export declare const AccessControlAllowHeadersList: any;
export interface ResponseHeadersPolicyAccessControlAllowHeaders {
    Quantity: number;
    Items: string[];
}
export declare const ResponseHeadersPolicyAccessControlAllowHeaders: S.Schema<ResponseHeadersPolicyAccessControlAllowHeaders>;
export type ResponseHeadersPolicyAccessControlAllowMethodsValues = "GET" | "POST" | "OPTIONS" | "PUT" | "DELETE" | "PATCH" | "HEAD" | "ALL" | (string & {});
export declare const ResponseHeadersPolicyAccessControlAllowMethodsValues: any;
export type AccessControlAllowMethodsList = ResponseHeadersPolicyAccessControlAllowMethodsValues[];
export declare const AccessControlAllowMethodsList: any;
export interface ResponseHeadersPolicyAccessControlAllowMethods {
    Quantity: number;
    Items: ResponseHeadersPolicyAccessControlAllowMethodsValues[];
}
export declare const ResponseHeadersPolicyAccessControlAllowMethods: S.Schema<ResponseHeadersPolicyAccessControlAllowMethods>;
export type AccessControlExposeHeadersList = string[];
export declare const AccessControlExposeHeadersList: any;
export interface ResponseHeadersPolicyAccessControlExposeHeaders {
    Quantity: number;
    Items?: string[];
}
export declare const ResponseHeadersPolicyAccessControlExposeHeaders: S.Schema<ResponseHeadersPolicyAccessControlExposeHeaders>;
export interface ResponseHeadersPolicyCorsConfig {
    AccessControlAllowOrigins: ResponseHeadersPolicyAccessControlAllowOrigins;
    AccessControlAllowHeaders: ResponseHeadersPolicyAccessControlAllowHeaders;
    AccessControlAllowMethods: ResponseHeadersPolicyAccessControlAllowMethods;
    AccessControlAllowCredentials: boolean;
    AccessControlExposeHeaders?: ResponseHeadersPolicyAccessControlExposeHeaders;
    AccessControlMaxAgeSec?: number;
    OriginOverride: boolean;
}
export declare const ResponseHeadersPolicyCorsConfig: S.Schema<ResponseHeadersPolicyCorsConfig>;
export interface ResponseHeadersPolicyXSSProtection {
    Override: boolean;
    Protection: boolean;
    ModeBlock?: boolean;
    ReportUri?: string;
}
export declare const ResponseHeadersPolicyXSSProtection: S.Schema<ResponseHeadersPolicyXSSProtection>;
export type FrameOptionsList = "DENY" | "SAMEORIGIN" | (string & {});
export declare const FrameOptionsList: any;
export interface ResponseHeadersPolicyFrameOptions {
    Override: boolean;
    FrameOption: FrameOptionsList;
}
export declare const ResponseHeadersPolicyFrameOptions: S.Schema<ResponseHeadersPolicyFrameOptions>;
export type ReferrerPolicyList = "no-referrer" | "no-referrer-when-downgrade" | "origin" | "origin-when-cross-origin" | "same-origin" | "strict-origin" | "strict-origin-when-cross-origin" | "unsafe-url" | (string & {});
export declare const ReferrerPolicyList: any;
export interface ResponseHeadersPolicyReferrerPolicy {
    Override: boolean;
    ReferrerPolicy: ReferrerPolicyList;
}
export declare const ResponseHeadersPolicyReferrerPolicy: S.Schema<ResponseHeadersPolicyReferrerPolicy>;
export interface ResponseHeadersPolicyContentSecurityPolicy {
    Override: boolean;
    ContentSecurityPolicy: string;
}
export declare const ResponseHeadersPolicyContentSecurityPolicy: S.Schema<ResponseHeadersPolicyContentSecurityPolicy>;
export interface ResponseHeadersPolicyContentTypeOptions {
    Override: boolean;
}
export declare const ResponseHeadersPolicyContentTypeOptions: S.Schema<ResponseHeadersPolicyContentTypeOptions>;
export interface ResponseHeadersPolicyStrictTransportSecurity {
    Override: boolean;
    IncludeSubdomains?: boolean;
    Preload?: boolean;
    AccessControlMaxAgeSec: number;
}
export declare const ResponseHeadersPolicyStrictTransportSecurity: S.Schema<ResponseHeadersPolicyStrictTransportSecurity>;
export interface ResponseHeadersPolicySecurityHeadersConfig {
    XSSProtection?: ResponseHeadersPolicyXSSProtection;
    FrameOptions?: ResponseHeadersPolicyFrameOptions;
    ReferrerPolicy?: ResponseHeadersPolicyReferrerPolicy;
    ContentSecurityPolicy?: ResponseHeadersPolicyContentSecurityPolicy;
    ContentTypeOptions?: ResponseHeadersPolicyContentTypeOptions;
    StrictTransportSecurity?: ResponseHeadersPolicyStrictTransportSecurity;
}
export declare const ResponseHeadersPolicySecurityHeadersConfig: S.Schema<ResponseHeadersPolicySecurityHeadersConfig>;
export type SamplingRate = number;
export interface ResponseHeadersPolicyServerTimingHeadersConfig {
    Enabled: boolean;
    SamplingRate?: number;
}
export declare const ResponseHeadersPolicyServerTimingHeadersConfig: S.Schema<ResponseHeadersPolicyServerTimingHeadersConfig>;
export interface ResponseHeadersPolicyCustomHeader {
    Header: string;
    Value: string;
    Override: boolean;
}
export declare const ResponseHeadersPolicyCustomHeader: S.Schema<ResponseHeadersPolicyCustomHeader>;
export type ResponseHeadersPolicyCustomHeaderList = ResponseHeadersPolicyCustomHeader[];
export declare const ResponseHeadersPolicyCustomHeaderList: any;
export interface ResponseHeadersPolicyCustomHeadersConfig {
    Quantity: number;
    Items?: ResponseHeadersPolicyCustomHeader[];
}
export declare const ResponseHeadersPolicyCustomHeadersConfig: S.Schema<ResponseHeadersPolicyCustomHeadersConfig>;
export interface ResponseHeadersPolicyRemoveHeader {
    Header: string;
}
export declare const ResponseHeadersPolicyRemoveHeader: S.Schema<ResponseHeadersPolicyRemoveHeader>;
export type ResponseHeadersPolicyRemoveHeaderList = ResponseHeadersPolicyRemoveHeader[];
export declare const ResponseHeadersPolicyRemoveHeaderList: any;
export interface ResponseHeadersPolicyRemoveHeadersConfig {
    Quantity: number;
    Items?: ResponseHeadersPolicyRemoveHeader[];
}
export declare const ResponseHeadersPolicyRemoveHeadersConfig: S.Schema<ResponseHeadersPolicyRemoveHeadersConfig>;
export interface ResponseHeadersPolicyConfig {
    Comment?: string;
    Name: string;
    CorsConfig?: ResponseHeadersPolicyCorsConfig;
    SecurityHeadersConfig?: ResponseHeadersPolicySecurityHeadersConfig;
    ServerTimingHeadersConfig?: ResponseHeadersPolicyServerTimingHeadersConfig;
    CustomHeadersConfig?: ResponseHeadersPolicyCustomHeadersConfig;
    RemoveHeadersConfig?: ResponseHeadersPolicyRemoveHeadersConfig;
}
export declare const ResponseHeadersPolicyConfig: S.Schema<ResponseHeadersPolicyConfig>;
export interface CreateResponseHeadersPolicyRequest {
    ResponseHeadersPolicyConfig: ResponseHeadersPolicyConfig;
}
export declare const CreateResponseHeadersPolicyRequest: S.Schema<CreateResponseHeadersPolicyRequest>;
export interface ResponseHeadersPolicy {
    Id: string;
    LastModifiedTime: Date;
    ResponseHeadersPolicyConfig: ResponseHeadersPolicyConfig;
}
export declare const ResponseHeadersPolicy: S.Schema<ResponseHeadersPolicy>;
export interface CreateResponseHeadersPolicyResult {
    ResponseHeadersPolicy?: ResponseHeadersPolicy;
    Location?: string;
    ETag?: string;
}
export declare const CreateResponseHeadersPolicyResult: S.Schema<CreateResponseHeadersPolicyResult>;
export interface S3Origin {
    DomainName: string;
    OriginAccessIdentity: string;
}
export declare const S3Origin: S.Schema<S3Origin>;
export interface StreamingLoggingConfig {
    Enabled: boolean;
    Bucket: string;
    Prefix: string;
}
export declare const StreamingLoggingConfig: S.Schema<StreamingLoggingConfig>;
export interface StreamingDistributionConfig {
    CallerReference: string;
    S3Origin: S3Origin;
    Aliases?: Aliases;
    Comment: string;
    Logging?: StreamingLoggingConfig;
    TrustedSigners: TrustedSigners;
    PriceClass?: PriceClass;
    Enabled: boolean;
}
export declare const StreamingDistributionConfig: S.Schema<StreamingDistributionConfig>;
export interface CreateStreamingDistributionRequest {
    StreamingDistributionConfig: StreamingDistributionConfig;
}
export declare const CreateStreamingDistributionRequest: S.Schema<CreateStreamingDistributionRequest>;
export interface StreamingDistribution {
    Id: string;
    ARN: string;
    Status: string;
    LastModifiedTime?: Date;
    DomainName: string;
    ActiveTrustedSigners: ActiveTrustedSigners;
    StreamingDistributionConfig: StreamingDistributionConfig;
}
export declare const StreamingDistribution: S.Schema<StreamingDistribution>;
export interface CreateStreamingDistributionResult {
    StreamingDistribution?: StreamingDistribution;
    Location?: string;
    ETag?: string;
}
export declare const CreateStreamingDistributionResult: S.Schema<CreateStreamingDistributionResult>;
export interface StreamingDistributionConfigWithTags {
    StreamingDistributionConfig: StreamingDistributionConfig;
    Tags: Tags;
}
export declare const StreamingDistributionConfigWithTags: S.Schema<StreamingDistributionConfigWithTags>;
export interface CreateStreamingDistributionWithTagsRequest {
    StreamingDistributionConfigWithTags: StreamingDistributionConfigWithTags;
}
export declare const CreateStreamingDistributionWithTagsRequest: S.Schema<CreateStreamingDistributionWithTagsRequest>;
export interface CreateStreamingDistributionWithTagsResult {
    StreamingDistribution?: StreamingDistribution;
    Location?: string;
    ETag?: string;
}
export declare const CreateStreamingDistributionWithTagsResult: S.Schema<CreateStreamingDistributionWithTagsResult>;
export interface CaCertificatesBundleS3Location {
    Bucket: string;
    Key: string;
    Region: string;
    Version?: string;
}
export declare const CaCertificatesBundleS3Location: S.Schema<CaCertificatesBundleS3Location>;
export type CaCertificatesBundleSource = {
    CaCertificatesBundleS3Location: CaCertificatesBundleS3Location;
};
export declare const CaCertificatesBundleSource: any;
export interface CreateTrustStoreRequest {
    Name: string;
    CaCertificatesBundleSource: CaCertificatesBundleSource;
    UseClientCertificateOCSPEndpoint?: boolean;
    Tags?: Tags;
}
export declare const CreateTrustStoreRequest: S.Schema<CreateTrustStoreRequest>;
export type TrustStoreStatus = "pending" | "active" | "failed" | (string & {});
export declare const TrustStoreStatus: any;
export interface TrustStore {
    Id?: string;
    Arn?: string;
    Name?: string;
    Status?: TrustStoreStatus;
    NumberOfCaCertificates?: number;
    LastModifiedTime?: Date;
    Reason?: string;
    UseClientCertificateOCSPEndpoint?: boolean;
}
export declare const TrustStore: S.Schema<TrustStore>;
export interface CreateTrustStoreResult {
    TrustStore?: TrustStore;
    ETag?: string;
}
export declare const CreateTrustStoreResult: S.Schema<CreateTrustStoreResult>;
export interface VpcOriginEndpointConfig {
    Name: string;
    Arn: string;
    HTTPPort: number;
    HTTPSPort: number;
    OriginProtocolPolicy: OriginProtocolPolicy;
    OriginSslProtocols?: OriginSslProtocols;
}
export declare const VpcOriginEndpointConfig: S.Schema<VpcOriginEndpointConfig>;
export interface CreateVpcOriginRequest {
    VpcOriginEndpointConfig: VpcOriginEndpointConfig;
    Tags?: Tags;
}
export declare const CreateVpcOriginRequest: S.Schema<CreateVpcOriginRequest>;
export interface VpcOrigin {
    Id: string;
    Arn: string;
    AccountId?: string;
    Status: string;
    CreatedTime: Date;
    LastModifiedTime: Date;
    VpcOriginEndpointConfig: VpcOriginEndpointConfig;
}
export declare const VpcOrigin: S.Schema<VpcOrigin>;
export interface CreateVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    Location?: string;
    ETag?: string;
}
export declare const CreateVpcOriginResult: S.Schema<CreateVpcOriginResult>;
export interface DeleteAnycastIpListRequest {
    Id: string;
    IfMatch: string;
}
export declare const DeleteAnycastIpListRequest: S.Schema<DeleteAnycastIpListRequest>;
export interface DeleteAnycastIpListResponse {
}
export declare const DeleteAnycastIpListResponse: S.Schema<DeleteAnycastIpListResponse>;
export interface DeleteCachePolicyRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteCachePolicyRequest: S.Schema<DeleteCachePolicyRequest>;
export interface DeleteCachePolicyResponse {
}
export declare const DeleteCachePolicyResponse: S.Schema<DeleteCachePolicyResponse>;
export interface DeleteCloudFrontOriginAccessIdentityRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteCloudFrontOriginAccessIdentityRequest: S.Schema<DeleteCloudFrontOriginAccessIdentityRequest>;
export interface DeleteCloudFrontOriginAccessIdentityResponse {
}
export declare const DeleteCloudFrontOriginAccessIdentityResponse: S.Schema<DeleteCloudFrontOriginAccessIdentityResponse>;
export interface DeleteConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
}
export declare const DeleteConnectionFunctionRequest: S.Schema<DeleteConnectionFunctionRequest>;
export interface DeleteConnectionFunctionResponse {
}
export declare const DeleteConnectionFunctionResponse: S.Schema<DeleteConnectionFunctionResponse>;
export interface DeleteConnectionGroupRequest {
    Id: string;
    IfMatch: string;
}
export declare const DeleteConnectionGroupRequest: S.Schema<DeleteConnectionGroupRequest>;
export interface DeleteConnectionGroupResponse {
}
export declare const DeleteConnectionGroupResponse: S.Schema<DeleteConnectionGroupResponse>;
export interface DeleteContinuousDeploymentPolicyRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteContinuousDeploymentPolicyRequest: S.Schema<DeleteContinuousDeploymentPolicyRequest>;
export interface DeleteContinuousDeploymentPolicyResponse {
}
export declare const DeleteContinuousDeploymentPolicyResponse: S.Schema<DeleteContinuousDeploymentPolicyResponse>;
export interface DeleteDistributionRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteDistributionRequest: S.Schema<DeleteDistributionRequest>;
export interface DeleteDistributionResponse {
}
export declare const DeleteDistributionResponse: S.Schema<DeleteDistributionResponse>;
export interface DeleteDistributionTenantRequest {
    Id: string;
    IfMatch: string;
}
export declare const DeleteDistributionTenantRequest: S.Schema<DeleteDistributionTenantRequest>;
export interface DeleteDistributionTenantResponse {
}
export declare const DeleteDistributionTenantResponse: S.Schema<DeleteDistributionTenantResponse>;
export interface DeleteFieldLevelEncryptionConfigRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteFieldLevelEncryptionConfigRequest: S.Schema<DeleteFieldLevelEncryptionConfigRequest>;
export interface DeleteFieldLevelEncryptionConfigResponse {
}
export declare const DeleteFieldLevelEncryptionConfigResponse: S.Schema<DeleteFieldLevelEncryptionConfigResponse>;
export interface DeleteFieldLevelEncryptionProfileRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteFieldLevelEncryptionProfileRequest: S.Schema<DeleteFieldLevelEncryptionProfileRequest>;
export interface DeleteFieldLevelEncryptionProfileResponse {
}
export declare const DeleteFieldLevelEncryptionProfileResponse: S.Schema<DeleteFieldLevelEncryptionProfileResponse>;
export interface DeleteFunctionRequest {
    Name: string;
    IfMatch: string;
}
export declare const DeleteFunctionRequest: S.Schema<DeleteFunctionRequest>;
export interface DeleteFunctionResponse {
}
export declare const DeleteFunctionResponse: S.Schema<DeleteFunctionResponse>;
export interface DeleteKeyGroupRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteKeyGroupRequest: S.Schema<DeleteKeyGroupRequest>;
export interface DeleteKeyGroupResponse {
}
export declare const DeleteKeyGroupResponse: S.Schema<DeleteKeyGroupResponse>;
export interface DeleteKeyValueStoreRequest {
    Name: string;
    IfMatch: string;
}
export declare const DeleteKeyValueStoreRequest: S.Schema<DeleteKeyValueStoreRequest>;
export interface DeleteKeyValueStoreResponse {
}
export declare const DeleteKeyValueStoreResponse: S.Schema<DeleteKeyValueStoreResponse>;
export interface DeleteMonitoringSubscriptionRequest {
    DistributionId: string;
}
export declare const DeleteMonitoringSubscriptionRequest: S.Schema<DeleteMonitoringSubscriptionRequest>;
export interface DeleteMonitoringSubscriptionResult {
}
export declare const DeleteMonitoringSubscriptionResult: S.Schema<DeleteMonitoringSubscriptionResult>;
export interface DeleteOriginAccessControlRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteOriginAccessControlRequest: S.Schema<DeleteOriginAccessControlRequest>;
export interface DeleteOriginAccessControlResponse {
}
export declare const DeleteOriginAccessControlResponse: S.Schema<DeleteOriginAccessControlResponse>;
export interface DeleteOriginRequestPolicyRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteOriginRequestPolicyRequest: S.Schema<DeleteOriginRequestPolicyRequest>;
export interface DeleteOriginRequestPolicyResponse {
}
export declare const DeleteOriginRequestPolicyResponse: S.Schema<DeleteOriginRequestPolicyResponse>;
export interface DeletePublicKeyRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeletePublicKeyRequest: S.Schema<DeletePublicKeyRequest>;
export interface DeletePublicKeyResponse {
}
export declare const DeletePublicKeyResponse: S.Schema<DeletePublicKeyResponse>;
export interface DeleteRealtimeLogConfigRequest {
    Name?: string;
    ARN?: string;
}
export declare const DeleteRealtimeLogConfigRequest: S.Schema<DeleteRealtimeLogConfigRequest>;
export interface DeleteRealtimeLogConfigResponse {
}
export declare const DeleteRealtimeLogConfigResponse: S.Schema<DeleteRealtimeLogConfigResponse>;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DeleteResponseHeadersPolicyRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteResponseHeadersPolicyRequest: S.Schema<DeleteResponseHeadersPolicyRequest>;
export interface DeleteResponseHeadersPolicyResponse {
}
export declare const DeleteResponseHeadersPolicyResponse: S.Schema<DeleteResponseHeadersPolicyResponse>;
export interface DeleteStreamingDistributionRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DeleteStreamingDistributionRequest: S.Schema<DeleteStreamingDistributionRequest>;
export interface DeleteStreamingDistributionResponse {
}
export declare const DeleteStreamingDistributionResponse: S.Schema<DeleteStreamingDistributionResponse>;
export interface DeleteTrustStoreRequest {
    Id: string;
    IfMatch: string;
}
export declare const DeleteTrustStoreRequest: S.Schema<DeleteTrustStoreRequest>;
export interface DeleteTrustStoreResponse {
}
export declare const DeleteTrustStoreResponse: S.Schema<DeleteTrustStoreResponse>;
export interface DeleteVpcOriginRequest {
    Id: string;
    IfMatch: string;
}
export declare const DeleteVpcOriginRequest: S.Schema<DeleteVpcOriginRequest>;
export interface DeleteVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    ETag?: string;
}
export declare const DeleteVpcOriginResult: S.Schema<DeleteVpcOriginResult>;
export interface DescribeConnectionFunctionRequest {
    Identifier: string;
    Stage?: FunctionStage;
}
export declare const DescribeConnectionFunctionRequest: S.Schema<DescribeConnectionFunctionRequest>;
export interface DescribeConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    ETag?: string;
}
export declare const DescribeConnectionFunctionResult: S.Schema<DescribeConnectionFunctionResult>;
export interface DescribeFunctionRequest {
    Name: string;
    Stage?: FunctionStage;
}
export declare const DescribeFunctionRequest: S.Schema<DescribeFunctionRequest>;
export interface DescribeFunctionResult {
    FunctionSummary?: FunctionSummary;
    ETag?: string;
}
export declare const DescribeFunctionResult: S.Schema<DescribeFunctionResult>;
export interface DescribeKeyValueStoreRequest {
    Name: string;
}
export declare const DescribeKeyValueStoreRequest: S.Schema<DescribeKeyValueStoreRequest>;
export interface DescribeKeyValueStoreResult {
    KeyValueStore?: KeyValueStore;
    ETag?: string;
}
export declare const DescribeKeyValueStoreResult: S.Schema<DescribeKeyValueStoreResult>;
export interface DisassociateDistributionTenantWebACLRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DisassociateDistributionTenantWebACLRequest: S.Schema<DisassociateDistributionTenantWebACLRequest>;
export interface DisassociateDistributionTenantWebACLResult {
    Id?: string;
    ETag?: string;
}
export declare const DisassociateDistributionTenantWebACLResult: S.Schema<DisassociateDistributionTenantWebACLResult>;
export interface DisassociateDistributionWebACLRequest {
    Id: string;
    IfMatch?: string;
}
export declare const DisassociateDistributionWebACLRequest: S.Schema<DisassociateDistributionWebACLRequest>;
export interface DisassociateDistributionWebACLResult {
    Id?: string;
    ETag?: string;
}
export declare const DisassociateDistributionWebACLResult: S.Schema<DisassociateDistributionWebACLResult>;
export interface GetAnycastIpListRequest {
    Id: string;
}
export declare const GetAnycastIpListRequest: S.Schema<GetAnycastIpListRequest>;
export interface GetAnycastIpListResult {
    AnycastIpList?: AnycastIpList;
    ETag?: string;
}
export declare const GetAnycastIpListResult: S.Schema<GetAnycastIpListResult>;
export interface GetCachePolicyRequest {
    Id: string;
}
export declare const GetCachePolicyRequest: S.Schema<GetCachePolicyRequest>;
export interface GetCachePolicyResult {
    CachePolicy?: CachePolicy;
    ETag?: string;
}
export declare const GetCachePolicyResult: S.Schema<GetCachePolicyResult>;
export interface GetCachePolicyConfigRequest {
    Id: string;
}
export declare const GetCachePolicyConfigRequest: S.Schema<GetCachePolicyConfigRequest>;
export interface GetCachePolicyConfigResult {
    CachePolicyConfig?: CachePolicyConfig;
    ETag?: string;
}
export declare const GetCachePolicyConfigResult: S.Schema<GetCachePolicyConfigResult>;
export interface GetCloudFrontOriginAccessIdentityRequest {
    Id: string;
}
export declare const GetCloudFrontOriginAccessIdentityRequest: S.Schema<GetCloudFrontOriginAccessIdentityRequest>;
export interface GetCloudFrontOriginAccessIdentityResult {
    CloudFrontOriginAccessIdentity?: CloudFrontOriginAccessIdentity;
    ETag?: string;
}
export declare const GetCloudFrontOriginAccessIdentityResult: S.Schema<GetCloudFrontOriginAccessIdentityResult>;
export interface GetCloudFrontOriginAccessIdentityConfigRequest {
    Id: string;
}
export declare const GetCloudFrontOriginAccessIdentityConfigRequest: S.Schema<GetCloudFrontOriginAccessIdentityConfigRequest>;
export interface GetCloudFrontOriginAccessIdentityConfigResult {
    CloudFrontOriginAccessIdentityConfig?: CloudFrontOriginAccessIdentityConfig;
    ETag?: string;
}
export declare const GetCloudFrontOriginAccessIdentityConfigResult: S.Schema<GetCloudFrontOriginAccessIdentityConfigResult>;
export interface GetConnectionFunctionRequest {
    Identifier: string;
    Stage?: FunctionStage;
}
export declare const GetConnectionFunctionRequest: S.Schema<GetConnectionFunctionRequest>;
export interface GetConnectionFunctionResult {
    ConnectionFunctionCode?: T.StreamingOutputBody;
    ETag?: string;
    ContentType?: string;
}
export declare const GetConnectionFunctionResult: S.Schema<GetConnectionFunctionResult>;
export interface GetConnectionGroupRequest {
    Identifier: string;
}
export declare const GetConnectionGroupRequest: S.Schema<GetConnectionGroupRequest>;
export interface GetConnectionGroupResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export declare const GetConnectionGroupResult: S.Schema<GetConnectionGroupResult>;
export interface GetConnectionGroupByRoutingEndpointRequest {
    RoutingEndpoint: string;
}
export declare const GetConnectionGroupByRoutingEndpointRequest: S.Schema<GetConnectionGroupByRoutingEndpointRequest>;
export interface GetConnectionGroupByRoutingEndpointResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export declare const GetConnectionGroupByRoutingEndpointResult: S.Schema<GetConnectionGroupByRoutingEndpointResult>;
export interface GetContinuousDeploymentPolicyRequest {
    Id: string;
}
export declare const GetContinuousDeploymentPolicyRequest: S.Schema<GetContinuousDeploymentPolicyRequest>;
export interface GetContinuousDeploymentPolicyResult {
    ContinuousDeploymentPolicy?: ContinuousDeploymentPolicy;
    ETag?: string;
}
export declare const GetContinuousDeploymentPolicyResult: S.Schema<GetContinuousDeploymentPolicyResult>;
export interface GetContinuousDeploymentPolicyConfigRequest {
    Id: string;
}
export declare const GetContinuousDeploymentPolicyConfigRequest: S.Schema<GetContinuousDeploymentPolicyConfigRequest>;
export interface GetContinuousDeploymentPolicyConfigResult {
    ContinuousDeploymentPolicyConfig?: ContinuousDeploymentPolicyConfig;
    ETag?: string;
}
export declare const GetContinuousDeploymentPolicyConfigResult: S.Schema<GetContinuousDeploymentPolicyConfigResult>;
export interface GetDistributionRequest {
    Id: string;
}
export declare const GetDistributionRequest: S.Schema<GetDistributionRequest>;
export interface GetDistributionResult {
    Distribution?: Distribution;
    ETag?: string;
}
export declare const GetDistributionResult: S.Schema<GetDistributionResult>;
export interface GetDistributionConfigRequest {
    Id: string;
}
export declare const GetDistributionConfigRequest: S.Schema<GetDistributionConfigRequest>;
export interface GetDistributionConfigResult {
    DistributionConfig?: DistributionConfig;
    ETag?: string;
}
export declare const GetDistributionConfigResult: S.Schema<GetDistributionConfigResult>;
export interface GetDistributionTenantRequest {
    Identifier: string;
}
export declare const GetDistributionTenantRequest: S.Schema<GetDistributionTenantRequest>;
export interface GetDistributionTenantResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export declare const GetDistributionTenantResult: S.Schema<GetDistributionTenantResult>;
export interface GetDistributionTenantByDomainRequest {
    Domain: string;
}
export declare const GetDistributionTenantByDomainRequest: S.Schema<GetDistributionTenantByDomainRequest>;
export interface GetDistributionTenantByDomainResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export declare const GetDistributionTenantByDomainResult: S.Schema<GetDistributionTenantByDomainResult>;
export interface GetFieldLevelEncryptionRequest {
    Id: string;
}
export declare const GetFieldLevelEncryptionRequest: S.Schema<GetFieldLevelEncryptionRequest>;
export interface GetFieldLevelEncryptionResult {
    FieldLevelEncryption?: FieldLevelEncryption;
    ETag?: string;
}
export declare const GetFieldLevelEncryptionResult: S.Schema<GetFieldLevelEncryptionResult>;
export interface GetFieldLevelEncryptionConfigRequest {
    Id: string;
}
export declare const GetFieldLevelEncryptionConfigRequest: S.Schema<GetFieldLevelEncryptionConfigRequest>;
export interface GetFieldLevelEncryptionConfigResult {
    FieldLevelEncryptionConfig?: FieldLevelEncryptionConfig;
    ETag?: string;
}
export declare const GetFieldLevelEncryptionConfigResult: S.Schema<GetFieldLevelEncryptionConfigResult>;
export interface GetFieldLevelEncryptionProfileRequest {
    Id: string;
}
export declare const GetFieldLevelEncryptionProfileRequest: S.Schema<GetFieldLevelEncryptionProfileRequest>;
export interface GetFieldLevelEncryptionProfileResult {
    FieldLevelEncryptionProfile?: FieldLevelEncryptionProfile;
    ETag?: string;
}
export declare const GetFieldLevelEncryptionProfileResult: S.Schema<GetFieldLevelEncryptionProfileResult>;
export interface GetFieldLevelEncryptionProfileConfigRequest {
    Id: string;
}
export declare const GetFieldLevelEncryptionProfileConfigRequest: S.Schema<GetFieldLevelEncryptionProfileConfigRequest>;
export interface GetFieldLevelEncryptionProfileConfigResult {
    FieldLevelEncryptionProfileConfig?: FieldLevelEncryptionProfileConfig;
    ETag?: string;
}
export declare const GetFieldLevelEncryptionProfileConfigResult: S.Schema<GetFieldLevelEncryptionProfileConfigResult>;
export interface GetFunctionRequest {
    Name: string;
    Stage?: FunctionStage;
}
export declare const GetFunctionRequest: S.Schema<GetFunctionRequest>;
export interface GetFunctionResult {
    FunctionCode?: T.StreamingOutputBody;
    ETag?: string;
    ContentType?: string;
}
export declare const GetFunctionResult: S.Schema<GetFunctionResult>;
export interface GetInvalidationRequest {
    DistributionId: string;
    Id: string;
}
export declare const GetInvalidationRequest: S.Schema<GetInvalidationRequest>;
export interface GetInvalidationResult {
    Invalidation?: Invalidation;
}
export declare const GetInvalidationResult: S.Schema<GetInvalidationResult>;
export interface GetInvalidationForDistributionTenantRequest {
    DistributionTenantId: string;
    Id: string;
}
export declare const GetInvalidationForDistributionTenantRequest: S.Schema<GetInvalidationForDistributionTenantRequest>;
export interface GetInvalidationForDistributionTenantResult {
    Invalidation?: Invalidation;
}
export declare const GetInvalidationForDistributionTenantResult: S.Schema<GetInvalidationForDistributionTenantResult>;
export interface GetKeyGroupRequest {
    Id: string;
}
export declare const GetKeyGroupRequest: S.Schema<GetKeyGroupRequest>;
export interface GetKeyGroupResult {
    KeyGroup?: KeyGroup;
    ETag?: string;
}
export declare const GetKeyGroupResult: S.Schema<GetKeyGroupResult>;
export interface GetKeyGroupConfigRequest {
    Id: string;
}
export declare const GetKeyGroupConfigRequest: S.Schema<GetKeyGroupConfigRequest>;
export interface GetKeyGroupConfigResult {
    KeyGroupConfig?: KeyGroupConfig;
    ETag?: string;
}
export declare const GetKeyGroupConfigResult: S.Schema<GetKeyGroupConfigResult>;
export interface GetManagedCertificateDetailsRequest {
    Identifier: string;
}
export declare const GetManagedCertificateDetailsRequest: S.Schema<GetManagedCertificateDetailsRequest>;
export type ManagedCertificateStatus = "pending-validation" | "issued" | "inactive" | "expired" | "validation-timed-out" | "revoked" | "failed" | (string & {});
export declare const ManagedCertificateStatus: any;
export interface ValidationTokenDetail {
    Domain: string;
    RedirectTo?: string;
    RedirectFrom?: string;
}
export declare const ValidationTokenDetail: S.Schema<ValidationTokenDetail>;
export type ValidationTokenDetailList = ValidationTokenDetail[];
export declare const ValidationTokenDetailList: any;
export interface ManagedCertificateDetails {
    CertificateArn?: string;
    CertificateStatus?: ManagedCertificateStatus;
    ValidationTokenHost?: ValidationTokenHost;
    ValidationTokenDetails?: ValidationTokenDetail[];
}
export declare const ManagedCertificateDetails: S.Schema<ManagedCertificateDetails>;
export interface GetManagedCertificateDetailsResult {
    ManagedCertificateDetails?: ManagedCertificateDetails;
}
export declare const GetManagedCertificateDetailsResult: S.Schema<GetManagedCertificateDetailsResult>;
export interface GetMonitoringSubscriptionRequest {
    DistributionId: string;
}
export declare const GetMonitoringSubscriptionRequest: S.Schema<GetMonitoringSubscriptionRequest>;
export interface GetMonitoringSubscriptionResult {
    MonitoringSubscription?: MonitoringSubscription;
}
export declare const GetMonitoringSubscriptionResult: S.Schema<GetMonitoringSubscriptionResult>;
export interface GetOriginAccessControlRequest {
    Id: string;
}
export declare const GetOriginAccessControlRequest: S.Schema<GetOriginAccessControlRequest>;
export interface GetOriginAccessControlResult {
    OriginAccessControl?: OriginAccessControl;
    ETag?: string;
}
export declare const GetOriginAccessControlResult: S.Schema<GetOriginAccessControlResult>;
export interface GetOriginAccessControlConfigRequest {
    Id: string;
}
export declare const GetOriginAccessControlConfigRequest: S.Schema<GetOriginAccessControlConfigRequest>;
export interface GetOriginAccessControlConfigResult {
    OriginAccessControlConfig?: OriginAccessControlConfig;
    ETag?: string;
}
export declare const GetOriginAccessControlConfigResult: S.Schema<GetOriginAccessControlConfigResult>;
export interface GetOriginRequestPolicyRequest {
    Id: string;
}
export declare const GetOriginRequestPolicyRequest: S.Schema<GetOriginRequestPolicyRequest>;
export interface GetOriginRequestPolicyResult {
    OriginRequestPolicy?: OriginRequestPolicy;
    ETag?: string;
}
export declare const GetOriginRequestPolicyResult: S.Schema<GetOriginRequestPolicyResult>;
export interface GetOriginRequestPolicyConfigRequest {
    Id: string;
}
export declare const GetOriginRequestPolicyConfigRequest: S.Schema<GetOriginRequestPolicyConfigRequest>;
export interface GetOriginRequestPolicyConfigResult {
    OriginRequestPolicyConfig?: OriginRequestPolicyConfig;
    ETag?: string;
}
export declare const GetOriginRequestPolicyConfigResult: S.Schema<GetOriginRequestPolicyConfigResult>;
export interface GetPublicKeyRequest {
    Id: string;
}
export declare const GetPublicKeyRequest: S.Schema<GetPublicKeyRequest>;
export interface GetPublicKeyResult {
    PublicKey?: PublicKey;
    ETag?: string;
}
export declare const GetPublicKeyResult: S.Schema<GetPublicKeyResult>;
export interface GetPublicKeyConfigRequest {
    Id: string;
}
export declare const GetPublicKeyConfigRequest: S.Schema<GetPublicKeyConfigRequest>;
export interface GetPublicKeyConfigResult {
    PublicKeyConfig?: PublicKeyConfig;
    ETag?: string;
}
export declare const GetPublicKeyConfigResult: S.Schema<GetPublicKeyConfigResult>;
export interface GetRealtimeLogConfigRequest {
    Name?: string;
    ARN?: string;
}
export declare const GetRealtimeLogConfigRequest: S.Schema<GetRealtimeLogConfigRequest>;
export interface GetRealtimeLogConfigResult {
    RealtimeLogConfig?: RealtimeLogConfig;
}
export declare const GetRealtimeLogConfigResult: S.Schema<GetRealtimeLogConfigResult>;
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export interface GetResourcePolicyResult {
    ResourceArn?: string;
    PolicyDocument?: string;
}
export declare const GetResourcePolicyResult: S.Schema<GetResourcePolicyResult>;
export interface GetResponseHeadersPolicyRequest {
    Id: string;
}
export declare const GetResponseHeadersPolicyRequest: S.Schema<GetResponseHeadersPolicyRequest>;
export interface GetResponseHeadersPolicyResult {
    ResponseHeadersPolicy?: ResponseHeadersPolicy;
    ETag?: string;
}
export declare const GetResponseHeadersPolicyResult: S.Schema<GetResponseHeadersPolicyResult>;
export interface GetResponseHeadersPolicyConfigRequest {
    Id: string;
}
export declare const GetResponseHeadersPolicyConfigRequest: S.Schema<GetResponseHeadersPolicyConfigRequest>;
export interface GetResponseHeadersPolicyConfigResult {
    ResponseHeadersPolicyConfig?: ResponseHeadersPolicyConfig;
    ETag?: string;
}
export declare const GetResponseHeadersPolicyConfigResult: S.Schema<GetResponseHeadersPolicyConfigResult>;
export interface GetStreamingDistributionRequest {
    Id: string;
}
export declare const GetStreamingDistributionRequest: S.Schema<GetStreamingDistributionRequest>;
export interface GetStreamingDistributionResult {
    StreamingDistribution?: StreamingDistribution;
    ETag?: string;
}
export declare const GetStreamingDistributionResult: S.Schema<GetStreamingDistributionResult>;
export interface GetStreamingDistributionConfigRequest {
    Id: string;
}
export declare const GetStreamingDistributionConfigRequest: S.Schema<GetStreamingDistributionConfigRequest>;
export interface GetStreamingDistributionConfigResult {
    StreamingDistributionConfig?: StreamingDistributionConfig;
    ETag?: string;
}
export declare const GetStreamingDistributionConfigResult: S.Schema<GetStreamingDistributionConfigResult>;
export interface GetTrustStoreRequest {
    Identifier: string;
}
export declare const GetTrustStoreRequest: S.Schema<GetTrustStoreRequest>;
export interface GetTrustStoreResult {
    TrustStore?: TrustStore;
    ETag?: string;
}
export declare const GetTrustStoreResult: S.Schema<GetTrustStoreResult>;
export interface GetVpcOriginRequest {
    Id: string;
}
export declare const GetVpcOriginRequest: S.Schema<GetVpcOriginRequest>;
export interface GetVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    ETag?: string;
}
export declare const GetVpcOriginResult: S.Schema<GetVpcOriginResult>;
export interface ListAnycastIpListsRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListAnycastIpListsRequest: S.Schema<ListAnycastIpListsRequest>;
export interface AnycastIpListSummary {
    Id: string;
    Name: string;
    Status: string;
    Arn: string;
    IpCount: number;
    LastModifiedTime: Date;
    IpAddressType?: IpAddressType;
    ETag?: string;
    IpamConfig?: IpamConfig;
}
export declare const AnycastIpListSummary: S.Schema<AnycastIpListSummary>;
export type AnycastIpListSummaries = AnycastIpListSummary[];
export declare const AnycastIpListSummaries: any;
export interface AnycastIpListCollection {
    Items?: AnycastIpListSummary[];
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
}
export declare const AnycastIpListCollection: S.Schema<AnycastIpListCollection>;
export interface ListAnycastIpListsResult {
    AnycastIpLists?: AnycastIpListCollection;
}
export declare const ListAnycastIpListsResult: S.Schema<ListAnycastIpListsResult>;
export type CachePolicyType = "managed" | "custom" | (string & {});
export declare const CachePolicyType: any;
export interface ListCachePoliciesRequest {
    Type?: CachePolicyType;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListCachePoliciesRequest: S.Schema<ListCachePoliciesRequest>;
export interface CachePolicySummary {
    Type: CachePolicyType;
    CachePolicy: CachePolicy;
}
export declare const CachePolicySummary: S.Schema<CachePolicySummary>;
export type CachePolicySummaryList = CachePolicySummary[];
export declare const CachePolicySummaryList: any;
export interface CachePolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: CachePolicySummary[];
}
export declare const CachePolicyList: S.Schema<CachePolicyList>;
export interface ListCachePoliciesResult {
    CachePolicyList?: CachePolicyList;
}
export declare const ListCachePoliciesResult: S.Schema<ListCachePoliciesResult>;
export interface ListCloudFrontOriginAccessIdentitiesRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListCloudFrontOriginAccessIdentitiesRequest: S.Schema<ListCloudFrontOriginAccessIdentitiesRequest>;
export interface CloudFrontOriginAccessIdentitySummary {
    Id: string;
    S3CanonicalUserId: string;
    Comment: string;
}
export declare const CloudFrontOriginAccessIdentitySummary: S.Schema<CloudFrontOriginAccessIdentitySummary>;
export type CloudFrontOriginAccessIdentitySummaryList = CloudFrontOriginAccessIdentitySummary[];
export declare const CloudFrontOriginAccessIdentitySummaryList: any;
export interface CloudFrontOriginAccessIdentityList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: CloudFrontOriginAccessIdentitySummary[];
}
export declare const CloudFrontOriginAccessIdentityList: S.Schema<CloudFrontOriginAccessIdentityList>;
export interface ListCloudFrontOriginAccessIdentitiesResult {
    CloudFrontOriginAccessIdentityList?: CloudFrontOriginAccessIdentityList;
}
export declare const ListCloudFrontOriginAccessIdentitiesResult: S.Schema<ListCloudFrontOriginAccessIdentitiesResult>;
export type DistributionIdString = string;
export type AliasString = string;
export type ListConflictingAliasesMaxItemsInteger = number;
export interface ListConflictingAliasesRequest {
    DistributionId: string;
    Alias: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListConflictingAliasesRequest: S.Schema<ListConflictingAliasesRequest>;
export interface ConflictingAlias {
    Alias?: string;
    DistributionId?: string;
    AccountId?: string;
}
export declare const ConflictingAlias: S.Schema<ConflictingAlias>;
export type ConflictingAliases = ConflictingAlias[];
export declare const ConflictingAliases: any;
export interface ConflictingAliasesList {
    NextMarker?: string;
    MaxItems?: number;
    Quantity?: number;
    Items?: ConflictingAlias[];
}
export declare const ConflictingAliasesList: S.Schema<ConflictingAliasesList>;
export interface ListConflictingAliasesResult {
    ConflictingAliasesList?: ConflictingAliasesList;
}
export declare const ListConflictingAliasesResult: S.Schema<ListConflictingAliasesResult>;
export interface ListConnectionFunctionsRequest {
    Marker?: string;
    MaxItems?: number;
    Stage?: FunctionStage;
}
export declare const ListConnectionFunctionsRequest: S.Schema<ListConnectionFunctionsRequest>;
export type ConnectionFunctionSummaryList = ConnectionFunctionSummary[];
export declare const ConnectionFunctionSummaryList: any;
export interface ListConnectionFunctionsResult {
    NextMarker?: string;
    ConnectionFunctions?: ConnectionFunctionSummary[];
}
export declare const ListConnectionFunctionsResult: S.Schema<ListConnectionFunctionsResult>;
export interface ConnectionGroupAssociationFilter {
    AnycastIpListId?: string;
}
export declare const ConnectionGroupAssociationFilter: S.Schema<ConnectionGroupAssociationFilter>;
export interface ListConnectionGroupsRequest {
    AssociationFilter?: ConnectionGroupAssociationFilter;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListConnectionGroupsRequest: S.Schema<ListConnectionGroupsRequest>;
export interface ConnectionGroupSummary {
    Id: string;
    Name: string;
    Arn: string;
    RoutingEndpoint: string;
    CreatedTime: Date;
    LastModifiedTime: Date;
    ETag: string;
    AnycastIpListId?: string;
    Enabled?: boolean;
    Status?: string;
    IsDefault?: boolean;
}
export declare const ConnectionGroupSummary: S.Schema<ConnectionGroupSummary>;
export type ConnectionGroupSummaryList = ConnectionGroupSummary[];
export declare const ConnectionGroupSummaryList: any;
export interface ListConnectionGroupsResult {
    NextMarker?: string;
    ConnectionGroups?: ConnectionGroupSummary[];
}
export declare const ListConnectionGroupsResult: S.Schema<ListConnectionGroupsResult>;
export interface ListContinuousDeploymentPoliciesRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListContinuousDeploymentPoliciesRequest: S.Schema<ListContinuousDeploymentPoliciesRequest>;
export interface ContinuousDeploymentPolicySummary {
    ContinuousDeploymentPolicy: ContinuousDeploymentPolicy;
}
export declare const ContinuousDeploymentPolicySummary: S.Schema<ContinuousDeploymentPolicySummary>;
export type ContinuousDeploymentPolicySummaryList = ContinuousDeploymentPolicySummary[];
export declare const ContinuousDeploymentPolicySummaryList: any;
export interface ContinuousDeploymentPolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: ContinuousDeploymentPolicySummary[];
}
export declare const ContinuousDeploymentPolicyList: S.Schema<ContinuousDeploymentPolicyList>;
export interface ListContinuousDeploymentPoliciesResult {
    ContinuousDeploymentPolicyList?: ContinuousDeploymentPolicyList;
}
export declare const ListContinuousDeploymentPoliciesResult: S.Schema<ListContinuousDeploymentPoliciesResult>;
export interface ListDistributionsRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListDistributionsRequest: S.Schema<ListDistributionsRequest>;
export interface DistributionSummary {
    Id: string;
    ARN: string;
    ETag?: string;
    Status: string;
    LastModifiedTime: Date;
    DomainName: string;
    Aliases: Aliases;
    Origins: Origins;
    OriginGroups?: OriginGroups;
    DefaultCacheBehavior: DefaultCacheBehavior;
    CacheBehaviors: CacheBehaviors;
    CustomErrorResponses: CustomErrorResponses;
    Comment: string | redacted.Redacted<string>;
    PriceClass: PriceClass;
    Enabled: boolean;
    ViewerCertificate: ViewerCertificate;
    Restrictions: Restrictions;
    WebACLId?: string;
    HttpVersion: HttpVersion;
    IsIPV6Enabled: boolean;
    AliasICPRecordals?: AliasICPRecordal[];
    Staging: boolean;
    ConnectionMode?: ConnectionMode;
    AnycastIpListId?: string;
    ViewerMtlsConfig?: ViewerMtlsConfig;
    ConnectionFunctionAssociation?: ConnectionFunctionAssociation;
}
export declare const DistributionSummary: S.Schema<DistributionSummary>;
export type DistributionSummaryList = DistributionSummary[];
export declare const DistributionSummaryList: any;
export interface DistributionList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: DistributionSummary[];
}
export declare const DistributionList: S.Schema<DistributionList>;
export interface ListDistributionsResult {
    DistributionList?: DistributionList;
}
export declare const ListDistributionsResult: S.Schema<ListDistributionsResult>;
export interface ListDistributionsByAnycastIpListIdRequest {
    Marker?: string;
    MaxItems?: number;
    AnycastIpListId: string;
}
export declare const ListDistributionsByAnycastIpListIdRequest: S.Schema<ListDistributionsByAnycastIpListIdRequest>;
export interface ListDistributionsByAnycastIpListIdResult {
    DistributionList?: DistributionList;
}
export declare const ListDistributionsByAnycastIpListIdResult: S.Schema<ListDistributionsByAnycastIpListIdResult>;
export interface ListDistributionsByCachePolicyIdRequest {
    Marker?: string;
    MaxItems?: number;
    CachePolicyId: string;
}
export declare const ListDistributionsByCachePolicyIdRequest: S.Schema<ListDistributionsByCachePolicyIdRequest>;
export type DistributionIdListSummary = string[];
export declare const DistributionIdListSummary: any;
export interface DistributionIdList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: string[];
}
export declare const DistributionIdList: S.Schema<DistributionIdList>;
export interface ListDistributionsByCachePolicyIdResult {
    DistributionIdList?: DistributionIdList;
}
export declare const ListDistributionsByCachePolicyIdResult: S.Schema<ListDistributionsByCachePolicyIdResult>;
export interface ListDistributionsByConnectionFunctionRequest {
    Marker?: string;
    MaxItems?: number;
    ConnectionFunctionIdentifier: string;
}
export declare const ListDistributionsByConnectionFunctionRequest: S.Schema<ListDistributionsByConnectionFunctionRequest>;
export interface ListDistributionsByConnectionFunctionResult {
    DistributionList?: DistributionList;
}
export declare const ListDistributionsByConnectionFunctionResult: S.Schema<ListDistributionsByConnectionFunctionResult>;
export interface ListDistributionsByConnectionModeRequest {
    Marker?: string;
    MaxItems?: number;
    ConnectionMode: ConnectionMode;
}
export declare const ListDistributionsByConnectionModeRequest: S.Schema<ListDistributionsByConnectionModeRequest>;
export interface ListDistributionsByConnectionModeResult {
    DistributionList?: DistributionList;
}
export declare const ListDistributionsByConnectionModeResult: S.Schema<ListDistributionsByConnectionModeResult>;
export interface ListDistributionsByKeyGroupRequest {
    Marker?: string;
    MaxItems?: number;
    KeyGroupId: string;
}
export declare const ListDistributionsByKeyGroupRequest: S.Schema<ListDistributionsByKeyGroupRequest>;
export interface ListDistributionsByKeyGroupResult {
    DistributionIdList?: DistributionIdList;
}
export declare const ListDistributionsByKeyGroupResult: S.Schema<ListDistributionsByKeyGroupResult>;
export interface ListDistributionsByOriginRequestPolicyIdRequest {
    Marker?: string;
    MaxItems?: number;
    OriginRequestPolicyId: string;
}
export declare const ListDistributionsByOriginRequestPolicyIdRequest: S.Schema<ListDistributionsByOriginRequestPolicyIdRequest>;
export interface ListDistributionsByOriginRequestPolicyIdResult {
    DistributionIdList?: DistributionIdList;
}
export declare const ListDistributionsByOriginRequestPolicyIdResult: S.Schema<ListDistributionsByOriginRequestPolicyIdResult>;
export interface ListDistributionsByOwnedResourceRequest {
    ResourceArn: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListDistributionsByOwnedResourceRequest: S.Schema<ListDistributionsByOwnedResourceRequest>;
export interface DistributionIdOwner {
    DistributionId: string;
    OwnerAccountId: string;
}
export declare const DistributionIdOwner: S.Schema<DistributionIdOwner>;
export type DistributionIdOwnerItemList = DistributionIdOwner[];
export declare const DistributionIdOwnerItemList: any;
export interface DistributionIdOwnerList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: DistributionIdOwner[];
}
export declare const DistributionIdOwnerList: S.Schema<DistributionIdOwnerList>;
export interface ListDistributionsByOwnedResourceResult {
    DistributionList?: DistributionIdOwnerList;
}
export declare const ListDistributionsByOwnedResourceResult: S.Schema<ListDistributionsByOwnedResourceResult>;
export interface ListDistributionsByRealtimeLogConfigRequest {
    Marker?: string;
    MaxItems?: number;
    RealtimeLogConfigName?: string;
    RealtimeLogConfigArn?: string;
}
export declare const ListDistributionsByRealtimeLogConfigRequest: S.Schema<ListDistributionsByRealtimeLogConfigRequest>;
export interface ListDistributionsByRealtimeLogConfigResult {
    DistributionList?: DistributionList;
}
export declare const ListDistributionsByRealtimeLogConfigResult: S.Schema<ListDistributionsByRealtimeLogConfigResult>;
export interface ListDistributionsByResponseHeadersPolicyIdRequest {
    Marker?: string;
    MaxItems?: number;
    ResponseHeadersPolicyId: string;
}
export declare const ListDistributionsByResponseHeadersPolicyIdRequest: S.Schema<ListDistributionsByResponseHeadersPolicyIdRequest>;
export interface ListDistributionsByResponseHeadersPolicyIdResult {
    DistributionIdList?: DistributionIdList;
}
export declare const ListDistributionsByResponseHeadersPolicyIdResult: S.Schema<ListDistributionsByResponseHeadersPolicyIdResult>;
export interface ListDistributionsByTrustStoreRequest {
    TrustStoreIdentifier: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListDistributionsByTrustStoreRequest: S.Schema<ListDistributionsByTrustStoreRequest>;
export interface ListDistributionsByTrustStoreResult {
    DistributionList?: DistributionList;
}
export declare const ListDistributionsByTrustStoreResult: S.Schema<ListDistributionsByTrustStoreResult>;
export interface ListDistributionsByVpcOriginIdRequest {
    Marker?: string;
    MaxItems?: number;
    VpcOriginId: string;
}
export declare const ListDistributionsByVpcOriginIdRequest: S.Schema<ListDistributionsByVpcOriginIdRequest>;
export interface ListDistributionsByVpcOriginIdResult {
    DistributionIdList?: DistributionIdList;
}
export declare const ListDistributionsByVpcOriginIdResult: S.Schema<ListDistributionsByVpcOriginIdResult>;
export interface ListDistributionsByWebACLIdRequest {
    Marker?: string;
    MaxItems?: number;
    WebACLId: string;
}
export declare const ListDistributionsByWebACLIdRequest: S.Schema<ListDistributionsByWebACLIdRequest>;
export interface ListDistributionsByWebACLIdResult {
    DistributionList?: DistributionList;
}
export declare const ListDistributionsByWebACLIdResult: S.Schema<ListDistributionsByWebACLIdResult>;
export interface DistributionTenantAssociationFilter {
    DistributionId?: string;
    ConnectionGroupId?: string;
}
export declare const DistributionTenantAssociationFilter: S.Schema<DistributionTenantAssociationFilter>;
export interface ListDistributionTenantsRequest {
    AssociationFilter?: DistributionTenantAssociationFilter;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListDistributionTenantsRequest: S.Schema<ListDistributionTenantsRequest>;
export interface DistributionTenantSummary {
    Id: string;
    DistributionId: string;
    Name: string;
    Arn: string;
    Domains: DomainResult[];
    ConnectionGroupId?: string;
    Customizations?: Customizations;
    CreatedTime: Date;
    LastModifiedTime: Date;
    ETag: string;
    Enabled?: boolean;
    Status?: string;
}
export declare const DistributionTenantSummary: S.Schema<DistributionTenantSummary>;
export type DistributionTenantList = DistributionTenantSummary[];
export declare const DistributionTenantList: any;
export interface ListDistributionTenantsResult {
    NextMarker?: string;
    DistributionTenantList?: DistributionTenantSummary[];
}
export declare const ListDistributionTenantsResult: S.Schema<ListDistributionTenantsResult>;
export interface ListDistributionTenantsByCustomizationRequest {
    WebACLArn?: string;
    CertificateArn?: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListDistributionTenantsByCustomizationRequest: S.Schema<ListDistributionTenantsByCustomizationRequest>;
export interface ListDistributionTenantsByCustomizationResult {
    NextMarker?: string;
    DistributionTenantList?: DistributionTenantSummary[];
}
export declare const ListDistributionTenantsByCustomizationResult: S.Schema<ListDistributionTenantsByCustomizationResult>;
export interface DistributionResourceId {
    DistributionId?: string;
    DistributionTenantId?: string;
}
export declare const DistributionResourceId: S.Schema<DistributionResourceId>;
export interface ListDomainConflictsRequest {
    Domain: string;
    DomainControlValidationResource: DistributionResourceId;
    MaxItems?: number;
    Marker?: string;
}
export declare const ListDomainConflictsRequest: S.Schema<ListDomainConflictsRequest>;
export type DistributionResourceType = "distribution" | "distribution-tenant" | (string & {});
export declare const DistributionResourceType: any;
export interface DomainConflict {
    Domain: string;
    ResourceType: DistributionResourceType;
    ResourceId: string;
    AccountId: string;
}
export declare const DomainConflict: S.Schema<DomainConflict>;
export type DomainConflictsList = DomainConflict[];
export declare const DomainConflictsList: any;
export interface ListDomainConflictsResult {
    DomainConflicts?: DomainConflict[];
    NextMarker?: string;
}
export declare const ListDomainConflictsResult: S.Schema<ListDomainConflictsResult>;
export interface ListFieldLevelEncryptionConfigsRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListFieldLevelEncryptionConfigsRequest: S.Schema<ListFieldLevelEncryptionConfigsRequest>;
export interface FieldLevelEncryptionSummary {
    Id: string;
    LastModifiedTime: Date;
    Comment?: string;
    QueryArgProfileConfig?: QueryArgProfileConfig;
    ContentTypeProfileConfig?: ContentTypeProfileConfig;
}
export declare const FieldLevelEncryptionSummary: S.Schema<FieldLevelEncryptionSummary>;
export type FieldLevelEncryptionSummaryList = FieldLevelEncryptionSummary[];
export declare const FieldLevelEncryptionSummaryList: any;
export interface FieldLevelEncryptionList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: FieldLevelEncryptionSummary[];
}
export declare const FieldLevelEncryptionList: S.Schema<FieldLevelEncryptionList>;
export interface ListFieldLevelEncryptionConfigsResult {
    FieldLevelEncryptionList?: FieldLevelEncryptionList;
}
export declare const ListFieldLevelEncryptionConfigsResult: S.Schema<ListFieldLevelEncryptionConfigsResult>;
export interface ListFieldLevelEncryptionProfilesRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListFieldLevelEncryptionProfilesRequest: S.Schema<ListFieldLevelEncryptionProfilesRequest>;
export interface FieldLevelEncryptionProfileSummary {
    Id: string;
    LastModifiedTime: Date;
    Name: string;
    EncryptionEntities: EncryptionEntities;
    Comment?: string;
}
export declare const FieldLevelEncryptionProfileSummary: S.Schema<FieldLevelEncryptionProfileSummary>;
export type FieldLevelEncryptionProfileSummaryList = FieldLevelEncryptionProfileSummary[];
export declare const FieldLevelEncryptionProfileSummaryList: any;
export interface FieldLevelEncryptionProfileList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: FieldLevelEncryptionProfileSummary[];
}
export declare const FieldLevelEncryptionProfileList: S.Schema<FieldLevelEncryptionProfileList>;
export interface ListFieldLevelEncryptionProfilesResult {
    FieldLevelEncryptionProfileList?: FieldLevelEncryptionProfileList;
}
export declare const ListFieldLevelEncryptionProfilesResult: S.Schema<ListFieldLevelEncryptionProfilesResult>;
export interface ListFunctionsRequest {
    Marker?: string;
    MaxItems?: number;
    Stage?: FunctionStage;
}
export declare const ListFunctionsRequest: S.Schema<ListFunctionsRequest>;
export type FunctionSummaryList = FunctionSummary[];
export declare const FunctionSummaryList: any;
export interface FunctionList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: FunctionSummary[];
}
export declare const FunctionList: S.Schema<FunctionList>;
export interface ListFunctionsResult {
    FunctionList?: FunctionList;
}
export declare const ListFunctionsResult: S.Schema<ListFunctionsResult>;
export interface ListInvalidationsRequest {
    DistributionId: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListInvalidationsRequest: S.Schema<ListInvalidationsRequest>;
export interface InvalidationSummary {
    Id: string;
    CreateTime: Date;
    Status: string;
}
export declare const InvalidationSummary: S.Schema<InvalidationSummary>;
export type InvalidationSummaryList = InvalidationSummary[];
export declare const InvalidationSummaryList: any;
export interface InvalidationList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: InvalidationSummary[];
}
export declare const InvalidationList: S.Schema<InvalidationList>;
export interface ListInvalidationsResult {
    InvalidationList?: InvalidationList;
}
export declare const ListInvalidationsResult: S.Schema<ListInvalidationsResult>;
export interface ListInvalidationsForDistributionTenantRequest {
    Id: string;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListInvalidationsForDistributionTenantRequest: S.Schema<ListInvalidationsForDistributionTenantRequest>;
export interface ListInvalidationsForDistributionTenantResult {
    InvalidationList?: InvalidationList;
}
export declare const ListInvalidationsForDistributionTenantResult: S.Schema<ListInvalidationsForDistributionTenantResult>;
export interface ListKeyGroupsRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListKeyGroupsRequest: S.Schema<ListKeyGroupsRequest>;
export interface KeyGroupSummary {
    KeyGroup: KeyGroup;
}
export declare const KeyGroupSummary: S.Schema<KeyGroupSummary>;
export type KeyGroupSummaryList = KeyGroupSummary[];
export declare const KeyGroupSummaryList: any;
export interface KeyGroupList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: KeyGroupSummary[];
}
export declare const KeyGroupList: S.Schema<KeyGroupList>;
export interface ListKeyGroupsResult {
    KeyGroupList?: KeyGroupList;
}
export declare const ListKeyGroupsResult: S.Schema<ListKeyGroupsResult>;
export interface ListKeyValueStoresRequest {
    Marker?: string;
    MaxItems?: number;
    Status?: string;
}
export declare const ListKeyValueStoresRequest: S.Schema<ListKeyValueStoresRequest>;
export type KeyValueStoreSummaryList = KeyValueStore[];
export declare const KeyValueStoreSummaryList: any;
export interface KeyValueStoreList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: KeyValueStore[];
}
export declare const KeyValueStoreList: S.Schema<KeyValueStoreList>;
export interface ListKeyValueStoresResult {
    KeyValueStoreList?: KeyValueStoreList;
}
export declare const ListKeyValueStoresResult: S.Schema<ListKeyValueStoresResult>;
export interface ListOriginAccessControlsRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListOriginAccessControlsRequest: S.Schema<ListOriginAccessControlsRequest>;
export interface OriginAccessControlSummary {
    Id: string;
    Description?: string;
    Name: string;
    SigningProtocol: OriginAccessControlSigningProtocols;
    SigningBehavior: OriginAccessControlSigningBehaviors;
    OriginAccessControlOriginType: OriginAccessControlOriginTypes;
}
export declare const OriginAccessControlSummary: S.Schema<OriginAccessControlSummary>;
export type OriginAccessControlSummaryList = OriginAccessControlSummary[];
export declare const OriginAccessControlSummaryList: any;
export interface OriginAccessControlList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: OriginAccessControlSummary[];
}
export declare const OriginAccessControlList: S.Schema<OriginAccessControlList>;
export interface ListOriginAccessControlsResult {
    OriginAccessControlList?: OriginAccessControlList;
}
export declare const ListOriginAccessControlsResult: S.Schema<ListOriginAccessControlsResult>;
export type OriginRequestPolicyType = "managed" | "custom" | (string & {});
export declare const OriginRequestPolicyType: any;
export interface ListOriginRequestPoliciesRequest {
    Type?: OriginRequestPolicyType;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListOriginRequestPoliciesRequest: S.Schema<ListOriginRequestPoliciesRequest>;
export interface OriginRequestPolicySummary {
    Type: OriginRequestPolicyType;
    OriginRequestPolicy: OriginRequestPolicy;
}
export declare const OriginRequestPolicySummary: S.Schema<OriginRequestPolicySummary>;
export type OriginRequestPolicySummaryList = OriginRequestPolicySummary[];
export declare const OriginRequestPolicySummaryList: any;
export interface OriginRequestPolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: OriginRequestPolicySummary[];
}
export declare const OriginRequestPolicyList: S.Schema<OriginRequestPolicyList>;
export interface ListOriginRequestPoliciesResult {
    OriginRequestPolicyList?: OriginRequestPolicyList;
}
export declare const ListOriginRequestPoliciesResult: S.Schema<ListOriginRequestPoliciesResult>;
export interface ListPublicKeysRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListPublicKeysRequest: S.Schema<ListPublicKeysRequest>;
export interface PublicKeySummary {
    Id: string;
    Name: string;
    CreatedTime: Date;
    EncodedKey: string;
    Comment?: string;
}
export declare const PublicKeySummary: S.Schema<PublicKeySummary>;
export type PublicKeySummaryList = PublicKeySummary[];
export declare const PublicKeySummaryList: any;
export interface PublicKeyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: PublicKeySummary[];
}
export declare const PublicKeyList: S.Schema<PublicKeyList>;
export interface ListPublicKeysResult {
    PublicKeyList?: PublicKeyList;
}
export declare const ListPublicKeysResult: S.Schema<ListPublicKeysResult>;
export interface ListRealtimeLogConfigsRequest {
    MaxItems?: number;
    Marker?: string;
}
export declare const ListRealtimeLogConfigsRequest: S.Schema<ListRealtimeLogConfigsRequest>;
export type RealtimeLogConfigList = RealtimeLogConfig[];
export declare const RealtimeLogConfigList: any;
export interface RealtimeLogConfigs {
    MaxItems: number;
    Items?: RealtimeLogConfig[];
    IsTruncated: boolean;
    Marker?: string;
    NextMarker?: string;
}
export declare const RealtimeLogConfigs: S.Schema<RealtimeLogConfigs>;
export interface ListRealtimeLogConfigsResult {
    RealtimeLogConfigs?: RealtimeLogConfigs;
}
export declare const ListRealtimeLogConfigsResult: S.Schema<ListRealtimeLogConfigsResult>;
export type ResponseHeadersPolicyType = "managed" | "custom" | (string & {});
export declare const ResponseHeadersPolicyType: any;
export interface ListResponseHeadersPoliciesRequest {
    Type?: ResponseHeadersPolicyType;
    Marker?: string;
    MaxItems?: number;
}
export declare const ListResponseHeadersPoliciesRequest: S.Schema<ListResponseHeadersPoliciesRequest>;
export interface ResponseHeadersPolicySummary {
    Type: ResponseHeadersPolicyType;
    ResponseHeadersPolicy: ResponseHeadersPolicy;
}
export declare const ResponseHeadersPolicySummary: S.Schema<ResponseHeadersPolicySummary>;
export type ResponseHeadersPolicySummaryList = ResponseHeadersPolicySummary[];
export declare const ResponseHeadersPolicySummaryList: any;
export interface ResponseHeadersPolicyList {
    NextMarker?: string;
    MaxItems: number;
    Quantity: number;
    Items?: ResponseHeadersPolicySummary[];
}
export declare const ResponseHeadersPolicyList: S.Schema<ResponseHeadersPolicyList>;
export interface ListResponseHeadersPoliciesResult {
    ResponseHeadersPolicyList?: ResponseHeadersPolicyList;
}
export declare const ListResponseHeadersPoliciesResult: S.Schema<ListResponseHeadersPoliciesResult>;
export interface ListStreamingDistributionsRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListStreamingDistributionsRequest: S.Schema<ListStreamingDistributionsRequest>;
export interface StreamingDistributionSummary {
    Id: string;
    ARN: string;
    Status: string;
    LastModifiedTime: Date;
    DomainName: string;
    S3Origin: S3Origin;
    Aliases: Aliases;
    TrustedSigners: TrustedSigners;
    Comment: string;
    PriceClass: PriceClass;
    Enabled: boolean;
}
export declare const StreamingDistributionSummary: S.Schema<StreamingDistributionSummary>;
export type StreamingDistributionSummaryList = StreamingDistributionSummary[];
export declare const StreamingDistributionSummaryList: any;
export interface StreamingDistributionList {
    Marker?: string;
    NextMarker?: string;
    MaxItems: number;
    IsTruncated: boolean;
    Quantity: number;
    Items?: StreamingDistributionSummary[];
}
export declare const StreamingDistributionList: S.Schema<StreamingDistributionList>;
export interface ListStreamingDistributionsResult {
    StreamingDistributionList?: StreamingDistributionList;
}
export declare const ListStreamingDistributionsResult: S.Schema<ListStreamingDistributionsResult>;
export type ResourceARN = string;
export interface ListTagsForResourceRequest {
    Resource: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResult {
    Tags: Tags;
}
export declare const ListTagsForResourceResult: S.Schema<ListTagsForResourceResult>;
export interface ListTrustStoresRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListTrustStoresRequest: S.Schema<ListTrustStoresRequest>;
export interface TrustStoreSummary {
    Id: string;
    Arn: string;
    Name: string;
    Status: TrustStoreStatus;
    NumberOfCaCertificates: number;
    LastModifiedTime: Date;
    Reason?: string;
    ETag: string;
}
export declare const TrustStoreSummary: S.Schema<TrustStoreSummary>;
export type TrustStoreList = TrustStoreSummary[];
export declare const TrustStoreList: any;
export interface ListTrustStoresResult {
    NextMarker?: string;
    TrustStoreList?: TrustStoreSummary[];
}
export declare const ListTrustStoresResult: S.Schema<ListTrustStoresResult>;
export interface ListVpcOriginsRequest {
    Marker?: string;
    MaxItems?: number;
}
export declare const ListVpcOriginsRequest: S.Schema<ListVpcOriginsRequest>;
export interface VpcOriginSummary {
    Id: string;
    Name: string;
    Status: string;
    CreatedTime: Date;
    LastModifiedTime: Date;
    Arn: string;
    AccountId?: string;
    OriginEndpointArn: string;
}
export declare const VpcOriginSummary: S.Schema<VpcOriginSummary>;
export type VpcOriginSummaryList = VpcOriginSummary[];
export declare const VpcOriginSummaryList: any;
export interface VpcOriginList {
    Marker?: string;
    NextMarker?: string;
    MaxItems?: number;
    IsTruncated?: boolean;
    Quantity?: number;
    Items?: VpcOriginSummary[];
}
export declare const VpcOriginList: S.Schema<VpcOriginList>;
export interface ListVpcOriginsResult {
    VpcOriginList?: VpcOriginList;
}
export declare const ListVpcOriginsResult: S.Schema<ListVpcOriginsResult>;
export interface PublishConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
}
export declare const PublishConnectionFunctionRequest: S.Schema<PublishConnectionFunctionRequest>;
export interface PublishConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
}
export declare const PublishConnectionFunctionResult: S.Schema<PublishConnectionFunctionResult>;
export interface PublishFunctionRequest {
    Name: string;
    IfMatch: string;
}
export declare const PublishFunctionRequest: S.Schema<PublishFunctionRequest>;
export interface PublishFunctionResult {
    FunctionSummary?: FunctionSummary;
}
export declare const PublishFunctionResult: S.Schema<PublishFunctionResult>;
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    PolicyDocument: string;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResult {
    ResourceArn?: string;
}
export declare const PutResourcePolicyResult: S.Schema<PutResourcePolicyResult>;
export interface TagResourceRequest {
    Resource: string;
    Tags: Tags;
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type FunctionEventObject = Uint8Array | redacted.Redacted<Uint8Array>;
export interface TestConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
    Stage?: FunctionStage;
    ConnectionObject: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const TestConnectionFunctionRequest: S.Schema<TestConnectionFunctionRequest>;
export type FunctionExecutionLogList = string[];
export declare const FunctionExecutionLogList: any;
export interface ConnectionFunctionTestResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    ComputeUtilization?: string;
    ConnectionFunctionExecutionLogs?: string[];
    ConnectionFunctionErrorMessage?: string | redacted.Redacted<string>;
    ConnectionFunctionOutput?: string | redacted.Redacted<string>;
}
export declare const ConnectionFunctionTestResult: S.Schema<ConnectionFunctionTestResult>;
export interface TestConnectionFunctionResult {
    ConnectionFunctionTestResult?: ConnectionFunctionTestResult;
}
export declare const TestConnectionFunctionResult: S.Schema<TestConnectionFunctionResult>;
export interface TestFunctionRequest {
    Name: string;
    IfMatch: string;
    Stage?: FunctionStage;
    EventObject: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const TestFunctionRequest: S.Schema<TestFunctionRequest>;
export interface TestResult {
    FunctionSummary?: FunctionSummary;
    ComputeUtilization?: string;
    FunctionExecutionLogs?: string[];
    FunctionErrorMessage?: string | redacted.Redacted<string>;
    FunctionOutput?: string | redacted.Redacted<string>;
}
export declare const TestResult: S.Schema<TestResult>;
export interface TestFunctionResult {
    TestResult?: TestResult;
}
export declare const TestFunctionResult: S.Schema<TestFunctionResult>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface TagKeys {
    Items?: string[];
}
export declare const TagKeys: S.Schema<TagKeys>;
export interface UntagResourceRequest {
    Resource: string;
    TagKeys: TagKeys;
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAnycastIpListRequest {
    Id: string;
    IpAddressType?: IpAddressType;
    IpamCidrConfigs?: IpamCidrConfig[];
    IfMatch: string;
}
export declare const UpdateAnycastIpListRequest: S.Schema<UpdateAnycastIpListRequest>;
export interface UpdateAnycastIpListResult {
    AnycastIpList?: AnycastIpList;
    ETag?: string;
}
export declare const UpdateAnycastIpListResult: S.Schema<UpdateAnycastIpListResult>;
export interface UpdateCachePolicyRequest {
    CachePolicyConfig: CachePolicyConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateCachePolicyRequest: S.Schema<UpdateCachePolicyRequest>;
export interface UpdateCachePolicyResult {
    CachePolicy?: CachePolicy;
    ETag?: string;
}
export declare const UpdateCachePolicyResult: S.Schema<UpdateCachePolicyResult>;
export interface UpdateCloudFrontOriginAccessIdentityRequest {
    CloudFrontOriginAccessIdentityConfig: CloudFrontOriginAccessIdentityConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateCloudFrontOriginAccessIdentityRequest: S.Schema<UpdateCloudFrontOriginAccessIdentityRequest>;
export interface UpdateCloudFrontOriginAccessIdentityResult {
    CloudFrontOriginAccessIdentity?: CloudFrontOriginAccessIdentity;
    ETag?: string;
}
export declare const UpdateCloudFrontOriginAccessIdentityResult: S.Schema<UpdateCloudFrontOriginAccessIdentityResult>;
export interface UpdateConnectionFunctionRequest {
    Id: string;
    IfMatch: string;
    ConnectionFunctionConfig: FunctionConfig;
    ConnectionFunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const UpdateConnectionFunctionRequest: S.Schema<UpdateConnectionFunctionRequest>;
export interface UpdateConnectionFunctionResult {
    ConnectionFunctionSummary?: ConnectionFunctionSummary;
    ETag?: string;
}
export declare const UpdateConnectionFunctionResult: S.Schema<UpdateConnectionFunctionResult>;
export interface UpdateConnectionGroupRequest {
    Id: string;
    Ipv6Enabled?: boolean;
    IfMatch: string;
    AnycastIpListId?: string;
    Enabled?: boolean;
}
export declare const UpdateConnectionGroupRequest: S.Schema<UpdateConnectionGroupRequest>;
export interface UpdateConnectionGroupResult {
    ConnectionGroup?: ConnectionGroup;
    ETag?: string;
}
export declare const UpdateConnectionGroupResult: S.Schema<UpdateConnectionGroupResult>;
export interface UpdateContinuousDeploymentPolicyRequest {
    ContinuousDeploymentPolicyConfig: ContinuousDeploymentPolicyConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateContinuousDeploymentPolicyRequest: S.Schema<UpdateContinuousDeploymentPolicyRequest>;
export interface UpdateContinuousDeploymentPolicyResult {
    ContinuousDeploymentPolicy?: ContinuousDeploymentPolicy;
    ETag?: string;
}
export declare const UpdateContinuousDeploymentPolicyResult: S.Schema<UpdateContinuousDeploymentPolicyResult>;
export interface UpdateDistributionRequest {
    DistributionConfig: DistributionConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateDistributionRequest: S.Schema<UpdateDistributionRequest>;
export interface UpdateDistributionResult {
    Distribution?: Distribution;
    ETag?: string;
}
export declare const UpdateDistributionResult: S.Schema<UpdateDistributionResult>;
export interface UpdateDistributionTenantRequest {
    Id: string;
    DistributionId?: string;
    Domains?: DomainItem[];
    Customizations?: Customizations;
    Parameters?: Parameter[];
    ConnectionGroupId?: string;
    IfMatch: string;
    ManagedCertificateRequest?: ManagedCertificateRequest;
    Enabled?: boolean;
}
export declare const UpdateDistributionTenantRequest: S.Schema<UpdateDistributionTenantRequest>;
export interface UpdateDistributionTenantResult {
    DistributionTenant?: DistributionTenant;
    ETag?: string;
}
export declare const UpdateDistributionTenantResult: S.Schema<UpdateDistributionTenantResult>;
export interface UpdateDistributionWithStagingConfigRequest {
    Id: string;
    StagingDistributionId?: string;
    IfMatch?: string;
}
export declare const UpdateDistributionWithStagingConfigRequest: S.Schema<UpdateDistributionWithStagingConfigRequest>;
export interface UpdateDistributionWithStagingConfigResult {
    Distribution?: Distribution;
    ETag?: string;
}
export declare const UpdateDistributionWithStagingConfigResult: S.Schema<UpdateDistributionWithStagingConfigResult>;
export interface UpdateDomainAssociationRequest {
    Domain: string;
    TargetResource: DistributionResourceId;
    IfMatch?: string;
}
export declare const UpdateDomainAssociationRequest: S.Schema<UpdateDomainAssociationRequest>;
export interface UpdateDomainAssociationResult {
    Domain?: string;
    ResourceId?: string;
    ETag?: string;
}
export declare const UpdateDomainAssociationResult: S.Schema<UpdateDomainAssociationResult>;
export interface UpdateFieldLevelEncryptionConfigRequest {
    FieldLevelEncryptionConfig: FieldLevelEncryptionConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateFieldLevelEncryptionConfigRequest: S.Schema<UpdateFieldLevelEncryptionConfigRequest>;
export interface UpdateFieldLevelEncryptionConfigResult {
    FieldLevelEncryption?: FieldLevelEncryption;
    ETag?: string;
}
export declare const UpdateFieldLevelEncryptionConfigResult: S.Schema<UpdateFieldLevelEncryptionConfigResult>;
export interface UpdateFieldLevelEncryptionProfileRequest {
    FieldLevelEncryptionProfileConfig: FieldLevelEncryptionProfileConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateFieldLevelEncryptionProfileRequest: S.Schema<UpdateFieldLevelEncryptionProfileRequest>;
export interface UpdateFieldLevelEncryptionProfileResult {
    FieldLevelEncryptionProfile?: FieldLevelEncryptionProfile;
    ETag?: string;
}
export declare const UpdateFieldLevelEncryptionProfileResult: S.Schema<UpdateFieldLevelEncryptionProfileResult>;
export interface UpdateFunctionRequest {
    Name: string;
    IfMatch: string;
    FunctionConfig: FunctionConfig;
    FunctionCode: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const UpdateFunctionRequest: S.Schema<UpdateFunctionRequest>;
export interface UpdateFunctionResult {
    FunctionSummary?: FunctionSummary;
    ETag?: string;
}
export declare const UpdateFunctionResult: S.Schema<UpdateFunctionResult>;
export interface UpdateKeyGroupRequest {
    KeyGroupConfig: KeyGroupConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateKeyGroupRequest: S.Schema<UpdateKeyGroupRequest>;
export interface UpdateKeyGroupResult {
    KeyGroup?: KeyGroup;
    ETag?: string;
}
export declare const UpdateKeyGroupResult: S.Schema<UpdateKeyGroupResult>;
export interface UpdateKeyValueStoreRequest {
    Name: string;
    Comment: string;
    IfMatch: string;
}
export declare const UpdateKeyValueStoreRequest: S.Schema<UpdateKeyValueStoreRequest>;
export interface UpdateKeyValueStoreResult {
    KeyValueStore?: KeyValueStore;
    ETag?: string;
}
export declare const UpdateKeyValueStoreResult: S.Schema<UpdateKeyValueStoreResult>;
export interface UpdateOriginAccessControlRequest {
    OriginAccessControlConfig: OriginAccessControlConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateOriginAccessControlRequest: S.Schema<UpdateOriginAccessControlRequest>;
export interface UpdateOriginAccessControlResult {
    OriginAccessControl?: OriginAccessControl;
    ETag?: string;
}
export declare const UpdateOriginAccessControlResult: S.Schema<UpdateOriginAccessControlResult>;
export interface UpdateOriginRequestPolicyRequest {
    OriginRequestPolicyConfig: OriginRequestPolicyConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateOriginRequestPolicyRequest: S.Schema<UpdateOriginRequestPolicyRequest>;
export interface UpdateOriginRequestPolicyResult {
    OriginRequestPolicy?: OriginRequestPolicy;
    ETag?: string;
}
export declare const UpdateOriginRequestPolicyResult: S.Schema<UpdateOriginRequestPolicyResult>;
export interface UpdatePublicKeyRequest {
    PublicKeyConfig: PublicKeyConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdatePublicKeyRequest: S.Schema<UpdatePublicKeyRequest>;
export interface UpdatePublicKeyResult {
    PublicKey?: PublicKey;
    ETag?: string;
}
export declare const UpdatePublicKeyResult: S.Schema<UpdatePublicKeyResult>;
export interface UpdateRealtimeLogConfigRequest {
    EndPoints?: EndPoint[];
    Fields?: string[];
    Name?: string;
    ARN?: string;
    SamplingRate?: number;
}
export declare const UpdateRealtimeLogConfigRequest: S.Schema<UpdateRealtimeLogConfigRequest>;
export interface UpdateRealtimeLogConfigResult {
    RealtimeLogConfig?: RealtimeLogConfig;
}
export declare const UpdateRealtimeLogConfigResult: S.Schema<UpdateRealtimeLogConfigResult>;
export interface UpdateResponseHeadersPolicyRequest {
    ResponseHeadersPolicyConfig: ResponseHeadersPolicyConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateResponseHeadersPolicyRequest: S.Schema<UpdateResponseHeadersPolicyRequest>;
export interface UpdateResponseHeadersPolicyResult {
    ResponseHeadersPolicy?: ResponseHeadersPolicy;
    ETag?: string;
}
export declare const UpdateResponseHeadersPolicyResult: S.Schema<UpdateResponseHeadersPolicyResult>;
export interface UpdateStreamingDistributionRequest {
    StreamingDistributionConfig: StreamingDistributionConfig;
    Id: string;
    IfMatch?: string;
}
export declare const UpdateStreamingDistributionRequest: S.Schema<UpdateStreamingDistributionRequest>;
export interface UpdateStreamingDistributionResult {
    StreamingDistribution?: StreamingDistribution;
    ETag?: string;
}
export declare const UpdateStreamingDistributionResult: S.Schema<UpdateStreamingDistributionResult>;
export interface UpdateTrustStoreRequest {
    Id: string;
    CaCertificatesBundleSource?: CaCertificatesBundleSource;
    UseClientCertificateOCSPEndpoint?: boolean;
    IfMatch: string;
}
export declare const UpdateTrustStoreRequest: S.Schema<UpdateTrustStoreRequest>;
export interface UpdateTrustStoreResult {
    TrustStore?: TrustStore;
    ETag?: string;
}
export declare const UpdateTrustStoreResult: S.Schema<UpdateTrustStoreResult>;
export interface UpdateVpcOriginRequest {
    VpcOriginEndpointConfig: VpcOriginEndpointConfig;
    Id: string;
    IfMatch: string;
}
export declare const UpdateVpcOriginRequest: S.Schema<UpdateVpcOriginRequest>;
export interface UpdateVpcOriginResult {
    VpcOrigin?: VpcOrigin;
    ETag?: string;
}
export declare const UpdateVpcOriginResult: S.Schema<UpdateVpcOriginResult>;
export interface VerifyDnsConfigurationRequest {
    Domain?: string;
    Identifier: string;
}
export declare const VerifyDnsConfigurationRequest: S.Schema<VerifyDnsConfigurationRequest>;
export type DnsConfigurationStatus = "valid-configuration" | "invalid-configuration" | "unknown-configuration" | (string & {});
export declare const DnsConfigurationStatus: any;
export interface DnsConfiguration {
    Domain: string;
    Status: DnsConfigurationStatus;
    Reason?: string;
}
export declare const DnsConfiguration: S.Schema<DnsConfiguration>;
export type DnsConfigurationList = DnsConfiguration[];
export declare const DnsConfigurationList: any;
export interface VerifyDnsConfigurationResult {
    DnsConfigurationList?: DnsConfiguration[];
}
export declare const VerifyDnsConfigurationResult: S.Schema<VerifyDnsConfigurationResult>;
export type AssociateAliasError = AccessDenied | IllegalUpdate | InvalidArgument | NoSuchDistribution | TooManyDistributionCNAMEs | CommonErrors;
/**
 * The `AssociateAlias` API operation only supports standard distributions. To move domains between distribution tenants and/or standard distributions, we recommend that you use the UpdateDomainAssociation API operation instead.
 *
 * Associates an alias with a CloudFront standard distribution. An alias is commonly known as a custom domain or vanity domain. It can also be called a CNAME or alternate domain name.
 *
 * With this operation, you can move an alias that's already used for a standard distribution to a different standard distribution. This prevents the downtime that could occur if you first remove the alias from one standard distribution and then separately add the alias to another standard distribution.
 *
 * To use this operation, specify the alias and the ID of the target standard distribution.
 *
 * For more information, including how to set up the target standard distribution, prerequisites that you must complete, and other restrictions, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 */
export declare const associateAlias: API.OperationMethod<AssociateAliasRequest, AssociateAliasResponse, AssociateAliasError, Credentials | HttpClient.HttpClient>;
export type AssociateDistributionTenantWebACLError = AccessDenied | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Associates the WAF web ACL with a distribution tenant.
 */
export declare const associateDistributionTenantWebACL: API.OperationMethod<AssociateDistributionTenantWebACLRequest, AssociateDistributionTenantWebACLResult, AssociateDistributionTenantWebACLError, Credentials | HttpClient.HttpClient>;
export type AssociateDistributionWebACLError = AccessDenied | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Associates the WAF web ACL with a distribution.
 */
export declare const associateDistributionWebACL: API.OperationMethod<AssociateDistributionWebACLRequest, AssociateDistributionWebACLResult, AssociateDistributionWebACLError, Credentials | HttpClient.HttpClient>;
export type CopyDistributionError = AccessDenied | CNAMEAlreadyExists | DistributionAlreadyExists | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidIfMatchVersion | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidProtocolSettings | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchDistribution | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | PreconditionFailed | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributions | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Creates a staging distribution using the configuration of the provided primary distribution. A staging distribution is a copy of an existing distribution (called the primary distribution) that you can use in a continuous deployment workflow.
 *
 * After you create a staging distribution, you can use `UpdateDistribution` to modify the staging distribution's configuration. Then you can use `CreateContinuousDeploymentPolicy` to incrementally move traffic to the staging distribution.
 *
 * This API operation requires the following IAM permissions:
 *
 * - GetDistribution
 *
 * - CreateDistribution
 *
 * - CopyDistribution
 */
export declare const copyDistribution: API.OperationMethod<CopyDistributionRequest, CopyDistributionResult, CopyDistributionError, Credentials | HttpClient.HttpClient>;
export type CreateAnycastIpListError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | InvalidArgument | InvalidTagging | UnsupportedOperation | CommonErrors;
/**
 * Creates an Anycast static IP list.
 */
export declare const createAnycastIpList: API.OperationMethod<CreateAnycastIpListRequest, CreateAnycastIpListResult, CreateAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type CreateCachePolicyError = AccessDenied | CachePolicyAlreadyExists | InconsistentQuantities | InvalidArgument | TooManyCachePolicies | TooManyCookiesInCachePolicy | TooManyHeadersInCachePolicy | TooManyQueryStringsInCachePolicy | CommonErrors;
/**
 * Creates a cache policy.
 *
 * After you create a cache policy, you can attach it to one or more cache behaviors. When it's attached to a cache behavior, the cache policy determines the following:
 *
 * - The values that CloudFront includes in the *cache key*. These values can include HTTP headers, cookies, and URL query strings. CloudFront uses the cache key to find an object in its cache that it can return to the viewer.
 *
 * - The default, minimum, and maximum time to live (TTL) values that you want objects to stay in the CloudFront cache.
 *
 * If your minimum TTL is greater than 0, CloudFront will cache content for at least the duration specified in the cache policy's minimum TTL, even if the `Cache-Control: no-cache`, `no-store`, or `private` directives are present in the origin headers.
 *
 * The headers, cookies, and query strings that are included in the cache key are also included in requests that CloudFront sends to the origin. CloudFront sends a request when it can't find an object in its cache that matches the request's cache key. If you want to send values to the origin but *not* include them in the cache key, use `OriginRequestPolicy`.
 *
 * For more information about cache policies, see Controlling the cache key in the *Amazon CloudFront Developer Guide*.
 */
export declare const createCachePolicy: API.OperationMethod<CreateCachePolicyRequest, CreateCachePolicyResult, CreateCachePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateCloudFrontOriginAccessIdentityError = CloudFrontOriginAccessIdentityAlreadyExists | InconsistentQuantities | InvalidArgument | MissingBody | TooManyCloudFrontOriginAccessIdentities | CommonErrors;
/**
 * Creates a new origin access identity. If you're using Amazon S3 for your origin, you can use an origin access identity to require users to access your content using a CloudFront URL instead of the Amazon S3 URL. For more information about how to use origin access identities, see Serving Private Content through CloudFront in the *Amazon CloudFront Developer Guide*.
 */
export declare const createCloudFrontOriginAccessIdentity: API.OperationMethod<CreateCloudFrontOriginAccessIdentityRequest, CreateCloudFrontOriginAccessIdentityResult, CreateCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionFunctionError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntitySizeLimitExceeded | InvalidArgument | InvalidTagging | UnsupportedOperation | CommonErrors;
/**
 * Creates a connection function.
 */
export declare const createConnectionFunction: API.OperationMethod<CreateConnectionFunctionRequest, CreateConnectionFunctionResult, CreateConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionGroupError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidTagging | CommonErrors;
/**
 * Creates a connection group.
 */
export declare const createConnectionGroup: API.OperationMethod<CreateConnectionGroupRequest, CreateConnectionGroupResult, CreateConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateContinuousDeploymentPolicyError = AccessDenied | ContinuousDeploymentPolicyAlreadyExists | InconsistentQuantities | InvalidArgument | StagingDistributionInUse | TooManyContinuousDeploymentPolicies | CommonErrors;
/**
 * Creates a continuous deployment policy that distributes traffic for a custom domain name to two different CloudFront distributions.
 *
 * To use a continuous deployment policy, first use `CopyDistribution` to create a staging distribution, then use `UpdateDistribution` to modify the staging distribution's configuration.
 *
 * After you create and update a staging distribution, you can use a continuous deployment policy to incrementally move traffic to the staging distribution. This workflow enables you to test changes to a distribution's configuration before moving all of your domain's production traffic to the new configuration.
 */
export declare const createContinuousDeploymentPolicy: API.OperationMethod<CreateContinuousDeploymentPolicyRequest, CreateContinuousDeploymentPolicyResult, CreateContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionError = AccessDenied | CNAMEAlreadyExists | ContinuousDeploymentPolicyInUse | DistributionAlreadyExists | EntityLimitExceeded | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalOriginAccessConfiguration | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidDomainNameForOriginAccessControl | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidProtocolSettings | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchContinuousDeploymentPolicy | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributions | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Creates a CloudFront distribution.
 */
export declare const createDistribution: API.OperationMethod<CreateDistributionRequest, CreateDistributionResult, CreateDistributionError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionTenantError = AccessDenied | CNAMEAlreadyExists | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidAssociation | InvalidTagging | CommonErrors;
/**
 * Creates a distribution tenant.
 */
export declare const createDistributionTenant: API.OperationMethod<CreateDistributionTenantRequest, CreateDistributionTenantResult, CreateDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type CreateDistributionWithTagsError = AccessDenied | CNAMEAlreadyExists | ContinuousDeploymentPolicyInUse | DistributionAlreadyExists | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalOriginAccessConfiguration | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidDomainNameForOriginAccessControl | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidProtocolSettings | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTagging | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchContinuousDeploymentPolicy | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributions | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Create a new distribution with tags. This API operation requires the following IAM permissions:
 *
 * - CreateDistribution
 *
 * - TagResource
 */
export declare const createDistributionWithTags: API.OperationMethod<CreateDistributionWithTagsRequest, CreateDistributionWithTagsResult, CreateDistributionWithTagsError, Credentials | HttpClient.HttpClient>;
export type CreateFieldLevelEncryptionConfigError = FieldLevelEncryptionConfigAlreadyExists | InconsistentQuantities | InvalidArgument | NoSuchFieldLevelEncryptionProfile | QueryArgProfileEmpty | TooManyFieldLevelEncryptionConfigs | TooManyFieldLevelEncryptionContentTypeProfiles | TooManyFieldLevelEncryptionQueryArgProfiles | CommonErrors;
/**
 * Create a new field-level encryption configuration.
 */
export declare const createFieldLevelEncryptionConfig: API.OperationMethod<CreateFieldLevelEncryptionConfigRequest, CreateFieldLevelEncryptionConfigResult, CreateFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type CreateFieldLevelEncryptionProfileError = FieldLevelEncryptionProfileAlreadyExists | FieldLevelEncryptionProfileSizeExceeded | InconsistentQuantities | InvalidArgument | NoSuchPublicKey | TooManyFieldLevelEncryptionEncryptionEntities | TooManyFieldLevelEncryptionFieldPatterns | TooManyFieldLevelEncryptionProfiles | CommonErrors;
/**
 * Create a field-level encryption profile.
 */
export declare const createFieldLevelEncryptionProfile: API.OperationMethod<CreateFieldLevelEncryptionProfileRequest, CreateFieldLevelEncryptionProfileResult, CreateFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionError = FunctionAlreadyExists | FunctionSizeLimitExceeded | InvalidArgument | TooManyFunctions | UnsupportedOperation | CommonErrors;
/**
 * Creates a CloudFront function.
 *
 * To create a function, you provide the function code and some configuration information about the function. The response contains an Amazon Resource Name (ARN) that uniquely identifies the function.
 *
 * When you create a function, it's in the `DEVELOPMENT` stage. In this stage, you can test the function with `TestFunction`, and update it with `UpdateFunction`.
 *
 * When you're ready to use your function with a CloudFront distribution, use `PublishFunction` to copy the function from the `DEVELOPMENT` stage to `LIVE`. When it's live, you can attach the function to a distribution's cache behavior, using the function's ARN.
 */
export declare const createFunction: API.OperationMethod<CreateFunctionRequest, CreateFunctionResult, CreateFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateInvalidationError = AccessDenied | BatchTooLarge | InconsistentQuantities | InvalidArgument | MissingBody | NoSuchDistribution | TooManyInvalidationsInProgress | CommonErrors;
/**
 * Create a new invalidation. For more information, see Invalidating files in the *Amazon CloudFront Developer Guide*.
 */
export declare const createInvalidation: API.OperationMethod<CreateInvalidationRequest, CreateInvalidationResult, CreateInvalidationError, Credentials | HttpClient.HttpClient>;
export type CreateInvalidationForDistributionTenantError = AccessDenied | BatchTooLarge | EntityNotFound | InconsistentQuantities | InvalidArgument | MissingBody | TooManyInvalidationsInProgress | CommonErrors;
/**
 * Creates an invalidation for a distribution tenant. For more information, see Invalidating files in the *Amazon CloudFront Developer Guide*.
 */
export declare const createInvalidationForDistributionTenant: API.OperationMethod<CreateInvalidationForDistributionTenantRequest, CreateInvalidationForDistributionTenantResult, CreateInvalidationForDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type CreateKeyGroupError = InvalidArgument | KeyGroupAlreadyExists | TooManyKeyGroups | TooManyPublicKeysInKeyGroup | CommonErrors;
/**
 * Creates a key group that you can use with CloudFront signed URLs and signed cookies.
 *
 * To create a key group, you must specify at least one public key for the key group. After you create a key group, you can reference it from one or more cache behaviors. When you reference a key group in a cache behavior, CloudFront requires signed URLs or signed cookies for all requests that match the cache behavior. The URLs or cookies must be signed with a private key whose corresponding public key is in the key group. The signed URL or cookie contains information about which public key CloudFront should use to verify the signature. For more information, see Serving private content in the *Amazon CloudFront Developer Guide*.
 */
export declare const createKeyGroup: API.OperationMethod<CreateKeyGroupRequest, CreateKeyGroupResult, CreateKeyGroupError, Credentials | HttpClient.HttpClient>;
export type CreateKeyValueStoreError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntitySizeLimitExceeded | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store resource to add to your account. In your account, the key value store names must be unique. You can also import key value store data in JSON format from an S3 bucket by providing a valid `ImportSource` that you own.
 */
export declare const createKeyValueStore: API.OperationMethod<CreateKeyValueStoreRequest, CreateKeyValueStoreResult, CreateKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type CreateMonitoringSubscriptionError = AccessDenied | MonitoringSubscriptionAlreadyExists | NoSuchDistribution | UnsupportedOperation | CommonErrors;
/**
 * Enables or disables additional Amazon CloudWatch metrics for the specified CloudFront distribution. The additional metrics incur an additional cost.
 *
 * For more information, see Viewing additional CloudFront distribution metrics in the *Amazon CloudFront Developer Guide*.
 */
export declare const createMonitoringSubscription: API.OperationMethod<CreateMonitoringSubscriptionRequest, CreateMonitoringSubscriptionResult, CreateMonitoringSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateOriginAccessControlError = InvalidArgument | OriginAccessControlAlreadyExists | TooManyOriginAccessControls | CommonErrors;
/**
 * Creates a new origin access control in CloudFront. After you create an origin access control, you can add it to an origin in a CloudFront distribution so that CloudFront sends authenticated (signed) requests to the origin.
 *
 * This makes it possible to block public access to the origin, allowing viewers (users) to access the origin's content only through CloudFront.
 *
 * For more information about using a CloudFront origin access control, see Restricting access to an Amazon Web Services origin in the *Amazon CloudFront Developer Guide*.
 */
export declare const createOriginAccessControl: API.OperationMethod<CreateOriginAccessControlRequest, CreateOriginAccessControlResult, CreateOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type CreateOriginRequestPolicyError = AccessDenied | InconsistentQuantities | InvalidArgument | OriginRequestPolicyAlreadyExists | TooManyCookiesInOriginRequestPolicy | TooManyHeadersInOriginRequestPolicy | TooManyOriginRequestPolicies | TooManyQueryStringsInOriginRequestPolicy | CommonErrors;
/**
 * Creates an origin request policy.
 *
 * After you create an origin request policy, you can attach it to one or more cache behaviors. When it's attached to a cache behavior, the origin request policy determines the values that CloudFront includes in requests that it sends to the origin. Each request that CloudFront sends to the origin includes the following:
 *
 * - The request body and the URL path (without the domain name) from the viewer request.
 *
 * - The headers that CloudFront automatically includes in every origin request, including `Host`, `User-Agent`, and `X-Amz-Cf-Id`.
 *
 * - All HTTP headers, cookies, and URL query strings that are specified in the cache policy or the origin request policy. These can include items from the viewer request and, in the case of headers, additional ones that are added by CloudFront.
 *
 * CloudFront sends a request when it can't find a valid object in its cache that matches the request. If you want to send values to the origin and also include them in the cache key, use `CachePolicy`.
 *
 * For more information about origin request policies, see Controlling origin requests in the *Amazon CloudFront Developer Guide*.
 */
export declare const createOriginRequestPolicy: API.OperationMethod<CreateOriginRequestPolicyRequest, CreateOriginRequestPolicyResult, CreateOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type CreatePublicKeyError = InvalidArgument | PublicKeyAlreadyExists | TooManyPublicKeys | CommonErrors;
/**
 * Uploads a public key to CloudFront that you can use with signed URLs and signed cookies, or with field-level encryption.
 */
export declare const createPublicKey: API.OperationMethod<CreatePublicKeyRequest, CreatePublicKeyResult, CreatePublicKeyError, Credentials | HttpClient.HttpClient>;
export type CreateRealtimeLogConfigError = AccessDenied | InvalidArgument | RealtimeLogConfigAlreadyExists | TooManyRealtimeLogConfigs | CommonErrors;
/**
 * Creates a real-time log configuration.
 *
 * After you create a real-time log configuration, you can attach it to one or more cache behaviors to send real-time log data to the specified Amazon Kinesis data stream.
 *
 * For more information about real-time log configurations, see Real-time logs in the *Amazon CloudFront Developer Guide*.
 */
export declare const createRealtimeLogConfig: API.OperationMethod<CreateRealtimeLogConfigRequest, CreateRealtimeLogConfigResult, CreateRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type CreateResponseHeadersPolicyError = AccessDenied | InconsistentQuantities | InvalidArgument | ResponseHeadersPolicyAlreadyExists | TooLongCSPInResponseHeadersPolicy | TooManyCustomHeadersInResponseHeadersPolicy | TooManyRemoveHeadersInResponseHeadersPolicy | TooManyResponseHeadersPolicies | CommonErrors;
/**
 * Creates a response headers policy.
 *
 * A response headers policy contains information about a set of HTTP headers. To create a response headers policy, you provide some metadata about the policy and a set of configurations that specify the headers.
 *
 * After you create a response headers policy, you can use its ID to attach it to one or more cache behaviors in a CloudFront distribution. When it's attached to a cache behavior, the response headers policy affects the HTTP headers that CloudFront includes in HTTP responses to requests that match the cache behavior. CloudFront adds or removes response headers according to the configuration of the response headers policy.
 *
 * For more information, see Adding or removing HTTP headers in CloudFront responses in the *Amazon CloudFront Developer Guide*.
 */
export declare const createResponseHeadersPolicy: API.OperationMethod<CreateResponseHeadersPolicyRequest, CreateResponseHeadersPolicyResult, CreateResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateStreamingDistributionError = AccessDenied | CNAMEAlreadyExists | InconsistentQuantities | InvalidArgument | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | MissingBody | StreamingDistributionAlreadyExists | TooManyStreamingDistributionCNAMEs | TooManyStreamingDistributions | TooManyTrustedSigners | TrustedSignerDoesNotExist | CommonErrors;
/**
 * This API is deprecated. Amazon CloudFront is deprecating real-time messaging protocol (RTMP) distributions on December 31, 2020. For more information, read the announcement on the Amazon CloudFront discussion forum.
 */
export declare const createStreamingDistribution: API.OperationMethod<CreateStreamingDistributionRequest, CreateStreamingDistributionResult, CreateStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type CreateStreamingDistributionWithTagsError = AccessDenied | CNAMEAlreadyExists | InconsistentQuantities | InvalidArgument | InvalidOrigin | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidTagging | MissingBody | StreamingDistributionAlreadyExists | TooManyStreamingDistributionCNAMEs | TooManyStreamingDistributions | TooManyTrustedSigners | TrustedSignerDoesNotExist | CommonErrors;
/**
 * This API is deprecated. Amazon CloudFront is deprecating real-time messaging protocol (RTMP) distributions on December 31, 2020. For more information, read the announcement on the Amazon CloudFront discussion forum.
 */
export declare const createStreamingDistributionWithTags: API.OperationMethod<CreateStreamingDistributionWithTagsRequest, CreateStreamingDistributionWithTagsResult, CreateStreamingDistributionWithTagsError, Credentials | HttpClient.HttpClient>;
export type CreateTrustStoreError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidTagging | CommonErrors;
/**
 * Creates a trust store.
 */
export declare const createTrustStore: API.OperationMethod<CreateTrustStoreRequest, CreateTrustStoreResult, CreateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type CreateVpcOriginError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | InconsistentQuantities | InvalidArgument | InvalidTagging | UnsupportedOperation | CommonErrors;
/**
 * Create an Amazon CloudFront VPC origin.
 */
export declare const createVpcOrigin: API.OperationMethod<CreateVpcOriginRequest, CreateVpcOriginResult, CreateVpcOriginError, Credentials | HttpClient.HttpClient>;
export type DeleteAnycastIpListError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | IllegalDelete | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes an Anycast static IP list.
 */
export declare const deleteAnycastIpList: API.OperationMethod<DeleteAnycastIpListRequest, DeleteAnycastIpListResponse, DeleteAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type DeleteCachePolicyError = AccessDenied | CachePolicyInUse | IllegalDelete | InvalidIfMatchVersion | NoSuchCachePolicy | PreconditionFailed | CommonErrors;
/**
 * Deletes a cache policy.
 *
 * You cannot delete a cache policy if it's attached to a cache behavior. First update your distributions to remove the cache policy from all cache behaviors, then delete the cache policy.
 *
 * To delete a cache policy, you must provide the policy's identifier and version. To get these values, you can use `ListCachePolicies` or `GetCachePolicy`.
 */
export declare const deleteCachePolicy: API.OperationMethod<DeleteCachePolicyRequest, DeleteCachePolicyResponse, DeleteCachePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudFrontOriginAccessIdentityError = AccessDenied | CloudFrontOriginAccessIdentityInUse | InvalidIfMatchVersion | NoSuchCloudFrontOriginAccessIdentity | PreconditionFailed | CommonErrors;
/**
 * Delete an origin access identity.
 */
export declare const deleteCloudFrontOriginAccessIdentity: API.OperationMethod<DeleteCloudFrontOriginAccessIdentityRequest, DeleteCloudFrontOriginAccessIdentityResponse, DeleteCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionFunctionError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes a connection function.
 */
export declare const deleteConnectionFunction: API.OperationMethod<DeleteConnectionFunctionRequest, DeleteConnectionFunctionResponse, DeleteConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionGroupError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidIfMatchVersion | PreconditionFailed | ResourceNotDisabled | CommonErrors;
/**
 * Deletes a connection group.
 */
export declare const deleteConnectionGroup: API.OperationMethod<DeleteConnectionGroupRequest, DeleteConnectionGroupResponse, DeleteConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteContinuousDeploymentPolicyError = AccessDenied | ContinuousDeploymentPolicyInUse | InvalidArgument | InvalidIfMatchVersion | NoSuchContinuousDeploymentPolicy | PreconditionFailed | CommonErrors;
/**
 * Deletes a continuous deployment policy.
 *
 * You cannot delete a continuous deployment policy that's attached to a primary distribution. First update your distribution to remove the continuous deployment policy, then you can delete the policy.
 */
export declare const deleteContinuousDeploymentPolicy: API.OperationMethod<DeleteContinuousDeploymentPolicyRequest, DeleteContinuousDeploymentPolicyResponse, DeleteContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionError = AccessDenied | DistributionNotDisabled | InvalidIfMatchVersion | NoSuchDistribution | PreconditionFailed | ResourceInUse | CommonErrors;
/**
 * Delete a distribution.
 *
 * Before you can delete a distribution, you must disable it, which requires permission to update the distribution. Once deleted, a distribution cannot be recovered.
 */
export declare const deleteDistribution: API.OperationMethod<DeleteDistributionRequest, DeleteDistributionResponse, DeleteDistributionError, Credentials | HttpClient.HttpClient>;
export type DeleteDistributionTenantError = AccessDenied | EntityNotFound | InvalidIfMatchVersion | PreconditionFailed | ResourceNotDisabled | CommonErrors;
/**
 * Deletes a distribution tenant. If you use this API operation to delete a distribution tenant that is currently enabled, the request will fail.
 *
 * To delete a distribution tenant, you must first disable the distribution tenant by using the `UpdateDistributionTenant` API operation.
 */
export declare const deleteDistributionTenant: API.OperationMethod<DeleteDistributionTenantRequest, DeleteDistributionTenantResponse, DeleteDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type DeleteFieldLevelEncryptionConfigError = AccessDenied | FieldLevelEncryptionConfigInUse | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionConfig | PreconditionFailed | CommonErrors;
/**
 * Remove a field-level encryption configuration.
 */
export declare const deleteFieldLevelEncryptionConfig: API.OperationMethod<DeleteFieldLevelEncryptionConfigRequest, DeleteFieldLevelEncryptionConfigResponse, DeleteFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteFieldLevelEncryptionProfileError = AccessDenied | FieldLevelEncryptionProfileInUse | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionProfile | PreconditionFailed | CommonErrors;
/**
 * Remove a field-level encryption profile.
 */
export declare const deleteFieldLevelEncryptionProfile: API.OperationMethod<DeleteFieldLevelEncryptionProfileRequest, DeleteFieldLevelEncryptionProfileResponse, DeleteFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionError = FunctionInUse | InvalidIfMatchVersion | NoSuchFunctionExists | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes a CloudFront function.
 *
 * You cannot delete a function if it's associated with a cache behavior. First, update your distributions to remove the function association from all cache behaviors, then delete the function.
 *
 * To delete a function, you must provide the function's name and version (`ETag` value). To get these values, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const deleteFunction: API.OperationMethod<DeleteFunctionRequest, DeleteFunctionResponse, DeleteFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteKeyGroupError = InvalidIfMatchVersion | NoSuchResource | PreconditionFailed | ResourceInUse | CommonErrors;
/**
 * Deletes a key group.
 *
 * You cannot delete a key group that is referenced in a cache behavior. First update your distributions to remove the key group from all cache behaviors, then delete the key group.
 *
 * To delete a key group, you must provide the key group's identifier and version. To get these values, use `ListKeyGroups` followed by `GetKeyGroup` or `GetKeyGroupConfig`.
 */
export declare const deleteKeyGroup: API.OperationMethod<DeleteKeyGroupRequest, DeleteKeyGroupResponse, DeleteKeyGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteKeyValueStoreError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store to delete.
 */
export declare const deleteKeyValueStore: API.OperationMethod<DeleteKeyValueStoreRequest, DeleteKeyValueStoreResponse, DeleteKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitoringSubscriptionError = AccessDenied | NoSuchDistribution | NoSuchMonitoringSubscription | UnsupportedOperation | CommonErrors;
/**
 * Disables additional CloudWatch metrics for the specified CloudFront distribution.
 */
export declare const deleteMonitoringSubscription: API.OperationMethod<DeleteMonitoringSubscriptionRequest, DeleteMonitoringSubscriptionResult, DeleteMonitoringSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginAccessControlError = AccessDenied | InvalidIfMatchVersion | NoSuchOriginAccessControl | OriginAccessControlInUse | PreconditionFailed | CommonErrors;
/**
 * Deletes a CloudFront origin access control.
 *
 * You cannot delete an origin access control if it's in use. First, update all distributions to remove the origin access control from all origins, then delete the origin access control.
 */
export declare const deleteOriginAccessControl: API.OperationMethod<DeleteOriginAccessControlRequest, DeleteOriginAccessControlResponse, DeleteOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type DeleteOriginRequestPolicyError = AccessDenied | IllegalDelete | InvalidIfMatchVersion | NoSuchOriginRequestPolicy | OriginRequestPolicyInUse | PreconditionFailed | CommonErrors;
/**
 * Deletes an origin request policy.
 *
 * You cannot delete an origin request policy if it's attached to any cache behaviors. First update your distributions to remove the origin request policy from all cache behaviors, then delete the origin request policy.
 *
 * To delete an origin request policy, you must provide the policy's identifier and version. To get the identifier, you can use `ListOriginRequestPolicies` or `GetOriginRequestPolicy`.
 */
export declare const deleteOriginRequestPolicy: API.OperationMethod<DeleteOriginRequestPolicyRequest, DeleteOriginRequestPolicyResponse, DeleteOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePublicKeyError = AccessDenied | InvalidIfMatchVersion | NoSuchPublicKey | PreconditionFailed | PublicKeyInUse | CommonErrors;
/**
 * Remove a public key you previously added to CloudFront.
 */
export declare const deletePublicKey: API.OperationMethod<DeletePublicKeyRequest, DeletePublicKeyResponse, DeletePublicKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteRealtimeLogConfigError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | RealtimeLogConfigInUse | CommonErrors;
/**
 * Deletes a real-time log configuration.
 *
 * You cannot delete a real-time log configuration if it's attached to a cache behavior. First update your distributions to remove the real-time log configuration from all cache behaviors, then delete the real-time log configuration.
 *
 * To delete a real-time log configuration, you can provide the configuration's name or its Amazon Resource Name (ARN). You must provide at least one. If you provide both, CloudFront uses the name to identify the real-time log configuration to delete.
 */
export declare const deleteRealtimeLogConfig: API.OperationMethod<DeleteRealtimeLogConfigRequest, DeleteRealtimeLogConfigResponse, DeleteRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDenied | EntityNotFound | IllegalDelete | InvalidArgument | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Deletes the resource policy attached to the CloudFront resource.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteResponseHeadersPolicyError = AccessDenied | IllegalDelete | InvalidIfMatchVersion | NoSuchResponseHeadersPolicy | PreconditionFailed | ResponseHeadersPolicyInUse | CommonErrors;
/**
 * Deletes a response headers policy.
 *
 * You cannot delete a response headers policy if it's attached to a cache behavior. First update your distributions to remove the response headers policy from all cache behaviors, then delete the response headers policy.
 *
 * To delete a response headers policy, you must provide the policy's identifier and version. To get these values, you can use `ListResponseHeadersPolicies` or `GetResponseHeadersPolicy`.
 */
export declare const deleteResponseHeadersPolicy: API.OperationMethod<DeleteResponseHeadersPolicyRequest, DeleteResponseHeadersPolicyResponse, DeleteResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteStreamingDistributionError = AccessDenied | InvalidIfMatchVersion | NoSuchStreamingDistribution | PreconditionFailed | StreamingDistributionNotDisabled | CommonErrors;
/**
 * Delete a streaming distribution. To delete an RTMP distribution using the CloudFront API, perform the following steps.
 *
 * **To delete an RTMP distribution using the CloudFront API**:
 *
 * - Disable the RTMP distribution.
 *
 * - Submit a `GET Streaming Distribution Config` request to get the current configuration and the `Etag` header for the distribution.
 *
 * - Update the XML document that was returned in the response to your `GET Streaming Distribution Config` request to change the value of `Enabled` to `false`.
 *
 * - Submit a `PUT Streaming Distribution Config` request to update the configuration for your distribution. In the request body, include the XML document that you updated in Step 3. Then set the value of the HTTP `If-Match` header to the value of the `ETag` header that CloudFront returned when you submitted the `GET Streaming Distribution Config` request in Step 2.
 *
 * - Review the response to the `PUT Streaming Distribution Config` request to confirm that the distribution was successfully disabled.
 *
 * - Submit a `GET Streaming Distribution Config` request to confirm that your changes have propagated. When propagation is complete, the value of `Status` is `Deployed`.
 *
 * - Submit a `DELETE Streaming Distribution` request. Set the value of the HTTP `If-Match` header to the value of the `ETag` header that CloudFront returned when you submitted the `GET Streaming Distribution Config` request in Step 2.
 *
 * - Review the response to your `DELETE Streaming Distribution` request to confirm that the distribution was successfully deleted.
 *
 * For information about deleting a distribution using the CloudFront console, see Deleting a Distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const deleteStreamingDistribution: API.OperationMethod<DeleteStreamingDistributionRequest, DeleteStreamingDistributionResponse, DeleteStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type DeleteTrustStoreError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Deletes a trust store.
 */
export declare const deleteTrustStore: API.OperationMethod<DeleteTrustStoreRequest, DeleteTrustStoreResponse, DeleteTrustStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcOriginError = AccessDenied | CannotDeleteEntityWhileInUse | EntityNotFound | IllegalDelete | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Delete an Amazon CloudFront VPC origin.
 */
export declare const deleteVpcOrigin: API.OperationMethod<DeleteVpcOriginRequest, DeleteVpcOriginResult, DeleteVpcOriginError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionFunctionError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Describes a connection function.
 */
export declare const describeConnectionFunction: API.OperationMethod<DescribeConnectionFunctionRequest, DescribeConnectionFunctionResult, DescribeConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type DescribeFunctionError = NoSuchFunctionExists | UnsupportedOperation | CommonErrors;
/**
 * Gets configuration information and metadata about a CloudFront function, but not the function's code. To get a function's code, use `GetFunction`.
 *
 * To get configuration information and metadata about a function, you must provide the function's name and stage. To get these values, you can use `ListFunctions`.
 */
export declare const describeFunction: API.OperationMethod<DescribeFunctionRequest, DescribeFunctionResult, DescribeFunctionError, Credentials | HttpClient.HttpClient>;
export type DescribeKeyValueStoreError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store and its configuration.
 */
export declare const describeKeyValueStore: API.OperationMethod<DescribeKeyValueStoreRequest, DescribeKeyValueStoreResult, DescribeKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type DisassociateDistributionTenantWebACLError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Disassociates a distribution tenant from the WAF web ACL.
 */
export declare const disassociateDistributionTenantWebACL: API.OperationMethod<DisassociateDistributionTenantWebACLRequest, DisassociateDistributionTenantWebACLResult, DisassociateDistributionTenantWebACLError, Credentials | HttpClient.HttpClient>;
export type DisassociateDistributionWebACLError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Disassociates a distribution from the WAF web ACL.
 */
export declare const disassociateDistributionWebACL: API.OperationMethod<DisassociateDistributionWebACLRequest, DisassociateDistributionWebACLResult, DisassociateDistributionWebACLError, Credentials | HttpClient.HttpClient>;
export type GetAnycastIpListError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Gets an Anycast static IP list.
 */
export declare const getAnycastIpList: API.OperationMethod<GetAnycastIpListRequest, GetAnycastIpListResult, GetAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type GetCachePolicyError = AccessDenied | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a cache policy, including the following metadata:
 *
 * - The policy's identifier.
 *
 * - The date and time when the policy was last modified.
 *
 * To get a cache policy, you must provide the policy's identifier. If the cache policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the cache policy is not attached to a cache behavior, you can get the identifier using `ListCachePolicies`.
 */
export declare const getCachePolicy: API.OperationMethod<GetCachePolicyRequest, GetCachePolicyResult, GetCachePolicyError, Credentials | HttpClient.HttpClient>;
export type GetCachePolicyConfigError = AccessDenied | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a cache policy configuration.
 *
 * To get a cache policy configuration, you must provide the policy's identifier. If the cache policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the cache policy is not attached to a cache behavior, you can get the identifier using `ListCachePolicies`.
 */
export declare const getCachePolicyConfig: API.OperationMethod<GetCachePolicyConfigRequest, GetCachePolicyConfigResult, GetCachePolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetCloudFrontOriginAccessIdentityError = AccessDenied | NoSuchCloudFrontOriginAccessIdentity | CommonErrors;
/**
 * Get the information about an origin access identity.
 */
export declare const getCloudFrontOriginAccessIdentity: API.OperationMethod<GetCloudFrontOriginAccessIdentityRequest, GetCloudFrontOriginAccessIdentityResult, GetCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type GetCloudFrontOriginAccessIdentityConfigError = AccessDenied | NoSuchCloudFrontOriginAccessIdentity | CommonErrors;
/**
 * Get the configuration information about an origin access identity.
 */
export declare const getCloudFrontOriginAccessIdentityConfig: API.OperationMethod<GetCloudFrontOriginAccessIdentityConfigRequest, GetCloudFrontOriginAccessIdentityConfigResult, GetCloudFrontOriginAccessIdentityConfigError, Credentials | HttpClient.HttpClient>;
export type GetConnectionFunctionError = AccessDenied | EntityNotFound | UnsupportedOperation | CommonErrors;
/**
 * Gets a connection function.
 */
export declare const getConnectionFunction: API.OperationMethod<GetConnectionFunctionRequest, GetConnectionFunctionResult, GetConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type GetConnectionGroupError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a connection group.
 */
export declare const getConnectionGroup: API.OperationMethod<GetConnectionGroupRequest, GetConnectionGroupResult, GetConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type GetConnectionGroupByRoutingEndpointError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a connection group by using the endpoint that you specify.
 */
export declare const getConnectionGroupByRoutingEndpoint: API.OperationMethod<GetConnectionGroupByRoutingEndpointRequest, GetConnectionGroupByRoutingEndpointResult, GetConnectionGroupByRoutingEndpointError, Credentials | HttpClient.HttpClient>;
export type GetContinuousDeploymentPolicyError = AccessDenied | NoSuchContinuousDeploymentPolicy | CommonErrors;
/**
 * Gets a continuous deployment policy, including metadata (the policy's identifier and the date and time when the policy was last modified).
 */
export declare const getContinuousDeploymentPolicy: API.OperationMethod<GetContinuousDeploymentPolicyRequest, GetContinuousDeploymentPolicyResult, GetContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type GetContinuousDeploymentPolicyConfigError = AccessDenied | NoSuchContinuousDeploymentPolicy | CommonErrors;
/**
 * Gets configuration information about a continuous deployment policy.
 */
export declare const getContinuousDeploymentPolicyConfig: API.OperationMethod<GetContinuousDeploymentPolicyConfigRequest, GetContinuousDeploymentPolicyConfigResult, GetContinuousDeploymentPolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetDistributionError = AccessDenied | NoSuchDistribution | CommonErrors;
/**
 * Get the information about a distribution.
 */
export declare const getDistribution: API.OperationMethod<GetDistributionRequest, GetDistributionResult, GetDistributionError, Credentials | HttpClient.HttpClient>;
export type GetDistributionConfigError = AccessDenied | NoSuchDistribution | CommonErrors;
/**
 * Get the configuration information about a distribution.
 */
export declare const getDistributionConfig: API.OperationMethod<GetDistributionConfigRequest, GetDistributionConfigResult, GetDistributionConfigError, Credentials | HttpClient.HttpClient>;
export type GetDistributionTenantError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a distribution tenant.
 */
export declare const getDistributionTenant: API.OperationMethod<GetDistributionTenantRequest, GetDistributionTenantResult, GetDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type GetDistributionTenantByDomainError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets information about a distribution tenant by the associated domain.
 */
export declare const getDistributionTenantByDomain: API.OperationMethod<GetDistributionTenantByDomainRequest, GetDistributionTenantByDomainResult, GetDistributionTenantByDomainError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionError = AccessDenied | NoSuchFieldLevelEncryptionConfig | CommonErrors;
/**
 * Get the field-level encryption configuration information.
 */
export declare const getFieldLevelEncryption: API.OperationMethod<GetFieldLevelEncryptionRequest, GetFieldLevelEncryptionResult, GetFieldLevelEncryptionError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionConfigError = AccessDenied | NoSuchFieldLevelEncryptionConfig | CommonErrors;
/**
 * Get the field-level encryption configuration information.
 */
export declare const getFieldLevelEncryptionConfig: API.OperationMethod<GetFieldLevelEncryptionConfigRequest, GetFieldLevelEncryptionConfigResult, GetFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionProfileError = AccessDenied | NoSuchFieldLevelEncryptionProfile | CommonErrors;
/**
 * Get the field-level encryption profile information.
 */
export declare const getFieldLevelEncryptionProfile: API.OperationMethod<GetFieldLevelEncryptionProfileRequest, GetFieldLevelEncryptionProfileResult, GetFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type GetFieldLevelEncryptionProfileConfigError = AccessDenied | NoSuchFieldLevelEncryptionProfile | CommonErrors;
/**
 * Get the field-level encryption profile configuration information.
 */
export declare const getFieldLevelEncryptionProfileConfig: API.OperationMethod<GetFieldLevelEncryptionProfileConfigRequest, GetFieldLevelEncryptionProfileConfigResult, GetFieldLevelEncryptionProfileConfigError, Credentials | HttpClient.HttpClient>;
export type GetFunctionError = NoSuchFunctionExists | UnsupportedOperation | CommonErrors;
/**
 * Gets the code of a CloudFront function. To get configuration information and metadata about a function, use `DescribeFunction`.
 *
 * To get a function's code, you must provide the function's name and stage. To get these values, you can use `ListFunctions`.
 */
export declare const getFunction: API.OperationMethod<GetFunctionRequest, GetFunctionResult, GetFunctionError, Credentials | HttpClient.HttpClient>;
export type GetInvalidationError = AccessDenied | NoSuchDistribution | NoSuchInvalidation | CommonErrors;
/**
 * Get the information about an invalidation.
 */
export declare const getInvalidation: API.OperationMethod<GetInvalidationRequest, GetInvalidationResult, GetInvalidationError, Credentials | HttpClient.HttpClient>;
export type GetInvalidationForDistributionTenantError = AccessDenied | EntityNotFound | NoSuchInvalidation | CommonErrors;
/**
 * Gets information about a specific invalidation for a distribution tenant.
 */
export declare const getInvalidationForDistributionTenant: API.OperationMethod<GetInvalidationForDistributionTenantRequest, GetInvalidationForDistributionTenantResult, GetInvalidationForDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type GetKeyGroupError = NoSuchResource | CommonErrors;
/**
 * Gets a key group, including the date and time when the key group was last modified.
 *
 * To get a key group, you must provide the key group's identifier. If the key group is referenced in a distribution's cache behavior, you can get the key group's identifier using `ListDistributions` or `GetDistribution`. If the key group is not referenced in a cache behavior, you can get the identifier using `ListKeyGroups`.
 */
export declare const getKeyGroup: API.OperationMethod<GetKeyGroupRequest, GetKeyGroupResult, GetKeyGroupError, Credentials | HttpClient.HttpClient>;
export type GetKeyGroupConfigError = NoSuchResource | CommonErrors;
/**
 * Gets a key group configuration.
 *
 * To get a key group configuration, you must provide the key group's identifier. If the key group is referenced in a distribution's cache behavior, you can get the key group's identifier using `ListDistributions` or `GetDistribution`. If the key group is not referenced in a cache behavior, you can get the identifier using `ListKeyGroups`.
 */
export declare const getKeyGroupConfig: API.OperationMethod<GetKeyGroupConfigRequest, GetKeyGroupConfigResult, GetKeyGroupConfigError, Credentials | HttpClient.HttpClient>;
export type GetManagedCertificateDetailsError = AccessDenied | EntityNotFound | CommonErrors;
/**
 * Gets details about the CloudFront managed ACM certificate.
 */
export declare const getManagedCertificateDetails: API.OperationMethod<GetManagedCertificateDetailsRequest, GetManagedCertificateDetailsResult, GetManagedCertificateDetailsError, Credentials | HttpClient.HttpClient>;
export type GetMonitoringSubscriptionError = AccessDenied | NoSuchDistribution | NoSuchMonitoringSubscription | UnsupportedOperation | CommonErrors;
/**
 * Gets information about whether additional CloudWatch metrics are enabled for the specified CloudFront distribution.
 */
export declare const getMonitoringSubscription: API.OperationMethod<GetMonitoringSubscriptionRequest, GetMonitoringSubscriptionResult, GetMonitoringSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetOriginAccessControlError = AccessDenied | NoSuchOriginAccessControl | CommonErrors;
/**
 * Gets a CloudFront origin access control, including its unique identifier.
 */
export declare const getOriginAccessControl: API.OperationMethod<GetOriginAccessControlRequest, GetOriginAccessControlResult, GetOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type GetOriginAccessControlConfigError = AccessDenied | NoSuchOriginAccessControl | CommonErrors;
/**
 * Gets a CloudFront origin access control configuration.
 */
export declare const getOriginAccessControlConfig: API.OperationMethod<GetOriginAccessControlConfigRequest, GetOriginAccessControlConfigResult, GetOriginAccessControlConfigError, Credentials | HttpClient.HttpClient>;
export type GetOriginRequestPolicyError = AccessDenied | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets an origin request policy, including the following metadata:
 *
 * - The policy's identifier.
 *
 * - The date and time when the policy was last modified.
 *
 * To get an origin request policy, you must provide the policy's identifier. If the origin request policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the origin request policy is not attached to a cache behavior, you can get the identifier using `ListOriginRequestPolicies`.
 */
export declare const getOriginRequestPolicy: API.OperationMethod<GetOriginRequestPolicyRequest, GetOriginRequestPolicyResult, GetOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type GetOriginRequestPolicyConfigError = AccessDenied | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets an origin request policy configuration.
 *
 * To get an origin request policy configuration, you must provide the policy's identifier. If the origin request policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the origin request policy is not attached to a cache behavior, you can get the identifier using `ListOriginRequestPolicies`.
 */
export declare const getOriginRequestPolicyConfig: API.OperationMethod<GetOriginRequestPolicyConfigRequest, GetOriginRequestPolicyConfigResult, GetOriginRequestPolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetPublicKeyError = AccessDenied | NoSuchPublicKey | CommonErrors;
/**
 * Gets a public key.
 */
export declare const getPublicKey: API.OperationMethod<GetPublicKeyRequest, GetPublicKeyResult, GetPublicKeyError, Credentials | HttpClient.HttpClient>;
export type GetPublicKeyConfigError = AccessDenied | NoSuchPublicKey | CommonErrors;
/**
 * Gets a public key configuration.
 */
export declare const getPublicKeyConfig: API.OperationMethod<GetPublicKeyConfigRequest, GetPublicKeyConfigResult, GetPublicKeyConfigError, Credentials | HttpClient.HttpClient>;
export type GetRealtimeLogConfigError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | CommonErrors;
/**
 * Gets a real-time log configuration.
 *
 * To get a real-time log configuration, you can provide the configuration's name or its Amazon Resource Name (ARN). You must provide at least one. If you provide both, CloudFront uses the name to identify the real-time log configuration to get.
 */
export declare const getRealtimeLogConfig: API.OperationMethod<GetRealtimeLogConfigRequest, GetRealtimeLogConfigResult, GetRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Retrieves the resource policy for the specified CloudFront resource that you own and have shared.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResult, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetResponseHeadersPolicyError = AccessDenied | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a response headers policy, including metadata (the policy's identifier and the date and time when the policy was last modified).
 *
 * To get a response headers policy, you must provide the policy's identifier. If the response headers policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the response headers policy is not attached to a cache behavior, you can get the identifier using `ListResponseHeadersPolicies`.
 */
export declare const getResponseHeadersPolicy: API.OperationMethod<GetResponseHeadersPolicyRequest, GetResponseHeadersPolicyResult, GetResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type GetResponseHeadersPolicyConfigError = AccessDenied | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a response headers policy configuration.
 *
 * To get a response headers policy configuration, you must provide the policy's identifier. If the response headers policy is attached to a distribution's cache behavior, you can get the policy's identifier using `ListDistributions` or `GetDistribution`. If the response headers policy is not attached to a cache behavior, you can get the identifier using `ListResponseHeadersPolicies`.
 */
export declare const getResponseHeadersPolicyConfig: API.OperationMethod<GetResponseHeadersPolicyConfigRequest, GetResponseHeadersPolicyConfigResult, GetResponseHeadersPolicyConfigError, Credentials | HttpClient.HttpClient>;
export type GetStreamingDistributionError = AccessDenied | NoSuchStreamingDistribution | CommonErrors;
/**
 * Gets information about a specified RTMP distribution, including the distribution configuration.
 */
export declare const getStreamingDistribution: API.OperationMethod<GetStreamingDistributionRequest, GetStreamingDistributionResult, GetStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type GetStreamingDistributionConfigError = AccessDenied | NoSuchStreamingDistribution | CommonErrors;
/**
 * Get the configuration information about a streaming distribution.
 */
export declare const getStreamingDistributionConfig: API.OperationMethod<GetStreamingDistributionConfigRequest, GetStreamingDistributionConfigResult, GetStreamingDistributionConfigError, Credentials | HttpClient.HttpClient>;
export type GetTrustStoreError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Gets a trust store.
 */
export declare const getTrustStore: API.OperationMethod<GetTrustStoreRequest, GetTrustStoreResult, GetTrustStoreError, Credentials | HttpClient.HttpClient>;
export type GetVpcOriginError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Get the details of an Amazon CloudFront VPC origin.
 */
export declare const getVpcOrigin: API.OperationMethod<GetVpcOriginRequest, GetVpcOriginResult, GetVpcOriginError, Credentials | HttpClient.HttpClient>;
export type ListAnycastIpListsError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists your Anycast static IP lists.
 */
export declare const listAnycastIpLists: API.OperationMethod<ListAnycastIpListsRequest, ListAnycastIpListsResult, ListAnycastIpListsError, Credentials | HttpClient.HttpClient>;
export type ListCachePoliciesError = AccessDenied | InvalidArgument | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a list of cache policies.
 *
 * You can optionally apply a filter to return only the managed policies created by Amazon Web Services, or only the custom policies created in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listCachePolicies: API.OperationMethod<ListCachePoliciesRequest, ListCachePoliciesResult, ListCachePoliciesError, Credentials | HttpClient.HttpClient>;
export type ListCloudFrontOriginAccessIdentitiesError = InvalidArgument | CommonErrors;
/**
 * Lists origin access identities.
 */
export declare const listCloudFrontOriginAccessIdentities: API.PaginatedOperationMethod<ListCloudFrontOriginAccessIdentitiesRequest, ListCloudFrontOriginAccessIdentitiesResult, ListCloudFrontOriginAccessIdentitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConflictingAliasesError = InvalidArgument | NoSuchDistribution | CommonErrors;
/**
 * The `ListConflictingAliases` API operation only supports standard distributions. To list domain conflicts for both standard distributions and distribution tenants, we recommend that you use the ListDomainConflicts API operation instead.
 *
 * Gets a list of aliases that conflict or overlap with the provided alias, and the associated CloudFront standard distribution and Amazon Web Services accounts for each conflicting alias. An alias is commonly known as a custom domain or vanity domain. It can also be called a CNAME or alternate domain name.
 *
 * In the returned list, the standard distribution and account IDs are partially hidden, which allows you to identify the standard distribution and accounts that you own, and helps to protect the information of ones that you don't own.
 *
 * Use this operation to find aliases that are in use in CloudFront that conflict or overlap with the provided alias. For example, if you provide `www.example.com` as input, the returned list can include `www.example.com` and the overlapping wildcard alternate domain name (`*.example.com`), if they exist. If you provide `*.example.com` as input, the returned list can include `*.example.com` and any alternate domain names covered by that wildcard (for example, `www.example.com`, `test.example.com`, `dev.example.com`, and so on), if they exist.
 *
 * To list conflicting aliases, specify the alias to search and the ID of a standard distribution in your account that has an attached TLS certificate that includes the provided alias. For more information, including how to set up the standard distribution and certificate, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listConflictingAliases: API.OperationMethod<ListConflictingAliasesRequest, ListConflictingAliasesResult, ListConflictingAliasesError, Credentials | HttpClient.HttpClient>;
export type ListConnectionFunctionsError = AccessDenied | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists connection functions.
 */
export declare const listConnectionFunctions: API.PaginatedOperationMethod<ListConnectionFunctionsRequest, ListConnectionFunctionsResult, ListConnectionFunctionsError, Credentials | HttpClient.HttpClient, ConnectionFunctionSummary>;
export type ListConnectionGroupsError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists the connection groups in your Amazon Web Services account.
 */
export declare const listConnectionGroups: API.PaginatedOperationMethod<ListConnectionGroupsRequest, ListConnectionGroupsResult, ListConnectionGroupsError, Credentials | HttpClient.HttpClient, ConnectionGroupSummary>;
export type ListContinuousDeploymentPoliciesError = AccessDenied | InvalidArgument | NoSuchContinuousDeploymentPolicy | CommonErrors;
/**
 * Gets a list of the continuous deployment policies in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listContinuousDeploymentPolicies: API.OperationMethod<ListContinuousDeploymentPoliciesRequest, ListContinuousDeploymentPoliciesResult, ListContinuousDeploymentPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsError = InvalidArgument | CommonErrors;
/**
 * List CloudFront distributions.
 */
export declare const listDistributions: API.PaginatedOperationMethod<ListDistributionsRequest, ListDistributionsResult, ListDistributionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByAnycastIpListIdError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists the distributions in your account that are associated with the specified `AnycastIpListId`.
 */
export declare const listDistributionsByAnycastIpListId: API.OperationMethod<ListDistributionsByAnycastIpListIdRequest, ListDistributionsByAnycastIpListIdResult, ListDistributionsByAnycastIpListIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByCachePolicyIdError = AccessDenied | InvalidArgument | NoSuchCachePolicy | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that's associated with the specified cache policy.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByCachePolicyId: API.OperationMethod<ListDistributionsByCachePolicyIdRequest, ListDistributionsByCachePolicyIdResult, ListDistributionsByCachePolicyIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByConnectionFunctionError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists distributions by connection function.
 */
export declare const listDistributionsByConnectionFunction: API.PaginatedOperationMethod<ListDistributionsByConnectionFunctionRequest, ListDistributionsByConnectionFunctionResult, ListDistributionsByConnectionFunctionError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByConnectionModeError = AccessDenied | InvalidArgument | CommonErrors;
/**
 * Lists the distributions by the connection mode that you specify.
 */
export declare const listDistributionsByConnectionMode: API.PaginatedOperationMethod<ListDistributionsByConnectionModeRequest, ListDistributionsByConnectionModeResult, ListDistributionsByConnectionModeError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByKeyGroupError = InvalidArgument | NoSuchResource | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that references the specified key group.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByKeyGroup: API.OperationMethod<ListDistributionsByKeyGroupRequest, ListDistributionsByKeyGroupResult, ListDistributionsByKeyGroupError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByOriginRequestPolicyIdError = AccessDenied | InvalidArgument | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that's associated with the specified origin request policy.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByOriginRequestPolicyId: API.OperationMethod<ListDistributionsByOriginRequestPolicyIdRequest, ListDistributionsByOriginRequestPolicyIdResult, ListDistributionsByOriginRequestPolicyIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByOwnedResourceError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Lists the CloudFront distributions that are associated with the specified resource that you own.
 */
export declare const listDistributionsByOwnedResource: API.OperationMethod<ListDistributionsByOwnedResourceRequest, ListDistributionsByOwnedResourceResult, ListDistributionsByOwnedResourceError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByRealtimeLogConfigError = InvalidArgument | CommonErrors;
/**
 * Gets a list of distributions that have a cache behavior that's associated with the specified real-time log configuration.
 *
 * You can specify the real-time log configuration by its name or its Amazon Resource Name (ARN). You must provide at least one. If you provide both, CloudFront uses the name to identify the real-time log configuration to list distributions for.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByRealtimeLogConfig: API.OperationMethod<ListDistributionsByRealtimeLogConfigRequest, ListDistributionsByRealtimeLogConfigResult, ListDistributionsByRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByResponseHeadersPolicyIdError = AccessDenied | InvalidArgument | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a list of distribution IDs for distributions that have a cache behavior that's associated with the specified response headers policy.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDistributionsByResponseHeadersPolicyId: API.OperationMethod<ListDistributionsByResponseHeadersPolicyIdRequest, ListDistributionsByResponseHeadersPolicyIdResult, ListDistributionsByResponseHeadersPolicyIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByTrustStoreError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists distributions by trust store.
 */
export declare const listDistributionsByTrustStore: API.PaginatedOperationMethod<ListDistributionsByTrustStoreRequest, ListDistributionsByTrustStoreResult, ListDistributionsByTrustStoreError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDistributionsByVpcOriginIdError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * List CloudFront distributions by their VPC origin ID.
 */
export declare const listDistributionsByVpcOriginId: API.OperationMethod<ListDistributionsByVpcOriginIdRequest, ListDistributionsByVpcOriginIdResult, ListDistributionsByVpcOriginIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionsByWebACLIdError = InvalidArgument | InvalidWebACLId | CommonErrors;
/**
 * List the distributions that are associated with a specified WAF web ACL.
 */
export declare const listDistributionsByWebACLId: API.OperationMethod<ListDistributionsByWebACLIdRequest, ListDistributionsByWebACLIdResult, ListDistributionsByWebACLIdError, Credentials | HttpClient.HttpClient>;
export type ListDistributionTenantsError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists the distribution tenants in your Amazon Web Services account.
 */
export declare const listDistributionTenants: API.PaginatedOperationMethod<ListDistributionTenantsRequest, ListDistributionTenantsResult, ListDistributionTenantsError, Credentials | HttpClient.HttpClient, DistributionTenantSummary>;
export type ListDistributionTenantsByCustomizationError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists distribution tenants by the customization that you specify.
 *
 * You must specify either the `CertificateArn` parameter or `WebACLArn` parameter, but not both in the same request.
 */
export declare const listDistributionTenantsByCustomization: API.PaginatedOperationMethod<ListDistributionTenantsByCustomizationRequest, ListDistributionTenantsByCustomizationResult, ListDistributionTenantsByCustomizationError, Credentials | HttpClient.HttpClient, DistributionTenantSummary>;
export type ListDomainConflictsError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * We recommend that you use the `ListDomainConflicts` API operation to check for domain conflicts, as it supports both standard distributions and distribution tenants. ListConflictingAliases performs similar checks but only supports standard distributions.
 *
 * Lists existing domain associations that conflict with the domain that you specify.
 *
 * You can use this API operation to identify potential domain conflicts when moving domains between standard distributions and/or distribution tenants. Domain conflicts must be resolved first before they can be moved.
 *
 * For example, if you provide `www.example.com` as input, the returned list can include `www.example.com` and the overlapping wildcard alternate domain name (`*.example.com`), if they exist. If you provide `*.example.com` as input, the returned list can include `*.example.com` and any alternate domain names covered by that wildcard (for example, `www.example.com`, `test.example.com`, `dev.example.com`, and so on), if they exist.
 *
 * To list conflicting domains, specify the following:
 *
 * - The domain to search for
 *
 * - The ID of a standard distribution or distribution tenant in your account that has an attached TLS certificate, which covers the specified domain
 *
 * For more information, including how to set up the standard distribution or distribution tenant, and the certificate, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listDomainConflicts: API.PaginatedOperationMethod<ListDomainConflictsRequest, ListDomainConflictsResult, ListDomainConflictsError, Credentials | HttpClient.HttpClient, DomainConflict>;
export type ListFieldLevelEncryptionConfigsError = InvalidArgument | CommonErrors;
/**
 * List all field-level encryption configurations that have been created in CloudFront for this account.
 */
export declare const listFieldLevelEncryptionConfigs: API.OperationMethod<ListFieldLevelEncryptionConfigsRequest, ListFieldLevelEncryptionConfigsResult, ListFieldLevelEncryptionConfigsError, Credentials | HttpClient.HttpClient>;
export type ListFieldLevelEncryptionProfilesError = InvalidArgument | CommonErrors;
/**
 * Request a list of field-level encryption profiles that have been created in CloudFront for this account.
 */
export declare const listFieldLevelEncryptionProfiles: API.OperationMethod<ListFieldLevelEncryptionProfilesRequest, ListFieldLevelEncryptionProfilesResult, ListFieldLevelEncryptionProfilesError, Credentials | HttpClient.HttpClient>;
export type ListFunctionsError = InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Gets a list of all CloudFront functions in your Amazon Web Services account.
 *
 * You can optionally apply a filter to return only the functions that are in the specified stage, either `DEVELOPMENT` or `LIVE`.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listFunctions: API.OperationMethod<ListFunctionsRequest, ListFunctionsResult, ListFunctionsError, Credentials | HttpClient.HttpClient>;
export type ListInvalidationsError = AccessDenied | InvalidArgument | NoSuchDistribution | CommonErrors;
/**
 * Lists invalidation batches.
 */
export declare const listInvalidations: API.PaginatedOperationMethod<ListInvalidationsRequest, ListInvalidationsResult, ListInvalidationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListInvalidationsForDistributionTenantError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists the invalidations for a distribution tenant.
 */
export declare const listInvalidationsForDistributionTenant: API.PaginatedOperationMethod<ListInvalidationsForDistributionTenantRequest, ListInvalidationsForDistributionTenantResult, ListInvalidationsForDistributionTenantError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKeyGroupsError = InvalidArgument | CommonErrors;
/**
 * Gets a list of key groups.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listKeyGroups: API.OperationMethod<ListKeyGroupsRequest, ListKeyGroupsResult, ListKeyGroupsError, Credentials | HttpClient.HttpClient>;
export type ListKeyValueStoresError = AccessDenied | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value stores to list.
 */
export declare const listKeyValueStores: API.PaginatedOperationMethod<ListKeyValueStoresRequest, ListKeyValueStoresResult, ListKeyValueStoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOriginAccessControlsError = InvalidArgument | CommonErrors;
/**
 * Gets the list of CloudFront origin access controls (OACs) in this Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send another request that specifies the `NextMarker` value from the current response as the `Marker` value in the next request.
 *
 * If you're not using origin access controls for your Amazon Web Services account, the `ListOriginAccessControls` operation doesn't return the `Items` element in the response.
 */
export declare const listOriginAccessControls: API.PaginatedOperationMethod<ListOriginAccessControlsRequest, ListOriginAccessControlsResult, ListOriginAccessControlsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOriginRequestPoliciesError = AccessDenied | InvalidArgument | NoSuchOriginRequestPolicy | CommonErrors;
/**
 * Gets a list of origin request policies.
 *
 * You can optionally apply a filter to return only the managed policies created by Amazon Web Services, or only the custom policies created in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listOriginRequestPolicies: API.OperationMethod<ListOriginRequestPoliciesRequest, ListOriginRequestPoliciesResult, ListOriginRequestPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListPublicKeysError = InvalidArgument | CommonErrors;
/**
 * List all public keys that have been added to CloudFront for this account.
 */
export declare const listPublicKeys: API.PaginatedOperationMethod<ListPublicKeysRequest, ListPublicKeysResult, ListPublicKeysError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRealtimeLogConfigsError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | CommonErrors;
/**
 * Gets a list of real-time log configurations.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listRealtimeLogConfigs: API.OperationMethod<ListRealtimeLogConfigsRequest, ListRealtimeLogConfigsResult, ListRealtimeLogConfigsError, Credentials | HttpClient.HttpClient>;
export type ListResponseHeadersPoliciesError = AccessDenied | InvalidArgument | NoSuchResponseHeadersPolicy | CommonErrors;
/**
 * Gets a list of response headers policies.
 *
 * You can optionally apply a filter to get only the managed policies created by Amazon Web Services, or only the custom policies created in your Amazon Web Services account.
 *
 * You can optionally specify the maximum number of items to receive in the response. If the total number of items in the list exceeds the maximum that you specify, or the default maximum, the response is paginated. To get the next page of items, send a subsequent request that specifies the `NextMarker` value from the current response as the `Marker` value in the subsequent request.
 */
export declare const listResponseHeadersPolicies: API.OperationMethod<ListResponseHeadersPoliciesRequest, ListResponseHeadersPoliciesResult, ListResponseHeadersPoliciesError, Credentials | HttpClient.HttpClient>;
export type ListStreamingDistributionsError = InvalidArgument | CommonErrors;
/**
 * List streaming distributions.
 */
export declare const listStreamingDistributions: API.PaginatedOperationMethod<ListStreamingDistributionsRequest, ListStreamingDistributionsResult, ListStreamingDistributionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDenied | InvalidArgument | InvalidTagging | NoSuchResource | CommonErrors;
/**
 * List tags for a CloudFront resource. For more information, see Tagging a distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTrustStoresError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Lists trust stores.
 */
export declare const listTrustStores: API.PaginatedOperationMethod<ListTrustStoresRequest, ListTrustStoresResult, ListTrustStoresError, Credentials | HttpClient.HttpClient, TrustStoreSummary>;
export type ListVpcOriginsError = AccessDenied | EntityNotFound | InvalidArgument | UnsupportedOperation | CommonErrors;
/**
 * List the CloudFront VPC origins in your account.
 */
export declare const listVpcOrigins: API.OperationMethod<ListVpcOriginsRequest, ListVpcOriginsResult, ListVpcOriginsError, Credentials | HttpClient.HttpClient>;
export type PublishConnectionFunctionError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Publishes a connection function.
 */
export declare const publishConnectionFunction: API.OperationMethod<PublishConnectionFunctionRequest, PublishConnectionFunctionResult, PublishConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type PublishFunctionError = InvalidArgument | InvalidIfMatchVersion | NoSuchFunctionExists | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Publishes a CloudFront function by copying the function code from the `DEVELOPMENT` stage to `LIVE`. This automatically updates all cache behaviors that are using this function to use the newly published copy in the `LIVE` stage.
 *
 * When a function is published to the `LIVE` stage, you can attach the function to a distribution's cache behavior, using the function's Amazon Resource Name (ARN).
 *
 * To publish a function, you must provide the function's name and version (`ETag` value). To get these values, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const publishFunction: API.OperationMethod<PublishFunctionRequest, PublishFunctionResult, PublishFunctionError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDenied | EntityNotFound | IllegalUpdate | InvalidArgument | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Creates a resource control policy for a given CloudFront resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResult, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDenied | InvalidArgument | InvalidTagging | NoSuchResource | CommonErrors;
/**
 * Add tags to a CloudFront resource. For more information, see Tagging a distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestConnectionFunctionError = EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | TestFunctionFailed | UnsupportedOperation | CommonErrors;
/**
 * Tests a connection function.
 */
export declare const testConnectionFunction: API.OperationMethod<TestConnectionFunctionRequest, TestConnectionFunctionResult, TestConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type TestFunctionError = InvalidArgument | InvalidIfMatchVersion | NoSuchFunctionExists | TestFunctionFailed | UnsupportedOperation | CommonErrors;
/**
 * Tests a CloudFront function.
 *
 * To test a function, you provide an *event object* that represents an HTTP request or response that your CloudFront distribution could receive in production. CloudFront runs the function, passing it the event object that you provided, and returns the function's result (the modified event object) in the response. The response also contains function logs and error messages, if any exist. For more information about testing functions, see Testing functions in the *Amazon CloudFront Developer Guide*.
 *
 * To test a function, you provide the function's name and version (`ETag` value) along with the event object. To get the function's name and version, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const testFunction: API.OperationMethod<TestFunctionRequest, TestFunctionResult, TestFunctionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDenied | InvalidArgument | InvalidTagging | NoSuchResource | CommonErrors;
/**
 * Remove tags from a CloudFront resource. For more information, see Tagging a distribution in the *Amazon CloudFront Developer Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnycastIpListError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Updates an Anycast static IP list.
 */
export declare const updateAnycastIpList: API.OperationMethod<UpdateAnycastIpListRequest, UpdateAnycastIpListResult, UpdateAnycastIpListError, Credentials | HttpClient.HttpClient>;
export type UpdateCachePolicyError = AccessDenied | CachePolicyAlreadyExists | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchCachePolicy | PreconditionFailed | TooManyCookiesInCachePolicy | TooManyHeadersInCachePolicy | TooManyQueryStringsInCachePolicy | CommonErrors;
/**
 * Updates a cache policy configuration.
 *
 * When you update a cache policy configuration, all the fields are updated with the values provided in the request. You cannot update some fields independent of others. To update a cache policy configuration:
 *
 * - Use `GetCachePolicyConfig` to get the current configuration.
 *
 * - Locally modify the fields in the cache policy configuration that you want to update.
 *
 * - Call `UpdateCachePolicy` by providing the entire cache policy configuration, including the fields that you modified and those that you didn't.
 *
 * If your minimum TTL is greater than 0, CloudFront will cache content for at least the duration specified in the cache policy's minimum TTL, even if the `Cache-Control: no-cache`, `no-store`, or `private` directives are present in the origin headers.
 */
export declare const updateCachePolicy: API.OperationMethod<UpdateCachePolicyRequest, UpdateCachePolicyResult, UpdateCachePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudFrontOriginAccessIdentityError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | MissingBody | NoSuchCloudFrontOriginAccessIdentity | PreconditionFailed | CommonErrors;
/**
 * Update an origin access identity.
 */
export declare const updateCloudFrontOriginAccessIdentity: API.OperationMethod<UpdateCloudFrontOriginAccessIdentityRequest, UpdateCloudFrontOriginAccessIdentityResult, UpdateCloudFrontOriginAccessIdentityError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionFunctionError = AccessDenied | EntityNotFound | EntitySizeLimitExceeded | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Updates a connection function.
 */
export declare const updateConnectionFunction: API.OperationMethod<UpdateConnectionFunctionRequest, UpdateConnectionFunctionResult, UpdateConnectionFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionGroupError = AccessDenied | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | ResourceInUse | CommonErrors;
/**
 * Updates a connection group.
 */
export declare const updateConnectionGroup: API.OperationMethod<UpdateConnectionGroupRequest, UpdateConnectionGroupResult, UpdateConnectionGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateContinuousDeploymentPolicyError = AccessDenied | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchContinuousDeploymentPolicy | PreconditionFailed | StagingDistributionInUse | CommonErrors;
/**
 * Updates a continuous deployment policy. You can update a continuous deployment policy to enable or disable it, to change the percentage of traffic that it sends to the staging distribution, or to change the staging distribution that it sends traffic to.
 *
 * When you update a continuous deployment policy configuration, all the fields are updated with the values that are provided in the request. You cannot update some fields independent of others. To update a continuous deployment policy configuration:
 *
 * - Use `GetContinuousDeploymentPolicyConfig` to get the current configuration.
 *
 * - Locally modify the fields in the continuous deployment policy configuration that you want to update.
 *
 * - Use `UpdateContinuousDeploymentPolicy`, providing the entire continuous deployment policy configuration, including the fields that you modified and those that you didn't.
 */
export declare const updateContinuousDeploymentPolicy: API.OperationMethod<UpdateContinuousDeploymentPolicyRequest, UpdateContinuousDeploymentPolicyResult, UpdateContinuousDeploymentPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionError = AccessDenied | CNAMEAlreadyExists | ContinuousDeploymentPolicyInUse | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalOriginAccessConfiguration | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidDomainNameForOriginAccessControl | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidIfMatchVersion | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchContinuousDeploymentPolicy | NoSuchDistribution | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | PreconditionFailed | RealtimeLogConfigOwnerMismatch | StagingDistributionInUse | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Updates the configuration for a CloudFront distribution.
 *
 * The update process includes getting the current distribution configuration, updating it to make your changes, and then submitting an `UpdateDistribution` request to make the updates.
 *
 * **To update a web distribution using the CloudFront API**
 *
 * - Use `GetDistributionConfig` to get the current configuration, including the version identifier (`ETag`).
 *
 * - Update the distribution configuration that was returned in the response. Note the following important requirements and restrictions:
 *
 * - You must copy the `ETag` field value from the response. (You'll use it for the `IfMatch` parameter in your request.) Then, remove the `ETag` field from the distribution configuration.
 *
 * - You can't change the value of `CallerReference`.
 *
 * - Submit an `UpdateDistribution` request, providing the updated distribution configuration. The new configuration replaces the existing configuration. The values that you specify in an `UpdateDistribution` request are not merged into your existing configuration. Make sure to include all fields: the ones that you modified and also the ones that you didn't.
 */
export declare const updateDistribution: API.OperationMethod<UpdateDistributionRequest, UpdateDistributionResult, UpdateDistributionError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionTenantError = AccessDenied | CNAMEAlreadyExists | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | InvalidArgument | InvalidAssociation | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Updates a distribution tenant.
 */
export declare const updateDistributionTenant: API.OperationMethod<UpdateDistributionTenantRequest, UpdateDistributionTenantResult, UpdateDistributionTenantError, Credentials | HttpClient.HttpClient>;
export type UpdateDistributionWithStagingConfigError = AccessDenied | CNAMEAlreadyExists | EntityLimitExceeded | EntityNotFound | IllegalFieldLevelEncryptionConfigAssociationWithCacheBehavior | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidDefaultRootObject | InvalidErrorCode | InvalidForwardCookies | InvalidFunctionAssociation | InvalidGeoRestrictionParameter | InvalidHeadersForS3Origin | InvalidIfMatchVersion | InvalidLambdaFunctionAssociation | InvalidLocationCode | InvalidMinimumProtocolVersion | InvalidOriginAccessControl | InvalidOriginAccessIdentity | InvalidOriginKeepaliveTimeout | InvalidOriginReadTimeout | InvalidQueryStringParameters | InvalidRelativePath | InvalidRequiredProtocol | InvalidResponseCode | InvalidTTLOrder | InvalidViewerCertificate | InvalidWebACLId | MissingBody | NoSuchCachePolicy | NoSuchDistribution | NoSuchFieldLevelEncryptionConfig | NoSuchOrigin | NoSuchOriginRequestPolicy | NoSuchRealtimeLogConfig | NoSuchResponseHeadersPolicy | PreconditionFailed | RealtimeLogConfigOwnerMismatch | TooManyCacheBehaviors | TooManyCertificates | TooManyCookieNamesInWhiteList | TooManyDistributionCNAMEs | TooManyDistributionsAssociatedToCachePolicy | TooManyDistributionsAssociatedToFieldLevelEncryptionConfig | TooManyDistributionsAssociatedToKeyGroup | TooManyDistributionsAssociatedToOriginAccessControl | TooManyDistributionsAssociatedToOriginRequestPolicy | TooManyDistributionsAssociatedToResponseHeadersPolicy | TooManyDistributionsWithFunctionAssociations | TooManyDistributionsWithLambdaAssociations | TooManyDistributionsWithSingleFunctionARN | TooManyFunctionAssociations | TooManyHeadersInForwardedValues | TooManyKeyGroupsAssociatedToDistribution | TooManyLambdaFunctionAssociations | TooManyOriginCustomHeaders | TooManyOriginGroupsPerDistribution | TooManyOrigins | TooManyQueryStringParameters | TooManyTrustedSigners | TrustedKeyGroupDoesNotExist | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Copies the staging distribution's configuration to its corresponding primary distribution. The primary distribution retains its `Aliases` (also known as alternate domain names or CNAMEs) and `ContinuousDeploymentPolicyId` value, but otherwise its configuration is overwritten to match the staging distribution.
 *
 * You can use this operation in a continuous deployment workflow after you have tested configuration changes on the staging distribution. After using a continuous deployment policy to move a portion of your domain name's traffic to the staging distribution and verifying that it works as intended, you can use this operation to copy the staging distribution's configuration to the primary distribution. This action will disable the continuous deployment policy and move your domain's traffic back to the primary distribution.
 *
 * This API operation requires the following IAM permissions:
 *
 * - GetDistribution
 *
 * - UpdateDistribution
 */
export declare const updateDistributionWithStagingConfig: API.OperationMethod<UpdateDistributionWithStagingConfigRequest, UpdateDistributionWithStagingConfigResult, UpdateDistributionWithStagingConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainAssociationError = AccessDenied | EntityNotFound | IllegalUpdate | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * We recommend that you use the `UpdateDomainAssociation` API operation to move a domain association, as it supports both standard distributions and distribution tenants. AssociateAlias performs similar checks but only supports standard distributions.
 *
 * Moves a domain from its current standard distribution or distribution tenant to another one.
 *
 * You must first disable the source distribution (standard distribution or distribution tenant) and then separately call this operation to move the domain to another target distribution (standard distribution or distribution tenant).
 *
 * To use this operation, specify the domain and the ID of the target resource (standard distribution or distribution tenant). For more information, including how to set up the target resource, prerequisites that you must complete, and other restrictions, see Moving an alternate domain name to a different standard distribution or distribution tenant in the *Amazon CloudFront Developer Guide*.
 */
export declare const updateDomainAssociation: API.OperationMethod<UpdateDomainAssociationRequest, UpdateDomainAssociationResult, UpdateDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateFieldLevelEncryptionConfigError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionConfig | NoSuchFieldLevelEncryptionProfile | PreconditionFailed | QueryArgProfileEmpty | TooManyFieldLevelEncryptionContentTypeProfiles | TooManyFieldLevelEncryptionQueryArgProfiles | CommonErrors;
/**
 * Update a field-level encryption configuration.
 */
export declare const updateFieldLevelEncryptionConfig: API.OperationMethod<UpdateFieldLevelEncryptionConfigRequest, UpdateFieldLevelEncryptionConfigResult, UpdateFieldLevelEncryptionConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateFieldLevelEncryptionProfileError = AccessDenied | FieldLevelEncryptionProfileAlreadyExists | FieldLevelEncryptionProfileSizeExceeded | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchFieldLevelEncryptionProfile | NoSuchPublicKey | PreconditionFailed | TooManyFieldLevelEncryptionEncryptionEntities | TooManyFieldLevelEncryptionFieldPatterns | CommonErrors;
/**
 * Update a field-level encryption profile.
 */
export declare const updateFieldLevelEncryptionProfile: API.OperationMethod<UpdateFieldLevelEncryptionProfileRequest, UpdateFieldLevelEncryptionProfileResult, UpdateFieldLevelEncryptionProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionError = FunctionSizeLimitExceeded | InvalidArgument | InvalidIfMatchVersion | NoSuchFunctionExists | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Updates a CloudFront function.
 *
 * You can update a function's code or the comment that describes the function. You cannot update a function's name.
 *
 * To update a function, you provide the function's name and version (`ETag` value) along with the updated function code. To get the name and version, you can use `ListFunctions` and `DescribeFunction`.
 */
export declare const updateFunction: API.OperationMethod<UpdateFunctionRequest, UpdateFunctionResult, UpdateFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateKeyGroupError = InvalidArgument | InvalidIfMatchVersion | KeyGroupAlreadyExists | NoSuchResource | PreconditionFailed | TooManyPublicKeysInKeyGroup | CommonErrors;
/**
 * Updates a key group.
 *
 * When you update a key group, all the fields are updated with the values provided in the request. You cannot update some fields independent of others. To update a key group:
 *
 * - Get the current key group with `GetKeyGroup` or `GetKeyGroupConfig`.
 *
 * - Locally modify the fields in the key group that you want to update. For example, add or remove public key IDs.
 *
 * - Call `UpdateKeyGroup` with the entire key group object, including the fields that you modified and those that you didn't.
 */
export declare const updateKeyGroup: API.OperationMethod<UpdateKeyGroupRequest, UpdateKeyGroupResult, UpdateKeyGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateKeyValueStoreError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Specifies the key value store to update.
 */
export declare const updateKeyValueStore: API.OperationMethod<UpdateKeyValueStoreRequest, UpdateKeyValueStoreResult, UpdateKeyValueStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateOriginAccessControlError = AccessDenied | IllegalUpdate | InvalidArgument | InvalidIfMatchVersion | NoSuchOriginAccessControl | OriginAccessControlAlreadyExists | PreconditionFailed | CommonErrors;
/**
 * Updates a CloudFront origin access control.
 */
export declare const updateOriginAccessControl: API.OperationMethod<UpdateOriginAccessControlRequest, UpdateOriginAccessControlResult, UpdateOriginAccessControlError, Credentials | HttpClient.HttpClient>;
export type UpdateOriginRequestPolicyError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchOriginRequestPolicy | OriginRequestPolicyAlreadyExists | PreconditionFailed | TooManyCookiesInOriginRequestPolicy | TooManyHeadersInOriginRequestPolicy | TooManyQueryStringsInOriginRequestPolicy | CommonErrors;
/**
 * Updates an origin request policy configuration.
 *
 * When you update an origin request policy configuration, all the fields are updated with the values provided in the request. You cannot update some fields independent of others. To update an origin request policy configuration:
 *
 * - Use `GetOriginRequestPolicyConfig` to get the current configuration.
 *
 * - Locally modify the fields in the origin request policy configuration that you want to update.
 *
 * - Call `UpdateOriginRequestPolicy` by providing the entire origin request policy configuration, including the fields that you modified and those that you didn't.
 */
export declare const updateOriginRequestPolicy: API.OperationMethod<UpdateOriginRequestPolicyRequest, UpdateOriginRequestPolicyResult, UpdateOriginRequestPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdatePublicKeyError = AccessDenied | CannotChangeImmutablePublicKeyFields | IllegalUpdate | InvalidArgument | InvalidIfMatchVersion | NoSuchPublicKey | PreconditionFailed | CommonErrors;
/**
 * Update public key information. Note that the only value you can change is the comment.
 */
export declare const updatePublicKey: API.OperationMethod<UpdatePublicKeyRequest, UpdatePublicKeyResult, UpdatePublicKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateRealtimeLogConfigError = AccessDenied | InvalidArgument | NoSuchRealtimeLogConfig | CommonErrors;
/**
 * Updates a real-time log configuration.
 *
 * When you update a real-time log configuration, all the parameters are updated with the values provided in the request. You cannot update some parameters independent of others. To update a real-time log configuration:
 *
 * - Call `GetRealtimeLogConfig` to get the current real-time log configuration.
 *
 * - Locally modify the parameters in the real-time log configuration that you want to update.
 *
 * - Call this API (`UpdateRealtimeLogConfig`) by providing the entire real-time log configuration, including the parameters that you modified and those that you didn't.
 *
 * You cannot update a real-time log configuration's `Name` or `ARN`.
 */
export declare const updateRealtimeLogConfig: API.OperationMethod<UpdateRealtimeLogConfigRequest, UpdateRealtimeLogConfigResult, UpdateRealtimeLogConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateResponseHeadersPolicyError = AccessDenied | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | NoSuchResponseHeadersPolicy | PreconditionFailed | ResponseHeadersPolicyAlreadyExists | TooLongCSPInResponseHeadersPolicy | TooManyCustomHeadersInResponseHeadersPolicy | TooManyRemoveHeadersInResponseHeadersPolicy | CommonErrors;
/**
 * Updates a response headers policy.
 *
 * When you update a response headers policy, the entire policy is replaced. You cannot update some policy fields independent of others. To update a response headers policy configuration:
 *
 * - Use `GetResponseHeadersPolicyConfig` to get the current policy's configuration.
 *
 * - Modify the fields in the response headers policy configuration that you want to update.
 *
 * - Call `UpdateResponseHeadersPolicy`, providing the entire response headers policy configuration, including the fields that you modified and those that you didn't.
 */
export declare const updateResponseHeadersPolicy: API.OperationMethod<UpdateResponseHeadersPolicyRequest, UpdateResponseHeadersPolicyResult, UpdateResponseHeadersPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateStreamingDistributionError = AccessDenied | CNAMEAlreadyExists | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | InvalidOriginAccessControl | InvalidOriginAccessIdentity | MissingBody | NoSuchStreamingDistribution | PreconditionFailed | TooManyStreamingDistributionCNAMEs | TooManyTrustedSigners | TrustedSignerDoesNotExist | CommonErrors;
/**
 * Update a streaming distribution.
 */
export declare const updateStreamingDistribution: API.OperationMethod<UpdateStreamingDistributionRequest, UpdateStreamingDistributionResult, UpdateStreamingDistributionError, Credentials | HttpClient.HttpClient>;
export type UpdateTrustStoreError = AccessDenied | EntityNotFound | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | CommonErrors;
/**
 * Updates a trust store.
 */
export declare const updateTrustStore: API.OperationMethod<UpdateTrustStoreRequest, UpdateTrustStoreResult, UpdateTrustStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcOriginError = AccessDenied | CannotUpdateEntityWhileInUse | EntityAlreadyExists | EntityLimitExceeded | EntityNotFound | IllegalUpdate | InconsistentQuantities | InvalidArgument | InvalidIfMatchVersion | PreconditionFailed | UnsupportedOperation | CommonErrors;
/**
 * Update an Amazon CloudFront VPC origin in your account.
 */
export declare const updateVpcOrigin: API.OperationMethod<UpdateVpcOriginRequest, UpdateVpcOriginResult, UpdateVpcOriginError, Credentials | HttpClient.HttpClient>;
export type VerifyDnsConfigurationError = AccessDenied | EntityNotFound | InvalidArgument | CommonErrors;
/**
 * Verify the DNS configuration for your domain names. This API operation checks whether your domain name points to the correct routing endpoint of the connection group, such as d111111abcdef8.cloudfront.net. You can use this API operation to troubleshoot and resolve DNS configuration issues.
 */
export declare const verifyDnsConfiguration: API.OperationMethod<VerifyDnsConfigurationRequest, VerifyDnsConfigurationResult, VerifyDnsConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudfront.d.ts.map