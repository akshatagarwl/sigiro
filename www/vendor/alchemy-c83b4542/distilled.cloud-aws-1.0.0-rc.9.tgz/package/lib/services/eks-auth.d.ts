import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ExpiredTokenException_base: S.Class<ExpiredTokenException, S.TaggedStruct<"ExpiredTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredTokenException extends /*@__PURE__*/ ExpiredTokenException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidTokenException_base: S.Class<InvalidTokenException, S.TaggedStruct<"InvalidTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTokenException extends /*@__PURE__*/ InvalidTokenException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type ClusterName = string;
export type JwtToken = string | redacted.Redacted<string>;
export interface AssumeRoleForPodIdentityRequest {
    clusterName: string;
    token: string | redacted.Redacted<string>;
    eksNodeName?: string;
    instanceId?: string;
    zone?: string;
}
export declare const AssumeRoleForPodIdentityRequest: S.Schema<AssumeRoleForPodIdentityRequest>;
export interface Subject {
    namespace: string;
    serviceAccount: string;
}
export declare const Subject: S.Schema<Subject>;
export interface PodIdentityAssociation {
    associationArn: string;
    associationId: string;
}
export declare const PodIdentityAssociation: S.Schema<PodIdentityAssociation>;
export interface AssumedRoleUser {
    arn: string;
    assumeRoleId: string;
}
export declare const AssumedRoleUser: S.Schema<AssumedRoleUser>;
export interface Credentials {
    sessionToken: string | redacted.Redacted<string>;
    secretAccessKey: string | redacted.Redacted<string>;
    accessKeyId: string;
    expiration: Date;
}
export declare const Credentials: S.Schema<Credentials>;
export interface AssumeRoleForPodIdentityResponse {
    subject: Subject;
    audience: string;
    podIdentityAssociation: PodIdentityAssociation;
    assumedRoleUser: AssumedRoleUser;
    credentials: Credentials;
}
export declare const AssumeRoleForPodIdentityResponse: S.Schema<AssumeRoleForPodIdentityResponse>;
export type AssumeRoleForPodIdentityError = AccessDeniedException | ExpiredTokenException | InternalServerException | InvalidParameterException | InvalidRequestException | InvalidTokenException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * The Amazon EKS Auth API and the `AssumeRoleForPodIdentity` action are only used by the EKS Pod Identity Agent.
 *
 * We recommend that applications use the Amazon Web Services SDKs to connect to Amazon Web Services services; if credentials from an EKS Pod Identity association are available in the pod, the latest versions of the SDKs use them automatically.
 */
export declare const assumeRoleForPodIdentity: API.OperationMethod<AssumeRoleForPodIdentityRequest, AssumeRoleForPodIdentityResponse, AssumeRoleForPodIdentityError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=eks-auth.d.ts.map