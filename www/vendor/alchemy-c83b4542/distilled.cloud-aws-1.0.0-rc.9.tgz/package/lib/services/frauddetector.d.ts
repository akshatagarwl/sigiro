import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.Class<ResourceUnavailableException, S.TaggedStruct<"ResourceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface VariableEntry {
    name?: string;
    dataType?: string;
    dataSource?: string;
    defaultValue?: string;
    description?: string;
    variableType?: string;
}
export declare const VariableEntry: S.Schema<VariableEntry>;
export type VariableEntryList = VariableEntry[];
export declare const VariableEntryList: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface BatchCreateVariableRequest {
    variableEntries: VariableEntry[];
    tags?: Tag[];
}
export declare const BatchCreateVariableRequest: S.Schema<BatchCreateVariableRequest>;
export type Integer2 = number;
export interface BatchCreateVariableError_ {
    name?: string;
    code?: number;
    message?: string;
}
export declare const BatchCreateVariableError_: S.Schema<BatchCreateVariableError_>;
export type BatchCreateVariableErrorList = BatchCreateVariableError_[];
export declare const BatchCreateVariableErrorList: any;
export interface BatchCreateVariableResult {
    errors?: BatchCreateVariableError_[];
}
export declare const BatchCreateVariableResult: S.Schema<BatchCreateVariableResult>;
export type NameList = string[];
export declare const NameList: any;
export interface BatchGetVariableRequest {
    names: string[];
}
export declare const BatchGetVariableRequest: S.Schema<BatchGetVariableRequest>;
export type DataType = "STRING" | "INTEGER" | "FLOAT" | "BOOLEAN" | "DATETIME" | (string & {});
export declare const DataType: any;
export type DataSource = "EVENT" | "MODEL_SCORE" | "EXTERNAL_MODEL_SCORE" | (string & {});
export declare const DataSource: any;
export type FraudDetectorArn = string;
export interface Variable {
    name?: string;
    dataType?: DataType;
    dataSource?: DataSource;
    defaultValue?: string;
    description?: string;
    variableType?: string;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
}
export declare const Variable: S.Schema<Variable>;
export type VariableList = Variable[];
export declare const VariableList: any;
export interface BatchGetVariableError_ {
    name?: string;
    code?: number;
    message?: string;
}
export declare const BatchGetVariableError_: S.Schema<BatchGetVariableError_>;
export type BatchGetVariableErrorList = BatchGetVariableError_[];
export declare const BatchGetVariableErrorList: any;
export interface BatchGetVariableResult {
    variables?: Variable[];
    errors?: BatchGetVariableError_[];
}
export declare const BatchGetVariableResult: S.Schema<BatchGetVariableResult>;
export type Identifier = string;
export interface CancelBatchImportJobRequest {
    jobId: string;
}
export declare const CancelBatchImportJobRequest: S.Schema<CancelBatchImportJobRequest>;
export interface CancelBatchImportJobResult {
}
export declare const CancelBatchImportJobResult: S.Schema<CancelBatchImportJobResult>;
export interface CancelBatchPredictionJobRequest {
    jobId: string;
}
export declare const CancelBatchPredictionJobRequest: S.Schema<CancelBatchPredictionJobRequest>;
export interface CancelBatchPredictionJobResult {
}
export declare const CancelBatchPredictionJobResult: S.Schema<CancelBatchPredictionJobResult>;
export type S3BucketLocation = string;
export type IamRoleArn = string;
export interface CreateBatchImportJobRequest {
    jobId: string;
    inputPath: string;
    outputPath: string;
    eventTypeName: string;
    iamRoleArn: string;
    tags?: Tag[];
}
export declare const CreateBatchImportJobRequest: S.Schema<CreateBatchImportJobRequest>;
export interface CreateBatchImportJobResult {
}
export declare const CreateBatchImportJobResult: S.Schema<CreateBatchImportJobResult>;
export type WholeNumberVersionString = string;
export interface CreateBatchPredictionJobRequest {
    jobId: string;
    inputPath: string;
    outputPath: string;
    eventTypeName: string;
    detectorName: string;
    detectorVersion?: string;
    iamRoleArn: string;
    tags?: Tag[];
}
export declare const CreateBatchPredictionJobRequest: S.Schema<CreateBatchPredictionJobRequest>;
export interface CreateBatchPredictionJobResult {
}
export declare const CreateBatchPredictionJobResult: S.Schema<CreateBatchPredictionJobResult>;
export type Description = string;
export type ListOfStrings = string[];
export declare const ListOfStrings: any;
export interface Rule {
    detectorId: string;
    ruleId: string;
    ruleVersion: string;
}
export declare const Rule: S.Schema<Rule>;
export type RuleList = Rule[];
export declare const RuleList: any;
export type ModelIdentifier = string;
export type ModelTypeEnum = "ONLINE_FRAUD_INSIGHTS" | "TRANSACTION_FRAUD_INSIGHTS" | "ACCOUNT_TAKEOVER_INSIGHTS" | (string & {});
export declare const ModelTypeEnum: any;
export type FloatVersionString = string;
export interface ModelVersion {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
    arn?: string;
}
export declare const ModelVersion: S.Schema<ModelVersion>;
export type ListOfModelVersions = ModelVersion[];
export declare const ListOfModelVersions: any;
export type RuleExecutionMode = "ALL_MATCHED" | "FIRST_MATCHED" | (string & {});
export declare const RuleExecutionMode: any;
export interface CreateDetectorVersionRequest {
    detectorId: string;
    description?: string;
    externalModelEndpoints?: string[];
    rules: Rule[];
    modelVersions?: ModelVersion[];
    ruleExecutionMode?: RuleExecutionMode;
    tags?: Tag[];
}
export declare const CreateDetectorVersionRequest: S.Schema<CreateDetectorVersionRequest>;
export type DetectorVersionStatus = "DRAFT" | "ACTIVE" | "INACTIVE" | (string & {});
export declare const DetectorVersionStatus: any;
export interface CreateDetectorVersionResult {
    detectorId?: string;
    detectorVersionId?: string;
    status?: DetectorVersionStatus;
}
export declare const CreateDetectorVersionResult: S.Schema<CreateDetectorVersionResult>;
export type NoDashIdentifier = string;
export type Elements = string | redacted.Redacted<string>;
export type ElementsList = (string | redacted.Redacted<string>)[];
export declare const ElementsList: any;
export type VariableType = string;
export interface CreateListRequest {
    name: string;
    elements?: (string | redacted.Redacted<string>)[];
    variableType?: string;
    description?: string;
    tags?: Tag[];
}
export declare const CreateListRequest: S.Schema<CreateListRequest>;
export interface CreateListResult {
}
export declare const CreateListResult: S.Schema<CreateListResult>;
export interface CreateModelRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    description?: string;
    eventTypeName: string;
    tags?: Tag[];
}
export declare const CreateModelRequest: S.Schema<CreateModelRequest>;
export interface CreateModelResult {
}
export declare const CreateModelResult: S.Schema<CreateModelResult>;
export type TrainingDataSourceEnum = "EXTERNAL_EVENTS" | "INGESTED_EVENTS" | (string & {});
export declare const TrainingDataSourceEnum: any;
export type LabelMapper = {
    [key: string]: string[] | undefined;
};
export declare const LabelMapper: any;
export type UnlabeledEventsTreatment = "IGNORE" | "FRAUD" | "LEGIT" | "AUTO" | (string & {});
export declare const UnlabeledEventsTreatment: any;
export interface LabelSchema {
    labelMapper?: {
        [key: string]: string[] | undefined;
    };
    unlabeledEventsTreatment?: UnlabeledEventsTreatment;
}
export declare const LabelSchema: S.Schema<LabelSchema>;
export interface TrainingDataSchema {
    modelVariables: string[];
    labelSchema?: LabelSchema;
}
export declare const TrainingDataSchema: S.Schema<TrainingDataSchema>;
export interface ExternalEventsDetail {
    dataLocation: string;
    dataAccessRoleArn: string;
}
export declare const ExternalEventsDetail: S.Schema<ExternalEventsDetail>;
export interface IngestedEventsTimeWindow {
    startTime: string;
    endTime: string;
}
export declare const IngestedEventsTimeWindow: S.Schema<IngestedEventsTimeWindow>;
export interface IngestedEventsDetail {
    ingestedEventsTimeWindow: IngestedEventsTimeWindow;
}
export declare const IngestedEventsDetail: S.Schema<IngestedEventsDetail>;
export interface CreateModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    trainingDataSource: TrainingDataSourceEnum;
    trainingDataSchema: TrainingDataSchema;
    externalEventsDetail?: ExternalEventsDetail;
    ingestedEventsDetail?: IngestedEventsDetail;
    tags?: Tag[];
}
export declare const CreateModelVersionRequest: S.Schema<CreateModelVersionRequest>;
export interface CreateModelVersionResult {
    modelId?: string;
    modelType?: ModelTypeEnum;
    modelVersionNumber?: string;
    status?: string;
}
export declare const CreateModelVersionResult: S.Schema<CreateModelVersionResult>;
export type RuleExpression = string | redacted.Redacted<string>;
export type Language = "DETECTORPL" | (string & {});
export declare const Language: any;
export type NonEmptyListOfStrings = string[];
export declare const NonEmptyListOfStrings: any;
export interface CreateRuleRequest {
    ruleId: string;
    detectorId: string;
    description?: string;
    expression: string | redacted.Redacted<string>;
    language: Language;
    outcomes: string[];
    tags?: Tag[];
}
export declare const CreateRuleRequest: S.Schema<CreateRuleRequest>;
export interface CreateRuleResult {
    rule?: Rule;
}
export declare const CreateRuleResult: S.Schema<CreateRuleResult>;
export interface CreateVariableRequest {
    name: string;
    dataType: DataType;
    dataSource: DataSource;
    defaultValue: string;
    description?: string;
    variableType?: string;
    tags?: Tag[];
}
export declare const CreateVariableRequest: S.Schema<CreateVariableRequest>;
export interface CreateVariableResult {
}
export declare const CreateVariableResult: S.Schema<CreateVariableResult>;
export interface DeleteBatchImportJobRequest {
    jobId: string;
}
export declare const DeleteBatchImportJobRequest: S.Schema<DeleteBatchImportJobRequest>;
export interface DeleteBatchImportJobResult {
}
export declare const DeleteBatchImportJobResult: S.Schema<DeleteBatchImportJobResult>;
export interface DeleteBatchPredictionJobRequest {
    jobId: string;
}
export declare const DeleteBatchPredictionJobRequest: S.Schema<DeleteBatchPredictionJobRequest>;
export interface DeleteBatchPredictionJobResult {
}
export declare const DeleteBatchPredictionJobResult: S.Schema<DeleteBatchPredictionJobResult>;
export interface DeleteDetectorRequest {
    detectorId: string;
}
export declare const DeleteDetectorRequest: S.Schema<DeleteDetectorRequest>;
export interface DeleteDetectorResult {
}
export declare const DeleteDetectorResult: S.Schema<DeleteDetectorResult>;
export interface DeleteDetectorVersionRequest {
    detectorId: string;
    detectorVersionId: string;
}
export declare const DeleteDetectorVersionRequest: S.Schema<DeleteDetectorVersionRequest>;
export interface DeleteDetectorVersionResult {
}
export declare const DeleteDetectorVersionResult: S.Schema<DeleteDetectorVersionResult>;
export interface DeleteEntityTypeRequest {
    name: string;
}
export declare const DeleteEntityTypeRequest: S.Schema<DeleteEntityTypeRequest>;
export interface DeleteEntityTypeResult {
}
export declare const DeleteEntityTypeResult: S.Schema<DeleteEntityTypeResult>;
export type DeleteAuditHistory = boolean;
export interface DeleteEventRequest {
    eventId: string;
    eventTypeName: string;
    deleteAuditHistory?: boolean;
}
export declare const DeleteEventRequest: S.Schema<DeleteEventRequest>;
export interface DeleteEventResult {
}
export declare const DeleteEventResult: S.Schema<DeleteEventResult>;
export interface DeleteEventsByEventTypeRequest {
    eventTypeName: string;
}
export declare const DeleteEventsByEventTypeRequest: S.Schema<DeleteEventsByEventTypeRequest>;
export interface DeleteEventsByEventTypeResult {
    eventTypeName?: string;
    eventsDeletionStatus?: string;
}
export declare const DeleteEventsByEventTypeResult: S.Schema<DeleteEventsByEventTypeResult>;
export interface DeleteEventTypeRequest {
    name: string;
}
export declare const DeleteEventTypeRequest: S.Schema<DeleteEventTypeRequest>;
export interface DeleteEventTypeResult {
}
export declare const DeleteEventTypeResult: S.Schema<DeleteEventTypeResult>;
export type SageMakerEndpointIdentifier = string;
export interface DeleteExternalModelRequest {
    modelEndpoint: string;
}
export declare const DeleteExternalModelRequest: S.Schema<DeleteExternalModelRequest>;
export interface DeleteExternalModelResult {
}
export declare const DeleteExternalModelResult: S.Schema<DeleteExternalModelResult>;
export interface DeleteLabelRequest {
    name: string;
}
export declare const DeleteLabelRequest: S.Schema<DeleteLabelRequest>;
export interface DeleteLabelResult {
}
export declare const DeleteLabelResult: S.Schema<DeleteLabelResult>;
export interface DeleteListRequest {
    name: string;
}
export declare const DeleteListRequest: S.Schema<DeleteListRequest>;
export interface DeleteListResult {
}
export declare const DeleteListResult: S.Schema<DeleteListResult>;
export interface DeleteModelRequest {
    modelId: string;
    modelType: ModelTypeEnum;
}
export declare const DeleteModelRequest: S.Schema<DeleteModelRequest>;
export interface DeleteModelResult {
}
export declare const DeleteModelResult: S.Schema<DeleteModelResult>;
export interface DeleteModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
}
export declare const DeleteModelVersionRequest: S.Schema<DeleteModelVersionRequest>;
export interface DeleteModelVersionResult {
}
export declare const DeleteModelVersionResult: S.Schema<DeleteModelVersionResult>;
export interface DeleteOutcomeRequest {
    name: string;
}
export declare const DeleteOutcomeRequest: S.Schema<DeleteOutcomeRequest>;
export interface DeleteOutcomeResult {
}
export declare const DeleteOutcomeResult: S.Schema<DeleteOutcomeResult>;
export interface DeleteRuleRequest {
    rule: Rule;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export interface DeleteRuleResult {
}
export declare const DeleteRuleResult: S.Schema<DeleteRuleResult>;
export interface DeleteVariableRequest {
    name: string;
}
export declare const DeleteVariableRequest: S.Schema<DeleteVariableRequest>;
export interface DeleteVariableResult {
}
export declare const DeleteVariableResult: S.Schema<DeleteVariableResult>;
export type DetectorVersionMaxResults = number;
export interface DescribeDetectorRequest {
    detectorId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeDetectorRequest: S.Schema<DescribeDetectorRequest>;
export interface DetectorVersionSummary {
    detectorVersionId?: string;
    status?: DetectorVersionStatus;
    description?: string;
    lastUpdatedTime?: string;
}
export declare const DetectorVersionSummary: S.Schema<DetectorVersionSummary>;
export type DetectorVersionSummaryList = DetectorVersionSummary[];
export declare const DetectorVersionSummaryList: any;
export interface DescribeDetectorResult {
    detectorId?: string;
    detectorVersionSummaries?: DetectorVersionSummary[];
    nextToken?: string;
    arn?: string;
}
export declare const DescribeDetectorResult: S.Schema<DescribeDetectorResult>;
export type ModelsMaxPageSize = number;
export interface DescribeModelVersionsRequest {
    modelId?: string;
    modelVersionNumber?: string;
    modelType?: ModelTypeEnum;
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeModelVersionsRequest: S.Schema<DescribeModelVersionsRequest>;
export interface FileValidationMessage {
    title?: string;
    content?: string;
    type?: string;
}
export declare const FileValidationMessage: S.Schema<FileValidationMessage>;
export type FileValidationMessageList = FileValidationMessage[];
export declare const FileValidationMessageList: any;
export interface FieldValidationMessage {
    fieldName?: string;
    identifier?: string;
    title?: string;
    content?: string;
    type?: string;
}
export declare const FieldValidationMessage: S.Schema<FieldValidationMessage>;
export type FieldValidationMessageList = FieldValidationMessage[];
export declare const FieldValidationMessageList: any;
export interface DataValidationMetrics {
    fileLevelMessages?: FileValidationMessage[];
    fieldLevelMessages?: FieldValidationMessage[];
}
export declare const DataValidationMetrics: S.Schema<DataValidationMetrics>;
export interface MetricDataPoint {
    fpr?: number;
    precision?: number;
    tpr?: number;
    threshold?: number;
}
export declare const MetricDataPoint: S.Schema<MetricDataPoint>;
export type MetricDataPointsList = MetricDataPoint[];
export declare const MetricDataPointsList: any;
export interface TrainingMetrics {
    auc?: number;
    metricDataPoints?: MetricDataPoint[];
}
export declare const TrainingMetrics: S.Schema<TrainingMetrics>;
export interface LogOddsMetric {
    variableName: string;
    variableType: string;
    variableImportance: number;
}
export declare const LogOddsMetric: S.Schema<LogOddsMetric>;
export type ListOfLogOddsMetrics = LogOddsMetric[];
export declare const ListOfLogOddsMetrics: any;
export interface VariableImportanceMetrics {
    logOddsMetrics?: LogOddsMetric[];
}
export declare const VariableImportanceMetrics: S.Schema<VariableImportanceMetrics>;
export interface TrainingResult {
    dataValidationMetrics?: DataValidationMetrics;
    trainingMetrics?: TrainingMetrics;
    variableImportanceMetrics?: VariableImportanceMetrics;
}
export declare const TrainingResult: S.Schema<TrainingResult>;
export interface OFIMetricDataPoint {
    fpr?: number;
    precision?: number;
    tpr?: number;
    threshold?: number;
}
export declare const OFIMetricDataPoint: S.Schema<OFIMetricDataPoint>;
export type OFIMetricDataPointsList = OFIMetricDataPoint[];
export declare const OFIMetricDataPointsList: any;
export interface UncertaintyRange {
    lowerBoundValue: number;
    upperBoundValue: number;
}
export declare const UncertaintyRange: S.Schema<UncertaintyRange>;
export interface OFIModelPerformance {
    auc?: number;
    uncertaintyRange?: UncertaintyRange;
}
export declare const OFIModelPerformance: S.Schema<OFIModelPerformance>;
export interface OFITrainingMetricsValue {
    metricDataPoints?: OFIMetricDataPoint[];
    modelPerformance?: OFIModelPerformance;
}
export declare const OFITrainingMetricsValue: S.Schema<OFITrainingMetricsValue>;
export interface TFIMetricDataPoint {
    fpr?: number;
    precision?: number;
    tpr?: number;
    threshold?: number;
}
export declare const TFIMetricDataPoint: S.Schema<TFIMetricDataPoint>;
export type TFIMetricDataPointsList = TFIMetricDataPoint[];
export declare const TFIMetricDataPointsList: any;
export interface TFIModelPerformance {
    auc?: number;
    uncertaintyRange?: UncertaintyRange;
}
export declare const TFIModelPerformance: S.Schema<TFIModelPerformance>;
export interface TFITrainingMetricsValue {
    metricDataPoints?: TFIMetricDataPoint[];
    modelPerformance?: TFIModelPerformance;
}
export declare const TFITrainingMetricsValue: S.Schema<TFITrainingMetricsValue>;
export interface ATIMetricDataPoint {
    cr?: number;
    adr?: number;
    threshold?: number;
    atodr?: number;
}
export declare const ATIMetricDataPoint: S.Schema<ATIMetricDataPoint>;
export type ATIMetricDataPointsList = ATIMetricDataPoint[];
export declare const ATIMetricDataPointsList: any;
export interface ATIModelPerformance {
    asi?: number;
}
export declare const ATIModelPerformance: S.Schema<ATIModelPerformance>;
export interface ATITrainingMetricsValue {
    metricDataPoints?: ATIMetricDataPoint[];
    modelPerformance?: ATIModelPerformance;
}
export declare const ATITrainingMetricsValue: S.Schema<ATITrainingMetricsValue>;
export interface TrainingMetricsV2 {
    ofi?: OFITrainingMetricsValue;
    tfi?: TFITrainingMetricsValue;
    ati?: ATITrainingMetricsValue;
}
export declare const TrainingMetricsV2: S.Schema<TrainingMetricsV2>;
export interface AggregatedLogOddsMetric {
    variableNames: string[];
    aggregatedVariablesImportance: number;
}
export declare const AggregatedLogOddsMetric: S.Schema<AggregatedLogOddsMetric>;
export type ListOfAggregatedLogOddsMetrics = AggregatedLogOddsMetric[];
export declare const ListOfAggregatedLogOddsMetrics: any;
export interface AggregatedVariablesImportanceMetrics {
    logOddsMetrics?: AggregatedLogOddsMetric[];
}
export declare const AggregatedVariablesImportanceMetrics: S.Schema<AggregatedVariablesImportanceMetrics>;
export interface TrainingResultV2 {
    dataValidationMetrics?: DataValidationMetrics;
    trainingMetricsV2?: TrainingMetricsV2;
    variableImportanceMetrics?: VariableImportanceMetrics;
    aggregatedVariablesImportanceMetrics?: AggregatedVariablesImportanceMetrics;
}
export declare const TrainingResultV2: S.Schema<TrainingResultV2>;
export interface ModelVersionDetail {
    modelId?: string;
    modelType?: ModelTypeEnum;
    modelVersionNumber?: string;
    status?: string;
    trainingDataSource?: TrainingDataSourceEnum;
    trainingDataSchema?: TrainingDataSchema;
    externalEventsDetail?: ExternalEventsDetail;
    ingestedEventsDetail?: IngestedEventsDetail;
    trainingResult?: TrainingResult;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
    trainingResultV2?: TrainingResultV2;
}
export declare const ModelVersionDetail: S.Schema<ModelVersionDetail>;
export type ModelVersionDetailList = ModelVersionDetail[];
export declare const ModelVersionDetailList: any;
export interface DescribeModelVersionsResult {
    modelVersionDetails?: ModelVersionDetail[];
    nextToken?: string;
}
export declare const DescribeModelVersionsResult: S.Schema<DescribeModelVersionsResult>;
export type BatchImportsMaxPageSize = number;
export interface GetBatchImportJobsRequest {
    jobId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetBatchImportJobsRequest: S.Schema<GetBatchImportJobsRequest>;
export type AsyncJobStatus = "IN_PROGRESS_INITIALIZING" | "IN_PROGRESS" | "CANCEL_IN_PROGRESS" | "CANCELED" | "COMPLETE" | "FAILED" | (string & {});
export declare const AsyncJobStatus: any;
export interface BatchImport {
    jobId?: string;
    status?: AsyncJobStatus;
    failureReason?: string;
    startTime?: string;
    completionTime?: string;
    inputPath?: string;
    outputPath?: string;
    eventTypeName?: string;
    iamRoleArn?: string;
    arn?: string;
    processedRecordsCount?: number;
    failedRecordsCount?: number;
    totalRecordsCount?: number;
}
export declare const BatchImport: S.Schema<BatchImport>;
export type BatchImportList = BatchImport[];
export declare const BatchImportList: any;
export interface GetBatchImportJobsResult {
    batchImports?: BatchImport[];
    nextToken?: string;
}
export declare const GetBatchImportJobsResult: S.Schema<GetBatchImportJobsResult>;
export type BatchPredictionsMaxPageSize = number;
export interface GetBatchPredictionJobsRequest {
    jobId?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetBatchPredictionJobsRequest: S.Schema<GetBatchPredictionJobsRequest>;
export interface BatchPrediction {
    jobId?: string;
    status?: AsyncJobStatus;
    failureReason?: string;
    startTime?: string;
    completionTime?: string;
    lastHeartbeatTime?: string;
    inputPath?: string;
    outputPath?: string;
    eventTypeName?: string;
    detectorName?: string;
    detectorVersion?: string;
    iamRoleArn?: string;
    arn?: string;
    processedRecordsCount?: number;
    totalRecordsCount?: number;
}
export declare const BatchPrediction: S.Schema<BatchPrediction>;
export type BatchPredictionList = BatchPrediction[];
export declare const BatchPredictionList: any;
export interface GetBatchPredictionJobsResult {
    batchPredictions?: BatchPrediction[];
    nextToken?: string;
}
export declare const GetBatchPredictionJobsResult: S.Schema<GetBatchPredictionJobsResult>;
export interface GetDeleteEventsByEventTypeStatusRequest {
    eventTypeName: string;
}
export declare const GetDeleteEventsByEventTypeStatusRequest: S.Schema<GetDeleteEventsByEventTypeStatusRequest>;
export interface GetDeleteEventsByEventTypeStatusResult {
    eventTypeName?: string;
    eventsDeletionStatus?: AsyncJobStatus;
}
export declare const GetDeleteEventsByEventTypeStatusResult: S.Schema<GetDeleteEventsByEventTypeStatusResult>;
export type DetectorsMaxResults = number;
export interface GetDetectorsRequest {
    detectorId?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetDetectorsRequest: S.Schema<GetDetectorsRequest>;
export interface Detector {
    detectorId?: string;
    description?: string;
    eventTypeName?: string;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
}
export declare const Detector: S.Schema<Detector>;
export type DetectorList = Detector[];
export declare const DetectorList: any;
export interface GetDetectorsResult {
    detectors?: Detector[];
    nextToken?: string;
}
export declare const GetDetectorsResult: S.Schema<GetDetectorsResult>;
export interface GetDetectorVersionRequest {
    detectorId: string;
    detectorVersionId: string;
}
export declare const GetDetectorVersionRequest: S.Schema<GetDetectorVersionRequest>;
export interface GetDetectorVersionResult {
    detectorId?: string;
    detectorVersionId?: string;
    description?: string;
    externalModelEndpoints?: string[];
    modelVersions?: ModelVersion[];
    rules?: Rule[];
    status?: DetectorVersionStatus;
    lastUpdatedTime?: string;
    createdTime?: string;
    ruleExecutionMode?: RuleExecutionMode;
    arn?: string;
}
export declare const GetDetectorVersionResult: S.Schema<GetDetectorVersionResult>;
export type EntityTypesMaxResults = number;
export interface GetEntityTypesRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetEntityTypesRequest: S.Schema<GetEntityTypesRequest>;
export interface EntityType {
    name?: string;
    description?: string;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
}
export declare const EntityType: S.Schema<EntityType>;
export type EntityTypeList = EntityType[];
export declare const EntityTypeList: any;
export interface GetEntityTypesResult {
    entityTypes?: EntityType[];
    nextToken?: string;
}
export declare const GetEntityTypesResult: S.Schema<GetEntityTypesResult>;
export interface GetEventRequest {
    eventId: string;
    eventTypeName: string;
}
export declare const GetEventRequest: S.Schema<GetEventRequest>;
export type AttributeKey = string;
export type AttributeValue = string | redacted.Redacted<string>;
export type EventAttributeMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const EventAttributeMap: any;
export type EntityRestrictedString = string;
export interface Entity {
    entityType: string;
    entityId: string;
}
export declare const Entity: S.Schema<Entity>;
export type ListOfEntities = Entity[];
export declare const ListOfEntities: any;
export interface Event {
    eventId?: string;
    eventTypeName?: string;
    eventTimestamp?: string;
    eventVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    currentLabel?: string;
    labelTimestamp?: string;
    entities?: Entity[];
}
export declare const Event: S.Schema<Event>;
export interface GetEventResult {
    event?: Event;
}
export declare const GetEventResult: S.Schema<GetEventResult>;
export type UtcTimestampISO8601 = string;
export type VariableName = string;
export type VariableValue = string | redacted.Redacted<string>;
export type EventVariableMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const EventVariableMap: any;
export type ContentType = string;
export interface ModelEndpointDataBlob {
    byteBuffer?: Uint8Array;
    contentType?: string;
}
export declare const ModelEndpointDataBlob: S.Schema<ModelEndpointDataBlob>;
export type ExternalModelEndpointDataBlobMap = {
    [key: string]: ModelEndpointDataBlob | undefined;
};
export declare const ExternalModelEndpointDataBlobMap: any;
export interface GetEventPredictionRequest {
    detectorId: string;
    detectorVersionId?: string;
    eventId: string;
    eventTypeName: string;
    entities: Entity[];
    eventTimestamp: string;
    eventVariables: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    externalModelEndpointDataBlobs?: {
        [key: string]: ModelEndpointDataBlob | undefined;
    };
}
export declare const GetEventPredictionRequest: S.Schema<GetEventPredictionRequest>;
export type ModelPredictionMap = {
    [key: string]: number | undefined;
};
export declare const ModelPredictionMap: any;
export interface ModelScores {
    modelVersion?: ModelVersion;
    scores?: {
        [key: string]: number | undefined;
    };
}
export declare const ModelScores: S.Schema<ModelScores>;
export type ListOfModelScores = ModelScores[];
export declare const ListOfModelScores: any;
export interface RuleResult {
    ruleId?: string;
    outcomes?: string[];
}
export declare const RuleResult: S.Schema<RuleResult>;
export type ListOfRuleResults = RuleResult[];
export declare const ListOfRuleResults: any;
export type ModelSource = "SAGEMAKER" | (string & {});
export declare const ModelSource: any;
export interface ExternalModelSummary {
    modelEndpoint?: string;
    modelSource?: ModelSource;
}
export declare const ExternalModelSummary: S.Schema<ExternalModelSummary>;
export type ExternalModelPredictionMap = {
    [key: string]: string | undefined;
};
export declare const ExternalModelPredictionMap: any;
export interface ExternalModelOutputs {
    externalModel?: ExternalModelSummary;
    outputs?: {
        [key: string]: string | undefined;
    };
}
export declare const ExternalModelOutputs: S.Schema<ExternalModelOutputs>;
export type ListOfExternalModelOutputs = ExternalModelOutputs[];
export declare const ListOfExternalModelOutputs: any;
export interface GetEventPredictionResult {
    modelScores?: ModelScores[];
    ruleResults?: RuleResult[];
    externalModelOutputs?: ExternalModelOutputs[];
}
export declare const GetEventPredictionResult: S.Schema<GetEventPredictionResult>;
export interface GetEventPredictionMetadataRequest {
    eventId: string;
    eventTypeName: string;
    detectorId: string;
    detectorVersionId: string;
    predictionTimestamp: string;
}
export declare const GetEventPredictionMetadataRequest: S.Schema<GetEventPredictionMetadataRequest>;
export type SensitiveString = string | redacted.Redacted<string>;
export interface EventVariableSummary {
    name?: string | redacted.Redacted<string>;
    value?: string | redacted.Redacted<string>;
    source?: string | redacted.Redacted<string>;
}
export declare const EventVariableSummary: S.Schema<EventVariableSummary>;
export type ListOfEventVariableSummaries = EventVariableSummary[];
export declare const ListOfEventVariableSummaries: any;
export interface EvaluatedRule {
    ruleId?: string;
    ruleVersion?: string;
    expression?: string | redacted.Redacted<string>;
    expressionWithValues?: string | redacted.Redacted<string>;
    outcomes?: string[];
    evaluated?: boolean;
    matched?: boolean;
}
export declare const EvaluatedRule: S.Schema<EvaluatedRule>;
export type EvaluatedRuleList = EvaluatedRule[];
export declare const EvaluatedRuleList: any;
export interface VariableImpactExplanation {
    eventVariableName?: string;
    relativeImpact?: string;
    logOddsImpact?: number;
}
export declare const VariableImpactExplanation: S.Schema<VariableImpactExplanation>;
export type ListOfVariableImpactExplanations = VariableImpactExplanation[];
export declare const ListOfVariableImpactExplanations: any;
export interface AggregatedVariablesImpactExplanation {
    eventVariableNames?: string[];
    relativeImpact?: string;
    logOddsImpact?: number;
}
export declare const AggregatedVariablesImpactExplanation: S.Schema<AggregatedVariablesImpactExplanation>;
export type ListOfAggregatedVariablesImpactExplanations = AggregatedVariablesImpactExplanation[];
export declare const ListOfAggregatedVariablesImpactExplanations: any;
export interface PredictionExplanations {
    variableImpactExplanations?: VariableImpactExplanation[];
    aggregatedVariablesImpactExplanations?: AggregatedVariablesImpactExplanation[];
}
export declare const PredictionExplanations: S.Schema<PredictionExplanations>;
export interface ModelVersionEvaluation {
    outputVariableName?: string;
    evaluationScore?: string;
    predictionExplanations?: PredictionExplanations;
}
export declare const ModelVersionEvaluation: S.Schema<ModelVersionEvaluation>;
export type ListOfModelVersionEvaluations = ModelVersionEvaluation[];
export declare const ListOfModelVersionEvaluations: any;
export interface EvaluatedModelVersion {
    modelId?: string;
    modelVersion?: string;
    modelType?: string;
    evaluations?: ModelVersionEvaluation[];
}
export declare const EvaluatedModelVersion: S.Schema<EvaluatedModelVersion>;
export type ListOfEvaluatedModelVersions = EvaluatedModelVersion[];
export declare const ListOfEvaluatedModelVersions: any;
export type MapOfStrings = {
    [key: string]: string | undefined;
};
export declare const MapOfStrings: any;
export interface EvaluatedExternalModel {
    modelEndpoint?: string;
    useEventVariables?: boolean;
    inputVariables?: {
        [key: string]: string | undefined;
    };
    outputVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const EvaluatedExternalModel: S.Schema<EvaluatedExternalModel>;
export type ListOfEvaluatedExternalModels = EvaluatedExternalModel[];
export declare const ListOfEvaluatedExternalModels: any;
export interface GetEventPredictionMetadataResult {
    eventId?: string;
    eventTypeName?: string;
    entityId?: string;
    entityType?: string;
    eventTimestamp?: string;
    detectorId?: string;
    detectorVersionId?: string;
    detectorVersionStatus?: string;
    eventVariables?: EventVariableSummary[];
    rules?: EvaluatedRule[];
    ruleExecutionMode?: RuleExecutionMode;
    outcomes?: string[];
    evaluatedModelVersions?: EvaluatedModelVersion[];
    evaluatedExternalModels?: EvaluatedExternalModel[];
    predictionTimestamp?: string;
}
export declare const GetEventPredictionMetadataResult: S.Schema<GetEventPredictionMetadataResult>;
export type EventTypesMaxResults = number;
export interface GetEventTypesRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetEventTypesRequest: S.Schema<GetEventTypesRequest>;
export type EventIngestion = "ENABLED" | "DISABLED" | (string & {});
export declare const EventIngestion: any;
export interface IngestedEventStatistics {
    numberOfEvents?: number;
    eventDataSizeInBytes?: number;
    leastRecentEvent?: string;
    mostRecentEvent?: string;
    lastUpdatedTime?: string;
}
export declare const IngestedEventStatistics: S.Schema<IngestedEventStatistics>;
export interface EventOrchestration {
    eventBridgeEnabled: boolean;
}
export declare const EventOrchestration: S.Schema<EventOrchestration>;
export interface EventType {
    name?: string;
    description?: string;
    eventVariables?: string[];
    labels?: string[];
    entityTypes?: string[];
    eventIngestion?: EventIngestion;
    ingestedEventStatistics?: IngestedEventStatistics;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
    eventOrchestration?: EventOrchestration;
}
export declare const EventType: S.Schema<EventType>;
export type EventTypeList = EventType[];
export declare const EventTypeList: any;
export interface GetEventTypesResult {
    eventTypes?: EventType[];
    nextToken?: string;
}
export declare const GetEventTypesResult: S.Schema<GetEventTypesResult>;
export type ExternalModelsMaxResults = number;
export interface GetExternalModelsRequest {
    modelEndpoint?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetExternalModelsRequest: S.Schema<GetExternalModelsRequest>;
export type ModelInputDataFormat = "TEXT_CSV" | "APPLICATION_JSON" | (string & {});
export declare const ModelInputDataFormat: any;
export type UseEventVariables = boolean;
export type ModelInputTemplate = string;
export interface ModelInputConfiguration {
    eventTypeName?: string;
    format?: ModelInputDataFormat;
    useEventVariables: boolean;
    jsonInputTemplate?: string;
    csvInputTemplate?: string;
}
export declare const ModelInputConfiguration: S.Schema<ModelInputConfiguration>;
export type ModelOutputDataFormat = "TEXT_CSV" | "APPLICATION_JSONLINES" | (string & {});
export declare const ModelOutputDataFormat: any;
export type JsonKeyToVariableMap = {
    [key: string]: string | undefined;
};
export declare const JsonKeyToVariableMap: any;
export type CsvIndexToVariableMap = {
    [key: string]: string | undefined;
};
export declare const CsvIndexToVariableMap: any;
export interface ModelOutputConfiguration {
    format: ModelOutputDataFormat;
    jsonKeyToVariableMap?: {
        [key: string]: string | undefined;
    };
    csvIndexToVariableMap?: {
        [key: string]: string | undefined;
    };
}
export declare const ModelOutputConfiguration: S.Schema<ModelOutputConfiguration>;
export type ModelEndpointStatus = "ASSOCIATED" | "DISSOCIATED" | (string & {});
export declare const ModelEndpointStatus: any;
export interface ExternalModel {
    modelEndpoint?: string;
    modelSource?: ModelSource;
    invokeModelEndpointRoleArn?: string;
    inputConfiguration?: ModelInputConfiguration;
    outputConfiguration?: ModelOutputConfiguration;
    modelEndpointStatus?: ModelEndpointStatus;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
}
export declare const ExternalModel: S.Schema<ExternalModel>;
export type ExternalModelList = ExternalModel[];
export declare const ExternalModelList: any;
export interface GetExternalModelsResult {
    externalModels?: ExternalModel[];
    nextToken?: string;
}
export declare const GetExternalModelsResult: S.Schema<GetExternalModelsResult>;
export interface GetKMSEncryptionKeyRequest {
}
export declare const GetKMSEncryptionKeyRequest: S.Schema<GetKMSEncryptionKeyRequest>;
export type KmsEncryptionKeyArn = string;
export interface KMSKey {
    kmsEncryptionKeyArn?: string;
}
export declare const KMSKey: S.Schema<KMSKey>;
export interface GetKMSEncryptionKeyResult {
    kmsKey?: KMSKey;
}
export declare const GetKMSEncryptionKeyResult: S.Schema<GetKMSEncryptionKeyResult>;
export type LabelsMaxResults = number;
export interface GetLabelsRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetLabelsRequest: S.Schema<GetLabelsRequest>;
export interface Label {
    name?: string;
    description?: string;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
}
export declare const Label: S.Schema<Label>;
export type LabelList = Label[];
export declare const LabelList: any;
export interface GetLabelsResult {
    labels?: Label[];
    nextToken?: string;
}
export declare const GetLabelsResult: S.Schema<GetLabelsResult>;
export type NextToken = string;
export type ListsElementsMaxResults = number;
export interface GetListElementsRequest {
    name: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetListElementsRequest: S.Schema<GetListElementsRequest>;
export interface GetListElementsResult {
    elements?: (string | redacted.Redacted<string>)[];
    nextToken?: string;
}
export declare const GetListElementsResult: S.Schema<GetListElementsResult>;
export type ListsMetadataMaxResults = number;
export interface GetListsMetadataRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetListsMetadataRequest: S.Schema<GetListsMetadataRequest>;
export interface AllowDenyList {
    name: string;
    description?: string;
    variableType?: string;
    createdTime?: string;
    updatedTime?: string;
    arn?: string;
}
export declare const AllowDenyList: S.Schema<AllowDenyList>;
export type AllowDenyLists = AllowDenyList[];
export declare const AllowDenyLists: any;
export interface GetListsMetadataResult {
    lists?: AllowDenyList[];
    nextToken?: string;
}
export declare const GetListsMetadataResult: S.Schema<GetListsMetadataResult>;
export interface GetModelsRequest {
    modelId?: string;
    modelType?: ModelTypeEnum;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetModelsRequest: S.Schema<GetModelsRequest>;
export interface Model {
    modelId?: string;
    modelType?: ModelTypeEnum;
    description?: string;
    eventTypeName?: string;
    createdTime?: string;
    lastUpdatedTime?: string;
    arn?: string;
}
export declare const Model: S.Schema<Model>;
export type ModelList = Model[];
export declare const ModelList: any;
export interface GetModelsResult {
    nextToken?: string;
    models?: Model[];
}
export declare const GetModelsResult: S.Schema<GetModelsResult>;
export interface GetModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
}
export declare const GetModelVersionRequest: S.Schema<GetModelVersionRequest>;
export interface GetModelVersionResult {
    modelId?: string;
    modelType?: ModelTypeEnum;
    modelVersionNumber?: string;
    trainingDataSource?: TrainingDataSourceEnum;
    trainingDataSchema?: TrainingDataSchema;
    externalEventsDetail?: ExternalEventsDetail;
    ingestedEventsDetail?: IngestedEventsDetail;
    status?: string;
    arn?: string;
}
export declare const GetModelVersionResult: S.Schema<GetModelVersionResult>;
export type OutcomesMaxResults = number;
export interface GetOutcomesRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetOutcomesRequest: S.Schema<GetOutcomesRequest>;
export interface Outcome {
    name?: string;
    description?: string;
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
}
export declare const Outcome: S.Schema<Outcome>;
export type OutcomeList = Outcome[];
export declare const OutcomeList: any;
export interface GetOutcomesResult {
    outcomes?: Outcome[];
    nextToken?: string;
}
export declare const GetOutcomesResult: S.Schema<GetOutcomesResult>;
export type RulesMaxResults = number;
export interface GetRulesRequest {
    ruleId?: string;
    detectorId: string;
    ruleVersion?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetRulesRequest: S.Schema<GetRulesRequest>;
export interface RuleDetail {
    ruleId?: string;
    description?: string;
    detectorId?: string;
    ruleVersion?: string;
    expression?: string | redacted.Redacted<string>;
    language?: Language;
    outcomes?: string[];
    lastUpdatedTime?: string;
    createdTime?: string;
    arn?: string;
}
export declare const RuleDetail: S.Schema<RuleDetail>;
export type RuleDetailList = RuleDetail[];
export declare const RuleDetailList: any;
export interface GetRulesResult {
    ruleDetails?: RuleDetail[];
    nextToken?: string;
}
export declare const GetRulesResult: S.Schema<GetRulesResult>;
export type VariablesMaxResults = number;
export interface GetVariablesRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetVariablesRequest: S.Schema<GetVariablesRequest>;
export interface GetVariablesResult {
    variables?: Variable[];
    nextToken?: string;
}
export declare const GetVariablesResult: S.Schema<GetVariablesResult>;
export type FilterString = string;
export interface FilterCondition {
    value?: string;
}
export declare const FilterCondition: S.Schema<FilterCondition>;
export interface PredictionTimeRange {
    startTime: string;
    endTime: string;
}
export declare const PredictionTimeRange: S.Schema<PredictionTimeRange>;
export type EventPredictionsMaxResults = number;
export interface ListEventPredictionsRequest {
    eventId?: FilterCondition;
    eventType?: FilterCondition;
    detectorId?: FilterCondition;
    detectorVersionId?: FilterCondition;
    predictionTimeRange?: PredictionTimeRange;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEventPredictionsRequest: S.Schema<ListEventPredictionsRequest>;
export interface EventPredictionSummary {
    eventId?: string;
    eventTypeName?: string;
    eventTimestamp?: string;
    predictionTimestamp?: string;
    detectorId?: string;
    detectorVersionId?: string;
}
export declare const EventPredictionSummary: S.Schema<EventPredictionSummary>;
export type ListOfEventPredictionSummaries = EventPredictionSummary[];
export declare const ListOfEventPredictionSummaries: any;
export interface ListEventPredictionsResult {
    eventPredictionSummaries?: EventPredictionSummary[];
    nextToken?: string;
}
export declare const ListEventPredictionsResult: S.Schema<ListEventPredictionsResult>;
export type TagsMaxResults = number;
export interface ListTagsForResourceRequest {
    resourceARN: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResult {
    tags?: Tag[];
    nextToken?: string;
}
export declare const ListTagsForResourceResult: S.Schema<ListTagsForResourceResult>;
export interface PutDetectorRequest {
    detectorId: string;
    description?: string;
    eventTypeName: string;
    tags?: Tag[];
}
export declare const PutDetectorRequest: S.Schema<PutDetectorRequest>;
export interface PutDetectorResult {
}
export declare const PutDetectorResult: S.Schema<PutDetectorResult>;
export interface PutEntityTypeRequest {
    name: string;
    description?: string;
    tags?: Tag[];
}
export declare const PutEntityTypeRequest: S.Schema<PutEntityTypeRequest>;
export interface PutEntityTypeResult {
}
export declare const PutEntityTypeResult: S.Schema<PutEntityTypeResult>;
export interface PutEventTypeRequest {
    name: string;
    description?: string;
    eventVariables: string[];
    labels?: string[];
    entityTypes: string[];
    eventIngestion?: EventIngestion;
    tags?: Tag[];
    eventOrchestration?: EventOrchestration;
}
export declare const PutEventTypeRequest: S.Schema<PutEventTypeRequest>;
export interface PutEventTypeResult {
}
export declare const PutEventTypeResult: S.Schema<PutEventTypeResult>;
export interface PutExternalModelRequest {
    modelEndpoint: string;
    modelSource: ModelSource;
    invokeModelEndpointRoleArn: string;
    inputConfiguration: ModelInputConfiguration;
    outputConfiguration: ModelOutputConfiguration;
    modelEndpointStatus: ModelEndpointStatus;
    tags?: Tag[];
}
export declare const PutExternalModelRequest: S.Schema<PutExternalModelRequest>;
export interface PutExternalModelResult {
}
export declare const PutExternalModelResult: S.Schema<PutExternalModelResult>;
export interface PutKMSEncryptionKeyRequest {
    kmsEncryptionKeyArn: string;
}
export declare const PutKMSEncryptionKeyRequest: S.Schema<PutKMSEncryptionKeyRequest>;
export interface PutKMSEncryptionKeyResult {
}
export declare const PutKMSEncryptionKeyResult: S.Schema<PutKMSEncryptionKeyResult>;
export interface PutLabelRequest {
    name: string;
    description?: string;
    tags?: Tag[];
}
export declare const PutLabelRequest: S.Schema<PutLabelRequest>;
export interface PutLabelResult {
}
export declare const PutLabelResult: S.Schema<PutLabelResult>;
export interface PutOutcomeRequest {
    name: string;
    description?: string;
    tags?: Tag[];
}
export declare const PutOutcomeRequest: S.Schema<PutOutcomeRequest>;
export interface PutOutcomeResult {
}
export declare const PutOutcomeResult: S.Schema<PutOutcomeResult>;
export interface SendEventRequest {
    eventId: string;
    eventTypeName: string;
    eventTimestamp: string;
    eventVariables: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    assignedLabel?: string;
    labelTimestamp?: string;
    entities: Entity[];
}
export declare const SendEventRequest: S.Schema<SendEventRequest>;
export interface SendEventResult {
}
export declare const SendEventResult: S.Schema<SendEventResult>;
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResult {
}
export declare const TagResourceResult: S.Schema<TagResourceResult>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResult {
}
export declare const UntagResourceResult: S.Schema<UntagResourceResult>;
export interface UpdateDetectorVersionRequest {
    detectorId: string;
    detectorVersionId: string;
    externalModelEndpoints: string[];
    rules: Rule[];
    description?: string;
    modelVersions?: ModelVersion[];
    ruleExecutionMode?: RuleExecutionMode;
}
export declare const UpdateDetectorVersionRequest: S.Schema<UpdateDetectorVersionRequest>;
export interface UpdateDetectorVersionResult {
}
export declare const UpdateDetectorVersionResult: S.Schema<UpdateDetectorVersionResult>;
export interface UpdateDetectorVersionMetadataRequest {
    detectorId: string;
    detectorVersionId: string;
    description: string;
}
export declare const UpdateDetectorVersionMetadataRequest: S.Schema<UpdateDetectorVersionMetadataRequest>;
export interface UpdateDetectorVersionMetadataResult {
}
export declare const UpdateDetectorVersionMetadataResult: S.Schema<UpdateDetectorVersionMetadataResult>;
export interface UpdateDetectorVersionStatusRequest {
    detectorId: string;
    detectorVersionId: string;
    status: DetectorVersionStatus;
}
export declare const UpdateDetectorVersionStatusRequest: S.Schema<UpdateDetectorVersionStatusRequest>;
export interface UpdateDetectorVersionStatusResult {
}
export declare const UpdateDetectorVersionStatusResult: S.Schema<UpdateDetectorVersionStatusResult>;
export interface UpdateEventLabelRequest {
    eventId: string;
    eventTypeName: string;
    assignedLabel: string;
    labelTimestamp: string;
}
export declare const UpdateEventLabelRequest: S.Schema<UpdateEventLabelRequest>;
export interface UpdateEventLabelResult {
}
export declare const UpdateEventLabelResult: S.Schema<UpdateEventLabelResult>;
export type ListUpdateMode = "REPLACE" | "APPEND" | "REMOVE" | (string & {});
export declare const ListUpdateMode: any;
export interface UpdateListRequest {
    name: string;
    elements?: (string | redacted.Redacted<string>)[];
    description?: string;
    updateMode?: ListUpdateMode;
    variableType?: string;
}
export declare const UpdateListRequest: S.Schema<UpdateListRequest>;
export interface UpdateListResult {
}
export declare const UpdateListResult: S.Schema<UpdateListResult>;
export interface UpdateModelRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    description?: string;
}
export declare const UpdateModelRequest: S.Schema<UpdateModelRequest>;
export interface UpdateModelResult {
}
export declare const UpdateModelResult: S.Schema<UpdateModelResult>;
export interface UpdateModelVersionRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    majorVersionNumber: string;
    externalEventsDetail?: ExternalEventsDetail;
    ingestedEventsDetail?: IngestedEventsDetail;
    tags?: Tag[];
}
export declare const UpdateModelVersionRequest: S.Schema<UpdateModelVersionRequest>;
export interface UpdateModelVersionResult {
    modelId?: string;
    modelType?: ModelTypeEnum;
    modelVersionNumber?: string;
    status?: string;
}
export declare const UpdateModelVersionResult: S.Schema<UpdateModelVersionResult>;
export type ModelVersionStatus = "ACTIVE" | "INACTIVE" | "TRAINING_CANCELLED" | (string & {});
export declare const ModelVersionStatus: any;
export interface UpdateModelVersionStatusRequest {
    modelId: string;
    modelType: ModelTypeEnum;
    modelVersionNumber: string;
    status: ModelVersionStatus;
}
export declare const UpdateModelVersionStatusRequest: S.Schema<UpdateModelVersionStatusRequest>;
export interface UpdateModelVersionStatusResult {
}
export declare const UpdateModelVersionStatusResult: S.Schema<UpdateModelVersionStatusResult>;
export interface UpdateRuleMetadataRequest {
    rule: Rule;
    description: string;
}
export declare const UpdateRuleMetadataRequest: S.Schema<UpdateRuleMetadataRequest>;
export interface UpdateRuleMetadataResult {
}
export declare const UpdateRuleMetadataResult: S.Schema<UpdateRuleMetadataResult>;
export interface UpdateRuleVersionRequest {
    rule: Rule;
    description?: string;
    expression: string | redacted.Redacted<string>;
    language: Language;
    outcomes: string[];
    tags?: Tag[];
}
export declare const UpdateRuleVersionRequest: S.Schema<UpdateRuleVersionRequest>;
export interface UpdateRuleVersionResult {
    rule?: Rule;
}
export declare const UpdateRuleVersionResult: S.Schema<UpdateRuleVersionResult>;
export interface UpdateVariableRequest {
    name: string;
    defaultValue?: string;
    description?: string;
    variableType?: string;
}
export declare const UpdateVariableRequest: S.Schema<UpdateVariableRequest>;
export interface UpdateVariableResult {
}
export declare const UpdateVariableResult: S.Schema<UpdateVariableResult>;
export type BatchCreateVariableError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch of variables.
 */
export declare const batchCreateVariable: API.OperationMethod<BatchCreateVariableRequest, BatchCreateVariableResult, BatchCreateVariableError, Credentials | HttpClient.HttpClient>;
export type BatchGetVariableError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a batch of variables.
 */
export declare const batchGetVariable: API.OperationMethod<BatchGetVariableRequest, BatchGetVariableResult, BatchGetVariableError, Credentials | HttpClient.HttpClient>;
export type CancelBatchImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels an in-progress batch import job.
 */
export declare const cancelBatchImportJob: API.OperationMethod<CancelBatchImportJobRequest, CancelBatchImportJobResult, CancelBatchImportJobError, Credentials | HttpClient.HttpClient>;
export type CancelBatchPredictionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the specified batch prediction job.
 */
export declare const cancelBatchPredictionJob: API.OperationMethod<CancelBatchPredictionJobRequest, CancelBatchPredictionJobResult, CancelBatchPredictionJobError, Credentials | HttpClient.HttpClient>;
export type CreateBatchImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch import job.
 */
export declare const createBatchImportJob: API.OperationMethod<CreateBatchImportJobRequest, CreateBatchImportJobResult, CreateBatchImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateBatchPredictionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch prediction job.
 */
export declare const createBatchPredictionJob: API.OperationMethod<CreateBatchPredictionJobRequest, CreateBatchPredictionJobResult, CreateBatchPredictionJobError, Credentials | HttpClient.HttpClient>;
export type CreateDetectorVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a detector version. The detector version starts in a `DRAFT` status.
 */
export declare const createDetectorVersion: API.OperationMethod<CreateDetectorVersionRequest, CreateDetectorVersionResult, CreateDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type CreateListError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a list.
 *
 * List is a set of input data for a variable in your event dataset. You use the input data in a rule that's associated with your detector.
 * For more information, see Lists.
 */
export declare const createList: API.OperationMethod<CreateListRequest, CreateListResult, CreateListError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a model using the specified model type.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest, CreateModelResult, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreateModelVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a version of the model using the specified model type and model id.
 */
export declare const createModelVersion: API.OperationMethod<CreateModelVersionRequest, CreateModelVersionResult, CreateModelVersionError, Credentials | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rule for use with the specified detector.
 */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResult, CreateRuleError, Credentials | HttpClient.HttpClient>;
export type CreateVariableError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a variable.
 */
export declare const createVariable: API.OperationMethod<CreateVariableRequest, CreateVariableResult, CreateVariableError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchImportJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified batch import job ID record. This action does not delete the data that was batch imported.
 */
export declare const deleteBatchImportJob: API.OperationMethod<DeleteBatchImportJobRequest, DeleteBatchImportJobResult, DeleteBatchImportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteBatchPredictionJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a batch prediction job.
 */
export declare const deleteBatchPredictionJob: API.OperationMethod<DeleteBatchPredictionJobRequest, DeleteBatchPredictionJobResult, DeleteBatchPredictionJobError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the detector. Before deleting a detector, you must first delete all detector versions and rule versions associated with the detector.
 *
 * When you delete a detector, Amazon Fraud Detector permanently deletes the detector and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteDetector: API.OperationMethod<DeleteDetectorRequest, DeleteDetectorResult, DeleteDetectorError, Credentials | HttpClient.HttpClient>;
export type DeleteDetectorVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the detector version. You cannot delete detector versions that are in `ACTIVE` status.
 *
 * When you delete a detector version, Amazon Fraud Detector permanently deletes the detector and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteDetectorVersion: API.OperationMethod<DeleteDetectorVersionRequest, DeleteDetectorVersionResult, DeleteDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteEntityTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an entity type.
 *
 * You cannot delete an entity type that is included in an event type.
 *
 * When you delete an entity type, Amazon Fraud Detector permanently deletes that entity type and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteEntityType: API.OperationMethod<DeleteEntityTypeRequest, DeleteEntityTypeResult, DeleteEntityTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEventError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified event.
 *
 * When you delete an event, Amazon Fraud Detector permanently deletes that event and the event data is no longer stored in Amazon Fraud Detector.
 * If `deleteAuditHistory` is `True`, event data is available through search for up to 30 seconds after the delete operation is completed.
 */
export declare const deleteEvent: API.OperationMethod<DeleteEventRequest, DeleteEventResult, DeleteEventError, Credentials | HttpClient.HttpClient>;
export type DeleteEventsByEventTypeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes all events of a particular event type.
 */
export declare const deleteEventsByEventType: API.OperationMethod<DeleteEventsByEventTypeRequest, DeleteEventsByEventTypeResult, DeleteEventsByEventTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteEventTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an event type.
 *
 * You cannot delete an event type that is used in a detector or a model.
 *
 * When you delete an event type, Amazon Fraud Detector permanently deletes that event type and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteEventType: API.OperationMethod<DeleteEventTypeRequest, DeleteEventTypeResult, DeleteEventTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteExternalModelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a SageMaker model from Amazon Fraud Detector.
 *
 * You can remove an Amazon SageMaker model if it is not associated with a detector version. Removing a SageMaker model disconnects it from Amazon Fraud Detector, but the model remains available in SageMaker.
 */
export declare const deleteExternalModel: API.OperationMethod<DeleteExternalModelRequest, DeleteExternalModelResult, DeleteExternalModelError, Credentials | HttpClient.HttpClient>;
export type DeleteLabelError = ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a label.
 *
 * You cannot delete labels that are included in an event type in Amazon Fraud Detector.
 *
 * You cannot delete a label assigned to an event ID. You must first delete the relevant event ID.
 *
 * When you delete a label, Amazon Fraud Detector permanently deletes that label and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteLabel: API.OperationMethod<DeleteLabelRequest, DeleteLabelResult, DeleteLabelError, Credentials | HttpClient.HttpClient>;
export type DeleteListError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the list, provided it is not used in a rule.
 *
 * When you delete a list, Amazon Fraud Detector permanently deletes that list and the elements in the list.
 */
export declare const deleteList: API.OperationMethod<DeleteListRequest, DeleteListResult, DeleteListError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a model.
 *
 * You can delete models and model versions in Amazon Fraud Detector, provided that they are not associated with a detector version.
 *
 * When you delete a model, Amazon Fraud Detector permanently deletes that model and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest, DeleteModelResult, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeleteModelVersionError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a model version.
 *
 * You can delete models and model versions in Amazon Fraud Detector, provided that they are not associated with a detector version.
 *
 * When you delete a model version, Amazon Fraud Detector permanently deletes that model version and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteModelVersion: API.OperationMethod<DeleteModelVersionRequest, DeleteModelVersionResult, DeleteModelVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteOutcomeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an outcome.
 *
 * You cannot delete an outcome that is used in a rule version.
 *
 * When you delete an outcome, Amazon Fraud Detector permanently deletes that outcome and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteOutcome: API.OperationMethod<DeleteOutcomeRequest, DeleteOutcomeResult, DeleteOutcomeError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the rule. You cannot delete a rule if it is used by an `ACTIVE` or `INACTIVE` detector version.
 *
 * When you delete a rule, Amazon Fraud Detector permanently deletes that rule and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResult, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteVariableError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a variable.
 *
 * You can't delete variables that are included in an event type in Amazon Fraud Detector.
 *
 * Amazon Fraud Detector automatically deletes model output variables and SageMaker model output variables when you delete the model. You can't delete these variables manually.
 *
 * When you delete a variable, Amazon Fraud Detector permanently deletes that variable and the data is no longer stored in Amazon Fraud Detector.
 */
export declare const deleteVariable: API.OperationMethod<DeleteVariableRequest, DeleteVariableResult, DeleteVariableError, Credentials | HttpClient.HttpClient>;
export type DescribeDetectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all versions for a specified detector.
 */
export declare const describeDetector: API.OperationMethod<DescribeDetectorRequest, DescribeDetectorResult, DescribeDetectorError, Credentials | HttpClient.HttpClient>;
export type DescribeModelVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all of the model versions for the specified model type or for the specified model type and model ID. You can also get details for a single, specified model version.
 */
export declare const describeModelVersions: API.PaginatedOperationMethod<DescribeModelVersionsRequest, DescribeModelVersionsResult, DescribeModelVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBatchImportJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all batch import jobs or a specific job of the specified ID. This is a paginated API. If you provide a null `maxResults`,
 * this action retrieves a maximum of 50 records per page. If you provide a `maxResults`, the value must be between 1 and 50.
 * To get the next page results, provide the pagination token from the `GetBatchImportJobsResponse` as part of your request.
 * A null pagination token fetches the records from the beginning.
 */
export declare const getBatchImportJobs: API.PaginatedOperationMethod<GetBatchImportJobsRequest, GetBatchImportJobsResult, GetBatchImportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBatchPredictionJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all batch prediction jobs or a specific job if you specify a job ID. This is a paginated API. If you provide a null maxResults, this action retrieves a maximum of 50 records per page. If you provide a maxResults, the value must be between 1 and 50. To get the next page results, provide the pagination token from the GetBatchPredictionJobsResponse as part of your request. A null pagination token fetches the records from the beginning.
 */
export declare const getBatchPredictionJobs: API.PaginatedOperationMethod<GetBatchPredictionJobsRequest, GetBatchPredictionJobsResult, GetBatchPredictionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDeleteEventsByEventTypeStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status of a `DeleteEventsByEventType` action.
 */
export declare const getDeleteEventsByEventTypeStatus: API.OperationMethod<GetDeleteEventsByEventTypeStatusRequest, GetDeleteEventsByEventTypeStatusResult, GetDeleteEventsByEventTypeStatusError, Credentials | HttpClient.HttpClient>;
export type GetDetectorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all detectors or a single detector if a `detectorId` is specified. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 5 and 10.
 * To get the next page results, provide the pagination token from the
 * `GetDetectorsResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getDetectors: API.PaginatedOperationMethod<GetDetectorsRequest, GetDetectorsResult, GetDetectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDetectorVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a particular detector version.
 */
export declare const getDetectorVersion: API.OperationMethod<GetDetectorVersionRequest, GetDetectorVersionResult, GetDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type GetEntityTypesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all entity types or a specific entity type if a name is specified. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 5 and 10.
 * To get the next page results, provide the pagination token from the
 * `GetEntityTypesResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getEntityTypes: API.PaginatedOperationMethod<GetEntityTypesRequest, GetEntityTypesResult, GetEntityTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetEventError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of events stored with Amazon Fraud Detector. This action does not retrieve prediction results.
 */
export declare const getEvent: API.OperationMethod<GetEventRequest, GetEventResult, GetEventError, Credentials | HttpClient.HttpClient>;
export type GetEventPredictionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates an event against a detector version. If a version ID is not provided, the detector’s (`ACTIVE`) version is used.
 */
export declare const getEventPrediction: API.OperationMethod<GetEventPredictionRequest, GetEventPredictionResult, GetEventPredictionError, Credentials | HttpClient.HttpClient>;
export type GetEventPredictionMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details of the past fraud predictions for the specified event ID, event type, detector ID, and detector version ID that was generated in the specified time period.
 */
export declare const getEventPredictionMetadata: API.OperationMethod<GetEventPredictionMetadataRequest, GetEventPredictionMetadataResult, GetEventPredictionMetadataError, Credentials | HttpClient.HttpClient>;
export type GetEventTypesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all event types or a specific event type if name is provided. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 5 and 10.
 * To get the next page results, provide the pagination token from the
 * `GetEventTypesResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getEventTypes: API.PaginatedOperationMethod<GetEventTypesRequest, GetEventTypesResult, GetEventTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetExternalModelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details for one or more Amazon SageMaker models that have been imported into the
 * service. This is a paginated API. If you provide a null `maxResults`, this
 * actions retrieves a maximum of 10 records per page. If you provide a
 * `maxResults`, the value must be between 5 and 10. To get the next page
 * results, provide the pagination token from the `GetExternalModelsResult` as part
 * of your request. A null pagination token fetches the records from the beginning.
 */
export declare const getExternalModels: API.PaginatedOperationMethod<GetExternalModelsRequest, GetExternalModelsResult, GetExternalModelsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetKMSEncryptionKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the encryption key if a KMS key has been specified to be used to encrypt content in Amazon Fraud Detector.
 */
export declare const getKMSEncryptionKey: API.OperationMethod<GetKMSEncryptionKeyRequest, GetKMSEncryptionKeyResult, GetKMSEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type GetLabelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all labels or a specific label if name is provided. This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 50 records
 * per page. If you provide a `maxResults`, the value must be between 10 and 50.
 * To get the next page results, provide the pagination token from the
 * `GetGetLabelsResponse` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getLabels: API.PaginatedOperationMethod<GetLabelsRequest, GetLabelsResult, GetLabelsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetListElementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all the elements in the specified list.
 */
export declare const getListElements: API.PaginatedOperationMethod<GetListElementsRequest, GetListElementsResult, GetListElementsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetListsMetadataError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the metadata of either all the lists under the account or the specified list.
 */
export declare const getListsMetadata: API.PaginatedOperationMethod<GetListsMetadataRequest, GetListsMetadataResult, GetListsMetadataError, Credentials | HttpClient.HttpClient, unknown>;
export type GetModelsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets one or more models. Gets all models for the Amazon Web Services account if no model type and no model id provided. Gets all models for the Amazon Web Services account and model type, if the model type is specified but model id is not provided. Gets a specific model if (model type, model id) tuple is specified.
 *
 * This is a paginated API. If you
 * provide a null `maxResults`, this action retrieves a maximum of 10 records
 * per page. If you provide a `maxResults`, the value must be between 1 and 10.
 * To get the next page results, provide the pagination token from the
 * response as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getModels: API.PaginatedOperationMethod<GetModelsRequest, GetModelsResult, GetModelsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetModelVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the details of the specified model version.
 */
export declare const getModelVersion: API.OperationMethod<GetModelVersionRequest, GetModelVersionResult, GetModelVersionError, Credentials | HttpClient.HttpClient>;
export type GetOutcomesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets one or more outcomes. This is a paginated
 * API. If you provide a null `maxResults`, this actions retrieves a maximum of
 * 100 records per page. If you provide a `maxResults`, the value must be
 * between 50 and 100. To get the next page results, provide the pagination token from the
 * `GetOutcomesResult` as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const getOutcomes: API.PaginatedOperationMethod<GetOutcomesRequest, GetOutcomesResult, GetOutcomesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetRulesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get all rules for a detector (paginated) if `ruleId` and `ruleVersion` are not specified. Gets all rules for the detector and the `ruleId` if present (paginated). Gets a specific rule if both the `ruleId` and the `ruleVersion` are specified.
 *
 * This is a paginated API. Providing null maxResults results in retrieving maximum of 100 records per page. If you provide maxResults the value must be between 50 and 100. To get the next page result, a provide a pagination token from GetRulesResult as part of your request. Null pagination token fetches the records from the beginning.
 */
export declare const getRules: API.PaginatedOperationMethod<GetRulesRequest, GetRulesResult, GetRulesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetVariablesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets all of the variables or the specific variable. This is a
 * paginated API. Providing null `maxSizePerPage` results in retrieving maximum of
 * 100 records per page. If you provide `maxSizePerPage` the value must be between
 * 50 and 100. To get the next page result, a provide a pagination token from
 * `GetVariablesResult` as part of your request. Null pagination token
 * fetches the records from the beginning.
 */
export declare const getVariables: API.PaginatedOperationMethod<GetVariablesRequest, GetVariablesResult, GetVariablesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventPredictionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of past predictions. The list can be filtered by detector ID, detector version ID, event ID, event type, or by specifying a time period.
 * If filter is not specified, the most recent prediction is returned.
 *
 * For example, the following filter lists all past predictions for `xyz` event type -
 * {
 * "eventType":{
 * "value": "xyz" }”
 * }
 *
 * This is a paginated API. If you provide a null `maxResults`, this action will retrieve a maximum of 10 records per page.
 * If you provide a `maxResults`, the value must be between 50 and 100. To get the next page results, provide
 * the `nextToken` from the response as part of your request. A null `nextToken` fetches the records from the beginning.
 */
export declare const listEventPredictions: API.PaginatedOperationMethod<ListEventPredictionsRequest, ListEventPredictionsResult, ListEventPredictionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags associated with the resource. This is a paginated API. To get the next page results, provide the pagination token from the
 * response as part of your request. A null pagination token
 * fetches the records from the beginning.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient, unknown>;
export type PutDetectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates a detector.
 */
export declare const putDetector: API.OperationMethod<PutDetectorRequest, PutDetectorResult, PutDetectorError, Credentials | HttpClient.HttpClient>;
export type PutEntityTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an entity type. An entity represents who is performing the event. As part of a fraud prediction, you pass the entity ID to indicate the specific entity who performed the event. An entity type classifies the entity. Example classifications include customer, merchant, or account.
 */
export declare const putEntityType: API.OperationMethod<PutEntityTypeRequest, PutEntityTypeResult, PutEntityTypeError, Credentials | HttpClient.HttpClient>;
export type PutEventTypeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an event type. An event is a business activity that is evaluated for fraud risk. With Amazon Fraud Detector, you generate fraud predictions for events. An event type defines the structure for an event sent to Amazon Fraud Detector. This includes the variables sent as part of the event, the entity performing the event (such as a customer), and the labels that classify the event. Example event types include online payment transactions, account registrations, and authentications.
 */
export declare const putEventType: API.OperationMethod<PutEventTypeRequest, PutEventTypeResult, PutEventTypeError, Credentials | HttpClient.HttpClient>;
export type PutExternalModelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an Amazon SageMaker model endpoint. You can also use this action to update the configuration of the model endpoint, including the IAM role and/or the mapped variables.
 */
export declare const putExternalModel: API.OperationMethod<PutExternalModelRequest, PutExternalModelResult, PutExternalModelError, Credentials | HttpClient.HttpClient>;
export type PutKMSEncryptionKeyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Specifies the KMS key to be used to encrypt content in Amazon Fraud Detector.
 */
export declare const putKMSEncryptionKey: API.OperationMethod<PutKMSEncryptionKeyRequest, PutKMSEncryptionKeyResult, PutKMSEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type PutLabelError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates label. A label classifies an event as fraudulent or legitimate. Labels are associated with event types and used to train supervised machine learning models in Amazon Fraud Detector.
 */
export declare const putLabel: API.OperationMethod<PutLabelRequest, PutLabelResult, PutLabelError, Credentials | HttpClient.HttpClient>;
export type PutOutcomeError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates an outcome.
 */
export declare const putOutcome: API.OperationMethod<PutOutcomeRequest, PutOutcomeResult, PutOutcomeError, Credentials | HttpClient.HttpClient>;
export type SendEventError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stores events in Amazon Fraud Detector without generating fraud predictions for those events. For example, you can use `SendEvent` to upload a historical dataset, which you can then later use to train a model.
 */
export declare const sendEvent: API.OperationMethod<SendEventRequest, SendEventResult, SendEventError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a detector version. The detector version attributes that you can update include models, external model endpoints, rules, rule execution mode, and description. You can only update a `DRAFT` detector version.
 */
export declare const updateDetectorVersion: API.OperationMethod<UpdateDetectorVersionRequest, UpdateDetectorVersionResult, UpdateDetectorVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorVersionMetadataError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the detector version's description. You can update the metadata for any detector version (`DRAFT, ACTIVE,` or
 * `INACTIVE`).
 */
export declare const updateDetectorVersionMetadata: API.OperationMethod<UpdateDetectorVersionMetadataRequest, UpdateDetectorVersionMetadataResult, UpdateDetectorVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdateDetectorVersionStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the detector version’s status. You can perform the following promotions or
 * demotions using `UpdateDetectorVersionStatus`: `DRAFT` to `ACTIVE`, `ACTIVE` to `INACTIVE`, and `INACTIVE` to `ACTIVE`.
 */
export declare const updateDetectorVersionStatus: API.OperationMethod<UpdateDetectorVersionStatusRequest, UpdateDetectorVersionStatusResult, UpdateDetectorVersionStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateEventLabelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified event with a new label.
 */
export declare const updateEventLabel: API.OperationMethod<UpdateEventLabelRequest, UpdateEventLabelResult, UpdateEventLabelError, Credentials | HttpClient.HttpClient>;
export type UpdateListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a list.
 */
export declare const updateList: API.OperationMethod<UpdateListRequest, UpdateListResult, UpdateListError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates model description.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest, UpdateModelResult, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdateModelVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a model version. Updating a model version retrains an existing model version using updated training data and produces a new minor version of the model. You can update the training data set location and data access role attributes using this action. This action creates and trains a new minor version of the model, for example version 1.01, 1.02, 1.03.
 */
export declare const updateModelVersion: API.OperationMethod<UpdateModelVersionRequest, UpdateModelVersionResult, UpdateModelVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateModelVersionStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of a model version.
 *
 * You can perform the following status updates:
 *
 * - Change the `TRAINING_IN_PROGRESS` status to `TRAINING_CANCELLED`.
 *
 * - Change the `TRAINING_COMPLETE` status to `ACTIVE`.
 *
 * - Change `ACTIVE` to `INACTIVE`.
 */
export declare const updateModelVersionStatus: API.OperationMethod<UpdateModelVersionStatusRequest, UpdateModelVersionStatusResult, UpdateModelVersionStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleMetadataError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a rule's metadata. The description attribute can be updated.
 */
export declare const updateRuleMetadata: API.OperationMethod<UpdateRuleMetadataRequest, UpdateRuleMetadataResult, UpdateRuleMetadataError, Credentials | HttpClient.HttpClient>;
export type UpdateRuleVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a rule version resulting in a new rule version. Updates a rule version resulting in a new rule version (version 1, 2, 3 ...).
 */
export declare const updateRuleVersion: API.OperationMethod<UpdateRuleVersionRequest, UpdateRuleVersionResult, UpdateRuleVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateVariableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a variable.
 */
export declare const updateVariable: API.OperationMethod<UpdateVariableRequest, UpdateVariableResult, UpdateVariableError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=frauddetector.d.ts.map