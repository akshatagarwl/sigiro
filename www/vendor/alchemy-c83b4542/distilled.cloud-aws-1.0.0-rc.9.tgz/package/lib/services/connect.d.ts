import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConditionalOperationFailedException_base: S.Class<ConditionalOperationFailedException, S.TaggedStruct<"ConditionalOperationFailedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConditionalOperationFailedException extends /*@__PURE__*/ ConditionalOperationFailedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ContactFlowNotPublishedException_base: S.Class<ContactFlowNotPublishedException, S.TaggedStruct<"ContactFlowNotPublishedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContactFlowNotPublishedException extends /*@__PURE__*/ ContactFlowNotPublishedException_base {
}
declare const ContactNotFoundException_base: S.Class<ContactNotFoundException, S.TaggedStruct<"ContactNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ContactNotFoundException extends /*@__PURE__*/ ContactNotFoundException_base {
}
declare const ContactNotTerminatedException_base: S.Class<ContactNotTerminatedException, S.TaggedStruct<"ContactNotTerminatedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ContactNotTerminatedException extends /*@__PURE__*/ ContactNotTerminatedException_base {
}
declare const DestinationNotAllowedException_base: S.Class<DestinationNotAllowedException, S.TaggedStruct<"DestinationNotAllowedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DestinationNotAllowedException extends /*@__PURE__*/ DestinationNotAllowedException_base {
}
declare const DuplicateResourceException_base: S.Class<DuplicateResourceException, S.TaggedStruct<"DuplicateResourceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateResourceException extends /*@__PURE__*/ DuplicateResourceException_base {
}
declare const IdempotencyException_base: S.Class<IdempotencyException, S.TaggedStruct<"IdempotencyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotencyException extends /*@__PURE__*/ IdempotencyException_base {
}
declare const InternalServiceException_base: S.Class<InternalServiceException, S.TaggedStruct<"InternalServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidActiveRegionException_base: S.Class<InvalidActiveRegionException, S.TaggedStruct<"InvalidActiveRegionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidActiveRegionException extends /*@__PURE__*/ InvalidActiveRegionException_base {
}
declare const InvalidContactFlowException_base: S.Class<InvalidContactFlowException, S.TaggedStruct<"InvalidContactFlowException", {
    readonly problems: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidContactFlowException extends /*@__PURE__*/ InvalidContactFlowException_base {
}
declare const InvalidContactFlowModuleException_base: S.Class<InvalidContactFlowModuleException, S.TaggedStruct<"InvalidContactFlowModuleException", {
    readonly Problems: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidContactFlowModuleException extends /*@__PURE__*/ InvalidContactFlowModuleException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidTestCaseException_base: S.Class<InvalidTestCaseException, S.TaggedStruct<"InvalidTestCaseException", {
    readonly Problems: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTestCaseException extends /*@__PURE__*/ InvalidTestCaseException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MaximumResultReturnedException_base: S.Class<MaximumResultReturnedException, S.TaggedStruct<"MaximumResultReturnedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MaximumResultReturnedException extends /*@__PURE__*/ MaximumResultReturnedException_base {
}
declare const OutboundContactNotPermittedException_base: S.Class<OutboundContactNotPermittedException, S.TaggedStruct<"OutboundContactNotPermittedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OutboundContactNotPermittedException extends /*@__PURE__*/ OutboundContactNotPermittedException_base {
}
declare const OutputTypeNotFoundException_base: S.Class<OutputTypeNotFoundException, S.TaggedStruct<"OutputTypeNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OutputTypeNotFoundException extends /*@__PURE__*/ OutputTypeNotFoundException_base {
}
declare const PropertyValidationException_base: S.Class<PropertyValidationException, S.TaggedStruct<"PropertyValidationException", {
    readonly message: any;
    readonly PropertyList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PropertyValidationException extends /*@__PURE__*/ PropertyValidationException_base {
}
declare const ResourceConflictException_base: S.Class<ResourceConflictException, S.TaggedStruct<"ResourceConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly ResourceId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotReadyException_base: S.Class<ResourceNotReadyException, S.TaggedStruct<"ResourceNotReadyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UserNotFoundException_base: S.Class<UserNotFoundException, S.TaggedStruct<"UserNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundException extends /*@__PURE__*/ UserNotFoundException_base {
}
export type InstanceId = string;
export type ResourceId = string;
export type VersionNumber = number;
export interface ActivateEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
}
export declare const ActivateEvaluationFormRequest: S.Schema<ActivateEvaluationFormRequest>;
export type ARN = string;
export interface ActivateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export declare const ActivateEvaluationFormResponse: S.Schema<ActivateEvaluationFormResponse>;
export type DataSetId = string;
export type AWSAccountId = string;
export interface AssociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetId: string;
    TargetAccountId?: string;
}
export declare const AssociateAnalyticsDataSetRequest: S.Schema<AssociateAnalyticsDataSetRequest>;
export interface AssociateAnalyticsDataSetResponse {
    DataSetId?: string;
    TargetAccountId?: string;
    ResourceShareId?: string;
    ResourceShareArn?: string;
}
export declare const AssociateAnalyticsDataSetResponse: S.Schema<AssociateAnalyticsDataSetResponse>;
export type Origin = string;
export type ClientToken = string;
export interface AssociateApprovedOriginRequest {
    InstanceId: string;
    Origin: string;
    ClientToken?: string;
}
export declare const AssociateApprovedOriginRequest: S.Schema<AssociateApprovedOriginRequest>;
export interface AssociateApprovedOriginResponse {
}
export declare const AssociateApprovedOriginResponse: S.Schema<AssociateApprovedOriginResponse>;
export type BotName = string;
export type LexRegion = string;
export interface LexBot {
    Name: string;
    LexRegion: string;
}
export declare const LexBot: S.Schema<LexBot>;
export type AliasArn = string;
export interface LexV2Bot {
    AliasArn?: string;
}
export declare const LexV2Bot: S.Schema<LexV2Bot>;
export interface AssociateBotRequest {
    InstanceId: string;
    LexBot?: LexBot;
    LexV2Bot?: LexV2Bot;
    ClientToken?: string;
}
export declare const AssociateBotRequest: S.Schema<AssociateBotRequest>;
export interface AssociateBotResponse {
}
export declare const AssociateBotResponse: S.Schema<AssociateBotResponse>;
export type ContactId = string;
export type AgentResourceId = string;
export interface AssociateContactWithUserRequest {
    InstanceId: string;
    ContactId: string;
    UserId: string;
}
export declare const AssociateContactWithUserRequest: S.Schema<AssociateContactWithUserRequest>;
export interface AssociateContactWithUserResponse {
}
export declare const AssociateContactWithUserResponse: S.Schema<AssociateContactWithUserResponse>;
export type VocabularyLanguageCode = "ar-AE" | "de-CH" | "de-DE" | "en-AB" | "en-AU" | "en-GB" | "en-IE" | "en-IN" | "en-US" | "en-WL" | "es-ES" | "es-US" | "fr-CA" | "fr-FR" | "hi-IN" | "it-IT" | "ja-JP" | "ko-KR" | "pt-BR" | "pt-PT" | "zh-CN" | "en-NZ" | "en-ZA" | "ca-ES" | "da-DK" | "fi-FI" | "id-ID" | "ms-MY" | "nl-NL" | "no-NO" | "pl-PL" | "sv-SE" | "tl-PH" | (string & {});
export declare const VocabularyLanguageCode: any;
export type VocabularyId = string;
export interface AssociateDefaultVocabularyRequest {
    InstanceId: string;
    LanguageCode: VocabularyLanguageCode;
    VocabularyId?: string;
}
export declare const AssociateDefaultVocabularyRequest: S.Schema<AssociateDefaultVocabularyRequest>;
export interface AssociateDefaultVocabularyResponse {
}
export declare const AssociateDefaultVocabularyResponse: S.Schema<AssociateDefaultVocabularyResponse>;
export type EmailAddressId = string;
export interface AliasConfiguration {
    EmailAddressId: string;
}
export declare const AliasConfiguration: S.Schema<AliasConfiguration>;
export interface AssociateEmailAddressAliasRequest {
    EmailAddressId: string;
    InstanceId: string;
    AliasConfiguration: AliasConfiguration;
    ClientToken?: string;
}
export declare const AssociateEmailAddressAliasRequest: S.Schema<AssociateEmailAddressAliasRequest>;
export interface AssociateEmailAddressAliasResponse {
}
export declare const AssociateEmailAddressAliasResponse: S.Schema<AssociateEmailAddressAliasResponse>;
export type FlowAssociationResourceType = "SMS_PHONE_NUMBER" | "INBOUND_EMAIL" | "OUTBOUND_EMAIL" | "ANALYTICS_CONNECTOR" | "WHATSAPP_MESSAGING_PHONE_NUMBER" | (string & {});
export declare const FlowAssociationResourceType: any;
export interface AssociateFlowRequest {
    InstanceId: string;
    ResourceId: string;
    FlowId: string;
    ResourceType: FlowAssociationResourceType;
}
export declare const AssociateFlowRequest: S.Schema<AssociateFlowRequest>;
export interface AssociateFlowResponse {
}
export declare const AssociateFlowResponse: S.Schema<AssociateFlowResponse>;
export type HoursOfOperationId = string;
export interface ParentHoursOfOperationConfig {
    HoursOfOperationId?: string;
}
export declare const ParentHoursOfOperationConfig: S.Schema<ParentHoursOfOperationConfig>;
export type ParentHoursOfOperationConfigList = ParentHoursOfOperationConfig[];
export declare const ParentHoursOfOperationConfigList: any;
export interface AssociateHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    ParentHoursOfOperationConfigs: ParentHoursOfOperationConfig[];
}
export declare const AssociateHoursOfOperationsRequest: S.Schema<AssociateHoursOfOperationsRequest>;
export interface AssociateHoursOfOperationsResponse {
}
export declare const AssociateHoursOfOperationsResponse: S.Schema<AssociateHoursOfOperationsResponse>;
export type InstanceStorageResourceType = "CHAT_TRANSCRIPTS" | "CALL_RECORDINGS" | "SCHEDULED_REPORTS" | "MEDIA_STREAMS" | "CONTACT_TRACE_RECORDS" | "AGENT_EVENTS" | "REAL_TIME_CONTACT_ANALYSIS_SEGMENTS" | "ATTACHMENTS" | "CONTACT_EVALUATIONS" | "SCREEN_RECORDINGS" | "REAL_TIME_CONTACT_ANALYSIS_CHAT_SEGMENTS" | "REAL_TIME_CONTACT_ANALYSIS_VOICE_SEGMENTS" | "EMAIL_MESSAGES" | (string & {});
export declare const InstanceStorageResourceType: any;
export type AssociationId = string;
export type StorageType = "S3" | "KINESIS_VIDEO_STREAM" | "KINESIS_STREAM" | "KINESIS_FIREHOSE" | (string & {});
export declare const StorageType: any;
export type BucketName = string;
export type Prefix = string;
export type EncryptionType = "KMS" | (string & {});
export declare const EncryptionType: any;
export type KeyId = string;
export interface EncryptionConfig {
    EncryptionType: EncryptionType;
    KeyId: string;
}
export declare const EncryptionConfig: S.Schema<EncryptionConfig>;
export interface S3Config {
    BucketName: string;
    BucketPrefix: string;
    EncryptionConfig?: EncryptionConfig;
}
export declare const S3Config: S.Schema<S3Config>;
export type Hours = number;
export interface KinesisVideoStreamConfig {
    Prefix: string;
    RetentionPeriodHours: number;
    EncryptionConfig: EncryptionConfig;
}
export declare const KinesisVideoStreamConfig: S.Schema<KinesisVideoStreamConfig>;
export interface KinesisStreamConfig {
    StreamArn: string;
}
export declare const KinesisStreamConfig: S.Schema<KinesisStreamConfig>;
export interface KinesisFirehoseConfig {
    FirehoseArn: string;
}
export declare const KinesisFirehoseConfig: S.Schema<KinesisFirehoseConfig>;
export interface InstanceStorageConfig {
    AssociationId?: string;
    StorageType: StorageType;
    S3Config?: S3Config;
    KinesisVideoStreamConfig?: KinesisVideoStreamConfig;
    KinesisStreamConfig?: KinesisStreamConfig;
    KinesisFirehoseConfig?: KinesisFirehoseConfig;
}
export declare const InstanceStorageConfig: S.Schema<InstanceStorageConfig>;
export interface AssociateInstanceStorageConfigRequest {
    InstanceId: string;
    ResourceType: InstanceStorageResourceType;
    StorageConfig: InstanceStorageConfig;
    ClientToken?: string;
}
export declare const AssociateInstanceStorageConfigRequest: S.Schema<AssociateInstanceStorageConfigRequest>;
export interface AssociateInstanceStorageConfigResponse {
    AssociationId?: string;
}
export declare const AssociateInstanceStorageConfigResponse: S.Schema<AssociateInstanceStorageConfigResponse>;
export type FunctionArn = string;
export interface AssociateLambdaFunctionRequest {
    InstanceId: string;
    FunctionArn: string;
    ClientToken?: string;
}
export declare const AssociateLambdaFunctionRequest: S.Schema<AssociateLambdaFunctionRequest>;
export interface AssociateLambdaFunctionResponse {
}
export declare const AssociateLambdaFunctionResponse: S.Schema<AssociateLambdaFunctionResponse>;
export interface AssociateLexBotRequest {
    InstanceId: string;
    LexBot: LexBot;
    ClientToken?: string;
}
export declare const AssociateLexBotRequest: S.Schema<AssociateLexBotRequest>;
export interface AssociateLexBotResponse {
}
export declare const AssociateLexBotResponse: S.Schema<AssociateLexBotResponse>;
export type PhoneNumberId = string;
export type ContactFlowId = string;
export interface AssociatePhoneNumberContactFlowRequest {
    PhoneNumberId: string;
    InstanceId: string;
    ContactFlowId: string;
}
export declare const AssociatePhoneNumberContactFlowRequest: S.Schema<AssociatePhoneNumberContactFlowRequest>;
export interface AssociatePhoneNumberContactFlowResponse {
}
export declare const AssociatePhoneNumberContactFlowResponse: S.Schema<AssociatePhoneNumberContactFlowResponse>;
export type QueueId = string;
export interface EmailAddressConfig {
    EmailAddressId: string;
}
export declare const EmailAddressConfig: S.Schema<EmailAddressConfig>;
export type EmailAddressConfigList = EmailAddressConfig[];
export declare const EmailAddressConfigList: any;
export interface AssociateQueueEmailAddressesRequest {
    InstanceId: string;
    QueueId: string;
    EmailAddressesConfig: EmailAddressConfig[];
    ClientToken?: string;
}
export declare const AssociateQueueEmailAddressesRequest: S.Schema<AssociateQueueEmailAddressesRequest>;
export interface AssociateQueueEmailAddressesResponse {
}
export declare const AssociateQueueEmailAddressesResponse: S.Schema<AssociateQueueEmailAddressesResponse>;
export type QuickConnectId = string;
export type QuickConnectsList = string[];
export declare const QuickConnectsList: any;
export interface AssociateQueueQuickConnectsRequest {
    InstanceId: string;
    QueueId: string;
    QuickConnectIds: string[];
}
export declare const AssociateQueueQuickConnectsRequest: S.Schema<AssociateQueueQuickConnectsRequest>;
export interface AssociateQueueQuickConnectsResponse {
}
export declare const AssociateQueueQuickConnectsResponse: S.Schema<AssociateQueueQuickConnectsResponse>;
export type RoutingProfileId = string;
export type Channel = "VOICE" | "CHAT" | "TASK" | "EMAIL" | (string & {});
export declare const Channel: any;
export interface RoutingProfileQueueReference {
    QueueId: string;
    Channel: Channel;
}
export declare const RoutingProfileQueueReference: S.Schema<RoutingProfileQueueReference>;
export type Priority = number;
export type Delay = number;
export interface RoutingProfileQueueConfig {
    QueueReference: RoutingProfileQueueReference;
    Priority: number;
    Delay: number;
}
export declare const RoutingProfileQueueConfig: S.Schema<RoutingProfileQueueConfig>;
export type RoutingProfileQueueConfigList = RoutingProfileQueueConfig[];
export declare const RoutingProfileQueueConfigList: any;
export interface RoutingProfileManualAssignmentQueueConfig {
    QueueReference: RoutingProfileQueueReference;
}
export declare const RoutingProfileManualAssignmentQueueConfig: S.Schema<RoutingProfileManualAssignmentQueueConfig>;
export type RoutingProfileManualAssignmentQueueConfigList = RoutingProfileManualAssignmentQueueConfig[];
export declare const RoutingProfileManualAssignmentQueueConfigList: any;
export interface AssociateRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    QueueConfigs?: RoutingProfileQueueConfig[];
    ManualAssignmentQueueConfigs?: RoutingProfileManualAssignmentQueueConfig[];
}
export declare const AssociateRoutingProfileQueuesRequest: S.Schema<AssociateRoutingProfileQueuesRequest>;
export interface AssociateRoutingProfileQueuesResponse {
}
export declare const AssociateRoutingProfileQueuesResponse: S.Schema<AssociateRoutingProfileQueuesResponse>;
export type PEM = string;
export interface AssociateSecurityKeyRequest {
    InstanceId: string;
    Key: string;
    ClientToken?: string;
}
export declare const AssociateSecurityKeyRequest: S.Schema<AssociateSecurityKeyRequest>;
export interface AssociateSecurityKeyResponse {
    AssociationId?: string;
}
export declare const AssociateSecurityKeyResponse: S.Schema<AssociateSecurityKeyResponse>;
export type SecurityProfileId = string;
export interface SecurityProfileItem {
    Id?: string;
}
export declare const SecurityProfileItem: S.Schema<SecurityProfileItem>;
export type SecurityProfiles = SecurityProfileItem[];
export declare const SecurityProfiles: any;
export type EntityType = "USER" | "AI_AGENT" | (string & {});
export declare const EntityType: any;
export type EntityArn = string;
export interface AssociateSecurityProfilesRequest {
    InstanceId: string;
    SecurityProfiles: SecurityProfileItem[];
    EntityType: EntityType;
    EntityArn: string;
}
export declare const AssociateSecurityProfilesRequest: S.Schema<AssociateSecurityProfilesRequest>;
export interface AssociateSecurityProfilesResponse {
}
export declare const AssociateSecurityProfilesResponse: S.Schema<AssociateSecurityProfilesResponse>;
export type TrafficDistributionGroupIdOrArn = string;
export type UserId = string;
export interface AssociateTrafficDistributionGroupUserRequest {
    TrafficDistributionGroupId: string;
    UserId: string;
    InstanceId: string;
}
export declare const AssociateTrafficDistributionGroupUserRequest: S.Schema<AssociateTrafficDistributionGroupUserRequest>;
export interface AssociateTrafficDistributionGroupUserResponse {
}
export declare const AssociateTrafficDistributionGroupUserResponse: S.Schema<AssociateTrafficDistributionGroupUserResponse>;
export type PredefinedAttributeName = string;
export type PredefinedAttributeStringValue = string;
export type ProficiencyLevel = number;
export interface UserProficiency {
    AttributeName: string;
    AttributeValue: string;
    Level: number;
}
export declare const UserProficiency: S.Schema<UserProficiency>;
export type UserProficiencyList = UserProficiency[];
export declare const UserProficiencyList: any;
export interface AssociateUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    UserProficiencies: UserProficiency[];
}
export declare const AssociateUserProficienciesRequest: S.Schema<AssociateUserProficienciesRequest>;
export interface AssociateUserProficienciesResponse {
}
export declare const AssociateUserProficienciesResponse: S.Schema<AssociateUserProficienciesResponse>;
export type WorkspaceId = string;
export type WorkspaceResourceArnList = string[];
export declare const WorkspaceResourceArnList: any;
export interface AssociateWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
    ResourceArns: string[];
}
export declare const AssociateWorkspaceRequest: S.Schema<AssociateWorkspaceRequest>;
export interface SuccessfulBatchAssociationSummary {
    ResourceArn?: string;
}
export declare const SuccessfulBatchAssociationSummary: S.Schema<SuccessfulBatchAssociationSummary>;
export type SuccessfulBatchAssociationSummaryList = SuccessfulBatchAssociationSummary[];
export declare const SuccessfulBatchAssociationSummaryList: any;
export type WorkspaceErrorCode = string;
export type WorkspaceBatchErrorMessage = string;
export interface FailedBatchAssociationSummary {
    ResourceArn?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const FailedBatchAssociationSummary: S.Schema<FailedBatchAssociationSummary>;
export type FailedBatchAssociationSummaryList = FailedBatchAssociationSummary[];
export declare const FailedBatchAssociationSummaryList: any;
export interface AssociateWorkspaceResponse {
    SuccessfulList?: SuccessfulBatchAssociationSummary[];
    FailedList?: FailedBatchAssociationSummary[];
}
export declare const AssociateWorkspaceResponse: S.Schema<AssociateWorkspaceResponse>;
export type DataSetIds = string[];
export declare const DataSetIds: any;
export interface BatchAssociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetIds: string[];
    TargetAccountId?: string;
}
export declare const BatchAssociateAnalyticsDataSetRequest: S.Schema<BatchAssociateAnalyticsDataSetRequest>;
export interface AnalyticsDataAssociationResult {
    DataSetId?: string;
    TargetAccountId?: string;
    ResourceShareId?: string;
    ResourceShareArn?: string;
    ResourceShareStatus?: string;
}
export declare const AnalyticsDataAssociationResult: S.Schema<AnalyticsDataAssociationResult>;
export type AnalyticsDataAssociationResults = AnalyticsDataAssociationResult[];
export declare const AnalyticsDataAssociationResults: any;
export interface ErrorResult {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const ErrorResult: S.Schema<ErrorResult>;
export type ErrorResults = ErrorResult[];
export declare const ErrorResults: any;
export interface BatchAssociateAnalyticsDataSetResponse {
    Created?: AnalyticsDataAssociationResult[];
    Errors?: ErrorResult[];
}
export declare const BatchAssociateAnalyticsDataSetResponse: S.Schema<BatchAssociateAnalyticsDataSetResponse>;
export type DataTableId = string;
export type DataTableName = string;
export interface PrimaryValue {
    AttributeName: string;
    Value: string;
}
export declare const PrimaryValue: S.Schema<PrimaryValue>;
export type PrimaryValuesSet = PrimaryValue[];
export declare const PrimaryValuesSet: any;
export interface DataTableLockVersion {
    DataTable?: string;
    Attribute?: string;
    PrimaryValues?: string;
    Value?: string;
}
export declare const DataTableLockVersion: S.Schema<DataTableLockVersion>;
export type RegionName = string;
export interface DataTableValue {
    PrimaryValues?: PrimaryValue[];
    AttributeName: string;
    Value: string;
    LockVersion?: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const DataTableValue: S.Schema<DataTableValue>;
export type DataTableValueList = DataTableValue[];
export declare const DataTableValueList: any;
export interface BatchCreateDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValue[];
}
export declare const BatchCreateDataTableValueRequest: S.Schema<BatchCreateDataTableValueRequest>;
export interface BatchCreateDataTableValueSuccessResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    RecordId: string;
    LockVersion: DataTableLockVersion;
}
export declare const BatchCreateDataTableValueSuccessResult: S.Schema<BatchCreateDataTableValueSuccessResult>;
export type BatchCreateDataTableValueSuccessResultList = BatchCreateDataTableValueSuccessResult[];
export declare const BatchCreateDataTableValueSuccessResultList: any;
export interface BatchCreateDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export declare const BatchCreateDataTableValueFailureResult: S.Schema<BatchCreateDataTableValueFailureResult>;
export type BatchCreateDataTableValueFailureResultList = BatchCreateDataTableValueFailureResult[];
export declare const BatchCreateDataTableValueFailureResultList: any;
export interface BatchCreateDataTableValueResponse {
    Successful: BatchCreateDataTableValueSuccessResult[];
    Failed: BatchCreateDataTableValueFailureResult[];
}
export declare const BatchCreateDataTableValueResponse: S.Schema<BatchCreateDataTableValueResponse>;
export interface DataTableDeleteValueIdentifier {
    PrimaryValues?: PrimaryValue[];
    AttributeName: string;
    LockVersion: DataTableLockVersion;
}
export declare const DataTableDeleteValueIdentifier: S.Schema<DataTableDeleteValueIdentifier>;
export type DataTableDeleteValueIdentifierList = DataTableDeleteValueIdentifier[];
export declare const DataTableDeleteValueIdentifierList: any;
export interface BatchDeleteDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableDeleteValueIdentifier[];
}
export declare const BatchDeleteDataTableValueRequest: S.Schema<BatchDeleteDataTableValueRequest>;
export interface BatchDeleteDataTableValueSuccessResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    LockVersion: DataTableLockVersion;
}
export declare const BatchDeleteDataTableValueSuccessResult: S.Schema<BatchDeleteDataTableValueSuccessResult>;
export type BatchDeleteDataTableValueSuccessResultList = BatchDeleteDataTableValueSuccessResult[];
export declare const BatchDeleteDataTableValueSuccessResultList: any;
export interface BatchDeleteDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export declare const BatchDeleteDataTableValueFailureResult: S.Schema<BatchDeleteDataTableValueFailureResult>;
export type BatchDeleteDataTableValueFailureResultList = BatchDeleteDataTableValueFailureResult[];
export declare const BatchDeleteDataTableValueFailureResultList: any;
export interface BatchDeleteDataTableValueResponse {
    Successful: BatchDeleteDataTableValueSuccessResult[];
    Failed: BatchDeleteDataTableValueFailureResult[];
}
export declare const BatchDeleteDataTableValueResponse: S.Schema<BatchDeleteDataTableValueResponse>;
export interface DataTableValueIdentifier {
    PrimaryValues?: PrimaryValue[];
    AttributeName: string;
}
export declare const DataTableValueIdentifier: S.Schema<DataTableValueIdentifier>;
export type DataTableValueIdentifierList = DataTableValueIdentifier[];
export declare const DataTableValueIdentifierList: any;
export interface BatchDescribeDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValueIdentifier[];
}
export declare const BatchDescribeDataTableValueRequest: S.Schema<BatchDescribeDataTableValueRequest>;
export interface PrimaryValueResponse {
    AttributeName?: string;
    AttributeId?: string;
    Value?: string;
}
export declare const PrimaryValueResponse: S.Schema<PrimaryValueResponse>;
export type PrimaryValuesResponseSet = PrimaryValueResponse[];
export declare const PrimaryValuesResponseSet: any;
export interface BatchDescribeDataTableValueSuccessResult {
    RecordId: string;
    AttributeId: string;
    PrimaryValues: PrimaryValueResponse[];
    AttributeName: string;
    Value?: string;
    LockVersion: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const BatchDescribeDataTableValueSuccessResult: S.Schema<BatchDescribeDataTableValueSuccessResult>;
export type BatchDescribeDataTableValueSuccessResultList = BatchDescribeDataTableValueSuccessResult[];
export declare const BatchDescribeDataTableValueSuccessResultList: any;
export interface BatchDescribeDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export declare const BatchDescribeDataTableValueFailureResult: S.Schema<BatchDescribeDataTableValueFailureResult>;
export type BatchDescribeDataTableValueFailureResultList = BatchDescribeDataTableValueFailureResult[];
export declare const BatchDescribeDataTableValueFailureResultList: any;
export interface BatchDescribeDataTableValueResponse {
    Successful: BatchDescribeDataTableValueSuccessResult[];
    Failed: BatchDescribeDataTableValueFailureResult[];
}
export declare const BatchDescribeDataTableValueResponse: S.Schema<BatchDescribeDataTableValueResponse>;
export interface BatchDisassociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetIds: string[];
    TargetAccountId?: string;
}
export declare const BatchDisassociateAnalyticsDataSetRequest: S.Schema<BatchDisassociateAnalyticsDataSetRequest>;
export interface BatchDisassociateAnalyticsDataSetResponse {
    Deleted?: string[];
    Errors?: ErrorResult[];
}
export declare const BatchDisassociateAnalyticsDataSetResponse: S.Schema<BatchDisassociateAnalyticsDataSetResponse>;
export type FileId = string;
export type FileIdList = string[];
export declare const FileIdList: any;
export interface BatchGetAttachedFileMetadataRequest {
    FileIds: string[];
    InstanceId: string;
    AssociatedResourceArn: string;
}
export declare const BatchGetAttachedFileMetadataRequest: S.Schema<BatchGetAttachedFileMetadataRequest>;
export type ISO8601Datetime = string;
export type FileName = string;
export type FileSizeInBytes = number;
export type FileStatusType = "APPROVED" | "REJECTED" | "PROCESSING" | "FAILED" | (string & {});
export declare const FileStatusType: any;
export type CreatedByInfo = {
    ConnectUserArn: string;
    AWSIdentityArn?: never;
} | {
    ConnectUserArn?: never;
    AWSIdentityArn: string;
};
export declare const CreatedByInfo: any;
export type FileUseCaseType = "CONTACT_ANALYSIS" | "EMAIL_MESSAGE" | "EMAIL_MESSAGE_PLAIN_TEXT" | "EMAIL_MESSAGE_REDACTED" | "EMAIL_MESSAGE_PLAIN_TEXT_REDACTED" | "ATTACHMENT" | "VOICE_RECORDING" | (string & {});
export declare const FileUseCaseType: any;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface AttachedFile {
    CreationTime: string;
    FileArn: string;
    FileId: string;
    FileName: string;
    FileSizeInBytes: number;
    FileStatus: FileStatusType;
    CreatedBy?: CreatedByInfo;
    FileUseCaseType?: FileUseCaseType;
    AssociatedResourceArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const AttachedFile: S.Schema<AttachedFile>;
export type AttachedFilesList = AttachedFile[];
export declare const AttachedFilesList: any;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface AttachedFileError {
    ErrorCode?: string;
    ErrorMessage?: string;
    FileId?: string;
}
export declare const AttachedFileError: S.Schema<AttachedFileError>;
export type AttachedFileErrorsList = AttachedFileError[];
export declare const AttachedFileErrorsList: any;
export interface BatchGetAttachedFileMetadataResponse {
    Files?: AttachedFile[];
    Errors?: AttachedFileError[];
}
export declare const BatchGetAttachedFileMetadataResponse: S.Schema<BatchGetAttachedFileMetadataResponse>;
export type ResourceArnListMaxLimit100 = string[];
export declare const ResourceArnListMaxLimit100: any;
export type ListFlowAssociationResourceType = "WHATSAPP_MESSAGING_PHONE_NUMBER" | "VOICE_PHONE_NUMBER" | "INBOUND_EMAIL" | "OUTBOUND_EMAIL" | "ANALYTICS_CONNECTOR" | (string & {});
export declare const ListFlowAssociationResourceType: any;
export interface BatchGetFlowAssociationRequest {
    InstanceId: string;
    ResourceIds: string[];
    ResourceType?: ListFlowAssociationResourceType;
}
export declare const BatchGetFlowAssociationRequest: S.Schema<BatchGetFlowAssociationRequest>;
export interface FlowAssociationSummary {
    ResourceId?: string;
    FlowId?: string;
    ResourceType?: ListFlowAssociationResourceType;
}
export declare const FlowAssociationSummary: S.Schema<FlowAssociationSummary>;
export type FlowAssociationSummaryList = FlowAssociationSummary[];
export declare const FlowAssociationSummaryList: any;
export interface BatchGetFlowAssociationResponse {
    FlowAssociationSummaryList?: FlowAssociationSummary[];
}
export declare const BatchGetFlowAssociationResponse: S.Schema<BatchGetFlowAssociationResponse>;
export type EndpointType = "TELEPHONE_NUMBER" | "VOIP" | "CONTACT_FLOW" | "CONNECT_PHONENUMBER_ARN" | "EMAIL_ADDRESS" | (string & {});
export declare const EndpointType: any;
export type EndpointAddress = string;
export interface Endpoint {
    Type?: EndpointType;
    Address?: string;
}
export declare const Endpoint: S.Schema<Endpoint>;
export type RequestIdentifier = string;
export type AttributeName = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export declare const Attributes: any;
export type CampaignId = string;
export interface Campaign {
    CampaignId?: string;
}
export declare const Campaign: S.Schema<Campaign>;
export type OutboundStrategyType = "AGENT_FIRST" | (string & {});
export declare const OutboundStrategyType: any;
export type PostAcceptPreviewTimeoutDurationInSeconds = number;
export interface PostAcceptTimeoutConfig {
    DurationInSeconds: number;
}
export declare const PostAcceptTimeoutConfig: S.Schema<PostAcceptTimeoutConfig>;
export type AllowedUserAction = "CALL" | "DISCARD" | (string & {});
export declare const AllowedUserAction: any;
export type AllowedUserActions = AllowedUserAction[];
export declare const AllowedUserActions: any;
export interface Preview {
    PostAcceptTimeoutConfig: PostAcceptTimeoutConfig;
    AllowedUserActions: AllowedUserAction[];
}
export declare const Preview: S.Schema<Preview>;
export interface AgentFirst {
    Preview?: Preview;
}
export declare const AgentFirst: S.Schema<AgentFirst>;
export interface OutboundStrategyConfig {
    AgentFirst?: AgentFirst;
}
export declare const OutboundStrategyConfig: S.Schema<OutboundStrategyConfig>;
export interface OutboundStrategy {
    Type: OutboundStrategyType;
    Config?: OutboundStrategyConfig;
}
export declare const OutboundStrategy: S.Schema<OutboundStrategy>;
export interface ContactDataRequest {
    SystemEndpoint?: Endpoint;
    CustomerEndpoint?: Endpoint;
    RequestIdentifier?: string;
    QueueId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    Campaign?: Campaign;
    OutboundStrategy?: OutboundStrategy;
}
export declare const ContactDataRequest: S.Schema<ContactDataRequest>;
export type ContactDataRequestList = ContactDataRequest[];
export declare const ContactDataRequestList: any;
export interface BatchPutContactRequest {
    ClientToken?: string;
    InstanceId: string;
    ContactDataRequestList: ContactDataRequest[];
}
export declare const BatchPutContactRequest: S.Schema<BatchPutContactRequest>;
export interface SuccessfulRequest {
    RequestIdentifier?: string;
    ContactId?: string;
}
export declare const SuccessfulRequest: S.Schema<SuccessfulRequest>;
export type SuccessfulRequestList = SuccessfulRequest[];
export declare const SuccessfulRequestList: any;
export type FailureReasonCode = "INVALID_ATTRIBUTE_KEY" | "INVALID_CUSTOMER_ENDPOINT" | "INVALID_SYSTEM_ENDPOINT" | "INVALID_QUEUE" | "INVALID_OUTBOUND_STRATEGY" | "MISSING_CAMPAIGN" | "MISSING_CUSTOMER_ENDPOINT" | "MISSING_QUEUE_ID_AND_SYSTEM_ENDPOINT" | "REQUEST_THROTTLED" | "IDEMPOTENCY_EXCEPTION" | "INTERNAL_ERROR" | (string & {});
export declare const FailureReasonCode: any;
export interface FailedRequest {
    RequestIdentifier?: string;
    FailureReasonCode?: FailureReasonCode;
    FailureReasonMessage?: string;
}
export declare const FailedRequest: S.Schema<FailedRequest>;
export type FailedRequestList = FailedRequest[];
export declare const FailedRequestList: any;
export interface BatchPutContactResponse {
    SuccessfulRequestList?: SuccessfulRequest[];
    FailedRequestList?: FailedRequest[];
}
export declare const BatchPutContactResponse: S.Schema<BatchPutContactResponse>;
export interface BatchUpdateDataTableValueRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValue[];
}
export declare const BatchUpdateDataTableValueRequest: S.Schema<BatchUpdateDataTableValueRequest>;
export interface BatchUpdateDataTableValueSuccessResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    LockVersion: DataTableLockVersion;
}
export declare const BatchUpdateDataTableValueSuccessResult: S.Schema<BatchUpdateDataTableValueSuccessResult>;
export type BatchUpdateDataTableValueSuccessResultList = BatchUpdateDataTableValueSuccessResult[];
export declare const BatchUpdateDataTableValueSuccessResultList: any;
export interface BatchUpdateDataTableValueFailureResult {
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    Message: string;
}
export declare const BatchUpdateDataTableValueFailureResult: S.Schema<BatchUpdateDataTableValueFailureResult>;
export type BatchUpdateDataTableValueFailureResultList = BatchUpdateDataTableValueFailureResult[];
export declare const BatchUpdateDataTableValueFailureResultList: any;
export interface BatchUpdateDataTableValueResponse {
    Successful: BatchUpdateDataTableValueSuccessResult[];
    Failed: BatchUpdateDataTableValueFailureResult[];
}
export declare const BatchUpdateDataTableValueResponse: S.Schema<BatchUpdateDataTableValueResponse>;
export type PhoneNumber = string;
export type PhoneNumberDescription = string;
export interface ClaimPhoneNumberRequest {
    TargetArn?: string;
    InstanceId?: string;
    PhoneNumber: string;
    PhoneNumberDescription?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export declare const ClaimPhoneNumberRequest: S.Schema<ClaimPhoneNumberRequest>;
export interface ClaimPhoneNumberResponse {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
}
export declare const ClaimPhoneNumberResponse: S.Schema<ClaimPhoneNumberResponse>;
export interface CompleteAttachedFileUploadRequest {
    InstanceId: string;
    FileId: string;
    AssociatedResourceArn: string;
}
export declare const CompleteAttachedFileUploadRequest: S.Schema<CompleteAttachedFileUploadRequest>;
export interface CompleteAttachedFileUploadResponse {
}
export declare const CompleteAttachedFileUploadResponse: S.Schema<CompleteAttachedFileUploadResponse>;
export type AgentStatusName = string;
export type AgentStatusDescription = string;
export type AgentStatusState = "ENABLED" | "DISABLED" | (string & {});
export declare const AgentStatusState: any;
export type AgentStatusOrderNumber = number;
export interface CreateAgentStatusRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    State: AgentStatusState;
    DisplayOrder?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAgentStatusRequest: S.Schema<CreateAgentStatusRequest>;
export type AgentStatusId = string;
export interface CreateAgentStatusResponse {
    AgentStatusARN?: string;
    AgentStatusId?: string;
}
export declare const CreateAgentStatusResponse: S.Schema<CreateAgentStatusResponse>;
export type FileSourceUri = string;
export interface CreateAttachedFileRequest {
    ClientToken?: string;
    InstanceId: string;
    FileUseCaseType: FileUseCaseType;
    FileSourceUri: string;
    AssociatedResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateAttachedFileRequest: S.Schema<CreateAttachedFileRequest>;
export interface CreateAttachedFileResponse {
    FileArn?: string;
    FileId?: string;
    CreationTime?: string;
    FileStatus?: FileStatusType;
}
export declare const CreateAttachedFileResponse: S.Schema<CreateAttachedFileResponse>;
export type SecurityProfileIds = string[];
export declare const SecurityProfileIds: any;
export type AuthCodeEntityType = "CUSTOMER_PROFILE" | (string & {});
export declare const AuthCodeEntityType: any;
export type EntityId = string;
export type CustomerProfilesDomainName = string;
export interface AuthScope {
    SecurityProfileIds?: string[];
    EntityType: AuthCodeEntityType;
    EntityId?: string;
    DomainName?: string;
}
export declare const AuthScope: S.Schema<AuthScope>;
export type MaxSessionDurationMinutes = number;
export type SessionInactivityDurationMinutes = number;
export interface CreateAuthCodeRequest {
    InstanceId: string;
    Scope: AuthScope;
    MaxSessionDurationMinutes?: number;
    SessionInactivityDurationMinutes: number;
}
export declare const CreateAuthCodeRequest: S.Schema<CreateAuthCodeRequest>;
export type AuthCode = string | redacted.Redacted<string>;
export type SessionId = string;
export interface CreateAuthCodeResponse {
    AuthCode?: string | redacted.Redacted<string>;
    SessionId?: string;
    EntityType?: AuthCodeEntityType;
    EntityId?: string;
}
export declare const CreateAuthCodeResponse: S.Schema<CreateAuthCodeResponse>;
export type ReferenceKey = string;
export type ReferenceValue = string;
export type ReferenceType = "URL" | "ATTACHMENT" | "CONTACT_ANALYSIS" | "NUMBER" | "STRING" | "DATE" | "EMAIL" | "EMAIL_MESSAGE" | "EMAIL_MESSAGE_PLAIN_TEXT" | "EMAIL_MESSAGE_PLAIN_TEXT_REDACTED" | "EMAIL_MESSAGE_REDACTED" | (string & {});
export declare const ReferenceType: any;
export type ReferenceStatus = "AVAILABLE" | "DELETED" | "APPROVED" | "REJECTED" | "PROCESSING" | "FAILED" | (string & {});
export declare const ReferenceStatus: any;
export type ReferenceArn = string;
export type ReferenceStatusReason = string;
export interface Reference {
    Value?: string;
    Type: ReferenceType;
    Status?: ReferenceStatus;
    Arn?: string;
    StatusReason?: string;
}
export declare const Reference: S.Schema<Reference>;
export type ContactReferences = {
    [key: string]: Reference | undefined;
};
export declare const ContactReferences: any;
export type ContactInitiationMethod = "INBOUND" | "OUTBOUND" | "TRANSFER" | "QUEUE_TRANSFER" | "CALLBACK" | "API" | "DISCONNECT" | "MONITOR" | "EXTERNAL_OUTBOUND" | "WEBRTC_API" | "AGENT_REPLY" | "FLOW" | (string & {});
export declare const ContactInitiationMethod: any;
export type ExpiryDurationInMinutes = number;
export interface UserInfo {
    UserId?: string;
}
export declare const UserInfo: S.Schema<UserInfo>;
export type InitiateAs = "CONNECTED_TO_USER" | "COMPLETED" | (string & {});
export declare const InitiateAs: any;
export type Name = string | redacted.Redacted<string>;
export type Description = string | redacted.Redacted<string>;
export type SegmentAttributeName = string;
export type SegmentAttributeValueString = string;
export type SegmentAttributeValueMap = {
    [key: string]: SegmentAttributeValue | undefined;
};
export declare const SegmentAttributeValueMap: S.Schema<SegmentAttributeValueMap>;
export type SegmentAttributeValueInteger = number;
export type SegmentAttributeValueList = SegmentAttributeValue[];
export declare const SegmentAttributeValueList: S.Schema<SegmentAttributeValueList>;
export interface SegmentAttributeValue {
    ValueString?: string;
    ValueMap?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    ValueInteger?: number;
    ValueList?: SegmentAttributeValue[];
    ValueArn?: string;
}
export declare const SegmentAttributeValue: S.Schema<SegmentAttributeValue>;
export type SegmentAttributes = {
    [key: string]: SegmentAttributeValue | undefined;
};
export declare const SegmentAttributes: any;
export interface CreateContactRequest {
    InstanceId: string;
    ClientToken?: string;
    RelatedContactId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    References?: {
        [key: string]: Reference | undefined;
    };
    Channel: Channel;
    InitiationMethod: ContactInitiationMethod;
    ExpiryDurationInMinutes?: number;
    UserInfo?: UserInfo;
    InitiateAs?: InitiateAs;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    PreviousContactId?: string;
}
export declare const CreateContactRequest: S.Schema<CreateContactRequest>;
export interface CreateContactResponse {
    ContactId?: string;
    ContactArn?: string;
}
export declare const CreateContactResponse: S.Schema<CreateContactResponse>;
export type ContactFlowName = string;
export type ContactFlowType = "CONTACT_FLOW" | "CUSTOMER_QUEUE" | "CUSTOMER_HOLD" | "CUSTOMER_WHISPER" | "AGENT_HOLD" | "AGENT_WHISPER" | "OUTBOUND_WHISPER" | "AGENT_TRANSFER" | "QUEUE_TRANSFER" | "CAMPAIGN" | (string & {});
export declare const ContactFlowType: any;
export type ContactFlowDescription = string;
export type ContactFlowContent = string;
export type ContactFlowStatus = "PUBLISHED" | "SAVED" | (string & {});
export declare const ContactFlowStatus: any;
export interface CreateContactFlowRequest {
    InstanceId: string;
    Name: string;
    Type: ContactFlowType;
    Description?: string;
    Content: string;
    Status?: ContactFlowStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateContactFlowRequest: S.Schema<CreateContactFlowRequest>;
export type FlowContentSha256 = string;
export interface CreateContactFlowResponse {
    ContactFlowId?: string;
    ContactFlowArn?: string;
    FlowContentSha256?: string;
}
export declare const CreateContactFlowResponse: S.Schema<CreateContactFlowResponse>;
export type ContactFlowModuleName = string;
export type ContactFlowModuleDescription = string;
export type ContactFlowModuleContent = string;
export type FlowModuleSettings = string;
export interface ExternalInvocationConfiguration {
    Enabled?: boolean;
}
export declare const ExternalInvocationConfiguration: S.Schema<ExternalInvocationConfiguration>;
export interface CreateContactFlowModuleRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    Content: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    Settings?: string;
    ExternalInvocationConfiguration?: ExternalInvocationConfiguration;
}
export declare const CreateContactFlowModuleRequest: S.Schema<CreateContactFlowModuleRequest>;
export type ContactFlowModuleId = string;
export interface CreateContactFlowModuleResponse {
    Id?: string;
    Arn?: string;
}
export declare const CreateContactFlowModuleResponse: S.Schema<CreateContactFlowModuleResponse>;
export type InstanceIdOrArn = string;
export type ResourceVersion = number;
export type ContactFlowModuleAlias = string;
export interface CreateContactFlowModuleAliasRequest {
    InstanceId: string;
    Description?: string;
    ContactFlowModuleId: string;
    ContactFlowModuleVersion: number;
    AliasName: string;
}
export declare const CreateContactFlowModuleAliasRequest: S.Schema<CreateContactFlowModuleAliasRequest>;
export interface CreateContactFlowModuleAliasResponse {
    ContactFlowModuleArn?: string;
    Id?: string;
}
export declare const CreateContactFlowModuleAliasResponse: S.Schema<CreateContactFlowModuleAliasResponse>;
export type FlowModuleContentSha256 = string;
export interface CreateContactFlowModuleVersionRequest {
    InstanceId: string;
    Description?: string;
    ContactFlowModuleId: string;
    FlowModuleContentSha256?: string;
}
export declare const CreateContactFlowModuleVersionRequest: S.Schema<CreateContactFlowModuleVersionRequest>;
export interface CreateContactFlowModuleVersionResponse {
    ContactFlowModuleArn?: string;
    Version?: number;
}
export declare const CreateContactFlowModuleVersionResponse: S.Schema<CreateContactFlowModuleVersionResponse>;
export interface CreateContactFlowVersionRequest {
    InstanceId: string;
    Description?: string;
    ContactFlowId: string;
    FlowContentSha256?: string;
    ContactFlowVersion?: number;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const CreateContactFlowVersionRequest: S.Schema<CreateContactFlowVersionRequest>;
export interface CreateContactFlowVersionResponse {
    ContactFlowArn?: string;
    Version?: number;
}
export declare const CreateContactFlowVersionResponse: S.Schema<CreateContactFlowVersionResponse>;
export type DataTableDescription = string;
export type TimeZone = string;
export type DataTableLockLevel = "NONE" | "DATA_TABLE" | "PRIMARY_VALUE" | "ATTRIBUTE" | "VALUE" | (string & {});
export declare const DataTableLockLevel: any;
export type DataTableStatus = "PUBLISHED" | (string & {});
export declare const DataTableStatus: any;
export interface CreateDataTableRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    TimeZone: string;
    ValueLockLevel: DataTableLockLevel;
    Status: DataTableStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDataTableRequest: S.Schema<CreateDataTableRequest>;
export interface CreateDataTableResponse {
    Id: string;
    Arn: string;
    LockVersion: DataTableLockVersion;
}
export declare const CreateDataTableResponse: S.Schema<CreateDataTableResponse>;
export type DataTableAttributeValueType = "TEXT" | "NUMBER" | "BOOLEAN" | "TEXT_LIST" | "NUMBER_LIST" | (string & {});
export declare const DataTableAttributeValueType: any;
export type LengthBoundary = number;
export type ValueBoundary = number;
export type PositiveAndNegativeDouble = number;
export type PositiveDouble = number;
export type ValidationEnumValues = string[];
export declare const ValidationEnumValues: any;
export interface ValidationEnum {
    Strict?: boolean;
    Values?: string[];
}
export declare const ValidationEnum: S.Schema<ValidationEnum>;
export interface Validation {
    MinLength?: number;
    MaxLength?: number;
    MinValues?: number;
    MaxValues?: number;
    IgnoreCase?: boolean;
    Minimum?: number;
    Maximum?: number;
    ExclusiveMinimum?: number;
    ExclusiveMaximum?: number;
    MultipleOf?: number;
    Enum?: ValidationEnum;
}
export declare const Validation: S.Schema<Validation>;
export interface CreateDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    Name: string;
    ValueType: DataTableAttributeValueType;
    Description?: string;
    Primary?: boolean;
    Validation?: Validation;
}
export declare const CreateDataTableAttributeRequest: S.Schema<CreateDataTableAttributeRequest>;
export interface CreateDataTableAttributeResponse {
    Name: string;
    AttributeId?: string;
    LockVersion: DataTableLockVersion;
}
export declare const CreateDataTableAttributeResponse: S.Schema<CreateDataTableAttributeResponse>;
export type EmailAddress = string | redacted.Redacted<string>;
export type EmailAddressDisplayName = string | redacted.Redacted<string>;
export interface CreateEmailAddressRequest {
    Description?: string | redacted.Redacted<string>;
    InstanceId: string;
    EmailAddress: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export declare const CreateEmailAddressRequest: S.Schema<CreateEmailAddressRequest>;
export type EmailAddressArn = string;
export interface CreateEmailAddressResponse {
    EmailAddressId?: string;
    EmailAddressArn?: string;
}
export declare const CreateEmailAddressResponse: S.Schema<CreateEmailAddressResponse>;
export type EvaluationFormTitle = string;
export type EvaluationFormDescription = string;
export type EvaluationFormSectionTitle = string;
export type ReferenceId = string;
export type EvaluationFormQuestionInstructions = string;
export type EvaluationFormItemWeight = number;
export type PerformanceCategoryName = "NEEDS_IMPROVEMENT" | "EXCEEDS_EXPECTATIONS" | (string & {});
export declare const PerformanceCategoryName: any;
export type EvaluationScorePercentage = number;
export interface EvaluationFormScoreThreshold {
    PerformanceCategory: PerformanceCategoryName;
    MinScorePercentage?: number;
    MaxScorePercentage?: number;
}
export declare const EvaluationFormScoreThreshold: S.Schema<EvaluationFormScoreThreshold>;
export type EvaluationFormScoreThresholdList = EvaluationFormScoreThreshold[];
export declare const EvaluationFormScoreThresholdList: any;
export interface EvaluationFormSection {
    Title: string;
    RefId: string;
    Instructions?: string;
    Items: EvaluationFormItem[];
    Weight?: number;
    IsExcludedFromScoring?: boolean;
    ScoreThresholds?: EvaluationFormScoreThreshold[];
}
export declare const EvaluationFormSection: S.Schema<EvaluationFormSection>;
export type EvaluationFormQuestionTitle = string;
export type EvaluationFormQuestionType = "TEXT" | "SINGLESELECT" | "NUMERIC" | "MULTISELECT" | "DATETIME" | (string & {});
export declare const EvaluationFormQuestionType: any;
export type EvaluationFormQuestionAnswerScore = number;
export interface AutomaticFailConfiguration {
    TargetSection?: string;
}
export declare const AutomaticFailConfiguration: S.Schema<AutomaticFailConfiguration>;
export type PointValue = number;
export interface QuestionOptionPointsConfiguration {
    PointValue: number;
    IsBonus?: boolean;
}
export declare const QuestionOptionPointsConfiguration: S.Schema<QuestionOptionPointsConfiguration>;
export interface EvaluationFormNumericQuestionOption {
    MinValue: number;
    MaxValue: number;
    Score?: number;
    AutomaticFail?: boolean;
    AutomaticFailConfiguration?: AutomaticFailConfiguration;
    PointsConfiguration?: QuestionOptionPointsConfiguration;
}
export declare const EvaluationFormNumericQuestionOption: S.Schema<EvaluationFormNumericQuestionOption>;
export type EvaluationFormNumericQuestionOptionList = EvaluationFormNumericQuestionOption[];
export declare const EvaluationFormNumericQuestionOptionList: any;
export type NumericQuestionPropertyAutomationLabel = "OVERALL_CUSTOMER_SENTIMENT_SCORE" | "OVERALL_AGENT_SENTIMENT_SCORE" | "CUSTOMER_SENTIMENT_SCORE_WITHOUT_AGENT" | "CUSTOMER_SENTIMENT_SCORE_WITH_AGENT" | "NON_TALK_TIME" | "NON_TALK_TIME_PERCENTAGE" | "NUMBER_OF_INTERRUPTIONS" | "CONTACT_DURATION" | "AGENT_INTERACTION_DURATION" | "CUSTOMER_HOLD_TIME" | "LONGEST_HOLD_DURATION" | "NUMBER_OF_HOLDS" | "AGENT_INTERACTION_AND_HOLD_DURATION" | (string & {});
export declare const NumericQuestionPropertyAutomationLabel: any;
export interface NumericQuestionPropertyValueAutomation {
    Label: NumericQuestionPropertyAutomationLabel;
}
export declare const NumericQuestionPropertyValueAutomation: S.Schema<NumericQuestionPropertyValueAutomation>;
export type EvaluationFormQuestionAutomationAnswerSourceType = "CONTACT_LENS_DATA" | "GEN_AI" | (string & {});
export declare const EvaluationFormQuestionAutomationAnswerSourceType: any;
export interface EvaluationFormQuestionAutomationAnswerSource {
    SourceType: EvaluationFormQuestionAutomationAnswerSourceType;
}
export declare const EvaluationFormQuestionAutomationAnswerSource: S.Schema<EvaluationFormQuestionAutomationAnswerSource>;
export type EvaluationFormNumericQuestionAutomation = {
    PropertyValue: NumericQuestionPropertyValueAutomation;
    AnswerSource?: never;
} | {
    PropertyValue?: never;
    AnswerSource: EvaluationFormQuestionAutomationAnswerSource;
};
export declare const EvaluationFormNumericQuestionAutomation: any;
export interface EvaluationFormNumericQuestionProperties {
    MinValue: number;
    MaxValue: number;
    Options?: EvaluationFormNumericQuestionOption[];
    Automation?: EvaluationFormNumericQuestionAutomation;
}
export declare const EvaluationFormNumericQuestionProperties: S.Schema<EvaluationFormNumericQuestionProperties>;
export type EvaluationFormSingleSelectQuestionOptionText = string;
export interface EvaluationFormSingleSelectQuestionOption {
    RefId: string;
    Text: string;
    Score?: number;
    AutomaticFail?: boolean;
    AutomaticFailConfiguration?: AutomaticFailConfiguration;
    PointsConfiguration?: QuestionOptionPointsConfiguration;
}
export declare const EvaluationFormSingleSelectQuestionOption: S.Schema<EvaluationFormSingleSelectQuestionOption>;
export type EvaluationFormSingleSelectQuestionOptionList = EvaluationFormSingleSelectQuestionOption[];
export declare const EvaluationFormSingleSelectQuestionOptionList: any;
export type EvaluationFormSingleSelectQuestionDisplayMode = "DROPDOWN" | "RADIO" | (string & {});
export declare const EvaluationFormSingleSelectQuestionDisplayMode: any;
export type SingleSelectQuestionRuleCategoryAutomationLabel = string;
export type SingleSelectQuestionRuleCategoryAutomationCondition = "PRESENT" | "NOT_PRESENT" | (string & {});
export declare const SingleSelectQuestionRuleCategoryAutomationCondition: any;
export interface SingleSelectQuestionRuleCategoryAutomation {
    Category: string;
    Condition: SingleSelectQuestionRuleCategoryAutomationCondition;
    OptionRefId: string;
}
export declare const SingleSelectQuestionRuleCategoryAutomation: S.Schema<SingleSelectQuestionRuleCategoryAutomation>;
export type EvaluationFormSingleSelectQuestionAutomationOption = {
    RuleCategory: SingleSelectQuestionRuleCategoryAutomation;
};
export declare const EvaluationFormSingleSelectQuestionAutomationOption: any;
export type EvaluationFormSingleSelectQuestionAutomationOptionList = EvaluationFormSingleSelectQuestionAutomationOption[];
export declare const EvaluationFormSingleSelectQuestionAutomationOptionList: any;
export interface EvaluationFormSingleSelectQuestionAutomation {
    Options?: EvaluationFormSingleSelectQuestionAutomationOption[];
    DefaultOptionRefId?: string;
    AnswerSource?: EvaluationFormQuestionAutomationAnswerSource;
}
export declare const EvaluationFormSingleSelectQuestionAutomation: S.Schema<EvaluationFormSingleSelectQuestionAutomation>;
export interface EvaluationFormSingleSelectQuestionProperties {
    Options: EvaluationFormSingleSelectQuestionOption[];
    DisplayAs?: EvaluationFormSingleSelectQuestionDisplayMode;
    Automation?: EvaluationFormSingleSelectQuestionAutomation;
}
export declare const EvaluationFormSingleSelectQuestionProperties: S.Schema<EvaluationFormSingleSelectQuestionProperties>;
export interface EvaluationFormTextQuestionAutomation {
    AnswerSource?: EvaluationFormQuestionAutomationAnswerSource;
}
export declare const EvaluationFormTextQuestionAutomation: S.Schema<EvaluationFormTextQuestionAutomation>;
export interface EvaluationFormTextQuestionProperties {
    Automation?: EvaluationFormTextQuestionAutomation;
}
export declare const EvaluationFormTextQuestionProperties: S.Schema<EvaluationFormTextQuestionProperties>;
export type EvaluationFormMultiSelectQuestionOptionText = string;
export interface EvaluationFormMultiSelectQuestionOption {
    RefId: string;
    Text: string;
    Score?: number;
    AutomaticFail?: boolean;
    AutomaticFailConfiguration?: AutomaticFailConfiguration;
    PointsConfiguration?: QuestionOptionPointsConfiguration;
}
export declare const EvaluationFormMultiSelectQuestionOption: S.Schema<EvaluationFormMultiSelectQuestionOption>;
export type EvaluationFormMultiSelectQuestionOptionList = EvaluationFormMultiSelectQuestionOption[];
export declare const EvaluationFormMultiSelectQuestionOptionList: any;
export type EvaluationFormMultiSelectQuestionDisplayMode = "DROPDOWN" | "CHECKBOX" | (string & {});
export declare const EvaluationFormMultiSelectQuestionDisplayMode: any;
export type MultiSelectQuestionRuleCategoryAutomationLabel = string;
export type MultiSelectQuestionRuleCategoryAutomationCondition = "PRESENT" | "NOT_PRESENT" | (string & {});
export declare const MultiSelectQuestionRuleCategoryAutomationCondition: any;
export type ReferenceIdList = string[];
export declare const ReferenceIdList: any;
export interface MultiSelectQuestionRuleCategoryAutomation {
    Category: string;
    Condition: MultiSelectQuestionRuleCategoryAutomationCondition;
    OptionRefIds: string[];
}
export declare const MultiSelectQuestionRuleCategoryAutomation: S.Schema<MultiSelectQuestionRuleCategoryAutomation>;
export type EvaluationFormMultiSelectQuestionAutomationOption = {
    RuleCategory: MultiSelectQuestionRuleCategoryAutomation;
};
export declare const EvaluationFormMultiSelectQuestionAutomationOption: any;
export type EvaluationFormMultiSelectQuestionAutomationOptionList = EvaluationFormMultiSelectQuestionAutomationOption[];
export declare const EvaluationFormMultiSelectQuestionAutomationOptionList: any;
export interface EvaluationFormMultiSelectQuestionAutomation {
    Options?: EvaluationFormMultiSelectQuestionAutomationOption[];
    DefaultOptionRefIds?: string[];
    AnswerSource?: EvaluationFormQuestionAutomationAnswerSource;
}
export declare const EvaluationFormMultiSelectQuestionAutomation: S.Schema<EvaluationFormMultiSelectQuestionAutomation>;
export interface EvaluationFormMultiSelectQuestionProperties {
    Options: EvaluationFormMultiSelectQuestionOption[];
    DisplayAs?: EvaluationFormMultiSelectQuestionDisplayMode;
    Automation?: EvaluationFormMultiSelectQuestionAutomation;
}
export declare const EvaluationFormMultiSelectQuestionProperties: S.Schema<EvaluationFormMultiSelectQuestionProperties>;
export type EvaluationFormQuestionTypeProperties = {
    Numeric: EvaluationFormNumericQuestionProperties;
    SingleSelect?: never;
    Text?: never;
    MultiSelect?: never;
} | {
    Numeric?: never;
    SingleSelect: EvaluationFormSingleSelectQuestionProperties;
    Text?: never;
    MultiSelect?: never;
} | {
    Numeric?: never;
    SingleSelect?: never;
    Text: EvaluationFormTextQuestionProperties;
    MultiSelect?: never;
} | {
    Numeric?: never;
    SingleSelect?: never;
    Text?: never;
    MultiSelect: EvaluationFormMultiSelectQuestionProperties;
};
export declare const EvaluationFormQuestionTypeProperties: any;
export type EvaluationFormItemEnablementSourceType = "QUESTION_REF_ID" | (string & {});
export declare const EvaluationFormItemEnablementSourceType: any;
export interface EvaluationFormItemEnablementSource {
    Type: EvaluationFormItemEnablementSourceType;
    RefId?: string;
}
export declare const EvaluationFormItemEnablementSource: S.Schema<EvaluationFormItemEnablementSource>;
export type EvaluationFormItemEnablementSourceValueType = "OPTION_REF_ID" | (string & {});
export declare const EvaluationFormItemEnablementSourceValueType: any;
export interface EvaluationFormItemEnablementSourceValue {
    Type: EvaluationFormItemEnablementSourceValueType;
    RefId?: string;
}
export declare const EvaluationFormItemEnablementSourceValue: S.Schema<EvaluationFormItemEnablementSourceValue>;
export type EvaluationFormItemEnablementSourceValueList = EvaluationFormItemEnablementSourceValue[];
export declare const EvaluationFormItemEnablementSourceValueList: any;
export type EvaluationFormItemSourceValuesComparator = "IN" | "NOT_IN" | "ALL_IN" | "EXACT" | (string & {});
export declare const EvaluationFormItemSourceValuesComparator: any;
export interface EvaluationFormItemEnablementExpression {
    Source: EvaluationFormItemEnablementSource;
    Values: EvaluationFormItemEnablementSourceValue[];
    Comparator: EvaluationFormItemSourceValuesComparator;
}
export declare const EvaluationFormItemEnablementExpression: S.Schema<EvaluationFormItemEnablementExpression>;
export type EvaluationFormItemEnablementConditionOperand = {
    Expression: EvaluationFormItemEnablementExpression;
    Condition?: never;
} | {
    Expression?: never;
    Condition: EvaluationFormItemEnablementCondition;
};
export declare const EvaluationFormItemEnablementConditionOperand: S.Schema<EvaluationFormItemEnablementConditionOperand>;
export type EvaluationFormItemEnablementConditionOperandList = EvaluationFormItemEnablementConditionOperand[];
export declare const EvaluationFormItemEnablementConditionOperandList: S.Schema<EvaluationFormItemEnablementConditionOperandList>;
export type EvaluationFormItemEnablementOperator = "OR" | "AND" | (string & {});
export declare const EvaluationFormItemEnablementOperator: any;
export interface EvaluationFormItemEnablementCondition {
    Operands: EvaluationFormItemEnablementConditionOperand[];
    Operator?: EvaluationFormItemEnablementOperator;
}
export declare const EvaluationFormItemEnablementCondition: S.Schema<EvaluationFormItemEnablementCondition>;
export type EvaluationFormItemEnablementAction = "DISABLE" | "ENABLE" | (string & {});
export declare const EvaluationFormItemEnablementAction: any;
export interface EvaluationFormItemEnablementConfiguration {
    Condition: EvaluationFormItemEnablementCondition;
    Action: EvaluationFormItemEnablementAction;
    DefaultAction?: EvaluationFormItemEnablementAction;
}
export declare const EvaluationFormItemEnablementConfiguration: S.Schema<EvaluationFormItemEnablementConfiguration>;
export interface QuestionPointsConfiguration {
    MaxPointValue?: number;
    MinPointValue?: number;
    IsBonus?: boolean;
}
export declare const QuestionPointsConfiguration: S.Schema<QuestionPointsConfiguration>;
export interface EvaluationFormQuestionScoringConfiguration {
    PointsConfiguration?: QuestionPointsConfiguration;
    IsExcludedFromScoring?: boolean;
    ScoreThresholds?: EvaluationFormScoreThreshold[];
}
export declare const EvaluationFormQuestionScoringConfiguration: S.Schema<EvaluationFormQuestionScoringConfiguration>;
export interface EvaluationFormQuestion {
    Title: string;
    Instructions?: string;
    RefId: string;
    NotApplicableEnabled?: boolean;
    QuestionType: EvaluationFormQuestionType;
    QuestionTypeProperties?: EvaluationFormQuestionTypeProperties;
    Enablement?: EvaluationFormItemEnablementConfiguration;
    Weight?: number;
    ScoringConfiguration?: EvaluationFormQuestionScoringConfiguration;
}
export declare const EvaluationFormQuestion: S.Schema<EvaluationFormQuestion>;
export type EvaluationFormItem = {
    Section: EvaluationFormSection;
    Question?: never;
} | {
    Section?: never;
    Question: EvaluationFormQuestion;
};
export declare const EvaluationFormItem: S.Schema<EvaluationFormItem>;
export type EvaluationFormItemsList = EvaluationFormItem[];
export declare const EvaluationFormItemsList: S.Schema<EvaluationFormItemsList>;
export type EvaluationFormScoringMode = "QUESTION_ONLY" | "SECTION_ONLY" | "POINTS_BASED" | (string & {});
export declare const EvaluationFormScoringMode: any;
export type EvaluationFormScoringStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const EvaluationFormScoringStatus: any;
export interface EvaluationFormScoringStrategy {
    Mode: EvaluationFormScoringMode;
    Status: EvaluationFormScoringStatus;
    ScoreThresholds?: EvaluationFormScoreThreshold[];
}
export declare const EvaluationFormScoringStrategy: S.Schema<EvaluationFormScoringStrategy>;
export interface EvaluationFormAutoEvaluationConfiguration {
    Enabled: boolean;
}
export declare const EvaluationFormAutoEvaluationConfiguration: S.Schema<EvaluationFormAutoEvaluationConfiguration>;
export type BoxedBoolean = boolean;
export type EvaluationReviewNotificationRecipientType = "USER_ID" | (string & {});
export declare const EvaluationReviewNotificationRecipientType: any;
export interface EvaluationReviewNotificationRecipientValue {
    UserId?: string;
}
export declare const EvaluationReviewNotificationRecipientValue: S.Schema<EvaluationReviewNotificationRecipientValue>;
export interface EvaluationReviewNotificationRecipient {
    Type: EvaluationReviewNotificationRecipientType;
    Value: EvaluationReviewNotificationRecipientValue;
}
export declare const EvaluationReviewNotificationRecipient: S.Schema<EvaluationReviewNotificationRecipient>;
export type EvaluationReviewNotificationRecipientList = EvaluationReviewNotificationRecipient[];
export declare const EvaluationReviewNotificationRecipientList: any;
export interface EvaluationReviewConfiguration {
    ReviewNotificationRecipients: EvaluationReviewNotificationRecipient[];
    EligibilityDays?: number;
}
export declare const EvaluationReviewConfiguration: S.Schema<EvaluationReviewConfiguration>;
export type ContactInteractionType = "AGENT" | "AUTOMATED" | "CUSTOMER" | (string & {});
export declare const ContactInteractionType: any;
export interface EvaluationFormTargetConfiguration {
    ContactInteractionType: ContactInteractionType;
}
export declare const EvaluationFormTargetConfiguration: S.Schema<EvaluationFormTargetConfiguration>;
export type EvaluationFormLanguageCode = "de-DE" | "en-US" | "es-ES" | "fr-FR" | "it-IT" | "pt-BR" | "ja-JP" | "ko-KR" | "zh-CN" | "ms-MY" | (string & {});
export declare const EvaluationFormLanguageCode: any;
export interface EvaluationFormLanguageConfiguration {
    FormLanguage?: EvaluationFormLanguageCode;
}
export declare const EvaluationFormLanguageConfiguration: S.Schema<EvaluationFormLanguageConfiguration>;
export interface CreateEvaluationFormRequest {
    InstanceId: string;
    Title: string;
    Description?: string;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    ClientToken?: string;
    AsDraft?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
    ReviewConfiguration?: EvaluationReviewConfiguration;
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
}
export declare const CreateEvaluationFormRequest: S.Schema<CreateEvaluationFormRequest>;
export interface CreateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
}
export declare const CreateEvaluationFormResponse: S.Schema<CreateEvaluationFormResponse>;
export type ExtractionDefinitionName = string;
export type ExtractionDefinitionPromptHint = string;
export type NotFoundBehaviorType = "USE_DEFAULT_VALUE" | "OMIT" | (string & {});
export declare const NotFoundBehaviorType: any;
export type NotFoundDefaultValue = string;
export interface ExtractionDefinitionNotFoundBehavior {
    Behavior: NotFoundBehaviorType;
    DefaultValue?: string;
}
export declare const ExtractionDefinitionNotFoundBehavior: S.Schema<ExtractionDefinitionNotFoundBehavior>;
export interface ExtractionConfiguration {
    PromptHint: string;
    NotFoundBehavior?: ExtractionDefinitionNotFoundBehavior;
}
export declare const ExtractionConfiguration: S.Schema<ExtractionConfiguration>;
export type ExtractionDefinitionDisplayLabel = string;
export interface ExtractionDefinitionDisplay {
    Label?: string;
}
export declare const ExtractionDefinitionDisplay: S.Schema<ExtractionDefinitionDisplay>;
export interface CreateExtractionDefinitionRequest {
    ClientToken?: string;
    InstanceId: string;
    Name: string;
    ExtractionConfiguration: ExtractionConfiguration;
    Display?: ExtractionDefinitionDisplay;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateExtractionDefinitionRequest: S.Schema<CreateExtractionDefinitionRequest>;
export type ExtractionDefinitionId = string;
export interface CreateExtractionDefinitionResponse {
    ExtractionDefinitionArn: string;
    ExtractionDefinitionId: string;
}
export declare const CreateExtractionDefinitionResponse: S.Schema<CreateExtractionDefinitionResponse>;
export type CommonNameLength127 = string;
export type HoursOfOperationDescription = string;
export type HoursOfOperationDays = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export declare const HoursOfOperationDays: any;
export type Hours24Format = number;
export type MinutesLimit60 = number;
export interface HoursOfOperationTimeSlice {
    Hours: number;
    Minutes: number;
}
export declare const HoursOfOperationTimeSlice: S.Schema<HoursOfOperationTimeSlice>;
export interface HoursOfOperationConfig {
    Day: HoursOfOperationDays;
    StartTime: HoursOfOperationTimeSlice;
    EndTime: HoursOfOperationTimeSlice;
}
export declare const HoursOfOperationConfig: S.Schema<HoursOfOperationConfig>;
export type HoursOfOperationConfigList = HoursOfOperationConfig[];
export declare const HoursOfOperationConfigList: any;
export interface CreateHoursOfOperationRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    TimeZone: string;
    Config: HoursOfOperationConfig[];
    ParentHoursOfOperationConfigs?: ParentHoursOfOperationConfig[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateHoursOfOperationRequest: S.Schema<CreateHoursOfOperationRequest>;
export interface CreateHoursOfOperationResponse {
    HoursOfOperationId?: string;
    HoursOfOperationArn?: string;
}
export declare const CreateHoursOfOperationResponse: S.Schema<CreateHoursOfOperationResponse>;
export type CommonHumanReadableName = string;
export type CommonHumanReadableDescription = string;
export type OverrideDays = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export declare const OverrideDays: any;
export interface OverrideTimeSlice {
    Hours: number;
    Minutes: number;
}
export declare const OverrideTimeSlice: S.Schema<OverrideTimeSlice>;
export interface HoursOfOperationOverrideConfig {
    Day?: OverrideDays;
    StartTime?: OverrideTimeSlice;
    EndTime?: OverrideTimeSlice;
}
export declare const HoursOfOperationOverrideConfig: S.Schema<HoursOfOperationOverrideConfig>;
export type HoursOfOperationOverrideConfigList = HoursOfOperationOverrideConfig[];
export declare const HoursOfOperationOverrideConfigList: any;
export type HoursOfOperationOverrideYearMonthDayDateFormat = string;
export type RecurrenceFrequency = "WEEKLY" | "MONTHLY" | "YEARLY" | (string & {});
export declare const RecurrenceFrequency: any;
export type IntervalPositiveInteger = number;
export type Month = number;
export type MonthList = number[];
export declare const MonthList: any;
export type MonthDay = number;
export type MonthDayList = number[];
export declare const MonthDayList: any;
export type WeekdayOccurrenceInteger = number;
export type WeekdayOccurrenceList = number[];
export declare const WeekdayOccurrenceList: any;
export interface RecurrencePattern {
    Frequency: RecurrenceFrequency;
    Interval: number;
    ByMonth?: number[];
    ByMonthDay?: number[];
    ByWeekdayOccurrence?: number[];
}
export declare const RecurrencePattern: S.Schema<RecurrencePattern>;
export interface RecurrenceConfig {
    RecurrencePattern: RecurrencePattern;
}
export declare const RecurrenceConfig: S.Schema<RecurrenceConfig>;
export type OverrideType = "STANDARD" | "OPEN" | "CLOSED" | (string & {});
export declare const OverrideType: any;
export interface CreateHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    Name: string;
    Description?: string;
    Config: HoursOfOperationOverrideConfig[];
    EffectiveFrom: string;
    EffectiveTill: string;
    RecurrenceConfig?: RecurrenceConfig;
    OverrideType?: OverrideType;
}
export declare const CreateHoursOfOperationOverrideRequest: S.Schema<CreateHoursOfOperationOverrideRequest>;
export type HoursOfOperationOverrideId = string;
export interface CreateHoursOfOperationOverrideResponse {
    HoursOfOperationOverrideId?: string;
}
export declare const CreateHoursOfOperationOverrideResponse: S.Schema<CreateHoursOfOperationOverrideResponse>;
export type DirectoryType = "SAML" | "CONNECT_MANAGED" | "EXISTING_DIRECTORY" | (string & {});
export declare const DirectoryType: any;
export type DirectoryAlias = string | redacted.Redacted<string>;
export type DirectoryId = string;
export type InboundCallsEnabled = boolean;
export type OutboundCallsEnabled = boolean;
export interface CreateInstanceRequest {
    ClientToken?: string;
    IdentityManagementType: DirectoryType;
    InstanceAlias?: string | redacted.Redacted<string>;
    DirectoryId?: string;
    InboundCallsEnabled: boolean;
    OutboundCallsEnabled: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateInstanceRequest: S.Schema<CreateInstanceRequest>;
export interface CreateInstanceResponse {
    Id?: string;
    Arn?: string;
}
export declare const CreateInstanceResponse: S.Schema<CreateInstanceResponse>;
export type IntegrationType = "EVENT" | "VOICE_ID" | "PINPOINT_APP" | "WISDOM_ASSISTANT" | "WISDOM_KNOWLEDGE_BASE" | "WISDOM_QUICK_RESPONSES" | "Q_MESSAGE_TEMPLATES" | "CASES_DOMAIN" | "APPLICATION" | "FILE_SCANNER" | "SES_IDENTITY" | "ANALYTICS_CONNECTOR" | "CALL_TRANSFER_CONNECTOR" | "COGNITO_USER_POOL" | "MESSAGE_PROCESSOR" | (string & {});
export declare const IntegrationType: any;
export type URI = string;
export type SourceApplicationName = string;
export type SourceType = "SALESFORCE" | "ZENDESK" | "CASES" | (string & {});
export declare const SourceType: any;
export interface CreateIntegrationAssociationRequest {
    InstanceId: string;
    IntegrationType: IntegrationType;
    IntegrationArn: string;
    SourceApplicationUrl?: string;
    SourceApplicationName?: string;
    SourceType?: SourceType;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateIntegrationAssociationRequest: S.Schema<CreateIntegrationAssociationRequest>;
export type IntegrationAssociationId = string;
export interface CreateIntegrationAssociationResponse {
    IntegrationAssociationId?: string;
    IntegrationAssociationArn?: string;
}
export declare const CreateIntegrationAssociationResponse: S.Schema<CreateIntegrationAssociationResponse>;
export type MetricName = string;
export type ComponentAlias = string;
export type MetricId = string;
export type MetricFilterKey = string;
export type MetricFilterNumberConditionComparison = "LESSER" | "LESSER_OR_EQUAL" | "GREATER" | "GREATER_OR_EQUAL" | (string & {});
export declare const MetricFilterNumberConditionComparison: any;
export type NumberValueList = number[];
export declare const NumberValueList: any;
export interface MetricFilterNumberCondition {
    Comparison: MetricFilterNumberConditionComparison;
    Values: number[];
}
export declare const MetricFilterNumberCondition: S.Schema<MetricFilterNumberCondition>;
export type MetricFilterStringConditionComparison = "MATCHES_ANY" | "MATCHES_NONE" | (string & {});
export declare const MetricFilterStringConditionComparison: any;
export type StringValueList = string[];
export declare const StringValueList: any;
export interface MetricFilterStringCondition {
    Comparison: MetricFilterStringConditionComparison;
    Values: string[];
}
export declare const MetricFilterStringCondition: S.Schema<MetricFilterStringCondition>;
export type MetricFilterBooleanConditionComparison = "IS_TRUE" | "IS_FALSE" | (string & {});
export declare const MetricFilterBooleanConditionComparison: any;
export interface MetricFilterBooleanCondition {
    Comparison: MetricFilterBooleanConditionComparison;
}
export declare const MetricFilterBooleanCondition: S.Schema<MetricFilterBooleanCondition>;
export interface MetricFilter {
    MetricFilterKey: string;
    Negate?: boolean;
    NumberCondition?: MetricFilterNumberCondition;
    StringCondition?: MetricFilterStringCondition;
    BooleanCondition?: MetricFilterBooleanCondition;
}
export declare const MetricFilter: S.Schema<MetricFilter>;
export type MetricFilterList = MetricFilter[];
export declare const MetricFilterList: any;
export interface CalculationComponent {
    Alias: string;
    MetricName?: string;
    MetricId?: string;
    MetricFilters?: MetricFilter[];
}
export declare const CalculationComponent: S.Schema<CalculationComponent>;
export type CalculationComponentList = CalculationComponent[];
export declare const CalculationComponentList: any;
export type CalculationExpression = string;
export interface MetricCalculation {
    CalculationComponents: CalculationComponent[];
    Calculation: string;
}
export declare const MetricCalculation: S.Schema<MetricCalculation>;
export type MetricUnit = "INTEGER" | "DOUBLE" | "PERCENT" | "SECONDS" | (string & {});
export declare const MetricUnit: any;
export type MetricStatus = "PUBLISHED" | "SAVED" | (string & {});
export declare const MetricStatus: any;
export type MetricDescription = string;
export type TrendIndicator = "POSITIVE" | "NEGATIVE" | "NEUTRAL" | (string & {});
export declare const TrendIndicator: any;
export interface CreateMetricRequest {
    InstanceId: string;
    Name: string;
    MetricCalculation: MetricCalculation;
    Unit: MetricUnit;
    Status?: MetricStatus;
    ClientToken?: string;
    Description?: string;
    PositiveTrendIndicator?: TrendIndicator;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateMetricRequest: S.Schema<CreateMetricRequest>;
export interface CreateMetricResponse {
    MetricArn: string;
    MetricId: string;
}
export declare const CreateMetricResponse: S.Schema<CreateMetricResponse>;
export type RecipientList = string[];
export declare const RecipientList: any;
export type ConfigurableNotificationPriority = "HIGH" | "LOW" | (string & {});
export declare const ConfigurableNotificationPriority: any;
export type LocaleCode = "en_US" | "de_DE" | "es_ES" | "fr_FR" | "id_ID" | "it_IT" | "ja_JP" | "ko_KR" | "pt_BR" | "zh_CN" | "zh_TW" | (string & {});
export declare const LocaleCode: any;
export type LocalizedString = string;
export type NotificationContent = {
    [key in LocaleCode]?: string;
};
export declare const NotificationContent: any;
export type NotificationId = string;
export interface CreateNotificationRequest {
    InstanceId: string;
    ExpiresAt?: Date;
    Recipients: string[];
    Priority?: ConfigurableNotificationPriority;
    Content: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    PredefinedNotificationId?: string;
    ClientToken?: string;
}
export declare const CreateNotificationRequest: S.Schema<CreateNotificationRequest>;
export interface CreateNotificationResponse {
    NotificationId: string;
    NotificationArn: string;
}
export declare const CreateNotificationResponse: S.Schema<CreateNotificationResponse>;
export type ParticipantRole = "AGENT" | "CUSTOMER" | "SYSTEM" | "CUSTOM_BOT" | "SUPERVISOR" | (string & {});
export declare const ParticipantRole: any;
export type DisplayName = string;
export type VideoCapability = "SEND" | (string & {});
export declare const VideoCapability: any;
export type ScreenShareCapability = "SEND" | (string & {});
export declare const ScreenShareCapability: any;
export interface ParticipantCapabilities {
    Video?: VideoCapability;
    ScreenShare?: ScreenShareCapability;
}
export declare const ParticipantCapabilities: S.Schema<ParticipantCapabilities>;
export interface ParticipantDetailsToAdd {
    ParticipantRole?: ParticipantRole;
    DisplayName?: string;
    ParticipantCapabilities?: ParticipantCapabilities;
}
export declare const ParticipantDetailsToAdd: S.Schema<ParticipantDetailsToAdd>;
export interface CreateParticipantRequest {
    InstanceId: string;
    ContactId: string;
    ClientToken?: string;
    ParticipantDetails: ParticipantDetailsToAdd;
}
export declare const CreateParticipantRequest: S.Schema<CreateParticipantRequest>;
export type ParticipantToken = string;
export interface ParticipantTokenCredentials {
    ParticipantToken?: string;
    Expiry?: string;
}
export declare const ParticipantTokenCredentials: S.Schema<ParticipantTokenCredentials>;
export type ParticipantId = string;
export interface CreateParticipantResponse {
    ParticipantCredentials?: ParticipantTokenCredentials;
    ParticipantId?: string;
}
export declare const CreateParticipantResponse: S.Schema<CreateParticipantResponse>;
export type RehydrationType = "ENTIRE_PAST_SESSION" | "FROM_SEGMENT" | (string & {});
export declare const RehydrationType: any;
export interface CreatePersistentContactAssociationRequest {
    InstanceId: string;
    InitialContactId: string;
    RehydrationType: RehydrationType;
    SourceContactId: string;
    ClientToken?: string;
}
export declare const CreatePersistentContactAssociationRequest: S.Schema<CreatePersistentContactAssociationRequest>;
export interface CreatePersistentContactAssociationResponse {
    ContinuedFromContactId?: string;
}
export declare const CreatePersistentContactAssociationResponse: S.Schema<CreatePersistentContactAssociationResponse>;
export type PredefinedAttributeStringValuesList = string[];
export declare const PredefinedAttributeStringValuesList: any;
export type PredefinedAttributeValues = {
    StringList: string[];
};
export declare const PredefinedAttributeValues: any;
export type PredefinedAttributePurposeName = string;
export type PredefinedAttributePurposeNameList = string[];
export declare const PredefinedAttributePurposeNameList: any;
export type EnableValueValidationOnAssociation = boolean;
export interface InputPredefinedAttributeConfiguration {
    EnableValueValidationOnAssociation?: boolean;
}
export declare const InputPredefinedAttributeConfiguration: S.Schema<InputPredefinedAttributeConfiguration>;
export interface CreatePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
    Values?: PredefinedAttributeValues;
    Purposes?: string[];
    AttributeConfiguration?: InputPredefinedAttributeConfiguration;
}
export declare const CreatePredefinedAttributeRequest: S.Schema<CreatePredefinedAttributeRequest>;
export interface CreatePredefinedAttributeResponse {
}
export declare const CreatePredefinedAttributeResponse: S.Schema<CreatePredefinedAttributeResponse>;
export type PromptDescription = string;
export type S3Uri = string;
export interface CreatePromptRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    S3Uri: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePromptRequest: S.Schema<CreatePromptRequest>;
export type PromptId = string;
export interface CreatePromptResponse {
    PromptARN?: string;
    PromptId?: string;
}
export declare const CreatePromptResponse: S.Schema<CreatePromptResponse>;
export type DeviceToken = string;
export type DeviceType = "GCM" | "APNS" | "APNS_SANDBOX" | (string & {});
export declare const DeviceType: any;
export type IncludeRawMessage = boolean;
export interface ContactConfiguration {
    ContactId: string;
    ParticipantRole?: ParticipantRole;
    IncludeRawMessage?: boolean;
}
export declare const ContactConfiguration: S.Schema<ContactConfiguration>;
export interface CreatePushNotificationRegistrationRequest {
    InstanceId: string;
    ClientToken?: string;
    PinpointAppArn: string;
    DeviceToken: string;
    DeviceType: DeviceType;
    ContactConfiguration: ContactConfiguration;
}
export declare const CreatePushNotificationRegistrationRequest: S.Schema<CreatePushNotificationRegistrationRequest>;
export type RegistrationId = string;
export interface CreatePushNotificationRegistrationResponse {
    RegistrationId: string;
}
export declare const CreatePushNotificationRegistrationResponse: S.Schema<CreatePushNotificationRegistrationResponse>;
export type QueueDescription = string;
export type OutboundCallerIdName = string;
export interface OutboundCallerConfig {
    OutboundCallerIdName?: string;
    OutboundCallerIdNumberId?: string;
    OutboundFlowId?: string;
}
export declare const OutboundCallerConfig: S.Schema<OutboundCallerConfig>;
export interface OutboundEmailConfig {
    OutboundEmailAddressId?: string;
}
export declare const OutboundEmailConfig: S.Schema<OutboundEmailConfig>;
export type QueueMaxContacts = number;
export interface CreateQueueRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    OutboundCallerConfig?: OutboundCallerConfig;
    OutboundEmailConfig?: OutboundEmailConfig;
    HoursOfOperationId: string;
    MaxContacts?: number;
    QuickConnectIds?: string[];
    EmailAddressesConfig?: EmailAddressConfig[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateQueueRequest: S.Schema<CreateQueueRequest>;
export interface CreateQueueResponse {
    QueueArn?: string;
    QueueId?: string;
}
export declare const CreateQueueResponse: S.Schema<CreateQueueResponse>;
export type QuickConnectName = string;
export type QuickConnectDescription = string;
export type QuickConnectType = "USER" | "QUEUE" | "PHONE_NUMBER" | "FLOW" | (string & {});
export declare const QuickConnectType: any;
export interface UserQuickConnectConfig {
    UserId: string;
    ContactFlowId: string;
}
export declare const UserQuickConnectConfig: S.Schema<UserQuickConnectConfig>;
export interface QueueQuickConnectConfig {
    QueueId: string;
    ContactFlowId: string;
}
export declare const QueueQuickConnectConfig: S.Schema<QueueQuickConnectConfig>;
export interface PhoneNumberQuickConnectConfig {
    PhoneNumber: string;
}
export declare const PhoneNumberQuickConnectConfig: S.Schema<PhoneNumberQuickConnectConfig>;
export interface FlowQuickConnectConfig {
    ContactFlowId: string;
}
export declare const FlowQuickConnectConfig: S.Schema<FlowQuickConnectConfig>;
export interface QuickConnectConfig {
    QuickConnectType: QuickConnectType;
    UserConfig?: UserQuickConnectConfig;
    QueueConfig?: QueueQuickConnectConfig;
    PhoneConfig?: PhoneNumberQuickConnectConfig;
    FlowConfig?: FlowQuickConnectConfig;
}
export declare const QuickConnectConfig: S.Schema<QuickConnectConfig>;
export interface CreateQuickConnectRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    QuickConnectConfig: QuickConnectConfig;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateQuickConnectRequest: S.Schema<CreateQuickConnectRequest>;
export interface CreateQuickConnectResponse {
    QuickConnectARN?: string;
    QuickConnectId?: string;
}
export declare const CreateQuickConnectResponse: S.Schema<CreateQuickConnectResponse>;
export type RoutingProfileName = string;
export type RoutingProfileDescription = string;
export type Concurrency = number;
export type BehaviorType = "ROUTE_CURRENT_CHANNEL_ONLY" | "ROUTE_ANY_CHANNEL" | (string & {});
export declare const BehaviorType: any;
export interface CrossChannelBehavior {
    BehaviorType: BehaviorType;
}
export declare const CrossChannelBehavior: S.Schema<CrossChannelBehavior>;
export interface MediaConcurrency {
    Channel: Channel;
    Concurrency: number;
    CrossChannelBehavior?: CrossChannelBehavior;
}
export declare const MediaConcurrency: S.Schema<MediaConcurrency>;
export type MediaConcurrencies = MediaConcurrency[];
export declare const MediaConcurrencies: any;
export type AgentAvailabilityTimer = "TIME_SINCE_LAST_ACTIVITY" | "TIME_SINCE_LAST_INBOUND" | (string & {});
export declare const AgentAvailabilityTimer: any;
export interface CreateRoutingProfileRequest {
    InstanceId: string;
    Name: string;
    Description: string;
    DefaultOutboundQueueId: string;
    QueueConfigs?: RoutingProfileQueueConfig[];
    ManualAssignmentQueueConfigs?: RoutingProfileManualAssignmentQueueConfig[];
    MediaConcurrencies: MediaConcurrency[];
    Tags?: {
        [key: string]: string | undefined;
    };
    AgentAvailabilityTimer?: AgentAvailabilityTimer;
}
export declare const CreateRoutingProfileRequest: S.Schema<CreateRoutingProfileRequest>;
export interface CreateRoutingProfileResponse {
    RoutingProfileArn?: string;
    RoutingProfileId?: string;
}
export declare const CreateRoutingProfileResponse: S.Schema<CreateRoutingProfileResponse>;
export type RuleName = string;
export type EventSourceName = "OnPostCallAnalysisAvailable" | "OnRealTimeCallAnalysisAvailable" | "OnRealTimeChatAnalysisAvailable" | "OnPostChatAnalysisAvailable" | "OnAfterCallWorkAvailable" | "OnAfterChatWorkAvailable" | "OnEmailAnalysisAvailable" | "OnZendeskTicketCreate" | "OnZendeskTicketStatusUpdate" | "OnSalesforceCaseCreate" | "OnContactEvaluationSubmit" | "OnMetricDataUpdate" | "OnCaseCreate" | "OnCaseUpdate" | "OnSlaBreach" | "OnAlertUpdate" | "OnSchedulePublish" | "OnScheduleUpdate" | "OnScheduleTimeOffRequestActivity" | (string & {});
export declare const EventSourceName: any;
export interface RuleTriggerEventSource {
    EventSourceName: EventSourceName;
    IntegrationAssociationId?: string;
}
export declare const RuleTriggerEventSource: S.Schema<RuleTriggerEventSource>;
export type RuleFunction = string;
export type ActionType = "CREATE_TASK" | "ASSIGN_CONTACT_CATEGORY" | "GENERATE_EVENTBRIDGE_EVENT" | "SEND_NOTIFICATION" | "CREATE_CASE" | "UPDATE_CASE" | "ASSIGN_SLA" | "END_ASSOCIATED_TASKS" | "SUBMIT_AUTO_EVALUATION" | "EXTRACT_INFORMATION" | (string & {});
export declare const ActionType: any;
export type TaskNameExpression = string;
export type TaskDescriptionExpression = string;
export interface TaskActionDefinition {
    Name: string;
    Description?: string;
    ContactFlowId: string;
    References?: {
        [key: string]: Reference | undefined;
    };
}
export declare const TaskActionDefinition: S.Schema<TaskActionDefinition>;
export type EventBridgeActionName = string;
export interface EventBridgeActionDefinition {
    Name: string;
}
export declare const EventBridgeActionDefinition: S.Schema<EventBridgeActionDefinition>;
export interface AssignContactCategoryActionDefinition {
}
export declare const AssignContactCategoryActionDefinition: S.Schema<AssignContactCategoryActionDefinition>;
export type NotificationDeliveryType = "EMAIL" | (string & {});
export declare const NotificationDeliveryType: any;
export type Subject = string;
export type Content = string;
export type NotificationContentType = "PLAIN_TEXT" | (string & {});
export declare const NotificationContentType: any;
export type UserTagMap = {
    [key: string]: string | undefined;
};
export declare const UserTagMap: any;
export type UserIdList = string[];
export declare const UserIdList: any;
export interface NotificationRecipientType {
    UserTags?: {
        [key: string]: string | undefined;
    };
    UserIds?: string[];
}
export declare const NotificationRecipientType: S.Schema<NotificationRecipientType>;
export interface SendNotificationActionDefinition {
    DeliveryMethod: NotificationDeliveryType;
    Subject?: string;
    Content: string;
    ContentType: NotificationContentType;
    Recipient: NotificationRecipientType;
    Exclusion?: NotificationRecipientType;
}
export declare const SendNotificationActionDefinition: S.Schema<SendNotificationActionDefinition>;
export type FieldValueId = string;
export interface EmptyFieldValue {
}
export declare const EmptyFieldValue: S.Schema<EmptyFieldValue>;
export type FieldStringValue = string;
export interface FieldValueUnion {
    BooleanValue?: boolean;
    DoubleValue?: number;
    EmptyValue?: EmptyFieldValue;
    StringValue?: string;
}
export declare const FieldValueUnion: S.Schema<FieldValueUnion>;
export interface FieldValue {
    Id: string;
    Value: FieldValueUnion;
}
export declare const FieldValue: S.Schema<FieldValue>;
export type FieldValues = FieldValue[];
export declare const FieldValues: any;
export type TemplateId = string;
export interface CreateCaseActionDefinition {
    Fields: FieldValue[];
    TemplateId: string;
}
export declare const CreateCaseActionDefinition: S.Schema<CreateCaseActionDefinition>;
export interface UpdateCaseActionDefinition {
    Fields: FieldValue[];
}
export declare const UpdateCaseActionDefinition: S.Schema<UpdateCaseActionDefinition>;
export type SlaAssignmentType = "CASES" | (string & {});
export declare const SlaAssignmentType: any;
export type SlaName = string;
export type SlaType = "CaseField" | (string & {});
export declare const SlaType: any;
export type SlaFieldValueUnionList = FieldValueUnion[];
export declare const SlaFieldValueUnionList: any;
export type TargetSlaMinutes = number;
export interface CaseSlaConfiguration {
    Name: string;
    Type: SlaType;
    FieldId?: string;
    TargetFieldValues?: FieldValueUnion[];
    TargetSlaMinutes: number;
}
export declare const CaseSlaConfiguration: S.Schema<CaseSlaConfiguration>;
export interface AssignSlaActionDefinition {
    SlaAssignmentType: SlaAssignmentType;
    CaseSlaConfiguration?: CaseSlaConfiguration;
}
export declare const AssignSlaActionDefinition: S.Schema<AssignSlaActionDefinition>;
export interface EndAssociatedTasksActionDefinition {
}
export declare const EndAssociatedTasksActionDefinition: S.Schema<EndAssociatedTasksActionDefinition>;
export type EvaluationFormId = string;
export interface SubmitAutoEvaluationActionDefinition {
    EvaluationFormId: string;
}
export declare const SubmitAutoEvaluationActionDefinition: S.Schema<SubmitAutoEvaluationActionDefinition>;
export type RulesExtractionDefinitionId = string;
export interface RulesExtractionDefinitionIdentifier {
    Identifier: string;
}
export declare const RulesExtractionDefinitionIdentifier: S.Schema<RulesExtractionDefinitionIdentifier>;
export type RulesExtractionDefinitionIdentifierList = RulesExtractionDefinitionIdentifier[];
export declare const RulesExtractionDefinitionIdentifierList: any;
export interface ExtractInformationActionDefinition {
    RulesExtractionDefinitions: RulesExtractionDefinitionIdentifier[];
}
export declare const ExtractInformationActionDefinition: S.Schema<ExtractInformationActionDefinition>;
export interface RuleAction {
    ActionType: ActionType;
    TaskAction?: TaskActionDefinition;
    EventBridgeAction?: EventBridgeActionDefinition;
    AssignContactCategoryAction?: AssignContactCategoryActionDefinition;
    SendNotificationAction?: SendNotificationActionDefinition;
    CreateCaseAction?: CreateCaseActionDefinition;
    UpdateCaseAction?: UpdateCaseActionDefinition;
    AssignSlaAction?: AssignSlaActionDefinition;
    EndAssociatedTasksAction?: EndAssociatedTasksActionDefinition;
    SubmitAutoEvaluationAction?: SubmitAutoEvaluationActionDefinition;
    ExtractInformationAction?: ExtractInformationActionDefinition;
}
export declare const RuleAction: S.Schema<RuleAction>;
export type RuleActions = RuleAction[];
export declare const RuleActions: any;
export type RulePublishStatus = "DRAFT" | "PUBLISHED" | (string & {});
export declare const RulePublishStatus: any;
export interface CreateRuleRequest {
    InstanceId: string;
    Name: string;
    TriggerEventSource: RuleTriggerEventSource;
    Function: string;
    Actions: RuleAction[];
    PublishStatus: RulePublishStatus;
    ClientToken?: string;
}
export declare const CreateRuleRequest: S.Schema<CreateRuleRequest>;
export type RuleId = string;
export interface CreateRuleResponse {
    RuleArn: string;
    RuleId: string;
}
export declare const CreateRuleResponse: S.Schema<CreateRuleResponse>;
export type CreateSecurityProfileName = string;
export type SecurityProfileDescription = string;
export type SecurityProfilePermission = string;
export type PermissionsList = string[];
export declare const PermissionsList: any;
export type SecurityProfilePolicyKey = string;
export type SecurityProfilePolicyValue = string;
export type AllowedAccessControlTags = {
    [key: string]: string | undefined;
};
export declare const AllowedAccessControlTags: any;
export type TagRestrictedResourceName = string;
export type TagRestrictedResourceList = string[];
export declare const TagRestrictedResourceList: any;
export type Namespace = string;
export type Permission = string;
export type ApplicationPermissions = string[];
export declare const ApplicationPermissions: any;
export type ApplicationType = "MCP" | "THIRD_PARTY_APPLICATION" | (string & {});
export declare const ApplicationType: any;
export interface Application {
    Namespace?: string;
    ApplicationPermissions?: string[];
    Type?: ApplicationType;
}
export declare const Application: S.Schema<Application>;
export type Applications = Application[];
export declare const Applications: any;
export type HierarchyRestrictedResourceName = string;
export type HierarchyRestrictedResourceList = string[];
export declare const HierarchyRestrictedResourceList: any;
export type HierarchyGroupId = string;
export type FlowModuleType = "MCP" | (string & {});
export declare const FlowModuleType: any;
export type FlowModuleId = string;
export interface FlowModule {
    Type?: FlowModuleType;
    FlowModuleId?: string;
}
export declare const FlowModule: S.Schema<FlowModule>;
export type AllowedFlowModules = FlowModule[];
export declare const AllowedFlowModules: any;
export type AccessType = "ALLOW" | (string & {});
export declare const AccessType: any;
export type PrimaryAttributeContextKeyName = string;
export type IAMRestrictedPrimaryValue = string;
export type PrimaryValueList = string[];
export declare const PrimaryValueList: any;
export interface PrimaryAttributeValue {
    AccessType?: AccessType;
    AttributeName?: string;
    Values?: string[];
}
export declare const PrimaryAttributeValue: S.Schema<PrimaryAttributeValue>;
export type PrimaryAttributeValuesSet = PrimaryAttributeValue[];
export declare const PrimaryAttributeValuesSet: any;
export interface PrimaryAttributeAccessControlConfigurationItem {
    PrimaryAttributeValues?: PrimaryAttributeValue[];
}
export declare const PrimaryAttributeAccessControlConfigurationItem: S.Schema<PrimaryAttributeAccessControlConfigurationItem>;
export interface DataTableAccessControlConfiguration {
    PrimaryAttributeAccessControlConfiguration?: PrimaryAttributeAccessControlConfigurationItem;
}
export declare const DataTableAccessControlConfiguration: S.Schema<DataTableAccessControlConfiguration>;
export interface GranularAccessControlConfiguration {
    DataTableAccessControlConfiguration?: DataTableAccessControlConfiguration;
}
export declare const GranularAccessControlConfiguration: S.Schema<GranularAccessControlConfiguration>;
export interface CreateSecurityProfileRequest {
    SecurityProfileName: string;
    Description?: string;
    Permissions?: string[];
    InstanceId: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    AllowedAccessControlTags?: {
        [key: string]: string | undefined;
    };
    TagRestrictedResources?: string[];
    Applications?: Application[];
    HierarchyRestrictedResources?: string[];
    AllowedAccessControlHierarchyGroupId?: string;
    AllowedFlowModules?: FlowModule[];
    GranularAccessControlConfiguration?: GranularAccessControlConfiguration;
}
export declare const CreateSecurityProfileRequest: S.Schema<CreateSecurityProfileRequest>;
export interface CreateSecurityProfileResponse {
    SecurityProfileId?: string;
    SecurityProfileArn?: string;
}
export declare const CreateSecurityProfileResponse: S.Schema<CreateSecurityProfileResponse>;
export type TaskTemplateName = string;
export type TaskTemplateDescription = string;
export type TaskTemplateFieldName = string;
export interface TaskTemplateFieldIdentifier {
    Name?: string;
}
export declare const TaskTemplateFieldIdentifier: S.Schema<TaskTemplateFieldIdentifier>;
export interface RequiredFieldInfo {
    Id?: TaskTemplateFieldIdentifier;
}
export declare const RequiredFieldInfo: S.Schema<RequiredFieldInfo>;
export type RequiredTaskTemplateFields = RequiredFieldInfo[];
export declare const RequiredTaskTemplateFields: any;
export interface ReadOnlyFieldInfo {
    Id?: TaskTemplateFieldIdentifier;
}
export declare const ReadOnlyFieldInfo: S.Schema<ReadOnlyFieldInfo>;
export type ReadOnlyTaskTemplateFields = ReadOnlyFieldInfo[];
export declare const ReadOnlyTaskTemplateFields: any;
export interface InvisibleFieldInfo {
    Id?: TaskTemplateFieldIdentifier;
}
export declare const InvisibleFieldInfo: S.Schema<InvisibleFieldInfo>;
export type InvisibleTaskTemplateFields = InvisibleFieldInfo[];
export declare const InvisibleTaskTemplateFields: any;
export interface TaskTemplateConstraints {
    RequiredFields?: RequiredFieldInfo[];
    ReadOnlyFields?: ReadOnlyFieldInfo[];
    InvisibleFields?: InvisibleFieldInfo[];
}
export declare const TaskTemplateConstraints: S.Schema<TaskTemplateConstraints>;
export type TaskTemplateFieldValue = string;
export interface TaskTemplateDefaultFieldValue {
    Id?: TaskTemplateFieldIdentifier;
    DefaultValue?: string;
}
export declare const TaskTemplateDefaultFieldValue: S.Schema<TaskTemplateDefaultFieldValue>;
export type TaskTemplateDefaultFieldValueList = TaskTemplateDefaultFieldValue[];
export declare const TaskTemplateDefaultFieldValueList: any;
export interface TaskTemplateDefaults {
    DefaultFieldValues?: TaskTemplateDefaultFieldValue[];
}
export declare const TaskTemplateDefaults: S.Schema<TaskTemplateDefaults>;
export type TaskTemplateStatus = "ACTIVE" | "INACTIVE" | (string & {});
export declare const TaskTemplateStatus: any;
export type TaskTemplateFieldDescription = string;
export type TaskTemplateFieldType = "NAME" | "DESCRIPTION" | "SCHEDULED_TIME" | "QUICK_CONNECT" | "URL" | "NUMBER" | "TEXT" | "TEXT_AREA" | "DATE_TIME" | "BOOLEAN" | "SINGLE_SELECT" | "EMAIL" | "SELF_ASSIGN" | "EXPIRY_DURATION" | (string & {});
export declare const TaskTemplateFieldType: any;
export type TaskTemplateSingleSelectOption = string;
export type SingleSelectOptions = string[];
export declare const SingleSelectOptions: any;
export interface TaskTemplateField {
    Id: TaskTemplateFieldIdentifier;
    Description?: string;
    Type?: TaskTemplateFieldType;
    SingleSelectOptions?: string[];
}
export declare const TaskTemplateField: S.Schema<TaskTemplateField>;
export type TaskTemplateFields = TaskTemplateField[];
export declare const TaskTemplateFields: any;
export interface CreateTaskTemplateRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Status?: TaskTemplateStatus;
    Fields: TaskTemplateField[];
    ClientToken?: string;
}
export declare const CreateTaskTemplateRequest: S.Schema<CreateTaskTemplateRequest>;
export type TaskTemplateId = string;
export type TaskTemplateArn = string;
export interface CreateTaskTemplateResponse {
    Id: string;
    Arn: string;
}
export declare const CreateTaskTemplateResponse: S.Schema<CreateTaskTemplateResponse>;
export type TestCaseName = string;
export type TestCaseDescription = string;
export type TestCaseContent = string;
export type TestCaseEntryPointType = "VOICE_CALL" | "CHAT" | (string & {});
export declare const TestCaseEntryPointType: any;
export interface VoiceCallEntryPointParameters {
    SourcePhoneNumber?: string;
    DestinationPhoneNumber?: string;
    FlowId?: string;
}
export declare const VoiceCallEntryPointParameters: S.Schema<VoiceCallEntryPointParameters>;
export interface ChatEntryPointParameters {
    FlowId?: string;
}
export declare const ChatEntryPointParameters: S.Schema<ChatEntryPointParameters>;
export interface TestCaseEntryPoint {
    Type?: TestCaseEntryPointType;
    VoiceCallEntryPointParameters?: VoiceCallEntryPointParameters;
    ChatEntryPointParameters?: ChatEntryPointParameters;
}
export declare const TestCaseEntryPoint: S.Schema<TestCaseEntryPoint>;
export type TestCaseInitializationData = string;
export type TestCaseStatus = "PUBLISHED" | "SAVED" | (string & {});
export declare const TestCaseStatus: any;
export type TestCaseId = string;
export interface CreateTestCaseRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    Content: string;
    EntryPoint?: TestCaseEntryPoint;
    InitializationData?: string;
    Status?: TestCaseStatus;
    TestCaseId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const CreateTestCaseRequest: S.Schema<CreateTestCaseRequest>;
export interface CreateTestCaseResponse {
    TestCaseId?: string;
    TestCaseArn?: string;
}
export declare const CreateTestCaseResponse: S.Schema<CreateTestCaseResponse>;
export type Name128 = string;
export type Description250 = string;
export interface CreateTrafficDistributionGroupRequest {
    Name: string;
    Description?: string;
    InstanceId: string;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateTrafficDistributionGroupRequest: S.Schema<CreateTrafficDistributionGroupRequest>;
export type TrafficDistributionGroupId = string;
export type TrafficDistributionGroupArn = string;
export interface CreateTrafficDistributionGroupResponse {
    Id?: string;
    Arn?: string;
}
export declare const CreateTrafficDistributionGroupResponse: S.Schema<CreateTrafficDistributionGroupResponse>;
export type UseCaseType = "RULES_EVALUATION" | "CONNECT_CAMPAIGNS" | (string & {});
export declare const UseCaseType: any;
export interface CreateUseCaseRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
    UseCaseType: UseCaseType;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateUseCaseRequest: S.Schema<CreateUseCaseRequest>;
export type UseCaseId = string;
export interface CreateUseCaseResponse {
    UseCaseId?: string;
    UseCaseArn?: string;
}
export declare const CreateUseCaseResponse: S.Schema<CreateUseCaseResponse>;
export type AgentUsername = string;
export type Password = string | redacted.Redacted<string>;
export type AgentFirstName = string | redacted.Redacted<string>;
export type AgentLastName = string | redacted.Redacted<string>;
export type Email = string | redacted.Redacted<string>;
export interface UserIdentityInfo {
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
    Email?: string | redacted.Redacted<string>;
    SecondaryEmail?: string | redacted.Redacted<string>;
    Mobile?: string;
}
export declare const UserIdentityInfo: S.Schema<UserIdentityInfo>;
export type PhoneType = "SOFT_PHONE" | "DESK_PHONE" | (string & {});
export declare const PhoneType: any;
export type AutoAccept = boolean;
export type AfterContactWorkTimeLimit = number;
export type SensitivePhoneNumber = string | redacted.Redacted<string>;
export type PersistentConnection = boolean;
export interface UserPhoneConfig {
    PhoneType?: PhoneType;
    AutoAccept?: boolean;
    AfterContactWorkTimeLimit?: number;
    DeskPhoneNumber?: string | redacted.Redacted<string>;
    PersistentConnection?: boolean;
}
export declare const UserPhoneConfig: S.Schema<UserPhoneConfig>;
export type DirectoryUserId = string;
export type AgentFirstCallbackAutoAccept = boolean;
export interface AutoAcceptConfig {
    Channel: Channel;
    AutoAccept: boolean;
    AgentFirstCallbackAutoAccept?: boolean;
}
export declare const AutoAcceptConfig: S.Schema<AutoAcceptConfig>;
export type AutoAcceptConfigs = AutoAcceptConfig[];
export declare const AutoAcceptConfigs: any;
export interface AfterContactWorkConfig {
    AfterContactWorkTimeLimit?: number;
}
export declare const AfterContactWorkConfig: S.Schema<AfterContactWorkConfig>;
export interface AfterContactWorkConfigPerChannel {
    Channel: Channel;
    AfterContactWorkConfig: AfterContactWorkConfig;
    AgentFirstCallbackAfterContactWorkConfig?: AfterContactWorkConfig;
}
export declare const AfterContactWorkConfigPerChannel: S.Schema<AfterContactWorkConfigPerChannel>;
export type AfterContactWorkConfigs = AfterContactWorkConfigPerChannel[];
export declare const AfterContactWorkConfigs: any;
export interface PhoneNumberConfig {
    Channel: Channel;
    PhoneType: PhoneType;
    PhoneNumber?: string | redacted.Redacted<string>;
}
export declare const PhoneNumberConfig: S.Schema<PhoneNumberConfig>;
export type PhoneNumberConfigs = PhoneNumberConfig[];
export declare const PhoneNumberConfigs: any;
export interface PersistentConnectionConfig {
    Channel: Channel;
    PersistentConnection: boolean;
}
export declare const PersistentConnectionConfig: S.Schema<PersistentConnectionConfig>;
export type PersistentConnectionConfigs = PersistentConnectionConfig[];
export declare const PersistentConnectionConfigs: any;
export type VoiceEnhancementMode = "VOICE_ISOLATION" | "NOISE_SUPPRESSION" | "NONE" | (string & {});
export declare const VoiceEnhancementMode: any;
export interface VoiceEnhancementConfig {
    Channel: Channel;
    VoiceEnhancementMode: VoiceEnhancementMode;
}
export declare const VoiceEnhancementConfig: S.Schema<VoiceEnhancementConfig>;
export type VoiceEnhancementConfigs = VoiceEnhancementConfig[];
export declare const VoiceEnhancementConfigs: any;
export interface CreateUserRequest {
    Username: string;
    Password?: string | redacted.Redacted<string>;
    IdentityInfo?: UserIdentityInfo;
    PhoneConfig?: UserPhoneConfig;
    DirectoryUserId?: string;
    SecurityProfileIds: string[];
    RoutingProfileId: string;
    HierarchyGroupId?: string;
    InstanceId: string;
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
export interface CreateUserResponse {
    UserId?: string;
    UserArn?: string;
}
export declare const CreateUserResponse: S.Schema<CreateUserResponse>;
export type HierarchyGroupName = string;
export interface CreateUserHierarchyGroupRequest {
    Name: string;
    ParentGroupId?: string;
    InstanceId: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateUserHierarchyGroupRequest: S.Schema<CreateUserHierarchyGroupRequest>;
export interface CreateUserHierarchyGroupResponse {
    HierarchyGroupId?: string;
    HierarchyGroupArn?: string;
}
export declare const CreateUserHierarchyGroupResponse: S.Schema<CreateUserHierarchyGroupResponse>;
export type ViewsInstanceId = string;
export type ViewsClientToken = string;
export type ViewStatus = "PUBLISHED" | "SAVED" | (string & {});
export declare const ViewStatus: any;
export type ViewTemplate = string;
export type ViewAction = string | redacted.Redacted<string>;
export type ViewActions = (string | redacted.Redacted<string>)[];
export declare const ViewActions: any;
export interface ViewInputContent {
    Template?: string;
    Actions?: (string | redacted.Redacted<string>)[];
}
export declare const ViewInputContent: S.Schema<ViewInputContent>;
export type ViewDescription = string;
export type ViewName = string | redacted.Redacted<string>;
export interface CreateViewRequest {
    InstanceId: string;
    ClientToken?: string;
    Status: ViewStatus;
    Content: ViewInputContent;
    Description?: string;
    Name: string | redacted.Redacted<string>;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateViewRequest: S.Schema<CreateViewRequest>;
export type ViewId = string;
export type ViewType = "CUSTOMER_MANAGED" | "AWS_MANAGED" | (string & {});
export declare const ViewType: any;
export type ViewVersion = number;
export type ViewInputSchema = string | redacted.Redacted<string>;
export interface ViewContent {
    InputSchema?: string | redacted.Redacted<string>;
    Template?: string;
    Actions?: (string | redacted.Redacted<string>)[];
}
export declare const ViewContent: S.Schema<ViewContent>;
export type ViewContentSha256 = string;
export interface View {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Status?: ViewStatus;
    Type?: ViewType;
    Description?: string;
    Version?: number;
    VersionDescription?: string;
    Content?: ViewContent;
    Tags?: {
        [key: string]: string | undefined;
    };
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    ViewContentSha256?: string;
}
export declare const View: S.Schema<View>;
export interface CreateViewResponse {
    View?: View;
}
export declare const CreateViewResponse: S.Schema<CreateViewResponse>;
export interface CreateViewVersionRequest {
    InstanceId: string;
    ViewId: string;
    VersionDescription?: string;
    ViewContentSha256?: string;
}
export declare const CreateViewVersionRequest: S.Schema<CreateViewVersionRequest>;
export interface CreateViewVersionResponse {
    View?: View;
}
export declare const CreateViewVersionResponse: S.Schema<CreateViewVersionResponse>;
export type VocabularyName = string;
export type VocabularyContent = string;
export interface CreateVocabularyRequest {
    ClientToken?: string;
    InstanceId: string;
    VocabularyName: string;
    LanguageCode: VocabularyLanguageCode;
    Content: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateVocabularyRequest: S.Schema<CreateVocabularyRequest>;
export type VocabularyState = "CREATION_IN_PROGRESS" | "ACTIVE" | "CREATION_FAILED" | "DELETE_IN_PROGRESS" | (string & {});
export declare const VocabularyState: any;
export interface CreateVocabularyResponse {
    VocabularyArn: string;
    VocabularyId: string;
    State: VocabularyState;
}
export declare const CreateVocabularyResponse: S.Schema<CreateVocabularyResponse>;
export type WorkspaceName = string;
export type WorkspaceDescription = string;
export type ThemeString = string;
export interface PaletteHeader {
    Background?: string;
    Text?: string;
    TextHover?: string;
    InvertActionsColors?: boolean;
}
export declare const PaletteHeader: S.Schema<PaletteHeader>;
export interface PaletteNavigation {
    Background?: string;
    TextBackgroundHover?: string;
    TextBackgroundActive?: string;
    Text?: string;
    TextHover?: string;
    TextActive?: string;
    InvertActionsColors?: boolean;
}
export declare const PaletteNavigation: S.Schema<PaletteNavigation>;
export interface PaletteCanvas {
    ContainerBackground?: string;
    PageBackground?: string;
    ActiveBackground?: string;
}
export declare const PaletteCanvas: S.Schema<PaletteCanvas>;
export interface PalettePrimary {
    Default?: string;
    Active?: string;
    ContrastText?: string;
}
export declare const PalettePrimary: S.Schema<PalettePrimary>;
export interface WorkspaceThemePalette {
    Header?: PaletteHeader;
    Navigation?: PaletteNavigation;
    Canvas?: PaletteCanvas;
    Primary?: PalettePrimary;
}
export declare const WorkspaceThemePalette: S.Schema<WorkspaceThemePalette>;
export type ThemeImageLink = string;
export interface ImagesLogo {
    Default?: string;
    Favicon?: string;
}
export declare const ImagesLogo: S.Schema<ImagesLogo>;
export interface WorkspaceThemeImages {
    Logo?: ImagesLogo;
}
export declare const WorkspaceThemeImages: S.Schema<WorkspaceThemeImages>;
export type WorkspaceFontFamily = "Arial" | "Courier New" | "Georgia" | "Times New Roman" | "Trebuchet" | "Verdana" | (string & {});
export declare const WorkspaceFontFamily: any;
export interface FontFamily {
    Default?: WorkspaceFontFamily;
}
export declare const FontFamily: S.Schema<FontFamily>;
export interface WorkspaceThemeTypography {
    FontFamily?: FontFamily;
}
export declare const WorkspaceThemeTypography: S.Schema<WorkspaceThemeTypography>;
export interface WorkspaceThemeConfig {
    Palette?: WorkspaceThemePalette;
    Images?: WorkspaceThemeImages;
    Typography?: WorkspaceThemeTypography;
}
export declare const WorkspaceThemeConfig: S.Schema<WorkspaceThemeConfig>;
export interface WorkspaceTheme {
    Light?: WorkspaceThemeConfig;
    Dark?: WorkspaceThemeConfig;
}
export declare const WorkspaceTheme: S.Schema<WorkspaceTheme>;
export type WorkspaceTitle = string;
export interface CreateWorkspaceRequest {
    InstanceId: string;
    Name: string;
    Description?: string;
    Theme?: WorkspaceTheme;
    Title?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateWorkspaceRequest: S.Schema<CreateWorkspaceRequest>;
export interface CreateWorkspaceResponse {
    WorkspaceId: string;
    WorkspaceArn: string;
}
export declare const CreateWorkspaceResponse: S.Schema<CreateWorkspaceResponse>;
export type Page = string;
export type Slug = string;
export type InputData = string;
export interface CreateWorkspacePageRequest {
    InstanceId: string;
    WorkspaceId: string;
    ResourceArn: string;
    Page: string;
    Slug?: string;
    InputData?: string;
}
export declare const CreateWorkspacePageRequest: S.Schema<CreateWorkspacePageRequest>;
export interface CreateWorkspacePageResponse {
}
export declare const CreateWorkspacePageResponse: S.Schema<CreateWorkspacePageResponse>;
export interface DeactivateEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
}
export declare const DeactivateEvaluationFormRequest: S.Schema<DeactivateEvaluationFormRequest>;
export interface DeactivateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export declare const DeactivateEvaluationFormResponse: S.Schema<DeactivateEvaluationFormResponse>;
export interface DeleteAttachedFileRequest {
    InstanceId: string;
    FileId: string;
    AssociatedResourceArn: string;
}
export declare const DeleteAttachedFileRequest: S.Schema<DeleteAttachedFileRequest>;
export interface DeleteAttachedFileResponse {
}
export declare const DeleteAttachedFileResponse: S.Schema<DeleteAttachedFileResponse>;
export type ContactField = "CUSTOMER_ENDPOINT" | "ADDITIONAL_EMAIL_RECIPIENTS" | "EMAIL_SUBJECT" | (string & {});
export declare const ContactField: any;
export type ContactFields = ContactField[];
export declare const ContactFields: any;
export interface DeleteContactDataRequest {
    InstanceId: string;
    ContactId: string;
    ContactFields: ContactField[];
}
export declare const DeleteContactDataRequest: S.Schema<DeleteContactDataRequest>;
export interface DeleteContactDataResponse {
}
export declare const DeleteContactDataResponse: S.Schema<DeleteContactDataResponse>;
export interface DeleteContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
}
export declare const DeleteContactEvaluationRequest: S.Schema<DeleteContactEvaluationRequest>;
export interface DeleteContactEvaluationResponse {
}
export declare const DeleteContactEvaluationResponse: S.Schema<DeleteContactEvaluationResponse>;
export interface DeleteContactFlowRequest {
    InstanceId: string;
    ContactFlowId: string;
}
export declare const DeleteContactFlowRequest: S.Schema<DeleteContactFlowRequest>;
export interface DeleteContactFlowResponse {
}
export declare const DeleteContactFlowResponse: S.Schema<DeleteContactFlowResponse>;
export interface DeleteContactFlowModuleRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
}
export declare const DeleteContactFlowModuleRequest: S.Schema<DeleteContactFlowModuleRequest>;
export interface DeleteContactFlowModuleResponse {
}
export declare const DeleteContactFlowModuleResponse: S.Schema<DeleteContactFlowModuleResponse>;
export interface DeleteContactFlowModuleAliasRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    AliasId: string;
}
export declare const DeleteContactFlowModuleAliasRequest: S.Schema<DeleteContactFlowModuleAliasRequest>;
export interface DeleteContactFlowModuleAliasResponse {
}
export declare const DeleteContactFlowModuleAliasResponse: S.Schema<DeleteContactFlowModuleAliasResponse>;
export interface DeleteContactFlowModuleVersionRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    ContactFlowModuleVersion: number;
}
export declare const DeleteContactFlowModuleVersionRequest: S.Schema<DeleteContactFlowModuleVersionRequest>;
export interface DeleteContactFlowModuleVersionResponse {
}
export declare const DeleteContactFlowModuleVersionResponse: S.Schema<DeleteContactFlowModuleVersionResponse>;
export interface DeleteContactFlowVersionRequest {
    InstanceId: string;
    ContactFlowId: string;
    ContactFlowVersion: number;
}
export declare const DeleteContactFlowVersionRequest: S.Schema<DeleteContactFlowVersionRequest>;
export interface DeleteContactFlowVersionResponse {
}
export declare const DeleteContactFlowVersionResponse: S.Schema<DeleteContactFlowVersionResponse>;
export interface DeleteDataTableRequest {
    InstanceId: string;
    DataTableId: string;
}
export declare const DeleteDataTableRequest: S.Schema<DeleteDataTableRequest>;
export interface DeleteDataTableResponse {
}
export declare const DeleteDataTableResponse: S.Schema<DeleteDataTableResponse>;
export interface DeleteDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeName: string;
}
export declare const DeleteDataTableAttributeRequest: S.Schema<DeleteDataTableAttributeRequest>;
export interface DeleteDataTableAttributeResponse {
    LockVersion: DataTableLockVersion;
}
export declare const DeleteDataTableAttributeResponse: S.Schema<DeleteDataTableAttributeResponse>;
export interface DeleteEmailAddressRequest {
    InstanceId: string;
    EmailAddressId: string;
}
export declare const DeleteEmailAddressRequest: S.Schema<DeleteEmailAddressRequest>;
export interface DeleteEmailAddressResponse {
}
export declare const DeleteEmailAddressResponse: S.Schema<DeleteEmailAddressResponse>;
export interface DeleteEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion?: number;
}
export declare const DeleteEvaluationFormRequest: S.Schema<DeleteEvaluationFormRequest>;
export interface DeleteEvaluationFormResponse {
}
export declare const DeleteEvaluationFormResponse: S.Schema<DeleteEvaluationFormResponse>;
export interface DeleteExtractionDefinitionRequest {
    InstanceId: string;
    ExtractionDefinitionId: string;
}
export declare const DeleteExtractionDefinitionRequest: S.Schema<DeleteExtractionDefinitionRequest>;
export interface DeleteExtractionDefinitionResponse {
}
export declare const DeleteExtractionDefinitionResponse: S.Schema<DeleteExtractionDefinitionResponse>;
export interface DeleteHoursOfOperationRequest {
    InstanceId: string;
    HoursOfOperationId: string;
}
export declare const DeleteHoursOfOperationRequest: S.Schema<DeleteHoursOfOperationRequest>;
export interface DeleteHoursOfOperationResponse {
}
export declare const DeleteHoursOfOperationResponse: S.Schema<DeleteHoursOfOperationResponse>;
export interface DeleteHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    HoursOfOperationOverrideId: string;
}
export declare const DeleteHoursOfOperationOverrideRequest: S.Schema<DeleteHoursOfOperationOverrideRequest>;
export interface DeleteHoursOfOperationOverrideResponse {
}
export declare const DeleteHoursOfOperationOverrideResponse: S.Schema<DeleteHoursOfOperationOverrideResponse>;
export interface DeleteInstanceRequest {
    InstanceId: string;
    ClientToken?: string;
}
export declare const DeleteInstanceRequest: S.Schema<DeleteInstanceRequest>;
export interface DeleteInstanceResponse {
}
export declare const DeleteInstanceResponse: S.Schema<DeleteInstanceResponse>;
export interface DeleteIntegrationAssociationRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
}
export declare const DeleteIntegrationAssociationRequest: S.Schema<DeleteIntegrationAssociationRequest>;
export interface DeleteIntegrationAssociationResponse {
}
export declare const DeleteIntegrationAssociationResponse: S.Schema<DeleteIntegrationAssociationResponse>;
export interface DeleteMetricRequest {
    InstanceId: string;
    MetricId: string;
}
export declare const DeleteMetricRequest: S.Schema<DeleteMetricRequest>;
export interface DeleteMetricResponse {
}
export declare const DeleteMetricResponse: S.Schema<DeleteMetricResponse>;
export interface DeleteNotificationRequest {
    InstanceId: string;
    NotificationId: string;
}
export declare const DeleteNotificationRequest: S.Schema<DeleteNotificationRequest>;
export interface DeleteNotificationResponse {
}
export declare const DeleteNotificationResponse: S.Schema<DeleteNotificationResponse>;
export interface DeletePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
}
export declare const DeletePredefinedAttributeRequest: S.Schema<DeletePredefinedAttributeRequest>;
export interface DeletePredefinedAttributeResponse {
}
export declare const DeletePredefinedAttributeResponse: S.Schema<DeletePredefinedAttributeResponse>;
export interface DeletePromptRequest {
    InstanceId: string;
    PromptId: string;
}
export declare const DeletePromptRequest: S.Schema<DeletePromptRequest>;
export interface DeletePromptResponse {
}
export declare const DeletePromptResponse: S.Schema<DeletePromptResponse>;
export interface DeletePushNotificationRegistrationRequest {
    InstanceId: string;
    RegistrationId: string;
    ContactId: string;
}
export declare const DeletePushNotificationRegistrationRequest: S.Schema<DeletePushNotificationRegistrationRequest>;
export interface DeletePushNotificationRegistrationResponse {
}
export declare const DeletePushNotificationRegistrationResponse: S.Schema<DeletePushNotificationRegistrationResponse>;
export interface DeleteQueueRequest {
    InstanceId: string;
    QueueId: string;
}
export declare const DeleteQueueRequest: S.Schema<DeleteQueueRequest>;
export interface DeleteQueueResponse {
}
export declare const DeleteQueueResponse: S.Schema<DeleteQueueResponse>;
export interface DeleteQuickConnectRequest {
    InstanceId: string;
    QuickConnectId: string;
}
export declare const DeleteQuickConnectRequest: S.Schema<DeleteQuickConnectRequest>;
export interface DeleteQuickConnectResponse {
}
export declare const DeleteQuickConnectResponse: S.Schema<DeleteQuickConnectResponse>;
export interface DeleteRoutingProfileRequest {
    InstanceId: string;
    RoutingProfileId: string;
}
export declare const DeleteRoutingProfileRequest: S.Schema<DeleteRoutingProfileRequest>;
export interface DeleteRoutingProfileResponse {
}
export declare const DeleteRoutingProfileResponse: S.Schema<DeleteRoutingProfileResponse>;
export interface DeleteRuleRequest {
    InstanceId: string;
    RuleId: string;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export interface DeleteRuleResponse {
}
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface DeleteSecurityProfileRequest {
    InstanceId: string;
    SecurityProfileId: string;
}
export declare const DeleteSecurityProfileRequest: S.Schema<DeleteSecurityProfileRequest>;
export interface DeleteSecurityProfileResponse {
}
export declare const DeleteSecurityProfileResponse: S.Schema<DeleteSecurityProfileResponse>;
export interface DeleteSessionRequest {
    InstanceId: string;
    SessionId: string;
}
export declare const DeleteSessionRequest: S.Schema<DeleteSessionRequest>;
export interface DeleteSessionResponse {
}
export declare const DeleteSessionResponse: S.Schema<DeleteSessionResponse>;
export interface DeleteTaskTemplateRequest {
    InstanceId: string;
    TaskTemplateId: string;
}
export declare const DeleteTaskTemplateRequest: S.Schema<DeleteTaskTemplateRequest>;
export interface DeleteTaskTemplateResponse {
}
export declare const DeleteTaskTemplateResponse: S.Schema<DeleteTaskTemplateResponse>;
export interface DeleteTestCaseRequest {
    InstanceId: string;
    TestCaseId: string;
}
export declare const DeleteTestCaseRequest: S.Schema<DeleteTestCaseRequest>;
export interface DeleteTestCaseResponse {
}
export declare const DeleteTestCaseResponse: S.Schema<DeleteTestCaseResponse>;
export interface DeleteTrafficDistributionGroupRequest {
    TrafficDistributionGroupId: string;
}
export declare const DeleteTrafficDistributionGroupRequest: S.Schema<DeleteTrafficDistributionGroupRequest>;
export interface DeleteTrafficDistributionGroupResponse {
}
export declare const DeleteTrafficDistributionGroupResponse: S.Schema<DeleteTrafficDistributionGroupResponse>;
export interface DeleteUseCaseRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
    UseCaseId: string;
}
export declare const DeleteUseCaseRequest: S.Schema<DeleteUseCaseRequest>;
export interface DeleteUseCaseResponse {
}
export declare const DeleteUseCaseResponse: S.Schema<DeleteUseCaseResponse>;
export interface DeleteUserRequest {
    InstanceId: string;
    UserId: string;
}
export declare const DeleteUserRequest: S.Schema<DeleteUserRequest>;
export interface DeleteUserResponse {
}
export declare const DeleteUserResponse: S.Schema<DeleteUserResponse>;
export interface DeleteUserHierarchyGroupRequest {
    HierarchyGroupId: string;
    InstanceId: string;
}
export declare const DeleteUserHierarchyGroupRequest: S.Schema<DeleteUserHierarchyGroupRequest>;
export interface DeleteUserHierarchyGroupResponse {
}
export declare const DeleteUserHierarchyGroupResponse: S.Schema<DeleteUserHierarchyGroupResponse>;
export interface DeleteViewRequest {
    InstanceId: string;
    ViewId: string;
}
export declare const DeleteViewRequest: S.Schema<DeleteViewRequest>;
export interface DeleteViewResponse {
}
export declare const DeleteViewResponse: S.Schema<DeleteViewResponse>;
export interface DeleteViewVersionRequest {
    InstanceId: string;
    ViewId: string;
    ViewVersion: number;
}
export declare const DeleteViewVersionRequest: S.Schema<DeleteViewVersionRequest>;
export interface DeleteViewVersionResponse {
}
export declare const DeleteViewVersionResponse: S.Schema<DeleteViewVersionResponse>;
export interface DeleteVocabularyRequest {
    InstanceId: string;
    VocabularyId: string;
}
export declare const DeleteVocabularyRequest: S.Schema<DeleteVocabularyRequest>;
export interface DeleteVocabularyResponse {
    VocabularyArn: string;
    VocabularyId: string;
    State: VocabularyState;
}
export declare const DeleteVocabularyResponse: S.Schema<DeleteVocabularyResponse>;
export interface DeleteWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
}
export declare const DeleteWorkspaceRequest: S.Schema<DeleteWorkspaceRequest>;
export interface DeleteWorkspaceResponse {
}
export declare const DeleteWorkspaceResponse: S.Schema<DeleteWorkspaceResponse>;
export type MediaType = "IMAGE_LOGO_LIGHT_FAVICON" | "IMAGE_LOGO_DARK_FAVICON" | "IMAGE_LOGO_LIGHT_HORIZONTAL" | "IMAGE_LOGO_DARK_HORIZONTAL" | (string & {});
export declare const MediaType: any;
export interface DeleteWorkspaceMediaRequest {
    InstanceId: string;
    WorkspaceId: string;
    MediaType: MediaType;
}
export declare const DeleteWorkspaceMediaRequest: S.Schema<DeleteWorkspaceMediaRequest>;
export interface DeleteWorkspaceMediaResponse {
}
export declare const DeleteWorkspaceMediaResponse: S.Schema<DeleteWorkspaceMediaResponse>;
export interface DeleteWorkspacePageRequest {
    InstanceId: string;
    WorkspaceId: string;
    Page: string;
}
export declare const DeleteWorkspacePageRequest: S.Schema<DeleteWorkspacePageRequest>;
export interface DeleteWorkspacePageResponse {
}
export declare const DeleteWorkspacePageResponse: S.Schema<DeleteWorkspacePageResponse>;
export interface DescribeAgentStatusRequest {
    InstanceId: string;
    AgentStatusId: string;
}
export declare const DescribeAgentStatusRequest: S.Schema<DescribeAgentStatusRequest>;
export type AgentStatusType = "ROUTABLE" | "CUSTOM" | "OFFLINE" | (string & {});
export declare const AgentStatusType: any;
export interface AgentStatus {
    AgentStatusARN?: string;
    AgentStatusId?: string;
    Name?: string;
    Description?: string;
    Type?: AgentStatusType;
    DisplayOrder?: number;
    State?: AgentStatusState;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const AgentStatus: S.Schema<AgentStatus>;
export interface DescribeAgentStatusResponse {
    AgentStatus?: AgentStatus;
}
export declare const DescribeAgentStatusResponse: S.Schema<DescribeAgentStatusResponse>;
export type AttachmentScope = "EMAIL" | "CHAT" | "CASE" | "TASK" | (string & {});
export declare const AttachmentScope: any;
export interface DescribeAttachedFilesConfigurationRequest {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
}
export declare const DescribeAttachedFilesConfigurationRequest: S.Schema<DescribeAttachedFilesConfigurationRequest>;
export type MaximumSizeLimitInBytes = number;
export type FileExtension = string;
export interface AllowedExtension {
    Extension: string;
}
export declare const AllowedExtension: S.Schema<AllowedExtension>;
export type AllowedExtensionsList = AllowedExtension[];
export declare const AllowedExtensionsList: any;
export interface ExtensionConfiguration {
    AllowedExtensions: AllowedExtension[];
}
export declare const ExtensionConfiguration: S.Schema<ExtensionConfiguration>;
export interface AttachedFilesConfiguration {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
    LastModifiedTime?: Date;
}
export declare const AttachedFilesConfiguration: S.Schema<AttachedFilesConfiguration>;
export interface DescribeAttachedFilesConfigurationResponse {
    AttachedFilesConfiguration: AttachedFilesConfiguration;
}
export declare const DescribeAttachedFilesConfigurationResponse: S.Schema<DescribeAttachedFilesConfigurationResponse>;
export type AuthenticationProfileId = string;
export interface DescribeAuthenticationProfileRequest {
    AuthenticationProfileId: string;
    InstanceId: string;
}
export declare const DescribeAuthenticationProfileRequest: S.Schema<DescribeAuthenticationProfileRequest>;
export type AuthenticationProfileName = string;
export type AuthenticationProfileDescription = string;
export type IpCidr = string;
export type IpCidrList = string[];
export declare const IpCidrList: any;
export type AccessTokenDuration = number;
export type RefreshTokenDuration = number;
export type InactivityDuration = number;
export interface AuthenticationProfile {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    AllowedIps?: string[];
    BlockedIps?: string[];
    IsDefault?: boolean;
    CreatedTime?: Date;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    PeriodicSessionDuration?: number;
    MaxSessionDuration?: number;
    SessionInactivityDuration?: number;
    SessionInactivityHandlingEnabled?: boolean;
}
export declare const AuthenticationProfile: S.Schema<AuthenticationProfile>;
export interface DescribeAuthenticationProfileResponse {
    AuthenticationProfile?: AuthenticationProfile;
}
export declare const DescribeAuthenticationProfileResponse: S.Schema<DescribeAuthenticationProfileResponse>;
export interface DescribeContactRequest {
    InstanceId: string;
    ContactId: string;
}
export declare const DescribeContactRequest: S.Schema<DescribeContactRequest>;
export interface QueueInfo {
    Id?: string;
    EnqueueTimestamp?: Date;
}
export declare const QueueInfo: S.Schema<QueueInfo>;
export type AgentPauseDurationInSeconds = number;
export interface AgentHierarchyGroup {
    Arn?: string;
}
export declare const AgentHierarchyGroup: S.Schema<AgentHierarchyGroup>;
export interface HierarchyGroups {
    Level1?: AgentHierarchyGroup;
    Level2?: AgentHierarchyGroup;
    Level3?: AgentHierarchyGroup;
    Level4?: AgentHierarchyGroup;
    Level5?: AgentHierarchyGroup;
}
export declare const HierarchyGroups: S.Schema<HierarchyGroups>;
export type PlatformName = string;
export type PlatformVersion = string;
export type OperatingSystem = string;
export interface DeviceInfo {
    PlatformName?: string;
    PlatformVersion?: string;
    OperatingSystem?: string;
}
export declare const DeviceInfo: S.Schema<DeviceInfo>;
export type Duration = number;
export type ParticipantState = "INITIAL" | "CONNECTED" | "DISCONNECTED" | "MISSED" | (string & {});
export declare const ParticipantState: any;
export interface StateTransition {
    State?: ParticipantState;
    StateStartTimestamp?: Date;
    StateEndTimestamp?: Date;
}
export declare const StateTransition: S.Schema<StateTransition>;
export type StateTransitions = StateTransition[];
export declare const StateTransitions: any;
export interface AgentInfo {
    Id?: string;
    AcceptedByAgentTimestamp?: Date;
    PreviewEndTimestamp?: Date;
    ConnectedToAgentTimestamp?: Date;
    AgentPauseDurationInSeconds?: number;
    HierarchyGroups?: HierarchyGroups;
    DeviceInfo?: DeviceInfo;
    Capabilities?: ParticipantCapabilities;
    AfterContactWorkDuration?: number;
    AfterContactWorkStartTimestamp?: Date;
    AfterContactWorkEndTimestamp?: Date;
    AgentInitiatedHoldDuration?: number;
    StateTransitions?: StateTransition[];
    VoiceEnhancementMode?: VoiceEnhancementMode;
}
export declare const AgentInfo: S.Schema<AgentInfo>;
export type TotalPauseCount = number;
export type TotalPauseDurationInSeconds = number;
export type AiUseCase = "AgentAssistance" | "SelfService" | (string & {});
export declare const AiUseCase: any;
export type AiAgentVersionId = string;
export interface AiAgentInfo {
    AiUseCase?: AiUseCase;
    AiAgentVersionId?: string;
    AiAgentEscalated?: boolean;
}
export declare const AiAgentInfo: S.Schema<AiAgentInfo>;
export type AiAgents = AiAgentInfo[];
export declare const AiAgents: any;
export interface WisdomInfo {
    SessionArn?: string;
    AiAgents?: AiAgentInfo[];
}
export declare const WisdomInfo: S.Schema<WisdomInfo>;
export type CustomerId = string;
export type EndpointDisplayName = string;
export interface EndpointInfo {
    Type?: EndpointType;
    Address?: string;
    DisplayName?: string;
}
export declare const EndpointInfo: S.Schema<EndpointInfo>;
export type QueueTimeAdjustmentSeconds = number;
export type QueuePriority = number;
export type ContactTagKey = string;
export type ContactTagValue = string;
export type ContactTagMap = {
    [key: string]: string | undefined;
};
export declare const ContactTagMap: any;
export type DurationInSeconds = number;
export interface Expiry {
    DurationInSeconds?: number;
    ExpiryTimestamp?: Date;
}
export declare const Expiry: S.Schema<Expiry>;
export type ProficiencyValue = string;
export type NullableProficiencyLevel = number;
export interface Range {
    MinProficiencyLevel?: number;
    MaxProficiencyLevel?: number;
}
export declare const Range: S.Schema<Range>;
export type AgentId = string;
export type AgentIds = string[];
export declare const AgentIds: any;
export interface AgentsCriteria {
    AgentIds?: string[];
}
export declare const AgentsCriteria: S.Schema<AgentsCriteria>;
export interface MatchCriteria {
    AgentsCriteria?: AgentsCriteria;
}
export declare const MatchCriteria: S.Schema<MatchCriteria>;
export type ComparisonOperator = string;
export interface AttributeCondition {
    Name?: string;
    Value?: string;
    ProficiencyLevel?: number;
    Range?: Range;
    MatchCriteria?: MatchCriteria;
    ComparisonOperator?: string;
}
export declare const AttributeCondition: S.Schema<AttributeCondition>;
export type Expressions = Expression[];
export declare const Expressions: S.Schema<Expressions>;
export interface Expression {
    AttributeCondition?: AttributeCondition;
    AndExpression?: Expression[];
    OrExpression?: Expression[];
    NotAttributeCondition?: AttributeCondition;
}
export declare const Expression: S.Schema<Expression>;
export type RoutingCriteriaStepStatus = "ACTIVE" | "INACTIVE" | "JOINED" | "EXPIRED" | (string & {});
export declare const RoutingCriteriaStepStatus: any;
export interface Step {
    Expiry?: Expiry;
    Expression?: Expression;
    Status?: RoutingCriteriaStepStatus;
}
export declare const Step: S.Schema<Step>;
export type Steps = Step[];
export declare const Steps: any;
export type Index = number;
export interface RoutingCriteria {
    Steps?: Step[];
    ActivationTimestamp?: Date;
    Index?: number;
}
export declare const RoutingCriteria: S.Schema<RoutingCriteria>;
export interface Customer {
    DeviceInfo?: DeviceInfo;
    Capabilities?: ParticipantCapabilities;
}
export declare const Customer: S.Schema<Customer>;
export type AnsweringMachineDetectionStatus = "ANSWERED" | "UNDETECTED" | "ERROR" | "HUMAN_ANSWERED" | "SIT_TONE_DETECTED" | "SIT_TONE_BUSY" | "SIT_TONE_INVALID_NUMBER" | "FAX_MACHINE_DETECTED" | "VOICEMAIL_BEEP" | "VOICEMAIL_NO_BEEP" | "AMD_UNRESOLVED" | "AMD_UNANSWERED" | "AMD_ERROR" | "AMD_NOT_APPLICABLE" | (string & {});
export declare const AnsweringMachineDetectionStatus: any;
export interface CustomerVoiceActivity {
    GreetingStartTimestamp?: Date;
    GreetingEndTimestamp?: Date;
}
export declare const CustomerVoiceActivity: S.Schema<CustomerVoiceActivity>;
export type AudioQualityScore = number;
export type PotentialAudioQualityIssue = string;
export type PotentialAudioQualityIssues = string[];
export declare const PotentialAudioQualityIssues: any;
export interface AudioQualityMetricsInfo {
    QualityScore?: number;
    PotentialQualityIssues?: string[];
}
export declare const AudioQualityMetricsInfo: S.Schema<AudioQualityMetricsInfo>;
export interface AgentQualityMetrics {
    Audio?: AudioQualityMetricsInfo;
}
export declare const AgentQualityMetrics: S.Schema<AgentQualityMetrics>;
export interface CustomerQualityMetrics {
    Audio?: AudioQualityMetricsInfo;
}
export declare const CustomerQualityMetrics: S.Schema<CustomerQualityMetrics>;
export interface QualityMetrics {
    Agent?: AgentQualityMetrics;
    Customer?: CustomerQualityMetrics;
}
export declare const QualityMetrics: S.Schema<QualityMetrics>;
export type Count = number;
export type DurationMillis = number;
export interface ChatContactMetrics {
    MultiParty?: boolean;
    TotalMessages?: number;
    TotalBotMessages?: number;
    TotalBotMessageLengthInChars?: number;
    ConversationCloseTimeInMillis?: number;
    ConversationTurnCount?: number;
    AgentFirstResponseTimestamp?: Date;
    AgentFirstResponseTimeInMillis?: number;
}
export declare const ChatContactMetrics: S.Schema<ChatContactMetrics>;
export type ParticipantType = "ALL" | "MANAGER" | "AGENT" | "CUSTOMER" | "THIRDPARTY" | (string & {});
export declare const ParticipantType: any;
export interface ParticipantMetrics {
    ParticipantId?: string;
    ParticipantType?: ParticipantType;
    ConversationAbandon?: boolean;
    MessagesSent?: number;
    NumResponses?: number;
    MessageLengthInChars?: number;
    TotalResponseTimeInMillis?: number;
    MaxResponseTimeInMillis?: number;
    LastMessageTimestamp?: Date;
}
export declare const ParticipantMetrics: S.Schema<ParticipantMetrics>;
export interface ChatMetrics {
    ChatContactMetrics?: ChatContactMetrics;
    AgentMetrics?: ParticipantMetrics;
    CustomerMetrics?: ParticipantMetrics;
}
export declare const ChatMetrics: S.Schema<ChatMetrics>;
export type PotentialDisconnectIssue = string;
export interface DisconnectDetails {
    PotentialDisconnectIssue?: string;
}
export declare const DisconnectDetails: S.Schema<DisconnectDetails>;
export interface EmailRecipient {
    Address?: string;
    DisplayName?: string;
}
export declare const EmailRecipient: S.Schema<EmailRecipient>;
export type EmailRecipientsList = EmailRecipient[];
export declare const EmailRecipientsList: any;
export interface AdditionalEmailRecipients {
    ToList?: EmailRecipient[];
    CcList?: EmailRecipient[];
}
export declare const AdditionalEmailRecipients: S.Schema<AdditionalEmailRecipients>;
export type RecordingLocation = string;
export type MediaStreamType = "AUDIO" | "VIDEO" | (string & {});
export declare const MediaStreamType: any;
export type FragmentNumber = string;
export type RecordingStatus = "AVAILABLE" | "DELETED" | (string & {});
export declare const RecordingStatus: any;
export type RecordingDeletionReason = string;
export type UnprocessedTranscriptLocation = string;
export interface RecordingInfo {
    StorageType?: StorageType;
    Location?: string;
    MediaStreamType?: MediaStreamType;
    ParticipantType?: ParticipantType;
    FragmentStartNumber?: string;
    FragmentStopNumber?: string;
    StartTimestamp?: Date;
    StopTimestamp?: Date;
    Status?: RecordingStatus;
    DeletionReason?: string;
    UnprocessedTranscriptLocation?: string;
}
export declare const RecordingInfo: S.Schema<RecordingInfo>;
export type Recordings = RecordingInfo[];
export declare const Recordings: any;
export type EvaluationId = string;
export type FormId = string;
export type EvaluationArn = string;
export type Status = "COMPLETE" | "IN_PROGRESS" | "DELETED" | (string & {});
export declare const Status: any;
export type ExportLocation = string;
export interface ContactEvaluation {
    FormId?: string;
    EvaluationArn?: string;
    Status?: Status;
    StartTimestamp?: Date;
    EndTimestamp?: Date;
    DeleteTimestamp?: Date;
    ExportLocation?: string;
}
export declare const ContactEvaluation: S.Schema<ContactEvaluation>;
export type ContactEvaluations = {
    [key: string]: ContactEvaluation | undefined;
};
export declare const ContactEvaluations: any;
export interface TaskTemplateInfoV2 {
    Arn?: string;
    Name?: string;
}
export declare const TaskTemplateInfoV2: S.Schema<TaskTemplateInfoV2>;
export type ContactDetailName = string;
export type ContactDetailDescription = string;
export interface ContactDetails {
    Name?: string;
    Description?: string;
}
export declare const ContactDetails: S.Schema<ContactDetails>;
export type NextContactType = "QUICK_CONNECT" | (string & {});
export declare const NextContactType: any;
export interface QuickConnectContactData {
    ContactId?: string;
    InitiationTimestamp?: Date;
    QuickConnectId?: string;
    QuickConnectName?: string;
    QuickConnectType?: QuickConnectType;
}
export declare const QuickConnectContactData: S.Schema<QuickConnectContactData>;
export type NextContactMetadata = {
    QuickConnectContactData: QuickConnectContactData;
};
export declare const NextContactMetadata: any;
export interface NextContactEntry {
    Type?: NextContactType;
    NextContactMetadata?: NextContactMetadata;
}
export declare const NextContactEntry: S.Schema<NextContactEntry>;
export type NextContacts = NextContactEntry[];
export declare const NextContacts: any;
export type ActiveRegion = string;
export type OriginRegion = string;
export interface GlobalResiliencyMetadata {
    ActiveRegion?: string;
    OriginRegion?: string;
    TrafficDistributionGroupId?: string;
}
export declare const GlobalResiliencyMetadata: S.Schema<GlobalResiliencyMetadata>;
export interface Contact {
    Arn?: string;
    Id?: string;
    InitialContactId?: string;
    PreviousContactId?: string;
    ContactAssociationId?: string;
    InitiationMethod?: ContactInitiationMethod;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    Channel?: Channel;
    QueueInfo?: QueueInfo;
    AgentInfo?: AgentInfo;
    InitiationTimestamp?: Date;
    DisconnectTimestamp?: Date;
    LastUpdateTimestamp?: Date;
    LastPausedTimestamp?: Date;
    LastResumedTimestamp?: Date;
    RingStartTimestamp?: Date;
    TotalPauseCount?: number;
    TotalPauseDurationInSeconds?: number;
    ScheduledTimestamp?: Date;
    RelatedContactId?: string;
    WisdomInfo?: WisdomInfo;
    CustomerId?: string;
    CustomerEndpoint?: EndpointInfo;
    SystemEndpoint?: EndpointInfo;
    QueueTimeAdjustmentSeconds?: number;
    QueuePriority?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    ConnectedToSystemTimestamp?: Date;
    RoutingCriteria?: RoutingCriteria;
    Customer?: Customer;
    Campaign?: Campaign;
    AnsweringMachineDetectionStatus?: AnsweringMachineDetectionStatus;
    CustomerVoiceActivity?: CustomerVoiceActivity;
    QualityMetrics?: QualityMetrics;
    ChatMetrics?: ChatMetrics;
    DisconnectDetails?: DisconnectDetails;
    AdditionalEmailRecipients?: AdditionalEmailRecipients;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    Recordings?: RecordingInfo[];
    DisconnectReason?: string;
    ContactEvaluations?: {
        [key: string]: ContactEvaluation | undefined;
    };
    TaskTemplateInfo?: TaskTemplateInfoV2;
    ContactDetails?: ContactDetails;
    OutboundStrategy?: OutboundStrategy;
    Attributes?: {
        [key: string]: string | undefined;
    };
    NextContacts?: NextContactEntry[];
    GlobalResiliencyMetadata?: GlobalResiliencyMetadata;
}
export declare const Contact: S.Schema<Contact>;
export interface DescribeContactResponse {
    Contact?: Contact;
}
export declare const DescribeContactResponse: S.Schema<DescribeContactResponse>;
export interface DescribeContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
}
export declare const DescribeContactEvaluationRequest: S.Schema<DescribeContactEvaluationRequest>;
export interface EvaluationScore {
    Percentage?: number;
    NotApplicable?: boolean;
    AutomaticFail?: boolean;
    AppliedWeight?: number;
    EarnedPoints?: number;
    MaxBasePoint?: number;
    PerformanceCategory?: PerformanceCategoryName;
}
export declare const EvaluationScore: S.Schema<EvaluationScore>;
export type AutoEvaluationStatus = "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export declare const AutoEvaluationStatus: any;
export interface AutoEvaluationDetails {
    AutoEvaluationEnabled: boolean;
    AutoEvaluationStatus?: AutoEvaluationStatus;
}
export declare const AutoEvaluationDetails: S.Schema<AutoEvaluationDetails>;
export type EvaluationAcknowledgerCommentString = string;
export interface EvaluationAcknowledgement {
    AcknowledgedTime: Date;
    AcknowledgedBy: string;
    AcknowledgerComment?: string;
}
export declare const EvaluationAcknowledgement: S.Schema<EvaluationAcknowledgement>;
export type EvaluationReviewRequestCommentContent = string;
export interface EvaluationReviewRequestComment {
    Comment?: string;
    CreatedTime?: Date;
    CreatedBy?: string;
}
export declare const EvaluationReviewRequestComment: S.Schema<EvaluationReviewRequestComment>;
export type EvaluationReviewRequestCommentList = EvaluationReviewRequestComment[];
export declare const EvaluationReviewRequestCommentList: any;
export interface EvaluationReviewMetadata {
    ReviewId?: string;
    RequestedTime?: Date;
    RequestedBy?: string;
    CreatedTime?: Date;
    CreatedBy?: string;
    ReviewRequestComments: EvaluationReviewRequestComment[];
}
export declare const EvaluationReviewMetadata: S.Schema<EvaluationReviewMetadata>;
export type ContactParticipantRole = "AGENT" | "SYSTEM" | "CUSTOM_BOT" | "CUSTOMER" | (string & {});
export declare const ContactParticipantRole: any;
export interface EvaluationContactParticipant {
    ContactParticipantRole?: ContactParticipantRole;
    ContactParticipantId?: string;
}
export declare const EvaluationContactParticipant: S.Schema<EvaluationContactParticipant>;
export interface EvaluationMetadata {
    ContactId: string;
    EvaluatorArn: string;
    ContactAgentId?: string;
    CalibrationSessionId?: string;
    Score?: EvaluationScore;
    AutoEvaluation?: AutoEvaluationDetails;
    Acknowledgement?: EvaluationAcknowledgement;
    Review?: EvaluationReviewMetadata;
    ContactParticipant?: EvaluationContactParticipant;
    SamplingJobId?: string;
}
export declare const EvaluationMetadata: S.Schema<EvaluationMetadata>;
export type EvaluationAnswerDataStringValue = string;
export type EvaluationAnswerDataNumericValue = number;
export type EvaluationAnswerDataStringValueList = string[];
export declare const EvaluationAnswerDataStringValueList: any;
export type EvaluationAnswerData = {
    StringValue: string;
    NumericValue?: never;
    StringValues?: never;
    DateTimeValue?: never;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue: number;
    StringValues?: never;
    DateTimeValue?: never;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue?: never;
    StringValues: string[];
    DateTimeValue?: never;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue?: never;
    StringValues?: never;
    DateTimeValue: string;
    NotApplicable?: never;
} | {
    StringValue?: never;
    NumericValue?: never;
    StringValues?: never;
    DateTimeValue?: never;
    NotApplicable: boolean;
};
export declare const EvaluationAnswerData: any;
export type EvaluationSuggestedAnswerStatus = "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | (string & {});
export declare const EvaluationSuggestedAnswerStatus: any;
export type EvaluationTranscriptType = "RAW" | "REDACTED" | (string & {});
export declare const EvaluationTranscriptType: any;
export interface EvaluationQuestionInputDetails {
    TranscriptType?: EvaluationTranscriptType;
}
export declare const EvaluationQuestionInputDetails: S.Schema<EvaluationQuestionInputDetails>;
export type EvaluationQuestionAnswerAnalysisType = "CONTACT_LENS_DATA" | "GEN_AI" | (string & {});
export declare const EvaluationQuestionAnswerAnalysisType: any;
export type EvaluationSuggestedAnswerJustification = string;
export type EvaluationSuggestedAnswerTranscriptMillisOffset = number;
export interface EvaluationSuggestedAnswerTranscriptMillisecondOffsets {
    BeginOffsetMillis: number;
}
export declare const EvaluationSuggestedAnswerTranscriptMillisecondOffsets: S.Schema<EvaluationSuggestedAnswerTranscriptMillisecondOffsets>;
export type EvaluationSuggestedAnswerTranscriptSegment = string;
export interface EvaluationTranscriptPointOfInterest {
    MillisecondOffsets?: EvaluationSuggestedAnswerTranscriptMillisecondOffsets;
    TranscriptSegment?: string;
}
export declare const EvaluationTranscriptPointOfInterest: S.Schema<EvaluationTranscriptPointOfInterest>;
export type EvaluationTranscriptPointsOfInterest = EvaluationTranscriptPointOfInterest[];
export declare const EvaluationTranscriptPointsOfInterest: any;
export interface EvaluationGenAIAnswerAnalysisDetails {
    Justification?: string;
    PointsOfInterest?: EvaluationTranscriptPointOfInterest[];
}
export declare const EvaluationGenAIAnswerAnalysisDetails: S.Schema<EvaluationGenAIAnswerAnalysisDetails>;
export type QuestionRuleCategoryAutomationLabel = string;
export type QuestionRuleCategoryAutomationCondition = "PRESENT" | "NOT_PRESENT" | (string & {});
export declare const QuestionRuleCategoryAutomationCondition: any;
export interface EvaluationAutomationRuleCategory {
    Category: string;
    Condition: QuestionRuleCategoryAutomationCondition;
    PointsOfInterest?: EvaluationTranscriptPointOfInterest[];
}
export declare const EvaluationAutomationRuleCategory: S.Schema<EvaluationAutomationRuleCategory>;
export type EvaluationAutomationRuleCategoryList = EvaluationAutomationRuleCategory[];
export declare const EvaluationAutomationRuleCategoryList: any;
export interface EvaluationContactLensAnswerAnalysisDetails {
    MatchedRuleCategories?: EvaluationAutomationRuleCategory[];
}
export declare const EvaluationContactLensAnswerAnalysisDetails: S.Schema<EvaluationContactLensAnswerAnalysisDetails>;
export type EvaluationQuestionAnswerAnalysisDetails = {
    GenAI: EvaluationGenAIAnswerAnalysisDetails;
    ContactLens?: never;
} | {
    GenAI?: never;
    ContactLens: EvaluationContactLensAnswerAnalysisDetails;
};
export declare const EvaluationQuestionAnswerAnalysisDetails: any;
export interface EvaluationSuggestedAnswer {
    Value?: EvaluationAnswerData;
    Status: EvaluationSuggestedAnswerStatus;
    Input?: EvaluationQuestionInputDetails;
    AnalysisType: EvaluationQuestionAnswerAnalysisType;
    AnalysisDetails?: EvaluationQuestionAnswerAnalysisDetails;
}
export declare const EvaluationSuggestedAnswer: S.Schema<EvaluationSuggestedAnswer>;
export type EvaluationSuggestedAnswersList = EvaluationSuggestedAnswer[];
export declare const EvaluationSuggestedAnswersList: any;
export interface EvaluationAnswerOutput {
    Value?: EvaluationAnswerData;
    SystemSuggestedValue?: EvaluationAnswerData;
    SuggestedAnswers?: EvaluationSuggestedAnswer[];
}
export declare const EvaluationAnswerOutput: S.Schema<EvaluationAnswerOutput>;
export type EvaluationAnswersOutputMap = {
    [key: string]: EvaluationAnswerOutput | undefined;
};
export declare const EvaluationAnswersOutputMap: any;
export type EvaluationNoteString = string;
export interface EvaluationNote {
    Value?: string;
}
export declare const EvaluationNote: S.Schema<EvaluationNote>;
export type EvaluationNotesMap = {
    [key: string]: EvaluationNote | undefined;
};
export declare const EvaluationNotesMap: any;
export type EvaluationStatus = "DRAFT" | "SUBMITTED" | "REVIEW_REQUESTED" | "UNDER_REVIEW" | (string & {});
export declare const EvaluationStatus: any;
export type EvaluationScoresMap = {
    [key: string]: EvaluationScore | undefined;
};
export declare const EvaluationScoresMap: any;
export type EvaluationType = "STANDARD" | "CALIBRATION" | (string & {});
export declare const EvaluationType: any;
export interface Evaluation {
    EvaluationId: string;
    EvaluationArn: string;
    Metadata: EvaluationMetadata;
    Answers: {
        [key: string]: EvaluationAnswerOutput | undefined;
    };
    Notes: {
        [key: string]: EvaluationNote | undefined;
    };
    Status: EvaluationStatus;
    Scores?: {
        [key: string]: EvaluationScore | undefined;
    };
    CreatedTime: Date;
    LastModifiedTime: Date;
    EvaluationType?: EvaluationType;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Evaluation: S.Schema<Evaluation>;
export interface EvaluationFormContent {
    EvaluationFormVersion: number;
    EvaluationFormId: string;
    EvaluationFormArn: string;
    Title: string;
    Description?: string;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
    ReviewConfiguration?: EvaluationReviewConfiguration;
}
export declare const EvaluationFormContent: S.Schema<EvaluationFormContent>;
export interface DescribeContactEvaluationResponse {
    Evaluation: Evaluation;
    EvaluationForm: EvaluationFormContent;
}
export declare const DescribeContactEvaluationResponse: S.Schema<DescribeContactEvaluationResponse>;
export interface DescribeContactFlowRequest {
    InstanceId: string;
    ContactFlowId: string;
}
export declare const DescribeContactFlowRequest: S.Schema<DescribeContactFlowRequest>;
export type ContactFlowState = "ACTIVE" | "ARCHIVED" | (string & {});
export declare const ContactFlowState: any;
export interface ContactFlow {
    Arn?: string;
    Id?: string;
    Name?: string;
    Type?: ContactFlowType;
    State?: ContactFlowState;
    Status?: ContactFlowStatus;
    Description?: string;
    Content?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    FlowContentSha256?: string;
    Version?: number;
    VersionDescription?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ContactFlow: S.Schema<ContactFlow>;
export interface DescribeContactFlowResponse {
    ContactFlow?: ContactFlow;
}
export declare const DescribeContactFlowResponse: S.Schema<DescribeContactFlowResponse>;
export interface DescribeContactFlowModuleRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
}
export declare const DescribeContactFlowModuleRequest: S.Schema<DescribeContactFlowModuleRequest>;
export type ContactFlowModuleState = "ACTIVE" | "ARCHIVED" | (string & {});
export declare const ContactFlowModuleState: any;
export type ContactFlowModuleStatus = "PUBLISHED" | "SAVED" | (string & {});
export declare const ContactFlowModuleStatus: any;
export interface ContactFlowModule {
    Arn?: string;
    Id?: string;
    Name?: string;
    Content?: string;
    Description?: string;
    State?: ContactFlowModuleState;
    Status?: ContactFlowModuleStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    FlowModuleContentSha256?: string;
    Version?: number;
    VersionDescription?: string;
    Settings?: string;
    ExternalInvocationConfiguration?: ExternalInvocationConfiguration;
}
export declare const ContactFlowModule: S.Schema<ContactFlowModule>;
export interface DescribeContactFlowModuleResponse {
    ContactFlowModule?: ContactFlowModule;
}
export declare const DescribeContactFlowModuleResponse: S.Schema<DescribeContactFlowModuleResponse>;
export interface DescribeContactFlowModuleAliasRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    AliasId: string;
}
export declare const DescribeContactFlowModuleAliasRequest: S.Schema<DescribeContactFlowModuleAliasRequest>;
export interface ContactFlowModuleAliasInfo {
    ContactFlowModuleId?: string;
    ContactFlowModuleArn?: string;
    AliasId?: string;
    Version?: number;
    Name?: string;
    Description?: string;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
}
export declare const ContactFlowModuleAliasInfo: S.Schema<ContactFlowModuleAliasInfo>;
export interface DescribeContactFlowModuleAliasResponse {
    ContactFlowModuleAlias?: ContactFlowModuleAliasInfo;
}
export declare const DescribeContactFlowModuleAliasResponse: S.Schema<DescribeContactFlowModuleAliasResponse>;
export interface DescribeDataTableRequest {
    InstanceId: string;
    DataTableId: string;
}
export declare const DescribeDataTableRequest: S.Schema<DescribeDataTableRequest>;
export type DataTableVersion = string;
export interface DataTable {
    Name: string;
    Id: string;
    Arn: string;
    TimeZone: string;
    Description?: string;
    ValueLockLevel?: DataTableLockLevel;
    LockVersion?: DataTableLockVersion;
    Version?: string;
    VersionDescription?: string;
    Status?: DataTableStatus;
    CreatedTime?: Date;
    LastModifiedTime: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DataTable: S.Schema<DataTable>;
export interface DescribeDataTableResponse {
    DataTable: DataTable;
}
export declare const DescribeDataTableResponse: S.Schema<DescribeDataTableResponse>;
export interface DescribeDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeName: string;
}
export declare const DescribeDataTableAttributeRequest: S.Schema<DescribeDataTableAttributeRequest>;
export interface DataTableAttribute {
    AttributeId?: string;
    Name: string;
    ValueType: DataTableAttributeValueType;
    Description?: string;
    DataTableId?: string;
    DataTableArn?: string;
    Primary?: boolean;
    Version?: string;
    LockVersion?: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    Validation?: Validation;
}
export declare const DataTableAttribute: S.Schema<DataTableAttribute>;
export interface DescribeDataTableAttributeResponse {
    Attribute: DataTableAttribute;
}
export declare const DescribeDataTableAttributeResponse: S.Schema<DescribeDataTableAttributeResponse>;
export interface DescribeEmailAddressRequest {
    InstanceId: string;
    EmailAddressId: string;
}
export declare const DescribeEmailAddressRequest: S.Schema<DescribeEmailAddressRequest>;
export type AliasConfigurationList = AliasConfiguration[];
export declare const AliasConfigurationList: any;
export interface DescribeEmailAddressResponse {
    EmailAddressId?: string;
    EmailAddressArn?: string;
    EmailAddress?: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    CreateTimestamp?: string;
    ModifiedTimestamp?: string;
    AliasConfigurations?: AliasConfiguration[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeEmailAddressResponse: S.Schema<DescribeEmailAddressResponse>;
export interface DescribeEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion?: number;
}
export declare const DescribeEvaluationFormRequest: S.Schema<DescribeEvaluationFormRequest>;
export type EvaluationFormVersionIsLocked = boolean;
export type EvaluationFormVersionStatus = "DRAFT" | "ACTIVE" | (string & {});
export declare const EvaluationFormVersionStatus: any;
export type EvaluationFormValidationStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export declare const EvaluationFormValidationStatus: any;
export interface EvaluationForm {
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    Locked: boolean;
    EvaluationFormArn: string;
    Title: string;
    Description?: string;
    Status: EvaluationFormVersionStatus;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    ReviewConfiguration?: EvaluationReviewConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
    LatestValidationStatus?: EvaluationFormValidationStatus;
    LastValidationTime?: Date;
}
export declare const EvaluationForm: S.Schema<EvaluationForm>;
export interface DescribeEvaluationFormResponse {
    EvaluationForm: EvaluationForm;
}
export declare const DescribeEvaluationFormResponse: S.Schema<DescribeEvaluationFormResponse>;
export interface DescribeExtractionDefinitionRequest {
    InstanceId: string;
    ExtractionDefinitionId: string;
}
export declare const DescribeExtractionDefinitionRequest: S.Schema<DescribeExtractionDefinitionRequest>;
export interface ExtractionDefinition {
    Name: string;
    ExtractionDefinitionId: string;
    ExtractionDefinitionArn: string;
    ExtractionConfiguration: ExtractionConfiguration;
    Display?: ExtractionDefinitionDisplay;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ExtractionDefinition: S.Schema<ExtractionDefinition>;
export interface DescribeExtractionDefinitionResponse {
    ExtractionDefinition: ExtractionDefinition;
}
export declare const DescribeExtractionDefinitionResponse: S.Schema<DescribeExtractionDefinitionResponse>;
export interface DescribeHoursOfOperationRequest {
    InstanceId: string;
    HoursOfOperationId: string;
}
export declare const DescribeHoursOfOperationRequest: S.Schema<DescribeHoursOfOperationRequest>;
export interface HoursOfOperationsIdentifier {
    Name: string;
    Id: string;
    Arn?: string;
}
export declare const HoursOfOperationsIdentifier: S.Schema<HoursOfOperationsIdentifier>;
export type ParentHoursOfOperationsList = HoursOfOperationsIdentifier[];
export declare const ParentHoursOfOperationsList: any;
export interface HoursOfOperation {
    HoursOfOperationId?: string;
    HoursOfOperationArn?: string;
    Name?: string;
    Description?: string;
    TimeZone?: string;
    Config?: HoursOfOperationConfig[];
    ParentHoursOfOperations?: HoursOfOperationsIdentifier[];
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const HoursOfOperation: S.Schema<HoursOfOperation>;
export interface DescribeHoursOfOperationResponse {
    HoursOfOperation?: HoursOfOperation;
}
export declare const DescribeHoursOfOperationResponse: S.Schema<DescribeHoursOfOperationResponse>;
export interface DescribeHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    HoursOfOperationOverrideId: string;
}
export declare const DescribeHoursOfOperationOverrideRequest: S.Schema<DescribeHoursOfOperationOverrideRequest>;
export interface HoursOfOperationOverride {
    HoursOfOperationOverrideId?: string;
    HoursOfOperationId?: string;
    HoursOfOperationArn?: string;
    Name?: string;
    Description?: string;
    Config?: HoursOfOperationOverrideConfig[];
    EffectiveFrom?: string;
    EffectiveTill?: string;
    RecurrenceConfig?: RecurrenceConfig;
    OverrideType?: OverrideType;
}
export declare const HoursOfOperationOverride: S.Schema<HoursOfOperationOverride>;
export interface DescribeHoursOfOperationOverrideResponse {
    HoursOfOperationOverride?: HoursOfOperationOverride;
}
export declare const DescribeHoursOfOperationOverrideResponse: S.Schema<DescribeHoursOfOperationOverrideResponse>;
export interface DescribeInstanceRequest {
    InstanceId: string;
}
export declare const DescribeInstanceRequest: S.Schema<DescribeInstanceRequest>;
export type InstanceStatus = "CREATION_IN_PROGRESS" | "ACTIVE" | "CREATION_FAILED" | (string & {});
export declare const InstanceStatus: any;
export interface InstanceStatusReason {
    Message?: string;
}
export declare const InstanceStatusReason: S.Schema<InstanceStatusReason>;
export type Url = string;
export interface Instance {
    Id?: string;
    Arn?: string;
    IdentityManagementType?: DirectoryType;
    InstanceAlias?: string | redacted.Redacted<string>;
    CreatedTime?: Date;
    ServiceRole?: string;
    InstanceStatus?: InstanceStatus;
    StatusReason?: InstanceStatusReason;
    InboundCallsEnabled?: boolean;
    OutboundCallsEnabled?: boolean;
    InstanceAccessUrl?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Instance: S.Schema<Instance>;
export type AwsRegion = string;
export type InstanceReplicationStatus = "INSTANCE_REPLICATION_COMPLETE" | "INSTANCE_REPLICATION_IN_PROGRESS" | "INSTANCE_REPLICATION_FAILED" | "INSTANCE_REPLICA_DELETING" | "INSTANCE_REPLICATION_DELETION_FAILED" | "RESOURCE_REPLICATION_NOT_STARTED" | (string & {});
export declare const InstanceReplicationStatus: any;
export type ReplicationStatusReason = string;
export interface ReplicationStatusSummary {
    Region?: string;
    ReplicationStatus?: InstanceReplicationStatus;
    ReplicationStatusReason?: string;
}
export declare const ReplicationStatusSummary: S.Schema<ReplicationStatusSummary>;
export type ReplicationStatusSummaryList = ReplicationStatusSummary[];
export declare const ReplicationStatusSummaryList: any;
export type GlobalSignInEndpoint = string;
export interface ReplicationConfiguration {
    ReplicationStatusSummaryList?: ReplicationStatusSummary[];
    SourceRegion?: string;
    GlobalSignInEndpoint?: string;
}
export declare const ReplicationConfiguration: S.Schema<ReplicationConfiguration>;
export interface DescribeInstanceResponse {
    Instance?: Instance;
    ReplicationConfiguration?: ReplicationConfiguration;
}
export declare const DescribeInstanceResponse: S.Schema<DescribeInstanceResponse>;
export type InstanceAttributeType = "INBOUND_CALLS" | "OUTBOUND_CALLS" | "CONTACTFLOW_LOGS" | "CONTACT_LENS" | "AUTO_RESOLVE_BEST_VOICES" | "USE_CUSTOM_TTS_VOICES" | "EARLY_MEDIA" | "MULTI_PARTY_CONFERENCE" | "HIGH_VOLUME_OUTBOUND" | "ENHANCED_CONTACT_MONITORING" | "ENHANCED_CHAT_MONITORING" | "MULTI_PARTY_CHAT_CONFERENCE" | "MESSAGE_STREAMING" | (string & {});
export declare const InstanceAttributeType: any;
export interface DescribeInstanceAttributeRequest {
    InstanceId: string;
    AttributeType: InstanceAttributeType;
}
export declare const DescribeInstanceAttributeRequest: S.Schema<DescribeInstanceAttributeRequest>;
export type InstanceAttributeValue = string;
export interface Attribute {
    AttributeType?: InstanceAttributeType;
    Value?: string;
}
export declare const Attribute: S.Schema<Attribute>;
export interface DescribeInstanceAttributeResponse {
    Attribute?: Attribute;
}
export declare const DescribeInstanceAttributeResponse: S.Schema<DescribeInstanceAttributeResponse>;
export interface DescribeInstanceStorageConfigRequest {
    InstanceId: string;
    AssociationId: string;
    ResourceType: InstanceStorageResourceType;
}
export declare const DescribeInstanceStorageConfigRequest: S.Schema<DescribeInstanceStorageConfigRequest>;
export interface DescribeInstanceStorageConfigResponse {
    StorageConfig?: InstanceStorageConfig;
}
export declare const DescribeInstanceStorageConfigResponse: S.Schema<DescribeInstanceStorageConfigResponse>;
export interface DescribeMetricRequest {
    InstanceId: string;
    MetricId: string;
}
export declare const DescribeMetricRequest: S.Schema<DescribeMetricRequest>;
export type MetricCreationMethod = "SERVICE_LEVEL_BUILDER" | "METRIC_BUILDER" | (string & {});
export declare const MetricCreationMethod: any;
export type MetricType = "AWS_MANAGED" | "CUSTOMER_MANAGED" | (string & {});
export declare const MetricType: any;
export type MetricGroupingList = string[];
export declare const MetricGroupingList: any;
export type FilterId = string;
export type AvailableFilterType = "METRIC_LEVEL" | "RESOURCE_LEVEL" | (string & {});
export declare const AvailableFilterType: any;
export interface AvailableFilter {
    Id?: string;
    Type?: AvailableFilterType;
}
export declare const AvailableFilter: S.Schema<AvailableFilter>;
export type AvailableFilterList = AvailableFilter[];
export declare const AvailableFilterList: any;
export type RefreshRate = number;
export type MetricCategory = string;
export type SupportedStatsList = string[];
export declare const SupportedStatsList: any;
export type DefaultStat = string;
export type SupportsPreaggregateCalculation = boolean;
export type SupportsCustomCalculation = boolean;
export type PrimaryEventSource = string;
export type PrimaryEventSourceEffectiveTimestampType = string;
export interface MetricDefinition {
    Arn: string;
    Id: string;
    Name: string;
    Description?: string;
    MetricCalculation?: MetricCalculation;
    CreationMethod?: MetricCreationMethod;
    Status?: MetricStatus;
    Type: MetricType;
    Unit: MetricUnit;
    PositiveTrendIndicator?: TrendIndicator;
    Groupings: string[];
    Filters: AvailableFilter[];
    EffectiveTime?: Date;
    RefreshRate?: number;
    Category: string;
    SupportedStats?: string[];
    DefaultStat?: string;
    SupportsPreaggregateCalculation: boolean;
    SupportsCustomCalculation: boolean;
    PrimaryEventSource?: string;
    PrimaryEventSourceEffectiveTimestampType?: string;
    CreatedTime?: Date;
    CreatedUser?: CreatedByInfo;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
    LastModifiedUser?: CreatedByInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const MetricDefinition: S.Schema<MetricDefinition>;
export interface DescribeMetricResponse {
    Metric: MetricDefinition;
}
export declare const DescribeMetricResponse: S.Schema<DescribeMetricResponse>;
export interface DescribeNotificationRequest {
    InstanceId: string;
    NotificationId: string;
}
export declare const DescribeNotificationRequest: S.Schema<DescribeNotificationRequest>;
export type NotificationPriority = "URGENT" | "HIGH" | "LOW" | (string & {});
export declare const NotificationPriority: any;
export interface Notification {
    Content?: {
        [key: string]: string | undefined;
    };
    Id: string;
    Arn: string;
    Priority?: NotificationPriority;
    Recipients?: string[];
    LastModifiedTime: Date;
    CreatedAt?: Date;
    ExpiresAt?: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Notification: S.Schema<Notification>;
export interface DescribeNotificationResponse {
    Notification: Notification;
}
export declare const DescribeNotificationResponse: S.Schema<DescribeNotificationResponse>;
export interface DescribePhoneNumberRequest {
    PhoneNumberId: string;
}
export declare const DescribePhoneNumberRequest: S.Schema<DescribePhoneNumberRequest>;
export type PhoneNumberCountryCode = "AF" | "AL" | "DZ" | "AS" | "AD" | "AO" | "AI" | "AQ" | "AG" | "AR" | "AM" | "AW" | "AU" | "AT" | "AZ" | "BS" | "BH" | "BD" | "BB" | "BY" | "BE" | "BZ" | "BJ" | "BM" | "BT" | "BO" | "BA" | "BW" | "BR" | "IO" | "VG" | "BN" | "BG" | "BF" | "BI" | "KH" | "CM" | "CA" | "CV" | "KY" | "CF" | "TD" | "CL" | "CN" | "CX" | "CC" | "CO" | "KM" | "CK" | "CR" | "HR" | "CU" | "CW" | "CY" | "CZ" | "CD" | "DK" | "DJ" | "DM" | "DO" | "TL" | "EC" | "EG" | "SV" | "GQ" | "ER" | "EE" | "ET" | "FK" | "FO" | "FJ" | "FI" | "FR" | "PF" | "GA" | "GM" | "GE" | "DE" | "GH" | "GI" | "GR" | "GL" | "GD" | "GU" | "GT" | "GG" | "GN" | "GW" | "GY" | "HT" | "HN" | "HK" | "HU" | "IS" | "IN" | "ID" | "IR" | "IQ" | "IE" | "IM" | "IL" | "IT" | "CI" | "JM" | "JP" | "JE" | "JO" | "KZ" | "KE" | "KI" | "KW" | "KG" | "LA" | "LV" | "LB" | "LS" | "LR" | "LY" | "LI" | "LT" | "LU" | "MO" | "MK" | "MG" | "MW" | "MY" | "MV" | "ML" | "MT" | "MH" | "MR" | "MU" | "YT" | "MX" | "FM" | "MD" | "MC" | "MN" | "ME" | "MS" | "MA" | "MZ" | "MM" | "NA" | "NR" | "NP" | "NL" | "AN" | "NC" | "NZ" | "NI" | "NE" | "NG" | "NU" | "KP" | "MP" | "NO" | "OM" | "PK" | "PW" | "PA" | "PG" | "PY" | "PE" | "PH" | "PN" | "PL" | "PT" | "PR" | "QA" | "CG" | "RE" | "RO" | "RU" | "RW" | "BL" | "SH" | "KN" | "LC" | "MF" | "PM" | "VC" | "WS" | "SM" | "ST" | "SA" | "SN" | "RS" | "SC" | "SL" | "SG" | "SX" | "SK" | "SI" | "SB" | "SO" | "ZA" | "KR" | "ES" | "LK" | "SD" | "SR" | "SJ" | "SZ" | "SE" | "CH" | "SY" | "TW" | "TJ" | "TZ" | "TH" | "TG" | "TK" | "TO" | "TT" | "TN" | "TR" | "TM" | "TC" | "TV" | "VI" | "UG" | "UA" | "AE" | "GB" | "US" | "UY" | "UZ" | "VU" | "VA" | "VE" | "VN" | "WF" | "EH" | "YE" | "ZM" | "ZW" | (string & {});
export declare const PhoneNumberCountryCode: any;
export type PhoneNumberType = "TOLL_FREE" | "DID" | "UIFN" | "SHARED" | "THIRD_PARTY_TF" | "THIRD_PARTY_DID" | "SHORT_CODE" | (string & {});
export declare const PhoneNumberType: any;
export type PhoneNumberWorkflowStatus = "CLAIMED" | "IN_PROGRESS" | "FAILED" | (string & {});
export declare const PhoneNumberWorkflowStatus: any;
export type PhoneNumberWorkflowMessage = string;
export interface PhoneNumberStatus {
    Status?: PhoneNumberWorkflowStatus;
    Message?: string;
}
export declare const PhoneNumberStatus: S.Schema<PhoneNumberStatus>;
export interface ClaimedPhoneNumberSummary {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
    PhoneNumber?: string;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
    PhoneNumberType?: PhoneNumberType;
    PhoneNumberDescription?: string;
    TargetArn?: string;
    InstanceId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    PhoneNumberStatus?: PhoneNumberStatus;
    SourcePhoneNumberArn?: string;
}
export declare const ClaimedPhoneNumberSummary: S.Schema<ClaimedPhoneNumberSummary>;
export interface DescribePhoneNumberResponse {
    ClaimedPhoneNumberSummary?: ClaimedPhoneNumberSummary;
}
export declare const DescribePhoneNumberResponse: S.Schema<DescribePhoneNumberResponse>;
export interface DescribePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
}
export declare const DescribePredefinedAttributeRequest: S.Schema<DescribePredefinedAttributeRequest>;
export type IsReadOnly = boolean;
export interface PredefinedAttributeConfiguration {
    EnableValueValidationOnAssociation?: boolean;
    IsReadOnly?: boolean;
}
export declare const PredefinedAttributeConfiguration: S.Schema<PredefinedAttributeConfiguration>;
export interface PredefinedAttribute {
    Name?: string;
    Values?: PredefinedAttributeValues;
    Purposes?: string[];
    AttributeConfiguration?: PredefinedAttributeConfiguration;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const PredefinedAttribute: S.Schema<PredefinedAttribute>;
export interface DescribePredefinedAttributeResponse {
    PredefinedAttribute?: PredefinedAttribute;
}
export declare const DescribePredefinedAttributeResponse: S.Schema<DescribePredefinedAttributeResponse>;
export interface DescribePromptRequest {
    InstanceId: string;
    PromptId: string;
}
export declare const DescribePromptRequest: S.Schema<DescribePromptRequest>;
export interface Prompt {
    PromptARN?: string;
    PromptId?: string;
    Name?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const Prompt: S.Schema<Prompt>;
export interface DescribePromptResponse {
    Prompt?: Prompt;
}
export declare const DescribePromptResponse: S.Schema<DescribePromptResponse>;
export interface DescribeQueueRequest {
    InstanceId: string;
    QueueId: string;
}
export declare const DescribeQueueRequest: S.Schema<DescribeQueueRequest>;
export type QueueStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const QueueStatus: any;
export interface Queue {
    Name?: string;
    QueueArn?: string;
    QueueId?: string;
    Description?: string;
    OutboundCallerConfig?: OutboundCallerConfig;
    OutboundEmailConfig?: OutboundEmailConfig;
    HoursOfOperationId?: string;
    MaxContacts?: number;
    Status?: QueueStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const Queue: S.Schema<Queue>;
export interface DescribeQueueResponse {
    Queue?: Queue;
}
export declare const DescribeQueueResponse: S.Schema<DescribeQueueResponse>;
export interface DescribeQuickConnectRequest {
    InstanceId: string;
    QuickConnectId: string;
}
export declare const DescribeQuickConnectRequest: S.Schema<DescribeQuickConnectRequest>;
export interface QuickConnect {
    QuickConnectARN?: string;
    QuickConnectId?: string;
    Name?: string;
    Description?: string;
    QuickConnectConfig?: QuickConnectConfig;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const QuickConnect: S.Schema<QuickConnect>;
export interface DescribeQuickConnectResponse {
    QuickConnect?: QuickConnect;
}
export declare const DescribeQuickConnectResponse: S.Schema<DescribeQuickConnectResponse>;
export interface DescribeRoutingProfileRequest {
    InstanceId: string;
    RoutingProfileId: string;
}
export declare const DescribeRoutingProfileRequest: S.Schema<DescribeRoutingProfileRequest>;
export type AssociatedQueueIdList = string[];
export declare const AssociatedQueueIdList: any;
export interface RoutingProfile {
    InstanceId?: string;
    Name?: string;
    RoutingProfileArn?: string;
    RoutingProfileId?: string;
    Description?: string;
    MediaConcurrencies?: MediaConcurrency[];
    DefaultOutboundQueueId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    NumberOfAssociatedQueues?: number;
    NumberOfAssociatedManualAssignmentQueues?: number;
    NumberOfAssociatedUsers?: number;
    AgentAvailabilityTimer?: AgentAvailabilityTimer;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    IsDefault?: boolean;
    AssociatedQueueIds?: string[];
    AssociatedManualAssignmentQueueIds?: string[];
}
export declare const RoutingProfile: S.Schema<RoutingProfile>;
export interface DescribeRoutingProfileResponse {
    RoutingProfile?: RoutingProfile;
}
export declare const DescribeRoutingProfileResponse: S.Schema<DescribeRoutingProfileResponse>;
export interface DescribeRuleRequest {
    InstanceId: string;
    RuleId: string;
}
export declare const DescribeRuleRequest: S.Schema<DescribeRuleRequest>;
export type RuleCapabilityTier = "GenerativeAI" | (string & {});
export declare const RuleCapabilityTier: any;
export type RuleCapabilityTiers = RuleCapabilityTier[];
export declare const RuleCapabilityTiers: any;
export interface Rule {
    Name: string;
    RuleId: string;
    RuleArn: string;
    TriggerEventSource: RuleTriggerEventSource;
    RuleCapabilityTiers?: RuleCapabilityTier[];
    Function: string;
    Actions: RuleAction[];
    PublishStatus: RulePublishStatus;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Rule: S.Schema<Rule>;
export interface DescribeRuleResponse {
    Rule: Rule;
}
export declare const DescribeRuleResponse: S.Schema<DescribeRuleResponse>;
export interface DescribeSecurityProfileRequest {
    SecurityProfileId: string;
    InstanceId: string;
}
export declare const DescribeSecurityProfileRequest: S.Schema<DescribeSecurityProfileRequest>;
export type SecurityProfileName = string;
export interface SecurityProfile {
    Id?: string;
    OrganizationResourceId?: string;
    Arn?: string;
    SecurityProfileName?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    AllowedAccessControlTags?: {
        [key: string]: string | undefined;
    };
    TagRestrictedResources?: string[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    HierarchyRestrictedResources?: string[];
    AllowedAccessControlHierarchyGroupId?: string;
    GranularAccessControlConfiguration?: GranularAccessControlConfiguration;
}
export declare const SecurityProfile: S.Schema<SecurityProfile>;
export interface DescribeSecurityProfileResponse {
    SecurityProfile?: SecurityProfile;
}
export declare const DescribeSecurityProfileResponse: S.Schema<DescribeSecurityProfileResponse>;
export interface DescribeTestCaseRequest {
    InstanceId: string;
    TestCaseId: string;
    Status?: TestCaseStatus;
}
export declare const DescribeTestCaseRequest: S.Schema<DescribeTestCaseRequest>;
export type TestCaseSha256 = string;
export interface TestCase {
    Arn?: string;
    Id?: string;
    Name?: string;
    Content?: string;
    EntryPoint?: TestCaseEntryPoint;
    InitializationData?: string;
    Description?: string;
    Status?: TestCaseStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    TestCaseSha256?: string;
}
export declare const TestCase: S.Schema<TestCase>;
export interface DescribeTestCaseResponse {
    TestCase?: TestCase;
}
export declare const DescribeTestCaseResponse: S.Schema<DescribeTestCaseResponse>;
export interface DescribeTrafficDistributionGroupRequest {
    TrafficDistributionGroupId: string;
}
export declare const DescribeTrafficDistributionGroupRequest: S.Schema<DescribeTrafficDistributionGroupRequest>;
export type InstanceArn = string;
export type TrafficDistributionGroupStatus = "CREATION_IN_PROGRESS" | "ACTIVE" | "CREATION_FAILED" | "PENDING_DELETION" | "DELETION_FAILED" | "UPDATE_IN_PROGRESS" | (string & {});
export declare const TrafficDistributionGroupStatus: any;
export interface TrafficDistributionGroup {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    InstanceArn?: string;
    Status?: TrafficDistributionGroupStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    IsDefault?: boolean;
}
export declare const TrafficDistributionGroup: S.Schema<TrafficDistributionGroup>;
export interface DescribeTrafficDistributionGroupResponse {
    TrafficDistributionGroup?: TrafficDistributionGroup;
}
export declare const DescribeTrafficDistributionGroupResponse: S.Schema<DescribeTrafficDistributionGroupResponse>;
export interface DescribeUserRequest {
    UserId: string;
    InstanceId: string;
}
export declare const DescribeUserRequest: S.Schema<DescribeUserRequest>;
export interface User {
    Id?: string;
    Arn?: string;
    Username?: string;
    IdentityInfo?: UserIdentityInfo;
    PhoneConfig?: UserPhoneConfig;
    DirectoryUserId?: string;
    SecurityProfileIds?: string[];
    RoutingProfileId?: string;
    HierarchyGroupId?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const User: S.Schema<User>;
export interface DescribeUserResponse {
    User?: User;
}
export declare const DescribeUserResponse: S.Schema<DescribeUserResponse>;
export interface DescribeUserHierarchyGroupRequest {
    HierarchyGroupId: string;
    InstanceId: string;
}
export declare const DescribeUserHierarchyGroupRequest: S.Schema<DescribeUserHierarchyGroupRequest>;
export type HierarchyLevelId = string;
export interface HierarchyGroupSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const HierarchyGroupSummary: S.Schema<HierarchyGroupSummary>;
export interface HierarchyPath {
    LevelOne?: HierarchyGroupSummary;
    LevelTwo?: HierarchyGroupSummary;
    LevelThree?: HierarchyGroupSummary;
    LevelFour?: HierarchyGroupSummary;
    LevelFive?: HierarchyGroupSummary;
}
export declare const HierarchyPath: S.Schema<HierarchyPath>;
export interface HierarchyGroup {
    Id?: string;
    Arn?: string;
    Name?: string;
    LevelId?: string;
    HierarchyPath?: HierarchyPath;
    Tags?: {
        [key: string]: string | undefined;
    };
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const HierarchyGroup: S.Schema<HierarchyGroup>;
export interface DescribeUserHierarchyGroupResponse {
    HierarchyGroup?: HierarchyGroup;
}
export declare const DescribeUserHierarchyGroupResponse: S.Schema<DescribeUserHierarchyGroupResponse>;
export interface DescribeUserHierarchyStructureRequest {
    InstanceId: string;
}
export declare const DescribeUserHierarchyStructureRequest: S.Schema<DescribeUserHierarchyStructureRequest>;
export type HierarchyLevelName = string;
export interface HierarchyLevel {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const HierarchyLevel: S.Schema<HierarchyLevel>;
export interface HierarchyStructure {
    LevelOne?: HierarchyLevel;
    LevelTwo?: HierarchyLevel;
    LevelThree?: HierarchyLevel;
    LevelFour?: HierarchyLevel;
    LevelFive?: HierarchyLevel;
}
export declare const HierarchyStructure: S.Schema<HierarchyStructure>;
export interface DescribeUserHierarchyStructureResponse {
    HierarchyStructure?: HierarchyStructure;
}
export declare const DescribeUserHierarchyStructureResponse: S.Schema<DescribeUserHierarchyStructureResponse>;
export interface DescribeViewRequest {
    InstanceId: string;
    ViewId: string;
}
export declare const DescribeViewRequest: S.Schema<DescribeViewRequest>;
export interface DescribeViewResponse {
    View?: View;
}
export declare const DescribeViewResponse: S.Schema<DescribeViewResponse>;
export interface DescribeVocabularyRequest {
    InstanceId: string;
    VocabularyId: string;
}
export declare const DescribeVocabularyRequest: S.Schema<DescribeVocabularyRequest>;
export type VocabularyLastModifiedTime = Date;
export type VocabularyFailureReason = string;
export interface Vocabulary {
    Name: string;
    Id: string;
    Arn: string;
    LanguageCode: VocabularyLanguageCode;
    State: VocabularyState;
    LastModifiedTime: Date;
    FailureReason?: string;
    Content?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Vocabulary: S.Schema<Vocabulary>;
export interface DescribeVocabularyResponse {
    Vocabulary: Vocabulary;
}
export declare const DescribeVocabularyResponse: S.Schema<DescribeVocabularyResponse>;
export interface DescribeWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
}
export declare const DescribeWorkspaceRequest: S.Schema<DescribeWorkspaceRequest>;
export type Visibility = "ALL" | "ASSIGNED" | "NONE" | (string & {});
export declare const Visibility: any;
export interface Workspace {
    Visibility?: Visibility;
    Id: string;
    Name: string;
    Arn: string;
    Description?: string;
    Theme?: WorkspaceTheme;
    Title?: string;
    LastModifiedTime: Date;
    LastModifiedRegion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Workspace: S.Schema<Workspace>;
export interface DescribeWorkspaceResponse {
    Workspace: Workspace;
}
export declare const DescribeWorkspaceResponse: S.Schema<DescribeWorkspaceResponse>;
export interface DisassociateAnalyticsDataSetRequest {
    InstanceId: string;
    DataSetId: string;
    TargetAccountId?: string;
}
export declare const DisassociateAnalyticsDataSetRequest: S.Schema<DisassociateAnalyticsDataSetRequest>;
export interface DisassociateAnalyticsDataSetResponse {
}
export declare const DisassociateAnalyticsDataSetResponse: S.Schema<DisassociateAnalyticsDataSetResponse>;
export interface DisassociateApprovedOriginRequest {
    InstanceId: string;
    Origin: string;
    ClientToken?: string;
}
export declare const DisassociateApprovedOriginRequest: S.Schema<DisassociateApprovedOriginRequest>;
export interface DisassociateApprovedOriginResponse {
}
export declare const DisassociateApprovedOriginResponse: S.Schema<DisassociateApprovedOriginResponse>;
export interface DisassociateBotRequest {
    InstanceId: string;
    LexBot?: LexBot;
    LexV2Bot?: LexV2Bot;
    ClientToken?: string;
}
export declare const DisassociateBotRequest: S.Schema<DisassociateBotRequest>;
export interface DisassociateBotResponse {
}
export declare const DisassociateBotResponse: S.Schema<DisassociateBotResponse>;
export interface DisassociateEmailAddressAliasRequest {
    EmailAddressId: string;
    InstanceId: string;
    AliasConfiguration: AliasConfiguration;
    ClientToken?: string;
}
export declare const DisassociateEmailAddressAliasRequest: S.Schema<DisassociateEmailAddressAliasRequest>;
export interface DisassociateEmailAddressAliasResponse {
}
export declare const DisassociateEmailAddressAliasResponse: S.Schema<DisassociateEmailAddressAliasResponse>;
export interface DisassociateFlowRequest {
    InstanceId: string;
    ResourceId: string;
    ResourceType: FlowAssociationResourceType;
}
export declare const DisassociateFlowRequest: S.Schema<DisassociateFlowRequest>;
export interface DisassociateFlowResponse {
}
export declare const DisassociateFlowResponse: S.Schema<DisassociateFlowResponse>;
export type ParentHoursOfOperationIdList = string[];
export declare const ParentHoursOfOperationIdList: any;
export interface DisassociateHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    ParentHoursOfOperationIds: string[];
}
export declare const DisassociateHoursOfOperationsRequest: S.Schema<DisassociateHoursOfOperationsRequest>;
export interface DisassociateHoursOfOperationsResponse {
}
export declare const DisassociateHoursOfOperationsResponse: S.Schema<DisassociateHoursOfOperationsResponse>;
export interface DisassociateInstanceStorageConfigRequest {
    InstanceId: string;
    AssociationId: string;
    ResourceType: InstanceStorageResourceType;
    ClientToken?: string;
}
export declare const DisassociateInstanceStorageConfigRequest: S.Schema<DisassociateInstanceStorageConfigRequest>;
export interface DisassociateInstanceStorageConfigResponse {
}
export declare const DisassociateInstanceStorageConfigResponse: S.Schema<DisassociateInstanceStorageConfigResponse>;
export interface DisassociateLambdaFunctionRequest {
    InstanceId: string;
    FunctionArn: string;
    ClientToken?: string;
}
export declare const DisassociateLambdaFunctionRequest: S.Schema<DisassociateLambdaFunctionRequest>;
export interface DisassociateLambdaFunctionResponse {
}
export declare const DisassociateLambdaFunctionResponse: S.Schema<DisassociateLambdaFunctionResponse>;
export interface DisassociateLexBotRequest {
    InstanceId: string;
    BotName: string;
    LexRegion: string;
    ClientToken?: string;
}
export declare const DisassociateLexBotRequest: S.Schema<DisassociateLexBotRequest>;
export interface DisassociateLexBotResponse {
}
export declare const DisassociateLexBotResponse: S.Schema<DisassociateLexBotResponse>;
export interface DisassociatePhoneNumberContactFlowRequest {
    PhoneNumberId: string;
    InstanceId: string;
}
export declare const DisassociatePhoneNumberContactFlowRequest: S.Schema<DisassociatePhoneNumberContactFlowRequest>;
export interface DisassociatePhoneNumberContactFlowResponse {
}
export declare const DisassociatePhoneNumberContactFlowResponse: S.Schema<DisassociatePhoneNumberContactFlowResponse>;
export type EmailAddressIdList = string[];
export declare const EmailAddressIdList: any;
export interface DisassociateQueueEmailAddressesRequest {
    InstanceId: string;
    QueueId: string;
    EmailAddressesId: string[];
    ClientToken?: string;
}
export declare const DisassociateQueueEmailAddressesRequest: S.Schema<DisassociateQueueEmailAddressesRequest>;
export interface DisassociateQueueEmailAddressesResponse {
}
export declare const DisassociateQueueEmailAddressesResponse: S.Schema<DisassociateQueueEmailAddressesResponse>;
export interface DisassociateQueueQuickConnectsRequest {
    InstanceId: string;
    QueueId: string;
    QuickConnectIds: string[];
}
export declare const DisassociateQueueQuickConnectsRequest: S.Schema<DisassociateQueueQuickConnectsRequest>;
export interface DisassociateQueueQuickConnectsResponse {
}
export declare const DisassociateQueueQuickConnectsResponse: S.Schema<DisassociateQueueQuickConnectsResponse>;
export type RoutingProfileQueueReferenceList = RoutingProfileQueueReference[];
export declare const RoutingProfileQueueReferenceList: any;
export interface DisassociateRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    QueueReferences?: RoutingProfileQueueReference[];
    ManualAssignmentQueueReferences?: RoutingProfileQueueReference[];
}
export declare const DisassociateRoutingProfileQueuesRequest: S.Schema<DisassociateRoutingProfileQueuesRequest>;
export interface DisassociateRoutingProfileQueuesResponse {
}
export declare const DisassociateRoutingProfileQueuesResponse: S.Schema<DisassociateRoutingProfileQueuesResponse>;
export interface DisassociateSecurityKeyRequest {
    InstanceId: string;
    AssociationId: string;
    ClientToken?: string;
}
export declare const DisassociateSecurityKeyRequest: S.Schema<DisassociateSecurityKeyRequest>;
export interface DisassociateSecurityKeyResponse {
}
export declare const DisassociateSecurityKeyResponse: S.Schema<DisassociateSecurityKeyResponse>;
export interface DisassociateSecurityProfilesRequest {
    InstanceId: string;
    SecurityProfiles: SecurityProfileItem[];
    EntityType: EntityType;
    EntityArn: string;
}
export declare const DisassociateSecurityProfilesRequest: S.Schema<DisassociateSecurityProfilesRequest>;
export interface DisassociateSecurityProfilesResponse {
}
export declare const DisassociateSecurityProfilesResponse: S.Schema<DisassociateSecurityProfilesResponse>;
export interface DisassociateTrafficDistributionGroupUserRequest {
    TrafficDistributionGroupId: string;
    UserId: string;
    InstanceId: string;
}
export declare const DisassociateTrafficDistributionGroupUserRequest: S.Schema<DisassociateTrafficDistributionGroupUserRequest>;
export interface DisassociateTrafficDistributionGroupUserResponse {
}
export declare const DisassociateTrafficDistributionGroupUserResponse: S.Schema<DisassociateTrafficDistributionGroupUserResponse>;
export interface UserProficiencyDisassociate {
    AttributeName: string;
    AttributeValue: string;
}
export declare const UserProficiencyDisassociate: S.Schema<UserProficiencyDisassociate>;
export type UserProficiencyDisassociateList = UserProficiencyDisassociate[];
export declare const UserProficiencyDisassociateList: any;
export interface DisassociateUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    UserProficiencies: UserProficiencyDisassociate[];
}
export declare const DisassociateUserProficienciesRequest: S.Schema<DisassociateUserProficienciesRequest>;
export interface DisassociateUserProficienciesResponse {
}
export declare const DisassociateUserProficienciesResponse: S.Schema<DisassociateUserProficienciesResponse>;
export interface DisassociateWorkspaceRequest {
    InstanceId: string;
    WorkspaceId: string;
    ResourceArns: string[];
}
export declare const DisassociateWorkspaceRequest: S.Schema<DisassociateWorkspaceRequest>;
export interface DisassociateWorkspaceResponse {
    SuccessfulList?: SuccessfulBatchAssociationSummary[];
    FailedList?: FailedBatchAssociationSummary[];
}
export declare const DisassociateWorkspaceResponse: S.Schema<DisassociateWorkspaceResponse>;
export interface DismissUserContactRequest {
    UserId: string;
    InstanceId: string;
    ContactId: string;
}
export declare const DismissUserContactRequest: S.Schema<DismissUserContactRequest>;
export interface DismissUserContactResponse {
}
export declare const DismissUserContactResponse: S.Schema<DismissUserContactResponse>;
export type AttributeNameList = string[];
export declare const AttributeNameList: any;
export interface DataTableValueEvaluationSet {
    PrimaryValues?: PrimaryValue[];
    AttributeNames: string[];
}
export declare const DataTableValueEvaluationSet: S.Schema<DataTableValueEvaluationSet>;
export type DataTableValueEvaluationSetList = DataTableValueEvaluationSet[];
export declare const DataTableValueEvaluationSetList: any;
export type NextToken = string;
export type MaxResult100 = number;
export interface EvaluateDataTableValuesRequest {
    InstanceId: string;
    DataTableId: string;
    Values: DataTableValueEvaluationSet[];
    TimeZone?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const EvaluateDataTableValuesRequest: S.Schema<EvaluateDataTableValuesRequest>;
export interface DataTableEvaluatedValue {
    RecordId: string;
    PrimaryValues: PrimaryValue[];
    AttributeName: string;
    ValueType: DataTableAttributeValueType;
    Found: boolean;
    Error: boolean;
    EvaluatedValue: string;
}
export declare const DataTableEvaluatedValue: S.Schema<DataTableEvaluatedValue>;
export type DataTableEvaluatedValueList = DataTableEvaluatedValue[];
export declare const DataTableEvaluatedValueList: any;
export interface EvaluateDataTableValuesResponse {
    Values: DataTableEvaluatedValue[];
    NextToken?: string;
}
export declare const EvaluateDataTableValuesResponse: S.Schema<EvaluateDataTableValuesResponse>;
export type URLExpiryInSeconds = number;
export interface GetAttachedFileRequest {
    InstanceId: string;
    FileId: string;
    UrlExpiryInSeconds?: number;
    AssociatedResourceArn: string;
}
export declare const GetAttachedFileRequest: S.Schema<GetAttachedFileRequest>;
export type MetadataUrl = string;
export interface DownloadUrlMetadata {
    Url?: string;
    UrlExpiry?: string;
}
export declare const DownloadUrlMetadata: S.Schema<DownloadUrlMetadata>;
export interface GetAttachedFileResponse {
    FileArn?: string;
    FileId?: string;
    CreationTime?: string;
    FileStatus?: FileStatusType;
    FileName?: string;
    FileSizeInBytes: number;
    AssociatedResourceArn?: string;
    FileUseCaseType?: FileUseCaseType;
    CreatedBy?: CreatedByInfo;
    DownloadUrlMetadata?: DownloadUrlMetadata;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetAttachedFileResponse: S.Schema<GetAttachedFileResponse>;
export interface GetContactAttributesRequest {
    InstanceId: string;
    InitialContactId: string;
}
export declare const GetContactAttributesRequest: S.Schema<GetContactAttributesRequest>;
export interface GetContactAttributesResponse {
    Attributes?: {
        [key: string]: string | undefined;
    };
}
export declare const GetContactAttributesResponse: S.Schema<GetContactAttributesResponse>;
export type ContactMetricName = "ESTIMATED_WAIT_TIME" | "POSITION_IN_QUEUE" | (string & {});
export declare const ContactMetricName: any;
export interface ContactMetricInfo {
    Name: ContactMetricName;
}
export declare const ContactMetricInfo: S.Schema<ContactMetricInfo>;
export type ContactMetrics = ContactMetricInfo[];
export declare const ContactMetrics: any;
export interface GetContactMetricsRequest {
    InstanceId: string;
    ContactId: string;
    Metrics: ContactMetricInfo[];
}
export declare const GetContactMetricsRequest: S.Schema<GetContactMetricsRequest>;
export type ContactMetricValue = {
    Number: number;
};
export declare const ContactMetricValue: any;
export interface ContactMetricResult {
    Name: ContactMetricName;
    Value: ContactMetricValue;
}
export declare const ContactMetricResult: S.Schema<ContactMetricResult>;
export type ContactMetricResults = ContactMetricResult[];
export declare const ContactMetricResults: any;
export interface GetContactMetricsResponse {
    MetricResults?: ContactMetricResult[];
    Id?: string;
    Arn?: string;
}
export declare const GetContactMetricsResponse: S.Schema<GetContactMetricsResponse>;
export type Queues = string[];
export declare const Queues: any;
export type Channels = Channel[];
export declare const Channels: any;
export type RoutingProfiles = string[];
export declare const RoutingProfiles: any;
export type RoutingExpression = string;
export type RoutingExpressions = string[];
export declare const RoutingExpressions: any;
export type AgentStatuses = string[];
export declare const AgentStatuses: any;
export type Subtype = string;
export type Subtypes = string[];
export declare const Subtypes: any;
export type ValidationTestType = string;
export type ValidationTestTypes = string[];
export declare const ValidationTestTypes: any;
export interface Filters {
    Queues?: string[];
    Channels?: Channel[];
    RoutingProfiles?: string[];
    RoutingStepExpressions?: string[];
    AgentStatuses?: string[];
    Subtypes?: string[];
    ValidationTestTypes?: string[];
}
export declare const Filters: S.Schema<Filters>;
export type Grouping = "QUEUE" | "CHANNEL" | "ROUTING_PROFILE" | "ROUTING_STEP_EXPRESSION" | "AGENT_STATUS" | "SUBTYPE" | "VALIDATION_TEST_TYPE" | (string & {});
export declare const Grouping: any;
export type Groupings = Grouping[];
export declare const Groupings: any;
export type CurrentMetricName = "AGENTS_ONLINE" | "AGENTS_AVAILABLE" | "AGENTS_ON_CALL" | "AGENTS_NON_PRODUCTIVE" | "AGENTS_AFTER_CONTACT_WORK" | "AGENTS_ERROR" | "AGENTS_STAFFED" | "CONTACTS_IN_QUEUE" | "OLDEST_CONTACT_AGE" | "CONTACTS_SCHEDULED" | "AGENTS_ON_CONTACT" | "SLOTS_ACTIVE" | "SLOTS_AVAILABLE" | "ESTIMATED_WAIT_TIME" | (string & {});
export declare const CurrentMetricName: any;
export type CurrentMetricId = string;
export type Unit = "SECONDS" | "COUNT" | "PERCENT" | (string & {});
export declare const Unit: any;
export interface CurrentMetric {
    Name?: CurrentMetricName;
    MetricId?: string;
    Unit?: Unit;
}
export declare const CurrentMetric: S.Schema<CurrentMetric>;
export type CurrentMetrics = CurrentMetric[];
export declare const CurrentMetrics: any;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SortOrder: any;
export interface CurrentMetricSortCriteria {
    SortByMetric?: CurrentMetricName;
    SortOrder?: SortOrder;
}
export declare const CurrentMetricSortCriteria: S.Schema<CurrentMetricSortCriteria>;
export type CurrentMetricSortCriteriaMaxOne = CurrentMetricSortCriteria[];
export declare const CurrentMetricSortCriteriaMaxOne: any;
export interface GetCurrentMetricDataRequest {
    InstanceId: string;
    Filters: Filters;
    Groupings?: Grouping[];
    CurrentMetrics: CurrentMetric[];
    NextToken?: string;
    MaxResults?: number;
    SortCriteria?: CurrentMetricSortCriteria[];
}
export declare const GetCurrentMetricDataRequest: S.Schema<GetCurrentMetricDataRequest>;
export interface QueueReference {
    Id?: string;
    Arn?: string;
}
export declare const QueueReference: S.Schema<QueueReference>;
export interface RoutingProfileReference {
    Id?: string;
    Arn?: string;
}
export declare const RoutingProfileReference: S.Schema<RoutingProfileReference>;
export interface AgentStatusIdentifier {
    Arn?: string;
    Id?: string;
}
export declare const AgentStatusIdentifier: S.Schema<AgentStatusIdentifier>;
export interface Dimensions {
    Queue?: QueueReference;
    Channel?: Channel;
    RoutingProfile?: RoutingProfileReference;
    RoutingStepExpression?: string;
    AgentStatus?: AgentStatusIdentifier;
    Subtype?: string;
    ValidationTestType?: string;
}
export declare const Dimensions: S.Schema<Dimensions>;
export type Value = number;
export interface CurrentMetricData {
    Metric?: CurrentMetric;
    Value?: number;
}
export declare const CurrentMetricData: S.Schema<CurrentMetricData>;
export type CurrentMetricDataCollections = CurrentMetricData[];
export declare const CurrentMetricDataCollections: any;
export interface CurrentMetricResult {
    Dimensions?: Dimensions;
    Collections?: CurrentMetricData[];
}
export declare const CurrentMetricResult: S.Schema<CurrentMetricResult>;
export type CurrentMetricResults = CurrentMetricResult[];
export declare const CurrentMetricResults: any;
export type ApproximateTotalCount = number;
export interface GetCurrentMetricDataResponse {
    NextToken?: string;
    MetricResults?: CurrentMetricResult[];
    DataSnapshotTime?: Date;
    ApproximateTotalCount?: number;
}
export declare const GetCurrentMetricDataResponse: S.Schema<GetCurrentMetricDataResponse>;
export type ContactState = "INCOMING" | "PENDING" | "CONNECTING" | "CONNECTED" | "CONNECTED_ONHOLD" | "MISSED" | "ERROR" | "ENDED" | "REJECTED" | (string & {});
export declare const ContactState: any;
export type ContactStates = ContactState[];
export declare const ContactStates: any;
export interface ContactFilter {
    ContactStates?: ContactState[];
}
export declare const ContactFilter: S.Schema<ContactFilter>;
export type AgentsMinOneMaxHundred = string[];
export declare const AgentsMinOneMaxHundred: any;
export type UserDataHierarchyGroups = string[];
export declare const UserDataHierarchyGroups: any;
export interface UserDataFilters {
    Queues?: string[];
    ContactFilter?: ContactFilter;
    RoutingProfiles?: string[];
    Agents?: string[];
    UserHierarchyGroups?: string[];
}
export declare const UserDataFilters: S.Schema<UserDataFilters>;
export interface GetCurrentUserDataRequest {
    InstanceId: string;
    Filters: UserDataFilters;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetCurrentUserDataRequest: S.Schema<GetCurrentUserDataRequest>;
export interface UserReference {
    Id?: string;
    Arn?: string;
}
export declare const UserReference: S.Schema<UserReference>;
export interface HierarchyGroupSummaryReference {
    Id?: string;
    Arn?: string;
}
export declare const HierarchyGroupSummaryReference: S.Schema<HierarchyGroupSummaryReference>;
export interface HierarchyPathReference {
    LevelOne?: HierarchyGroupSummaryReference;
    LevelTwo?: HierarchyGroupSummaryReference;
    LevelThree?: HierarchyGroupSummaryReference;
    LevelFour?: HierarchyGroupSummaryReference;
    LevelFive?: HierarchyGroupSummaryReference;
}
export declare const HierarchyPathReference: S.Schema<HierarchyPathReference>;
export interface AgentStatusReference {
    StatusStartTimestamp?: Date;
    StatusArn?: string;
    StatusName?: string;
}
export declare const AgentStatusReference: S.Schema<AgentStatusReference>;
export type IntegerCount = number;
export type ChannelToCountMap = {
    [key in Channel]?: number;
};
export declare const ChannelToCountMap: any;
export interface AgentContactReference {
    ContactId?: string;
    Channel?: Channel;
    InitiationMethod?: ContactInitiationMethod;
    AgentContactState?: ContactState;
    StateStartTimestamp?: Date;
    ConnectedToAgentTimestamp?: Date;
    Queue?: QueueReference;
}
export declare const AgentContactReference: S.Schema<AgentContactReference>;
export type AgentContactReferenceList = AgentContactReference[];
export declare const AgentContactReferenceList: any;
export interface UserData {
    User?: UserReference;
    RoutingProfile?: RoutingProfileReference;
    HierarchyPath?: HierarchyPathReference;
    Status?: AgentStatusReference;
    AvailableSlotsByChannel?: {
        [key: string]: number | undefined;
    };
    MaxSlotsByChannel?: {
        [key: string]: number | undefined;
    };
    ActiveSlotsByChannel?: {
        [key: string]: number | undefined;
    };
    Contacts?: AgentContactReference[];
    NextStatus?: string;
}
export declare const UserData: S.Schema<UserData>;
export type UserDataList = UserData[];
export declare const UserDataList: any;
export interface GetCurrentUserDataResponse {
    NextToken?: string;
    UserDataList?: UserData[];
    ApproximateTotalCount?: number;
}
export declare const GetCurrentUserDataResponse: S.Schema<GetCurrentUserDataResponse>;
export interface GetEffectiveHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    FromDate: string;
    ToDate: string;
}
export declare const GetEffectiveHoursOfOperationsRequest: S.Schema<GetEffectiveHoursOfOperationsRequest>;
export interface OperationalHour {
    Start?: OverrideTimeSlice;
    End?: OverrideTimeSlice;
}
export declare const OperationalHour: S.Schema<OperationalHour>;
export type OperationalHours = OperationalHour[];
export declare const OperationalHours: any;
export interface EffectiveHoursOfOperations {
    Date?: string;
    OperationalHours?: OperationalHour[];
}
export declare const EffectiveHoursOfOperations: S.Schema<EffectiveHoursOfOperations>;
export type EffectiveHoursOfOperationList = EffectiveHoursOfOperations[];
export declare const EffectiveHoursOfOperationList: any;
export type OperationalStatus = "OPEN" | "CLOSED" | (string & {});
export declare const OperationalStatus: any;
export interface OverrideHour {
    Start?: OverrideTimeSlice;
    End?: OverrideTimeSlice;
    OverrideName?: string;
    OperationalStatus?: OperationalStatus;
}
export declare const OverrideHour: S.Schema<OverrideHour>;
export type OverrideHours = OverrideHour[];
export declare const OverrideHours: any;
export interface EffectiveOverrideHours {
    Date?: string;
    OverrideHours?: OverrideHour[];
}
export declare const EffectiveOverrideHours: S.Schema<EffectiveOverrideHours>;
export type EffectiveOverrideHoursList = EffectiveOverrideHours[];
export declare const EffectiveOverrideHoursList: any;
export interface GetEffectiveHoursOfOperationsResponse {
    EffectiveHoursOfOperationList?: EffectiveHoursOfOperations[];
    EffectiveOverrideHoursList?: EffectiveOverrideHours[];
    TimeZone?: string;
}
export declare const GetEffectiveHoursOfOperationsResponse: S.Schema<GetEffectiveHoursOfOperationsResponse>;
export interface GetEvaluationFormValidationRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion?: number;
}
export declare const GetEvaluationFormValidationRequest: S.Schema<GetEvaluationFormValidationRequest>;
export type EvaluationFormValidationFailureReason = string;
export type EvaluationFormValidationIssueCode = string;
export type EvaluationFormValidationFindingItemProperty = string;
export interface EvaluationFormValidationFindingItem {
    RefId?: string;
    Property?: string;
}
export declare const EvaluationFormValidationFindingItem: S.Schema<EvaluationFormValidationFindingItem>;
export type EvaluationFormValidationFindingItemList = EvaluationFormValidationFindingItem[];
export declare const EvaluationFormValidationFindingItemList: any;
export type EvaluationFormValidationFindingDescription = string;
export type EvaluationFormValidationFindingSuggestion = string;
export type EvaluationFormValidationFindingSeverity = "WARNING" | "ERROR" | (string & {});
export declare const EvaluationFormValidationFindingSeverity: any;
export interface EvaluationFormValidationFinding {
    IssueCode: string;
    Items?: EvaluationFormValidationFindingItem[];
    Description: string;
    Suggestion?: string;
    Severity: EvaluationFormValidationFindingSeverity;
}
export declare const EvaluationFormValidationFinding: S.Schema<EvaluationFormValidationFinding>;
export type EvaluationFormValidationFindingList = EvaluationFormValidationFinding[];
export declare const EvaluationFormValidationFindingList: any;
export interface GetEvaluationFormValidationResponse {
    Status: EvaluationFormValidationStatus;
    FailureReason?: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    StartedTime: Date;
    Findings?: EvaluationFormValidationFinding[];
}
export declare const GetEvaluationFormValidationResponse: S.Schema<GetEvaluationFormValidationResponse>;
export interface GetFederationTokenRequest {
    InstanceId: string;
}
export declare const GetFederationTokenRequest: S.Schema<GetFederationTokenRequest>;
export type SecurityToken = string | redacted.Redacted<string>;
export interface Credentials {
    AccessToken?: string | redacted.Redacted<string>;
    AccessTokenExpiration?: Date;
    RefreshToken?: string | redacted.Redacted<string>;
    RefreshTokenExpiration?: Date;
}
export declare const Credentials: S.Schema<Credentials>;
export interface GetFederationTokenResponse {
    UserId?: string;
    UserArn?: string;
    Credentials?: Credentials;
    SignInUrl?: string;
}
export declare const GetFederationTokenResponse: S.Schema<GetFederationTokenResponse>;
export interface GetFlowAssociationRequest {
    InstanceId: string;
    ResourceId: string;
    ResourceType: FlowAssociationResourceType;
}
export declare const GetFlowAssociationRequest: S.Schema<GetFlowAssociationRequest>;
export interface GetFlowAssociationResponse {
    ResourceId?: string;
    FlowId?: string;
    ResourceType?: FlowAssociationResourceType;
}
export declare const GetFlowAssociationResponse: S.Schema<GetFlowAssociationResponse>;
export type HistoricalMetricName = "CONTACTS_QUEUED" | "CONTACTS_HANDLED" | "CONTACTS_ABANDONED" | "CONTACTS_CONSULTED" | "CONTACTS_AGENT_HUNG_UP_FIRST" | "CONTACTS_HANDLED_INCOMING" | "CONTACTS_HANDLED_OUTBOUND" | "CONTACTS_HOLD_ABANDONS" | "CONTACTS_TRANSFERRED_IN" | "CONTACTS_TRANSFERRED_OUT" | "CONTACTS_TRANSFERRED_IN_FROM_QUEUE" | "CONTACTS_TRANSFERRED_OUT_FROM_QUEUE" | "CONTACTS_MISSED" | "CALLBACK_CONTACTS_HANDLED" | "API_CONTACTS_HANDLED" | "OCCUPANCY" | "HANDLE_TIME" | "AFTER_CONTACT_WORK_TIME" | "QUEUED_TIME" | "ABANDON_TIME" | "QUEUE_ANSWER_TIME" | "HOLD_TIME" | "INTERACTION_TIME" | "INTERACTION_AND_HOLD_TIME" | "SERVICE_LEVEL" | (string & {});
export declare const HistoricalMetricName: any;
export type Comparison = "LT" | (string & {});
export declare const Comparison: any;
export type ThresholdValue = number;
export interface Threshold {
    Comparison?: Comparison;
    ThresholdValue?: number;
}
export declare const Threshold: S.Schema<Threshold>;
export type Statistic = "SUM" | "MAX" | "AVG" | (string & {});
export declare const Statistic: any;
export interface HistoricalMetric {
    Name?: HistoricalMetricName;
    Threshold?: Threshold;
    Statistic?: Statistic;
    Unit?: Unit;
}
export declare const HistoricalMetric: S.Schema<HistoricalMetric>;
export type HistoricalMetrics = HistoricalMetric[];
export declare const HistoricalMetrics: any;
export interface GetMetricDataRequest {
    InstanceId: string;
    StartTime: Date;
    EndTime: Date;
    Filters: Filters;
    Groupings?: Grouping[];
    HistoricalMetrics: HistoricalMetric[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetMetricDataRequest: S.Schema<GetMetricDataRequest>;
export interface HistoricalMetricData {
    Metric?: HistoricalMetric;
    Value?: number;
}
export declare const HistoricalMetricData: S.Schema<HistoricalMetricData>;
export type HistoricalMetricDataCollections = HistoricalMetricData[];
export declare const HistoricalMetricDataCollections: any;
export interface HistoricalMetricResult {
    Dimensions?: Dimensions;
    Collections?: HistoricalMetricData[];
}
export declare const HistoricalMetricResult: S.Schema<HistoricalMetricResult>;
export type HistoricalMetricResults = HistoricalMetricResult[];
export declare const HistoricalMetricResults: any;
export interface GetMetricDataResponse {
    NextToken?: string;
    MetricResults?: HistoricalMetricResult[];
}
export declare const GetMetricDataResponse: S.Schema<GetMetricDataResponse>;
export type IntervalPeriod = "FIFTEEN_MIN" | "THIRTY_MIN" | "HOUR" | "DAY" | "WEEK" | "TOTAL" | (string & {});
export declare const IntervalPeriod: any;
export interface IntervalDetails {
    TimeZone?: string;
    IntervalPeriod?: IntervalPeriod;
}
export declare const IntervalDetails: S.Schema<IntervalDetails>;
export type ResourceArnOrId = string;
export type FilterValueList = string[];
export declare const FilterValueList: any;
export type FilterV2StringConditionComparisonOperator = "NOT_EXISTS" | (string & {});
export declare const FilterV2StringConditionComparisonOperator: any;
export interface FilterV2StringCondition {
    Comparison?: FilterV2StringConditionComparisonOperator;
}
export declare const FilterV2StringCondition: S.Schema<FilterV2StringCondition>;
export interface FilterV2 {
    FilterKey?: string;
    FilterValues?: string[];
    StringCondition?: FilterV2StringCondition;
}
export declare const FilterV2: S.Schema<FilterV2>;
export type FiltersV2List = FilterV2[];
export declare const FiltersV2List: any;
export type GroupingV2 = string;
export type GroupingsV2 = string[];
export declare const GroupingsV2: any;
export type MetricNameV2 = string;
export interface ThresholdV2 {
    Comparison?: string;
    ThresholdValue?: number;
}
export declare const ThresholdV2: S.Schema<ThresholdV2>;
export type ThresholdCollections = ThresholdV2[];
export declare const ThresholdCollections: any;
export type MetricFilterValueList = string[];
export declare const MetricFilterValueList: any;
export interface MetricFilterV2 {
    MetricFilterKey?: string;
    MetricFilterValues?: string[];
    Negate?: boolean;
}
export declare const MetricFilterV2: S.Schema<MetricFilterV2>;
export type MetricFiltersV2List = MetricFilterV2[];
export declare const MetricFiltersV2List: any;
export interface MetricV2 {
    Name?: string;
    Threshold?: ThresholdV2[];
    MetricId?: string;
    MetricFilters?: MetricFilterV2[];
}
export declare const MetricV2: S.Schema<MetricV2>;
export type MetricsV2 = MetricV2[];
export declare const MetricsV2: any;
export type NextToken2500 = string;
export interface GetMetricDataV2Request {
    ResourceArn: string;
    StartTime: Date;
    EndTime: Date;
    Interval?: IntervalDetails;
    Filters: FilterV2[];
    Groupings?: string[];
    Metrics: MetricV2[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetMetricDataV2Request: S.Schema<GetMetricDataV2Request>;
export type DimensionsV2Key = string;
export type DimensionsV2Value = string;
export type DimensionsV2Map = {
    [key: string]: string | undefined;
};
export declare const DimensionsV2Map: any;
export interface MetricInterval {
    Interval?: IntervalPeriod;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const MetricInterval: S.Schema<MetricInterval>;
export interface MetricDataV2 {
    Metric?: MetricV2;
    Value?: number;
}
export declare const MetricDataV2: S.Schema<MetricDataV2>;
export type MetricDataCollectionsV2 = MetricDataV2[];
export declare const MetricDataCollectionsV2: any;
export interface MetricResultV2 {
    Dimensions?: {
        [key: string]: string | undefined;
    };
    MetricInterval?: MetricInterval;
    Collections?: MetricDataV2[];
}
export declare const MetricResultV2: S.Schema<MetricResultV2>;
export type MetricResultsV2 = MetricResultV2[];
export declare const MetricResultsV2: any;
export interface GetMetricDataV2Response {
    NextToken?: string;
    MetricResults?: MetricResultV2[];
}
export declare const GetMetricDataV2Response: S.Schema<GetMetricDataV2Response>;
export interface GetPromptFileRequest {
    InstanceId: string;
    PromptId: string;
}
export declare const GetPromptFileRequest: S.Schema<GetPromptFileRequest>;
export type PromptPresignedUrl = string;
export interface GetPromptFileResponse {
    PromptPresignedUrl?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const GetPromptFileResponse: S.Schema<GetPromptFileResponse>;
export type SnapshotVersion = string;
export interface GetTaskTemplateRequest {
    InstanceId: string;
    TaskTemplateId: string;
    SnapshotVersion?: string;
}
export declare const GetTaskTemplateRequest: S.Schema<GetTaskTemplateRequest>;
export interface GetTaskTemplateResponse {
    InstanceId?: string;
    Id: string;
    Arn: string;
    Name: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Fields?: TaskTemplateField[];
    Status?: TaskTemplateStatus;
    LastModifiedTime?: Date;
    CreatedTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetTaskTemplateResponse: S.Schema<GetTaskTemplateResponse>;
export type TestCaseExecutionId = string;
export interface GetTestCaseExecutionSummaryRequest {
    InstanceId: string;
    TestCaseId: string;
    TestCaseExecutionId: string;
}
export declare const GetTestCaseExecutionSummaryRequest: S.Schema<GetTestCaseExecutionSummaryRequest>;
export type TestCaseExecutionStatus = "INITIATED" | "PASSED" | "FAILED" | "IN_PROGRESS" | "STOPPED" | (string & {});
export declare const TestCaseExecutionStatus: any;
export interface ObservationSummary {
    TotalObservations?: number;
    ObservationsPassed?: number;
    ObservationsFailed?: number;
}
export declare const ObservationSummary: S.Schema<ObservationSummary>;
export interface GetTestCaseExecutionSummaryResponse {
    StartTime?: Date;
    EndTime?: Date;
    Status?: TestCaseExecutionStatus;
    ObservationSummary?: ObservationSummary;
}
export declare const GetTestCaseExecutionSummaryResponse: S.Schema<GetTestCaseExecutionSummaryResponse>;
export interface GetTrafficDistributionRequest {
    Id: string;
}
export declare const GetTrafficDistributionRequest: S.Schema<GetTrafficDistributionRequest>;
export type Percentage = number;
export interface Distribution {
    Region: string;
    Percentage: number;
}
export declare const Distribution: S.Schema<Distribution>;
export type DistributionList = Distribution[];
export declare const DistributionList: any;
export interface TelephonyConfig {
    Distributions: Distribution[];
}
export declare const TelephonyConfig: S.Schema<TelephonyConfig>;
export interface SignInDistribution {
    Region: string;
    Enabled: boolean;
}
export declare const SignInDistribution: S.Schema<SignInDistribution>;
export type SignInDistributionList = SignInDistribution[];
export declare const SignInDistributionList: any;
export interface SignInConfig {
    Distributions: SignInDistribution[];
}
export declare const SignInConfig: S.Schema<SignInConfig>;
export interface AgentConfig {
    Distributions: Distribution[];
}
export declare const AgentConfig: S.Schema<AgentConfig>;
export interface GetTrafficDistributionResponse {
    TelephonyConfig?: TelephonyConfig;
    Id?: string;
    Arn?: string;
    SignInConfig?: SignInConfig;
    AgentConfig?: AgentConfig;
}
export declare const GetTrafficDistributionResponse: S.Schema<GetTrafficDistributionResponse>;
export interface ImportPhoneNumberRequest {
    InstanceId: string;
    SourcePhoneNumberArn: string;
    PhoneNumberDescription?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
}
export declare const ImportPhoneNumberRequest: S.Schema<ImportPhoneNumberRequest>;
export interface ImportPhoneNumberResponse {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
}
export declare const ImportPhoneNumberResponse: S.Schema<ImportPhoneNumberResponse>;
export type MediaSource = string;
export interface ImportWorkspaceMediaRequest {
    InstanceId: string;
    WorkspaceId: string;
    MediaType: MediaType;
    MediaSource: string;
}
export declare const ImportWorkspaceMediaRequest: S.Schema<ImportWorkspaceMediaRequest>;
export interface ImportWorkspaceMediaResponse {
}
export declare const ImportWorkspaceMediaResponse: S.Schema<ImportWorkspaceMediaResponse>;
export type MaxResult1000 = number;
export type AgentStatusTypes = AgentStatusType[];
export declare const AgentStatusTypes: any;
export interface ListAgentStatusRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    AgentStatusTypes?: AgentStatusType[];
}
export declare const ListAgentStatusRequest: S.Schema<ListAgentStatusRequest>;
export interface AgentStatusSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    Type?: AgentStatusType;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const AgentStatusSummary: S.Schema<AgentStatusSummary>;
export type AgentStatusSummaryList = AgentStatusSummary[];
export declare const AgentStatusSummaryList: any;
export interface ListAgentStatusResponse {
    NextToken?: string;
    AgentStatusSummaryList?: AgentStatusSummary[];
}
export declare const ListAgentStatusResponse: S.Schema<ListAgentStatusResponse>;
export interface ListAnalyticsDataAssociationsRequest {
    InstanceId: string;
    DataSetId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAnalyticsDataAssociationsRequest: S.Schema<ListAnalyticsDataAssociationsRequest>;
export interface ListAnalyticsDataAssociationsResponse {
    Results?: AnalyticsDataAssociationResult[];
    NextToken?: string;
}
export declare const ListAnalyticsDataAssociationsResponse: S.Schema<ListAnalyticsDataAssociationsResponse>;
export interface ListAnalyticsDataLakeDataSetsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAnalyticsDataLakeDataSetsRequest: S.Schema<ListAnalyticsDataLakeDataSetsRequest>;
export interface AnalyticsDataSetsResult {
    DataSetId?: string;
    DataSetName?: string;
}
export declare const AnalyticsDataSetsResult: S.Schema<AnalyticsDataSetsResult>;
export type AnalyticsDataSetsResults = AnalyticsDataSetsResult[];
export declare const AnalyticsDataSetsResults: any;
export interface ListAnalyticsDataLakeDataSetsResponse {
    Results?: AnalyticsDataSetsResult[];
    NextToken?: string;
}
export declare const ListAnalyticsDataLakeDataSetsResponse: S.Schema<ListAnalyticsDataLakeDataSetsResponse>;
export type MaxResult25 = number;
export interface ListApprovedOriginsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListApprovedOriginsRequest: S.Schema<ListApprovedOriginsRequest>;
export type OriginsList = string[];
export declare const OriginsList: any;
export interface ListApprovedOriginsResponse {
    Origins?: string[];
    NextToken?: string;
}
export declare const ListApprovedOriginsResponse: S.Schema<ListApprovedOriginsResponse>;
export type ListAssociatedContactsRequestMaxResults = number;
export interface ListAssociatedContactsRequest {
    InstanceId: string;
    ContactId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAssociatedContactsRequest: S.Schema<ListAssociatedContactsRequest>;
export interface AssociatedContactSummary {
    ContactId?: string;
    ContactArn?: string;
    InitiationTimestamp?: Date;
    DisconnectTimestamp?: Date;
    InitialContactId?: string;
    PreviousContactId?: string;
    RelatedContactId?: string;
    InitiationMethod?: ContactInitiationMethod;
    Channel?: Channel;
}
export declare const AssociatedContactSummary: S.Schema<AssociatedContactSummary>;
export type AssociatedContactSummaryList = AssociatedContactSummary[];
export declare const AssociatedContactSummaryList: any;
export interface ListAssociatedContactsResponse {
    ContactSummaryList?: AssociatedContactSummary[];
    NextToken?: string;
}
export declare const ListAssociatedContactsResponse: S.Schema<ListAssociatedContactsResponse>;
export interface ListAttachedFilesConfigurationsRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAttachedFilesConfigurationsRequest: S.Schema<ListAttachedFilesConfigurationsRequest>;
export interface AttachedFilesConfigurationSummary {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
}
export declare const AttachedFilesConfigurationSummary: S.Schema<AttachedFilesConfigurationSummary>;
export type AttachedFilesConfigurationSummaryList = AttachedFilesConfigurationSummary[];
export declare const AttachedFilesConfigurationSummaryList: any;
export interface ListAttachedFilesConfigurationsResponse {
    AttachedFilesConfigurations?: AttachedFilesConfigurationSummary[];
    NextToken?: string;
}
export declare const ListAttachedFilesConfigurationsResponse: S.Schema<ListAttachedFilesConfigurationsResponse>;
export interface ListAuthenticationProfilesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAuthenticationProfilesRequest: S.Schema<ListAuthenticationProfilesRequest>;
export interface AuthenticationProfileSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    IsDefault?: boolean;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const AuthenticationProfileSummary: S.Schema<AuthenticationProfileSummary>;
export type AuthenticationProfileSummaryList = AuthenticationProfileSummary[];
export declare const AuthenticationProfileSummaryList: any;
export interface ListAuthenticationProfilesResponse {
    AuthenticationProfileSummaryList?: AuthenticationProfileSummary[];
    NextToken?: string;
}
export declare const ListAuthenticationProfilesResponse: S.Schema<ListAuthenticationProfilesResponse>;
export type LexVersion = "V1" | "V2" | (string & {});
export declare const LexVersion: any;
export interface ListBotsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    LexVersion: LexVersion;
}
export declare const ListBotsRequest: S.Schema<ListBotsRequest>;
export interface LexBotConfig {
    LexBot?: LexBot;
    LexV2Bot?: LexV2Bot;
}
export declare const LexBotConfig: S.Schema<LexBotConfig>;
export type LexBotConfigList = LexBotConfig[];
export declare const LexBotConfigList: any;
export interface ListBotsResponse {
    LexBots?: LexBotConfig[];
    NextToken?: string;
}
export declare const ListBotsResponse: S.Schema<ListBotsResponse>;
export interface ListChildHoursOfOperationsRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListChildHoursOfOperationsRequest: S.Schema<ListChildHoursOfOperationsRequest>;
export type ChildHoursOfOperationsList = HoursOfOperationsIdentifier[];
export declare const ChildHoursOfOperationsList: any;
export interface ListChildHoursOfOperationsResponse {
    NextToken?: string;
    ChildHoursOfOperationsSummaryList?: HoursOfOperationsIdentifier[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListChildHoursOfOperationsResponse: S.Schema<ListChildHoursOfOperationsResponse>;
export interface ListContactEvaluationsRequest {
    InstanceId: string;
    ContactId: string;
    NextToken?: string;
}
export declare const ListContactEvaluationsRequest: S.Schema<ListContactEvaluationsRequest>;
export interface EvaluationAcknowledgementSummary {
    AcknowledgedTime?: Date;
    AcknowledgedBy?: string;
    AcknowledgerComment?: string;
}
export declare const EvaluationAcknowledgementSummary: S.Schema<EvaluationAcknowledgementSummary>;
export interface EvaluationSummary {
    EvaluationId: string;
    EvaluationArn: string;
    EvaluationFormTitle: string;
    EvaluationFormId: string;
    CalibrationSessionId?: string;
    Status: EvaluationStatus;
    AutoEvaluationEnabled?: boolean;
    AutoEvaluationStatus?: AutoEvaluationStatus;
    EvaluatorArn: string;
    Score?: EvaluationScore;
    Acknowledgement?: EvaluationAcknowledgementSummary;
    EvaluationType?: EvaluationType;
    CreatedTime: Date;
    LastModifiedTime: Date;
    ContactParticipant?: EvaluationContactParticipant;
}
export declare const EvaluationSummary: S.Schema<EvaluationSummary>;
export type EvaluationSummaryList = EvaluationSummary[];
export declare const EvaluationSummaryList: any;
export interface ListContactEvaluationsResponse {
    EvaluationSummaryList: EvaluationSummary[];
    NextToken?: string;
}
export declare const ListContactEvaluationsResponse: S.Schema<ListContactEvaluationsResponse>;
export interface ListContactFlowModuleAliasesRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListContactFlowModuleAliasesRequest: S.Schema<ListContactFlowModuleAliasesRequest>;
export interface ContactFlowModuleAliasSummary {
    Arn?: string;
    AliasId?: string;
    Version?: number;
    AliasName?: string;
    AliasDescription?: string;
    LastModifiedTime?: Date;
}
export declare const ContactFlowModuleAliasSummary: S.Schema<ContactFlowModuleAliasSummary>;
export type ContactFlowModuleAliasSummaryList = ContactFlowModuleAliasSummary[];
export declare const ContactFlowModuleAliasSummaryList: any;
export interface ListContactFlowModuleAliasesResponse {
    ContactFlowModuleAliasSummaryList?: ContactFlowModuleAliasSummary[];
    NextToken?: string;
}
export declare const ListContactFlowModuleAliasesResponse: S.Schema<ListContactFlowModuleAliasesResponse>;
export interface ListContactFlowModulesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    ContactFlowModuleState?: ContactFlowModuleState;
}
export declare const ListContactFlowModulesRequest: S.Schema<ListContactFlowModulesRequest>;
export interface ContactFlowModuleSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    State?: ContactFlowModuleState;
}
export declare const ContactFlowModuleSummary: S.Schema<ContactFlowModuleSummary>;
export type ContactFlowModulesSummaryList = ContactFlowModuleSummary[];
export declare const ContactFlowModulesSummaryList: any;
export interface ListContactFlowModulesResponse {
    ContactFlowModulesSummaryList?: ContactFlowModuleSummary[];
    NextToken?: string;
}
export declare const ListContactFlowModulesResponse: S.Schema<ListContactFlowModulesResponse>;
export interface ListContactFlowModuleVersionsRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListContactFlowModuleVersionsRequest: S.Schema<ListContactFlowModuleVersionsRequest>;
export interface ContactFlowModuleVersionSummary {
    Arn?: string;
    VersionDescription?: string;
    Version?: number;
}
export declare const ContactFlowModuleVersionSummary: S.Schema<ContactFlowModuleVersionSummary>;
export type ContactFlowModuleVersionSummaryList = ContactFlowModuleVersionSummary[];
export declare const ContactFlowModuleVersionSummaryList: any;
export interface ListContactFlowModuleVersionsResponse {
    ContactFlowModuleVersionSummaryList?: ContactFlowModuleVersionSummary[];
    NextToken?: string;
}
export declare const ListContactFlowModuleVersionsResponse: S.Schema<ListContactFlowModuleVersionsResponse>;
export type ContactFlowTypes = ContactFlowType[];
export declare const ContactFlowTypes: any;
export interface ListContactFlowsRequest {
    InstanceId: string;
    ContactFlowTypes?: ContactFlowType[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListContactFlowsRequest: S.Schema<ListContactFlowsRequest>;
export interface ContactFlowSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    ContactFlowType?: ContactFlowType;
    ContactFlowState?: ContactFlowState;
    ContactFlowStatus?: ContactFlowStatus;
}
export declare const ContactFlowSummary: S.Schema<ContactFlowSummary>;
export type ContactFlowSummaryList = ContactFlowSummary[];
export declare const ContactFlowSummaryList: any;
export interface ListContactFlowsResponse {
    ContactFlowSummaryList?: ContactFlowSummary[];
    NextToken?: string;
}
export declare const ListContactFlowsResponse: S.Schema<ListContactFlowsResponse>;
export interface ListContactFlowVersionsRequest {
    InstanceId: string;
    ContactFlowId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListContactFlowVersionsRequest: S.Schema<ListContactFlowVersionsRequest>;
export interface ContactFlowVersionSummary {
    Arn?: string;
    VersionDescription?: string;
    Version?: number;
}
export declare const ContactFlowVersionSummary: S.Schema<ContactFlowVersionSummary>;
export type ContactFlowVersionSummaryList = ContactFlowVersionSummary[];
export declare const ContactFlowVersionSummaryList: any;
export interface ListContactFlowVersionsResponse {
    ContactFlowVersionSummaryList?: ContactFlowVersionSummary[];
    NextToken?: string;
}
export declare const ListContactFlowVersionsResponse: S.Schema<ListContactFlowVersionsResponse>;
export type ReferenceTypes = ReferenceType[];
export declare const ReferenceTypes: any;
export interface ListContactReferencesRequest {
    InstanceId: string;
    ContactId: string;
    ReferenceTypes: ReferenceType[];
    NextToken?: string;
}
export declare const ListContactReferencesRequest: S.Schema<ListContactReferencesRequest>;
export interface UrlReference {
    Name?: string;
    Value?: string;
}
export declare const UrlReference: S.Schema<UrlReference>;
export interface AttachmentReference {
    Name?: string;
    Value?: string;
    Status?: ReferenceStatus;
    Arn?: string;
}
export declare const AttachmentReference: S.Schema<AttachmentReference>;
export interface EmailMessageReference {
    Name?: string;
    Arn?: string;
}
export declare const EmailMessageReference: S.Schema<EmailMessageReference>;
export interface StringReference {
    Name?: string;
    Value?: string;
}
export declare const StringReference: S.Schema<StringReference>;
export interface NumberReference {
    Name?: string;
    Value?: string;
}
export declare const NumberReference: S.Schema<NumberReference>;
export interface DateReference {
    Name?: string;
    Value?: string;
}
export declare const DateReference: S.Schema<DateReference>;
export interface EmailReference {
    Name?: string;
    Value?: string;
}
export declare const EmailReference: S.Schema<EmailReference>;
export type ReferenceSummary = {
    Url: UrlReference;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment: AttachmentReference;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage: EmailMessageReference;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted: EmailMessageReference;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText: EmailMessageReference;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted: EmailMessageReference;
    String?: never;
    Number?: never;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String: StringReference;
    Number?: never;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number: NumberReference;
    Date?: never;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date: DateReference;
    Email?: never;
} | {
    Url?: never;
    Attachment?: never;
    EmailMessage?: never;
    EmailMessageRedacted?: never;
    EmailMessagePlainText?: never;
    EmailMessagePlainTextRedacted?: never;
    String?: never;
    Number?: never;
    Date?: never;
    Email: EmailReference;
};
export declare const ReferenceSummary: any;
export type ReferenceSummaryList = ReferenceSummary[];
export declare const ReferenceSummaryList: any;
export interface ListContactReferencesResponse {
    ReferenceSummaryList?: ReferenceSummary[];
    NextToken?: string;
}
export declare const ListContactReferencesResponse: S.Schema<ListContactReferencesResponse>;
export type AttributeIds = string[];
export declare const AttributeIds: any;
export interface ListDataTableAttributesRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeIds?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataTableAttributesRequest: S.Schema<ListDataTableAttributesRequest>;
export type AttributeList = DataTableAttribute[];
export declare const AttributeList: any;
export interface ListDataTableAttributesResponse {
    NextToken?: string;
    Attributes: DataTableAttribute[];
}
export declare const ListDataTableAttributesResponse: S.Schema<ListDataTableAttributesResponse>;
export type RecordIds = string[];
export declare const RecordIds: any;
export type ValueList = string[];
export declare const ValueList: any;
export interface PrimaryAttributeValueFilter {
    AttributeName: string;
    Values: string[];
}
export declare const PrimaryAttributeValueFilter: S.Schema<PrimaryAttributeValueFilter>;
export type PrimaryAttributeValueFilters = PrimaryAttributeValueFilter[];
export declare const PrimaryAttributeValueFilters: any;
export interface ListDataTablePrimaryValuesRequest {
    InstanceId: string;
    DataTableId: string;
    RecordIds?: string[];
    PrimaryAttributeValues?: PrimaryAttributeValueFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataTablePrimaryValuesRequest: S.Schema<ListDataTablePrimaryValuesRequest>;
export interface RecordPrimaryValue {
    RecordId?: string;
    PrimaryValues?: PrimaryValueResponse[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const RecordPrimaryValue: S.Schema<RecordPrimaryValue>;
export type PrimaryValuesList = RecordPrimaryValue[];
export declare const PrimaryValuesList: any;
export interface ListDataTablePrimaryValuesResponse {
    NextToken?: string;
    PrimaryValuesList: RecordPrimaryValue[];
}
export declare const ListDataTablePrimaryValuesResponse: S.Schema<ListDataTablePrimaryValuesResponse>;
export interface ListDataTablesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataTablesRequest: S.Schema<ListDataTablesRequest>;
export interface DataTableSummary {
    Name?: string;
    Id?: string;
    Arn?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const DataTableSummary: S.Schema<DataTableSummary>;
export type DataTableSummaryList = DataTableSummary[];
export declare const DataTableSummaryList: any;
export interface ListDataTablesResponse {
    NextToken?: string;
    DataTableSummaryList: DataTableSummary[];
}
export declare const ListDataTablesResponse: S.Schema<ListDataTablesResponse>;
export interface ListDataTableValuesRequest {
    InstanceId: string;
    DataTableId: string;
    RecordIds?: string[];
    PrimaryAttributeValues?: PrimaryAttributeValueFilter[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataTableValuesRequest: S.Schema<ListDataTableValuesRequest>;
export interface DataTableValueSummary {
    RecordId?: string;
    AttributeId?: string;
    PrimaryValues: PrimaryValueResponse[];
    AttributeName: string;
    ValueType: DataTableAttributeValueType;
    Value: string;
    LockVersion?: DataTableLockVersion;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const DataTableValueSummary: S.Schema<DataTableValueSummary>;
export type DataTableValueSummaryList = DataTableValueSummary[];
export declare const DataTableValueSummaryList: any;
export interface ListDataTableValuesResponse {
    NextToken?: string;
    Values: DataTableValueSummary[];
}
export declare const ListDataTableValuesResponse: S.Schema<ListDataTableValuesResponse>;
export type VocabularyNextToken = string;
export interface ListDefaultVocabulariesRequest {
    InstanceId: string;
    LanguageCode?: VocabularyLanguageCode;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDefaultVocabulariesRequest: S.Schema<ListDefaultVocabulariesRequest>;
export interface DefaultVocabulary {
    InstanceId: string;
    LanguageCode: VocabularyLanguageCode;
    VocabularyId: string;
    VocabularyName: string;
}
export declare const DefaultVocabulary: S.Schema<DefaultVocabulary>;
export type DefaultVocabularyList = DefaultVocabulary[];
export declare const DefaultVocabularyList: any;
export interface ListDefaultVocabulariesResponse {
    DefaultVocabularyList: DefaultVocabulary[];
    NextToken?: string;
}
export declare const ListDefaultVocabulariesResponse: S.Schema<ListDefaultVocabulariesResponse>;
export interface ListEntitySecurityProfilesRequest {
    InstanceId: string;
    EntityType: EntityType;
    EntityArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEntitySecurityProfilesRequest: S.Schema<ListEntitySecurityProfilesRequest>;
export type SecurityProfiles100 = SecurityProfileItem[];
export declare const SecurityProfiles100: any;
export interface ListEntitySecurityProfilesResponse {
    SecurityProfiles?: SecurityProfileItem[];
    NextToken?: string;
}
export declare const ListEntitySecurityProfilesResponse: S.Schema<ListEntitySecurityProfilesResponse>;
export interface ListEvaluationFormsRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListEvaluationFormsRequest: S.Schema<ListEvaluationFormsRequest>;
export interface EvaluationFormSummary {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    Title: string;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
    LastActivatedTime?: Date;
    LastActivatedBy?: string;
    LatestVersion: number;
    ActiveVersion?: number;
}
export declare const EvaluationFormSummary: S.Schema<EvaluationFormSummary>;
export type EvaluationFormSummaryList = EvaluationFormSummary[];
export declare const EvaluationFormSummaryList: any;
export interface ListEvaluationFormsResponse {
    EvaluationFormSummaryList: EvaluationFormSummary[];
    NextToken?: string;
}
export declare const ListEvaluationFormsResponse: S.Schema<ListEvaluationFormsResponse>;
export interface ListEvaluationFormVersionsRequest {
    InstanceId: string;
    EvaluationFormId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListEvaluationFormVersionsRequest: S.Schema<ListEvaluationFormVersionsRequest>;
export interface EvaluationFormVersionSummary {
    EvaluationFormArn: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    Locked: boolean;
    Status: EvaluationFormVersionStatus;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
}
export declare const EvaluationFormVersionSummary: S.Schema<EvaluationFormVersionSummary>;
export type EvaluationFormVersionSummaryList = EvaluationFormVersionSummary[];
export declare const EvaluationFormVersionSummaryList: any;
export interface ListEvaluationFormVersionsResponse {
    EvaluationFormVersionSummaryList: EvaluationFormVersionSummary[];
    NextToken?: string;
}
export declare const ListEvaluationFormVersionsResponse: S.Schema<ListEvaluationFormVersionsResponse>;
export interface ListExtractionDefinitionsRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExtractionDefinitionsRequest: S.Schema<ListExtractionDefinitionsRequest>;
export interface ExtractionDefinitionSummary {
    Name: string;
    ExtractionDefinitionId: string;
    ExtractionDefinitionArn: string;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
}
export declare const ExtractionDefinitionSummary: S.Schema<ExtractionDefinitionSummary>;
export type ExtractionDefinitionSummaryList = ExtractionDefinitionSummary[];
export declare const ExtractionDefinitionSummaryList: any;
export interface ListExtractionDefinitionsResponse {
    ExtractionDefinitionSummaryList: ExtractionDefinitionSummary[];
    NextToken?: string;
}
export declare const ListExtractionDefinitionsResponse: S.Schema<ListExtractionDefinitionsResponse>;
export interface ListFlowAssociationsRequest {
    InstanceId: string;
    ResourceType?: ListFlowAssociationResourceType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFlowAssociationsRequest: S.Schema<ListFlowAssociationsRequest>;
export interface ListFlowAssociationsResponse {
    FlowAssociationSummaryList?: FlowAssociationSummary[];
    NextToken?: string;
}
export declare const ListFlowAssociationsResponse: S.Schema<ListFlowAssociationsResponse>;
export interface ListHoursOfOperationOverridesRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListHoursOfOperationOverridesRequest: S.Schema<ListHoursOfOperationOverridesRequest>;
export type HoursOfOperationOverrideList = HoursOfOperationOverride[];
export declare const HoursOfOperationOverrideList: any;
export interface ListHoursOfOperationOverridesResponse {
    NextToken?: string;
    HoursOfOperationOverrideList?: HoursOfOperationOverride[];
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
}
export declare const ListHoursOfOperationOverridesResponse: S.Schema<ListHoursOfOperationOverridesResponse>;
export interface ListHoursOfOperationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListHoursOfOperationsRequest: S.Schema<ListHoursOfOperationsRequest>;
export type HoursOfOperationName = string;
export interface HoursOfOperationSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const HoursOfOperationSummary: S.Schema<HoursOfOperationSummary>;
export type HoursOfOperationSummaryList = HoursOfOperationSummary[];
export declare const HoursOfOperationSummaryList: any;
export interface ListHoursOfOperationsResponse {
    HoursOfOperationSummaryList?: HoursOfOperationSummary[];
    NextToken?: string;
}
export declare const ListHoursOfOperationsResponse: S.Schema<ListHoursOfOperationsResponse>;
export type MaxResult7 = number;
export interface ListInstanceAttributesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListInstanceAttributesRequest: S.Schema<ListInstanceAttributesRequest>;
export type AttributesList = Attribute[];
export declare const AttributesList: any;
export interface ListInstanceAttributesResponse {
    Attributes?: Attribute[];
    NextToken?: string;
}
export declare const ListInstanceAttributesResponse: S.Schema<ListInstanceAttributesResponse>;
export type MaxResult10 = number;
export interface ListInstancesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListInstancesRequest: S.Schema<ListInstancesRequest>;
export interface InstanceSummary {
    Id?: string;
    Arn?: string;
    IdentityManagementType?: DirectoryType;
    InstanceAlias?: string | redacted.Redacted<string>;
    CreatedTime?: Date;
    ServiceRole?: string;
    InstanceStatus?: InstanceStatus;
    InboundCallsEnabled?: boolean;
    OutboundCallsEnabled?: boolean;
    InstanceAccessUrl?: string;
}
export declare const InstanceSummary: S.Schema<InstanceSummary>;
export type InstanceSummaryList = InstanceSummary[];
export declare const InstanceSummaryList: any;
export interface ListInstancesResponse {
    InstanceSummaryList?: InstanceSummary[];
    NextToken?: string;
}
export declare const ListInstancesResponse: S.Schema<ListInstancesResponse>;
export interface ListInstanceStorageConfigsRequest {
    InstanceId: string;
    ResourceType: InstanceStorageResourceType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListInstanceStorageConfigsRequest: S.Schema<ListInstanceStorageConfigsRequest>;
export type InstanceStorageConfigs = InstanceStorageConfig[];
export declare const InstanceStorageConfigs: any;
export interface ListInstanceStorageConfigsResponse {
    StorageConfigs?: InstanceStorageConfig[];
    NextToken?: string;
}
export declare const ListInstanceStorageConfigsResponse: S.Schema<ListInstanceStorageConfigsResponse>;
export interface ListIntegrationAssociationsRequest {
    InstanceId: string;
    IntegrationType?: IntegrationType;
    NextToken?: string;
    MaxResults?: number;
    IntegrationArn?: string;
}
export declare const ListIntegrationAssociationsRequest: S.Schema<ListIntegrationAssociationsRequest>;
export interface IntegrationAssociationSummary {
    IntegrationAssociationId?: string;
    IntegrationAssociationArn?: string;
    InstanceId?: string;
    IntegrationType?: IntegrationType;
    IntegrationArn?: string;
    SourceApplicationUrl?: string;
    SourceApplicationName?: string;
    SourceType?: SourceType;
}
export declare const IntegrationAssociationSummary: S.Schema<IntegrationAssociationSummary>;
export type IntegrationAssociationSummaryList = IntegrationAssociationSummary[];
export declare const IntegrationAssociationSummaryList: any;
export interface ListIntegrationAssociationsResponse {
    IntegrationAssociationSummaryList?: IntegrationAssociationSummary[];
    NextToken?: string;
}
export declare const ListIntegrationAssociationsResponse: S.Schema<ListIntegrationAssociationsResponse>;
export interface ListLambdaFunctionsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListLambdaFunctionsRequest: S.Schema<ListLambdaFunctionsRequest>;
export type FunctionArnsList = string[];
export declare const FunctionArnsList: any;
export interface ListLambdaFunctionsResponse {
    LambdaFunctions?: string[];
    NextToken?: string;
}
export declare const ListLambdaFunctionsResponse: S.Schema<ListLambdaFunctionsResponse>;
export interface ListLexBotsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListLexBotsRequest: S.Schema<ListLexBotsRequest>;
export type LexBotsList = LexBot[];
export declare const LexBotsList: any;
export interface ListLexBotsResponse {
    LexBots?: LexBot[];
    NextToken?: string;
}
export declare const ListLexBotsResponse: S.Schema<ListLexBotsResponse>;
export interface ListMetricsRequest {
    InstanceId: string;
    Type?: MetricType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListMetricsRequest: S.Schema<ListMetricsRequest>;
export interface MetricSummary {
    Arn: string;
    Id: string;
    Name: string;
    Status: MetricStatus;
    Type: MetricType;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
}
export declare const MetricSummary: S.Schema<MetricSummary>;
export type MetricSummaryList = MetricSummary[];
export declare const MetricSummaryList: any;
export interface ListMetricsResponse {
    MetricSummaryList: MetricSummary[];
    NextToken?: string;
}
export declare const ListMetricsResponse: S.Schema<ListMetricsResponse>;
export interface ListNotificationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListNotificationsRequest: S.Schema<ListNotificationsRequest>;
export type NotificationSummaryList = Notification[];
export declare const NotificationSummaryList: any;
export interface ListNotificationsResponse {
    NextToken?: string;
    NotificationSummaryList: Notification[];
}
export declare const ListNotificationsResponse: S.Schema<ListNotificationsResponse>;
export type PhoneNumberTypes = PhoneNumberType[];
export declare const PhoneNumberTypes: any;
export type PhoneNumberCountryCodes = PhoneNumberCountryCode[];
export declare const PhoneNumberCountryCodes: any;
export interface ListPhoneNumbersRequest {
    InstanceId: string;
    PhoneNumberTypes?: PhoneNumberType[];
    PhoneNumberCountryCodes?: PhoneNumberCountryCode[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPhoneNumbersRequest: S.Schema<ListPhoneNumbersRequest>;
export interface PhoneNumberSummary {
    Id?: string;
    Arn?: string;
    PhoneNumber?: string;
    PhoneNumberType?: PhoneNumberType;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
}
export declare const PhoneNumberSummary: S.Schema<PhoneNumberSummary>;
export type PhoneNumberSummaryList = PhoneNumberSummary[];
export declare const PhoneNumberSummaryList: any;
export interface ListPhoneNumbersResponse {
    PhoneNumberSummaryList?: PhoneNumberSummary[];
    NextToken?: string;
}
export declare const ListPhoneNumbersResponse: S.Schema<ListPhoneNumbersResponse>;
export type LargeNextToken = string;
export type PhoneNumberPrefix = string;
export interface ListPhoneNumbersV2Request {
    TargetArn?: string;
    InstanceId?: string;
    MaxResults?: number;
    NextToken?: string;
    PhoneNumberCountryCodes?: PhoneNumberCountryCode[];
    PhoneNumberTypes?: PhoneNumberType[];
    PhoneNumberPrefix?: string;
}
export declare const ListPhoneNumbersV2Request: S.Schema<ListPhoneNumbersV2Request>;
export interface ListPhoneNumbersSummary {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
    PhoneNumber?: string;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
    PhoneNumberType?: PhoneNumberType;
    TargetArn?: string;
    InstanceId?: string;
    PhoneNumberDescription?: string;
    SourcePhoneNumberArn?: string;
}
export declare const ListPhoneNumbersSummary: S.Schema<ListPhoneNumbersSummary>;
export type ListPhoneNumbersSummaryList = ListPhoneNumbersSummary[];
export declare const ListPhoneNumbersSummaryList: any;
export interface ListPhoneNumbersV2Response {
    NextToken?: string;
    ListPhoneNumbersSummaryList?: ListPhoneNumbersSummary[];
}
export declare const ListPhoneNumbersV2Response: S.Schema<ListPhoneNumbersV2Response>;
export interface ListPredefinedAttributesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPredefinedAttributesRequest: S.Schema<ListPredefinedAttributesRequest>;
export interface PredefinedAttributeSummary {
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const PredefinedAttributeSummary: S.Schema<PredefinedAttributeSummary>;
export type PredefinedAttributeSummaryList = PredefinedAttributeSummary[];
export declare const PredefinedAttributeSummaryList: any;
export interface ListPredefinedAttributesResponse {
    NextToken?: string;
    PredefinedAttributeSummaryList?: PredefinedAttributeSummary[];
}
export declare const ListPredefinedAttributesResponse: S.Schema<ListPredefinedAttributesResponse>;
export interface ListPromptsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPromptsRequest: S.Schema<ListPromptsRequest>;
export type PromptName = string;
export interface PromptSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const PromptSummary: S.Schema<PromptSummary>;
export type PromptSummaryList = PromptSummary[];
export declare const PromptSummaryList: any;
export interface ListPromptsResponse {
    PromptSummaryList?: PromptSummary[];
    NextToken?: string;
}
export declare const ListPromptsResponse: S.Schema<ListPromptsResponse>;
export interface ListQueueEmailAddressesRequest {
    InstanceId: string;
    QueueId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListQueueEmailAddressesRequest: S.Schema<ListQueueEmailAddressesRequest>;
export interface EmailAddressSummary {
    Id?: string;
    Arn?: string;
    IsDefaultOutboundEmail?: boolean;
}
export declare const EmailAddressSummary: S.Schema<EmailAddressSummary>;
export type EmailAddressMetadataList = EmailAddressSummary[];
export declare const EmailAddressMetadataList: any;
export interface ListQueueEmailAddressesResponse {
    NextToken?: string;
    EmailAddressMetadataList?: EmailAddressSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListQueueEmailAddressesResponse: S.Schema<ListQueueEmailAddressesResponse>;
export interface ListQueueQuickConnectsRequest {
    InstanceId: string;
    QueueId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListQueueQuickConnectsRequest: S.Schema<ListQueueQuickConnectsRequest>;
export interface QuickConnectSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    QuickConnectType?: QuickConnectType;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const QuickConnectSummary: S.Schema<QuickConnectSummary>;
export type QuickConnectSummaryList = QuickConnectSummary[];
export declare const QuickConnectSummaryList: any;
export interface ListQueueQuickConnectsResponse {
    NextToken?: string;
    QuickConnectSummaryList?: QuickConnectSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListQueueQuickConnectsResponse: S.Schema<ListQueueQuickConnectsResponse>;
export type QueueType = "STANDARD" | "AGENT" | (string & {});
export declare const QueueType: any;
export type QueueTypes = QueueType[];
export declare const QueueTypes: any;
export interface ListQueuesRequest {
    InstanceId: string;
    QueueTypes?: QueueType[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListQueuesRequest: S.Schema<ListQueuesRequest>;
export type QueueName = string;
export interface QueueSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    QueueType?: QueueType;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const QueueSummary: S.Schema<QueueSummary>;
export type QueueSummaryList = QueueSummary[];
export declare const QueueSummaryList: any;
export interface ListQueuesResponse {
    QueueSummaryList?: QueueSummary[];
    NextToken?: string;
}
export declare const ListQueuesResponse: S.Schema<ListQueuesResponse>;
export type QuickConnectTypes = QuickConnectType[];
export declare const QuickConnectTypes: any;
export interface ListQuickConnectsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    QuickConnectTypes?: QuickConnectType[];
}
export declare const ListQuickConnectsRequest: S.Schema<ListQuickConnectsRequest>;
export interface ListQuickConnectsResponse {
    QuickConnectSummaryList?: QuickConnectSummary[];
    NextToken?: string;
}
export declare const ListQuickConnectsResponse: S.Schema<ListQuickConnectsResponse>;
export type RealTimeContactAnalysisOutputType = "Raw" | "Redacted" | (string & {});
export declare const RealTimeContactAnalysisOutputType: any;
export type RealTimeContactAnalysisSegmentType = "Transcript" | "Categories" | "Issues" | "Event" | "Attachments" | "PostContactSummary" | "ExtractedInformation" | (string & {});
export declare const RealTimeContactAnalysisSegmentType: any;
export type RealTimeContactAnalysisSegmentTypes = RealTimeContactAnalysisSegmentType[];
export declare const RealTimeContactAnalysisSegmentTypes: any;
export interface ListRealtimeContactAnalysisSegmentsV2Request {
    InstanceId: string;
    ContactId: string;
    MaxResults?: number;
    NextToken?: string;
    OutputType: RealTimeContactAnalysisOutputType;
    SegmentTypes: RealTimeContactAnalysisSegmentType[];
}
export declare const ListRealtimeContactAnalysisSegmentsV2Request: S.Schema<ListRealtimeContactAnalysisSegmentsV2Request>;
export type RealTimeContactAnalysisSupportedChannel = "VOICE" | "CHAT" | (string & {});
export declare const RealTimeContactAnalysisSupportedChannel: any;
export type RealTimeContactAnalysisStatus = "IN_PROGRESS" | "FAILED" | "COMPLETED" | (string & {});
export declare const RealTimeContactAnalysisStatus: any;
export type RealTimeContactAnalysisId256 = string;
export type RealTimeContactAnalysisTranscriptContent = string;
export type RealTimeContactAnalysisContentType = string;
export type RealTimeContactAnalysisTimeInstant = Date;
export type RealTimeContactAnalysisTimeData = {
    AbsoluteTime: Date;
};
export declare const RealTimeContactAnalysisTimeData: any;
export type RealTimeContactAnalysisOffset = number;
export interface RealTimeContactAnalysisCharacterInterval {
    BeginOffsetChar: number;
    EndOffsetChar: number;
}
export declare const RealTimeContactAnalysisCharacterInterval: S.Schema<RealTimeContactAnalysisCharacterInterval>;
export type RealTimeContactAnalysisCharacterIntervals = RealTimeContactAnalysisCharacterInterval[];
export declare const RealTimeContactAnalysisCharacterIntervals: any;
export interface RealTimeContactAnalysisTranscriptItemRedaction {
    CharacterOffsets?: RealTimeContactAnalysisCharacterInterval[];
}
export declare const RealTimeContactAnalysisTranscriptItemRedaction: S.Schema<RealTimeContactAnalysisTranscriptItemRedaction>;
export type RealTimeContactAnalysisSentimentLabel = "POSITIVE" | "NEGATIVE" | "NEUTRAL" | (string & {});
export declare const RealTimeContactAnalysisSentimentLabel: any;
export interface RealTimeContactAnalysisSegmentTranscript {
    Id: string;
    ParticipantId: string;
    ParticipantRole: ParticipantRole;
    DisplayName?: string;
    Content: string;
    ContentType?: string;
    Time: RealTimeContactAnalysisTimeData;
    Redaction?: RealTimeContactAnalysisTranscriptItemRedaction;
    Sentiment?: RealTimeContactAnalysisSentimentLabel;
}
export declare const RealTimeContactAnalysisSegmentTranscript: S.Schema<RealTimeContactAnalysisSegmentTranscript>;
export type RealTimeContactAnalysisCategoryName = string;
export interface RealTimeContactAnalysisTranscriptItemWithCharacterOffsets {
    Id: string;
    CharacterOffsets?: RealTimeContactAnalysisCharacterInterval;
}
export declare const RealTimeContactAnalysisTranscriptItemWithCharacterOffsets: S.Schema<RealTimeContactAnalysisTranscriptItemWithCharacterOffsets>;
export type RealTimeContactAnalysisTranscriptItemsWithCharacterOffsets = RealTimeContactAnalysisTranscriptItemWithCharacterOffsets[];
export declare const RealTimeContactAnalysisTranscriptItemsWithCharacterOffsets: any;
export interface RealTimeContactAnalysisPointOfInterest {
    TranscriptItems?: RealTimeContactAnalysisTranscriptItemWithCharacterOffsets[];
}
export declare const RealTimeContactAnalysisPointOfInterest: S.Schema<RealTimeContactAnalysisPointOfInterest>;
export type RealTimeContactAnalysisPointsOfInterest = RealTimeContactAnalysisPointOfInterest[];
export declare const RealTimeContactAnalysisPointsOfInterest: any;
export interface RealTimeContactAnalysisCategoryDetails {
    PointsOfInterest: RealTimeContactAnalysisPointOfInterest[];
}
export declare const RealTimeContactAnalysisCategoryDetails: S.Schema<RealTimeContactAnalysisCategoryDetails>;
export type RealTimeContactAnalysisMatchedDetails = {
    [key: string]: RealTimeContactAnalysisCategoryDetails | undefined;
};
export declare const RealTimeContactAnalysisMatchedDetails: any;
export interface RealTimeContactAnalysisSegmentCategories {
    MatchedDetails: {
        [key: string]: RealTimeContactAnalysisCategoryDetails | undefined;
    };
}
export declare const RealTimeContactAnalysisSegmentCategories: S.Schema<RealTimeContactAnalysisSegmentCategories>;
export interface RealTimeContactAnalysisTranscriptItemWithContent {
    Content?: string;
    Id: string;
    CharacterOffsets?: RealTimeContactAnalysisCharacterInterval;
}
export declare const RealTimeContactAnalysisTranscriptItemWithContent: S.Schema<RealTimeContactAnalysisTranscriptItemWithContent>;
export type RealTimeContactAnalysisTranscriptItemsWithContent = RealTimeContactAnalysisTranscriptItemWithContent[];
export declare const RealTimeContactAnalysisTranscriptItemsWithContent: any;
export interface RealTimeContactAnalysisIssueDetected {
    TranscriptItems: RealTimeContactAnalysisTranscriptItemWithContent[];
}
export declare const RealTimeContactAnalysisIssueDetected: S.Schema<RealTimeContactAnalysisIssueDetected>;
export type RealTimeContactAnalysisIssuesDetected = RealTimeContactAnalysisIssueDetected[];
export declare const RealTimeContactAnalysisIssuesDetected: any;
export interface RealTimeContactAnalysisSegmentIssues {
    IssuesDetected: RealTimeContactAnalysisIssueDetected[];
}
export declare const RealTimeContactAnalysisSegmentIssues: S.Schema<RealTimeContactAnalysisSegmentIssues>;
export type RealTimeContactAnalysisEventType = string;
export interface RealTimeContactAnalysisSegmentEvent {
    Id: string;
    ParticipantId?: string;
    ParticipantRole?: ParticipantRole;
    DisplayName?: string;
    EventType: string;
    Time: RealTimeContactAnalysisTimeData;
}
export declare const RealTimeContactAnalysisSegmentEvent: S.Schema<RealTimeContactAnalysisSegmentEvent>;
export type AttachmentName = string;
export type ContentType = string;
export type ArtifactId = string;
export type ArtifactStatus = "APPROVED" | "REJECTED" | "IN_PROGRESS" | (string & {});
export declare const ArtifactStatus: any;
export interface RealTimeContactAnalysisAttachment {
    AttachmentName: string;
    ContentType?: string;
    AttachmentId: string;
    Status?: ArtifactStatus;
}
export declare const RealTimeContactAnalysisAttachment: S.Schema<RealTimeContactAnalysisAttachment>;
export type RealTimeContactAnalysisAttachments = RealTimeContactAnalysisAttachment[];
export declare const RealTimeContactAnalysisAttachments: any;
export interface RealTimeContactAnalysisSegmentAttachments {
    Id: string;
    ParticipantId: string;
    ParticipantRole: ParticipantRole;
    DisplayName?: string;
    Attachments: RealTimeContactAnalysisAttachment[];
    Time: RealTimeContactAnalysisTimeData;
}
export declare const RealTimeContactAnalysisSegmentAttachments: S.Schema<RealTimeContactAnalysisSegmentAttachments>;
export type RealTimeContactAnalysisPostContactSummaryContent = string;
export type RealTimeContactAnalysisPostContactSummaryStatus = "FAILED" | "COMPLETED" | (string & {});
export declare const RealTimeContactAnalysisPostContactSummaryStatus: any;
export type RealTimeContactAnalysisPostContactSummaryFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INVALID_ANALYSIS_CONFIGURATION" | "INTERNAL_ERROR" | (string & {});
export declare const RealTimeContactAnalysisPostContactSummaryFailureCode: any;
export interface RealTimeContactAnalysisSegmentPostContactSummary {
    Content?: string;
    Status: RealTimeContactAnalysisPostContactSummaryStatus;
    FailureCode?: RealTimeContactAnalysisPostContactSummaryFailureCode;
}
export declare const RealTimeContactAnalysisSegmentPostContactSummary: S.Schema<RealTimeContactAnalysisSegmentPostContactSummary>;
export type RealTimeContactAnalysisExtractedInformationContent = string;
export interface RealTimeContactAnalysisExtractedInformationValue {
    Content: string;
    PointsOfInterest: RealTimeContactAnalysisTranscriptItemWithCharacterOffsets[];
}
export declare const RealTimeContactAnalysisExtractedInformationValue: S.Schema<RealTimeContactAnalysisExtractedInformationValue>;
export type RealTimeContactAnalysisExtractedInformationValues = RealTimeContactAnalysisExtractedInformationValue[];
export declare const RealTimeContactAnalysisExtractedInformationValues: any;
export type RealTimeContactAnalysisExtractedInformationFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INTERNAL_ERROR" | "MAX_PACKAGE_FEATURE_ONLY" | (string & {});
export declare const RealTimeContactAnalysisExtractedInformationFailureCode: any;
export interface RealTimeContactAnalysisSegmentExtractedInformation {
    ExtractionDefinitionId: string;
    ExtractionDefinitionName: string;
    ExtractionDefinitionDisplayLabel?: string;
    ExtractedValues?: RealTimeContactAnalysisExtractedInformationValue[];
    FailureCode?: RealTimeContactAnalysisExtractedInformationFailureCode;
}
export declare const RealTimeContactAnalysisSegmentExtractedInformation: S.Schema<RealTimeContactAnalysisSegmentExtractedInformation>;
export type RealtimeContactAnalysisSegment = {
    Transcript: RealTimeContactAnalysisSegmentTranscript;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories: RealTimeContactAnalysisSegmentCategories;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues: RealTimeContactAnalysisSegmentIssues;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event: RealTimeContactAnalysisSegmentEvent;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments: RealTimeContactAnalysisSegmentAttachments;
    PostContactSummary?: never;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary: RealTimeContactAnalysisSegmentPostContactSummary;
    ExtractedInformation?: never;
} | {
    Transcript?: never;
    Categories?: never;
    Issues?: never;
    Event?: never;
    Attachments?: never;
    PostContactSummary?: never;
    ExtractedInformation: RealTimeContactAnalysisSegmentExtractedInformation;
};
export declare const RealtimeContactAnalysisSegment: any;
export type RealtimeContactAnalysisSegments = RealtimeContactAnalysisSegment[];
export declare const RealtimeContactAnalysisSegments: any;
export interface ListRealtimeContactAnalysisSegmentsV2Response {
    Channel: RealTimeContactAnalysisSupportedChannel;
    Status: RealTimeContactAnalysisStatus;
    Segments: RealtimeContactAnalysisSegment[];
    NextToken?: string;
}
export declare const ListRealtimeContactAnalysisSegmentsV2Response: S.Schema<ListRealtimeContactAnalysisSegmentsV2Response>;
export interface ListRoutingProfileManualAssignmentQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRoutingProfileManualAssignmentQueuesRequest: S.Schema<ListRoutingProfileManualAssignmentQueuesRequest>;
export interface RoutingProfileManualAssignmentQueueConfigSummary {
    QueueId: string;
    QueueArn: string;
    QueueName: string;
    Channel: Channel;
}
export declare const RoutingProfileManualAssignmentQueueConfigSummary: S.Schema<RoutingProfileManualAssignmentQueueConfigSummary>;
export type RoutingProfileManualAssignmentQueueConfigSummaryList = RoutingProfileManualAssignmentQueueConfigSummary[];
export declare const RoutingProfileManualAssignmentQueueConfigSummaryList: any;
export interface ListRoutingProfileManualAssignmentQueuesResponse {
    NextToken?: string;
    RoutingProfileManualAssignmentQueueConfigSummaryList?: RoutingProfileManualAssignmentQueueConfigSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListRoutingProfileManualAssignmentQueuesResponse: S.Schema<ListRoutingProfileManualAssignmentQueuesResponse>;
export interface ListRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRoutingProfileQueuesRequest: S.Schema<ListRoutingProfileQueuesRequest>;
export interface RoutingProfileQueueConfigSummary {
    QueueId: string;
    QueueArn: string;
    QueueName: string;
    Priority: number;
    Delay: number;
    Channel: Channel;
}
export declare const RoutingProfileQueueConfigSummary: S.Schema<RoutingProfileQueueConfigSummary>;
export type RoutingProfileQueueConfigSummaryList = RoutingProfileQueueConfigSummary[];
export declare const RoutingProfileQueueConfigSummaryList: any;
export interface ListRoutingProfileQueuesResponse {
    NextToken?: string;
    RoutingProfileQueueConfigSummaryList?: RoutingProfileQueueConfigSummary[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListRoutingProfileQueuesResponse: S.Schema<ListRoutingProfileQueuesResponse>;
export interface ListRoutingProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRoutingProfilesRequest: S.Schema<ListRoutingProfilesRequest>;
export interface RoutingProfileSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const RoutingProfileSummary: S.Schema<RoutingProfileSummary>;
export type RoutingProfileSummaryList = RoutingProfileSummary[];
export declare const RoutingProfileSummaryList: any;
export interface ListRoutingProfilesResponse {
    RoutingProfileSummaryList?: RoutingProfileSummary[];
    NextToken?: string;
}
export declare const ListRoutingProfilesResponse: S.Schema<ListRoutingProfilesResponse>;
export type MaxResult200 = number;
export interface ListRulesRequest {
    InstanceId: string;
    PublishStatus?: RulePublishStatus;
    EventSourceName?: EventSourceName;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export interface ActionSummary {
    ActionType: ActionType;
}
export declare const ActionSummary: S.Schema<ActionSummary>;
export type ActionSummaries = ActionSummary[];
export declare const ActionSummaries: any;
export interface RuleSummary {
    Name: string;
    RuleId: string;
    RuleArn: string;
    EventSourceName: EventSourceName;
    PublishStatus: RulePublishStatus;
    RuleCapabilityTiers?: RuleCapabilityTier[];
    ActionSummaries: ActionSummary[];
    CreatedTime: Date;
    LastUpdatedTime: Date;
}
export declare const RuleSummary: S.Schema<RuleSummary>;
export type RuleSummaryList = RuleSummary[];
export declare const RuleSummaryList: any;
export interface ListRulesResponse {
    RuleSummaryList: RuleSummary[];
    NextToken?: string;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export type MaxResult2 = number;
export interface ListSecurityKeysRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSecurityKeysRequest: S.Schema<ListSecurityKeysRequest>;
export interface SecurityKey {
    AssociationId?: string;
    Key?: string;
    CreationTime?: Date;
}
export declare const SecurityKey: S.Schema<SecurityKey>;
export type SecurityKeysList = SecurityKey[];
export declare const SecurityKeysList: any;
export interface ListSecurityKeysResponse {
    SecurityKeys?: SecurityKey[];
    NextToken?: string;
}
export declare const ListSecurityKeysResponse: S.Schema<ListSecurityKeysResponse>;
export interface ListSecurityProfileApplicationsRequest {
    SecurityProfileId: string;
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSecurityProfileApplicationsRequest: S.Schema<ListSecurityProfileApplicationsRequest>;
export interface ListSecurityProfileApplicationsResponse {
    Applications?: Application[];
    NextToken?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListSecurityProfileApplicationsResponse: S.Schema<ListSecurityProfileApplicationsResponse>;
export interface ListSecurityProfileFlowModulesRequest {
    SecurityProfileId: string;
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSecurityProfileFlowModulesRequest: S.Schema<ListSecurityProfileFlowModulesRequest>;
export interface ListSecurityProfileFlowModulesResponse {
    AllowedFlowModules?: FlowModule[];
    NextToken?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListSecurityProfileFlowModulesResponse: S.Schema<ListSecurityProfileFlowModulesResponse>;
export interface ListSecurityProfilePermissionsRequest {
    SecurityProfileId: string;
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSecurityProfilePermissionsRequest: S.Schema<ListSecurityProfilePermissionsRequest>;
export interface ListSecurityProfilePermissionsResponse {
    Permissions?: string[];
    NextToken?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListSecurityProfilePermissionsResponse: S.Schema<ListSecurityProfilePermissionsResponse>;
export interface ListSecurityProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSecurityProfilesRequest: S.Schema<ListSecurityProfilesRequest>;
export interface SecurityProfileSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const SecurityProfileSummary: S.Schema<SecurityProfileSummary>;
export type SecurityProfileSummaryList = SecurityProfileSummary[];
export declare const SecurityProfileSummaryList: any;
export interface ListSecurityProfilesResponse {
    SecurityProfileSummaryList?: SecurityProfileSummary[];
    NextToken?: string;
}
export declare const ListSecurityProfilesResponse: S.Schema<ListSecurityProfilesResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTaskTemplatesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    Status?: TaskTemplateStatus;
    Name?: string;
}
export declare const ListTaskTemplatesRequest: S.Schema<ListTaskTemplatesRequest>;
export interface TaskTemplateMetadata {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    Status?: TaskTemplateStatus;
    LastModifiedTime?: Date;
    CreatedTime?: Date;
}
export declare const TaskTemplateMetadata: S.Schema<TaskTemplateMetadata>;
export type TaskTemplateList = TaskTemplateMetadata[];
export declare const TaskTemplateList: any;
export interface ListTaskTemplatesResponse {
    TaskTemplates?: TaskTemplateMetadata[];
    NextToken?: string;
}
export declare const ListTaskTemplatesResponse: S.Schema<ListTaskTemplatesResponse>;
export interface ListTestCaseExecutionRecordsRequest {
    InstanceId: string;
    TestCaseId: string;
    TestCaseExecutionId: string;
    Status?: TestCaseExecutionStatus;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTestCaseExecutionRecordsRequest: S.Schema<ListTestCaseExecutionRecordsRequest>;
export type TestCaseResourceId = string;
export type ExecutionRecordStatus = "PASSED" | "FAILED" | "IN_PROGRESS" | "STOPPED" | (string & {});
export declare const ExecutionRecordStatus: any;
export type ExecutionRecordString = string;
export interface ExecutionRecord {
    ObservationId?: string;
    Status?: ExecutionRecordStatus;
    Timestamp?: Date;
    Record?: string;
}
export declare const ExecutionRecord: S.Schema<ExecutionRecord>;
export type ExecutionRecordList = ExecutionRecord[];
export declare const ExecutionRecordList: any;
export interface ListTestCaseExecutionRecordsResponse {
    ExecutionRecords?: ExecutionRecord[];
    NextToken?: string;
}
export declare const ListTestCaseExecutionRecordsResponse: S.Schema<ListTestCaseExecutionRecordsResponse>;
export type EpochMilliseconds = number;
export interface ListTestCaseExecutionsRequest {
    InstanceId: string;
    TestCaseId?: string;
    TestCaseName?: string;
    StartTime?: number;
    EndTime?: number;
    Status?: TestCaseExecutionStatus;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTestCaseExecutionsRequest: S.Schema<ListTestCaseExecutionsRequest>;
export interface TestCaseExecution {
    StartTime?: Date;
    EndTime?: Date;
    TestCaseExecutionId?: string;
    TestCaseId?: string;
    TestCaseExecutionStatus?: TestCaseExecutionStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TestCaseExecution: S.Schema<TestCaseExecution>;
export type TestCaseExecutionList = TestCaseExecution[];
export declare const TestCaseExecutionList: any;
export interface ListTestCaseExecutionsResponse {
    TestCaseExecutions?: TestCaseExecution[];
    NextToken?: string;
}
export declare const ListTestCaseExecutionsResponse: S.Schema<ListTestCaseExecutionsResponse>;
export interface ListTestCasesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTestCasesRequest: S.Schema<ListTestCasesRequest>;
export interface TestCaseSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    Status?: TestCaseStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const TestCaseSummary: S.Schema<TestCaseSummary>;
export type TestCaseSummaryList = TestCaseSummary[];
export declare const TestCaseSummaryList: any;
export interface ListTestCasesResponse {
    TestCaseSummaryList?: TestCaseSummary[];
    NextToken?: string;
}
export declare const ListTestCasesResponse: S.Schema<ListTestCasesResponse>;
export interface ListTrafficDistributionGroupsRequest {
    MaxResults?: number;
    NextToken?: string;
    InstanceId?: string;
}
export declare const ListTrafficDistributionGroupsRequest: S.Schema<ListTrafficDistributionGroupsRequest>;
export interface TrafficDistributionGroupSummary {
    Id?: string;
    Arn?: string;
    Name?: string;
    InstanceArn?: string;
    Status?: TrafficDistributionGroupStatus;
    IsDefault?: boolean;
}
export declare const TrafficDistributionGroupSummary: S.Schema<TrafficDistributionGroupSummary>;
export type TrafficDistributionGroupSummaryList = TrafficDistributionGroupSummary[];
export declare const TrafficDistributionGroupSummaryList: any;
export interface ListTrafficDistributionGroupsResponse {
    NextToken?: string;
    TrafficDistributionGroupSummaryList?: TrafficDistributionGroupSummary[];
}
export declare const ListTrafficDistributionGroupsResponse: S.Schema<ListTrafficDistributionGroupsResponse>;
export interface ListTrafficDistributionGroupUsersRequest {
    TrafficDistributionGroupId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTrafficDistributionGroupUsersRequest: S.Schema<ListTrafficDistributionGroupUsersRequest>;
export interface TrafficDistributionGroupUserSummary {
    UserId?: string;
}
export declare const TrafficDistributionGroupUserSummary: S.Schema<TrafficDistributionGroupUserSummary>;
export type TrafficDistributionGroupUserSummaryList = TrafficDistributionGroupUserSummary[];
export declare const TrafficDistributionGroupUserSummaryList: any;
export interface ListTrafficDistributionGroupUsersResponse {
    NextToken?: string;
    TrafficDistributionGroupUserSummaryList?: TrafficDistributionGroupUserSummary[];
}
export declare const ListTrafficDistributionGroupUsersResponse: S.Schema<ListTrafficDistributionGroupUsersResponse>;
export interface ListUseCasesRequest {
    InstanceId: string;
    IntegrationAssociationId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListUseCasesRequest: S.Schema<ListUseCasesRequest>;
export interface UseCase {
    UseCaseId?: string;
    UseCaseArn?: string;
    UseCaseType?: UseCaseType;
}
export declare const UseCase: S.Schema<UseCase>;
export type UseCaseSummaryList = UseCase[];
export declare const UseCaseSummaryList: any;
export interface ListUseCasesResponse {
    UseCaseSummaryList?: UseCase[];
    NextToken?: string;
}
export declare const ListUseCasesResponse: S.Schema<ListUseCasesResponse>;
export interface ListUserHierarchyGroupsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListUserHierarchyGroupsRequest: S.Schema<ListUserHierarchyGroupsRequest>;
export type HierarchyGroupSummaryList = HierarchyGroupSummary[];
export declare const HierarchyGroupSummaryList: any;
export interface ListUserHierarchyGroupsResponse {
    UserHierarchyGroupSummaryList?: HierarchyGroupSummary[];
    NextToken?: string;
}
export declare const ListUserHierarchyGroupsResponse: S.Schema<ListUserHierarchyGroupsResponse>;
export interface ListUserNotificationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    UserId: string;
}
export declare const ListUserNotificationsRequest: S.Schema<ListUserNotificationsRequest>;
export type NotificationStatus = "READ" | "UNREAD" | "HIDDEN" | (string & {});
export declare const NotificationStatus: any;
export type NotificationSource = "CUSTOMER" | "RULES" | "SYSTEM" | (string & {});
export declare const NotificationSource: any;
export interface UserNotificationSummary {
    NotificationId?: string;
    NotificationStatus?: NotificationStatus;
    InstanceId?: string;
    RecipientId?: string;
    Content?: {
        [key: string]: string | undefined;
    };
    Priority?: NotificationPriority;
    Source?: NotificationSource;
    CreatedAt?: Date;
    ExpiresAt?: Date;
}
export declare const UserNotificationSummary: S.Schema<UserNotificationSummary>;
export type UserNotificationSummaryList = UserNotificationSummary[];
export declare const UserNotificationSummaryList: any;
export interface ListUserNotificationsResponse {
    UserNotifications?: UserNotificationSummary[];
    NextToken?: string;
}
export declare const ListUserNotificationsResponse: S.Schema<ListUserNotificationsResponse>;
export interface ListUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListUserProficienciesRequest: S.Schema<ListUserProficienciesRequest>;
export interface ListUserProficienciesResponse {
    NextToken?: string;
    UserProficiencyList?: UserProficiency[];
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const ListUserProficienciesResponse: S.Schema<ListUserProficienciesResponse>;
export interface ListUsersRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListUsersRequest: S.Schema<ListUsersRequest>;
export interface UserSummary {
    Id?: string;
    Arn?: string;
    Username?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const UserSummary: S.Schema<UserSummary>;
export type UserSummaryList = UserSummary[];
export declare const UserSummaryList: any;
export interface ListUsersResponse {
    UserSummaryList?: UserSummary[];
    NextToken?: string;
}
export declare const ListUsersResponse: S.Schema<ListUsersResponse>;
export type ViewsNextToken = string;
export type MaxResults = number;
export interface ListViewsRequest {
    InstanceId: string;
    Type?: ViewType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListViewsRequest: S.Schema<ListViewsRequest>;
export interface ViewSummary {
    Id?: string;
    Arn?: string;
    Name?: string | redacted.Redacted<string>;
    Type?: ViewType;
    Status?: ViewStatus;
    Description?: string;
}
export declare const ViewSummary: S.Schema<ViewSummary>;
export type ViewsSummaryList = ViewSummary[];
export declare const ViewsSummaryList: any;
export interface ListViewsResponse {
    ViewsSummaryList?: ViewSummary[];
    NextToken?: string;
}
export declare const ListViewsResponse: S.Schema<ListViewsResponse>;
export interface ListViewVersionsRequest {
    InstanceId: string;
    ViewId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListViewVersionsRequest: S.Schema<ListViewVersionsRequest>;
export interface ViewVersionSummary {
    Id?: string;
    Arn?: string;
    Description?: string;
    Name?: string | redacted.Redacted<string>;
    Type?: ViewType;
    Version?: number;
    VersionDescription?: string;
}
export declare const ViewVersionSummary: S.Schema<ViewVersionSummary>;
export type ViewVersionSummaryList = ViewVersionSummary[];
export declare const ViewVersionSummaryList: any;
export interface ListViewVersionsResponse {
    ViewVersionSummaryList?: ViewVersionSummary[];
    NextToken?: string;
}
export declare const ListViewVersionsResponse: S.Schema<ListViewVersionsResponse>;
export interface ListWorkspaceMediaRequest {
    InstanceId: string;
    WorkspaceId: string;
}
export declare const ListWorkspaceMediaRequest: S.Schema<ListWorkspaceMediaRequest>;
export interface MediaItem {
    Type?: MediaType;
    Source?: string;
}
export declare const MediaItem: S.Schema<MediaItem>;
export type MediaList = MediaItem[];
export declare const MediaList: any;
export interface ListWorkspaceMediaResponse {
    Media?: MediaItem[];
}
export declare const ListWorkspaceMediaResponse: S.Schema<ListWorkspaceMediaResponse>;
export interface ListWorkspacePagesRequest {
    InstanceId: string;
    WorkspaceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListWorkspacePagesRequest: S.Schema<ListWorkspacePagesRequest>;
export interface WorkspacePage {
    ResourceArn?: string;
    Page?: string;
    Slug?: string;
    InputData?: string;
}
export declare const WorkspacePage: S.Schema<WorkspacePage>;
export type WorkspacePageList = WorkspacePage[];
export declare const WorkspacePageList: any;
export interface ListWorkspacePagesResponse {
    NextToken?: string;
    WorkspacePageList: WorkspacePage[];
}
export declare const ListWorkspacePagesResponse: S.Schema<ListWorkspacePagesResponse>;
export interface ListWorkspacesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListWorkspacesRequest: S.Schema<ListWorkspacesRequest>;
export interface WorkspaceSummary {
    Id?: string;
    Name?: string;
    Arn?: string;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const WorkspaceSummary: S.Schema<WorkspaceSummary>;
export type WorkspaceSummaryList = WorkspaceSummary[];
export declare const WorkspaceSummaryList: any;
export interface ListWorkspacesResponse {
    NextToken?: string;
    WorkspaceSummaryList: WorkspaceSummary[];
}
export declare const ListWorkspacesResponse: S.Schema<ListWorkspacesResponse>;
export type MonitorCapability = "SILENT_MONITOR" | "BARGE" | (string & {});
export declare const MonitorCapability: any;
export type AllowedMonitorCapabilities = MonitorCapability[];
export declare const AllowedMonitorCapabilities: any;
export interface MonitorContactRequest {
    InstanceId: string;
    ContactId: string;
    UserId: string;
    AllowedMonitorCapabilities?: MonitorCapability[];
    ClientToken?: string;
}
export declare const MonitorContactRequest: S.Schema<MonitorContactRequest>;
export interface MonitorContactResponse {
    ContactId?: string;
    ContactArn?: string;
}
export declare const MonitorContactResponse: S.Schema<MonitorContactResponse>;
export interface PauseContactRequest {
    ContactId: string;
    InstanceId: string;
    ContactFlowId?: string;
}
export declare const PauseContactRequest: S.Schema<PauseContactRequest>;
export interface PauseContactResponse {
}
export declare const PauseContactResponse: S.Schema<PauseContactResponse>;
export interface PutUserStatusRequest {
    UserId: string;
    InstanceId: string;
    AgentStatusId: string;
}
export declare const PutUserStatusRequest: S.Schema<PutUserStatusRequest>;
export interface PutUserStatusResponse {
}
export declare const PutUserStatusResponse: S.Schema<PutUserStatusResponse>;
export interface ReleasePhoneNumberRequest {
    PhoneNumberId: string;
    ClientToken?: string;
}
export declare const ReleasePhoneNumberRequest: S.Schema<ReleasePhoneNumberRequest>;
export interface ReleasePhoneNumberResponse {
}
export declare const ReleasePhoneNumberResponse: S.Schema<ReleasePhoneNumberResponse>;
export interface ReplicateInstanceRequest {
    InstanceId: string;
    ReplicaRegion: string;
    ClientToken?: string;
    ReplicaAlias: string | redacted.Redacted<string>;
}
export declare const ReplicateInstanceRequest: S.Schema<ReplicateInstanceRequest>;
export interface ReplicateInstanceResponse {
    Id?: string;
    Arn?: string;
}
export declare const ReplicateInstanceResponse: S.Schema<ReplicateInstanceResponse>;
export interface ResumeContactRequest {
    ContactId: string;
    InstanceId: string;
    ContactFlowId?: string;
}
export declare const ResumeContactRequest: S.Schema<ResumeContactRequest>;
export interface ResumeContactResponse {
}
export declare const ResumeContactResponse: S.Schema<ResumeContactResponse>;
export type ContactRecordingType = "AGENT" | "IVR" | "SCREEN" | (string & {});
export declare const ContactRecordingType: any;
export interface ResumeContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    ContactRecordingType?: ContactRecordingType;
}
export declare const ResumeContactRecordingRequest: S.Schema<ResumeContactRecordingRequest>;
export interface ResumeContactRecordingResponse {
}
export declare const ResumeContactRecordingResponse: S.Schema<ResumeContactRecordingResponse>;
export interface TagCondition {
    TagKey?: string;
    TagValue?: string;
}
export declare const TagCondition: S.Schema<TagCondition>;
export type TagAndConditionList = TagCondition[];
export declare const TagAndConditionList: any;
export interface CommonAttributeAndCondition {
    TagConditions?: TagCondition[];
}
export declare const CommonAttributeAndCondition: S.Schema<CommonAttributeAndCondition>;
export type CommonAttributeOrConditionList = CommonAttributeAndCondition[];
export declare const CommonAttributeOrConditionList: any;
export interface ControlPlaneAttributeFilter {
    OrConditions?: CommonAttributeAndCondition[];
    AndCondition?: CommonAttributeAndCondition;
    TagCondition?: TagCondition;
}
export declare const ControlPlaneAttributeFilter: S.Schema<ControlPlaneAttributeFilter>;
export interface AgentStatusSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const AgentStatusSearchFilter: S.Schema<AgentStatusSearchFilter>;
export type AgentStatusSearchConditionList = AgentStatusSearchCriteria[];
export declare const AgentStatusSearchConditionList: S.Schema<AgentStatusSearchConditionList>;
export type StringComparisonType = "STARTS_WITH" | "CONTAINS" | "EXACT" | (string & {});
export declare const StringComparisonType: any;
export interface StringCondition {
    FieldName?: string;
    Value?: string;
    ComparisonType?: StringComparisonType;
}
export declare const StringCondition: S.Schema<StringCondition>;
export interface AgentStatusSearchCriteria {
    OrConditions?: AgentStatusSearchCriteria[];
    AndConditions?: AgentStatusSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const AgentStatusSearchCriteria: S.Schema<AgentStatusSearchCriteria>;
export interface SearchAgentStatusesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: AgentStatusSearchFilter;
    SearchCriteria?: AgentStatusSearchCriteria;
}
export declare const SearchAgentStatusesRequest: S.Schema<SearchAgentStatusesRequest>;
export type AgentStatusList = AgentStatus[];
export declare const AgentStatusList: any;
export interface SearchAgentStatusesResponse {
    AgentStatuses?: AgentStatus[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchAgentStatusesResponse: S.Schema<SearchAgentStatusesResponse>;
export interface SearchAvailablePhoneNumbersRequest {
    TargetArn?: string;
    InstanceId?: string;
    PhoneNumberCountryCode: PhoneNumberCountryCode;
    PhoneNumberType: PhoneNumberType;
    PhoneNumberPrefix?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const SearchAvailablePhoneNumbersRequest: S.Schema<SearchAvailablePhoneNumbersRequest>;
export interface AvailableNumberSummary {
    PhoneNumber?: string;
    PhoneNumberCountryCode?: PhoneNumberCountryCode;
    PhoneNumberType?: PhoneNumberType;
}
export declare const AvailableNumberSummary: S.Schema<AvailableNumberSummary>;
export type AvailableNumbersList = AvailableNumberSummary[];
export declare const AvailableNumbersList: any;
export interface SearchAvailablePhoneNumbersResponse {
    NextToken?: string;
    AvailableNumbersList?: AvailableNumberSummary[];
}
export declare const SearchAvailablePhoneNumbersResponse: S.Schema<SearchAvailablePhoneNumbersResponse>;
export type EvaluationSearchConditionList = EvaluationSearchCriteria[];
export declare const EvaluationSearchConditionList: S.Schema<EvaluationSearchConditionList>;
export type NullableProficiencyLimitValue = number;
export type NumberComparisonType = "GREATER_OR_EQUAL" | "GREATER" | "LESSER_OR_EQUAL" | "LESSER" | "EQUAL" | "NOT_EQUAL" | "RANGE" | (string & {});
export declare const NumberComparisonType: any;
export interface NumberCondition {
    FieldName?: string;
    MinValue?: number;
    MaxValue?: number;
    ComparisonType?: NumberComparisonType;
}
export declare const NumberCondition: S.Schema<NumberCondition>;
export type BooleanComparisonType = "IS_TRUE" | "IS_FALSE" | (string & {});
export declare const BooleanComparisonType: any;
export interface BooleanCondition {
    FieldName?: string;
    ComparisonType?: BooleanComparisonType;
}
export declare const BooleanCondition: S.Schema<BooleanCondition>;
export type DateTimeFormat = string;
export type DateTimeComparisonType = "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_OR_EQUAL_TO" | "LESS_THAN_OR_EQUAL_TO" | "EQUAL_TO" | "RANGE" | (string & {});
export declare const DateTimeComparisonType: any;
export interface DateTimeCondition {
    FieldName?: string;
    MinValue?: string;
    MaxValue?: string;
    ComparisonType?: DateTimeComparisonType;
}
export declare const DateTimeCondition: S.Schema<DateTimeCondition>;
export type DecimalComparisonType = "GREATER_OR_EQUAL" | "GREATER" | "LESSER_OR_EQUAL" | "LESSER" | "EQUAL" | "NOT_EQUAL" | "RANGE" | (string & {});
export declare const DecimalComparisonType: any;
export interface DecimalCondition {
    FieldName?: string;
    MinValue?: number;
    MaxValue?: number;
    ComparisonType?: DecimalComparisonType;
}
export declare const DecimalCondition: S.Schema<DecimalCondition>;
export interface EvaluationSearchCriteria {
    OrConditions?: EvaluationSearchCriteria[];
    AndConditions?: EvaluationSearchCriteria[];
    StringCondition?: StringCondition;
    NumberCondition?: NumberCondition;
    BooleanCondition?: BooleanCondition;
    DateTimeCondition?: DateTimeCondition;
    DecimalCondition?: DecimalCondition;
}
export declare const EvaluationSearchCriteria: S.Schema<EvaluationSearchCriteria>;
export type ContactEvaluationAttributeKey = "ContactAgentId" | (string & {});
export declare const ContactEvaluationAttributeKey: any;
export interface ContactEvaluationAttributeValue {
    StringValue?: string;
}
export declare const ContactEvaluationAttributeValue: S.Schema<ContactEvaluationAttributeValue>;
export type ContactEvaluationAttributeComparisonType = "EXACT" | (string & {});
export declare const ContactEvaluationAttributeComparisonType: any;
export interface ContactEvaluationAttributeCondition {
    AttributeKey?: ContactEvaluationAttributeKey;
    AttributeValue?: ContactEvaluationAttributeValue;
    ComparisonType?: ContactEvaluationAttributeComparisonType;
}
export declare const ContactEvaluationAttributeCondition: S.Schema<ContactEvaluationAttributeCondition>;
export type ContactEvaluationAttributeConditionList = ContactEvaluationAttributeCondition[];
export declare const ContactEvaluationAttributeConditionList: any;
export interface ContactEvaluationAttributeAndCondition {
    TagConditions?: TagCondition[];
    AttributeConditions?: ContactEvaluationAttributeCondition[];
}
export declare const ContactEvaluationAttributeAndCondition: S.Schema<ContactEvaluationAttributeAndCondition>;
export type ContactEvaluationAttributeOrConditionList = ContactEvaluationAttributeAndCondition[];
export declare const ContactEvaluationAttributeOrConditionList: any;
export interface ContactEvaluationAttributeFilter {
    OrConditions?: ContactEvaluationAttributeAndCondition[];
    AndCondition?: ContactEvaluationAttributeAndCondition;
    TagCondition?: TagCondition;
    ContactEvaluationAttributeCondition?: ContactEvaluationAttributeCondition;
}
export declare const ContactEvaluationAttributeFilter: S.Schema<ContactEvaluationAttributeFilter>;
export interface EvaluationSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
    ContactEvaluationAttributeFilter?: ContactEvaluationAttributeFilter;
}
export declare const EvaluationSearchFilter: S.Schema<EvaluationSearchFilter>;
export interface SearchContactEvaluationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: EvaluationSearchCriteria;
    SearchFilter?: EvaluationSearchFilter;
}
export declare const SearchContactEvaluationsRequest: S.Schema<SearchContactEvaluationsRequest>;
export interface EvaluationSearchMetadata {
    ContactId: string;
    EvaluatorArn: string;
    ContactAgentId?: string;
    CalibrationSessionId?: string;
    ScorePercentage?: number;
    ScoreAutomaticFail?: boolean;
    ScoreNotApplicable?: boolean;
    AutoEvaluationEnabled?: boolean;
    AutoEvaluationStatus?: AutoEvaluationStatus;
    AcknowledgedTime?: Date;
    AcknowledgedBy?: string;
    AcknowledgerComment?: string;
    SamplingJobId?: string;
    ReviewId?: string;
    ContactParticipantRole?: ContactParticipantRole;
    ContactParticipantId?: string;
    EarnedPoints?: number;
    MaxBasePoint?: number;
    PerformanceCategory?: PerformanceCategoryName;
}
export declare const EvaluationSearchMetadata: S.Schema<EvaluationSearchMetadata>;
export interface EvaluationSearchSummary {
    EvaluationId: string;
    EvaluationArn: string;
    EvaluationFormId?: string;
    EvaluationFormVersion: number;
    EvaluationFormTitle?: string;
    Metadata: EvaluationSearchMetadata;
    Status: EvaluationStatus;
    EvaluationType?: EvaluationType;
    CreatedTime: Date;
    LastModifiedTime: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const EvaluationSearchSummary: S.Schema<EvaluationSearchSummary>;
export type EvaluationSearchSummaryList = EvaluationSearchSummary[];
export declare const EvaluationSearchSummaryList: any;
export interface SearchContactEvaluationsResponse {
    EvaluationSearchSummaryList?: EvaluationSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchContactEvaluationsResponse: S.Schema<SearchContactEvaluationsResponse>;
export type TagOrConditionList = TagCondition[][];
export declare const TagOrConditionList: any;
export interface ControlPlaneTagFilter {
    OrConditions?: TagCondition[][];
    AndConditions?: TagCondition[];
    TagCondition?: TagCondition;
}
export declare const ControlPlaneTagFilter: S.Schema<ControlPlaneTagFilter>;
export interface ContactFlowModuleSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const ContactFlowModuleSearchFilter: S.Schema<ContactFlowModuleSearchFilter>;
export type ContactFlowModuleSearchConditionList = ContactFlowModuleSearchCriteria[];
export declare const ContactFlowModuleSearchConditionList: S.Schema<ContactFlowModuleSearchConditionList>;
export interface ContactFlowModuleSearchCriteria {
    OrConditions?: ContactFlowModuleSearchCriteria[];
    AndConditions?: ContactFlowModuleSearchCriteria[];
    StringCondition?: StringCondition;
    StateCondition?: ContactFlowModuleState;
    StatusCondition?: ContactFlowModuleStatus;
}
export declare const ContactFlowModuleSearchCriteria: S.Schema<ContactFlowModuleSearchCriteria>;
export interface SearchContactFlowModulesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: ContactFlowModuleSearchFilter;
    SearchCriteria?: ContactFlowModuleSearchCriteria;
}
export declare const SearchContactFlowModulesRequest: S.Schema<SearchContactFlowModulesRequest>;
export type ContactFlowModuleSearchSummaryList = ContactFlowModule[];
export declare const ContactFlowModuleSearchSummaryList: any;
export interface SearchContactFlowModulesResponse {
    ContactFlowModules?: ContactFlowModule[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchContactFlowModulesResponse: S.Schema<SearchContactFlowModulesResponse>;
export interface ContactFlowTypeCondition {
    ContactFlowType?: ContactFlowType;
}
export declare const ContactFlowTypeCondition: S.Schema<ContactFlowTypeCondition>;
export interface ContactFlowAttributeAndCondition {
    TagConditions?: TagCondition[];
    ContactFlowTypeCondition?: ContactFlowTypeCondition;
}
export declare const ContactFlowAttributeAndCondition: S.Schema<ContactFlowAttributeAndCondition>;
export type ContactFlowAttributeOrConditionList = ContactFlowAttributeAndCondition[];
export declare const ContactFlowAttributeOrConditionList: any;
export interface ContactFlowAttributeFilter {
    OrConditions?: ContactFlowAttributeAndCondition[];
    AndCondition?: ContactFlowAttributeAndCondition;
    TagCondition?: TagCondition;
    ContactFlowTypeCondition?: ContactFlowTypeCondition;
}
export declare const ContactFlowAttributeFilter: S.Schema<ContactFlowAttributeFilter>;
export interface ContactFlowSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
    FlowAttributeFilter?: ContactFlowAttributeFilter;
}
export declare const ContactFlowSearchFilter: S.Schema<ContactFlowSearchFilter>;
export type ContactFlowSearchConditionList = ContactFlowSearchCriteria[];
export declare const ContactFlowSearchConditionList: S.Schema<ContactFlowSearchConditionList>;
export interface ContactFlowSearchCriteria {
    OrConditions?: ContactFlowSearchCriteria[];
    AndConditions?: ContactFlowSearchCriteria[];
    StringCondition?: StringCondition;
    TypeCondition?: ContactFlowType;
    StateCondition?: ContactFlowState;
    StatusCondition?: ContactFlowStatus;
}
export declare const ContactFlowSearchCriteria: S.Schema<ContactFlowSearchCriteria>;
export interface SearchContactFlowsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: ContactFlowSearchFilter;
    SearchCriteria?: ContactFlowSearchCriteria;
}
export declare const SearchContactFlowsRequest: S.Schema<SearchContactFlowsRequest>;
export type ContactFlowSearchSummaryList = ContactFlow[];
export declare const ContactFlowSearchSummaryList: any;
export interface SearchContactFlowsResponse {
    ContactFlows?: ContactFlow[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchContactFlowsResponse: S.Schema<SearchContactFlowsResponse>;
export type SearchContactsTimeRangeType = "INITIATION_TIMESTAMP" | "SCHEDULED_TIMESTAMP" | "CONNECTED_TO_AGENT_TIMESTAMP" | "DISCONNECT_TIMESTAMP" | "ENQUEUE_TIMESTAMP" | (string & {});
export declare const SearchContactsTimeRangeType: any;
export interface SearchContactsTimeRange {
    Type: SearchContactsTimeRangeType;
    StartTime: Date;
    EndTime: Date;
}
export declare const SearchContactsTimeRange: S.Schema<SearchContactsTimeRange>;
export type SearchText = string | redacted.Redacted<string>;
export type SearchTextList = (string | redacted.Redacted<string>)[];
export declare const SearchTextList: any;
export type SearchContactsMatchType = "MATCH_ALL" | "MATCH_ANY" | "MATCH_EXACT" | "MATCH_NONE" | (string & {});
export declare const SearchContactsMatchType: any;
export interface NameCriteria {
    SearchText: (string | redacted.Redacted<string>)[];
    MatchType: SearchContactsMatchType;
}
export declare const NameCriteria: S.Schema<NameCriteria>;
export type AgentResourceIdList = string[];
export declare const AgentResourceIdList: any;
export type HierarchyGroupIdList = string[];
export declare const HierarchyGroupIdList: any;
export interface AgentHierarchyGroups {
    L1Ids?: string[];
    L2Ids?: string[];
    L3Ids?: string[];
    L4Ids?: string[];
    L5Ids?: string[];
}
export declare const AgentHierarchyGroups: S.Schema<AgentHierarchyGroups>;
export type ChannelList = Channel[];
export declare const ChannelList: any;
export interface TranscriptCriteria {
    ParticipantRole: ParticipantRole;
    SearchText: (string | redacted.Redacted<string>)[];
    MatchType: SearchContactsMatchType;
}
export declare const TranscriptCriteria: S.Schema<TranscriptCriteria>;
export type TranscriptCriteriaList = TranscriptCriteria[];
export declare const TranscriptCriteriaList: any;
export interface Transcript {
    Criteria: TranscriptCriteria[];
    MatchType?: SearchContactsMatchType;
}
export declare const Transcript: S.Schema<Transcript>;
export interface ContactAnalysis {
    Transcript?: Transcript;
}
export declare const ContactAnalysis: S.Schema<ContactAnalysis>;
export type InitiationMethodList = ContactInitiationMethod[];
export declare const InitiationMethodList: any;
export type QueueIdList = string[];
export declare const QueueIdList: any;
export interface SearchableAgentCriteriaStep {
    AgentIds?: string[];
    MatchType?: SearchContactsMatchType;
}
export declare const SearchableAgentCriteriaStep: S.Schema<SearchableAgentCriteriaStep>;
export interface SearchableRoutingCriteriaStep {
    AgentCriteria?: SearchableAgentCriteriaStep;
}
export declare const SearchableRoutingCriteriaStep: S.Schema<SearchableRoutingCriteriaStep>;
export type SearchableRoutingCriteriaStepList = SearchableRoutingCriteriaStep[];
export declare const SearchableRoutingCriteriaStepList: any;
export interface SearchableRoutingCriteria {
    Steps?: SearchableRoutingCriteriaStep[];
}
export declare const SearchableRoutingCriteria: S.Schema<SearchableRoutingCriteria>;
export type SearchContactsTimeRangeConditionType = "NOT_EXISTS" | (string & {});
export declare const SearchContactsTimeRangeConditionType: any;
export interface SearchContactsTimestampCondition {
    Type: SearchContactsTimeRangeType;
    ConditionType: SearchContactsTimeRangeConditionType;
}
export declare const SearchContactsTimestampCondition: S.Schema<SearchContactsTimestampCondition>;
export interface SearchContactsAdditionalTimeRangeCriteria {
    TimeRange?: SearchContactsTimeRange;
    TimestampCondition?: SearchContactsTimestampCondition;
}
export declare const SearchContactsAdditionalTimeRangeCriteria: S.Schema<SearchContactsAdditionalTimeRangeCriteria>;
export type SearchContactsAdditionalTimeRangeCriteriaList = SearchContactsAdditionalTimeRangeCriteria[];
export declare const SearchContactsAdditionalTimeRangeCriteriaList: any;
export interface SearchContactsAdditionalTimeRange {
    Criteria: SearchContactsAdditionalTimeRangeCriteria[];
    MatchType: SearchContactsMatchType;
}
export declare const SearchContactsAdditionalTimeRange: S.Schema<SearchContactsAdditionalTimeRange>;
export type SearchableContactAttributeKey = string | redacted.Redacted<string>;
export type SearchableContactAttributeValue = string | redacted.Redacted<string>;
export type SearchableContactAttributeValueList = (string | redacted.Redacted<string>)[];
export declare const SearchableContactAttributeValueList: any;
export interface SearchableContactAttributesCriteria {
    Key: string | redacted.Redacted<string>;
    Values: (string | redacted.Redacted<string>)[];
}
export declare const SearchableContactAttributesCriteria: S.Schema<SearchableContactAttributesCriteria>;
export type SearchableContactAttributesCriteriaList = SearchableContactAttributesCriteria[];
export declare const SearchableContactAttributesCriteriaList: any;
export interface SearchableContactAttributes {
    Criteria: SearchableContactAttributesCriteria[];
    MatchType?: SearchContactsMatchType;
}
export declare const SearchableContactAttributes: S.Schema<SearchableContactAttributes>;
export type SearchableSegmentAttributeKey = string | redacted.Redacted<string>;
export type SearchableSegmentAttributeValue = string | redacted.Redacted<string>;
export type SearchableSegmentAttributeValueList = (string | redacted.Redacted<string>)[];
export declare const SearchableSegmentAttributeValueList: any;
export interface SearchableSegmentAttributesCriteria {
    Key: string | redacted.Redacted<string>;
    Values: (string | redacted.Redacted<string>)[];
}
export declare const SearchableSegmentAttributesCriteria: S.Schema<SearchableSegmentAttributesCriteria>;
export type SearchableSegmentAttributesCriteriaList = SearchableSegmentAttributesCriteria[];
export declare const SearchableSegmentAttributesCriteriaList: any;
export interface SearchableSegmentAttributes {
    Criteria: SearchableSegmentAttributesCriteria[];
    MatchType?: SearchContactsMatchType;
}
export declare const SearchableSegmentAttributes: S.Schema<SearchableSegmentAttributes>;
export type ActiveRegionList = string[];
export declare const ActiveRegionList: any;
export type AiAgentId = string;
export type AiAgentVersionNumber = number;
export interface AiAgentSearchCriteria {
    Id?: string;
    VersionNumber?: number;
    AiAgentEscalated?: boolean;
    AiUseCase?: AiUseCase;
}
export declare const AiAgentSearchCriteria: S.Schema<AiAgentSearchCriteria>;
export type AiAgentSearchCriteriaList = AiAgentSearchCriteria[];
export declare const AiAgentSearchCriteriaList: any;
export interface AiAgentsCriteria {
    Criteria?: AiAgentSearchCriteria[];
}
export declare const AiAgentsCriteria: S.Schema<AiAgentsCriteria>;
export interface SearchCriteria {
    Name?: NameCriteria;
    AgentIds?: string[];
    AgentHierarchyGroups?: AgentHierarchyGroups;
    Channels?: Channel[];
    ContactAnalysis?: ContactAnalysis;
    InitiationMethods?: ContactInitiationMethod[];
    QueueIds?: string[];
    RoutingCriteria?: SearchableRoutingCriteria;
    AdditionalTimeRange?: SearchContactsAdditionalTimeRange;
    SearchableContactAttributes?: SearchableContactAttributes;
    SearchableSegmentAttributes?: SearchableSegmentAttributes;
    ActiveRegions?: string[];
    ContactTags?: ControlPlaneTagFilter;
    AiAgents?: AiAgentsCriteria;
}
export declare const SearchCriteria: S.Schema<SearchCriteria>;
export type SortableFieldName = "INITIATION_TIMESTAMP" | "SCHEDULED_TIMESTAMP" | "CONNECTED_TO_AGENT_TIMESTAMP" | "DISCONNECT_TIMESTAMP" | "INITIATION_METHOD" | "CHANNEL" | "EXPIRY_TIMESTAMP" | (string & {});
export declare const SortableFieldName: any;
export interface Sort {
    FieldName: SortableFieldName;
    Order: SortOrder;
}
export declare const Sort: S.Schema<Sort>;
export interface SearchContactsRequest {
    InstanceId: string;
    TimeRange: SearchContactsTimeRange;
    SearchCriteria?: SearchCriteria;
    MaxResults?: number;
    NextToken?: string;
    Sort?: Sort;
}
export declare const SearchContactsRequest: S.Schema<SearchContactsRequest>;
export interface ContactSearchSummaryQueueInfo {
    Id?: string;
    EnqueueTimestamp?: Date;
}
export declare const ContactSearchSummaryQueueInfo: S.Schema<ContactSearchSummaryQueueInfo>;
export interface ContactSearchSummaryAgentInfo {
    Id?: string;
    ConnectedToAgentTimestamp?: Date;
}
export declare const ContactSearchSummaryAgentInfo: S.Schema<ContactSearchSummaryAgentInfo>;
export interface ContactSearchSummarySegmentAttributeValue {
    ValueString?: string;
    ValueMap?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
}
export declare const ContactSearchSummarySegmentAttributeValue: S.Schema<ContactSearchSummarySegmentAttributeValue>;
export type ContactSearchSummarySegmentAttributes = {
    [key: string]: ContactSearchSummarySegmentAttributeValue | undefined;
};
export declare const ContactSearchSummarySegmentAttributes: any;
export interface ContactSearchSummaryAiAgentInfo {
    AiAgentVersionId?: string;
    AiAgentEscalated?: boolean;
    AiUseCase?: AiUseCase;
}
export declare const ContactSearchSummaryAiAgentInfo: S.Schema<ContactSearchSummaryAiAgentInfo>;
export type ContactSearchSummaryAiAgentInfoList = ContactSearchSummaryAiAgentInfo[];
export declare const ContactSearchSummaryAiAgentInfoList: any;
export interface ContactSearchSummary {
    Arn?: string;
    Id?: string;
    InitialContactId?: string;
    PreviousContactId?: string;
    InitiationMethod?: ContactInitiationMethod;
    Channel?: Channel;
    QueueInfo?: ContactSearchSummaryQueueInfo;
    AgentInfo?: ContactSearchSummaryAgentInfo;
    InitiationTimestamp?: Date;
    DisconnectTimestamp?: Date;
    ScheduledTimestamp?: Date;
    SegmentAttributes?: {
        [key: string]: ContactSearchSummarySegmentAttributeValue | undefined;
    };
    Name?: string | redacted.Redacted<string>;
    RoutingCriteria?: RoutingCriteria;
    Tags?: {
        [key: string]: string | undefined;
    };
    GlobalResiliencyMetadata?: GlobalResiliencyMetadata;
    AiAgentInfo?: ContactSearchSummaryAiAgentInfo[];
}
export declare const ContactSearchSummary: S.Schema<ContactSearchSummary>;
export type Contacts = ContactSearchSummary[];
export declare const Contacts: any;
export type TotalCount = number;
export interface SearchContactsResponse {
    Contacts: ContactSearchSummary[];
    NextToken?: string;
    TotalCount?: number;
}
export declare const SearchContactsResponse: S.Schema<SearchContactsResponse>;
export interface DataTableSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const DataTableSearchFilter: S.Schema<DataTableSearchFilter>;
export type DataTableSearchConditionList = DataTableSearchCriteria[];
export declare const DataTableSearchConditionList: S.Schema<DataTableSearchConditionList>;
export interface DataTableSearchCriteria {
    OrConditions?: DataTableSearchCriteria[];
    AndConditions?: DataTableSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const DataTableSearchCriteria: S.Schema<DataTableSearchCriteria>;
export interface SearchDataTablesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: DataTableSearchFilter;
    SearchCriteria?: DataTableSearchCriteria;
}
export declare const SearchDataTablesRequest: S.Schema<SearchDataTablesRequest>;
export type DataTableList = DataTable[];
export declare const DataTableList: any;
export interface SearchDataTablesResponse {
    DataTables?: DataTable[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchDataTablesResponse: S.Schema<SearchDataTablesResponse>;
export type EmailAddressSearchConditionList = EmailAddressSearchCriteria[];
export declare const EmailAddressSearchConditionList: S.Schema<EmailAddressSearchConditionList>;
export interface EmailAddressSearchCriteria {
    OrConditions?: EmailAddressSearchCriteria[];
    AndConditions?: EmailAddressSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const EmailAddressSearchCriteria: S.Schema<EmailAddressSearchCriteria>;
export interface EmailAddressSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const EmailAddressSearchFilter: S.Schema<EmailAddressSearchFilter>;
export interface SearchEmailAddressesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
    SearchCriteria?: EmailAddressSearchCriteria;
    SearchFilter?: EmailAddressSearchFilter;
}
export declare const SearchEmailAddressesRequest: S.Schema<SearchEmailAddressesRequest>;
export interface EmailAddressMetadata {
    EmailAddressId?: string;
    EmailAddressArn?: string;
    EmailAddress?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    AliasConfigurations?: AliasConfiguration[];
}
export declare const EmailAddressMetadata: S.Schema<EmailAddressMetadata>;
export type EmailAddressList = EmailAddressMetadata[];
export declare const EmailAddressList: any;
export interface SearchEmailAddressesResponse {
    NextToken?: string;
    EmailAddresses?: EmailAddressMetadata[];
    ApproximateTotalCount?: number;
}
export declare const SearchEmailAddressesResponse: S.Schema<SearchEmailAddressesResponse>;
export type EvaluationFormSearchConditionList = EvaluationFormSearchCriteria[];
export declare const EvaluationFormSearchConditionList: S.Schema<EvaluationFormSearchConditionList>;
export interface EvaluationFormSearchCriteria {
    OrConditions?: EvaluationFormSearchCriteria[];
    AndConditions?: EvaluationFormSearchCriteria[];
    StringCondition?: StringCondition;
    NumberCondition?: NumberCondition;
    BooleanCondition?: BooleanCondition;
    DateTimeCondition?: DateTimeCondition;
}
export declare const EvaluationFormSearchCriteria: S.Schema<EvaluationFormSearchCriteria>;
export interface EvaluationFormSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const EvaluationFormSearchFilter: S.Schema<EvaluationFormSearchFilter>;
export interface SearchEvaluationFormsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: EvaluationFormSearchCriteria;
    SearchFilter?: EvaluationFormSearchFilter;
}
export declare const SearchEvaluationFormsRequest: S.Schema<SearchEvaluationFormsRequest>;
export interface EvaluationFormSearchSummary {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    Title: string;
    Status: EvaluationFormVersionStatus;
    Description?: string;
    CreatedTime: Date;
    CreatedBy: string;
    LastModifiedTime: Date;
    LastModifiedBy: string;
    LastActivatedTime?: Date;
    LastActivatedBy?: string;
    LatestVersion: number;
    ActiveVersion?: number;
    AutoEvaluationEnabled?: boolean;
    EvaluationFormLanguage?: EvaluationFormLanguageCode;
    ContactInteractionType?: ContactInteractionType;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const EvaluationFormSearchSummary: S.Schema<EvaluationFormSearchSummary>;
export type EvaluationFormSearchSummaryList = EvaluationFormSearchSummary[];
export declare const EvaluationFormSearchSummaryList: any;
export interface SearchEvaluationFormsResponse {
    EvaluationFormSearchSummaryList?: EvaluationFormSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchEvaluationFormsResponse: S.Schema<SearchEvaluationFormsResponse>;
export interface HoursOfOperationSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const HoursOfOperationSearchFilter: S.Schema<HoursOfOperationSearchFilter>;
export type HoursOfOperationOverrideSearchConditionList = HoursOfOperationOverrideSearchCriteria[];
export declare const HoursOfOperationOverrideSearchConditionList: S.Schema<HoursOfOperationOverrideSearchConditionList>;
export type DateYearMonthDayFormat = string;
export type DateComparisonType = "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_OR_EQUAL_TO" | "LESS_THAN_OR_EQUAL_TO" | "EQUAL_TO" | (string & {});
export declare const DateComparisonType: any;
export interface DateCondition {
    FieldName?: string;
    Value?: string;
    ComparisonType?: DateComparisonType;
}
export declare const DateCondition: S.Schema<DateCondition>;
export interface HoursOfOperationOverrideSearchCriteria {
    OrConditions?: HoursOfOperationOverrideSearchCriteria[];
    AndConditions?: HoursOfOperationOverrideSearchCriteria[];
    StringCondition?: StringCondition;
    DateCondition?: DateCondition;
}
export declare const HoursOfOperationOverrideSearchCriteria: S.Schema<HoursOfOperationOverrideSearchCriteria>;
export interface SearchHoursOfOperationOverridesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: HoursOfOperationSearchFilter;
    SearchCriteria?: HoursOfOperationOverrideSearchCriteria;
}
export declare const SearchHoursOfOperationOverridesRequest: S.Schema<SearchHoursOfOperationOverridesRequest>;
export interface SearchHoursOfOperationOverridesResponse {
    HoursOfOperationOverrides?: HoursOfOperationOverride[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchHoursOfOperationOverridesResponse: S.Schema<SearchHoursOfOperationOverridesResponse>;
export type HoursOfOperationSearchConditionList = HoursOfOperationSearchCriteria[];
export declare const HoursOfOperationSearchConditionList: S.Schema<HoursOfOperationSearchConditionList>;
export interface HoursOfOperationSearchCriteria {
    OrConditions?: HoursOfOperationSearchCriteria[];
    AndConditions?: HoursOfOperationSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const HoursOfOperationSearchCriteria: S.Schema<HoursOfOperationSearchCriteria>;
export interface SearchHoursOfOperationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: HoursOfOperationSearchFilter;
    SearchCriteria?: HoursOfOperationSearchCriteria;
}
export declare const SearchHoursOfOperationsRequest: S.Schema<SearchHoursOfOperationsRequest>;
export type HoursOfOperationList = HoursOfOperation[];
export declare const HoursOfOperationList: any;
export interface SearchHoursOfOperationsResponse {
    HoursOfOperations?: HoursOfOperation[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchHoursOfOperationsResponse: S.Schema<SearchHoursOfOperationsResponse>;
export interface MetricSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const MetricSearchFilter: S.Schema<MetricSearchFilter>;
export type MetricSearchConditionList = MetricSearchCriteria[];
export declare const MetricSearchConditionList: S.Schema<MetricSearchConditionList>;
export interface MetricSearchCriteria {
    OrConditions?: MetricSearchCriteria[];
    AndConditions?: MetricSearchCriteria[];
    StringCondition?: StringCondition;
    BooleanCondition?: BooleanCondition;
}
export declare const MetricSearchCriteria: S.Schema<MetricSearchCriteria>;
export interface SearchMetricsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: MetricSearchFilter;
    SearchCriteria?: MetricSearchCriteria;
}
export declare const SearchMetricsRequest: S.Schema<SearchMetricsRequest>;
export type MetricSearchSummaryList = MetricDefinition[];
export declare const MetricSearchSummaryList: any;
export interface SearchMetricsResponse {
    Metrics?: MetricDefinition[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchMetricsResponse: S.Schema<SearchMetricsResponse>;
export interface NotificationSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const NotificationSearchFilter: S.Schema<NotificationSearchFilter>;
export type NotificationSearchConditionList = NotificationSearchCriteria[];
export declare const NotificationSearchConditionList: S.Schema<NotificationSearchConditionList>;
export interface NotificationSearchCriteria {
    OrConditions?: NotificationSearchCriteria[];
    AndConditions?: NotificationSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const NotificationSearchCriteria: S.Schema<NotificationSearchCriteria>;
export interface SearchNotificationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: NotificationSearchFilter;
    SearchCriteria?: NotificationSearchCriteria;
}
export declare const SearchNotificationsRequest: S.Schema<SearchNotificationsRequest>;
export interface NotificationSearchSummary {
    Id?: string;
    Arn?: string;
    InstanceId?: string;
    Content?: {
        [key: string]: string | undefined;
    };
    Priority?: NotificationPriority;
    Recipients?: string[];
    CreatedAt?: Date;
    ExpiresAt?: Date;
    LastModifiedRegion?: string;
    LastModifiedTime?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const NotificationSearchSummary: S.Schema<NotificationSearchSummary>;
export type NotificationSearchSummaryList = NotificationSearchSummary[];
export declare const NotificationSearchSummaryList: any;
export interface SearchNotificationsResponse {
    Notifications?: NotificationSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchNotificationsResponse: S.Schema<SearchNotificationsResponse>;
export type PredefinedAttributeSearchConditionList = PredefinedAttributeSearchCriteria[];
export declare const PredefinedAttributeSearchConditionList: S.Schema<PredefinedAttributeSearchConditionList>;
export interface PredefinedAttributeSearchCriteria {
    OrConditions?: PredefinedAttributeSearchCriteria[];
    AndConditions?: PredefinedAttributeSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const PredefinedAttributeSearchCriteria: S.Schema<PredefinedAttributeSearchCriteria>;
export interface SearchPredefinedAttributesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: PredefinedAttributeSearchCriteria;
}
export declare const SearchPredefinedAttributesRequest: S.Schema<SearchPredefinedAttributesRequest>;
export type PredefinedAttributeSearchSummaryList = PredefinedAttribute[];
export declare const PredefinedAttributeSearchSummaryList: any;
export interface SearchPredefinedAttributesResponse {
    PredefinedAttributes?: PredefinedAttribute[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchPredefinedAttributesResponse: S.Schema<SearchPredefinedAttributesResponse>;
export interface PromptSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const PromptSearchFilter: S.Schema<PromptSearchFilter>;
export type PromptSearchConditionList = PromptSearchCriteria[];
export declare const PromptSearchConditionList: S.Schema<PromptSearchConditionList>;
export interface PromptSearchCriteria {
    OrConditions?: PromptSearchCriteria[];
    AndConditions?: PromptSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const PromptSearchCriteria: S.Schema<PromptSearchCriteria>;
export interface SearchPromptsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: PromptSearchFilter;
    SearchCriteria?: PromptSearchCriteria;
}
export declare const SearchPromptsRequest: S.Schema<SearchPromptsRequest>;
export type PromptList = Prompt[];
export declare const PromptList: any;
export interface SearchPromptsResponse {
    Prompts?: Prompt[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchPromptsResponse: S.Schema<SearchPromptsResponse>;
export type MaxResult500 = number;
export interface QueueSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const QueueSearchFilter: S.Schema<QueueSearchFilter>;
export type QueueSearchConditionList = QueueSearchCriteria[];
export declare const QueueSearchConditionList: S.Schema<QueueSearchConditionList>;
export type SearchableQueueType = "STANDARD" | (string & {});
export declare const SearchableQueueType: any;
export interface QueueSearchCriteria {
    OrConditions?: QueueSearchCriteria[];
    AndConditions?: QueueSearchCriteria[];
    StringCondition?: StringCondition;
    QueueTypeCondition?: SearchableQueueType;
}
export declare const QueueSearchCriteria: S.Schema<QueueSearchCriteria>;
export interface SearchQueuesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: QueueSearchFilter;
    SearchCriteria?: QueueSearchCriteria;
}
export declare const SearchQueuesRequest: S.Schema<SearchQueuesRequest>;
export type QueueSearchSummaryList = Queue[];
export declare const QueueSearchSummaryList: any;
export interface SearchQueuesResponse {
    Queues?: Queue[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchQueuesResponse: S.Schema<SearchQueuesResponse>;
export interface QuickConnectSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const QuickConnectSearchFilter: S.Schema<QuickConnectSearchFilter>;
export type QuickConnectSearchConditionList = QuickConnectSearchCriteria[];
export declare const QuickConnectSearchConditionList: S.Schema<QuickConnectSearchConditionList>;
export interface QuickConnectSearchCriteria {
    OrConditions?: QuickConnectSearchCriteria[];
    AndConditions?: QuickConnectSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const QuickConnectSearchCriteria: S.Schema<QuickConnectSearchCriteria>;
export interface SearchQuickConnectsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: QuickConnectSearchFilter;
    SearchCriteria?: QuickConnectSearchCriteria;
}
export declare const SearchQuickConnectsRequest: S.Schema<SearchQuickConnectsRequest>;
export type QuickConnectSearchSummaryList = QuickConnect[];
export declare const QuickConnectSearchSummaryList: any;
export interface SearchQuickConnectsResponse {
    QuickConnects?: QuickConnect[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchQuickConnectsResponse: S.Schema<SearchQuickConnectsResponse>;
export type ResourceTypeList = string[];
export declare const ResourceTypeList: any;
export type TagKeyString = string;
export type TagValueString = string;
export interface TagSearchCondition {
    tagKey?: string;
    tagValue?: string;
    tagKeyComparisonType?: StringComparisonType;
    tagValueComparisonType?: StringComparisonType;
}
export declare const TagSearchCondition: S.Schema<TagSearchCondition>;
export interface ResourceTagsSearchCriteria {
    TagSearchCondition?: TagSearchCondition;
}
export declare const ResourceTagsSearchCriteria: S.Schema<ResourceTagsSearchCriteria>;
export interface SearchResourceTagsRequest {
    InstanceId: string;
    ResourceTypes?: string[];
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: ResourceTagsSearchCriteria;
}
export declare const SearchResourceTagsRequest: S.Schema<SearchResourceTagsRequest>;
export interface TagSet {
    key?: string;
    value?: string;
}
export declare const TagSet: S.Schema<TagSet>;
export type TagsList = TagSet[];
export declare const TagsList: any;
export interface SearchResourceTagsResponse {
    Tags?: TagSet[];
    NextToken?: string;
}
export declare const SearchResourceTagsResponse: S.Schema<SearchResourceTagsResponse>;
export interface RoutingProfileSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const RoutingProfileSearchFilter: S.Schema<RoutingProfileSearchFilter>;
export type RoutingProfileSearchConditionList = RoutingProfileSearchCriteria[];
export declare const RoutingProfileSearchConditionList: S.Schema<RoutingProfileSearchConditionList>;
export interface RoutingProfileSearchCriteria {
    OrConditions?: RoutingProfileSearchCriteria[];
    AndConditions?: RoutingProfileSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const RoutingProfileSearchCriteria: S.Schema<RoutingProfileSearchCriteria>;
export interface SearchRoutingProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: RoutingProfileSearchFilter;
    SearchCriteria?: RoutingProfileSearchCriteria;
}
export declare const SearchRoutingProfilesRequest: S.Schema<SearchRoutingProfilesRequest>;
export type RoutingProfileList = RoutingProfile[];
export declare const RoutingProfileList: any;
export interface SearchRoutingProfilesResponse {
    RoutingProfiles?: RoutingProfile[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchRoutingProfilesResponse: S.Schema<SearchRoutingProfilesResponse>;
export type RulesSearchConditionList = RulesSearchCriteria[];
export declare const RulesSearchConditionList: S.Schema<RulesSearchConditionList>;
export interface RulesSearchCriteria {
    OrConditions?: RulesSearchCriteria[];
    AndConditions?: RulesSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const RulesSearchCriteria: S.Schema<RulesSearchCriteria>;
export interface RuleAttributeAndCondition {
    TagConditions?: TagCondition[];
}
export declare const RuleAttributeAndCondition: S.Schema<RuleAttributeAndCondition>;
export type RuleAttributeOrConditionList = RuleAttributeAndCondition[];
export declare const RuleAttributeOrConditionList: any;
export interface RuleAttributeFilter {
    OrConditions?: RuleAttributeAndCondition[];
    AndCondition?: RuleAttributeAndCondition;
    TagCondition?: TagCondition;
}
export declare const RuleAttributeFilter: S.Schema<RuleAttributeFilter>;
export interface RulesSearchFilter {
    AttributeFilter?: RuleAttributeFilter;
}
export declare const RulesSearchFilter: S.Schema<RulesSearchFilter>;
export interface SearchRulesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
    SearchCriteria?: RulesSearchCriteria;
    SearchFilter?: RulesSearchFilter;
}
export declare const SearchRulesRequest: S.Schema<SearchRulesRequest>;
export interface RuleSearchSummary {
    Name: string;
    RuleId: string;
    RuleArn: string;
    TriggerEventSource: RuleTriggerEventSource;
    ActionSummaries: ActionSummary[];
    RuleCapabilityTiers?: RuleCapabilityTier[];
    PublishStatus: RulePublishStatus;
    CreatedTime: Date;
    LastUpdatedTime: Date;
    LastUpdatedBy: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RuleSearchSummary: S.Schema<RuleSearchSummary>;
export type RuleSearchSummaryList = RuleSearchSummary[];
export declare const RuleSearchSummaryList: any;
export interface SearchRulesResponse {
    Rules: RuleSearchSummary[];
    ApproximateTotalCount?: number;
    NextToken?: string;
}
export declare const SearchRulesResponse: S.Schema<SearchRulesResponse>;
export type SecurityProfileSearchConditionList = SecurityProfileSearchCriteria[];
export declare const SecurityProfileSearchConditionList: S.Schema<SecurityProfileSearchConditionList>;
export interface SecurityProfileSearchCriteria {
    OrConditions?: SecurityProfileSearchCriteria[];
    AndConditions?: SecurityProfileSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const SecurityProfileSearchCriteria: S.Schema<SecurityProfileSearchCriteria>;
export interface SecurityProfilesSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const SecurityProfilesSearchFilter: S.Schema<SecurityProfilesSearchFilter>;
export interface SearchSecurityProfilesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchCriteria?: SecurityProfileSearchCriteria;
    SearchFilter?: SecurityProfilesSearchFilter;
}
export declare const SearchSecurityProfilesRequest: S.Schema<SearchSecurityProfilesRequest>;
export interface SecurityProfileSearchSummary {
    Id?: string;
    OrganizationResourceId?: string;
    Arn?: string;
    SecurityProfileName?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const SecurityProfileSearchSummary: S.Schema<SecurityProfileSearchSummary>;
export type SecurityProfilesSearchSummaryList = SecurityProfileSearchSummary[];
export declare const SecurityProfilesSearchSummaryList: any;
export interface SearchSecurityProfilesResponse {
    SecurityProfiles?: SecurityProfileSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchSecurityProfilesResponse: S.Schema<SearchSecurityProfilesResponse>;
export interface TestCaseSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
}
export declare const TestCaseSearchFilter: S.Schema<TestCaseSearchFilter>;
export type TestCaseSearchConditionList = TestCaseSearchCriteria[];
export declare const TestCaseSearchConditionList: S.Schema<TestCaseSearchConditionList>;
export interface TestCaseSearchCriteria {
    OrConditions?: TestCaseSearchCriteria[];
    AndConditions?: TestCaseSearchCriteria[];
    StringCondition?: StringCondition;
    StatusCondition?: TestCaseStatus;
}
export declare const TestCaseSearchCriteria: S.Schema<TestCaseSearchCriteria>;
export interface SearchTestCasesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: TestCaseSearchFilter;
    SearchCriteria?: TestCaseSearchCriteria;
}
export declare const SearchTestCasesRequest: S.Schema<SearchTestCasesRequest>;
export type TestCaseSearchSummaryList = TestCase[];
export declare const TestCaseSearchSummaryList: any;
export interface SearchTestCasesResponse {
    TestCases?: TestCase[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchTestCasesResponse: S.Schema<SearchTestCasesResponse>;
export interface UserHierarchyGroupSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const UserHierarchyGroupSearchFilter: S.Schema<UserHierarchyGroupSearchFilter>;
export type UserHierarchyGroupSearchConditionList = UserHierarchyGroupSearchCriteria[];
export declare const UserHierarchyGroupSearchConditionList: S.Schema<UserHierarchyGroupSearchConditionList>;
export interface UserHierarchyGroupSearchCriteria {
    OrConditions?: UserHierarchyGroupSearchCriteria[];
    AndConditions?: UserHierarchyGroupSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const UserHierarchyGroupSearchCriteria: S.Schema<UserHierarchyGroupSearchCriteria>;
export interface SearchUserHierarchyGroupsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: UserHierarchyGroupSearchFilter;
    SearchCriteria?: UserHierarchyGroupSearchCriteria;
}
export declare const SearchUserHierarchyGroupsRequest: S.Schema<SearchUserHierarchyGroupsRequest>;
export type UserHierarchyGroupList = HierarchyGroup[];
export declare const UserHierarchyGroupList: any;
export interface SearchUserHierarchyGroupsResponse {
    UserHierarchyGroups?: HierarchyGroup[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchUserHierarchyGroupsResponse: S.Schema<SearchUserHierarchyGroupsResponse>;
export type HierarchyGroupMatchType = "EXACT" | "WITH_CHILD_GROUPS" | (string & {});
export declare const HierarchyGroupMatchType: any;
export interface HierarchyGroupCondition {
    Value?: string;
    HierarchyGroupMatchType?: HierarchyGroupMatchType;
}
export declare const HierarchyGroupCondition: S.Schema<HierarchyGroupCondition>;
export interface AttributeAndCondition {
    TagConditions?: TagCondition[];
    HierarchyGroupCondition?: HierarchyGroupCondition;
}
export declare const AttributeAndCondition: S.Schema<AttributeAndCondition>;
export type AttributeOrConditionList = AttributeAndCondition[];
export declare const AttributeOrConditionList: any;
export interface ControlPlaneUserAttributeFilter {
    OrConditions?: AttributeAndCondition[];
    AndCondition?: AttributeAndCondition;
    TagCondition?: TagCondition;
    HierarchyGroupCondition?: HierarchyGroupCondition;
}
export declare const ControlPlaneUserAttributeFilter: S.Schema<ControlPlaneUserAttributeFilter>;
export interface UserSearchFilter {
    TagFilter?: ControlPlaneTagFilter;
    UserAttributeFilter?: ControlPlaneUserAttributeFilter;
}
export declare const UserSearchFilter: S.Schema<UserSearchFilter>;
export type UserSearchConditionList = UserSearchCriteria[];
export declare const UserSearchConditionList: S.Schema<UserSearchConditionList>;
export type TargetListType = "PROFICIENCIES" | (string & {});
export declare const TargetListType: any;
export interface Condition {
    StringCondition?: StringCondition;
    NumberCondition?: NumberCondition;
}
export declare const Condition: S.Schema<Condition>;
export type Conditions = Condition[];
export declare const Conditions: any;
export interface ListCondition {
    TargetListType?: TargetListType;
    Conditions?: Condition[];
}
export declare const ListCondition: S.Schema<ListCondition>;
export interface UserSearchCriteria {
    OrConditions?: UserSearchCriteria[];
    AndConditions?: UserSearchCriteria[];
    StringCondition?: StringCondition;
    ListCondition?: ListCondition;
    HierarchyGroupCondition?: HierarchyGroupCondition;
}
export declare const UserSearchCriteria: S.Schema<UserSearchCriteria>;
export interface SearchUsersRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: UserSearchFilter;
    SearchCriteria?: UserSearchCriteria;
}
export declare const SearchUsersRequest: S.Schema<SearchUsersRequest>;
export interface UserIdentityInfoLite {
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
}
export declare const UserIdentityInfoLite: S.Schema<UserIdentityInfoLite>;
export interface UserSearchSummary {
    Arn?: string;
    DirectoryUserId?: string;
    HierarchyGroupId?: string;
    Id?: string;
    IdentityInfo?: UserIdentityInfoLite;
    PhoneConfig?: UserPhoneConfig;
    RoutingProfileId?: string;
    SecurityProfileIds?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
    Username?: string;
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
}
export declare const UserSearchSummary: S.Schema<UserSearchSummary>;
export type UserSearchSummaryList = UserSearchSummary[];
export declare const UserSearchSummaryList: any;
export interface SearchUsersResponse {
    Users?: UserSearchSummary[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchUsersResponse: S.Schema<SearchUsersResponse>;
export interface ViewSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const ViewSearchFilter: S.Schema<ViewSearchFilter>;
export type ViewSearchConditionList = ViewSearchCriteria[];
export declare const ViewSearchConditionList: S.Schema<ViewSearchConditionList>;
export interface ViewSearchCriteria {
    OrConditions?: ViewSearchCriteria[];
    AndConditions?: ViewSearchCriteria[];
    StringCondition?: StringCondition;
    ViewTypeCondition?: ViewType;
    ViewStatusCondition?: ViewStatus;
}
export declare const ViewSearchCriteria: S.Schema<ViewSearchCriteria>;
export interface SearchViewsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: ViewSearchFilter;
    SearchCriteria?: ViewSearchCriteria;
}
export declare const SearchViewsRequest: S.Schema<SearchViewsRequest>;
export type ViewSearchSummaryList = View[];
export declare const ViewSearchSummaryList: any;
export interface SearchViewsResponse {
    Views?: View[];
    NextToken?: string;
    ApproximateTotalCount?: number;
}
export declare const SearchViewsResponse: S.Schema<SearchViewsResponse>;
export interface SearchVocabulariesRequest {
    InstanceId: string;
    MaxResults?: number;
    NextToken?: string;
    State?: VocabularyState;
    NameStartsWith?: string;
    LanguageCode?: VocabularyLanguageCode;
}
export declare const SearchVocabulariesRequest: S.Schema<SearchVocabulariesRequest>;
export interface VocabularySummary {
    Name: string;
    Id: string;
    Arn: string;
    LanguageCode: VocabularyLanguageCode;
    State: VocabularyState;
    LastModifiedTime: Date;
    FailureReason?: string;
}
export declare const VocabularySummary: S.Schema<VocabularySummary>;
export type VocabularySummaryList = VocabularySummary[];
export declare const VocabularySummaryList: any;
export interface SearchVocabulariesResponse {
    VocabularySummaryList?: VocabularySummary[];
    NextToken?: string;
}
export declare const SearchVocabulariesResponse: S.Schema<SearchVocabulariesResponse>;
export interface WorkspaceAssociationSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const WorkspaceAssociationSearchFilter: S.Schema<WorkspaceAssociationSearchFilter>;
export type WorkspaceAssociationSearchConditionList = WorkspaceAssociationSearchCriteria[];
export declare const WorkspaceAssociationSearchConditionList: S.Schema<WorkspaceAssociationSearchConditionList>;
export interface WorkspaceAssociationSearchCriteria {
    OrConditions?: WorkspaceAssociationSearchCriteria[];
    AndConditions?: WorkspaceAssociationSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const WorkspaceAssociationSearchCriteria: S.Schema<WorkspaceAssociationSearchCriteria>;
export interface SearchWorkspaceAssociationsRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: WorkspaceAssociationSearchFilter;
    SearchCriteria?: WorkspaceAssociationSearchCriteria;
}
export declare const SearchWorkspaceAssociationsRequest: S.Schema<SearchWorkspaceAssociationsRequest>;
export type WorkspaceAssociatedResourceId = string;
export type WorkspaceAssociatedResourceType = string;
export type WorkspaceAssociatedResourceName = string;
export interface WorkspaceAssociationSearchSummary {
    WorkspaceId?: string;
    WorkspaceArn?: string;
    ResourceId?: string;
    ResourceArn?: string;
    ResourceType?: string;
    ResourceName?: string;
}
export declare const WorkspaceAssociationSearchSummary: S.Schema<WorkspaceAssociationSearchSummary>;
export type WorkspaceAssociationSearchSummaryList = WorkspaceAssociationSearchSummary[];
export declare const WorkspaceAssociationSearchSummaryList: any;
export interface SearchWorkspaceAssociationsResponse {
    NextToken?: string;
    WorkspaceAssociations?: WorkspaceAssociationSearchSummary[];
    ApproximateTotalCount?: number;
}
export declare const SearchWorkspaceAssociationsResponse: S.Schema<SearchWorkspaceAssociationsResponse>;
export interface WorkspaceSearchFilter {
    AttributeFilter?: ControlPlaneAttributeFilter;
}
export declare const WorkspaceSearchFilter: S.Schema<WorkspaceSearchFilter>;
export type WorkspaceSearchConditionList = WorkspaceSearchCriteria[];
export declare const WorkspaceSearchConditionList: S.Schema<WorkspaceSearchConditionList>;
export interface WorkspaceSearchCriteria {
    OrConditions?: WorkspaceSearchCriteria[];
    AndConditions?: WorkspaceSearchCriteria[];
    StringCondition?: StringCondition;
}
export declare const WorkspaceSearchCriteria: S.Schema<WorkspaceSearchCriteria>;
export interface SearchWorkspacesRequest {
    InstanceId: string;
    NextToken?: string;
    MaxResults?: number;
    SearchFilter?: WorkspaceSearchFilter;
    SearchCriteria?: WorkspaceSearchCriteria;
}
export declare const SearchWorkspacesRequest: S.Schema<SearchWorkspacesRequest>;
export interface WorkspaceSearchSummary {
    Id?: string;
    Name?: string;
    Visibility?: Visibility;
    Description?: string;
    Title?: string;
    Arn?: string;
    CreatedAt?: Date;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const WorkspaceSearchSummary: S.Schema<WorkspaceSearchSummary>;
export type WorkspaceSearchSummaryList = WorkspaceSearchSummary[];
export declare const WorkspaceSearchSummaryList: any;
export interface SearchWorkspacesResponse {
    NextToken?: string;
    Workspaces?: WorkspaceSearchSummary[];
    ApproximateTotalCount?: number;
}
export declare const SearchWorkspacesResponse: S.Schema<SearchWorkspacesResponse>;
export type SourceId = string;
export type DestinationId = string;
export type ChatEventType = "DISCONNECT" | "MESSAGE" | "EVENT" | (string & {});
export declare const ChatEventType: any;
export type ChatContentType = string;
export type ChatContent = string;
export interface ChatEvent {
    Type: ChatEventType;
    ContentType?: string;
    Content?: string;
}
export declare const ChatEvent: S.Schema<ChatEvent>;
export type SupportedMessagingContentType = string;
export type SupportedMessagingContentTypes = string[];
export declare const SupportedMessagingContentTypes: any;
export interface ParticipantDetails {
    DisplayName: string;
}
export declare const ParticipantDetails: S.Schema<ParticipantDetails>;
export type ChatStreamingEndpointARN = string;
export interface ChatStreamingConfiguration {
    StreamingEndpointArn: string;
}
export declare const ChatStreamingConfiguration: S.Schema<ChatStreamingConfiguration>;
export interface NewSessionDetails {
    SupportedMessagingContentTypes?: string[];
    ParticipantDetails?: ParticipantDetails;
    Attributes?: {
        [key: string]: string | undefined;
    };
    StreamingConfiguration?: ChatStreamingConfiguration;
}
export declare const NewSessionDetails: S.Schema<NewSessionDetails>;
export interface SendChatIntegrationEventRequest {
    SourceId: string;
    DestinationId: string;
    Subtype?: string;
    Event: ChatEvent;
    NewSessionDetails?: NewSessionDetails;
}
export declare const SendChatIntegrationEventRequest: S.Schema<SendChatIntegrationEventRequest>;
export type NewChatCreated = boolean;
export interface SendChatIntegrationEventResponse {
    InitialContactId?: string;
    NewChatCreated?: boolean;
}
export declare const SendChatIntegrationEventResponse: S.Schema<SendChatIntegrationEventResponse>;
export interface EmailAddressInfo {
    EmailAddress: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
}
export declare const EmailAddressInfo: S.Schema<EmailAddressInfo>;
export type EmailAddressRecipientList = EmailAddressInfo[];
export declare const EmailAddressRecipientList: any;
export interface OutboundAdditionalRecipients {
    CcEmailAddresses?: EmailAddressInfo[];
}
export declare const OutboundAdditionalRecipients: S.Schema<OutboundAdditionalRecipients>;
export type OutboundMessageSourceType = "TEMPLATE" | "RAW" | (string & {});
export declare const OutboundMessageSourceType: any;
export type MessageTemplateKnowledgeBaseId = string;
export type MessageTemplateId = string;
export type CustomerProfileAttributesSerialized = string;
export interface TemplateAttributes {
    CustomAttributes?: {
        [key: string]: string | undefined;
    };
    CustomerProfileAttributes?: string;
}
export declare const TemplateAttributes: S.Schema<TemplateAttributes>;
export interface TemplatedMessageConfig {
    KnowledgeBaseId: string;
    MessageTemplateId: string;
    TemplateAttributes: TemplateAttributes;
}
export declare const TemplatedMessageConfig: S.Schema<TemplatedMessageConfig>;
export type OutboundSubject = string | redacted.Redacted<string>;
export type Body = string | redacted.Redacted<string>;
export type EmailMessageContentType = string;
export interface OutboundRawMessage {
    Subject: string | redacted.Redacted<string>;
    Body: string | redacted.Redacted<string>;
    ContentType: string;
}
export declare const OutboundRawMessage: S.Schema<OutboundRawMessage>;
export interface OutboundEmailContent {
    MessageSourceType: OutboundMessageSourceType;
    TemplatedMessageConfig?: TemplatedMessageConfig;
    RawMessage?: OutboundRawMessage;
}
export declare const OutboundEmailContent: S.Schema<OutboundEmailContent>;
export type TrafficType = "GENERAL" | "CAMPAIGN" | (string & {});
export declare const TrafficType: any;
export type OutboundRequestId = string;
export interface SourceCampaign {
    CampaignId?: string;
    OutboundRequestId?: string;
}
export declare const SourceCampaign: S.Schema<SourceCampaign>;
export interface SendOutboundEmailRequest {
    InstanceId: string;
    FromEmailAddress: EmailAddressInfo;
    DestinationEmailAddress: EmailAddressInfo;
    AdditionalRecipients?: OutboundAdditionalRecipients;
    EmailMessage: OutboundEmailContent;
    TrafficType: TrafficType;
    SourceCampaign?: SourceCampaign;
    ClientToken?: string;
}
export declare const SendOutboundEmailRequest: S.Schema<SendOutboundEmailRequest>;
export interface SendOutboundEmailResponse {
}
export declare const SendOutboundEmailResponse: S.Schema<SendOutboundEmailResponse>;
export type WebBrowserId = string;
export type WebSessionId = string;
export interface WebNotificationSource {
    SourceCampaign: SourceCampaign;
}
export declare const WebNotificationSource: S.Schema<WebNotificationSource>;
export type WidgetId = string;
export type CustomerProfileId = string;
export interface WidgetDestination {
    WidgetId: string;
    ProfileId: string;
}
export declare const WidgetDestination: S.Schema<WidgetDestination>;
export type NotificationType = "WIDGET_VIEW" | "WIDGET_ACTION" | (string & {});
export declare const NotificationType: any;
export type ViewArn = string;
export type PersonalizeDomainName = string;
export type RecommenderName = string;
export type RecommenderContextKey = string;
export type RecommenderContextValue = string;
export type RecommenderContext = {
    [key: string]: string | undefined;
};
export declare const RecommenderContext: any;
export interface RecommenderConfig {
    DomainName: string;
    RecommenderName: string;
    Context?: {
        [key: string]: string | undefined;
    };
}
export declare const RecommenderConfig: S.Schema<RecommenderConfig>;
export interface ContentAttributes {
    RecommenderConfig?: RecommenderConfig;
}
export declare const ContentAttributes: S.Schema<ContentAttributes>;
export interface WebNotificationContent {
    Type: NotificationType;
    ViewArn?: string;
    Attributes?: ContentAttributes;
}
export declare const WebNotificationContent: S.Schema<WebNotificationContent>;
export interface SendOutboundWebNotificationRequest {
    InstanceId: string;
    ClientToken?: string;
    BrowserId: string;
    SessionId: string;
    ExpiresAt: Date;
    Source: WebNotificationSource;
    Destination: WidgetDestination;
    Content: WebNotificationContent;
}
export declare const SendOutboundWebNotificationRequest: S.Schema<SendOutboundWebNotificationRequest>;
export interface SendOutboundWebNotificationResponse {
}
export declare const SendOutboundWebNotificationResponse: S.Schema<SendOutboundWebNotificationResponse>;
export interface AiAgentInput {
    AiAgentId: string;
}
export declare const AiAgentInput: S.Schema<AiAgentInput>;
export interface ChatMessage {
    ContentType: string;
    Content: string;
}
export declare const ChatMessage: S.Schema<ChatMessage>;
export interface PersistentChat {
    RehydrationType?: RehydrationType;
    SourceContactId?: string;
}
export declare const PersistentChat: S.Schema<PersistentChat>;
export interface StartAssistantContactRequest {
    InstanceId: string;
    AiAgent: AiAgentInput;
    ParticipantDetails: ParticipantDetails;
    InitialMessage?: ChatMessage;
    Attributes?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    PersistentChat?: PersistentChat;
    RelatedContactId?: string;
}
export declare const StartAssistantContactRequest: S.Schema<StartAssistantContactRequest>;
export interface StartAssistantContactResponse {
    ContactId?: string;
    ParticipantId?: string;
    ParticipantToken?: string;
    ContinuedFromContactId?: string;
}
export declare const StartAssistantContactResponse: S.Schema<StartAssistantContactResponse>;
export interface StartAttachedFileUploadRequest {
    ClientToken?: string;
    InstanceId: string;
    FileName: string;
    FileSizeInBytes: number;
    UrlExpiryInSeconds?: number;
    FileUseCaseType: FileUseCaseType;
    AssociatedResourceArn: string;
    CreatedBy?: CreatedByInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartAttachedFileUploadRequest: S.Schema<StartAttachedFileUploadRequest>;
export type UrlMetadataSignedHeadersKey = string;
export type UrlMetadataSignedHeadersValue = string;
export type UrlMetadataSignedHeaders = {
    [key: string]: string | undefined;
};
export declare const UrlMetadataSignedHeaders: any;
export interface UploadUrlMetadata {
    Url?: string;
    UrlExpiry?: string;
    HeadersToInclude?: {
        [key: string]: string | undefined;
    };
}
export declare const UploadUrlMetadata: S.Schema<UploadUrlMetadata>;
export interface StartAttachedFileUploadResponse {
    FileArn?: string;
    FileId?: string;
    CreationTime?: string;
    FileStatus?: FileStatusType;
    CreatedBy?: CreatedByInfo;
    UploadUrlMetadata?: UploadUrlMetadata;
}
export declare const StartAttachedFileUploadResponse: S.Schema<StartAttachedFileUploadResponse>;
export type ResponseMode = "INCREMENTAL" | "COMPLETE" | (string & {});
export declare const ResponseMode: any;
export interface ParticipantConfiguration {
    ResponseMode?: ResponseMode;
}
export declare const ParticipantConfiguration: S.Schema<ParticipantConfiguration>;
export type ChatDurationInMinutes = number;
export type CustomerIdNonEmpty = string | redacted.Redacted<string>;
export type DisconnectOnCustomerExitParticipantType = "AGENT" | (string & {});
export declare const DisconnectOnCustomerExitParticipantType: any;
export type DisconnectOnCustomerExit = DisconnectOnCustomerExitParticipantType[];
export declare const DisconnectOnCustomerExit: any;
export interface StartChatContactRequest {
    InstanceId: string;
    ContactFlowId: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    ParticipantDetails: ParticipantDetails;
    ParticipantConfiguration?: ParticipantConfiguration;
    InitialMessage?: ChatMessage;
    ClientToken?: string;
    ChatDurationInMinutes?: number;
    SupportedMessagingContentTypes?: string[];
    PersistentChat?: PersistentChat;
    RelatedContactId?: string;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    CustomerId?: string | redacted.Redacted<string>;
    DisconnectOnCustomerExit?: DisconnectOnCustomerExitParticipantType[];
}
export declare const StartChatContactRequest: S.Schema<StartChatContactRequest>;
export interface StartChatContactResponse {
    ContactId?: string;
    ParticipantId?: string;
    ParticipantToken?: string;
    ContinuedFromContactId?: string;
}
export declare const StartChatContactResponse: S.Schema<StartChatContactResponse>;
export type AnalyticsMode = "PostContact" | "RealTime" | "ContactLens" | "AutomatedInteraction" | (string & {});
export declare const AnalyticsMode: any;
export type AnalyticsModes = AnalyticsMode[];
export declare const AnalyticsModes: any;
export type LanguageLocale = string;
export interface LanguageConfiguration {
    LanguageLocale?: string;
}
export declare const LanguageConfiguration: S.Schema<LanguageConfiguration>;
export type Behavior = "Enable" | "Disable" | (string & {});
export declare const Behavior: any;
export type Policy = "None" | "RedactedOnly" | "RedactedAndOriginal" | (string & {});
export declare const Policy: any;
export type Entity = string;
export type Entities = string[];
export declare const Entities: any;
export type MaskMode = "PII" | "EntityType" | (string & {});
export declare const MaskMode: any;
export interface RedactionConfiguration {
    Behavior: Behavior;
    Policy: Policy;
    Entities?: string[];
    MaskMode?: MaskMode;
}
export declare const RedactionConfiguration: S.Schema<RedactionConfiguration>;
export interface SentimentConfiguration {
    Behavior: Behavior;
}
export declare const SentimentConfiguration: S.Schema<SentimentConfiguration>;
export type SummaryMode = "PostContact" | "AutomatedInteraction" | "ContactChain" | (string & {});
export declare const SummaryMode: any;
export type SummaryModes = SummaryMode[];
export declare const SummaryModes: any;
export interface SummaryConfiguration {
    SummaryModes: SummaryMode[];
}
export declare const SummaryConfiguration: S.Schema<SummaryConfiguration>;
export interface RulesConfiguration {
    Behavior?: Behavior;
}
export declare const RulesConfiguration: S.Schema<RulesConfiguration>;
export interface AnalyticsConfiguration {
    LanguageConfiguration: LanguageConfiguration;
    RedactionConfiguration: RedactionConfiguration;
    SentimentConfiguration: SentimentConfiguration;
    SummaryConfiguration: SummaryConfiguration;
    RulesConfiguration: RulesConfiguration;
}
export declare const AnalyticsConfiguration: S.Schema<AnalyticsConfiguration>;
export interface StartContactConversationalAnalyticsJobRequest {
    InstanceId: string;
    ContactId: string;
    AnalyticsModes: AnalyticsMode[];
    AnalyticsConfiguration: AnalyticsConfiguration;
    ClientToken?: string;
}
export declare const StartContactConversationalAnalyticsJobRequest: S.Schema<StartContactConversationalAnalyticsJobRequest>;
export interface StartContactConversationalAnalyticsJobResponse {
    InstanceId?: string;
    ContactId?: string;
}
export declare const StartContactConversationalAnalyticsJobResponse: S.Schema<StartContactConversationalAnalyticsJobResponse>;
export interface AutoEvaluationConfiguration {
    Enabled: boolean;
}
export declare const AutoEvaluationConfiguration: S.Schema<AutoEvaluationConfiguration>;
export interface StartContactEvaluationRequest {
    InstanceId: string;
    ContactId: string;
    EvaluationFormId: string;
    AutoEvaluationConfiguration?: AutoEvaluationConfiguration;
    ClientToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartContactEvaluationRequest: S.Schema<StartContactEvaluationRequest>;
export interface StartContactEvaluationResponse {
    EvaluationId: string;
    EvaluationArn: string;
}
export declare const StartContactEvaluationResponse: S.Schema<StartContactEvaluationResponse>;
export type ContactMediaProcessingFailureMode = "DELIVER_UNPROCESSED_MESSAGE" | "DO_NOT_DELIVER_UNPROCESSED_MESSAGE" | (string & {});
export declare const ContactMediaProcessingFailureMode: any;
export interface StartContactMediaProcessingRequest {
    InstanceId?: string;
    ContactId?: string;
    ProcessorArn?: string;
    FailureMode?: ContactMediaProcessingFailureMode;
}
export declare const StartContactMediaProcessingRequest: S.Schema<StartContactMediaProcessingRequest>;
export interface StartContactMediaProcessingResponse {
}
export declare const StartContactMediaProcessingResponse: S.Schema<StartContactMediaProcessingResponse>;
export type VoiceRecordingTrack = "FROM_AGENT" | "TO_AGENT" | "ALL" | (string & {});
export declare const VoiceRecordingTrack: any;
export type IvrRecordingTrack = "ALL" | (string & {});
export declare const IvrRecordingTrack: any;
export interface VoiceRecordingConfiguration {
    VoiceRecordingTrack?: VoiceRecordingTrack;
    IvrRecordingTrack?: IvrRecordingTrack;
}
export declare const VoiceRecordingConfiguration: S.Schema<VoiceRecordingConfiguration>;
export interface StartContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    VoiceRecordingConfiguration: VoiceRecordingConfiguration;
}
export declare const StartContactRecordingRequest: S.Schema<StartContactRecordingRequest>;
export interface StartContactRecordingResponse {
}
export declare const StartContactRecordingResponse: S.Schema<StartContactRecordingResponse>;
export interface StartContactStreamingRequest {
    InstanceId: string;
    ContactId: string;
    ChatStreamingConfiguration: ChatStreamingConfiguration;
    ClientToken: string;
}
export declare const StartContactStreamingRequest: S.Schema<StartContactStreamingRequest>;
export type StreamingId = string;
export interface StartContactStreamingResponse {
    StreamingId: string;
}
export declare const StartContactStreamingResponse: S.Schema<StartContactStreamingResponse>;
export type InboundMessageSourceType = "RAW" | (string & {});
export declare const InboundMessageSourceType: any;
export type InboundSubject = string | redacted.Redacted<string>;
export type EmailHeaderType = "REFERENCES" | "MESSAGE_ID" | "IN_REPLY_TO" | "X_SES_SPAM_VERDICT" | "X_SES_VIRUS_VERDICT" | (string & {});
export declare const EmailHeaderType: any;
export type EmailHeaderValue = string;
export type EmailHeaders = {
    [key in EmailHeaderType]?: string;
};
export declare const EmailHeaders: any;
export interface InboundRawMessage {
    Subject: string | redacted.Redacted<string>;
    Body: string | redacted.Redacted<string>;
    ContentType: string;
    Headers?: {
        [key: string]: string | undefined;
    };
}
export declare const InboundRawMessage: S.Schema<InboundRawMessage>;
export interface InboundEmailContent {
    MessageSourceType: InboundMessageSourceType;
    RawMessage?: InboundRawMessage;
}
export declare const InboundEmailContent: S.Schema<InboundEmailContent>;
export interface InboundAdditionalRecipients {
    ToAddresses?: EmailAddressInfo[];
    CcAddresses?: EmailAddressInfo[];
}
export declare const InboundAdditionalRecipients: S.Schema<InboundAdditionalRecipients>;
export type PreSignedAttachmentUrl = string;
export interface EmailAttachment {
    FileName: string;
    S3Url: string;
}
export declare const EmailAttachment: S.Schema<EmailAttachment>;
export type EmailAttachments = EmailAttachment[];
export declare const EmailAttachments: any;
export interface StartEmailContactRequest {
    InstanceId: string;
    FromEmailAddress: EmailAddressInfo;
    DestinationEmailAddress: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    Name?: string | redacted.Redacted<string>;
    EmailMessage: InboundEmailContent;
    AdditionalRecipients?: InboundAdditionalRecipients;
    Attachments?: EmailAttachment[];
    ContactFlowId?: string;
    RelatedContactId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    ClientToken?: string;
}
export declare const StartEmailContactRequest: S.Schema<StartEmailContactRequest>;
export interface StartEmailContactResponse {
    ContactId?: string;
}
export declare const StartEmailContactResponse: S.Schema<StartEmailContactResponse>;
export interface StartEvaluationFormValidationRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
}
export declare const StartEvaluationFormValidationRequest: S.Schema<StartEvaluationFormValidationRequest>;
export interface StartEvaluationFormValidationResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export declare const StartEvaluationFormValidationResponse: S.Schema<StartEvaluationFormValidationResponse>;
export interface StartOutboundChatContactRequest {
    SourceEndpoint: Endpoint;
    DestinationEndpoint: Endpoint;
    InstanceId: string;
    SegmentAttributes: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    Attributes?: {
        [key: string]: string | undefined;
    };
    ContactFlowId: string;
    ChatDurationInMinutes?: number;
    ParticipantDetails?: ParticipantDetails;
    InitialSystemMessage?: ChatMessage;
    InitialTemplatedSystemMessage?: TemplatedMessageConfig;
    RelatedContactId?: string;
    SupportedMessagingContentTypes?: string[];
    ClientToken?: string;
}
export declare const StartOutboundChatContactRequest: S.Schema<StartOutboundChatContactRequest>;
export interface StartOutboundChatContactResponse {
    ContactId?: string;
}
export declare const StartOutboundChatContactResponse: S.Schema<StartOutboundChatContactResponse>;
export interface StartOutboundEmailContactRequest {
    InstanceId: string;
    ContactId: string;
    FromEmailAddress?: EmailAddressInfo;
    DestinationEmailAddress: EmailAddressInfo;
    AdditionalRecipients?: OutboundAdditionalRecipients;
    EmailMessage: OutboundEmailContent;
    ClientToken?: string;
}
export declare const StartOutboundEmailContactRequest: S.Schema<StartOutboundEmailContactRequest>;
export interface StartOutboundEmailContactResponse {
    ContactId?: string;
}
export declare const StartOutboundEmailContactResponse: S.Schema<StartOutboundEmailContactResponse>;
export interface AnswerMachineDetectionConfig {
    EnableAnswerMachineDetection?: boolean;
    AwaitAnswerMachinePrompt?: boolean;
}
export declare const AnswerMachineDetectionConfig: S.Schema<AnswerMachineDetectionConfig>;
export type RingTimeoutInSeconds = number;
export interface StartOutboundVoiceContactRequest {
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    RelatedContactId?: string;
    DestinationPhoneNumber: string;
    ContactFlowId: string;
    InstanceId: string;
    ClientToken?: string;
    SourcePhoneNumber?: string;
    QueueId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    AnswerMachineDetectionConfig?: AnswerMachineDetectionConfig;
    CampaignId?: string;
    TrafficType?: TrafficType;
    OutboundStrategy?: OutboundStrategy;
    RingTimeoutInSeconds?: number;
}
export declare const StartOutboundVoiceContactRequest: S.Schema<StartOutboundVoiceContactRequest>;
export interface StartOutboundVoiceContactResponse {
    ContactId?: string;
}
export declare const StartOutboundVoiceContactResponse: S.Schema<StartOutboundVoiceContactResponse>;
export interface StartScreenSharingRequest {
    ClientToken?: string;
    InstanceId: string;
    ContactId: string;
}
export declare const StartScreenSharingRequest: S.Schema<StartScreenSharingRequest>;
export interface StartScreenSharingResponse {
}
export declare const StartScreenSharingResponse: S.Schema<StartScreenSharingResponse>;
export interface TaskAttachment {
    FileName: string;
    S3Url: string;
}
export declare const TaskAttachment: S.Schema<TaskAttachment>;
export type TaskAttachments = TaskAttachment[];
export declare const TaskAttachments: any;
export interface StartTaskContactRequest {
    InstanceId: string;
    PreviousContactId?: string;
    ContactFlowId?: string;
    Attributes?: {
        [key: string]: string | undefined;
    };
    Name: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    Description?: string | redacted.Redacted<string>;
    ClientToken?: string;
    ScheduledTime?: Date;
    TaskTemplateId?: string;
    QuickConnectId?: string;
    RelatedContactId?: string;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    Attachments?: TaskAttachment[];
}
export declare const StartTaskContactRequest: S.Schema<StartTaskContactRequest>;
export interface StartTaskContactResponse {
    ContactId?: string;
}
export declare const StartTaskContactResponse: S.Schema<StartTaskContactResponse>;
export interface StartTestCaseExecutionRequest {
    InstanceId: string;
    TestCaseId: string;
    ClientToken?: string;
}
export declare const StartTestCaseExecutionRequest: S.Schema<StartTestCaseExecutionRequest>;
export interface StartTestCaseExecutionResponse {
    TestCaseExecutionId?: string;
    TestCaseId?: string;
    Status?: TestCaseExecutionStatus;
}
export declare const StartTestCaseExecutionResponse: S.Schema<StartTestCaseExecutionResponse>;
export interface AllowedCapabilities {
    Customer?: ParticipantCapabilities;
    Agent?: ParticipantCapabilities;
}
export declare const AllowedCapabilities: S.Schema<AllowedCapabilities>;
export interface StartWebRTCContactRequest {
    Attributes?: {
        [key: string]: string | undefined;
    };
    ClientToken?: string;
    ContactFlowId: string;
    InstanceId: string;
    AllowedCapabilities?: AllowedCapabilities;
    ParticipantDetails: ParticipantDetails;
    RelatedContactId?: string;
    References?: {
        [key: string]: Reference | undefined;
    };
    Description?: string | redacted.Redacted<string>;
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
}
export declare const StartWebRTCContactRequest: S.Schema<StartWebRTCContactRequest>;
export type AttendeeId = string;
export type JoinToken = string | redacted.Redacted<string>;
export interface Attendee {
    AttendeeId?: string;
    JoinToken?: string | redacted.Redacted<string>;
}
export declare const Attendee: S.Schema<Attendee>;
export type MediaRegion = string;
export interface MediaPlacement {
    AudioHostUrl?: string;
    AudioFallbackUrl?: string;
    SignalingUrl?: string;
    TurnControlUrl?: string;
    EventIngestionUrl?: string;
}
export declare const MediaPlacement: S.Schema<MediaPlacement>;
export type MeetingFeatureStatus = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export declare const MeetingFeatureStatus: any;
export interface AudioFeatures {
    EchoReduction?: MeetingFeatureStatus;
}
export declare const AudioFeatures: S.Schema<AudioFeatures>;
export interface MeetingFeaturesConfiguration {
    Audio?: AudioFeatures;
}
export declare const MeetingFeaturesConfiguration: S.Schema<MeetingFeaturesConfiguration>;
export type MeetingId = string;
export interface Meeting {
    MediaRegion?: string;
    MediaPlacement?: MediaPlacement;
    MeetingFeatures?: MeetingFeaturesConfiguration;
    MeetingId?: string;
}
export declare const Meeting: S.Schema<Meeting>;
export interface ConnectionData {
    Attendee?: Attendee;
    Meeting?: Meeting;
}
export declare const ConnectionData: S.Schema<ConnectionData>;
export interface StartWebRTCContactResponse {
    ConnectionData?: ConnectionData;
    ContactId?: string;
    ParticipantId?: string;
    ParticipantToken?: string;
}
export declare const StartWebRTCContactResponse: S.Schema<StartWebRTCContactResponse>;
export type DisconnectReasonCode = string;
export interface DisconnectReason {
    Code?: string;
}
export declare const DisconnectReason: S.Schema<DisconnectReason>;
export interface StopContactRequest {
    ContactId: string;
    InstanceId: string;
    DisconnectReason?: DisconnectReason;
}
export declare const StopContactRequest: S.Schema<StopContactRequest>;
export interface StopContactResponse {
}
export declare const StopContactResponse: S.Schema<StopContactResponse>;
export interface StopContactMediaProcessingRequest {
    InstanceId?: string;
    ContactId?: string;
}
export declare const StopContactMediaProcessingRequest: S.Schema<StopContactMediaProcessingRequest>;
export interface StopContactMediaProcessingResponse {
}
export declare const StopContactMediaProcessingResponse: S.Schema<StopContactMediaProcessingResponse>;
export interface StopContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    ContactRecordingType?: ContactRecordingType;
}
export declare const StopContactRecordingRequest: S.Schema<StopContactRecordingRequest>;
export interface StopContactRecordingResponse {
}
export declare const StopContactRecordingResponse: S.Schema<StopContactRecordingResponse>;
export interface StopContactStreamingRequest {
    InstanceId: string;
    ContactId: string;
    StreamingId: string;
}
export declare const StopContactStreamingRequest: S.Schema<StopContactStreamingRequest>;
export interface StopContactStreamingResponse {
}
export declare const StopContactStreamingResponse: S.Schema<StopContactStreamingResponse>;
export interface StopTestCaseExecutionRequest {
    InstanceId: string;
    TestCaseExecutionId: string;
    TestCaseId: string;
    ClientToken?: string;
}
export declare const StopTestCaseExecutionRequest: S.Schema<StopTestCaseExecutionRequest>;
export interface StopTestCaseExecutionResponse {
}
export declare const StopTestCaseExecutionResponse: S.Schema<StopTestCaseExecutionResponse>;
export interface EvaluationAnswerInput {
    Value?: EvaluationAnswerData;
}
export declare const EvaluationAnswerInput: S.Schema<EvaluationAnswerInput>;
export type EvaluationAnswersInputMap = {
    [key: string]: EvaluationAnswerInput | undefined;
};
export declare const EvaluationAnswersInputMap: any;
export type EvaluatorUserUnion = {
    ConnectUserArn: string;
};
export declare const EvaluatorUserUnion: any;
export interface SubmitContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
    Answers?: {
        [key: string]: EvaluationAnswerInput | undefined;
    };
    Notes?: {
        [key: string]: EvaluationNote | undefined;
    };
    SubmittedBy?: EvaluatorUserUnion;
}
export declare const SubmitContactEvaluationRequest: S.Schema<SubmitContactEvaluationRequest>;
export interface SubmitContactEvaluationResponse {
    EvaluationId: string;
    EvaluationArn: string;
}
export declare const SubmitContactEvaluationResponse: S.Schema<SubmitContactEvaluationResponse>;
export interface SuspendContactRecordingRequest {
    InstanceId: string;
    ContactId: string;
    InitialContactId: string;
    ContactRecordingType?: ContactRecordingType;
}
export declare const SuspendContactRecordingRequest: S.Schema<SuspendContactRecordingRequest>;
export interface SuspendContactRecordingResponse {
}
export declare const SuspendContactRecordingResponse: S.Schema<SuspendContactRecordingResponse>;
export interface TagContactRequest {
    ContactId: string;
    InstanceId: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagContactRequest: S.Schema<TagContactRequest>;
export interface TagContactResponse {
}
export declare const TagContactResponse: S.Schema<TagContactResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface TransferContactRequest {
    InstanceId: string;
    ContactId: string;
    QueueId?: string;
    UserId?: string;
    ContactFlowId: string;
    ClientToken?: string;
}
export declare const TransferContactRequest: S.Schema<TransferContactRequest>;
export interface TransferContactResponse {
    ContactId?: string;
    ContactArn?: string;
}
export declare const TransferContactResponse: S.Schema<TransferContactResponse>;
export type ContactTagKeys = string[];
export declare const ContactTagKeys: any;
export interface UntagContactRequest {
    ContactId: string;
    InstanceId: string;
    TagKeys: string[];
}
export declare const UntagContactRequest: S.Schema<UntagContactRequest>;
export interface UntagContactResponse {
}
export declare const UntagContactResponse: S.Schema<UntagContactResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type UpdateAgentStatusDescription = string;
export interface UpdateAgentStatusRequest {
    InstanceId: string;
    AgentStatusId: string;
    Name?: string;
    Description?: string;
    State?: AgentStatusState;
    DisplayOrder?: number;
    ResetOrderNumber?: boolean;
}
export declare const UpdateAgentStatusRequest: S.Schema<UpdateAgentStatusRequest>;
export interface UpdateAgentStatusResponse {
}
export declare const UpdateAgentStatusResponse: S.Schema<UpdateAgentStatusResponse>;
export interface UpdateAttachedFilesConfigurationRequest {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
}
export declare const UpdateAttachedFilesConfigurationRequest: S.Schema<UpdateAttachedFilesConfigurationRequest>;
export interface UpdateAttachedFilesConfigurationResponse {
    InstanceId: string;
    AttachmentScope: AttachmentScope;
    MaximumSizeLimitInBytes?: number;
    ExtensionConfiguration?: ExtensionConfiguration;
    LastModifiedTime?: Date;
}
export declare const UpdateAttachedFilesConfigurationResponse: S.Schema<UpdateAttachedFilesConfigurationResponse>;
export interface UpdateAuthenticationProfileRequest {
    AuthenticationProfileId: string;
    InstanceId: string;
    Name?: string;
    Description?: string;
    AllowedIps?: string[];
    BlockedIps?: string[];
    PeriodicSessionDuration?: number;
    SessionInactivityDuration?: number;
    SessionInactivityHandlingEnabled?: boolean;
}
export declare const UpdateAuthenticationProfileRequest: S.Schema<UpdateAuthenticationProfileRequest>;
export interface UpdateAuthenticationProfileResponse {
}
export declare const UpdateAuthenticationProfileResponse: S.Schema<UpdateAuthenticationProfileResponse>;
export interface QueueInfoInput {
    Id?: string;
}
export declare const QueueInfoInput: S.Schema<QueueInfoInput>;
export interface UpdateContactRequest {
    InstanceId: string;
    ContactId: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string>;
    References?: {
        [key: string]: Reference | undefined;
    };
    SegmentAttributes?: {
        [key: string]: SegmentAttributeValue | undefined;
    };
    QueueInfo?: QueueInfoInput;
    UserInfo?: UserInfo;
    CustomerEndpoint?: Endpoint;
    SystemEndpoint?: Endpoint;
}
export declare const UpdateContactRequest: S.Schema<UpdateContactRequest>;
export interface UpdateContactResponse {
}
export declare const UpdateContactResponse: S.Schema<UpdateContactResponse>;
export interface UpdateContactAttributesRequest {
    InitialContactId: string;
    InstanceId: string;
    Attributes: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateContactAttributesRequest: S.Schema<UpdateContactAttributesRequest>;
export interface UpdateContactAttributesResponse {
}
export declare const UpdateContactAttributesResponse: S.Schema<UpdateContactAttributesResponse>;
export interface UpdateContactEvaluationRequest {
    InstanceId: string;
    EvaluationId: string;
    Answers?: {
        [key: string]: EvaluationAnswerInput | undefined;
    };
    Notes?: {
        [key: string]: EvaluationNote | undefined;
    };
    UpdatedBy?: EvaluatorUserUnion;
}
export declare const UpdateContactEvaluationRequest: S.Schema<UpdateContactEvaluationRequest>;
export interface UpdateContactEvaluationResponse {
    EvaluationId: string;
    EvaluationArn: string;
}
export declare const UpdateContactEvaluationResponse: S.Schema<UpdateContactEvaluationResponse>;
export interface UpdateContactFlowContentRequest {
    InstanceId: string;
    ContactFlowId: string;
    Content: string;
}
export declare const UpdateContactFlowContentRequest: S.Schema<UpdateContactFlowContentRequest>;
export interface UpdateContactFlowContentResponse {
}
export declare const UpdateContactFlowContentResponse: S.Schema<UpdateContactFlowContentResponse>;
export interface UpdateContactFlowMetadataRequest {
    InstanceId: string;
    ContactFlowId: string;
    Name?: string;
    Description?: string;
    ContactFlowState?: ContactFlowState;
}
export declare const UpdateContactFlowMetadataRequest: S.Schema<UpdateContactFlowMetadataRequest>;
export interface UpdateContactFlowMetadataResponse {
}
export declare const UpdateContactFlowMetadataResponse: S.Schema<UpdateContactFlowMetadataResponse>;
export interface UpdateContactFlowModuleAliasRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    AliasId: string;
    Name?: string;
    Description?: string;
    ContactFlowModuleVersion?: number;
}
export declare const UpdateContactFlowModuleAliasRequest: S.Schema<UpdateContactFlowModuleAliasRequest>;
export interface UpdateContactFlowModuleAliasResponse {
}
export declare const UpdateContactFlowModuleAliasResponse: S.Schema<UpdateContactFlowModuleAliasResponse>;
export interface UpdateContactFlowModuleContentRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    Content?: string;
    Settings?: string;
}
export declare const UpdateContactFlowModuleContentRequest: S.Schema<UpdateContactFlowModuleContentRequest>;
export interface UpdateContactFlowModuleContentResponse {
}
export declare const UpdateContactFlowModuleContentResponse: S.Schema<UpdateContactFlowModuleContentResponse>;
export interface UpdateContactFlowModuleMetadataRequest {
    InstanceId: string;
    ContactFlowModuleId: string;
    Name?: string;
    Description?: string;
    State?: ContactFlowModuleState;
}
export declare const UpdateContactFlowModuleMetadataRequest: S.Schema<UpdateContactFlowModuleMetadataRequest>;
export interface UpdateContactFlowModuleMetadataResponse {
}
export declare const UpdateContactFlowModuleMetadataResponse: S.Schema<UpdateContactFlowModuleMetadataResponse>;
export interface UpdateContactFlowNameRequest {
    InstanceId: string;
    ContactFlowId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateContactFlowNameRequest: S.Schema<UpdateContactFlowNameRequest>;
export interface UpdateContactFlowNameResponse {
}
export declare const UpdateContactFlowNameResponse: S.Schema<UpdateContactFlowNameResponse>;
export interface RoutingCriteriaInputStepExpiry {
    DurationInSeconds?: number;
}
export declare const RoutingCriteriaInputStepExpiry: S.Schema<RoutingCriteriaInputStepExpiry>;
export interface RoutingCriteriaInputStep {
    Expiry?: RoutingCriteriaInputStepExpiry;
    Expression?: Expression;
}
export declare const RoutingCriteriaInputStep: S.Schema<RoutingCriteriaInputStep>;
export type RoutingCriteriaInputSteps = RoutingCriteriaInputStep[];
export declare const RoutingCriteriaInputSteps: any;
export interface RoutingCriteriaInput {
    Steps?: RoutingCriteriaInputStep[];
}
export declare const RoutingCriteriaInput: S.Schema<RoutingCriteriaInput>;
export interface UpdateContactRoutingDataRequest {
    InstanceId: string;
    ContactId: string;
    QueueTimeAdjustmentSeconds?: number;
    QueuePriority?: number;
    RoutingCriteria?: RoutingCriteriaInput;
}
export declare const UpdateContactRoutingDataRequest: S.Schema<UpdateContactRoutingDataRequest>;
export interface UpdateContactRoutingDataResponse {
}
export declare const UpdateContactRoutingDataResponse: S.Schema<UpdateContactRoutingDataResponse>;
export interface UpdateContactScheduleRequest {
    InstanceId: string;
    ContactId: string;
    ScheduledTime: Date;
}
export declare const UpdateContactScheduleRequest: S.Schema<UpdateContactScheduleRequest>;
export interface UpdateContactScheduleResponse {
}
export declare const UpdateContactScheduleResponse: S.Schema<UpdateContactScheduleResponse>;
export interface UpdateContactTaskTemplateRequest {
    InstanceId: string;
    TaskTemplateId: string;
    ContactId: string;
}
export declare const UpdateContactTaskTemplateRequest: S.Schema<UpdateContactTaskTemplateRequest>;
export interface UpdateContactTaskTemplateResponse {
}
export declare const UpdateContactTaskTemplateResponse: S.Schema<UpdateContactTaskTemplateResponse>;
export interface UpdateDataTableAttributeRequest {
    InstanceId: string;
    DataTableId: string;
    AttributeName: string;
    Name: string;
    ValueType: DataTableAttributeValueType;
    Description?: string;
    Primary?: boolean;
    Validation?: Validation;
}
export declare const UpdateDataTableAttributeRequest: S.Schema<UpdateDataTableAttributeRequest>;
export interface UpdateDataTableAttributeResponse {
    Name: string;
    LockVersion: DataTableLockVersion;
}
export declare const UpdateDataTableAttributeResponse: S.Schema<UpdateDataTableAttributeResponse>;
export interface UpdateDataTableMetadataRequest {
    InstanceId: string;
    DataTableId: string;
    Name: string;
    Description?: string;
    ValueLockLevel: DataTableLockLevel;
    TimeZone: string;
}
export declare const UpdateDataTableMetadataRequest: S.Schema<UpdateDataTableMetadataRequest>;
export interface UpdateDataTableMetadataResponse {
    LockVersion: DataTableLockVersion;
}
export declare const UpdateDataTableMetadataResponse: S.Schema<UpdateDataTableMetadataResponse>;
export interface UpdateDataTablePrimaryValuesRequest {
    InstanceId: string;
    DataTableId: string;
    PrimaryValues: PrimaryValue[];
    NewPrimaryValues: PrimaryValue[];
    LockVersion: DataTableLockVersion;
}
export declare const UpdateDataTablePrimaryValuesRequest: S.Schema<UpdateDataTablePrimaryValuesRequest>;
export interface UpdateDataTablePrimaryValuesResponse {
    LockVersion: DataTableLockVersion;
}
export declare const UpdateDataTablePrimaryValuesResponse: S.Schema<UpdateDataTablePrimaryValuesResponse>;
export interface UpdateEmailAddressMetadataRequest {
    InstanceId: string;
    EmailAddressId: string;
    Description?: string | redacted.Redacted<string>;
    DisplayName?: string | redacted.Redacted<string>;
    ClientToken?: string;
}
export declare const UpdateEmailAddressMetadataRequest: S.Schema<UpdateEmailAddressMetadataRequest>;
export interface UpdateEmailAddressMetadataResponse {
    EmailAddressId?: string;
    EmailAddressArn?: string;
}
export declare const UpdateEmailAddressMetadataResponse: S.Schema<UpdateEmailAddressMetadataResponse>;
export interface UpdateEvaluationFormRequest {
    InstanceId: string;
    EvaluationFormId: string;
    EvaluationFormVersion: number;
    CreateNewVersion?: boolean;
    Title: string;
    Description?: string;
    Items: EvaluationFormItem[];
    ScoringStrategy?: EvaluationFormScoringStrategy;
    AutoEvaluationConfiguration?: EvaluationFormAutoEvaluationConfiguration;
    ReviewConfiguration?: EvaluationReviewConfiguration;
    AsDraft?: boolean;
    ClientToken?: string;
    TargetConfiguration?: EvaluationFormTargetConfiguration;
    LanguageConfiguration?: EvaluationFormLanguageConfiguration;
}
export declare const UpdateEvaluationFormRequest: S.Schema<UpdateEvaluationFormRequest>;
export interface UpdateEvaluationFormResponse {
    EvaluationFormId: string;
    EvaluationFormArn: string;
    EvaluationFormVersion: number;
}
export declare const UpdateEvaluationFormResponse: S.Schema<UpdateEvaluationFormResponse>;
export interface UpdateExtractionDefinitionRequest {
    ClientToken?: string;
    ExtractionDefinitionId: string;
    InstanceId: string;
    Name: string;
    ExtractionConfiguration: ExtractionConfiguration;
    Display?: ExtractionDefinitionDisplay;
}
export declare const UpdateExtractionDefinitionRequest: S.Schema<UpdateExtractionDefinitionRequest>;
export interface UpdateExtractionDefinitionResponse {
}
export declare const UpdateExtractionDefinitionResponse: S.Schema<UpdateExtractionDefinitionResponse>;
export type UpdateHoursOfOperationDescription = string;
export interface UpdateHoursOfOperationRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    Name?: string;
    Description?: string;
    TimeZone?: string;
    Config?: HoursOfOperationConfig[];
}
export declare const UpdateHoursOfOperationRequest: S.Schema<UpdateHoursOfOperationRequest>;
export interface UpdateHoursOfOperationResponse {
}
export declare const UpdateHoursOfOperationResponse: S.Schema<UpdateHoursOfOperationResponse>;
export interface UpdateHoursOfOperationOverrideRequest {
    InstanceId: string;
    HoursOfOperationId: string;
    HoursOfOperationOverrideId: string;
    Name?: string;
    Description?: string;
    Config?: HoursOfOperationOverrideConfig[];
    EffectiveFrom?: string;
    EffectiveTill?: string;
    RecurrenceConfig?: RecurrenceConfig;
    OverrideType?: OverrideType;
}
export declare const UpdateHoursOfOperationOverrideRequest: S.Schema<UpdateHoursOfOperationOverrideRequest>;
export interface UpdateHoursOfOperationOverrideResponse {
}
export declare const UpdateHoursOfOperationOverrideResponse: S.Schema<UpdateHoursOfOperationOverrideResponse>;
export interface UpdateInstanceAttributeRequest {
    InstanceId: string;
    AttributeType: InstanceAttributeType;
    Value: string;
    ClientToken?: string;
}
export declare const UpdateInstanceAttributeRequest: S.Schema<UpdateInstanceAttributeRequest>;
export interface UpdateInstanceAttributeResponse {
}
export declare const UpdateInstanceAttributeResponse: S.Schema<UpdateInstanceAttributeResponse>;
export interface UpdateInstanceStorageConfigRequest {
    InstanceId: string;
    AssociationId: string;
    ResourceType: InstanceStorageResourceType;
    StorageConfig: InstanceStorageConfig;
    ClientToken?: string;
}
export declare const UpdateInstanceStorageConfigRequest: S.Schema<UpdateInstanceStorageConfigRequest>;
export interface UpdateInstanceStorageConfigResponse {
}
export declare const UpdateInstanceStorageConfigResponse: S.Schema<UpdateInstanceStorageConfigResponse>;
export interface UpdateMetricContentRequest {
    InstanceId: string;
    MetricId: string;
    MetricCalculation?: MetricCalculation;
    Unit?: MetricUnit;
    PositiveTrendIndicator?: TrendIndicator;
}
export declare const UpdateMetricContentRequest: S.Schema<UpdateMetricContentRequest>;
export interface UpdateMetricContentResponse {
}
export declare const UpdateMetricContentResponse: S.Schema<UpdateMetricContentResponse>;
export interface UpdateMetricMetadataRequest {
    InstanceId: string;
    MetricId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateMetricMetadataRequest: S.Schema<UpdateMetricMetadataRequest>;
export interface UpdateMetricMetadataResponse {
}
export declare const UpdateMetricMetadataResponse: S.Schema<UpdateMetricMetadataResponse>;
export interface UpdateNotificationContentRequest {
    InstanceId: string;
    NotificationId: string;
    Content: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateNotificationContentRequest: S.Schema<UpdateNotificationContentRequest>;
export interface UpdateNotificationContentResponse {
}
export declare const UpdateNotificationContentResponse: S.Schema<UpdateNotificationContentResponse>;
export type AuthorizationCode = string | redacted.Redacted<string>;
export type AuthenticationError = string | redacted.Redacted<string>;
export type AuthenticationErrorDescription = string | redacted.Redacted<string>;
export interface UpdateParticipantAuthenticationRequest {
    State: string;
    InstanceId: string;
    Code?: string | redacted.Redacted<string>;
    Error?: string | redacted.Redacted<string>;
    ErrorDescription?: string | redacted.Redacted<string>;
}
export declare const UpdateParticipantAuthenticationRequest: S.Schema<UpdateParticipantAuthenticationRequest>;
export interface UpdateParticipantAuthenticationResponse {
}
export declare const UpdateParticipantAuthenticationResponse: S.Schema<UpdateParticipantAuthenticationResponse>;
export type TimerEligibleParticipantRoles = "CUSTOMER" | "AGENT" | (string & {});
export declare const TimerEligibleParticipantRoles: any;
export type ParticipantTimerType = "IDLE" | "DISCONNECT_NONCUSTOMER" | (string & {});
export declare const ParticipantTimerType: any;
export type ParticipantTimerAction = "Unset" | (string & {});
export declare const ParticipantTimerAction: any;
export type ParticipantTimerDurationInMinutes = number;
export type ParticipantTimerValue = {
    ParticipantTimerAction: ParticipantTimerAction;
    ParticipantTimerDurationInMinutes?: never;
} | {
    ParticipantTimerAction?: never;
    ParticipantTimerDurationInMinutes: number;
};
export declare const ParticipantTimerValue: any;
export interface ParticipantTimerConfiguration {
    ParticipantRole: TimerEligibleParticipantRoles;
    TimerType: ParticipantTimerType;
    TimerValue: ParticipantTimerValue;
}
export declare const ParticipantTimerConfiguration: S.Schema<ParticipantTimerConfiguration>;
export type ParticipantTimerConfigList = ParticipantTimerConfiguration[];
export declare const ParticipantTimerConfigList: any;
export interface ChatParticipantRoleConfig {
    ParticipantTimerConfigList: ParticipantTimerConfiguration[];
}
export declare const ChatParticipantRoleConfig: S.Schema<ChatParticipantRoleConfig>;
export type UpdateParticipantRoleConfigChannelInfo = {
    Chat: ChatParticipantRoleConfig;
};
export declare const UpdateParticipantRoleConfigChannelInfo: any;
export interface UpdateParticipantRoleConfigRequest {
    InstanceId: string;
    ContactId: string;
    ChannelConfiguration: UpdateParticipantRoleConfigChannelInfo;
}
export declare const UpdateParticipantRoleConfigRequest: S.Schema<UpdateParticipantRoleConfigRequest>;
export interface UpdateParticipantRoleConfigResponse {
}
export declare const UpdateParticipantRoleConfigResponse: S.Schema<UpdateParticipantRoleConfigResponse>;
export interface UpdatePhoneNumberRequest {
    PhoneNumberId: string;
    TargetArn?: string;
    InstanceId?: string;
    ClientToken?: string;
}
export declare const UpdatePhoneNumberRequest: S.Schema<UpdatePhoneNumberRequest>;
export interface UpdatePhoneNumberResponse {
    PhoneNumberId?: string;
    PhoneNumberArn?: string;
}
export declare const UpdatePhoneNumberResponse: S.Schema<UpdatePhoneNumberResponse>;
export interface UpdatePhoneNumberMetadataRequest {
    PhoneNumberId: string;
    PhoneNumberDescription?: string;
    ClientToken?: string;
}
export declare const UpdatePhoneNumberMetadataRequest: S.Schema<UpdatePhoneNumberMetadataRequest>;
export interface UpdatePhoneNumberMetadataResponse {
}
export declare const UpdatePhoneNumberMetadataResponse: S.Schema<UpdatePhoneNumberMetadataResponse>;
export interface UpdatePredefinedAttributeRequest {
    InstanceId: string;
    Name: string;
    Values?: PredefinedAttributeValues;
    Purposes?: string[];
    AttributeConfiguration?: InputPredefinedAttributeConfiguration;
}
export declare const UpdatePredefinedAttributeRequest: S.Schema<UpdatePredefinedAttributeRequest>;
export interface UpdatePredefinedAttributeResponse {
}
export declare const UpdatePredefinedAttributeResponse: S.Schema<UpdatePredefinedAttributeResponse>;
export interface UpdatePromptRequest {
    InstanceId: string;
    PromptId: string;
    Name?: string;
    Description?: string;
    S3Uri?: string;
}
export declare const UpdatePromptRequest: S.Schema<UpdatePromptRequest>;
export interface UpdatePromptResponse {
    PromptARN?: string;
    PromptId?: string;
}
export declare const UpdatePromptResponse: S.Schema<UpdatePromptResponse>;
export interface UpdateQueueHoursOfOperationRequest {
    InstanceId: string;
    QueueId: string;
    HoursOfOperationId: string;
}
export declare const UpdateQueueHoursOfOperationRequest: S.Schema<UpdateQueueHoursOfOperationRequest>;
export interface UpdateQueueHoursOfOperationResponse {
}
export declare const UpdateQueueHoursOfOperationResponse: S.Schema<UpdateQueueHoursOfOperationResponse>;
export interface UpdateQueueMaxContactsRequest {
    InstanceId: string;
    QueueId: string;
    MaxContacts?: number;
}
export declare const UpdateQueueMaxContactsRequest: S.Schema<UpdateQueueMaxContactsRequest>;
export interface UpdateQueueMaxContactsResponse {
}
export declare const UpdateQueueMaxContactsResponse: S.Schema<UpdateQueueMaxContactsResponse>;
export interface UpdateQueueNameRequest {
    InstanceId: string;
    QueueId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateQueueNameRequest: S.Schema<UpdateQueueNameRequest>;
export interface UpdateQueueNameResponse {
}
export declare const UpdateQueueNameResponse: S.Schema<UpdateQueueNameResponse>;
export interface UpdateQueueOutboundCallerConfigRequest {
    InstanceId: string;
    QueueId: string;
    OutboundCallerConfig: OutboundCallerConfig;
}
export declare const UpdateQueueOutboundCallerConfigRequest: S.Schema<UpdateQueueOutboundCallerConfigRequest>;
export interface UpdateQueueOutboundCallerConfigResponse {
}
export declare const UpdateQueueOutboundCallerConfigResponse: S.Schema<UpdateQueueOutboundCallerConfigResponse>;
export interface UpdateQueueOutboundEmailConfigRequest {
    InstanceId: string;
    QueueId: string;
    OutboundEmailConfig: OutboundEmailConfig;
}
export declare const UpdateQueueOutboundEmailConfigRequest: S.Schema<UpdateQueueOutboundEmailConfigRequest>;
export interface UpdateQueueOutboundEmailConfigResponse {
}
export declare const UpdateQueueOutboundEmailConfigResponse: S.Schema<UpdateQueueOutboundEmailConfigResponse>;
export interface UpdateQueueStatusRequest {
    InstanceId: string;
    QueueId: string;
    Status: QueueStatus;
}
export declare const UpdateQueueStatusRequest: S.Schema<UpdateQueueStatusRequest>;
export interface UpdateQueueStatusResponse {
}
export declare const UpdateQueueStatusResponse: S.Schema<UpdateQueueStatusResponse>;
export interface UpdateQuickConnectConfigRequest {
    InstanceId: string;
    QuickConnectId: string;
    QuickConnectConfig: QuickConnectConfig;
}
export declare const UpdateQuickConnectConfigRequest: S.Schema<UpdateQuickConnectConfigRequest>;
export interface UpdateQuickConnectConfigResponse {
}
export declare const UpdateQuickConnectConfigResponse: S.Schema<UpdateQuickConnectConfigResponse>;
export type UpdateQuickConnectDescription = string;
export interface UpdateQuickConnectNameRequest {
    InstanceId: string;
    QuickConnectId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateQuickConnectNameRequest: S.Schema<UpdateQuickConnectNameRequest>;
export interface UpdateQuickConnectNameResponse {
}
export declare const UpdateQuickConnectNameResponse: S.Schema<UpdateQuickConnectNameResponse>;
export interface UpdateRoutingProfileAgentAvailabilityTimerRequest {
    InstanceId: string;
    RoutingProfileId: string;
    AgentAvailabilityTimer: AgentAvailabilityTimer;
}
export declare const UpdateRoutingProfileAgentAvailabilityTimerRequest: S.Schema<UpdateRoutingProfileAgentAvailabilityTimerRequest>;
export interface UpdateRoutingProfileAgentAvailabilityTimerResponse {
}
export declare const UpdateRoutingProfileAgentAvailabilityTimerResponse: S.Schema<UpdateRoutingProfileAgentAvailabilityTimerResponse>;
export interface UpdateRoutingProfileConcurrencyRequest {
    InstanceId: string;
    RoutingProfileId: string;
    MediaConcurrencies: MediaConcurrency[];
}
export declare const UpdateRoutingProfileConcurrencyRequest: S.Schema<UpdateRoutingProfileConcurrencyRequest>;
export interface UpdateRoutingProfileConcurrencyResponse {
}
export declare const UpdateRoutingProfileConcurrencyResponse: S.Schema<UpdateRoutingProfileConcurrencyResponse>;
export interface UpdateRoutingProfileDefaultOutboundQueueRequest {
    InstanceId: string;
    RoutingProfileId: string;
    DefaultOutboundQueueId: string;
}
export declare const UpdateRoutingProfileDefaultOutboundQueueRequest: S.Schema<UpdateRoutingProfileDefaultOutboundQueueRequest>;
export interface UpdateRoutingProfileDefaultOutboundQueueResponse {
}
export declare const UpdateRoutingProfileDefaultOutboundQueueResponse: S.Schema<UpdateRoutingProfileDefaultOutboundQueueResponse>;
export interface UpdateRoutingProfileNameRequest {
    InstanceId: string;
    RoutingProfileId: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateRoutingProfileNameRequest: S.Schema<UpdateRoutingProfileNameRequest>;
export interface UpdateRoutingProfileNameResponse {
}
export declare const UpdateRoutingProfileNameResponse: S.Schema<UpdateRoutingProfileNameResponse>;
export interface UpdateRoutingProfileQueuesRequest {
    InstanceId: string;
    RoutingProfileId: string;
    QueueConfigs: RoutingProfileQueueConfig[];
}
export declare const UpdateRoutingProfileQueuesRequest: S.Schema<UpdateRoutingProfileQueuesRequest>;
export interface UpdateRoutingProfileQueuesResponse {
}
export declare const UpdateRoutingProfileQueuesResponse: S.Schema<UpdateRoutingProfileQueuesResponse>;
export interface UpdateRuleRequest {
    RuleId: string;
    InstanceId: string;
    Name: string;
    Function: string;
    Actions: RuleAction[];
    PublishStatus: RulePublishStatus;
}
export declare const UpdateRuleRequest: S.Schema<UpdateRuleRequest>;
export interface UpdateRuleResponse {
}
export declare const UpdateRuleResponse: S.Schema<UpdateRuleResponse>;
export interface UpdateSecurityProfileRequest {
    Description?: string;
    Permissions?: string[];
    SecurityProfileId: string;
    InstanceId: string;
    AllowedAccessControlTags?: {
        [key: string]: string | undefined;
    };
    TagRestrictedResources?: string[];
    Applications?: Application[];
    HierarchyRestrictedResources?: string[];
    AllowedAccessControlHierarchyGroupId?: string;
    AllowedFlowModules?: FlowModule[];
    GranularAccessControlConfiguration?: GranularAccessControlConfiguration;
}
export declare const UpdateSecurityProfileRequest: S.Schema<UpdateSecurityProfileRequest>;
export interface UpdateSecurityProfileResponse {
}
export declare const UpdateSecurityProfileResponse: S.Schema<UpdateSecurityProfileResponse>;
export interface UpdateTaskTemplateRequest {
    TaskTemplateId: string;
    InstanceId: string;
    Name?: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Status?: TaskTemplateStatus;
    Fields?: TaskTemplateField[];
}
export declare const UpdateTaskTemplateRequest: S.Schema<UpdateTaskTemplateRequest>;
export interface UpdateTaskTemplateResponse {
    InstanceId?: string;
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    ContactFlowId?: string;
    SelfAssignFlowId?: string;
    Constraints?: TaskTemplateConstraints;
    Defaults?: TaskTemplateDefaults;
    Fields?: TaskTemplateField[];
    Status?: TaskTemplateStatus;
    LastModifiedTime?: Date;
    CreatedTime?: Date;
}
export declare const UpdateTaskTemplateResponse: S.Schema<UpdateTaskTemplateResponse>;
export interface UpdateTestCaseRequest {
    InstanceId: string;
    TestCaseId: string;
    Content?: string;
    EntryPoint?: TestCaseEntryPoint;
    InitializationData?: string;
    Name?: string;
    Description?: string;
    Status?: TestCaseStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const UpdateTestCaseRequest: S.Schema<UpdateTestCaseRequest>;
export interface UpdateTestCaseResponse {
}
export declare const UpdateTestCaseResponse: S.Schema<UpdateTestCaseResponse>;
export interface UpdateTrafficDistributionRequest {
    Id: string;
    TelephonyConfig?: TelephonyConfig;
    SignInConfig?: SignInConfig;
    AgentConfig?: AgentConfig;
}
export declare const UpdateTrafficDistributionRequest: S.Schema<UpdateTrafficDistributionRequest>;
export interface UpdateTrafficDistributionResponse {
}
export declare const UpdateTrafficDistributionResponse: S.Schema<UpdateTrafficDistributionResponse>;
export interface UpdateUserConfigRequest {
    AutoAcceptConfigs?: AutoAcceptConfig[];
    AfterContactWorkConfigs?: AfterContactWorkConfigPerChannel[];
    PhoneNumberConfigs?: PhoneNumberConfig[];
    PersistentConnectionConfigs?: PersistentConnectionConfig[];
    VoiceEnhancementConfigs?: VoiceEnhancementConfig[];
    UserId: string;
    InstanceId: string;
}
export declare const UpdateUserConfigRequest: S.Schema<UpdateUserConfigRequest>;
export interface UpdateUserConfigResponse {
}
export declare const UpdateUserConfigResponse: S.Schema<UpdateUserConfigResponse>;
export interface UpdateUserHierarchyRequest {
    HierarchyGroupId?: string;
    UserId: string;
    InstanceId: string;
}
export declare const UpdateUserHierarchyRequest: S.Schema<UpdateUserHierarchyRequest>;
export interface UpdateUserHierarchyResponse {
}
export declare const UpdateUserHierarchyResponse: S.Schema<UpdateUserHierarchyResponse>;
export interface UpdateUserHierarchyGroupNameRequest {
    Name: string;
    HierarchyGroupId: string;
    InstanceId: string;
}
export declare const UpdateUserHierarchyGroupNameRequest: S.Schema<UpdateUserHierarchyGroupNameRequest>;
export interface UpdateUserHierarchyGroupNameResponse {
}
export declare const UpdateUserHierarchyGroupNameResponse: S.Schema<UpdateUserHierarchyGroupNameResponse>;
export interface HierarchyLevelUpdate {
    Name: string;
}
export declare const HierarchyLevelUpdate: S.Schema<HierarchyLevelUpdate>;
export interface HierarchyStructureUpdate {
    LevelOne?: HierarchyLevelUpdate;
    LevelTwo?: HierarchyLevelUpdate;
    LevelThree?: HierarchyLevelUpdate;
    LevelFour?: HierarchyLevelUpdate;
    LevelFive?: HierarchyLevelUpdate;
}
export declare const HierarchyStructureUpdate: S.Schema<HierarchyStructureUpdate>;
export interface UpdateUserHierarchyStructureRequest {
    HierarchyStructure: HierarchyStructureUpdate;
    InstanceId: string;
}
export declare const UpdateUserHierarchyStructureRequest: S.Schema<UpdateUserHierarchyStructureRequest>;
export interface UpdateUserHierarchyStructureResponse {
}
export declare const UpdateUserHierarchyStructureResponse: S.Schema<UpdateUserHierarchyStructureResponse>;
export interface UpdateUserIdentityInfoRequest {
    IdentityInfo: UserIdentityInfo;
    UserId: string;
    InstanceId: string;
}
export declare const UpdateUserIdentityInfoRequest: S.Schema<UpdateUserIdentityInfoRequest>;
export interface UpdateUserIdentityInfoResponse {
}
export declare const UpdateUserIdentityInfoResponse: S.Schema<UpdateUserIdentityInfoResponse>;
export interface UpdateUserNotificationStatusRequest {
    InstanceId: string;
    NotificationId: string;
    UserId: string;
    Status: NotificationStatus;
    LastModifiedTime?: Date;
    LastModifiedRegion?: string;
}
export declare const UpdateUserNotificationStatusRequest: S.Schema<UpdateUserNotificationStatusRequest>;
export interface UpdateUserNotificationStatusResponse {
}
export declare const UpdateUserNotificationStatusResponse: S.Schema<UpdateUserNotificationStatusResponse>;
export interface UpdateUserPhoneConfigRequest {
    PhoneConfig: UserPhoneConfig;
    UserId: string;
    InstanceId: string;
}
export declare const UpdateUserPhoneConfigRequest: S.Schema<UpdateUserPhoneConfigRequest>;
export interface UpdateUserPhoneConfigResponse {
}
export declare const UpdateUserPhoneConfigResponse: S.Schema<UpdateUserPhoneConfigResponse>;
export interface UpdateUserProficienciesRequest {
    InstanceId: string;
    UserId: string;
    UserProficiencies: UserProficiency[];
}
export declare const UpdateUserProficienciesRequest: S.Schema<UpdateUserProficienciesRequest>;
export interface UpdateUserProficienciesResponse {
}
export declare const UpdateUserProficienciesResponse: S.Schema<UpdateUserProficienciesResponse>;
export interface UpdateUserRoutingProfileRequest {
    RoutingProfileId: string;
    UserId: string;
    InstanceId: string;
}
export declare const UpdateUserRoutingProfileRequest: S.Schema<UpdateUserRoutingProfileRequest>;
export interface UpdateUserRoutingProfileResponse {
}
export declare const UpdateUserRoutingProfileResponse: S.Schema<UpdateUserRoutingProfileResponse>;
export interface UpdateUserSecurityProfilesRequest {
    SecurityProfileIds: string[];
    UserId: string;
    InstanceId: string;
}
export declare const UpdateUserSecurityProfilesRequest: S.Schema<UpdateUserSecurityProfilesRequest>;
export interface UpdateUserSecurityProfilesResponse {
}
export declare const UpdateUserSecurityProfilesResponse: S.Schema<UpdateUserSecurityProfilesResponse>;
export interface UpdateViewContentRequest {
    InstanceId: string;
    ViewId: string;
    Status: ViewStatus;
    Content: ViewInputContent;
}
export declare const UpdateViewContentRequest: S.Schema<UpdateViewContentRequest>;
export interface UpdateViewContentResponse {
    View?: View;
}
export declare const UpdateViewContentResponse: S.Schema<UpdateViewContentResponse>;
export interface UpdateViewMetadataRequest {
    InstanceId: string;
    ViewId: string;
    Name?: string | redacted.Redacted<string>;
    Description?: string;
}
export declare const UpdateViewMetadataRequest: S.Schema<UpdateViewMetadataRequest>;
export interface UpdateViewMetadataResponse {
}
export declare const UpdateViewMetadataResponse: S.Schema<UpdateViewMetadataResponse>;
export interface UpdateWorkspaceMetadataRequest {
    InstanceId: string;
    WorkspaceId: string;
    Name?: string;
    Description?: string;
    Title?: string;
}
export declare const UpdateWorkspaceMetadataRequest: S.Schema<UpdateWorkspaceMetadataRequest>;
export interface UpdateWorkspaceMetadataResponse {
}
export declare const UpdateWorkspaceMetadataResponse: S.Schema<UpdateWorkspaceMetadataResponse>;
export interface UpdateWorkspacePageRequest {
    InstanceId: string;
    WorkspaceId: string;
    Page: string;
    NewPage?: string;
    ResourceArn?: string;
    Slug?: string;
    InputData?: string;
}
export declare const UpdateWorkspacePageRequest: S.Schema<UpdateWorkspacePageRequest>;
export interface UpdateWorkspacePageResponse {
}
export declare const UpdateWorkspacePageResponse: S.Schema<UpdateWorkspacePageResponse>;
export interface UpdateWorkspaceThemeRequest {
    InstanceId: string;
    WorkspaceId: string;
    Theme?: WorkspaceTheme;
}
export declare const UpdateWorkspaceThemeRequest: S.Schema<UpdateWorkspaceThemeRequest>;
export interface UpdateWorkspaceThemeResponse {
}
export declare const UpdateWorkspaceThemeResponse: S.Schema<UpdateWorkspaceThemeResponse>;
export interface UpdateWorkspaceVisibilityRequest {
    InstanceId: string;
    WorkspaceId: string;
    Visibility: Visibility;
}
export declare const UpdateWorkspaceVisibilityRequest: S.Schema<UpdateWorkspaceVisibilityRequest>;
export interface UpdateWorkspaceVisibilityResponse {
}
export declare const UpdateWorkspaceVisibilityResponse: S.Schema<UpdateWorkspaceVisibilityResponse>;
export type Message = string;
export type AttachedFileInvalidRequestExceptionReason = "INVALID_FILE_SIZE" | "INVALID_FILE_TYPE" | "INVALID_FILE_NAME" | (string & {});
export declare const AttachedFileInvalidRequestExceptionReason: any;
export type InvalidRequestExceptionReason = {
    AttachedFileInvalidRequestExceptionReason: AttachedFileInvalidRequestExceptionReason;
};
export declare const InvalidRequestExceptionReason: any;
export type AttachedFileServiceQuotaExceededExceptionReason = "TOTAL_FILE_SIZE_EXCEEDED" | "TOTAL_FILE_COUNT_EXCEEDED" | (string & {});
export declare const AttachedFileServiceQuotaExceededExceptionReason: any;
export type ServiceQuotaExceededExceptionReason = {
    AttachedFileServiceQuotaExceededExceptionReason: AttachedFileServiceQuotaExceededExceptionReason;
};
export declare const ServiceQuotaExceededExceptionReason: any;
export type ProblemMessageString = string;
export interface ProblemDetail {
    message?: string;
}
export declare const ProblemDetail: S.Schema<ProblemDetail>;
export type Problems = ProblemDetail[];
export declare const Problems: any;
export type PropertyValidationExceptionReason = "INVALID_FORMAT" | "UNIQUE_CONSTRAINT_VIOLATED" | "REFERENCED_RESOURCE_NOT_FOUND" | "RESOURCE_NAME_ALREADY_EXISTS" | "REQUIRED_PROPERTY_MISSING" | "NOT_SUPPORTED" | "TYPE_MISMATCH" | (string & {});
export declare const PropertyValidationExceptionReason: any;
export interface PropertyValidationExceptionProperty {
    PropertyPath: string;
    Reason: PropertyValidationExceptionReason;
    Message: string;
}
export declare const PropertyValidationExceptionProperty: S.Schema<PropertyValidationExceptionProperty>;
export type PropertyValidationExceptionPropertyList = PropertyValidationExceptionProperty[];
export declare const PropertyValidationExceptionPropertyList: any;
export type ResourceType = "CONTACT" | "CONTACT_FLOW" | "INSTANCE" | "PARTICIPANT" | "HIERARCHY_LEVEL" | "HIERARCHY_GROUP" | "USER" | "PHONE_NUMBER" | (string & {});
export declare const ResourceType: any;
export type ActivateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Activates an evaluation form in the specified Connect Customer instance. After the evaluation form is
 * activated, it is available to start new evaluations based on the form.
 */
export declare const activateEvaluationForm: API.OperationMethod<ActivateEvaluationFormRequest, ActivateEvaluationFormResponse, ActivateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type AssociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates the specified dataset for a Connect Customer instance with the target account. You can associate
 * only one dataset in a single call.
 */
export declare const associateAnalyticsDataSet: API.OperationMethod<AssociateAnalyticsDataSetRequest, AssociateAnalyticsDataSetResponse, AssociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type AssociateApprovedOriginError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Associates an approved origin to an Connect Customer instance.
 */
export declare const associateApprovedOrigin: API.OperationMethod<AssociateApprovedOriginRequest, AssociateApprovedOriginResponse, AssociateApprovedOriginError, Creds | HttpClient.HttpClient>;
export type AssociateBotError = InternalServiceException | InvalidRequestException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Allows the specified Connect Customer instance to access the specified Amazon Lex or Amazon Lex V2
 * bot.
 */
export declare const associateBot: API.OperationMethod<AssociateBotRequest, AssociateBotResponse, AssociateBotError, Creds | HttpClient.HttpClient>;
export type AssociateContactWithUserError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a queued contact with an agent.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Programmatically assign queued contacts to available users.
 *
 * - Leverage the IAM context key `connect:PreferredUserArn` to restrict contact association to specific
 * preferred user.
 *
 * **Important things to know**
 *
 * - Use this API with chat, email, task, and voice contacts. For voice callbacks, this API does not support customer-first mode.
 *
 * - This API can be used to offer a contact to an agent even if the agent is currently at maximum concurrency
 * for the channel.
 *
 * - Use it to associate contacts with users regardless of their current state, including custom states. Ensure
 * your application logic accounts for user availability before making associations.
 *
 * - It honors the IAM context key `connect:PreferredUserArn` to prevent unauthorized contact
 * associations.
 *
 * - It respects the IAM context key `connect:PreferredUserArn` to enforce authorization controls and
 * prevent unauthorized contact associations. Verify that your IAM policies are properly configured to support your
 * intended use cases.
 *
 * - The service quota *Queues per routing profile per instance* applies to manually assigned
 * queues, too. For more information about this quota, see Connect Customer
 * quotas in the *Connect Customer Administrator Guide*.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const associateContactWithUser: API.OperationMethod<AssociateContactWithUserRequest, AssociateContactWithUserResponse, AssociateContactWithUserError, Creds | HttpClient.HttpClient>;
export type AssociateDefaultVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an existing vocabulary as the default. Contact Lens for Connect Customer uses the vocabulary in post-call and real-time
 * analysis sessions for the given language.
 */
export declare const associateDefaultVocabulary: API.OperationMethod<AssociateDefaultVocabularyRequest, AssociateDefaultVocabularyResponse, AssociateDefaultVocabularyError, Creds | HttpClient.HttpClient>;
export type AssociateEmailAddressAliasError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an email address alias with an existing email address in an Connect Customer instance. This creates
 * a forwarding relationship where emails sent to the alias email address are automatically forwarded to the primary
 * email address.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - **Unified customer support**: Create multiple entry points (for example,
 * support@example.com, help@example.com, customercare@example.com) that all forward to a single agent queue for
 * streamlined management.
 *
 * - **Department consolidation**: Forward emails from legacy department addresses
 * (for example, sales@example.com, info@example.com) to a centralized customer service email during organizational
 * restructuring.
 *
 * - **Brand management**: Enable you to use familiar brand-specific email addresses
 * that forward to the appropriate Connect Customer instance email address.
 *
 * **Important things to know**
 *
 * - Each email address can have a maximum of one alias. You cannot create multiple aliases for the same email
 * address.
 *
 * - If the alias email address already receives direct emails, it continues to receive direct emails plus
 * forwarded emails.
 *
 * - You cannot chain email aliases together (that is, create an alias of an alias).
 *
 * `AssociateEmailAddressAlias` does not return the following information:
 *
 * - A confirmation of the alias relationship details (you must call DescribeEmailAddress to verify).
 *
 * - The timestamp of when the association occurred.
 *
 * - The status of the forwarding configuration.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 *
 * **Related operations**
 *
 * - DisassociateEmailAddressAlias: Removes the alias association between two email addresses in an Connect Customer instance.
 *
 * - DescribeEmailAddress: View current alias configurations for an email address.
 *
 * - SearchEmailAddresses: Find email addresses and their alias relationships across an instance.
 *
 * - CreateEmailAddress: Create new email addresses that can participate in alias relationships.
 *
 * - DeleteEmailAddress: Remove email addresses (automatically removes any alias relationships).
 *
 * - UpdateEmailAddressMetadata: Modify email address properties (does not affect alias relationships).
 */
export declare const associateEmailAddressAlias: API.OperationMethod<AssociateEmailAddressAliasRequest, AssociateEmailAddressAliasResponse, AssociateEmailAddressAliasError, Creds | HttpClient.HttpClient>;
export type AssociateFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a connect resource to a flow.
 */
export declare const associateFlow: API.OperationMethod<AssociateFlowRequest, AssociateFlowResponse, AssociateFlowError, Creds | HttpClient.HttpClient>;
export type AssociateHoursOfOperationsError = ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Associates a set of hours of operations with another hours of operation. For more information about inheriting overrides from parent hours of operation, see Hours of operation overrides in the Administrator Guide.
 */
export declare const associateHoursOfOperations: API.OperationMethod<AssociateHoursOfOperationsRequest, AssociateHoursOfOperationsResponse, AssociateHoursOfOperationsError, Creds | HttpClient.HttpClient>;
export type AssociateInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Associates a storage resource type for the first time. You can only associate one type of storage configuration
 * in a single call. This means, for example, that you can't define an instance with multiple S3 buckets for storing
 * chat transcripts.
 *
 * This API does not create a resource that doesn't exist. It only associates it to the instance. Ensure that the
 * resource being specified in the storage configuration, like an S3 bucket, exists when being used for
 * association.
 */
export declare const associateInstanceStorageConfig: API.OperationMethod<AssociateInstanceStorageConfigRequest, AssociateInstanceStorageConfigResponse, AssociateInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type AssociateLambdaFunctionError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Allows the specified Connect Customer instance to access the specified Lambda function.
 */
export declare const associateLambdaFunction: API.OperationMethod<AssociateLambdaFunctionRequest, AssociateLambdaFunctionResponse, AssociateLambdaFunctionError, Creds | HttpClient.HttpClient>;
export type AssociateLexBotError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Allows the specified Connect Customer instance to access the specified Amazon Lex V1 bot. This API
 * only supports the association of Amazon Lex V1 bots.
 */
export declare const associateLexBot: API.OperationMethod<AssociateLexBotRequest, AssociateLexBotResponse, AssociateLexBotError, Creds | HttpClient.HttpClient>;
export type AssociatePhoneNumberContactFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a flow with a phone number claimed to your Connect Customer instance.
 *
 * If the number is claimed to a traffic distribution group, and you are calling this API using an instance in the Amazon Web Services Region where the traffic distribution group was created, you can use either a full phone number ARN or UUID value for the
 * `PhoneNumberId` URI request parameter. However, if the number is claimed to a traffic distribution group and you are calling
 * this API using an instance in the alternate Amazon Web Services Region associated with the traffic distribution group, you must provide a
 * full phone number ARN. If a UUID is provided
 * in
 * this scenario, you will receive a `ResourceNotFoundException`.
 */
export declare const associatePhoneNumberContactFlow: API.OperationMethod<AssociatePhoneNumberContactFlowRequest, AssociatePhoneNumberContactFlowResponse, AssociatePhoneNumberContactFlowError, Creds | HttpClient.HttpClient>;
export type AssociateQueueEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of email addresses with a queue to enable agents to select different "From" (system) email addresses when replying to inbound email contacts or initiating outbound email contacts. This allows agents to handle email contacts across different brands and business units within the same queue.
 *
 * **Important things to know**
 *
 * - You can associate up to 49 additional email addresses with a single queue, plus 1 default outbound email address, for a total of 50.
 *
 * - The email addresses must already exist in the Connect Customer instance before they can be associated with a queue.
 *
 * - Agents will be able to select from these associated email addresses when handling email contacts in the queue.
 *
 * - For inbound email contacts, agents can select from email addresses associated with the queue where the contact was accepted.
 *
 * - For outbound email contacts, agents can select from email addresses associated with their default outbound queue configured in their routing profile.
 */
export declare const associateQueueEmailAddresses: API.OperationMethod<AssociateQueueEmailAddressesRequest, AssociateQueueEmailAddressesResponse, AssociateQueueEmailAddressesError, Creds | HttpClient.HttpClient>;
export type AssociateQueueQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of quick connects with a queue.
 */
export declare const associateQueueQuickConnects: API.OperationMethod<AssociateQueueQuickConnectsRequest, AssociateQueueQuickConnectsResponse, AssociateQueueQuickConnectsError, Creds | HttpClient.HttpClient>;
export type AssociateRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of queues with a routing profile.
 */
export declare const associateRoutingProfileQueues: API.OperationMethod<AssociateRoutingProfileQueuesRequest, AssociateRoutingProfileQueuesResponse, AssociateRoutingProfileQueuesError, Creds | HttpClient.HttpClient>;
export type AssociateSecurityKeyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Associates a security key to the instance.
 */
export declare const associateSecurityKey: API.OperationMethod<AssociateSecurityKeyRequest, AssociateSecurityKeyResponse, AssociateSecurityKeyError, Creds | HttpClient.HttpClient>;
export type AssociateSecurityProfilesError = AccessDeniedException | ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Associate security profiles with an Entity in an Amazon Connect instance.
 */
export declare const associateSecurityProfiles: API.OperationMethod<AssociateSecurityProfilesRequest, AssociateSecurityProfilesResponse, AssociateSecurityProfilesError, Creds | HttpClient.HttpClient>;
export type AssociateTrafficDistributionGroupUserError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates an agent with a traffic distribution group. This API can be called only in the Region where the traffic distribution group
 * is created.
 */
export declare const associateTrafficDistributionGroupUser: API.OperationMethod<AssociateTrafficDistributionGroupUserRequest, AssociateTrafficDistributionGroupUserResponse, AssociateTrafficDistributionGroupUserError, Creds | HttpClient.HttpClient>;
export type AssociateUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a set of proficiencies with a user.
 */
export declare const associateUserProficiencies: API.OperationMethod<AssociateUserProficienciesRequest, AssociateUserProficienciesResponse, AssociateUserProficienciesError, Creds | HttpClient.HttpClient>;
export type AssociateWorkspaceError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a workspace with one or more users or routing profiles, allowing them to access the workspace's
 * configured views and pages.
 */
export declare const associateWorkspace: API.OperationMethod<AssociateWorkspaceRequest, AssociateWorkspaceResponse, AssociateWorkspaceError, Creds | HttpClient.HttpClient>;
export type BatchAssociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Associates a list of analytics datasets for a given Connect Customer instance to a target account. You can
 * associate multiple datasets in a single call.
 */
export declare const batchAssociateAnalyticsDataSet: API.OperationMethod<BatchAssociateAnalyticsDataSetRequest, BatchAssociateAnalyticsDataSetResponse, BatchAssociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type BatchCreateDataTableValueError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates values for attributes in a data table. The value may be a default or it may be associated with a primary
 * value. The value must pass all customer defined validation as well as the default validation for the value type. The
 * operation must conform to Batch Operation API Standards. Although the standard specifies that successful and failed
 * entities are listed separately in the response, authorization fails if any primary values or attributes are
 * unauthorized. The combination of primary values and the attribute name serve as the identifier for the individual
 * item request.
 */
export declare const batchCreateDataTableValue: API.OperationMethod<BatchCreateDataTableValueRequest, BatchCreateDataTableValueResponse, BatchCreateDataTableValueError, Creds | HttpClient.HttpClient>;
export type BatchDeleteDataTableValueError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes multiple values from a data table. API users may delete values at any time. When deletion is requested
 * from the admin website, a warning is shown alerting the user of the most recent time the attribute and its values
 * were accessed. System managed values are not deletable by customers.
 */
export declare const batchDeleteDataTableValue: API.OperationMethod<BatchDeleteDataTableValueRequest, BatchDeleteDataTableValueResponse, BatchDeleteDataTableValueError, Creds | HttpClient.HttpClient>;
export type BatchDescribeDataTableValueError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves multiple values from a data table without evaluating expressions. Returns the raw stored values along
 * with metadata such as lock versions and modification timestamps. "Describe" is a deprecated term but is allowed to
 * maintain consistency with existing operations.
 */
export declare const batchDescribeDataTableValue: API.OperationMethod<BatchDescribeDataTableValueRequest, BatchDescribeDataTableValueResponse, BatchDescribeDataTableValueError, Creds | HttpClient.HttpClient>;
export type BatchDisassociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a list of analytics datasets associated with a given Connect Customer instance. You can disassociate
 * multiple datasets in a single call.
 */
export declare const batchDisassociateAnalyticsDataSet: API.OperationMethod<BatchDisassociateAnalyticsDataSetRequest, BatchDisassociateAnalyticsDataSetResponse, BatchDisassociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type BatchGetAttachedFileMetadataError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows you to retrieve metadata about multiple attached files on an associated resource. Each attached file
 * provided in the input list must be associated with the input AssociatedResourceArn.
 */
export declare const batchGetAttachedFileMetadata: API.OperationMethod<BatchGetAttachedFileMetadataRequest, BatchGetAttachedFileMetadataResponse, BatchGetAttachedFileMetadataError, Creds | HttpClient.HttpClient>;
export type BatchGetFlowAssociationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieve the flow associations for the given resources.
 */
export declare const batchGetFlowAssociation: API.OperationMethod<BatchGetFlowAssociationRequest, BatchGetFlowAssociationResponse, BatchGetFlowAssociationError, Creds | HttpClient.HttpClient>;
export type BatchPutContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Only the Connect Customer outbound campaigns service principal is allowed to assume a role in your account
 * and call this API.
 *
 * Allows you to create a batch of contacts in Connect Customer. The outbound campaigns capability ingests dial
 * requests via the PutDialRequestBatch API. It then uses BatchPutContact to create contacts corresponding to those dial
 * requests. If agents are available, the dial requests are dialed out, which results in a voice call. The resulting
 * voice call uses the same contactId that was created by BatchPutContact.
 */
export declare const batchPutContact: API.OperationMethod<BatchPutContactRequest, BatchPutContactResponse, BatchPutContactError, Creds | HttpClient.HttpClient>;
export type BatchUpdateDataTableValueError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates multiple data table values using all properties from BatchCreateDataTableValue. System managed values
 * are not modifiable by customers. The operation requires proper lock versions to prevent concurrent modification
 * conflicts.
 */
export declare const batchUpdateDataTableValue: API.OperationMethod<BatchUpdateDataTableValueRequest, BatchUpdateDataTableValueResponse, BatchUpdateDataTableValueError, Creds | HttpClient.HttpClient>;
export type ClaimPhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Claims an available phone number to your Connect Customer instance or traffic distribution group. You can call
 * this API only in the same Amazon Web Services Region where the Connect Customer instance or traffic distribution group was
 * created.
 *
 * For more information about how to use this operation, see Claim a phone number in your country and Claim
 * phone numbers to traffic distribution groups in the Connect Customer Administrator
 * Guide.
 *
 * You can call the SearchAvailablePhoneNumbers API for
 * available phone numbers that you can claim. Call the DescribePhoneNumber API to verify the status
 * of a previous ClaimPhoneNumber operation.
 *
 * If you plan to claim and release numbers frequently,
 * contact us for a service quota exception. Otherwise, it is possible you will be blocked from
 * claiming and releasing any more numbers until up to 180 days past the oldest number
 * released has expired.
 *
 * By default you can claim and release up to 200% of your maximum number of active
 * phone numbers. If you claim and release phone numbers using
 * the UI or API during a rolling 180 day cycle that exceeds 200% of your phone number
 * service level quota, you will be blocked from claiming any more numbers until 180
 * days past the oldest number released has expired.
 *
 * For example, if you already have 99 claimed numbers and a service level quota of 99 phone numbers, and in any 180
 * day period you release 99, claim 99, and then release 99, you will have exceeded the
 * 200% limit. At that point you are blocked from claiming any more numbers until you
 * open an Amazon Web Services support ticket.
 */
export declare const claimPhoneNumber: API.OperationMethod<ClaimPhoneNumberRequest, ClaimPhoneNumberResponse, ClaimPhoneNumberError, Creds | HttpClient.HttpClient>;
export type CompleteAttachedFileUploadError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows you to confirm that the attached file has been uploaded using the pre-signed URL provided in the
 * StartAttachedFileUpload API.
 */
export declare const completeAttachedFileUpload: API.OperationMethod<CompleteAttachedFileUploadRequest, CompleteAttachedFileUploadResponse, CompleteAttachedFileUploadError, Creds | HttpClient.HttpClient>;
export type CreateAgentStatusError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an agent status for the specified Connect Customer instance.
 */
export declare const createAgentStatus: API.OperationMethod<CreateAgentStatusRequest, CreateAgentStatusResponse, CreateAgentStatusError, Creds | HttpClient.HttpClient>;
export type CreateAttachedFileError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an attached file for a completed voice contact by copying a recording from a source S3 URI into
 * Connect Customer managed storage. Use this API to attach voice recordings to contacts for downstream
 * processing such as conversational analytics.
 *
 * The `AssociatedResourceArn` must be the ARN of a completed voice contact, `FileUseCaseType`
 * must be set to `VOICE_RECORDING`, and `FileSourceUri` must be a valid S3 URI.
 *
 * For example, you can call `CreateContact`, then `CreateAttachedFile`, then
 * `StartContactConversationalAnalyticsJob` to create a contact, attach a recording, and
 * run post-call analytics.
 */
export declare const createAttachedFile: API.OperationMethod<CreateAttachedFileRequest, CreateAttachedFileResponse, CreateAttachedFileError, Creds | HttpClient.HttpClient>;
export type CreateAuthCodeError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an authorization code for the specified Connect Customer instance. The authorization code can be used
 * to establish a session with scoped permissions defined by the specified scope parameters.
 */
export declare const createAuthCode: API.OperationMethod<CreateAuthCodeRequest, CreateAuthCodeResponse, CreateAuthCodeError, Creds | HttpClient.HttpClient>;
export type CreateContactError = AccessDeniedException | ConflictException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Only the VOICE, EMAIL, and TASK channels are supported.
 *
 * - For VOICE: The supported initiation method is `TRANSFER`. The contacts created with this
 * initiation method have a subtype `connect:ExternalAudio`.
 *
 * - For EMAIL: The supported initiation methods are `OUTBOUND`, `AGENT_REPLY`, and
 * `FLOW`.
 *
 * - For TASK: The supported initiation method is `API`. Contacts created with this API have a sub-type
 * of `connect:ExternalTask`.
 *
 * Creates a new VOICE, EMAIL, or TASK contact.
 *
 * After a contact is created, you can move it to the desired state by using the `InitiateAs` parameter.
 * While you can use API to create task contacts that are in the `COMPLETED` state, you must contact Amazon Web Services Support before using it for bulk import use cases. Bulk import causes your requests to be throttled or
 * fail if your CreateContact limits aren't high enough.
 */
export declare const createContact: API.OperationMethod<CreateContactRequest, CreateContactResponse, CreateContactError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowError = DuplicateResourceException | InternalServiceException | InvalidContactFlowException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a flow for the specified Connect Customer instance.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 */
export declare const createContactFlow: API.OperationMethod<CreateContactFlowRequest, CreateContactFlowResponse, CreateContactFlowError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowModuleError = AccessDeniedException | DuplicateResourceException | IdempotencyException | InternalServiceException | InvalidContactFlowModuleException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a flow module for the specified Connect Customer instance.
 */
export declare const createContactFlowModule: API.OperationMethod<CreateContactFlowModuleRequest, CreateContactFlowModuleResponse, CreateContactFlowModuleError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowModuleAliasError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a named alias that points to a specific version of a contact flow module.
 */
export declare const createContactFlowModuleAlias: API.OperationMethod<CreateContactFlowModuleAliasRequest, CreateContactFlowModuleAliasResponse, CreateContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowModuleVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an immutable snapshot of a contact flow module, preserving its content and settings at a specific point
 * in time for version control and rollback capabilities.
 */
export declare const createContactFlowModuleVersion: API.OperationMethod<CreateContactFlowModuleVersionRequest, CreateContactFlowModuleVersionResponse, CreateContactFlowModuleVersionError, Creds | HttpClient.HttpClient>;
export type CreateContactFlowVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Publishes a new version of the flow provided. Versions are immutable and monotonically increasing. If the
 * `FlowContentSha256` provided is different from the `FlowContentSha256` of the
 * `$LATEST` published flow content, then an error is returned. This API only supports creating versions for
 * flows of type `Campaign`.
 */
export declare const createContactFlowVersion: API.OperationMethod<CreateContactFlowVersionRequest, CreateContactFlowVersionResponse, CreateContactFlowVersionError, Creds | HttpClient.HttpClient>;
export type CreateDataTableError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a new data table with the specified properties. Supports the creation of all table properties except for
 * attributes and values. A table with no attributes and values is a valid state for a table. The number of tables per
 * instance is limited to 100 per instance. Customers can request an increase by using Amazon Web Services Service Quotas.
 */
export declare const createDataTable: API.OperationMethod<CreateDataTableRequest, CreateDataTableResponse, CreateDataTableError, Creds | HttpClient.HttpClient>;
export type CreateDataTableAttributeError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Adds an attribute to an existing data table. Creating a new primary attribute uses the empty value for the
 * specified value type for all existing records. This should not affect uniqueness of published data tables since the
 * existing primary values will already be unique. Creating attributes does not create any values. System managed tables
 * may not allow customers to create new attributes.
 */
export declare const createDataTableAttribute: API.OperationMethod<CreateDataTableAttributeRequest, CreateDataTableAttributeResponse, CreateDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type CreateEmailAddressError = AccessDeniedException | DuplicateResourceException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Create new email address in the specified Connect Customer instance. For more information about email
 * addresses, see Create email
 * addresses in the Connect Customer Administrator Guide.
 */
export declare const createEmailAddress: API.OperationMethod<CreateEmailAddressRequest, CreateEmailAddressResponse, CreateEmailAddressError, Creds | HttpClient.HttpClient>;
export type CreateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an evaluation form in the specified Connect Customer instance. The form can be used to define
 * questions related to agent performance, and create sections to organize such questions. Question and section
 * identifiers cannot be duplicated within the same evaluation form.
 */
export declare const createEvaluationForm: API.OperationMethod<CreateEvaluationFormRequest, CreateEvaluationFormResponse, CreateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type CreateExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an extraction definition in the specified Connect Customer instance. An extraction
 * definition specifies how structured data is extracted from customer interactions using generative
 * AI, including the prompt hint that guides extraction and the behavior when a value cannot be
 * found.
 */
export declare const createExtractionDefinition: API.OperationMethod<CreateExtractionDefinitionRequest, CreateExtractionDefinitionResponse, CreateExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type CreateHoursOfOperationError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates hours of operation.
 */
export declare const createHoursOfOperation: API.OperationMethod<CreateHoursOfOperationRequest, CreateHoursOfOperationResponse, CreateHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type CreateHoursOfOperationOverrideError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an hours of operation override in an Connect Customer hours of operation resource.
 */
export declare const createHoursOfOperationOverride: API.OperationMethod<CreateHoursOfOperationOverrideRequest, CreateHoursOfOperationOverrideResponse, CreateHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type CreateInstanceError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Initiates an Connect Customer instance with all the supported channels enabled. It does not attach any
 * storage, such as Amazon Simple Storage Service (Amazon S3) or Amazon Kinesis. It also does not allow for any
 * configurations on features, such as Contact Lens for Connect Customer.
 *
 * For more information, see Create an Connect Customer instance in the
 * *Connect Customer Administrator Guide*.
 *
 * Connect Customer enforces a limit on the total number of instances that you can create or delete in 30 days.
 * If you exceed this limit, you will get an error message indicating there has been an excessive number of attempts at creating or deleting instances.
 * You must wait 30 days before you can restart creating and deleting instances in your account.
 */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, Creds | HttpClient.HttpClient>;
export type CreateIntegrationAssociationError = DuplicateResourceException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an Amazon Web Services resource association with an Connect Customer instance.
 */
export declare const createIntegrationAssociation: API.OperationMethod<CreateIntegrationAssociationRequest, CreateIntegrationAssociationResponse, CreateIntegrationAssociationError, Creds | HttpClient.HttpClient>;
export type CreateMetricError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new metric definition for the specified Connect Customer instance. You can create custom metrics
 * that use formulas referencing existing Amazon Web Services-managed metrics, optionally with filters applied.
 */
export declare const createMetric: API.OperationMethod<CreateMetricRequest, CreateMetricResponse, CreateMetricError, Creds | HttpClient.HttpClient>;
export type CreateNotificationError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new notification to be delivered to specified recipients. Notifications can include localized content with links, and an optional expiration time. Recipients can be specified as individual user ARNs or instance ARNs to target all users in an instance.
 */
export declare const createNotification: API.OperationMethod<CreateNotificationRequest, CreateNotificationResponse, CreateNotificationError, Creds | HttpClient.HttpClient>;
export type CreateParticipantError = ConflictException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Adds a new participant into an on-going chat contact or webRTC call. For more information, see Customize chat flow experiences by
 * integrating custom participants or Enable multi-user web, in-app, and video
 * calling.
 */
export declare const createParticipant: API.OperationMethod<CreateParticipantRequest, CreateParticipantResponse, CreateParticipantError, Creds | HttpClient.HttpClient>;
export type CreatePersistentContactAssociationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Enables rehydration of chats for the lifespan of a contact. For more information about chat rehydration, see
 * Enable persistent chat in
 * the *Connect Customer Administrator Guide*.
 */
export declare const createPersistentContactAssociation: API.OperationMethod<CreatePersistentContactAssociationRequest, CreatePersistentContactAssociationResponse, CreatePersistentContactAssociationError, Creds | HttpClient.HttpClient>;
export type CreatePredefinedAttributeError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new predefined attribute for the specified Connect Customer instance. A *predefined attribute*
 * is made up of a name and a value.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Create an attribute for routing proficiency (for example, agent certification) that has predefined values (for
 * example, a list of possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Create an attribute for business unit name that has a list of predefined business unit names used in your
 * organization. This is a use case where information for a contact varies between transfers or conferences. For more
 * information, see Use contact segment attributes.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const createPredefinedAttribute: API.OperationMethod<CreatePredefinedAttributeRequest, CreatePredefinedAttributeResponse, CreatePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type CreatePromptError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a prompt. For more information about prompts, such as supported file types and maximum length, see
 * Create prompts in the
 * *Connect Customer Administrator Guide*.
 */
export declare const createPrompt: API.OperationMethod<CreatePromptRequest, CreatePromptResponse, CreatePromptError, Creds | HttpClient.HttpClient>;
export type CreatePushNotificationRegistrationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates registration for a device token and a chat contact to receive real-time push notifications. For more
 * information about push notifications, see Set up push notifications in Connect Customer for mobile chat in the *Connect Customer Administrator Guide*.
 */
export declare const createPushNotificationRegistration: API.OperationMethod<CreatePushNotificationRegistrationRequest, CreatePushNotificationRegistrationResponse, CreatePushNotificationRegistrationError, Creds | HttpClient.HttpClient>;
export type CreateQueueError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new queue for the specified Connect Customer instance.
 *
 * - If the phone number is claimed to a traffic distribution group that was created in the
 * same Region as the Connect Customer instance where you are calling this API, then you can use a
 * full phone number ARN or a UUID for `OutboundCallerIdNumberId`. However, if the phone number is claimed
 * to a traffic distribution group that is in one Region, and you are calling this API from an instance in another Amazon Web Services Region that is associated with the traffic distribution group, you must provide a full phone number ARN. If a
 * UUID is provided in this scenario, you will receive a
 * `ResourceNotFoundException`.
 *
 * - Only use the phone number ARN format that doesn't contain `instance` in the path, for example,
 * `arn:aws:connect:us-east-1:1234567890:phone-number/uuid`. This is the same ARN format that is returned
 * when you call the ListPhoneNumbersV2 API.
 *
 * - If you plan to use IAM policies to allow/deny access to this API for phone number resources
 * claimed to a traffic distribution group, see Allow or Deny queue API actions for phone numbers in a replica Region.
 */
export declare const createQueue: API.OperationMethod<CreateQueueRequest, CreateQueueResponse, CreateQueueError, Creds | HttpClient.HttpClient>;
export type CreateQuickConnectError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a quick connect for the specified Connect Customer instance.
 */
export declare const createQuickConnect: API.OperationMethod<CreateQuickConnectRequest, CreateQuickConnectResponse, CreateQuickConnectError, Creds | HttpClient.HttpClient>;
export type CreateRoutingProfileError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new routing profile.
 */
export declare const createRoutingProfile: API.OperationMethod<CreateRoutingProfileRequest, CreateRoutingProfileResponse, CreateRoutingProfileError, Creds | HttpClient.HttpClient>;
export type CreateRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a rule for the specified Connect Customer instance.
 *
 * Use the Rules Function
 * language to code conditions for the rule.
 */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, Creds | HttpClient.HttpClient>;
export type CreateSecurityProfileError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const createSecurityProfile: API.OperationMethod<CreateSecurityProfileRequest, CreateSecurityProfileResponse, CreateSecurityProfileError, Creds | HttpClient.HttpClient>;
export type CreateTaskTemplateError = InternalServiceException | InvalidParameterException | PropertyValidationException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a new task template in the specified Connect Customer instance.
 */
export declare const createTaskTemplate: API.OperationMethod<CreateTaskTemplateRequest, CreateTaskTemplateResponse, CreateTaskTemplateError, Creds | HttpClient.HttpClient>;
export type CreateTestCaseError = AccessDeniedException | DuplicateResourceException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | InvalidTestCaseException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a test case with its content and metadata for the specified Amazon Connect instance.
 */
export declare const createTestCase: API.OperationMethod<CreateTestCaseRequest, CreateTestCaseResponse, CreateTestCaseError, Creds | HttpClient.HttpClient>;
export type CreateTrafficDistributionGroupError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ResourceNotReadyException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a traffic distribution group given an Connect Customer instance that has been replicated.
 *
 * The `SignInConfig` distribution is available only on a
 * default `TrafficDistributionGroup` (see the `IsDefault` parameter in the
 * TrafficDistributionGroup
 * data type). If you call
 * `UpdateTrafficDistribution` with a modified `SignInConfig` and a non-default `TrafficDistributionGroup`,
 * an `InvalidRequestException` is returned.
 *
 * For more information about creating traffic distribution groups, see Set up traffic distribution groups in the
 * *Connect Customer Administrator Guide*.
 */
export declare const createTrafficDistributionGroup: API.OperationMethod<CreateTrafficDistributionGroupRequest, CreateTrafficDistributionGroupResponse, CreateTrafficDistributionGroupError, Creds | HttpClient.HttpClient>;
export type CreateUseCaseError = DuplicateResourceException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a use case for an integration association.
 */
export declare const createUseCase: API.OperationMethod<CreateUseCaseRequest, CreateUseCaseResponse, CreateUseCaseError, Creds | HttpClient.HttpClient>;
export type CreateUserError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a user account for the specified Connect Customer instance.
 *
 * Certain UserIdentityInfo parameters are required in some situations. For example, `Email`,
 * `FirstName` and `LastName` are required if you are using Connect Customer or SAML for
 * identity management.
 *
 * Fields in `PhoneConfig` cannot be set simultaneously with their corresponding channel-specific configuration parameters. Specifically:
 *
 * - `PhoneConfig.AutoAccept` conflicts with `AutoAcceptConfigs`
 *
 * - `PhoneConfig.AfterContactWorkTimeLimit` conflicts with `AfterContactWorkConfigs`
 *
 * - `PhoneConfig.PhoneType` and `PhoneConfig.PhoneNumber` conflict with `PhoneNumberConfigs`
 *
 * - `PhoneConfig.PersistentConnection` conflicts with `PersistentConnectionConfigs`
 *
 * We recommend using channel-specific parameters such as `AutoAcceptConfigs`, `AfterContactWorkConfigs`, `PhoneNumberConfigs`, `PersistentConnectionConfigs`, and `VoiceEnhancementConfigs` for per-channel configuration.
 *
 * For information about how to create users using the Connect Customer admin website, see Add Users in the Connect Customer
 * Administrator Guide.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResponse, CreateUserError, Creds | HttpClient.HttpClient>;
export type CreateUserHierarchyGroupError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new user hierarchy group.
 */
export declare const createUserHierarchyGroup: API.OperationMethod<CreateUserHierarchyGroupRequest, CreateUserHierarchyGroupResponse, CreateUserHierarchyGroupError, Creds | HttpClient.HttpClient>;
export type CreateViewError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new view with the possible status of `SAVED` or `PUBLISHED`.
 *
 * The views will have a unique name for each connect instance.
 *
 * It performs basic content validation if the status is `SAVED` or full content validation if the
 * status is set to `PUBLISHED`. An error is returned if validation fails. It associates either the
 * `$SAVED` qualifier or both of the `$SAVED` and `$LATEST` qualifiers with the
 * provided view content based on the status. The view is idempotent if ClientToken is provided.
 */
export declare const createView: API.OperationMethod<CreateViewRequest, CreateViewResponse, CreateViewError, Creds | HttpClient.HttpClient>;
export type CreateViewVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Publishes a new version of the view identifier.
 *
 * Versions are immutable and monotonically increasing.
 *
 * It returns the highest version if there is no change in content compared to that version. An error is displayed
 * if the supplied ViewContentSha256 is different from the ViewContentSha256 of the `$LATEST` alias.
 */
export declare const createViewVersion: API.OperationMethod<CreateViewVersionRequest, CreateViewVersionResponse, CreateViewVersionError, Creds | HttpClient.HttpClient>;
export type CreateVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a custom vocabulary associated with your Connect Customer instance. You can set a custom vocabulary to
 * be your default vocabulary for a given language. Contact Lens for Connect Customer uses the default vocabulary in post-call and real-time
 * contact analysis sessions for that language.
 */
export declare const createVocabulary: API.OperationMethod<CreateVocabularyRequest, CreateVocabularyResponse, CreateVocabularyError, Creds | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a workspace that defines the user experience by mapping views to pages. Workspaces can be assigned to
 * users or routing profiles.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest, CreateWorkspaceResponse, CreateWorkspaceError, Creds | HttpClient.HttpClient>;
export type CreateWorkspacePageError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Associates a view with a page in a workspace, defining what users see when they navigate to that page.
 */
export declare const createWorkspacePage: API.OperationMethod<CreateWorkspacePageRequest, CreateWorkspacePageResponse, CreateWorkspacePageError, Creds | HttpClient.HttpClient>;
export type DeactivateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deactivates an evaluation form in the specified Connect Customer instance. After a form is deactivated, it is no longer
 * available for users to start new evaluations based on the form.
 */
export declare const deactivateEvaluationForm: API.OperationMethod<DeactivateEvaluationFormRequest, DeactivateEvaluationFormResponse, DeactivateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type DeleteAttachedFileError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an attached file along with the underlying S3 Object.
 *
 * The attached file is **permanently deleted** if S3 bucket versioning is not
 * enabled.
 */
export declare const deleteAttachedFile: API.OperationMethod<DeleteAttachedFileRequest, DeleteAttachedFileResponse, DeleteAttachedFileError, Creds | HttpClient.HttpClient>;
export type DeleteContactDataError = ContactNotTerminatedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified fields containing personally identifiable information (PII) from a
 * contact in the specified Connect Customer instance. We redact PII (such as
 * customer endpoints, additional email recipients, and the email subject) from the contact and its
 * associated contact trace record (CTR). The contact must be in a terminated state.
 *
 * **This deletion is permanent and cannot be undone.** Performing this
 * operation permanently deletes the specified PII. There is
 * no retention period; you cannot recover the data after deletion. We remove only the fields
 * that Connect Customer identifies and stores as PII. Any PII that you place in fields
 * outside the scope of this operation remains your responsibility to remove.
 */
export declare const deleteContactData: API.OperationMethod<DeleteContactDataRequest, DeleteContactDataResponse, DeleteContactDataError, Creds | HttpClient.HttpClient>;
export type DeleteContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a contact evaluation in the specified Connect Customer instance.
 */
export declare const deleteContactEvaluation: API.OperationMethod<DeleteContactEvaluationRequest, DeleteContactEvaluationResponse, DeleteContactEvaluationError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a flow for the specified Connect Customer instance.
 */
export declare const deleteContactFlow: API.OperationMethod<DeleteContactFlowRequest, DeleteContactFlowResponse, DeleteContactFlowError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowModuleError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified flow module.
 */
export declare const deleteContactFlowModule: API.OperationMethod<DeleteContactFlowModuleRequest, DeleteContactFlowModuleResponse, DeleteContactFlowModuleError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowModuleAliasError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes an alias reference, breaking the named connection to the underlying module version without affecting the
 * version itself.
 */
export declare const deleteContactFlowModuleAlias: API.OperationMethod<DeleteContactFlowModuleAliasRequest, DeleteContactFlowModuleAliasResponse, DeleteContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowModuleVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a specific version of a contact flow module.
 */
export declare const deleteContactFlowModuleVersion: API.OperationMethod<DeleteContactFlowModuleVersionRequest, DeleteContactFlowModuleVersionResponse, DeleteContactFlowModuleVersionError, Creds | HttpClient.HttpClient>;
export type DeleteContactFlowVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the particular version specified in flow version identifier.
 */
export declare const deleteContactFlowVersion: API.OperationMethod<DeleteContactFlowVersionRequest, DeleteContactFlowVersionResponse, DeleteContactFlowVersionError, Creds | HttpClient.HttpClient>;
export type DeleteDataTableError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a data table and all associated attributes, versions, audits, and values. Does not update any references
 * to the data table, even from other data tables. This includes dynamic values and conditional validations. System
 * managed data tables are not deletable by customers. API users may delete the table at any time. When deletion is
 * requested from the admin website, a warning is shown alerting the user of the most recent time the table and its
 * values were accessed.
 */
export declare const deleteDataTable: API.OperationMethod<DeleteDataTableRequest, DeleteDataTableResponse, DeleteDataTableError, Creds | HttpClient.HttpClient>;
export type DeleteDataTableAttributeError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an attribute and all its values from a data table.
 */
export declare const deleteDataTableAttribute: API.OperationMethod<DeleteDataTableAttributeRequest, DeleteDataTableAttributeResponse, DeleteDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type DeleteEmailAddressError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes email address from the specified Connect Customer instance.
 */
export declare const deleteEmailAddress: API.OperationMethod<DeleteEmailAddressRequest, DeleteEmailAddressResponse, DeleteEmailAddressError, Creds | HttpClient.HttpClient>;
export type DeleteEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an evaluation form in the specified Connect Customer instance.
 *
 * - If the version property is provided, only the specified version of the evaluation form is deleted.
 *
 * - If no version is provided, then the full form (all versions) is deleted.
 */
export declare const deleteEvaluationForm: API.OperationMethod<DeleteEvaluationFormRequest, DeleteEvaluationFormResponse, DeleteEvaluationFormError, Creds | HttpClient.HttpClient>;
export type DeleteExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an extraction definition from the specified Connect Customer instance.
 */
export declare const deleteExtractionDefinition: API.OperationMethod<DeleteExtractionDefinitionRequest, DeleteExtractionDefinitionResponse, DeleteExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type DeleteHoursOfOperationError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an hours of operation.
 */
export declare const deleteHoursOfOperation: API.OperationMethod<DeleteHoursOfOperationRequest, DeleteHoursOfOperationResponse, DeleteHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type DeleteHoursOfOperationOverrideError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an hours of operation override in an Connect Customer hours of operation resource.
 */
export declare const deleteHoursOfOperationOverride: API.OperationMethod<DeleteHoursOfOperationOverrideRequest, DeleteHoursOfOperationOverrideResponse, DeleteHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type DeleteInstanceError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Deletes the Connect Customer instance. For more information, see Delete your Connect Customer instance in the
 * *Connect Customer Administrator Guide*.
 *
 * Connect Customer enforces a limit on the total number of instances that you can create or delete in 30 days.
 * If you exceed this limit, you will get an error message indicating there has been an excessive number of attempts at creating or deleting instances.
 * You must wait 30 days before you can restart creating and deleting instances in your account.
 */
export declare const deleteInstance: API.OperationMethod<DeleteInstanceRequest, DeleteInstanceResponse, DeleteInstanceError, Creds | HttpClient.HttpClient>;
export type DeleteIntegrationAssociationError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an Amazon Web Services resource association from an Connect Customer instance. The association must not
 * have any use cases associated with it.
 */
export declare const deleteIntegrationAssociation: API.OperationMethod<DeleteIntegrationAssociationRequest, DeleteIntegrationAssociationResponse, DeleteIntegrationAssociationError, Creds | HttpClient.HttpClient>;
export type DeleteMetricError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing metric from the specified Connect Customer instance. This operation fails with `ResourceConflictException` if the metric is currently in use in a dashboard.
 */
export declare const deleteMetric: API.OperationMethod<DeleteMetricRequest, DeleteMetricResponse, DeleteMetricError, Creds | HttpClient.HttpClient>;
export type DeleteNotificationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a notification. Once deleted, the notification is no longer visible to all users and cannot be managed through the Admin Website or APIs.
 */
export declare const deleteNotification: API.OperationMethod<DeleteNotificationRequest, DeleteNotificationResponse, DeleteNotificationError, Creds | HttpClient.HttpClient>;
export type DeletePredefinedAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a predefined attribute from the specified Connect Customer instance.
 */
export declare const deletePredefinedAttribute: API.OperationMethod<DeletePredefinedAttributeRequest, DeletePredefinedAttributeResponse, DeletePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type DeletePromptError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a prompt.
 */
export declare const deletePrompt: API.OperationMethod<DeletePromptRequest, DeletePromptResponse, DeletePromptError, Creds | HttpClient.HttpClient>;
export type DeletePushNotificationRegistrationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes registration for a device token and a chat contact.
 */
export declare const deletePushNotificationRegistration: API.OperationMethod<DeletePushNotificationRegistrationRequest, DeletePushNotificationRegistrationResponse, DeletePushNotificationRegistrationError, Creds | HttpClient.HttpClient>;
export type DeleteQueueError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a queue.
 */
export declare const deleteQueue: API.OperationMethod<DeleteQueueRequest, DeleteQueueResponse, DeleteQueueError, Creds | HttpClient.HttpClient>;
export type DeleteQuickConnectError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a quick connect.
 *
 * After calling DeleteUser, it's important to call `DeleteQuickConnect` to delete any records related to the
 * deleted users. This will help you:
 *
 * - Avoid dangling resources that impact your service quotas.
 *
 * - Remove deleted users so they don't appear to agents as transfer options.
 *
 * - Avoid the disruption of other Connect Customer processes, such as instance replication and syncing if
 * you're using Connect Customer Global Resiliency.
 */
export declare const deleteQuickConnect: API.OperationMethod<DeleteQuickConnectRequest, DeleteQuickConnectResponse, DeleteQuickConnectError, Creds | HttpClient.HttpClient>;
export type DeleteRoutingProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a routing profile.
 */
export declare const deleteRoutingProfile: API.OperationMethod<DeleteRoutingProfileRequest, DeleteRoutingProfileResponse, DeleteRoutingProfileError, Creds | HttpClient.HttpClient>;
export type DeleteRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a rule for the specified Connect Customer instance.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, Creds | HttpClient.HttpClient>;
export type DeleteSecurityProfileError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a security profile.
 */
export declare const deleteSecurityProfile: API.OperationMethod<DeleteSecurityProfileRequest, DeleteSecurityProfileResponse, DeleteSecurityProfileError, Creds | HttpClient.HttpClient>;
export type DeleteSessionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a session for the specified Connect Customer instance.
 */
export declare const deleteSession: API.OperationMethod<DeleteSessionRequest, DeleteSessionResponse, DeleteSessionError, Creds | HttpClient.HttpClient>;
export type DeleteTaskTemplateError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the task template.
 */
export declare const deleteTaskTemplate: API.OperationMethod<DeleteTaskTemplateRequest, DeleteTaskTemplateResponse, DeleteTaskTemplateError, Creds | HttpClient.HttpClient>;
export type DeleteTestCaseError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the test case that has already been created for the specified Amazon Connect instance.
 */
export declare const deleteTestCase: API.OperationMethod<DeleteTestCaseRequest, DeleteTestCaseResponse, DeleteTestCaseError, Creds | HttpClient.HttpClient>;
export type DeleteTrafficDistributionGroupError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceInUseException | ThrottlingException | CommonErrors;
/**
 * Deletes a traffic distribution group. This API can be called only in the Region where the traffic distribution group is created.
 *
 * For more information about deleting traffic distribution groups, see Delete traffic distribution groups in the
 * *Connect Customer Administrator Guide*.
 */
export declare const deleteTrafficDistributionGroup: API.OperationMethod<DeleteTrafficDistributionGroupRequest, DeleteTrafficDistributionGroupResponse, DeleteTrafficDistributionGroupError, Creds | HttpClient.HttpClient>;
export type DeleteUseCaseError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a use case from an integration association.
 */
export declare const deleteUseCase: API.OperationMethod<DeleteUseCaseRequest, DeleteUseCaseResponse, DeleteUseCaseError, Creds | HttpClient.HttpClient>;
export type DeleteUserError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a user account from the specified Connect Customer instance.
 *
 * For information about what happens to a user's data when their account is deleted, see Delete Users from Your Connect Customer
 * Instance in the *Connect Customer Administrator Guide*.
 *
 * After calling DeleteUser, call DeleteQuickConnect to delete any records
 * related to the deleted users. This will help you:
 *
 * - Avoid dangling resources that impact your service quotas.
 *
 * - Remove deleted users so they don't appear to agents as transfer options.
 *
 * - Avoid the disruption of other Connect Customer processes, such as instance replication and syncing if
 * you're using Connect Customer Global Resiliency.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Creds | HttpClient.HttpClient>;
export type DeleteUserHierarchyGroupError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing user hierarchy group. It must not be associated with any agents or have any active child
 * groups.
 */
export declare const deleteUserHierarchyGroup: API.OperationMethod<DeleteUserHierarchyGroupRequest, DeleteUserHierarchyGroupResponse, DeleteUserHierarchyGroupError, Creds | HttpClient.HttpClient>;
export type DeleteViewError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the view entirely. It deletes the view and all associated qualifiers (versions and aliases).
 */
export declare const deleteView: API.OperationMethod<DeleteViewRequest, DeleteViewResponse, DeleteViewError, Creds | HttpClient.HttpClient>;
export type DeleteViewVersionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the particular version specified in `ViewVersion` identifier.
 */
export declare const deleteViewVersion: API.OperationMethod<DeleteViewVersionRequest, DeleteViewVersionResponse, DeleteViewVersionError, Creds | HttpClient.HttpClient>;
export type DeleteVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the vocabulary that has the given identifier.
 */
export declare const deleteVocabulary: API.OperationMethod<DeleteVocabularyRequest, DeleteVocabularyResponse, DeleteVocabularyError, Creds | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a workspace and removes all associated view and resource assignments.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest, DeleteWorkspaceResponse, DeleteWorkspaceError, Creds | HttpClient.HttpClient>;
export type DeleteWorkspaceMediaError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a media asset (such as a logo) from a workspace.
 */
export declare const deleteWorkspaceMedia: API.OperationMethod<DeleteWorkspaceMediaRequest, DeleteWorkspaceMediaResponse, DeleteWorkspaceMediaError, Creds | HttpClient.HttpClient>;
export type DeleteWorkspacePageError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the association between a view and a page in a workspace. The page will display the default view after
 * deletion.
 */
export declare const deleteWorkspacePage: API.OperationMethod<DeleteWorkspacePageRequest, DeleteWorkspacePageResponse, DeleteWorkspacePageError, Creds | HttpClient.HttpClient>;
export type DescribeAgentStatusError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an agent status.
 */
export declare const describeAgentStatus: API.OperationMethod<DescribeAgentStatusRequest, DescribeAgentStatusResponse, DescribeAgentStatusError, Creds | HttpClient.HttpClient>;
export type DescribeAttachedFilesConfigurationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the attached files configuration for the specified Connect Customer instance and attachment scope.
 *
 * If a custom configuration exists for the specified attachment scope, the custom configuration is returned. If no custom configuration exists, the default configuration values for that attachment scope are returned.
 */
export declare const describeAttachedFilesConfiguration: API.OperationMethod<DescribeAttachedFilesConfigurationRequest, DescribeAttachedFilesConfigurationResponse, DescribeAttachedFilesConfigurationError, Creds | HttpClient.HttpClient>;
export type DescribeAuthenticationProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change. To
 * request access to this API, contact Amazon Web Services Support.
 *
 * Describes the target authentication profile.
 */
export declare const describeAuthenticationProfile: API.OperationMethod<DescribeAuthenticationProfileRequest, DescribeAuthenticationProfileResponse, DescribeAuthenticationProfileError, Creds | HttpClient.HttpClient>;
export type DescribeContactError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Describes the specified contact.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Retrieve contact information such as the caller's phone number and the specific number the caller dialed to
 * integrate into custom monitoring or custom agent experience solutions.
 *
 * - Detect when a customer chat session disconnects due to a network issue on the agent's end. Use the
 * DisconnectReason field in the ContactTraceRecord to detect
 * this event and then re-queue the chat for followup.
 *
 * - Identify after contact work (ACW) duration and call recordings information when a COMPLETED event is received
 * by using the contact event
 * stream.
 *
 * **Important things to know**
 *
 * - `SystemEndpoint` is not populated for contacts with initiation method of MONITOR, QUEUE_TRANSFER,
 * or CALLBACK
 *
 * - Contact information remains available in Connect Customer for 24 months from the
 * `InitiationTimestamp`, and then it is deleted. Only contact information that is available in Connect Customer is returned by this API.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const describeContact: API.OperationMethod<DescribeContactRequest, DescribeContactResponse, DescribeContactError, Creds | HttpClient.HttpClient>;
export type DescribeContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a contact evaluation in the specified Connect Customer instance.
 */
export declare const describeContactEvaluation: API.OperationMethod<DescribeContactEvaluationRequest, DescribeContactEvaluationResponse, DescribeContactEvaluationError, Creds | HttpClient.HttpClient>;
export type DescribeContactFlowError = ContactFlowNotPublishedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified flow.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 *
 * Use `arn:aws:.../contact-flow/{id}:{version}` to retrieve the content of a specific flow
 * version.
 *
 * In the response, **Status** indicates the flow status as either `SAVED`
 * or `PUBLISHED`. The `PUBLISHED` status will initiate validation on the content.
 * `SAVED` does not initiate validation of the content. `SAVED` | `PUBLISHED`
 */
export declare const describeContactFlow: API.OperationMethod<DescribeContactFlowRequest, DescribeContactFlowResponse, DescribeContactFlowError, Creds | HttpClient.HttpClient>;
export type DescribeContactFlowModuleError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified flow module.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 */
export declare const describeContactFlowModule: API.OperationMethod<DescribeContactFlowModuleRequest, DescribeContactFlowModuleResponse, DescribeContactFlowModuleError, Creds | HttpClient.HttpClient>;
export type DescribeContactFlowModuleAliasError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific alias, including which version it currently points to and its
 * metadata.
 */
export declare const describeContactFlowModuleAlias: API.OperationMethod<DescribeContactFlowModuleAliasRequest, DescribeContactFlowModuleAliasResponse, DescribeContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type DescribeDataTableError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns all properties for a data table except for attributes and values. All properties from CreateDataTable
 * are returned as well as properties for region replication, versioning, and system tables. "Describe" is a deprecated
 * term but is allowed to maintain consistency with existing operations.
 */
export declare const describeDataTable: API.OperationMethod<DescribeDataTableRequest, DescribeDataTableResponse, DescribeDataTableError, Creds | HttpClient.HttpClient>;
export type DescribeDataTableAttributeError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information for a specific data table attribute including its configuration, validation rules,
 * and metadata. "Describe" is a deprecated term but is allowed to maintain consistency with existing operations.
 */
export declare const describeDataTableAttribute: API.OperationMethod<DescribeDataTableAttributeRequest, DescribeDataTableAttributeResponse, DescribeDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type DescribeEmailAddressError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describe email address form the specified Connect Customer instance.
 */
export declare const describeEmailAddress: API.OperationMethod<DescribeEmailAddressRequest, DescribeEmailAddressResponse, DescribeEmailAddressError, Creds | HttpClient.HttpClient>;
export type DescribeEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an evaluation form in the specified Connect Customer instance. If the version property is not
 * provided, the latest version of the evaluation form is described.
 */
export declare const describeEvaluationForm: API.OperationMethod<DescribeEvaluationFormRequest, DescribeEvaluationFormResponse, DescribeEvaluationFormError, Creds | HttpClient.HttpClient>;
export type DescribeExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an extraction definition in the specified Connect Customer instance.
 */
export declare const describeExtractionDefinition: API.OperationMethod<DescribeExtractionDefinitionRequest, DescribeExtractionDefinitionResponse, DescribeExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type DescribeHoursOfOperationError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the hours of operation.
 */
export declare const describeHoursOfOperation: API.OperationMethod<DescribeHoursOfOperationRequest, DescribeHoursOfOperationResponse, DescribeHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type DescribeHoursOfOperationOverrideError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the hours of operation override.
 */
export declare const describeHoursOfOperationOverride: API.OperationMethod<DescribeHoursOfOperationOverrideRequest, DescribeHoursOfOperationOverrideResponse, DescribeHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type DescribeInstanceError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns the current state of the specified instance identifier. It tracks the instance while it is being created
 * and returns an error status, if applicable.
 *
 * If an instance is not created successfully, the instance status reason field returns details relevant to the
 * reason. The instance in a failed state is returned only for 24 hours after the CreateInstance API was invoked.
 */
export declare const describeInstance: API.OperationMethod<DescribeInstanceRequest, DescribeInstanceResponse, DescribeInstanceError, Creds | HttpClient.HttpClient>;
export type DescribeInstanceAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Describes the specified instance attribute.
 */
export declare const describeInstanceAttribute: API.OperationMethod<DescribeInstanceAttributeRequest, DescribeInstanceAttributeResponse, DescribeInstanceAttributeError, Creds | HttpClient.HttpClient>;
export type DescribeInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Retrieves the current storage configurations for the specified resource type, association ID, and instance
 * ID.
 */
export declare const describeInstanceStorageConfig: API.OperationMethod<DescribeInstanceStorageConfigRequest, DescribeInstanceStorageConfigResponse, DescribeInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type DescribeMetricError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the full definition of an existing metric from the specified Connect Customer instance.
 */
export declare const describeMetric: API.OperationMethod<DescribeMetricRequest, DescribeMetricResponse, DescribeMetricError, Creds | HttpClient.HttpClient>;
export type DescribeNotificationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about a specific notification, including its content, priority, recipients, and metadata.
 */
export declare const describeNotification: API.OperationMethod<DescribeNotificationRequest, DescribeNotificationResponse, DescribeNotificationError, Creds | HttpClient.HttpClient>;
export type DescribePhoneNumberError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets details and status of a phone number that’s claimed to your Connect Customer instance or traffic distribution group.
 *
 * If the number is claimed to a traffic distribution group, and you are calling in the Amazon Web Services Region where the traffic distribution group was
 * created, you can use either a phone number ARN or UUID value for the `PhoneNumberId` URI request
 * parameter. However, if the number is claimed to a traffic distribution group and you are calling this API in the alternate Amazon Web Services Region associated with the traffic distribution group, you must provide a full phone number ARN. If a UUID is provided
 * in
 * this scenario, you receive a `ResourceNotFoundException`.
 */
export declare const describePhoneNumber: API.OperationMethod<DescribePhoneNumberRequest, DescribePhoneNumberResponse, DescribePhoneNumberError, Creds | HttpClient.HttpClient>;
export type DescribePredefinedAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a predefined attribute for the specified Connect Customer instance. A *predefined attribute*
 * is made up of a name and a value. You can use predefined attributes for:
 *
 * - Routing proficiency (for example, agent certification) that has predefined values (for example, a list of
 * possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Contact information that varies between transfers or conferences, such as the name of the business unit
 * handling the contact. For more information, see Use contact segment attributes.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const describePredefinedAttribute: API.OperationMethod<DescribePredefinedAttributeRequest, DescribePredefinedAttributeResponse, DescribePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type DescribePromptError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the prompt.
 */
export declare const describePrompt: API.OperationMethod<DescribePromptRequest, DescribePromptResponse, DescribePromptError, Creds | HttpClient.HttpClient>;
export type DescribeQueueError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified queue.
 */
export declare const describeQueue: API.OperationMethod<DescribeQueueRequest, DescribeQueueResponse, DescribeQueueError, Creds | HttpClient.HttpClient>;
export type DescribeQuickConnectError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the quick connect.
 */
export declare const describeQuickConnect: API.OperationMethod<DescribeQuickConnectRequest, DescribeQuickConnectResponse, DescribeQuickConnectError, Creds | HttpClient.HttpClient>;
export type DescribeRoutingProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified routing profile.
 *
 * `DescribeRoutingProfile` does not populate AssociatedQueueIds in its response. The example Response
 * Syntax shown on this page is incorrect; we are working to update it. SearchRoutingProfiles does include
 * AssociatedQueueIds.
 */
export declare const describeRoutingProfile: API.OperationMethod<DescribeRoutingProfileRequest, DescribeRoutingProfileResponse, DescribeRoutingProfileError, Creds | HttpClient.HttpClient>;
export type DescribeRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a rule for the specified Connect Customer instance.
 */
export declare const describeRule: API.OperationMethod<DescribeRuleRequest, DescribeRuleResponse, DescribeRuleError, Creds | HttpClient.HttpClient>;
export type DescribeSecurityProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets basic information about the security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const describeSecurityProfile: API.OperationMethod<DescribeSecurityProfileRequest, DescribeSecurityProfileResponse, DescribeSecurityProfileError, Creds | HttpClient.HttpClient>;
export type DescribeTestCaseError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified test case and allows you to get the content and metadata of the test case for the specified Amazon Connect instance.
 */
export declare const describeTestCase: API.OperationMethod<DescribeTestCaseRequest, DescribeTestCaseResponse, DescribeTestCaseError, Creds | HttpClient.HttpClient>;
export type DescribeTrafficDistributionGroupError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets details and status of a traffic distribution group.
 */
export declare const describeTrafficDistributionGroup: API.OperationMethod<DescribeTrafficDistributionGroupRequest, DescribeTrafficDistributionGroupResponse, DescribeTrafficDistributionGroupError, Creds | HttpClient.HttpClient>;
export type DescribeUserError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified user. You can find the instance ID in the Connect Customer
 * console (it’s the final part of the ARN). The console does not display the user IDs. Instead, list the users
 * and note the IDs provided in the output.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest, DescribeUserResponse, DescribeUserError, Creds | HttpClient.HttpClient>;
export type DescribeUserHierarchyGroupError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified hierarchy group.
 */
export declare const describeUserHierarchyGroup: API.OperationMethod<DescribeUserHierarchyGroupRequest, DescribeUserHierarchyGroupResponse, DescribeUserHierarchyGroupError, Creds | HttpClient.HttpClient>;
export type DescribeUserHierarchyStructureError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the hierarchy structure of the specified Connect Customer instance.
 */
export declare const describeUserHierarchyStructure: API.OperationMethod<DescribeUserHierarchyStructureRequest, DescribeUserHierarchyStructureResponse, DescribeUserHierarchyStructureError, Creds | HttpClient.HttpClient>;
export type DescribeViewError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the view for the specified Connect Customer instance and view identifier.
 *
 * The view identifier can be supplied as a ViewId or ARN.
 *
 * `$SAVED` needs to be supplied if a view is unpublished.
 *
 * The view identifier can contain an optional qualifier, for example, `:$SAVED`, which
 * is either an actual version number or an Connect Customer managed qualifier `$SAVED | $LATEST`. If it is
 * not supplied, then `$LATEST` is assumed for customer managed views and an error is returned if there is no
 * published content available. Version 1 is assumed for Amazon Web Services managed views.
 */
export declare const describeView: API.OperationMethod<DescribeViewRequest, DescribeViewResponse, DescribeViewError, Creds | HttpClient.HttpClient>;
export type DescribeVocabularyError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the specified vocabulary.
 */
export declare const describeVocabulary: API.OperationMethod<DescribeVocabularyRequest, DescribeVocabularyResponse, DescribeVocabularyError, Creds | HttpClient.HttpClient>;
export type DescribeWorkspaceError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about a workspace, including its configuration and metadata.
 */
export declare const describeWorkspace: API.OperationMethod<DescribeWorkspaceRequest, DescribeWorkspaceResponse, DescribeWorkspaceError, Creds | HttpClient.HttpClient>;
export type DisassociateAnalyticsDataSetError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the dataset ID associated with a given Connect Customer instance.
 */
export declare const disassociateAnalyticsDataSet: API.OperationMethod<DisassociateAnalyticsDataSetRequest, DisassociateAnalyticsDataSetResponse, DisassociateAnalyticsDataSetError, Creds | HttpClient.HttpClient>;
export type DisassociateApprovedOriginError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Revokes access to integrated applications from Connect Customer.
 */
export declare const disassociateApprovedOrigin: API.OperationMethod<DisassociateApprovedOriginRequest, DisassociateApprovedOriginResponse, DisassociateApprovedOriginError, Creds | HttpClient.HttpClient>;
export type DisassociateBotError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Revokes authorization from the specified instance to access the specified Amazon Lex or Amazon Lex V2 bot.
 */
export declare const disassociateBot: API.OperationMethod<DisassociateBotRequest, DisassociateBotResponse, DisassociateBotError, Creds | HttpClient.HttpClient>;
export type DisassociateEmailAddressAliasError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the alias association between two email addresses in an Connect Customer instance. After
 * disassociation, emails sent to the former alias email address are no longer forwarded to the primary email address.
 * Both email addresses continue to exist independently and can receive emails directly.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - **Department separation**: Remove alias relationships when splitting a
 * consolidated support queue back into separate department-specific queues.
 *
 * - **Email address retirement**: Cleanly remove forwarding relationships before
 * decommissioning old email addresses.
 *
 * - **Organizational restructuring**: Reconfigure email routing when business
 * processes change and aliases are no longer needed.
 *
 * **Important things to know**
 *
 * - Concurrent operations: This API uses distributed locking, so concurrent operations on the same email addresses
 * may be temporarily blocked.
 *
 * - Emails sent to the former alias address are still delivered directly to that address if it exists.
 *
 * - You do not need to delete the email addresses after disassociation. Both addresses remain active
 * independently.
 *
 * - After a successful disassociation, you can immediately create a new alias relationship with the same
 * addresses.
 *
 * - 200 status means alias was successfully disassociated.
 *
 * `DisassociateEmailAddressAlias` does not return the following information:
 *
 * - Details in the response about the email that was disassociated. The response returns an empty body.
 *
 * - The timestamp of when the disassociation occurred.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 *
 * **Related operations**
 *
 * - AssociateEmailAddressAlias: Associates an email address alias with an existing email address in an
 * Connect Customer instance.
 *
 * - DescribeEmailAddress: View current alias configurations for an email address.
 *
 * - SearchEmailAddresses: Find email addresses and their alias relationships across an instance.
 *
 * - CreateEmailAddress: Create new email addresses that can participate in alias relationships.
 *
 * - DeleteEmailAddress: Remove email addresses (automatically removes any alias relationships).
 *
 * - UpdateEmailAddressMetadata: Modify email address properties (does not affect alias relationships).
 */
export declare const disassociateEmailAddressAlias: API.OperationMethod<DisassociateEmailAddressAliasRequest, DisassociateEmailAddressAliasResponse, DisassociateEmailAddressAliasError, Creds | HttpClient.HttpClient>;
export type DisassociateFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a connect resource from a flow.
 */
export declare const disassociateFlow: API.OperationMethod<DisassociateFlowRequest, DisassociateFlowResponse, DisassociateFlowError, Creds | HttpClient.HttpClient>;
export type DisassociateHoursOfOperationsError = ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of hours of operations with another hours of operation. For more information about inheriting overrides from parent hours of operation, see Hours of operation overrides in the Administrator Guide.
 */
export declare const disassociateHoursOfOperations: API.OperationMethod<DisassociateHoursOfOperationsRequest, DisassociateHoursOfOperationsResponse, DisassociateHoursOfOperationsError, Creds | HttpClient.HttpClient>;
export type DisassociateInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Removes the storage type configurations for the specified resource type and association ID.
 */
export declare const disassociateInstanceStorageConfig: API.OperationMethod<DisassociateInstanceStorageConfigRequest, DisassociateInstanceStorageConfigResponse, DisassociateInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type DisassociateLambdaFunctionError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Remove the Lambda function from the dropdown options available in the relevant flow blocks.
 */
export declare const disassociateLambdaFunction: API.OperationMethod<DisassociateLambdaFunctionRequest, DisassociateLambdaFunctionResponse, DisassociateLambdaFunctionError, Creds | HttpClient.HttpClient>;
export type DisassociateLexBotError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Revokes authorization from the specified instance to access the specified Amazon Lex bot.
 */
export declare const disassociateLexBot: API.OperationMethod<DisassociateLexBotRequest, DisassociateLexBotResponse, DisassociateLexBotError, Creds | HttpClient.HttpClient>;
export type DisassociatePhoneNumberContactFlowError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the flow association from a phone number claimed to your Connect Customer instance.
 *
 * If the number is claimed to a traffic distribution group, and you are calling this API using an instance in the Amazon Web Services Region where the traffic distribution group was created, you can use either a full phone number ARN or UUID value for the
 * `PhoneNumberId` URI request parameter. However, if the number is claimed to a traffic distribution group and you are calling
 * this API using an instance in the alternate Amazon Web Services Region associated with the traffic distribution group, you must provide a
 * full phone number ARN. If a UUID is provided in this scenario, you will receive a
 * `ResourceNotFoundException`.
 */
export declare const disassociatePhoneNumberContactFlow: API.OperationMethod<DisassociatePhoneNumberContactFlowRequest, DisassociatePhoneNumberContactFlowResponse, DisassociatePhoneNumberContactFlowError, Creds | HttpClient.HttpClient>;
export type DisassociateQueueEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the association between a set of email addresses and a queue. After disassociation, agents will no longer be able to select these email addresses as "From" addresses when replying to inbound email contacts or initiating outbound email contacts in this queue.
 *
 * **Important things to know**
 *
 * - Agents will no longer see these email addresses in their "From" address selection options for this queue.
 *
 * - The email addresses themselves are not deleted from the instance, only their availability for agent selection in this queue is removed.
 *
 * - Changes take effect immediately and will affect the agent experience in the Contact Control Panel (CCP).
 */
export declare const disassociateQueueEmailAddresses: API.OperationMethod<DisassociateQueueEmailAddressesRequest, DisassociateQueueEmailAddressesResponse, DisassociateQueueEmailAddressesError, Creds | HttpClient.HttpClient>;
export type DisassociateQueueQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of quick connects from a queue.
 */
export declare const disassociateQueueQuickConnects: API.OperationMethod<DisassociateQueueQuickConnectsRequest, DisassociateQueueQuickConnectsResponse, DisassociateQueueQuickConnectsError, Creds | HttpClient.HttpClient>;
export type DisassociateRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of queues from a routing profile.
 *
 * Up to 10 queue references can be disassociated in a single API call. More than 10 queue references results in a
 * single call results in an InvalidParameterException.
 */
export declare const disassociateRoutingProfileQueues: API.OperationMethod<DisassociateRoutingProfileQueuesRequest, DisassociateRoutingProfileQueuesResponse, DisassociateRoutingProfileQueuesError, Creds | HttpClient.HttpClient>;
export type DisassociateSecurityKeyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Deletes the specified security key.
 */
export declare const disassociateSecurityKey: API.OperationMethod<DisassociateSecurityKeyRequest, DisassociateSecurityKeyResponse, DisassociateSecurityKeyError, Creds | HttpClient.HttpClient>;
export type DisassociateSecurityProfilesError = AccessDeniedException | ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a security profile attached to a Q in Connect AI Agent Entity in an Amazon Connect instance.
 */
export declare const disassociateSecurityProfiles: API.OperationMethod<DisassociateSecurityProfilesRequest, DisassociateSecurityProfilesResponse, DisassociateSecurityProfilesError, Creds | HttpClient.HttpClient>;
export type DisassociateTrafficDistributionGroupUserError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates an agent from a traffic distribution group. This API can be called only in the Region where the
 * traffic distribution group is created.
 */
export declare const disassociateTrafficDistributionGroupUser: API.OperationMethod<DisassociateTrafficDistributionGroupUserRequest, DisassociateTrafficDistributionGroupUserResponse, DisassociateTrafficDistributionGroupUserError, Creds | HttpClient.HttpClient>;
export type DisassociateUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disassociates a set of proficiencies from a user.
 */
export declare const disassociateUserProficiencies: API.OperationMethod<DisassociateUserProficienciesRequest, DisassociateUserProficienciesResponse, DisassociateUserProficienciesError, Creds | HttpClient.HttpClient>;
export type DisassociateWorkspaceError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the association between a workspace and one or more users or routing profiles.
 */
export declare const disassociateWorkspace: API.OperationMethod<DisassociateWorkspaceRequest, DisassociateWorkspaceResponse, DisassociateWorkspaceError, Creds | HttpClient.HttpClient>;
export type DismissUserContactError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Dismisses contacts from an agent’s CCP and returns the agent to an available state, which allows the agent to
 * receive a new routed contact. Contacts can only be dismissed if they are in a `MISSED`,
 * `ERROR`, `ENDED`, or `REJECTED` state in the Agent Event Stream.
 */
export declare const dismissUserContact: API.OperationMethod<DismissUserContactRequest, DismissUserContactResponse, DismissUserContactError, Creds | HttpClient.HttpClient>;
export type EvaluateDataTableValuesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Evaluates values at the time of the request and returns them. It considers the request's timezone or the table's
 * timezone, in that order, when accessing time based tables. When a value is accessed, the accessor's identity and the
 * time of access are saved alongside the value to help identify values that are actively in use. The term "Batch" is
 * not included in the operation name since it does not meet all the criteria for a batch operation as specified in
 * Batch Operations: Amazon Web Services API Standards.
 */
export declare const evaluateDataTableValues: API.PaginatedOperationMethod<EvaluateDataTableValuesRequest, EvaluateDataTableValuesResponse, EvaluateDataTableValuesError, Creds | HttpClient.HttpClient, unknown>;
export type GetAttachedFileError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a pre-signed URL for download of an approved attached file. This API also returns metadata about the
 * attached file. It will only return a downloadURL if the status of the attached file is `APPROVED`.
 */
export declare const getAttachedFile: API.OperationMethod<GetAttachedFileRequest, GetAttachedFileResponse, GetAttachedFileError, Creds | HttpClient.HttpClient>;
export type GetContactAttributesError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the contact attributes for the specified contact.
 */
export declare const getContactAttributes: API.OperationMethod<GetContactAttributesRequest, GetContactAttributesResponse, GetContactAttributesError, Creds | HttpClient.HttpClient>;
export type GetContactMetricsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves contact metric data for a specified contact.
 *
 * **Use cases**
 *
 * Following are common use cases for position in queue and estimated wait time:
 *
 * - Customer-Facing Wait Time Announcements - Display or announce the estimated wait time and position in queue to customers before or during their queue experience.
 *
 * - Callback Offerings - Offer customers a callback option when the estimated wait time or position in queue exceeds a defined threshold.
 *
 * - Queue Routing Decisions - Route incoming contacts to less congested queues by comparing estimated wait time and position in queue across multiple queues.
 *
 * - Self-Service Deflection - Redirect customers to self-service options like chatbots or FAQs when estimated wait time is high or position in queue is unfavorable.
 *
 * **Important things to know**
 *
 * - Metrics are only available while the contact is actively in queue.
 *
 * - For more information, see the Position in queue metric in the *Connect Customer Administrator Guide*.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const getContactMetrics: API.OperationMethod<GetContactMetricsRequest, GetContactMetricsResponse, GetContactMetricsError, Creds | HttpClient.HttpClient>;
export type GetCurrentMetricDataError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the real-time metric data from the specified Connect Customer instance.
 *
 * For a description of each metric, see Metrics definitions in the *Connect Customer Administrator Guide*.
 *
 * When you make a successful API request, you can expect the following metric values in the response:
 *
 * - **Metric value is null**: The calculation cannot be performed due to divide by
 * zero or insufficient data
 *
 * - **Metric value is a number (including 0) of defined type**: The number provided
 * is the calculation result
 *
 * - **MetricResult list is empty**: The request cannot find any data in the
 * system
 *
 * The following guidelines can help you work with the API:
 *
 * - Each dimension in the metric response must contain a value
 *
 * - Each item in MetricResult must include all requested metrics
 *
 * - If the response is slow due to large result sets, try these approaches:
 *
 * - Add filters to reduce the amount of data returned
 */
export declare const getCurrentMetricData: API.PaginatedOperationMethod<GetCurrentMetricDataRequest, GetCurrentMetricDataResponse, GetCurrentMetricDataError, Creds | HttpClient.HttpClient, unknown>;
export type GetCurrentUserDataError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the real-time active user data from the specified Connect Customer instance.
 */
export declare const getCurrentUserData: API.PaginatedOperationMethod<GetCurrentUserDataRequest, GetCurrentUserDataResponse, GetCurrentUserDataError, Creds | HttpClient.HttpClient, unknown>;
export type GetEffectiveHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get the hours of operations with the effective override applied.
 */
export declare const getEffectiveHoursOfOperations: API.OperationMethod<GetEffectiveHoursOfOperationsRequest, GetEffectiveHoursOfOperationsResponse, GetEffectiveHoursOfOperationsError, Creds | HttpClient.HttpClient>;
export type GetEvaluationFormValidationError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the status and results of a validation process started by StartEvaluationFormValidation.
 * Returns the current execution status (`IN_PROGRESS`, `COMPLETED`, or `FAILED`),
 * the validated form version, and when completed, a list of findings that identify structural issues and quality
 * improvements for the evaluation form, and may include suggested fixes. If the validation failed, a reason is provided
 * indicating the cause of the failure.
 */
export declare const getEvaluationFormValidation: API.OperationMethod<GetEvaluationFormValidationRequest, GetEvaluationFormValidationResponse, GetEvaluationFormValidationError, Creds | HttpClient.HttpClient>;
export type GetFederationTokenError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UserNotFoundException | CommonErrors;
/**
 * Supports SAML sign-in for Connect Customer. Retrieves a token for federation. The token is for the Connect Customer user which corresponds to the IAM credentials that were used to invoke this action.
 *
 * For more information about how SAML sign-in works in Connect Customer, see Configure SAML with IAM for Connect Customer
 * in the *Connect Customer Administrator Guide*.
 *
 * This API doesn't support root users. If you try to invoke GetFederationToken with root credentials, an error
 * message similar to the following one appears:
 *
 * `Provided identity: Principal: .... User: .... cannot be used for federation with Connect Customer`
 */
export declare const getFederationToken: API.OperationMethod<GetFederationTokenRequest, GetFederationTokenResponse, GetFederationTokenError, Creds | HttpClient.HttpClient>;
export type GetFlowAssociationError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the flow associated for a given resource.
 */
export declare const getFlowAssociation: API.OperationMethod<GetFlowAssociationRequest, GetFlowAssociationResponse, GetFlowAssociationError, Creds | HttpClient.HttpClient>;
export type GetMetricDataError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets historical metric data from the specified Connect Customer instance.
 *
 * For a description of each historical metric, see Metrics definitions in the *Connect Customer Administrator Guide*.
 *
 * We recommend using the GetMetricDataV2 API. It provides more flexibility, features, and the ability to query longer time ranges
 * than `GetMetricData`. Use it to retrieve historical agent and contact metrics for the last 3 months, at
 * varying intervals. You can also use it to build custom dashboards to measure historical queue and agent performance.
 * For example, you can track the number of incoming contacts for the last 7 days, with data split by day, to see how
 * contact volume changed per day of the week.
 */
export declare const getMetricData: API.PaginatedOperationMethod<GetMetricDataRequest, GetMetricDataResponse, GetMetricDataError, Creds | HttpClient.HttpClient, unknown>;
export type GetMetricDataV2Error = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets metric data from the specified Connect Customer instance.
 *
 * `GetMetricDataV2` offers more features than GetMetricData, the previous version of this API. It
 * has new metrics, offers filtering at a metric level, and offers the ability to filter and group data by channels,
 * queues, routing profiles, agents, and agent hierarchy levels. It can retrieve historical data for the last 3 months,
 * at varying intervals. It does not support agent queues.
 *
 * For a description of the historical metrics that are supported by `GetMetricDataV2` and
 * `GetMetricData`, see Metrics definitions in the *Connect Customer Administrator Guide*.
 *
 * When you make a successful API request, you can expect the following metric values in the response:
 *
 * - **Metric value is null**: The calculation cannot be performed due to divide by
 * zero or insufficient data
 *
 * - **Metric value is a number (including 0) of defined type**: The number provided
 * is the calculation result
 *
 * - **MetricResult list is empty**: The request cannot find any data in the
 * system
 *
 * The following guidelines can help you work with the API:
 *
 * - Each dimension in the metric response must contain a value
 *
 * - Each item in MetricResult must include all requested metrics
 *
 * - If the response is slow due to large result sets, try these approaches:
 *
 * - Narrow the time range of your request
 *
 * - Add filters to reduce the amount of data returned
 */
export declare const getMetricDataV2: API.PaginatedOperationMethod<GetMetricDataV2Request, GetMetricDataV2Response, GetMetricDataV2Error, Creds | HttpClient.HttpClient, unknown>;
export type GetPromptFileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets the prompt file.
 */
export declare const getPromptFile: API.OperationMethod<GetPromptFileRequest, GetPromptFileResponse, GetPromptFileError, Creds | HttpClient.HttpClient>;
export type GetTaskTemplateError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets details about a specific task template in the specified Connect Customer instance.
 */
export declare const getTaskTemplate: API.OperationMethod<GetTaskTemplateRequest, GetTaskTemplateResponse, GetTaskTemplateError, Creds | HttpClient.HttpClient>;
export type GetTestCaseExecutionSummaryError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves an overview of a test execution that includes the status of the execution, start and end time, and observation summary.
 */
export declare const getTestCaseExecutionSummary: API.OperationMethod<GetTestCaseExecutionSummaryRequest, GetTestCaseExecutionSummaryResponse, GetTestCaseExecutionSummaryError, Creds | HttpClient.HttpClient>;
export type GetTrafficDistributionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current traffic distribution for a given traffic distribution group.
 */
export declare const getTrafficDistribution: API.OperationMethod<GetTrafficDistributionRequest, GetTrafficDistributionResponse, GetTrafficDistributionError, Creds | HttpClient.HttpClient>;
export type ImportPhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Imports a claimed phone number from an external service, such as Amazon Web Services End User Messaging, into an
 * Connect Customer instance. You can call this API only in the same Amazon Web Services Region where the Connect Customer instance was created.
 *
 * Call the DescribePhoneNumber API to verify the status of a previous `ImportPhoneNumber` operation.
 *
 * If you plan to claim or import numbers and then release numbers frequently, contact us for a service quota
 * exception. Otherwise, it is possible you will be blocked from claiming and releasing any more numbers until up to 180
 * days past the oldest number released has expired.
 *
 * By default you can claim or import and then release up to 200% of your maximum number of active phone numbers.
 * If you claim or import and then release phone numbers using the UI or API during a rolling 180 day cycle that exceeds
 * 200% of your phone number service level quota, you will be blocked from claiming or importing any more numbers until
 * 180 days past the oldest number released has expired.
 *
 * For example, if you already have 99 claimed or imported numbers and a service level quota of 99 phone numbers,
 * and in any 180 day period you release 99, claim 99, and then release 99, you will have exceeded the 200% limit. At
 * that point you are blocked from claiming any more numbers until you open an Amazon Web Services Support ticket.
 */
export declare const importPhoneNumber: API.OperationMethod<ImportPhoneNumberRequest, ImportPhoneNumberResponse, ImportPhoneNumberError, Creds | HttpClient.HttpClient>;
export type ImportWorkspaceMediaError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Imports a media asset (such as a logo) for use in a workspace.
 */
export declare const importWorkspaceMedia: API.OperationMethod<ImportWorkspaceMediaRequest, ImportWorkspaceMediaResponse, ImportWorkspaceMediaError, Creds | HttpClient.HttpClient>;
export type ListAgentStatusesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists agent statuses.
 */
export declare const listAgentStatuses: API.PaginatedOperationMethod<ListAgentStatusRequest, ListAgentStatusResponse, ListAgentStatusesError, Creds | HttpClient.HttpClient, AgentStatusSummary>;
export type ListAnalyticsDataAssociationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the association status of requested dataset ID for a given Connect Customer instance.
 */
export declare const listAnalyticsDataAssociations: API.OperationMethod<ListAnalyticsDataAssociationsRequest, ListAnalyticsDataAssociationsResponse, ListAnalyticsDataAssociationsError, Creds | HttpClient.HttpClient>;
export type ListAnalyticsDataLakeDataSetsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the data lake datasets available to associate with for a given Connect Customer instance.
 */
export declare const listAnalyticsDataLakeDataSets: API.OperationMethod<ListAnalyticsDataLakeDataSetsRequest, ListAnalyticsDataLakeDataSetsResponse, ListAnalyticsDataLakeDataSetsError, Creds | HttpClient.HttpClient>;
export type ListApprovedOriginsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all approved origins associated with the instance.
 */
export declare const listApprovedOrigins: API.PaginatedOperationMethod<ListApprovedOriginsRequest, ListApprovedOriginsResponse, ListApprovedOriginsError, Creds | HttpClient.HttpClient, Origin>;
export type ListAssociatedContactsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about contact tree, a list of associated contacts with a unique identifier.
 */
export declare const listAssociatedContacts: API.OperationMethod<ListAssociatedContactsRequest, ListAssociatedContactsResponse, ListAssociatedContactsError, Creds | HttpClient.HttpClient>;
export type ListAttachedFilesConfigurationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the attached files configurations for the specified Connect Customer instance.
 *
 * This API returns effective configurations (custom overrides or defaults) for each attachment scope. If no custom configuration exists for a scope, the default configuration values are returned.
 */
export declare const listAttachedFilesConfigurations: API.PaginatedOperationMethod<ListAttachedFilesConfigurationsRequest, ListAttachedFilesConfigurationsResponse, ListAttachedFilesConfigurationsError, Creds | HttpClient.HttpClient, AttachedFilesConfigurationSummary>;
export type ListAuthenticationProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change. To
 * request access to this API, contact Amazon Web Services Support.
 *
 * Provides summary information about the authentication profiles in a specified Connect Customer
 * instance.
 */
export declare const listAuthenticationProfiles: API.PaginatedOperationMethod<ListAuthenticationProfilesRequest, ListAuthenticationProfilesResponse, ListAuthenticationProfilesError, Creds | HttpClient.HttpClient, AuthenticationProfileSummary>;
export type ListBotsError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * For the specified version of Amazon Lex, returns a paginated list of all the Amazon Lex bots
 * currently associated with the instance. Use this API to return both Amazon Lex V1 and V2
 * bots.
 */
export declare const listBots: API.PaginatedOperationMethod<ListBotsRequest, ListBotsResponse, ListBotsError, Creds | HttpClient.HttpClient, LexBotConfig>;
export type ListChildHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the child hours of operations for the specified parent hours of operation.
 *
 * For more information about child hours of operations, see Link overrides from different hours of operation in the
 * * Administrator Guide*.
 */
export declare const listChildHoursOfOperations: API.PaginatedOperationMethod<ListChildHoursOfOperationsRequest, ListChildHoursOfOperationsResponse, ListChildHoursOfOperationsError, Creds | HttpClient.HttpClient, HoursOfOperationsIdentifier>;
export type ListContactEvaluationsError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists contact evaluations in the specified Connect Customer instance.
 */
export declare const listContactEvaluations: API.PaginatedOperationMethod<ListContactEvaluationsRequest, ListContactEvaluationsResponse, ListContactEvaluationsError, Creds | HttpClient.HttpClient, EvaluationSummary>;
export type ListContactFlowModuleAliasesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all aliases associated with a contact flow module, showing their current version mappings and
 * metadata.
 */
export declare const listContactFlowModuleAliases: API.PaginatedOperationMethod<ListContactFlowModuleAliasesRequest, ListContactFlowModuleAliasesResponse, ListContactFlowModuleAliasesError, Creds | HttpClient.HttpClient, ContactFlowModuleAliasSummary>;
export type ListContactFlowModulesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the flow modules for the specified Connect Customer instance.
 */
export declare const listContactFlowModules: API.PaginatedOperationMethod<ListContactFlowModulesRequest, ListContactFlowModulesResponse, ListContactFlowModulesError, Creds | HttpClient.HttpClient, ContactFlowModuleSummary>;
export type ListContactFlowModuleVersionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of all versions for a specific contact flow module.
 */
export declare const listContactFlowModuleVersions: API.PaginatedOperationMethod<ListContactFlowModuleVersionsRequest, ListContactFlowModuleVersionsResponse, ListContactFlowModuleVersionsError, Creds | HttpClient.HttpClient, ContactFlowModuleVersionSummary>;
export type ListContactFlowsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the flows for the specified Connect Customer instance.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 *
 * For more information about flows, see Flows in the Connect Customer
 * Administrator Guide.
 */
export declare const listContactFlows: API.PaginatedOperationMethod<ListContactFlowsRequest, ListContactFlowsResponse, ListContactFlowsError, Creds | HttpClient.HttpClient, ContactFlowSummary>;
export type ListContactFlowVersionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns all the available versions for the specified Connect Customer instance and flow identifier.
 */
export declare const listContactFlowVersions: API.PaginatedOperationMethod<ListContactFlowVersionsRequest, ListContactFlowVersionsResponse, ListContactFlowVersionsError, Creds | HttpClient.HttpClient, ContactFlowVersionSummary>;
export type ListContactReferencesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * For the specified `referenceTypes`, returns a list of references associated with the contact.
 * *References* are links to documents that are related to a contact, such as emails, attachments,
 * or URLs.
 */
export declare const listContactReferences: API.PaginatedOperationMethod<ListContactReferencesRequest, ListContactReferencesResponse, ListContactReferencesError, Creds | HttpClient.HttpClient, ReferenceSummary>;
export type ListDataTableAttributesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns all attributes for a specified data table. A maximum of 100 attributes per data table is allowed.
 * Customers can request an increase by using Amazon Web Services Service Quotas. The response can be filtered by specific attribute IDs
 * for CloudFormation integration.
 */
export declare const listDataTableAttributes: API.PaginatedOperationMethod<ListDataTableAttributesRequest, ListDataTableAttributesResponse, ListDataTableAttributesError, Creds | HttpClient.HttpClient, DataTableAttribute>;
export type ListDataTablePrimaryValuesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all primary value combinations for a given data table. Returns the unique combinations of primary
 * attribute values that identify records in the table. Up to 100 records are returned per request.
 */
export declare const listDataTablePrimaryValues: API.PaginatedOperationMethod<ListDataTablePrimaryValuesRequest, ListDataTablePrimaryValuesResponse, ListDataTablePrimaryValuesError, Creds | HttpClient.HttpClient, RecordPrimaryValue>;
export type ListDataTablesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all data tables for the specified Amazon Connect instance. Returns summary information for each table
 * including basic metadata and modification details.
 */
export declare const listDataTables: API.PaginatedOperationMethod<ListDataTablesRequest, ListDataTablesResponse, ListDataTablesError, Creds | HttpClient.HttpClient, DataTableSummary>;
export type ListDataTableValuesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists values stored in a data table with optional filtering by record IDs or primary attribute values. Returns
 * the raw stored values along with metadata such as lock versions and modification timestamps.
 */
export declare const listDataTableValues: API.PaginatedOperationMethod<ListDataTableValuesRequest, ListDataTableValuesResponse, ListDataTableValuesError, Creds | HttpClient.HttpClient, DataTableValueSummary>;
export type ListDefaultVocabulariesError = AccessDeniedException | InternalServiceException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists the default vocabularies for the specified Connect Customer instance.
 */
export declare const listDefaultVocabularies: API.PaginatedOperationMethod<ListDefaultVocabulariesRequest, ListDefaultVocabulariesResponse, ListDefaultVocabulariesError, Creds | HttpClient.HttpClient, DefaultVocabulary>;
export type ListEntitySecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all security profiles attached to a Q in Connect AIAgent Entity in an Amazon Connect instance.
 */
export declare const listEntitySecurityProfiles: API.PaginatedOperationMethod<ListEntitySecurityProfilesRequest, ListEntitySecurityProfilesResponse, ListEntitySecurityProfilesError, Creds | HttpClient.HttpClient, SecurityProfileItem>;
export type ListEvaluationFormsError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists evaluation forms in the specified Connect Customer instance.
 */
export declare const listEvaluationForms: API.PaginatedOperationMethod<ListEvaluationFormsRequest, ListEvaluationFormsResponse, ListEvaluationFormsError, Creds | HttpClient.HttpClient, EvaluationFormSummary>;
export type ListEvaluationFormVersionsError = InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists versions of an evaluation form in the specified Connect Customer instance.
 */
export declare const listEvaluationFormVersions: API.PaginatedOperationMethod<ListEvaluationFormVersionsRequest, ListEvaluationFormVersionsResponse, ListEvaluationFormVersionsError, Creds | HttpClient.HttpClient, EvaluationFormVersionSummary>;
export type ListExtractionDefinitionsError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists extraction definitions in the specified Connect Customer instance.
 */
export declare const listExtractionDefinitions: API.PaginatedOperationMethod<ListExtractionDefinitionsRequest, ListExtractionDefinitionsResponse, ListExtractionDefinitionsError, Creds | HttpClient.HttpClient, ExtractionDefinitionSummary>;
export type ListFlowAssociationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List the flow association based on the filters.
 */
export declare const listFlowAssociations: API.PaginatedOperationMethod<ListFlowAssociationsRequest, ListFlowAssociationsResponse, ListFlowAssociationsError, Creds | HttpClient.HttpClient, FlowAssociationSummary>;
export type ListHoursOfOperationOverridesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List the hours of operation overrides.
 */
export declare const listHoursOfOperationOverrides: API.PaginatedOperationMethod<ListHoursOfOperationOverridesRequest, ListHoursOfOperationOverridesResponse, ListHoursOfOperationOverridesError, Creds | HttpClient.HttpClient, HoursOfOperationOverride>;
export type ListHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the hours of operation for the specified Connect Customer instance.
 *
 * For more information about hours of operation, see Set the Hours of Operation for a Queue in the
 * *Connect Customer Administrator Guide*.
 */
export declare const listHoursOfOperations: API.PaginatedOperationMethod<ListHoursOfOperationsRequest, ListHoursOfOperationsResponse, ListHoursOfOperationsError, Creds | HttpClient.HttpClient, HoursOfOperationSummary>;
export type ListInstanceAttributesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all attribute types for the given instance.
 */
export declare const listInstanceAttributes: API.PaginatedOperationMethod<ListInstanceAttributesRequest, ListInstanceAttributesResponse, ListInstanceAttributesError, Creds | HttpClient.HttpClient, Attribute>;
export type ListInstancesError = InternalServiceException | InvalidRequestException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Return a list of instances which are in active state, creation-in-progress state, and failed state. Instances
 * that aren't successfully created (they are in a failed state) are returned only for 24 hours after the CreateInstance
 * API was invoked.
 */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, Creds | HttpClient.HttpClient, InstanceSummary>;
export type ListInstanceStorageConfigsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of storage configs for the identified instance and resource type.
 */
export declare const listInstanceStorageConfigs: API.PaginatedOperationMethod<ListInstanceStorageConfigsRequest, ListInstanceStorageConfigsResponse, ListInstanceStorageConfigsError, Creds | HttpClient.HttpClient, InstanceStorageConfig>;
export type ListIntegrationAssociationsError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the Amazon Web Services resource associations for the specified Connect Customer instance.
 */
export declare const listIntegrationAssociations: API.PaginatedOperationMethod<ListIntegrationAssociationsRequest, ListIntegrationAssociationsResponse, ListIntegrationAssociationsError, Creds | HttpClient.HttpClient, IntegrationAssociationSummary>;
export type ListLambdaFunctionsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all Lambda functions that display in the dropdown options in the relevant flow
 * blocks.
 */
export declare const listLambdaFunctions: API.PaginatedOperationMethod<ListLambdaFunctionsRequest, ListLambdaFunctionsResponse, ListLambdaFunctionsError, Creds | HttpClient.HttpClient, FunctionArn>;
export type ListLexBotsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all the Amazon Lex V1 bots currently associated with the instance. To return
 * both Amazon Lex V1 and V2 bots, use the ListBots API.
 */
export declare const listLexBots: API.PaginatedOperationMethod<ListLexBotsRequest, ListLexBotsResponse, ListLexBotsError, Creds | HttpClient.HttpClient, LexBot>;
export type ListMetricsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of metric summaries for the specified Connect Customer instance. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listMetrics: API.PaginatedOperationMethod<ListMetricsRequest, ListMetricsResponse, ListMetricsError, Creds | HttpClient.HttpClient, MetricSummary>;
export type ListNotificationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of all notifications in the Amazon Connect instance.
 */
export declare const listNotifications: API.OperationMethod<ListNotificationsRequest, ListNotificationsResponse, ListNotificationsError, Creds | HttpClient.HttpClient>;
export type ListPhoneNumbersError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the phone numbers for the specified Connect Customer instance.
 *
 * For more information about phone numbers, see Set Up Phone Numbers for Your Contact
 * Center in the *Connect Customer Administrator Guide*.
 *
 * - We recommend using ListPhoneNumbersV2 to return phone number types. ListPhoneNumbers doesn't support number types
 * `UIFN`, `SHARED`, `THIRD_PARTY_TF`, and `THIRD_PARTY_DID`. While it
 * returns numbers of those types, it incorrectly lists them as `TOLL_FREE` or `DID`.
 *
 * - The phone number `Arn` value that is returned from each of the items in the PhoneNumberSummaryList cannot be used to tag phone number resources. It will fail with a
 * `ResourceNotFoundException`. Instead, use the ListPhoneNumbersV2 API. It returns the new
 * phone number ARN that can be used to tag phone number resources.
 */
export declare const listPhoneNumbers: API.PaginatedOperationMethod<ListPhoneNumbersRequest, ListPhoneNumbersResponse, ListPhoneNumbersError, Creds | HttpClient.HttpClient, PhoneNumberSummary>;
export type ListPhoneNumbersV2Error = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists phone numbers claimed to your Connect Customer instance or traffic distribution group. If the provided `TargetArn`
 * is a traffic distribution group, you can call this API in both Amazon Web Services Regions associated with traffic distribution group.
 *
 * For more information about phone numbers, see Set Up Phone Numbers for Your Contact
 * Center in the *Connect Customer Administrator Guide*.
 *
 * - When given an instance ARN, `ListPhoneNumbersV2` returns only the phone numbers claimed to the
 * instance.
 *
 * - When given a traffic distribution group ARN `ListPhoneNumbersV2` returns only the phone numbers claimed to the
 * traffic distribution group.
 */
export declare const listPhoneNumbersV2: API.PaginatedOperationMethod<ListPhoneNumbersV2Request, ListPhoneNumbersV2Response, ListPhoneNumbersV2Error, Creds | HttpClient.HttpClient, ListPhoneNumbersSummary>;
export type ListPredefinedAttributesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists predefined attributes for the specified Connect Customer instance. A *predefined attribute* is
 * made up of a name and a value. You can use predefined attributes for:
 *
 * - Routing proficiency (for example, agent certification) that has predefined values (for example, a list of
 * possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Contact information that varies between transfers or conferences, such as the name of the business unit
 * handling the contact. For more information, see Use contact segment attributes.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const listPredefinedAttributes: API.PaginatedOperationMethod<ListPredefinedAttributesRequest, ListPredefinedAttributesResponse, ListPredefinedAttributesError, Creds | HttpClient.HttpClient, PredefinedAttributeSummary>;
export type ListPromptsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the prompts for the specified Connect Customer instance.
 */
export declare const listPrompts: API.PaginatedOperationMethod<ListPromptsRequest, ListPromptsResponse, ListPromptsError, Creds | HttpClient.HttpClient, PromptSummary>;
export type ListQueueEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all email addresses that are currently associated with a specific queue, providing details about which "From" email addresses agents can select when handling email contacts. This helps administrators manage agent email address options and understand the available choices for different brands and business units.
 *
 * **Important things to know**
 *
 * - The response includes metadata about each email address available for agent selection, including whether it's configured as the default outbound email.
 *
 * - Agents can select from these email addresses when replying to inbound contacts or initiating outbound contacts in this queue.
 *
 * - The list includes both explicitly associated email addresses and any default outbound email address configured for the queue.
 *
 * - Results are paginated to handle queues with many associated email addresses (up to 50 per queue).
 */
export declare const listQueueEmailAddresses: API.OperationMethod<ListQueueEmailAddressesRequest, ListQueueEmailAddressesResponse, ListQueueEmailAddressesError, Creds | HttpClient.HttpClient>;
export type ListQueueQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the quick connects associated with a queue.
 */
export declare const listQueueQuickConnects: API.PaginatedOperationMethod<ListQueueQuickConnectsRequest, ListQueueQuickConnectsResponse, ListQueueQuickConnectsError, Creds | HttpClient.HttpClient, QuickConnectSummary>;
export type ListQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the queues for the specified Connect Customer instance.
 *
 * If you do not specify a `QueueTypes` parameter, both standard and
 * agent queues are returned. This might cause an unexpected truncation of results if you have more than 1000 agents and
 * you limit the number of results of the API call in code.
 *
 * For more information about queues, see Queues: Standard and Agent in the
 * *Connect Customer Administrator Guide*.
 */
export declare const listQueues: API.PaginatedOperationMethod<ListQueuesRequest, ListQueuesResponse, ListQueuesError, Creds | HttpClient.HttpClient, QueueSummary>;
export type ListQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides information about the quick connects for the specified Connect Customer instance.
 */
export declare const listQuickConnects: API.PaginatedOperationMethod<ListQuickConnectsRequest, ListQuickConnectsResponse, ListQuickConnectsError, Creds | HttpClient.HttpClient, QuickConnectSummary>;
export type ListRealtimeContactAnalysisSegmentsV2Error = AccessDeniedException | InternalServiceException | InvalidRequestException | OutputTypeNotFoundException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a list of analysis segments for a real-time chat analysis session. This API supports CHAT channels
 * only.
 *
 * This API does not support VOICE. If you attempt to use it for VOICE, an `InvalidRequestException`
 * occurs.
 */
export declare const listRealtimeContactAnalysisSegmentsV2: API.PaginatedOperationMethod<ListRealtimeContactAnalysisSegmentsV2Request, ListRealtimeContactAnalysisSegmentsV2Response, ListRealtimeContactAnalysisSegmentsV2Error, Creds | HttpClient.HttpClient, unknown>;
export type ListRoutingProfileManualAssignmentQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the manual assignment queues associated with a routing profile.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - This API returns list of queues where contacts can be manually assigned or picked by an agent who has access
 * to the Worklist app. The user can additionally filter on queues, if they have access to those queues (otherwise a
 * invalid request exception will be thrown).
 *
 * For information about how manual contact assignment works in the agent workspace, see the Access the Worklist app in the Connect Customer agent workspace in the *Connect Customer Administrator Guide*.
 *
 * **Important things to know**
 *
 * - This API only returns the manual assignment queues associated with a routing profile. Use the
 * ListRoutingProfileQueues API to list the auto assignment queues for the routing profile.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const listRoutingProfileManualAssignmentQueues: API.PaginatedOperationMethod<ListRoutingProfileManualAssignmentQueuesRequest, ListRoutingProfileManualAssignmentQueuesResponse, ListRoutingProfileManualAssignmentQueuesError, Creds | HttpClient.HttpClient, RoutingProfileManualAssignmentQueueConfigSummary>;
export type ListRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the queues associated with a routing profile.
 */
export declare const listRoutingProfileQueues: API.PaginatedOperationMethod<ListRoutingProfileQueuesRequest, ListRoutingProfileQueuesResponse, ListRoutingProfileQueuesError, Creds | HttpClient.HttpClient, RoutingProfileQueueConfigSummary>;
export type ListRoutingProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the routing profiles for the specified Connect Customer instance.
 *
 * For more information about routing profiles, see Routing Profiles and Create a Routing Profile in the *Connect Customer Administrator Guide*.
 */
export declare const listRoutingProfiles: API.PaginatedOperationMethod<ListRoutingProfilesRequest, ListRoutingProfilesResponse, ListRoutingProfilesError, Creds | HttpClient.HttpClient, RoutingProfileSummary>;
export type ListRulesError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List all rules for the specified Connect Customer instance.
 */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, Creds | HttpClient.HttpClient, RuleSummary>;
export type ListSecurityKeysError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Returns a paginated list of all security keys associated with the instance.
 */
export declare const listSecurityKeys: API.PaginatedOperationMethod<ListSecurityKeysRequest, ListSecurityKeysResponse, ListSecurityKeysError, Creds | HttpClient.HttpClient, SecurityKey>;
export type ListSecurityProfileApplicationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of third-party applications or MCP Servers in a specific security profile.
 */
export declare const listSecurityProfileApplications: API.PaginatedOperationMethod<ListSecurityProfileApplicationsRequest, ListSecurityProfileApplicationsResponse, ListSecurityProfileApplicationsError, Creds | HttpClient.HttpClient, Application>;
export type ListSecurityProfileFlowModulesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * A list of Flow Modules an AI Agent can invoke as a tool
 */
export declare const listSecurityProfileFlowModules: API.PaginatedOperationMethod<ListSecurityProfileFlowModulesRequest, ListSecurityProfileFlowModulesResponse, ListSecurityProfileFlowModulesError, Creds | HttpClient.HttpClient, FlowModule>;
export type ListSecurityProfilePermissionsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the permissions granted to a security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const listSecurityProfilePermissions: API.PaginatedOperationMethod<ListSecurityProfilePermissionsRequest, ListSecurityProfilePermissionsResponse, ListSecurityProfilePermissionsError, Creds | HttpClient.HttpClient, SecurityProfilePermission>;
export type ListSecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the security profiles for the specified Connect Customer instance.
 *
 * For more information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const listSecurityProfiles: API.PaginatedOperationMethod<ListSecurityProfilesRequest, ListSecurityProfilesResponse, ListSecurityProfilesError, Creds | HttpClient.HttpClient, SecurityProfileSummary>;
export type ListTagsForResourceError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 *
 * For sample policies that use tags, see Connect Customer Identity-Based Policy
 * Examples in the *Connect Customer Administrator Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Creds | HttpClient.HttpClient>;
export type ListTaskTemplatesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists task templates for the specified Connect Customer instance.
 */
export declare const listTaskTemplates: API.PaginatedOperationMethod<ListTaskTemplatesRequest, ListTaskTemplatesResponse, ListTaskTemplatesError, Creds | HttpClient.HttpClient, TaskTemplateMetadata>;
export type ListTestCaseExecutionRecordsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists detailed steps of test case execution that includes all observations along with actions taken and data associated in the specified Amazon Connect instance.
 */
export declare const listTestCaseExecutionRecords: API.OperationMethod<ListTestCaseExecutionRecordsRequest, ListTestCaseExecutionRecordsResponse, ListTestCaseExecutionRecordsError, Creds | HttpClient.HttpClient>;
export type ListTestCaseExecutionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all test case executions and allows filtering by test case id, test case name, start time, end time or status of the execution for the specified Amazon Connect instance.
 */
export declare const listTestCaseExecutions: API.OperationMethod<ListTestCaseExecutionsRequest, ListTestCaseExecutionsResponse, ListTestCaseExecutionsError, Creds | HttpClient.HttpClient>;
export type ListTestCasesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the test cases present in the specific Amazon Connect instance.
 */
export declare const listTestCases: API.PaginatedOperationMethod<ListTestCasesRequest, ListTestCasesResponse, ListTestCasesError, Creds | HttpClient.HttpClient, TestCaseSummary>;
export type ListTrafficDistributionGroupsError = AccessDeniedException | InternalServiceException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists traffic distribution groups.
 */
export declare const listTrafficDistributionGroups: API.PaginatedOperationMethod<ListTrafficDistributionGroupsRequest, ListTrafficDistributionGroupsResponse, ListTrafficDistributionGroupsError, Creds | HttpClient.HttpClient, TrafficDistributionGroupSummary>;
export type ListTrafficDistributionGroupUsersError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists traffic distribution group users.
 */
export declare const listTrafficDistributionGroupUsers: API.PaginatedOperationMethod<ListTrafficDistributionGroupUsersRequest, ListTrafficDistributionGroupUsersResponse, ListTrafficDistributionGroupUsersError, Creds | HttpClient.HttpClient, TrafficDistributionGroupUserSummary>;
export type ListUseCasesError = InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the use cases for the integration association.
 */
export declare const listUseCases: API.PaginatedOperationMethod<ListUseCasesRequest, ListUseCasesResponse, ListUseCasesError, Creds | HttpClient.HttpClient, UseCase>;
export type ListUserHierarchyGroupsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the hierarchy groups for the specified Connect Customer instance.
 *
 * For more information about agent hierarchies, see Set Up Agent Hierarchies in the *Connect Customer Administrator Guide*.
 */
export declare const listUserHierarchyGroups: API.PaginatedOperationMethod<ListUserHierarchyGroupsRequest, ListUserHierarchyGroupsResponse, ListUserHierarchyGroupsError, Creds | HttpClient.HttpClient, HierarchyGroupSummary>;
export type ListUserNotificationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves a paginated list of notifications for a specific user, including the notification status for that user.
 */
export declare const listUserNotifications: API.OperationMethod<ListUserNotificationsRequest, ListUserNotificationsResponse, ListUserNotificationsError, Creds | HttpClient.HttpClient>;
export type ListUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists proficiencies associated with a user.
 */
export declare const listUserProficiencies: API.PaginatedOperationMethod<ListUserProficienciesRequest, ListUserProficienciesResponse, ListUserProficienciesError, Creds | HttpClient.HttpClient, UserProficiency>;
export type ListUsersError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides summary information about the users for the specified Connect Customer instance.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Creds | HttpClient.HttpClient, UserSummary>;
export type ListViewsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns views in the given instance.
 *
 * Results are sorted primarily by type, and secondarily by name.
 */
export declare const listViews: API.PaginatedOperationMethod<ListViewsRequest, ListViewsResponse, ListViewsError, Creds | HttpClient.HttpClient, ViewSummary>;
export type ListViewVersionsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns all the available versions for the specified Connect Customer instance and view identifier.
 *
 * Results will be sorted from highest to lowest.
 */
export declare const listViewVersions: API.PaginatedOperationMethod<ListViewVersionsRequest, ListViewVersionsResponse, ListViewVersionsError, Creds | HttpClient.HttpClient, ViewVersionSummary>;
export type ListWorkspaceMediaError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists media assets (such as logos) associated with a workspace.
 */
export declare const listWorkspaceMedia: API.OperationMethod<ListWorkspaceMediaRequest, ListWorkspaceMediaResponse, ListWorkspaceMediaError, Creds | HttpClient.HttpClient>;
export type ListWorkspacePagesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the page configurations in a workspace, including the views assigned to each page.
 */
export declare const listWorkspacePages: API.PaginatedOperationMethod<ListWorkspacePagesRequest, ListWorkspacePagesResponse, ListWorkspacePagesError, Creds | HttpClient.HttpClient, WorkspacePage>;
export type ListWorkspacesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the workspaces in an Amazon Connect instance.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest, ListWorkspacesResponse, ListWorkspacesError, Creds | HttpClient.HttpClient, WorkspaceSummary>;
export type MonitorContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Initiates silent monitoring of a contact. The Contact Control Panel (CCP) of the user specified by
 * *userId* will be set to silent monitoring mode on the contact.
 */
export declare const monitorContact: API.OperationMethod<MonitorContactRequest, MonitorContactResponse, MonitorContactError, Creds | HttpClient.HttpClient>;
export type PauseContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows pausing an ongoing task contact.
 */
export declare const pauseContact: API.OperationMethod<PauseContactRequest, PauseContactResponse, PauseContactError, Creds | HttpClient.HttpClient>;
export type PutUserStatusError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Changes the current status of a user or agent in Connect Customer. If the agent is currently handling a
 * contact, this sets the agent's next status.
 *
 * For more information, see Agent status and Set your
 * next status in the *Connect Customer Administrator Guide*.
 */
export declare const putUserStatus: API.OperationMethod<PutUserStatusRequest, PutUserStatusResponse, PutUserStatusError, Creds | HttpClient.HttpClient>;
export type ReleasePhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Releases a phone number previously claimed to an Connect Customer instance or traffic distribution group. You can call this API
 * only in the Amazon Web Services Region where the number was claimed.
 *
 * To release phone numbers from a traffic distribution group, use the `ReleasePhoneNumber` API, not the Connect Customer admin website.
 *
 * After releasing a phone number, the phone number enters into a cooldown period for up to 180 days. It cannot be
 * searched for or claimed again until the period has ended. If you accidentally release a phone number, contact
 * Amazon Web Services Support.
 *
 * If you plan to claim and release numbers frequently,
 * contact us for a service quota exception. Otherwise, it is possible you will be blocked from
 * claiming and releasing any more numbers until up to 180 days past the oldest number
 * released has expired.
 *
 * By default you can claim and release up to 200% of your maximum number of active
 * phone numbers. If you claim and release phone numbers using
 * the UI or API during a rolling 180 day cycle that exceeds 200% of your phone number
 * service level quota, you will be blocked from claiming any more numbers until 180
 * days past the oldest number released has expired.
 *
 * For example, if you already have 99 claimed numbers and a service level quota of 99 phone numbers, and in any 180
 * day period you release 99, claim 99, and then release 99, you will have exceeded the
 * 200% limit. At that point you are blocked from claiming any more numbers until you
 * open an Amazon Web Services support ticket.
 */
export declare const releasePhoneNumber: API.OperationMethod<ReleasePhoneNumberRequest, ReleasePhoneNumberResponse, ReleasePhoneNumberError, Creds | HttpClient.HttpClient>;
export type ReplicateInstanceError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ResourceNotReadyException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Replicates an Connect Customer instance in the specified Amazon Web Services Region and copies configuration
 * information for Connect Customer resources across Amazon Web Services Regions.
 *
 * For more information about replicating an Connect Customer instance, see Create a replica of your existing Connect Customer
 * instance in the *Connect Customer Administrator Guide*.
 */
export declare const replicateInstance: API.OperationMethod<ReplicateInstanceRequest, ReplicateInstanceResponse, ReplicateInstanceError, Creds | HttpClient.HttpClient>;
export type ResumeContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Allows resuming a task contact in a paused state.
 */
export declare const resumeContact: API.OperationMethod<ResumeContactRequest, ResumeContactResponse, ResumeContactError, Creds | HttpClient.HttpClient>;
export type ResumeContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * When a contact is being recorded, and the recording has been suspended using SuspendContactRecording, this API
 * resumes recording whatever recording is selected in the flow configuration: call, screen, or both. If only call
 * recording or only screen recording is enabled, then it would resume.
 *
 * Voice and screen recordings are supported.
 */
export declare const resumeContactRecording: API.OperationMethod<ResumeContactRecordingRequest, ResumeContactRecordingResponse, ResumeContactRecordingError, Creds | HttpClient.HttpClient>;
export type SearchAgentStatusesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches AgentStatuses in an Connect Customer instance, with optional filtering.
 */
export declare const searchAgentStatuses: API.PaginatedOperationMethod<SearchAgentStatusesRequest, SearchAgentStatusesResponse, SearchAgentStatusesError, Creds | HttpClient.HttpClient, AgentStatus>;
export type SearchAvailablePhoneNumbersError = AccessDeniedException | InternalServiceException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Searches for available phone numbers that you can claim to your Connect Customer instance or traffic distribution group. If the
 * provided `TargetArn` is a traffic distribution group, you can call this API in both Amazon Web Services Regions associated with
 * the traffic distribution group.
 */
export declare const searchAvailablePhoneNumbers: API.PaginatedOperationMethod<SearchAvailablePhoneNumbersRequest, SearchAvailablePhoneNumbersResponse, SearchAvailablePhoneNumbersError, Creds | HttpClient.HttpClient, AvailableNumberSummary>;
export type SearchContactEvaluationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches contact evaluations in an Connect Customer instance, with optional filtering.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Find contact evaluations by using specific search criteria.
 *
 * - Find contact evaluations that are tagged with a specific set of tags.
 *
 * **Important things to know**
 *
 * - A Search operation, unlike a List operation, takes time to index changes to resource (create, update or
 * delete). If you don't see updated information for recently changed contact evaluations, try calling the API again
 * in a few seconds.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const searchContactEvaluations: API.OperationMethod<SearchContactEvaluationsRequest, SearchContactEvaluationsResponse, SearchContactEvaluationsError, Creds | HttpClient.HttpClient>;
export type SearchContactFlowModulesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the flow modules in an Connect Customer instance, with optional filtering.
 */
export declare const searchContactFlowModules: API.PaginatedOperationMethod<SearchContactFlowModulesRequest, SearchContactFlowModulesResponse, SearchContactFlowModulesError, Creds | HttpClient.HttpClient, ContactFlowModule>;
export type SearchContactFlowsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the flows in an Connect Customer instance, with optional filtering.
 */
export declare const searchContactFlows: API.PaginatedOperationMethod<SearchContactFlowsRequest, SearchContactFlowsResponse, SearchContactFlowsError, Creds | HttpClient.HttpClient, ContactFlow>;
export type SearchContactsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches contacts in an Connect Customer instance.
 */
export declare const searchContacts: API.PaginatedOperationMethod<SearchContactsRequest, SearchContactsResponse, SearchContactsError, Creds | HttpClient.HttpClient, ContactSearchSummary>;
export type SearchDataTablesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for data tables based on the table's ID, name, and description. In the future, this operation can
 * support searching on attribute names and possibly primary values. Follows other search operations closely and
 * supports both search criteria and filters.
 */
export declare const searchDataTables: API.PaginatedOperationMethod<SearchDataTablesRequest, SearchDataTablesResponse, SearchDataTablesError, Creds | HttpClient.HttpClient, DataTable>;
export type SearchEmailAddressesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches email address in an instance, with optional filtering.
 */
export declare const searchEmailAddresses: API.OperationMethod<SearchEmailAddressesRequest, SearchEmailAddressesResponse, SearchEmailAddressesError, Creds | HttpClient.HttpClient>;
export type SearchEvaluationFormsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches evaluation forms in an Connect Customer instance, with optional filtering.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - List all evaluation forms in an instance.
 *
 * - Find all evaluation forms that meet specific criteria, such as Title, Description, Status, and more.
 *
 * - Find all evaluation forms that are tagged with a specific set of tags.
 *
 * **Important things to know**
 *
 * - A Search operation, unlike a List operation, takes time to index changes to resource (create, update or
 * delete). If you don't see updated information for recently changed contact evaluations, try calling the API again
 * in a few seconds.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const searchEvaluationForms: API.OperationMethod<SearchEvaluationFormsRequest, SearchEvaluationFormsResponse, SearchEvaluationFormsError, Creds | HttpClient.HttpClient>;
export type SearchHoursOfOperationOverridesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the hours of operation overrides.
 */
export declare const searchHoursOfOperationOverrides: API.PaginatedOperationMethod<SearchHoursOfOperationOverridesRequest, SearchHoursOfOperationOverridesResponse, SearchHoursOfOperationOverridesError, Creds | HttpClient.HttpClient, HoursOfOperationOverride>;
export type SearchHoursOfOperationsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches the hours of operation in an Connect Customer instance, with optional filtering.
 */
export declare const searchHoursOfOperations: API.PaginatedOperationMethod<SearchHoursOfOperationsRequest, SearchHoursOfOperationsResponse, SearchHoursOfOperationsError, Creds | HttpClient.HttpClient, HoursOfOperation>;
export type SearchMetricsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for metrics in the specified Connect Customer instance using search criteria and optional tag-based filters. Use pagination to ensure that the operation returns quickly and successfully.
 */
export declare const searchMetrics: API.PaginatedOperationMethod<SearchMetricsRequest, SearchMetricsResponse, SearchMetricsError, Creds | HttpClient.HttpClient, MetricDefinition>;
export type SearchNotificationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for notifications based on specified criteria and filters. Returns a paginated list of notifications matching the search parameters, ordered by descending creation time. Supports filtering by content and tags.
 */
export declare const searchNotifications: API.OperationMethod<SearchNotificationsRequest, SearchNotificationsResponse, SearchNotificationsError, Creds | HttpClient.HttpClient>;
export type SearchPredefinedAttributesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches predefined attributes that meet certain criteria. A *predefined attribute* is made
 * up of a name and a value. You can use predefined attributes for:
 *
 * - Routing proficiency (for example, agent certification) that has predefined values (for example, a list of
 * possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Contact information that varies between transfers or conferences, such as the name of the business unit
 * handling the contact. For more information, see Use contact segment attributes.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const searchPredefinedAttributes: API.PaginatedOperationMethod<SearchPredefinedAttributesRequest, SearchPredefinedAttributesResponse, SearchPredefinedAttributesError, Creds | HttpClient.HttpClient, PredefinedAttribute>;
export type SearchPromptsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches prompts in an Connect Customer instance, with optional filtering.
 */
export declare const searchPrompts: API.PaginatedOperationMethod<SearchPromptsRequest, SearchPromptsResponse, SearchPromptsError, Creds | HttpClient.HttpClient, Prompt>;
export type SearchQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches queues in an Connect Customer instance, with optional filtering.
 */
export declare const searchQueues: API.PaginatedOperationMethod<SearchQueuesRequest, SearchQueuesResponse, SearchQueuesError, Creds | HttpClient.HttpClient, Queue>;
export type SearchQuickConnectsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches quick connects in an Connect Customer instance, with optional filtering.
 */
export declare const searchQuickConnects: API.PaginatedOperationMethod<SearchQuickConnectsRequest, SearchQuickConnectsResponse, SearchQuickConnectsError, Creds | HttpClient.HttpClient, QuickConnect>;
export type SearchResourceTagsError = InternalServiceException | InvalidParameterException | InvalidRequestException | MaximumResultReturnedException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches tags used in an Connect Customer instance using optional search criteria.
 */
export declare const searchResourceTags: API.PaginatedOperationMethod<SearchResourceTagsRequest, SearchResourceTagsResponse, SearchResourceTagsError, Creds | HttpClient.HttpClient, TagSet>;
export type SearchRoutingProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches routing profiles in an Connect Customer instance, with optional filtering.
 *
 * `SearchRoutingProfiles` does not populate LastModifiedRegion, LastModifiedTime,
 * MediaConcurrencies.CrossChannelBehavior, and AgentAvailabilityTimer in its response, but DescribeRoutingProfile does.
 */
export declare const searchRoutingProfiles: API.PaginatedOperationMethod<SearchRoutingProfilesRequest, SearchRoutingProfilesResponse, SearchRoutingProfilesError, Creds | HttpClient.HttpClient, RoutingProfile>;
export type SearchRulesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches rules in an Connect Customer instance, with optional filtering.
 */
export declare const searchRules: API.PaginatedOperationMethod<SearchRulesRequest, SearchRulesResponse, SearchRulesError, Creds | HttpClient.HttpClient, RuleSearchSummary>;
export type SearchSecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches security profiles in an Connect Customer instance, with optional filtering.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const searchSecurityProfiles: API.PaginatedOperationMethod<SearchSecurityProfilesRequest, SearchSecurityProfilesResponse, SearchSecurityProfilesError, Creds | HttpClient.HttpClient, SecurityProfileSearchSummary>;
export type SearchTestCasesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for test cases in the specified Amazon Connect instance, with optional filtering.
 */
export declare const searchTestCases: API.PaginatedOperationMethod<SearchTestCasesRequest, SearchTestCasesResponse, SearchTestCasesError, Creds | HttpClient.HttpClient, TestCase>;
export type SearchUserHierarchyGroupsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches UserHierarchyGroups in an Connect Customer instance, with optional filtering.
 *
 * The UserHierarchyGroup with `"LevelId": "0"` is the foundation for building levels on top of an
 * instance. It is not user-definable, nor is it visible in the UI.
 */
export declare const searchUserHierarchyGroups: API.PaginatedOperationMethod<SearchUserHierarchyGroupsRequest, SearchUserHierarchyGroupsResponse, SearchUserHierarchyGroupsError, Creds | HttpClient.HttpClient, HierarchyGroup>;
export type SearchUsersError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches users in an Connect Customer instance, with optional filtering.
 *
 * `AfterContactWorkTimeLimit` is returned in milliseconds.
 */
export declare const searchUsers: API.PaginatedOperationMethod<SearchUsersRequest, SearchUsersResponse, SearchUsersError, Creds | HttpClient.HttpClient, UserSearchSummary>;
export type SearchViewsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches views based on name, description, or tags.
 */
export declare const searchViews: API.PaginatedOperationMethod<SearchViewsRequest, SearchViewsResponse, SearchViewsError, Creds | HttpClient.HttpClient, View>;
export type SearchVocabulariesError = AccessDeniedException | InternalServiceException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Searches for vocabularies within a specific Connect Customer instance using `State`,
 * `NameStartsWith`, and `LanguageCode`.
 */
export declare const searchVocabularies: API.PaginatedOperationMethod<SearchVocabulariesRequest, SearchVocabulariesResponse, SearchVocabulariesError, Creds | HttpClient.HttpClient, VocabularySummary>;
export type SearchWorkspaceAssociationsError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for workspace associations with users or routing profiles based on various criteria.
 */
export declare const searchWorkspaceAssociations: API.PaginatedOperationMethod<SearchWorkspaceAssociationsRequest, SearchWorkspaceAssociationsResponse, SearchWorkspaceAssociationsError, Creds | HttpClient.HttpClient, WorkspaceAssociationSearchSummary>;
export type SearchWorkspacesError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches workspaces based on name, description, visibility, or tags.
 */
export declare const searchWorkspaces: API.PaginatedOperationMethod<SearchWorkspacesRequest, SearchWorkspacesResponse, SearchWorkspacesError, Creds | HttpClient.HttpClient, WorkspaceSearchSummary>;
export type SendChatIntegrationEventError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Processes chat integration events from Amazon Web Services or external integrations to Connect Customer. A chat
 * integration event includes:
 *
 * - SourceId, DestinationId, and Subtype: a set of identifiers, uniquely representing a chat
 *
 * - ChatEvent: details of the chat action to perform such as sending a message, event, or disconnecting from a
 * chat
 *
 * When a chat integration event is sent with chat identifiers that do not map to an active chat contact, a new
 * chat contact is also created before handling chat action.
 *
 * Access to this API is currently restricted to Amazon Web Services End User Messaging for supporting SMS
 * integration.
 */
export declare const sendChatIntegrationEvent: API.OperationMethod<SendChatIntegrationEventRequest, SendChatIntegrationEventResponse, SendChatIntegrationEventError, Creds | HttpClient.HttpClient>;
export type SendOutboundEmailError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Send outbound email for outbound campaigns. For more information about outbound campaigns, see Set up Connect Customer
 * outbound campaigns.
 *
 * Only the Connect Customer outbound campaigns service principal is allowed to assume a role in your account
 * and call this API.
 */
export declare const sendOutboundEmail: API.OperationMethod<SendOutboundEmailRequest, SendOutboundEmailResponse, SendOutboundEmailError, Creds | HttpClient.HttpClient>;
export type SendOutboundWebNotificationError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Sends an outbound web notification to a customer's web browser for outbound campaigns. For more information
 * about outbound campaigns, see Set up Connect Customer outbound
 * campaigns.
 *
 * Only the Connect Customer outbound campaigns service principal is allowed to assume a role in your account
 * and call this API.
 */
export declare const sendOutboundWebNotification: API.OperationMethod<SendOutboundWebNotificationRequest, SendOutboundWebNotificationResponse, SendOutboundWebNotificationError, Creds | HttpClient.HttpClient>;
export type StartAssistantContactError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts a chat contact with an AI agent.
 *
 * Use the returned `ParticipantToken` with the CreateParticipantConnection operation.
 *
 * For more information about chat, see the following topics in the Connect Customer
 * Administrator Guide:
 *
 * - Concepts: Web and mobile messaging capabilities in Connect Customer
 *
 * - Connect Customer Chat security best practices
 */
export declare const startAssistantContact: API.OperationMethod<StartAssistantContactRequest, StartAssistantContactResponse, StartAssistantContactError, Creds | HttpClient.HttpClient>;
export type StartAttachedFileUploadError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Provides a pre-signed Amazon S3 URL in response for uploading your content.
 *
 * You may only use this API to upload attachments to a Connect Customer Case, Connect Customer Email, or
 * Connect Customer Task.
 */
export declare const startAttachedFileUpload: API.OperationMethod<StartAttachedFileUploadRequest, StartAttachedFileUploadResponse, StartAttachedFileUploadError, Creds | HttpClient.HttpClient>;
export type StartChatContactError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Initiates a flow to start a new chat for the customer. Response of this API provides a token required to obtain
 * credentials from the CreateParticipantConnection API in the Connect Customer Participant Service.
 *
 * When a new chat contact is successfully created, clients must subscribe to the participant’s connection for the
 * created chat within 5 minutes. This is achieved by invoking CreateParticipantConnection with WEBSOCKET and CONNECTION_CREDENTIALS.
 *
 * A 429 error occurs in the following situations:
 *
 * - API rate limit is exceeded. API TPS throttling returns a `TooManyRequests` exception.
 *
 * - The quota for
 * concurrent active chats is exceeded. Active chat throttling returns a
 * `LimitExceededException`.
 *
 * If you use the `ChatDurationInMinutes` parameter and receive a 400 error, your account may not
 * support the ability to configure custom chat durations. For more information, contact Amazon Web Services Support.
 *
 * For more information about chat, see the following topics in the Connect Customer
 * Administrator Guide:
 *
 * - Concepts: Web and mobile messaging capabilities in Connect Customer
 *
 * - Connect Customer Chat security best practices
 */
export declare const startChatContact: API.OperationMethod<StartChatContactRequest, StartChatContactResponse, StartChatContactError, Creds | HttpClient.HttpClient>;
export type StartContactConversationalAnalyticsJobError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts a Contact Lens post-call analytics job for the specified contact. This API runs Conversational
 * Analytics post-contact analysis on a voice recording that is already attached to the contact, generating
 * transcription, sentiment analysis, redaction, and summarization results based on the provided configuration.
 *
 * A voice recording must already be attached to the contact before calling this API. Use
 * `CreateAttachedFile` to attach a recording from an S3 source URI.
 *
 * For example, you can call `CreateContact`, then `CreateAttachedFile`, then
 * `StartContactConversationalAnalyticsJob` to create a contact, attach a recording, and
 * run post-call analytics.
 */
export declare const startContactConversationalAnalyticsJob: API.OperationMethod<StartContactConversationalAnalyticsJobRequest, StartContactConversationalAnalyticsJobResponse, StartContactConversationalAnalyticsJobError, Creds | HttpClient.HttpClient>;
export type StartContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts an empty evaluation in the specified Connect Customer instance, using the given evaluation form for the
 * particular contact. The evaluation form version used for the contact evaluation corresponds to the currently
 * activated version. If no version is activated for the evaluation form, the contact evaluation cannot be started.
 *
 * Evaluations created through the public API do not contain answer values suggested from automation.
 */
export declare const startContactEvaluation: API.OperationMethod<StartContactEvaluationRequest, StartContactEvaluationResponse, StartContactEvaluationError, Creds | HttpClient.HttpClient>;
export type StartContactMediaProcessingError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Enables in-flight message processing for an ongoing chat session. Message processing will stay active for the
 * rest of the chat, even if an individual contact segment ends.
 */
export declare const startContactMediaProcessing: API.OperationMethod<StartContactMediaProcessingRequest, StartContactMediaProcessingResponse, StartContactMediaProcessingError, Creds | HttpClient.HttpClient>;
export type StartContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Starts recording the contact:
 *
 * - If the API is called *before* the agent joins the call, recording starts when the agent
 * joins the call.
 *
 * - If the API is called *after* the agent joins the call, recording starts at the time of the
 * API call.
 *
 * StartContactRecording is a one-time action. For example, if you use StopContactRecording to stop recording an
 * ongoing call, you can't use StartContactRecording to restart it. For scenarios where the recording has started and
 * you want to suspend and resume it, such as when collecting sensitive information (for example, a credit card number),
 * use SuspendContactRecording and ResumeContactRecording.
 *
 * You can use this API to override the recording behavior configured in the Set recording behavior block.
 *
 * Only voice recordings are supported at this time.
 */
export declare const startContactRecording: API.OperationMethod<StartContactRecordingRequest, StartContactRecordingResponse, StartContactRecordingError, Creds | HttpClient.HttpClient>;
export type StartContactStreamingError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Initiates real-time message streaming for a new chat contact.
 *
 * For more information about message streaming, see Enable real-time chat message streaming in the
 * *Connect Customer Administrator Guide*.
 *
 * For more information about chat, see the following topics in the Connect Customer
 * Administrator Guide:
 *
 * - Concepts: Web and mobile messaging capabilities in Connect Customer
 *
 * - Connect Customer Chat security best practices
 */
export declare const startContactStreaming: API.OperationMethod<StartContactStreamingRequest, StartContactStreamingResponse, StartContactStreamingError, Creds | HttpClient.HttpClient>;
export type StartEmailContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an inbound email contact and initiates a flow to start the email contact for the customer. Response of
 * this API provides the ContactId of the email contact created.
 */
export declare const startEmailContact: API.OperationMethod<StartEmailContactRequest, StartEmailContactResponse, StartEmailContactError, Creds | HttpClient.HttpClient>;
export type StartEvaluationFormValidationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts an asynchronous validation process for an evaluation form version in the specified Connect Customer
 * instance. The validation first performs structural checks on the form content (such as verifying required fields,
 * valid scoring configuration, and correct conditional logic), then asynchronously analyzes questions configured for
 * generative AI evaluation against a set of best practices. Use GetEvaluationFormValidation to
 * retrieve the status and results once the validation completes.
 */
export declare const startEvaluationFormValidation: API.OperationMethod<StartEvaluationFormValidationRequest, StartEvaluationFormValidationResponse, StartEvaluationFormValidationError, Creds | HttpClient.HttpClient>;
export type StartOutboundChatContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Initiates a new outbound SMS or WhatsApp contact to a customer. Response of this API provides the
 * `ContactId` of the outbound SMS or WhatsApp contact created.
 *
 * **SourceEndpoint** only supports Endpoints with
 * `CONNECT_PHONENUMBER_ARN` as Type and **DestinationEndpoint** only supports
 * Endpoints with `TELEPHONE_NUMBER` as Type. **ContactFlowId** initiates the
 * flow to manage the new contact created.
 *
 * This API can be used to initiate outbound SMS or WhatsApp contacts for an agent, or it can also deflect
 * an ongoing contact to an outbound SMS or WhatsApp contact by using the StartOutboundChatContact Flow
 * Action.
 *
 * For more information about using SMS or WhatsApp in Connect Customer, see the following topics in
 * the *Connect Customer Administrator Guide*:
 *
 * - Set up SMS
 * messaging
 *
 * - Request an SMS-enabled phone
 * number through Amazon Web Services End User Messaging SMS
 *
 * - Set up WhatsApp
 * Business messaging
 */
export declare const startOutboundChatContact: API.OperationMethod<StartOutboundChatContactRequest, StartOutboundChatContactResponse, StartOutboundChatContactError, Creds | HttpClient.HttpClient>;
export type StartOutboundEmailContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Initiates a flow to send an agent reply or outbound email contact (created from the CreateContact API) to a
 * customer.
 */
export declare const startOutboundEmailContact: API.OperationMethod<StartOutboundEmailContactRequest, StartOutboundEmailContactResponse, StartOutboundEmailContactError, Creds | HttpClient.HttpClient>;
export type StartOutboundVoiceContactError = DestinationNotAllowedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | OutboundContactNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Places an outbound call to a contact, and then initiates the flow. It performs the actions in the flow that's
 * specified (in `ContactFlowId`).
 *
 * Agents do not initiate the outbound API, which means that they do not dial the contact. If the flow places an
 * outbound call to a contact, and then puts the contact in queue, the call is then routed to the agent, like any other
 * inbound case.
 *
 * Dialing timeout for this operation can be configured with the “RingTimeoutInSeconds” parameter. If not
 * specified, the default dialing timeout will be 60 seconds which means if the call is not connected within 60 seconds,
 * it fails.
 *
 * UK numbers with a 447 prefix are not allowed by default. Before you can dial these UK mobile numbers, you must
 * submit a service quota increase request. For more information, see Connect Customer Service Quotas in the
 * *Connect Customer Administrator Guide*.
 *
 * Campaign calls are not allowed by default. Before you can make a call with `TrafficType` =
 * `CAMPAIGN`, you must submit a service quota increase request to the quota Connect Customer campaigns.
 *
 * For Preview dialing mode, only the Amazon Connect outbound campaigns service principal is allowed to assume a
 * role in your account and call this API with OutboundStrategy.
 */
export declare const startOutboundVoiceContact: API.OperationMethod<StartOutboundVoiceContactRequest, StartOutboundVoiceContactResponse, StartOutboundVoiceContactError, Creds | HttpClient.HttpClient>;
export type StartScreenSharingError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts screen sharing for a contact. For more information about screen sharing, see Set up in-app, web, video calling, and screen sharing
 * capabilities in the *Connect Customer Administrator Guide*.
 */
export declare const startScreenSharing: API.OperationMethod<StartScreenSharingRequest, StartScreenSharingResponse, StartScreenSharingError, Creds | HttpClient.HttpClient>;
export type StartTaskContactError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Initiates a flow to start a new task contact. For more information about task contacts, see Concepts: Tasks in Connect Customer in the
 * *Connect Customer Administrator Guide*.
 *
 * When using `PreviousContactId` and `RelatedContactId` input parameters, note the
 * following:
 *
 * - `PreviousContactId`
 *
 * - Any updates to user-defined task contact attributes on any contact linked through the same
 * `PreviousContactId` will affect every contact in the chain.
 *
 * - There can be a maximum of 12 linked task contacts in a chain. That is, 12 task contacts can be created that
 * share the same `PreviousContactId`.
 *
 * - `RelatedContactId`
 *
 * - Copies contact attributes from the related task contact to the new contact.
 *
 * - Any update on attributes in a new task contact does not update attributes on previous contact.
 *
 * - There’s no limit on the number of task contacts that can be created that use the same
 * `RelatedContactId`.
 *
 * In addition, when calling StartTaskContact include only one of these parameters: `ContactFlowID`,
 * `QuickConnectID`, or `TaskTemplateID`. Only one parameter is required as long as the task
 * template has a flow configured to run it. If more than one parameter is specified, or only the
 * `TaskTemplateID` is specified but it does not have a flow configured, the request returns an error
 * because Connect Customer cannot identify the unique flow to run when the task is created.
 *
 * A `ServiceQuotaExceededException` occurs when the number of open tasks exceeds the active tasks quota
 * or there are already 12 tasks referencing the same `PreviousContactId`. For more information about service
 * quotas for task contacts, see Connect Customer service quotas in the
 * *Connect Customer Administrator Guide*.
 */
export declare const startTaskContact: API.OperationMethod<StartTaskContactRequest, StartTaskContactResponse, StartTaskContactError, Creds | HttpClient.HttpClient>;
export type StartTestCaseExecutionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Starts executing a published test case.
 */
export declare const startTestCaseExecution: API.OperationMethod<StartTestCaseExecutionRequest, StartTestCaseExecutionResponse, StartTestCaseExecutionError, Creds | HttpClient.HttpClient>;
export type StartWebRTCContactError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Places an inbound in-app, web, or video call to a contact, and then initiates the flow. It performs the actions
 * in the flow that are specified (in ContactFlowId) and present in the Connect Customer instance (specified as
 * InstanceId).
 */
export declare const startWebRTCContact: API.OperationMethod<StartWebRTCContactRequest, StartWebRTCContactResponse, StartWebRTCContactError, Creds | HttpClient.HttpClient>;
export type StopContactError = ContactNotFoundException | InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Ends the specified contact. Use this API to stop queued callbacks. It does not work for voice contacts that use
 * the following initiation methods:
 *
 * - DISCONNECT
 *
 * - TRANSFER
 *
 * - QUEUE_TRANSFER
 *
 * - EXTERNAL_OUTBOUND
 *
 * - MONITOR
 *
 * Chat and task contacts can be terminated in any state, regardless of initiation method.
 */
export declare const stopContact: API.OperationMethod<StopContactRequest, StopContactResponse, StopContactError, Creds | HttpClient.HttpClient>;
export type StopContactMediaProcessingError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Stops in-flight message processing for an ongoing chat session.
 */
export declare const stopContactMediaProcessing: API.OperationMethod<StopContactMediaProcessingRequest, StopContactMediaProcessingResponse, StopContactMediaProcessingError, Creds | HttpClient.HttpClient>;
export type StopContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops recording a call when a contact is being recorded. StopContactRecording is a one-time action. If you use
 * StopContactRecording to stop recording an ongoing call, you can't use StartContactRecording to restart it. For
 * scenarios where the recording has started and you want to suspend it for sensitive information (for example, to
 * collect a credit card number), and then restart it, use SuspendContactRecording and ResumeContactRecording.
 *
 * Only voice recordings are supported at this time.
 */
export declare const stopContactRecording: API.OperationMethod<StopContactRecordingRequest, StopContactRecordingResponse, StopContactRecordingError, Creds | HttpClient.HttpClient>;
export type StopContactStreamingError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Ends message streaming on a specified contact. To restart message streaming on that contact, call the StartContactStreaming
 * API.
 */
export declare const stopContactStreaming: API.OperationMethod<StopContactStreamingRequest, StopContactStreamingResponse, StopContactStreamingError, Creds | HttpClient.HttpClient>;
export type StopTestCaseExecutionError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Stops a running test execution.
 */
export declare const stopTestCaseExecution: API.OperationMethod<StopTestCaseExecutionRequest, StopTestCaseExecutionResponse, StopTestCaseExecutionError, Creds | HttpClient.HttpClient>;
export type SubmitContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Submits a contact evaluation in the specified Connect Customer instance. Answers included in the request are
 * merged with existing answers for the given evaluation. If no answers or notes are passed, the evaluation is submitted
 * with the existing answers and notes. You can delete an answer or note by passing an empty object (`{}`) to
 * the question identifier.
 *
 * If a contact evaluation is already in submitted state, this operation will trigger a resubmission.
 */
export declare const submitContactEvaluation: API.OperationMethod<SubmitContactEvaluationRequest, SubmitContactEvaluationResponse, SubmitContactEvaluationError, Creds | HttpClient.HttpClient>;
export type SuspendContactRecordingError = InternalServiceException | InvalidActiveRegionException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * When a contact is being recorded, this API suspends recording whatever is selected in the flow configuration:
 * call (IVR or agent), screen, or both. If only call recording or only screen recording is enabled, then it would be
 * suspended. For example, you might suspend the screen recording while collecting sensitive information, such as a
 * credit card number. Then use ResumeContactRecording to restart
 * recording the screen.
 *
 * The period of time that the recording is suspended is filled with silence in the final recording.
 *
 * Voice (IVR, agent) and screen recordings are supported.
 */
export declare const suspendContactRecording: API.OperationMethod<SuspendContactRecordingRequest, SuspendContactRecordingResponse, SuspendContactRecordingError, Creds | HttpClient.HttpClient>;
export type TagContactError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds the specified tags to the contact resource. For more information about this API is used, see Set up granular billing for a detailed
 * view of your Connect Customer usage.
 */
export declare const tagContact: API.OperationMethod<TagContactRequest, TagContactResponse, TagContactError, Creds | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 *
 * Some of the supported resource types are agents, routing profiles, queues, quick connects, flows, agent
 * statuses, hours of operation, phone numbers, security profiles, task templates, and custom metrics. For a complete list, see Tagging resources in Connect Customer.
 *
 * For sample policies that use tags, see Connect Customer Identity-Based Policy
 * Examples in the *Connect Customer Administrator Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Creds | HttpClient.HttpClient>;
export type TransferContactError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Transfers `TASK` or `EMAIL`
 * contacts from one agent or queue to another agent or queue at any point after a contact is
 * created. You can transfer a contact to another queue by providing the flow which orchestrates the contact to the
 * destination queue. This gives you more control over contact handling and helps you adhere to the service level
 * agreement (SLA) guaranteed to your customers.
 *
 * Note the following requirements:
 *
 * - Transfer is only supported for `TASK` and `EMAIL` contacts.
 *
 * - Do not use both `QueueId` and `UserId` in the same call.
 *
 * - The following flow types are supported: Inbound flow, Transfer to agent flow, and Transfer to queue
 * flow.
 *
 * - The `TransferContact` API can be called only on active contacts.
 *
 * - A contact cannot be transferred more than 11 times.
 */
export declare const transferContact: API.OperationMethod<TransferContactRequest, TransferContactResponse, TransferContactError, Creds | HttpClient.HttpClient>;
export type UntagContactError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the specified tags from the contact resource. For more information about this API is used, see Set up granular billing for a detailed
 * view of your Connect Customer usage.
 */
export declare const untagContact: API.OperationMethod<UntagContactRequest, UntagContactResponse, UntagContactError, Creds | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Creds | HttpClient.HttpClient>;
export type UpdateAgentStatusError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates agent status.
 */
export declare const updateAgentStatus: API.OperationMethod<UpdateAgentStatusRequest, UpdateAgentStatusResponse, UpdateAgentStatusError, Creds | HttpClient.HttpClient>;
export type UpdateAttachedFilesConfigurationError = AccessDeniedException | InternalServiceException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the attached files configuration for the specified Connect Customer instance and attachment scope.
 *
 * If no instance-specific configuration exists, this operation creates one. Partial updates are supported—only specified fields are updated, while unspecified fields retain their current values.
 */
export declare const updateAttachedFilesConfiguration: API.OperationMethod<UpdateAttachedFilesConfigurationRequest, UpdateAttachedFilesConfigurationResponse, UpdateAttachedFilesConfigurationError, Creds | HttpClient.HttpClient>;
export type UpdateAuthenticationProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change. To
 * request access to this API, contact Amazon Web Services Support.
 *
 * Updates the selected authentication profile.
 */
export declare const updateAuthenticationProfile: API.OperationMethod<UpdateAuthenticationProfileRequest, UpdateAuthenticationProfileResponse, UpdateAuthenticationProfileError, Creds | HttpClient.HttpClient>;
export type UpdateContactError = AccessDeniedException | ConflictException | InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Adds or updates user-defined contact information associated with the specified contact. At least one field to be
 * updated must be present in the request.
 *
 * You can add or update user-defined contact information for both ongoing and completed contacts.
 */
export declare const updateContact: API.OperationMethod<UpdateContactRequest, UpdateContactResponse, UpdateContactError, Creds | HttpClient.HttpClient>;
export type UpdateContactAttributesError = InternalServiceException | InvalidActiveRegionException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Creates or updates user-defined contact
 * attributes associated with the specified contact.
 *
 * You can create or update user-defined attributes for both ongoing and completed contacts. For example, while the
 * call is active, you can update the customer's name or the reason the customer called. You can add notes about steps
 * that the agent took during the call that display to the next agent that takes the call. You can also update
 * attributes for a contact using data from your CRM application and save the data with the contact in Connect Customer. You could also flag calls for additional analysis, such as legal review or to identify abusive callers.
 *
 * Contact attributes are available in Connect Customer for 24 months, and are then deleted. For information
 * about contact record retention and the maximum size of the contact record attributes section, see Feature
 * specifications in the *Connect Customer Administrator Guide*.
 */
export declare const updateContactAttributes: API.OperationMethod<UpdateContactAttributesRequest, UpdateContactAttributesResponse, UpdateContactAttributesError, Creds | HttpClient.HttpClient>;
export type UpdateContactEvaluationError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates details about a contact evaluation in the specified Connect Customer instance. A contact evaluation
 * must be in draft state. Answers included in the request are merged with existing answers for the given evaluation. An
 * answer or note can be deleted by passing an empty object (`{}`) to the question identifier.
 */
export declare const updateContactEvaluation: API.OperationMethod<UpdateContactEvaluationRequest, UpdateContactEvaluationResponse, UpdateContactEvaluationError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowContentError = InternalServiceException | InvalidContactFlowException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the specified flow.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 */
export declare const updateContactFlowContent: API.OperationMethod<UpdateContactFlowContentRequest, UpdateContactFlowContentResponse, UpdateContactFlowContentError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowMetadataError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates metadata about specified flow.
 */
export declare const updateContactFlowMetadata: API.OperationMethod<UpdateContactFlowMetadataRequest, UpdateContactFlowMetadataResponse, UpdateContactFlowMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowModuleAliasError = AccessDeniedException | ConditionalOperationFailedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a specific Aliases metadata, including the version it’s tied to, it’s name, and description.
 */
export declare const updateContactFlowModuleAlias: API.OperationMethod<UpdateContactFlowModuleAliasRequest, UpdateContactFlowModuleAliasResponse, UpdateContactFlowModuleAliasError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowModuleContentError = AccessDeniedException | InternalServiceException | InvalidContactFlowModuleException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates specified flow module for the specified Connect Customer instance.
 *
 * Use the `$SAVED` alias in the request to describe the `SAVED` content of a Flow. For
 * example, `arn:aws:.../contact-flow/{id}:$SAVED`. After a flow is published, `$SAVED` needs to
 * be supplied to view saved content that has not been published.
 */
export declare const updateContactFlowModuleContent: API.OperationMethod<UpdateContactFlowModuleContentRequest, UpdateContactFlowModuleContentResponse, UpdateContactFlowModuleContentError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowModuleMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates metadata about specified flow module.
 */
export declare const updateContactFlowModuleMetadata: API.OperationMethod<UpdateContactFlowModuleMetadataRequest, UpdateContactFlowModuleMetadataResponse, UpdateContactFlowModuleMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateContactFlowNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The name of the flow.
 *
 * You can also create and update flows using the Connect Customer
 * Flow language.
 */
export declare const updateContactFlowName: API.OperationMethod<UpdateContactFlowNameRequest, UpdateContactFlowNameResponse, UpdateContactFlowNameError, Creds | HttpClient.HttpClient>;
export type UpdateContactRoutingDataError = AccessDeniedException | InternalServiceException | InvalidActiveRegionException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates routing priority and age on the contact (**QueuePriority** and **QueueTimeAdjustmentInSeconds**). These properties can be used to change a customer's position
 * in the queue. For example, you can move a contact to the back of the queue by setting a lower routing priority
 * relative to other contacts in queue; or you can move a contact to the front of the queue by increasing the routing
 * age which will make the contact look artificially older and therefore higher up in the first-in-first-out routing
 * order. Note that adjusting the routing age of a contact affects only its position in queue, and not its actual queue
 * wait time as reported through metrics. These properties can also be updated by using the Set routing priority / age flow
 * block.
 *
 * Either **QueuePriority** or **QueueTimeAdjustmentInSeconds** should be provided within the request body, but not both.
 */
export declare const updateContactRoutingData: API.OperationMethod<UpdateContactRoutingDataRequest, UpdateContactRoutingDataResponse, UpdateContactRoutingDataError, Creds | HttpClient.HttpClient>;
export type UpdateContactScheduleError = InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the scheduled time of a task contact that is already scheduled.
 */
export declare const updateContactSchedule: API.OperationMethod<UpdateContactScheduleRequest, UpdateContactScheduleResponse, UpdateContactScheduleError, Creds | HttpClient.HttpClient>;
export type UpdateContactTaskTemplateError = AccessDeniedException | InternalServiceException | InvalidRequestException | LimitExceededException | PropertyValidationException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Updates the task template association on an existing task contact. You can update the task template on a contact
 * before assignment to support tasks that are created without a template (for example Rules or disconnect flows) or change the agent interaction
 * form to represent the latest task data (for example an initial request that was submitted as a refund gets updated to
 * an account cancellation and requires a new template).
 *
 * This operation can only be used with task contacts that are in progress and not connected to an agent. A task
 * template can be updated a maximum of 5 times per contact.
 *
 * The task's references must be compatible with the fields of the target task template. If the target template has
 * a required field, the task must have a corresponding reference with a matching name and compatible type. The
 * following task template field types map to reference types:
 *
 * - `TEXT`, `TEXT_AREA`, `BOOLEAN`, and `SINGLE_SELECT` map to
 * references of type `STRING`.
 *
 * - `NUMBER` maps to references of type `NUMBER`.
 *
 * - `DATE_TIME` maps to references of type `DATE`.
 *
 * - `URL` maps to references of type `URL`.
 *
 * - `EMAIL` maps to references of type `EMAIL`.
 *
 * References corresponding to `TEXT` fields must be fewer than 512 characters.
 * `TEXT_AREA` fields must be fewer than 4,096 characters. `BOOLEAN` fields must have a value
 * of `true` or `false`.
 *
 * An `InvalidRequestException` occurs when `UpdateContactTaskTemplate` is called on a
 * connected or terminated task, when it is called on non-task contacts, and when the task contact already uses the
 * provided task template. A `PropertyValidationException` occurs when the task's references conflict with
 * the task template's fields, for example if the task is missing a reference that matches a required field, or if the
 * task has a reference that matches a required field's name but not its datatype.
 */
export declare const updateContactTaskTemplate: API.OperationMethod<UpdateContactTaskTemplateRequest, UpdateContactTaskTemplateResponse, UpdateContactTaskTemplateError, Creds | HttpClient.HttpClient>;
export type UpdateDataTableAttributeError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates all properties for an attribute using all properties from CreateDataTableAttribute. There are no other
 * granular update endpoints. It does not act as a patch operation - all properties must be provided. System managed
 * attributes are not mutable by customers. Changing an attribute's validation does not invalidate existing values since
 * validation only runs when values are created or updated.
 */
export declare const updateDataTableAttribute: API.OperationMethod<UpdateDataTableAttributeRequest, UpdateDataTableAttributeResponse, UpdateDataTableAttributeError, Creds | HttpClient.HttpClient>;
export type UpdateDataTableMetadataError = AccessDeniedException | ConflictException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the metadata properties of a data table. Accepts all fields similar to CreateDataTable, except for
 * fields and tags. There are no other granular update endpoints. It does not act as a patch operation - all properties
 * must be provided or defaults will be used. Fields follow the same requirements as CreateDataTable.
 */
export declare const updateDataTableMetadata: API.OperationMethod<UpdateDataTableMetadataRequest, UpdateDataTableMetadataResponse, UpdateDataTableMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateDataTablePrimaryValuesError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the primary values for a record. This operation affects all existing values that are currently
 * associated to the record and its primary values. Users that have restrictions on attributes and/or primary values are
 * not authorized to use this endpoint. The combination of new primary values must be unique within the table.
 */
export declare const updateDataTablePrimaryValues: API.OperationMethod<UpdateDataTablePrimaryValuesRequest, UpdateDataTablePrimaryValuesResponse, UpdateDataTablePrimaryValuesError, Creds | HttpClient.HttpClient>;
export type UpdateEmailAddressMetadataError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an email address metadata. For more information about email addresses, see Create email addresses in the Connect Customer
 * Administrator Guide.
 */
export declare const updateEmailAddressMetadata: API.OperationMethod<UpdateEmailAddressMetadataRequest, UpdateEmailAddressMetadataResponse, UpdateEmailAddressMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateEvaluationFormError = InternalServiceException | InvalidParameterException | ResourceConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates details about a specific evaluation form version in the specified Connect Customer instance. Question
 * and section identifiers cannot be duplicated within the same evaluation form.
 *
 * This operation does not support partial updates. Instead it does a full update of evaluation form
 * content.
 */
export declare const updateEvaluationForm: API.OperationMethod<UpdateEvaluationFormRequest, UpdateEvaluationFormResponse, UpdateEvaluationFormError, Creds | HttpClient.HttpClient>;
export type UpdateExtractionDefinitionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an extraction definition in the specified Connect Customer instance.
 */
export declare const updateExtractionDefinition: API.OperationMethod<UpdateExtractionDefinitionRequest, UpdateExtractionDefinitionResponse, UpdateExtractionDefinitionError, Creds | HttpClient.HttpClient>;
export type UpdateHoursOfOperationError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the hours of operation.
 */
export declare const updateHoursOfOperation: API.OperationMethod<UpdateHoursOfOperationRequest, UpdateHoursOfOperationResponse, UpdateHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type UpdateHoursOfOperationOverrideError = ConditionalOperationFailedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Update the hours of operation override.
 */
export declare const updateHoursOfOperationOverride: API.OperationMethod<UpdateHoursOfOperationOverrideRequest, UpdateHoursOfOperationOverrideResponse, UpdateHoursOfOperationOverrideError, Creds | HttpClient.HttpClient>;
export type UpdateInstanceAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Updates the value for the specified attribute type.
 */
export declare const updateInstanceAttribute: API.OperationMethod<UpdateInstanceAttributeRequest, UpdateInstanceAttributeResponse, UpdateInstanceAttributeError, Creds | HttpClient.HttpClient>;
export type UpdateInstanceStorageConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API is in preview release for Connect Customer and is subject to change.
 *
 * Updates an existing configuration for a resource type. This API is idempotent.
 */
export declare const updateInstanceStorageConfig: API.OperationMethod<UpdateInstanceStorageConfigRequest, UpdateInstanceStorageConfigResponse, UpdateInstanceStorageConfigError, Creds | HttpClient.HttpClient>;
export type UpdateMetricContentError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the calculation, unit, and/or trend indicator of an existing metric in the specified Connect Customer instance.
 */
export declare const updateMetricContent: API.OperationMethod<UpdateMetricContentRequest, UpdateMetricContentResponse, UpdateMetricContentError, Creds | HttpClient.HttpClient>;
export type UpdateMetricMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and/or description of an existing metric in the specified Connect Customer instance.
 */
export declare const updateMetricMetadata: API.OperationMethod<UpdateMetricMetadataRequest, UpdateMetricMetadataResponse, UpdateMetricMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateNotificationContentError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the localized content of an existing notification. This operation applies to all users for whom the notification was sent.
 */
export declare const updateNotificationContent: API.OperationMethod<UpdateNotificationContentRequest, UpdateNotificationContentResponse, UpdateNotificationContentError, Creds | HttpClient.HttpClient>;
export type UpdateParticipantAuthenticationError = AccessDeniedException | ConflictException | InternalServiceException | InvalidParameterException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Instructs Connect Customer to resume the authentication process. The subsequent actions depend on the request
 * body contents:
 *
 * - **If a code is provided**: Connect retrieves the identity information from Amazon
 * Cognito and imports it into Connect Customer Profiles.
 *
 * - **If an error is provided**: The error branch of the Authenticate Customer block
 * is executed.
 *
 * The API returns a success response to acknowledge the request. However, the interaction and exchange of
 * identity information occur asynchronously after the response is returned.
 */
export declare const updateParticipantAuthentication: API.OperationMethod<UpdateParticipantAuthenticationRequest, UpdateParticipantAuthenticationResponse, UpdateParticipantAuthenticationError, Creds | HttpClient.HttpClient>;
export type UpdateParticipantRoleConfigError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates timeouts for when human chat participants are to be considered idle, and when agents are automatically
 * disconnected from a chat due to idleness. You can set four timers:
 *
 * - Customer idle timeout
 *
 * - Customer auto-disconnect timeout
 *
 * - Agent idle timeout
 *
 * - Agent auto-disconnect timeout
 *
 * For more information about how chat timeouts work, see
 * Set up chat timeouts for human participants.
 */
export declare const updateParticipantRoleConfig: API.OperationMethod<UpdateParticipantRoleConfigRequest, UpdateParticipantRoleConfigResponse, UpdateParticipantRoleConfigError, Creds | HttpClient.HttpClient>;
export type UpdatePhoneNumberError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates your claimed phone number from its current Connect Customer instance or traffic distribution group to another Connect Customer instance or traffic distribution group in the same Amazon Web Services Region.
 *
 * After using this API, you must verify that the phone number is attached to the correct flow in the target
 * instance or traffic distribution group. You need to do this because the API switches only the phone number to a new
 * instance or traffic distribution group. It doesn't migrate the flow configuration of the phone number, too.
 *
 * You can call DescribePhoneNumber API to verify the status of a previous UpdatePhoneNumber operation.
 */
export declare const updatePhoneNumber: API.OperationMethod<UpdatePhoneNumberRequest, UpdatePhoneNumberResponse, UpdatePhoneNumberError, Creds | HttpClient.HttpClient>;
export type UpdatePhoneNumberMetadataError = AccessDeniedException | IdempotencyException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a phone number’s metadata.
 *
 * To verify the status of a previous UpdatePhoneNumberMetadata operation, call the DescribePhoneNumber API.
 */
export declare const updatePhoneNumberMetadata: API.OperationMethod<UpdatePhoneNumberMetadataRequest, UpdatePhoneNumberMetadataResponse, UpdatePhoneNumberMetadataError, Creds | HttpClient.HttpClient>;
export type UpdatePredefinedAttributeError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a predefined attribute for the specified Connect Customer instance. A *predefined attribute* is
 * made up of a name and a value.
 *
 * For the predefined attributes per instance quota, see Connect Customer
 * quotas.
 *
 * **Use cases**
 *
 * Following are common uses cases for this API:
 *
 * - Update routing proficiency (for example, agent certification) that has predefined values (for example, a list
 * of possible certifications). For more information, see Create predefined attributes for routing contacts to
 * agents.
 *
 * - Update an attribute for business unit name that has a list of predefined business unit names used in your
 * organization. This is a use case where information for a contact varies between transfers or conferences. For more
 * information, see Use contact segment attributes.
 *
 * **Endpoints**: See Connect Customer endpoints and quotas.
 */
export declare const updatePredefinedAttribute: API.OperationMethod<UpdatePredefinedAttributeRequest, UpdatePredefinedAttributeResponse, UpdatePredefinedAttributeError, Creds | HttpClient.HttpClient>;
export type UpdatePromptError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a prompt.
 */
export declare const updatePrompt: API.OperationMethod<UpdatePromptRequest, UpdatePromptResponse, UpdatePromptError, Creds | HttpClient.HttpClient>;
export type UpdateQueueHoursOfOperationError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the hours of operation for the specified queue.
 */
export declare const updateQueueHoursOfOperation: API.OperationMethod<UpdateQueueHoursOfOperationRequest, UpdateQueueHoursOfOperationResponse, UpdateQueueHoursOfOperationError, Creds | HttpClient.HttpClient>;
export type UpdateQueueMaxContactsError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the maximum number of contacts allowed in a queue before it is considered full.
 */
export declare const updateQueueMaxContacts: API.OperationMethod<UpdateQueueMaxContactsRequest, UpdateQueueMaxContactsResponse, UpdateQueueMaxContactsError, Creds | HttpClient.HttpClient>;
export type UpdateQueueNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of a queue. At least `Name` or `Description` must be provided.
 */
export declare const updateQueueName: API.OperationMethod<UpdateQueueNameRequest, UpdateQueueNameResponse, UpdateQueueNameError, Creds | HttpClient.HttpClient>;
export type UpdateQueueOutboundCallerConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the outbound caller ID name, number, and outbound whisper flow for a specified queue.
 *
 * - If the phone number is claimed to a traffic distribution group that was created in the
 * same Region as the Connect Customer instance where you are calling this API, then you can use a
 * full phone number ARN or a UUID for `OutboundCallerIdNumberId`. However, if the phone number is claimed
 * to a traffic distribution group that is in one Region, and you are calling this API from an instance in another Amazon Web Services Region that is associated with the traffic distribution group, you must provide a full phone number ARN. If a
 * UUID is provided in this scenario, you will receive a
 * `ResourceNotFoundException`.
 *
 * - Only use the phone number ARN format that doesn't contain `instance` in the path, for example,
 * `arn:aws:connect:us-east-1:1234567890:phone-number/uuid`. This is the same ARN format that is returned
 * when you call the ListPhoneNumbersV2 API.
 *
 * - If you plan to use IAM policies to allow/deny access to this API for phone number resources
 * claimed to a traffic distribution group, see Allow or Deny queue API actions for phone numbers in a replica Region.
 */
export declare const updateQueueOutboundCallerConfig: API.OperationMethod<UpdateQueueOutboundCallerConfigRequest, UpdateQueueOutboundCallerConfigResponse, UpdateQueueOutboundCallerConfigError, Creds | HttpClient.HttpClient>;
export type UpdateQueueOutboundEmailConfigError = AccessDeniedException | ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the outbound email address Id for a specified queue.
 */
export declare const updateQueueOutboundEmailConfig: API.OperationMethod<UpdateQueueOutboundEmailConfigRequest, UpdateQueueOutboundEmailConfigResponse, UpdateQueueOutboundEmailConfigError, Creds | HttpClient.HttpClient>;
export type UpdateQueueStatusError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the status of the queue.
 */
export declare const updateQueueStatus: API.OperationMethod<UpdateQueueStatusRequest, UpdateQueueStatusResponse, UpdateQueueStatusError, Creds | HttpClient.HttpClient>;
export type UpdateQuickConnectConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the configuration settings for the specified quick connect.
 */
export declare const updateQuickConnectConfig: API.OperationMethod<UpdateQuickConnectConfigRequest, UpdateQuickConnectConfigResponse, UpdateQuickConnectConfigError, Creds | HttpClient.HttpClient>;
export type UpdateQuickConnectNameError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of a quick connect. The request accepts the following data in JSON format. At least `Name` or `Description` must be provided.
 */
export declare const updateQuickConnectName: API.OperationMethod<UpdateQuickConnectNameRequest, UpdateQuickConnectNameResponse, UpdateQuickConnectNameError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileAgentAvailabilityTimerError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Whether agents with this routing profile will have their routing order calculated based on time since
 * their last inbound contact or *longest idle time*.
 */
export declare const updateRoutingProfileAgentAvailabilityTimer: API.OperationMethod<UpdateRoutingProfileAgentAvailabilityTimerRequest, UpdateRoutingProfileAgentAvailabilityTimerResponse, UpdateRoutingProfileAgentAvailabilityTimerError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileConcurrencyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the channels that agents can handle in the Contact Control Panel (CCP) for a routing profile.
 */
export declare const updateRoutingProfileConcurrency: API.OperationMethod<UpdateRoutingProfileConcurrencyRequest, UpdateRoutingProfileConcurrencyResponse, UpdateRoutingProfileConcurrencyError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileDefaultOutboundQueueError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the default outbound queue of a routing profile.
 */
export declare const updateRoutingProfileDefaultOutboundQueue: API.OperationMethod<UpdateRoutingProfileDefaultOutboundQueueRequest, UpdateRoutingProfileDefaultOutboundQueueResponse, UpdateRoutingProfileDefaultOutboundQueueError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of a routing profile. The request accepts the following data in JSON format. At least `Name` or `Description` must be provided.
 */
export declare const updateRoutingProfileName: API.OperationMethod<UpdateRoutingProfileNameRequest, UpdateRoutingProfileNameResponse, UpdateRoutingProfileNameError, Creds | HttpClient.HttpClient>;
export type UpdateRoutingProfileQueuesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties associated with a set of queues for a routing profile.
 */
export declare const updateRoutingProfileQueues: API.OperationMethod<UpdateRoutingProfileQueuesRequest, UpdateRoutingProfileQueuesResponse, UpdateRoutingProfileQueuesError, Creds | HttpClient.HttpClient>;
export type UpdateRuleError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a rule for the specified Connect Customer instance.
 *
 * Use the Rules Function
 * language to code conditions for the rule.
 */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, Creds | HttpClient.HttpClient>;
export type UpdateSecurityProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a security profile.
 *
 * For information about security profiles, see Security Profiles in the *Connect Customer Administrator Guide*. For a mapping of the API name and user interface name of the security
 * profile permissions, see List
 * of security profile permissions.
 */
export declare const updateSecurityProfile: API.OperationMethod<UpdateSecurityProfileRequest, UpdateSecurityProfileResponse, UpdateSecurityProfileError, Creds | HttpClient.HttpClient>;
export type UpdateTaskTemplateError = InternalServiceException | InvalidParameterException | PropertyValidationException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates details about a specific task template in the specified Connect Customer instance. This operation does
 * not support partial updates. Instead it does a full update of template content.
 */
export declare const updateTaskTemplate: API.OperationMethod<UpdateTaskTemplateRequest, UpdateTaskTemplateResponse, UpdateTaskTemplateError, Creds | HttpClient.HttpClient>;
export type UpdateTestCaseError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | InvalidTestCaseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates any of the metadata for a test case, such as the name, description, and status or content of an existing test case. This API doesn't allow customers to update the tags of the test case resource for the specified Amazon Connect instance.
 */
export declare const updateTestCase: API.OperationMethod<UpdateTestCaseRequest, UpdateTestCaseResponse, UpdateTestCaseError, Creds | HttpClient.HttpClient>;
export type UpdateTrafficDistributionError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the traffic distribution for a given traffic distribution group.
 *
 * When you shift telephony traffic, also shift agents and/or agent sign-ins to ensure they can handle the calls
 * in the other Region. If you don't shift the agents, voice calls will go to the shifted Region but there won't be any
 * agents available to receive the calls.
 *
 * The `SignInConfig` distribution is available only on a
 * default `TrafficDistributionGroup` (see the `IsDefault` parameter in the
 * TrafficDistributionGroup
 * data type). If you call
 * `UpdateTrafficDistribution` with a modified `SignInConfig` and a non-default `TrafficDistributionGroup`,
 * an `InvalidRequestException` is returned.
 *
 * For more information about updating a traffic distribution group, see Update telephony traffic distribution
 * across Amazon Web Services Regions
 * in the *Connect Customer Administrator Guide*.
 *
 * **Important things to know**
 *
 * - Invoke the UpdateTrafficDistribution API in the region that should handle traffic.
 */
export declare const updateTrafficDistribution: API.OperationMethod<UpdateTrafficDistributionRequest, UpdateTrafficDistributionResponse, UpdateTrafficDistributionError, Creds | HttpClient.HttpClient>;
export type UpdateUserConfigError = ConditionalOperationFailedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the configuration settings for the specified user, including per-channel auto-accept and after contact work (ACW) timeout settings.
 *
 * This operation replaces the UpdateUserPhoneConfig API. While UpdateUserPhoneConfig applies the same ACW timeout to all channels, UpdateUserConfig allows you to set different auto-accept and ACW timeout values for each channel type.
 */
export declare const updateUserConfig: API.OperationMethod<UpdateUserConfigRequest, UpdateUserConfigResponse, UpdateUserConfigError, Creds | HttpClient.HttpClient>;
export type UpdateUserHierarchyError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns the specified hierarchy group to the specified user.
 */
export declare const updateUserHierarchy: API.OperationMethod<UpdateUserHierarchyRequest, UpdateUserHierarchyResponse, UpdateUserHierarchyError, Creds | HttpClient.HttpClient>;
export type UpdateUserHierarchyGroupNameError = DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the name of the user hierarchy group.
 */
export declare const updateUserHierarchyGroupName: API.OperationMethod<UpdateUserHierarchyGroupNameRequest, UpdateUserHierarchyGroupNameResponse, UpdateUserHierarchyGroupNameError, Creds | HttpClient.HttpClient>;
export type UpdateUserHierarchyStructureError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the user hierarchy structure: add, remove, and rename user hierarchy levels.
 */
export declare const updateUserHierarchyStructure: API.OperationMethod<UpdateUserHierarchyStructureRequest, UpdateUserHierarchyStructureResponse, UpdateUserHierarchyStructureError, Creds | HttpClient.HttpClient>;
export type UpdateUserIdentityInfoError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the identity information for the specified user.
 *
 * We strongly recommend limiting who has the ability to invoke `UpdateUserIdentityInfo`. Someone with
 * that ability can change the login credentials of other users by changing their email address. This poses a security
 * risk to your organization. They can change the email address of a user to the attacker's email address, and then
 * reset the password through email. For more information, see Best Practices for Security Profiles
 * in the *Connect Customer Administrator Guide*.
 */
export declare const updateUserIdentityInfo: API.OperationMethod<UpdateUserIdentityInfoRequest, UpdateUserIdentityInfoResponse, UpdateUserIdentityInfoError, Creds | HttpClient.HttpClient>;
export type UpdateUserNotificationStatusError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the status of a notification for a specific user, such as marking it as read or hidden. Users can only update notification status for notifications that have been sent to them. READ status deprioritizes the notification and greys it out, while HIDDEN status removes it from the notification widget.
 */
export declare const updateUserNotificationStatus: API.OperationMethod<UpdateUserNotificationStatusRequest, UpdateUserNotificationStatusResponse, UpdateUserNotificationStatusError, Creds | HttpClient.HttpClient>;
export type UpdateUserPhoneConfigError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the phone configuration settings for the specified user.
 *
 * We recommend using the UpdateUserConfig API, which supports additional functionality that is not available in the UpdateUserPhoneConfig API, such as voice enhancement settings and per-channel configuration for auto-accept and After Contact Work (ACW) timeouts. In comparison, the UpdateUserPhoneConfig API will always set the same ACW timeouts to all channels the user handles.
 */
export declare const updateUserPhoneConfig: API.OperationMethod<UpdateUserPhoneConfigRequest, UpdateUserPhoneConfigResponse, UpdateUserPhoneConfigError, Creds | HttpClient.HttpClient>;
export type UpdateUserProficienciesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties associated with the proficiencies of a user.
 */
export declare const updateUserProficiencies: API.OperationMethod<UpdateUserProficienciesRequest, UpdateUserProficienciesResponse, UpdateUserProficienciesError, Creds | HttpClient.HttpClient>;
export type UpdateUserRoutingProfileError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns the specified routing profile to the specified user.
 */
export declare const updateUserRoutingProfile: API.OperationMethod<UpdateUserRoutingProfileRequest, UpdateUserRoutingProfileResponse, UpdateUserRoutingProfileError, Creds | HttpClient.HttpClient>;
export type UpdateUserSecurityProfilesError = InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns the specified security profiles to the specified user.
 */
export declare const updateUserSecurityProfiles: API.OperationMethod<UpdateUserSecurityProfilesRequest, UpdateUserSecurityProfilesResponse, UpdateUserSecurityProfilesError, Creds | HttpClient.HttpClient>;
export type UpdateViewContentError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the view content of the given view identifier in the specified Connect Customer instance.
 *
 * It performs content validation if `Status` is set to `SAVED` and performs full content
 * validation if `Status` is `PUBLISHED`. Note that the `$SAVED` alias' content will
 * always be updated, but the `$LATEST` alias' content will only be updated if `Status` is
 * `PUBLISHED`.
 */
export declare const updateViewContent: API.OperationMethod<UpdateViewContentRequest, UpdateViewContentResponse, UpdateViewContentError, Creds | HttpClient.HttpClient>;
export type UpdateViewMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the view metadata. Note that either `Name` or `Description` must be
 * provided.
 */
export declare const updateViewMetadata: API.OperationMethod<UpdateViewMetadataRequest, UpdateViewMetadataResponse, UpdateViewMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspaceMetadataError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the metadata of a workspace, such as its name and description.
 */
export declare const updateWorkspaceMetadata: API.OperationMethod<UpdateWorkspaceMetadataRequest, UpdateWorkspaceMetadataResponse, UpdateWorkspaceMetadataError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspacePageError = AccessDeniedException | DuplicateResourceException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceConflictException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the configuration of a page in a workspace, including the associated view and input data.
 */
export declare const updateWorkspacePage: API.OperationMethod<UpdateWorkspacePageRequest, UpdateWorkspacePageResponse, UpdateWorkspacePageError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspaceThemeError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the theme configuration for a workspace, including colors and styling.
 */
export declare const updateWorkspaceTheme: API.OperationMethod<UpdateWorkspaceThemeRequest, UpdateWorkspaceThemeResponse, UpdateWorkspaceThemeError, Creds | HttpClient.HttpClient>;
export type UpdateWorkspaceVisibilityError = AccessDeniedException | InternalServiceException | InvalidParameterException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the visibility setting of a workspace, controlling whether it is available to all users, assigned users
 * only, or none.
 */
export declare const updateWorkspaceVisibility: API.OperationMethod<UpdateWorkspaceVisibilityRequest, UpdateWorkspaceVisibilityResponse, UpdateWorkspaceVisibilityError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connect.d.ts.map