import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type TunnelId = string;
export type DeleteFlag = boolean;
export interface CloseTunnelRequest {
    tunnelId: string;
    delete?: boolean;
}
export declare const CloseTunnelRequest: S.Schema<CloseTunnelRequest>;
export interface CloseTunnelResponse {
}
export declare const CloseTunnelResponse: S.Schema<CloseTunnelResponse>;
export interface DescribeTunnelRequest {
    tunnelId: string;
}
export declare const DescribeTunnelRequest: S.Schema<DescribeTunnelRequest>;
export type TunnelArn = string;
export type TunnelStatus = "OPEN" | "CLOSED" | (string & {});
export declare const TunnelStatus: any;
export type ConnectionStatus = "CONNECTED" | "DISCONNECTED" | (string & {});
export declare const ConnectionStatus: any;
export interface ConnectionState {
    status?: ConnectionStatus;
    lastUpdatedAt?: Date;
}
export declare const ConnectionState: S.Schema<ConnectionState>;
export type Description = string;
export type ThingName = string;
export type Service = string;
export type ServiceList = string[];
export declare const ServiceList: any;
export interface DestinationConfig {
    thingName?: string;
    services: string[];
}
export declare const DestinationConfig: S.Schema<DestinationConfig>;
export type TimeoutInMin = number;
export interface TimeoutConfig {
    maxLifetimeTimeoutMinutes?: number;
}
export declare const TimeoutConfig: S.Schema<TimeoutConfig>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface Tunnel {
    tunnelId?: string;
    tunnelArn?: string;
    status?: TunnelStatus;
    sourceConnectionState?: ConnectionState;
    destinationConnectionState?: ConnectionState;
    description?: string;
    destinationConfig?: DestinationConfig;
    timeoutConfig?: TimeoutConfig;
    tags?: Tag[];
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export declare const Tunnel: S.Schema<Tunnel>;
export interface DescribeTunnelResponse {
    tunnel?: Tunnel;
}
export declare const DescribeTunnelResponse: S.Schema<DescribeTunnelResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListTunnelsRequest {
    thingName?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListTunnelsRequest: S.Schema<ListTunnelsRequest>;
export interface TunnelSummary {
    tunnelId?: string;
    tunnelArn?: string;
    status?: TunnelStatus;
    description?: string;
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export declare const TunnelSummary: S.Schema<TunnelSummary>;
export type TunnelSummaryList = TunnelSummary[];
export declare const TunnelSummaryList: any;
export interface ListTunnelsResponse {
    tunnelSummaries?: TunnelSummary[];
    nextToken?: string;
}
export declare const ListTunnelsResponse: S.Schema<ListTunnelsResponse>;
export interface OpenTunnelRequest {
    description?: string;
    tags?: Tag[];
    destinationConfig?: DestinationConfig;
    timeoutConfig?: TimeoutConfig;
}
export declare const OpenTunnelRequest: S.Schema<OpenTunnelRequest>;
export type ClientAccessToken = string | redacted.Redacted<string>;
export interface OpenTunnelResponse {
    tunnelId?: string;
    tunnelArn?: string;
    sourceAccessToken?: string | redacted.Redacted<string>;
    destinationAccessToken?: string | redacted.Redacted<string>;
}
export declare const OpenTunnelResponse: S.Schema<OpenTunnelResponse>;
export type ClientMode = "SOURCE" | "DESTINATION" | "ALL" | (string & {});
export declare const ClientMode: any;
export interface RotateTunnelAccessTokenRequest {
    tunnelId: string;
    clientMode: ClientMode;
    destinationConfig?: DestinationConfig;
}
export declare const RotateTunnelAccessTokenRequest: S.Schema<RotateTunnelAccessTokenRequest>;
export interface RotateTunnelAccessTokenResponse {
    tunnelArn?: string;
    sourceAccessToken?: string | redacted.Redacted<string>;
    destinationAccessToken?: string | redacted.Redacted<string>;
}
export declare const RotateTunnelAccessTokenResponse: S.Schema<RotateTunnelAccessTokenResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type ErrorMessage = string;
export type CloseTunnelError = ResourceNotFoundException | CommonErrors;
/**
 * Closes a tunnel identified by the unique tunnel id. When a `CloseTunnel`
 * request is received, we close the WebSocket connections between the client and proxy
 * server so no data can be transmitted.
 *
 * Requires permission to access the CloseTunnel action.
 */
export declare const closeTunnel: API.OperationMethod<CloseTunnelRequest, CloseTunnelResponse, CloseTunnelError, Credentials | HttpClient.HttpClient>;
export type DescribeTunnelError = ResourceNotFoundException | CommonErrors;
/**
 * Gets information about a tunnel identified by the unique tunnel id.
 *
 * Requires permission to access the DescribeTunnel action.
 */
export declare const describeTunnel: API.OperationMethod<DescribeTunnelRequest, DescribeTunnelResponse, DescribeTunnelError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTunnelsError = CommonErrors;
/**
 * List all tunnels for an Amazon Web Services account. Tunnels are listed by creation time in
 * descending order, newer tunnels will be listed before older tunnels.
 *
 * Requires permission to access the ListTunnels action.
 */
export declare const listTunnels: API.PaginatedOperationMethod<ListTunnelsRequest, ListTunnelsResponse, ListTunnelsError, Credentials | HttpClient.HttpClient, unknown>;
export type OpenTunnelError = LimitExceededException | CommonErrors;
/**
 * Creates a new tunnel, and returns two client access tokens for clients to use to
 * connect to the IoT Secure Tunneling proxy server.
 *
 * Requires permission to access the OpenTunnel action.
 */
export declare const openTunnel: API.OperationMethod<OpenTunnelRequest, OpenTunnelResponse, OpenTunnelError, Credentials | HttpClient.HttpClient>;
export type RotateTunnelAccessTokenError = ResourceNotFoundException | CommonErrors;
/**
 * Revokes the current client access token (CAT) and returns new CAT for clients to
 * use when reconnecting to secure tunneling to access the same tunnel.
 *
 * Requires permission to access the RotateTunnelAccessToken action.
 *
 * Rotating the CAT doesn't extend the tunnel duration. For example, say the tunnel
 * duration is 12 hours and the tunnel has already been open for 4 hours. When you
 * rotate the access tokens, the new tokens that are generated can only be used for the
 * remaining 8 hours.
 */
export declare const rotateTunnelAccessToken: API.OperationMethod<RotateTunnelAccessTokenRequest, RotateTunnelAccessTokenResponse, RotateTunnelAccessTokenError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * A resource tag.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotsecuretunneling.d.ts.map