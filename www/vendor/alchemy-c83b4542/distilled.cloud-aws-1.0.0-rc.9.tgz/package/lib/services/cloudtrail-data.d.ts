import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ChannelInsufficientPermission_base: S.Class<ChannelInsufficientPermission, S.TaggedStruct<"ChannelInsufficientPermission", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ChannelInsufficientPermission extends /*@__PURE__*/ ChannelInsufficientPermission_base {
}
declare const ChannelNotFound_base: S.Class<ChannelNotFound, S.TaggedStruct<"ChannelNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ChannelNotFound extends /*@__PURE__*/ ChannelNotFound_base {
}
declare const ChannelUnsupportedSchema_base: S.Class<ChannelUnsupportedSchema, S.TaggedStruct<"ChannelUnsupportedSchema", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ChannelUnsupportedSchema extends /*@__PURE__*/ ChannelUnsupportedSchema_base {
}
declare const DuplicatedAuditEventId_base: S.Class<DuplicatedAuditEventId, S.TaggedStruct<"DuplicatedAuditEventId", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicatedAuditEventId extends /*@__PURE__*/ DuplicatedAuditEventId_base {
}
declare const InvalidChannelARN_base: S.Class<InvalidChannelARN, S.TaggedStruct<"InvalidChannelARN", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidChannelARN extends /*@__PURE__*/ InvalidChannelARN_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type Uuid = string;
export interface AuditEvent {
    id: string;
    eventData: string;
    eventDataChecksum?: string;
}
export declare const AuditEvent: S.Schema<AuditEvent>;
export type AuditEvents = AuditEvent[];
export declare const AuditEvents: any;
export type ChannelArn = string;
export type ExternalId = string;
export interface PutAuditEventsRequest {
    auditEvents: AuditEvent[];
    channelArn: string;
    externalId?: string;
}
export declare const PutAuditEventsRequest: S.Schema<PutAuditEventsRequest>;
export interface AuditEventResultEntry {
    id: string;
    eventID: string;
}
export declare const AuditEventResultEntry: S.Schema<AuditEventResultEntry>;
export type AuditEventResultEntries = AuditEventResultEntry[];
export declare const AuditEventResultEntries: any;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface ResultErrorEntry {
    id: string;
    errorCode: string;
    errorMessage: string;
}
export declare const ResultErrorEntry: S.Schema<ResultErrorEntry>;
export type ResultErrorEntries = ResultErrorEntry[];
export declare const ResultErrorEntries: any;
export interface PutAuditEventsResponse {
    successful: AuditEventResultEntry[];
    failed: ResultErrorEntry[];
}
export declare const PutAuditEventsResponse: S.Schema<PutAuditEventsResponse>;
export type PutAuditEventsError = ChannelInsufficientPermission | ChannelNotFound | ChannelUnsupportedSchema | DuplicatedAuditEventId | InvalidChannelARN | UnsupportedOperationException | CommonErrors;
/**
 * Ingests your application events into CloudTrail Lake. A required parameter,
 * `auditEvents`, accepts the JSON records (also called
 * *payload*) of events that you want CloudTrail to ingest. You
 * can add up to 100 of these events (or up to 1 MB) per `PutAuditEvents`
 * request.
 */
export declare const putAuditEvents: API.OperationMethod<PutAuditEventsRequest, PutAuditEventsResponse, PutAuditEventsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudtrail-data.d.ts.map