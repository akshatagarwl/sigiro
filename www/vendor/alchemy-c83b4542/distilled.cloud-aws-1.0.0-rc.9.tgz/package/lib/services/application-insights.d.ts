import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TagsAlreadyExistException_base: S.Class<TagsAlreadyExistException, S.TaggedStruct<"TagsAlreadyExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagsAlreadyExistException extends /*@__PURE__*/ TagsAlreadyExistException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceGroupName = string;
export type ComponentName = string;
export type WorkloadName = string;
export type Tier = "CUSTOM" | "DEFAULT" | "DOT_NET_CORE" | "DOT_NET_WORKER" | "DOT_NET_WEB_TIER" | "DOT_NET_WEB" | "SQL_SERVER" | "SQL_SERVER_ALWAYSON_AVAILABILITY_GROUP" | "MYSQL" | "POSTGRESQL" | "JAVA_JMX" | "ORACLE" | "SAP_HANA_MULTI_NODE" | "SAP_HANA_SINGLE_NODE" | "SAP_HANA_HIGH_AVAILABILITY" | "SAP_ASE_SINGLE_NODE" | "SAP_ASE_HIGH_AVAILABILITY" | "SQL_SERVER_FAILOVER_CLUSTER_INSTANCE" | "SHAREPOINT" | "ACTIVE_DIRECTORY" | "SAP_NETWEAVER_STANDARD" | "SAP_NETWEAVER_DISTRIBUTED" | "SAP_NETWEAVER_HIGH_AVAILABILITY" | (string & {});
export declare const Tier: any;
export type ComponentConfiguration = string;
export interface WorkloadConfiguration {
    WorkloadName?: string;
    Tier?: Tier;
    Configuration?: string;
}
export declare const WorkloadConfiguration: S.Schema<WorkloadConfiguration>;
export interface AddWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadConfiguration: WorkloadConfiguration;
}
export declare const AddWorkloadRequest: S.Schema<AddWorkloadRequest>;
export type WorkloadId = string;
export interface AddWorkloadResponse {
    WorkloadId?: string;
    WorkloadConfiguration?: WorkloadConfiguration;
}
export declare const AddWorkloadResponse: S.Schema<AddWorkloadResponse>;
export type OpsCenterEnabled = boolean;
export type CWEMonitorEnabled = boolean;
export type OpsItemSNSTopicArn = string;
export type SNSNotificationArn = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type AutoConfigEnabled = boolean;
export type AutoCreate = boolean;
export type GroupingType = "ACCOUNT_BASED" | (string & {});
export declare const GroupingType: any;
export type AttachMissingPermission = boolean;
export interface CreateApplicationRequest {
    ResourceGroupName?: string;
    OpsCenterEnabled?: boolean;
    CWEMonitorEnabled?: boolean;
    OpsItemSNSTopicArn?: string;
    SNSNotificationArn?: string;
    Tags?: Tag[];
    AutoConfigEnabled?: boolean;
    AutoCreate?: boolean;
    GroupingType?: GroupingType;
    AttachMissingPermission?: boolean;
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type AccountId = string;
export type LifeCycle = string;
export type Remarks = string;
export type DiscoveryType = "RESOURCE_GROUP_BASED" | "ACCOUNT_BASED" | (string & {});
export declare const DiscoveryType: any;
export interface ApplicationInfo {
    AccountId?: string;
    ResourceGroupName?: string;
    LifeCycle?: string;
    OpsItemSNSTopicArn?: string;
    SNSNotificationArn?: string;
    OpsCenterEnabled?: boolean;
    CWEMonitorEnabled?: boolean;
    Remarks?: string;
    AutoConfigEnabled?: boolean;
    DiscoveryType?: DiscoveryType;
    AttachMissingPermission?: boolean;
}
export declare const ApplicationInfo: S.Schema<ApplicationInfo>;
export interface CreateApplicationResponse {
    ApplicationInfo?: ApplicationInfo;
}
export declare const CreateApplicationResponse: S.Schema<CreateApplicationResponse>;
export type CustomComponentName = string;
export type ResourceARN = string;
export type ResourceList = string[];
export declare const ResourceList: any;
export interface CreateComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
    ResourceList: string[];
}
export declare const CreateComponentRequest: S.Schema<CreateComponentRequest>;
export interface CreateComponentResponse {
}
export declare const CreateComponentResponse: S.Schema<CreateComponentResponse>;
export type LogPatternSetName = string;
export type LogPatternName = string;
export type LogPatternRegex = string;
export type LogPatternRank = number;
export interface CreateLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
    Pattern: string;
    Rank: number;
}
export declare const CreateLogPatternRequest: S.Schema<CreateLogPatternRequest>;
export interface LogPattern {
    PatternSetName?: string;
    PatternName?: string;
    Pattern?: string;
    Rank?: number;
}
export declare const LogPattern: S.Schema<LogPattern>;
export interface CreateLogPatternResponse {
    LogPattern?: LogPattern;
    ResourceGroupName?: string;
}
export declare const CreateLogPatternResponse: S.Schema<CreateLogPatternResponse>;
export interface DeleteApplicationRequest {
    ResourceGroupName: string;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export interface DeleteComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
}
export declare const DeleteComponentRequest: S.Schema<DeleteComponentRequest>;
export interface DeleteComponentResponse {
}
export declare const DeleteComponentResponse: S.Schema<DeleteComponentResponse>;
export interface DeleteLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
}
export declare const DeleteLogPatternRequest: S.Schema<DeleteLogPatternRequest>;
export interface DeleteLogPatternResponse {
}
export declare const DeleteLogPatternResponse: S.Schema<DeleteLogPatternResponse>;
export interface DescribeApplicationRequest {
    ResourceGroupName: string;
    AccountId?: string;
}
export declare const DescribeApplicationRequest: S.Schema<DescribeApplicationRequest>;
export interface DescribeApplicationResponse {
    ApplicationInfo?: ApplicationInfo;
}
export declare const DescribeApplicationResponse: S.Schema<DescribeApplicationResponse>;
export interface DescribeComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
    AccountId?: string;
}
export declare const DescribeComponentRequest: S.Schema<DescribeComponentRequest>;
export type ResourceType = string;
export type OsType = "WINDOWS" | "LINUX" | (string & {});
export declare const OsType: any;
export type Monitor = boolean;
export type MetaDataKey = string;
export type MetaDataValue = string;
export type WorkloadMetaData = {
    [key: string]: string | undefined;
};
export declare const WorkloadMetaData: any;
export type DetectedWorkload = {
    [key in Tier]?: {
        [key: string]: string | undefined;
    };
};
export declare const DetectedWorkload: any;
export interface ApplicationComponent {
    ComponentName?: string;
    ComponentRemarks?: string;
    ResourceType?: string;
    OsType?: OsType;
    Tier?: Tier;
    Monitor?: boolean;
    DetectedWorkload?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
}
export declare const ApplicationComponent: S.Schema<ApplicationComponent>;
export interface DescribeComponentResponse {
    ApplicationComponent?: ApplicationComponent;
    ResourceList?: string[];
}
export declare const DescribeComponentResponse: S.Schema<DescribeComponentResponse>;
export interface DescribeComponentConfigurationRequest {
    ResourceGroupName: string;
    ComponentName: string;
    AccountId?: string;
}
export declare const DescribeComponentConfigurationRequest: S.Schema<DescribeComponentConfigurationRequest>;
export interface DescribeComponentConfigurationResponse {
    Monitor?: boolean;
    Tier?: Tier;
    ComponentConfiguration?: string;
}
export declare const DescribeComponentConfigurationResponse: S.Schema<DescribeComponentConfigurationResponse>;
export type RecommendationType = "INFRA_ONLY" | "WORKLOAD_ONLY" | "ALL" | (string & {});
export declare const RecommendationType: any;
export interface DescribeComponentConfigurationRecommendationRequest {
    ResourceGroupName: string;
    ComponentName: string;
    Tier: Tier;
    WorkloadName?: string;
    RecommendationType?: RecommendationType;
}
export declare const DescribeComponentConfigurationRecommendationRequest: S.Schema<DescribeComponentConfigurationRecommendationRequest>;
export interface DescribeComponentConfigurationRecommendationResponse {
    ComponentConfiguration?: string;
}
export declare const DescribeComponentConfigurationRecommendationResponse: S.Schema<DescribeComponentConfigurationRecommendationResponse>;
export interface DescribeLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
    AccountId?: string;
}
export declare const DescribeLogPatternRequest: S.Schema<DescribeLogPatternRequest>;
export interface DescribeLogPatternResponse {
    ResourceGroupName?: string;
    AccountId?: string;
    LogPattern?: LogPattern;
}
export declare const DescribeLogPatternResponse: S.Schema<DescribeLogPatternResponse>;
export type ObservationId = string;
export interface DescribeObservationRequest {
    ObservationId: string;
    AccountId?: string;
}
export declare const DescribeObservationRequest: S.Schema<DescribeObservationRequest>;
export type StartTime = Date;
export type EndTime = Date;
export type SourceType = string;
export type SourceARN = string;
export type LogGroup = string;
export type LineTime = Date;
export type LogText = string;
export type LogFilter = "ERROR" | "WARN" | "INFO" | (string & {});
export declare const LogFilter: any;
export type MetricNamespace = string;
export type MetricName = string;
export type Unit = string;
export type Value = number;
export type CloudWatchEventId = string;
export type CloudWatchEventSource = "EC2" | "CODE_DEPLOY" | "HEALTH" | "RDS" | (string & {});
export declare const CloudWatchEventSource: any;
export type CloudWatchEventDetailType = string;
export type HealthEventArn = string;
export type HealthService = string;
export type HealthEventTypeCode = string;
export type HealthEventTypeCategory = string;
export type HealthEventDescription = string;
export type CodeDeployDeploymentId = string;
export type CodeDeployDeploymentGroup = string;
export type CodeDeployState = string;
export type CodeDeployApplication = string;
export type CodeDeployInstanceGroupId = string;
export type Ec2State = string;
export type RdsEventCategories = string;
export type RdsEventMessage = string;
export type S3EventName = string;
export type StatesExecutionArn = string;
export type StatesArn = string;
export type StatesStatus = string;
export type StatesInput = string;
export type EbsEvent = string;
export type EbsResult = string;
export type EbsCause = string;
export type EbsRequestId = string;
export type XRayFaultPercent = number;
export type XRayThrottlePercent = number;
export type XRayErrorPercent = number;
export type XRayRequestCount = number;
export type XRayRequestAverageLatency = number;
export type XRayNodeName = string;
export type XRayNodeType = string;
export interface Observation {
    Id?: string;
    StartTime?: Date;
    EndTime?: Date;
    SourceType?: string;
    SourceARN?: string;
    LogGroup?: string;
    LineTime?: Date;
    LogText?: string;
    LogFilter?: LogFilter;
    MetricNamespace?: string;
    MetricName?: string;
    Unit?: string;
    Value?: number;
    CloudWatchEventId?: string;
    CloudWatchEventSource?: CloudWatchEventSource;
    CloudWatchEventDetailType?: string;
    HealthEventArn?: string;
    HealthService?: string;
    HealthEventTypeCode?: string;
    HealthEventTypeCategory?: string;
    HealthEventDescription?: string;
    CodeDeployDeploymentId?: string;
    CodeDeployDeploymentGroup?: string;
    CodeDeployState?: string;
    CodeDeployApplication?: string;
    CodeDeployInstanceGroupId?: string;
    Ec2State?: string;
    RdsEventCategories?: string;
    RdsEventMessage?: string;
    S3EventName?: string;
    StatesExecutionArn?: string;
    StatesArn?: string;
    StatesStatus?: string;
    StatesInput?: string;
    EbsEvent?: string;
    EbsResult?: string;
    EbsCause?: string;
    EbsRequestId?: string;
    XRayFaultPercent?: number;
    XRayThrottlePercent?: number;
    XRayErrorPercent?: number;
    XRayRequestCount?: number;
    XRayRequestAverageLatency?: number;
    XRayNodeName?: string;
    XRayNodeType?: string;
}
export declare const Observation: S.Schema<Observation>;
export interface DescribeObservationResponse {
    Observation?: Observation;
}
export declare const DescribeObservationResponse: S.Schema<DescribeObservationResponse>;
export type ProblemId = string;
export interface DescribeProblemRequest {
    ProblemId: string;
    AccountId?: string;
}
export declare const DescribeProblemRequest: S.Schema<DescribeProblemRequest>;
export type Title = string;
export type ShortName = string;
export type Insights = string;
export type Status = "IGNORE" | "RESOLVED" | "PENDING" | "RECURRING" | "RECOVERING" | (string & {});
export declare const Status: any;
export type AffectedResource = string;
export type SeverityLevel = "Informative" | "Low" | "Medium" | "High" | (string & {});
export declare const SeverityLevel: any;
export type FeedbackKey = "INSIGHTS_FEEDBACK" | (string & {});
export declare const FeedbackKey: any;
export type FeedbackValue = "NOT_SPECIFIED" | "USEFUL" | "NOT_USEFUL" | (string & {});
export declare const FeedbackValue: any;
export type Feedback = {
    [key in FeedbackKey]?: FeedbackValue;
};
export declare const Feedback: any;
export type RecurringCount = number;
export type LastRecurrenceTime = Date;
export type Visibility = "IGNORED" | "VISIBLE" | (string & {});
export declare const Visibility: any;
export type ResolutionMethod = "MANUAL" | "AUTOMATIC" | "UNRESOLVED" | (string & {});
export declare const ResolutionMethod: any;
export interface Problem {
    Id?: string;
    Title?: string;
    ShortName?: string;
    Insights?: string;
    Status?: Status;
    AffectedResource?: string;
    StartTime?: Date;
    EndTime?: Date;
    SeverityLevel?: SeverityLevel;
    AccountId?: string;
    ResourceGroupName?: string;
    Feedback?: {
        [key: string]: FeedbackValue | undefined;
    };
    RecurringCount?: number;
    LastRecurrenceTime?: Date;
    Visibility?: Visibility;
    ResolutionMethod?: ResolutionMethod;
}
export declare const Problem: S.Schema<Problem>;
export interface DescribeProblemResponse {
    Problem?: Problem;
    SNSNotificationArn?: string;
}
export declare const DescribeProblemResponse: S.Schema<DescribeProblemResponse>;
export interface DescribeProblemObservationsRequest {
    ProblemId: string;
    AccountId?: string;
}
export declare const DescribeProblemObservationsRequest: S.Schema<DescribeProblemObservationsRequest>;
export type ObservationList = Observation[];
export declare const ObservationList: any;
export interface RelatedObservations {
    ObservationList?: Observation[];
}
export declare const RelatedObservations: S.Schema<RelatedObservations>;
export interface DescribeProblemObservationsResponse {
    RelatedObservations?: RelatedObservations;
}
export declare const DescribeProblemObservationsResponse: S.Schema<DescribeProblemObservationsResponse>;
export interface DescribeWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadId: string;
    AccountId?: string;
}
export declare const DescribeWorkloadRequest: S.Schema<DescribeWorkloadRequest>;
export interface DescribeWorkloadResponse {
    WorkloadId?: string;
    WorkloadRemarks?: string;
    WorkloadConfiguration?: WorkloadConfiguration;
}
export declare const DescribeWorkloadResponse: S.Schema<DescribeWorkloadResponse>;
export type MaxEntities = number;
export type PaginationToken = string;
export interface ListApplicationsRequest {
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
}
export declare const ListApplicationsRequest: S.Schema<ListApplicationsRequest>;
export type ApplicationInfoList = ApplicationInfo[];
export declare const ApplicationInfoList: any;
export interface ListApplicationsResponse {
    ApplicationInfoList?: ApplicationInfo[];
    NextToken?: string;
}
export declare const ListApplicationsResponse: S.Schema<ListApplicationsResponse>;
export interface ListComponentsRequest {
    ResourceGroupName: string;
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
}
export declare const ListComponentsRequest: S.Schema<ListComponentsRequest>;
export type ApplicationComponentList = ApplicationComponent[];
export declare const ApplicationComponentList: any;
export interface ListComponentsResponse {
    ApplicationComponentList?: ApplicationComponent[];
    NextToken?: string;
}
export declare const ListComponentsResponse: S.Schema<ListComponentsResponse>;
export type ConfigurationEventStatus = "INFO" | "WARN" | "ERROR" | (string & {});
export declare const ConfigurationEventStatus: any;
export interface ListConfigurationHistoryRequest {
    ResourceGroupName?: string;
    StartTime?: Date;
    EndTime?: Date;
    EventStatus?: ConfigurationEventStatus;
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
}
export declare const ListConfigurationHistoryRequest: S.Schema<ListConfigurationHistoryRequest>;
export type ConfigurationEventMonitoredResourceARN = string;
export type ConfigurationEventResourceType = "CLOUDWATCH_ALARM" | "CLOUDWATCH_LOG" | "CLOUDFORMATION" | "SSM_ASSOCIATION" | (string & {});
export declare const ConfigurationEventResourceType: any;
export type ConfigurationEventTime = Date;
export type ConfigurationEventDetail = string;
export type ConfigurationEventResourceName = string;
export interface ConfigurationEvent {
    ResourceGroupName?: string;
    AccountId?: string;
    MonitoredResourceARN?: string;
    EventStatus?: ConfigurationEventStatus;
    EventResourceType?: ConfigurationEventResourceType;
    EventTime?: Date;
    EventDetail?: string;
    EventResourceName?: string;
}
export declare const ConfigurationEvent: S.Schema<ConfigurationEvent>;
export type ConfigurationEventList = ConfigurationEvent[];
export declare const ConfigurationEventList: any;
export interface ListConfigurationHistoryResponse {
    EventList?: ConfigurationEvent[];
    NextToken?: string;
}
export declare const ListConfigurationHistoryResponse: S.Schema<ListConfigurationHistoryResponse>;
export interface ListLogPatternsRequest {
    ResourceGroupName: string;
    PatternSetName?: string;
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
}
export declare const ListLogPatternsRequest: S.Schema<ListLogPatternsRequest>;
export type LogPatternList = LogPattern[];
export declare const LogPatternList: any;
export interface ListLogPatternsResponse {
    ResourceGroupName?: string;
    AccountId?: string;
    LogPatterns?: LogPattern[];
    NextToken?: string;
}
export declare const ListLogPatternsResponse: S.Schema<ListLogPatternsResponse>;
export interface ListLogPatternSetsRequest {
    ResourceGroupName: string;
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
}
export declare const ListLogPatternSetsRequest: S.Schema<ListLogPatternSetsRequest>;
export type LogPatternSetList = string[];
export declare const LogPatternSetList: any;
export interface ListLogPatternSetsResponse {
    ResourceGroupName?: string;
    AccountId?: string;
    LogPatternSets?: string[];
    NextToken?: string;
}
export declare const ListLogPatternSetsResponse: S.Schema<ListLogPatternSetsResponse>;
export interface ListProblemsRequest {
    AccountId?: string;
    ResourceGroupName?: string;
    StartTime?: Date;
    EndTime?: Date;
    MaxResults?: number;
    NextToken?: string;
    ComponentName?: string;
    Visibility?: Visibility;
}
export declare const ListProblemsRequest: S.Schema<ListProblemsRequest>;
export type ProblemList = Problem[];
export declare const ProblemList: any;
export interface ListProblemsResponse {
    ProblemList?: Problem[];
    NextToken?: string;
    ResourceGroupName?: string;
    AccountId?: string;
}
export declare const ListProblemsResponse: S.Schema<ListProblemsResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWorkloadsRequest {
    ResourceGroupName: string;
    ComponentName: string;
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
}
export declare const ListWorkloadsRequest: S.Schema<ListWorkloadsRequest>;
export type MissingWorkloadConfig = boolean;
export interface Workload {
    WorkloadId?: string;
    ComponentName?: string;
    WorkloadName?: string;
    Tier?: Tier;
    WorkloadRemarks?: string;
    MissingWorkloadConfig?: boolean;
}
export declare const Workload: S.Schema<Workload>;
export type WorkloadList = Workload[];
export declare const WorkloadList: any;
export interface ListWorkloadsResponse {
    WorkloadList?: Workload[];
    NextToken?: string;
}
export declare const ListWorkloadsResponse: S.Schema<ListWorkloadsResponse>;
export interface RemoveWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadId: string;
}
export declare const RemoveWorkloadRequest: S.Schema<RemoveWorkloadRequest>;
export interface RemoveWorkloadResponse {
}
export declare const RemoveWorkloadResponse: S.Schema<RemoveWorkloadResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type RemoveSNSTopic = boolean;
export interface UpdateApplicationRequest {
    ResourceGroupName: string;
    OpsCenterEnabled?: boolean;
    CWEMonitorEnabled?: boolean;
    OpsItemSNSTopicArn?: string;
    SNSNotificationArn?: string;
    RemoveSNSTopic?: boolean;
    AutoConfigEnabled?: boolean;
    AttachMissingPermission?: boolean;
}
export declare const UpdateApplicationRequest: S.Schema<UpdateApplicationRequest>;
export interface UpdateApplicationResponse {
    ApplicationInfo?: ApplicationInfo;
}
export declare const UpdateApplicationResponse: S.Schema<UpdateApplicationResponse>;
export interface UpdateComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
    NewComponentName?: string;
    ResourceList?: string[];
}
export declare const UpdateComponentRequest: S.Schema<UpdateComponentRequest>;
export interface UpdateComponentResponse {
}
export declare const UpdateComponentResponse: S.Schema<UpdateComponentResponse>;
export interface UpdateComponentConfigurationRequest {
    ResourceGroupName: string;
    ComponentName: string;
    Monitor?: boolean;
    Tier?: Tier;
    ComponentConfiguration?: string;
    AutoConfigEnabled?: boolean;
}
export declare const UpdateComponentConfigurationRequest: S.Schema<UpdateComponentConfigurationRequest>;
export interface UpdateComponentConfigurationResponse {
}
export declare const UpdateComponentConfigurationResponse: S.Schema<UpdateComponentConfigurationResponse>;
export interface UpdateLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
    Pattern?: string;
    Rank?: number;
}
export declare const UpdateLogPatternRequest: S.Schema<UpdateLogPatternRequest>;
export interface UpdateLogPatternResponse {
    ResourceGroupName?: string;
    LogPattern?: LogPattern;
}
export declare const UpdateLogPatternResponse: S.Schema<UpdateLogPatternResponse>;
export type UpdateStatus = "RESOLVED" | (string & {});
export declare const UpdateStatus: any;
export interface UpdateProblemRequest {
    ProblemId: string;
    UpdateStatus?: UpdateStatus;
    Visibility?: Visibility;
}
export declare const UpdateProblemRequest: S.Schema<UpdateProblemRequest>;
export interface UpdateProblemResponse {
}
export declare const UpdateProblemResponse: S.Schema<UpdateProblemResponse>;
export interface UpdateWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadId?: string;
    WorkloadConfiguration: WorkloadConfiguration;
}
export declare const UpdateWorkloadRequest: S.Schema<UpdateWorkloadRequest>;
export interface UpdateWorkloadResponse {
    WorkloadId?: string;
    WorkloadConfiguration?: WorkloadConfiguration;
}
export declare const UpdateWorkloadResponse: S.Schema<UpdateWorkloadResponse>;
export type ErrorMsg = string;
export type ExceptionMessage = string;
export type AddWorkloadError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a workload to a component. Each component can have at most five workloads.
 */
export declare const addWorkload: API.OperationMethod<AddWorkloadRequest, AddWorkloadResponse, AddWorkloadError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | InternalServerException | ResourceInUseException | ResourceNotFoundException | TagsAlreadyExistException | ValidationException | CommonErrors;
/**
 * Adds an application that is created from a resource group.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateComponentError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a custom component by grouping similar standalone instances to monitor.
 */
export declare const createComponent: API.OperationMethod<CreateComponentRequest, CreateComponentResponse, CreateComponentError, Credentials | HttpClient.HttpClient>;
export type CreateLogPatternError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds an log pattern to a `LogPatternSet`.
 */
export declare const createLogPattern: API.OperationMethod<CreateLogPatternRequest, CreateLogPatternResponse, CreateLogPatternError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified application from monitoring. Does not delete the
 * application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Ungroups a custom component. When you ungroup custom components, all applicable monitors
 * that are set up for the component are removed and the instances revert to their standalone
 * status.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteLogPatternError = BadRequestException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified log pattern from a `LogPatternSet`.
 */
export declare const deleteLogPattern: API.OperationMethod<DeleteLogPatternRequest, DeleteLogPatternResponse, DeleteLogPatternError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the application.
 */
export declare const describeApplication: API.OperationMethod<DescribeApplicationRequest, DescribeApplicationResponse, DescribeApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes a component and lists the resources that are grouped together in a
 * component.
 */
export declare const describeComponent: API.OperationMethod<DescribeComponentRequest, DescribeComponentResponse, DescribeComponentError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentConfigurationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the monitoring configuration of the component.
 */
export declare const describeComponentConfiguration: API.OperationMethod<DescribeComponentConfigurationRequest, DescribeComponentConfigurationResponse, DescribeComponentConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentConfigurationRecommendationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the recommended monitoring configuration of the component.
 */
export declare const describeComponentConfigurationRecommendation: API.OperationMethod<DescribeComponentConfigurationRecommendationRequest, DescribeComponentConfigurationRecommendationResponse, DescribeComponentConfigurationRecommendationError, Credentials | HttpClient.HttpClient>;
export type DescribeLogPatternError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describe a specific log pattern from a `LogPatternSet`.
 */
export declare const describeLogPattern: API.OperationMethod<DescribeLogPatternRequest, DescribeLogPatternResponse, DescribeLogPatternError, Credentials | HttpClient.HttpClient>;
export type DescribeObservationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes an anomaly or error with the application.
 */
export declare const describeObservation: API.OperationMethod<DescribeObservationRequest, DescribeObservationResponse, DescribeObservationError, Credentials | HttpClient.HttpClient>;
export type DescribeProblemError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes an application problem.
 */
export declare const describeProblem: API.OperationMethod<DescribeProblemRequest, DescribeProblemResponse, DescribeProblemError, Credentials | HttpClient.HttpClient>;
export type DescribeProblemObservationsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the anomalies or errors associated with the problem.
 */
export declare const describeProblemObservations: API.OperationMethod<DescribeProblemObservationsRequest, DescribeProblemObservationsResponse, DescribeProblemObservationsError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkloadError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes a workload and its configuration.
 */
export declare const describeWorkload: API.OperationMethod<DescribeWorkloadRequest, DescribeWorkloadResponse, DescribeWorkloadError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the IDs of the applications that you are monitoring.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListComponentsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the auto-grouped, standalone, and custom components of the application.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConfigurationHistoryError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the INFO, WARN, and ERROR events for periodic configuration updates performed by
 * Application Insights. Examples of events represented are:
 *
 * - INFO: creating a new alarm or updating an alarm threshold.
 *
 * - WARN: alarm not created due to insufficient data points used to predict
 * thresholds.
 *
 * - ERROR: alarm not created due to permission errors or exceeding quotas.
 */
export declare const listConfigurationHistory: API.PaginatedOperationMethod<ListConfigurationHistoryRequest, ListConfigurationHistoryResponse, ListConfigurationHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLogPatternsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the log patterns in the specific log `LogPatternSet`.
 */
export declare const listLogPatterns: API.PaginatedOperationMethod<ListLogPatternsRequest, ListLogPatternsResponse, ListLogPatternsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLogPatternSetsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the log pattern sets in the specific application.
 */
export declare const listLogPatternSets: API.PaginatedOperationMethod<ListLogPatternSetsRequest, ListLogPatternSetsResponse, ListLogPatternSetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProblemsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the problems with your application.
 */
export declare const listProblems: API.PaginatedOperationMethod<ListProblemsRequest, ListProblemsResponse, ListProblemsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieve a list of the tags (keys and values) that are associated with a specified
 * application. A *tag* is a label that you optionally define and associate
 * with an application. Each tag consists of a required *tag key* and an
 * optional associated *tag value*. A tag key is a general label that acts
 * as a category for more specific tag values. A tag value acts as a descriptor within a tag
 * key.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkloadsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the workloads that are configured on a given component.
 */
export declare const listWorkloads: API.PaginatedOperationMethod<ListWorkloadsRequest, ListWorkloadsResponse, ListWorkloadsError, Credentials | HttpClient.HttpClient, unknown>;
export type RemoveWorkloadError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove workload from a component.
 */
export declare const removeWorkload: API.OperationMethod<RemoveWorkloadRequest, RemoveWorkloadResponse, RemoveWorkloadError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Add one or more tags (keys and values) to a specified application. A
 * *tag* is a label that you optionally define and associate with an
 * application. Tags can help you categorize and manage application in different ways, such as
 * by purpose, owner, environment, or other criteria.
 *
 * Each tag consists of a required *tag key* and an associated
 * *tag value*, both of which you define. A tag key is a general label
 * that acts as a category for more specific tag values. A tag value acts as a descriptor
 * within a tag key.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove one or more tags (keys and values) from a specified application.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the custom component name and/or the list of resources that make up the
 * component.
 */
export declare const updateComponent: API.OperationMethod<UpdateComponentRequest, UpdateComponentResponse, UpdateComponentError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentConfigurationError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the monitoring configurations for the component. The configuration input
 * parameter is an escaped JSON of the configuration and should match the schema of what is
 * returned by `DescribeComponentConfigurationRecommendation`.
 */
export declare const updateComponentConfiguration: API.OperationMethod<UpdateComponentConfigurationRequest, UpdateComponentConfigurationResponse, UpdateComponentConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLogPatternError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a log pattern to a `LogPatternSet`.
 */
export declare const updateLogPattern: API.OperationMethod<UpdateLogPatternRequest, UpdateLogPatternResponse, UpdateLogPatternError, Credentials | HttpClient.HttpClient>;
export type UpdateProblemError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the visibility of the problem or specifies the problem as
 * `RESOLVED`.
 */
export declare const updateProblem: API.OperationMethod<UpdateProblemRequest, UpdateProblemResponse, UpdateProblemError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkloadError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a workload to a component. Each component can have at most five workloads.
 */
export declare const updateWorkload: API.OperationMethod<UpdateWorkloadRequest, UpdateWorkloadResponse, UpdateWorkloadError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=application-insights.d.ts.map