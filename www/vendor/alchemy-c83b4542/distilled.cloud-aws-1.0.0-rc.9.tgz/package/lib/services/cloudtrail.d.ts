import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AccountHasOngoingImportException_base: S.Class<AccountHasOngoingImportException, S.TaggedStruct<"AccountHasOngoingImportException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountHasOngoingImportException extends /*@__PURE__*/ AccountHasOngoingImportException_base {
}
declare const AccountNotFoundException_base: S.Class<AccountNotFoundException, S.TaggedStruct<"AccountNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountNotFoundException extends /*@__PURE__*/ AccountNotFoundException_base {
}
declare const AccountNotRegisteredException_base: S.Class<AccountNotRegisteredException, S.TaggedStruct<"AccountNotRegisteredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountNotRegisteredException extends /*@__PURE__*/ AccountNotRegisteredException_base {
}
declare const AccountRegisteredException_base: S.Class<AccountRegisteredException, S.TaggedStruct<"AccountRegisteredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountRegisteredException extends /*@__PURE__*/ AccountRegisteredException_base {
}
declare const CannotDelegateManagementAccountException_base: S.Class<CannotDelegateManagementAccountException, S.TaggedStruct<"CannotDelegateManagementAccountException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CannotDelegateManagementAccountException extends /*@__PURE__*/ CannotDelegateManagementAccountException_base {
}
declare const ChannelAlreadyExistsException_base: S.Class<ChannelAlreadyExistsException, S.TaggedStruct<"ChannelAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ChannelAlreadyExistsException extends /*@__PURE__*/ ChannelAlreadyExistsException_base {
}
declare const ChannelARNInvalidException_base: S.Class<ChannelARNInvalidException, S.TaggedStruct<"ChannelARNInvalidException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelARNInvalidException extends /*@__PURE__*/ ChannelARNInvalidException_base {
}
declare const ChannelExistsForEDSException_base: S.Class<ChannelExistsForEDSException, S.TaggedStruct<"ChannelExistsForEDSException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelExistsForEDSException extends /*@__PURE__*/ ChannelExistsForEDSException_base {
}
declare const ChannelMaxLimitExceededException_base: S.Class<ChannelMaxLimitExceededException, S.TaggedStruct<"ChannelMaxLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelMaxLimitExceededException extends /*@__PURE__*/ ChannelMaxLimitExceededException_base {
}
declare const ChannelNotFoundException_base: S.Class<ChannelNotFoundException, S.TaggedStruct<"ChannelNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChannelNotFoundException extends /*@__PURE__*/ ChannelNotFoundException_base {
}
declare const CloudTrailAccessNotEnabledException_base: S.Class<CloudTrailAccessNotEnabledException, S.TaggedStruct<"CloudTrailAccessNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailAccessNotEnabledException extends /*@__PURE__*/ CloudTrailAccessNotEnabledException_base {
}
declare const CloudTrailARNInvalidException_base: S.Class<CloudTrailARNInvalidException, S.TaggedStruct<"CloudTrailARNInvalidException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailARNInvalidException extends /*@__PURE__*/ CloudTrailARNInvalidException_base {
}
declare const CloudTrailInvalidClientTokenIdException_base: S.Class<CloudTrailInvalidClientTokenIdException, S.TaggedStruct<"CloudTrailInvalidClientTokenIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailInvalidClientTokenIdException extends /*@__PURE__*/ CloudTrailInvalidClientTokenIdException_base {
}
declare const CloudTrailLakeOnboardingClosed_base: S.Class<CloudTrailLakeOnboardingClosed, S.TaggedStruct<"CloudTrailLakeOnboardingClosed", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudTrailLakeOnboardingClosed extends /*@__PURE__*/ CloudTrailLakeOnboardingClosed_base {
}
declare const CloudWatchLogsDeliveryUnavailableException_base: S.Class<CloudWatchLogsDeliveryUnavailableException, S.TaggedStruct<"CloudWatchLogsDeliveryUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CloudWatchLogsDeliveryUnavailableException extends /*@__PURE__*/ CloudWatchLogsDeliveryUnavailableException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DelegatedAdminAccountLimitExceededException_base: S.Class<DelegatedAdminAccountLimitExceededException, S.TaggedStruct<"DelegatedAdminAccountLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DelegatedAdminAccountLimitExceededException extends /*@__PURE__*/ DelegatedAdminAccountLimitExceededException_base {
}
declare const EventDataStoreAlreadyExistsException_base: S.Class<EventDataStoreAlreadyExistsException, S.TaggedStruct<"EventDataStoreAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EventDataStoreAlreadyExistsException extends /*@__PURE__*/ EventDataStoreAlreadyExistsException_base {
}
declare const EventDataStoreARNInvalidException_base: S.Class<EventDataStoreARNInvalidException, S.TaggedStruct<"EventDataStoreARNInvalidException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreARNInvalidException extends /*@__PURE__*/ EventDataStoreARNInvalidException_base {
}
declare const EventDataStoreFederationEnabledException_base: S.Class<EventDataStoreFederationEnabledException, S.TaggedStruct<"EventDataStoreFederationEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreFederationEnabledException extends /*@__PURE__*/ EventDataStoreFederationEnabledException_base {
}
declare const EventDataStoreHasOngoingImportException_base: S.Class<EventDataStoreHasOngoingImportException, S.TaggedStruct<"EventDataStoreHasOngoingImportException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreHasOngoingImportException extends /*@__PURE__*/ EventDataStoreHasOngoingImportException_base {
}
declare const EventDataStoreMaxLimitExceededException_base: S.Class<EventDataStoreMaxLimitExceededException, S.TaggedStruct<"EventDataStoreMaxLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreMaxLimitExceededException extends /*@__PURE__*/ EventDataStoreMaxLimitExceededException_base {
}
declare const EventDataStoreNotFoundException_base: S.Class<EventDataStoreNotFoundException, S.TaggedStruct<"EventDataStoreNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreNotFoundException extends /*@__PURE__*/ EventDataStoreNotFoundException_base {
}
declare const EventDataStoreTerminationProtectedException_base: S.Class<EventDataStoreTerminationProtectedException, S.TaggedStruct<"EventDataStoreTerminationProtectedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventDataStoreTerminationProtectedException extends /*@__PURE__*/ EventDataStoreTerminationProtectedException_base {
}
declare const GenerateResponseException_base: S.Class<GenerateResponseException, S.TaggedStruct<"GenerateResponseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GenerateResponseException extends /*@__PURE__*/ GenerateResponseException_base {
}
declare const ImportNotFoundException_base: S.Class<ImportNotFoundException, S.TaggedStruct<"ImportNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ImportNotFoundException extends /*@__PURE__*/ ImportNotFoundException_base {
}
declare const InactiveEventDataStoreException_base: S.Class<InactiveEventDataStoreException, S.TaggedStruct<"InactiveEventDataStoreException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InactiveEventDataStoreException extends /*@__PURE__*/ InactiveEventDataStoreException_base {
}
declare const InactiveQueryException_base: S.Class<InactiveQueryException, S.TaggedStruct<"InactiveQueryException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InactiveQueryException extends /*@__PURE__*/ InactiveQueryException_base {
}
declare const InsightNotEnabledException_base: S.Class<InsightNotEnabledException, S.TaggedStruct<"InsightNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsightNotEnabledException extends /*@__PURE__*/ InsightNotEnabledException_base {
}
declare const InsufficientDependencyServiceAccessPermissionException_base: S.Class<InsufficientDependencyServiceAccessPermissionException, S.TaggedStruct<"InsufficientDependencyServiceAccessPermissionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientDependencyServiceAccessPermissionException extends /*@__PURE__*/ InsufficientDependencyServiceAccessPermissionException_base {
}
declare const InsufficientEncryptionPolicyException_base: S.Class<InsufficientEncryptionPolicyException, S.TaggedStruct<"InsufficientEncryptionPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientEncryptionPolicyException extends /*@__PURE__*/ InsufficientEncryptionPolicyException_base {
}
declare const InsufficientIAMAccessPermissionException_base: S.Class<InsufficientIAMAccessPermissionException, S.TaggedStruct<"InsufficientIAMAccessPermissionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientIAMAccessPermissionException extends /*@__PURE__*/ InsufficientIAMAccessPermissionException_base {
}
declare const InsufficientS3BucketPolicyException_base: S.Class<InsufficientS3BucketPolicyException, S.TaggedStruct<"InsufficientS3BucketPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientS3BucketPolicyException extends /*@__PURE__*/ InsufficientS3BucketPolicyException_base {
}
declare const InsufficientSnsTopicPolicyException_base: S.Class<InsufficientSnsTopicPolicyException, S.TaggedStruct<"InsufficientSnsTopicPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientSnsTopicPolicyException extends /*@__PURE__*/ InsufficientSnsTopicPolicyException_base {
}
declare const InvalidCloudWatchLogsLogGroupArnException_base: S.Class<InvalidCloudWatchLogsLogGroupArnException, S.TaggedStruct<"InvalidCloudWatchLogsLogGroupArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCloudWatchLogsLogGroupArnException extends /*@__PURE__*/ InvalidCloudWatchLogsLogGroupArnException_base {
}
declare const InvalidCloudWatchLogsRoleArnException_base: S.Class<InvalidCloudWatchLogsRoleArnException, S.TaggedStruct<"InvalidCloudWatchLogsRoleArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCloudWatchLogsRoleArnException extends /*@__PURE__*/ InvalidCloudWatchLogsRoleArnException_base {
}
declare const InvalidDateRangeException_base: S.Class<InvalidDateRangeException, S.TaggedStruct<"InvalidDateRangeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDateRangeException extends /*@__PURE__*/ InvalidDateRangeException_base {
}
declare const InvalidEventCategoryException_base: S.Class<InvalidEventCategoryException, S.TaggedStruct<"InvalidEventCategoryException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventCategoryException extends /*@__PURE__*/ InvalidEventCategoryException_base {
}
declare const InvalidEventDataStoreCategoryException_base: S.Class<InvalidEventDataStoreCategoryException, S.TaggedStruct<"InvalidEventDataStoreCategoryException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventDataStoreCategoryException extends /*@__PURE__*/ InvalidEventDataStoreCategoryException_base {
}
declare const InvalidEventDataStoreStatusException_base: S.Class<InvalidEventDataStoreStatusException, S.TaggedStruct<"InvalidEventDataStoreStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventDataStoreStatusException extends /*@__PURE__*/ InvalidEventDataStoreStatusException_base {
}
declare const InvalidEventSelectorsException_base: S.Class<InvalidEventSelectorsException, S.TaggedStruct<"InvalidEventSelectorsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventSelectorsException extends /*@__PURE__*/ InvalidEventSelectorsException_base {
}
declare const InvalidHomeRegionException_base: S.Class<InvalidHomeRegionException, S.TaggedStruct<"InvalidHomeRegionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidHomeRegionException extends /*@__PURE__*/ InvalidHomeRegionException_base {
}
declare const InvalidImportSourceException_base: S.Class<InvalidImportSourceException, S.TaggedStruct<"InvalidImportSourceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidImportSourceException extends /*@__PURE__*/ InvalidImportSourceException_base {
}
declare const InvalidInsightSelectorsException_base: S.Class<InvalidInsightSelectorsException, S.TaggedStruct<"InvalidInsightSelectorsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInsightSelectorsException extends /*@__PURE__*/ InvalidInsightSelectorsException_base {
}
declare const InvalidKmsKeyIdException_base: S.Class<InvalidKmsKeyIdException, S.TaggedStruct<"InvalidKmsKeyIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKmsKeyIdException extends /*@__PURE__*/ InvalidKmsKeyIdException_base {
}
declare const InvalidLookupAttributesException_base: S.Class<InvalidLookupAttributesException, S.TaggedStruct<"InvalidLookupAttributesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLookupAttributesException extends /*@__PURE__*/ InvalidLookupAttributesException_base {
}
declare const InvalidMaxResultsException_base: S.Class<InvalidMaxResultsException, S.TaggedStruct<"InvalidMaxResultsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidMaxResultsException extends /*@__PURE__*/ InvalidMaxResultsException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterCombinationException_base: S.Class<InvalidParameterCombinationException, S.TaggedStruct<"InvalidParameterCombinationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidQueryStatementException_base: S.Class<InvalidQueryStatementException, S.TaggedStruct<"InvalidQueryStatementException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidQueryStatementException extends /*@__PURE__*/ InvalidQueryStatementException_base {
}
declare const InvalidQueryStatusException_base: S.Class<InvalidQueryStatusException, S.TaggedStruct<"InvalidQueryStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidQueryStatusException extends /*@__PURE__*/ InvalidQueryStatusException_base {
}
declare const InvalidS3BucketNameException_base: S.Class<InvalidS3BucketNameException, S.TaggedStruct<"InvalidS3BucketNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3BucketNameException extends /*@__PURE__*/ InvalidS3BucketNameException_base {
}
declare const InvalidS3PrefixException_base: S.Class<InvalidS3PrefixException, S.TaggedStruct<"InvalidS3PrefixException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidS3PrefixException extends /*@__PURE__*/ InvalidS3PrefixException_base {
}
declare const InvalidSnsTopicNameException_base: S.Class<InvalidSnsTopicNameException, S.TaggedStruct<"InvalidSnsTopicNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnsTopicNameException extends /*@__PURE__*/ InvalidSnsTopicNameException_base {
}
declare const InvalidSourceException_base: S.Class<InvalidSourceException, S.TaggedStruct<"InvalidSourceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSourceException extends /*@__PURE__*/ InvalidSourceException_base {
}
declare const InvalidTagParameterException_base: S.Class<InvalidTagParameterException, S.TaggedStruct<"InvalidTagParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTagParameterException extends /*@__PURE__*/ InvalidTagParameterException_base {
}
declare const InvalidTimeRangeException_base: S.Class<InvalidTimeRangeException, S.TaggedStruct<"InvalidTimeRangeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTimeRangeException extends /*@__PURE__*/ InvalidTimeRangeException_base {
}
declare const InvalidTokenException_base: S.Class<InvalidTokenException, S.TaggedStruct<"InvalidTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTokenException extends /*@__PURE__*/ InvalidTokenException_base {
}
declare const InvalidTrailNameException_base: S.Class<InvalidTrailNameException, S.TaggedStruct<"InvalidTrailNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTrailNameException extends /*@__PURE__*/ InvalidTrailNameException_base {
}
declare const KmsException_base: S.Class<KmsException, S.TaggedStruct<"KmsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsException extends /*@__PURE__*/ KmsException_base {
}
declare const KmsKeyDisabledException_base: S.Class<KmsKeyDisabledException, S.TaggedStruct<"KmsKeyDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsKeyDisabledException extends /*@__PURE__*/ KmsKeyDisabledException_base {
}
declare const KmsKeyNotFoundException_base: S.Class<KmsKeyNotFoundException, S.TaggedStruct<"KmsKeyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsKeyNotFoundException extends /*@__PURE__*/ KmsKeyNotFoundException_base {
}
declare const MaxConcurrentQueriesException_base: S.Class<MaxConcurrentQueriesException, S.TaggedStruct<"MaxConcurrentQueriesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class MaxConcurrentQueriesException extends /*@__PURE__*/ MaxConcurrentQueriesException_base {
}
declare const MaximumNumberOfTrailsExceededException_base: S.Class<MaximumNumberOfTrailsExceededException, S.TaggedStruct<"MaximumNumberOfTrailsExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class MaximumNumberOfTrailsExceededException extends /*@__PURE__*/ MaximumNumberOfTrailsExceededException_base {
}
declare const NoManagementAccountSLRExistsException_base: S.Class<NoManagementAccountSLRExistsException, S.TaggedStruct<"NoManagementAccountSLRExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NoManagementAccountSLRExistsException extends /*@__PURE__*/ NoManagementAccountSLRExistsException_base {
}
declare const NotOrganizationManagementAccountException_base: S.Class<NotOrganizationManagementAccountException, S.TaggedStruct<"NotOrganizationManagementAccountException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotOrganizationManagementAccountException extends /*@__PURE__*/ NotOrganizationManagementAccountException_base {
}
declare const NotOrganizationMasterAccountException_base: S.Class<NotOrganizationMasterAccountException, S.TaggedStruct<"NotOrganizationMasterAccountException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotOrganizationMasterAccountException extends /*@__PURE__*/ NotOrganizationMasterAccountException_base {
}
declare const OperationNotPermittedException_base: S.Class<OperationNotPermittedException, S.TaggedStruct<"OperationNotPermittedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const OrganizationNotInAllFeaturesModeException_base: S.Class<OrganizationNotInAllFeaturesModeException, S.TaggedStruct<"OrganizationNotInAllFeaturesModeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationNotInAllFeaturesModeException extends /*@__PURE__*/ OrganizationNotInAllFeaturesModeException_base {
}
declare const OrganizationsNotInUseException_base: S.Class<OrganizationsNotInUseException, S.TaggedStruct<"OrganizationsNotInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationsNotInUseException extends /*@__PURE__*/ OrganizationsNotInUseException_base {
}
declare const QueryIdNotFoundException_base: S.Class<QueryIdNotFoundException, S.TaggedStruct<"QueryIdNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QueryIdNotFoundException extends /*@__PURE__*/ QueryIdNotFoundException_base {
}
declare const ResourceARNNotValidException_base: S.Class<ResourceARNNotValidException, S.TaggedStruct<"ResourceARNNotValidException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceARNNotValidException extends /*@__PURE__*/ ResourceARNNotValidException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourcePolicyNotFoundException_base: S.Class<ResourcePolicyNotFoundException, S.TaggedStruct<"ResourcePolicyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourcePolicyNotFoundException extends /*@__PURE__*/ ResourcePolicyNotFoundException_base {
}
declare const ResourcePolicyNotValidException_base: S.Class<ResourcePolicyNotValidException, S.TaggedStruct<"ResourcePolicyNotValidException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourcePolicyNotValidException extends /*@__PURE__*/ ResourcePolicyNotValidException_base {
}
declare const ResourceTypeNotSupportedException_base: S.Class<ResourceTypeNotSupportedException, S.TaggedStruct<"ResourceTypeNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceTypeNotSupportedException extends /*@__PURE__*/ ResourceTypeNotSupportedException_base {
}
declare const S3BucketDoesNotExistException_base: S.Class<S3BucketDoesNotExistException, S.TaggedStruct<"S3BucketDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class S3BucketDoesNotExistException extends /*@__PURE__*/ S3BucketDoesNotExistException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TagsLimitExceededException_base: S.Class<TagsLimitExceededException, S.TaggedStruct<"TagsLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagsLimitExceededException extends /*@__PURE__*/ TagsLimitExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TrailAlreadyExistsException_base: S.Class<TrailAlreadyExistsException, S.TaggedStruct<"TrailAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TrailAlreadyExistsException extends /*@__PURE__*/ TrailAlreadyExistsException_base {
}
declare const TrailNotFoundException_base: S.Class<TrailNotFoundException, S.TaggedStruct<"TrailNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrailNotFoundException extends /*@__PURE__*/ TrailNotFoundException_base {
}
declare const TrailNotProvidedException_base: S.Class<TrailNotProvidedException, S.TaggedStruct<"TrailNotProvidedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TrailNotProvidedException extends /*@__PURE__*/ TrailNotProvidedException_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagsList = Tag[];
export declare const TagsList: any;
export interface AddTagsRequest {
    ResourceId: string;
    TagsList: Tag[];
}
export declare const AddTagsRequest: S.Schema<AddTagsRequest>;
export interface AddTagsResponse {
}
export declare const AddTagsResponse: S.Schema<AddTagsResponse>;
export type EventDataStoreArn = string;
export type UUID = string;
export type AccountId = string;
export interface CancelQueryRequest {
    EventDataStore?: string;
    QueryId: string;
    EventDataStoreOwnerAccountId?: string;
}
export declare const CancelQueryRequest: S.Schema<CancelQueryRequest>;
export type QueryStatus = "QUEUED" | "RUNNING" | "FINISHED" | "FAILED" | "CANCELLED" | "TIMED_OUT" | (string & {});
export declare const QueryStatus: any;
export interface CancelQueryResponse {
    QueryId: string;
    QueryStatus: QueryStatus;
    EventDataStoreOwnerAccountId?: string;
}
export declare const CancelQueryResponse: S.Schema<CancelQueryResponse>;
export type ChannelName = string;
export type Source = string;
export type DestinationType = "EVENT_DATA_STORE" | "AWS_SERVICE" | (string & {});
export declare const DestinationType: any;
export type Location = string;
export interface Destination {
    Type: DestinationType;
    Location: string;
}
export declare const Destination: S.Schema<Destination>;
export type Destinations = Destination[];
export declare const Destinations: any;
export interface CreateChannelRequest {
    Name: string;
    Source: string;
    Destinations: Destination[];
    Tags?: Tag[];
}
export declare const CreateChannelRequest: S.Schema<CreateChannelRequest>;
export type ChannelArn = string;
export interface CreateChannelResponse {
    ChannelArn?: string;
    Name?: string;
    Source?: string;
    Destinations?: Destination[];
    Tags?: Tag[];
}
export declare const CreateChannelResponse: S.Schema<CreateChannelResponse>;
export type DashboardName = string;
export type RefreshScheduleFrequencyUnit = "HOURS" | "DAYS" | (string & {});
export declare const RefreshScheduleFrequencyUnit: any;
export type RefreshScheduleFrequencyValue = number;
export interface RefreshScheduleFrequency {
    Unit?: RefreshScheduleFrequencyUnit;
    Value?: number;
}
export declare const RefreshScheduleFrequency: S.Schema<RefreshScheduleFrequency>;
export type RefreshScheduleStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const RefreshScheduleStatus: any;
export type TimeOfDay = string;
export interface RefreshSchedule {
    Frequency?: RefreshScheduleFrequency;
    Status?: RefreshScheduleStatus;
    TimeOfDay?: string;
}
export declare const RefreshSchedule: S.Schema<RefreshSchedule>;
export type TerminationProtectionEnabled = boolean;
export type QueryStatement = string;
export type QueryParameter = string;
export type QueryParameters = string[];
export declare const QueryParameters: any;
export type ViewPropertiesKey = string;
export type ViewPropertiesValue = string;
export type ViewPropertiesMap = {
    [key: string]: string | undefined;
};
export declare const ViewPropertiesMap: any;
export interface RequestWidget {
    QueryStatement: string;
    QueryParameters?: string[];
    ViewProperties: {
        [key: string]: string | undefined;
    };
}
export declare const RequestWidget: S.Schema<RequestWidget>;
export type RequestWidgetList = RequestWidget[];
export declare const RequestWidgetList: any;
export interface CreateDashboardRequest {
    Name: string;
    RefreshSchedule?: RefreshSchedule;
    TagsList?: Tag[];
    TerminationProtectionEnabled?: boolean;
    Widgets?: RequestWidget[];
}
export declare const CreateDashboardRequest: S.Schema<CreateDashboardRequest>;
export type DashboardArn = string;
export type DashboardType = "MANAGED" | "CUSTOM" | (string & {});
export declare const DashboardType: any;
export type QueryAlias = string;
export interface Widget {
    QueryAlias?: string;
    QueryStatement?: string;
    QueryParameters?: string[];
    ViewProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const Widget: S.Schema<Widget>;
export type WidgetList = Widget[];
export declare const WidgetList: any;
export interface CreateDashboardResponse {
    DashboardArn?: string;
    Name?: string;
    Type?: DashboardType;
    Widgets?: Widget[];
    TagsList?: Tag[];
    RefreshSchedule?: RefreshSchedule;
    TerminationProtectionEnabled?: boolean;
}
export declare const CreateDashboardResponse: S.Schema<CreateDashboardResponse>;
export type EventDataStoreName = string;
export type SelectorName = string;
export type SelectorField = string;
export type OperatorValue = string;
export type Operator = string[];
export declare const Operator: any;
export interface AdvancedFieldSelector {
    Field: string;
    Equals?: string[];
    StartsWith?: string[];
    EndsWith?: string[];
    NotEquals?: string[];
    NotStartsWith?: string[];
    NotEndsWith?: string[];
}
export declare const AdvancedFieldSelector: S.Schema<AdvancedFieldSelector>;
export type AdvancedFieldSelectors = AdvancedFieldSelector[];
export declare const AdvancedFieldSelectors: any;
export interface AdvancedEventSelector {
    Name?: string;
    FieldSelectors: AdvancedFieldSelector[];
}
export declare const AdvancedEventSelector: S.Schema<AdvancedEventSelector>;
export type AdvancedEventSelectors = AdvancedEventSelector[];
export declare const AdvancedEventSelectors: any;
export type RetentionPeriod = number;
export type EventDataStoreKmsKeyId = string;
export type BillingMode = "EXTENDABLE_RETENTION_PRICING" | "FIXED_RETENTION_PRICING" | (string & {});
export declare const BillingMode: any;
export interface CreateEventDataStoreRequest {
    Name: string;
    AdvancedEventSelectors?: AdvancedEventSelector[];
    MultiRegionEnabled?: boolean;
    OrganizationEnabled?: boolean;
    RetentionPeriod?: number;
    TerminationProtectionEnabled?: boolean;
    TagsList?: Tag[];
    KmsKeyId?: string;
    StartIngestion?: boolean;
    BillingMode?: BillingMode;
}
export declare const CreateEventDataStoreRequest: S.Schema<CreateEventDataStoreRequest>;
export type EventDataStoreStatus = "CREATED" | "ENABLED" | "PENDING_DELETION" | "STARTING_INGESTION" | "STOPPING_INGESTION" | "STOPPED_INGESTION" | (string & {});
export declare const EventDataStoreStatus: any;
export interface CreateEventDataStoreResponse {
    EventDataStoreArn?: string;
    Name?: string;
    Status?: EventDataStoreStatus;
    AdvancedEventSelectors?: AdvancedEventSelector[];
    MultiRegionEnabled?: boolean;
    OrganizationEnabled?: boolean;
    RetentionPeriod?: number;
    TerminationProtectionEnabled?: boolean;
    TagsList?: Tag[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    KmsKeyId?: string;
    BillingMode?: BillingMode;
}
export declare const CreateEventDataStoreResponse: S.Schema<CreateEventDataStoreResponse>;
export interface CreateTrailRequest {
    Name: string;
    S3BucketName: string;
    S3KeyPrefix?: string;
    SnsTopicName?: string;
    IncludeGlobalServiceEvents?: boolean;
    IsMultiRegionTrail?: boolean;
    EnableLogFileValidation?: boolean;
    CloudWatchLogsLogGroupArn?: string;
    CloudWatchLogsRoleArn?: string;
    KmsKeyId?: string;
    IsOrganizationTrail?: boolean;
    TagsList?: Tag[];
}
export declare const CreateTrailRequest: S.Schema<CreateTrailRequest>;
export interface CreateTrailResponse {
    Name?: string;
    S3BucketName?: string;
    S3KeyPrefix?: string;
    SnsTopicName?: string;
    SnsTopicARN?: string;
    IncludeGlobalServiceEvents?: boolean;
    IsMultiRegionTrail?: boolean;
    TrailARN?: string;
    LogFileValidationEnabled?: boolean;
    CloudWatchLogsLogGroupArn?: string;
    CloudWatchLogsRoleArn?: string;
    KmsKeyId?: string;
    IsOrganizationTrail?: boolean;
}
export declare const CreateTrailResponse: S.Schema<CreateTrailResponse>;
export interface DeleteChannelRequest {
    Channel: string;
}
export declare const DeleteChannelRequest: S.Schema<DeleteChannelRequest>;
export interface DeleteChannelResponse {
}
export declare const DeleteChannelResponse: S.Schema<DeleteChannelResponse>;
export interface DeleteDashboardRequest {
    DashboardId: string;
}
export declare const DeleteDashboardRequest: S.Schema<DeleteDashboardRequest>;
export interface DeleteDashboardResponse {
}
export declare const DeleteDashboardResponse: S.Schema<DeleteDashboardResponse>;
export interface DeleteEventDataStoreRequest {
    EventDataStore: string;
}
export declare const DeleteEventDataStoreRequest: S.Schema<DeleteEventDataStoreRequest>;
export interface DeleteEventDataStoreResponse {
}
export declare const DeleteEventDataStoreResponse: S.Schema<DeleteEventDataStoreResponse>;
export type ResourceArn = string;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DeleteTrailRequest {
    Name: string;
}
export declare const DeleteTrailRequest: S.Schema<DeleteTrailRequest>;
export interface DeleteTrailResponse {
}
export declare const DeleteTrailResponse: S.Schema<DeleteTrailResponse>;
export interface DeregisterOrganizationDelegatedAdminRequest {
    DelegatedAdminAccountId: string;
}
export declare const DeregisterOrganizationDelegatedAdminRequest: S.Schema<DeregisterOrganizationDelegatedAdminRequest>;
export interface DeregisterOrganizationDelegatedAdminResponse {
}
export declare const DeregisterOrganizationDelegatedAdminResponse: S.Schema<DeregisterOrganizationDelegatedAdminResponse>;
export type RefreshId = string;
export interface DescribeQueryRequest {
    EventDataStore?: string;
    QueryId?: string;
    QueryAlias?: string;
    RefreshId?: string;
    EventDataStoreOwnerAccountId?: string;
}
export declare const DescribeQueryRequest: S.Schema<DescribeQueryRequest>;
export interface QueryStatisticsForDescribeQuery {
    EventsMatched?: number;
    EventsScanned?: number;
    BytesScanned?: number;
    ExecutionTimeInMillis?: number;
    CreationTime?: Date;
}
export declare const QueryStatisticsForDescribeQuery: S.Schema<QueryStatisticsForDescribeQuery>;
export type ErrorMessage = string;
export type DeliveryS3Uri = string;
export type DeliveryStatus = "SUCCESS" | "FAILED" | "FAILED_SIGNING_FILE" | "PENDING" | "RESOURCE_NOT_FOUND" | "ACCESS_DENIED" | "ACCESS_DENIED_SIGNING_FILE" | "CANCELLED" | "UNKNOWN" | (string & {});
export declare const DeliveryStatus: any;
export type Prompt = string;
export interface DescribeQueryResponse {
    QueryId?: string;
    QueryString?: string;
    QueryStatus?: QueryStatus;
    QueryStatistics?: QueryStatisticsForDescribeQuery;
    ErrorMessage?: string;
    DeliveryS3Uri?: string;
    DeliveryStatus?: DeliveryStatus;
    Prompt?: string;
    EventDataStoreOwnerAccountId?: string;
}
export declare const DescribeQueryResponse: S.Schema<DescribeQueryResponse>;
export type TrailNameList = string[];
export declare const TrailNameList: any;
export interface DescribeTrailsRequest {
    trailNameList?: string[];
    includeShadowTrails?: boolean;
}
export declare const DescribeTrailsRequest: S.Schema<DescribeTrailsRequest>;
export interface Trail {
    Name?: string;
    S3BucketName?: string;
    S3KeyPrefix?: string;
    SnsTopicName?: string;
    SnsTopicARN?: string;
    IncludeGlobalServiceEvents?: boolean;
    IsMultiRegionTrail?: boolean;
    HomeRegion?: string;
    TrailARN?: string;
    LogFileValidationEnabled?: boolean;
    CloudWatchLogsLogGroupArn?: string;
    CloudWatchLogsRoleArn?: string;
    KmsKeyId?: string;
    HasCustomEventSelectors?: boolean;
    HasInsightSelectors?: boolean;
    IsOrganizationTrail?: boolean;
}
export declare const Trail: S.Schema<Trail>;
export type TrailList = Trail[];
export declare const TrailList: any;
export interface DescribeTrailsResponse {
    trailList?: Trail[];
}
export declare const DescribeTrailsResponse: S.Schema<DescribeTrailsResponse>;
export interface DisableFederationRequest {
    EventDataStore: string;
}
export declare const DisableFederationRequest: S.Schema<DisableFederationRequest>;
export type FederationStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | (string & {});
export declare const FederationStatus: any;
export interface DisableFederationResponse {
    EventDataStoreArn?: string;
    FederationStatus?: FederationStatus;
}
export declare const DisableFederationResponse: S.Schema<DisableFederationResponse>;
export type FederationRoleArn = string;
export interface EnableFederationRequest {
    EventDataStore: string;
    FederationRoleArn: string;
}
export declare const EnableFederationRequest: S.Schema<EnableFederationRequest>;
export interface EnableFederationResponse {
    EventDataStoreArn?: string;
    FederationStatus?: FederationStatus;
    FederationRoleArn?: string;
}
export declare const EnableFederationResponse: S.Schema<EnableFederationResponse>;
export type EventDataStoreList = string[];
export declare const EventDataStoreList: any;
export interface GenerateQueryRequest {
    EventDataStores: string[];
    Prompt: string;
}
export declare const GenerateQueryRequest: S.Schema<GenerateQueryRequest>;
export interface GenerateQueryResponse {
    QueryStatement?: string;
    QueryAlias?: string;
    EventDataStoreOwnerAccountId?: string;
}
export declare const GenerateQueryResponse: S.Schema<GenerateQueryResponse>;
export interface GetChannelRequest {
    Channel: string;
}
export declare const GetChannelRequest: S.Schema<GetChannelRequest>;
export interface SourceConfig {
    ApplyToAllRegions?: boolean;
    AdvancedEventSelectors?: AdvancedEventSelector[];
}
export declare const SourceConfig: S.Schema<SourceConfig>;
export interface IngestionStatus {
    LatestIngestionSuccessTime?: Date;
    LatestIngestionSuccessEventID?: string;
    LatestIngestionErrorCode?: string;
    LatestIngestionAttemptTime?: Date;
    LatestIngestionAttemptEventID?: string;
}
export declare const IngestionStatus: S.Schema<IngestionStatus>;
export interface GetChannelResponse {
    ChannelArn?: string;
    Name?: string;
    Source?: string;
    SourceConfig?: SourceConfig;
    Destinations?: Destination[];
    IngestionStatus?: IngestionStatus;
}
export declare const GetChannelResponse: S.Schema<GetChannelResponse>;
export interface GetDashboardRequest {
    DashboardId: string;
}
export declare const GetDashboardRequest: S.Schema<GetDashboardRequest>;
export type DashboardStatus = "CREATING" | "CREATED" | "UPDATING" | "UPDATED" | "DELETING" | (string & {});
export declare const DashboardStatus: any;
export interface GetDashboardResponse {
    DashboardArn?: string;
    Type?: DashboardType;
    Status?: DashboardStatus;
    Widgets?: Widget[];
    RefreshSchedule?: RefreshSchedule;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    LastRefreshId?: string;
    LastRefreshFailureReason?: string;
    TerminationProtectionEnabled?: boolean;
}
export declare const GetDashboardResponse: S.Schema<GetDashboardResponse>;
export interface GetEventConfigurationRequest {
    TrailName?: string;
    EventDataStore?: string;
}
export declare const GetEventConfigurationRequest: S.Schema<GetEventConfigurationRequest>;
export type MaxEventSize = "Standard" | "Large" | (string & {});
export declare const MaxEventSize: any;
export type Type = "TagContext" | "RequestContext" | (string & {});
export declare const Type: any;
export type OperatorTargetListMember = string;
export type OperatorTargetList = string[];
export declare const OperatorTargetList: any;
export interface ContextKeySelector {
    Type: Type;
    Equals: string[];
}
export declare const ContextKeySelector: S.Schema<ContextKeySelector>;
export type ContextKeySelectors = ContextKeySelector[];
export declare const ContextKeySelectors: any;
export type Template = "API_ACTIVITY" | "RESOURCE_ACCESS" | "USER_ACTIONS" | (string & {});
export declare const Template: any;
export type Templates = Template[];
export declare const Templates: any;
export type EventCategoryAggregation = "Data" | (string & {});
export declare const EventCategoryAggregation: any;
export interface AggregationConfiguration {
    Templates: Template[];
    EventCategory: EventCategoryAggregation;
}
export declare const AggregationConfiguration: S.Schema<AggregationConfiguration>;
export type AggregationConfigurations = AggregationConfiguration[];
export declare const AggregationConfigurations: any;
export interface GetEventConfigurationResponse {
    TrailARN?: string;
    EventDataStoreArn?: string;
    MaxEventSize?: MaxEventSize;
    ContextKeySelectors?: ContextKeySelector[];
    AggregationConfigurations?: AggregationConfiguration[];
}
export declare const GetEventConfigurationResponse: S.Schema<GetEventConfigurationResponse>;
export interface GetEventDataStoreRequest {
    EventDataStore: string;
}
export declare const GetEventDataStoreRequest: S.Schema<GetEventDataStoreRequest>;
export type PartitionKeyName = string;
export type PartitionKeyType = string;
export interface PartitionKey {
    Name: string;
    Type: string;
}
export declare const PartitionKey: S.Schema<PartitionKey>;
export type PartitionKeyList = PartitionKey[];
export declare const PartitionKeyList: any;
export interface GetEventDataStoreResponse {
    EventDataStoreArn?: string;
    Name?: string;
    Status?: EventDataStoreStatus;
    AdvancedEventSelectors?: AdvancedEventSelector[];
    MultiRegionEnabled?: boolean;
    OrganizationEnabled?: boolean;
    RetentionPeriod?: number;
    TerminationProtectionEnabled?: boolean;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    KmsKeyId?: string;
    BillingMode?: BillingMode;
    FederationStatus?: FederationStatus;
    FederationRoleArn?: string;
    PartitionKeys?: PartitionKey[];
}
export declare const GetEventDataStoreResponse: S.Schema<GetEventDataStoreResponse>;
export interface GetEventSelectorsRequest {
    TrailName: string;
}
export declare const GetEventSelectorsRequest: S.Schema<GetEventSelectorsRequest>;
export type ReadWriteType = "ReadOnly" | "WriteOnly" | "All" | (string & {});
export declare const ReadWriteType: any;
export type DataResourceValues = string[];
export declare const DataResourceValues: any;
export interface DataResource {
    Type?: string;
    Values?: string[];
}
export declare const DataResource: S.Schema<DataResource>;
export type DataResources = DataResource[];
export declare const DataResources: any;
export type ExcludeManagementEventSources = string[];
export declare const ExcludeManagementEventSources: any;
export interface EventSelector {
    ReadWriteType?: ReadWriteType;
    IncludeManagementEvents?: boolean;
    DataResources?: DataResource[];
    ExcludeManagementEventSources?: string[];
}
export declare const EventSelector: S.Schema<EventSelector>;
export type EventSelectors = EventSelector[];
export declare const EventSelectors: any;
export interface GetEventSelectorsResponse {
    TrailARN?: string;
    EventSelectors?: EventSelector[];
    AdvancedEventSelectors?: AdvancedEventSelector[];
}
export declare const GetEventSelectorsResponse: S.Schema<GetEventSelectorsResponse>;
export interface GetImportRequest {
    ImportId: string;
}
export declare const GetImportRequest: S.Schema<GetImportRequest>;
export type ImportDestinations = string[];
export declare const ImportDestinations: any;
export interface S3ImportSource {
    S3LocationUri: string;
    S3BucketRegion: string;
    S3BucketAccessRoleArn: string;
}
export declare const S3ImportSource: S.Schema<S3ImportSource>;
export interface ImportSource {
    S3: S3ImportSource;
}
export declare const ImportSource: S.Schema<ImportSource>;
export type ImportStatus = "INITIALIZING" | "IN_PROGRESS" | "FAILED" | "STOPPED" | "COMPLETED" | (string & {});
export declare const ImportStatus: any;
export interface ImportStatistics {
    PrefixesFound?: number;
    PrefixesCompleted?: number;
    FilesCompleted?: number;
    EventsCompleted?: number;
    FailedEntries?: number;
}
export declare const ImportStatistics: S.Schema<ImportStatistics>;
export interface GetImportResponse {
    ImportId?: string;
    Destinations?: string[];
    ImportSource?: ImportSource;
    StartEventTime?: Date;
    EndEventTime?: Date;
    ImportStatus?: ImportStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    ImportStatistics?: ImportStatistics;
}
export declare const GetImportResponse: S.Schema<GetImportResponse>;
export interface GetInsightSelectorsRequest {
    TrailName?: string;
    EventDataStore?: string;
}
export declare const GetInsightSelectorsRequest: S.Schema<GetInsightSelectorsRequest>;
export type InsightType = "ApiCallRateInsight" | "ApiErrorRateInsight" | (string & {});
export declare const InsightType: any;
export type SourceEventCategory = "Management" | "Data" | (string & {});
export declare const SourceEventCategory: any;
export type SourceEventCategories = SourceEventCategory[];
export declare const SourceEventCategories: any;
export interface InsightSelector {
    InsightType?: InsightType;
    EventCategories?: SourceEventCategory[];
}
export declare const InsightSelector: S.Schema<InsightSelector>;
export type InsightSelectors = InsightSelector[];
export declare const InsightSelectors: any;
export interface GetInsightSelectorsResponse {
    TrailARN?: string;
    InsightSelectors?: InsightSelector[];
    EventDataStoreArn?: string;
    InsightsDestination?: string;
}
export declare const GetInsightSelectorsResponse: S.Schema<GetInsightSelectorsResponse>;
export type PaginationToken = string;
export type MaxQueryResults = number;
export interface GetQueryResultsRequest {
    EventDataStore?: string;
    QueryId: string;
    NextToken?: string;
    MaxQueryResults?: number;
    EventDataStoreOwnerAccountId?: string;
}
export declare const GetQueryResultsRequest: S.Schema<GetQueryResultsRequest>;
export interface QueryStatistics {
    ResultsCount?: number;
    TotalResultsCount?: number;
    BytesScanned?: number;
}
export declare const QueryStatistics: S.Schema<QueryStatistics>;
export type QueryResultKey = string;
export type QueryResultValue = string;
export type QueryResultColumn = {
    [key: string]: string | undefined;
};
export declare const QueryResultColumn: any;
export type QueryResultRow = {
    [key: string]: string | undefined;
}[];
export declare const QueryResultRow: any;
export type QueryResultRows = {
    [key: string]: string | undefined;
}[][];
export declare const QueryResultRows: any;
export interface GetQueryResultsResponse {
    QueryStatus?: QueryStatus;
    QueryStatistics?: QueryStatistics;
    QueryResultRows?: {
        [key: string]: string | undefined;
    }[][];
    NextToken?: string;
    ErrorMessage?: string;
}
export declare const GetQueryResultsResponse: S.Schema<GetQueryResultsResponse>;
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export type ResourcePolicy = string;
export interface GetResourcePolicyResponse {
    ResourceArn?: string;
    ResourcePolicy?: string;
    DelegatedAdminResourcePolicy?: string;
}
export declare const GetResourcePolicyResponse: S.Schema<GetResourcePolicyResponse>;
export interface GetTrailRequest {
    Name: string;
}
export declare const GetTrailRequest: S.Schema<GetTrailRequest>;
export interface GetTrailResponse {
    Trail?: Trail;
}
export declare const GetTrailResponse: S.Schema<GetTrailResponse>;
export interface GetTrailStatusRequest {
    Name: string;
}
export declare const GetTrailStatusRequest: S.Schema<GetTrailStatusRequest>;
export interface GetTrailStatusResponse {
    IsLogging?: boolean;
    LatestDeliveryError?: string;
    LatestNotificationError?: string;
    LatestDeliveryTime?: Date;
    LatestNotificationTime?: Date;
    StartLoggingTime?: Date;
    StopLoggingTime?: Date;
    LatestCloudWatchLogsDeliveryError?: string;
    LatestCloudWatchLogsDeliveryTime?: Date;
    LatestDigestDeliveryTime?: Date;
    LatestDigestDeliveryError?: string;
    LatestDeliveryAttemptTime?: string;
    LatestNotificationAttemptTime?: string;
    LatestNotificationAttemptSucceeded?: string;
    LatestDeliveryAttemptSucceeded?: string;
    TimeLoggingStarted?: string;
    TimeLoggingStopped?: string;
}
export declare const GetTrailStatusResponse: S.Schema<GetTrailStatusResponse>;
export type ListChannelsMaxResultsCount = number;
export interface ListChannelsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListChannelsRequest: S.Schema<ListChannelsRequest>;
export interface Channel {
    ChannelArn?: string;
    Name?: string;
}
export declare const Channel: S.Schema<Channel>;
export type Channels = Channel[];
export declare const Channels: any;
export interface ListChannelsResponse {
    Channels?: Channel[];
    NextToken?: string;
}
export declare const ListChannelsResponse: S.Schema<ListChannelsResponse>;
export type ListDashboardsMaxResultsCount = number;
export interface ListDashboardsRequest {
    NamePrefix?: string;
    Type?: DashboardType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDashboardsRequest: S.Schema<ListDashboardsRequest>;
export interface DashboardDetail {
    DashboardArn?: string;
    Type?: DashboardType;
}
export declare const DashboardDetail: S.Schema<DashboardDetail>;
export type Dashboards = DashboardDetail[];
export declare const Dashboards: any;
export interface ListDashboardsResponse {
    Dashboards?: DashboardDetail[];
    NextToken?: string;
}
export declare const ListDashboardsResponse: S.Schema<ListDashboardsResponse>;
export type ListEventDataStoresMaxResultsCount = number;
export interface ListEventDataStoresRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEventDataStoresRequest: S.Schema<ListEventDataStoresRequest>;
export interface EventDataStore {
    EventDataStoreArn?: string;
    Name?: string;
    TerminationProtectionEnabled?: boolean;
    Status?: EventDataStoreStatus;
    AdvancedEventSelectors?: AdvancedEventSelector[];
    MultiRegionEnabled?: boolean;
    OrganizationEnabled?: boolean;
    RetentionPeriod?: number;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const EventDataStore: S.Schema<EventDataStore>;
export type EventDataStores = EventDataStore[];
export declare const EventDataStores: any;
export interface ListEventDataStoresResponse {
    EventDataStores?: EventDataStore[];
    NextToken?: string;
}
export declare const ListEventDataStoresResponse: S.Schema<ListEventDataStoresResponse>;
export type ListImportFailuresMaxResultsCount = number;
export interface ListImportFailuresRequest {
    ImportId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListImportFailuresRequest: S.Schema<ListImportFailuresRequest>;
export type ImportFailureStatus = "FAILED" | "RETRY" | "SUCCEEDED" | (string & {});
export declare const ImportFailureStatus: any;
export interface ImportFailureListItem {
    Location?: string;
    Status?: ImportFailureStatus;
    ErrorType?: string;
    ErrorMessage?: string;
    LastUpdatedTime?: Date;
}
export declare const ImportFailureListItem: S.Schema<ImportFailureListItem>;
export type ImportFailureList = ImportFailureListItem[];
export declare const ImportFailureList: any;
export interface ListImportFailuresResponse {
    Failures?: ImportFailureListItem[];
    NextToken?: string;
}
export declare const ListImportFailuresResponse: S.Schema<ListImportFailuresResponse>;
export type ListImportsMaxResultsCount = number;
export interface ListImportsRequest {
    MaxResults?: number;
    Destination?: string;
    ImportStatus?: ImportStatus;
    NextToken?: string;
}
export declare const ListImportsRequest: S.Schema<ListImportsRequest>;
export interface ImportsListItem {
    ImportId?: string;
    ImportStatus?: ImportStatus;
    Destinations?: string[];
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const ImportsListItem: S.Schema<ImportsListItem>;
export type ImportsList = ImportsListItem[];
export declare const ImportsList: any;
export interface ListImportsResponse {
    Imports?: ImportsListItem[];
    NextToken?: string;
}
export declare const ListImportsResponse: S.Schema<ListImportsResponse>;
export type ListInsightsDataType = "InsightsEvents" | (string & {});
export declare const ListInsightsDataType: any;
export type ListInsightsDataDimensionKey = "EventId" | "EventName" | "EventSource" | (string & {});
export declare const ListInsightsDataDimensionKey: any;
export type ListInsightsDataDimensionValue = string;
export type ListInsightsDataDimensions = {
    [key in ListInsightsDataDimensionKey]?: string;
};
export declare const ListInsightsDataDimensions: any;
export type ListInsightsDataMaxResultsCount = number;
export interface ListInsightsDataRequest {
    InsightSource: string;
    DataType: ListInsightsDataType;
    Dimensions?: {
        [key: string]: string | undefined;
    };
    StartTime?: Date;
    EndTime?: Date;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListInsightsDataRequest: S.Schema<ListInsightsDataRequest>;
export interface Resource {
    ResourceType?: string;
    ResourceName?: string;
}
export declare const Resource: S.Schema<Resource>;
export type ResourceList = Resource[];
export declare const ResourceList: any;
export interface Event {
    EventId?: string;
    EventName?: string;
    ReadOnly?: string;
    AccessKeyId?: string;
    EventTime?: Date;
    EventSource?: string;
    Username?: string;
    Resources?: Resource[];
    CloudTrailEvent?: string;
}
export declare const Event: S.Schema<Event>;
export type EventsList = Event[];
export declare const EventsList: any;
export interface ListInsightsDataResponse {
    Events?: Event[];
    NextToken?: string;
}
export declare const ListInsightsDataResponse: S.Schema<ListInsightsDataResponse>;
export type EventSource = string;
export type EventName = string;
export type ErrorCode = string;
export type InsightsMetricPeriod = number;
export type InsightsMetricDataType = "FillWithZeros" | "NonZeroData" | (string & {});
export declare const InsightsMetricDataType: any;
export type InsightsMetricMaxResults = number;
export type InsightsMetricNextToken = string;
export interface ListInsightsMetricDataRequest {
    TrailName?: string;
    EventSource: string;
    EventName: string;
    InsightType: InsightType;
    ErrorCode?: string;
    StartTime?: Date;
    EndTime?: Date;
    Period?: number;
    DataType?: InsightsMetricDataType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListInsightsMetricDataRequest: S.Schema<ListInsightsMetricDataRequest>;
export type Timestamps = Date[];
export declare const Timestamps: any;
export type InsightsMetricValues = number[];
export declare const InsightsMetricValues: any;
export interface ListInsightsMetricDataResponse {
    TrailARN?: string;
    EventSource?: string;
    EventName?: string;
    InsightType?: InsightType;
    ErrorCode?: string;
    Timestamps?: Date[];
    Values?: number[];
    NextToken?: string;
}
export declare const ListInsightsMetricDataResponse: S.Schema<ListInsightsMetricDataResponse>;
export interface ListPublicKeysRequest {
    StartTime?: Date;
    EndTime?: Date;
    NextToken?: string;
}
export declare const ListPublicKeysRequest: S.Schema<ListPublicKeysRequest>;
export type ByteBuffer = Uint8Array;
export interface PublicKey {
    Value?: Uint8Array;
    ValidityStartTime?: Date;
    ValidityEndTime?: Date;
    Fingerprint?: string;
}
export declare const PublicKey: S.Schema<PublicKey>;
export type PublicKeyList = PublicKey[];
export declare const PublicKeyList: any;
export interface ListPublicKeysResponse {
    PublicKeyList?: PublicKey[];
    NextToken?: string;
}
export declare const ListPublicKeysResponse: S.Schema<ListPublicKeysResponse>;
export type ListQueriesMaxResultsCount = number;
export interface ListQueriesRequest {
    EventDataStore: string;
    NextToken?: string;
    MaxResults?: number;
    StartTime?: Date;
    EndTime?: Date;
    QueryStatus?: QueryStatus;
}
export declare const ListQueriesRequest: S.Schema<ListQueriesRequest>;
export interface Query {
    QueryId?: string;
    QueryStatus?: QueryStatus;
    CreationTime?: Date;
}
export declare const Query: S.Schema<Query>;
export type Queries = Query[];
export declare const Queries: any;
export interface ListQueriesResponse {
    Queries?: Query[];
    NextToken?: string;
}
export declare const ListQueriesResponse: S.Schema<ListQueriesResponse>;
export type ResourceIdList = string[];
export declare const ResourceIdList: any;
export interface ListTagsRequest {
    ResourceIdList: string[];
    NextToken?: string;
}
export declare const ListTagsRequest: S.Schema<ListTagsRequest>;
export interface ResourceTag {
    ResourceId?: string;
    TagsList?: Tag[];
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface ListTagsResponse {
    ResourceTagList?: ResourceTag[];
    NextToken?: string;
}
export declare const ListTagsResponse: S.Schema<ListTagsResponse>;
export interface ListTrailsRequest {
    NextToken?: string;
}
export declare const ListTrailsRequest: S.Schema<ListTrailsRequest>;
export interface TrailInfo {
    TrailARN?: string;
    Name?: string;
    HomeRegion?: string;
}
export declare const TrailInfo: S.Schema<TrailInfo>;
export type Trails = TrailInfo[];
export declare const Trails: any;
export interface ListTrailsResponse {
    Trails?: TrailInfo[];
    NextToken?: string;
}
export declare const ListTrailsResponse: S.Schema<ListTrailsResponse>;
export type LookupAttributeKey = "EventId" | "EventName" | "ReadOnly" | "Username" | "ResourceType" | "ResourceName" | "EventSource" | "AccessKeyId" | (string & {});
export declare const LookupAttributeKey: any;
export type LookupAttributeValue = string;
export interface LookupAttribute {
    AttributeKey: LookupAttributeKey;
    AttributeValue: string;
}
export declare const LookupAttribute: S.Schema<LookupAttribute>;
export type LookupAttributesList = LookupAttribute[];
export declare const LookupAttributesList: any;
export type EventCategory = "insight" | (string & {});
export declare const EventCategory: any;
export type MaxResults = number;
export type NextToken = string;
export interface LookupEventsRequest {
    LookupAttributes?: LookupAttribute[];
    StartTime?: Date;
    EndTime?: Date;
    EventCategory?: EventCategory;
    MaxResults?: number;
    NextToken?: string;
}
export declare const LookupEventsRequest: S.Schema<LookupEventsRequest>;
export interface LookupEventsResponse {
    Events?: Event[];
    NextToken?: string;
}
export declare const LookupEventsResponse: S.Schema<LookupEventsResponse>;
export interface PutEventConfigurationRequest {
    TrailName?: string;
    EventDataStore?: string;
    MaxEventSize?: MaxEventSize;
    ContextKeySelectors?: ContextKeySelector[];
    AggregationConfigurations?: AggregationConfiguration[];
}
export declare const PutEventConfigurationRequest: S.Schema<PutEventConfigurationRequest>;
export interface PutEventConfigurationResponse {
    TrailARN?: string;
    EventDataStoreArn?: string;
    MaxEventSize?: MaxEventSize;
    ContextKeySelectors?: ContextKeySelector[];
    AggregationConfigurations?: AggregationConfiguration[];
}
export declare const PutEventConfigurationResponse: S.Schema<PutEventConfigurationResponse>;
export interface PutEventSelectorsRequest {
    TrailName: string;
    EventSelectors?: EventSelector[];
    AdvancedEventSelectors?: AdvancedEventSelector[];
}
export declare const PutEventSelectorsRequest: S.Schema<PutEventSelectorsRequest>;
export interface PutEventSelectorsResponse {
    TrailARN?: string;
    EventSelectors?: EventSelector[];
    AdvancedEventSelectors?: AdvancedEventSelector[];
}
export declare const PutEventSelectorsResponse: S.Schema<PutEventSelectorsResponse>;
export interface PutInsightSelectorsRequest {
    TrailName?: string;
    InsightSelectors: InsightSelector[];
    EventDataStore?: string;
    InsightsDestination?: string;
}
export declare const PutInsightSelectorsRequest: S.Schema<PutInsightSelectorsRequest>;
export interface PutInsightSelectorsResponse {
    TrailARN?: string;
    InsightSelectors?: InsightSelector[];
    EventDataStoreArn?: string;
    InsightsDestination?: string;
}
export declare const PutInsightSelectorsResponse: S.Schema<PutInsightSelectorsResponse>;
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    ResourcePolicy: string;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResponse {
    ResourceArn?: string;
    ResourcePolicy?: string;
    DelegatedAdminResourcePolicy?: string;
}
export declare const PutResourcePolicyResponse: S.Schema<PutResourcePolicyResponse>;
export interface RegisterOrganizationDelegatedAdminRequest {
    MemberAccountId: string;
}
export declare const RegisterOrganizationDelegatedAdminRequest: S.Schema<RegisterOrganizationDelegatedAdminRequest>;
export interface RegisterOrganizationDelegatedAdminResponse {
}
export declare const RegisterOrganizationDelegatedAdminResponse: S.Schema<RegisterOrganizationDelegatedAdminResponse>;
export interface RemoveTagsRequest {
    ResourceId: string;
    TagsList: Tag[];
}
export declare const RemoveTagsRequest: S.Schema<RemoveTagsRequest>;
export interface RemoveTagsResponse {
}
export declare const RemoveTagsResponse: S.Schema<RemoveTagsResponse>;
export interface RestoreEventDataStoreRequest {
    EventDataStore: string;
}
export declare const RestoreEventDataStoreRequest: S.Schema<RestoreEventDataStoreRequest>;
export interface RestoreEventDataStoreResponse {
    EventDataStoreArn?: string;
    Name?: string;
    Status?: EventDataStoreStatus;
    AdvancedEventSelectors?: AdvancedEventSelector[];
    MultiRegionEnabled?: boolean;
    OrganizationEnabled?: boolean;
    RetentionPeriod?: number;
    TerminationProtectionEnabled?: boolean;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    KmsKeyId?: string;
    BillingMode?: BillingMode;
}
export declare const RestoreEventDataStoreResponse: S.Schema<RestoreEventDataStoreResponse>;
export type SearchSampleQueriesSearchPhrase = string;
export type SearchSampleQueriesMaxResults = number;
export interface SearchSampleQueriesRequest {
    SearchPhrase: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const SearchSampleQueriesRequest: S.Schema<SearchSampleQueriesRequest>;
export type SampleQueryName = string;
export type SampleQueryDescription = string;
export type SampleQuerySQL = string;
export type SampleQueryRelevance = number;
export interface SearchSampleQueriesSearchResult {
    Name?: string;
    Description?: string;
    SQL?: string;
    Relevance?: number;
}
export declare const SearchSampleQueriesSearchResult: S.Schema<SearchSampleQueriesSearchResult>;
export type SearchSampleQueriesSearchResults = SearchSampleQueriesSearchResult[];
export declare const SearchSampleQueriesSearchResults: any;
export interface SearchSampleQueriesResponse {
    SearchResults?: SearchSampleQueriesSearchResult[];
    NextToken?: string;
}
export declare const SearchSampleQueriesResponse: S.Schema<SearchSampleQueriesResponse>;
export type QueryParameterKey = string;
export type QueryParameterValue = string;
export type QueryParameterValues = {
    [key: string]: string | undefined;
};
export declare const QueryParameterValues: any;
export interface StartDashboardRefreshRequest {
    DashboardId: string;
    QueryParameterValues?: {
        [key: string]: string | undefined;
    };
}
export declare const StartDashboardRefreshRequest: S.Schema<StartDashboardRefreshRequest>;
export interface StartDashboardRefreshResponse {
    RefreshId?: string;
}
export declare const StartDashboardRefreshResponse: S.Schema<StartDashboardRefreshResponse>;
export interface StartEventDataStoreIngestionRequest {
    EventDataStore: string;
}
export declare const StartEventDataStoreIngestionRequest: S.Schema<StartEventDataStoreIngestionRequest>;
export interface StartEventDataStoreIngestionResponse {
}
export declare const StartEventDataStoreIngestionResponse: S.Schema<StartEventDataStoreIngestionResponse>;
export interface StartImportRequest {
    Destinations?: string[];
    ImportSource?: ImportSource;
    StartEventTime?: Date;
    EndEventTime?: Date;
    ImportId?: string;
}
export declare const StartImportRequest: S.Schema<StartImportRequest>;
export interface StartImportResponse {
    ImportId?: string;
    Destinations?: string[];
    ImportSource?: ImportSource;
    StartEventTime?: Date;
    EndEventTime?: Date;
    ImportStatus?: ImportStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const StartImportResponse: S.Schema<StartImportResponse>;
export interface StartLoggingRequest {
    Name: string;
}
export declare const StartLoggingRequest: S.Schema<StartLoggingRequest>;
export interface StartLoggingResponse {
}
export declare const StartLoggingResponse: S.Schema<StartLoggingResponse>;
export interface StartQueryRequest {
    QueryStatement?: string;
    DeliveryS3Uri?: string;
    QueryAlias?: string;
    QueryParameters?: string[];
    EventDataStoreOwnerAccountId?: string;
}
export declare const StartQueryRequest: S.Schema<StartQueryRequest>;
export interface StartQueryResponse {
    QueryId?: string;
    EventDataStoreOwnerAccountId?: string;
}
export declare const StartQueryResponse: S.Schema<StartQueryResponse>;
export interface StopEventDataStoreIngestionRequest {
    EventDataStore: string;
}
export declare const StopEventDataStoreIngestionRequest: S.Schema<StopEventDataStoreIngestionRequest>;
export interface StopEventDataStoreIngestionResponse {
}
export declare const StopEventDataStoreIngestionResponse: S.Schema<StopEventDataStoreIngestionResponse>;
export interface StopImportRequest {
    ImportId: string;
}
export declare const StopImportRequest: S.Schema<StopImportRequest>;
export interface StopImportResponse {
    ImportId?: string;
    ImportSource?: ImportSource;
    Destinations?: string[];
    ImportStatus?: ImportStatus;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    StartEventTime?: Date;
    EndEventTime?: Date;
    ImportStatistics?: ImportStatistics;
}
export declare const StopImportResponse: S.Schema<StopImportResponse>;
export interface StopLoggingRequest {
    Name: string;
}
export declare const StopLoggingRequest: S.Schema<StopLoggingRequest>;
export interface StopLoggingResponse {
}
export declare const StopLoggingResponse: S.Schema<StopLoggingResponse>;
export interface UpdateChannelRequest {
    Channel: string;
    Destinations?: Destination[];
    Name?: string;
}
export declare const UpdateChannelRequest: S.Schema<UpdateChannelRequest>;
export interface UpdateChannelResponse {
    ChannelArn?: string;
    Name?: string;
    Source?: string;
    Destinations?: Destination[];
}
export declare const UpdateChannelResponse: S.Schema<UpdateChannelResponse>;
export interface UpdateDashboardRequest {
    DashboardId: string;
    Widgets?: RequestWidget[];
    RefreshSchedule?: RefreshSchedule;
    TerminationProtectionEnabled?: boolean;
}
export declare const UpdateDashboardRequest: S.Schema<UpdateDashboardRequest>;
export interface UpdateDashboardResponse {
    DashboardArn?: string;
    Name?: string;
    Type?: DashboardType;
    Widgets?: Widget[];
    RefreshSchedule?: RefreshSchedule;
    TerminationProtectionEnabled?: boolean;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
}
export declare const UpdateDashboardResponse: S.Schema<UpdateDashboardResponse>;
export interface UpdateEventDataStoreRequest {
    EventDataStore: string;
    Name?: string;
    AdvancedEventSelectors?: AdvancedEventSelector[];
    MultiRegionEnabled?: boolean;
    OrganizationEnabled?: boolean;
    RetentionPeriod?: number;
    TerminationProtectionEnabled?: boolean;
    KmsKeyId?: string;
    BillingMode?: BillingMode;
}
export declare const UpdateEventDataStoreRequest: S.Schema<UpdateEventDataStoreRequest>;
export interface UpdateEventDataStoreResponse {
    EventDataStoreArn?: string;
    Name?: string;
    Status?: EventDataStoreStatus;
    AdvancedEventSelectors?: AdvancedEventSelector[];
    MultiRegionEnabled?: boolean;
    OrganizationEnabled?: boolean;
    RetentionPeriod?: number;
    TerminationProtectionEnabled?: boolean;
    CreatedTimestamp?: Date;
    UpdatedTimestamp?: Date;
    KmsKeyId?: string;
    BillingMode?: BillingMode;
    FederationStatus?: FederationStatus;
    FederationRoleArn?: string;
}
export declare const UpdateEventDataStoreResponse: S.Schema<UpdateEventDataStoreResponse>;
export interface UpdateTrailRequest {
    Name: string;
    S3BucketName?: string;
    S3KeyPrefix?: string;
    SnsTopicName?: string;
    IncludeGlobalServiceEvents?: boolean;
    IsMultiRegionTrail?: boolean;
    EnableLogFileValidation?: boolean;
    CloudWatchLogsLogGroupArn?: string;
    CloudWatchLogsRoleArn?: string;
    KmsKeyId?: string;
    IsOrganizationTrail?: boolean;
}
export declare const UpdateTrailRequest: S.Schema<UpdateTrailRequest>;
export interface UpdateTrailResponse {
    Name?: string;
    S3BucketName?: string;
    S3KeyPrefix?: string;
    SnsTopicName?: string;
    SnsTopicARN?: string;
    IncludeGlobalServiceEvents?: boolean;
    IsMultiRegionTrail?: boolean;
    TrailARN?: string;
    LogFileValidationEnabled?: boolean;
    CloudWatchLogsLogGroupArn?: string;
    CloudWatchLogsRoleArn?: string;
    KmsKeyId?: string;
    IsOrganizationTrail?: boolean;
}
export declare const UpdateTrailResponse: S.Schema<UpdateTrailResponse>;
export type AddTagsError = ChannelARNInvalidException | ChannelNotFoundException | CloudTrailARNInvalidException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidTagParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ResourceNotFoundException | ResourceTypeNotSupportedException | TagsLimitExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Adds one or more tags to a trail, event data store, dashboard, or channel, up to a limit of 50. Overwrites an
 * existing tag's value when a new value is specified for an existing tag key. Tag key names
 * must be unique; you cannot have two keys with the same name but different
 * values. If you specify a key without a value, the tag will be created with the specified
 * key and a value of null. You can tag a trail or event data store that applies to all
 * Amazon Web Services Regions only from the Region in which the trail or event data store
 * was created (also known as its home Region).
 */
export declare const addTags: API.OperationMethod<AddTagsRequest, AddTagsResponse, AddTagsError, Credentials | HttpClient.HttpClient>;
export type CancelQueryError = ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InactiveQueryException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | QueryIdNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Cancels a query if the query is not in a terminated state, such as
 * `CANCELLED`, `FAILED`, `TIMED_OUT`, or
 * `FINISHED`. You must specify an ARN value for `EventDataStore`.
 * The ID of the query that you want to cancel is also required. When you run
 * `CancelQuery`, the query status might show as `CANCELLED` even if
 * the operation is not yet finished.
 */
export declare const cancelQuery: API.OperationMethod<CancelQueryRequest, CancelQueryResponse, CancelQueryError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = ChannelAlreadyExistsException | ChannelMaxLimitExceededException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidEventDataStoreCategoryException | InvalidParameterException | InvalidSourceException | InvalidTagParameterException | OperationNotPermittedException | TagsLimitExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a channel for CloudTrail to ingest events from a partner or external source.
 * After you create a channel, a CloudTrail Lake event data store can log events
 * from the partner or source that you specify.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateDashboardError = ConflictException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidQueryStatementException | InvalidTagParameterException | ServiceQuotaExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a custom dashboard or the Highlights dashboard.
 *
 * - **Custom dashboards** - Custom dashboards allow you to query
 * events in any event data store type. You can add up to 10 widgets to a custom dashboard. You can manually refresh a custom dashboard, or you can set a refresh schedule.
 *
 * - **Highlights dashboard** - You can create
 * the Highlights dashboard to see a summary of key user activities and API usage across all your event data stores.
 * CloudTrail Lake manages the Highlights dashboard and refreshes the dashboard every 6 hours. To create the Highlights dashboard, you must set and enable a refresh schedule.
 *
 * CloudTrail runs queries to populate the dashboard's widgets during a manual or scheduled refresh. CloudTrail must be granted permissions to run the `StartQuery` operation on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to each event data store. For more information,
 * see Example: Allow CloudTrail to run queries to populate a dashboard in the *CloudTrail User Guide*.
 *
 * To set a refresh schedule, CloudTrail must be granted permissions to run the `StartDashboardRefresh` operation to refresh the dashboard on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to the dashboard. For more information,
 * see
 * Resource-based policy example for a dashboard in the *CloudTrail User Guide*.
 *
 * For more information about dashboards, see CloudTrail Lake dashboards in the *CloudTrail User Guide*.
 */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest, CreateDashboardResponse, CreateDashboardError, Credentials | HttpClient.HttpClient>;
export type CreateEventDataStoreError = CloudTrailAccessNotEnabledException | ConflictException | EventDataStoreAlreadyExistsException | EventDataStoreMaxLimitExceededException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InvalidEventSelectorsException | InvalidKmsKeyIdException | InvalidParameterException | InvalidTagParameterException | KmsException | KmsKeyNotFoundException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | ThrottlingException | UnsupportedOperationException | CloudTrailLakeOnboardingClosed | CommonErrors;
/**
 * Creates a new event data store.
 */
export declare const createEventDataStore: API.OperationMethod<CreateEventDataStoreRequest, CreateEventDataStoreResponse, CreateEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type CreateTrailError = CloudTrailAccessNotEnabledException | CloudTrailInvalidClientTokenIdException | CloudWatchLogsDeliveryUnavailableException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InsufficientSnsTopicPolicyException | InvalidCloudWatchLogsLogGroupArnException | InvalidCloudWatchLogsRoleArnException | InvalidKmsKeyIdException | InvalidParameterCombinationException | InvalidParameterException | InvalidS3BucketNameException | InvalidS3PrefixException | InvalidSnsTopicNameException | InvalidTagParameterException | InvalidTrailNameException | KmsException | KmsKeyDisabledException | KmsKeyNotFoundException | MaximumNumberOfTrailsExceededException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | S3BucketDoesNotExistException | TagsLimitExceededException | ThrottlingException | TrailAlreadyExistsException | TrailNotProvidedException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a trail that specifies the settings for delivery of log data to an Amazon S3 bucket.
 */
export declare const createTrail: API.OperationMethod<CreateTrailRequest, CreateTrailResponse, CreateTrailError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = ChannelARNInvalidException | ChannelNotFoundException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a channel.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardError = ConflictException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified dashboard. You cannot delete a dashboard that has termination protection enabled.
 */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest, DeleteDashboardResponse, DeleteDashboardError, Credentials | HttpClient.HttpClient>;
export type DeleteEventDataStoreError = ChannelExistsForEDSException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreFederationEnabledException | EventDataStoreHasOngoingImportException | EventDataStoreNotFoundException | EventDataStoreTerminationProtectedException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Disables the event data store specified by `EventDataStore`, which accepts an
 * event data store ARN. After you run `DeleteEventDataStore`, the event data store
 * enters a `PENDING_DELETION` state, and is automatically deleted after a wait
 * period of seven days. `TerminationProtectionEnabled` must be set to
 * `False` on the event data store and the `FederationStatus` must be `DISABLED`.
 * You cannot delete an event data store if `TerminationProtectionEnabled`
 * is `True` or the `FederationStatus` is `ENABLED`.
 *
 * After you run `DeleteEventDataStore` on an event data store, you cannot run
 * `ListQueries`, `DescribeQuery`, or `GetQueryResults` on
 * queries that are using an event data store in a `PENDING_DELETION` state. An
 * event data store in the `PENDING_DELETION` state does not incur costs.
 */
export declare const deleteEventDataStore: API.OperationMethod<DeleteEventDataStoreRequest, DeleteEventDataStoreResponse, DeleteEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = ConflictException | OperationNotPermittedException | ResourceARNNotValidException | ResourceNotFoundException | ResourcePolicyNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the resource-based policy attached to the CloudTrail event data store, dashboard, or channel.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTrailError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a trail. This operation must be called from the Region in which the trail was
 * created. `DeleteTrail` cannot be called on the shadow trails (replicated trails
 * in other Regions) of a trail that is enabled in all Regions.
 *
 * While deleting a CloudTrail trail is an irreversible action, CloudTrail does not
 * delete log files in the Amazon S3 bucket for that trail, the Amazon S3 bucket itself, or the
 * CloudWatchlog group to which the trail delivers events. Deleting a multi-Region trail
 * will stop logging of events in all Amazon Web Services Regions enabled in your Amazon Web Services account. Deleting a
 * single-Region trail will stop logging of events in that Region only. It will not stop
 * logging of events in other Regions even if the trails in those other Regions have
 * identical names to the deleted trail.
 *
 * For information about account closure and deletion of CloudTrail trails, see https://docs.aws.amazon.com/awscloudtrail/latest/userguide/cloudtrail-account-closure.html.
 */
export declare const deleteTrail: API.OperationMethod<DeleteTrailRequest, DeleteTrailResponse, DeleteTrailError, Credentials | HttpClient.HttpClient>;
export type DeregisterOrganizationDelegatedAdminError = AccountNotFoundException | AccountNotRegisteredException | CloudTrailAccessNotEnabledException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NotOrganizationManagementAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * Removes CloudTrail delegated administrator permissions from a member account in
 * an organization.
 */
export declare const deregisterOrganizationDelegatedAdmin: API.OperationMethod<DeregisterOrganizationDelegatedAdminRequest, DeregisterOrganizationDelegatedAdminResponse, DeregisterOrganizationDelegatedAdminError, Credentials | HttpClient.HttpClient>;
export type DescribeQueryError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | QueryIdNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Returns metadata about a query, including query run time in milliseconds, number of
 * events scanned and matched, and query status. If the query results were delivered to an S3 bucket,
 * the response also provides the S3 URI and the delivery status.
 *
 * You must specify either `QueryId` or `QueryAlias`. Specifying the `QueryAlias` parameter
 * returns information about the last query run for the alias. You can provide
 * `RefreshId` along with `QueryAlias` to view the query results
 * of a dashboard query for the specified `RefreshId`.
 */
export declare const describeQuery: API.OperationMethod<DescribeQueryRequest, DescribeQueryResponse, DescribeQueryError, Credentials | HttpClient.HttpClient>;
export type DescribeTrailsError = CloudTrailARNInvalidException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves settings for one or more trails associated with the current Region for your
 * account.
 */
export declare const describeTrails: API.OperationMethod<DescribeTrailsRequest, DescribeTrailsResponse, DescribeTrailsError, Credentials | HttpClient.HttpClient>;
export type DisableFederationError = AccessDeniedException | CloudTrailAccessNotEnabledException | ConcurrentModificationException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * Disables Lake query federation on the specified event data store. When you disable federation, CloudTrail disables
 * the integration with Glue, Lake Formation, and Amazon Athena.
 * After disabling Lake query federation, you can no longer query your event data in Amazon Athena.
 *
 * No CloudTrail Lake data is deleted when you disable federation and you can continue to run queries in CloudTrail Lake.
 */
export declare const disableFederation: API.OperationMethod<DisableFederationRequest, DisableFederationResponse, DisableFederationError, Credentials | HttpClient.HttpClient>;
export type EnableFederationError = AccessDeniedException | CloudTrailAccessNotEnabledException | ConcurrentModificationException | EventDataStoreARNInvalidException | EventDataStoreFederationEnabledException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * Enables Lake query federation on the specified event data store. Federating an event data store lets you view the metadata associated with the event data store in the Glue
 * Data Catalog and run
 * SQL queries against your event data using Amazon Athena. The table metadata stored in the Glue Data Catalog
 * lets the Athena query engine know how to find, read, and process the data that you want to query.
 *
 * When you enable Lake query federation, CloudTrail
 * creates a managed database named `aws:cloudtrail` (if the database doesn't already exist) and a managed federated table in
 * the Glue Data Catalog. The event data store ID is used for the table name. CloudTrail registers the role ARN and event data store in
 * Lake Formation, the service responsible for allowing fine-grained access control
 * of the federated resources in the Glue Data Catalog.
 *
 * For more information about Lake query federation, see Federate an event data store.
 */
export declare const enableFederation: API.OperationMethod<EnableFederationRequest, EnableFederationResponse, EnableFederationError, Credentials | HttpClient.HttpClient>;
export type GenerateQueryError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | GenerateResponseException | InactiveEventDataStoreException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Generates a query from a natural language prompt. This operation uses generative artificial intelligence
 * (generative AI) to produce a ready-to-use SQL query from the prompt.
 *
 * The prompt can be a question or a statement about the event data
 * in your event data store. For example, you can enter prompts like "What are my
 * top errors in the past month?" and “Give me a list of users that used SNS.”
 *
 * The prompt must be in English. For information about limitations, permissions, and supported Regions, see
 * Create CloudTrail Lake queries from natural language prompts
 * in the *CloudTrail * user guide.
 *
 * Do not include any personally identifying, confidential, or sensitive information
 * in your prompts.
 *
 * This feature uses generative AI large language models (LLMs); we recommend double-checking the
 * LLM response.
 */
export declare const generateQuery: API.OperationMethod<GenerateQueryRequest, GenerateQueryResponse, GenerateQueryError, Credentials | HttpClient.HttpClient>;
export type GetChannelError = ChannelARNInvalidException | ChannelNotFoundException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns information about a specific channel.
 */
export declare const getChannel: API.OperationMethod<GetChannelRequest, GetChannelResponse, GetChannelError, Credentials | HttpClient.HttpClient>;
export type GetDashboardError = ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Returns the specified dashboard.
 */
export declare const getDashboard: API.OperationMethod<GetDashboardRequest, GetDashboardResponse, GetDashboardError, Credentials | HttpClient.HttpClient>;
export type GetEventConfigurationError = CloudTrailARNInvalidException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the current event configuration settings for the specified event data store or trail. The response includes maximum event size configuration, the context key selectors configured for the event data store, and any aggregation settings configured for the trail.
 */
export declare const getEventConfiguration: API.OperationMethod<GetEventConfigurationRequest, GetEventConfigurationResponse, GetEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetEventDataStoreError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns information about an event data store specified as either an ARN or the ID
 * portion of the ARN.
 */
export declare const getEventDataStore: API.OperationMethod<GetEventDataStoreRequest, GetEventDataStoreResponse, GetEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type GetEventSelectorsError = CloudTrailARNInvalidException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Describes the settings for the event selectors that you configured for your trail. The
 * information returned for your event selectors includes the following:
 *
 * - If your event selector includes read-only events, write-only events, or all
 * events. This applies to management events, data events, and network activity events.
 *
 * - If your event selector includes management events.
 *
 * - If your event selector includes network activity events, the event sources
 * for which you are logging network activity events.
 *
 * - If your event selector includes data events, the resources on which you are
 * logging data events.
 *
 * For more information about logging management, data, and network activity events, see the following topics
 * in the *CloudTrail User Guide*:
 *
 * - Logging management events
 *
 * - Logging data events
 *
 * - Logging network activity events
 */
export declare const getEventSelectors: API.OperationMethod<GetEventSelectorsRequest, GetEventSelectorsResponse, GetEventSelectorsError, Credentials | HttpClient.HttpClient>;
export type GetImportError = ImportNotFoundException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns information about a specific import.
 */
export declare const getImport: API.OperationMethod<GetImportRequest, GetImportResponse, GetImportError, Credentials | HttpClient.HttpClient>;
export type GetInsightSelectorsError = CloudTrailARNInvalidException | InsightNotEnabledException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Describes the settings for the Insights event selectors that you configured for your
 * trail or event data store. `GetInsightSelectors` shows if CloudTrail Insights logging is enabled
 * and which Insights types are configured with corresponding event categories. If you run
 * `GetInsightSelectors` on a trail or event data store that does not have Insights events enabled,
 * the operation throws the exception `InsightNotEnabledException`
 *
 * Specify either the `EventDataStore` parameter to get Insights event selectors for an event data store,
 * or the `TrailName` parameter to the get Insights event selectors for a trail. You cannot specify these parameters together.
 *
 * For more information, see Working with CloudTrail Insights in the *CloudTrail User Guide*.
 */
export declare const getInsightSelectors: API.OperationMethod<GetInsightSelectorsRequest, GetInsightSelectorsResponse, GetInsightSelectorsError, Credentials | HttpClient.HttpClient>;
export type GetQueryResultsError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidMaxResultsException | InvalidNextTokenException | InvalidParameterException | NoManagementAccountSLRExistsException | OperationNotPermittedException | QueryIdNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Gets event data results of a query. You must specify the `QueryID` value
 * returned by the `StartQuery` operation.
 */
export declare const getQueryResults: API.PaginatedOperationMethod<GetQueryResultsRequest, GetQueryResultsResponse, GetQueryResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetResourcePolicyError = OperationNotPermittedException | ResourceARNNotValidException | ResourceNotFoundException | ResourcePolicyNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Retrieves the JSON text of the resource-based policy document attached to the CloudTrail event data store, dashboard, or channel.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetTrailError = CloudTrailARNInvalidException | InvalidTrailNameException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Returns settings information for a specified trail.
 */
export declare const getTrail: API.OperationMethod<GetTrailRequest, GetTrailResponse, GetTrailError, Credentials | HttpClient.HttpClient>;
export type GetTrailStatusError = CloudTrailARNInvalidException | InvalidTrailNameException | OperationNotPermittedException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a JSON-formatted list of information about the specified trail. Fields include
 * information on delivery errors, Amazon SNS and Amazon S3 errors, and start
 * and stop logging times for each trail. This operation returns trail status from a single
 * Region. To return trail status from all Regions, you must call the operation on each
 * Region.
 */
export declare const getTrailStatus: API.OperationMethod<GetTrailStatusRequest, GetTrailStatusResponse, GetTrailStatusError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = InvalidNextTokenException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Lists the channels in the current account, and their source names.
 */
export declare const listChannels: API.PaginatedOperationMethod<ListChannelsRequest, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDashboardsError = UnsupportedOperationException | CommonErrors;
/**
 * Returns information about all dashboards in the account, in the current Region.
 */
export declare const listDashboards: API.OperationMethod<ListDashboardsRequest, ListDashboardsResponse, ListDashboardsError, Credentials | HttpClient.HttpClient>;
export type ListEventDataStoresError = InvalidMaxResultsException | InvalidNextTokenException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns information about all event data stores in the account, in the current
 * Region.
 */
export declare const listEventDataStores: API.PaginatedOperationMethod<ListEventDataStoresRequest, ListEventDataStoresResponse, ListEventDataStoresError, Credentials | HttpClient.HttpClient, unknown>;
export type ListImportFailuresError = InvalidNextTokenException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a list of failures for the specified import.
 */
export declare const listImportFailures: API.PaginatedOperationMethod<ListImportFailuresRequest, ListImportFailuresResponse, ListImportFailuresError, Credentials | HttpClient.HttpClient, ImportFailureListItem>;
export type ListImportsError = EventDataStoreARNInvalidException | InvalidNextTokenException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns information on all imports, or a select set of imports by
 * `ImportStatus` or `Destination`.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsRequest, ListImportsResponse, ListImportsError, Credentials | HttpClient.HttpClient, ImportsListItem>;
export type ListInsightsDataError = InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns Insights events generated on a trail that logs data events. You can list Insights events that occurred in a Region within the last 90 days.
 *
 * ListInsightsData supports the following Dimensions for Insights events:
 *
 * - Event ID
 *
 * - Event name
 *
 * - Event source
 *
 * All dimensions are optional. The default number of results returned is 50, with a
 * maximum of 50 possible. The response includes a token that you can use to get the next page
 * of results.
 *
 * The rate of ListInsightsData requests is limited to two per second, per account, per Region. If
 * this limit is exceeded, a throttling error occurs.
 */
export declare const listInsightsData: API.PaginatedOperationMethod<ListInsightsDataRequest, ListInsightsDataResponse, ListInsightsDataError, Credentials | HttpClient.HttpClient, Event>;
export type ListInsightsMetricDataError = InvalidParameterException | InvalidTrailNameException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns Insights metrics data for trails that have enabled Insights. The request must include the `EventSource`,
 * `EventName`, and `InsightType` parameters.
 *
 * If the `InsightType` is set to `ApiErrorRateInsight`, the request must also include the `ErrorCode` parameter.
 *
 * The following are the available time periods for `ListInsightsMetricData`. Each cutoff is inclusive.
 *
 * - Data points with a period of 60 seconds (1-minute) are available for 15 days.
 *
 * - Data points with a period of 300 seconds (5-minute) are available for 63 days.
 *
 * - Data points with a period of 3600 seconds (1 hour) are available for 90 days.
 *
 * To use `ListInsightsMetricData` operation, you must have the following permissions:
 *
 * - If `ListInsightsMetricData` is invoked with `TrailName` parameter, access to the `ListInsightsMetricData` API operation is linked to the `cloudtrail:LookupEvents` action and `cloudtrail:ListInsightsData`. To use this operation,
 * you must have permissions to perform the `cloudtrail:LookupEvents` and `cloudtrail:ListInsightsData` action on the specific trail.
 *
 * - If `ListInsightsMetricData` is invoked without `TrailName` parameter, access to the `ListInsightsMetricData` API operation is linked to the `cloudtrail:LookupEvents` action only. To use this operation,
 * you must have permissions to perform the `cloudtrail:LookupEvents` action.
 */
export declare const listInsightsMetricData: API.PaginatedOperationMethod<ListInsightsMetricDataRequest, ListInsightsMetricDataResponse, ListInsightsMetricDataError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPublicKeysError = InvalidTimeRangeException | InvalidTokenException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns all public keys whose private keys were used to sign the digest files within the
 * specified time range. The public key is needed to validate digest files that were signed
 * with its corresponding private key.
 *
 * CloudTrail uses different private and public key pairs per Region. Each digest
 * file is signed with a private key unique to its Region. When you validate a digest file
 * from a specific Region, you must look in the same Region for its corresponding public
 * key.
 */
export declare const listPublicKeys: API.PaginatedOperationMethod<ListPublicKeysRequest, ListPublicKeysResponse, ListPublicKeysError, Credentials | HttpClient.HttpClient, PublicKey>;
export type ListQueriesError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidDateRangeException | InvalidMaxResultsException | InvalidNextTokenException | InvalidParameterException | InvalidQueryStatusException | NoManagementAccountSLRExistsException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Returns a list of queries and query statuses for the past seven days. You must specify
 * an ARN value for `EventDataStore`. Optionally, to shorten the list of results,
 * you can specify a time range, formatted as timestamps, by adding `StartTime` and
 * `EndTime` parameters, and a `QueryStatus` value. Valid values for
 * `QueryStatus` include `QUEUED`, `RUNNING`,
 * `FINISHED`, `FAILED`, `TIMED_OUT`, or
 * `CANCELLED`.
 */
export declare const listQueries: API.PaginatedOperationMethod<ListQueriesRequest, ListQueriesResponse, ListQueriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsError = ChannelARNInvalidException | CloudTrailARNInvalidException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidTokenException | InvalidTrailNameException | NoManagementAccountSLRExistsException | OperationNotPermittedException | ResourceNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Lists the tags for the specified trails, event data stores, dashboards, or channels in the current Region.
 */
export declare const listTags: API.PaginatedOperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient, ResourceTag>;
export type ListTrailsError = OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Lists trails that are in the current account.
 */
export declare const listTrails: API.PaginatedOperationMethod<ListTrailsRequest, ListTrailsResponse, ListTrailsError, Credentials | HttpClient.HttpClient, TrailInfo>;
export type LookupEventsError = InvalidEventCategoryException | InvalidLookupAttributesException | InvalidMaxResultsException | InvalidNextTokenException | InvalidTimeRangeException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Looks up management events or CloudTrail Insights events that are captured by CloudTrail.
 * You can look up events that occurred in a Region within the last 90 days.
 *
 * `LookupEvents` returns recent Insights events for trails that enable Insights. To view Insights events for an event data store, you can run queries on your
 * Insights event data store, and you can also view the Lake dashboard for Insights.
 *
 * Lookup supports the following attributes for management events:
 *
 * - Amazon Web Services access key
 *
 * - Event ID
 *
 * - Event name
 *
 * - Event source
 *
 * - Read only
 *
 * - Resource name
 *
 * - Resource type
 *
 * - User name
 *
 * Lookup supports the following attributes for Insights events:
 *
 * - Event ID
 *
 * - Event name
 *
 * - Event source
 *
 * All attributes are optional. The default number of results returned is 50, with a
 * maximum of 50 possible. The response includes a token that you can use to get the next page
 * of results.
 *
 * The rate of lookup requests is limited to two per second, per account, per Region. If
 * this limit is exceeded, a throttling error occurs.
 */
export declare const lookupEvents: API.PaginatedOperationMethod<LookupEventsRequest, LookupEventsResponse, LookupEventsError, Credentials | HttpClient.HttpClient, Event>;
export type PutEventConfigurationError = CloudTrailARNInvalidException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InsufficientIAMAccessPermissionException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidHomeRegionException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Updates the event configuration settings for the specified event data store or trail. This operation supports updating the maximum event size, adding or modifying context key selectors for event data store, and configuring aggregation settings for the trail.
 */
export declare const putEventConfiguration: API.OperationMethod<PutEventConfigurationRequest, PutEventConfigurationResponse, PutEventConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutEventSelectorsError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidEventSelectorsException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Configures event selectors (also referred to as *basic event selectors*) or advanced event selectors for your trail. You can use
 * either `AdvancedEventSelectors` or `EventSelectors`, but not both. If
 * you apply `AdvancedEventSelectors` to a trail, any existing
 * `EventSelectors` are overwritten.
 *
 * You can use `AdvancedEventSelectors` to
 * log management events, data events for all resource types, and network activity events.
 *
 * You can use `EventSelectors` to log management events and data events for the following resource types:
 *
 * - `AWS::DynamoDB::Table`
 *
 * - `AWS::Lambda::Function`
 *
 * - `AWS::S3::Object`
 *
 * You can't use `EventSelectors` to log network activity events.
 *
 * If you want your trail to log Insights events, be sure the event selector or advanced event selector enables
 * logging of the Insights event types you want configured for your trail. For more information about logging Insights events, see Working with CloudTrail Insights in the *CloudTrail User Guide*.
 * By default, trails created without specific event selectors are configured to
 * log all read and write management events, and no data events or network activity events.
 *
 * When an event occurs in your account, CloudTrail evaluates the event selectors or
 * advanced event selectors in all trails. For each trail, if the event matches any event
 * selector, the trail processes and logs the event. If the event doesn't match any event
 * selector, the trail doesn't log the event.
 *
 * Example
 *
 * - You create an event selector for a trail and specify that you want to log write-only
 * events.
 *
 * - The EC2 `GetConsoleOutput` and `RunInstances` API operations
 * occur in your account.
 *
 * - CloudTrail evaluates whether the events match your event selectors.
 *
 * - The `RunInstances` is a write-only event and it matches your event
 * selector. The trail logs the event.
 *
 * - The `GetConsoleOutput` is a read-only event that doesn't match your
 * event selector. The trail doesn't log the event.
 *
 * The `PutEventSelectors` operation must be called from the Region in which the
 * trail was created; otherwise, an `InvalidHomeRegionException` exception is
 * thrown.
 *
 * You can configure up to five event selectors for each trail.
 *
 * You can add advanced event selectors, and conditions for your advanced event selectors,
 * up to a maximum of 500 values for all conditions and selectors on a trail. For more information, see
 * Logging management events, Logging
 * data events, Logging
 * network activity events, and Quotas in CloudTrail in the CloudTrail User
 * Guide.
 */
export declare const putEventSelectors: API.OperationMethod<PutEventSelectorsRequest, PutEventSelectorsResponse, PutEventSelectorsError, Credentials | HttpClient.HttpClient>;
export type PutInsightSelectorsError = CloudTrailARNInvalidException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InvalidHomeRegionException | InvalidInsightSelectorsException | InvalidParameterCombinationException | InvalidParameterException | InvalidTrailNameException | KmsException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | S3BucketDoesNotExistException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Lets you enable Insights event logging on specific event categories by specifying the Insights selectors that you
 * want to enable on an existing trail or event data store. You also use `PutInsightSelectors` to turn
 * off Insights event logging, by passing an empty list of Insights types. The valid Insights
 * event types are `ApiErrorRateInsight` and
 * `ApiCallRateInsight`, and valid EventCategories are `Management` and `Data`.
 *
 * Insights on data events are not supported on event data stores. For event data stores, you can only enable Insights on management events.
 *
 * To enable Insights on an event data store, you must specify the ARNs (or ID suffix of the ARNs) for the source event data store (`EventDataStore`) and the destination event data store (`InsightsDestination`). The source event data store logs management events and enables Insights.
 * The destination event data store logs Insights events based upon the management event activity of the source event data store. The source and destination event data stores must belong to the same Amazon Web Services account.
 *
 * To log Insights events for a trail, you must specify the name (`TrailName`) of the CloudTrail trail for which you want to change or add Insights
 * selectors.
 *
 * - For Management events Insights: To log CloudTrail Insights on the API call rate, the trail or event data store must log `write` management events.
 * To log CloudTrail Insights on the API error rate, the trail or event data store must log `read` or `write` management events.
 *
 * - For Data events Insights: To log CloudTrail Insights on the API call rate or API error rate, the trail must log `read` or `write` data events. Data events Insights are not supported on event data store.
 *
 * To log CloudTrail Insights events on API call volume, the trail or event data store
 * must log `write` management events. To log CloudTrail
 * Insights events on API error rate, the trail or event data store must log `read` or
 * `write` management events. You can call `GetEventSelectors` on a trail
 * to check whether the trail logs management events. You can call `GetEventDataStore` on an
 * event data store to check whether the event data store logs management events.
 *
 * For more information, see Working with CloudTrail Insights in the *CloudTrail User Guide*.
 */
export declare const putInsightSelectors: API.OperationMethod<PutInsightSelectorsRequest, PutInsightSelectorsResponse, PutInsightSelectorsError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = ConflictException | OperationNotPermittedException | ResourceARNNotValidException | ResourceNotFoundException | ResourcePolicyNotValidException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Attaches a resource-based permission policy to a CloudTrail event data store, dashboard, or channel. For more information about resource-based policies, see
 * CloudTrail resource-based policy examples
 * in the *CloudTrail User Guide*.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type RegisterOrganizationDelegatedAdminError = AccountNotFoundException | AccountRegisteredException | CannotDelegateManagementAccountException | CloudTrailAccessNotEnabledException | ConflictException | DelegatedAdminAccountLimitExceededException | InsufficientDependencyServiceAccessPermissionException | InsufficientIAMAccessPermissionException | InvalidParameterException | NotOrganizationManagementAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * Registers an organization’s member account as the CloudTrail delegated administrator.
 */
export declare const registerOrganizationDelegatedAdmin: API.OperationMethod<RegisterOrganizationDelegatedAdminRequest, RegisterOrganizationDelegatedAdminResponse, RegisterOrganizationDelegatedAdminError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = ChannelARNInvalidException | ChannelNotFoundException | CloudTrailARNInvalidException | ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidTagParameterException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ResourceNotFoundException | ResourceTypeNotSupportedException | UnsupportedOperationException | CommonErrors;
/**
 * Removes the specified tags from a trail, event data store, dashboard, or channel.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsRequest, RemoveTagsResponse, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type RestoreEventDataStoreError = CloudTrailAccessNotEnabledException | EventDataStoreARNInvalidException | EventDataStoreMaxLimitExceededException | EventDataStoreNotFoundException | InsufficientDependencyServiceAccessPermissionException | InvalidEventDataStoreStatusException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | UnsupportedOperationException | CommonErrors;
/**
 * Restores a deleted event data store specified by `EventDataStore`, which
 * accepts an event data store ARN. You can only restore a deleted event data store within the
 * seven-day wait period after deletion. Restoring an event data store can take several
 * minutes, depending on the size of the event data store.
 */
export declare const restoreEventDataStore: API.OperationMethod<RestoreEventDataStoreRequest, RestoreEventDataStoreResponse, RestoreEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type SearchSampleQueriesError = InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Searches sample queries and returns a list of sample queries that are sorted by relevance.
 * To search for sample queries, provide a natural language `SearchPhrase` in English.
 */
export declare const searchSampleQueries: API.OperationMethod<SearchSampleQueriesRequest, SearchSampleQueriesResponse, SearchSampleQueriesError, Credentials | HttpClient.HttpClient>;
export type StartDashboardRefreshError = EventDataStoreNotFoundException | InactiveEventDataStoreException | ResourceNotFoundException | ServiceQuotaExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Starts a refresh of the specified dashboard.
 *
 * Each time a dashboard is refreshed, CloudTrail runs queries to populate the dashboard's widgets. CloudTrail must be granted permissions to run the `StartQuery` operation on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to each event data store. For more information,
 * see Example: Allow CloudTrail to run queries to populate a dashboard in the *CloudTrail User Guide*.
 */
export declare const startDashboardRefresh: API.OperationMethod<StartDashboardRefreshRequest, StartDashboardRefreshResponse, StartDashboardRefreshError, Credentials | HttpClient.HttpClient>;
export type StartEventDataStoreIngestionError = ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InsufficientDependencyServiceAccessPermissionException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Starts the ingestion of live events on an event data store specified as either an ARN or the ID portion of the ARN. To start ingestion, the event data store `Status` must be `STOPPED_INGESTION`
 * and the `eventCategory` must be `Management`, `Data`, `NetworkActivity`, or `ConfigurationItem`.
 */
export declare const startEventDataStoreIngestion: API.OperationMethod<StartEventDataStoreIngestionRequest, StartEventDataStoreIngestionResponse, StartEventDataStoreIngestionError, Credentials | HttpClient.HttpClient>;
export type StartImportError = AccountHasOngoingImportException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | ImportNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidImportSourceException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Starts an import of logged trail events from a source S3 bucket to a destination event
 * data store. By default, CloudTrail only imports events contained in the S3 bucket's
 * `CloudTrail` prefix and the prefixes inside the `CloudTrail` prefix, and does not check prefixes for other Amazon Web Services
 * services. If you want to import CloudTrail events contained in another prefix, you
 * must include the prefix in the `S3LocationUri`. For more considerations about
 * importing trail events, see Considerations for copying trail events in the *CloudTrail User Guide*.
 *
 * When you start a new import, the `Destinations` and
 * `ImportSource` parameters are required. Before starting a new import, disable
 * any access control lists (ACLs) attached to the source S3 bucket. For more information
 * about disabling ACLs, see Controlling ownership of
 * objects and disabling ACLs for your bucket.
 *
 * When you retry an import, the `ImportID` parameter is required.
 *
 * If the destination event data store is for an organization, you must use the
 * management account to import trail events. You cannot use the delegated administrator
 * account for the organization.
 */
export declare const startImport: API.OperationMethod<StartImportRequest, StartImportResponse, StartImportError, Credentials | HttpClient.HttpClient>;
export type StartLoggingError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Starts the recording of Amazon Web Services API calls and log file delivery for a trail.
 * For a trail that is enabled in all Regions, this operation must be called from the Region
 * in which the trail was created. This operation cannot be called on the shadow trails
 * (replicated trails in other Regions) of a trail that is enabled in all Regions.
 */
export declare const startLogging: API.OperationMethod<StartLoggingRequest, StartLoggingResponse, StartLoggingError, Credentials | HttpClient.HttpClient>;
export type StartQueryError = EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InvalidParameterException | InvalidQueryStatementException | InvalidS3BucketNameException | InvalidS3PrefixException | MaxConcurrentQueriesException | NoManagementAccountSLRExistsException | OperationNotPermittedException | S3BucketDoesNotExistException | UnsupportedOperationException | CommonErrors;
/**
 * Starts a CloudTrail Lake query. Use the `QueryStatement`
 * parameter to provide your SQL query, enclosed in single quotation marks. Use the optional
 * `DeliveryS3Uri` parameter to deliver the query results to an S3
 * bucket.
 *
 * `StartQuery` requires you specify either the `QueryStatement` parameter, or a `QueryAlias` and any `QueryParameters`. In the current release,
 * the `QueryAlias` and `QueryParameters` parameters are used only for the queries that populate the CloudTrail Lake dashboards.
 */
export declare const startQuery: API.OperationMethod<StartQueryRequest, StartQueryResponse, StartQueryError, Credentials | HttpClient.HttpClient>;
export type StopEventDataStoreIngestionError = ConflictException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InsufficientDependencyServiceAccessPermissionException | InvalidEventDataStoreCategoryException | InvalidEventDataStoreStatusException | InvalidParameterException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Stops the ingestion of live events on an event data store specified as either an ARN or the ID portion of the ARN. To stop ingestion, the event data store `Status` must be `ENABLED`
 * and the `eventCategory` must be `Management`, `Data`, `NetworkActivity`, or `ConfigurationItem`.
 */
export declare const stopEventDataStoreIngestion: API.OperationMethod<StopEventDataStoreIngestionRequest, StopEventDataStoreIngestionResponse, StopEventDataStoreIngestionError, Credentials | HttpClient.HttpClient>;
export type StopImportError = ImportNotFoundException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Stops a specified import.
 */
export declare const stopImport: API.OperationMethod<StopImportRequest, StopImportResponse, StopImportError, Credentials | HttpClient.HttpClient>;
export type StopLoggingError = CloudTrailARNInvalidException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InvalidHomeRegionException | InvalidTrailNameException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | ThrottlingException | TrailNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * Suspends the recording of Amazon Web Services API calls and log file delivery for the
 * specified trail. Under most circumstances, there is no need to use this action. You can
 * update a trail without stopping it first. This action is the only way to stop recording.
 * For a trail enabled in all Regions, this operation must be called from the Region in which
 * the trail was created, or an `InvalidHomeRegionException` will occur. This
 * operation cannot be called on the shadow trails (replicated trails in other Regions) of a
 * trail enabled in all Regions.
 */
export declare const stopLogging: API.OperationMethod<StopLoggingRequest, StopLoggingResponse, StopLoggingError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = ChannelAlreadyExistsException | ChannelARNInvalidException | ChannelNotFoundException | EventDataStoreARNInvalidException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InvalidEventDataStoreCategoryException | InvalidParameterException | OperationNotPermittedException | UnsupportedOperationException | CommonErrors;
/**
 * Updates a channel specified by a required channel ARN or UUID.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardError = ConflictException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientEncryptionPolicyException | InvalidQueryStatementException | ResourceNotFoundException | ServiceQuotaExceededException | UnsupportedOperationException | CommonErrors;
/**
 * Updates the specified dashboard.
 *
 * To set a refresh schedule, CloudTrail must be granted permissions to run the `StartDashboardRefresh` operation to refresh the dashboard on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to the dashboard. For more information,
 * see
 * Resource-based policy example for a dashboard in the *CloudTrail User Guide*.
 *
 * CloudTrail runs queries to populate the dashboard's widgets during a manual or scheduled refresh. CloudTrail must be granted permissions to run the `StartQuery` operation on your behalf. To provide permissions, run the `PutResourcePolicy` operation to attach a resource-based policy to each event data store. For more information,
 * see Example: Allow CloudTrail to run queries to populate a dashboard in the *CloudTrail User Guide*.
 */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest, UpdateDashboardResponse, UpdateDashboardError, Credentials | HttpClient.HttpClient>;
export type UpdateEventDataStoreError = CloudTrailAccessNotEnabledException | ConflictException | EventDataStoreAlreadyExistsException | EventDataStoreARNInvalidException | EventDataStoreHasOngoingImportException | EventDataStoreNotFoundException | InactiveEventDataStoreException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InvalidEventSelectorsException | InvalidInsightSelectorsException | InvalidKmsKeyIdException | InvalidParameterException | KmsException | KmsKeyNotFoundException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | ThrottlingException | UnsupportedOperationException | CommonErrors;
/**
 * Updates an event data store. The required `EventDataStore` value is an ARN or
 * the ID portion of the ARN. Other parameters are optional, but at least one optional
 * parameter must be specified, or CloudTrail throws an error.
 * `RetentionPeriod` is in days, and valid values are integers between 7 and
 * 3653 if the `BillingMode` is set to `EXTENDABLE_RETENTION_PRICING`, or between 7 and 2557 if `BillingMode` is set to `FIXED_RETENTION_PRICING`. By default, `TerminationProtection` is enabled.
 *
 * For event data stores for CloudTrail events, `AdvancedEventSelectors`
 * includes or excludes management, data, or network activity events in your event data store. For more
 * information about `AdvancedEventSelectors`, see AdvancedEventSelectors.
 *
 * For event data stores for CloudTrail Insights events, Config configuration items, Audit Manager evidence, or non-Amazon Web Services events,
 * `AdvancedEventSelectors` includes events of that type in your event data store.
 */
export declare const updateEventDataStore: API.OperationMethod<UpdateEventDataStoreRequest, UpdateEventDataStoreResponse, UpdateEventDataStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateTrailError = CloudTrailAccessNotEnabledException | CloudTrailARNInvalidException | CloudTrailInvalidClientTokenIdException | CloudWatchLogsDeliveryUnavailableException | ConflictException | InsufficientDependencyServiceAccessPermissionException | InsufficientEncryptionPolicyException | InsufficientS3BucketPolicyException | InsufficientSnsTopicPolicyException | InvalidCloudWatchLogsLogGroupArnException | InvalidCloudWatchLogsRoleArnException | InvalidEventSelectorsException | InvalidHomeRegionException | InvalidKmsKeyIdException | InvalidParameterCombinationException | InvalidParameterException | InvalidS3BucketNameException | InvalidS3PrefixException | InvalidSnsTopicNameException | InvalidTrailNameException | KmsException | KmsKeyDisabledException | KmsKeyNotFoundException | NoManagementAccountSLRExistsException | NotOrganizationMasterAccountException | OperationNotPermittedException | OrganizationNotInAllFeaturesModeException | OrganizationsNotInUseException | S3BucketDoesNotExistException | ThrottlingException | TrailNotFoundException | TrailNotProvidedException | UnsupportedOperationException | CommonErrors;
/**
 * Updates trail settings that control what events you are logging, and how to handle log
 * files. Changes to a trail do not require stopping the CloudTrail service. Use this
 * action to designate an existing bucket for log delivery. If the existing bucket has
 * previously been a target for CloudTrail log files, an IAM policy
 * exists for the bucket. `UpdateTrail` must be called from the Region in which the
 * trail was created; otherwise, an `InvalidHomeRegionException` is thrown.
 */
export declare const updateTrail: API.OperationMethod<UpdateTrailRequest, UpdateTrailResponse, UpdateTrailError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudtrail.d.ts.map