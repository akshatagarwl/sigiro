import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ReportId = string;
export interface DeleteReportDefinitionRequest {
    reportId: string;
}
export declare const DeleteReportDefinitionRequest: S.Schema<DeleteReportDefinitionRequest>;
export interface DeleteReportDefinitionResult {
    reportId?: string;
}
export declare const DeleteReportDefinitionResult: S.Schema<DeleteReportDefinitionResult>;
export interface GetReportDefinitionRequest {
    reportId: string;
}
export declare const GetReportDefinitionRequest: S.Schema<GetReportDefinitionRequest>;
export type ReportDescription = string;
export type ReportFrequency = "MONTHLY" | "DAILY" | "ALL" | (string & {});
export declare const ReportFrequency: any;
export type Format = "CSV" | "PARQUET" | (string & {});
export declare const Format: any;
export type S3Bucket = string;
export type S3Prefix = string;
export interface S3Location {
    bucket: string;
    prefix: string;
}
export declare const S3Location: S.Schema<S3Location>;
export interface GetReportDefinitionResult {
    reportId: string;
    reportDescription: string;
    reportFrequency: ReportFrequency;
    format: Format;
    destinationS3Location: S3Location;
    createdAt: Date;
    lastUpdated: Date;
}
export declare const GetReportDefinitionResult: S.Schema<GetReportDefinitionResult>;
export type S3Key = string;
export type S3BucketRegion = "ap-east-1" | "me-south-1" | "eu-south-1" | "af-south-1" | (string & {});
export declare const S3BucketRegion: any;
export interface SourceS3Location {
    bucket: string;
    key: string;
    region?: S3BucketRegion;
}
export declare const SourceS3Location: S.Schema<SourceS3Location>;
export interface ImportApplicationUsageRequest {
    sourceS3Location: SourceS3Location;
}
export declare const ImportApplicationUsageRequest: S.Schema<ImportApplicationUsageRequest>;
export type ImportId = string;
export interface ImportApplicationUsageResult {
    importId: string;
}
export declare const ImportApplicationUsageResult: S.Schema<ImportApplicationUsageResult>;
export type Token = string;
export interface ListReportDefinitionsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListReportDefinitionsRequest: S.Schema<ListReportDefinitionsRequest>;
export interface ReportDefinition {
    reportId?: string;
    reportDescription?: string;
    reportFrequency?: ReportFrequency;
    format?: Format;
    destinationS3Location?: S3Location;
    createdAt?: Date;
    lastUpdatedAt?: Date;
}
export declare const ReportDefinition: S.Schema<ReportDefinition>;
export type ReportDefinitionList = ReportDefinition[];
export declare const ReportDefinitionList: any;
export interface ListReportDefinitionsResult {
    reportDefinitions?: ReportDefinition[];
    nextToken?: string;
}
export declare const ListReportDefinitionsResult: S.Schema<ListReportDefinitionsResult>;
export interface PutReportDefinitionRequest {
    reportId: string;
    reportDescription: string;
    reportFrequency: ReportFrequency;
    format: Format;
    destinationS3Location: S3Location;
}
export declare const PutReportDefinitionRequest: S.Schema<PutReportDefinitionRequest>;
export interface PutReportDefinitionResult {
    reportId?: string;
}
export declare const PutReportDefinitionResult: S.Schema<PutReportDefinitionResult>;
export interface UpdateReportDefinitionRequest {
    reportId: string;
    reportDescription: string;
    reportFrequency: ReportFrequency;
    format: Format;
    destinationS3Location: S3Location;
}
export declare const UpdateReportDefinitionRequest: S.Schema<UpdateReportDefinitionRequest>;
export interface UpdateReportDefinitionResult {
    reportId?: string;
}
export declare const UpdateReportDefinitionResult: S.Schema<UpdateReportDefinitionResult>;
export type ErrorMessage = string;
export type DeleteReportDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified report definition in AWS Application Cost Profiler. This stops the report from being
 * generated.
 */
export declare const deleteReportDefinition: API.OperationMethod<DeleteReportDefinitionRequest, DeleteReportDefinitionResult, DeleteReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetReportDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the definition of a report already configured in AWS Application Cost Profiler.
 */
export declare const getReportDefinition: API.OperationMethod<GetReportDefinitionRequest, GetReportDefinitionResult, GetReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type ImportApplicationUsageError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Ingests application usage data from Amazon Simple Storage Service (Amazon S3).
 *
 * The data must already exist in the S3 location. As part of the action, AWS Application Cost Profiler
 * copies the object from your S3 bucket to an S3 bucket owned by Amazon for processing
 * asynchronously.
 */
export declare const importApplicationUsage: API.OperationMethod<ImportApplicationUsageRequest, ImportApplicationUsageResult, ImportApplicationUsageError, Credentials | HttpClient.HttpClient>;
export type ListReportDefinitionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all reports and their configurations for your AWS account.
 *
 * The maximum number of reports is one.
 */
export declare const listReportDefinitions: API.PaginatedOperationMethod<ListReportDefinitionsRequest, ListReportDefinitionsResult, ListReportDefinitionsError, Credentials | HttpClient.HttpClient, ReportDefinition>;
export type PutReportDefinitionError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates the report definition for a report in Application Cost Profiler.
 */
export declare const putReportDefinition: API.OperationMethod<PutReportDefinitionRequest, PutReportDefinitionResult, PutReportDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateReportDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates existing report in AWS Application Cost Profiler.
 */
export declare const updateReportDefinition: API.OperationMethod<UpdateReportDefinitionRequest, UpdateReportDefinitionResult, UpdateReportDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=applicationcostprofiler.d.ts.map