import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const CodeBuildNotInServiceRegionException_base: S.Class<CodeBuildNotInServiceRegionException, S.TaggedStruct<"CodeBuildNotInServiceRegionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeBuildNotInServiceRegionException extends /*@__PURE__*/ CodeBuildNotInServiceRegionException_base {
}
declare const ElasticBeanstalkServiceException_base: S.Class<ElasticBeanstalkServiceException, S.TaggedStruct<"ElasticBeanstalkServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ElasticBeanstalkServiceException extends /*@__PURE__*/ ElasticBeanstalkServiceException_base {
}
declare const InsufficientPrivilegesException_base: S.Class<InsufficientPrivilegesException, S.TaggedStruct<"InsufficientPrivilegesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientPrivilegesException extends /*@__PURE__*/ InsufficientPrivilegesException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ManagedActionInvalidStateException_base: S.Class<ManagedActionInvalidStateException, S.TaggedStruct<"ManagedActionInvalidStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ManagedActionInvalidStateException extends /*@__PURE__*/ ManagedActionInvalidStateException_base {
}
declare const OperationInProgressException_base: S.Class<OperationInProgressException, S.TaggedStruct<"OperationInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationInProgressException extends /*@__PURE__*/ OperationInProgressException_base {
}
declare const PlatformVersionStillReferencedException_base: S.Class<PlatformVersionStillReferencedException, S.TaggedStruct<"PlatformVersionStillReferencedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PlatformVersionStillReferencedException extends /*@__PURE__*/ PlatformVersionStillReferencedException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceTypeNotSupportedException_base: S.Class<ResourceTypeNotSupportedException, S.TaggedStruct<"ResourceTypeNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceTypeNotSupportedException extends /*@__PURE__*/ ResourceTypeNotSupportedException_base {
}
declare const S3LocationNotInServiceRegionException_base: S.Class<S3LocationNotInServiceRegionException, S.TaggedStruct<"S3LocationNotInServiceRegionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class S3LocationNotInServiceRegionException extends /*@__PURE__*/ S3LocationNotInServiceRegionException_base {
}
declare const S3SubscriptionRequiredException_base: S.Class<S3SubscriptionRequiredException, S.TaggedStruct<"S3SubscriptionRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class S3SubscriptionRequiredException extends /*@__PURE__*/ S3SubscriptionRequiredException_base {
}
declare const SourceBundleDeletionException_base: S.Class<SourceBundleDeletionException, S.TaggedStruct<"SourceBundleDeletionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceBundleDeletionException extends /*@__PURE__*/ SourceBundleDeletionException_base {
}
declare const TooManyApplicationsException_base: S.Class<TooManyApplicationsException, S.TaggedStruct<"TooManyApplicationsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyApplicationsException extends /*@__PURE__*/ TooManyApplicationsException_base {
}
declare const TooManyApplicationVersionsException_base: S.Class<TooManyApplicationVersionsException, S.TaggedStruct<"TooManyApplicationVersionsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyApplicationVersionsException extends /*@__PURE__*/ TooManyApplicationVersionsException_base {
}
declare const TooManyBucketsException_base: S.Class<TooManyBucketsException, S.TaggedStruct<"TooManyBucketsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyBucketsException extends /*@__PURE__*/ TooManyBucketsException_base {
}
declare const TooManyConfigurationTemplatesException_base: S.Class<TooManyConfigurationTemplatesException, S.TaggedStruct<"TooManyConfigurationTemplatesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyConfigurationTemplatesException extends /*@__PURE__*/ TooManyConfigurationTemplatesException_base {
}
declare const TooManyEnvironmentsException_base: S.Class<TooManyEnvironmentsException, S.TaggedStruct<"TooManyEnvironmentsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyEnvironmentsException extends /*@__PURE__*/ TooManyEnvironmentsException_base {
}
declare const TooManyPlatformsException_base: S.Class<TooManyPlatformsException, S.TaggedStruct<"TooManyPlatformsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyPlatformsException extends /*@__PURE__*/ TooManyPlatformsException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type EnvironmentId = string;
export type EnvironmentName = string;
export interface AbortEnvironmentUpdateMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export declare const AbortEnvironmentUpdateMessage: S.Schema<AbortEnvironmentUpdateMessage>;
export interface AbortEnvironmentUpdateResponse {
}
export declare const AbortEnvironmentUpdateResponse: S.Schema<AbortEnvironmentUpdateResponse>;
export interface ApplyEnvironmentManagedActionRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    ActionId: string;
}
export declare const ApplyEnvironmentManagedActionRequest: S.Schema<ApplyEnvironmentManagedActionRequest>;
export type ActionType = "InstanceRefresh" | "PlatformUpdate" | "Unknown" | (string & {});
export declare const ActionType: any;
export interface ApplyEnvironmentManagedActionResult {
    ActionId?: string;
    ActionDescription?: string;
    ActionType?: ActionType;
    Status?: string;
}
export declare const ApplyEnvironmentManagedActionResult: S.Schema<ApplyEnvironmentManagedActionResult>;
export type OperationsRole = string;
export interface AssociateEnvironmentOperationsRoleMessage {
    EnvironmentName: string;
    OperationsRole: string;
}
export declare const AssociateEnvironmentOperationsRoleMessage: S.Schema<AssociateEnvironmentOperationsRoleMessage>;
export interface AssociateEnvironmentOperationsRoleResponse {
}
export declare const AssociateEnvironmentOperationsRoleResponse: S.Schema<AssociateEnvironmentOperationsRoleResponse>;
export type DNSCnamePrefix = string;
export interface CheckDNSAvailabilityMessage {
    CNAMEPrefix: string;
}
export declare const CheckDNSAvailabilityMessage: S.Schema<CheckDNSAvailabilityMessage>;
export type CnameAvailability = boolean;
export type DNSCname = string;
export interface CheckDNSAvailabilityResultMessage {
    Available?: boolean;
    FullyQualifiedCNAME?: string;
}
export declare const CheckDNSAvailabilityResultMessage: S.Schema<CheckDNSAvailabilityResultMessage>;
export type ApplicationName = string;
export type GroupName = string;
export type VersionLabel = string;
export type VersionLabels = string[];
export declare const VersionLabels: any;
export interface ComposeEnvironmentsMessage {
    ApplicationName?: string;
    GroupName?: string;
    VersionLabels?: string[];
}
export declare const ComposeEnvironmentsMessage: S.Schema<ComposeEnvironmentsMessage>;
export type SolutionStackName = string;
export type PlatformArn = string;
export type ConfigurationTemplateName = string;
export type Description = string;
export type EndpointURL = string;
export type CreationDate = Date;
export type UpdateDate = Date;
export type EnvironmentStatus = "Aborting" | "Launching" | "Updating" | "LinkingFrom" | "LinkingTo" | "Ready" | "Terminating" | "Terminated" | (string & {});
export declare const EnvironmentStatus: any;
export type AbortableOperationInProgress = boolean;
export type EnvironmentHealth = "Green" | "Yellow" | "Red" | "Grey" | (string & {});
export declare const EnvironmentHealth: any;
export type EnvironmentHealthStatus = "NoData" | "Unknown" | "Pending" | "Ok" | "Info" | "Warning" | "Degraded" | "Severe" | "Suspended" | (string & {});
export declare const EnvironmentHealthStatus: any;
export interface Listener {
    Protocol?: string;
    Port?: number;
}
export declare const Listener: S.Schema<Listener>;
export type LoadBalancerListenersDescription = Listener[];
export declare const LoadBalancerListenersDescription: any;
export interface LoadBalancerDescription {
    LoadBalancerName?: string;
    Domain?: string;
    Listeners?: Listener[];
}
export declare const LoadBalancerDescription: S.Schema<LoadBalancerDescription>;
export interface EnvironmentResourcesDescription {
    LoadBalancer?: LoadBalancerDescription;
}
export declare const EnvironmentResourcesDescription: S.Schema<EnvironmentResourcesDescription>;
export interface EnvironmentTier {
    Name?: string;
    Type?: string;
    Version?: string;
}
export declare const EnvironmentTier: S.Schema<EnvironmentTier>;
export interface EnvironmentLink {
    LinkName?: string;
    EnvironmentName?: string;
}
export declare const EnvironmentLink: S.Schema<EnvironmentLink>;
export type EnvironmentLinks = EnvironmentLink[];
export declare const EnvironmentLinks: any;
export type EnvironmentArn = string;
export interface EnvironmentDescription {
    EnvironmentName?: string;
    EnvironmentId?: string;
    ApplicationName?: string;
    VersionLabel?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    TemplateName?: string;
    Description?: string;
    EndpointURL?: string;
    CNAME?: string;
    DateCreated?: Date;
    DateUpdated?: Date;
    Status?: EnvironmentStatus;
    AbortableOperationInProgress?: boolean;
    Health?: EnvironmentHealth;
    HealthStatus?: EnvironmentHealthStatus;
    Resources?: EnvironmentResourcesDescription;
    Tier?: EnvironmentTier;
    EnvironmentLinks?: EnvironmentLink[];
    EnvironmentArn?: string;
    OperationsRole?: string;
}
export declare const EnvironmentDescription: S.Schema<EnvironmentDescription>;
export type EnvironmentDescriptionsList = EnvironmentDescription[];
export declare const EnvironmentDescriptionsList: any;
export type Token = string;
export interface EnvironmentDescriptionsMessage {
    Environments?: EnvironmentDescription[];
    NextToken?: string;
}
export declare const EnvironmentDescriptionsMessage: S.Schema<EnvironmentDescriptionsMessage>;
export type BoxedBoolean = boolean;
export type BoxedInt = number;
export interface MaxCountRule {
    Enabled: boolean;
    MaxCount?: number;
    DeleteSourceFromS3?: boolean;
}
export declare const MaxCountRule: S.Schema<MaxCountRule>;
export interface MaxAgeRule {
    Enabled: boolean;
    MaxAgeInDays?: number;
    DeleteSourceFromS3?: boolean;
}
export declare const MaxAgeRule: S.Schema<MaxAgeRule>;
export interface ApplicationVersionLifecycleConfig {
    MaxCountRule?: MaxCountRule;
    MaxAgeRule?: MaxAgeRule;
}
export declare const ApplicationVersionLifecycleConfig: S.Schema<ApplicationVersionLifecycleConfig>;
export interface ApplicationResourceLifecycleConfig {
    ServiceRole?: string;
    VersionLifecycleConfig?: ApplicationVersionLifecycleConfig;
}
export declare const ApplicationResourceLifecycleConfig: S.Schema<ApplicationResourceLifecycleConfig>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface CreateApplicationMessage {
    ApplicationName: string;
    Description?: string;
    ResourceLifecycleConfig?: ApplicationResourceLifecycleConfig;
    Tags?: Tag[];
}
export declare const CreateApplicationMessage: S.Schema<CreateApplicationMessage>;
export type ApplicationArn = string;
export type VersionLabelsList = string[];
export declare const VersionLabelsList: any;
export type ConfigurationTemplateNamesList = string[];
export declare const ConfigurationTemplateNamesList: any;
export interface ApplicationDescription {
    ApplicationArn?: string;
    ApplicationName?: string;
    Description?: string;
    DateCreated?: Date;
    DateUpdated?: Date;
    Versions?: string[];
    ConfigurationTemplates?: string[];
    ResourceLifecycleConfig?: ApplicationResourceLifecycleConfig;
}
export declare const ApplicationDescription: S.Schema<ApplicationDescription>;
export interface ApplicationDescriptionMessage {
    Application?: ApplicationDescription;
}
export declare const ApplicationDescriptionMessage: S.Schema<ApplicationDescriptionMessage>;
export type SourceType = "Git" | "Zip" | (string & {});
export declare const SourceType: any;
export type SourceRepository = "CodeCommit" | "S3" | (string & {});
export declare const SourceRepository: any;
export type SourceLocation = string;
export interface SourceBuildInformation {
    SourceType: SourceType;
    SourceRepository: SourceRepository;
    SourceLocation: string;
}
export declare const SourceBuildInformation: S.Schema<SourceBuildInformation>;
export type S3Bucket = string;
export type S3Key = string;
export interface S3Location {
    S3Bucket?: string;
    S3Key?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type NonEmptyString = string;
export type ComputeType = "BUILD_GENERAL1_SMALL" | "BUILD_GENERAL1_MEDIUM" | "BUILD_GENERAL1_LARGE" | (string & {});
export declare const ComputeType: any;
export interface BuildConfiguration {
    ArtifactName?: string;
    CodeBuildServiceRole: string;
    ComputeType?: ComputeType;
    Image: string;
    TimeoutInMinutes?: number;
}
export declare const BuildConfiguration: S.Schema<BuildConfiguration>;
export type AutoCreateApplication = boolean;
export type ApplicationVersionProccess = boolean;
export interface CreateApplicationVersionMessage {
    ApplicationName: string;
    VersionLabel: string;
    Description?: string;
    SourceBuildInformation?: SourceBuildInformation;
    SourceBundle?: S3Location;
    BuildConfiguration?: BuildConfiguration;
    AutoCreateApplication?: boolean;
    Process?: boolean;
    Tags?: Tag[];
}
export declare const CreateApplicationVersionMessage: S.Schema<CreateApplicationVersionMessage>;
export type ApplicationVersionArn = string;
export type ApplicationVersionStatus = "Processed" | "Unprocessed" | "Failed" | "Processing" | "Building" | (string & {});
export declare const ApplicationVersionStatus: any;
export interface ApplicationVersionDescription {
    ApplicationVersionArn?: string;
    ApplicationName?: string;
    Description?: string;
    VersionLabel?: string;
    SourceBuildInformation?: SourceBuildInformation;
    BuildArn?: string;
    SourceBundle?: S3Location;
    DateCreated?: Date;
    DateUpdated?: Date;
    Status?: ApplicationVersionStatus;
}
export declare const ApplicationVersionDescription: S.Schema<ApplicationVersionDescription>;
export interface ApplicationVersionDescriptionMessage {
    ApplicationVersion?: ApplicationVersionDescription;
}
export declare const ApplicationVersionDescriptionMessage: S.Schema<ApplicationVersionDescriptionMessage>;
export interface SourceConfiguration {
    ApplicationName?: string;
    TemplateName?: string;
}
export declare const SourceConfiguration: S.Schema<SourceConfiguration>;
export type ResourceName = string;
export type OptionNamespace = string;
export type ConfigurationOptionName = string;
export type ConfigurationOptionValue = string;
export interface ConfigurationOptionSetting {
    ResourceName?: string;
    Namespace?: string;
    OptionName?: string;
    Value?: string;
}
export declare const ConfigurationOptionSetting: S.Schema<ConfigurationOptionSetting>;
export type ConfigurationOptionSettingsList = ConfigurationOptionSetting[];
export declare const ConfigurationOptionSettingsList: any;
export interface CreateConfigurationTemplateMessage {
    ApplicationName: string;
    TemplateName: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    SourceConfiguration?: SourceConfiguration;
    EnvironmentId?: string;
    Description?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    Tags?: Tag[];
}
export declare const CreateConfigurationTemplateMessage: S.Schema<CreateConfigurationTemplateMessage>;
export type ConfigurationDeploymentStatus = "deployed" | "pending" | "failed" | (string & {});
export declare const ConfigurationDeploymentStatus: any;
export interface ConfigurationSettingsDescription {
    SolutionStackName?: string;
    PlatformArn?: string;
    ApplicationName?: string;
    TemplateName?: string;
    Description?: string;
    EnvironmentName?: string;
    DeploymentStatus?: ConfigurationDeploymentStatus;
    DateCreated?: Date;
    DateUpdated?: Date;
    OptionSettings?: ConfigurationOptionSetting[];
}
export declare const ConfigurationSettingsDescription: S.Schema<ConfigurationSettingsDescription>;
export interface OptionSpecification {
    ResourceName?: string;
    Namespace?: string;
    OptionName?: string;
}
export declare const OptionSpecification: S.Schema<OptionSpecification>;
export type OptionsSpecifierList = OptionSpecification[];
export declare const OptionsSpecifierList: any;
export interface CreateEnvironmentMessage {
    ApplicationName: string;
    EnvironmentName?: string;
    GroupName?: string;
    Description?: string;
    CNAMEPrefix?: string;
    Tier?: EnvironmentTier;
    Tags?: Tag[];
    VersionLabel?: string;
    TemplateName?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    OptionsToRemove?: OptionSpecification[];
    OperationsRole?: string;
}
export declare const CreateEnvironmentMessage: S.Schema<CreateEnvironmentMessage>;
export type PlatformName = string;
export type PlatformVersion = string;
export interface CreatePlatformVersionRequest {
    PlatformName: string;
    PlatformVersion: string;
    PlatformDefinitionBundle: S3Location;
    EnvironmentName?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    Tags?: Tag[];
}
export declare const CreatePlatformVersionRequest: S.Schema<CreatePlatformVersionRequest>;
export type PlatformOwner = string;
export type PlatformStatus = "Creating" | "Failed" | "Ready" | "Deleting" | "Deleted" | (string & {});
export declare const PlatformStatus: any;
export type PlatformCategory = string;
export type OperatingSystemName = string;
export type OperatingSystemVersion = string;
export type SupportedTier = string;
export type SupportedTierList = string[];
export declare const SupportedTierList: any;
export type SupportedAddon = string;
export type SupportedAddonList = string[];
export declare const SupportedAddonList: any;
export type PlatformLifecycleState = string;
export type BranchName = string;
export type PlatformBranchLifecycleState = string;
export interface PlatformSummary {
    PlatformArn?: string;
    PlatformOwner?: string;
    PlatformStatus?: PlatformStatus;
    PlatformCategory?: string;
    OperatingSystemName?: string;
    OperatingSystemVersion?: string;
    SupportedTierList?: string[];
    SupportedAddonList?: string[];
    PlatformLifecycleState?: string;
    PlatformVersion?: string;
    PlatformBranchName?: string;
    PlatformBranchLifecycleState?: string;
}
export declare const PlatformSummary: S.Schema<PlatformSummary>;
export type ARN = string;
export interface Builder {
    ARN?: string;
}
export declare const Builder: S.Schema<Builder>;
export interface CreatePlatformVersionResult {
    PlatformSummary?: PlatformSummary;
    Builder?: Builder;
}
export declare const CreatePlatformVersionResult: S.Schema<CreatePlatformVersionResult>;
export interface CreateStorageLocationRequest {
}
export declare const CreateStorageLocationRequest: S.Schema<CreateStorageLocationRequest>;
export interface CreateStorageLocationResultMessage {
    S3Bucket?: string;
}
export declare const CreateStorageLocationResultMessage: S.Schema<CreateStorageLocationResultMessage>;
export type TerminateEnvForce = boolean;
export interface DeleteApplicationMessage {
    ApplicationName: string;
    TerminateEnvByForce?: boolean;
}
export declare const DeleteApplicationMessage: S.Schema<DeleteApplicationMessage>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export type DeleteSourceBundle = boolean;
export interface DeleteApplicationVersionMessage {
    ApplicationName: string;
    VersionLabel: string;
    DeleteSourceBundle?: boolean;
}
export declare const DeleteApplicationVersionMessage: S.Schema<DeleteApplicationVersionMessage>;
export interface DeleteApplicationVersionResponse {
}
export declare const DeleteApplicationVersionResponse: S.Schema<DeleteApplicationVersionResponse>;
export interface DeleteConfigurationTemplateMessage {
    ApplicationName: string;
    TemplateName: string;
}
export declare const DeleteConfigurationTemplateMessage: S.Schema<DeleteConfigurationTemplateMessage>;
export interface DeleteConfigurationTemplateResponse {
}
export declare const DeleteConfigurationTemplateResponse: S.Schema<DeleteConfigurationTemplateResponse>;
export interface DeleteEnvironmentConfigurationMessage {
    ApplicationName: string;
    EnvironmentName: string;
}
export declare const DeleteEnvironmentConfigurationMessage: S.Schema<DeleteEnvironmentConfigurationMessage>;
export interface DeleteEnvironmentConfigurationResponse {
}
export declare const DeleteEnvironmentConfigurationResponse: S.Schema<DeleteEnvironmentConfigurationResponse>;
export interface DeletePlatformVersionRequest {
    PlatformArn?: string;
}
export declare const DeletePlatformVersionRequest: S.Schema<DeletePlatformVersionRequest>;
export interface DeletePlatformVersionResult {
    PlatformSummary?: PlatformSummary;
}
export declare const DeletePlatformVersionResult: S.Schema<DeletePlatformVersionResult>;
export interface DescribeAccountAttributesRequest {
}
export declare const DescribeAccountAttributesRequest: S.Schema<DescribeAccountAttributesRequest>;
export interface ResourceQuota {
    Maximum?: number;
}
export declare const ResourceQuota: S.Schema<ResourceQuota>;
export interface ResourceQuotas {
    ApplicationQuota?: ResourceQuota;
    ApplicationVersionQuota?: ResourceQuota;
    EnvironmentQuota?: ResourceQuota;
    ConfigurationTemplateQuota?: ResourceQuota;
    CustomPlatformQuota?: ResourceQuota;
}
export declare const ResourceQuotas: S.Schema<ResourceQuotas>;
export interface DescribeAccountAttributesResult {
    ResourceQuotas?: ResourceQuotas;
}
export declare const DescribeAccountAttributesResult: S.Schema<DescribeAccountAttributesResult>;
export type ApplicationNamesList = string[];
export declare const ApplicationNamesList: any;
export interface DescribeApplicationsMessage {
    ApplicationNames?: string[];
}
export declare const DescribeApplicationsMessage: S.Schema<DescribeApplicationsMessage>;
export type ApplicationDescriptionList = ApplicationDescription[];
export declare const ApplicationDescriptionList: any;
export interface ApplicationDescriptionsMessage {
    Applications?: ApplicationDescription[];
}
export declare const ApplicationDescriptionsMessage: S.Schema<ApplicationDescriptionsMessage>;
export type MaxRecords = number;
export interface DescribeApplicationVersionsMessage {
    ApplicationName?: string;
    VersionLabels?: string[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeApplicationVersionsMessage: S.Schema<DescribeApplicationVersionsMessage>;
export type ApplicationVersionDescriptionList = ApplicationVersionDescription[];
export declare const ApplicationVersionDescriptionList: any;
export interface ApplicationVersionDescriptionsMessage {
    ApplicationVersions?: ApplicationVersionDescription[];
    NextToken?: string;
}
export declare const ApplicationVersionDescriptionsMessage: S.Schema<ApplicationVersionDescriptionsMessage>;
export interface DescribeConfigurationOptionsMessage {
    ApplicationName?: string;
    TemplateName?: string;
    EnvironmentName?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    Options?: OptionSpecification[];
}
export declare const DescribeConfigurationOptionsMessage: S.Schema<DescribeConfigurationOptionsMessage>;
export type ConfigurationOptionDefaultValue = string;
export type ConfigurationOptionSeverity = string;
export type UserDefinedOption = boolean;
export type ConfigurationOptionValueType = "Scalar" | "List" | (string & {});
export declare const ConfigurationOptionValueType: any;
export type ConfigurationOptionPossibleValue = string;
export type ConfigurationOptionPossibleValues = string[];
export declare const ConfigurationOptionPossibleValues: any;
export type OptionRestrictionMinValue = number;
export type OptionRestrictionMaxValue = number;
export type OptionRestrictionMaxLength = number;
export type RegexPattern = string;
export type RegexLabel = string;
export interface OptionRestrictionRegex {
    Pattern?: string;
    Label?: string;
}
export declare const OptionRestrictionRegex: S.Schema<OptionRestrictionRegex>;
export interface ConfigurationOptionDescription {
    Namespace?: string;
    Name?: string;
    DefaultValue?: string;
    ChangeSeverity?: string;
    UserDefined?: boolean;
    ValueType?: ConfigurationOptionValueType;
    ValueOptions?: string[];
    MinValue?: number;
    MaxValue?: number;
    MaxLength?: number;
    Regex?: OptionRestrictionRegex;
}
export declare const ConfigurationOptionDescription: S.Schema<ConfigurationOptionDescription>;
export type ConfigurationOptionDescriptionsList = ConfigurationOptionDescription[];
export declare const ConfigurationOptionDescriptionsList: any;
export interface ConfigurationOptionsDescription {
    SolutionStackName?: string;
    PlatformArn?: string;
    Options?: ConfigurationOptionDescription[];
}
export declare const ConfigurationOptionsDescription: S.Schema<ConfigurationOptionsDescription>;
export interface DescribeConfigurationSettingsMessage {
    ApplicationName: string;
    TemplateName?: string;
    EnvironmentName?: string;
}
export declare const DescribeConfigurationSettingsMessage: S.Schema<DescribeConfigurationSettingsMessage>;
export type ConfigurationSettingsDescriptionList = ConfigurationSettingsDescription[];
export declare const ConfigurationSettingsDescriptionList: any;
export interface ConfigurationSettingsDescriptions {
    ConfigurationSettings?: ConfigurationSettingsDescription[];
}
export declare const ConfigurationSettingsDescriptions: S.Schema<ConfigurationSettingsDescriptions>;
export type EnvironmentHealthAttribute = "Status" | "Color" | "Causes" | "ApplicationMetrics" | "InstancesHealth" | "All" | "HealthStatus" | "RefreshedAt" | (string & {});
export declare const EnvironmentHealthAttribute: any;
export type EnvironmentHealthAttributes = EnvironmentHealthAttribute[];
export declare const EnvironmentHealthAttributes: any;
export interface DescribeEnvironmentHealthRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    AttributeNames?: EnvironmentHealthAttribute[];
}
export declare const DescribeEnvironmentHealthRequest: S.Schema<DescribeEnvironmentHealthRequest>;
export type Cause = string;
export type Causes = string[];
export declare const Causes: any;
export type RequestCount = number;
export interface StatusCodes {
    Status2xx?: number;
    Status3xx?: number;
    Status4xx?: number;
    Status5xx?: number;
}
export declare const StatusCodes: S.Schema<StatusCodes>;
export interface Latency {
    P999?: number;
    P99?: number;
    P95?: number;
    P90?: number;
    P85?: number;
    P75?: number;
    P50?: number;
    P10?: number;
}
export declare const Latency: S.Schema<Latency>;
export interface ApplicationMetrics {
    Duration?: number;
    RequestCount?: number;
    StatusCodes?: StatusCodes;
    Latency?: Latency;
}
export declare const ApplicationMetrics: S.Schema<ApplicationMetrics>;
export interface InstanceHealthSummary {
    NoData?: number;
    Unknown?: number;
    Pending?: number;
    Ok?: number;
    Info?: number;
    Warning?: number;
    Degraded?: number;
    Severe?: number;
}
export declare const InstanceHealthSummary: S.Schema<InstanceHealthSummary>;
export type RefreshedAt = Date;
export interface DescribeEnvironmentHealthResult {
    EnvironmentName?: string;
    HealthStatus?: string;
    Status?: EnvironmentHealth;
    Color?: string;
    Causes?: string[];
    ApplicationMetrics?: ApplicationMetrics;
    InstancesHealth?: InstanceHealthSummary;
    RefreshedAt?: Date;
}
export declare const DescribeEnvironmentHealthResult: S.Schema<DescribeEnvironmentHealthResult>;
export type ManagedActionHistoryMaxItems = number;
export interface DescribeEnvironmentManagedActionHistoryRequest {
    EnvironmentId?: string;
    EnvironmentName?: string;
    NextToken?: string;
    MaxItems?: number;
}
export declare const DescribeEnvironmentManagedActionHistoryRequest: S.Schema<DescribeEnvironmentManagedActionHistoryRequest>;
export type FailureType = "UpdateCancelled" | "CancellationFailed" | "RollbackFailed" | "RollbackSuccessful" | "InternalFailure" | "InvalidEnvironmentState" | "PermissionsError" | (string & {});
export declare const FailureType: any;
export type ActionHistoryStatus = "Completed" | "Failed" | "Unknown" | (string & {});
export declare const ActionHistoryStatus: any;
export interface ManagedActionHistoryItem {
    ActionId?: string;
    ActionType?: ActionType;
    ActionDescription?: string;
    FailureType?: FailureType;
    Status?: ActionHistoryStatus;
    FailureDescription?: string;
    ExecutedTime?: Date;
    FinishedTime?: Date;
}
export declare const ManagedActionHistoryItem: S.Schema<ManagedActionHistoryItem>;
export type ManagedActionHistoryItems = ManagedActionHistoryItem[];
export declare const ManagedActionHistoryItems: any;
export interface DescribeEnvironmentManagedActionHistoryResult {
    ManagedActionHistoryItems?: ManagedActionHistoryItem[];
    NextToken?: string;
}
export declare const DescribeEnvironmentManagedActionHistoryResult: S.Schema<DescribeEnvironmentManagedActionHistoryResult>;
export type ActionStatus = "Scheduled" | "Pending" | "Running" | "Unknown" | (string & {});
export declare const ActionStatus: any;
export interface DescribeEnvironmentManagedActionsRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    Status?: ActionStatus;
}
export declare const DescribeEnvironmentManagedActionsRequest: S.Schema<DescribeEnvironmentManagedActionsRequest>;
export interface ManagedAction {
    ActionId?: string;
    ActionDescription?: string;
    ActionType?: ActionType;
    Status?: ActionStatus;
    WindowStartTime?: Date;
}
export declare const ManagedAction: S.Schema<ManagedAction>;
export type ManagedActions = ManagedAction[];
export declare const ManagedActions: any;
export interface DescribeEnvironmentManagedActionsResult {
    ManagedActions?: ManagedAction[];
}
export declare const DescribeEnvironmentManagedActionsResult: S.Schema<DescribeEnvironmentManagedActionsResult>;
export interface DescribeEnvironmentResourcesMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export declare const DescribeEnvironmentResourcesMessage: S.Schema<DescribeEnvironmentResourcesMessage>;
export type ResourceId = string;
export interface AutoScalingGroup {
    Name?: string;
}
export declare const AutoScalingGroup: S.Schema<AutoScalingGroup>;
export type AutoScalingGroupList = AutoScalingGroup[];
export declare const AutoScalingGroupList: any;
export interface Instance {
    Id?: string;
}
export declare const Instance: S.Schema<Instance>;
export type InstanceList = Instance[];
export declare const InstanceList: any;
export interface LaunchConfiguration {
    Name?: string;
}
export declare const LaunchConfiguration: S.Schema<LaunchConfiguration>;
export type LaunchConfigurationList = LaunchConfiguration[];
export declare const LaunchConfigurationList: any;
export interface LaunchTemplate {
    Id?: string;
}
export declare const LaunchTemplate: S.Schema<LaunchTemplate>;
export type LaunchTemplateList = LaunchTemplate[];
export declare const LaunchTemplateList: any;
export interface LoadBalancer {
    Name?: string;
}
export declare const LoadBalancer: S.Schema<LoadBalancer>;
export type LoadBalancerList = LoadBalancer[];
export declare const LoadBalancerList: any;
export interface Trigger {
    Name?: string;
}
export declare const Trigger: S.Schema<Trigger>;
export type TriggerList = Trigger[];
export declare const TriggerList: any;
export interface Queue {
    Name?: string;
    URL?: string;
}
export declare const Queue: S.Schema<Queue>;
export type QueueList = Queue[];
export declare const QueueList: any;
export interface EnvironmentResourceDescription {
    EnvironmentName?: string;
    AutoScalingGroups?: AutoScalingGroup[];
    Instances?: Instance[];
    LaunchConfigurations?: LaunchConfiguration[];
    LaunchTemplates?: LaunchTemplate[];
    LoadBalancers?: LoadBalancer[];
    Triggers?: Trigger[];
    Queues?: Queue[];
}
export declare const EnvironmentResourceDescription: S.Schema<EnvironmentResourceDescription>;
export interface EnvironmentResourceDescriptionsMessage {
    EnvironmentResources?: EnvironmentResourceDescription;
}
export declare const EnvironmentResourceDescriptionsMessage: S.Schema<EnvironmentResourceDescriptionsMessage>;
export type EnvironmentIdList = string[];
export declare const EnvironmentIdList: any;
export type EnvironmentNamesList = string[];
export declare const EnvironmentNamesList: any;
export type IncludeDeleted = boolean;
export type IncludeDeletedBackTo = Date;
export interface DescribeEnvironmentsMessage {
    ApplicationName?: string;
    VersionLabel?: string;
    EnvironmentIds?: string[];
    EnvironmentNames?: string[];
    IncludeDeleted?: boolean;
    IncludedDeletedBackTo?: Date;
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeEnvironmentsMessage: S.Schema<DescribeEnvironmentsMessage>;
export type RequestId = string;
export type EventSeverity = "TRACE" | "DEBUG" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export declare const EventSeverity: any;
export type TimeFilterStart = Date;
export type TimeFilterEnd = Date;
export interface DescribeEventsMessage {
    ApplicationName?: string;
    VersionLabel?: string;
    TemplateName?: string;
    EnvironmentId?: string;
    EnvironmentName?: string;
    PlatformArn?: string;
    RequestId?: string;
    Severity?: EventSeverity;
    StartTime?: Date;
    EndTime?: Date;
    MaxRecords?: number;
    NextToken?: string;
}
export declare const DescribeEventsMessage: S.Schema<DescribeEventsMessage>;
export type EventDate = Date;
export type EventMessage = string;
export interface EventDescription {
    EventDate?: Date;
    Message?: string;
    ApplicationName?: string;
    VersionLabel?: string;
    TemplateName?: string;
    EnvironmentName?: string;
    PlatformArn?: string;
    RequestId?: string;
    Severity?: EventSeverity;
}
export declare const EventDescription: S.Schema<EventDescription>;
export type EventDescriptionList = EventDescription[];
export declare const EventDescriptionList: any;
export interface EventDescriptionsMessage {
    Events?: EventDescription[];
    NextToken?: string;
}
export declare const EventDescriptionsMessage: S.Schema<EventDescriptionsMessage>;
export type InstancesHealthAttribute = "HealthStatus" | "Color" | "Causes" | "ApplicationMetrics" | "RefreshedAt" | "LaunchedAt" | "System" | "Deployment" | "AvailabilityZone" | "InstanceType" | "All" | (string & {});
export declare const InstancesHealthAttribute: any;
export type InstancesHealthAttributes = InstancesHealthAttribute[];
export declare const InstancesHealthAttributes: any;
export type NextToken = string;
export interface DescribeInstancesHealthRequest {
    EnvironmentName?: string;
    EnvironmentId?: string;
    AttributeNames?: InstancesHealthAttribute[];
    NextToken?: string;
}
export declare const DescribeInstancesHealthRequest: S.Schema<DescribeInstancesHealthRequest>;
export type InstanceId = string;
export type LaunchedAt = Date;
export interface CPUUtilization {
    User?: number;
    Nice?: number;
    System?: number;
    Idle?: number;
    IOWait?: number;
    IRQ?: number;
    SoftIRQ?: number;
    Privileged?: number;
}
export declare const CPUUtilization: S.Schema<CPUUtilization>;
export type LoadAverageValue = number;
export type LoadAverage = number[];
export declare const LoadAverage: any;
export interface SystemStatus {
    CPUUtilization?: CPUUtilization;
    LoadAverage?: number[];
}
export declare const SystemStatus: S.Schema<SystemStatus>;
export type DeploymentTimestamp = Date;
export interface Deployment {
    VersionLabel?: string;
    DeploymentId?: number;
    Status?: string;
    DeploymentTime?: Date;
}
export declare const Deployment: S.Schema<Deployment>;
export interface SingleInstanceHealth {
    InstanceId?: string;
    HealthStatus?: string;
    Color?: string;
    Causes?: string[];
    LaunchedAt?: Date;
    ApplicationMetrics?: ApplicationMetrics;
    System?: SystemStatus;
    Deployment?: Deployment;
    AvailabilityZone?: string;
    InstanceType?: string;
}
export declare const SingleInstanceHealth: S.Schema<SingleInstanceHealth>;
export type InstanceHealthList = SingleInstanceHealth[];
export declare const InstanceHealthList: any;
export interface DescribeInstancesHealthResult {
    InstanceHealthList?: SingleInstanceHealth[];
    RefreshedAt?: Date;
    NextToken?: string;
}
export declare const DescribeInstancesHealthResult: S.Schema<DescribeInstancesHealthResult>;
export interface DescribePlatformVersionRequest {
    PlatformArn?: string;
}
export declare const DescribePlatformVersionRequest: S.Schema<DescribePlatformVersionRequest>;
export type Maintainer = string;
export interface PlatformProgrammingLanguage {
    Name?: string;
    Version?: string;
}
export declare const PlatformProgrammingLanguage: S.Schema<PlatformProgrammingLanguage>;
export type PlatformProgrammingLanguages = PlatformProgrammingLanguage[];
export declare const PlatformProgrammingLanguages: any;
export interface PlatformFramework {
    Name?: string;
    Version?: string;
}
export declare const PlatformFramework: S.Schema<PlatformFramework>;
export type PlatformFrameworks = PlatformFramework[];
export declare const PlatformFrameworks: any;
export type VirtualizationType = string;
export type ImageId = string;
export interface CustomAmi {
    VirtualizationType?: string;
    ImageId?: string;
}
export declare const CustomAmi: S.Schema<CustomAmi>;
export type CustomAmiList = CustomAmi[];
export declare const CustomAmiList: any;
export interface PlatformDescription {
    PlatformArn?: string;
    PlatformOwner?: string;
    PlatformName?: string;
    PlatformVersion?: string;
    SolutionStackName?: string;
    PlatformStatus?: PlatformStatus;
    DateCreated?: Date;
    DateUpdated?: Date;
    PlatformCategory?: string;
    Description?: string;
    Maintainer?: string;
    OperatingSystemName?: string;
    OperatingSystemVersion?: string;
    ProgrammingLanguages?: PlatformProgrammingLanguage[];
    Frameworks?: PlatformFramework[];
    CustomAmiList?: CustomAmi[];
    SupportedTierList?: string[];
    SupportedAddonList?: string[];
    PlatformLifecycleState?: string;
    PlatformBranchName?: string;
    PlatformBranchLifecycleState?: string;
}
export declare const PlatformDescription: S.Schema<PlatformDescription>;
export interface DescribePlatformVersionResult {
    PlatformDescription?: PlatformDescription;
}
export declare const DescribePlatformVersionResult: S.Schema<DescribePlatformVersionResult>;
export interface DisassociateEnvironmentOperationsRoleMessage {
    EnvironmentName: string;
}
export declare const DisassociateEnvironmentOperationsRoleMessage: S.Schema<DisassociateEnvironmentOperationsRoleMessage>;
export interface DisassociateEnvironmentOperationsRoleResponse {
}
export declare const DisassociateEnvironmentOperationsRoleResponse: S.Schema<DisassociateEnvironmentOperationsRoleResponse>;
export interface ListAvailableSolutionStacksRequest {
}
export declare const ListAvailableSolutionStacksRequest: S.Schema<ListAvailableSolutionStacksRequest>;
export type AvailableSolutionStackNamesList = string[];
export declare const AvailableSolutionStackNamesList: any;
export type FileTypeExtension = string;
export type SolutionStackFileTypeList = string[];
export declare const SolutionStackFileTypeList: any;
export interface SolutionStackDescription {
    SolutionStackName?: string;
    PermittedFileTypes?: string[];
}
export declare const SolutionStackDescription: S.Schema<SolutionStackDescription>;
export type AvailableSolutionStackDetailsList = SolutionStackDescription[];
export declare const AvailableSolutionStackDetailsList: any;
export interface ListAvailableSolutionStacksResultMessage {
    SolutionStacks?: string[];
    SolutionStackDetails?: SolutionStackDescription[];
}
export declare const ListAvailableSolutionStacksResultMessage: S.Schema<ListAvailableSolutionStacksResultMessage>;
export type SearchFilterAttribute = string;
export type SearchFilterOperator = string;
export type SearchFilterValue = string;
export type SearchFilterValues = string[];
export declare const SearchFilterValues: any;
export interface SearchFilter {
    Attribute?: string;
    Operator?: string;
    Values?: string[];
}
export declare const SearchFilter: S.Schema<SearchFilter>;
export type SearchFilters = SearchFilter[];
export declare const SearchFilters: any;
export type PlatformBranchMaxRecords = number;
export interface ListPlatformBranchesRequest {
    Filters?: SearchFilter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const ListPlatformBranchesRequest: S.Schema<ListPlatformBranchesRequest>;
export type BranchOrder = number;
export interface PlatformBranchSummary {
    PlatformName?: string;
    BranchName?: string;
    LifecycleState?: string;
    BranchOrder?: number;
    SupportedTierList?: string[];
}
export declare const PlatformBranchSummary: S.Schema<PlatformBranchSummary>;
export type PlatformBranchSummaryList = PlatformBranchSummary[];
export declare const PlatformBranchSummaryList: any;
export interface ListPlatformBranchesResult {
    PlatformBranchSummaryList?: PlatformBranchSummary[];
    NextToken?: string;
}
export declare const ListPlatformBranchesResult: S.Schema<ListPlatformBranchesResult>;
export type PlatformFilterType = string;
export type PlatformFilterOperator = string;
export type PlatformFilterValue = string;
export type PlatformFilterValueList = string[];
export declare const PlatformFilterValueList: any;
export interface PlatformFilter {
    Type?: string;
    Operator?: string;
    Values?: string[];
}
export declare const PlatformFilter: S.Schema<PlatformFilter>;
export type PlatformFilters = PlatformFilter[];
export declare const PlatformFilters: any;
export type PlatformMaxRecords = number;
export interface ListPlatformVersionsRequest {
    Filters?: PlatformFilter[];
    MaxRecords?: number;
    NextToken?: string;
}
export declare const ListPlatformVersionsRequest: S.Schema<ListPlatformVersionsRequest>;
export type PlatformSummaryList = PlatformSummary[];
export declare const PlatformSummaryList: any;
export interface ListPlatformVersionsResult {
    PlatformSummaryList?: PlatformSummary[];
    NextToken?: string;
}
export declare const ListPlatformVersionsResult: S.Schema<ListPlatformVersionsResult>;
export type ResourceArn = string;
export interface ListTagsForResourceMessage {
    ResourceArn: string;
}
export declare const ListTagsForResourceMessage: S.Schema<ListTagsForResourceMessage>;
export type TagList = Tag[];
export declare const TagList: any;
export interface ResourceTagsDescriptionMessage {
    ResourceArn?: string;
    ResourceTags?: Tag[];
}
export declare const ResourceTagsDescriptionMessage: S.Schema<ResourceTagsDescriptionMessage>;
export interface RebuildEnvironmentMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export declare const RebuildEnvironmentMessage: S.Schema<RebuildEnvironmentMessage>;
export interface RebuildEnvironmentResponse {
}
export declare const RebuildEnvironmentResponse: S.Schema<RebuildEnvironmentResponse>;
export type EnvironmentInfoType = "tail" | "bundle" | "analyze" | (string & {});
export declare const EnvironmentInfoType: any;
export interface RequestEnvironmentInfoMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
    InfoType: EnvironmentInfoType;
}
export declare const RequestEnvironmentInfoMessage: S.Schema<RequestEnvironmentInfoMessage>;
export interface RequestEnvironmentInfoResponse {
}
export declare const RequestEnvironmentInfoResponse: S.Schema<RequestEnvironmentInfoResponse>;
export interface RestartAppServerMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
}
export declare const RestartAppServerMessage: S.Schema<RestartAppServerMessage>;
export interface RestartAppServerResponse {
}
export declare const RestartAppServerResponse: S.Schema<RestartAppServerResponse>;
export interface RetrieveEnvironmentInfoMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
    InfoType: EnvironmentInfoType;
}
export declare const RetrieveEnvironmentInfoMessage: S.Schema<RetrieveEnvironmentInfoMessage>;
export type Ec2InstanceId = string;
export type SampleTimestamp = Date;
export type Message = string;
export interface EnvironmentInfoDescription {
    InfoType?: EnvironmentInfoType;
    Ec2InstanceId?: string;
    SampleTimestamp?: Date;
    Message?: string;
}
export declare const EnvironmentInfoDescription: S.Schema<EnvironmentInfoDescription>;
export type EnvironmentInfoDescriptionList = EnvironmentInfoDescription[];
export declare const EnvironmentInfoDescriptionList: any;
export interface RetrieveEnvironmentInfoResultMessage {
    EnvironmentInfo?: EnvironmentInfoDescription[];
}
export declare const RetrieveEnvironmentInfoResultMessage: S.Schema<RetrieveEnvironmentInfoResultMessage>;
export interface SwapEnvironmentCNAMEsMessage {
    SourceEnvironmentId?: string;
    SourceEnvironmentName?: string;
    DestinationEnvironmentId?: string;
    DestinationEnvironmentName?: string;
}
export declare const SwapEnvironmentCNAMEsMessage: S.Schema<SwapEnvironmentCNAMEsMessage>;
export interface SwapEnvironmentCNAMEsResponse {
}
export declare const SwapEnvironmentCNAMEsResponse: S.Schema<SwapEnvironmentCNAMEsResponse>;
export type TerminateEnvironmentResources = boolean;
export type ForceTerminate = boolean;
export interface TerminateEnvironmentMessage {
    EnvironmentId?: string;
    EnvironmentName?: string;
    TerminateResources?: boolean;
    ForceTerminate?: boolean;
}
export declare const TerminateEnvironmentMessage: S.Schema<TerminateEnvironmentMessage>;
export interface UpdateApplicationMessage {
    ApplicationName: string;
    Description?: string;
}
export declare const UpdateApplicationMessage: S.Schema<UpdateApplicationMessage>;
export interface UpdateApplicationResourceLifecycleMessage {
    ApplicationName: string;
    ResourceLifecycleConfig: ApplicationResourceLifecycleConfig;
}
export declare const UpdateApplicationResourceLifecycleMessage: S.Schema<UpdateApplicationResourceLifecycleMessage>;
export interface ApplicationResourceLifecycleDescriptionMessage {
    ApplicationName?: string;
    ResourceLifecycleConfig?: ApplicationResourceLifecycleConfig;
}
export declare const ApplicationResourceLifecycleDescriptionMessage: S.Schema<ApplicationResourceLifecycleDescriptionMessage>;
export interface UpdateApplicationVersionMessage {
    ApplicationName: string;
    VersionLabel: string;
    Description?: string;
}
export declare const UpdateApplicationVersionMessage: S.Schema<UpdateApplicationVersionMessage>;
export interface UpdateConfigurationTemplateMessage {
    ApplicationName: string;
    TemplateName: string;
    Description?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    OptionsToRemove?: OptionSpecification[];
}
export declare const UpdateConfigurationTemplateMessage: S.Schema<UpdateConfigurationTemplateMessage>;
export interface UpdateEnvironmentMessage {
    ApplicationName?: string;
    EnvironmentId?: string;
    EnvironmentName?: string;
    GroupName?: string;
    Description?: string;
    Tier?: EnvironmentTier;
    VersionLabel?: string;
    TemplateName?: string;
    SolutionStackName?: string;
    PlatformArn?: string;
    OptionSettings?: ConfigurationOptionSetting[];
    OptionsToRemove?: OptionSpecification[];
}
export declare const UpdateEnvironmentMessage: S.Schema<UpdateEnvironmentMessage>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UpdateTagsForResourceMessage {
    ResourceArn: string;
    TagsToAdd?: Tag[];
    TagsToRemove?: string[];
}
export declare const UpdateTagsForResourceMessage: S.Schema<UpdateTagsForResourceMessage>;
export interface UpdateTagsForResourceResponse {
}
export declare const UpdateTagsForResourceResponse: S.Schema<UpdateTagsForResourceResponse>;
export interface ValidateConfigurationSettingsMessage {
    ApplicationName: string;
    TemplateName?: string;
    EnvironmentName?: string;
    OptionSettings: ConfigurationOptionSetting[];
}
export declare const ValidateConfigurationSettingsMessage: S.Schema<ValidateConfigurationSettingsMessage>;
export type ValidationMessageString = string;
export type ValidationSeverity = "error" | "warning" | (string & {});
export declare const ValidationSeverity: any;
export interface ValidationMessage {
    Message?: string;
    Severity?: ValidationSeverity;
    Namespace?: string;
    OptionName?: string;
}
export declare const ValidationMessage: S.Schema<ValidationMessage>;
export type ValidationMessagesList = ValidationMessage[];
export declare const ValidationMessagesList: any;
export interface ConfigurationSettingsValidationMessages {
    Messages?: ValidationMessage[];
}
export declare const ConfigurationSettingsValidationMessages: S.Schema<ConfigurationSettingsValidationMessages>;
export type ExceptionMessage = string;
export type AbortEnvironmentUpdateError = InsufficientPrivilegesException | CommonErrors;
/**
 * Cancels in-progress environment configuration update or application version
 * deployment.
 */
export declare const abortEnvironmentUpdate: API.OperationMethod<AbortEnvironmentUpdateMessage, AbortEnvironmentUpdateResponse, AbortEnvironmentUpdateError, Credentials | HttpClient.HttpClient>;
export type ApplyEnvironmentManagedActionError = ElasticBeanstalkServiceException | ManagedActionInvalidStateException | CommonErrors;
/**
 * Applies a scheduled managed action immediately. A managed action can be applied only if
 * its status is `Scheduled`. Get the status and action ID of a managed action with
 * DescribeEnvironmentManagedActions.
 */
export declare const applyEnvironmentManagedAction: API.OperationMethod<ApplyEnvironmentManagedActionRequest, ApplyEnvironmentManagedActionResult, ApplyEnvironmentManagedActionError, Credentials | HttpClient.HttpClient>;
export type AssociateEnvironmentOperationsRoleError = InsufficientPrivilegesException | CommonErrors;
/**
 * Add or change the operations role used by an environment. After this call is made, Elastic Beanstalk
 * uses the associated operations role for permissions to downstream services during subsequent
 * calls acting on this environment. For more information, see Operations roles in the
 * *AWS Elastic Beanstalk Developer Guide*.
 */
export declare const associateEnvironmentOperationsRole: API.OperationMethod<AssociateEnvironmentOperationsRoleMessage, AssociateEnvironmentOperationsRoleResponse, AssociateEnvironmentOperationsRoleError, Credentials | HttpClient.HttpClient>;
export type CheckDNSAvailabilityError = CommonErrors;
/**
 * Checks if the specified CNAME is available.
 */
export declare const checkDNSAvailability: API.OperationMethod<CheckDNSAvailabilityMessage, CheckDNSAvailabilityResultMessage, CheckDNSAvailabilityError, Credentials | HttpClient.HttpClient>;
export type ComposeEnvironmentsError = InsufficientPrivilegesException | TooManyEnvironmentsException | CommonErrors;
/**
 * Create or update a group of environments that each run a separate component of a single
 * application. Takes a list of version labels that specify application source bundles for each
 * of the environments to create or update. The name of each environment and other required
 * information must be included in the source bundles in an environment manifest named
 * `env.yaml`. See Compose Environments
 * for details.
 */
export declare const composeEnvironments: API.OperationMethod<ComposeEnvironmentsMessage, EnvironmentDescriptionsMessage, ComposeEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = TooManyApplicationsException | CommonErrors;
/**
 * Creates an application that has one configuration template named `default`
 * and no application versions.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationMessage, ApplicationDescriptionMessage, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationVersionError = CodeBuildNotInServiceRegionException | InsufficientPrivilegesException | S3LocationNotInServiceRegionException | TooManyApplicationsException | TooManyApplicationVersionsException | CommonErrors;
/**
 * Creates an application version for the specified application. You can create an
 * application version from a source bundle in Amazon S3, a commit in AWS CodeCommit, or the
 * output of an AWS CodeBuild build as follows:
 *
 * Specify a commit in an AWS CodeCommit repository with
 * `SourceBuildInformation`.
 *
 * Specify a build in an AWS CodeBuild with `SourceBuildInformation` and
 * `BuildConfiguration`.
 *
 * Specify a source bundle in S3 with `SourceBundle`
 *
 * Omit both `SourceBuildInformation` and `SourceBundle` to use the
 * default sample application.
 *
 * After you create an application version with a specified Amazon S3 bucket and key
 * location, you can't change that Amazon S3 location. If you change the Amazon S3 location,
 * you receive an exception when you attempt to launch an environment from the application
 * version.
 */
export declare const createApplicationVersion: API.OperationMethod<CreateApplicationVersionMessage, ApplicationVersionDescriptionMessage, CreateApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationTemplateError = InsufficientPrivilegesException | TooManyBucketsException | TooManyConfigurationTemplatesException | CommonErrors;
/**
 * Creates an AWS Elastic Beanstalk configuration template, associated with a specific Elastic Beanstalk
 * application. You define application configuration settings in a configuration template. You
 * can then use the configuration template to deploy different versions of the application with
 * the same configuration settings.
 *
 * Templates aren't associated with any environment. The `EnvironmentName`
 * response element is always `null`.
 *
 * Related Topics
 *
 * - DescribeConfigurationOptions
 *
 * - DescribeConfigurationSettings
 *
 * - ListAvailableSolutionStacks
 */
export declare const createConfigurationTemplate: API.OperationMethod<CreateConfigurationTemplateMessage, ConfigurationSettingsDescription, CreateConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = InsufficientPrivilegesException | TooManyEnvironmentsException | CommonErrors;
/**
 * Launches an AWS Elastic Beanstalk environment for the specified application using the specified
 * configuration.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentMessage, EnvironmentDescription, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreatePlatformVersionError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | TooManyPlatformsException | CommonErrors;
/**
 * Create a new version of your custom platform.
 */
export declare const createPlatformVersion: API.OperationMethod<CreatePlatformVersionRequest, CreatePlatformVersionResult, CreatePlatformVersionError, Credentials | HttpClient.HttpClient>;
export type CreateStorageLocationError = InsufficientPrivilegesException | S3SubscriptionRequiredException | TooManyBucketsException | CommonErrors;
/**
 * Creates a bucket in Amazon S3 to store application versions, logs, and other files used
 * by Elastic Beanstalk environments. The Elastic Beanstalk console and EB CLI call this API the
 * first time you create an environment in a region. If the storage location already exists,
 * `CreateStorageLocation` still returns the bucket name but does not create a new
 * bucket.
 */
export declare const createStorageLocation: API.OperationMethod<CreateStorageLocationRequest, CreateStorageLocationResultMessage, CreateStorageLocationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = OperationInProgressException | CommonErrors;
/**
 * Deletes the specified application along with all associated versions and
 * configurations. The application versions will not be deleted from your Amazon S3
 * bucket.
 *
 * You cannot delete an application that has a running environment.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationMessage, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationVersionError = InsufficientPrivilegesException | OperationInProgressException | S3LocationNotInServiceRegionException | SourceBundleDeletionException | CommonErrors;
/**
 * Deletes the specified version from the specified application.
 *
 * You cannot delete an application version that is associated with a running
 * environment.
 */
export declare const deleteApplicationVersion: API.OperationMethod<DeleteApplicationVersionMessage, DeleteApplicationVersionResponse, DeleteApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationTemplateError = OperationInProgressException | CommonErrors;
/**
 * Deletes the specified configuration template.
 *
 * When you launch an environment using a configuration template, the environment gets a
 * copy of the template. You can delete or modify the environment's copy of the template
 * without affecting the running environment.
 */
export declare const deleteConfigurationTemplate: API.OperationMethod<DeleteConfigurationTemplateMessage, DeleteConfigurationTemplateResponse, DeleteConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentConfigurationError = CommonErrors;
/**
 * Deletes the draft configuration associated with the running environment.
 *
 * Updating a running environment with any configuration changes creates a draft
 * configuration set. You can get the draft configuration using DescribeConfigurationSettings while the update is in progress or if the update
 * fails. The `DeploymentStatus` for the draft configuration indicates whether the
 * deployment is in process or has failed. The draft configuration remains in existence until it
 * is deleted with this action.
 */
export declare const deleteEnvironmentConfiguration: API.OperationMethod<DeleteEnvironmentConfigurationMessage, DeleteEnvironmentConfigurationResponse, DeleteEnvironmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePlatformVersionError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | OperationInProgressException | PlatformVersionStillReferencedException | CommonErrors;
/**
 * Deletes the specified version of a custom platform.
 */
export declare const deletePlatformVersion: API.OperationMethod<DeletePlatformVersionRequest, DeletePlatformVersionResult, DeletePlatformVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAttributesError = InsufficientPrivilegesException | CommonErrors;
/**
 * Returns attributes related to AWS Elastic Beanstalk that are associated with the calling AWS
 * account.
 *
 * The result currently has one set of attributes—resource quotas.
 */
export declare const describeAccountAttributes: API.OperationMethod<DescribeAccountAttributesRequest, DescribeAccountAttributesResult, DescribeAccountAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationsError = CommonErrors;
/**
 * Returns the descriptions of existing applications.
 */
export declare const describeApplications: API.OperationMethod<DescribeApplicationsMessage, ApplicationDescriptionsMessage, DescribeApplicationsError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationVersionsError = CommonErrors;
/**
 * Retrieve a list of application versions.
 */
export declare const describeApplicationVersions: API.OperationMethod<DescribeApplicationVersionsMessage, ApplicationVersionDescriptionsMessage, DescribeApplicationVersionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationOptionsError = TooManyBucketsException | CommonErrors;
/**
 * Describes the configuration options that are used in a particular configuration
 * template or environment, or that a specified solution stack defines. The description includes
 * the values the options, their default values, and an indication of the required action on a
 * running environment if an option value is changed.
 */
export declare const describeConfigurationOptions: API.OperationMethod<DescribeConfigurationOptionsMessage, ConfigurationOptionsDescription, DescribeConfigurationOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationSettingsError = TooManyBucketsException | CommonErrors;
/**
 * Returns a description of the settings for the specified configuration set, that is,
 * either a configuration template or the configuration set associated with a running
 * environment.
 *
 * When describing the settings for the configuration set associated with a running
 * environment, it is possible to receive two sets of setting descriptions. One is the deployed
 * configuration set, and the other is a draft configuration of an environment that is either in
 * the process of deployment or that failed to deploy.
 *
 * Related Topics
 *
 * - DeleteEnvironmentConfiguration
 */
export declare const describeConfigurationSettings: API.OperationMethod<DescribeConfigurationSettingsMessage, ConfigurationSettingsDescriptions, DescribeConfigurationSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentHealthError = ElasticBeanstalkServiceException | InvalidRequestException | CommonErrors;
/**
 * Returns information about the overall health of the specified environment. The
 * **DescribeEnvironmentHealth** operation is only available with
 * AWS Elastic Beanstalk Enhanced Health.
 */
export declare const describeEnvironmentHealth: API.OperationMethod<DescribeEnvironmentHealthRequest, DescribeEnvironmentHealthResult, DescribeEnvironmentHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentManagedActionHistoryError = ElasticBeanstalkServiceException | CommonErrors;
/**
 * Lists an environment's completed and failed managed actions.
 */
export declare const describeEnvironmentManagedActionHistory: API.PaginatedOperationMethod<DescribeEnvironmentManagedActionHistoryRequest, DescribeEnvironmentManagedActionHistoryResult, DescribeEnvironmentManagedActionHistoryError, Credentials | HttpClient.HttpClient, ManagedActionHistoryItem>;
export type DescribeEnvironmentManagedActionsError = ElasticBeanstalkServiceException | CommonErrors;
/**
 * Lists an environment's upcoming and in-progress managed actions.
 */
export declare const describeEnvironmentManagedActions: API.OperationMethod<DescribeEnvironmentManagedActionsRequest, DescribeEnvironmentManagedActionsResult, DescribeEnvironmentManagedActionsError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentResourcesError = InsufficientPrivilegesException | CommonErrors;
/**
 * Returns AWS resources for this environment.
 */
export declare const describeEnvironmentResources: API.OperationMethod<DescribeEnvironmentResourcesMessage, EnvironmentResourceDescriptionsMessage, DescribeEnvironmentResourcesError, Credentials | HttpClient.HttpClient>;
export type DescribeEnvironmentsError = CommonErrors;
/**
 * Returns descriptions for existing environments.
 */
export declare const describeEnvironments: API.OperationMethod<DescribeEnvironmentsMessage, EnvironmentDescriptionsMessage, DescribeEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns list of event descriptions matching criteria up to the last 6 weeks.
 *
 * This action returns the most recent 1,000 events from the specified
 * `NextToken`.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, EventDescriptionsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, EventDescription>;
export type DescribeInstancesHealthError = ElasticBeanstalkServiceException | InvalidRequestException | CommonErrors;
/**
 * Retrieves detailed information about the health of instances in your AWS Elastic
 * Beanstalk. This operation requires enhanced health
 * reporting.
 */
export declare const describeInstancesHealth: API.OperationMethod<DescribeInstancesHealthRequest, DescribeInstancesHealthResult, DescribeInstancesHealthError, Credentials | HttpClient.HttpClient>;
export type DescribePlatformVersionError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | CommonErrors;
/**
 * Describes a platform version. Provides full details. Compare to ListPlatformVersions, which provides summary information about a list of
 * platform versions.
 *
 * For definitions of platform version and other platform-related terms, see AWS Elastic Beanstalk
 * Platforms Glossary.
 */
export declare const describePlatformVersion: API.OperationMethod<DescribePlatformVersionRequest, DescribePlatformVersionResult, DescribePlatformVersionError, Credentials | HttpClient.HttpClient>;
export type DisassociateEnvironmentOperationsRoleError = InsufficientPrivilegesException | CommonErrors;
/**
 * Disassociate the operations role from an environment. After this call is made, Elastic Beanstalk uses
 * the caller's permissions for permissions to downstream services during subsequent calls acting
 * on this environment. For more information, see Operations roles in the
 * *AWS Elastic Beanstalk Developer Guide*.
 */
export declare const disassociateEnvironmentOperationsRole: API.OperationMethod<DisassociateEnvironmentOperationsRoleMessage, DisassociateEnvironmentOperationsRoleResponse, DisassociateEnvironmentOperationsRoleError, Credentials | HttpClient.HttpClient>;
export type ListAvailableSolutionStacksError = CommonErrors;
/**
 * Returns a list of the available solution stack names, with the public version first and
 * then in reverse chronological order.
 */
export declare const listAvailableSolutionStacks: API.OperationMethod<ListAvailableSolutionStacksRequest, ListAvailableSolutionStacksResultMessage, ListAvailableSolutionStacksError, Credentials | HttpClient.HttpClient>;
export type ListPlatformBranchesError = CommonErrors;
/**
 * Lists the platform branches available for your account in an AWS Region. Provides
 * summary information about each platform branch.
 *
 * For definitions of platform branch and other platform-related terms, see AWS Elastic Beanstalk
 * Platforms Glossary.
 */
export declare const listPlatformBranches: API.PaginatedOperationMethod<ListPlatformBranchesRequest, ListPlatformBranchesResult, ListPlatformBranchesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPlatformVersionsError = ElasticBeanstalkServiceException | InsufficientPrivilegesException | CommonErrors;
/**
 * Lists the platform versions available for your account in an AWS Region. Provides
 * summary information about each platform version. Compare to DescribePlatformVersion, which provides full details about a single platform
 * version.
 *
 * For definitions of platform version and other platform-related terms, see AWS Elastic Beanstalk
 * Platforms Glossary.
 */
export declare const listPlatformVersions: API.PaginatedOperationMethod<ListPlatformVersionsRequest, ListPlatformVersionsResult, ListPlatformVersionsError, Credentials | HttpClient.HttpClient, PlatformSummary>;
export type ListTagsForResourceError = InsufficientPrivilegesException | ResourceNotFoundException | ResourceTypeNotSupportedException | CommonErrors;
/**
 * Return the tags applied to an AWS Elastic Beanstalk resource. The response contains a list of tag key-value pairs.
 *
 * Elastic Beanstalk supports tagging of all of its resources. For details about resource tagging, see
 * Tagging Application
 * Resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage, ResourceTagsDescriptionMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RebuildEnvironmentError = InsufficientPrivilegesException | CommonErrors;
/**
 * Deletes and recreates all of the AWS resources (for example: the Auto Scaling group,
 * load balancer, etc.) for a specified environment and forces a restart.
 */
export declare const rebuildEnvironment: API.OperationMethod<RebuildEnvironmentMessage, RebuildEnvironmentResponse, RebuildEnvironmentError, Credentials | HttpClient.HttpClient>;
export type RequestEnvironmentInfoError = CommonErrors;
/**
 * Initiates a request to compile the specified type of information of the deployed
 * environment.
 *
 * Setting the `InfoType` to `tail` compiles the last lines from
 * the application server log files of every Amazon EC2 instance in your environment.
 *
 * Setting the `InfoType` to `bundle` compresses the application
 * server log files for every Amazon EC2 instance into a `.zip` file. Legacy and .NET
 * containers do not support bundle logs.
 *
 * Setting the `InfoType` to `analyze` collects recent events,
 * instance health, and logs from your environment and sends them to Amazon Bedrock in your
 * account to generate diagnostic insights and recommended next steps.
 *
 * Use RetrieveEnvironmentInfo to obtain the set of logs.
 *
 * Related Topics
 *
 * - RetrieveEnvironmentInfo
 */
export declare const requestEnvironmentInfo: API.OperationMethod<RequestEnvironmentInfoMessage, RequestEnvironmentInfoResponse, RequestEnvironmentInfoError, Credentials | HttpClient.HttpClient>;
export type RestartAppServerError = CommonErrors;
/**
 * Causes the environment to restart the application container server running on each
 * Amazon EC2 instance.
 */
export declare const restartAppServer: API.OperationMethod<RestartAppServerMessage, RestartAppServerResponse, RestartAppServerError, Credentials | HttpClient.HttpClient>;
export type RetrieveEnvironmentInfoError = CommonErrors;
/**
 * Retrieves the compiled information from a RequestEnvironmentInfo
 * request.
 *
 * Related Topics
 *
 * - RequestEnvironmentInfo
 */
export declare const retrieveEnvironmentInfo: API.OperationMethod<RetrieveEnvironmentInfoMessage, RetrieveEnvironmentInfoResultMessage, RetrieveEnvironmentInfoError, Credentials | HttpClient.HttpClient>;
export type SwapEnvironmentCNAMEsError = CommonErrors;
/**
 * Swaps the CNAMEs of two environments.
 */
export declare const swapEnvironmentCNAMEs: API.OperationMethod<SwapEnvironmentCNAMEsMessage, SwapEnvironmentCNAMEsResponse, SwapEnvironmentCNAMEsError, Credentials | HttpClient.HttpClient>;
export type TerminateEnvironmentError = InsufficientPrivilegesException | CommonErrors;
/**
 * Terminates the specified environment.
 */
export declare const terminateEnvironment: API.OperationMethod<TerminateEnvironmentMessage, EnvironmentDescription, TerminateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = CommonErrors;
/**
 * Updates the specified application to have the specified properties.
 *
 * If a property (for example, `description`) is not provided, the value
 * remains unchanged. To clear these properties, specify an empty string.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationMessage, ApplicationDescriptionMessage, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationResourceLifecycleError = InsufficientPrivilegesException | CommonErrors;
/**
 * Modifies lifecycle settings for an application.
 */
export declare const updateApplicationResourceLifecycle: API.OperationMethod<UpdateApplicationResourceLifecycleMessage, ApplicationResourceLifecycleDescriptionMessage, UpdateApplicationResourceLifecycleError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationVersionError = CommonErrors;
/**
 * Updates the specified application version to have the specified properties.
 *
 * If a property (for example, `description`) is not provided, the value
 * remains unchanged. To clear properties, specify an empty string.
 */
export declare const updateApplicationVersion: API.OperationMethod<UpdateApplicationVersionMessage, ApplicationVersionDescriptionMessage, UpdateApplicationVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationTemplateError = InsufficientPrivilegesException | TooManyBucketsException | CommonErrors;
/**
 * Updates the specified configuration template to have the specified properties or
 * configuration option values.
 *
 * If a property (for example, `ApplicationName`) is not provided, its value
 * remains unchanged. To clear such properties, specify an empty string.
 *
 * Related Topics
 *
 * - DescribeConfigurationOptions
 */
export declare const updateConfigurationTemplate: API.OperationMethod<UpdateConfigurationTemplateMessage, ConfigurationSettingsDescription, UpdateConfigurationTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = InsufficientPrivilegesException | TooManyBucketsException | CommonErrors;
/**
 * Updates the environment description, deploys a new application version, updates the
 * configuration settings to an entirely new configuration template, or updates select
 * configuration option values in the running environment.
 *
 * Attempting to update both the release and configuration is not allowed and AWS Elastic
 * Beanstalk returns an `InvalidParameterCombination` error.
 *
 * When updating the configuration settings to a new template or individual settings, a
 * draft configuration is created and DescribeConfigurationSettings for this
 * environment returns two setting descriptions with different `DeploymentStatus`
 * values.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentMessage, EnvironmentDescription, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateTagsForResourceError = InsufficientPrivilegesException | OperationInProgressException | ResourceNotFoundException | ResourceTypeNotSupportedException | TooManyTagsException | CommonErrors;
/**
 * Update the list of tags applied to an AWS Elastic Beanstalk resource. Two lists can be passed: `TagsToAdd`
 * for tags to add or update, and `TagsToRemove`.
 *
 * Elastic Beanstalk supports tagging of all of its resources. For details about resource tagging, see
 * Tagging Application
 * Resources.
 *
 * If you create a custom IAM user policy to control permission to this operation, specify
 * one of the following two virtual actions (or both) instead of the API operation name:
 *
 * ### elasticbeanstalk:AddTags
 *
 * Controls permission to call `UpdateTagsForResource` and pass a list of tags to add in the `TagsToAdd`
 * parameter.
 *
 * ### elasticbeanstalk:RemoveTags
 *
 * Controls permission to call `UpdateTagsForResource` and pass a list of tag keys to remove in the `TagsToRemove`
 * parameter.
 *
 * For details about creating a custom user policy, see Creating a Custom User Policy.
 */
export declare const updateTagsForResource: API.OperationMethod<UpdateTagsForResourceMessage, UpdateTagsForResourceResponse, UpdateTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ValidateConfigurationSettingsError = InsufficientPrivilegesException | TooManyBucketsException | CommonErrors;
/**
 * Takes a set of configuration settings and either a configuration template or
 * environment, and determines whether those values are valid.
 *
 * This action returns a list of messages indicating any errors or warnings associated
 * with the selection of option values.
 */
export declare const validateConfigurationSettings: API.OperationMethod<ValidateConfigurationSettingsMessage, ConfigurationSettingsValidationMessages, ValidateConfigurationSettingsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elastic-beanstalk.d.ts.map