import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SensitiveBoolean = boolean;
export interface IsolineAllowOptions {
    Hot?: boolean;
    Hov?: boolean;
}
export declare const IsolineAllowOptions: S.Schema<IsolineAllowOptions>;
export type TimestampWithTimezoneOffset = string | redacted.Redacted<string>;
export type BoundingBox = number[];
export declare const BoundingBox: any;
export type Position = number[];
export declare const Position: any;
export type LineString = number[][];
export declare const LineString: any;
export interface Corridor {
    LineString: number[][];
    Radius: number;
}
export declare const Corridor: S.Schema<Corridor>;
export type LinearRing = number[][];
export declare const LinearRing: any;
export type LinearRings = number[][][];
export declare const LinearRings: any;
export type Polyline = string | redacted.Redacted<string>;
export interface PolylineCorridor {
    Polyline: string | redacted.Redacted<string>;
    Radius: number;
}
export declare const PolylineCorridor: S.Schema<PolylineCorridor>;
export type PolylineRing = string | redacted.Redacted<string>;
export type PolylineRingList = (string | redacted.Redacted<string>)[];
export declare const PolylineRingList: any;
export interface IsolineAvoidanceAreaGeometry {
    BoundingBox?: number[];
    Corridor?: Corridor;
    Polygon?: number[][][];
    PolylineCorridor?: PolylineCorridor;
    PolylinePolygon?: (string | redacted.Redacted<string>)[];
}
export declare const IsolineAvoidanceAreaGeometry: S.Schema<IsolineAvoidanceAreaGeometry>;
export type IsolineAvoidanceAreaGeometryList = IsolineAvoidanceAreaGeometry[];
export declare const IsolineAvoidanceAreaGeometryList: any;
export interface IsolineAvoidanceArea {
    Except?: IsolineAvoidanceAreaGeometry[];
    Geometry: IsolineAvoidanceAreaGeometry;
}
export declare const IsolineAvoidanceArea: S.Schema<IsolineAvoidanceArea>;
export type IsolineAvoidanceAreaList = IsolineAvoidanceArea[];
export declare const IsolineAvoidanceAreaList: any;
export type TruckRoadType = string | redacted.Redacted<string>;
export type TruckRoadTypeList = (string | redacted.Redacted<string>)[];
export declare const TruckRoadTypeList: any;
export type IsolineZoneCategory = "CongestionPricing" | "Environmental" | "Vignette" | (string & {});
export declare const IsolineZoneCategory: any;
export interface IsolineAvoidanceZoneCategory {
    Category?: IsolineZoneCategory;
}
export declare const IsolineAvoidanceZoneCategory: S.Schema<IsolineAvoidanceZoneCategory>;
export type IsolineAvoidanceZoneCategoryList = IsolineAvoidanceZoneCategory[];
export declare const IsolineAvoidanceZoneCategoryList: any;
export interface IsolineAvoidanceOptions {
    Areas?: IsolineAvoidanceArea[];
    CarShuttleTrains?: boolean;
    ControlledAccessHighways?: boolean;
    DirtRoads?: boolean;
    Ferries?: boolean;
    SeasonalClosure?: boolean;
    TollRoads?: boolean;
    TollTransponders?: boolean;
    TruckRoadTypes?: (string | redacted.Redacted<string>)[];
    Tunnels?: boolean;
    UTurns?: boolean;
    ZoneCategories?: IsolineAvoidanceZoneCategory[];
}
export declare const IsolineAvoidanceOptions: S.Schema<IsolineAvoidanceOptions>;
export type DistanceMeters = number;
export type Heading = number;
export type SensitiveString = string | redacted.Redacted<string>;
export type MatchingStrategy = "MatchAny" | "MatchMostSignificantRoad" | (string & {});
export declare const MatchingStrategy: any;
export interface IsolineMatchingOptions {
    NameHint?: string | redacted.Redacted<string>;
    OnRoadThreshold?: number;
    Radius?: number;
    Strategy?: MatchingStrategy;
}
export declare const IsolineMatchingOptions: S.Schema<IsolineMatchingOptions>;
export type SideOfStreetMatchingStrategy = "AnyStreet" | "DividedStreetOnly" | (string & {});
export declare const SideOfStreetMatchingStrategy: any;
export interface IsolineSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy;
}
export declare const IsolineSideOfStreetOptions: S.Schema<IsolineSideOfStreetOptions>;
export interface IsolineDestinationOptions {
    AvoidActionsForDistance?: number;
    Heading?: number;
    Matching?: IsolineMatchingOptions;
    SideOfStreet?: IsolineSideOfStreetOptions;
}
export declare const IsolineDestinationOptions: S.Schema<IsolineDestinationOptions>;
export type GeometryFormat = "FlexiblePolyline" | "Simple" | (string & {});
export declare const GeometryFormat: any;
export interface IsolineGranularityOptions {
    MaxPoints?: number;
    MaxResolution?: number;
}
export declare const IsolineGranularityOptions: S.Schema<IsolineGranularityOptions>;
export type ApiKey = string | redacted.Redacted<string>;
export type IsolineOptimizationObjective = "AccurateCalculation" | "BalancedCalculation" | "FastCalculation" | (string & {});
export declare const IsolineOptimizationObjective: any;
export type RoutingObjective = "FastestRoute" | "ShortestRoute" | (string & {});
export declare const RoutingObjective: any;
export interface IsolineOriginOptions {
    AvoidActionsForDistance?: number;
    Heading?: number;
    Matching?: IsolineMatchingOptions;
    SideOfStreet?: IsolineSideOfStreetOptions;
}
export declare const IsolineOriginOptions: S.Schema<IsolineOriginOptions>;
export type DistanceThresholdList = number[];
export declare const DistanceThresholdList: any;
export type DurationSeconds = number;
export type TimeThresholdList = number[];
export declare const TimeThresholdList: any;
export interface IsolineThresholds {
    Distance?: number[];
    Time?: number[];
}
export declare const IsolineThresholds: S.Schema<IsolineThresholds>;
export type TrafficUsage = "IgnoreTrafficData" | "UseTrafficData" | (string & {});
export declare const TrafficUsage: any;
export interface IsolineTrafficOptions {
    FlowEventThresholdOverride?: number;
    Usage?: TrafficUsage;
}
export declare const IsolineTrafficOptions: S.Schema<IsolineTrafficOptions>;
export type IsolineTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export declare const IsolineTravelMode: any;
export type IsolineEngineType = "Electric" | "InternalCombustion" | "PluginHybrid" | (string & {});
export declare const IsolineEngineType: any;
export interface IsolineVehicleLicensePlate {
    LastCharacter?: string;
}
export declare const IsolineVehicleLicensePlate: S.Schema<IsolineVehicleLicensePlate>;
export type SpeedKilometersPerHour = number;
export type SensitiveInteger = number;
export interface IsolineCarOptions {
    EngineType?: IsolineEngineType;
    LicensePlate?: IsolineVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
}
export declare const IsolineCarOptions: S.Schema<IsolineCarOptions>;
export interface IsolineScooterOptions {
    EngineType?: IsolineEngineType;
    LicensePlate?: IsolineVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
}
export declare const IsolineScooterOptions: S.Schema<IsolineScooterOptions>;
export type WeightKilograms = number;
export type IsolineHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export declare const IsolineHazardousCargoType: any;
export type IsolineHazardousCargoTypeList = IsolineHazardousCargoType[];
export declare const IsolineHazardousCargoTypeList: any;
export type DimensionCentimeters = number;
export interface IsolineTrailerOptions {
    AxleCount?: number;
    TrailerCount?: number;
}
export declare const IsolineTrailerOptions: S.Schema<IsolineTrailerOptions>;
export type IsolineTruckType = "LightTruck" | "StraightTruck" | "Tractor" | (string & {});
export declare const IsolineTruckType: any;
export type TunnelRestrictionCode = string | redacted.Redacted<string>;
export interface WeightPerAxleGroup {
    Single?: number;
    Tandem?: number;
    Triple?: number;
    Quad?: number;
    Quint?: number;
}
export declare const WeightPerAxleGroup: S.Schema<WeightPerAxleGroup>;
export interface IsolineTruckOptions {
    AxleCount?: number;
    EngineType?: IsolineEngineType;
    GrossWeight?: number;
    HazardousCargos?: IsolineHazardousCargoType[];
    Height?: number;
    HeightAboveFirstAxle?: number;
    KpraLength?: number;
    Length?: number;
    LicensePlate?: IsolineVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
    PayloadCapacity?: number;
    TireCount?: number;
    Trailer?: IsolineTrailerOptions;
    TruckType?: IsolineTruckType;
    TunnelRestrictionCode?: string | redacted.Redacted<string>;
    WeightPerAxle?: number;
    WeightPerAxleGroup?: WeightPerAxleGroup;
    Width?: number;
}
export declare const IsolineTruckOptions: S.Schema<IsolineTruckOptions>;
export interface IsolineTravelModeOptions {
    Car?: IsolineCarOptions;
    Scooter?: IsolineScooterOptions;
    Truck?: IsolineTruckOptions;
}
export declare const IsolineTravelModeOptions: S.Schema<IsolineTravelModeOptions>;
export interface CalculateIsolinesRequest {
    Allow?: IsolineAllowOptions;
    ArrivalTime?: string | redacted.Redacted<string>;
    Avoid?: IsolineAvoidanceOptions;
    DepartNow?: boolean;
    DepartureTime?: string | redacted.Redacted<string>;
    Destination?: number[];
    DestinationOptions?: IsolineDestinationOptions;
    IsolineGeometryFormat?: GeometryFormat;
    IsolineGranularity?: IsolineGranularityOptions;
    Key?: string | redacted.Redacted<string>;
    OptimizeIsolineFor?: IsolineOptimizationObjective;
    OptimizeRoutingFor?: RoutingObjective;
    Origin?: number[];
    OriginOptions?: IsolineOriginOptions;
    Thresholds: IsolineThresholds;
    Traffic?: IsolineTrafficOptions;
    TravelMode?: IsolineTravelMode;
    TravelModeOptions?: IsolineTravelModeOptions;
}
export declare const CalculateIsolinesRequest: S.Schema<CalculateIsolinesRequest>;
export interface IsolineConnectionGeometry {
    LineString?: number[][];
    Polyline?: string | redacted.Redacted<string>;
}
export declare const IsolineConnectionGeometry: S.Schema<IsolineConnectionGeometry>;
export interface IsolineConnection {
    FromPolygonIndex: number;
    Geometry: IsolineConnectionGeometry;
    ToPolygonIndex: number;
}
export declare const IsolineConnection: S.Schema<IsolineConnection>;
export type IsolineConnectionList = IsolineConnection[];
export declare const IsolineConnectionList: any;
export interface IsolineShapeGeometry {
    Polygon?: number[][][];
    PolylinePolygon?: (string | redacted.Redacted<string>)[];
}
export declare const IsolineShapeGeometry: S.Schema<IsolineShapeGeometry>;
export type IsolineShapeGeometryList = IsolineShapeGeometry[];
export declare const IsolineShapeGeometryList: any;
export interface Isoline {
    Connections: IsolineConnection[];
    DistanceThreshold?: number;
    Geometries: IsolineShapeGeometry[];
    TimeThreshold?: number;
}
export declare const Isoline: S.Schema<Isoline>;
export type IsolineList = Isoline[];
export declare const IsolineList: any;
export interface CalculateIsolinesResponse {
    ArrivalTime?: string | redacted.Redacted<string>;
    DepartureTime?: string | redacted.Redacted<string>;
    IsolineGeometryFormat: GeometryFormat;
    Isolines: Isoline[];
    PricingBucket: string;
    SnappedDestination?: number[];
    SnappedOrigin?: number[];
}
export declare const CalculateIsolinesResponse: S.Schema<CalculateIsolinesResponse>;
export interface RouteMatrixAllowOptions {
    Hot?: boolean;
    Hov?: boolean;
}
export declare const RouteMatrixAllowOptions: S.Schema<RouteMatrixAllowOptions>;
export interface RouteMatrixAvoidanceAreaGeometry {
    BoundingBox?: number[];
    Polygon?: number[][][];
    PolylinePolygon?: (string | redacted.Redacted<string>)[];
}
export declare const RouteMatrixAvoidanceAreaGeometry: S.Schema<RouteMatrixAvoidanceAreaGeometry>;
export interface RouteMatrixAvoidanceArea {
    Geometry: RouteMatrixAvoidanceAreaGeometry;
}
export declare const RouteMatrixAvoidanceArea: S.Schema<RouteMatrixAvoidanceArea>;
export type RouteMatrixAvoidanceAreaList = RouteMatrixAvoidanceArea[];
export declare const RouteMatrixAvoidanceAreaList: any;
export type RouteMatrixZoneCategory = "CongestionPricing" | "Environmental" | "Vignette" | (string & {});
export declare const RouteMatrixZoneCategory: any;
export interface RouteMatrixAvoidanceZoneCategory {
    Category?: RouteMatrixZoneCategory;
}
export declare const RouteMatrixAvoidanceZoneCategory: S.Schema<RouteMatrixAvoidanceZoneCategory>;
export type RouteMatrixAvoidanceZoneCategoryList = RouteMatrixAvoidanceZoneCategory[];
export declare const RouteMatrixAvoidanceZoneCategoryList: any;
export interface RouteMatrixAvoidanceOptions {
    Areas?: RouteMatrixAvoidanceArea[];
    CarShuttleTrains?: boolean;
    ControlledAccessHighways?: boolean;
    DirtRoads?: boolean;
    Ferries?: boolean;
    TollRoads?: boolean;
    TollTransponders?: boolean;
    TruckRoadTypes?: (string | redacted.Redacted<string>)[];
    Tunnels?: boolean;
    UTurns?: boolean;
    ZoneCategories?: RouteMatrixAvoidanceZoneCategory[];
}
export declare const RouteMatrixAvoidanceOptions: S.Schema<RouteMatrixAvoidanceOptions>;
export interface RouteMatrixMatchingOptions {
    NameHint?: string | redacted.Redacted<string>;
    OnRoadThreshold?: number;
    Radius?: number;
    Strategy?: MatchingStrategy;
}
export declare const RouteMatrixMatchingOptions: S.Schema<RouteMatrixMatchingOptions>;
export interface RouteMatrixSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy;
}
export declare const RouteMatrixSideOfStreetOptions: S.Schema<RouteMatrixSideOfStreetOptions>;
export interface RouteMatrixDestinationOptions {
    AvoidActionsForDistance?: number;
    Heading?: number;
    Matching?: RouteMatrixMatchingOptions;
    SideOfStreet?: RouteMatrixSideOfStreetOptions;
}
export declare const RouteMatrixDestinationOptions: S.Schema<RouteMatrixDestinationOptions>;
export interface RouteMatrixDestination {
    Options?: RouteMatrixDestinationOptions;
    Position: number[];
}
export declare const RouteMatrixDestination: S.Schema<RouteMatrixDestination>;
export type RouteMatrixDestinationList = RouteMatrixDestination[];
export declare const RouteMatrixDestinationList: any;
export type CountryCode = string | redacted.Redacted<string>;
export type CountryCodeList = (string | redacted.Redacted<string>)[];
export declare const CountryCodeList: any;
export interface RouteMatrixExclusionOptions {
    Countries: (string | redacted.Redacted<string>)[];
}
export declare const RouteMatrixExclusionOptions: S.Schema<RouteMatrixExclusionOptions>;
export interface RouteMatrixOriginOptions {
    AvoidActionsForDistance?: number;
    Heading?: number;
    Matching?: RouteMatrixMatchingOptions;
    SideOfStreet?: RouteMatrixSideOfStreetOptions;
}
export declare const RouteMatrixOriginOptions: S.Schema<RouteMatrixOriginOptions>;
export interface RouteMatrixOrigin {
    Options?: RouteMatrixOriginOptions;
    Position: number[];
}
export declare const RouteMatrixOrigin: S.Schema<RouteMatrixOrigin>;
export type RouteMatrixOriginList = RouteMatrixOrigin[];
export declare const RouteMatrixOriginList: any;
export interface RouteMatrixAutoCircle {
    Margin?: number;
    MaxRadius?: number;
}
export declare const RouteMatrixAutoCircle: S.Schema<RouteMatrixAutoCircle>;
export type SensitiveDouble = number;
export interface Circle {
    Center: number[];
    Radius: number;
}
export declare const Circle: S.Schema<Circle>;
export interface RouteMatrixBoundaryGeometry {
    AutoCircle?: RouteMatrixAutoCircle;
    Circle?: Circle;
    BoundingBox?: number[];
    Polygon?: number[][][];
}
export declare const RouteMatrixBoundaryGeometry: S.Schema<RouteMatrixBoundaryGeometry>;
export interface RouteMatrixBoundary {
    Geometry?: RouteMatrixBoundaryGeometry;
    Unbounded?: boolean;
}
export declare const RouteMatrixBoundary: S.Schema<RouteMatrixBoundary>;
export interface RouteMatrixTrafficOptions {
    FlowEventThresholdOverride?: number;
    Usage?: TrafficUsage;
}
export declare const RouteMatrixTrafficOptions: S.Schema<RouteMatrixTrafficOptions>;
export type RouteMatrixTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export declare const RouteMatrixTravelMode: any;
export interface RouteMatrixVehicleLicensePlate {
    LastCharacter?: string;
}
export declare const RouteMatrixVehicleLicensePlate: S.Schema<RouteMatrixVehicleLicensePlate>;
export interface RouteMatrixCarOptions {
    LicensePlate?: RouteMatrixVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
}
export declare const RouteMatrixCarOptions: S.Schema<RouteMatrixCarOptions>;
export interface RouteMatrixScooterOptions {
    LicensePlate?: RouteMatrixVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
}
export declare const RouteMatrixScooterOptions: S.Schema<RouteMatrixScooterOptions>;
export type RouteMatrixHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export declare const RouteMatrixHazardousCargoType: any;
export type RouteMatrixHazardousCargoTypeList = RouteMatrixHazardousCargoType[];
export declare const RouteMatrixHazardousCargoTypeList: any;
export interface RouteMatrixTrailerOptions {
    TrailerCount?: number;
}
export declare const RouteMatrixTrailerOptions: S.Schema<RouteMatrixTrailerOptions>;
export type RouteMatrixTruckType = "LightTruck" | "StraightTruck" | "Tractor" | (string & {});
export declare const RouteMatrixTruckType: any;
export interface RouteMatrixTruckOptions {
    AxleCount?: number;
    GrossWeight?: number;
    HazardousCargos?: RouteMatrixHazardousCargoType[];
    Height?: number;
    KpraLength?: number;
    Length?: number;
    LicensePlate?: RouteMatrixVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
    PayloadCapacity?: number;
    Trailer?: RouteMatrixTrailerOptions;
    TruckType?: RouteMatrixTruckType;
    TunnelRestrictionCode?: string | redacted.Redacted<string>;
    WeightPerAxle?: number;
    WeightPerAxleGroup?: WeightPerAxleGroup;
    Width?: number;
}
export declare const RouteMatrixTruckOptions: S.Schema<RouteMatrixTruckOptions>;
export interface RouteMatrixTravelModeOptions {
    Car?: RouteMatrixCarOptions;
    Scooter?: RouteMatrixScooterOptions;
    Truck?: RouteMatrixTruckOptions;
}
export declare const RouteMatrixTravelModeOptions: S.Schema<RouteMatrixTravelModeOptions>;
export interface CalculateRouteMatrixRequest {
    Allow?: RouteMatrixAllowOptions;
    Avoid?: RouteMatrixAvoidanceOptions;
    DepartNow?: boolean;
    DepartureTime?: string | redacted.Redacted<string>;
    Destinations: RouteMatrixDestination[];
    Exclude?: RouteMatrixExclusionOptions;
    Key?: string | redacted.Redacted<string>;
    OptimizeRoutingFor?: RoutingObjective;
    Origins: RouteMatrixOrigin[];
    RoutingBoundary?: RouteMatrixBoundary;
    Traffic?: RouteMatrixTrafficOptions;
    TravelMode?: RouteMatrixTravelMode;
    TravelModeOptions?: RouteMatrixTravelModeOptions;
}
export declare const CalculateRouteMatrixRequest: S.Schema<CalculateRouteMatrixRequest>;
export type RouteMatrixErrorCode = "NoMatch" | "NoMatchDestination" | "NoMatchOrigin" | "NoRoute" | "OutOfBounds" | "OutOfBoundsDestination" | "OutOfBoundsOrigin" | "Other" | "Violation" | (string & {});
export declare const RouteMatrixErrorCode: any;
export interface RouteMatrixEntry {
    Distance: number;
    Duration: number;
    Error?: RouteMatrixErrorCode;
}
export declare const RouteMatrixEntry: S.Schema<RouteMatrixEntry>;
export type RouteMatrixRow = RouteMatrixEntry[];
export declare const RouteMatrixRow: any;
export type RouteMatrix = RouteMatrixEntry[][];
export declare const RouteMatrix: any;
export interface CalculateRouteMatrixResponse {
    ErrorCount: number;
    PricingBucket: string;
    RouteMatrix: RouteMatrixEntry[][];
    RoutingBoundary: RouteMatrixBoundary;
}
export declare const CalculateRouteMatrixResponse: S.Schema<CalculateRouteMatrixResponse>;
export interface RouteAllowOptions {
    Hot?: boolean;
    Hov?: boolean;
}
export declare const RouteAllowOptions: S.Schema<RouteAllowOptions>;
export interface RouteAvoidanceAreaGeometry {
    Corridor?: Corridor;
    BoundingBox?: number[];
    Polygon?: number[][][];
    PolylineCorridor?: PolylineCorridor;
    PolylinePolygon?: (string | redacted.Redacted<string>)[];
}
export declare const RouteAvoidanceAreaGeometry: S.Schema<RouteAvoidanceAreaGeometry>;
export type RouteAvoidanceAreaGeometryList = RouteAvoidanceAreaGeometry[];
export declare const RouteAvoidanceAreaGeometryList: any;
export interface RouteAvoidanceArea {
    Except?: RouteAvoidanceAreaGeometry[];
    Geometry: RouteAvoidanceAreaGeometry;
}
export declare const RouteAvoidanceArea: S.Schema<RouteAvoidanceArea>;
export type RouteAvoidanceAreaList = RouteAvoidanceArea[];
export declare const RouteAvoidanceAreaList: any;
export type RouteZoneCategory = "CongestionPricing" | "Environmental" | "Vignette" | (string & {});
export declare const RouteZoneCategory: any;
export interface RouteAvoidanceZoneCategory {
    Category: RouteZoneCategory;
}
export declare const RouteAvoidanceZoneCategory: S.Schema<RouteAvoidanceZoneCategory>;
export type RouteAvoidanceZoneCategoryList = RouteAvoidanceZoneCategory[];
export declare const RouteAvoidanceZoneCategoryList: any;
export interface RouteAvoidanceOptions {
    Areas?: RouteAvoidanceArea[];
    CarShuttleTrains?: boolean;
    ControlledAccessHighways?: boolean;
    DirtRoads?: boolean;
    Ferries?: boolean;
    SeasonalClosure?: boolean;
    TollRoads?: boolean;
    TollTransponders?: boolean;
    TruckRoadTypes?: (string | redacted.Redacted<string>)[];
    Tunnels?: boolean;
    UTurns?: boolean;
    ZoneCategories?: RouteAvoidanceZoneCategory[];
}
export declare const RouteAvoidanceOptions: S.Schema<RouteAvoidanceOptions>;
export interface RouteMatchingOptions {
    NameHint?: string | redacted.Redacted<string>;
    OnRoadThreshold?: number;
    Radius?: number;
    Strategy?: MatchingStrategy;
}
export declare const RouteMatchingOptions: S.Schema<RouteMatchingOptions>;
export interface RouteSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy;
}
export declare const RouteSideOfStreetOptions: S.Schema<RouteSideOfStreetOptions>;
export interface RouteDestinationOptions {
    AvoidActionsForDistance?: number;
    AvoidUTurns?: boolean;
    Heading?: number;
    Matching?: RouteMatchingOptions;
    SideOfStreet?: RouteSideOfStreetOptions;
    StopDuration?: number;
}
export declare const RouteDestinationOptions: S.Schema<RouteDestinationOptions>;
export interface RouteDriverScheduleInterval {
    DriveDuration: number;
    RestDuration: number;
}
export declare const RouteDriverScheduleInterval: S.Schema<RouteDriverScheduleInterval>;
export type RouteDriverScheduleIntervalList = RouteDriverScheduleInterval[];
export declare const RouteDriverScheduleIntervalList: any;
export interface RouteDriverOptions {
    Schedule?: RouteDriverScheduleInterval[];
}
export declare const RouteDriverOptions: S.Schema<RouteDriverOptions>;
export interface RouteExclusionOptions {
    Countries: (string | redacted.Redacted<string>)[];
}
export declare const RouteExclusionOptions: S.Schema<RouteExclusionOptions>;
export type MeasurementSystem = "Metric" | "Imperial" | (string & {});
export declare const MeasurementSystem: any;
export type LanguageTag = string;
export type LanguageTagList = string[];
export declare const LanguageTagList: any;
export type RouteLegAdditionalFeature = "Elevation" | "Incidents" | "PassThroughWaypoints" | "Summary" | "Tolls" | "TravelStepInstructions" | "TruckRoadTypes" | "TypicalDuration" | "Zones" | "Bookings" | "IntermediateStops" | "NextDepartures" | (string & {});
export declare const RouteLegAdditionalFeature: any;
export type RouteLegAdditionalFeatureList = RouteLegAdditionalFeature[];
export declare const RouteLegAdditionalFeatureList: any;
export interface RouteOriginOptions {
    AvoidActionsForDistance?: number;
    AvoidUTurns?: boolean;
    Heading?: number;
    Matching?: RouteMatchingOptions;
    SideOfStreet?: RouteSideOfStreetOptions;
}
export declare const RouteOriginOptions: S.Schema<RouteOriginOptions>;
export type RouteSpanAdditionalFeature = "BestCaseDuration" | "CarAccess" | "Country" | "Distance" | "Duration" | "DynamicSpeed" | "FunctionalClassification" | "Gates" | "Incidents" | "Names" | "Notices" | "PedestrianAccess" | "RailwayCrossings" | "Region" | "RoadAttributes" | "RouteNumbers" | "ScooterAccess" | "SpeedLimit" | "TollSystems" | "TruckAccess" | "TruckRoadTypes" | "TypicalDuration" | "Zones" | "Consumption" | (string & {});
export declare const RouteSpanAdditionalFeature: any;
export type RouteSpanAdditionalFeatureList = RouteSpanAdditionalFeature[];
export declare const RouteSpanAdditionalFeatureList: any;
export type CurrencyCode = string;
export interface RouteEmissionType {
    Co2EmissionClass?: string | redacted.Redacted<string>;
    Type: string | redacted.Redacted<string>;
}
export declare const RouteEmissionType: S.Schema<RouteEmissionType>;
export type RouteTollVehicleCategory = "Minibus" | (string & {});
export declare const RouteTollVehicleCategory: any;
export interface RouteTollOptions {
    AllTransponders?: boolean;
    AllVignettes?: boolean;
    Currency?: string;
    EmissionType?: RouteEmissionType;
    VehicleCategory?: RouteTollVehicleCategory;
}
export declare const RouteTollOptions: S.Schema<RouteTollOptions>;
export interface RouteTrafficOptions {
    FlowEventThresholdOverride?: number;
    Usage?: TrafficUsage;
}
export declare const RouteTrafficOptions: S.Schema<RouteTrafficOptions>;
export type RouteTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | "Intermodal" | "Transit" | (string & {});
export declare const RouteTravelMode: any;
export type RouteEngineType = "Electric" | "InternalCombustion" | "PluginHybrid" | (string & {});
export declare const RouteEngineType: any;
export interface RouteVehicleLicensePlate {
    LastCharacter?: string | redacted.Redacted<string>;
}
export declare const RouteVehicleLicensePlate: S.Schema<RouteVehicleLicensePlate>;
export interface RouteCarOptions {
    EngineType?: RouteEngineType;
    LicensePlate?: RouteVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
}
export declare const RouteCarOptions: S.Schema<RouteCarOptions>;
export interface RoutePedestrianOptions {
    Speed?: number;
}
export declare const RoutePedestrianOptions: S.Schema<RoutePedestrianOptions>;
export interface RouteScooterOptions {
    EngineType?: RouteEngineType;
    LicensePlate?: RouteVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
}
export declare const RouteScooterOptions: S.Schema<RouteScooterOptions>;
export type RouteHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export declare const RouteHazardousCargoType: any;
export type RouteHazardousCargoTypeList = RouteHazardousCargoType[];
export declare const RouteHazardousCargoTypeList: any;
export interface RouteTrailerOptions {
    AxleCount?: number;
    TrailerCount?: number;
}
export declare const RouteTrailerOptions: S.Schema<RouteTrailerOptions>;
export type RouteTruckType = "LightTruck" | "StraightTruck" | "Tractor" | (string & {});
export declare const RouteTruckType: any;
export interface RouteTruckOptions {
    AxleCount?: number;
    EngineType?: RouteEngineType;
    GrossWeight?: number;
    HazardousCargos?: RouteHazardousCargoType[];
    Height?: number;
    HeightAboveFirstAxle?: number;
    KpraLength?: number;
    Length?: number;
    LicensePlate?: RouteVehicleLicensePlate;
    MaxSpeed?: number;
    Occupancy?: number;
    PayloadCapacity?: number;
    TireCount?: number;
    Trailer?: RouteTrailerOptions;
    TruckType?: RouteTruckType;
    TunnelRestrictionCode?: string | redacted.Redacted<string>;
    WeightPerAxle?: number;
    WeightPerAxleGroup?: WeightPerAxleGroup;
    Width?: number;
}
export declare const RouteTruckOptions: S.Schema<RouteTruckOptions>;
export type RouteAccessibilityAttribute = "Wheelchair" | (string & {});
export declare const RouteAccessibilityAttribute: any;
export type RouteAccessibilityAttributeList = RouteAccessibilityAttribute[];
export declare const RouteAccessibilityAttributeList: any;
export interface RouteIntermodalPedestrianOptions {
    MaxDistance?: number;
    Speed?: number;
}
export declare const RouteIntermodalPedestrianOptions: S.Schema<RouteIntermodalPedestrianOptions>;
export type RouteRentalMode = "All" | "Car" | (string & {});
export declare const RouteRentalMode: any;
export type RouteRentalModeList = RouteRentalMode[];
export declare const RouteRentalModeList: any;
export type RouteIntermodalEnabledLegs = "FirstLeg" | "LastLeg" | "EntireRoute" | "None" | (string & {});
export declare const RouteIntermodalEnabledLegs: any;
export type RouteIntermodalEnabledLegsList = RouteIntermodalEnabledLegs[];
export declare const RouteIntermodalEnabledLegsList: any;
export interface RouteIntermodalRentalOptions {
    AllowedModes?: RouteRentalMode[];
    EnabledFor?: RouteIntermodalEnabledLegs[];
    ExcludedModes?: RouteRentalMode[];
}
export declare const RouteIntermodalRentalOptions: S.Schema<RouteIntermodalRentalOptions>;
export type RouteTaxiMode = "All" | "Car" | (string & {});
export declare const RouteTaxiMode: any;
export type RouteTaxiModeList = RouteTaxiMode[];
export declare const RouteTaxiModeList: any;
export interface RouteIntermodalTaxiOptions {
    AllowedModes?: RouteTaxiMode[];
    EnabledFor?: RouteIntermodalEnabledLegs[];
    ExcludedModes?: RouteTaxiMode[];
}
export declare const RouteIntermodalTaxiOptions: S.Schema<RouteIntermodalTaxiOptions>;
export type RouteTransitMode = "AerialTramway" | "Airplane" | "All" | "Bus" | "BusRapidTransit" | "CityTrain" | "Ferry" | "FunicularRailway" | "HighSpeedTrain" | "IntercityTrain" | "InterregionalTrain" | "LightRail" | "Monorail" | "PrivateBus" | "RegionalTrain" | "Subway" | (string & {});
export declare const RouteTransitMode: any;
export type RouteTransitModeList = RouteTransitMode[];
export declare const RouteTransitModeList: any;
export interface RouteIntermodalTransitOptions {
    AllowedModes?: RouteTransitMode[];
    EnabledFor?: RouteIntermodalEnabledLegs[];
    ExcludedModes?: RouteTransitMode[];
}
export declare const RouteIntermodalTransitOptions: S.Schema<RouteIntermodalTransitOptions>;
export type RouteVehicleMode = "All" | "Car" | (string & {});
export declare const RouteVehicleMode: any;
export type RouteVehicleModeList = RouteVehicleMode[];
export declare const RouteVehicleModeList: any;
export interface RouteIntermodalVehicleOptions {
    AllowedModes?: RouteVehicleMode[];
    EnabledFor?: RouteIntermodalEnabledLegs[];
    ExcludedModes?: RouteVehicleMode[];
}
export declare const RouteIntermodalVehicleOptions: S.Schema<RouteIntermodalVehicleOptions>;
export interface RouteIntermodalOptions {
    AccessibilityAttributes?: RouteAccessibilityAttribute[];
    MaxTransfers?: number;
    Pedestrian?: RouteIntermodalPedestrianOptions;
    Rental?: RouteIntermodalRentalOptions;
    Taxi?: RouteIntermodalTaxiOptions;
    Transit?: RouteIntermodalTransitOptions;
    Vehicle?: RouteIntermodalVehicleOptions;
}
export declare const RouteIntermodalOptions: S.Schema<RouteIntermodalOptions>;
export interface RouteTransitPedestrianOptions {
    MaxDistance?: number;
    Speed?: number;
}
export declare const RouteTransitPedestrianOptions: S.Schema<RouteTransitPedestrianOptions>;
export interface RouteTransitOptions {
    AccessibilityAttributes?: RouteAccessibilityAttribute[];
    AllowedModes?: RouteTransitMode[];
    ExcludedModes?: RouteTransitMode[];
    MaxTransfers?: number;
    Pedestrian?: RouteTransitPedestrianOptions;
}
export declare const RouteTransitOptions: S.Schema<RouteTransitOptions>;
export interface RouteTravelModeOptions {
    Car?: RouteCarOptions;
    Pedestrian?: RoutePedestrianOptions;
    Scooter?: RouteScooterOptions;
    Truck?: RouteTruckOptions;
    Intermodal?: RouteIntermodalOptions;
    Transit?: RouteTransitOptions;
}
export declare const RouteTravelModeOptions: S.Schema<RouteTravelModeOptions>;
export type RouteTravelStepType = "Default" | "TurnByTurn" | (string & {});
export declare const RouteTravelStepType: any;
export interface RouteWaypoint {
    AvoidActionsForDistance?: number;
    AvoidUTurns?: boolean;
    Heading?: number;
    Matching?: RouteMatchingOptions;
    PassThrough?: boolean;
    Position: number[];
    SideOfStreet?: RouteSideOfStreetOptions;
    StopDuration?: number;
}
export declare const RouteWaypoint: S.Schema<RouteWaypoint>;
export type RouteWaypointList = RouteWaypoint[];
export declare const RouteWaypointList: any;
export interface CalculateRoutesRequest {
    Allow?: RouteAllowOptions;
    ArrivalTime?: string | redacted.Redacted<string>;
    Avoid?: RouteAvoidanceOptions;
    DepartNow?: boolean;
    DepartureTime?: string | redacted.Redacted<string>;
    Destination: number[];
    DestinationOptions?: RouteDestinationOptions;
    Driver?: RouteDriverOptions;
    Exclude?: RouteExclusionOptions;
    InstructionsMeasurementSystem?: MeasurementSystem;
    Key?: string | redacted.Redacted<string>;
    Languages?: string[];
    LegAdditionalFeatures?: RouteLegAdditionalFeature[];
    LegGeometryFormat?: GeometryFormat;
    MaxAlternatives?: number;
    OptimizeRoutingFor?: RoutingObjective;
    Origin: number[];
    OriginOptions?: RouteOriginOptions;
    SpanAdditionalFeatures?: RouteSpanAdditionalFeature[];
    Tolls?: RouteTollOptions;
    Traffic?: RouteTrafficOptions;
    TravelMode?: RouteTravelMode;
    TravelModeOptions?: RouteTravelModeOptions;
    TravelStepType?: RouteTravelStepType;
    Waypoints?: RouteWaypoint[];
}
export declare const CalculateRoutesRequest: S.Schema<CalculateRoutesRequest>;
export type RouteResponseNoticeCode = "MainLanguageNotFound" | "Other" | "TravelTimeExceedsDriverWorkHours" | "TransitDataUnavailable" | "TransitRouteUnavailable" | "NoTransitStationsFound" | (string & {});
export declare const RouteResponseNoticeCode: any;
export type RouteNoticeImpact = "High" | "Low" | (string & {});
export declare const RouteNoticeImpact: any;
export interface RouteResponseNotice {
    Code: RouteResponseNoticeCode;
    Impact?: RouteNoticeImpact;
}
export declare const RouteResponseNotice: S.Schema<RouteResponseNotice>;
export type RouteResponseNoticeList = RouteResponseNotice[];
export declare const RouteResponseNoticeList: any;
export type RouteFerryAfterTravelStepType = "Deboard" | (string & {});
export declare const RouteFerryAfterTravelStepType: any;
export interface RouteFerryAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteFerryAfterTravelStepType;
}
export declare const RouteFerryAfterTravelStep: S.Schema<RouteFerryAfterTravelStep>;
export type RouteFerryAfterTravelStepList = RouteFerryAfterTravelStep[];
export declare const RouteFerryAfterTravelStepList: any;
export type Position23 = number[];
export declare const Position23: any;
export interface RouteFerryPlace {
    Name?: string | redacted.Redacted<string>;
    OriginalPosition?: number[];
    Position: number[];
    WaypointIndex?: number;
}
export declare const RouteFerryPlace: S.Schema<RouteFerryPlace>;
export interface RouteFerryArrival {
    Place: RouteFerryPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteFerryArrival: S.Schema<RouteFerryArrival>;
export type RouteFerryBeforeTravelStepType = "Board" | (string & {});
export declare const RouteFerryBeforeTravelStepType: any;
export interface RouteFerryBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteFerryBeforeTravelStepType;
}
export declare const RouteFerryBeforeTravelStep: S.Schema<RouteFerryBeforeTravelStep>;
export type RouteFerryBeforeTravelStepList = RouteFerryBeforeTravelStep[];
export declare const RouteFerryBeforeTravelStepList: any;
export interface RouteFerryDeparture {
    Place: RouteFerryPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteFerryDeparture: S.Schema<RouteFerryDeparture>;
export type RouteFerryNoticeCode = "AccuratePolylineUnavailable" | "NoSchedule" | "Other" | "ViolatedAvoidFerry" | "ViolatedAvoidRailFerry" | "SeasonalClosure" | "PotentialViolatedVehicleRestrictionUsage" | "ViolatedAvoidAreas" | "ViolatedVehicleRestriction" | (string & {});
export declare const RouteFerryNoticeCode: any;
export interface RouteFerryNotice {
    Code: RouteFerryNoticeCode;
    Impact?: RouteNoticeImpact;
}
export declare const RouteFerryNotice: S.Schema<RouteFerryNotice>;
export type RouteFerryNoticeList = RouteFerryNotice[];
export declare const RouteFerryNoticeList: any;
export interface RoutePassThroughPlace {
    OriginalPosition?: number[];
    Position: number[];
    WaypointIndex?: number;
}
export declare const RoutePassThroughPlace: S.Schema<RoutePassThroughPlace>;
export interface RoutePassThroughWaypoint {
    GeometryOffset?: number;
    Place: RoutePassThroughPlace;
}
export declare const RoutePassThroughWaypoint: S.Schema<RoutePassThroughWaypoint>;
export type RoutePassThroughWaypointList = RoutePassThroughWaypoint[];
export declare const RoutePassThroughWaypointList: any;
export type CountryCode3 = string | redacted.Redacted<string>;
export interface LocalizedString {
    Language?: string;
    Value: string | redacted.Redacted<string>;
}
export declare const LocalizedString: S.Schema<LocalizedString>;
export type LocalizedStringList = LocalizedString[];
export declare const LocalizedStringList: any;
export interface RouteFerrySpan {
    Country?: string | redacted.Redacted<string>;
    Distance?: number;
    Duration?: number;
    GeometryOffset?: number;
    Names?: LocalizedString[];
    Region?: string | redacted.Redacted<string>;
}
export declare const RouteFerrySpan: S.Schema<RouteFerrySpan>;
export type RouteFerrySpanList = RouteFerrySpan[];
export declare const RouteFerrySpanList: any;
export interface RouteFerryOverviewSummary {
    Distance: number;
    Duration: number;
}
export declare const RouteFerryOverviewSummary: S.Schema<RouteFerryOverviewSummary>;
export interface RouteFerryTravelOnlySummary {
    Duration: number;
}
export declare const RouteFerryTravelOnlySummary: S.Schema<RouteFerryTravelOnlySummary>;
export interface RouteFerrySummary {
    Overview?: RouteFerryOverviewSummary;
    TravelOnly?: RouteFerryTravelOnlySummary;
}
export declare const RouteFerrySummary: S.Schema<RouteFerrySummary>;
export type RouteFerryTravelStepType = "Depart" | "Continue" | "Arrive" | (string & {});
export declare const RouteFerryTravelStepType: any;
export interface RouteFerryTravelStep {
    Distance?: number;
    Duration: number;
    GeometryOffset?: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteFerryTravelStepType;
}
export declare const RouteFerryTravelStep: S.Schema<RouteFerryTravelStep>;
export type RouteFerryTravelStepList = RouteFerryTravelStep[];
export declare const RouteFerryTravelStepList: any;
export interface RouteFerryLegDetails {
    AfterTravelSteps?: RouteFerryAfterTravelStep[];
    Arrival: RouteFerryArrival;
    BeforeTravelSteps?: RouteFerryBeforeTravelStep[];
    Departure: RouteFerryDeparture;
    Notices?: RouteFerryNotice[];
    PassThroughWaypoints?: RoutePassThroughWaypoint[];
    RouteName?: string | redacted.Redacted<string>;
    Spans?: RouteFerrySpan[];
    Summary?: RouteFerrySummary;
    TravelSteps?: RouteFerryTravelStep[];
}
export declare const RouteFerryLegDetails: S.Schema<RouteFerryLegDetails>;
export interface RouteLegGeometry {
    LineString?: number[][];
    Polyline?: string | redacted.Redacted<string>;
}
export declare const RouteLegGeometry: S.Schema<RouteLegGeometry>;
export type RoutePedestrianAfterTravelStepType = "Wait" | (string & {});
export declare const RoutePedestrianAfterTravelStepType: any;
export interface RoutePedestrianAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RoutePedestrianAfterTravelStepType;
}
export declare const RoutePedestrianAfterTravelStep: S.Schema<RoutePedestrianAfterTravelStep>;
export type RoutePedestrianAfterTravelStepList = RoutePedestrianAfterTravelStep[];
export declare const RoutePedestrianAfterTravelStepList: any;
export type RouteAccessibilityAvailability = "Available" | "Limited" | "Unavailable" | "Unknown" | (string & {});
export declare const RouteAccessibilityAvailability: any;
export interface RouteAccessibilityAvailabilityDetails {
    Wheelchair?: RouteAccessibilityAvailability;
}
export declare const RouteAccessibilityAvailabilityDetails: S.Schema<RouteAccessibilityAvailabilityDetails>;
export interface RouteAccessPointDetails {
    Accessibility?: RouteAccessibilityAvailabilityDetails;
}
export declare const RouteAccessPointDetails: S.Schema<RouteAccessPointDetails>;
export type RouteSideOfStreet = "Left" | "Right" | (string & {});
export declare const RouteSideOfStreet: any;
export interface RouteStationDetails {
    Accessibility?: RouteAccessibilityAvailabilityDetails;
    PlatformName?: string | redacted.Redacted<string>;
    ShortName?: string | redacted.Redacted<string>;
}
export declare const RouteStationDetails: S.Schema<RouteStationDetails>;
export type RoutePedestrianPlaceType = "AccessPoint" | "DockingStation" | "ParkingLot" | "Station" | (string & {});
export declare const RoutePedestrianPlaceType: any;
export interface RoutePedestrianPlace {
    AccessPointDetails?: RouteAccessPointDetails;
    Name?: string | redacted.Redacted<string>;
    OriginalPosition?: number[];
    Position: number[];
    SideOfStreet?: RouteSideOfStreet;
    StationDetails?: RouteStationDetails;
    Type?: RoutePedestrianPlaceType;
    WaypointIndex?: number;
}
export declare const RoutePedestrianPlace: S.Schema<RoutePedestrianPlace>;
export interface RoutePedestrianArrival {
    Place: RoutePedestrianPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RoutePedestrianArrival: S.Schema<RoutePedestrianArrival>;
export interface RoutePedestrianDeparture {
    Place: RoutePedestrianPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RoutePedestrianDeparture: S.Schema<RoutePedestrianDeparture>;
export type RoutePedestrianNoticeCode = "AccuratePolylineUnavailable" | "Other" | "ViolatedAvoidDirtRoad" | "ViolatedAvoidTunnel" | "ViolatedPedestrianOption" | "ViolatedAvoidAreas" | (string & {});
export declare const RoutePedestrianNoticeCode: any;
export interface RoutePedestrianNotice {
    Code: RoutePedestrianNoticeCode;
    Impact?: RouteNoticeImpact;
}
export declare const RoutePedestrianNotice: S.Schema<RoutePedestrianNotice>;
export type RoutePedestrianNoticeList = RoutePedestrianNotice[];
export declare const RoutePedestrianNoticeList: any;
export interface RouteSpanDynamicSpeedDetails {
    BestCaseSpeed?: number;
    TurnDuration?: number;
    TypicalSpeed?: number;
}
export declare const RouteSpanDynamicSpeedDetails: S.Schema<RouteSpanDynamicSpeedDetails>;
export type IndexList = number[];
export declare const IndexList: any;
export type RouteSpanPedestrianAccessAttribute = "Allowed" | "Indoors" | "NoThroughTraffic" | "Park" | "Stairs" | "TollRoad" | (string & {});
export declare const RouteSpanPedestrianAccessAttribute: any;
export type RouteSpanPedestrianAccessAttributeList = RouteSpanPedestrianAccessAttribute[];
export declare const RouteSpanPedestrianAccessAttributeList: any;
export type RouteSpanRoadAttribute = "Bridge" | "BuiltUpArea" | "ControlledAccessHighway" | "DirtRoad" | "DividedRoad" | "Motorway" | "PrivateRoad" | "Ramp" | "RightHandTraffic" | "Roundabout" | "Tunnel" | "UnderConstruction" | (string & {});
export declare const RouteSpanRoadAttribute: any;
export type RouteSpanRoadAttributeList = RouteSpanRoadAttribute[];
export declare const RouteSpanRoadAttributeList: any;
export type RouteDirection = "East" | "North" | "South" | "West" | (string & {});
export declare const RouteDirection: any;
export interface RouteNumber {
    Direction?: RouteDirection;
    Language?: string;
    Value: string | redacted.Redacted<string>;
}
export declare const RouteNumber: S.Schema<RouteNumber>;
export type RouteNumberList = RouteNumber[];
export declare const RouteNumberList: any;
export interface RouteSpanSpeedLimitDetails {
    MaxSpeed?: number;
    Unlimited?: boolean;
}
export declare const RouteSpanSpeedLimitDetails: S.Schema<RouteSpanSpeedLimitDetails>;
export interface RoutePedestrianSpan {
    BestCaseDuration?: number;
    Country?: string | redacted.Redacted<string>;
    Distance?: number;
    Duration?: number;
    DynamicSpeed?: RouteSpanDynamicSpeedDetails;
    FunctionalClassification?: number;
    GeometryOffset?: number;
    Incidents?: number[];
    Names?: LocalizedString[];
    PedestrianAccess?: RouteSpanPedestrianAccessAttribute[];
    Region?: string | redacted.Redacted<string>;
    RoadAttributes?: RouteSpanRoadAttribute[];
    RouteNumbers?: RouteNumber[];
    SpeedLimit?: RouteSpanSpeedLimitDetails;
    TypicalDuration?: number;
}
export declare const RoutePedestrianSpan: S.Schema<RoutePedestrianSpan>;
export type RoutePedestrianSpanList = RoutePedestrianSpan[];
export declare const RoutePedestrianSpanList: any;
export interface RoutePedestrianOverviewSummary {
    Distance: number;
    Duration: number;
}
export declare const RoutePedestrianOverviewSummary: S.Schema<RoutePedestrianOverviewSummary>;
export interface RoutePedestrianTravelOnlySummary {
    Duration: number;
}
export declare const RoutePedestrianTravelOnlySummary: S.Schema<RoutePedestrianTravelOnlySummary>;
export interface RoutePedestrianSummary {
    Overview?: RoutePedestrianOverviewSummary;
    TravelOnly?: RoutePedestrianTravelOnlySummary;
}
export declare const RoutePedestrianSummary: S.Schema<RoutePedestrianSummary>;
export interface RouteContinueStepDetails {
    Intersection: LocalizedString[];
}
export declare const RouteContinueStepDetails: S.Schema<RouteContinueStepDetails>;
export type RouteRoadType = "Highway" | "Rural" | "Urban" | (string & {});
export declare const RouteRoadType: any;
export interface RouteRoad {
    RoadName: LocalizedString[];
    RouteNumber: RouteNumber[];
    Towards: LocalizedString[];
    Type?: RouteRoadType;
}
export declare const RouteRoad: S.Schema<RouteRoad>;
export type RouteSteeringDirection = "Left" | "Right" | "Straight" | (string & {});
export declare const RouteSteeringDirection: any;
export type TurnAngle = number;
export type RouteTurnIntensity = "Sharp" | "Slight" | "Typical" | (string & {});
export declare const RouteTurnIntensity: any;
export interface RouteKeepStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteKeepStepDetails: S.Schema<RouteKeepStepDetails>;
export interface RouteRoundaboutEnterStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteRoundaboutEnterStepDetails: S.Schema<RouteRoundaboutEnterStepDetails>;
export type RoundaboutAngle = number;
export interface RouteRoundaboutExitStepDetails {
    Intersection: LocalizedString[];
    RelativeExit?: number;
    RoundaboutAngle?: number;
    SteeringDirection?: RouteSteeringDirection;
}
export declare const RouteRoundaboutExitStepDetails: S.Schema<RouteRoundaboutExitStepDetails>;
export interface RouteRoundaboutPassStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteRoundaboutPassStepDetails: S.Schema<RouteRoundaboutPassStepDetails>;
export interface RouteSignpostLabel {
    RouteNumber?: RouteNumber;
    Text?: LocalizedString;
}
export declare const RouteSignpostLabel: S.Schema<RouteSignpostLabel>;
export type RouteSignpostLabelList = RouteSignpostLabel[];
export declare const RouteSignpostLabelList: any;
export interface RouteSignpost {
    Labels: RouteSignpostLabel[];
}
export declare const RouteSignpost: S.Schema<RouteSignpost>;
export interface RouteTurnStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteTurnStepDetails: S.Schema<RouteTurnStepDetails>;
export type RoutePedestrianTravelStepType = "Arrive" | "Continue" | "Depart" | "Keep" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | (string & {});
export declare const RoutePedestrianTravelStepType: any;
export interface RoutePedestrianTravelStep {
    ContinueStepDetails?: RouteContinueStepDetails;
    CurrentRoad?: RouteRoad;
    Distance?: number;
    Duration: number;
    ExitNumber?: LocalizedString[];
    GeometryOffset?: number;
    Instruction?: string | redacted.Redacted<string>;
    KeepStepDetails?: RouteKeepStepDetails;
    NextRoad?: RouteRoad;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails;
    Signpost?: RouteSignpost;
    TurnStepDetails?: RouteTurnStepDetails;
    Type: RoutePedestrianTravelStepType;
}
export declare const RoutePedestrianTravelStep: S.Schema<RoutePedestrianTravelStep>;
export type RoutePedestrianTravelStepList = RoutePedestrianTravelStep[];
export declare const RoutePedestrianTravelStepList: any;
export interface RoutePedestrianLegDetails {
    AfterTravelSteps?: RoutePedestrianAfterTravelStep[];
    Arrival: RoutePedestrianArrival;
    Departure: RoutePedestrianDeparture;
    Notices?: RoutePedestrianNotice[];
    PassThroughWaypoints?: RoutePassThroughWaypoint[];
    Spans?: RoutePedestrianSpan[];
    Summary?: RoutePedestrianSummary;
    TravelSteps?: RoutePedestrianTravelStep[];
}
export declare const RoutePedestrianLegDetails: S.Schema<RoutePedestrianLegDetails>;
export type RouteLegTravelMode = "Car" | "Ferry" | "Pedestrian" | "Scooter" | "Truck" | "CarShuttleTrain" | "AerialTramway" | "Airplane" | "Bus" | "BusRapidTransit" | "CityTrain" | "FunicularRailway" | "HighSpeedTrain" | "IntercityTrain" | "InterregionalTrain" | "LightRail" | "Monorail" | "PrivateBus" | "RegionalTrain" | "Subway" | (string & {});
export declare const RouteLegTravelMode: any;
export type RouteLegType = "Ferry" | "Pedestrian" | "Vehicle" | "Rental" | "Taxi" | "Transit" | (string & {});
export declare const RouteLegType: any;
export type EnergyKilowattHours = number;
export type PowerKilowatts = number;
export interface RouteChargeStepDetails {
    ArrivalCharge?: number;
    ConsumablePower?: number;
    DesiredCharge?: number;
}
export declare const RouteChargeStepDetails: S.Schema<RouteChargeStepDetails>;
export type RouteVehicleAfterTravelStepType = "Park" | (string & {});
export declare const RouteVehicleAfterTravelStepType: any;
export interface RouteVehicleAfterTravelStep {
    ChargeStepDetails?: RouteChargeStepDetails;
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteVehicleAfterTravelStepType;
}
export declare const RouteVehicleAfterTravelStep: S.Schema<RouteVehicleAfterTravelStep>;
export type RouteVehicleAfterTravelStepList = RouteVehicleAfterTravelStep[];
export declare const RouteVehicleAfterTravelStepList: any;
export type RouteVehiclePlaceType = "AccessPoint" | "DockingStation" | "ParkingLot" | "Station" | (string & {});
export declare const RouteVehiclePlaceType: any;
export interface RouteVehiclePlace {
    Name?: string | redacted.Redacted<string>;
    OriginalPosition?: number[];
    Position: number[];
    SideOfStreet?: RouteSideOfStreet;
    WaypointIndex?: number;
    AccessPointDetails?: RouteAccessPointDetails;
    StationDetails?: RouteStationDetails;
    Type?: RouteVehiclePlaceType;
}
export declare const RouteVehiclePlace: S.Schema<RouteVehiclePlace>;
export interface RouteVehicleArrival {
    Place: RouteVehiclePlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteVehicleArrival: S.Schema<RouteVehicleArrival>;
export interface RouteVehicleDeparture {
    Place: RouteVehiclePlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteVehicleDeparture: S.Schema<RouteVehicleDeparture>;
export type RouteVehicleIncidentSeverity = "Critical" | "High" | "Medium" | "Low" | (string & {});
export declare const RouteVehicleIncidentSeverity: any;
export type RouteVehicleIncidentType = "Accident" | "Congestion" | "Construction" | "DisabledVehicle" | "LaneRestriction" | "MassTransit" | "Other" | "PlannedEvent" | "RoadClosure" | "RoadHazard" | "Weather" | (string & {});
export declare const RouteVehicleIncidentType: any;
export interface RouteVehicleIncident {
    Description?: string | redacted.Redacted<string>;
    EndTime?: string | redacted.Redacted<string>;
    Severity?: RouteVehicleIncidentSeverity;
    StartTime?: string | redacted.Redacted<string>;
    Type?: RouteVehicleIncidentType;
}
export declare const RouteVehicleIncident: S.Schema<RouteVehicleIncident>;
export type RouteVehicleIncidentList = RouteVehicleIncident[];
export declare const RouteVehicleIncidentList: any;
export type RouteVehicleNoticeCode = "AccuratePolylineUnavailable" | "Other" | "PotentialViolatedAvoidTollRoadUsage" | "PotentialViolatedCarpoolUsage" | "PotentialViolatedTurnRestrictionUsage" | "PotentialViolatedVehicleRestrictionUsage" | "PotentialViolatedZoneRestrictionUsage" | "SeasonalClosure" | "TollsDataTemporarilyUnavailable" | "TollsDataUnavailable" | "TollTransponder" | "ViolatedAvoidControlledAccessHighway" | "ViolatedAvoidDifficultTurns" | "ViolatedAvoidDirtRoad" | "ViolatedAvoidSeasonalClosure" | "ViolatedAvoidTollRoad" | "ViolatedAvoidTollTransponder" | "ViolatedAvoidTruckRoadType" | "ViolatedAvoidTunnel" | "ViolatedAvoidUTurns" | "ViolatedBlockedRoad" | "ViolatedCarpool" | "ViolatedEmergencyGate" | "ViolatedStartDirection" | "ViolatedTurnRestriction" | "ViolatedVehicleRestriction" | "ViolatedZoneRestriction" | "TravelTimeExceedsDriverWorkHours" | (string & {});
export declare const RouteVehicleNoticeCode: any;
export interface RouteNoticeDetailRange {
    Min?: number;
    Max?: number;
}
export declare const RouteNoticeDetailRange: S.Schema<RouteNoticeDetailRange>;
export type RouteWeightConstraintType = "Current" | "Gross" | "Unknown" | (string & {});
export declare const RouteWeightConstraintType: any;
export interface RouteWeightConstraint {
    Type: RouteWeightConstraintType;
    Value: number;
}
export declare const RouteWeightConstraint: S.Schema<RouteWeightConstraint>;
export interface RouteViolatedConstraints {
    AllHazardsRestricted?: boolean;
    AxleCount?: RouteNoticeDetailRange;
    HazardousCargos: RouteHazardousCargoType[];
    MaxHeight?: number;
    MaxKpraLength?: number;
    MaxLength?: number;
    MaxPayloadCapacity?: number;
    MaxWeight?: RouteWeightConstraint;
    MaxWeightPerAxle?: number;
    MaxWeightPerAxleGroup?: WeightPerAxleGroup;
    MaxWidth?: number;
    Occupancy?: RouteNoticeDetailRange;
    RestrictedTimes?: string;
    TimeDependent?: boolean;
    TrailerCount?: RouteNoticeDetailRange;
    TravelMode?: boolean;
    TruckRoadType?: string;
    TruckType?: RouteTruckType;
    TunnelRestrictionCode?: string | redacted.Redacted<string>;
}
export declare const RouteViolatedConstraints: S.Schema<RouteViolatedConstraints>;
export interface RouteVehicleNoticeDetail {
    Title?: string | redacted.Redacted<string>;
    ViolatedConstraints?: RouteViolatedConstraints;
}
export declare const RouteVehicleNoticeDetail: S.Schema<RouteVehicleNoticeDetail>;
export type RouteVehicleNoticeDetailList = RouteVehicleNoticeDetail[];
export declare const RouteVehicleNoticeDetailList: any;
export interface RouteVehicleNotice {
    Code: RouteVehicleNoticeCode;
    Details: RouteVehicleNoticeDetail[];
    Impact?: RouteNoticeImpact;
}
export declare const RouteVehicleNotice: S.Schema<RouteVehicleNotice>;
export type RouteVehicleNoticeList = RouteVehicleNotice[];
export declare const RouteVehicleNoticeList: any;
export type RouteSpanCarAccessAttribute = "Allowed" | "NoThroughTraffic" | "TollRoad" | (string & {});
export declare const RouteSpanCarAccessAttribute: any;
export type RouteSpanCarAccessAttributeList = RouteSpanCarAccessAttribute[];
export declare const RouteSpanCarAccessAttributeList: any;
export type RouteSpanGateAttribute = "Emergency" | "KeyAccess" | "PermissionRequired" | (string & {});
export declare const RouteSpanGateAttribute: any;
export type RouteSpanRailwayCrossingAttribute = "Protected" | "Unprotected" | (string & {});
export declare const RouteSpanRailwayCrossingAttribute: any;
export type RouteSpanScooterAccessAttribute = "Allowed" | "NoThroughTraffic" | "TollRoad" | (string & {});
export declare const RouteSpanScooterAccessAttribute: any;
export type RouteSpanScooterAccessAttributeList = RouteSpanScooterAccessAttribute[];
export declare const RouteSpanScooterAccessAttributeList: any;
export type RouteSpanTruckAccessAttribute = "Allowed" | "NoThroughTraffic" | "TollRoad" | (string & {});
export declare const RouteSpanTruckAccessAttribute: any;
export type RouteSpanTruckAccessAttributeList = RouteSpanTruckAccessAttribute[];
export declare const RouteSpanTruckAccessAttributeList: any;
export interface RouteVehicleSpan {
    BestCaseDuration?: number;
    CarAccess?: RouteSpanCarAccessAttribute[];
    Country?: string | redacted.Redacted<string>;
    Distance?: number;
    Duration?: number;
    DynamicSpeed?: RouteSpanDynamicSpeedDetails;
    FunctionalClassification?: number;
    Gate?: RouteSpanGateAttribute;
    GeometryOffset?: number;
    Incidents?: number[];
    Names?: LocalizedString[];
    Notices?: number[];
    RailwayCrossing?: RouteSpanRailwayCrossingAttribute;
    Region?: string | redacted.Redacted<string>;
    RoadAttributes?: RouteSpanRoadAttribute[];
    RouteNumbers?: RouteNumber[];
    ScooterAccess?: RouteSpanScooterAccessAttribute[];
    SpeedLimit?: RouteSpanSpeedLimitDetails;
    TollSystems?: number[];
    TruckAccess?: RouteSpanTruckAccessAttribute[];
    TruckRoadTypes?: number[];
    TypicalDuration?: number;
    Zones?: number[];
}
export declare const RouteVehicleSpan: S.Schema<RouteVehicleSpan>;
export type RouteVehicleSpanList = RouteVehicleSpan[];
export declare const RouteVehicleSpanList: any;
export interface RouteVehicleOverviewSummary {
    BestCaseDuration?: number;
    Distance: number;
    Duration: number;
    TypicalDuration?: number;
}
export declare const RouteVehicleOverviewSummary: S.Schema<RouteVehicleOverviewSummary>;
export interface RouteVehicleTravelOnlySummary {
    BestCaseDuration?: number;
    Duration: number;
    TypicalDuration?: number;
}
export declare const RouteVehicleTravelOnlySummary: S.Schema<RouteVehicleTravelOnlySummary>;
export interface RouteVehicleSummary {
    Overview?: RouteVehicleOverviewSummary;
    TravelOnly?: RouteVehicleTravelOnlySummary;
}
export declare const RouteVehicleSummary: S.Schema<RouteVehicleSummary>;
export interface RouteTollPaymentSite {
    Name?: string;
    Position: number[];
}
export declare const RouteTollPaymentSite: S.Schema<RouteTollPaymentSite>;
export type RouteTollPaymentSiteList = RouteTollPaymentSite[];
export declare const RouteTollPaymentSiteList: any;
export interface RouteTollPriceValueRange {
    Min: number;
    Max: number;
}
export declare const RouteTollPriceValueRange: S.Schema<RouteTollPriceValueRange>;
export interface RouteTollPrice {
    Currency: string;
    Estimate: boolean;
    PerDuration?: number;
    Range: boolean;
    RangeValue?: RouteTollPriceValueRange;
    Value: number;
}
export declare const RouteTollPrice: S.Schema<RouteTollPrice>;
export type RouteTollPassValidityPeriodType = "Annual" | "Days" | "ExtendedAnnual" | "Minutes" | "Months" | (string & {});
export declare const RouteTollPassValidityPeriodType: any;
export interface RouteTollPassValidityPeriod {
    Period: RouteTollPassValidityPeriodType;
    PeriodCount?: number;
}
export declare const RouteTollPassValidityPeriod: S.Schema<RouteTollPassValidityPeriod>;
export interface RouteTollPass {
    IncludesReturnTrip?: boolean;
    SeniorPass?: boolean;
    TransferCount?: number;
    TripCount?: number;
    ValidityPeriod?: RouteTollPassValidityPeriod;
}
export declare const RouteTollPass: S.Schema<RouteTollPass>;
export type RouteTollPaymentMethod = "BankCard" | "Cash" | "CashExact" | "CreditCard" | "PassSubscription" | "TravelCard" | "Transponder" | "VideoToll" | (string & {});
export declare const RouteTollPaymentMethod: any;
export type RouteTollPaymentMethodList = RouteTollPaymentMethod[];
export declare const RouteTollPaymentMethodList: any;
export interface RouteTransponder {
    SystemName?: string | redacted.Redacted<string>;
}
export declare const RouteTransponder: S.Schema<RouteTransponder>;
export type RouteTransponderList = RouteTransponder[];
export declare const RouteTransponderList: any;
export interface RouteTollRate {
    ApplicableTimes?: string | redacted.Redacted<string>;
    ConvertedPrice?: RouteTollPrice;
    Id: string | redacted.Redacted<string>;
    LocalPrice: RouteTollPrice;
    Name: string | redacted.Redacted<string>;
    Pass?: RouteTollPass;
    PaymentMethods: RouteTollPaymentMethod[];
    Transponders: RouteTransponder[];
}
export declare const RouteTollRate: S.Schema<RouteTollRate>;
export type RouteTollRateList = RouteTollRate[];
export declare const RouteTollRateList: any;
export interface RouteToll {
    Country?: string | redacted.Redacted<string>;
    PaymentSites: RouteTollPaymentSite[];
    Rates: RouteTollRate[];
    Systems: number[];
}
export declare const RouteToll: S.Schema<RouteToll>;
export type RouteTollList = RouteToll[];
export declare const RouteTollList: any;
export interface RouteTollSystem {
    Name?: string | redacted.Redacted<string>;
}
export declare const RouteTollSystem: S.Schema<RouteTollSystem>;
export type RouteTollSystemList = RouteTollSystem[];
export declare const RouteTollSystemList: any;
export interface RouteContinueHighwayStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteContinueHighwayStepDetails: S.Schema<RouteContinueHighwayStepDetails>;
export interface RouteEnterHighwayStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteEnterHighwayStepDetails: S.Schema<RouteEnterHighwayStepDetails>;
export interface RouteExitStepDetails {
    Intersection: LocalizedString[];
    RelativeExit?: number;
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteExitStepDetails: S.Schema<RouteExitStepDetails>;
export interface RouteRampStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteRampStepDetails: S.Schema<RouteRampStepDetails>;
export type RouteVehicleTravelStepType = "Arrive" | "Continue" | "ContinueHighway" | "Depart" | "EnterHighway" | "Exit" | "Keep" | "Ramp" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | "UTurn" | (string & {});
export declare const RouteVehicleTravelStepType: any;
export interface RouteUTurnStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection;
    TurnAngle?: number;
    TurnIntensity?: RouteTurnIntensity;
}
export declare const RouteUTurnStepDetails: S.Schema<RouteUTurnStepDetails>;
export interface RouteVehicleTravelStep {
    ContinueHighwayStepDetails?: RouteContinueHighwayStepDetails;
    ContinueStepDetails?: RouteContinueStepDetails;
    CurrentRoad?: RouteRoad;
    Distance?: number;
    Duration: number;
    EnterHighwayStepDetails?: RouteEnterHighwayStepDetails;
    ExitNumber?: LocalizedString[];
    ExitStepDetails?: RouteExitStepDetails;
    GeometryOffset?: number;
    Instruction?: string | redacted.Redacted<string>;
    KeepStepDetails?: RouteKeepStepDetails;
    NextRoad?: RouteRoad;
    RampStepDetails?: RouteRampStepDetails;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails;
    Signpost?: RouteSignpost;
    TurnStepDetails?: RouteTurnStepDetails;
    Type: RouteVehicleTravelStepType;
    UTurnStepDetails?: RouteUTurnStepDetails;
}
export declare const RouteVehicleTravelStep: S.Schema<RouteVehicleTravelStep>;
export type RouteVehicleTravelStepList = RouteVehicleTravelStep[];
export declare const RouteVehicleTravelStepList: any;
export interface RouteZone {
    Category?: RouteZoneCategory;
    Name?: string | redacted.Redacted<string>;
}
export declare const RouteZone: S.Schema<RouteZone>;
export type RouteZoneList = RouteZone[];
export declare const RouteZoneList: any;
export interface RouteVehicleLegDetails {
    AfterTravelSteps?: RouteVehicleAfterTravelStep[];
    Arrival: RouteVehicleArrival;
    Departure: RouteVehicleDeparture;
    Incidents?: RouteVehicleIncident[];
    Notices?: RouteVehicleNotice[];
    PassThroughWaypoints?: RoutePassThroughWaypoint[];
    Spans?: RouteVehicleSpan[];
    Summary?: RouteVehicleSummary;
    Tolls?: RouteToll[];
    TollSystems?: RouteTollSystem[];
    TravelSteps?: RouteVehicleTravelStep[];
    TruckRoadTypes?: (string | redacted.Redacted<string>)[];
    Zones?: RouteZone[];
}
export declare const RouteVehicleLegDetails: S.Schema<RouteVehicleLegDetails>;
export type RouteRentalAfterTravelStepType = "Park" | (string & {});
export declare const RouteRentalAfterTravelStepType: any;
export interface RouteRentalAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteRentalAfterTravelStepType;
}
export declare const RouteRentalAfterTravelStep: S.Schema<RouteRentalAfterTravelStep>;
export type RouteRentalAfterTravelStepList = RouteRentalAfterTravelStep[];
export declare const RouteRentalAfterTravelStepList: any;
export interface RouteRentalAgency {
    Name: string | redacted.Redacted<string>;
    Url?: string | redacted.Redacted<string>;
}
export declare const RouteRentalAgency: S.Schema<RouteRentalAgency>;
export type RouteRentalPlaceType = "AccessPoint" | "DockingStation" | "ParkingLot" | "Station" | (string & {});
export declare const RouteRentalPlaceType: any;
export interface RouteRentalPlace {
    AccessPointDetails?: RouteAccessPointDetails;
    Name?: string | redacted.Redacted<string>;
    OriginalPosition?: number[];
    Position: number[];
    StationDetails?: RouteStationDetails;
    Type?: RouteRentalPlaceType;
    WaypointIndex?: number;
}
export declare const RouteRentalPlace: S.Schema<RouteRentalPlace>;
export interface RouteRentalArrival {
    Place: RouteRentalPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteRentalArrival: S.Schema<RouteRentalArrival>;
export type RouteAttributionType = "Disclaimer" | "Tariff" | (string & {});
export declare const RouteAttributionType: any;
export type RouteWebLinkDeviceType = "Android" | "Ios" | "Web" | (string & {});
export declare const RouteWebLinkDeviceType: any;
export interface RouteWebLink {
    AnchorText?: string | redacted.Redacted<string>;
    Description: string | redacted.Redacted<string>;
    DeviceType?: RouteWebLinkDeviceType;
    Url?: string | redacted.Redacted<string>;
}
export declare const RouteWebLink: S.Schema<RouteWebLink>;
export interface RouteAttribution {
    AttributionType?: RouteAttributionType;
    WebLink: RouteWebLink;
}
export declare const RouteAttribution: S.Schema<RouteAttribution>;
export type RouteAttributionList = RouteAttribution[];
export declare const RouteAttributionList: any;
export type RouteRentalBeforeTravelStepType = "Setup" | (string & {});
export declare const RouteRentalBeforeTravelStepType: any;
export interface RouteRentalBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteRentalBeforeTravelStepType;
}
export declare const RouteRentalBeforeTravelStep: S.Schema<RouteRentalBeforeTravelStep>;
export type RouteRentalBeforeTravelStepList = RouteRentalBeforeTravelStep[];
export declare const RouteRentalBeforeTravelStepList: any;
export type RouteWebLinkList = RouteWebLink[];
export declare const RouteWebLinkList: any;
export interface RouteRentalDeparture {
    Place: RouteRentalPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteRentalDeparture: S.Schema<RouteRentalDeparture>;
export interface RouteRentalOverviewSummary {
    Duration: number;
    Distance: number;
}
export declare const RouteRentalOverviewSummary: S.Schema<RouteRentalOverviewSummary>;
export interface RouteRentalTravelOnlySummary {
    Duration: number;
}
export declare const RouteRentalTravelOnlySummary: S.Schema<RouteRentalTravelOnlySummary>;
export interface RouteRentalSummary {
    Overview?: RouteRentalOverviewSummary;
    TravelOnly?: RouteRentalTravelOnlySummary;
}
export declare const RouteRentalSummary: S.Schema<RouteRentalSummary>;
export interface RouteRentalTransportModeDetails {
    AvailableSeats?: number;
    Category?: string | redacted.Redacted<string>;
    Color?: string | redacted.Redacted<string>;
    Engine?: RouteEngineType;
    LicensePlate?: string | redacted.Redacted<string>;
    Mode: RouteRentalMode;
    Model?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
    TextColor?: string | redacted.Redacted<string>;
}
export declare const RouteRentalTransportModeDetails: S.Schema<RouteRentalTransportModeDetails>;
export type RouteRentalTravelStepType = "Arrive" | "Continue" | "Depart" | "Exit" | "Keep" | "Ramp" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | "UTurn" | (string & {});
export declare const RouteRentalTravelStepType: any;
export interface RouteRentalTravelStep {
    ContinueStepDetails?: RouteContinueStepDetails;
    Distance?: number;
    Duration: number;
    ExitStepDetails?: RouteExitStepDetails;
    GeometryOffset?: number;
    Instruction?: string | redacted.Redacted<string>;
    KeepStepDetails?: RouteKeepStepDetails;
    RampStepDetails?: RouteRampStepDetails;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails;
    TurnStepDetails?: RouteTurnStepDetails;
    Type: RouteRentalTravelStepType;
    UTurnStepDetails?: RouteUTurnStepDetails;
}
export declare const RouteRentalTravelStep: S.Schema<RouteRentalTravelStep>;
export type RouteRentalTravelStepList = RouteRentalTravelStep[];
export declare const RouteRentalTravelStepList: any;
export interface RouteRentalLegDetails {
    AfterTravelSteps?: RouteRentalAfterTravelStep[];
    Agency: RouteRentalAgency;
    Arrival: RouteRentalArrival;
    Attributions?: RouteAttribution[];
    BeforeTravelSteps?: RouteRentalBeforeTravelStep[];
    BookingWebLinks?: RouteWebLink[];
    Departure: RouteRentalDeparture;
    Summary?: RouteRentalSummary;
    Transport: RouteRentalTransportModeDetails;
    TravelSteps?: RouteRentalTravelStep[];
}
export declare const RouteRentalLegDetails: S.Schema<RouteRentalLegDetails>;
export type RouteTaxiAfterTravelStepType = "Park" | (string & {});
export declare const RouteTaxiAfterTravelStepType: any;
export interface RouteTaxiAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteTaxiAfterTravelStepType;
}
export declare const RouteTaxiAfterTravelStep: S.Schema<RouteTaxiAfterTravelStep>;
export type RouteTaxiAfterTravelStepList = RouteTaxiAfterTravelStep[];
export declare const RouteTaxiAfterTravelStepList: any;
export interface RouteTaxiAgency {
    Name: string | redacted.Redacted<string>;
    Url?: string | redacted.Redacted<string>;
}
export declare const RouteTaxiAgency: S.Schema<RouteTaxiAgency>;
export type RouteTaxiPlaceType = "AccessPoint" | "Station" | (string & {});
export declare const RouteTaxiPlaceType: any;
export interface RouteTaxiPlace {
    AccessPointDetails?: RouteAccessPointDetails;
    Name?: string | redacted.Redacted<string>;
    OriginalPosition?: number[];
    Position: number[];
    StationDetails?: RouteStationDetails;
    Type?: RouteTaxiPlaceType;
    WaypointIndex?: number;
}
export declare const RouteTaxiPlace: S.Schema<RouteTaxiPlace>;
export interface RouteTaxiArrival {
    Place: RouteTaxiPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteTaxiArrival: S.Schema<RouteTaxiArrival>;
export type RouteTaxiBeforeTravelStepType = "Wait" | (string & {});
export declare const RouteTaxiBeforeTravelStepType: any;
export interface RouteTaxiBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteTaxiBeforeTravelStepType;
}
export declare const RouteTaxiBeforeTravelStep: S.Schema<RouteTaxiBeforeTravelStep>;
export type RouteTaxiBeforeTravelStepList = RouteTaxiBeforeTravelStep[];
export declare const RouteTaxiBeforeTravelStepList: any;
export interface RouteTaxiDeparture {
    Place: RouteTaxiPlace;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteTaxiDeparture: S.Schema<RouteTaxiDeparture>;
export type RouteTaxiNoticeCode = "AccuratePolylineUnavailable" | "Other" | (string & {});
export declare const RouteTaxiNoticeCode: any;
export interface RouteTaxiNotice {
    Code: RouteTaxiNoticeCode;
    Impact?: RouteNoticeImpact;
}
export declare const RouteTaxiNotice: S.Schema<RouteTaxiNotice>;
export type RouteTaxiNoticeList = RouteTaxiNotice[];
export declare const RouteTaxiNoticeList: any;
export interface RouteTaxiOverviewSummary {
    Duration: number;
    Distance: number;
}
export declare const RouteTaxiOverviewSummary: S.Schema<RouteTaxiOverviewSummary>;
export interface RouteTaxiTravelOnlySummary {
    Duration: number;
}
export declare const RouteTaxiTravelOnlySummary: S.Schema<RouteTaxiTravelOnlySummary>;
export interface RouteTaxiSummary {
    Overview?: RouteTaxiOverviewSummary;
    TravelOnly?: RouteTaxiTravelOnlySummary;
}
export declare const RouteTaxiSummary: S.Schema<RouteTaxiSummary>;
export interface RouteTaxiTransportModeDetails {
    AvailableSeats?: number;
    Category?: string | redacted.Redacted<string>;
    Color?: string | redacted.Redacted<string>;
    Engine?: RouteEngineType;
    LicensePlate?: string | redacted.Redacted<string>;
    Mode: RouteTaxiMode;
    Model?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
    TextColor?: string | redacted.Redacted<string>;
}
export declare const RouteTaxiTransportModeDetails: S.Schema<RouteTaxiTransportModeDetails>;
export type RouteTaxiTravelStepType = "Arrive" | "Continue" | "Depart" | "Exit" | "Keep" | "Ramp" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | "UTurn" | (string & {});
export declare const RouteTaxiTravelStepType: any;
export interface RouteTaxiTravelStep {
    ContinueStepDetails?: RouteContinueStepDetails;
    Distance?: number;
    Duration: number;
    ExitStepDetails?: RouteExitStepDetails;
    GeometryOffset?: number;
    Instruction?: string | redacted.Redacted<string>;
    KeepStepDetails?: RouteKeepStepDetails;
    RampStepDetails?: RouteRampStepDetails;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails;
    TurnStepDetails?: RouteTurnStepDetails;
    Type: RouteTaxiTravelStepType;
    UTurnStepDetails?: RouteUTurnStepDetails;
}
export declare const RouteTaxiTravelStep: S.Schema<RouteTaxiTravelStep>;
export type RouteTaxiTravelStepList = RouteTaxiTravelStep[];
export declare const RouteTaxiTravelStepList: any;
export interface RouteTaxiLegDetails {
    AfterTravelSteps?: RouteTaxiAfterTravelStep[];
    Agency: RouteTaxiAgency;
    Arrival: RouteTaxiArrival;
    Attributions?: RouteAttribution[];
    BeforeTravelSteps?: RouteTaxiBeforeTravelStep[];
    BookingWebLinks?: RouteWebLink[];
    Departure: RouteTaxiDeparture;
    Notices?: RouteTaxiNotice[];
    Summary?: RouteTaxiSummary;
    Transport: RouteTaxiTransportModeDetails;
    TravelSteps?: RouteTaxiTravelStep[];
}
export declare const RouteTaxiLegDetails: S.Schema<RouteTaxiLegDetails>;
export type RouteTransitAfterTravelStepType = "Deboard" | (string & {});
export declare const RouteTransitAfterTravelStepType: any;
export interface RouteTransitAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteTransitAfterTravelStepType;
}
export declare const RouteTransitAfterTravelStep: S.Schema<RouteTransitAfterTravelStep>;
export type RouteTransitAfterTravelStepList = RouteTransitAfterTravelStep[];
export declare const RouteTransitAfterTravelStepList: any;
export interface RouteTransitAgency {
    Name: string | redacted.Redacted<string>;
    Url?: string | redacted.Redacted<string>;
}
export declare const RouteTransitAgency: S.Schema<RouteTransitAgency>;
export type RouteTransitPlaceType = "Station" | (string & {});
export declare const RouteTransitPlaceType: any;
export interface RouteTransitPlace {
    Name?: string | redacted.Redacted<string>;
    OriginalPosition?: number[];
    Position: number[];
    StationDetails?: RouteStationDetails;
    Type?: RouteTransitPlaceType;
    WaypointIndex?: number;
}
export declare const RouteTransitPlace: S.Schema<RouteTransitPlace>;
export type RouteTransitTripStatus = "Added" | "Cancelled" | "Replaced" | "Scheduled" | (string & {});
export declare const RouteTransitTripStatus: any;
export interface RouteTransitArrival {
    Delay?: number;
    Place: RouteTransitPlace;
    Status?: RouteTransitTripStatus;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteTransitArrival: S.Schema<RouteTransitArrival>;
export type RouteTransitBeforeTravelStepType = "Board" | (string & {});
export declare const RouteTransitBeforeTravelStepType: any;
export interface RouteTransitBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteTransitBeforeTravelStepType;
}
export declare const RouteTransitBeforeTravelStep: S.Schema<RouteTransitBeforeTravelStep>;
export type RouteTransitBeforeTravelStepList = RouteTransitBeforeTravelStep[];
export declare const RouteTransitBeforeTravelStepList: any;
export interface RouteTransitDeparture {
    Delay?: number;
    Place: RouteTransitPlace;
    Status?: RouteTransitTripStatus;
    Time?: string | redacted.Redacted<string>;
}
export declare const RouteTransitDeparture: S.Schema<RouteTransitDeparture>;
export type RouteTransitIncidentEffect = "Delayed" | "Detoured" | "Other" | "ServiceAdded" | "ServiceCancelled" | "ServiceModified" | "ServiceReduced" | "StopMoved" | (string & {});
export declare const RouteTransitIncidentEffect: any;
export type RouteTransitIncidentType = "Accident" | "Construction" | "Demonstration" | "Holiday" | "Maintenance" | "MedicalEmergency" | "Other" | "PoliceActivity" | "Strike" | "TechnicalProblem" | "Weather" | (string & {});
export declare const RouteTransitIncidentType: any;
export interface RouteTransitIncident {
    Description?: string | redacted.Redacted<string>;
    Effect: RouteTransitIncidentEffect;
    EndTime?: string | redacted.Redacted<string>;
    StartTime?: string | redacted.Redacted<string>;
    Type: RouteTransitIncidentType;
    Url?: string | redacted.Redacted<string>;
}
export declare const RouteTransitIncident: S.Schema<RouteTransitIncident>;
export type RouteTransitIncidentList = RouteTransitIncident[];
export declare const RouteTransitIncidentList: any;
export type RouteTransitIntermediateStopAttribute = "NoEntry" | "NoExit" | (string & {});
export declare const RouteTransitIntermediateStopAttribute: any;
export type RouteTransitIntermediateStopAttributeList = RouteTransitIntermediateStopAttribute[];
export declare const RouteTransitIntermediateStopAttributeList: any;
export type HexColor = string | redacted.Redacted<string>;
export interface RouteTransitTransportModeDetails {
    Accessibility?: RouteAccessibilityAvailabilityDetails;
    Color?: string | redacted.Redacted<string>;
    Headsign?: string | redacted.Redacted<string>;
    LongRouteName?: string | redacted.Redacted<string>;
    Mode: RouteTransitMode;
    RouteName?: string | redacted.Redacted<string>;
    ShortRouteName?: string | redacted.Redacted<string>;
    TextColor?: string | redacted.Redacted<string>;
}
export declare const RouteTransitTransportModeDetails: S.Schema<RouteTransitTransportModeDetails>;
export interface RouteTransitIntermediateStop {
    Attributes?: RouteTransitIntermediateStopAttribute[];
    Departure: RouteTransitDeparture;
    Duration: number;
    GeometryOffset?: number;
    Transport?: RouteTransitTransportModeDetails;
}
export declare const RouteTransitIntermediateStop: S.Schema<RouteTransitIntermediateStop>;
export type RouteTransitIntermediateStopList = RouteTransitIntermediateStop[];
export declare const RouteTransitIntermediateStopList: any;
export interface RouteTransitNextDeparture {
    Delay?: number;
    PlatformName?: string | redacted.Redacted<string>;
    Status?: RouteTransitTripStatus;
    Time: string | redacted.Redacted<string>;
    Transport?: RouteTransitTransportModeDetails;
}
export declare const RouteTransitNextDeparture: S.Schema<RouteTransitNextDeparture>;
export type RouteTransitNextDepartureList = RouteTransitNextDeparture[];
export declare const RouteTransitNextDepartureList: any;
export type RouteTransitNoticeCode = "AccuratePolylineUnavailable" | "IntermediateStopsUnavailable" | "NoSchedule" | "Other" | "PotentialViolatedVehicleRestrictionUsage" | "ScheduledTimes" | "SeasonalClosure" | "ViolatedAvoidFerry" | "ViolatedAvoidRailFerry" | "ViolatedExcludedTransitMode" | "ViolatedVehicleRestriction" | "ViolatedAvoidAreas" | (string & {});
export declare const RouteTransitNoticeCode: any;
export interface RouteTransitNotice {
    Code: RouteTransitNoticeCode;
    Impact?: RouteNoticeImpact;
}
export declare const RouteTransitNotice: S.Schema<RouteTransitNotice>;
export type RouteTransitNoticeList = RouteTransitNotice[];
export declare const RouteTransitNoticeList: any;
export interface RouteTransitSpan {
    Country?: string | redacted.Redacted<string>;
    Distance?: number;
    Duration?: number;
    GeometryOffset?: number;
    Names?: LocalizedString[];
    Region?: string | redacted.Redacted<string>;
}
export declare const RouteTransitSpan: S.Schema<RouteTransitSpan>;
export type RouteTransitSpanList = RouteTransitSpan[];
export declare const RouteTransitSpanList: any;
export interface RouteTransitOverviewSummary {
    Distance: number;
    Duration: number;
}
export declare const RouteTransitOverviewSummary: S.Schema<RouteTransitOverviewSummary>;
export interface RouteTransitTravelOnlySummary {
    Duration: number;
}
export declare const RouteTransitTravelOnlySummary: S.Schema<RouteTransitTravelOnlySummary>;
export interface RouteTransitSummary {
    Overview?: RouteTransitOverviewSummary;
    TravelOnly?: RouteTransitTravelOnlySummary;
}
export declare const RouteTransitSummary: S.Schema<RouteTransitSummary>;
export type RouteTransitTravelStepType = "Depart" | (string & {});
export declare const RouteTransitTravelStepType: any;
export interface RouteTransitTravelStep {
    Distance?: number;
    Duration: number;
    GeometryOffset?: number;
    Instruction?: string | redacted.Redacted<string>;
    Type: RouteTransitTravelStepType;
}
export declare const RouteTransitTravelStep: S.Schema<RouteTransitTravelStep>;
export type RouteTransitTravelStepList = RouteTransitTravelStep[];
export declare const RouteTransitTravelStepList: any;
export interface RouteTransitLegDetails {
    AfterTravelSteps?: RouteTransitAfterTravelStep[];
    Agency?: RouteTransitAgency;
    Arrival: RouteTransitArrival;
    Attributions?: RouteAttribution[];
    BeforeTravelSteps?: RouteTransitBeforeTravelStep[];
    BookingWebLinks?: RouteWebLink[];
    Departure: RouteTransitDeparture;
    Incidents?: RouteTransitIncident[];
    IntermediateStops?: RouteTransitIntermediateStop[];
    NextDepartures?: RouteTransitNextDeparture[];
    Notices?: RouteTransitNotice[];
    PassThroughWaypoints?: RoutePassThroughWaypoint[];
    Spans?: RouteTransitSpan[];
    Summary?: RouteTransitSummary;
    Transport: RouteTransitTransportModeDetails;
    TravelSteps?: RouteTransitTravelStep[];
}
export declare const RouteTransitLegDetails: S.Schema<RouteTransitLegDetails>;
export interface RouteLeg {
    FerryLegDetails?: RouteFerryLegDetails;
    Geometry: RouteLegGeometry;
    Language?: string;
    PedestrianLegDetails?: RoutePedestrianLegDetails;
    TravelMode: RouteLegTravelMode;
    Type: RouteLegType;
    VehicleLegDetails?: RouteVehicleLegDetails;
    RentalLegDetails?: RouteRentalLegDetails;
    TaxiLegDetails?: RouteTaxiLegDetails;
    TransitLegDetails?: RouteTransitLegDetails;
}
export declare const RouteLeg: S.Schema<RouteLeg>;
export type RouteLegList = RouteLeg[];
export declare const RouteLegList: any;
export interface RouteMajorRoadLabel {
    RoadName?: LocalizedString;
    RouteNumber?: RouteNumber;
}
export declare const RouteMajorRoadLabel: S.Schema<RouteMajorRoadLabel>;
export type RouteMajorRoadLabelList = RouteMajorRoadLabel[];
export declare const RouteMajorRoadLabelList: any;
export interface RouteTollPriceSummary {
    Currency: string;
    Estimate: boolean;
    Range: boolean;
    RangeValue?: RouteTollPriceValueRange;
    Value: number;
}
export declare const RouteTollPriceSummary: S.Schema<RouteTollPriceSummary>;
export interface RouteTollSummary {
    Total?: RouteTollPriceSummary;
}
export declare const RouteTollSummary: S.Schema<RouteTollSummary>;
export interface RouteSummary {
    Distance?: number;
    Duration?: number;
    Tolls?: RouteTollSummary;
}
export declare const RouteSummary: S.Schema<RouteSummary>;
export interface Route {
    Legs: RouteLeg[];
    MajorRoadLabels: RouteMajorRoadLabel[];
    Summary?: RouteSummary;
}
export declare const Route: S.Schema<Route>;
export type RouteList = Route[];
export declare const RouteList: any;
export interface CalculateRoutesResponse {
    LegGeometryFormat: GeometryFormat;
    Notices: RouteResponseNotice[];
    PricingBucket: string;
    Routes: Route[];
}
export declare const CalculateRoutesResponse: S.Schema<CalculateRoutesResponse>;
export interface WaypointOptimizationAvoidanceAreaGeometry {
    BoundingBox?: number[];
}
export declare const WaypointOptimizationAvoidanceAreaGeometry: S.Schema<WaypointOptimizationAvoidanceAreaGeometry>;
export interface WaypointOptimizationAvoidanceArea {
    Geometry: WaypointOptimizationAvoidanceAreaGeometry;
}
export declare const WaypointOptimizationAvoidanceArea: S.Schema<WaypointOptimizationAvoidanceArea>;
export type WaypointOptimizationAvoidanceAreaList = WaypointOptimizationAvoidanceArea[];
export declare const WaypointOptimizationAvoidanceAreaList: any;
export interface WaypointOptimizationAvoidanceOptions {
    Areas?: WaypointOptimizationAvoidanceArea[];
    CarShuttleTrains?: boolean;
    ControlledAccessHighways?: boolean;
    DirtRoads?: boolean;
    Ferries?: boolean;
    TollRoads?: boolean;
    Tunnels?: boolean;
    UTurns?: boolean;
}
export declare const WaypointOptimizationAvoidanceOptions: S.Schema<WaypointOptimizationAvoidanceOptions>;
export type WaypointOptimizationClusteringAlgorithm = "DrivingDistance" | "TopologySegment" | (string & {});
export declare const WaypointOptimizationClusteringAlgorithm: any;
export type WaypointOptimizationDrivingDistance = number;
export interface WaypointOptimizationDrivingDistanceOptions {
    DrivingDistance: number;
}
export declare const WaypointOptimizationDrivingDistanceOptions: S.Schema<WaypointOptimizationDrivingDistanceOptions>;
export interface WaypointOptimizationClusteringOptions {
    Algorithm: WaypointOptimizationClusteringAlgorithm;
    DrivingDistanceOptions?: WaypointOptimizationDrivingDistanceOptions;
}
export declare const WaypointOptimizationClusteringOptions: S.Schema<WaypointOptimizationClusteringOptions>;
export type DayOfWeek = "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday" | "Sunday" | (string & {});
export declare const DayOfWeek: any;
export type TimeOfDay = string | redacted.Redacted<string>;
export interface WaypointOptimizationAccessHoursEntry {
    DayOfWeek: DayOfWeek;
    TimeOfDay: string | redacted.Redacted<string>;
}
export declare const WaypointOptimizationAccessHoursEntry: S.Schema<WaypointOptimizationAccessHoursEntry>;
export interface WaypointOptimizationAccessHours {
    From: WaypointOptimizationAccessHoursEntry;
    To: WaypointOptimizationAccessHoursEntry;
}
export declare const WaypointOptimizationAccessHours: S.Schema<WaypointOptimizationAccessHours>;
export type WaypointId = string;
export interface WaypointOptimizationSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy;
}
export declare const WaypointOptimizationSideOfStreetOptions: S.Schema<WaypointOptimizationSideOfStreetOptions>;
export interface WaypointOptimizationDestinationOptions {
    AccessHours?: WaypointOptimizationAccessHours;
    AppointmentTime?: string | redacted.Redacted<string>;
    Heading?: number;
    Id?: string;
    ServiceDuration?: number;
    SideOfStreet?: WaypointOptimizationSideOfStreetOptions;
}
export declare const WaypointOptimizationDestinationOptions: S.Schema<WaypointOptimizationDestinationOptions>;
export interface WaypointOptimizationRestCycleDurations {
    RestDuration: number;
    WorkDuration: number;
}
export declare const WaypointOptimizationRestCycleDurations: S.Schema<WaypointOptimizationRestCycleDurations>;
export interface WaypointOptimizationRestCycles {
    LongCycle: WaypointOptimizationRestCycleDurations;
    ShortCycle: WaypointOptimizationRestCycleDurations;
}
export declare const WaypointOptimizationRestCycles: S.Schema<WaypointOptimizationRestCycles>;
export interface WaypointOptimizationRestProfile {
    Profile: string | redacted.Redacted<string>;
}
export declare const WaypointOptimizationRestProfile: S.Schema<WaypointOptimizationRestProfile>;
export type WaypointOptimizationServiceTimeTreatment = "Rest" | "Work" | (string & {});
export declare const WaypointOptimizationServiceTimeTreatment: any;
export interface WaypointOptimizationDriverOptions {
    RestCycles?: WaypointOptimizationRestCycles;
    RestProfile?: WaypointOptimizationRestProfile;
    TreatServiceTimeAs?: WaypointOptimizationServiceTimeTreatment;
}
export declare const WaypointOptimizationDriverOptions: S.Schema<WaypointOptimizationDriverOptions>;
export interface WaypointOptimizationExclusionOptions {
    Countries: (string | redacted.Redacted<string>)[];
}
export declare const WaypointOptimizationExclusionOptions: S.Schema<WaypointOptimizationExclusionOptions>;
export type WaypointOptimizationSequencingObjective = "FastestRoute" | "ShortestRoute" | (string & {});
export declare const WaypointOptimizationSequencingObjective: any;
export interface WaypointOptimizationOriginOptions {
    Id?: string;
}
export declare const WaypointOptimizationOriginOptions: S.Schema<WaypointOptimizationOriginOptions>;
export interface WaypointOptimizationTrafficOptions {
    Usage?: TrafficUsage;
}
export declare const WaypointOptimizationTrafficOptions: S.Schema<WaypointOptimizationTrafficOptions>;
export type WaypointOptimizationTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export declare const WaypointOptimizationTravelMode: any;
export interface WaypointOptimizationPedestrianOptions {
    Speed?: number;
}
export declare const WaypointOptimizationPedestrianOptions: S.Schema<WaypointOptimizationPedestrianOptions>;
export type WaypointOptimizationHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export declare const WaypointOptimizationHazardousCargoType: any;
export type WaypointOptimizationHazardousCargoTypeList = WaypointOptimizationHazardousCargoType[];
export declare const WaypointOptimizationHazardousCargoTypeList: any;
export interface WaypointOptimizationTrailerOptions {
    TrailerCount?: number;
}
export declare const WaypointOptimizationTrailerOptions: S.Schema<WaypointOptimizationTrailerOptions>;
export type WaypointOptimizationTruckType = "StraightTruck" | "Tractor" | (string & {});
export declare const WaypointOptimizationTruckType: any;
export interface WaypointOptimizationTruckOptions {
    GrossWeight?: number;
    HazardousCargos?: WaypointOptimizationHazardousCargoType[];
    Height?: number;
    Length?: number;
    Trailer?: WaypointOptimizationTrailerOptions;
    TruckType?: WaypointOptimizationTruckType;
    TunnelRestrictionCode?: string | redacted.Redacted<string>;
    WeightPerAxle?: number;
    Width?: number;
}
export declare const WaypointOptimizationTruckOptions: S.Schema<WaypointOptimizationTruckOptions>;
export interface WaypointOptimizationTravelModeOptions {
    Pedestrian?: WaypointOptimizationPedestrianOptions;
    Truck?: WaypointOptimizationTruckOptions;
}
export declare const WaypointOptimizationTravelModeOptions: S.Schema<WaypointOptimizationTravelModeOptions>;
export type WaypointIndex = number;
export type BeforeWaypointsList = number[];
export declare const BeforeWaypointsList: any;
export interface WaypointOptimizationWaypoint {
    AccessHours?: WaypointOptimizationAccessHours;
    AppointmentTime?: string | redacted.Redacted<string>;
    Before?: number[];
    Heading?: number;
    Id?: string;
    Position: number[];
    ServiceDuration?: number;
    SideOfStreet?: WaypointOptimizationSideOfStreetOptions;
}
export declare const WaypointOptimizationWaypoint: S.Schema<WaypointOptimizationWaypoint>;
export type WaypointOptimizationWaypointList = WaypointOptimizationWaypoint[];
export declare const WaypointOptimizationWaypointList: any;
export interface OptimizeWaypointsRequest {
    Avoid?: WaypointOptimizationAvoidanceOptions;
    Clustering?: WaypointOptimizationClusteringOptions;
    DepartureTime?: string | redacted.Redacted<string>;
    Destination?: number[];
    DestinationOptions?: WaypointOptimizationDestinationOptions;
    Driver?: WaypointOptimizationDriverOptions;
    Exclude?: WaypointOptimizationExclusionOptions;
    Key?: string | redacted.Redacted<string>;
    OptimizeSequencingFor?: WaypointOptimizationSequencingObjective;
    Origin: number[];
    OriginOptions?: WaypointOptimizationOriginOptions;
    Traffic?: WaypointOptimizationTrafficOptions;
    TravelMode?: WaypointOptimizationTravelMode;
    TravelModeOptions?: WaypointOptimizationTravelModeOptions;
    Waypoints?: WaypointOptimizationWaypoint[];
}
export declare const OptimizeWaypointsRequest: S.Schema<OptimizeWaypointsRequest>;
export interface WaypointOptimizationConnection {
    Distance: number;
    From: string;
    RestDuration: number;
    To: string;
    TravelDuration: number;
    WaitDuration: number;
}
export declare const WaypointOptimizationConnection: S.Schema<WaypointOptimizationConnection>;
export type WaypointOptimizationConnectionList = WaypointOptimizationConnection[];
export declare const WaypointOptimizationConnectionList: any;
export type WaypointOptimizationConstraint = "AccessHours" | "AppointmentTime" | "Before" | "Heading" | "ServiceDuration" | "SideOfStreet" | (string & {});
export declare const WaypointOptimizationConstraint: any;
export interface WaypointOptimizationFailedConstraint {
    Constraint?: WaypointOptimizationConstraint;
    Reason?: string | redacted.Redacted<string>;
}
export declare const WaypointOptimizationFailedConstraint: S.Schema<WaypointOptimizationFailedConstraint>;
export type WaypointOptimizationFailedConstraintList = WaypointOptimizationFailedConstraint[];
export declare const WaypointOptimizationFailedConstraintList: any;
export interface WaypointOptimizationImpedingWaypoint {
    FailedConstraints: WaypointOptimizationFailedConstraint[];
    Id: string;
    Position: number[];
}
export declare const WaypointOptimizationImpedingWaypoint: S.Schema<WaypointOptimizationImpedingWaypoint>;
export type WaypointOptimizationImpedingWaypointList = WaypointOptimizationImpedingWaypoint[];
export declare const WaypointOptimizationImpedingWaypointList: any;
export type ClusterIndex = number;
export interface WaypointOptimizationOptimizedWaypoint {
    ArrivalTime?: string | redacted.Redacted<string>;
    ClusterIndex?: number;
    DepartureTime?: string | redacted.Redacted<string>;
    Id: string;
    Position: number[];
}
export declare const WaypointOptimizationOptimizedWaypoint: S.Schema<WaypointOptimizationOptimizedWaypoint>;
export type WaypointOptimizationOptimizedWaypointList = WaypointOptimizationOptimizedWaypoint[];
export declare const WaypointOptimizationOptimizedWaypointList: any;
export interface WaypointOptimizationTimeBreakdown {
    RestDuration: number;
    ServiceDuration: number;
    TravelDuration: number;
    WaitDuration: number;
}
export declare const WaypointOptimizationTimeBreakdown: S.Schema<WaypointOptimizationTimeBreakdown>;
export interface OptimizeWaypointsResponse {
    Connections: WaypointOptimizationConnection[];
    Distance: number;
    Duration: number;
    ImpedingWaypoints: WaypointOptimizationImpedingWaypoint[];
    OptimizedWaypoints: WaypointOptimizationOptimizedWaypoint[];
    PricingBucket: string;
    TimeBreakdown: WaypointOptimizationTimeBreakdown;
}
export declare const OptimizeWaypointsResponse: S.Schema<OptimizeWaypointsResponse>;
export interface RoadSnapTracePoint {
    Heading?: number;
    Position: number[];
    Speed?: number;
    Timestamp?: string | redacted.Redacted<string>;
}
export declare const RoadSnapTracePoint: S.Schema<RoadSnapTracePoint>;
export type RoadSnapTracePointList = RoadSnapTracePoint[];
export declare const RoadSnapTracePointList: any;
export type RoadSnapTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export declare const RoadSnapTravelMode: any;
export type RoadSnapHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export declare const RoadSnapHazardousCargoType: any;
export type RoadSnapHazardousCargoTypeList = RoadSnapHazardousCargoType[];
export declare const RoadSnapHazardousCargoTypeList: any;
export interface RoadSnapTrailerOptions {
    TrailerCount?: number;
}
export declare const RoadSnapTrailerOptions: S.Schema<RoadSnapTrailerOptions>;
export interface RoadSnapTruckOptions {
    GrossWeight?: number;
    HazardousCargos?: RoadSnapHazardousCargoType[];
    Height?: number;
    Length?: number;
    Trailer?: RoadSnapTrailerOptions;
    TunnelRestrictionCode?: string | redacted.Redacted<string>;
    Width?: number;
}
export declare const RoadSnapTruckOptions: S.Schema<RoadSnapTruckOptions>;
export interface RoadSnapTravelModeOptions {
    Truck?: RoadSnapTruckOptions;
}
export declare const RoadSnapTravelModeOptions: S.Schema<RoadSnapTravelModeOptions>;
export interface SnapToRoadsRequest {
    Key?: string | redacted.Redacted<string>;
    SnappedGeometryFormat?: GeometryFormat;
    SnapRadius?: number;
    TracePoints: RoadSnapTracePoint[];
    TravelMode?: RoadSnapTravelMode;
    TravelModeOptions?: RoadSnapTravelModeOptions;
}
export declare const SnapToRoadsRequest: S.Schema<SnapToRoadsRequest>;
export type RoadSnapNoticeCode = "TracePointsHeadingIgnored" | "TracePointsIgnored" | "TracePointsMovedByLargeDistance" | "TracePointsNotMatched" | "TracePointsOutOfSequence" | "TracePointsSpeedEstimated" | "TracePointsSpeedIgnored" | (string & {});
export declare const RoadSnapNoticeCode: any;
export type RoadSnapTracePointIndexList = number[];
export declare const RoadSnapTracePointIndexList: any;
export interface RoadSnapNotice {
    Code: RoadSnapNoticeCode;
    Title: string | redacted.Redacted<string>;
    TracePointIndexes: number[];
}
export declare const RoadSnapNotice: S.Schema<RoadSnapNotice>;
export type RoadSnapNoticeList = RoadSnapNotice[];
export declare const RoadSnapNoticeList: any;
export interface RoadSnapSnappedGeometry {
    LineString?: number[][];
    Polyline?: string | redacted.Redacted<string>;
}
export declare const RoadSnapSnappedGeometry: S.Schema<RoadSnapSnappedGeometry>;
export interface RoadSnapSnappedTracePoint {
    Confidence: number;
    OriginalPosition: number[];
    SnappedPosition: number[];
}
export declare const RoadSnapSnappedTracePoint: S.Schema<RoadSnapSnappedTracePoint>;
export type RoadSnapSnappedTracePointList = RoadSnapSnappedTracePoint[];
export declare const RoadSnapSnappedTracePointList: any;
export interface SnapToRoadsResponse {
    Notices: RoadSnapNotice[];
    PricingBucket: string;
    SnappedGeometry?: RoadSnapSnappedGeometry;
    SnappedGeometryFormat: GeometryFormat;
    SnappedTracePoints: RoadSnapSnappedTracePoint[];
}
export declare const SnapToRoadsResponse: S.Schema<SnapToRoadsResponse>;
export type ValidationExceptionReason = "UnknownOperation" | "Missing" | "CannotParse" | "FieldValidationFailed" | "Other" | "UnknownField" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type CalculateIsolinesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Calculates areas that can be reached within specified time or distance thresholds from a given point. For example, you can use this operation to determine the area within a 30-minute drive of a store location, find neighborhoods within walking distance of a school, or identify delivery zones based on drive time.
 *
 * Isolines (also known as isochrones for time-based calculations) are useful for various applications including:
 *
 * - Service area visualization - Show customers the area you can serve within promised delivery times
 *
 * - Site selection - Analyze potential business locations based on population within travel distance
 *
 * - Site selection - Determine areas that can be reached within specified response times
 *
 * Route preferences such as avoiding toll roads or ferries are treated as preferences rather than absolute restrictions. If a viable route cannot be calculated while honoring all preferences, some may be ignored.
 *
 * For more information, see Calculate isolines in the *Amazon Location Service Developer Guide*.
 */
export declare const calculateIsolines: API.OperationMethod<CalculateIsolinesRequest, CalculateIsolinesResponse, CalculateIsolinesError, Credentials | HttpClient.HttpClient>;
export type CalculateRouteMatrixError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use `CalculateRouteMatrix` to compute results for all pairs of Origins to Destinations. Each row corresponds to one entry in Origins. Each entry in the row corresponds to the route from that entry in Origins to an entry in Destinations positions.
 *
 * For more information, see Calculate route matrix in the *Amazon Location Service Developer Guide*.
 */
export declare const calculateRouteMatrix: API.OperationMethod<CalculateRouteMatrixRequest, CalculateRouteMatrixResponse, CalculateRouteMatrixError, Credentials | HttpClient.HttpClient>;
export type CalculateRoutesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `CalculateRoutes` computes routes given the following required parameters: `Origin` and `Destination`.
 *
 * For more information, see Calculate routes in the *Amazon Location Service Developer Guide*.
 */
export declare const calculateRoutes: API.OperationMethod<CalculateRoutesRequest, CalculateRoutesResponse, CalculateRoutesError, Credentials | HttpClient.HttpClient>;
export type OptimizeWaypointsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `OptimizeWaypoints` calculates the optimal order to travel between a set of waypoints to minimize either the travel time or the distance travelled during the journey, based on road network restrictions and the traffic pattern data.
 *
 * For more information, see Optimize waypoints in the *Amazon Location Service Developer Guide*.
 */
export declare const optimizeWaypoints: API.OperationMethod<OptimizeWaypointsRequest, OptimizeWaypointsResponse, OptimizeWaypointsError, Credentials | HttpClient.HttpClient>;
export type SnapToRoadsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SnapToRoads` matches GPS trace to roads most likely traveled on.
 *
 * For more information, see Snap to Roads in the *Amazon Location Service Developer Guide*.
 */
export declare const snapToRoads: API.OperationMethod<SnapToRoadsRequest, SnapToRoadsResponse, SnapToRoadsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=geo-routes.d.ts.map