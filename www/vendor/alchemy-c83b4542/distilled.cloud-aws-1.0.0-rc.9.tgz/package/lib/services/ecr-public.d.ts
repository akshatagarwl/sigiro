import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const EmptyUploadException_base: S.Class<EmptyUploadException, S.TaggedStruct<"EmptyUploadException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EmptyUploadException extends /*@__PURE__*/ EmptyUploadException_base {
}
declare const ImageAlreadyExistsException_base: S.Class<ImageAlreadyExistsException, S.TaggedStruct<"ImageAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ImageAlreadyExistsException extends /*@__PURE__*/ ImageAlreadyExistsException_base {
}
declare const ImageDigestDoesNotMatchException_base: S.Class<ImageDigestDoesNotMatchException, S.TaggedStruct<"ImageDigestDoesNotMatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageDigestDoesNotMatchException extends /*@__PURE__*/ ImageDigestDoesNotMatchException_base {
}
declare const ImageNotFoundException_base: S.Class<ImageNotFoundException, S.TaggedStruct<"ImageNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImageNotFoundException extends /*@__PURE__*/ ImageNotFoundException_base {
}
declare const ImageTagAlreadyExistsException_base: S.Class<ImageTagAlreadyExistsException, S.TaggedStruct<"ImageTagAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ImageTagAlreadyExistsException extends /*@__PURE__*/ ImageTagAlreadyExistsException_base {
}
declare const InvalidLayerException_base: S.Class<InvalidLayerException, S.TaggedStruct<"InvalidLayerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLayerException extends /*@__PURE__*/ InvalidLayerException_base {
}
declare const InvalidLayerPartException_base: S.Class<InvalidLayerPartException, S.TaggedStruct<"InvalidLayerPartException", {
    readonly registryId: any;
    readonly repositoryName: any;
    readonly uploadId: any;
    readonly lastValidByteReceived: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLayerPartException extends /*@__PURE__*/ InvalidLayerPartException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidTagParameterException_base: S.Class<InvalidTagParameterException, S.TaggedStruct<"InvalidTagParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagParameterException extends /*@__PURE__*/ InvalidTagParameterException_base {
}
declare const LayerAlreadyExistsException_base: S.Class<LayerAlreadyExistsException, S.TaggedStruct<"LayerAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class LayerAlreadyExistsException extends /*@__PURE__*/ LayerAlreadyExistsException_base {
}
declare const LayerPartTooSmallException_base: S.Class<LayerPartTooSmallException, S.TaggedStruct<"LayerPartTooSmallException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LayerPartTooSmallException extends /*@__PURE__*/ LayerPartTooSmallException_base {
}
declare const LayersNotFoundException_base: S.Class<LayersNotFoundException, S.TaggedStruct<"LayersNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LayersNotFoundException extends /*@__PURE__*/ LayersNotFoundException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ReferencedImagesNotFoundException_base: S.Class<ReferencedImagesNotFoundException, S.TaggedStruct<"ReferencedImagesNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ReferencedImagesNotFoundException extends /*@__PURE__*/ ReferencedImagesNotFoundException_base {
}
declare const RegistryNotFoundException_base: S.Class<RegistryNotFoundException, S.TaggedStruct<"RegistryNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RegistryNotFoundException extends /*@__PURE__*/ RegistryNotFoundException_base {
}
declare const RepositoryAlreadyExistsException_base: S.Class<RepositoryAlreadyExistsException, S.TaggedStruct<"RepositoryAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class RepositoryAlreadyExistsException extends /*@__PURE__*/ RepositoryAlreadyExistsException_base {
}
declare const RepositoryCatalogDataNotFoundException_base: S.Class<RepositoryCatalogDataNotFoundException, S.TaggedStruct<"RepositoryCatalogDataNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryCatalogDataNotFoundException extends /*@__PURE__*/ RepositoryCatalogDataNotFoundException_base {
}
declare const RepositoryNotEmptyException_base: S.Class<RepositoryNotEmptyException, S.TaggedStruct<"RepositoryNotEmptyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryNotEmptyException extends /*@__PURE__*/ RepositoryNotEmptyException_base {
}
declare const RepositoryNotFoundException_base: S.Class<RepositoryNotFoundException, S.TaggedStruct<"RepositoryNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryNotFoundException extends /*@__PURE__*/ RepositoryNotFoundException_base {
}
declare const RepositoryPolicyNotFoundException_base: S.Class<RepositoryPolicyNotFoundException, S.TaggedStruct<"RepositoryPolicyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RepositoryPolicyNotFoundException extends /*@__PURE__*/ RepositoryPolicyNotFoundException_base {
}
declare const ServerException_base: S.Class<ServerException, S.TaggedStruct<"ServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnsupportedCommandException_base: S.Class<UnsupportedCommandException, S.TaggedStruct<"UnsupportedCommandException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedCommandException extends /*@__PURE__*/ UnsupportedCommandException_base {
}
declare const UploadNotFoundException_base: S.Class<UploadNotFoundException, S.TaggedStruct<"UploadNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UploadNotFoundException extends /*@__PURE__*/ UploadNotFoundException_base {
}
export type RegistryIdOrAlias = string;
export type RepositoryName = string;
export type BatchedOperationLayerDigest = string;
export type BatchedOperationLayerDigestList = string[];
export declare const BatchedOperationLayerDigestList: any;
export interface BatchCheckLayerAvailabilityRequest {
    registryId?: string;
    repositoryName: string;
    layerDigests: string[];
}
export declare const BatchCheckLayerAvailabilityRequest: S.Schema<BatchCheckLayerAvailabilityRequest>;
export type LayerDigest = string;
export type LayerAvailability = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export declare const LayerAvailability: any;
export type LayerSizeInBytes = number;
export type MediaType = string;
export interface Layer {
    layerDigest?: string;
    layerAvailability?: LayerAvailability;
    layerSize?: number;
    mediaType?: string;
}
export declare const Layer: S.Schema<Layer>;
export type LayerList = Layer[];
export declare const LayerList: any;
export type LayerFailureCode = "InvalidLayerDigest" | "MissingLayerDigest" | (string & {});
export declare const LayerFailureCode: any;
export type LayerFailureReason = string;
export interface LayerFailure {
    layerDigest?: string;
    failureCode?: LayerFailureCode;
    failureReason?: string;
}
export declare const LayerFailure: S.Schema<LayerFailure>;
export type LayerFailureList = LayerFailure[];
export declare const LayerFailureList: any;
export interface BatchCheckLayerAvailabilityResponse {
    layers?: Layer[];
    failures?: LayerFailure[];
}
export declare const BatchCheckLayerAvailabilityResponse: S.Schema<BatchCheckLayerAvailabilityResponse>;
export type ImageDigest = string;
export type ImageTag = string;
export interface ImageIdentifier {
    imageDigest?: string;
    imageTag?: string;
}
export declare const ImageIdentifier: S.Schema<ImageIdentifier>;
export type ImageIdentifierList = ImageIdentifier[];
export declare const ImageIdentifierList: any;
export interface BatchDeleteImageRequest {
    registryId?: string;
    repositoryName: string;
    imageIds: ImageIdentifier[];
}
export declare const BatchDeleteImageRequest: S.Schema<BatchDeleteImageRequest>;
export type ImageFailureCode = "InvalidImageDigest" | "InvalidImageTag" | "ImageTagDoesNotMatchDigest" | "ImageNotFound" | "MissingDigestAndTag" | "ImageReferencedByManifestList" | "KmsError" | (string & {});
export declare const ImageFailureCode: any;
export type ImageFailureReason = string;
export interface ImageFailure {
    imageId?: ImageIdentifier;
    failureCode?: ImageFailureCode;
    failureReason?: string;
}
export declare const ImageFailure: S.Schema<ImageFailure>;
export type ImageFailureList = ImageFailure[];
export declare const ImageFailureList: any;
export interface BatchDeleteImageResponse {
    imageIds?: ImageIdentifier[];
    failures?: ImageFailure[];
}
export declare const BatchDeleteImageResponse: S.Schema<BatchDeleteImageResponse>;
export type UploadId = string;
export type LayerDigestList = string[];
export declare const LayerDigestList: any;
export interface CompleteLayerUploadRequest {
    registryId?: string;
    repositoryName: string;
    uploadId: string;
    layerDigests: string[];
}
export declare const CompleteLayerUploadRequest: S.Schema<CompleteLayerUploadRequest>;
export type RegistryId = string;
export interface CompleteLayerUploadResponse {
    registryId?: string;
    repositoryName?: string;
    uploadId?: string;
    layerDigest?: string;
}
export declare const CompleteLayerUploadResponse: S.Schema<CompleteLayerUploadResponse>;
export type RepositoryDescription = string;
export type Architecture = string;
export type ArchitectureList = string[];
export declare const ArchitectureList: any;
export type OperatingSystem = string;
export type OperatingSystemList = string[];
export declare const OperatingSystemList: any;
export type LogoImageBlob = Uint8Array;
export type AboutText = string;
export type UsageText = string;
export interface RepositoryCatalogDataInput {
    description?: string;
    architectures?: string[];
    operatingSystems?: string[];
    logoImageBlob?: Uint8Array;
    aboutText?: string;
    usageText?: string;
}
export declare const RepositoryCatalogDataInput: S.Schema<RepositoryCatalogDataInput>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateRepositoryRequest {
    repositoryName: string;
    catalogData?: RepositoryCatalogDataInput;
    tags?: Tag[];
}
export declare const CreateRepositoryRequest: S.Schema<CreateRepositoryRequest>;
export type Arn = string;
export type Url = string;
export type CreationTimestamp = Date;
export interface Repository {
    repositoryArn?: string;
    registryId?: string;
    repositoryName?: string;
    repositoryUri?: string;
    createdAt?: Date;
}
export declare const Repository: S.Schema<Repository>;
export type ResourceUrl = string;
export type MarketplaceCertified = boolean;
export interface RepositoryCatalogData {
    description?: string;
    architectures?: string[];
    operatingSystems?: string[];
    logoUrl?: string;
    aboutText?: string;
    usageText?: string;
    marketplaceCertified?: boolean;
}
export declare const RepositoryCatalogData: S.Schema<RepositoryCatalogData>;
export interface CreateRepositoryResponse {
    repository?: Repository;
    catalogData?: RepositoryCatalogData;
}
export declare const CreateRepositoryResponse: S.Schema<CreateRepositoryResponse>;
export type ForceFlag = boolean;
export interface DeleteRepositoryRequest {
    registryId?: string;
    repositoryName: string;
    force?: boolean;
}
export declare const DeleteRepositoryRequest: S.Schema<DeleteRepositoryRequest>;
export interface DeleteRepositoryResponse {
    repository?: Repository;
}
export declare const DeleteRepositoryResponse: S.Schema<DeleteRepositoryResponse>;
export interface DeleteRepositoryPolicyRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const DeleteRepositoryPolicyRequest: S.Schema<DeleteRepositoryPolicyRequest>;
export type RepositoryPolicyText = string;
export interface DeleteRepositoryPolicyResponse {
    registryId?: string;
    repositoryName?: string;
    policyText?: string;
}
export declare const DeleteRepositoryPolicyResponse: S.Schema<DeleteRepositoryPolicyResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface DescribeImagesRequest {
    registryId?: string;
    repositoryName: string;
    imageIds?: ImageIdentifier[];
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeImagesRequest: S.Schema<DescribeImagesRequest>;
export type ImageTagList = string[];
export declare const ImageTagList: any;
export type ImageSizeInBytes = number;
export type PushTimestamp = Date;
export interface ImageDetail {
    registryId?: string;
    repositoryName?: string;
    imageDigest?: string;
    imageTags?: string[];
    imageSizeInBytes?: number;
    imagePushedAt?: Date;
    imageManifestMediaType?: string;
    artifactMediaType?: string;
}
export declare const ImageDetail: S.Schema<ImageDetail>;
export type ImageDetailList = ImageDetail[];
export declare const ImageDetailList: any;
export interface DescribeImagesResponse {
    imageDetails?: ImageDetail[];
    nextToken?: string;
}
export declare const DescribeImagesResponse: S.Schema<DescribeImagesResponse>;
export interface DescribeImageTagsRequest {
    registryId?: string;
    repositoryName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeImageTagsRequest: S.Schema<DescribeImageTagsRequest>;
export interface ReferencedImageDetail {
    imageDigest?: string;
    imageSizeInBytes?: number;
    imagePushedAt?: Date;
    imageManifestMediaType?: string;
    artifactMediaType?: string;
}
export declare const ReferencedImageDetail: S.Schema<ReferencedImageDetail>;
export interface ImageTagDetail {
    imageTag?: string;
    createdAt?: Date;
    imageDetail?: ReferencedImageDetail;
}
export declare const ImageTagDetail: S.Schema<ImageTagDetail>;
export type ImageTagDetailList = ImageTagDetail[];
export declare const ImageTagDetailList: any;
export interface DescribeImageTagsResponse {
    imageTagDetails?: ImageTagDetail[];
    nextToken?: string;
}
export declare const DescribeImageTagsResponse: S.Schema<DescribeImageTagsResponse>;
export interface DescribeRegistriesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeRegistriesRequest: S.Schema<DescribeRegistriesRequest>;
export type RegistryVerified = boolean;
export type RegistryAliasName = string;
export type RegistryAliasStatus = "ACTIVE" | "PENDING" | "REJECTED" | (string & {});
export declare const RegistryAliasStatus: any;
export type PrimaryRegistryAliasFlag = boolean;
export type DefaultRegistryAliasFlag = boolean;
export interface RegistryAlias {
    name: string;
    status: RegistryAliasStatus;
    primaryRegistryAlias: boolean;
    defaultRegistryAlias: boolean;
}
export declare const RegistryAlias: S.Schema<RegistryAlias>;
export type RegistryAliasList = RegistryAlias[];
export declare const RegistryAliasList: any;
export interface Registry {
    registryId: string;
    registryArn: string;
    registryUri: string;
    verified: boolean;
    aliases: RegistryAlias[];
}
export declare const Registry: S.Schema<Registry>;
export type RegistryList = Registry[];
export declare const RegistryList: any;
export interface DescribeRegistriesResponse {
    registries: Registry[];
    nextToken?: string;
}
export declare const DescribeRegistriesResponse: S.Schema<DescribeRegistriesResponse>;
export type RepositoryNameList = string[];
export declare const RepositoryNameList: any;
export interface DescribeRepositoriesRequest {
    registryId?: string;
    repositoryNames?: string[];
    nextToken?: string;
    maxResults?: number;
}
export declare const DescribeRepositoriesRequest: S.Schema<DescribeRepositoriesRequest>;
export type RepositoryList = Repository[];
export declare const RepositoryList: any;
export interface DescribeRepositoriesResponse {
    repositories?: Repository[];
    nextToken?: string;
}
export declare const DescribeRepositoriesResponse: S.Schema<DescribeRepositoriesResponse>;
export interface GetAuthorizationTokenRequest {
}
export declare const GetAuthorizationTokenRequest: S.Schema<GetAuthorizationTokenRequest>;
export type Base64 = string;
export type ExpirationTimestamp = Date;
export interface AuthorizationData {
    authorizationToken?: string | redacted.Redacted<string>;
    expiresAt?: Date;
}
export declare const AuthorizationData: S.Schema<AuthorizationData>;
export interface GetAuthorizationTokenResponse {
    authorizationData?: AuthorizationData;
}
export declare const GetAuthorizationTokenResponse: S.Schema<GetAuthorizationTokenResponse>;
export interface GetRegistryCatalogDataRequest {
}
export declare const GetRegistryCatalogDataRequest: S.Schema<GetRegistryCatalogDataRequest>;
export type RegistryDisplayName = string;
export interface RegistryCatalogData {
    displayName?: string;
}
export declare const RegistryCatalogData: S.Schema<RegistryCatalogData>;
export interface GetRegistryCatalogDataResponse {
    registryCatalogData: RegistryCatalogData;
}
export declare const GetRegistryCatalogDataResponse: S.Schema<GetRegistryCatalogDataResponse>;
export interface GetRepositoryCatalogDataRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const GetRepositoryCatalogDataRequest: S.Schema<GetRepositoryCatalogDataRequest>;
export interface GetRepositoryCatalogDataResponse {
    catalogData?: RepositoryCatalogData;
}
export declare const GetRepositoryCatalogDataResponse: S.Schema<GetRepositoryCatalogDataResponse>;
export interface GetRepositoryPolicyRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const GetRepositoryPolicyRequest: S.Schema<GetRepositoryPolicyRequest>;
export interface GetRepositoryPolicyResponse {
    registryId?: string;
    repositoryName?: string;
    policyText?: string;
}
export declare const GetRepositoryPolicyResponse: S.Schema<GetRepositoryPolicyResponse>;
export interface InitiateLayerUploadRequest {
    registryId?: string;
    repositoryName: string;
}
export declare const InitiateLayerUploadRequest: S.Schema<InitiateLayerUploadRequest>;
export type PartSize = number;
export interface InitiateLayerUploadResponse {
    uploadId?: string;
    partSize?: number;
}
export declare const InitiateLayerUploadResponse: S.Schema<InitiateLayerUploadResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type ImageManifest = string;
export interface PutImageRequest {
    registryId?: string;
    repositoryName: string;
    imageManifest: string;
    imageManifestMediaType?: string;
    imageTag?: string;
    imageDigest?: string;
}
export declare const PutImageRequest: S.Schema<PutImageRequest>;
export interface Image {
    registryId?: string;
    repositoryName?: string;
    imageId?: ImageIdentifier;
    imageManifest?: string;
    imageManifestMediaType?: string;
}
export declare const Image: S.Schema<Image>;
export interface PutImageResponse {
    image?: Image;
}
export declare const PutImageResponse: S.Schema<PutImageResponse>;
export interface PutRegistryCatalogDataRequest {
    displayName?: string;
}
export declare const PutRegistryCatalogDataRequest: S.Schema<PutRegistryCatalogDataRequest>;
export interface PutRegistryCatalogDataResponse {
    registryCatalogData: RegistryCatalogData;
}
export declare const PutRegistryCatalogDataResponse: S.Schema<PutRegistryCatalogDataResponse>;
export interface PutRepositoryCatalogDataRequest {
    registryId?: string;
    repositoryName: string;
    catalogData: RepositoryCatalogDataInput;
}
export declare const PutRepositoryCatalogDataRequest: S.Schema<PutRepositoryCatalogDataRequest>;
export interface PutRepositoryCatalogDataResponse {
    catalogData?: RepositoryCatalogData;
}
export declare const PutRepositoryCatalogDataResponse: S.Schema<PutRepositoryCatalogDataResponse>;
export interface SetRepositoryPolicyRequest {
    registryId?: string;
    repositoryName: string;
    policyText: string;
    force?: boolean;
}
export declare const SetRepositoryPolicyRequest: S.Schema<SetRepositoryPolicyRequest>;
export interface SetRepositoryPolicyResponse {
    registryId?: string;
    repositoryName?: string;
    policyText?: string;
}
export declare const SetRepositoryPolicyResponse: S.Schema<SetRepositoryPolicyResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type LayerPartBlob = Uint8Array;
export interface UploadLayerPartRequest {
    registryId?: string;
    repositoryName: string;
    uploadId: string;
    partFirstByte: number;
    partLastByte: number;
    layerPartBlob: Uint8Array;
}
export declare const UploadLayerPartRequest: S.Schema<UploadLayerPartRequest>;
export interface UploadLayerPartResponse {
    registryId?: string;
    repositoryName?: string;
    uploadId?: string;
    lastByteReceived?: number;
}
export declare const UploadLayerPartResponse: S.Schema<UploadLayerPartResponse>;
export type ExceptionMessage = string;
export type BatchCheckLayerAvailabilityError = InvalidParameterException | RegistryNotFoundException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Checks the availability of one or more image layers that are within a repository in a
 * public registry. When an image is pushed to a repository, each image layer is checked to
 * verify if it has been uploaded before. If it has been uploaded, then the image layer is
 * skipped.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const batchCheckLayerAvailability: API.OperationMethod<BatchCheckLayerAvailabilityRequest, BatchCheckLayerAvailabilityResponse, BatchCheckLayerAvailabilityError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteImageError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Deletes a list of specified images that are within a repository in a public registry.
 * Images are specified with either an `imageTag` or
 * `imageDigest`.
 *
 * You can remove a tag from an image by specifying the image's tag in your request. When
 * you remove the last tag from an image, the image is deleted from your repository.
 *
 * You can completely delete an image (and all of its tags) by specifying the digest of the
 * image in your request.
 */
export declare const batchDeleteImage: API.OperationMethod<BatchDeleteImageRequest, BatchDeleteImageResponse, BatchDeleteImageError, Credentials | HttpClient.HttpClient>;
export type CompleteLayerUploadError = EmptyUploadException | InvalidLayerException | InvalidParameterException | LayerAlreadyExistsException | LayerPartTooSmallException | RegistryNotFoundException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | UploadNotFoundException | CommonErrors;
/**
 * Informs Amazon ECR that the image layer upload is complete for a specified public registry,
 * repository name, and upload ID. You can optionally provide a `sha256` digest of
 * the image layer for data validation purposes.
 *
 * When an image is pushed, the CompleteLayerUpload API is called once for each new image
 * layer to verify that the upload is complete.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const completeLayerUpload: API.OperationMethod<CompleteLayerUploadRequest, CompleteLayerUploadResponse, CompleteLayerUploadError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryError = InvalidParameterException | InvalidTagParameterException | LimitExceededException | RepositoryAlreadyExistsException | ServerException | TooManyTagsException | UnsupportedCommandException | CommonErrors;
/**
 * Creates a repository in a public registry. For more information, see Amazon ECR
 * repositories in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const createRepository: API.OperationMethod<CreateRepositoryRequest, CreateRepositoryResponse, CreateRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryError = InvalidParameterException | RepositoryNotEmptyException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Deletes a repository in a public registry. If the repository contains images, you must
 * either manually delete all images in the repository or use the `force` option.
 * This option deletes all images on your behalf before deleting the repository.
 */
export declare const deleteRepository: API.OperationMethod<DeleteRepositoryRequest, DeleteRepositoryResponse, DeleteRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | RepositoryPolicyNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Deletes the repository policy that's associated with the specified repository.
 */
export declare const deleteRepositoryPolicy: API.OperationMethod<DeleteRepositoryPolicyRequest, DeleteRepositoryPolicyResponse, DeleteRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeImagesError = ImageNotFoundException | InvalidParameterException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Returns metadata that's related to the images in a repository in a public
 * registry.
 *
 * Beginning with Docker version 1.9, the Docker client compresses image layers before
 * pushing them to a V2 Docker registry. The output of the `docker images`
 * command shows the uncompressed image size. Therefore, it might return a larger image
 * size than the image sizes that are returned by DescribeImages.
 */
export declare const describeImages: API.PaginatedOperationMethod<DescribeImagesRequest, DescribeImagesResponse, DescribeImagesError, Credentials | HttpClient.HttpClient, ImageDetail>;
export type DescribeImageTagsError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Returns the image tag details for a repository in a public registry.
 */
export declare const describeImageTags: API.PaginatedOperationMethod<DescribeImageTagsRequest, DescribeImageTagsResponse, DescribeImageTagsError, Credentials | HttpClient.HttpClient, ImageTagDetail>;
export type DescribeRegistriesError = InvalidParameterException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Returns details for a public registry.
 */
export declare const describeRegistries: API.PaginatedOperationMethod<DescribeRegistriesRequest, DescribeRegistriesResponse, DescribeRegistriesError, Credentials | HttpClient.HttpClient, Registry>;
export type DescribeRepositoriesError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Describes repositories that are in a public registry.
 */
export declare const describeRepositories: API.PaginatedOperationMethod<DescribeRepositoriesRequest, DescribeRepositoriesResponse, DescribeRepositoriesError, Credentials | HttpClient.HttpClient, Repository>;
export type GetAuthorizationTokenError = InvalidParameterException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Retrieves an authorization token. An authorization token represents your IAM
 * authentication credentials. You can use it to access any Amazon ECR registry that your IAM
 * principal has access to. The authorization token is valid for 12 hours. This API requires
 * the `ecr-public:GetAuthorizationToken` and
 * `sts:GetServiceBearerToken` permissions.
 */
export declare const getAuthorizationToken: API.OperationMethod<GetAuthorizationTokenRequest, GetAuthorizationTokenResponse, GetAuthorizationTokenError, Credentials | HttpClient.HttpClient>;
export type GetRegistryCatalogDataError = ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Retrieves catalog metadata for a public registry.
 */
export declare const getRegistryCatalogData: API.OperationMethod<GetRegistryCatalogDataRequest, GetRegistryCatalogDataResponse, GetRegistryCatalogDataError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryCatalogDataError = InvalidParameterException | RepositoryCatalogDataNotFoundException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Retrieve catalog metadata for a repository in a public registry. This metadata is
 * displayed publicly in the Amazon ECR Public Gallery.
 */
export declare const getRepositoryCatalogData: API.OperationMethod<GetRepositoryCatalogDataRequest, GetRepositoryCatalogDataResponse, GetRepositoryCatalogDataError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | RepositoryPolicyNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Retrieves the repository policy for the specified repository.
 */
export declare const getRepositoryPolicy: API.OperationMethod<GetRepositoryPolicyRequest, GetRepositoryPolicyResponse, GetRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type InitiateLayerUploadError = InvalidParameterException | RegistryNotFoundException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Notifies Amazon ECR that you intend to upload an image layer.
 *
 * When an image is pushed, the InitiateLayerUpload API is called once for each image layer
 * that hasn't already been uploaded. Whether an image layer uploads is determined by the
 * BatchCheckLayerAvailability API action.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const initiateLayerUpload: API.OperationMethod<InitiateLayerUploadRequest, InitiateLayerUploadResponse, InitiateLayerUploadError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * List the tags for an Amazon ECR Public resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutImageError = ImageAlreadyExistsException | ImageDigestDoesNotMatchException | ImageTagAlreadyExistsException | InvalidParameterException | LayersNotFoundException | LimitExceededException | ReferencedImagesNotFoundException | RegistryNotFoundException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Creates or updates the image manifest and tags that are associated with an image.
 *
 * When an image is pushed and all new image layers have been uploaded, the PutImage API is
 * called once to create or update the image manifest and the tags that are associated with
 * the image.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const putImage: API.OperationMethod<PutImageRequest, PutImageResponse, PutImageError, Credentials | HttpClient.HttpClient>;
export type PutRegistryCatalogDataError = InvalidParameterException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Create or update the catalog data for a public registry.
 */
export declare const putRegistryCatalogData: API.OperationMethod<PutRegistryCatalogDataRequest, PutRegistryCatalogDataResponse, PutRegistryCatalogDataError, Credentials | HttpClient.HttpClient>;
export type PutRepositoryCatalogDataError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Creates or updates the catalog data for a repository in a public registry.
 */
export declare const putRepositoryCatalogData: API.OperationMethod<PutRepositoryCatalogDataRequest, PutRepositoryCatalogDataResponse, PutRepositoryCatalogDataError, Credentials | HttpClient.HttpClient>;
export type SetRepositoryPolicyError = InvalidParameterException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | CommonErrors;
/**
 * Applies a repository policy to the specified public repository to control access
 * permissions. For more information, see Amazon ECR Repository
 * Policies in the *Amazon Elastic Container Registry User Guide*.
 */
export declare const setRepositoryPolicy: API.OperationMethod<SetRepositoryPolicyRequest, SetRepositoryPolicyResponse, SetRepositoryPolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | InvalidTagParameterException | RepositoryNotFoundException | ServerException | TooManyTagsException | UnsupportedCommandException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`.
 * If existing tags on a resource aren't specified in the request parameters, they aren't
 * changed. When a resource is deleted, the tags associated with that resource are also
 * deleted.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | InvalidTagParameterException | RepositoryNotFoundException | ServerException | TooManyTagsException | UnsupportedCommandException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UploadLayerPartError = InvalidLayerPartException | InvalidParameterException | LimitExceededException | RegistryNotFoundException | RepositoryNotFoundException | ServerException | UnsupportedCommandException | UploadNotFoundException | CommonErrors;
/**
 * Uploads an image layer part to Amazon ECR.
 *
 * When an image is pushed, each new image layer is uploaded in parts. The maximum size of
 * each image layer part can be 20971520 bytes (about 20MB). The UploadLayerPart API is called
 * once for each new image layer part.
 *
 * This operation is used by the Amazon ECR proxy and is not generally used by customers for pulling and pushing images. In most cases, you should use the `docker` CLI to pull, tag, and push images.
 */
export declare const uploadLayerPart: API.OperationMethod<UploadLayerPartRequest, UploadLayerPartResponse, UploadLayerPartError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ecr-public.d.ts.map