import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainName = string;
export type AccountId = string;
export type RepositoryName = string;
export type ExternalConnectionName = string;
export interface AssociateExternalConnectionRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    externalConnection: string;
}
export declare const AssociateExternalConnectionRequest: S.Schema<AssociateExternalConnectionRequest>;
export type Arn = string;
export type Description = string;
export interface UpstreamRepositoryInfo {
    repositoryName?: string;
}
export declare const UpstreamRepositoryInfo: S.Schema<UpstreamRepositoryInfo>;
export type UpstreamRepositoryInfoList = UpstreamRepositoryInfo[];
export declare const UpstreamRepositoryInfoList: any;
export type PackageFormat = "npm" | "pypi" | "maven" | "nuget" | "generic" | "ruby" | "swift" | "cargo" | (string & {});
export declare const PackageFormat: any;
export type ExternalConnectionStatus = "Available" | (string & {});
export declare const ExternalConnectionStatus: any;
export interface RepositoryExternalConnectionInfo {
    externalConnectionName?: string;
    packageFormat?: PackageFormat;
    status?: ExternalConnectionStatus;
}
export declare const RepositoryExternalConnectionInfo: S.Schema<RepositoryExternalConnectionInfo>;
export type RepositoryExternalConnectionInfoList = RepositoryExternalConnectionInfo[];
export declare const RepositoryExternalConnectionInfoList: any;
export interface RepositoryDescription {
    name?: string;
    administratorAccount?: string;
    domainName?: string;
    domainOwner?: string;
    arn?: string;
    description?: string;
    upstreams?: UpstreamRepositoryInfo[];
    externalConnections?: RepositoryExternalConnectionInfo[];
    createdTime?: Date;
}
export declare const RepositoryDescription: S.Schema<RepositoryDescription>;
export interface AssociateExternalConnectionResult {
    repository?: RepositoryDescription;
}
export declare const AssociateExternalConnectionResult: S.Schema<AssociateExternalConnectionResult>;
export type PackageNamespace = string;
export type PackageName = string;
export type PackageVersion = string;
export type PackageVersionList = string[];
export declare const PackageVersionList: any;
export type PackageVersionRevision = string;
export type PackageVersionRevisionMap = {
    [key: string]: string | undefined;
};
export declare const PackageVersionRevisionMap: any;
export interface CopyPackageVersionsRequest {
    domain: string;
    domainOwner?: string;
    sourceRepository: string;
    destinationRepository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    versions?: string[];
    versionRevisions?: {
        [key: string]: string | undefined;
    };
    allowOverwrite?: boolean;
    includeFromUpstream?: boolean;
}
export declare const CopyPackageVersionsRequest: S.Schema<CopyPackageVersionsRequest>;
export type PackageVersionStatus = "Published" | "Unfinished" | "Unlisted" | "Archived" | "Disposed" | "Deleted" | (string & {});
export declare const PackageVersionStatus: any;
export interface SuccessfulPackageVersionInfo {
    revision?: string;
    status?: PackageVersionStatus;
}
export declare const SuccessfulPackageVersionInfo: S.Schema<SuccessfulPackageVersionInfo>;
export type SuccessfulPackageVersionInfoMap = {
    [key: string]: SuccessfulPackageVersionInfo | undefined;
};
export declare const SuccessfulPackageVersionInfoMap: any;
export type PackageVersionErrorCode = "ALREADY_EXISTS" | "MISMATCHED_REVISION" | "MISMATCHED_STATUS" | "NOT_ALLOWED" | "NOT_FOUND" | "SKIPPED" | (string & {});
export declare const PackageVersionErrorCode: any;
export type ErrorMessage = string;
export interface PackageVersionError {
    errorCode?: PackageVersionErrorCode;
    errorMessage?: string;
}
export declare const PackageVersionError: S.Schema<PackageVersionError>;
export type PackageVersionErrorMap = {
    [key: string]: PackageVersionError | undefined;
};
export declare const PackageVersionErrorMap: any;
export interface CopyPackageVersionsResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    };
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    };
}
export declare const CopyPackageVersionsResult: S.Schema<CopyPackageVersionsResult>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateDomainRequest {
    domain: string;
    encryptionKey?: string;
    tags?: Tag[];
}
export declare const CreateDomainRequest: S.Schema<CreateDomainRequest>;
export type DomainStatus = "Active" | "Deleted" | (string & {});
export declare const DomainStatus: any;
export interface DomainDescription {
    name?: string;
    owner?: string;
    arn?: string;
    status?: DomainStatus;
    createdTime?: Date;
    encryptionKey?: string;
    repositoryCount?: number;
    assetSizeBytes?: number;
    s3BucketArn?: string;
}
export declare const DomainDescription: S.Schema<DomainDescription>;
export interface CreateDomainResult {
    domain?: DomainDescription;
}
export declare const CreateDomainResult: S.Schema<CreateDomainResult>;
export type PackageGroupPattern = string;
export type PackageGroupContactInfo = string;
export interface CreatePackageGroupRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
    contactInfo?: string;
    description?: string;
    tags?: Tag[];
}
export declare const CreatePackageGroupRequest: S.Schema<CreatePackageGroupRequest>;
export type PackageGroupOriginRestrictionType = "EXTERNAL_UPSTREAM" | "INTERNAL_UPSTREAM" | "PUBLISH" | (string & {});
export declare const PackageGroupOriginRestrictionType: any;
export type PackageGroupOriginRestrictionMode = "ALLOW" | "ALLOW_SPECIFIC_REPOSITORIES" | "BLOCK" | "INHERIT" | (string & {});
export declare const PackageGroupOriginRestrictionMode: any;
export interface PackageGroupReference {
    arn?: string;
    pattern?: string;
}
export declare const PackageGroupReference: S.Schema<PackageGroupReference>;
export interface PackageGroupOriginRestriction {
    mode?: PackageGroupOriginRestrictionMode;
    effectiveMode?: PackageGroupOriginRestrictionMode;
    inheritedFrom?: PackageGroupReference;
    repositoriesCount?: number;
}
export declare const PackageGroupOriginRestriction: S.Schema<PackageGroupOriginRestriction>;
export type PackageGroupOriginRestrictions = {
    [key in PackageGroupOriginRestrictionType]?: PackageGroupOriginRestriction;
};
export declare const PackageGroupOriginRestrictions: any;
export interface PackageGroupOriginConfiguration {
    restrictions?: {
        [key: string]: PackageGroupOriginRestriction | undefined;
    };
}
export declare const PackageGroupOriginConfiguration: S.Schema<PackageGroupOriginConfiguration>;
export interface PackageGroupDescription {
    arn?: string;
    pattern?: string;
    domainName?: string;
    domainOwner?: string;
    createdTime?: Date;
    contactInfo?: string;
    description?: string;
    originConfiguration?: PackageGroupOriginConfiguration;
    parent?: PackageGroupReference;
}
export declare const PackageGroupDescription: S.Schema<PackageGroupDescription>;
export interface CreatePackageGroupResult {
    packageGroup?: PackageGroupDescription;
}
export declare const CreatePackageGroupResult: S.Schema<CreatePackageGroupResult>;
export interface UpstreamRepository {
    repositoryName: string;
}
export declare const UpstreamRepository: S.Schema<UpstreamRepository>;
export type UpstreamRepositoryList = UpstreamRepository[];
export declare const UpstreamRepositoryList: any;
export interface CreateRepositoryRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    description?: string;
    upstreams?: UpstreamRepository[];
    tags?: Tag[];
}
export declare const CreateRepositoryRequest: S.Schema<CreateRepositoryRequest>;
export interface CreateRepositoryResult {
    repository?: RepositoryDescription;
}
export declare const CreateRepositoryResult: S.Schema<CreateRepositoryResult>;
export interface DeleteDomainRequest {
    domain: string;
    domainOwner?: string;
}
export declare const DeleteDomainRequest: S.Schema<DeleteDomainRequest>;
export interface DeleteDomainResult {
    domain?: DomainDescription;
}
export declare const DeleteDomainResult: S.Schema<DeleteDomainResult>;
export type PolicyRevision = string;
export interface DeleteDomainPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string;
    policyRevision?: string;
}
export declare const DeleteDomainPermissionsPolicyRequest: S.Schema<DeleteDomainPermissionsPolicyRequest>;
export type PolicyDocument = string;
export interface ResourcePolicy {
    resourceArn?: string;
    revision?: string;
    document?: string;
}
export declare const ResourcePolicy: S.Schema<ResourcePolicy>;
export interface DeleteDomainPermissionsPolicyResult {
    policy?: ResourcePolicy;
}
export declare const DeleteDomainPermissionsPolicyResult: S.Schema<DeleteDomainPermissionsPolicyResult>;
export interface DeletePackageRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
}
export declare const DeletePackageRequest: S.Schema<DeletePackageRequest>;
export type AllowPublish = "ALLOW" | "BLOCK" | (string & {});
export declare const AllowPublish: any;
export type AllowUpstream = "ALLOW" | "BLOCK" | (string & {});
export declare const AllowUpstream: any;
export interface PackageOriginRestrictions {
    publish: AllowPublish;
    upstream: AllowUpstream;
}
export declare const PackageOriginRestrictions: S.Schema<PackageOriginRestrictions>;
export interface PackageOriginConfiguration {
    restrictions?: PackageOriginRestrictions;
}
export declare const PackageOriginConfiguration: S.Schema<PackageOriginConfiguration>;
export interface PackageSummary {
    format?: PackageFormat;
    namespace?: string;
    package?: string;
    originConfiguration?: PackageOriginConfiguration;
}
export declare const PackageSummary: S.Schema<PackageSummary>;
export interface DeletePackageResult {
    deletedPackage?: PackageSummary;
}
export declare const DeletePackageResult: S.Schema<DeletePackageResult>;
export interface DeletePackageGroupRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
}
export declare const DeletePackageGroupRequest: S.Schema<DeletePackageGroupRequest>;
export interface DeletePackageGroupResult {
    packageGroup?: PackageGroupDescription;
}
export declare const DeletePackageGroupResult: S.Schema<DeletePackageGroupResult>;
export interface DeletePackageVersionsRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    versions: string[];
    expectedStatus?: PackageVersionStatus;
}
export declare const DeletePackageVersionsRequest: S.Schema<DeletePackageVersionsRequest>;
export interface DeletePackageVersionsResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    };
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    };
}
export declare const DeletePackageVersionsResult: S.Schema<DeletePackageVersionsResult>;
export interface DeleteRepositoryRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
}
export declare const DeleteRepositoryRequest: S.Schema<DeleteRepositoryRequest>;
export interface DeleteRepositoryResult {
    repository?: RepositoryDescription;
}
export declare const DeleteRepositoryResult: S.Schema<DeleteRepositoryResult>;
export interface DeleteRepositoryPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    policyRevision?: string;
}
export declare const DeleteRepositoryPermissionsPolicyRequest: S.Schema<DeleteRepositoryPermissionsPolicyRequest>;
export interface DeleteRepositoryPermissionsPolicyResult {
    policy?: ResourcePolicy;
}
export declare const DeleteRepositoryPermissionsPolicyResult: S.Schema<DeleteRepositoryPermissionsPolicyResult>;
export interface DescribeDomainRequest {
    domain: string;
    domainOwner?: string;
}
export declare const DescribeDomainRequest: S.Schema<DescribeDomainRequest>;
export interface DescribeDomainResult {
    domain?: DomainDescription;
}
export declare const DescribeDomainResult: S.Schema<DescribeDomainResult>;
export interface DescribePackageRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
}
export declare const DescribePackageRequest: S.Schema<DescribePackageRequest>;
export interface PackageDescription {
    format?: PackageFormat;
    namespace?: string;
    name?: string;
    originConfiguration?: PackageOriginConfiguration;
}
export declare const PackageDescription: S.Schema<PackageDescription>;
export interface DescribePackageResult {
    package: PackageDescription;
}
export declare const DescribePackageResult: S.Schema<DescribePackageResult>;
export interface DescribePackageGroupRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
}
export declare const DescribePackageGroupRequest: S.Schema<DescribePackageGroupRequest>;
export interface DescribePackageGroupResult {
    packageGroup?: PackageGroupDescription;
}
export declare const DescribePackageGroupResult: S.Schema<DescribePackageGroupResult>;
export interface DescribePackageVersionRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    packageVersion: string;
}
export declare const DescribePackageVersionRequest: S.Schema<DescribePackageVersionRequest>;
export type String255 = string;
export interface LicenseInfo {
    name?: string;
    url?: string;
}
export declare const LicenseInfo: S.Schema<LicenseInfo>;
export type LicenseInfoList = LicenseInfo[];
export declare const LicenseInfoList: any;
export interface DomainEntryPoint {
    repositoryName?: string;
    externalConnectionName?: string;
}
export declare const DomainEntryPoint: S.Schema<DomainEntryPoint>;
export type PackageVersionOriginType = "INTERNAL" | "EXTERNAL" | "UNKNOWN" | (string & {});
export declare const PackageVersionOriginType: any;
export interface PackageVersionOrigin {
    domainEntryPoint?: DomainEntryPoint;
    originType?: PackageVersionOriginType;
}
export declare const PackageVersionOrigin: S.Schema<PackageVersionOrigin>;
export interface PackageVersionDescription {
    format?: PackageFormat;
    namespace?: string;
    packageName?: string;
    displayName?: string;
    version?: string;
    summary?: string;
    homePage?: string;
    sourceCodeRepository?: string;
    publishedTime?: Date;
    licenses?: LicenseInfo[];
    revision?: string;
    status?: PackageVersionStatus;
    origin?: PackageVersionOrigin;
}
export declare const PackageVersionDescription: S.Schema<PackageVersionDescription>;
export interface DescribePackageVersionResult {
    packageVersion: PackageVersionDescription;
}
export declare const DescribePackageVersionResult: S.Schema<DescribePackageVersionResult>;
export interface DescribeRepositoryRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
}
export declare const DescribeRepositoryRequest: S.Schema<DescribeRepositoryRequest>;
export interface DescribeRepositoryResult {
    repository?: RepositoryDescription;
}
export declare const DescribeRepositoryResult: S.Schema<DescribeRepositoryResult>;
export interface DisassociateExternalConnectionRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    externalConnection: string;
}
export declare const DisassociateExternalConnectionRequest: S.Schema<DisassociateExternalConnectionRequest>;
export interface DisassociateExternalConnectionResult {
    repository?: RepositoryDescription;
}
export declare const DisassociateExternalConnectionResult: S.Schema<DisassociateExternalConnectionResult>;
export interface DisposePackageVersionsRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    versions: string[];
    versionRevisions?: {
        [key: string]: string | undefined;
    };
    expectedStatus?: PackageVersionStatus;
}
export declare const DisposePackageVersionsRequest: S.Schema<DisposePackageVersionsRequest>;
export interface DisposePackageVersionsResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    };
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    };
}
export declare const DisposePackageVersionsResult: S.Schema<DisposePackageVersionsResult>;
export interface GetAssociatedPackageGroupRequest {
    domain: string;
    domainOwner?: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
}
export declare const GetAssociatedPackageGroupRequest: S.Schema<GetAssociatedPackageGroupRequest>;
export type PackageGroupAssociationType = "STRONG" | "WEAK" | (string & {});
export declare const PackageGroupAssociationType: any;
export interface GetAssociatedPackageGroupResult {
    packageGroup?: PackageGroupDescription;
    associationType?: PackageGroupAssociationType;
}
export declare const GetAssociatedPackageGroupResult: S.Schema<GetAssociatedPackageGroupResult>;
export type AuthorizationTokenDurationSeconds = number;
export interface GetAuthorizationTokenRequest {
    domain: string;
    domainOwner?: string;
    durationSeconds?: number;
}
export declare const GetAuthorizationTokenRequest: S.Schema<GetAuthorizationTokenRequest>;
export interface GetAuthorizationTokenResult {
    authorizationToken?: string | redacted.Redacted<string>;
    expiration?: Date;
}
export declare const GetAuthorizationTokenResult: S.Schema<GetAuthorizationTokenResult>;
export interface GetDomainPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string;
}
export declare const GetDomainPermissionsPolicyRequest: S.Schema<GetDomainPermissionsPolicyRequest>;
export interface GetDomainPermissionsPolicyResult {
    policy?: ResourcePolicy;
}
export declare const GetDomainPermissionsPolicyResult: S.Schema<GetDomainPermissionsPolicyResult>;
export type AssetName = string;
export interface GetPackageVersionAssetRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    packageVersion: string;
    asset: string;
    packageVersionRevision?: string;
}
export declare const GetPackageVersionAssetRequest: S.Schema<GetPackageVersionAssetRequest>;
export interface GetPackageVersionAssetResult {
    asset?: T.StreamingOutputBody;
    assetName?: string;
    packageVersion?: string;
    packageVersionRevision?: string;
}
export declare const GetPackageVersionAssetResult: S.Schema<GetPackageVersionAssetResult>;
export interface GetPackageVersionReadmeRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    packageVersion: string;
}
export declare const GetPackageVersionReadmeRequest: S.Schema<GetPackageVersionReadmeRequest>;
export interface GetPackageVersionReadmeResult {
    format?: PackageFormat;
    namespace?: string;
    package?: string;
    version?: string;
    versionRevision?: string;
    readme?: string;
}
export declare const GetPackageVersionReadmeResult: S.Schema<GetPackageVersionReadmeResult>;
export type EndpointType = "dualstack" | "ipv4" | (string & {});
export declare const EndpointType: any;
export interface GetRepositoryEndpointRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    endpointType?: EndpointType;
}
export declare const GetRepositoryEndpointRequest: S.Schema<GetRepositoryEndpointRequest>;
export interface GetRepositoryEndpointResult {
    repositoryEndpoint?: string;
}
export declare const GetRepositoryEndpointResult: S.Schema<GetRepositoryEndpointResult>;
export interface GetRepositoryPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
}
export declare const GetRepositoryPermissionsPolicyRequest: S.Schema<GetRepositoryPermissionsPolicyRequest>;
export interface GetRepositoryPermissionsPolicyResult {
    policy?: ResourcePolicy;
}
export declare const GetRepositoryPermissionsPolicyResult: S.Schema<GetRepositoryPermissionsPolicyResult>;
export type ListAllowedRepositoriesForGroupMaxResults = number;
export type PaginationToken = string;
export interface ListAllowedRepositoriesForGroupRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
    originRestrictionType: PackageGroupOriginRestrictionType;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAllowedRepositoriesForGroupRequest: S.Schema<ListAllowedRepositoriesForGroupRequest>;
export type RepositoryNameList = string[];
export declare const RepositoryNameList: any;
export interface ListAllowedRepositoriesForGroupResult {
    allowedRepositories?: string[];
    nextToken?: string;
}
export declare const ListAllowedRepositoriesForGroupResult: S.Schema<ListAllowedRepositoriesForGroupResult>;
export type ListPackagesMaxResults = number;
export interface ListAssociatedPackagesRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
    maxResults?: number;
    nextToken?: string;
    preview?: boolean;
}
export declare const ListAssociatedPackagesRequest: S.Schema<ListAssociatedPackagesRequest>;
export interface AssociatedPackage {
    format?: PackageFormat;
    namespace?: string;
    package?: string;
    associationType?: PackageGroupAssociationType;
}
export declare const AssociatedPackage: S.Schema<AssociatedPackage>;
export type AssociatedPackageList = AssociatedPackage[];
export declare const AssociatedPackageList: any;
export interface ListAssociatedPackagesResult {
    packages?: AssociatedPackage[];
    nextToken?: string;
}
export declare const ListAssociatedPackagesResult: S.Schema<ListAssociatedPackagesResult>;
export type ListDomainsMaxResults = number;
export interface ListDomainsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDomainsRequest: S.Schema<ListDomainsRequest>;
export interface DomainSummary {
    name?: string;
    owner?: string;
    arn?: string;
    status?: DomainStatus;
    createdTime?: Date;
    encryptionKey?: string;
}
export declare const DomainSummary: S.Schema<DomainSummary>;
export type DomainSummaryList = DomainSummary[];
export declare const DomainSummaryList: any;
export interface ListDomainsResult {
    domains?: DomainSummary[];
    nextToken?: string;
}
export declare const ListDomainsResult: S.Schema<ListDomainsResult>;
export type ListPackageGroupsMaxResults = number;
export type PackageGroupPatternPrefix = string;
export interface ListPackageGroupsRequest {
    domain: string;
    domainOwner?: string;
    maxResults?: number;
    nextToken?: string;
    prefix?: string;
}
export declare const ListPackageGroupsRequest: S.Schema<ListPackageGroupsRequest>;
export interface PackageGroupSummary {
    arn?: string;
    pattern?: string;
    domainName?: string;
    domainOwner?: string;
    createdTime?: Date;
    contactInfo?: string;
    description?: string;
    originConfiguration?: PackageGroupOriginConfiguration;
    parent?: PackageGroupReference;
}
export declare const PackageGroupSummary: S.Schema<PackageGroupSummary>;
export type PackageGroupSummaryList = PackageGroupSummary[];
export declare const PackageGroupSummaryList: any;
export interface ListPackageGroupsResult {
    packageGroups?: PackageGroupSummary[];
    nextToken?: string;
}
export declare const ListPackageGroupsResult: S.Schema<ListPackageGroupsResult>;
export interface ListPackagesRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format?: PackageFormat;
    namespace?: string;
    packagePrefix?: string;
    maxResults?: number;
    nextToken?: string;
    publish?: AllowPublish;
    upstream?: AllowUpstream;
}
export declare const ListPackagesRequest: S.Schema<ListPackagesRequest>;
export type PackageSummaryList = PackageSummary[];
export declare const PackageSummaryList: any;
export interface ListPackagesResult {
    packages?: PackageSummary[];
    nextToken?: string;
}
export declare const ListPackagesResult: S.Schema<ListPackagesResult>;
export type ListPackageVersionAssetsMaxResults = number;
export interface ListPackageVersionAssetsRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    packageVersion: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPackageVersionAssetsRequest: S.Schema<ListPackageVersionAssetsRequest>;
export type HashAlgorithm = "MD5" | "SHA-1" | "SHA-256" | "SHA-512" | (string & {});
export declare const HashAlgorithm: any;
export type HashValue = string;
export type AssetHashes = {
    [key in HashAlgorithm]?: string;
};
export declare const AssetHashes: any;
export interface AssetSummary {
    name: string;
    size?: number;
    hashes?: {
        [key: string]: string | undefined;
    };
}
export declare const AssetSummary: S.Schema<AssetSummary>;
export type AssetSummaryList = AssetSummary[];
export declare const AssetSummaryList: any;
export interface ListPackageVersionAssetsResult {
    format?: PackageFormat;
    namespace?: string;
    package?: string;
    version?: string;
    versionRevision?: string;
    nextToken?: string;
    assets?: AssetSummary[];
}
export declare const ListPackageVersionAssetsResult: S.Schema<ListPackageVersionAssetsResult>;
export interface ListPackageVersionDependenciesRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    packageVersion: string;
    nextToken?: string;
}
export declare const ListPackageVersionDependenciesRequest: S.Schema<ListPackageVersionDependenciesRequest>;
export interface PackageDependency {
    namespace?: string;
    package?: string;
    dependencyType?: string;
    versionRequirement?: string;
}
export declare const PackageDependency: S.Schema<PackageDependency>;
export type PackageDependencyList = PackageDependency[];
export declare const PackageDependencyList: any;
export interface ListPackageVersionDependenciesResult {
    format?: PackageFormat;
    namespace?: string;
    package?: string;
    version?: string;
    versionRevision?: string;
    nextToken?: string;
    dependencies?: PackageDependency[];
}
export declare const ListPackageVersionDependenciesResult: S.Schema<ListPackageVersionDependenciesResult>;
export type PackageVersionSortType = "PUBLISHED_TIME" | (string & {});
export declare const PackageVersionSortType: any;
export type ListPackageVersionsMaxResults = number;
export interface ListPackageVersionsRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    status?: PackageVersionStatus;
    sortBy?: PackageVersionSortType;
    maxResults?: number;
    nextToken?: string;
    originType?: PackageVersionOriginType;
}
export declare const ListPackageVersionsRequest: S.Schema<ListPackageVersionsRequest>;
export interface PackageVersionSummary {
    version: string;
    revision?: string;
    status: PackageVersionStatus;
    origin?: PackageVersionOrigin;
}
export declare const PackageVersionSummary: S.Schema<PackageVersionSummary>;
export type PackageVersionSummaryList = PackageVersionSummary[];
export declare const PackageVersionSummaryList: any;
export interface ListPackageVersionsResult {
    defaultDisplayVersion?: string;
    format?: PackageFormat;
    namespace?: string;
    package?: string;
    versions?: PackageVersionSummary[];
    nextToken?: string;
}
export declare const ListPackageVersionsResult: S.Schema<ListPackageVersionsResult>;
export type ListRepositoriesMaxResults = number;
export interface ListRepositoriesRequest {
    repositoryPrefix?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRepositoriesRequest: S.Schema<ListRepositoriesRequest>;
export interface RepositorySummary {
    name?: string;
    administratorAccount?: string;
    domainName?: string;
    domainOwner?: string;
    arn?: string;
    description?: string;
    createdTime?: Date;
}
export declare const RepositorySummary: S.Schema<RepositorySummary>;
export type RepositorySummaryList = RepositorySummary[];
export declare const RepositorySummaryList: any;
export interface ListRepositoriesResult {
    repositories?: RepositorySummary[];
    nextToken?: string;
}
export declare const ListRepositoriesResult: S.Schema<ListRepositoriesResult>;
export type ListRepositoriesInDomainMaxResults = number;
export interface ListRepositoriesInDomainRequest {
    domain: string;
    domainOwner?: string;
    administratorAccount?: string;
    repositoryPrefix?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRepositoriesInDomainRequest: S.Schema<ListRepositoriesInDomainRequest>;
export interface ListRepositoriesInDomainResult {
    repositories?: RepositorySummary[];
    nextToken?: string;
}
export declare const ListRepositoriesInDomainResult: S.Schema<ListRepositoriesInDomainResult>;
export interface ListSubPackageGroupsRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSubPackageGroupsRequest: S.Schema<ListSubPackageGroupsRequest>;
export interface ListSubPackageGroupsResult {
    packageGroups?: PackageGroupSummary[];
    nextToken?: string;
}
export declare const ListSubPackageGroupsResult: S.Schema<ListSubPackageGroupsResult>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResult {
    tags?: Tag[];
}
export declare const ListTagsForResourceResult: S.Schema<ListTagsForResourceResult>;
export type SHA256 = string;
export interface PublishPackageVersionRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    packageVersion: string;
    assetContent: T.StreamingInputBody;
    assetName: string;
    assetSHA256: string;
    unfinished?: boolean;
}
export declare const PublishPackageVersionRequest: S.Schema<PublishPackageVersionRequest>;
export interface PublishPackageVersionResult {
    format?: PackageFormat;
    namespace?: string;
    package?: string;
    version?: string;
    versionRevision?: string;
    status?: PackageVersionStatus;
    asset?: AssetSummary;
}
export declare const PublishPackageVersionResult: S.Schema<PublishPackageVersionResult>;
export interface PutDomainPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string;
    policyRevision?: string;
    policyDocument: string;
}
export declare const PutDomainPermissionsPolicyRequest: S.Schema<PutDomainPermissionsPolicyRequest>;
export interface PutDomainPermissionsPolicyResult {
    policy?: ResourcePolicy;
}
export declare const PutDomainPermissionsPolicyResult: S.Schema<PutDomainPermissionsPolicyResult>;
export interface PutPackageOriginConfigurationRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    restrictions: PackageOriginRestrictions;
}
export declare const PutPackageOriginConfigurationRequest: S.Schema<PutPackageOriginConfigurationRequest>;
export interface PutPackageOriginConfigurationResult {
    originConfiguration?: PackageOriginConfiguration;
}
export declare const PutPackageOriginConfigurationResult: S.Schema<PutPackageOriginConfigurationResult>;
export interface PutRepositoryPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    policyRevision?: string;
    policyDocument: string;
}
export declare const PutRepositoryPermissionsPolicyRequest: S.Schema<PutRepositoryPermissionsPolicyRequest>;
export interface PutRepositoryPermissionsPolicyResult {
    policy?: ResourcePolicy;
}
export declare const PutRepositoryPermissionsPolicyResult: S.Schema<PutRepositoryPermissionsPolicyResult>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResult {
}
export declare const TagResourceResult: S.Schema<TagResourceResult>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResult {
}
export declare const UntagResourceResult: S.Schema<UntagResourceResult>;
export interface UpdatePackageGroupRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
    contactInfo?: string;
    description?: string;
}
export declare const UpdatePackageGroupRequest: S.Schema<UpdatePackageGroupRequest>;
export interface UpdatePackageGroupResult {
    packageGroup?: PackageGroupDescription;
}
export declare const UpdatePackageGroupResult: S.Schema<UpdatePackageGroupResult>;
export type OriginRestrictions = {
    [key in PackageGroupOriginRestrictionType]?: PackageGroupOriginRestrictionMode;
};
export declare const OriginRestrictions: any;
export interface PackageGroupAllowedRepository {
    repositoryName?: string;
    originRestrictionType?: PackageGroupOriginRestrictionType;
}
export declare const PackageGroupAllowedRepository: S.Schema<PackageGroupAllowedRepository>;
export type PackageGroupAllowedRepositoryList = PackageGroupAllowedRepository[];
export declare const PackageGroupAllowedRepositoryList: any;
export interface UpdatePackageGroupOriginConfigurationRequest {
    domain: string;
    domainOwner?: string;
    packageGroup: string;
    restrictions?: {
        [key: string]: PackageGroupOriginRestrictionMode | undefined;
    };
    addAllowedRepositories?: PackageGroupAllowedRepository[];
    removeAllowedRepositories?: PackageGroupAllowedRepository[];
}
export declare const UpdatePackageGroupOriginConfigurationRequest: S.Schema<UpdatePackageGroupOriginConfigurationRequest>;
export type PackageGroupAllowedRepositoryUpdateType = "ADDED" | "REMOVED" | (string & {});
export declare const PackageGroupAllowedRepositoryUpdateType: any;
export type PackageGroupAllowedRepositoryUpdate = {
    [key in PackageGroupAllowedRepositoryUpdateType]?: string[];
};
export declare const PackageGroupAllowedRepositoryUpdate: any;
export type PackageGroupAllowedRepositoryUpdates = {
    [key in PackageGroupOriginRestrictionType]?: {
        [key: string]: string[] | undefined;
    };
};
export declare const PackageGroupAllowedRepositoryUpdates: any;
export interface UpdatePackageGroupOriginConfigurationResult {
    packageGroup?: PackageGroupDescription;
    allowedRepositoryUpdates?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    };
}
export declare const UpdatePackageGroupOriginConfigurationResult: S.Schema<UpdatePackageGroupOriginConfigurationResult>;
export interface UpdatePackageVersionsStatusRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    format: PackageFormat;
    namespace?: string;
    package: string;
    versions: string[];
    versionRevisions?: {
        [key: string]: string | undefined;
    };
    expectedStatus?: PackageVersionStatus;
    targetStatus: PackageVersionStatus;
}
export declare const UpdatePackageVersionsStatusRequest: S.Schema<UpdatePackageVersionsStatusRequest>;
export interface UpdatePackageVersionsStatusResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    };
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    };
}
export declare const UpdatePackageVersionsStatusResult: S.Schema<UpdatePackageVersionsStatusResult>;
export interface UpdateRepositoryRequest {
    domain: string;
    domainOwner?: string;
    repository: string;
    description?: string;
    upstreams?: UpstreamRepository[];
}
export declare const UpdateRepositoryRequest: S.Schema<UpdateRepositoryRequest>;
export interface UpdateRepositoryResult {
    repository?: RepositoryDescription;
}
export declare const UpdateRepositoryResult: S.Schema<UpdateRepositoryResult>;
export type ResourceType = "domain" | "repository" | "package" | "package-version" | "asset" | (string & {});
export declare const ResourceType: any;
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "CANNOT_PARSE" | "ENCRYPTION_KEY_ERROR" | "FIELD_VALIDATION_FAILED" | "UNKNOWN_OPERATION" | "OTHER" | (string & {});
export declare const ValidationExceptionReason: any;
export type AssociateExternalConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds an existing external connection to a repository. One external connection is allowed
 * per repository.
 *
 * A repository can have one or more upstream repositories, or an external connection.
 */
export declare const associateExternalConnection: API.OperationMethod<AssociateExternalConnectionRequest, AssociateExternalConnectionResult, AssociateExternalConnectionError, Credentials | HttpClient.HttpClient>;
export type CopyPackageVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Copies package versions from one repository to another repository in the same domain.
 *
 * You must specify `versions` or `versionRevisions`. You cannot specify both.
 */
export declare const copyPackageVersions: API.OperationMethod<CopyPackageVersionsRequest, CopyPackageVersionsResult, CopyPackageVersionsError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain. CodeArtifact *domains* make it easier to manage multiple repositories across an
 * organization. You can use a domain to apply permissions across many
 * repositories owned by different Amazon Web Services accounts. An asset is stored only once
 * in a domain, even if it's in multiple repositories.
 *
 * Although you can have multiple domains, we recommend a single production domain that contains all
 * published artifacts so that your development teams can find and share packages. You can use a second
 * pre-production domain to test changes to the production domain configuration.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest, CreateDomainResult, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreatePackageGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a package group. For more information about creating package groups, including example CLI commands, see Create a package group in the *CodeArtifact User Guide*.
 */
export declare const createPackageGroup: API.OperationMethod<CreatePackageGroupRequest, CreatePackageGroupResult, CreatePackageGroupError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a repository.
 */
export declare const createRepository: API.OperationMethod<CreateRepositoryRequest, CreateRepositoryResult, CreateRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a domain. You cannot delete a domain that contains repositories. If you want to delete a domain
 * with repositories, first delete its repositories.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResult, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource policy set on a domain.
 */
export declare const deleteDomainPermissionsPolicy: API.OperationMethod<DeleteDomainPermissionsPolicyRequest, DeleteDomainPermissionsPolicyResult, DeleteDomainPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePackageError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a package and all associated package versions. A deleted package cannot be restored. To delete one or more package versions, use the
 * DeletePackageVersions API.
 */
export declare const deletePackage: API.OperationMethod<DeletePackageRequest, DeletePackageResult, DeletePackageError, Credentials | HttpClient.HttpClient>;
export type DeletePackageGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a package group.
 * Deleting a package group does not delete packages or package versions associated with the package group.
 * When a package group is deleted, the direct child package groups will become children of the package
 * group's direct parent package group. Therefore, if any of the child groups are inheriting any settings
 * from the parent, those settings could change.
 */
export declare const deletePackageGroup: API.OperationMethod<DeletePackageGroupRequest, DeletePackageGroupResult, DeletePackageGroupError, Credentials | HttpClient.HttpClient>;
export type DeletePackageVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes one or more versions of a package. A deleted package version cannot be restored
 * in your repository. If you want to remove a package version from your repository and be able
 * to restore it later, set its status to `Archived`. Archived packages cannot be
 * downloaded from a repository and don't show up with list package APIs (for example,
 * ListPackageVersions), but you can restore them using UpdatePackageVersionsStatus.
 */
export declare const deletePackageVersions: API.OperationMethod<DeletePackageVersionsRequest, DeletePackageVersionsResult, DeletePackageVersionsError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a repository.
 */
export declare const deleteRepository: API.OperationMethod<DeleteRepositoryRequest, DeleteRepositoryResult, DeleteRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource policy that is set on a repository. After a resource policy is deleted, the
 * permissions allowed and denied by the deleted policy are removed. The effect of deleting a resource policy might not be immediate.
 *
 * Use `DeleteRepositoryPermissionsPolicy` with caution. After a policy is deleted, Amazon Web Services users, roles, and accounts lose permissions to perform
 * the repository actions granted by the deleted policy.
 */
export declare const deleteRepositoryPermissionsPolicy: API.OperationMethod<DeleteRepositoryPermissionsPolicyRequest, DeleteRepositoryPermissionsPolicyResult, DeleteRepositoryPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a
 * DomainDescription
 * object that contains information about the requested domain.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainRequest, DescribeDomainResult, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribePackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a
 * PackageDescription
 * object that contains information about the requested package.
 */
export declare const describePackage: API.OperationMethod<DescribePackageRequest, DescribePackageResult, DescribePackageError, Credentials | HttpClient.HttpClient>;
export type DescribePackageGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a PackageGroupDescription object that
 * contains information about the requested package group.
 */
export declare const describePackageGroup: API.OperationMethod<DescribePackageGroupRequest, DescribePackageGroupResult, DescribePackageGroupError, Credentials | HttpClient.HttpClient>;
export type DescribePackageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a
 * PackageVersionDescription
 * object that contains information about the requested package version.
 */
export declare const describePackageVersion: API.OperationMethod<DescribePackageVersionRequest, DescribePackageVersionResult, DescribePackageVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeRepositoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a `RepositoryDescription` object that contains detailed information
 * about the requested repository.
 */
export declare const describeRepository: API.OperationMethod<DescribeRepositoryRequest, DescribeRepositoryResult, DescribeRepositoryError, Credentials | HttpClient.HttpClient>;
export type DisassociateExternalConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes an existing external connection from a repository.
 */
export declare const disassociateExternalConnection: API.OperationMethod<DisassociateExternalConnectionRequest, DisassociateExternalConnectionResult, DisassociateExternalConnectionError, Credentials | HttpClient.HttpClient>;
export type DisposePackageVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the assets in package versions and sets the package versions' status to `Disposed`.
 * A disposed package version cannot be restored in your repository because its assets are deleted.
 *
 * To view all disposed package versions in a repository, use ListPackageVersions and set the
 * status parameter
 * to `Disposed`.
 *
 * To view information about a disposed package version, use DescribePackageVersion.
 */
export declare const disposePackageVersions: API.OperationMethod<DisposePackageVersionsRequest, DisposePackageVersionsResult, DisposePackageVersionsError, Credentials | HttpClient.HttpClient>;
export type GetAssociatedPackageGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the most closely associated package group to the specified package. This API does not require that the package exist
 * in any repository in the domain. As such, `GetAssociatedPackageGroup` can be used to see which package group's origin configuration
 * applies to a package before that package is in a repository. This can be helpful to check if public packages are blocked without ingesting them.
 *
 * For information package group association and matching, see
 * Package group
 * definition syntax and matching behavior in the *CodeArtifact User Guide*.
 */
export declare const getAssociatedPackageGroup: API.OperationMethod<GetAssociatedPackageGroupRequest, GetAssociatedPackageGroupResult, GetAssociatedPackageGroupError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizationTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a temporary authorization token for accessing repositories in the domain.
 * This API requires the `codeartifact:GetAuthorizationToken` and `sts:GetServiceBearerToken` permissions.
 * For more information about authorization tokens, see
 * CodeArtifact authentication and tokens.
 *
 * CodeArtifact authorization tokens are valid for a period of 12 hours when created with the `login` command.
 * You can call `login` periodically to refresh the token. When
 * you create an authorization token with the `GetAuthorizationToken` API, you can set a custom authorization period,
 * up to a maximum of 12 hours, with the `durationSeconds` parameter.
 *
 * The authorization period begins after `login`
 * or `GetAuthorizationToken` is called. If `login` or `GetAuthorizationToken` is called while
 * assuming a role, the token lifetime is independent of the maximum session duration
 * of the role. For example, if you call `sts assume-role` and specify a session duration of 15 minutes, then
 * generate a CodeArtifact authorization token, the token will be valid for the full authorization period
 * even though this is longer than the 15-minute session duration.
 *
 * See
 * Using IAM Roles
 * for more information on controlling session duration.
 */
export declare const getAuthorizationToken: API.OperationMethod<GetAuthorizationTokenRequest, GetAuthorizationTokenResult, GetAuthorizationTokenError, Credentials | HttpClient.HttpClient>;
export type GetDomainPermissionsPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource policy attached to the specified domain.
 *
 * The policy is a resource-based policy, not an identity-based policy. For more information, see
 * Identity-based policies
 * and resource-based policies in the *IAM User Guide*.
 */
export declare const getDomainPermissionsPolicy: API.OperationMethod<GetDomainPermissionsPolicyRequest, GetDomainPermissionsPolicyResult, GetDomainPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an asset (or file) that is in a package. For example, for a Maven package version, use
 * `GetPackageVersionAsset` to download a `JAR` file, a `POM` file,
 * or any other assets in the package version.
 */
export declare const getPackageVersionAsset: API.OperationMethod<GetPackageVersionAssetRequest, GetPackageVersionAssetResult, GetPackageVersionAssetError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionReadmeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the readme file or descriptive text for a package version.
 *
 * The returned text might contain formatting. For example, it might contain formatting for Markdown or reStructuredText.
 */
export declare const getPackageVersionReadme: API.OperationMethod<GetPackageVersionReadmeRequest, GetPackageVersionReadmeResult, GetPackageVersionReadmeError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the endpoint of a repository for a specific package format. A repository has one endpoint for each
 * package format:
 *
 * - `cargo`
 *
 * - `generic`
 *
 * - `maven`
 *
 * - `npm`
 *
 * - `nuget`
 *
 * - `pypi`
 *
 * - `ruby`
 *
 * - `swift`
 */
export declare const getRepositoryEndpoint: API.OperationMethod<GetRepositoryEndpointRequest, GetRepositoryEndpointResult, GetRepositoryEndpointError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryPermissionsPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource policy that is set on a repository.
 */
export declare const getRepositoryPermissionsPolicy: API.OperationMethod<GetRepositoryPermissionsPolicyRequest, GetRepositoryPermissionsPolicyResult, GetRepositoryPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAllowedRepositoriesForGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the repositories in the added repositories list of the specified restriction type for a package group. For more information about restriction types
 * and added repository lists, see Package group origin controls in the *CodeArtifact User Guide*.
 */
export declare const listAllowedRepositoriesForGroup: API.PaginatedOperationMethod<ListAllowedRepositoriesForGroupRequest, ListAllowedRepositoriesForGroupResult, ListAllowedRepositoriesForGroupError, Credentials | HttpClient.HttpClient, RepositoryName>;
export type ListAssociatedPackagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of packages associated with the requested package group. For information package group association and matching, see
 * Package group
 * definition syntax and matching behavior in the *CodeArtifact User Guide*.
 */
export declare const listAssociatedPackages: API.PaginatedOperationMethod<ListAssociatedPackagesRequest, ListAssociatedPackagesResult, ListAssociatedPackagesError, Credentials | HttpClient.HttpClient, AssociatedPackage>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of DomainSummary objects for all domains owned by the Amazon Web Services account that makes
 * this call. Each returned `DomainSummary` object contains information about a
 * domain.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResult, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListPackageGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of package groups in the requested domain.
 */
export declare const listPackageGroups: API.PaginatedOperationMethod<ListPackageGroupsRequest, ListPackageGroupsResult, ListPackageGroupsError, Credentials | HttpClient.HttpClient, PackageGroupSummary>;
export type ListPackagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * PackageSummary
 * objects for packages in a repository that match the request parameters.
 */
export declare const listPackages: API.PaginatedOperationMethod<ListPackagesRequest, ListPackagesResult, ListPackagesError, Credentials | HttpClient.HttpClient, PackageSummary>;
export type ListPackageVersionAssetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * AssetSummary
 * objects for assets in a package version.
 */
export declare const listPackageVersionAssets: API.PaginatedOperationMethod<ListPackageVersionAssetsRequest, ListPackageVersionAssetsResult, ListPackageVersionAssetsError, Credentials | HttpClient.HttpClient, AssetSummary>;
export type ListPackageVersionDependenciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the direct dependencies for a package version. The dependencies are returned as
 * PackageDependency
 * objects. CodeArtifact extracts the dependencies for a package version from the metadata file for the package
 * format (for example, the `package.json` file for npm packages and the `pom.xml` file
 * for Maven). Any package version dependencies that are not listed in the configuration file are not returned.
 */
export declare const listPackageVersionDependencies: API.OperationMethod<ListPackageVersionDependenciesRequest, ListPackageVersionDependenciesResult, ListPackageVersionDependenciesError, Credentials | HttpClient.HttpClient>;
export type ListPackageVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * PackageVersionSummary
 * objects for package versions in a repository that match the request parameters. Package versions of all statuses will be returned by default when calling `list-package-versions` with no `--status` parameter.
 */
export declare const listPackageVersions: API.PaginatedOperationMethod<ListPackageVersionsRequest, ListPackageVersionsResult, ListPackageVersionsError, Credentials | HttpClient.HttpClient, PackageVersionSummary>;
export type ListRepositoriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * RepositorySummary
 * objects. Each `RepositorySummary` contains information about a repository in the specified Amazon Web Services account and that matches the input
 * parameters.
 */
export declare const listRepositories: API.PaginatedOperationMethod<ListRepositoriesRequest, ListRepositoriesResult, ListRepositoriesError, Credentials | HttpClient.HttpClient, RepositorySummary>;
export type ListRepositoriesInDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * RepositorySummary
 * objects. Each `RepositorySummary` contains information about a repository in the specified domain and that matches the input
 * parameters.
 */
export declare const listRepositoriesInDomain: API.PaginatedOperationMethod<ListRepositoriesInDomainRequest, ListRepositoriesInDomainResult, ListRepositoriesInDomainError, Credentials | HttpClient.HttpClient, RepositorySummary>;
export type ListSubPackageGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of direct children of the specified package group.
 *
 * For information package group hierarchy, see
 * Package group
 * definition syntax and matching behavior in the *CodeArtifact User Guide*.
 */
export declare const listSubPackageGroups: API.PaginatedOperationMethod<ListSubPackageGroupsRequest, ListSubPackageGroupsResult, ListSubPackageGroupsError, Credentials | HttpClient.HttpClient, PackageGroupSummary>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about Amazon Web Services tags for a specified Amazon Resource Name (ARN) in CodeArtifact.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PublishPackageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new package version containing one or more assets (or files).
 *
 * The `unfinished` flag can be used to keep the package version in the
 * `Unfinished` state until all of its assets have been uploaded (see Package version status in the *CodeArtifact user guide*). To set
 * the package version’s status to `Published`, omit the `unfinished` flag
 * when uploading the final asset, or set the status using UpdatePackageVersionStatus. Once a package version’s status is set to
 * `Published`, it cannot change back to `Unfinished`.
 *
 * Only generic packages can be published using this API. For more information, see Using generic
 * packages in the *CodeArtifact User Guide*.
 */
export declare const publishPackageVersion: API.OperationMethod<PublishPackageVersionRequest, PublishPackageVersionResult, PublishPackageVersionError, Credentials | HttpClient.HttpClient>;
export type PutDomainPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets a resource policy on a domain that specifies permissions to access it.
 *
 * When you call `PutDomainPermissionsPolicy`, the resource policy on the domain is ignored when evaluting permissions.
 * This ensures that the owner of a domain cannot lock themselves out of the domain, which would prevent them from being
 * able to update the resource policy.
 */
export declare const putDomainPermissionsPolicy: API.OperationMethod<PutDomainPermissionsPolicyRequest, PutDomainPermissionsPolicyResult, PutDomainPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type PutPackageOriginConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the package origin configuration for a package.
 *
 * The package origin configuration determines how new versions of a package can be added to a repository. You can allow or block direct
 * publishing of new package versions, or ingestion and retaining of new package versions from an external connection or upstream source.
 * For more information about package origin controls and configuration, see Editing package origin controls in the *CodeArtifact User Guide*.
 *
 * `PutPackageOriginConfiguration` can be called on a package that doesn't yet exist in the repository. When called
 * on a package that does not exist, a package is created in the repository with no versions and the requested restrictions are set on the package.
 * This can be used to preemptively block ingesting or retaining any versions from external connections or upstream repositories, or to block
 * publishing any versions of the package into the repository before connecting any package managers or publishers to the repository.
 */
export declare const putPackageOriginConfiguration: API.OperationMethod<PutPackageOriginConfigurationRequest, PutPackageOriginConfigurationResult, PutPackageOriginConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutRepositoryPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the resource policy on a repository that specifies permissions to access it.
 *
 * When you call `PutRepositoryPermissionsPolicy`, the resource policy on the repository is ignored when evaluting permissions.
 * This ensures that the owner of a repository cannot lock themselves out of the repository, which would prevent them from being
 * able to update the resource policy.
 */
export declare const putRepositoryPermissionsPolicy: API.OperationMethod<PutRepositoryPermissionsPolicyRequest, PutRepositoryPermissionsPolicyResult, PutRepositoryPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a resource in CodeArtifact.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource in CodeArtifact.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a package group. This API cannot be used to update a package group's origin configuration or pattern. To update a
 * package group's origin configuration, use UpdatePackageGroupOriginConfiguration.
 */
export declare const updatePackageGroup: API.OperationMethod<UpdatePackageGroupRequest, UpdatePackageGroupResult, UpdatePackageGroupError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageGroupOriginConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the package origin configuration for a package group.
 *
 * The package origin configuration determines how new versions of a package can be added to a repository. You can allow or block direct
 * publishing of new package versions, or ingestion and retaining of new package versions from an external connection or upstream source.
 * For more information about package group origin controls and configuration, see
 * Package group origin controls
 * in the *CodeArtifact User Guide*.
 */
export declare const updatePackageGroupOriginConfiguration: API.OperationMethod<UpdatePackageGroupOriginConfigurationRequest, UpdatePackageGroupOriginConfigurationResult, UpdatePackageGroupOriginConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageVersionsStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of one or more versions of a package. Using `UpdatePackageVersionsStatus`,
 * you can update the status of package versions to `Archived`, `Published`, or `Unlisted`.
 * To set the status of a package version to `Disposed`, use
 * DisposePackageVersions.
 */
export declare const updatePackageVersionsStatus: API.OperationMethod<UpdatePackageVersionsStatusRequest, UpdatePackageVersionsStatusResult, UpdatePackageVersionsStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the properties of a repository.
 */
export declare const updateRepository: API.OperationMethod<UpdateRepositoryRequest, UpdateRepositoryResult, UpdateRepositoryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codeartifact.d.ts.map