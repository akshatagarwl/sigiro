import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServiceException_base: S.Class<InternalServiceException, S.TaggedStruct<"InternalServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type InstanceId = string;
export type ContactId = string;
export type MaxResults = number;
export type NextToken = string;
export interface ListRealtimeContactAnalysisSegmentsRequest {
    InstanceId?: string;
    ContactId?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRealtimeContactAnalysisSegmentsRequest: S.Schema<ListRealtimeContactAnalysisSegmentsRequest>;
export type TranscriptId = string;
export type ParticipantId = string;
export type ParticipantRole = string;
export type TranscriptContent = string;
export type OffsetMillis = number;
export type SentimentValue = "POSITIVE" | "NEUTRAL" | "NEGATIVE" | (string & {});
export declare const SentimentValue: any;
export type CharacterOffset = number;
export interface CharacterOffsets {
    BeginOffsetChar?: number;
    EndOffsetChar?: number;
}
export declare const CharacterOffsets: S.Schema<CharacterOffsets>;
export interface IssueDetected {
    CharacterOffsets?: CharacterOffsets;
}
export declare const IssueDetected: S.Schema<IssueDetected>;
export type IssuesDetected = IssueDetected[];
export declare const IssuesDetected: any;
export interface Transcript {
    Id?: string;
    ParticipantId?: string;
    ParticipantRole?: string;
    Content?: string;
    BeginOffsetMillis?: number;
    EndOffsetMillis?: number;
    Sentiment?: SentimentValue;
    IssuesDetected?: IssueDetected[];
}
export declare const Transcript: S.Schema<Transcript>;
export type CategoryName = string;
export type MatchedCategories = string[];
export declare const MatchedCategories: any;
export interface PointOfInterest {
    BeginOffsetMillis?: number;
    EndOffsetMillis?: number;
}
export declare const PointOfInterest: S.Schema<PointOfInterest>;
export type PointsOfInterest = PointOfInterest[];
export declare const PointsOfInterest: any;
export interface CategoryDetails {
    PointsOfInterest?: PointOfInterest[];
}
export declare const CategoryDetails: S.Schema<CategoryDetails>;
export type MatchedDetails = {
    [key: string]: CategoryDetails | undefined;
};
export declare const MatchedDetails: any;
export interface Categories {
    MatchedCategories?: string[];
    MatchedDetails?: {
        [key: string]: CategoryDetails | undefined;
    };
}
export declare const Categories: S.Schema<Categories>;
export type PostContactSummaryContent = string;
export type PostContactSummaryStatus = "FAILED" | "COMPLETED" | (string & {});
export declare const PostContactSummaryStatus: any;
export type PostContactSummaryFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INVALID_ANALYSIS_CONFIGURATION" | "INTERNAL_ERROR" | (string & {});
export declare const PostContactSummaryFailureCode: any;
export interface PostContactSummary {
    Content?: string;
    Status?: PostContactSummaryStatus;
    FailureCode?: PostContactSummaryFailureCode;
}
export declare const PostContactSummary: S.Schema<PostContactSummary>;
export type ExtractionDefinitionId = string;
export type ExtractionDefinitionName = string;
export type ExtractionDefinitionDisplayLabel = string;
export type ExtractedInformationContent = string;
export interface ExtractedInformationValue {
    Content?: string;
    PointsOfInterest?: PointOfInterest[];
}
export declare const ExtractedInformationValue: S.Schema<ExtractedInformationValue>;
export type ExtractedInformationValues = ExtractedInformationValue[];
export declare const ExtractedInformationValues: any;
export type ExtractedInformationFailureCode = "QUOTA_EXCEEDED" | "INSUFFICIENT_CONVERSATION_CONTENT" | "FAILED_SAFETY_GUIDELINES" | "INTERNAL_ERROR" | "MAX_PACKAGE_FEATURE_ONLY" | (string & {});
export declare const ExtractedInformationFailureCode: any;
export interface ExtractedInformation {
    ExtractionDefinitionId?: string;
    ExtractionDefinitionName?: string;
    ExtractionDefinitionDisplayLabel?: string;
    ExtractedValues?: ExtractedInformationValue[];
    FailureCode?: ExtractedInformationFailureCode;
}
export declare const ExtractedInformation: S.Schema<ExtractedInformation>;
export interface RealtimeContactAnalysisSegment {
    Transcript?: Transcript;
    Categories?: Categories;
    PostContactSummary?: PostContactSummary;
    ExtractedInformation?: ExtractedInformation;
}
export declare const RealtimeContactAnalysisSegment: S.Schema<RealtimeContactAnalysisSegment>;
export type RealtimeContactAnalysisSegments = RealtimeContactAnalysisSegment[];
export declare const RealtimeContactAnalysisSegments: any;
export interface ListRealtimeContactAnalysisSegmentsResponse {
    Segments: (RealtimeContactAnalysisSegment & {
        Transcript: Transcript & {
            Id: TranscriptId;
            ParticipantId: ParticipantId;
            ParticipantRole: ParticipantRole;
            Content: TranscriptContent;
            BeginOffsetMillis: OffsetMillis;
            EndOffsetMillis: OffsetMillis;
            IssuesDetected: (IssueDetected & {
                CharacterOffsets: CharacterOffsets & {
                    BeginOffsetChar: CharacterOffset;
                    EndOffsetChar: CharacterOffset;
                };
            })[];
        };
        Categories: Categories & {
            MatchedCategories: MatchedCategories;
            MatchedDetails: {
                [key: string]: (CategoryDetails & {
                    PointsOfInterest: (PointOfInterest & {
                        BeginOffsetMillis: OffsetMillis;
                        EndOffsetMillis: OffsetMillis;
                    })[];
                }) | undefined;
            };
        };
        PostContactSummary: PostContactSummary & {
            Status: PostContactSummaryStatus;
        };
        ExtractedInformation: ExtractedInformation & {
            ExtractionDefinitionId: ExtractionDefinitionId;
            ExtractionDefinitionName: ExtractionDefinitionName;
            ExtractedValues: (ExtractedInformationValue & {
                Content: ExtractedInformationContent;
                PointsOfInterest: (PointOfInterest & {
                    BeginOffsetMillis: OffsetMillis;
                    EndOffsetMillis: OffsetMillis;
                })[];
            })[];
        };
    })[];
    NextToken?: string;
}
export declare const ListRealtimeContactAnalysisSegmentsResponse: S.Schema<ListRealtimeContactAnalysisSegmentsResponse>;
export type Message = string;
export type ListRealtimeContactAnalysisSegmentsError = AccessDeniedException | InternalServiceException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a list of analysis segments for a real-time analysis session for
 * voice.
 *
 * Voice data is retained for 24 hours. You must invoke this API during that
 * time.
 */
export declare const listRealtimeContactAnalysisSegments: API.PaginatedOperationMethod<ListRealtimeContactAnalysisSegmentsRequest, ListRealtimeContactAnalysisSegmentsResponse, ListRealtimeContactAnalysisSegmentsError, Credentials | HttpClient.HttpClient, unknown>;
export {};
//# sourceMappingURL=connect-contact-lens.d.ts.map