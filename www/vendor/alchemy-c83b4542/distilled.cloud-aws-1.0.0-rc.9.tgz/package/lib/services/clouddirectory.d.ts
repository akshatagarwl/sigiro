import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BatchWriteException_base: S.Class<BatchWriteException, S.TaggedStruct<"BatchWriteException", {
    readonly Index: any;
    readonly Type: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BatchWriteException extends /*@__PURE__*/ BatchWriteException_base {
}
declare const CannotListParentOfRootException_base: S.Class<CannotListParentOfRootException, S.TaggedStruct<"CannotListParentOfRootException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CannotListParentOfRootException extends /*@__PURE__*/ CannotListParentOfRootException_base {
}
declare const DirectoryAlreadyExistsException_base: S.Class<DirectoryAlreadyExistsException, S.TaggedStruct<"DirectoryAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DirectoryAlreadyExistsException extends /*@__PURE__*/ DirectoryAlreadyExistsException_base {
}
declare const DirectoryDeletedException_base: S.Class<DirectoryDeletedException, S.TaggedStruct<"DirectoryDeletedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DirectoryDeletedException extends /*@__PURE__*/ DirectoryDeletedException_base {
}
declare const DirectoryNotDisabledException_base: S.Class<DirectoryNotDisabledException, S.TaggedStruct<"DirectoryNotDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DirectoryNotDisabledException extends /*@__PURE__*/ DirectoryNotDisabledException_base {
}
declare const DirectoryNotEnabledException_base: S.Class<DirectoryNotEnabledException, S.TaggedStruct<"DirectoryNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DirectoryNotEnabledException extends /*@__PURE__*/ DirectoryNotEnabledException_base {
}
declare const FacetAlreadyExistsException_base: S.Class<FacetAlreadyExistsException, S.TaggedStruct<"FacetAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FacetAlreadyExistsException extends /*@__PURE__*/ FacetAlreadyExistsException_base {
}
declare const FacetInUseException_base: S.Class<FacetInUseException, S.TaggedStruct<"FacetInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FacetInUseException extends /*@__PURE__*/ FacetInUseException_base {
}
declare const FacetNotFoundException_base: S.Class<FacetNotFoundException, S.TaggedStruct<"FacetNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FacetNotFoundException extends /*@__PURE__*/ FacetNotFoundException_base {
}
declare const FacetValidationException_base: S.Class<FacetValidationException, S.TaggedStruct<"FacetValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FacetValidationException extends /*@__PURE__*/ FacetValidationException_base {
}
declare const IncompatibleSchemaException_base: S.Class<IncompatibleSchemaException, S.TaggedStruct<"IncompatibleSchemaException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncompatibleSchemaException extends /*@__PURE__*/ IncompatibleSchemaException_base {
}
declare const IndexedAttributeMissingException_base: S.Class<IndexedAttributeMissingException, S.TaggedStruct<"IndexedAttributeMissingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IndexedAttributeMissingException extends /*@__PURE__*/ IndexedAttributeMissingException_base {
}
declare const InternalServiceException_base: S.Class<InternalServiceException, S.TaggedStruct<"InternalServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidArnException_base: S.Class<InvalidArnException, S.TaggedStruct<"InvalidArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidAttachmentException_base: S.Class<InvalidAttachmentException, S.TaggedStruct<"InvalidAttachmentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAttachmentException extends /*@__PURE__*/ InvalidAttachmentException_base {
}
declare const InvalidFacetUpdateException_base: S.Class<InvalidFacetUpdateException, S.TaggedStruct<"InvalidFacetUpdateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFacetUpdateException extends /*@__PURE__*/ InvalidFacetUpdateException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidRuleException_base: S.Class<InvalidRuleException, S.TaggedStruct<"InvalidRuleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRuleException extends /*@__PURE__*/ InvalidRuleException_base {
}
declare const InvalidSchemaDocException_base: S.Class<InvalidSchemaDocException, S.TaggedStruct<"InvalidSchemaDocException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSchemaDocException extends /*@__PURE__*/ InvalidSchemaDocException_base {
}
declare const InvalidTaggingRequestException_base: S.Class<InvalidTaggingRequestException, S.TaggedStruct<"InvalidTaggingRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTaggingRequestException extends /*@__PURE__*/ InvalidTaggingRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const LinkNameAlreadyInUseException_base: S.Class<LinkNameAlreadyInUseException, S.TaggedStruct<"LinkNameAlreadyInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LinkNameAlreadyInUseException extends /*@__PURE__*/ LinkNameAlreadyInUseException_base {
}
declare const NotIndexException_base: S.Class<NotIndexException, S.TaggedStruct<"NotIndexException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotIndexException extends /*@__PURE__*/ NotIndexException_base {
}
declare const NotNodeException_base: S.Class<NotNodeException, S.TaggedStruct<"NotNodeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotNodeException extends /*@__PURE__*/ NotNodeException_base {
}
declare const NotPolicyException_base: S.Class<NotPolicyException, S.TaggedStruct<"NotPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotPolicyException extends /*@__PURE__*/ NotPolicyException_base {
}
declare const ObjectAlreadyDetachedException_base: S.Class<ObjectAlreadyDetachedException, S.TaggedStruct<"ObjectAlreadyDetachedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectAlreadyDetachedException extends /*@__PURE__*/ ObjectAlreadyDetachedException_base {
}
declare const ObjectNotDetachedException_base: S.Class<ObjectNotDetachedException, S.TaggedStruct<"ObjectNotDetachedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectNotDetachedException extends /*@__PURE__*/ ObjectNotDetachedException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RetryableConflictException_base: S.Class<RetryableConflictException, S.TaggedStruct<"RetryableConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class RetryableConflictException extends /*@__PURE__*/ RetryableConflictException_base {
}
declare const SchemaAlreadyExistsException_base: S.Class<SchemaAlreadyExistsException, S.TaggedStruct<"SchemaAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SchemaAlreadyExistsException extends /*@__PURE__*/ SchemaAlreadyExistsException_base {
}
declare const SchemaAlreadyPublishedException_base: S.Class<SchemaAlreadyPublishedException, S.TaggedStruct<"SchemaAlreadyPublishedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SchemaAlreadyPublishedException extends /*@__PURE__*/ SchemaAlreadyPublishedException_base {
}
declare const StillContainsLinksException_base: S.Class<StillContainsLinksException, S.TaggedStruct<"StillContainsLinksException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StillContainsLinksException extends /*@__PURE__*/ StillContainsLinksException_base {
}
declare const UnsupportedIndexTypeException_base: S.Class<UnsupportedIndexTypeException, S.TaggedStruct<"UnsupportedIndexTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedIndexTypeException extends /*@__PURE__*/ UnsupportedIndexTypeException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type FacetName = string;
export interface SchemaFacet {
    SchemaArn?: string;
    FacetName?: string;
}
export declare const SchemaFacet: S.Schema<SchemaFacet>;
export type AttributeName = string;
export interface AttributeKey {
    SchemaArn: string;
    FacetName: string;
    Name: string;
}
export declare const AttributeKey: S.Schema<AttributeKey>;
export type StringAttributeValue = string;
export type BinaryAttributeValue = Uint8Array;
export type BooleanAttributeValue = boolean;
export type NumberAttributeValue = string;
export type DatetimeAttributeValue = Date;
export type TypedAttributeValue = {
    StringValue: string;
    BinaryValue?: never;
    BooleanValue?: never;
    NumberValue?: never;
    DatetimeValue?: never;
} | {
    StringValue?: never;
    BinaryValue: Uint8Array;
    BooleanValue?: never;
    NumberValue?: never;
    DatetimeValue?: never;
} | {
    StringValue?: never;
    BinaryValue?: never;
    BooleanValue: boolean;
    NumberValue?: never;
    DatetimeValue?: never;
} | {
    StringValue?: never;
    BinaryValue?: never;
    BooleanValue?: never;
    NumberValue: string;
    DatetimeValue?: never;
} | {
    StringValue?: never;
    BinaryValue?: never;
    BooleanValue?: never;
    NumberValue?: never;
    DatetimeValue: Date;
};
export declare const TypedAttributeValue: any;
export interface AttributeKeyAndValue {
    Key: AttributeKey;
    Value: TypedAttributeValue;
}
export declare const AttributeKeyAndValue: S.Schema<AttributeKeyAndValue>;
export type AttributeKeyAndValueList = AttributeKeyAndValue[];
export declare const AttributeKeyAndValueList: any;
export type SelectorObjectReference = string;
export interface ObjectReference {
    Selector?: string;
}
export declare const ObjectReference: S.Schema<ObjectReference>;
export interface AddFacetToObjectRequest {
    DirectoryArn: string;
    SchemaFacet: SchemaFacet;
    ObjectAttributeList?: AttributeKeyAndValue[];
    ObjectReference: ObjectReference;
}
export declare const AddFacetToObjectRequest: S.Schema<AddFacetToObjectRequest>;
export interface AddFacetToObjectResponse {
}
export declare const AddFacetToObjectResponse: S.Schema<AddFacetToObjectResponse>;
export interface ApplySchemaRequest {
    PublishedSchemaArn: string;
    DirectoryArn: string;
}
export declare const ApplySchemaRequest: S.Schema<ApplySchemaRequest>;
export interface ApplySchemaResponse {
    AppliedSchemaArn?: string;
    DirectoryArn?: string;
}
export declare const ApplySchemaResponse: S.Schema<ApplySchemaResponse>;
export type LinkName = string;
export interface AttachObjectRequest {
    DirectoryArn: string;
    ParentReference: ObjectReference;
    ChildReference: ObjectReference;
    LinkName: string;
}
export declare const AttachObjectRequest: S.Schema<AttachObjectRequest>;
export type ObjectIdentifier = string;
export interface AttachObjectResponse {
    AttachedObjectIdentifier?: string;
}
export declare const AttachObjectResponse: S.Schema<AttachObjectResponse>;
export interface AttachPolicyRequest {
    DirectoryArn: string;
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export declare const AttachPolicyRequest: S.Schema<AttachPolicyRequest>;
export interface AttachPolicyResponse {
}
export declare const AttachPolicyResponse: S.Schema<AttachPolicyResponse>;
export interface AttachToIndexRequest {
    DirectoryArn: string;
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export declare const AttachToIndexRequest: S.Schema<AttachToIndexRequest>;
export interface AttachToIndexResponse {
    AttachedObjectIdentifier?: string;
}
export declare const AttachToIndexResponse: S.Schema<AttachToIndexResponse>;
export type TypedLinkName = string;
export interface TypedLinkSchemaAndFacetName {
    SchemaArn: string;
    TypedLinkName: string;
}
export declare const TypedLinkSchemaAndFacetName: S.Schema<TypedLinkSchemaAndFacetName>;
export interface AttributeNameAndValue {
    AttributeName: string;
    Value: TypedAttributeValue;
}
export declare const AttributeNameAndValue: S.Schema<AttributeNameAndValue>;
export type AttributeNameAndValueList = AttributeNameAndValue[];
export declare const AttributeNameAndValueList: any;
export interface AttachTypedLinkRequest {
    DirectoryArn: string;
    SourceObjectReference: ObjectReference;
    TargetObjectReference: ObjectReference;
    TypedLinkFacet: TypedLinkSchemaAndFacetName;
    Attributes: AttributeNameAndValue[];
}
export declare const AttachTypedLinkRequest: S.Schema<AttachTypedLinkRequest>;
export interface TypedLinkSpecifier {
    TypedLinkFacet: TypedLinkSchemaAndFacetName;
    SourceObjectReference: ObjectReference;
    TargetObjectReference: ObjectReference;
    IdentityAttributeValues: AttributeNameAndValue[];
}
export declare const TypedLinkSpecifier: S.Schema<TypedLinkSpecifier>;
export interface AttachTypedLinkResponse {
    TypedLinkSpecifier?: TypedLinkSpecifier;
}
export declare const AttachTypedLinkResponse: S.Schema<AttachTypedLinkResponse>;
export type NextToken = string;
export type NumberResults = number;
export interface BatchListObjectAttributes {
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
    FacetFilter?: SchemaFacet;
}
export declare const BatchListObjectAttributes: S.Schema<BatchListObjectAttributes>;
export interface BatchListObjectChildren {
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListObjectChildren: S.Schema<BatchListObjectChildren>;
export interface BatchListAttachedIndices {
    TargetReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListAttachedIndices: S.Schema<BatchListAttachedIndices>;
export interface BatchListObjectParentPaths {
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListObjectParentPaths: S.Schema<BatchListObjectParentPaths>;
export interface BatchGetObjectInformation {
    ObjectReference: ObjectReference;
}
export declare const BatchGetObjectInformation: S.Schema<BatchGetObjectInformation>;
export type AttributeNameList = string[];
export declare const AttributeNameList: any;
export interface BatchGetObjectAttributes {
    ObjectReference: ObjectReference;
    SchemaFacet: SchemaFacet;
    AttributeNames: string[];
}
export declare const BatchGetObjectAttributes: S.Schema<BatchGetObjectAttributes>;
export interface BatchListObjectParents {
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListObjectParents: S.Schema<BatchListObjectParents>;
export interface BatchListObjectPolicies {
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListObjectPolicies: S.Schema<BatchListObjectPolicies>;
export interface BatchListPolicyAttachments {
    PolicyReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListPolicyAttachments: S.Schema<BatchListPolicyAttachments>;
export interface BatchLookupPolicy {
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchLookupPolicy: S.Schema<BatchLookupPolicy>;
export type RangeMode = "FIRST" | "LAST" | "LAST_BEFORE_MISSING_VALUES" | "INCLUSIVE" | "EXCLUSIVE" | (string & {});
export declare const RangeMode: any;
export interface TypedAttributeValueRange {
    StartMode: RangeMode;
    StartValue?: TypedAttributeValue;
    EndMode: RangeMode;
    EndValue?: TypedAttributeValue;
}
export declare const TypedAttributeValueRange: S.Schema<TypedAttributeValueRange>;
export interface ObjectAttributeRange {
    AttributeKey?: AttributeKey;
    Range?: TypedAttributeValueRange;
}
export declare const ObjectAttributeRange: S.Schema<ObjectAttributeRange>;
export type ObjectAttributeRangeList = ObjectAttributeRange[];
export declare const ObjectAttributeRangeList: any;
export interface BatchListIndex {
    RangesOnIndexedValues?: ObjectAttributeRange[];
    IndexReference: ObjectReference;
    MaxResults?: number;
    NextToken?: string;
}
export declare const BatchListIndex: S.Schema<BatchListIndex>;
export interface TypedLinkAttributeRange {
    AttributeName?: string;
    Range: TypedAttributeValueRange;
}
export declare const TypedLinkAttributeRange: S.Schema<TypedLinkAttributeRange>;
export type TypedLinkAttributeRangeList = TypedLinkAttributeRange[];
export declare const TypedLinkAttributeRangeList: any;
export interface BatchListOutgoingTypedLinks {
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[];
    FilterTypedLink?: TypedLinkSchemaAndFacetName;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListOutgoingTypedLinks: S.Schema<BatchListOutgoingTypedLinks>;
export interface BatchListIncomingTypedLinks {
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[];
    FilterTypedLink?: TypedLinkSchemaAndFacetName;
    NextToken?: string;
    MaxResults?: number;
}
export declare const BatchListIncomingTypedLinks: S.Schema<BatchListIncomingTypedLinks>;
export interface BatchGetLinkAttributes {
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeNames: string[];
}
export declare const BatchGetLinkAttributes: S.Schema<BatchGetLinkAttributes>;
export interface BatchReadOperation {
    ListObjectAttributes?: BatchListObjectAttributes;
    ListObjectChildren?: BatchListObjectChildren;
    ListAttachedIndices?: BatchListAttachedIndices;
    ListObjectParentPaths?: BatchListObjectParentPaths;
    GetObjectInformation?: BatchGetObjectInformation;
    GetObjectAttributes?: BatchGetObjectAttributes;
    ListObjectParents?: BatchListObjectParents;
    ListObjectPolicies?: BatchListObjectPolicies;
    ListPolicyAttachments?: BatchListPolicyAttachments;
    LookupPolicy?: BatchLookupPolicy;
    ListIndex?: BatchListIndex;
    ListOutgoingTypedLinks?: BatchListOutgoingTypedLinks;
    ListIncomingTypedLinks?: BatchListIncomingTypedLinks;
    GetLinkAttributes?: BatchGetLinkAttributes;
}
export declare const BatchReadOperation: S.Schema<BatchReadOperation>;
export type BatchReadOperationList = BatchReadOperation[];
export declare const BatchReadOperationList: any;
export type ConsistencyLevel = "SERIALIZABLE" | "EVENTUAL" | (string & {});
export declare const ConsistencyLevel: any;
export interface BatchReadRequest {
    DirectoryArn: string;
    Operations: BatchReadOperation[];
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const BatchReadRequest: S.Schema<BatchReadRequest>;
export interface BatchListObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[];
    NextToken?: string;
}
export declare const BatchListObjectAttributesResponse: S.Schema<BatchListObjectAttributesResponse>;
export type LinkNameToObjectIdentifierMap = {
    [key: string]: string | undefined;
};
export declare const LinkNameToObjectIdentifierMap: any;
export interface BatchListObjectChildrenResponse {
    Children?: {
        [key: string]: string | undefined;
    };
    NextToken?: string;
}
export declare const BatchListObjectChildrenResponse: S.Schema<BatchListObjectChildrenResponse>;
export type SchemaFacetList = SchemaFacet[];
export declare const SchemaFacetList: any;
export interface BatchGetObjectInformationResponse {
    SchemaFacets?: SchemaFacet[];
    ObjectIdentifier?: string;
}
export declare const BatchGetObjectInformationResponse: S.Schema<BatchGetObjectInformationResponse>;
export interface BatchGetObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[];
}
export declare const BatchGetObjectAttributesResponse: S.Schema<BatchGetObjectAttributesResponse>;
export interface IndexAttachment {
    IndexedAttributes?: AttributeKeyAndValue[];
    ObjectIdentifier?: string;
}
export declare const IndexAttachment: S.Schema<IndexAttachment>;
export type IndexAttachmentList = IndexAttachment[];
export declare const IndexAttachmentList: any;
export interface BatchListAttachedIndicesResponse {
    IndexAttachments?: IndexAttachment[];
    NextToken?: string;
}
export declare const BatchListAttachedIndicesResponse: S.Schema<BatchListAttachedIndicesResponse>;
export type PathString = string;
export type ObjectIdentifierList = string[];
export declare const ObjectIdentifierList: any;
export interface PathToObjectIdentifiers {
    Path?: string;
    ObjectIdentifiers?: string[];
}
export declare const PathToObjectIdentifiers: S.Schema<PathToObjectIdentifiers>;
export type PathToObjectIdentifiersList = PathToObjectIdentifiers[];
export declare const PathToObjectIdentifiersList: any;
export interface BatchListObjectParentPathsResponse {
    PathToObjectIdentifiersList?: PathToObjectIdentifiers[];
    NextToken?: string;
}
export declare const BatchListObjectParentPathsResponse: S.Schema<BatchListObjectParentPathsResponse>;
export interface BatchListObjectPoliciesResponse {
    AttachedPolicyIds?: string[];
    NextToken?: string;
}
export declare const BatchListObjectPoliciesResponse: S.Schema<BatchListObjectPoliciesResponse>;
export interface BatchListPolicyAttachmentsResponse {
    ObjectIdentifiers?: string[];
    NextToken?: string;
}
export declare const BatchListPolicyAttachmentsResponse: S.Schema<BatchListPolicyAttachmentsResponse>;
export type PolicyType = string;
export interface PolicyAttachment {
    PolicyId?: string;
    ObjectIdentifier?: string;
    PolicyType?: string;
}
export declare const PolicyAttachment: S.Schema<PolicyAttachment>;
export type PolicyAttachmentList = PolicyAttachment[];
export declare const PolicyAttachmentList: any;
export interface PolicyToPath {
    Path?: string;
    Policies?: PolicyAttachment[];
}
export declare const PolicyToPath: S.Schema<PolicyToPath>;
export type PolicyToPathList = PolicyToPath[];
export declare const PolicyToPathList: any;
export interface BatchLookupPolicyResponse {
    PolicyToPathList?: PolicyToPath[];
    NextToken?: string;
}
export declare const BatchLookupPolicyResponse: S.Schema<BatchLookupPolicyResponse>;
export interface BatchListIndexResponse {
    IndexAttachments?: IndexAttachment[];
    NextToken?: string;
}
export declare const BatchListIndexResponse: S.Schema<BatchListIndexResponse>;
export type TypedLinkSpecifierList = TypedLinkSpecifier[];
export declare const TypedLinkSpecifierList: any;
export interface BatchListOutgoingTypedLinksResponse {
    TypedLinkSpecifiers?: TypedLinkSpecifier[];
    NextToken?: string;
}
export declare const BatchListOutgoingTypedLinksResponse: S.Schema<BatchListOutgoingTypedLinksResponse>;
export interface BatchListIncomingTypedLinksResponse {
    LinkSpecifiers?: TypedLinkSpecifier[];
    NextToken?: string;
}
export declare const BatchListIncomingTypedLinksResponse: S.Schema<BatchListIncomingTypedLinksResponse>;
export interface BatchGetLinkAttributesResponse {
    Attributes?: AttributeKeyAndValue[];
}
export declare const BatchGetLinkAttributesResponse: S.Schema<BatchGetLinkAttributesResponse>;
export interface ObjectIdentifierAndLinkNameTuple {
    ObjectIdentifier?: string;
    LinkName?: string;
}
export declare const ObjectIdentifierAndLinkNameTuple: S.Schema<ObjectIdentifierAndLinkNameTuple>;
export type ObjectIdentifierAndLinkNameList = ObjectIdentifierAndLinkNameTuple[];
export declare const ObjectIdentifierAndLinkNameList: any;
export interface BatchListObjectParentsResponse {
    ParentLinks?: ObjectIdentifierAndLinkNameTuple[];
    NextToken?: string;
}
export declare const BatchListObjectParentsResponse: S.Schema<BatchListObjectParentsResponse>;
export interface BatchReadSuccessfulResponse {
    ListObjectAttributes?: BatchListObjectAttributesResponse;
    ListObjectChildren?: BatchListObjectChildrenResponse;
    GetObjectInformation?: BatchGetObjectInformationResponse;
    GetObjectAttributes?: BatchGetObjectAttributesResponse;
    ListAttachedIndices?: BatchListAttachedIndicesResponse;
    ListObjectParentPaths?: BatchListObjectParentPathsResponse;
    ListObjectPolicies?: BatchListObjectPoliciesResponse;
    ListPolicyAttachments?: BatchListPolicyAttachmentsResponse;
    LookupPolicy?: BatchLookupPolicyResponse;
    ListIndex?: BatchListIndexResponse;
    ListOutgoingTypedLinks?: BatchListOutgoingTypedLinksResponse;
    ListIncomingTypedLinks?: BatchListIncomingTypedLinksResponse;
    GetLinkAttributes?: BatchGetLinkAttributesResponse;
    ListObjectParents?: BatchListObjectParentsResponse;
}
export declare const BatchReadSuccessfulResponse: S.Schema<BatchReadSuccessfulResponse>;
export type BatchReadExceptionType = "ValidationException" | "InvalidArnException" | "ResourceNotFoundException" | "InvalidNextTokenException" | "AccessDeniedException" | "NotNodeException" | "FacetValidationException" | "CannotListParentOfRootException" | "NotIndexException" | "NotPolicyException" | "DirectoryNotEnabledException" | "LimitExceededException" | "InternalServiceException" | (string & {});
export declare const BatchReadExceptionType: any;
export type ExceptionMessage = string;
export interface BatchReadException {
    Type?: BatchReadExceptionType;
    Message?: string;
}
export declare const BatchReadException: S.Schema<BatchReadException>;
export interface BatchReadOperationResponse {
    SuccessfulResponse?: BatchReadSuccessfulResponse;
    ExceptionResponse?: BatchReadException;
}
export declare const BatchReadOperationResponse: S.Schema<BatchReadOperationResponse>;
export type BatchReadOperationResponseList = BatchReadOperationResponse[];
export declare const BatchReadOperationResponseList: any;
export interface BatchReadResponse {
    Responses?: BatchReadOperationResponse[];
}
export declare const BatchReadResponse: S.Schema<BatchReadResponse>;
export type BatchReferenceName = string;
export interface BatchCreateObject {
    SchemaFacet: SchemaFacet[];
    ObjectAttributeList: AttributeKeyAndValue[];
    ParentReference?: ObjectReference;
    LinkName?: string;
    BatchReferenceName?: string;
}
export declare const BatchCreateObject: S.Schema<BatchCreateObject>;
export interface BatchAttachObject {
    ParentReference: ObjectReference;
    ChildReference: ObjectReference;
    LinkName: string;
}
export declare const BatchAttachObject: S.Schema<BatchAttachObject>;
export interface BatchDetachObject {
    ParentReference: ObjectReference;
    LinkName: string;
    BatchReferenceName?: string;
}
export declare const BatchDetachObject: S.Schema<BatchDetachObject>;
export type UpdateActionType = "CREATE_OR_UPDATE" | "DELETE" | (string & {});
export declare const UpdateActionType: any;
export interface ObjectAttributeAction {
    ObjectAttributeActionType?: UpdateActionType;
    ObjectAttributeUpdateValue?: TypedAttributeValue;
}
export declare const ObjectAttributeAction: S.Schema<ObjectAttributeAction>;
export interface ObjectAttributeUpdate {
    ObjectAttributeKey?: AttributeKey;
    ObjectAttributeAction?: ObjectAttributeAction;
}
export declare const ObjectAttributeUpdate: S.Schema<ObjectAttributeUpdate>;
export type ObjectAttributeUpdateList = ObjectAttributeUpdate[];
export declare const ObjectAttributeUpdateList: any;
export interface BatchUpdateObjectAttributes {
    ObjectReference: ObjectReference;
    AttributeUpdates: ObjectAttributeUpdate[];
}
export declare const BatchUpdateObjectAttributes: S.Schema<BatchUpdateObjectAttributes>;
export interface BatchDeleteObject {
    ObjectReference: ObjectReference;
}
export declare const BatchDeleteObject: S.Schema<BatchDeleteObject>;
export interface BatchAddFacetToObject {
    SchemaFacet: SchemaFacet;
    ObjectAttributeList: AttributeKeyAndValue[];
    ObjectReference: ObjectReference;
}
export declare const BatchAddFacetToObject: S.Schema<BatchAddFacetToObject>;
export interface BatchRemoveFacetFromObject {
    SchemaFacet: SchemaFacet;
    ObjectReference: ObjectReference;
}
export declare const BatchRemoveFacetFromObject: S.Schema<BatchRemoveFacetFromObject>;
export interface BatchAttachPolicy {
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export declare const BatchAttachPolicy: S.Schema<BatchAttachPolicy>;
export interface BatchDetachPolicy {
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export declare const BatchDetachPolicy: S.Schema<BatchDetachPolicy>;
export type AttributeKeyList = AttributeKey[];
export declare const AttributeKeyList: any;
export interface BatchCreateIndex {
    OrderedIndexedAttributeList: AttributeKey[];
    IsUnique: boolean;
    ParentReference?: ObjectReference;
    LinkName?: string;
    BatchReferenceName?: string;
}
export declare const BatchCreateIndex: S.Schema<BatchCreateIndex>;
export interface BatchAttachToIndex {
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export declare const BatchAttachToIndex: S.Schema<BatchAttachToIndex>;
export interface BatchDetachFromIndex {
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export declare const BatchDetachFromIndex: S.Schema<BatchDetachFromIndex>;
export interface BatchAttachTypedLink {
    SourceObjectReference: ObjectReference;
    TargetObjectReference: ObjectReference;
    TypedLinkFacet: TypedLinkSchemaAndFacetName;
    Attributes: AttributeNameAndValue[];
}
export declare const BatchAttachTypedLink: S.Schema<BatchAttachTypedLink>;
export interface BatchDetachTypedLink {
    TypedLinkSpecifier: TypedLinkSpecifier;
}
export declare const BatchDetachTypedLink: S.Schema<BatchDetachTypedLink>;
export interface LinkAttributeAction {
    AttributeActionType?: UpdateActionType;
    AttributeUpdateValue?: TypedAttributeValue;
}
export declare const LinkAttributeAction: S.Schema<LinkAttributeAction>;
export interface LinkAttributeUpdate {
    AttributeKey?: AttributeKey;
    AttributeAction?: LinkAttributeAction;
}
export declare const LinkAttributeUpdate: S.Schema<LinkAttributeUpdate>;
export type LinkAttributeUpdateList = LinkAttributeUpdate[];
export declare const LinkAttributeUpdateList: any;
export interface BatchUpdateLinkAttributes {
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeUpdates: LinkAttributeUpdate[];
}
export declare const BatchUpdateLinkAttributes: S.Schema<BatchUpdateLinkAttributes>;
export interface BatchWriteOperation {
    CreateObject?: BatchCreateObject;
    AttachObject?: BatchAttachObject;
    DetachObject?: BatchDetachObject;
    UpdateObjectAttributes?: BatchUpdateObjectAttributes;
    DeleteObject?: BatchDeleteObject;
    AddFacetToObject?: BatchAddFacetToObject;
    RemoveFacetFromObject?: BatchRemoveFacetFromObject;
    AttachPolicy?: BatchAttachPolicy;
    DetachPolicy?: BatchDetachPolicy;
    CreateIndex?: BatchCreateIndex;
    AttachToIndex?: BatchAttachToIndex;
    DetachFromIndex?: BatchDetachFromIndex;
    AttachTypedLink?: BatchAttachTypedLink;
    DetachTypedLink?: BatchDetachTypedLink;
    UpdateLinkAttributes?: BatchUpdateLinkAttributes;
}
export declare const BatchWriteOperation: S.Schema<BatchWriteOperation>;
export type BatchWriteOperationList = BatchWriteOperation[];
export declare const BatchWriteOperationList: any;
export interface BatchWriteRequest {
    DirectoryArn: string;
    Operations: BatchWriteOperation[];
}
export declare const BatchWriteRequest: S.Schema<BatchWriteRequest>;
export interface BatchCreateObjectResponse {
    ObjectIdentifier?: string;
}
export declare const BatchCreateObjectResponse: S.Schema<BatchCreateObjectResponse>;
export interface BatchAttachObjectResponse {
    attachedObjectIdentifier?: string;
}
export declare const BatchAttachObjectResponse: S.Schema<BatchAttachObjectResponse>;
export interface BatchDetachObjectResponse {
    detachedObjectIdentifier?: string;
}
export declare const BatchDetachObjectResponse: S.Schema<BatchDetachObjectResponse>;
export interface BatchUpdateObjectAttributesResponse {
    ObjectIdentifier?: string;
}
export declare const BatchUpdateObjectAttributesResponse: S.Schema<BatchUpdateObjectAttributesResponse>;
export interface BatchDeleteObjectResponse {
}
export declare const BatchDeleteObjectResponse: S.Schema<BatchDeleteObjectResponse>;
export interface BatchAddFacetToObjectResponse {
}
export declare const BatchAddFacetToObjectResponse: S.Schema<BatchAddFacetToObjectResponse>;
export interface BatchRemoveFacetFromObjectResponse {
}
export declare const BatchRemoveFacetFromObjectResponse: S.Schema<BatchRemoveFacetFromObjectResponse>;
export interface BatchAttachPolicyResponse {
}
export declare const BatchAttachPolicyResponse: S.Schema<BatchAttachPolicyResponse>;
export interface BatchDetachPolicyResponse {
}
export declare const BatchDetachPolicyResponse: S.Schema<BatchDetachPolicyResponse>;
export interface BatchCreateIndexResponse {
    ObjectIdentifier?: string;
}
export declare const BatchCreateIndexResponse: S.Schema<BatchCreateIndexResponse>;
export interface BatchAttachToIndexResponse {
    AttachedObjectIdentifier?: string;
}
export declare const BatchAttachToIndexResponse: S.Schema<BatchAttachToIndexResponse>;
export interface BatchDetachFromIndexResponse {
    DetachedObjectIdentifier?: string;
}
export declare const BatchDetachFromIndexResponse: S.Schema<BatchDetachFromIndexResponse>;
export interface BatchAttachTypedLinkResponse {
    TypedLinkSpecifier?: TypedLinkSpecifier;
}
export declare const BatchAttachTypedLinkResponse: S.Schema<BatchAttachTypedLinkResponse>;
export interface BatchDetachTypedLinkResponse {
}
export declare const BatchDetachTypedLinkResponse: S.Schema<BatchDetachTypedLinkResponse>;
export interface BatchUpdateLinkAttributesResponse {
}
export declare const BatchUpdateLinkAttributesResponse: S.Schema<BatchUpdateLinkAttributesResponse>;
export interface BatchWriteOperationResponse {
    CreateObject?: BatchCreateObjectResponse;
    AttachObject?: BatchAttachObjectResponse;
    DetachObject?: BatchDetachObjectResponse;
    UpdateObjectAttributes?: BatchUpdateObjectAttributesResponse;
    DeleteObject?: BatchDeleteObjectResponse;
    AddFacetToObject?: BatchAddFacetToObjectResponse;
    RemoveFacetFromObject?: BatchRemoveFacetFromObjectResponse;
    AttachPolicy?: BatchAttachPolicyResponse;
    DetachPolicy?: BatchDetachPolicyResponse;
    CreateIndex?: BatchCreateIndexResponse;
    AttachToIndex?: BatchAttachToIndexResponse;
    DetachFromIndex?: BatchDetachFromIndexResponse;
    AttachTypedLink?: BatchAttachTypedLinkResponse;
    DetachTypedLink?: BatchDetachTypedLinkResponse;
    UpdateLinkAttributes?: BatchUpdateLinkAttributesResponse;
}
export declare const BatchWriteOperationResponse: S.Schema<BatchWriteOperationResponse>;
export type BatchWriteOperationResponseList = BatchWriteOperationResponse[];
export declare const BatchWriteOperationResponseList: any;
export interface BatchWriteResponse {
    Responses?: BatchWriteOperationResponse[];
}
export declare const BatchWriteResponse: S.Schema<BatchWriteResponse>;
export type DirectoryName = string;
export interface CreateDirectoryRequest {
    Name: string;
    SchemaArn: string;
}
export declare const CreateDirectoryRequest: S.Schema<CreateDirectoryRequest>;
export type DirectoryArn = string;
export interface CreateDirectoryResponse {
    DirectoryArn: string;
    Name: string;
    ObjectIdentifier: string;
    AppliedSchemaArn: string;
}
export declare const CreateDirectoryResponse: S.Schema<CreateDirectoryResponse>;
export type FacetAttributeType = "STRING" | "BINARY" | "BOOLEAN" | "NUMBER" | "DATETIME" | "VARIANT" | (string & {});
export declare const FacetAttributeType: any;
export type RuleKey = string;
export type RuleType = "BINARY_LENGTH" | "NUMBER_COMPARISON" | "STRING_FROM_SET" | "STRING_LENGTH" | (string & {});
export declare const RuleType: any;
export type RuleParameterKey = string;
export type RuleParameterValue = string;
export type RuleParameterMap = {
    [key: string]: string | undefined;
};
export declare const RuleParameterMap: any;
export interface Rule {
    Type?: RuleType;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const Rule: S.Schema<Rule>;
export type RuleMap = {
    [key: string]: Rule | undefined;
};
export declare const RuleMap: any;
export interface FacetAttributeDefinition {
    Type: FacetAttributeType;
    DefaultValue?: TypedAttributeValue;
    IsImmutable?: boolean;
    Rules?: {
        [key: string]: Rule | undefined;
    };
}
export declare const FacetAttributeDefinition: S.Schema<FacetAttributeDefinition>;
export interface FacetAttributeReference {
    TargetFacetName: string;
    TargetAttributeName: string;
}
export declare const FacetAttributeReference: S.Schema<FacetAttributeReference>;
export type RequiredAttributeBehavior = "REQUIRED_ALWAYS" | "NOT_REQUIRED" | (string & {});
export declare const RequiredAttributeBehavior: any;
export interface FacetAttribute {
    Name: string;
    AttributeDefinition?: FacetAttributeDefinition;
    AttributeReference?: FacetAttributeReference;
    RequiredBehavior?: RequiredAttributeBehavior;
}
export declare const FacetAttribute: S.Schema<FacetAttribute>;
export type FacetAttributeList = FacetAttribute[];
export declare const FacetAttributeList: any;
export type ObjectType = "NODE" | "LEAF_NODE" | "POLICY" | "INDEX" | (string & {});
export declare const ObjectType: any;
export type FacetStyle = "STATIC" | "DYNAMIC" | (string & {});
export declare const FacetStyle: any;
export interface CreateFacetRequest {
    SchemaArn: string;
    Name: string;
    Attributes?: FacetAttribute[];
    ObjectType?: ObjectType;
    FacetStyle?: FacetStyle;
}
export declare const CreateFacetRequest: S.Schema<CreateFacetRequest>;
export interface CreateFacetResponse {
}
export declare const CreateFacetResponse: S.Schema<CreateFacetResponse>;
export interface CreateIndexRequest {
    DirectoryArn: string;
    OrderedIndexedAttributeList: AttributeKey[];
    IsUnique: boolean;
    ParentReference?: ObjectReference;
    LinkName?: string;
}
export declare const CreateIndexRequest: S.Schema<CreateIndexRequest>;
export interface CreateIndexResponse {
    ObjectIdentifier?: string;
}
export declare const CreateIndexResponse: S.Schema<CreateIndexResponse>;
export interface CreateObjectRequest {
    DirectoryArn: string;
    SchemaFacets: SchemaFacet[];
    ObjectAttributeList?: AttributeKeyAndValue[];
    ParentReference?: ObjectReference;
    LinkName?: string;
}
export declare const CreateObjectRequest: S.Schema<CreateObjectRequest>;
export interface CreateObjectResponse {
    ObjectIdentifier?: string;
}
export declare const CreateObjectResponse: S.Schema<CreateObjectResponse>;
export type SchemaName = string;
export interface CreateSchemaRequest {
    Name: string;
}
export declare const CreateSchemaRequest: S.Schema<CreateSchemaRequest>;
export interface CreateSchemaResponse {
    SchemaArn?: string;
}
export declare const CreateSchemaResponse: S.Schema<CreateSchemaResponse>;
export interface TypedLinkAttributeDefinition {
    Name: string;
    Type: FacetAttributeType;
    DefaultValue?: TypedAttributeValue;
    IsImmutable?: boolean;
    Rules?: {
        [key: string]: Rule | undefined;
    };
    RequiredBehavior: RequiredAttributeBehavior;
}
export declare const TypedLinkAttributeDefinition: S.Schema<TypedLinkAttributeDefinition>;
export type TypedLinkAttributeDefinitionList = TypedLinkAttributeDefinition[];
export declare const TypedLinkAttributeDefinitionList: any;
export interface TypedLinkFacet {
    Name: string;
    Attributes: TypedLinkAttributeDefinition[];
    IdentityAttributeOrder: string[];
}
export declare const TypedLinkFacet: S.Schema<TypedLinkFacet>;
export interface CreateTypedLinkFacetRequest {
    SchemaArn: string;
    Facet: TypedLinkFacet;
}
export declare const CreateTypedLinkFacetRequest: S.Schema<CreateTypedLinkFacetRequest>;
export interface CreateTypedLinkFacetResponse {
}
export declare const CreateTypedLinkFacetResponse: S.Schema<CreateTypedLinkFacetResponse>;
export interface DeleteDirectoryRequest {
    DirectoryArn: string;
}
export declare const DeleteDirectoryRequest: S.Schema<DeleteDirectoryRequest>;
export interface DeleteDirectoryResponse {
    DirectoryArn: string;
}
export declare const DeleteDirectoryResponse: S.Schema<DeleteDirectoryResponse>;
export interface DeleteFacetRequest {
    SchemaArn: string;
    Name: string;
}
export declare const DeleteFacetRequest: S.Schema<DeleteFacetRequest>;
export interface DeleteFacetResponse {
}
export declare const DeleteFacetResponse: S.Schema<DeleteFacetResponse>;
export interface DeleteObjectRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
}
export declare const DeleteObjectRequest: S.Schema<DeleteObjectRequest>;
export interface DeleteObjectResponse {
}
export declare const DeleteObjectResponse: S.Schema<DeleteObjectResponse>;
export interface DeleteSchemaRequest {
    SchemaArn: string;
}
export declare const DeleteSchemaRequest: S.Schema<DeleteSchemaRequest>;
export interface DeleteSchemaResponse {
    SchemaArn?: string;
}
export declare const DeleteSchemaResponse: S.Schema<DeleteSchemaResponse>;
export interface DeleteTypedLinkFacetRequest {
    SchemaArn: string;
    Name: string;
}
export declare const DeleteTypedLinkFacetRequest: S.Schema<DeleteTypedLinkFacetRequest>;
export interface DeleteTypedLinkFacetResponse {
}
export declare const DeleteTypedLinkFacetResponse: S.Schema<DeleteTypedLinkFacetResponse>;
export interface DetachFromIndexRequest {
    DirectoryArn: string;
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export declare const DetachFromIndexRequest: S.Schema<DetachFromIndexRequest>;
export interface DetachFromIndexResponse {
    DetachedObjectIdentifier?: string;
}
export declare const DetachFromIndexResponse: S.Schema<DetachFromIndexResponse>;
export interface DetachObjectRequest {
    DirectoryArn: string;
    ParentReference: ObjectReference;
    LinkName: string;
}
export declare const DetachObjectRequest: S.Schema<DetachObjectRequest>;
export interface DetachObjectResponse {
    DetachedObjectIdentifier?: string;
}
export declare const DetachObjectResponse: S.Schema<DetachObjectResponse>;
export interface DetachPolicyRequest {
    DirectoryArn: string;
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export declare const DetachPolicyRequest: S.Schema<DetachPolicyRequest>;
export interface DetachPolicyResponse {
}
export declare const DetachPolicyResponse: S.Schema<DetachPolicyResponse>;
export interface DetachTypedLinkRequest {
    DirectoryArn: string;
    TypedLinkSpecifier: TypedLinkSpecifier;
}
export declare const DetachTypedLinkRequest: S.Schema<DetachTypedLinkRequest>;
export interface DetachTypedLinkResponse {
}
export declare const DetachTypedLinkResponse: S.Schema<DetachTypedLinkResponse>;
export interface DisableDirectoryRequest {
    DirectoryArn: string;
}
export declare const DisableDirectoryRequest: S.Schema<DisableDirectoryRequest>;
export interface DisableDirectoryResponse {
    DirectoryArn: string;
}
export declare const DisableDirectoryResponse: S.Schema<DisableDirectoryResponse>;
export interface EnableDirectoryRequest {
    DirectoryArn: string;
}
export declare const EnableDirectoryRequest: S.Schema<EnableDirectoryRequest>;
export interface EnableDirectoryResponse {
    DirectoryArn: string;
}
export declare const EnableDirectoryResponse: S.Schema<EnableDirectoryResponse>;
export interface GetAppliedSchemaVersionRequest {
    SchemaArn: string;
}
export declare const GetAppliedSchemaVersionRequest: S.Schema<GetAppliedSchemaVersionRequest>;
export interface GetAppliedSchemaVersionResponse {
    AppliedSchemaArn?: string;
}
export declare const GetAppliedSchemaVersionResponse: S.Schema<GetAppliedSchemaVersionResponse>;
export interface GetDirectoryRequest {
    DirectoryArn: string;
}
export declare const GetDirectoryRequest: S.Schema<GetDirectoryRequest>;
export type DirectoryState = "ENABLED" | "DISABLED" | "DELETED" | (string & {});
export declare const DirectoryState: any;
export interface Directory {
    Name?: string;
    DirectoryArn?: string;
    State?: DirectoryState;
    CreationDateTime?: Date;
}
export declare const Directory: S.Schema<Directory>;
export interface GetDirectoryResponse {
    Directory: Directory;
}
export declare const GetDirectoryResponse: S.Schema<GetDirectoryResponse>;
export interface GetFacetRequest {
    SchemaArn: string;
    Name: string;
}
export declare const GetFacetRequest: S.Schema<GetFacetRequest>;
export interface Facet {
    Name?: string;
    ObjectType?: ObjectType;
    FacetStyle?: FacetStyle;
}
export declare const Facet: S.Schema<Facet>;
export interface GetFacetResponse {
    Facet?: Facet;
}
export declare const GetFacetResponse: S.Schema<GetFacetResponse>;
export interface GetLinkAttributesRequest {
    DirectoryArn: string;
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeNames: string[];
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const GetLinkAttributesRequest: S.Schema<GetLinkAttributesRequest>;
export interface GetLinkAttributesResponse {
    Attributes?: AttributeKeyAndValue[];
}
export declare const GetLinkAttributesResponse: S.Schema<GetLinkAttributesResponse>;
export interface GetObjectAttributesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    ConsistencyLevel?: ConsistencyLevel;
    SchemaFacet: SchemaFacet;
    AttributeNames: string[];
}
export declare const GetObjectAttributesRequest: S.Schema<GetObjectAttributesRequest>;
export interface GetObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[];
}
export declare const GetObjectAttributesResponse: S.Schema<GetObjectAttributesResponse>;
export interface GetObjectInformationRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const GetObjectInformationRequest: S.Schema<GetObjectInformationRequest>;
export interface GetObjectInformationResponse {
    SchemaFacets?: SchemaFacet[];
    ObjectIdentifier?: string;
}
export declare const GetObjectInformationResponse: S.Schema<GetObjectInformationResponse>;
export interface GetSchemaAsJsonRequest {
    SchemaArn: string;
}
export declare const GetSchemaAsJsonRequest: S.Schema<GetSchemaAsJsonRequest>;
export type SchemaJsonDocument = string;
export interface GetSchemaAsJsonResponse {
    Name?: string;
    Document?: string;
}
export declare const GetSchemaAsJsonResponse: S.Schema<GetSchemaAsJsonResponse>;
export interface GetTypedLinkFacetInformationRequest {
    SchemaArn: string;
    Name: string;
}
export declare const GetTypedLinkFacetInformationRequest: S.Schema<GetTypedLinkFacetInformationRequest>;
export interface GetTypedLinkFacetInformationResponse {
    IdentityAttributeOrder?: string[];
}
export declare const GetTypedLinkFacetInformationResponse: S.Schema<GetTypedLinkFacetInformationResponse>;
export interface ListAppliedSchemaArnsRequest {
    DirectoryArn: string;
    SchemaArn?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAppliedSchemaArnsRequest: S.Schema<ListAppliedSchemaArnsRequest>;
export type Arns = string[];
export declare const Arns: any;
export interface ListAppliedSchemaArnsResponse {
    SchemaArns?: string[];
    NextToken?: string;
}
export declare const ListAppliedSchemaArnsResponse: S.Schema<ListAppliedSchemaArnsResponse>;
export interface ListAttachedIndicesRequest {
    DirectoryArn: string;
    TargetReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const ListAttachedIndicesRequest: S.Schema<ListAttachedIndicesRequest>;
export interface ListAttachedIndicesResponse {
    IndexAttachments?: IndexAttachment[];
    NextToken?: string;
}
export declare const ListAttachedIndicesResponse: S.Schema<ListAttachedIndicesResponse>;
export interface ListDevelopmentSchemaArnsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDevelopmentSchemaArnsRequest: S.Schema<ListDevelopmentSchemaArnsRequest>;
export interface ListDevelopmentSchemaArnsResponse {
    SchemaArns?: string[];
    NextToken?: string;
}
export declare const ListDevelopmentSchemaArnsResponse: S.Schema<ListDevelopmentSchemaArnsResponse>;
export interface ListDirectoriesRequest {
    NextToken?: string;
    MaxResults?: number;
    state?: DirectoryState;
}
export declare const ListDirectoriesRequest: S.Schema<ListDirectoriesRequest>;
export type DirectoryList = Directory[];
export declare const DirectoryList: any;
export interface ListDirectoriesResponse {
    Directories: Directory[];
    NextToken?: string;
}
export declare const ListDirectoriesResponse: S.Schema<ListDirectoriesResponse>;
export interface ListFacetAttributesRequest {
    SchemaArn: string;
    Name: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFacetAttributesRequest: S.Schema<ListFacetAttributesRequest>;
export interface ListFacetAttributesResponse {
    Attributes?: FacetAttribute[];
    NextToken?: string;
}
export declare const ListFacetAttributesResponse: S.Schema<ListFacetAttributesResponse>;
export interface ListFacetNamesRequest {
    SchemaArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFacetNamesRequest: S.Schema<ListFacetNamesRequest>;
export type FacetNameList = string[];
export declare const FacetNameList: any;
export interface ListFacetNamesResponse {
    FacetNames?: string[];
    NextToken?: string;
}
export declare const ListFacetNamesResponse: S.Schema<ListFacetNamesResponse>;
export interface ListIncomingTypedLinksRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[];
    FilterTypedLink?: TypedLinkSchemaAndFacetName;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const ListIncomingTypedLinksRequest: S.Schema<ListIncomingTypedLinksRequest>;
export interface ListIncomingTypedLinksResponse {
    LinkSpecifiers?: TypedLinkSpecifier[];
    NextToken?: string;
}
export declare const ListIncomingTypedLinksResponse: S.Schema<ListIncomingTypedLinksResponse>;
export interface ListIndexRequest {
    DirectoryArn: string;
    RangesOnIndexedValues?: ObjectAttributeRange[];
    IndexReference: ObjectReference;
    MaxResults?: number;
    NextToken?: string;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const ListIndexRequest: S.Schema<ListIndexRequest>;
export interface ListIndexResponse {
    IndexAttachments?: IndexAttachment[];
    NextToken?: string;
}
export declare const ListIndexResponse: S.Schema<ListIndexResponse>;
export interface ListManagedSchemaArnsRequest {
    SchemaArn?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListManagedSchemaArnsRequest: S.Schema<ListManagedSchemaArnsRequest>;
export interface ListManagedSchemaArnsResponse {
    SchemaArns?: string[];
    NextToken?: string;
}
export declare const ListManagedSchemaArnsResponse: S.Schema<ListManagedSchemaArnsResponse>;
export interface ListObjectAttributesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
    FacetFilter?: SchemaFacet;
}
export declare const ListObjectAttributesRequest: S.Schema<ListObjectAttributesRequest>;
export interface ListObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[];
    NextToken?: string;
}
export declare const ListObjectAttributesResponse: S.Schema<ListObjectAttributesResponse>;
export interface ListObjectChildrenRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const ListObjectChildrenRequest: S.Schema<ListObjectChildrenRequest>;
export interface ListObjectChildrenResponse {
    Children?: {
        [key: string]: string | undefined;
    };
    NextToken?: string;
}
export declare const ListObjectChildrenResponse: S.Schema<ListObjectChildrenResponse>;
export interface ListObjectParentPathsRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListObjectParentPathsRequest: S.Schema<ListObjectParentPathsRequest>;
export interface ListObjectParentPathsResponse {
    PathToObjectIdentifiersList?: PathToObjectIdentifiers[];
    NextToken?: string;
}
export declare const ListObjectParentPathsResponse: S.Schema<ListObjectParentPathsResponse>;
export interface ListObjectParentsRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
    IncludeAllLinksToEachParent?: boolean;
}
export declare const ListObjectParentsRequest: S.Schema<ListObjectParentsRequest>;
export type ObjectIdentifierToLinkNameMap = {
    [key: string]: string | undefined;
};
export declare const ObjectIdentifierToLinkNameMap: any;
export interface ListObjectParentsResponse {
    Parents?: {
        [key: string]: string | undefined;
    };
    NextToken?: string;
    ParentLinks?: ObjectIdentifierAndLinkNameTuple[];
}
export declare const ListObjectParentsResponse: S.Schema<ListObjectParentsResponse>;
export interface ListObjectPoliciesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const ListObjectPoliciesRequest: S.Schema<ListObjectPoliciesRequest>;
export interface ListObjectPoliciesResponse {
    AttachedPolicyIds?: string[];
    NextToken?: string;
}
export declare const ListObjectPoliciesResponse: S.Schema<ListObjectPoliciesResponse>;
export interface ListOutgoingTypedLinksRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[];
    FilterTypedLink?: TypedLinkSchemaAndFacetName;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const ListOutgoingTypedLinksRequest: S.Schema<ListOutgoingTypedLinksRequest>;
export interface ListOutgoingTypedLinksResponse {
    TypedLinkSpecifiers?: TypedLinkSpecifier[];
    NextToken?: string;
}
export declare const ListOutgoingTypedLinksResponse: S.Schema<ListOutgoingTypedLinksResponse>;
export interface ListPolicyAttachmentsRequest {
    DirectoryArn: string;
    PolicyReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
    ConsistencyLevel?: ConsistencyLevel;
}
export declare const ListPolicyAttachmentsRequest: S.Schema<ListPolicyAttachmentsRequest>;
export interface ListPolicyAttachmentsResponse {
    ObjectIdentifiers?: string[];
    NextToken?: string;
}
export declare const ListPolicyAttachmentsResponse: S.Schema<ListPolicyAttachmentsResponse>;
export interface ListPublishedSchemaArnsRequest {
    SchemaArn?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPublishedSchemaArnsRequest: S.Schema<ListPublishedSchemaArnsRequest>;
export interface ListPublishedSchemaArnsResponse {
    SchemaArns?: string[];
    NextToken?: string;
}
export declare const ListPublishedSchemaArnsResponse: S.Schema<ListPublishedSchemaArnsResponse>;
export type TagsNumberResults = number;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
    NextToken?: string;
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTypedLinkFacetAttributesRequest {
    SchemaArn: string;
    Name: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTypedLinkFacetAttributesRequest: S.Schema<ListTypedLinkFacetAttributesRequest>;
export interface ListTypedLinkFacetAttributesResponse {
    Attributes?: TypedLinkAttributeDefinition[];
    NextToken?: string;
}
export declare const ListTypedLinkFacetAttributesResponse: S.Schema<ListTypedLinkFacetAttributesResponse>;
export interface ListTypedLinkFacetNamesRequest {
    SchemaArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTypedLinkFacetNamesRequest: S.Schema<ListTypedLinkFacetNamesRequest>;
export type TypedLinkNameList = string[];
export declare const TypedLinkNameList: any;
export interface ListTypedLinkFacetNamesResponse {
    FacetNames?: string[];
    NextToken?: string;
}
export declare const ListTypedLinkFacetNamesResponse: S.Schema<ListTypedLinkFacetNamesResponse>;
export interface LookupPolicyRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string;
    MaxResults?: number;
}
export declare const LookupPolicyRequest: S.Schema<LookupPolicyRequest>;
export interface LookupPolicyResponse {
    PolicyToPathList?: PolicyToPath[];
    NextToken?: string;
}
export declare const LookupPolicyResponse: S.Schema<LookupPolicyResponse>;
export type Version = string;
export interface PublishSchemaRequest {
    DevelopmentSchemaArn: string;
    Version: string;
    MinorVersion?: string;
    Name?: string;
}
export declare const PublishSchemaRequest: S.Schema<PublishSchemaRequest>;
export interface PublishSchemaResponse {
    PublishedSchemaArn?: string;
}
export declare const PublishSchemaResponse: S.Schema<PublishSchemaResponse>;
export interface PutSchemaFromJsonRequest {
    SchemaArn: string;
    Document: string;
}
export declare const PutSchemaFromJsonRequest: S.Schema<PutSchemaFromJsonRequest>;
export interface PutSchemaFromJsonResponse {
    Arn?: string;
}
export declare const PutSchemaFromJsonResponse: S.Schema<PutSchemaFromJsonResponse>;
export interface RemoveFacetFromObjectRequest {
    DirectoryArn: string;
    SchemaFacet: SchemaFacet;
    ObjectReference: ObjectReference;
}
export declare const RemoveFacetFromObjectRequest: S.Schema<RemoveFacetFromObjectRequest>;
export interface RemoveFacetFromObjectResponse {
}
export declare const RemoveFacetFromObjectResponse: S.Schema<RemoveFacetFromObjectResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface FacetAttributeUpdate {
    Attribute?: FacetAttribute;
    Action?: UpdateActionType;
}
export declare const FacetAttributeUpdate: S.Schema<FacetAttributeUpdate>;
export type FacetAttributeUpdateList = FacetAttributeUpdate[];
export declare const FacetAttributeUpdateList: any;
export interface UpdateFacetRequest {
    SchemaArn: string;
    Name: string;
    AttributeUpdates?: FacetAttributeUpdate[];
    ObjectType?: ObjectType;
}
export declare const UpdateFacetRequest: S.Schema<UpdateFacetRequest>;
export interface UpdateFacetResponse {
}
export declare const UpdateFacetResponse: S.Schema<UpdateFacetResponse>;
export interface UpdateLinkAttributesRequest {
    DirectoryArn: string;
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeUpdates: LinkAttributeUpdate[];
}
export declare const UpdateLinkAttributesRequest: S.Schema<UpdateLinkAttributesRequest>;
export interface UpdateLinkAttributesResponse {
}
export declare const UpdateLinkAttributesResponse: S.Schema<UpdateLinkAttributesResponse>;
export interface UpdateObjectAttributesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    AttributeUpdates: ObjectAttributeUpdate[];
}
export declare const UpdateObjectAttributesRequest: S.Schema<UpdateObjectAttributesRequest>;
export interface UpdateObjectAttributesResponse {
    ObjectIdentifier?: string;
}
export declare const UpdateObjectAttributesResponse: S.Schema<UpdateObjectAttributesResponse>;
export interface UpdateSchemaRequest {
    SchemaArn: string;
    Name: string;
}
export declare const UpdateSchemaRequest: S.Schema<UpdateSchemaRequest>;
export interface UpdateSchemaResponse {
    SchemaArn?: string;
}
export declare const UpdateSchemaResponse: S.Schema<UpdateSchemaResponse>;
export interface TypedLinkFacetAttributeUpdate {
    Attribute: TypedLinkAttributeDefinition;
    Action: UpdateActionType;
}
export declare const TypedLinkFacetAttributeUpdate: S.Schema<TypedLinkFacetAttributeUpdate>;
export type TypedLinkFacetAttributeUpdateList = TypedLinkFacetAttributeUpdate[];
export declare const TypedLinkFacetAttributeUpdateList: any;
export interface UpdateTypedLinkFacetRequest {
    SchemaArn: string;
    Name: string;
    AttributeUpdates: TypedLinkFacetAttributeUpdate[];
    IdentityAttributeOrder: string[];
}
export declare const UpdateTypedLinkFacetRequest: S.Schema<UpdateTypedLinkFacetRequest>;
export interface UpdateTypedLinkFacetResponse {
}
export declare const UpdateTypedLinkFacetResponse: S.Schema<UpdateTypedLinkFacetResponse>;
export interface UpgradeAppliedSchemaRequest {
    PublishedSchemaArn: string;
    DirectoryArn: string;
    DryRun?: boolean;
}
export declare const UpgradeAppliedSchemaRequest: S.Schema<UpgradeAppliedSchemaRequest>;
export interface UpgradeAppliedSchemaResponse {
    UpgradedSchemaArn?: string;
    DirectoryArn?: string;
}
export declare const UpgradeAppliedSchemaResponse: S.Schema<UpgradeAppliedSchemaResponse>;
export interface UpgradePublishedSchemaRequest {
    DevelopmentSchemaArn: string;
    PublishedSchemaArn: string;
    MinorVersion: string;
    DryRun?: boolean;
}
export declare const UpgradePublishedSchemaRequest: S.Schema<UpgradePublishedSchemaRequest>;
export interface UpgradePublishedSchemaResponse {
    UpgradedSchemaArn?: string;
}
export declare const UpgradePublishedSchemaResponse: S.Schema<UpgradePublishedSchemaResponse>;
export type BatchOperationIndex = number;
export type BatchWriteExceptionType = "InternalServiceException" | "ValidationException" | "InvalidArnException" | "LinkNameAlreadyInUseException" | "StillContainsLinksException" | "FacetValidationException" | "ObjectNotDetachedException" | "ResourceNotFoundException" | "AccessDeniedException" | "InvalidAttachmentException" | "NotIndexException" | "NotNodeException" | "IndexedAttributeMissingException" | "ObjectAlreadyDetachedException" | "NotPolicyException" | "DirectoryNotEnabledException" | "LimitExceededException" | "UnsupportedIndexTypeException" | (string & {});
export declare const BatchWriteExceptionType: any;
export type AddFacetToObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Adds a new Facet to an object. An object can have more than one facet applied on it.
 */
export declare const addFacetToObject: API.OperationMethod<AddFacetToObjectRequest, AddFacetToObjectResponse, AddFacetToObjectError, Credentials | HttpClient.HttpClient>;
export type ApplySchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | SchemaAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Copies the input published schema, at the specified version, into the Directory with the same
 * name and version as that of the published schema.
 */
export declare const applySchema: API.OperationMethod<ApplySchemaRequest, ApplySchemaResponse, ApplySchemaError, Credentials | HttpClient.HttpClient>;
export type AttachObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches an existing object to another object. An object can be accessed in two
 * ways:
 *
 * - Using the path
 *
 * - Using `ObjectIdentifier`
 */
export declare const attachObject: API.OperationMethod<AttachObjectRequest, AttachObjectResponse, AttachObjectError, Credentials | HttpClient.HttpClient>;
export type AttachPolicyError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotPolicyException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches a policy object to a regular object. An object can have a limited number of attached
 * policies.
 */
export declare const attachPolicy: API.OperationMethod<AttachPolicyRequest, AttachPolicyResponse, AttachPolicyError, Credentials | HttpClient.HttpClient>;
export type AttachToIndexError = AccessDeniedException | DirectoryNotEnabledException | IndexedAttributeMissingException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | LinkNameAlreadyInUseException | NotIndexException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches the specified object to the specified index.
 */
export declare const attachToIndex: API.OperationMethod<AttachToIndexRequest, AttachToIndexResponse, AttachToIndexError, Credentials | HttpClient.HttpClient>;
export type AttachTypedLinkError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches a typed link to a specified source and target object. For more information, see Typed Links.
 */
export declare const attachTypedLink: API.OperationMethod<AttachTypedLinkRequest, AttachTypedLinkResponse, AttachTypedLinkError, Credentials | HttpClient.HttpClient>;
export type BatchReadError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Performs all the read operations in a batch.
 */
export declare const batchRead: API.OperationMethod<BatchReadRequest, BatchReadResponse, BatchReadError, Credentials | HttpClient.HttpClient>;
export type BatchWriteError = AccessDeniedException | BatchWriteException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Performs all the write operations in a batch. Either all the operations succeed or
 * none.
 */
export declare const batchWrite: API.OperationMethod<BatchWriteRequest, BatchWriteResponse, BatchWriteError, Credentials | HttpClient.HttpClient>;
export type CreateDirectoryError = AccessDeniedException | DirectoryAlreadyExistsException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Creates a Directory by copying the published schema into the
 * directory. A directory cannot be created without a schema.
 *
 * You can also quickly create a directory using a managed schema, called the
 * `QuickStartSchema`. For more information, see Managed Schema in the *Amazon Cloud Directory Developer Guide*.
 */
export declare const createDirectory: API.OperationMethod<CreateDirectoryRequest, CreateDirectoryResponse, CreateDirectoryError, Credentials | HttpClient.HttpClient>;
export type CreateFacetError = AccessDeniedException | FacetAlreadyExistsException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Creates a new Facet in a schema. Facet creation is allowed only
 * in development or applied schemas.
 */
export declare const createFacet: API.OperationMethod<CreateFacetRequest, CreateFacetResponse, CreateFacetError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | UnsupportedIndexTypeException | ValidationException | CommonErrors;
/**
 * Creates an index object. See Indexing and search for more information.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | UnsupportedIndexTypeException | ValidationException | CommonErrors;
/**
 * Creates an object in a Directory. Additionally attaches the object to
 * a parent, if a parent reference and `LinkName` is specified. An object is simply a
 * collection of Facet attributes. You can also use this API call to create a
 * policy object, if the facet from which you create the object is a policy facet.
 */
export declare const createObject: API.OperationMethod<CreateObjectRequest, CreateObjectResponse, CreateObjectError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | SchemaAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a new schema in a development state. A schema can exist in three
 * phases:
 *
 * - *Development:* This is a mutable phase of the schema. All new
 * schemas are in the development phase. Once the schema is finalized, it can be
 * published.
 *
 * - *Published:* Published schemas are immutable and have a version
 * associated with them.
 *
 * - *Applied:* Applied schemas are mutable in a way that allows you
 * to add new schema facets. You can also add new, nonrequired attributes to existing schema
 * facets. You can apply only published schemas to directories.
 */
export declare const createSchema: API.OperationMethod<CreateSchemaRequest, CreateSchemaResponse, CreateSchemaError, Credentials | HttpClient.HttpClient>;
export type CreateTypedLinkFacetError = AccessDeniedException | FacetAlreadyExistsException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Creates a TypedLinkFacet. For more information, see Typed Links.
 */
export declare const createTypedLinkFacet: API.OperationMethod<CreateTypedLinkFacetRequest, CreateTypedLinkFacetResponse, CreateTypedLinkFacetError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectoryError = AccessDeniedException | DirectoryDeletedException | DirectoryNotDisabledException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes a directory. Only disabled directories can be deleted. A deleted directory cannot be undone. Exercise extreme
 * caution
 * when deleting directories.
 */
export declare const deleteDirectory: API.OperationMethod<DeleteDirectoryRequest, DeleteDirectoryResponse, DeleteDirectoryError, Credentials | HttpClient.HttpClient>;
export type DeleteFacetError = AccessDeniedException | FacetInUseException | FacetNotFoundException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes a given Facet. All attributes and Rules
 * that are associated with the facet will be deleted. Only development schema facets are allowed
 * deletion.
 */
export declare const deleteFacet: API.OperationMethod<DeleteFacetRequest, DeleteFacetResponse, DeleteFacetError, Credentials | HttpClient.HttpClient>;
export type DeleteObjectError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | ObjectNotDetachedException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes an object and its associated attributes. Only objects with no children and no
 * parents can be deleted. The maximum number of attributes that can be deleted during an object deletion is 30. For more information, see Amazon Cloud Directory Limits.
 */
export declare const deleteObject: API.OperationMethod<DeleteObjectRequest, DeleteObjectResponse, DeleteObjectError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | StillContainsLinksException | ValidationException | CommonErrors;
/**
 * Deletes a given schema. Schemas in a development and published state can only be deleted.
 */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaRequest, DeleteSchemaResponse, DeleteSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteTypedLinkFacetError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes a TypedLinkFacet. For more information, see Typed Links.
 */
export declare const deleteTypedLinkFacet: API.OperationMethod<DeleteTypedLinkFacetRequest, DeleteTypedLinkFacetResponse, DeleteTypedLinkFacetError, Credentials | HttpClient.HttpClient>;
export type DetachFromIndexError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotIndexException | ObjectAlreadyDetachedException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches the specified object from the specified index.
 */
export declare const detachFromIndex: API.OperationMethod<DetachFromIndexRequest, DetachFromIndexResponse, DetachFromIndexError, Credentials | HttpClient.HttpClient>;
export type DetachObjectError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotNodeException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches a given object from the parent object. The object that is to be detached from the
 * parent is specified by the link name.
 */
export declare const detachObject: API.OperationMethod<DetachObjectRequest, DetachObjectResponse, DetachObjectError, Credentials | HttpClient.HttpClient>;
export type DetachPolicyError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotPolicyException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches a policy from an object.
 */
export declare const detachPolicy: API.OperationMethod<DetachPolicyRequest, DetachPolicyResponse, DetachPolicyError, Credentials | HttpClient.HttpClient>;
export type DetachTypedLinkError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches a typed link from a specified source and target object. For more information, see Typed Links.
 */
export declare const detachTypedLink: API.OperationMethod<DetachTypedLinkRequest, DetachTypedLinkResponse, DetachTypedLinkError, Credentials | HttpClient.HttpClient>;
export type DisableDirectoryError = AccessDeniedException | DirectoryDeletedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Disables the specified directory. Disabled directories cannot be read or written to.
 * Only enabled directories can be disabled. Disabled directories may be reenabled.
 */
export declare const disableDirectory: API.OperationMethod<DisableDirectoryRequest, DisableDirectoryResponse, DisableDirectoryError, Credentials | HttpClient.HttpClient>;
export type EnableDirectoryError = AccessDeniedException | DirectoryDeletedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Enables the specified directory. Only disabled directories can be enabled. Once
 * enabled, the directory can then be read and written to.
 */
export declare const enableDirectory: API.OperationMethod<EnableDirectoryRequest, EnableDirectoryResponse, EnableDirectoryError, Credentials | HttpClient.HttpClient>;
export type GetAppliedSchemaVersionError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns current applied schema version ARN, including the minor version in use.
 */
export declare const getAppliedSchemaVersion: API.OperationMethod<GetAppliedSchemaVersionRequest, GetAppliedSchemaVersionResponse, GetAppliedSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type GetDirectoryError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves metadata about a directory.
 */
export declare const getDirectory: API.OperationMethod<GetDirectoryRequest, GetDirectoryResponse, GetDirectoryError, Credentials | HttpClient.HttpClient>;
export type GetFacetError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Gets details of the Facet, such as facet name, attributes, Rules, or `ObjectType`. You can call this on all kinds of schema
 * facets -- published, development, or applied.
 */
export declare const getFacet: API.OperationMethod<GetFacetRequest, GetFacetResponse, GetFacetError, Credentials | HttpClient.HttpClient>;
export type GetLinkAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves attributes that are associated with a typed link.
 */
export declare const getLinkAttributes: API.OperationMethod<GetLinkAttributesRequest, GetLinkAttributesResponse, GetLinkAttributesError, Credentials | HttpClient.HttpClient>;
export type GetObjectAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves attributes within a facet that are associated with an object.
 */
export declare const getObjectAttributes: API.OperationMethod<GetObjectAttributesRequest, GetObjectAttributesResponse, GetObjectAttributesError, Credentials | HttpClient.HttpClient>;
export type GetObjectInformationError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves metadata about an object.
 */
export declare const getObjectInformation: API.OperationMethod<GetObjectInformationRequest, GetObjectInformationResponse, GetObjectInformationError, Credentials | HttpClient.HttpClient>;
export type GetSchemaAsJsonError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves a JSON representation of the schema. See JSON Schema Format for more information.
 */
export declare const getSchemaAsJson: API.OperationMethod<GetSchemaAsJsonRequest, GetSchemaAsJsonResponse, GetSchemaAsJsonError, Credentials | HttpClient.HttpClient>;
export type GetTypedLinkFacetInformationError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns the identity attribute order for a specific TypedLinkFacet. For more information, see Typed Links.
 */
export declare const getTypedLinkFacetInformation: API.OperationMethod<GetTypedLinkFacetInformationRequest, GetTypedLinkFacetInformationResponse, GetTypedLinkFacetInformationError, Credentials | HttpClient.HttpClient>;
export type ListAppliedSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists schema major versions applied to a directory. If `SchemaArn` is provided, lists the minor version.
 */
export declare const listAppliedSchemaArns: API.PaginatedOperationMethod<ListAppliedSchemaArnsRequest, ListAppliedSchemaArnsResponse, ListAppliedSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAttachedIndicesError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists indices attached to the specified object.
 */
export declare const listAttachedIndices: API.PaginatedOperationMethod<ListAttachedIndicesRequest, ListAttachedIndicesResponse, ListAttachedIndicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDevelopmentSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves each Amazon Resource Name (ARN) of schemas in the development
 * state.
 */
export declare const listDevelopmentSchemaArns: API.PaginatedOperationMethod<ListDevelopmentSchemaArnsRequest, ListDevelopmentSchemaArnsResponse, ListDevelopmentSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDirectoriesError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists directories created within an account.
 */
export declare const listDirectories: API.PaginatedOperationMethod<ListDirectoriesRequest, ListDirectoriesResponse, ListDirectoriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFacetAttributesError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves attributes attached to the facet.
 */
export declare const listFacetAttributes: API.PaginatedOperationMethod<ListFacetAttributesRequest, ListFacetAttributesResponse, ListFacetAttributesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFacetNamesError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves the names of facets that exist in a schema.
 */
export declare const listFacetNames: API.PaginatedOperationMethod<ListFacetNamesRequest, ListFacetNamesResponse, ListFacetNamesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIncomingTypedLinksError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all the incoming TypedLinkSpecifier
 * information for an object. It also supports filtering by typed link facet and identity
 * attributes. For more information, see Typed Links.
 */
export declare const listIncomingTypedLinks: API.OperationMethod<ListIncomingTypedLinksRequest, ListIncomingTypedLinksResponse, ListIncomingTypedLinksError, Credentials | HttpClient.HttpClient>;
export type ListIndexError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | NotIndexException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists objects attached to the specified index.
 */
export declare const listIndex: API.PaginatedOperationMethod<ListIndexRequest, ListIndexResponse, ListIndexError, Credentials | HttpClient.HttpClient, unknown>;
export type ListManagedSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the major version families of each managed schema. If a major version ARN is provided as SchemaArn, the minor version revisions in that family are listed instead.
 */
export declare const listManagedSchemaArns: API.PaginatedOperationMethod<ListManagedSchemaArnsRequest, ListManagedSchemaArnsResponse, ListManagedSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists all attributes that are associated with an object.
 */
export declare const listObjectAttributes: API.PaginatedOperationMethod<ListObjectAttributesRequest, ListObjectAttributesResponse, ListObjectAttributesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectChildrenError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | NotNodeException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of child objects that are associated with a given
 * object.
 */
export declare const listObjectChildren: API.PaginatedOperationMethod<ListObjectChildrenRequest, ListObjectChildrenResponse, ListObjectChildrenError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectParentPathsError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves all available parent paths for any object type such as node, leaf node,
 * policy node, and index node objects. For more information about objects, see Directory Structure.
 *
 * Use this API to evaluate all parents for an object. The call returns all objects from
 * the root of the directory up to the requested object. The API returns the number of paths
 * based on user-defined `MaxResults`, in case there are multiple paths to the parent.
 * The order of the paths and nodes returned is consistent among multiple API calls unless the
 * objects are deleted or moved. Paths not leading to the directory root are ignored from the
 * target object.
 */
export declare const listObjectParentPaths: API.PaginatedOperationMethod<ListObjectParentPathsRequest, ListObjectParentPathsResponse, ListObjectParentPathsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectParentsError = AccessDeniedException | CannotListParentOfRootException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists parent objects that are associated with a given object in pagination
 * fashion.
 */
export declare const listObjectParents: API.PaginatedOperationMethod<ListObjectParentsRequest, ListObjectParentsResponse, ListObjectParentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectPoliciesError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns policies attached to an object in pagination fashion.
 */
export declare const listObjectPolicies: API.PaginatedOperationMethod<ListObjectPoliciesRequest, ListObjectPoliciesResponse, ListObjectPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOutgoingTypedLinksError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all the outgoing TypedLinkSpecifier
 * information for an object. It also supports filtering by typed link facet and identity
 * attributes. For more information, see Typed Links.
 */
export declare const listOutgoingTypedLinks: API.OperationMethod<ListOutgoingTypedLinksRequest, ListOutgoingTypedLinksResponse, ListOutgoingTypedLinksError, Credentials | HttpClient.HttpClient>;
export type ListPolicyAttachmentsError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | NotPolicyException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns all of the `ObjectIdentifiers` to which a given policy is attached.
 */
export declare const listPolicyAttachments: API.PaginatedOperationMethod<ListPolicyAttachmentsRequest, ListPolicyAttachmentsResponse, ListPolicyAttachmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPublishedSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists the major version families of each published schema. If a major version ARN is provided as `SchemaArn`, the minor version revisions in that family are listed instead.
 */
export declare const listPublishedSchemaArns: API.PaginatedOperationMethod<ListPublishedSchemaArnsRequest, ListPublishedSchemaArnsResponse, ListPublishedSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidTaggingRequestException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns tags for a resource. Tagging is currently supported only for directories with a
 * limit of 50 tags per directory. All 50 tags are returned for a given directory with this API
 * call.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTypedLinkFacetAttributesError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all attribute definitions for a particular TypedLinkFacet. For more information, see Typed Links.
 */
export declare const listTypedLinkFacetAttributes: API.PaginatedOperationMethod<ListTypedLinkFacetAttributesRequest, ListTypedLinkFacetAttributesResponse, ListTypedLinkFacetAttributesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTypedLinkFacetNamesError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of `TypedLink` facet names for a particular schema.
 * For more information, see Typed Links.
 */
export declare const listTypedLinkFacetNames: API.PaginatedOperationMethod<ListTypedLinkFacetNamesRequest, ListTypedLinkFacetNamesResponse, ListTypedLinkFacetNamesError, Credentials | HttpClient.HttpClient, unknown>;
export type LookupPolicyError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists all policies from the root of the Directory to the object
 * specified. If there are no policies present, an empty list is returned. If policies are
 * present, and if some objects don't have the policies attached, it returns the `ObjectIdentifier`
 * for such objects. If policies are present, it returns `ObjectIdentifier`, `policyId`, and
 * `policyType`. Paths that don't lead to the root from the target object are ignored. For more
 * information, see Policies.
 */
export declare const lookupPolicy: API.PaginatedOperationMethod<LookupPolicyRequest, LookupPolicyResponse, LookupPolicyError, Credentials | HttpClient.HttpClient, unknown>;
export type PublishSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | SchemaAlreadyPublishedException | ValidationException | CommonErrors;
/**
 * Publishes a development schema with a major version and a recommended minor version.
 */
export declare const publishSchema: API.OperationMethod<PublishSchemaRequest, PublishSchemaResponse, PublishSchemaError, Credentials | HttpClient.HttpClient>;
export type PutSchemaFromJsonError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidRuleException | InvalidSchemaDocException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Allows a schema to be updated using JSON upload. Only available for development schemas. See JSON Schema Format for more information.
 */
export declare const putSchemaFromJson: API.OperationMethod<PutSchemaFromJsonRequest, PutSchemaFromJsonResponse, PutSchemaFromJsonError, Credentials | HttpClient.HttpClient>;
export type RemoveFacetFromObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Removes the specified facet from the specified object.
 */
export declare const removeFacetFromObject: API.OperationMethod<RemoveFacetFromObjectRequest, RemoveFacetFromObjectResponse, RemoveFacetFromObjectError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidTaggingRequestException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * An API operation for adding tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidTaggingRequestException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * An API operation for removing tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFacetError = AccessDeniedException | FacetNotFoundException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidFacetUpdateException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Does the following:
 *
 * - Adds new `Attributes`, `Rules`, or `ObjectTypes`.
 *
 * - Updates existing `Attributes`, `Rules`, or `ObjectTypes`.
 *
 * - Deletes existing `Attributes`, `Rules`, or `ObjectTypes`.
 */
export declare const updateFacet: API.OperationMethod<UpdateFacetRequest, UpdateFacetResponse, UpdateFacetError, Credentials | HttpClient.HttpClient>;
export type UpdateLinkAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates a given typed link’s attributes. Attributes to be updated must not contribute to the typed link’s identity, as defined by its `IdentityAttributeOrder`.
 */
export declare const updateLinkAttributes: API.OperationMethod<UpdateLinkAttributesRequest, UpdateLinkAttributesResponse, UpdateLinkAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateObjectAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates a given object's attributes.
 */
export declare const updateObjectAttributes: API.OperationMethod<UpdateObjectAttributesRequest, UpdateObjectAttributesResponse, UpdateObjectAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates the schema name with a new name. Only development schema names can be
 * updated.
 */
export declare const updateSchema: API.OperationMethod<UpdateSchemaRequest, UpdateSchemaResponse, UpdateSchemaError, Credentials | HttpClient.HttpClient>;
export type UpdateTypedLinkFacetError = AccessDeniedException | FacetNotFoundException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidFacetUpdateException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates a TypedLinkFacet. For more information, see Typed Links.
 */
export declare const updateTypedLinkFacet: API.OperationMethod<UpdateTypedLinkFacetRequest, UpdateTypedLinkFacetResponse, UpdateTypedLinkFacetError, Credentials | HttpClient.HttpClient>;
export type UpgradeAppliedSchemaError = AccessDeniedException | IncompatibleSchemaException | InternalServiceException | InvalidArnException | InvalidAttachmentException | ResourceNotFoundException | RetryableConflictException | SchemaAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Upgrades a single directory in-place using the `PublishedSchemaArn` with schema updates found in `MinorVersion`. Backwards-compatible minor version upgrades are instantaneously available for readers on all objects in the directory. Note: This is a synchronous API call and upgrades only one schema on a given directory per call. To upgrade multiple directories from one schema, you would need to call this API on each directory.
 */
export declare const upgradeAppliedSchema: API.OperationMethod<UpgradeAppliedSchemaRequest, UpgradeAppliedSchemaResponse, UpgradeAppliedSchemaError, Credentials | HttpClient.HttpClient>;
export type UpgradePublishedSchemaError = AccessDeniedException | IncompatibleSchemaException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Upgrades a published schema under a new minor version revision using the current contents of `DevelopmentSchemaArn`.
 */
export declare const upgradePublishedSchema: API.OperationMethod<UpgradePublishedSchemaRequest, UpgradePublishedSchemaResponse, UpgradePublishedSchemaError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=clouddirectory.d.ts.map