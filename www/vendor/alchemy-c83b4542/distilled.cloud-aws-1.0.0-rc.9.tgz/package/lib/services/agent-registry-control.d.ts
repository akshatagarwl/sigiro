import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RegistryName = string;
export type Description = string | redacted.Redacted<string>;
export type DiscoveryUrl = string;
export type AllowedAudience = string;
export type AllowedAudienceList = string[];
export declare const AllowedAudienceList: any;
export type AllowedClient = string;
export type AllowedClientsList = string[];
export declare const AllowedClientsList: any;
export type AllowedScopeType = string;
export type AllowedScopesType = string[];
export declare const AllowedScopesType: any;
export type InboundTokenClaimNameType = string;
export type InboundTokenClaimValueType = "STRING" | "STRING_ARRAY" | (string & {});
export declare const InboundTokenClaimValueType: any;
export type MatchValueString = string;
export type MatchValueStringList = string[];
export declare const MatchValueStringList: any;
export type ClaimMatchValueType = {
    matchValueString: string;
    matchValueStringList?: never;
} | {
    matchValueString?: never;
    matchValueStringList: string[];
};
export declare const ClaimMatchValueType: any;
export type ClaimMatchOperatorType = "EQUALS" | "CONTAINS" | "CONTAINS_ANY" | (string & {});
export declare const ClaimMatchOperatorType: any;
export interface AuthorizingClaimMatchValueType {
    claimMatchValue: ClaimMatchValueType;
    claimMatchOperator: ClaimMatchOperatorType;
}
export declare const AuthorizingClaimMatchValueType: S.Schema<AuthorizingClaimMatchValueType>;
export interface CustomClaimValidationType {
    inboundTokenClaimName: string;
    inboundTokenClaimValueType: InboundTokenClaimValueType;
    authorizingClaimMatchValue: AuthorizingClaimMatchValueType;
}
export declare const CustomClaimValidationType: S.Schema<CustomClaimValidationType>;
export type CustomClaimValidationsType = CustomClaimValidationType[];
export declare const CustomClaimValidationsType: any;
export type ResourceConfigurationIdentifier = string;
export type SelfManagedLatticeResource = {
    resourceConfigurationIdentifier: string;
};
export declare const SelfManagedLatticeResource: any;
export type VpcIdentifier = string;
export type SubnetId = string;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export type EndpointIpAddressType = "IPV4" | "IPV6" | (string & {});
export declare const EndpointIpAddressType: any;
export type SecurityGroupIdentifier = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export type RoutingDomain = string;
export interface ManagedVpcResource {
    vpcIdentifier: string;
    subnetIds: string[];
    endpointIpAddressType: EndpointIpAddressType;
    securityGroupIds?: string[];
    tags?: {
        [key: string]: string | undefined;
    };
    routingDomain?: string;
}
export declare const ManagedVpcResource: S.Schema<ManagedVpcResource>;
export type PrivateEndpoint = {
    selfManagedLatticeResource: SelfManagedLatticeResource;
    managedVpcResource?: never;
} | {
    selfManagedLatticeResource?: never;
    managedVpcResource: ManagedVpcResource;
};
export declare const PrivateEndpoint: any;
export type PrivateEndpointOverrideDomain = string;
export interface PrivateEndpointOverride {
    domain: string;
    privateEndpoint: PrivateEndpoint;
}
export declare const PrivateEndpointOverride: S.Schema<PrivateEndpointOverride>;
export type PrivateEndpointOverrides = PrivateEndpointOverride[];
export declare const PrivateEndpointOverrides: any;
export interface CustomJWTAuthorizerConfiguration {
    discoveryUrl: string;
    allowedAudience?: string[];
    allowedClients?: string[];
    allowedScopes?: string[];
    customClaims?: CustomClaimValidationType[];
    privateEndpoint?: PrivateEndpoint;
    privateEndpointOverrides?: PrivateEndpointOverride[];
}
export declare const CustomJWTAuthorizerConfiguration: S.Schema<CustomJWTAuthorizerConfiguration>;
export type AuthorizerConfiguration = {
    customJWTAuthorizer: CustomJWTAuthorizerConfiguration;
};
export declare const AuthorizerConfiguration: any;
export type RegistryAuthorizerType = "CUSTOM_JWT" | "AWS_IAM" | (string & {});
export declare const RegistryAuthorizerType: any;
export interface DiscoveryConfiguration {
    authorizerConfiguration?: AuthorizerConfiguration;
    authorizerType?: RegistryAuthorizerType;
}
export declare const DiscoveryConfiguration: S.Schema<DiscoveryConfiguration>;
export type ClientToken = string;
export type AutoApprovalRule = "APPROVE_ALL" | (string & {});
export declare const AutoApprovalRule: any;
export type AutoApprovalRuleList = AutoApprovalRule[];
export declare const AutoApprovalRuleList: any;
export interface ApprovalConfiguration {
    autoApprovalRules?: AutoApprovalRule[];
}
export declare const ApprovalConfiguration: S.Schema<ApprovalConfiguration>;
export interface CreateRegistryRequest {
    name: string;
    description?: string | redacted.Redacted<string>;
    discoveryConfiguration?: DiscoveryConfiguration;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    approvalConfiguration?: ApprovalConfiguration;
}
export declare const CreateRegistryRequest: S.Schema<CreateRegistryRequest>;
export type RegistryArn = string;
export interface CreateRegistryResponse {
    registryArn: string;
}
export declare const CreateRegistryResponse: S.Schema<CreateRegistryResponse>;
export type RegistryIdentifier = string;
export type RegistryRecordName = string;
export type RegistryRecordDisplayName = string;
export type RecordType = "MCP" | "AGENT" | "CUSTOM" | "SKILL" | (string & {});
export declare const RecordType: any;
export type DescriptorData = string | redacted.Redacted<string>;
export type DataSchemaVersion = string;
export interface McpToolsDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
}
export declare const McpToolsDescriptor: S.Schema<McpToolsDescriptor>;
export interface McpServerAdditionalData {
    tools?: McpToolsDescriptor;
}
export declare const McpServerAdditionalData: S.Schema<McpServerAdditionalData>;
export type DescriptorSourceUrl = string;
export type RegistryRecordCredentialProviderType = "OAUTH" | "IAM" | (string & {});
export declare const RegistryRecordCredentialProviderType: any;
export type CredentialProviderArn = string;
export type RegistryRecordOAuthGrantType = "CLIENT_CREDENTIALS" | (string & {});
export declare const RegistryRecordOAuthGrantType: any;
export type ScopeList = string[];
export declare const ScopeList: any;
export type CustomParameterMap = {
    [key: string]: string | undefined;
};
export declare const CustomParameterMap: any;
export interface RegistryRecordOAuthCredentialProvider {
    providerArn: string;
    grantType?: RegistryRecordOAuthGrantType;
    scopes?: string[];
    customParameters?: {
        [key: string]: string | undefined;
    };
}
export declare const RegistryRecordOAuthCredentialProvider: S.Schema<RegistryRecordOAuthCredentialProvider>;
export type IamRoleArn = string;
export type IamSigningServiceName = string;
export type IamSigningRegion = string;
export interface RegistryRecordIamCredentialProvider {
    roleArn?: string;
    service?: string;
    region?: string;
}
export declare const RegistryRecordIamCredentialProvider: S.Schema<RegistryRecordIamCredentialProvider>;
export type RegistryRecordCredentialProviderUnion = {
    oauthCredentialProvider: RegistryRecordOAuthCredentialProvider;
    iamCredentialProvider?: never;
} | {
    oauthCredentialProvider?: never;
    iamCredentialProvider: RegistryRecordIamCredentialProvider;
};
export declare const RegistryRecordCredentialProviderUnion: any;
export interface RegistryRecordCredentialProviderConfiguration {
    credentialProviderType: RegistryRecordCredentialProviderType;
    credentialProvider: RegistryRecordCredentialProviderUnion;
}
export declare const RegistryRecordCredentialProviderConfiguration: S.Schema<RegistryRecordCredentialProviderConfiguration>;
export type RegistryRecordCredentialProviderConfigurationList = RegistryRecordCredentialProviderConfiguration[];
export declare const RegistryRecordCredentialProviderConfigurationList: any;
export interface DescriptorSourceFromUrl {
    url: string;
    credentialProviderConfigurations?: RegistryRecordCredentialProviderConfiguration[];
}
export declare const DescriptorSourceFromUrl: S.Schema<DescriptorSourceFromUrl>;
export interface DescriptorSource {
    fromUrl?: DescriptorSourceFromUrl;
}
export declare const DescriptorSource: S.Schema<DescriptorSource>;
export interface McpServerDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    additionalData?: McpServerAdditionalData;
    source?: DescriptorSource;
}
export declare const McpServerDescriptor: S.Schema<McpServerDescriptor>;
export interface A2aAgentCardDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    source?: DescriptorSource;
}
export declare const A2aAgentCardDescriptor: S.Schema<A2aAgentCardDescriptor>;
export interface AgentSkillsMdDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    source?: DescriptorSource;
}
export declare const AgentSkillsMdDescriptor: S.Schema<AgentSkillsMdDescriptor>;
export interface AgentSkillsAdditionalData {
    skillMd?: AgentSkillsMdDescriptor;
}
export declare const AgentSkillsAdditionalData: S.Schema<AgentSkillsAdditionalData>;
export interface AgentSkillsDefinitionDescriptor {
    data?: string | redacted.Redacted<string>;
    dataSchemaVersion?: string;
    additionalData?: AgentSkillsAdditionalData;
}
export declare const AgentSkillsDefinitionDescriptor: S.Schema<AgentSkillsDefinitionDescriptor>;
export interface CustomDescriptor {
    data?: string | redacted.Redacted<string>;
}
export declare const CustomDescriptor: S.Schema<CustomDescriptor>;
export interface Descriptors {
    mcpServer?: McpServerDescriptor;
    a2aAgentCard?: A2aAgentCardDescriptor;
    agentSkillsDefinition?: AgentSkillsDefinitionDescriptor;
    custom?: CustomDescriptor;
}
export declare const Descriptors: S.Schema<Descriptors>;
export type RegistryRecordVersion = string;
export interface CreateRegistryRecordRequest {
    registryId: string;
    name: string;
    displayName?: string;
    description?: string | redacted.Redacted<string>;
    recordType: RecordType;
    descriptors: Descriptors;
    recordVersion?: string;
    clientToken?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRegistryRecordRequest: S.Schema<CreateRegistryRecordRequest>;
export type RegistryRecordArn = string;
export type RegistryRecordStatus = "DRAFT" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "DEPRECATED" | "CREATING" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export declare const RegistryRecordStatus: any;
export interface CreateRegistryRecordResponse {
    recordArn: string;
    status: RegistryRecordStatus;
}
export declare const CreateRegistryRecordResponse: S.Schema<CreateRegistryRecordResponse>;
export interface DeleteRegistryRequest {
    registryId: string;
}
export declare const DeleteRegistryRequest: S.Schema<DeleteRegistryRequest>;
export type RegistryStatus = "CREATING" | "READY" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export declare const RegistryStatus: any;
export interface DeleteRegistryResponse {
    status: RegistryStatus;
}
export declare const DeleteRegistryResponse: S.Schema<DeleteRegistryResponse>;
export type RecordIdentifier = string;
export interface DeleteRegistryRecordRequest {
    registryId: string;
    recordId: string;
}
export declare const DeleteRegistryRecordRequest: S.Schema<DeleteRegistryRecordRequest>;
export interface DeleteRegistryRecordResponse {
}
export declare const DeleteRegistryRecordResponse: S.Schema<DeleteRegistryRecordResponse>;
export interface GetRegistryRequest {
    registryId: string;
}
export declare const GetRegistryRequest: S.Schema<GetRegistryRequest>;
export type RegistryId = string;
export interface GetRegistryResponse {
    name: string;
    description?: string | redacted.Redacted<string>;
    registryId: string;
    registryArn: string;
    discoveryConfiguration?: DiscoveryConfiguration;
    approvalConfiguration?: ApprovalConfiguration;
    status: RegistryStatus;
    statusReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const GetRegistryResponse: S.Schema<GetRegistryResponse>;
export interface GetRegistryRecordRequest {
    registryId: string;
    recordId: string;
}
export declare const GetRegistryRecordRequest: S.Schema<GetRegistryRecordRequest>;
export type RegistryRecordId = string;
export interface GetRegistryRecordResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    displayName?: string;
    description?: string | redacted.Redacted<string>;
    recordType: RecordType;
    descriptors?: Descriptors;
    recordVersion?: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    statusReason?: string;
}
export declare const GetRegistryRecordResponse: S.Schema<GetRegistryRecordResponse>;
export type MaxResults = number;
export type NextToken = string;
export type RegistryFilterName = "status" | "discoveryConfiguration.authorizerType" | (string & {});
export declare const RegistryFilterName: any;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export interface RegistryFilter {
    name: RegistryFilterName;
    values: string[];
}
export declare const RegistryFilter: S.Schema<RegistryFilter>;
export type RegistryFilterList = RegistryFilter[];
export declare const RegistryFilterList: any;
export interface ListRegistriesRequest {
    maxResults?: number;
    nextToken?: string;
    filters?: RegistryFilter[];
}
export declare const ListRegistriesRequest: S.Schema<ListRegistriesRequest>;
export interface RegistrySummary {
    name: string;
    description?: string | redacted.Redacted<string>;
    registryId: string;
    registryArn: string;
    discoveryConfiguration?: DiscoveryConfiguration;
    status: RegistryStatus;
    statusReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const RegistrySummary: S.Schema<RegistrySummary>;
export type RegistrySummaryList = RegistrySummary[];
export declare const RegistrySummaryList: any;
export interface ListRegistriesResponse {
    registries: RegistrySummary[];
    nextToken?: string;
}
export declare const ListRegistriesResponse: S.Schema<ListRegistriesResponse>;
export type RegistryRecordFilterName = "name" | "status" | "recordType" | (string & {});
export declare const RegistryRecordFilterName: any;
export interface RegistryRecordFilter {
    name: RegistryRecordFilterName;
    values: string[];
}
export declare const RegistryRecordFilter: S.Schema<RegistryRecordFilter>;
export type RegistryRecordFilterList = RegistryRecordFilter[];
export declare const RegistryRecordFilterList: any;
export interface ListRegistryRecordsRequest {
    registryId: string;
    maxResults?: number;
    nextToken?: string;
    filters?: RegistryRecordFilter[];
}
export declare const ListRegistryRecordsRequest: S.Schema<ListRegistryRecordsRequest>;
export interface RegistryRecordSummary {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    displayName?: string;
    description?: string | redacted.Redacted<string>;
    recordType: RecordType;
    recordVersion: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
}
export declare const RegistryRecordSummary: S.Schema<RegistryRecordSummary>;
export type RegistryRecordSummaryList = RegistryRecordSummary[];
export declare const RegistryRecordSummaryList: any;
export interface ListRegistryRecordsResponse {
    registryRecords: RegistryRecordSummary[];
    nextToken?: string;
}
export declare const ListRegistryRecordsResponse: S.Schema<ListRegistryRecordsResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type ResourceTagsMap = {
    [key: string]: string | undefined;
};
export declare const ResourceTagsMap: any;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface SubmitRegistryRecordForApprovalRequest {
    registryId: string;
    recordId: string;
}
export declare const SubmitRegistryRecordForApprovalRequest: S.Schema<SubmitRegistryRecordForApprovalRequest>;
export interface SubmitRegistryRecordForApprovalResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    status: RegistryRecordStatus;
    updatedAt: Date;
}
export declare const SubmitRegistryRecordForApprovalResponse: S.Schema<SubmitRegistryRecordForApprovalResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdatedDescription {
    optionalValue?: string | redacted.Redacted<string>;
}
export declare const UpdatedDescription: S.Schema<UpdatedDescription>;
export interface UpdatedAuthorizerConfiguration {
    optionalValue?: AuthorizerConfiguration;
}
export declare const UpdatedAuthorizerConfiguration: S.Schema<UpdatedAuthorizerConfiguration>;
export interface UpdatedDiscoveryConfiguration {
    authorizerConfiguration?: UpdatedAuthorizerConfiguration;
}
export declare const UpdatedDiscoveryConfiguration: S.Schema<UpdatedDiscoveryConfiguration>;
export interface UpdatedApprovalConfiguration {
    optionalValue?: ApprovalConfiguration;
}
export declare const UpdatedApprovalConfiguration: S.Schema<UpdatedApprovalConfiguration>;
export interface UpdateRegistryRequest {
    registryId: string;
    name?: string;
    description?: UpdatedDescription;
    discoveryConfiguration?: UpdatedDiscoveryConfiguration;
    approvalConfiguration?: UpdatedApprovalConfiguration;
}
export declare const UpdateRegistryRequest: S.Schema<UpdateRegistryRequest>;
export interface UpdateRegistryResponse {
    name: string;
    description?: string | redacted.Redacted<string>;
    registryId: string;
    registryArn: string;
    discoveryConfiguration?: DiscoveryConfiguration;
    approvalConfiguration?: ApprovalConfiguration;
    status: RegistryStatus;
    statusReason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const UpdateRegistryResponse: S.Schema<UpdateRegistryResponse>;
export interface UpdatedDisplayName {
    optionalValue?: string;
}
export declare const UpdatedDisplayName: S.Schema<UpdatedDisplayName>;
export interface UpdatedDescriptorData {
    optionalValue?: string | redacted.Redacted<string>;
}
export declare const UpdatedDescriptorData: S.Schema<UpdatedDescriptorData>;
export interface UpdatedDataSchemaVersion {
    optionalValue?: string;
}
export declare const UpdatedDataSchemaVersion: S.Schema<UpdatedDataSchemaVersion>;
export interface UpdatedDescriptorSource {
    optionalValue?: DescriptorSource;
}
export declare const UpdatedDescriptorSource: S.Schema<UpdatedDescriptorSource>;
export interface UpdatedMcpToolsDescriptorFields {
    data?: UpdatedDescriptorData;
    dataSchemaVersion?: UpdatedDataSchemaVersion;
}
export declare const UpdatedMcpToolsDescriptorFields: S.Schema<UpdatedMcpToolsDescriptorFields>;
export interface UpdatedMcpToolsDescriptor {
    optionalValue?: UpdatedMcpToolsDescriptorFields;
}
export declare const UpdatedMcpToolsDescriptor: S.Schema<UpdatedMcpToolsDescriptor>;
export interface UpdatedMcpServerAdditionalDataFields {
    tools?: UpdatedMcpToolsDescriptor;
}
export declare const UpdatedMcpServerAdditionalDataFields: S.Schema<UpdatedMcpServerAdditionalDataFields>;
export interface UpdatedMcpServerAdditionalData {
    optionalValue?: UpdatedMcpServerAdditionalDataFields;
}
export declare const UpdatedMcpServerAdditionalData: S.Schema<UpdatedMcpServerAdditionalData>;
export interface UpdatedMcpServerDescriptorFields {
    data?: UpdatedDescriptorData;
    dataSchemaVersion?: UpdatedDataSchemaVersion;
    source?: UpdatedDescriptorSource;
    additionalData?: UpdatedMcpServerAdditionalData;
}
export declare const UpdatedMcpServerDescriptorFields: S.Schema<UpdatedMcpServerDescriptorFields>;
export interface UpdatedMcpServerDescriptor {
    optionalValue?: UpdatedMcpServerDescriptorFields;
}
export declare const UpdatedMcpServerDescriptor: S.Schema<UpdatedMcpServerDescriptor>;
export interface UpdatedA2aAgentCardDescriptorFields {
    data?: UpdatedDescriptorData;
    dataSchemaVersion?: UpdatedDataSchemaVersion;
    source?: UpdatedDescriptorSource;
}
export declare const UpdatedA2aAgentCardDescriptorFields: S.Schema<UpdatedA2aAgentCardDescriptorFields>;
export interface UpdatedA2aAgentCardDescriptor {
    optionalValue?: UpdatedA2aAgentCardDescriptorFields;
}
export declare const UpdatedA2aAgentCardDescriptor: S.Schema<UpdatedA2aAgentCardDescriptor>;
export interface UpdatedAgentSkillsMdDescriptorFields {
    data?: UpdatedDescriptorData;
    dataSchemaVersion?: UpdatedDataSchemaVersion;
    source?: UpdatedDescriptorSource;
}
export declare const UpdatedAgentSkillsMdDescriptorFields: S.Schema<UpdatedAgentSkillsMdDescriptorFields>;
export interface UpdatedAgentSkillsMdDescriptor {
    optionalValue?: UpdatedAgentSkillsMdDescriptorFields;
}
export declare const UpdatedAgentSkillsMdDescriptor: S.Schema<UpdatedAgentSkillsMdDescriptor>;
export interface UpdatedAgentSkillsAdditionalDataFields {
    skillMd?: UpdatedAgentSkillsMdDescriptor;
}
export declare const UpdatedAgentSkillsAdditionalDataFields: S.Schema<UpdatedAgentSkillsAdditionalDataFields>;
export interface UpdatedAgentSkillsAdditionalData {
    optionalValue?: UpdatedAgentSkillsAdditionalDataFields;
}
export declare const UpdatedAgentSkillsAdditionalData: S.Schema<UpdatedAgentSkillsAdditionalData>;
export interface UpdatedAgentSkillsDefinitionDescriptorFields {
    data?: UpdatedDescriptorData;
    dataSchemaVersion?: UpdatedDataSchemaVersion;
    additionalData?: UpdatedAgentSkillsAdditionalData;
}
export declare const UpdatedAgentSkillsDefinitionDescriptorFields: S.Schema<UpdatedAgentSkillsDefinitionDescriptorFields>;
export interface UpdatedAgentSkillsDefinitionDescriptor {
    optionalValue?: UpdatedAgentSkillsDefinitionDescriptorFields;
}
export declare const UpdatedAgentSkillsDefinitionDescriptor: S.Schema<UpdatedAgentSkillsDefinitionDescriptor>;
export interface UpdatedCustomDescriptorFields {
    data?: UpdatedDescriptorData;
}
export declare const UpdatedCustomDescriptorFields: S.Schema<UpdatedCustomDescriptorFields>;
export interface UpdatedCustomDescriptor {
    optionalValue?: UpdatedCustomDescriptorFields;
}
export declare const UpdatedCustomDescriptor: S.Schema<UpdatedCustomDescriptor>;
export interface UpdatedDescriptorsFields {
    mcpServer?: UpdatedMcpServerDescriptor;
    a2aAgentCard?: UpdatedA2aAgentCardDescriptor;
    agentSkillsDefinition?: UpdatedAgentSkillsDefinitionDescriptor;
    custom?: UpdatedCustomDescriptor;
}
export declare const UpdatedDescriptorsFields: S.Schema<UpdatedDescriptorsFields>;
export interface UpdatedDescriptors {
    optionalValue?: UpdatedDescriptorsFields;
}
export declare const UpdatedDescriptors: S.Schema<UpdatedDescriptors>;
export interface UpdateRegistryRecordRequest {
    registryId: string;
    recordId: string;
    name?: string;
    displayName?: UpdatedDisplayName;
    description?: UpdatedDescription;
    recordType?: RecordType;
    descriptors?: UpdatedDescriptors;
    recordVersion?: string;
    triggerSynchronization?: boolean;
}
export declare const UpdateRegistryRecordRequest: S.Schema<UpdateRegistryRecordRequest>;
export interface UpdateRegistryRecordResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    name: string;
    displayName?: string;
    description?: string | redacted.Redacted<string>;
    recordType: RecordType;
    descriptors?: Descriptors;
    recordVersion?: string;
    status: RegistryRecordStatus;
    createdAt: Date;
    updatedAt: Date;
    statusReason?: string;
}
export declare const UpdateRegistryRecordResponse: S.Schema<UpdateRegistryRecordResponse>;
export interface UpdateRegistryRecordStatusRequest {
    registryId: string;
    recordId: string;
    status: RegistryRecordStatus;
    statusReason: string;
}
export declare const UpdateRegistryRecordStatusRequest: S.Schema<UpdateRegistryRecordStatusRequest>;
export interface UpdateRegistryRecordStatusResponse {
    registryArn: string;
    recordArn: string;
    recordId: string;
    status: RegistryRecordStatus;
    statusReason: string;
    updatedAt: Date;
}
export declare const UpdateRegistryRecordStatusResponse: S.Schema<UpdateRegistryRecordStatusResponse>;
export type NonBlankString = string;
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "IdempotentParameterMismatchException" | "EventInOtherSession" | "ResourceConflict" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type CreateRegistryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new registry, a catalog that organizes registry records and defines their discovery authorization and record approval behavior. Creation is asynchronous: the registry begins in the CREATING status and becomes usable once it reaches READY.
 */
export declare const createRegistry: API.OperationMethod<CreateRegistryRequest, CreateRegistryResponse, CreateRegistryError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a registry record within a registry. A registry record describes a discoverable resource, such as an MCP server, an agent, an agent skill, or a custom resource. Creation is asynchronous: the record is returned with the CREATING status while it is processed.
 */
export declare const createRegistryRecord: API.OperationMethod<CreateRegistryRecordRequest, CreateRegistryRecordResponse, CreateRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a registry. Deletion is asynchronous: the registry transitions to the DELETING status and is removed along with its registry records.
 */
export declare const deleteRegistry: API.OperationMethod<DeleteRegistryRequest, DeleteRegistryResponse, DeleteRegistryError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a registry record
 */
export declare const deleteRegistryRecord: API.OperationMethod<DeleteRegistryRecordRequest, DeleteRegistryRecordResponse, DeleteRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type GetRegistryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a registry by identifier (ARN or ID)
 */
export declare const getRegistry: API.OperationMethod<GetRegistryRequest, GetRegistryResponse, GetRegistryError, Credentials | HttpClient.HttpClient>;
export type GetRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a registry record
 */
export declare const getRegistryRecord: API.OperationMethod<GetRegistryRecordRequest, GetRegistryRecordResponse, GetRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type ListRegistriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the registries in the caller's account and Region, with optional filtering by status and discovery authorizer type
 */
export declare const listRegistries: API.PaginatedOperationMethod<ListRegistriesRequest, ListRegistriesResponse, ListRegistriesError, Credentials | HttpClient.HttpClient, RegistrySummary>;
export type ListRegistryRecordsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the registry records within a registry, with optional filtering by name, status, and record type
 */
export declare const listRegistryRecords: API.PaginatedOperationMethod<ListRegistryRecordsRequest, ListRegistryRecordsResponse, ListRegistryRecordsError, Credentials | HttpClient.HttpClient, RegistryRecordSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the tags on a resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SubmitRegistryRecordForApprovalError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits a DRAFT registry record for approval, moving it into the registry's approval workflow. Depending on the registry's approval configuration, the record is either auto-approved or set to PENDING_APPROVAL for a curator to approve or reject.
 */
export declare const submitRegistryRecordForApproval: API.OperationMethod<SubmitRegistryRecordForApprovalRequest, SubmitRegistryRecordForApprovalResponse, SubmitRegistryRecordForApprovalError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag a resource with key-value pairs
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource by key
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing registry. This operation uses PATCH semantics: specify only the fields you want to change, and omit the rest to leave them unchanged. Updates are applied asynchronously and the registry transitions to the UPDATING status while they are processed.
 */
export declare const updateRegistry: API.OperationMethod<UpdateRegistryRequest, UpdateRegistryResponse, UpdateRegistryError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryRecordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a registry record. The update is asynchronous: the record is returned with the UPDATING status while it is processed. Fields that use update wrappers follow PATCH semantics: omit the field to leave it unchanged.
 */
export declare const updateRegistryRecord: API.OperationMethod<UpdateRegistryRecordRequest, UpdateRegistryRecordResponse, UpdateRegistryRecordError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryRecordStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of a registry record as part of the registry's curation workflow, for example to approve or reject a record that is pending approval, or to deprecate an approved record so that it is no longer discoverable
 */
export declare const updateRegistryRecordStatus: API.OperationMethod<UpdateRegistryRecordStatusRequest, UpdateRegistryRecordStatusResponse, UpdateRegistryRecordStatusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=agent-registry-control.d.ts.map