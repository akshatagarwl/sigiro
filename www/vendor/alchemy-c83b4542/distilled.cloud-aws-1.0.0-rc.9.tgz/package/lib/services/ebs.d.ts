import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentLimitExceededException_base: S.Class<ConcurrentLimitExceededException, S.TaggedStruct<"ConcurrentLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentLimitExceededException extends /*@__PURE__*/ ConcurrentLimitExceededException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidSignatureException_base: S.Class<InvalidSignatureException, S.TaggedStruct<"InvalidSignatureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSignatureException extends /*@__PURE__*/ InvalidSignatureException_base {
}
declare const RequestThrottledException_base: S.Class<RequestThrottledException, S.TaggedStruct<"RequestThrottledException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestThrottledException extends /*@__PURE__*/ RequestThrottledException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SnapshotId = string;
export type ChangedBlocksCount = number;
export type Checksum = string;
export type ChecksumAlgorithm = "SHA256" | (string & {});
export declare const ChecksumAlgorithm: any;
export type ChecksumAggregationMethod = "LINEAR" | (string & {});
export declare const ChecksumAggregationMethod: any;
export interface CompleteSnapshotRequest {
    SnapshotId: string;
    ChangedBlocksCount: number;
    Checksum?: string;
    ChecksumAlgorithm?: ChecksumAlgorithm;
    ChecksumAggregationMethod?: ChecksumAggregationMethod;
}
export declare const CompleteSnapshotRequest: S.Schema<CompleteSnapshotRequest>;
export type Status = "completed" | "pending" | "error" | (string & {});
export declare const Status: any;
export interface CompleteSnapshotResponse {
    Status?: Status;
}
export declare const CompleteSnapshotResponse: S.Schema<CompleteSnapshotResponse>;
export type BlockIndex = number;
export type BlockToken = string;
export interface GetSnapshotBlockRequest {
    SnapshotId: string;
    BlockIndex: number;
    BlockToken: string;
}
export declare const GetSnapshotBlockRequest: S.Schema<GetSnapshotBlockRequest>;
export type DataLength = number;
export interface GetSnapshotBlockResponse {
    DataLength?: number;
    BlockData?: T.StreamingOutputBody;
    Checksum?: string;
    ChecksumAlgorithm?: ChecksumAlgorithm;
}
export declare const GetSnapshotBlockResponse: S.Schema<GetSnapshotBlockResponse>;
export type PageToken = string;
export type MaxResults = number;
export interface ListChangedBlocksRequest {
    FirstSnapshotId?: string;
    SecondSnapshotId: string;
    NextToken?: string;
    MaxResults?: number;
    StartingBlockIndex?: number;
}
export declare const ListChangedBlocksRequest: S.Schema<ListChangedBlocksRequest>;
export interface ChangedBlock {
    BlockIndex?: number;
    FirstBlockToken?: string;
    SecondBlockToken?: string;
}
export declare const ChangedBlock: S.Schema<ChangedBlock>;
export type ChangedBlocks = ChangedBlock[];
export declare const ChangedBlocks: any;
export type VolumeSize = number;
export type BlockSize = number;
export interface ListChangedBlocksResponse {
    ChangedBlocks?: ChangedBlock[];
    ExpiryTime?: Date;
    VolumeSize?: number;
    BlockSize?: number;
    NextToken?: string;
}
export declare const ListChangedBlocksResponse: S.Schema<ListChangedBlocksResponse>;
export interface ListSnapshotBlocksRequest {
    SnapshotId: string;
    NextToken?: string;
    MaxResults?: number;
    StartingBlockIndex?: number;
}
export declare const ListSnapshotBlocksRequest: S.Schema<ListSnapshotBlocksRequest>;
export interface Block {
    BlockIndex?: number;
    BlockToken?: string;
}
export declare const Block: S.Schema<Block>;
export type Blocks = Block[];
export declare const Blocks: any;
export interface ListSnapshotBlocksResponse {
    Blocks?: Block[];
    ExpiryTime?: Date;
    VolumeSize?: number;
    BlockSize?: number;
    NextToken?: string;
}
export declare const ListSnapshotBlocksResponse: S.Schema<ListSnapshotBlocksResponse>;
export type Progress = number;
export interface PutSnapshotBlockRequest {
    SnapshotId: string;
    BlockIndex: number;
    BlockData: T.StreamingInputBody;
    DataLength: number;
    Progress?: number;
    Checksum: string;
    ChecksumAlgorithm: ChecksumAlgorithm;
}
export declare const PutSnapshotBlockRequest: S.Schema<PutSnapshotBlockRequest>;
export interface PutSnapshotBlockResponse {
    Checksum?: string;
    ChecksumAlgorithm?: ChecksumAlgorithm;
}
export declare const PutSnapshotBlockResponse: S.Schema<PutSnapshotBlockResponse>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export type Description = string;
export type IdempotencyToken = string;
export type KmsKeyArn = string | redacted.Redacted<string>;
export type Timeout = number;
export interface StartSnapshotRequest {
    VolumeSize: number;
    ParentSnapshotId?: string;
    Tags?: Tag[];
    Description?: string;
    ClientToken?: string;
    Encrypted?: boolean;
    KmsKeyArn?: string | redacted.Redacted<string>;
    Timeout?: number;
}
export declare const StartSnapshotRequest: S.Schema<StartSnapshotRequest>;
export type OwnerId = string;
export type SSEType = "sse-ebs" | "sse-kms" | "none" | (string & {});
export declare const SSEType: any;
export interface StartSnapshotResponse {
    Description?: string;
    SnapshotId?: string;
    OwnerId?: string;
    Status?: Status;
    StartTime?: Date;
    VolumeSize?: number;
    BlockSize?: number;
    Tags?: Tag[];
    ParentSnapshotId?: string;
    KmsKeyArn?: string | redacted.Redacted<string>;
    SseType?: SSEType;
}
export declare const StartSnapshotResponse: S.Schema<StartSnapshotResponse>;
export type ErrorMessage = string;
export type AccessDeniedExceptionReason = "UNAUTHORIZED_ACCOUNT" | "DEPENDENCY_ACCESS_DENIED" | (string & {});
export declare const AccessDeniedExceptionReason: any;
export type RequestThrottledExceptionReason = "ACCOUNT_THROTTLED" | "DEPENDENCY_REQUEST_THROTTLED" | "RESOURCE_LEVEL_THROTTLE" | (string & {});
export declare const RequestThrottledExceptionReason: any;
export type ResourceNotFoundExceptionReason = "SNAPSHOT_NOT_FOUND" | "GRANT_NOT_FOUND" | "DEPENDENCY_RESOURCE_NOT_FOUND" | "IMAGE_NOT_FOUND" | (string & {});
export declare const ResourceNotFoundExceptionReason: any;
export type ServiceQuotaExceededExceptionReason = "DEPENDENCY_SERVICE_QUOTA_EXCEEDED" | (string & {});
export declare const ServiceQuotaExceededExceptionReason: any;
export type ValidationExceptionReason = "INVALID_CUSTOMER_KEY" | "INVALID_PAGE_TOKEN" | "INVALID_BLOCK_TOKEN" | "INVALID_GRANT_TOKEN" | "INVALID_SNAPSHOT_ID" | "UNRELATED_SNAPSHOTS" | "INVALID_BLOCK" | "INVALID_CONTENT_ENCODING" | "INVALID_TAG" | "INVALID_DEPENDENCY_REQUEST" | "INVALID_PARAMETER_VALUE" | "INVALID_VOLUME_SIZE" | "CONFLICTING_BLOCK_UPDATE" | "INVALID_IMAGE_ID" | "WRITE_REQUEST_TIMEOUT" | (string & {});
export declare const ValidationExceptionReason: any;
export type CompleteSnapshotError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | InvalidSignatureException | CommonErrors;
/**
 * Seals and completes the snapshot after all of the required blocks of data have been
 * written to it. Completing the snapshot changes the status to `completed`. You
 * cannot write new blocks to a snapshot after it has been completed.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const completeSnapshot: API.OperationMethod<CompleteSnapshotRequest, CompleteSnapshotResponse, CompleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetSnapshotBlockError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns the data in a block in an Amazon Elastic Block Store snapshot.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const getSnapshotBlock: API.OperationMethod<GetSnapshotBlockRequest, GetSnapshotBlockResponse, GetSnapshotBlockError, Credentials | HttpClient.HttpClient>;
export type ListChangedBlocksError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns information about the blocks that are different between two
 * Amazon Elastic Block Store snapshots of the same volume/snapshot lineage.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const listChangedBlocks: API.PaginatedOperationMethod<ListChangedBlocksRequest, ListChangedBlocksResponse, ListChangedBlocksError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSnapshotBlocksError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns information about the blocks in an Amazon Elastic Block Store snapshot.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const listSnapshotBlocks: API.PaginatedOperationMethod<ListSnapshotBlocksRequest, ListSnapshotBlocksResponse, ListSnapshotBlocksError, Credentials | HttpClient.HttpClient, unknown>;
export type PutSnapshotBlockError = AccessDeniedException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | InvalidSignatureException | CommonErrors;
/**
 * Writes a block of data to a snapshot. If the specified block contains
 * data, the existing data is overwritten. The target snapshot must be in the
 * `pending` state.
 *
 * Data written to a snapshot must be aligned with 512-KiB sectors.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const putSnapshotBlock: API.OperationMethod<PutSnapshotBlockRequest, PutSnapshotBlockResponse, PutSnapshotBlockError, Credentials | HttpClient.HttpClient>;
export type StartSnapshotError = AccessDeniedException | ConcurrentLimitExceededException | ConflictException | InternalServerException | RequestThrottledException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new Amazon EBS snapshot. The new snapshot enters the `pending` state
 * after the request completes.
 *
 * After creating the snapshot, use PutSnapshotBlock to
 * write blocks of data to the snapshot.
 *
 * You should always retry requests that receive server (`5xx`)
 * error responses, and `ThrottlingException` and `RequestThrottledException`
 * client error responses. For more information see Error retries in the
 * *Amazon Elastic Compute Cloud User Guide*.
 */
export declare const startSnapshot: API.OperationMethod<StartSnapshotRequest, StartSnapshotResponse, StartSnapshotError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ebs.d.ts.map