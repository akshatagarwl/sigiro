import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type BlueprintArn = string;
export type BlueprintStage = "DEVELOPMENT" | "LIVE" | (string & {});
export declare const BlueprintStage: any;
export type ClientToken = string;
export interface CopyBlueprintStageRequest {
    blueprintArn: string;
    sourceStage: BlueprintStage;
    targetStage: BlueprintStage;
    clientToken?: string;
}
export declare const CopyBlueprintStageRequest: S.Schema<CopyBlueprintStageRequest>;
export interface CopyBlueprintStageResponse {
}
export declare const CopyBlueprintStageResponse: S.Schema<CopyBlueprintStageResponse>;
export type BlueprintName = string | redacted.Redacted<string>;
export type Type = "DOCUMENT" | "IMAGE" | "AUDIO" | "VIDEO" | (string & {});
export declare const Type: any;
export type BlueprintSchema = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type KmsEncryptionContext = {
    [key: string]: string | undefined;
};
export declare const KmsEncryptionContext: any;
export interface EncryptionConfiguration {
    kmsKeyId: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateBlueprintRequest {
    blueprintName: string | redacted.Redacted<string>;
    type: Type;
    blueprintStage?: BlueprintStage;
    schema: string | redacted.Redacted<string>;
    clientToken?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export declare const CreateBlueprintRequest: S.Schema<CreateBlueprintRequest>;
export type BlueprintVersion = string;
export type S3Uri = string;
export type S3ObjectVersion = string;
export interface S3Object {
    s3Uri: string;
    version?: string;
}
export declare const S3Object: S.Schema<S3Object>;
export interface BlueprintOptimizationSample {
    assetS3Object: S3Object;
    groundTruthS3Object: S3Object;
}
export declare const BlueprintOptimizationSample: S.Schema<BlueprintOptimizationSample>;
export type BlueprintOptimizationSamples = BlueprintOptimizationSample[];
export declare const BlueprintOptimizationSamples: any;
export interface Blueprint {
    blueprintArn: string;
    schema: string | redacted.Redacted<string>;
    type: Type;
    creationTime: Date;
    lastModifiedTime: Date;
    blueprintName: string | redacted.Redacted<string>;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
    kmsKeyId?: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
    optimizationSamples?: BlueprintOptimizationSample[];
    optimizationTime?: Date;
}
export declare const Blueprint: S.Schema<Blueprint>;
export interface CreateBlueprintResponse {
    blueprint: Blueprint;
}
export declare const CreateBlueprintResponse: S.Schema<CreateBlueprintResponse>;
export interface CreateBlueprintVersionRequest {
    blueprintArn: string;
    clientToken?: string;
}
export declare const CreateBlueprintVersionRequest: S.Schema<CreateBlueprintVersionRequest>;
export interface CreateBlueprintVersionResponse {
    blueprint: Blueprint;
}
export declare const CreateBlueprintVersionResponse: S.Schema<CreateBlueprintVersionResponse>;
export type DataAutomationLibraryName = string | redacted.Redacted<string>;
export type DataAutomationLibraryDescription = string | redacted.Redacted<string>;
export interface CreateDataAutomationLibraryRequest {
    libraryName: string | redacted.Redacted<string>;
    libraryDescription?: string | redacted.Redacted<string>;
    clientToken?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export declare const CreateDataAutomationLibraryRequest: S.Schema<CreateDataAutomationLibraryRequest>;
export type DataAutomationLibraryArn = string;
export type DataAutomationLibraryStatus = "ACTIVE" | "DELETING" | (string & {});
export declare const DataAutomationLibraryStatus: any;
export interface CreateDataAutomationLibraryResponse {
    libraryArn?: string;
    status?: DataAutomationLibraryStatus;
}
export declare const CreateDataAutomationLibraryResponse: S.Schema<CreateDataAutomationLibraryResponse>;
export type DataAutomationProjectName = string | redacted.Redacted<string>;
export type DataAutomationProjectDescription = string | redacted.Redacted<string>;
export type DataAutomationProjectStage = "DEVELOPMENT" | "LIVE" | (string & {});
export declare const DataAutomationProjectStage: any;
export type DataAutomationProjectType = "ASYNC" | "SYNC" | (string & {});
export declare const DataAutomationProjectType: any;
export type DocumentExtractionGranularityType = "DOCUMENT" | "PAGE" | "ELEMENT" | "WORD" | "LINE" | (string & {});
export declare const DocumentExtractionGranularityType: any;
export type DocumentExtractionGranularityTypes = DocumentExtractionGranularityType[];
export declare const DocumentExtractionGranularityTypes: any;
export interface DocumentExtractionGranularity {
    types?: DocumentExtractionGranularityType[];
}
export declare const DocumentExtractionGranularity: S.Schema<DocumentExtractionGranularity>;
export type State = "ENABLED" | "DISABLED" | (string & {});
export declare const State: any;
export interface DocumentBoundingBox {
    state: State;
}
export declare const DocumentBoundingBox: S.Schema<DocumentBoundingBox>;
export interface DocumentStandardExtraction {
    granularity: DocumentExtractionGranularity;
    boundingBox: DocumentBoundingBox;
}
export declare const DocumentStandardExtraction: S.Schema<DocumentStandardExtraction>;
export interface DocumentStandardGenerativeField {
    state: State;
}
export declare const DocumentStandardGenerativeField: S.Schema<DocumentStandardGenerativeField>;
export type DocumentOutputTextFormatType = "PLAIN_TEXT" | "MARKDOWN" | "HTML" | "CSV" | (string & {});
export declare const DocumentOutputTextFormatType: any;
export type DocumentOutputTextFormatTypes = DocumentOutputTextFormatType[];
export declare const DocumentOutputTextFormatTypes: any;
export interface DocumentOutputTextFormat {
    types?: DocumentOutputTextFormatType[];
}
export declare const DocumentOutputTextFormat: S.Schema<DocumentOutputTextFormat>;
export interface DocumentOutputAdditionalFileFormat {
    state: State;
}
export declare const DocumentOutputAdditionalFileFormat: S.Schema<DocumentOutputAdditionalFileFormat>;
export interface DocumentOutputFormat {
    textFormat: DocumentOutputTextFormat;
    additionalFileFormat: DocumentOutputAdditionalFileFormat;
}
export declare const DocumentOutputFormat: S.Schema<DocumentOutputFormat>;
export interface DocumentStandardOutputConfiguration {
    extraction?: DocumentStandardExtraction;
    generativeField?: DocumentStandardGenerativeField;
    outputFormat?: DocumentOutputFormat;
}
export declare const DocumentStandardOutputConfiguration: S.Schema<DocumentStandardOutputConfiguration>;
export type ImageExtractionCategoryType = "CONTENT_MODERATION" | "TEXT_DETECTION" | "LOGOS" | (string & {});
export declare const ImageExtractionCategoryType: any;
export type ImageExtractionCategoryTypes = ImageExtractionCategoryType[];
export declare const ImageExtractionCategoryTypes: any;
export interface ImageExtractionCategory {
    state: State;
    types?: ImageExtractionCategoryType[];
}
export declare const ImageExtractionCategory: S.Schema<ImageExtractionCategory>;
export interface ImageBoundingBox {
    state: State;
}
export declare const ImageBoundingBox: S.Schema<ImageBoundingBox>;
export interface ImageStandardExtraction {
    category: ImageExtractionCategory;
    boundingBox: ImageBoundingBox;
}
export declare const ImageStandardExtraction: S.Schema<ImageStandardExtraction>;
export type ImageStandardGenerativeFieldType = "IMAGE_SUMMARY" | "IAB" | (string & {});
export declare const ImageStandardGenerativeFieldType: any;
export type ImageStandardGenerativeFieldTypes = ImageStandardGenerativeFieldType[];
export declare const ImageStandardGenerativeFieldTypes: any;
export interface ImageStandardGenerativeField {
    state: State;
    types?: ImageStandardGenerativeFieldType[];
}
export declare const ImageStandardGenerativeField: S.Schema<ImageStandardGenerativeField>;
export interface ImageStandardOutputConfiguration {
    extraction?: ImageStandardExtraction;
    generativeField?: ImageStandardGenerativeField;
}
export declare const ImageStandardOutputConfiguration: S.Schema<ImageStandardOutputConfiguration>;
export type VideoExtractionCategoryType = "CONTENT_MODERATION" | "TEXT_DETECTION" | "TRANSCRIPT" | "LOGOS" | (string & {});
export declare const VideoExtractionCategoryType: any;
export type VideoExtractionCategoryTypes = VideoExtractionCategoryType[];
export declare const VideoExtractionCategoryTypes: any;
export interface VideoExtractionCategory {
    state: State;
    types?: VideoExtractionCategoryType[];
}
export declare const VideoExtractionCategory: S.Schema<VideoExtractionCategory>;
export interface VideoBoundingBox {
    state: State;
}
export declare const VideoBoundingBox: S.Schema<VideoBoundingBox>;
export interface VideoStandardExtraction {
    category: VideoExtractionCategory;
    boundingBox: VideoBoundingBox;
}
export declare const VideoStandardExtraction: S.Schema<VideoStandardExtraction>;
export type VideoStandardGenerativeFieldType = "VIDEO_SUMMARY" | "IAB" | "CHAPTER_SUMMARY" | (string & {});
export declare const VideoStandardGenerativeFieldType: any;
export type VideoStandardGenerativeFieldTypes = VideoStandardGenerativeFieldType[];
export declare const VideoStandardGenerativeFieldTypes: any;
export interface VideoStandardGenerativeField {
    state: State;
    types?: VideoStandardGenerativeFieldType[];
}
export declare const VideoStandardGenerativeField: S.Schema<VideoStandardGenerativeField>;
export interface VideoStandardOutputConfiguration {
    extraction?: VideoStandardExtraction;
    generativeField?: VideoStandardGenerativeField;
}
export declare const VideoStandardOutputConfiguration: S.Schema<VideoStandardOutputConfiguration>;
export type AudioExtractionCategoryType = "AUDIO_CONTENT_MODERATION" | "TRANSCRIPT" | "TOPIC_CONTENT_MODERATION" | (string & {});
export declare const AudioExtractionCategoryType: any;
export type AudioExtractionCategoryTypes = AudioExtractionCategoryType[];
export declare const AudioExtractionCategoryTypes: any;
export interface SpeakerLabelingConfiguration {
    state: State;
}
export declare const SpeakerLabelingConfiguration: S.Schema<SpeakerLabelingConfiguration>;
export interface ChannelLabelingConfiguration {
    state: State;
}
export declare const ChannelLabelingConfiguration: S.Schema<ChannelLabelingConfiguration>;
export interface TranscriptConfiguration {
    speakerLabeling?: SpeakerLabelingConfiguration;
    channelLabeling?: ChannelLabelingConfiguration;
}
export declare const TranscriptConfiguration: S.Schema<TranscriptConfiguration>;
export interface AudioExtractionCategoryTypeConfiguration {
    transcript?: TranscriptConfiguration;
}
export declare const AudioExtractionCategoryTypeConfiguration: S.Schema<AudioExtractionCategoryTypeConfiguration>;
export interface AudioExtractionCategory {
    state: State;
    types?: AudioExtractionCategoryType[];
    typeConfiguration?: AudioExtractionCategoryTypeConfiguration;
}
export declare const AudioExtractionCategory: S.Schema<AudioExtractionCategory>;
export interface AudioStandardExtraction {
    category: AudioExtractionCategory;
}
export declare const AudioStandardExtraction: S.Schema<AudioStandardExtraction>;
export type AudioStandardGenerativeFieldType = "AUDIO_SUMMARY" | "IAB" | "TOPIC_SUMMARY" | (string & {});
export declare const AudioStandardGenerativeFieldType: any;
export type AudioStandardGenerativeFieldTypes = AudioStandardGenerativeFieldType[];
export declare const AudioStandardGenerativeFieldTypes: any;
export interface AudioStandardGenerativeField {
    state: State;
    types?: AudioStandardGenerativeFieldType[];
}
export declare const AudioStandardGenerativeField: S.Schema<AudioStandardGenerativeField>;
export interface AudioStandardOutputConfiguration {
    extraction?: AudioStandardExtraction;
    generativeField?: AudioStandardGenerativeField;
}
export declare const AudioStandardOutputConfiguration: S.Schema<AudioStandardOutputConfiguration>;
export interface StandardOutputConfiguration {
    document?: DocumentStandardOutputConfiguration;
    image?: ImageStandardOutputConfiguration;
    video?: VideoStandardOutputConfiguration;
    audio?: AudioStandardOutputConfiguration;
}
export declare const StandardOutputConfiguration: S.Schema<StandardOutputConfiguration>;
export interface BlueprintItem {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
}
export declare const BlueprintItem: S.Schema<BlueprintItem>;
export type BlueprintItems = BlueprintItem[];
export declare const BlueprintItems: any;
export type FallbackBlueprintItems = BlueprintItem[];
export declare const FallbackBlueprintItems: any;
export interface DocumentCustomOutputConfiguration {
    fallbackBlueprints?: BlueprintItem[];
}
export declare const DocumentCustomOutputConfiguration: S.Schema<DocumentCustomOutputConfiguration>;
export interface CustomOutputConfiguration {
    blueprints?: BlueprintItem[];
    document?: DocumentCustomOutputConfiguration;
}
export declare const CustomOutputConfiguration: S.Schema<CustomOutputConfiguration>;
export interface SplitterConfiguration {
    state?: State;
}
export declare const SplitterConfiguration: S.Schema<SplitterConfiguration>;
export interface ModalityProcessingConfiguration {
    state?: State;
}
export declare const ModalityProcessingConfiguration: S.Schema<ModalityProcessingConfiguration>;
export type SensitiveDataDetectionMode = "DETECTION" | "DETECTION_AND_REDACTION" | (string & {});
export declare const SensitiveDataDetectionMode: any;
export type SensitiveDataDetectionScopeType = "STANDARD" | "CUSTOM" | (string & {});
export declare const SensitiveDataDetectionScopeType: any;
export type SensitiveDataDetectionScope = SensitiveDataDetectionScopeType[];
export declare const SensitiveDataDetectionScope: any;
export type PIIEntityType = "ALL" | "ADDRESS" | "AGE" | "NAME" | "EMAIL" | "PHONE" | "USERNAME" | "PASSWORD" | "DRIVER_ID" | "LICENSE_PLATE" | "VEHICLE_IDENTIFICATION_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "PIN" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "SWIFT_CODE" | "IP_ADDRESS" | "MAC_ADDRESS" | "URL" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | (string & {});
export declare const PIIEntityType: any;
export type PIIEntityTypes = PIIEntityType[];
export declare const PIIEntityTypes: any;
export type PIIRedactionMaskMode = "PII" | "ENTITY_TYPE" | (string & {});
export declare const PIIRedactionMaskMode: any;
export interface PIIEntitiesConfiguration {
    piiEntityTypes?: PIIEntityType[];
    redactionMaskMode?: PIIRedactionMaskMode;
}
export declare const PIIEntitiesConfiguration: S.Schema<PIIEntitiesConfiguration>;
export interface SensitiveDataConfiguration {
    detectionMode: SensitiveDataDetectionMode;
    detectionScope?: SensitiveDataDetectionScopeType[];
    piiEntitiesConfiguration?: PIIEntitiesConfiguration;
}
export declare const SensitiveDataConfiguration: S.Schema<SensitiveDataConfiguration>;
export interface DocumentOverrideConfiguration {
    splitter?: SplitterConfiguration;
    modalityProcessing?: ModalityProcessingConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export declare const DocumentOverrideConfiguration: S.Schema<DocumentOverrideConfiguration>;
export interface ImageOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export declare const ImageOverrideConfiguration: S.Schema<ImageOverrideConfiguration>;
export interface VideoOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export declare const VideoOverrideConfiguration: S.Schema<VideoOverrideConfiguration>;
export type Language = "EN" | "DE" | "ES" | "FR" | "IT" | "PT" | "JA" | "KO" | "CN" | "TW" | "HK" | (string & {});
export declare const Language: any;
export type AudioInputLanguages = Language[];
export declare const AudioInputLanguages: any;
export type AudioGenerativeOutputLanguage = "DEFAULT" | "EN" | (string & {});
export declare const AudioGenerativeOutputLanguage: any;
export interface AudioLanguageConfiguration {
    inputLanguages?: Language[];
    generativeOutputLanguage?: AudioGenerativeOutputLanguage;
    identifyMultipleLanguages?: boolean;
}
export declare const AudioLanguageConfiguration: S.Schema<AudioLanguageConfiguration>;
export interface AudioOverrideConfiguration {
    modalityProcessing?: ModalityProcessingConfiguration;
    languageConfiguration?: AudioLanguageConfiguration;
    sensitiveDataConfiguration?: SensitiveDataConfiguration;
}
export declare const AudioOverrideConfiguration: S.Schema<AudioOverrideConfiguration>;
export type DesiredModality = "IMAGE" | "DOCUMENT" | "AUDIO" | "VIDEO" | (string & {});
export declare const DesiredModality: any;
export interface ModalityRoutingConfiguration {
    jpeg?: DesiredModality;
    png?: DesiredModality;
    mp4?: DesiredModality;
    mov?: DesiredModality;
}
export declare const ModalityRoutingConfiguration: S.Schema<ModalityRoutingConfiguration>;
export interface OverrideConfiguration {
    document?: DocumentOverrideConfiguration;
    image?: ImageOverrideConfiguration;
    video?: VideoOverrideConfiguration;
    audio?: AudioOverrideConfiguration;
    modalityRouting?: ModalityRoutingConfiguration;
}
export declare const OverrideConfiguration: S.Schema<OverrideConfiguration>;
export interface DataAutomationLibraryItem {
    libraryArn: string;
}
export declare const DataAutomationLibraryItem: S.Schema<DataAutomationLibraryItem>;
export type DataAutomationLibraryItems = DataAutomationLibraryItem[];
export declare const DataAutomationLibraryItems: any;
export interface DataAutomationLibraryConfiguration {
    libraries?: DataAutomationLibraryItem[];
}
export declare const DataAutomationLibraryConfiguration: S.Schema<DataAutomationLibraryConfiguration>;
export interface CreateDataAutomationProjectRequest {
    projectName: string | redacted.Redacted<string>;
    projectDescription?: string | redacted.Redacted<string>;
    projectStage?: DataAutomationProjectStage;
    projectType?: DataAutomationProjectType;
    standardOutputConfiguration: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration;
    overrideConfiguration?: OverrideConfiguration;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration;
    clientToken?: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export declare const CreateDataAutomationProjectRequest: S.Schema<CreateDataAutomationProjectRequest>;
export type DataAutomationProjectArn = string;
export type DataAutomationProjectStatus = "COMPLETED" | "IN_PROGRESS" | "FAILED" | (string & {});
export declare const DataAutomationProjectStatus: any;
export interface CreateDataAutomationProjectResponse {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    status?: DataAutomationProjectStatus;
}
export declare const CreateDataAutomationProjectResponse: S.Schema<CreateDataAutomationProjectResponse>;
export interface DeleteBlueprintRequest {
    blueprintArn: string;
    blueprintVersion?: string;
}
export declare const DeleteBlueprintRequest: S.Schema<DeleteBlueprintRequest>;
export interface DeleteBlueprintResponse {
}
export declare const DeleteBlueprintResponse: S.Schema<DeleteBlueprintResponse>;
export interface DeleteDataAutomationLibraryRequest {
    libraryArn: string;
}
export declare const DeleteDataAutomationLibraryRequest: S.Schema<DeleteDataAutomationLibraryRequest>;
export interface DeleteDataAutomationLibraryResponse {
    libraryArn?: string;
    status?: DataAutomationLibraryStatus;
}
export declare const DeleteDataAutomationLibraryResponse: S.Schema<DeleteDataAutomationLibraryResponse>;
export interface DeleteDataAutomationProjectRequest {
    projectArn: string;
}
export declare const DeleteDataAutomationProjectRequest: S.Schema<DeleteDataAutomationProjectRequest>;
export interface DeleteDataAutomationProjectResponse {
    projectArn: string;
    status?: DataAutomationProjectStatus;
}
export declare const DeleteDataAutomationProjectResponse: S.Schema<DeleteDataAutomationProjectResponse>;
export interface GetBlueprintRequest {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
}
export declare const GetBlueprintRequest: S.Schema<GetBlueprintRequest>;
export interface GetBlueprintResponse {
    blueprint: Blueprint;
}
export declare const GetBlueprintResponse: S.Schema<GetBlueprintResponse>;
export type BlueprintOptimizationInvocationArn = string;
export interface GetBlueprintOptimizationStatusRequest {
    invocationArn: string;
}
export declare const GetBlueprintOptimizationStatusRequest: S.Schema<GetBlueprintOptimizationStatusRequest>;
export type BlueprintOptimizationJobStatus = "Created" | "InProgress" | "Success" | "ServiceError" | "ClientError" | (string & {});
export declare const BlueprintOptimizationJobStatus: any;
export interface BlueprintOptimizationOutputConfiguration {
    s3Object: S3Object;
}
export declare const BlueprintOptimizationOutputConfiguration: S.Schema<BlueprintOptimizationOutputConfiguration>;
export interface GetBlueprintOptimizationStatusResponse {
    status?: BlueprintOptimizationJobStatus;
    errorType?: string;
    errorMessage?: string;
    outputConfiguration?: BlueprintOptimizationOutputConfiguration;
}
export declare const GetBlueprintOptimizationStatusResponse: S.Schema<GetBlueprintOptimizationStatusResponse>;
export interface GetDataAutomationLibraryRequest {
    libraryArn: string;
}
export declare const GetDataAutomationLibraryRequest: S.Schema<GetDataAutomationLibraryRequest>;
export type EntityType = "VOCABULARY" | (string & {});
export declare const EntityType: any;
export type EntityMetadata = string;
export interface EntityTypeInfo {
    entityType: EntityType;
    entityMetadata?: string;
}
export declare const EntityTypeInfo: S.Schema<EntityTypeInfo>;
export type EntityTypeInfoList = EntityTypeInfo[];
export declare const EntityTypeInfoList: any;
export interface DataAutomationLibrary {
    libraryArn: string;
    creationTime: Date;
    libraryName: string | redacted.Redacted<string>;
    libraryDescription?: string | redacted.Redacted<string>;
    status: DataAutomationLibraryStatus;
    entityTypes?: EntityTypeInfo[];
    kmsKeyId?: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export declare const DataAutomationLibrary: S.Schema<DataAutomationLibrary>;
export interface GetDataAutomationLibraryResponse {
    library?: DataAutomationLibrary;
}
export declare const GetDataAutomationLibraryResponse: S.Schema<GetDataAutomationLibraryResponse>;
export type EntityId = string;
export interface GetDataAutomationLibraryEntityRequest {
    libraryArn: string;
    entityType: EntityType;
    entityId: string;
}
export declare const GetDataAutomationLibraryEntityRequest: S.Schema<GetDataAutomationLibraryEntityRequest>;
export type EntityDescription = string | redacted.Redacted<string>;
export type PhraseText = string | redacted.Redacted<string>;
export type PhraseDisplayAsText = string | redacted.Redacted<string>;
export interface Phrase {
    text: string | redacted.Redacted<string>;
    displayAsText?: string | redacted.Redacted<string>;
}
export declare const Phrase: S.Schema<Phrase>;
export type PhraseList = Phrase[];
export declare const PhraseList: any;
export interface VocabularyEntity {
    entityId?: string;
    description?: string | redacted.Redacted<string>;
    language?: Language;
    phrases?: Phrase[];
    lastModifiedTime?: Date;
}
export declare const VocabularyEntity: S.Schema<VocabularyEntity>;
export type EntityDetails = {
    vocabulary: VocabularyEntity;
};
export declare const EntityDetails: any;
export interface GetDataAutomationLibraryEntityResponse {
    entity?: EntityDetails;
}
export declare const GetDataAutomationLibraryEntityResponse: S.Schema<GetDataAutomationLibraryEntityResponse>;
export type DataAutomationLibraryIngestionJobArn = string;
export interface GetDataAutomationLibraryIngestionJobRequest {
    libraryArn: string;
    jobArn: string;
}
export declare const GetDataAutomationLibraryIngestionJobRequest: S.Schema<GetDataAutomationLibraryIngestionJobRequest>;
export type LibraryIngestionJobOperationType = "UPSERT" | "DELETE" | (string & {});
export declare const LibraryIngestionJobOperationType: any;
export type LibraryIngestionJobStatus = "IN_PROGRESS" | "COMPLETED" | "COMPLETED_WITH_ERRORS" | "FAILED" | (string & {});
export declare const LibraryIngestionJobStatus: any;
export interface OutputConfiguration {
    s3Uri: string;
}
export declare const OutputConfiguration: S.Schema<OutputConfiguration>;
export interface DataAutomationLibraryIngestionJob {
    jobArn: string;
    creationTime: Date;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    jobStatus: LibraryIngestionJobStatus;
    outputConfiguration: OutputConfiguration;
    completionTime?: Date;
    errorMessage?: string;
    errorType?: string;
}
export declare const DataAutomationLibraryIngestionJob: S.Schema<DataAutomationLibraryIngestionJob>;
export interface GetDataAutomationLibraryIngestionJobResponse {
    job?: DataAutomationLibraryIngestionJob;
}
export declare const GetDataAutomationLibraryIngestionJobResponse: S.Schema<GetDataAutomationLibraryIngestionJobResponse>;
export interface GetDataAutomationProjectRequest {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
}
export declare const GetDataAutomationProjectRequest: S.Schema<GetDataAutomationProjectRequest>;
export interface DataAutomationProject {
    projectArn: string;
    creationTime: Date;
    lastModifiedTime: Date;
    projectName: string | redacted.Redacted<string>;
    projectStage?: DataAutomationProjectStage;
    projectType?: DataAutomationProjectType;
    projectDescription?: string | redacted.Redacted<string>;
    standardOutputConfiguration?: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration;
    overrideConfiguration?: OverrideConfiguration;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration;
    status: DataAutomationProjectStatus;
    kmsKeyId?: string;
    kmsEncryptionContext?: {
        [key: string]: string | undefined;
    };
}
export declare const DataAutomationProject: S.Schema<DataAutomationProject>;
export interface GetDataAutomationProjectResponse {
    project: DataAutomationProject;
}
export declare const GetDataAutomationProjectResponse: S.Schema<GetDataAutomationProjectResponse>;
export interface BlueprintOptimizationObject {
    blueprintArn: string;
    stage?: BlueprintStage;
}
export declare const BlueprintOptimizationObject: S.Schema<BlueprintOptimizationObject>;
export type DataAutomationProfileArn = string;
export interface InvokeBlueprintOptimizationAsyncRequest {
    blueprint: BlueprintOptimizationObject;
    samples: BlueprintOptimizationSample[];
    outputConfiguration: BlueprintOptimizationOutputConfiguration;
    dataAutomationProfileArn: string;
    encryptionConfiguration?: EncryptionConfiguration;
    tags?: Tag[];
}
export declare const InvokeBlueprintOptimizationAsyncRequest: S.Schema<InvokeBlueprintOptimizationAsyncRequest>;
export interface InvokeBlueprintOptimizationAsyncResponse {
    invocationArn: string;
}
export declare const InvokeBlueprintOptimizationAsyncResponse: S.Schema<InvokeBlueprintOptimizationAsyncResponse>;
export interface VocabularyEntityInfo {
    entityId?: string;
    description?: string | redacted.Redacted<string>;
    language: Language;
    phrases: Phrase[];
}
export declare const VocabularyEntityInfo: S.Schema<VocabularyEntityInfo>;
export type UpsertEntityInfo = {
    vocabulary: VocabularyEntityInfo;
};
export declare const UpsertEntityInfo: any;
export type UpsertEntitiesInfo = UpsertEntityInfo[];
export declare const UpsertEntitiesInfo: any;
export type EntityIdList = string[];
export declare const EntityIdList: any;
export interface DeleteEntitiesInfo {
    entityIds: string[];
}
export declare const DeleteEntitiesInfo: S.Schema<DeleteEntitiesInfo>;
export type InlinePayload = {
    upsertEntitiesInfo: UpsertEntityInfo[];
    deleteEntitiesInfo?: never;
} | {
    upsertEntitiesInfo?: never;
    deleteEntitiesInfo: DeleteEntitiesInfo;
};
export declare const InlinePayload: any;
export interface InputConfiguration {
    s3Object?: S3Object;
    inlinePayload?: InlinePayload;
}
export declare const InputConfiguration: S.Schema<InputConfiguration>;
export interface EventBridgeConfiguration {
    eventBridgeEnabled: boolean;
}
export declare const EventBridgeConfiguration: S.Schema<EventBridgeConfiguration>;
export interface NotificationConfiguration {
    eventBridgeConfiguration: EventBridgeConfiguration;
}
export declare const NotificationConfiguration: S.Schema<NotificationConfiguration>;
export interface InvokeDataAutomationLibraryIngestionJobRequest {
    libraryArn: string;
    clientToken?: string;
    inputConfiguration: InputConfiguration;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    outputConfiguration: OutputConfiguration;
    notificationConfiguration?: NotificationConfiguration;
    tags?: Tag[];
}
export declare const InvokeDataAutomationLibraryIngestionJobRequest: S.Schema<InvokeDataAutomationLibraryIngestionJobRequest>;
export interface InvokeDataAutomationLibraryIngestionJobResponse {
    jobArn?: string;
}
export declare const InvokeDataAutomationLibraryIngestionJobResponse: S.Schema<InvokeDataAutomationLibraryIngestionJobResponse>;
export type ResourceOwner = "SERVICE" | "ACCOUNT" | (string & {});
export declare const ResourceOwner: any;
export type BlueprintStageFilter = "DEVELOPMENT" | "LIVE" | "ALL" | (string & {});
export declare const BlueprintStageFilter: any;
export type MaxResults = number;
export type NextToken = string;
export interface DataAutomationProjectFilter {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
}
export declare const DataAutomationProjectFilter: S.Schema<DataAutomationProjectFilter>;
export interface ListBlueprintsRequest {
    blueprintArn?: string;
    resourceOwner?: ResourceOwner;
    blueprintStageFilter?: BlueprintStageFilter;
    maxResults?: number;
    nextToken?: string;
    projectFilter?: DataAutomationProjectFilter;
}
export declare const ListBlueprintsRequest: S.Schema<ListBlueprintsRequest>;
export interface BlueprintSummary {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
    blueprintName?: string | redacted.Redacted<string>;
    creationTime: Date;
    lastModifiedTime?: Date;
}
export declare const BlueprintSummary: S.Schema<BlueprintSummary>;
export type Blueprints = BlueprintSummary[];
export declare const Blueprints: any;
export interface ListBlueprintsResponse {
    blueprints: BlueprintSummary[];
    nextToken?: string;
}
export declare const ListBlueprintsResponse: S.Schema<ListBlueprintsResponse>;
export interface ListDataAutomationLibrariesRequest {
    maxResults?: number;
    nextToken?: string;
    projectFilter?: DataAutomationProjectFilter;
}
export declare const ListDataAutomationLibrariesRequest: S.Schema<ListDataAutomationLibrariesRequest>;
export interface DataAutomationLibrarySummary {
    libraryArn: string;
    libraryName?: string | redacted.Redacted<string>;
    creationTime: Date;
}
export declare const DataAutomationLibrarySummary: S.Schema<DataAutomationLibrarySummary>;
export type DataAutomationLibrarySummaries = DataAutomationLibrarySummary[];
export declare const DataAutomationLibrarySummaries: any;
export interface ListDataAutomationLibrariesResponse {
    libraries?: DataAutomationLibrarySummary[];
    nextToken?: string;
}
export declare const ListDataAutomationLibrariesResponse: S.Schema<ListDataAutomationLibrariesResponse>;
export interface ListDataAutomationLibraryEntitiesRequest {
    libraryArn: string;
    entityType: EntityType;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDataAutomationLibraryEntitiesRequest: S.Schema<ListDataAutomationLibraryEntitiesRequest>;
export interface VocabularyEntitySummary {
    entityId?: string;
    description?: string | redacted.Redacted<string>;
    language?: Language;
    numOfPhrases?: number;
    lastModifiedTime?: Date;
}
export declare const VocabularyEntitySummary: S.Schema<VocabularyEntitySummary>;
export type DataAutomationLibraryEntitySummary = {
    vocabulary: VocabularyEntitySummary;
};
export declare const DataAutomationLibraryEntitySummary: any;
export type DataAutomationLibraryEntitySummaries = DataAutomationLibraryEntitySummary[];
export declare const DataAutomationLibraryEntitySummaries: any;
export interface ListDataAutomationLibraryEntitiesResponse {
    entities?: DataAutomationLibraryEntitySummary[];
    nextToken?: string;
}
export declare const ListDataAutomationLibraryEntitiesResponse: S.Schema<ListDataAutomationLibraryEntitiesResponse>;
export interface ListDataAutomationLibraryIngestionJobsRequest {
    libraryArn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDataAutomationLibraryIngestionJobsRequest: S.Schema<ListDataAutomationLibraryIngestionJobsRequest>;
export interface DataAutomationLibraryIngestionJobSummary {
    jobArn: string;
    jobStatus: LibraryIngestionJobStatus;
    entityType: EntityType;
    operationType: LibraryIngestionJobOperationType;
    creationTime: Date;
    completionTime?: Date;
}
export declare const DataAutomationLibraryIngestionJobSummary: S.Schema<DataAutomationLibraryIngestionJobSummary>;
export type DataAutomationLibraryIngestionJobSummaries = DataAutomationLibraryIngestionJobSummary[];
export declare const DataAutomationLibraryIngestionJobSummaries: any;
export interface ListDataAutomationLibraryIngestionJobsResponse {
    jobs?: DataAutomationLibraryIngestionJobSummary[];
    nextToken?: string;
}
export declare const ListDataAutomationLibraryIngestionJobsResponse: S.Schema<ListDataAutomationLibraryIngestionJobsResponse>;
export type DataAutomationProjectStageFilter = "DEVELOPMENT" | "LIVE" | "ALL" | (string & {});
export declare const DataAutomationProjectStageFilter: any;
export interface BlueprintFilter {
    blueprintArn: string;
    blueprintVersion?: string;
    blueprintStage?: BlueprintStage;
}
export declare const BlueprintFilter: S.Schema<BlueprintFilter>;
export interface DataAutomationLibraryFilter {
    libraryArn: string;
}
export declare const DataAutomationLibraryFilter: S.Schema<DataAutomationLibraryFilter>;
export interface ListDataAutomationProjectsRequest {
    maxResults?: number;
    nextToken?: string;
    projectStageFilter?: DataAutomationProjectStageFilter;
    blueprintFilter?: BlueprintFilter;
    resourceOwner?: ResourceOwner;
    libraryFilter?: DataAutomationLibraryFilter;
}
export declare const ListDataAutomationProjectsRequest: S.Schema<ListDataAutomationProjectsRequest>;
export interface DataAutomationProjectSummary {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    projectType?: DataAutomationProjectType;
    projectName?: string | redacted.Redacted<string>;
    creationTime: Date;
}
export declare const DataAutomationProjectSummary: S.Schema<DataAutomationProjectSummary>;
export type DataAutomationProjectSummaries = DataAutomationProjectSummary[];
export declare const DataAutomationProjectSummaries: any;
export interface ListDataAutomationProjectsResponse {
    projects: DataAutomationProjectSummary[];
    nextToken?: string;
}
export declare const ListDataAutomationProjectsResponse: S.Schema<ListDataAutomationProjectsResponse>;
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateBlueprintRequest {
    blueprintArn: string;
    schema: string | redacted.Redacted<string>;
    blueprintStage?: BlueprintStage;
    encryptionConfiguration?: EncryptionConfiguration;
}
export declare const UpdateBlueprintRequest: S.Schema<UpdateBlueprintRequest>;
export interface UpdateBlueprintResponse {
    blueprint: Blueprint;
}
export declare const UpdateBlueprintResponse: S.Schema<UpdateBlueprintResponse>;
export interface UpdateDataAutomationLibraryRequest {
    libraryArn: string;
    libraryDescription?: string | redacted.Redacted<string>;
    clientToken?: string;
}
export declare const UpdateDataAutomationLibraryRequest: S.Schema<UpdateDataAutomationLibraryRequest>;
export interface UpdateDataAutomationLibraryResponse {
    libraryArn?: string;
    status?: DataAutomationLibraryStatus;
}
export declare const UpdateDataAutomationLibraryResponse: S.Schema<UpdateDataAutomationLibraryResponse>;
export interface UpdateDataAutomationProjectRequest {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    projectDescription?: string | redacted.Redacted<string>;
    standardOutputConfiguration: StandardOutputConfiguration;
    customOutputConfiguration?: CustomOutputConfiguration;
    overrideConfiguration?: OverrideConfiguration;
    dataAutomationLibraryConfiguration?: DataAutomationLibraryConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
}
export declare const UpdateDataAutomationProjectRequest: S.Schema<UpdateDataAutomationProjectRequest>;
export interface UpdateDataAutomationProjectResponse {
    projectArn: string;
    projectStage?: DataAutomationProjectStage;
    status?: DataAutomationProjectStatus;
}
export declare const UpdateDataAutomationProjectResponse: S.Schema<UpdateDataAutomationProjectResponse>;
export type NonBlankString = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type CopyBlueprintStageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Copies a Blueprint from one stage to another
 */
export declare const copyBlueprintStage: API.OperationMethod<CopyBlueprintStageRequest, CopyBlueprintStageResponse, CopyBlueprintStageError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Blueprint
 */
export declare const createBlueprint: API.OperationMethod<CreateBlueprintRequest, CreateBlueprintResponse, CreateBlueprintError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new version of an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const createBlueprintVersion: API.OperationMethod<CreateBlueprintVersionRequest, CreateBlueprintVersionResponse, CreateBlueprintVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Library
 */
export declare const createDataAutomationLibrary: API.OperationMethod<CreateDataAutomationLibraryRequest, CreateDataAutomationLibraryResponse, CreateDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type CreateDataAutomationProjectError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Bedrock Data Automation Project
 */
export declare const createDataAutomationProject: API.OperationMethod<CreateDataAutomationProjectRequest, CreateDataAutomationProjectResponse, CreateDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const deleteBlueprint: API.OperationMethod<DeleteBlueprintRequest, DeleteBlueprintResponse, DeleteBlueprintError, Credentials | HttpClient.HttpClient>;
export type DeleteDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Library
 */
export declare const deleteDataAutomationLibrary: API.OperationMethod<DeleteDataAutomationLibraryRequest, DeleteDataAutomationLibraryResponse, DeleteDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type DeleteDataAutomationProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing Amazon Bedrock Data Automation Project
 */
export declare const deleteDataAutomationProject: API.OperationMethod<DeleteDataAutomationProjectRequest, DeleteDataAutomationProjectResponse, DeleteDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const getBlueprint: API.OperationMethod<GetBlueprintRequest, GetBlueprintResponse, GetBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintOptimizationStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get blueprint optimization status.
 */
export declare const getBlueprintOptimizationStatus: API.OperationMethod<GetBlueprintOptimizationStatusRequest, GetBlueprintOptimizationStatusResponse, GetBlueprintOptimizationStatusError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Library
 */
export declare const getDataAutomationLibrary: API.OperationMethod<GetDataAutomationLibraryRequest, GetDataAutomationLibraryResponse, GetDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryEntityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing entity based on entity type from the library
 */
export declare const getDataAutomationLibraryEntity: API.OperationMethod<GetDataAutomationLibraryEntityRequest, GetDataAutomationLibraryEntityResponse, GetDataAutomationLibraryEntityError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationLibraryIngestionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * API used to get status of data automation library ingestion job
 */
export declare const getDataAutomationLibraryIngestionJob: API.OperationMethod<GetDataAutomationLibraryIngestionJobRequest, GetDataAutomationLibraryIngestionJobResponse, GetDataAutomationLibraryIngestionJobError, Credentials | HttpClient.HttpClient>;
export type GetDataAutomationProjectError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an existing Amazon Bedrock Data Automation Project
 */
export declare const getDataAutomationProject: API.OperationMethod<GetDataAutomationProjectRequest, GetDataAutomationProjectResponse, GetDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export type InvokeBlueprintOptimizationAsyncError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke an async job to perform Blueprint Optimization
 */
export declare const invokeBlueprintOptimizationAsync: API.OperationMethod<InvokeBlueprintOptimizationAsyncRequest, InvokeBlueprintOptimizationAsyncResponse, InvokeBlueprintOptimizationAsyncError, Credentials | HttpClient.HttpClient>;
export type InvokeDataAutomationLibraryIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Async API: Invoke data automation library ingestion job
 */
export declare const invokeDataAutomationLibraryIngestionJob: API.OperationMethod<InvokeDataAutomationLibraryIngestionJobRequest, InvokeDataAutomationLibraryIngestionJobResponse, InvokeDataAutomationLibraryIngestionJobError, Credentials | HttpClient.HttpClient>;
export type ListBlueprintsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Blueprints
 */
export declare const listBlueprints: API.PaginatedOperationMethod<ListBlueprintsRequest, ListBlueprintsResponse, ListBlueprintsError, Credentials | HttpClient.HttpClient, BlueprintSummary>;
export type ListDataAutomationLibrariesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Libraries
 */
export declare const listDataAutomationLibraries: API.PaginatedOperationMethod<ListDataAutomationLibrariesRequest, ListDataAutomationLibrariesResponse, ListDataAutomationLibrariesError, Credentials | HttpClient.HttpClient, DataAutomationLibrarySummary>;
export type ListDataAutomationLibraryEntitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all stored entities in the library
 */
export declare const listDataAutomationLibraryEntities: API.PaginatedOperationMethod<ListDataAutomationLibraryEntitiesRequest, ListDataAutomationLibraryEntitiesResponse, ListDataAutomationLibraryEntitiesError, Credentials | HttpClient.HttpClient, DataAutomationLibraryEntitySummary>;
export type ListDataAutomationLibraryIngestionJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all data automation library ingestion jobs
 */
export declare const listDataAutomationLibraryIngestionJobs: API.PaginatedOperationMethod<ListDataAutomationLibraryIngestionJobsRequest, ListDataAutomationLibraryIngestionJobsResponse, ListDataAutomationLibraryIngestionJobsError, Credentials | HttpClient.HttpClient, DataAutomationLibraryIngestionJobSummary>;
export type ListDataAutomationProjectsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing Amazon Bedrock Data Automation Projects
 */
export declare const listDataAutomationProjects: API.PaginatedOperationMethod<ListDataAutomationProjectsRequest, ListDataAutomationProjectsResponse, ListDataAutomationProjectsError, Credentials | HttpClient.HttpClient, DataAutomationProjectSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for an Amazon Bedrock Data Automation resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag an Amazon Bedrock Data Automation resource
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag an Amazon Bedrock Data Automation resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBlueprintError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Blueprint
 */
export declare const updateBlueprint: API.OperationMethod<UpdateBlueprintRequest, UpdateBlueprintResponse, UpdateBlueprintError, Credentials | HttpClient.HttpClient>;
export type UpdateDataAutomationLibraryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Library
 */
export declare const updateDataAutomationLibrary: API.OperationMethod<UpdateDataAutomationLibraryRequest, UpdateDataAutomationLibraryResponse, UpdateDataAutomationLibraryError, Credentials | HttpClient.HttpClient>;
export type UpdateDataAutomationProjectError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Bedrock Data Automation Project
 */
export declare const updateDataAutomationProject: API.OperationMethod<UpdateDataAutomationProjectRequest, UpdateDataAutomationProjectResponse, UpdateDataAutomationProjectError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-data-automation.d.ts.map