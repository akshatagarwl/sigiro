import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ClusterAlreadyExistsFault_base: S.Class<ClusterAlreadyExistsFault, S.TaggedStruct<"ClusterAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ClusterAlreadyExistsFault extends /*@__PURE__*/ ClusterAlreadyExistsFault_base {
}
declare const ClusterNotFoundFault_base: S.Class<ClusterNotFoundFault, S.TaggedStruct<"ClusterNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterNotFoundFault extends /*@__PURE__*/ ClusterNotFoundFault_base {
}
declare const ClusterQuotaForCustomerExceededFault_base: S.Class<ClusterQuotaForCustomerExceededFault, S.TaggedStruct<"ClusterQuotaForCustomerExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterQuotaForCustomerExceededFault extends /*@__PURE__*/ ClusterQuotaForCustomerExceededFault_base {
}
declare const InsufficientClusterCapacityFault_base: S.Class<InsufficientClusterCapacityFault, S.TaggedStruct<"InsufficientClusterCapacityFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientClusterCapacityFault extends /*@__PURE__*/ InsufficientClusterCapacityFault_base {
}
declare const InvalidARNFault_base: S.Class<InvalidARNFault, S.TaggedStruct<"InvalidARNFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidARNFault extends /*@__PURE__*/ InvalidARNFault_base {
}
declare const InvalidClusterStateFault_base: S.Class<InvalidClusterStateFault, S.TaggedStruct<"InvalidClusterStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidClusterStateFault extends /*@__PURE__*/ InvalidClusterStateFault_base {
}
declare const InvalidParameterCombinationException_base: S.Class<InvalidParameterCombinationException, S.TaggedStruct<"InvalidParameterCombinationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterGroupStateFault_base: S.Class<InvalidParameterGroupStateFault, S.TaggedStruct<"InvalidParameterGroupStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterGroupStateFault extends /*@__PURE__*/ InvalidParameterGroupStateFault_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidSubnet_base: S.Class<InvalidSubnet, S.TaggedStruct<"InvalidSubnet", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidVPCNetworkStateFault_base: S.Class<InvalidVPCNetworkStateFault, S.TaggedStruct<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const NodeNotFoundFault_base: S.Class<NodeNotFoundFault, S.TaggedStruct<"NodeNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeNotFoundFault extends /*@__PURE__*/ NodeNotFoundFault_base {
}
declare const NodeQuotaForClusterExceededFault_base: S.Class<NodeQuotaForClusterExceededFault, S.TaggedStruct<"NodeQuotaForClusterExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForClusterExceededFault extends /*@__PURE__*/ NodeQuotaForClusterExceededFault_base {
}
declare const NodeQuotaForCustomerExceededFault_base: S.Class<NodeQuotaForCustomerExceededFault, S.TaggedStruct<"NodeQuotaForCustomerExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForCustomerExceededFault extends /*@__PURE__*/ NodeQuotaForCustomerExceededFault_base {
}
declare const ParameterGroupAlreadyExistsFault_base: S.Class<ParameterGroupAlreadyExistsFault, S.TaggedStruct<"ParameterGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ParameterGroupAlreadyExistsFault extends /*@__PURE__*/ ParameterGroupAlreadyExistsFault_base {
}
declare const ParameterGroupNotFoundFault_base: S.Class<ParameterGroupNotFoundFault, S.TaggedStruct<"ParameterGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ParameterGroupNotFoundFault extends /*@__PURE__*/ ParameterGroupNotFoundFault_base {
}
declare const ParameterGroupQuotaExceededFault_base: S.Class<ParameterGroupQuotaExceededFault, S.TaggedStruct<"ParameterGroupQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ParameterGroupQuotaExceededFault extends /*@__PURE__*/ ParameterGroupQuotaExceededFault_base {
}
declare const ServiceLinkedRoleNotFoundFault_base: S.Class<ServiceLinkedRoleNotFoundFault, S.TaggedStruct<"ServiceLinkedRoleNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLinkedRoleNotFoundFault extends /*@__PURE__*/ ServiceLinkedRoleNotFoundFault_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SubnetGroupAlreadyExistsFault_base: S.Class<SubnetGroupAlreadyExistsFault, S.TaggedStruct<"SubnetGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SubnetGroupAlreadyExistsFault extends /*@__PURE__*/ SubnetGroupAlreadyExistsFault_base {
}
declare const SubnetGroupInUseFault_base: S.Class<SubnetGroupInUseFault, S.TaggedStruct<"SubnetGroupInUseFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetGroupInUseFault extends /*@__PURE__*/ SubnetGroupInUseFault_base {
}
declare const SubnetGroupNotFoundFault_base: S.Class<SubnetGroupNotFoundFault, S.TaggedStruct<"SubnetGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetGroupNotFoundFault extends /*@__PURE__*/ SubnetGroupNotFoundFault_base {
}
declare const SubnetGroupQuotaExceededFault_base: S.Class<SubnetGroupQuotaExceededFault, S.TaggedStruct<"SubnetGroupQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetGroupQuotaExceededFault extends /*@__PURE__*/ SubnetGroupQuotaExceededFault_base {
}
declare const SubnetInUse_base: S.Class<SubnetInUse, S.TaggedStruct<"SubnetInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetInUse extends /*@__PURE__*/ SubnetInUse_base {
}
declare const SubnetNotAllowedFault_base: S.Class<SubnetNotAllowedFault, S.TaggedStruct<"SubnetNotAllowedFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotAllowedFault extends /*@__PURE__*/ SubnetNotAllowedFault_base {
}
declare const SubnetQuotaExceededFault_base: S.Class<SubnetQuotaExceededFault, S.TaggedStruct<"SubnetQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetQuotaExceededFault extends /*@__PURE__*/ SubnetQuotaExceededFault_base {
}
declare const TagNotFoundFault_base: S.Class<TagNotFoundFault, S.TaggedStruct<"TagNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagNotFoundFault extends /*@__PURE__*/ TagNotFoundFault_base {
}
declare const TagQuotaPerResourceExceeded_base: S.Class<TagQuotaPerResourceExceeded, S.TaggedStruct<"TagQuotaPerResourceExceeded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagQuotaPerResourceExceeded extends /*@__PURE__*/ TagQuotaPerResourceExceeded_base {
}
export type AvailabilityZoneList = string[];
export declare const AvailabilityZoneList: any;
export type SecurityGroupIdentifierList = string[];
export declare const SecurityGroupIdentifierList: any;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type SSEEnabled = boolean;
export interface SSESpecification {
    Enabled: boolean;
}
export declare const SSESpecification: S.Schema<SSESpecification>;
export type ClusterEndpointEncryptionType = "NONE" | "TLS" | (string & {});
export declare const ClusterEndpointEncryptionType: any;
export type NetworkType = "ipv4" | "ipv6" | "dual_stack" | (string & {});
export declare const NetworkType: any;
export interface CreateClusterRequest {
    ClusterName: string;
    NodeType: string;
    Description?: string;
    ReplicationFactor: number;
    AvailabilityZones?: string[];
    SubnetGroupName?: string;
    SecurityGroupIds?: string[];
    PreferredMaintenanceWindow?: string;
    NotificationTopicArn?: string;
    IamRoleArn: string;
    ParameterGroupName?: string;
    Tags?: Tag[];
    SSESpecification?: SSESpecification;
    ClusterEndpointEncryptionType?: ClusterEndpointEncryptionType;
    NetworkType?: NetworkType;
}
export declare const CreateClusterRequest: S.Schema<CreateClusterRequest>;
export interface Endpoint {
    Address?: string;
    Port?: number;
    URL?: string;
}
export declare const Endpoint: S.Schema<Endpoint>;
export type NodeIdentifierList = string[];
export declare const NodeIdentifierList: any;
export interface Node {
    NodeId?: string;
    Endpoint?: Endpoint;
    NodeCreateTime?: Date;
    AvailabilityZone?: string;
    NodeStatus?: string;
    ParameterGroupStatus?: string;
}
export declare const Node: S.Schema<Node>;
export type NodeList = Node[];
export declare const NodeList: any;
export interface NotificationConfiguration {
    TopicArn?: string;
    TopicStatus?: string;
}
export declare const NotificationConfiguration: S.Schema<NotificationConfiguration>;
export interface SecurityGroupMembership {
    SecurityGroupIdentifier?: string;
    Status?: string;
}
export declare const SecurityGroupMembership: S.Schema<SecurityGroupMembership>;
export type SecurityGroupMembershipList = SecurityGroupMembership[];
export declare const SecurityGroupMembershipList: any;
export interface ParameterGroupStatus {
    ParameterGroupName?: string;
    ParameterApplyStatus?: string;
    NodeIdsToReboot?: string[];
}
export declare const ParameterGroupStatus: S.Schema<ParameterGroupStatus>;
export type SSEStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | (string & {});
export declare const SSEStatus: any;
export interface SSEDescription {
    Status?: SSEStatus;
}
export declare const SSEDescription: S.Schema<SSEDescription>;
export interface Cluster {
    ClusterName?: string;
    Description?: string;
    ClusterArn?: string;
    TotalNodes?: number;
    ActiveNodes?: number;
    NodeType?: string;
    Status?: string;
    ClusterDiscoveryEndpoint?: Endpoint;
    NodeIdsToRemove?: string[];
    Nodes?: Node[];
    PreferredMaintenanceWindow?: string;
    NotificationConfiguration?: NotificationConfiguration;
    SubnetGroup?: string;
    SecurityGroups?: SecurityGroupMembership[];
    IamRoleArn?: string;
    ParameterGroup?: ParameterGroupStatus;
    SSEDescription?: SSEDescription;
    ClusterEndpointEncryptionType?: ClusterEndpointEncryptionType;
    NetworkType?: NetworkType;
}
export declare const Cluster: S.Schema<Cluster>;
export interface CreateClusterResponse {
    Cluster?: Cluster;
}
export declare const CreateClusterResponse: S.Schema<CreateClusterResponse>;
export interface CreateParameterGroupRequest {
    ParameterGroupName: string;
    Description?: string;
}
export declare const CreateParameterGroupRequest: S.Schema<CreateParameterGroupRequest>;
export interface ParameterGroup {
    ParameterGroupName?: string;
    Description?: string;
}
export declare const ParameterGroup: S.Schema<ParameterGroup>;
export interface CreateParameterGroupResponse {
    ParameterGroup?: ParameterGroup;
}
export declare const CreateParameterGroupResponse: S.Schema<CreateParameterGroupResponse>;
export type SubnetIdentifierList = string[];
export declare const SubnetIdentifierList: any;
export interface CreateSubnetGroupRequest {
    SubnetGroupName: string;
    Description?: string;
    SubnetIds: string[];
}
export declare const CreateSubnetGroupRequest: S.Schema<CreateSubnetGroupRequest>;
export type NetworkTypeList = NetworkType[];
export declare const NetworkTypeList: any;
export interface Subnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: string;
    SupportedNetworkTypes?: NetworkType[];
}
export declare const Subnet: S.Schema<Subnet>;
export type SubnetList = Subnet[];
export declare const SubnetList: any;
export interface SubnetGroup {
    SubnetGroupName?: string;
    Description?: string;
    VpcId?: string;
    Subnets?: Subnet[];
    SupportedNetworkTypes?: NetworkType[];
}
export declare const SubnetGroup: S.Schema<SubnetGroup>;
export interface CreateSubnetGroupResponse {
    SubnetGroup?: SubnetGroup;
}
export declare const CreateSubnetGroupResponse: S.Schema<CreateSubnetGroupResponse>;
export interface DecreaseReplicationFactorRequest {
    ClusterName: string;
    NewReplicationFactor: number;
    AvailabilityZones?: string[];
    NodeIdsToRemove?: string[];
}
export declare const DecreaseReplicationFactorRequest: S.Schema<DecreaseReplicationFactorRequest>;
export interface DecreaseReplicationFactorResponse {
    Cluster?: Cluster;
}
export declare const DecreaseReplicationFactorResponse: S.Schema<DecreaseReplicationFactorResponse>;
export interface DeleteClusterRequest {
    ClusterName: string;
}
export declare const DeleteClusterRequest: S.Schema<DeleteClusterRequest>;
export interface DeleteClusterResponse {
    Cluster?: Cluster;
}
export declare const DeleteClusterResponse: S.Schema<DeleteClusterResponse>;
export interface DeleteParameterGroupRequest {
    ParameterGroupName: string;
}
export declare const DeleteParameterGroupRequest: S.Schema<DeleteParameterGroupRequest>;
export interface DeleteParameterGroupResponse {
    DeletionMessage?: string;
}
export declare const DeleteParameterGroupResponse: S.Schema<DeleteParameterGroupResponse>;
export interface DeleteSubnetGroupRequest {
    SubnetGroupName: string;
}
export declare const DeleteSubnetGroupRequest: S.Schema<DeleteSubnetGroupRequest>;
export interface DeleteSubnetGroupResponse {
    DeletionMessage?: string;
}
export declare const DeleteSubnetGroupResponse: S.Schema<DeleteSubnetGroupResponse>;
export type ClusterNameList = string[];
export declare const ClusterNameList: any;
export interface DescribeClustersRequest {
    ClusterNames?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeClustersRequest: S.Schema<DescribeClustersRequest>;
export type ClusterList = Cluster[];
export declare const ClusterList: any;
export interface DescribeClustersResponse {
    NextToken?: string;
    Clusters?: Cluster[];
}
export declare const DescribeClustersResponse: S.Schema<DescribeClustersResponse>;
export interface DescribeDefaultParametersRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeDefaultParametersRequest: S.Schema<DescribeDefaultParametersRequest>;
export type ParameterType = "DEFAULT" | "NODE_TYPE_SPECIFIC" | (string & {});
export declare const ParameterType: any;
export interface NodeTypeSpecificValue {
    NodeType?: string;
    Value?: string;
}
export declare const NodeTypeSpecificValue: S.Schema<NodeTypeSpecificValue>;
export type NodeTypeSpecificValueList = NodeTypeSpecificValue[];
export declare const NodeTypeSpecificValueList: any;
export type IsModifiable = "TRUE" | "FALSE" | "CONDITIONAL" | (string & {});
export declare const IsModifiable: any;
export type ChangeType = "IMMEDIATE" | "REQUIRES_REBOOT" | (string & {});
export declare const ChangeType: any;
export interface Parameter {
    ParameterName?: string;
    ParameterType?: ParameterType;
    ParameterValue?: string;
    NodeTypeSpecificValues?: NodeTypeSpecificValue[];
    Description?: string;
    Source?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: IsModifiable;
    ChangeType?: ChangeType;
}
export declare const Parameter: S.Schema<Parameter>;
export type ParameterList = Parameter[];
export declare const ParameterList: any;
export interface DescribeDefaultParametersResponse {
    NextToken?: string;
    Parameters?: Parameter[];
}
export declare const DescribeDefaultParametersResponse: S.Schema<DescribeDefaultParametersResponse>;
export type SourceType = "CLUSTER" | "PARAMETER_GROUP" | "SUBNET_GROUP" | (string & {});
export declare const SourceType: any;
export interface DescribeEventsRequest {
    SourceName?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeEventsRequest: S.Schema<DescribeEventsRequest>;
export interface Event {
    SourceName?: string;
    SourceType?: SourceType;
    Message?: string;
    Date?: Date;
}
export declare const Event: S.Schema<Event>;
export type EventList = Event[];
export declare const EventList: any;
export interface DescribeEventsResponse {
    NextToken?: string;
    Events?: Event[];
}
export declare const DescribeEventsResponse: S.Schema<DescribeEventsResponse>;
export type ParameterGroupNameList = string[];
export declare const ParameterGroupNameList: any;
export interface DescribeParameterGroupsRequest {
    ParameterGroupNames?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeParameterGroupsRequest: S.Schema<DescribeParameterGroupsRequest>;
export type ParameterGroupList = ParameterGroup[];
export declare const ParameterGroupList: any;
export interface DescribeParameterGroupsResponse {
    NextToken?: string;
    ParameterGroups?: ParameterGroup[];
}
export declare const DescribeParameterGroupsResponse: S.Schema<DescribeParameterGroupsResponse>;
export interface DescribeParametersRequest {
    ParameterGroupName: string;
    Source?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeParametersRequest: S.Schema<DescribeParametersRequest>;
export interface DescribeParametersResponse {
    NextToken?: string;
    Parameters?: Parameter[];
}
export declare const DescribeParametersResponse: S.Schema<DescribeParametersResponse>;
export type SubnetGroupNameList = string[];
export declare const SubnetGroupNameList: any;
export interface DescribeSubnetGroupsRequest {
    SubnetGroupNames?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeSubnetGroupsRequest: S.Schema<DescribeSubnetGroupsRequest>;
export type SubnetGroupList = SubnetGroup[];
export declare const SubnetGroupList: any;
export interface DescribeSubnetGroupsResponse {
    NextToken?: string;
    SubnetGroups?: SubnetGroup[];
}
export declare const DescribeSubnetGroupsResponse: S.Schema<DescribeSubnetGroupsResponse>;
export interface IncreaseReplicationFactorRequest {
    ClusterName: string;
    NewReplicationFactor: number;
    AvailabilityZones?: string[];
}
export declare const IncreaseReplicationFactorRequest: S.Schema<IncreaseReplicationFactorRequest>;
export interface IncreaseReplicationFactorResponse {
    Cluster?: Cluster;
}
export declare const IncreaseReplicationFactorResponse: S.Schema<IncreaseReplicationFactorResponse>;
export interface ListTagsRequest {
    ResourceName: string;
    NextToken?: string;
}
export declare const ListTagsRequest: S.Schema<ListTagsRequest>;
export interface ListTagsResponse {
    Tags?: Tag[];
    NextToken?: string;
}
export declare const ListTagsResponse: S.Schema<ListTagsResponse>;
export interface RebootNodeRequest {
    ClusterName: string;
    NodeId: string;
}
export declare const RebootNodeRequest: S.Schema<RebootNodeRequest>;
export interface RebootNodeResponse {
    Cluster?: Cluster;
}
export declare const RebootNodeResponse: S.Schema<RebootNodeResponse>;
export interface TagResourceRequest {
    ResourceName: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
    Tags?: Tag[];
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type KeyList = string[];
export declare const KeyList: any;
export interface UntagResourceRequest {
    ResourceName: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
    Tags?: Tag[];
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateClusterRequest {
    ClusterName: string;
    Description?: string;
    PreferredMaintenanceWindow?: string;
    NotificationTopicArn?: string;
    NotificationTopicStatus?: string;
    ParameterGroupName?: string;
    SecurityGroupIds?: string[];
}
export declare const UpdateClusterRequest: S.Schema<UpdateClusterRequest>;
export interface UpdateClusterResponse {
    Cluster?: Cluster;
}
export declare const UpdateClusterResponse: S.Schema<UpdateClusterResponse>;
export interface ParameterNameValue {
    ParameterName?: string;
    ParameterValue?: string;
}
export declare const ParameterNameValue: S.Schema<ParameterNameValue>;
export type ParameterNameValueList = ParameterNameValue[];
export declare const ParameterNameValueList: any;
export interface UpdateParameterGroupRequest {
    ParameterGroupName: string;
    ParameterNameValues: ParameterNameValue[];
}
export declare const UpdateParameterGroupRequest: S.Schema<UpdateParameterGroupRequest>;
export interface UpdateParameterGroupResponse {
    ParameterGroup?: ParameterGroup;
}
export declare const UpdateParameterGroupResponse: S.Schema<UpdateParameterGroupResponse>;
export interface UpdateSubnetGroupRequest {
    SubnetGroupName: string;
    Description?: string;
    SubnetIds?: string[];
}
export declare const UpdateSubnetGroupRequest: S.Schema<UpdateSubnetGroupRequest>;
export interface UpdateSubnetGroupResponse {
    SubnetGroup?: SubnetGroup;
}
export declare const UpdateSubnetGroupResponse: S.Schema<UpdateSubnetGroupResponse>;
export type ExceptionMessage = string;
export type AwsQueryErrorMessage = string;
export type CreateClusterError = ClusterAlreadyExistsFault | ClusterQuotaForCustomerExceededFault | InsufficientClusterCapacityFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | ServiceQuotaExceededException | SubnetGroupNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a DAX cluster. All nodes in the cluster run the same DAX caching software.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateParameterGroupError = InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupAlreadyExistsFault | ParameterGroupQuotaExceededFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Creates a new parameter group. A parameter group is a collection of parameters that
 * you apply to all of the nodes in a DAX cluster.
 */
export declare const createParameterGroup: API.OperationMethod<CreateParameterGroupRequest, CreateParameterGroupResponse, CreateParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateSubnetGroupError = InvalidSubnet | ServiceLinkedRoleNotFoundFault | SubnetGroupAlreadyExistsFault | SubnetGroupQuotaExceededFault | SubnetNotAllowedFault | SubnetQuotaExceededFault | CommonErrors;
/**
 * Creates a new subnet group.
 */
export declare const createSubnetGroup: API.OperationMethod<CreateSubnetGroupRequest, CreateSubnetGroupResponse, CreateSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DecreaseReplicationFactorError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | NodeNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Removes one or more nodes from a DAX cluster.
 *
 * You cannot use `DecreaseReplicationFactor` to remove the last node
 * in a DAX cluster. If you need to do this, use
 * `DeleteCluster` instead.
 */
export declare const decreaseReplicationFactor: API.OperationMethod<DecreaseReplicationFactorRequest, DecreaseReplicationFactorResponse, DecreaseReplicationFactorError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes a previously provisioned DAX cluster.
 * *DeleteCluster* deletes all associated nodes, node endpoints and
 * the DAX cluster itself. When you receive a successful response from this
 * action, DAX immediately begins deleting the cluster; you cannot cancel or
 * revert this action.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteParameterGroupError = InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes the specified parameter group. You cannot delete a parameter group if it is
 * associated with any DAX clusters.
 */
export declare const deleteParameterGroup: API.OperationMethod<DeleteParameterGroupRequest, DeleteParameterGroupResponse, DeleteParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteSubnetGroupError = ServiceLinkedRoleNotFoundFault | SubnetGroupInUseFault | SubnetGroupNotFoundFault | CommonErrors;
/**
 * Deletes a subnet group.
 *
 * You cannot delete a subnet group if it is associated with any DAX
 * clusters.
 */
export declare const deleteSubnetGroup: API.OperationMethod<DeleteSubnetGroupRequest, DeleteSubnetGroupResponse, DeleteSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeClustersError = ClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns information about all provisioned DAX clusters if no cluster identifier is
 * specified, or about a specific DAX cluster if a cluster identifier is
 * supplied.
 *
 * If the cluster is in the CREATING state, only cluster level information will be
 * displayed until all of the nodes are successfully provisioned.
 *
 * If the cluster is in the DELETING state, only cluster level information will be
 * displayed.
 *
 * If nodes are currently being added to the DAX cluster, node endpoint information
 * and creation time for the additional nodes will not be displayed until they are
 * completely provisioned. When the DAX cluster state is
 * *available*, the cluster is ready for use.
 *
 * If nodes are currently being removed from the DAX cluster, no
 * endpoint information for the removed nodes is displayed.
 */
export declare const describeClusters: API.OperationMethod<DescribeClustersRequest, DescribeClustersResponse, DescribeClustersError, Credentials | HttpClient.HttpClient>;
export type DescribeDefaultParametersError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns the default system parameter information for the DAX caching
 * software.
 */
export declare const describeDefaultParameters: API.OperationMethod<DescribeDefaultParametersRequest, DescribeDefaultParametersResponse, DescribeDefaultParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns events related to DAX clusters and parameter groups. You can
 * obtain events specific to a particular DAX cluster or parameter group by
 * providing the name as a parameter.
 *
 * By default, only the events occurring within the last 24 hours are returned;
 * however, you can retrieve up to 14 days' worth of events if necessary.
 */
export declare const describeEvents: API.OperationMethod<DescribeEventsRequest, DescribeEventsResponse, DescribeEventsError, Credentials | HttpClient.HttpClient>;
export type DescribeParameterGroupsError = InvalidParameterCombinationException | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns a list of parameter group descriptions. If a parameter group name is
 * specified, the list will contain only the descriptions for that group.
 */
export declare const describeParameterGroups: API.OperationMethod<DescribeParameterGroupsRequest, DescribeParameterGroupsResponse, DescribeParameterGroupsError, Credentials | HttpClient.HttpClient>;
export type DescribeParametersError = InvalidParameterCombinationException | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular parameter group.
 */
export declare const describeParameters: API.OperationMethod<DescribeParametersRequest, DescribeParametersResponse, DescribeParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeSubnetGroupsError = ServiceLinkedRoleNotFoundFault | SubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of subnet group descriptions. If a subnet group name is specified,
 * the list will contain only the description of that group.
 */
export declare const describeSubnetGroups: API.OperationMethod<DescribeSubnetGroupsRequest, DescribeSubnetGroupsResponse, DescribeSubnetGroupsError, Credentials | HttpClient.HttpClient>;
export type IncreaseReplicationFactorError = ClusterNotFoundFault | InsufficientClusterCapacityFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Adds one or more nodes to a DAX cluster.
 */
export declare const increaseReplicationFactor: API.OperationMethod<IncreaseReplicationFactorRequest, IncreaseReplicationFactorResponse, IncreaseReplicationFactorError, Credentials | HttpClient.HttpClient>;
export type ListTagsError = ClusterNotFoundFault | InvalidARNFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * List all of the tags for a DAX cluster. You can call
 * `ListTags` up to 10 times per second, per account.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type RebootNodeError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | NodeNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Reboots a single node of a DAX cluster. The reboot action takes
 * place as soon as possible. During the reboot, the node status is set to
 * REBOOTING.
 *
 * `RebootNode` restarts the DAX engine process and does not remove the
 * contents of the cache.
 */
export declare const rebootNode: API.OperationMethod<RebootNodeRequest, RebootNodeResponse, RebootNodeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ClusterNotFoundFault | InvalidARNFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Associates a set of tags with a DAX resource.
 * You can call `TagResource` up to
 * 5 times per second, per account.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ClusterNotFoundFault | InvalidARNFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagNotFoundFault | CommonErrors;
/**
 * Removes the association of tags from a DAX resource. You can call
 * `UntagResource` up to 5 times per second, per account.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = ClusterNotFoundFault | InvalidClusterStateFault | InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Modifies the settings for a DAX cluster. You can use this action to
 * change one or more cluster configuration parameters by specifying the parameters and the
 * new values.
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterRequest, UpdateClusterResponse, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateParameterGroupError = InvalidParameterCombinationException | InvalidParameterGroupStateFault | InvalidParameterValueException | ParameterGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Modifies the parameters of a parameter group. You can modify up to 20 parameters in
 * a single request by submitting a list parameter name and value pairs.
 */
export declare const updateParameterGroup: API.OperationMethod<UpdateParameterGroupRequest, UpdateParameterGroupResponse, UpdateParameterGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateSubnetGroupError = InvalidSubnet | ServiceLinkedRoleNotFoundFault | SubnetGroupNotFoundFault | SubnetInUse | SubnetNotAllowedFault | SubnetQuotaExceededFault | CommonErrors;
/**
 * Modifies an existing subnet group.
 */
export declare const updateSubnetGroup: API.OperationMethod<UpdateSubnetGroupRequest, UpdateSubnetGroupResponse, UpdateSubnetGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dax.d.ts.map