import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ControlArn = string;
export interface GetControlRequest {
    ControlArn: string;
}
export declare const GetControlRequest: S.Schema<GetControlRequest>;
export type ControlAlias = string;
export type ControlAliases = string[];
export declare const ControlAliases: any;
export type ControlBehavior = "PREVENTIVE" | "PROACTIVE" | "DETECTIVE" | (string & {});
export declare const ControlBehavior: any;
export type ControlSeverity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export declare const ControlSeverity: any;
export type ControlScope = "GLOBAL" | "REGIONAL" | (string & {});
export declare const ControlScope: any;
export type RegionCode = string;
export type DeployableRegions = string[];
export declare const DeployableRegions: any;
export interface RegionConfiguration {
    Scope: ControlScope;
    DeployableRegions?: string[];
}
export declare const RegionConfiguration: S.Schema<RegionConfiguration>;
export type ImplementationType = string;
export type ImplementationIdentifier = string;
export interface ImplementationDetails {
    Type: string;
    Identifier?: string;
}
export declare const ImplementationDetails: S.Schema<ImplementationDetails>;
export type ParameterRequirementSummary = "REQUIRED" | "OPTIONAL" | "NONE" | (string & {});
export declare const ParameterRequirementSummary: any;
export type ControlParameterRequirement = "REQUIRED" | "OPTIONAL" | (string & {});
export declare const ControlParameterRequirement: any;
export interface ControlParameter {
    Name: string;
    Requirement?: ControlParameterRequirement;
}
export declare const ControlParameter: S.Schema<ControlParameter>;
export type ControlParameters = ControlParameter[];
export declare const ControlParameters: any;
export type GovernedResource = string;
export type GovernedResources = string[];
export declare const GovernedResources: any;
export type GovernedProvider = string;
export type GovernedProviders = string[];
export declare const GovernedProviders: any;
export interface GetControlResponse {
    Arn: string;
    Aliases?: string[];
    Name: string;
    Description: string;
    Behavior: ControlBehavior;
    Severity?: ControlSeverity;
    RegionConfiguration: RegionConfiguration;
    Implementation?: ImplementationDetails;
    ParameterRequirementSummary?: ParameterRequirementSummary;
    Parameters?: ControlParameter[];
    CreateTime?: Date;
    GovernedResources?: string[];
    GovernedProviders?: string[];
}
export declare const GetControlResponse: S.Schema<GetControlResponse>;
export type MaxListCommonControlsResults = number;
export type PaginationToken = string;
export type ObjectiveArn = string;
export interface ObjectiveResourceFilter {
    Arn?: string;
}
export declare const ObjectiveResourceFilter: S.Schema<ObjectiveResourceFilter>;
export type ObjectiveResourceFilterList = ObjectiveResourceFilter[];
export declare const ObjectiveResourceFilterList: any;
export interface CommonControlFilter {
    Objectives?: ObjectiveResourceFilter[];
}
export declare const CommonControlFilter: S.Schema<CommonControlFilter>;
export interface ListCommonControlsRequest {
    MaxResults?: number;
    NextToken?: string;
    CommonControlFilter?: CommonControlFilter;
}
export declare const ListCommonControlsRequest: S.Schema<ListCommonControlsRequest>;
export type CommonControlArn = string;
export type DomainArn = string;
export interface AssociatedDomainSummary {
    Arn?: string;
    Name?: string;
}
export declare const AssociatedDomainSummary: S.Schema<AssociatedDomainSummary>;
export interface AssociatedObjectiveSummary {
    Arn?: string;
    Name?: string;
}
export declare const AssociatedObjectiveSummary: S.Schema<AssociatedObjectiveSummary>;
export interface CommonControlSummary {
    Arn: string;
    Name: string;
    Description: string;
    Domain: AssociatedDomainSummary;
    Objective: AssociatedObjectiveSummary;
    CreateTime: Date;
    LastUpdateTime: Date;
}
export declare const CommonControlSummary: S.Schema<CommonControlSummary>;
export type CommonControlSummaryList = CommonControlSummary[];
export declare const CommonControlSummaryList: any;
export interface ListCommonControlsResponse {
    CommonControls: CommonControlSummary[];
    NextToken?: string;
}
export declare const ListCommonControlsResponse: S.Schema<ListCommonControlsResponse>;
export type MaxListControlMappingsResults = number;
export type ControlArnFilterList = string[];
export declare const ControlArnFilterList: any;
export type CommonControlArnFilterList = string[];
export declare const CommonControlArnFilterList: any;
export type MappingType = "FRAMEWORK" | "COMMON_CONTROL" | "RELATED_CONTROL" | (string & {});
export declare const MappingType: any;
export type MappingTypeFilterList = MappingType[];
export declare const MappingTypeFilterList: any;
export interface ControlMappingFilter {
    ControlArns?: string[];
    CommonControlArns?: string[];
    MappingTypes?: MappingType[];
}
export declare const ControlMappingFilter: S.Schema<ControlMappingFilter>;
export interface ListControlMappingsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filter?: ControlMappingFilter;
}
export declare const ListControlMappingsRequest: S.Schema<ListControlMappingsRequest>;
export type FrameworkName = string;
export type FrameworkItem = string;
export interface FrameworkMappingDetails {
    Name: string;
    Item: string;
}
export declare const FrameworkMappingDetails: S.Schema<FrameworkMappingDetails>;
export interface CommonControlMappingDetails {
    CommonControlArn: string;
}
export declare const CommonControlMappingDetails: S.Schema<CommonControlMappingDetails>;
export type ControlRelationType = "COMPLEMENTARY" | "ALTERNATIVE" | "MUTUALLY_EXCLUSIVE" | (string & {});
export declare const ControlRelationType: any;
export interface RelatedControlMappingDetails {
    ControlArn?: string;
    RelationType: ControlRelationType;
}
export declare const RelatedControlMappingDetails: S.Schema<RelatedControlMappingDetails>;
export type Mapping = {
    Framework: FrameworkMappingDetails;
    CommonControl?: never;
    RelatedControl?: never;
} | {
    Framework?: never;
    CommonControl: CommonControlMappingDetails;
    RelatedControl?: never;
} | {
    Framework?: never;
    CommonControl?: never;
    RelatedControl: RelatedControlMappingDetails;
};
export declare const Mapping: any;
export interface ControlMapping {
    ControlArn: string;
    MappingType: MappingType;
    Mapping: Mapping;
}
export declare const ControlMapping: S.Schema<ControlMapping>;
export type ControlMappings = ControlMapping[];
export declare const ControlMappings: any;
export interface ListControlMappingsResponse {
    ControlMappings: ControlMapping[];
    NextToken?: string;
}
export declare const ListControlMappingsResponse: S.Schema<ListControlMappingsResponse>;
export type MaxListControlsResults = number;
export type ImplementationTypeFilterList = string[];
export declare const ImplementationTypeFilterList: any;
export type ImplementationIdentifierFilterList = string[];
export declare const ImplementationIdentifierFilterList: any;
export interface ImplementationFilter {
    Types?: string[];
    Identifiers?: string[];
}
export declare const ImplementationFilter: S.Schema<ImplementationFilter>;
export type GovernedProviderFilterList = string[];
export declare const GovernedProviderFilterList: any;
export interface ControlFilter {
    Implementations?: ImplementationFilter;
    GovernedProviders?: string[];
}
export declare const ControlFilter: S.Schema<ControlFilter>;
export interface ListControlsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filter?: ControlFilter;
}
export declare const ListControlsRequest: S.Schema<ListControlsRequest>;
export interface ImplementationSummary {
    Type: string;
    Identifier?: string;
}
export declare const ImplementationSummary: S.Schema<ImplementationSummary>;
export interface ControlSummary {
    Arn: string;
    Aliases?: string[];
    Name: string;
    Description: string;
    Behavior?: ControlBehavior;
    Severity?: ControlSeverity;
    ParameterRequirementSummary?: ParameterRequirementSummary;
    Implementation?: ImplementationSummary;
    CreateTime?: Date;
    GovernedResources?: string[];
    GovernedProviders?: string[];
}
export declare const ControlSummary: S.Schema<ControlSummary>;
export type Controls = ControlSummary[];
export declare const Controls: any;
export interface ListControlsResponse {
    Controls: ControlSummary[];
    NextToken?: string;
}
export declare const ListControlsResponse: S.Schema<ListControlsResponse>;
export type MaxListDomainsResults = number;
export interface ListDomainsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDomainsRequest: S.Schema<ListDomainsRequest>;
export interface DomainSummary {
    Arn: string;
    Name: string;
    Description: string;
    CreateTime: Date;
    LastUpdateTime: Date;
}
export declare const DomainSummary: S.Schema<DomainSummary>;
export type DomainSummaryList = DomainSummary[];
export declare const DomainSummaryList: any;
export interface ListDomainsResponse {
    Domains: DomainSummary[];
    NextToken?: string;
}
export declare const ListDomainsResponse: S.Schema<ListDomainsResponse>;
export type MaxListObjectivesResults = number;
export interface DomainResourceFilter {
    Arn?: string;
}
export declare const DomainResourceFilter: S.Schema<DomainResourceFilter>;
export type DomainResourceFilterList = DomainResourceFilter[];
export declare const DomainResourceFilterList: any;
export interface ObjectiveFilter {
    Domains?: DomainResourceFilter[];
}
export declare const ObjectiveFilter: S.Schema<ObjectiveFilter>;
export interface ListObjectivesRequest {
    MaxResults?: number;
    NextToken?: string;
    ObjectiveFilter?: ObjectiveFilter;
}
export declare const ListObjectivesRequest: S.Schema<ListObjectivesRequest>;
export interface ObjectiveSummary {
    Arn: string;
    Name: string;
    Description: string;
    Domain: AssociatedDomainSummary;
    CreateTime: Date;
    LastUpdateTime: Date;
}
export declare const ObjectiveSummary: S.Schema<ObjectiveSummary>;
export type ObjectiveSummaryList = ObjectiveSummary[];
export declare const ObjectiveSummaryList: any;
export interface ListObjectivesResponse {
    Objectives: ObjectiveSummary[];
    NextToken?: string;
}
export declare const ListObjectivesResponse: S.Schema<ListObjectivesResponse>;
export type GetControlError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a specific control, most notably a list of Amazon Web Services Regions where this control is supported. Input a value for the *ControlArn* parameter, in ARN form. `GetControl` accepts *controltower* or *controlcatalog* control ARNs as input. Returns a *controlcatalog* ARN format.
 *
 * In the API response, controls that have the value `GLOBAL` in the `Scope` field do not show the `DeployableRegions` field, because it does not apply. Controls that have the value `REGIONAL` in the `Scope` field return a value for the `DeployableRegions` field, as shown in the example.
 */
export declare const getControl: API.OperationMethod<GetControlRequest, GetControlResponse, GetControlError, Credentials | HttpClient.HttpClient>;
export type ListCommonControlsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of common controls from the Amazon Web Services Control Catalog.
 *
 * You can apply an optional filter to see common controls that have a specific objective. If you don’t provide a filter, the operation returns all common controls.
 */
export declare const listCommonControls: API.PaginatedOperationMethod<ListCommonControlsRequest, ListCommonControlsResponse, ListCommonControlsError, Credentials | HttpClient.HttpClient, CommonControlSummary>;
export type ListControlMappingsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of control mappings from the Control Catalog. Control mappings show relationships between controls and other entities, such as common controls or compliance frameworks.
 */
export declare const listControlMappings: API.PaginatedOperationMethod<ListControlMappingsRequest, ListControlMappingsResponse, ListControlMappingsError, Credentials | HttpClient.HttpClient, ControlMapping>;
export type ListControlsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all available controls in the Control Catalog library. Allows you to discover available controls. The list of controls is given as structures of type *controlSummary*. The ARN is returned in the global *controlcatalog* format, as shown in the examples.
 */
export declare const listControls: API.PaginatedOperationMethod<ListControlsRequest, ListControlsResponse, ListControlsError, Credentials | HttpClient.HttpClient, ControlSummary>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of domains from the Control Catalog.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListObjectivesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of objectives from the Control Catalog.
 *
 * You can apply an optional filter to see the objectives that belong to a specific domain. If you don’t provide a filter, the operation returns all objectives.
 */
export declare const listObjectives: API.PaginatedOperationMethod<ListObjectivesRequest, ListObjectivesResponse, ListObjectivesError, Credentials | HttpClient.HttpClient, ObjectiveSummary>;
export {};
//# sourceMappingURL=controlcatalog.d.ts.map