import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const EventBusHasRules_base: S.Class<EventBusHasRules, S.TaggedStruct<"EventBusHasRules", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class EventBusHasRules extends /*@__PURE__*/ EventBusHasRules_base {
}
declare const IllegalStatusException_base: S.Class<IllegalStatusException, S.TaggedStruct<"IllegalStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IllegalStatusException extends /*@__PURE__*/ IllegalStatusException_base {
}
declare const InternalException_base: S.Class<InternalException, S.TaggedStruct<"InternalException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidEventPatternException_base: S.Class<InvalidEventPatternException, S.TaggedStruct<"InvalidEventPatternException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventPatternException extends /*@__PURE__*/ InvalidEventPatternException_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ManagedRuleException_base: S.Class<ManagedRuleException, S.TaggedStruct<"ManagedRuleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ManagedRuleException extends /*@__PURE__*/ ManagedRuleException_base {
}
declare const OperationDisabledException_base: S.Class<OperationDisabledException, S.TaggedStruct<"OperationDisabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationDisabledException extends /*@__PURE__*/ OperationDisabledException_base {
}
declare const PolicyLengthExceededException_base: S.Class<PolicyLengthExceededException, S.TaggedStruct<"PolicyLengthExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class PolicyLengthExceededException extends /*@__PURE__*/ PolicyLengthExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type EventSourceName = string;
export interface ActivateEventSourceRequest {
    Name: string;
}
export declare const ActivateEventSourceRequest: S.Schema<ActivateEventSourceRequest>;
export interface ActivateEventSourceResponse {
}
export declare const ActivateEventSourceResponse: S.Schema<ActivateEventSourceResponse>;
export type ReplayName = string;
export interface CancelReplayRequest {
    ReplayName: string;
}
export declare const CancelReplayRequest: S.Schema<CancelReplayRequest>;
export type ReplayArn = string;
export type ReplayState = "STARTING" | "RUNNING" | "CANCELLING" | "COMPLETED" | "CANCELLED" | "FAILED" | (string & {});
export declare const ReplayState: any;
export type ReplayStateReason = string;
export interface CancelReplayResponse {
    ReplayArn?: string;
    State?: ReplayState;
    StateReason?: string;
}
export declare const CancelReplayResponse: S.Schema<CancelReplayResponse>;
export type ApiDestinationName = string;
export type ApiDestinationDescription = string;
export type ConnectionArn = string;
export type HttpsEndpoint = string;
export type ApiDestinationHttpMethod = "POST" | "GET" | "HEAD" | "OPTIONS" | "PUT" | "PATCH" | "DELETE" | (string & {});
export declare const ApiDestinationHttpMethod: any;
export type ApiDestinationInvocationRateLimitPerSecond = number;
export interface CreateApiDestinationRequest {
    Name: string;
    Description?: string;
    ConnectionArn: string;
    InvocationEndpoint: string;
    HttpMethod: ApiDestinationHttpMethod;
    InvocationRateLimitPerSecond?: number;
}
export declare const CreateApiDestinationRequest: S.Schema<CreateApiDestinationRequest>;
export type ApiDestinationArn = string;
export type ApiDestinationState = "ACTIVE" | "INACTIVE" | (string & {});
export declare const ApiDestinationState: any;
export interface CreateApiDestinationResponse {
    ApiDestinationArn?: string;
    ApiDestinationState?: ApiDestinationState;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const CreateApiDestinationResponse: S.Schema<CreateApiDestinationResponse>;
export type ArchiveName = string;
export type EventBusArn = string;
export type ArchiveDescription = string;
export type EventPattern = string;
export type RetentionDays = number;
export type KmsKeyIdentifier = string;
export interface CreateArchiveRequest {
    ArchiveName: string;
    EventSourceArn: string;
    Description?: string;
    EventPattern?: string;
    RetentionDays?: number;
    KmsKeyIdentifier?: string;
}
export declare const CreateArchiveRequest: S.Schema<CreateArchiveRequest>;
export type ArchiveArn = string;
export type ArchiveState = "ENABLED" | "DISABLED" | "CREATING" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export declare const ArchiveState: any;
export type ArchiveStateReason = string;
export interface CreateArchiveResponse {
    ArchiveArn?: string;
    State?: ArchiveState;
    StateReason?: string;
    CreationTime?: Date;
}
export declare const CreateArchiveResponse: S.Schema<CreateArchiveResponse>;
export type ConnectionName = string;
export type ConnectionDescription = string;
export type ConnectionAuthorizationType = "BASIC" | "OAUTH_CLIENT_CREDENTIALS" | "API_KEY" | (string & {});
export declare const ConnectionAuthorizationType: any;
export type AuthHeaderParameters = string;
export type AuthHeaderParametersSensitive = string | redacted.Redacted<string>;
export interface CreateConnectionBasicAuthRequestParameters {
    Username: string;
    Password: string | redacted.Redacted<string>;
}
export declare const CreateConnectionBasicAuthRequestParameters: S.Schema<CreateConnectionBasicAuthRequestParameters>;
export interface CreateConnectionOAuthClientRequestParameters {
    ClientID: string;
    ClientSecret: string | redacted.Redacted<string>;
}
export declare const CreateConnectionOAuthClientRequestParameters: S.Schema<CreateConnectionOAuthClientRequestParameters>;
export type ConnectionOAuthHttpMethod = "GET" | "POST" | "PUT" | (string & {});
export declare const ConnectionOAuthHttpMethod: any;
export type HeaderKey = string;
export type HeaderValueSensitive = string | redacted.Redacted<string>;
export interface ConnectionHeaderParameter {
    Key?: string;
    Value?: string | redacted.Redacted<string>;
    IsValueSecret?: boolean;
}
export declare const ConnectionHeaderParameter: S.Schema<ConnectionHeaderParameter>;
export type ConnectionHeaderParametersList = ConnectionHeaderParameter[];
export declare const ConnectionHeaderParametersList: any;
export type QueryStringKey = string;
export type QueryStringValueSensitive = string | redacted.Redacted<string>;
export interface ConnectionQueryStringParameter {
    Key?: string;
    Value?: string | redacted.Redacted<string>;
    IsValueSecret?: boolean;
}
export declare const ConnectionQueryStringParameter: S.Schema<ConnectionQueryStringParameter>;
export type ConnectionQueryStringParametersList = ConnectionQueryStringParameter[];
export declare const ConnectionQueryStringParametersList: any;
export type SensitiveString = string | redacted.Redacted<string>;
export interface ConnectionBodyParameter {
    Key?: string;
    Value?: string | redacted.Redacted<string>;
    IsValueSecret?: boolean;
}
export declare const ConnectionBodyParameter: S.Schema<ConnectionBodyParameter>;
export type ConnectionBodyParametersList = ConnectionBodyParameter[];
export declare const ConnectionBodyParametersList: any;
export interface ConnectionHttpParameters {
    HeaderParameters?: ConnectionHeaderParameter[];
    QueryStringParameters?: ConnectionQueryStringParameter[];
    BodyParameters?: ConnectionBodyParameter[];
}
export declare const ConnectionHttpParameters: S.Schema<ConnectionHttpParameters>;
export interface CreateConnectionOAuthRequestParameters {
    ClientParameters: CreateConnectionOAuthClientRequestParameters;
    AuthorizationEndpoint: string;
    HttpMethod: ConnectionOAuthHttpMethod;
    OAuthHttpParameters?: ConnectionHttpParameters;
}
export declare const CreateConnectionOAuthRequestParameters: S.Schema<CreateConnectionOAuthRequestParameters>;
export interface CreateConnectionApiKeyAuthRequestParameters {
    ApiKeyName: string;
    ApiKeyValue: string | redacted.Redacted<string>;
}
export declare const CreateConnectionApiKeyAuthRequestParameters: S.Schema<CreateConnectionApiKeyAuthRequestParameters>;
export type ResourceConfigurationArn = string;
export interface ConnectivityResourceConfigurationArn {
    ResourceConfigurationArn: string;
}
export declare const ConnectivityResourceConfigurationArn: S.Schema<ConnectivityResourceConfigurationArn>;
export interface ConnectivityResourceParameters {
    ResourceParameters: ConnectivityResourceConfigurationArn;
}
export declare const ConnectivityResourceParameters: S.Schema<ConnectivityResourceParameters>;
export interface CreateConnectionAuthRequestParameters {
    BasicAuthParameters?: CreateConnectionBasicAuthRequestParameters;
    OAuthParameters?: CreateConnectionOAuthRequestParameters;
    ApiKeyAuthParameters?: CreateConnectionApiKeyAuthRequestParameters;
    InvocationHttpParameters?: ConnectionHttpParameters;
    ConnectivityParameters?: ConnectivityResourceParameters;
}
export declare const CreateConnectionAuthRequestParameters: S.Schema<CreateConnectionAuthRequestParameters>;
export interface CreateConnectionRequest {
    Name: string;
    Description?: string;
    AuthorizationType: ConnectionAuthorizationType;
    AuthParameters: CreateConnectionAuthRequestParameters;
    InvocationConnectivityParameters?: ConnectivityResourceParameters;
    KmsKeyIdentifier?: string;
}
export declare const CreateConnectionRequest: S.Schema<CreateConnectionRequest>;
export type ConnectionState = "CREATING" | "UPDATING" | "DELETING" | "AUTHORIZED" | "DEAUTHORIZED" | "AUTHORIZING" | "DEAUTHORIZING" | "ACTIVE" | "FAILED_CONNECTIVITY" | (string & {});
export declare const ConnectionState: any;
export interface CreateConnectionResponse {
    ConnectionArn?: string;
    ConnectionState?: ConnectionState;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const CreateConnectionResponse: S.Schema<CreateConnectionResponse>;
export type EndpointName = string;
export type EndpointDescription = string;
export type HealthCheck = string;
export interface Primary {
    HealthCheck: string;
}
export declare const Primary: S.Schema<Primary>;
export type Route = string;
export interface Secondary {
    Route: string;
}
export declare const Secondary: S.Schema<Secondary>;
export interface FailoverConfig {
    Primary: Primary;
    Secondary: Secondary;
}
export declare const FailoverConfig: S.Schema<FailoverConfig>;
export interface RoutingConfig {
    FailoverConfig: FailoverConfig;
}
export declare const RoutingConfig: S.Schema<RoutingConfig>;
export type ReplicationState = "ENABLED" | "DISABLED" | (string & {});
export declare const ReplicationState: any;
export interface ReplicationConfig {
    State?: ReplicationState;
}
export declare const ReplicationConfig: S.Schema<ReplicationConfig>;
export type NonPartnerEventBusArn = string;
export interface EndpointEventBus {
    EventBusArn: string;
}
export declare const EndpointEventBus: S.Schema<EndpointEventBus>;
export type EndpointEventBusList = EndpointEventBus[];
export declare const EndpointEventBusList: any;
export type IamRoleArn = string;
export interface CreateEndpointRequest {
    Name: string;
    Description?: string;
    RoutingConfig: RoutingConfig;
    ReplicationConfig?: ReplicationConfig;
    EventBuses: EndpointEventBus[];
    RoleArn?: string;
}
export declare const CreateEndpointRequest: S.Schema<CreateEndpointRequest>;
export type EndpointArn = string;
export type EndpointState = "ACTIVE" | "CREATING" | "UPDATING" | "DELETING" | "CREATE_FAILED" | "UPDATE_FAILED" | "DELETE_FAILED" | (string & {});
export declare const EndpointState: any;
export interface CreateEndpointResponse {
    Name?: string;
    Arn?: string;
    RoutingConfig?: RoutingConfig;
    ReplicationConfig?: ReplicationConfig;
    EventBuses?: EndpointEventBus[];
    RoleArn?: string;
    State?: EndpointState;
}
export declare const CreateEndpointResponse: S.Schema<CreateEndpointResponse>;
export type EventBusName = string;
export type EventBusDescription = string;
export type ResourceArn = string;
export interface DeadLetterConfig {
    Arn?: string;
}
export declare const DeadLetterConfig: S.Schema<DeadLetterConfig>;
export type IncludeDetail = "NONE" | "FULL" | (string & {});
export declare const IncludeDetail: any;
export type Level = "OFF" | "ERROR" | "INFO" | "TRACE" | (string & {});
export declare const Level: any;
export interface LogConfig {
    IncludeDetail?: IncludeDetail;
    Level?: Level;
}
export declare const LogConfig: S.Schema<LogConfig>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateEventBusRequest {
    Name: string;
    EventSourceName?: string;
    Description?: string;
    KmsKeyIdentifier?: string;
    DeadLetterConfig?: DeadLetterConfig;
    LogConfig?: LogConfig;
    Tags?: Tag[];
}
export declare const CreateEventBusRequest: S.Schema<CreateEventBusRequest>;
export interface CreateEventBusResponse {
    EventBusArn?: string;
    Description?: string;
    KmsKeyIdentifier?: string;
    DeadLetterConfig?: DeadLetterConfig;
    LogConfig?: LogConfig;
}
export declare const CreateEventBusResponse: S.Schema<CreateEventBusResponse>;
export type AccountId = string;
export interface CreatePartnerEventSourceRequest {
    Name: string;
    Account: string;
}
export declare const CreatePartnerEventSourceRequest: S.Schema<CreatePartnerEventSourceRequest>;
export interface CreatePartnerEventSourceResponse {
    EventSourceArn?: string;
}
export declare const CreatePartnerEventSourceResponse: S.Schema<CreatePartnerEventSourceResponse>;
export interface DeactivateEventSourceRequest {
    Name: string;
}
export declare const DeactivateEventSourceRequest: S.Schema<DeactivateEventSourceRequest>;
export interface DeactivateEventSourceResponse {
}
export declare const DeactivateEventSourceResponse: S.Schema<DeactivateEventSourceResponse>;
export interface DeauthorizeConnectionRequest {
    Name: string;
}
export declare const DeauthorizeConnectionRequest: S.Schema<DeauthorizeConnectionRequest>;
export interface DeauthorizeConnectionResponse {
    ConnectionArn?: string;
    ConnectionState?: ConnectionState;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LastAuthorizedTime?: Date;
}
export declare const DeauthorizeConnectionResponse: S.Schema<DeauthorizeConnectionResponse>;
export interface DeleteApiDestinationRequest {
    Name: string;
}
export declare const DeleteApiDestinationRequest: S.Schema<DeleteApiDestinationRequest>;
export interface DeleteApiDestinationResponse {
}
export declare const DeleteApiDestinationResponse: S.Schema<DeleteApiDestinationResponse>;
export interface DeleteArchiveRequest {
    ArchiveName: string;
}
export declare const DeleteArchiveRequest: S.Schema<DeleteArchiveRequest>;
export interface DeleteArchiveResponse {
}
export declare const DeleteArchiveResponse: S.Schema<DeleteArchiveResponse>;
export interface DeleteConnectionRequest {
    Name: string;
}
export declare const DeleteConnectionRequest: S.Schema<DeleteConnectionRequest>;
export interface DeleteConnectionResponse {
    ConnectionArn?: string;
    ConnectionState?: ConnectionState;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LastAuthorizedTime?: Date;
}
export declare const DeleteConnectionResponse: S.Schema<DeleteConnectionResponse>;
export interface DeleteEndpointRequest {
    Name: string;
}
export declare const DeleteEndpointRequest: S.Schema<DeleteEndpointRequest>;
export interface DeleteEndpointResponse {
}
export declare const DeleteEndpointResponse: S.Schema<DeleteEndpointResponse>;
export interface DeleteEventBusRequest {
    Name: string;
}
export declare const DeleteEventBusRequest: S.Schema<DeleteEventBusRequest>;
export interface DeleteEventBusResponse {
}
export declare const DeleteEventBusResponse: S.Schema<DeleteEventBusResponse>;
export interface DeletePartnerEventSourceRequest {
    Name: string;
    Account: string;
}
export declare const DeletePartnerEventSourceRequest: S.Schema<DeletePartnerEventSourceRequest>;
export interface DeletePartnerEventSourceResponse {
}
export declare const DeletePartnerEventSourceResponse: S.Schema<DeletePartnerEventSourceResponse>;
export type RuleName = string;
export type EventBusNameOrArn = string;
export interface DeleteRuleRequest {
    Name: string;
    EventBusName?: string;
    Force?: boolean;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export interface DeleteRuleResponse {
}
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface DescribeApiDestinationRequest {
    Name: string;
}
export declare const DescribeApiDestinationRequest: S.Schema<DescribeApiDestinationRequest>;
export interface DescribeApiDestinationResponse {
    ApiDestinationArn?: string;
    Name?: string;
    Description?: string;
    ApiDestinationState?: ApiDestinationState;
    ConnectionArn?: string;
    InvocationEndpoint?: string;
    HttpMethod?: ApiDestinationHttpMethod;
    InvocationRateLimitPerSecond?: number;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const DescribeApiDestinationResponse: S.Schema<DescribeApiDestinationResponse>;
export interface DescribeArchiveRequest {
    ArchiveName: string;
}
export declare const DescribeArchiveRequest: S.Schema<DescribeArchiveRequest>;
export interface DescribeArchiveResponse {
    ArchiveArn?: string;
    ArchiveName?: string;
    EventSourceArn?: string;
    Description?: string;
    EventPattern?: string;
    State?: ArchiveState;
    StateReason?: string;
    KmsKeyIdentifier?: string;
    RetentionDays?: number;
    SizeBytes?: number;
    EventCount?: number;
    CreationTime?: Date;
}
export declare const DescribeArchiveResponse: S.Schema<DescribeArchiveResponse>;
export interface DescribeConnectionRequest {
    Name: string;
}
export declare const DescribeConnectionRequest: S.Schema<DescribeConnectionRequest>;
export type ResourceAssociationArn = string;
export interface DescribeConnectionResourceParameters {
    ResourceConfigurationArn: string;
    ResourceAssociationArn: string;
}
export declare const DescribeConnectionResourceParameters: S.Schema<DescribeConnectionResourceParameters>;
export interface DescribeConnectionConnectivityParameters {
    ResourceParameters: DescribeConnectionResourceParameters;
}
export declare const DescribeConnectionConnectivityParameters: S.Schema<DescribeConnectionConnectivityParameters>;
export type ConnectionStateReason = string;
export type SecretsManagerSecretArn = string;
export interface ConnectionBasicAuthResponseParameters {
    Username?: string;
}
export declare const ConnectionBasicAuthResponseParameters: S.Schema<ConnectionBasicAuthResponseParameters>;
export interface ConnectionOAuthClientResponseParameters {
    ClientID?: string;
}
export declare const ConnectionOAuthClientResponseParameters: S.Schema<ConnectionOAuthClientResponseParameters>;
export interface ConnectionOAuthResponseParameters {
    ClientParameters?: ConnectionOAuthClientResponseParameters;
    AuthorizationEndpoint?: string;
    HttpMethod?: ConnectionOAuthHttpMethod;
    OAuthHttpParameters?: ConnectionHttpParameters;
}
export declare const ConnectionOAuthResponseParameters: S.Schema<ConnectionOAuthResponseParameters>;
export interface ConnectionApiKeyAuthResponseParameters {
    ApiKeyName?: string;
}
export declare const ConnectionApiKeyAuthResponseParameters: S.Schema<ConnectionApiKeyAuthResponseParameters>;
export interface ConnectionAuthResponseParameters {
    BasicAuthParameters?: ConnectionBasicAuthResponseParameters;
    OAuthParameters?: ConnectionOAuthResponseParameters;
    ApiKeyAuthParameters?: ConnectionApiKeyAuthResponseParameters;
    InvocationHttpParameters?: ConnectionHttpParameters;
    ConnectivityParameters?: DescribeConnectionConnectivityParameters;
}
export declare const ConnectionAuthResponseParameters: S.Schema<ConnectionAuthResponseParameters>;
export interface DescribeConnectionResponse {
    ConnectionArn?: string;
    Name?: string;
    Description?: string;
    InvocationConnectivityParameters?: DescribeConnectionConnectivityParameters;
    ConnectionState?: ConnectionState;
    StateReason?: string;
    AuthorizationType?: ConnectionAuthorizationType;
    SecretArn?: string;
    KmsKeyIdentifier?: string;
    AuthParameters?: ConnectionAuthResponseParameters;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LastAuthorizedTime?: Date;
}
export declare const DescribeConnectionResponse: S.Schema<DescribeConnectionResponse>;
export type HomeRegion = string;
export interface DescribeEndpointRequest {
    Name: string;
    HomeRegion?: string;
}
export declare const DescribeEndpointRequest: S.Schema<DescribeEndpointRequest>;
export type EndpointId = string;
export type EndpointUrl = string;
export type EndpointStateReason = string;
export interface DescribeEndpointResponse {
    Name?: string;
    Description?: string;
    Arn?: string;
    RoutingConfig?: RoutingConfig;
    ReplicationConfig?: ReplicationConfig;
    EventBuses?: EndpointEventBus[];
    RoleArn?: string;
    EndpointId?: string;
    EndpointUrl?: string;
    State?: EndpointState;
    StateReason?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const DescribeEndpointResponse: S.Schema<DescribeEndpointResponse>;
export interface DescribeEventBusRequest {
    Name?: string;
}
export declare const DescribeEventBusRequest: S.Schema<DescribeEventBusRequest>;
export interface DescribeEventBusResponse {
    Name?: string;
    Arn?: string;
    Description?: string;
    KmsKeyIdentifier?: string;
    DeadLetterConfig?: DeadLetterConfig;
    Policy?: string;
    LogConfig?: LogConfig;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const DescribeEventBusResponse: S.Schema<DescribeEventBusResponse>;
export interface DescribeEventSourceRequest {
    Name: string;
}
export declare const DescribeEventSourceRequest: S.Schema<DescribeEventSourceRequest>;
export type EventSourceState = "PENDING" | "ACTIVE" | "DELETED" | (string & {});
export declare const EventSourceState: any;
export interface DescribeEventSourceResponse {
    Arn?: string;
    CreatedBy?: string;
    CreationTime?: Date;
    ExpirationTime?: Date;
    Name?: string;
    State?: EventSourceState;
}
export declare const DescribeEventSourceResponse: S.Schema<DescribeEventSourceResponse>;
export interface DescribePartnerEventSourceRequest {
    Name: string;
}
export declare const DescribePartnerEventSourceRequest: S.Schema<DescribePartnerEventSourceRequest>;
export interface DescribePartnerEventSourceResponse {
    Arn?: string;
    Name?: string;
}
export declare const DescribePartnerEventSourceResponse: S.Schema<DescribePartnerEventSourceResponse>;
export interface DescribeReplayRequest {
    ReplayName: string;
}
export declare const DescribeReplayRequest: S.Schema<DescribeReplayRequest>;
export type ReplayDescription = string;
export type Arn = string;
export type ReplayDestinationFilters = string[];
export declare const ReplayDestinationFilters: any;
export interface ReplayDestination {
    Arn: string;
    FilterArns?: string[];
}
export declare const ReplayDestination: S.Schema<ReplayDestination>;
export interface DescribeReplayResponse {
    ReplayName?: string;
    ReplayArn?: string;
    Description?: string;
    State?: ReplayState;
    StateReason?: string;
    EventSourceArn?: string;
    Destination?: ReplayDestination;
    EventStartTime?: Date;
    EventEndTime?: Date;
    EventLastReplayedTime?: Date;
    ReplayStartTime?: Date;
    ReplayEndTime?: Date;
}
export declare const DescribeReplayResponse: S.Schema<DescribeReplayResponse>;
export interface DescribeRuleRequest {
    Name: string;
    EventBusName?: string;
}
export declare const DescribeRuleRequest: S.Schema<DescribeRuleRequest>;
export type RuleArn = string;
export type ScheduleExpression = string;
export type RuleState = "ENABLED" | "DISABLED" | "ENABLED_WITH_ALL_CLOUDTRAIL_MANAGEMENT_EVENTS" | (string & {});
export declare const RuleState: any;
export type RuleDescription = string;
export type RoleArn = string;
export type ManagedBy = string;
export type CreatedBy = string;
export interface DescribeRuleResponse {
    Name?: string;
    Arn?: string;
    EventPattern?: string;
    ScheduleExpression?: string;
    State?: RuleState;
    Description?: string;
    RoleArn?: string;
    ManagedBy?: string;
    EventBusName?: string;
    CreatedBy?: string;
}
export declare const DescribeRuleResponse: S.Schema<DescribeRuleResponse>;
export interface DisableRuleRequest {
    Name: string;
    EventBusName?: string;
}
export declare const DisableRuleRequest: S.Schema<DisableRuleRequest>;
export interface DisableRuleResponse {
}
export declare const DisableRuleResponse: S.Schema<DisableRuleResponse>;
export interface EnableRuleRequest {
    Name: string;
    EventBusName?: string;
}
export declare const EnableRuleRequest: S.Schema<EnableRuleRequest>;
export interface EnableRuleResponse {
}
export declare const EnableRuleResponse: S.Schema<EnableRuleResponse>;
export type NextToken = string;
export type LimitMax100 = number;
export interface ListApiDestinationsRequest {
    NamePrefix?: string;
    ConnectionArn?: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListApiDestinationsRequest: S.Schema<ListApiDestinationsRequest>;
export interface ApiDestination {
    ApiDestinationArn?: string;
    Name?: string;
    ApiDestinationState?: ApiDestinationState;
    ConnectionArn?: string;
    InvocationEndpoint?: string;
    HttpMethod?: ApiDestinationHttpMethod;
    InvocationRateLimitPerSecond?: number;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const ApiDestination: S.Schema<ApiDestination>;
export type ApiDestinationResponseList = ApiDestination[];
export declare const ApiDestinationResponseList: any;
export interface ListApiDestinationsResponse {
    ApiDestinations?: ApiDestination[];
    NextToken?: string;
}
export declare const ListApiDestinationsResponse: S.Schema<ListApiDestinationsResponse>;
export interface ListArchivesRequest {
    NamePrefix?: string;
    EventSourceArn?: string;
    State?: ArchiveState;
    NextToken?: string;
    Limit?: number;
}
export declare const ListArchivesRequest: S.Schema<ListArchivesRequest>;
export interface Archive {
    ArchiveName?: string;
    EventSourceArn?: string;
    State?: ArchiveState;
    StateReason?: string;
    RetentionDays?: number;
    SizeBytes?: number;
    EventCount?: number;
    CreationTime?: Date;
}
export declare const Archive: S.Schema<Archive>;
export type ArchiveResponseList = Archive[];
export declare const ArchiveResponseList: any;
export interface ListArchivesResponse {
    Archives?: Archive[];
    NextToken?: string;
}
export declare const ListArchivesResponse: S.Schema<ListArchivesResponse>;
export interface ListConnectionsRequest {
    NamePrefix?: string;
    ConnectionState?: ConnectionState;
    NextToken?: string;
    Limit?: number;
}
export declare const ListConnectionsRequest: S.Schema<ListConnectionsRequest>;
export interface Connection {
    ConnectionArn?: string;
    Name?: string;
    ConnectionState?: ConnectionState;
    StateReason?: string;
    AuthorizationType?: ConnectionAuthorizationType;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LastAuthorizedTime?: Date;
}
export declare const Connection: S.Schema<Connection>;
export type ConnectionResponseList = Connection[];
export declare const ConnectionResponseList: any;
export interface ListConnectionsResponse {
    Connections?: Connection[];
    NextToken?: string;
}
export declare const ListConnectionsResponse: S.Schema<ListConnectionsResponse>;
export interface ListEndpointsRequest {
    NamePrefix?: string;
    HomeRegion?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEndpointsRequest: S.Schema<ListEndpointsRequest>;
export interface Endpoint {
    Name?: string;
    Description?: string;
    Arn?: string;
    RoutingConfig?: RoutingConfig;
    ReplicationConfig?: ReplicationConfig;
    EventBuses?: EndpointEventBus[];
    RoleArn?: string;
    EndpointId?: string;
    EndpointUrl?: string;
    State?: EndpointState;
    StateReason?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const Endpoint: S.Schema<Endpoint>;
export type EndpointList = Endpoint[];
export declare const EndpointList: any;
export interface ListEndpointsResponse {
    Endpoints?: Endpoint[];
    NextToken?: string;
}
export declare const ListEndpointsResponse: S.Schema<ListEndpointsResponse>;
export interface ListEventBusesRequest {
    NamePrefix?: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListEventBusesRequest: S.Schema<ListEventBusesRequest>;
export interface EventBus {
    Name?: string;
    Arn?: string;
    Description?: string;
    Policy?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const EventBus: S.Schema<EventBus>;
export type EventBusList = EventBus[];
export declare const EventBusList: any;
export interface ListEventBusesResponse {
    EventBuses?: EventBus[];
    NextToken?: string;
}
export declare const ListEventBusesResponse: S.Schema<ListEventBusesResponse>;
export type EventSourceNamePrefix = string;
export interface ListEventSourcesRequest {
    NamePrefix?: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListEventSourcesRequest: S.Schema<ListEventSourcesRequest>;
export interface EventSource {
    Arn?: string;
    CreatedBy?: string;
    CreationTime?: Date;
    ExpirationTime?: Date;
    Name?: string;
    State?: EventSourceState;
}
export declare const EventSource: S.Schema<EventSource>;
export type EventSourceList = EventSource[];
export declare const EventSourceList: any;
export interface ListEventSourcesResponse {
    EventSources?: EventSource[];
    NextToken?: string;
}
export declare const ListEventSourcesResponse: S.Schema<ListEventSourcesResponse>;
export interface ListPartnerEventSourceAccountsRequest {
    EventSourceName: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListPartnerEventSourceAccountsRequest: S.Schema<ListPartnerEventSourceAccountsRequest>;
export interface PartnerEventSourceAccount {
    Account?: string;
    CreationTime?: Date;
    ExpirationTime?: Date;
    State?: EventSourceState;
}
export declare const PartnerEventSourceAccount: S.Schema<PartnerEventSourceAccount>;
export type PartnerEventSourceAccountList = PartnerEventSourceAccount[];
export declare const PartnerEventSourceAccountList: any;
export interface ListPartnerEventSourceAccountsResponse {
    PartnerEventSourceAccounts?: PartnerEventSourceAccount[];
    NextToken?: string;
}
export declare const ListPartnerEventSourceAccountsResponse: S.Schema<ListPartnerEventSourceAccountsResponse>;
export type PartnerEventSourceNamePrefix = string;
export interface ListPartnerEventSourcesRequest {
    NamePrefix: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListPartnerEventSourcesRequest: S.Schema<ListPartnerEventSourcesRequest>;
export interface PartnerEventSource {
    Arn?: string;
    Name?: string;
}
export declare const PartnerEventSource: S.Schema<PartnerEventSource>;
export type PartnerEventSourceList = PartnerEventSource[];
export declare const PartnerEventSourceList: any;
export interface ListPartnerEventSourcesResponse {
    PartnerEventSources?: PartnerEventSource[];
    NextToken?: string;
}
export declare const ListPartnerEventSourcesResponse: S.Schema<ListPartnerEventSourcesResponse>;
export interface ListReplaysRequest {
    NamePrefix?: string;
    State?: ReplayState;
    EventSourceArn?: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListReplaysRequest: S.Schema<ListReplaysRequest>;
export interface Replay {
    ReplayName?: string;
    EventSourceArn?: string;
    State?: ReplayState;
    StateReason?: string;
    EventStartTime?: Date;
    EventEndTime?: Date;
    EventLastReplayedTime?: Date;
    ReplayStartTime?: Date;
    ReplayEndTime?: Date;
}
export declare const Replay: S.Schema<Replay>;
export type ReplayList = Replay[];
export declare const ReplayList: any;
export interface ListReplaysResponse {
    Replays?: Replay[];
    NextToken?: string;
}
export declare const ListReplaysResponse: S.Schema<ListReplaysResponse>;
export type TargetArn = string;
export interface ListRuleNamesByTargetRequest {
    TargetArn: string;
    EventBusName?: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListRuleNamesByTargetRequest: S.Schema<ListRuleNamesByTargetRequest>;
export type RuleNameList = string[];
export declare const RuleNameList: any;
export interface ListRuleNamesByTargetResponse {
    RuleNames?: string[];
    NextToken?: string;
}
export declare const ListRuleNamesByTargetResponse: S.Schema<ListRuleNamesByTargetResponse>;
export interface ListRulesRequest {
    NamePrefix?: string;
    EventBusName?: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export interface Rule {
    Name?: string;
    Arn?: string;
    EventPattern?: string;
    State?: RuleState;
    Description?: string;
    ScheduleExpression?: string;
    RoleArn?: string;
    ManagedBy?: string;
    EventBusName?: string;
}
export declare const Rule: S.Schema<Rule>;
export type RuleResponseList = Rule[];
export declare const RuleResponseList: any;
export interface ListRulesResponse {
    Rules?: Rule[];
    NextToken?: string;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTargetsByRuleRequest {
    Rule: string;
    EventBusName?: string;
    NextToken?: string;
    Limit?: number;
}
export declare const ListTargetsByRuleRequest: S.Schema<ListTargetsByRuleRequest>;
export type TargetId = string;
export type TargetInput = string;
export type TargetInputPath = string;
export type InputTransformerPathKey = string;
export type TransformerPaths = {
    [key: string]: string | undefined;
};
export declare const TransformerPaths: any;
export type TransformerInput = string;
export interface InputTransformer {
    InputPathsMap?: {
        [key: string]: string | undefined;
    };
    InputTemplate: string;
}
export declare const InputTransformer: S.Schema<InputTransformer>;
export type TargetPartitionKeyPath = string;
export interface KinesisParameters {
    PartitionKeyPath: string;
}
export declare const KinesisParameters: S.Schema<KinesisParameters>;
export type RunCommandTargetKey = string;
export type RunCommandTargetValue = string;
export type RunCommandTargetValues = string[];
export declare const RunCommandTargetValues: any;
export interface RunCommandTarget {
    Key: string;
    Values: string[];
}
export declare const RunCommandTarget: S.Schema<RunCommandTarget>;
export type RunCommandTargets = RunCommandTarget[];
export declare const RunCommandTargets: any;
export interface RunCommandParameters {
    RunCommandTargets: RunCommandTarget[];
}
export declare const RunCommandParameters: S.Schema<RunCommandParameters>;
export type LimitMin1 = number;
export type LaunchType = "EC2" | "FARGATE" | "EXTERNAL" | (string & {});
export declare const LaunchType: any;
export type StringList = string[];
export declare const StringList: any;
export type AssignPublicIp = "ENABLED" | "DISABLED" | (string & {});
export declare const AssignPublicIp: any;
export interface AwsVpcConfiguration {
    Subnets: string[];
    SecurityGroups?: string[];
    AssignPublicIp?: AssignPublicIp;
}
export declare const AwsVpcConfiguration: S.Schema<AwsVpcConfiguration>;
export interface NetworkConfiguration {
    awsvpcConfiguration?: AwsVpcConfiguration;
}
export declare const NetworkConfiguration: S.Schema<NetworkConfiguration>;
export type CapacityProvider = string;
export type CapacityProviderStrategyItemWeight = number;
export type CapacityProviderStrategyItemBase = number;
export interface CapacityProviderStrategyItem {
    capacityProvider: string;
    weight?: number;
    base?: number;
}
export declare const CapacityProviderStrategyItem: S.Schema<CapacityProviderStrategyItem>;
export type CapacityProviderStrategy = CapacityProviderStrategyItem[];
export declare const CapacityProviderStrategy: any;
export type PlacementConstraintType = "distinctInstance" | "memberOf" | (string & {});
export declare const PlacementConstraintType: any;
export type PlacementConstraintExpression = string;
export interface PlacementConstraint {
    type?: PlacementConstraintType;
    expression?: string;
}
export declare const PlacementConstraint: S.Schema<PlacementConstraint>;
export type PlacementConstraints = PlacementConstraint[];
export declare const PlacementConstraints: any;
export type PlacementStrategyType = "random" | "spread" | "binpack" | (string & {});
export declare const PlacementStrategyType: any;
export type PlacementStrategyField = string;
export interface PlacementStrategy {
    type?: PlacementStrategyType;
    field?: string;
}
export declare const PlacementStrategy: S.Schema<PlacementStrategy>;
export type PlacementStrategies = PlacementStrategy[];
export declare const PlacementStrategies: any;
export type PropagateTags = "TASK_DEFINITION" | (string & {});
export declare const PropagateTags: any;
export type ReferenceId = string;
export interface EcsParameters {
    TaskDefinitionArn: string;
    TaskCount?: number;
    LaunchType?: LaunchType;
    NetworkConfiguration?: NetworkConfiguration;
    PlatformVersion?: string;
    Group?: string;
    CapacityProviderStrategy?: CapacityProviderStrategyItem[];
    EnableECSManagedTags?: boolean;
    EnableExecuteCommand?: boolean;
    PlacementConstraints?: PlacementConstraint[];
    PlacementStrategy?: PlacementStrategy[];
    PropagateTags?: PropagateTags;
    ReferenceId?: string;
    Tags?: Tag[];
}
export declare const EcsParameters: S.Schema<EcsParameters>;
export interface BatchArrayProperties {
    Size?: number;
}
export declare const BatchArrayProperties: S.Schema<BatchArrayProperties>;
export interface BatchRetryStrategy {
    Attempts?: number;
}
export declare const BatchRetryStrategy: S.Schema<BatchRetryStrategy>;
export interface BatchParameters {
    JobDefinition: string;
    JobName: string;
    ArrayProperties?: BatchArrayProperties;
    RetryStrategy?: BatchRetryStrategy;
}
export declare const BatchParameters: S.Schema<BatchParameters>;
export type MessageGroupId = string;
export interface SqsParameters {
    MessageGroupId?: string;
}
export declare const SqsParameters: S.Schema<SqsParameters>;
export type PathParameter = string;
export type PathParameterList = string[];
export declare const PathParameterList: any;
export type HeaderValue = string;
export type HeaderParametersMap = {
    [key: string]: string | undefined;
};
export declare const HeaderParametersMap: any;
export type QueryStringValue = string;
export type QueryStringParametersMap = {
    [key: string]: string | undefined;
};
export declare const QueryStringParametersMap: any;
export interface HttpParameters {
    PathParameterValues?: string[];
    HeaderParameters?: {
        [key: string]: string | undefined;
    };
    QueryStringParameters?: {
        [key: string]: string | undefined;
    };
}
export declare const HttpParameters: S.Schema<HttpParameters>;
export type RedshiftSecretManagerArn = string;
export type Database = string;
export type DbUser = string;
export type Sql = string | redacted.Redacted<string>;
export type StatementName = string;
export type Sqls = (string | redacted.Redacted<string>)[];
export declare const Sqls: any;
export interface RedshiftDataParameters {
    SecretManagerArn?: string;
    Database: string;
    DbUser?: string;
    Sql?: string | redacted.Redacted<string>;
    StatementName?: string;
    WithEvent?: boolean;
    Sqls?: (string | redacted.Redacted<string>)[];
}
export declare const RedshiftDataParameters: S.Schema<RedshiftDataParameters>;
export type SageMakerPipelineParameterName = string;
export type SageMakerPipelineParameterValue = string;
export interface SageMakerPipelineParameter {
    Name: string;
    Value: string;
}
export declare const SageMakerPipelineParameter: S.Schema<SageMakerPipelineParameter>;
export type SageMakerPipelineParameterList = SageMakerPipelineParameter[];
export declare const SageMakerPipelineParameterList: any;
export interface SageMakerPipelineParameters {
    PipelineParameterList?: SageMakerPipelineParameter[];
}
export declare const SageMakerPipelineParameters: S.Schema<SageMakerPipelineParameters>;
export type MaximumRetryAttempts = number;
export type MaximumEventAgeInSeconds = number;
export interface RetryPolicy {
    MaximumRetryAttempts?: number;
    MaximumEventAgeInSeconds?: number;
}
export declare const RetryPolicy: S.Schema<RetryPolicy>;
export type GraphQLOperation = string | redacted.Redacted<string>;
export interface AppSyncParameters {
    GraphQLOperation?: string | redacted.Redacted<string>;
}
export declare const AppSyncParameters: S.Schema<AppSyncParameters>;
export interface Target {
    Id: string;
    Arn: string;
    RoleArn?: string;
    Input?: string;
    InputPath?: string;
    InputTransformer?: InputTransformer;
    KinesisParameters?: KinesisParameters;
    RunCommandParameters?: RunCommandParameters;
    EcsParameters?: EcsParameters;
    BatchParameters?: BatchParameters;
    SqsParameters?: SqsParameters;
    HttpParameters?: HttpParameters;
    RedshiftDataParameters?: RedshiftDataParameters;
    SageMakerPipelineParameters?: SageMakerPipelineParameters;
    DeadLetterConfig?: DeadLetterConfig;
    RetryPolicy?: RetryPolicy;
    AppSyncParameters?: AppSyncParameters;
}
export declare const Target: S.Schema<Target>;
export type TargetList = Target[];
export declare const TargetList: any;
export interface ListTargetsByRuleResponse {
    Targets?: Target[];
    NextToken?: string;
}
export declare const ListTargetsByRuleResponse: S.Schema<ListTargetsByRuleResponse>;
export type EventTime = Date;
export type EventResource = string;
export type EventResourceList = string[];
export declare const EventResourceList: any;
export type NonPartnerEventBusNameOrArn = string;
export type TraceHeader = string;
export interface PutEventsRequestEntry {
    Time?: Date;
    Source?: string;
    Resources?: string[];
    DetailType?: string;
    Detail?: string;
    EventBusName?: string;
    TraceHeader?: string;
}
export declare const PutEventsRequestEntry: S.Schema<PutEventsRequestEntry>;
export type PutEventsRequestEntryList = PutEventsRequestEntry[];
export declare const PutEventsRequestEntryList: any;
export interface PutEventsRequest {
    Entries: PutEventsRequestEntry[];
    EndpointId?: string;
}
export declare const PutEventsRequest: S.Schema<PutEventsRequest>;
export type EventId = string;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface PutEventsResultEntry {
    EventId?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const PutEventsResultEntry: S.Schema<PutEventsResultEntry>;
export type PutEventsResultEntryList = PutEventsResultEntry[];
export declare const PutEventsResultEntryList: any;
export interface PutEventsResponse {
    FailedEntryCount?: number;
    Entries?: PutEventsResultEntry[];
}
export declare const PutEventsResponse: S.Schema<PutEventsResponse>;
export interface PutPartnerEventsRequestEntry {
    Time?: Date;
    Source?: string;
    Resources?: string[];
    DetailType?: string;
    Detail?: string;
}
export declare const PutPartnerEventsRequestEntry: S.Schema<PutPartnerEventsRequestEntry>;
export type PutPartnerEventsRequestEntryList = PutPartnerEventsRequestEntry[];
export declare const PutPartnerEventsRequestEntryList: any;
export interface PutPartnerEventsRequest {
    Entries: PutPartnerEventsRequestEntry[];
}
export declare const PutPartnerEventsRequest: S.Schema<PutPartnerEventsRequest>;
export interface PutPartnerEventsResultEntry {
    EventId?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const PutPartnerEventsResultEntry: S.Schema<PutPartnerEventsResultEntry>;
export type PutPartnerEventsResultEntryList = PutPartnerEventsResultEntry[];
export declare const PutPartnerEventsResultEntryList: any;
export interface PutPartnerEventsResponse {
    FailedEntryCount?: number;
    Entries?: PutPartnerEventsResultEntry[];
}
export declare const PutPartnerEventsResponse: S.Schema<PutPartnerEventsResponse>;
export type NonPartnerEventBusName = string;
export type Action = string;
export type Principal = string;
export type StatementId = string;
export interface Condition {
    Type: string;
    Key: string;
    Value: string;
}
export declare const Condition: S.Schema<Condition>;
export interface PutPermissionRequest {
    EventBusName?: string;
    Action?: string;
    Principal?: string;
    StatementId?: string;
    Condition?: Condition;
    Policy?: string;
}
export declare const PutPermissionRequest: S.Schema<PutPermissionRequest>;
export interface PutPermissionResponse {
}
export declare const PutPermissionResponse: S.Schema<PutPermissionResponse>;
export interface PutRuleRequest {
    Name: string;
    ScheduleExpression?: string;
    EventPattern?: string;
    State?: RuleState;
    Description?: string;
    RoleArn?: string;
    Tags?: Tag[];
    EventBusName?: string;
}
export declare const PutRuleRequest: S.Schema<PutRuleRequest>;
export interface PutRuleResponse {
    RuleArn?: string;
}
export declare const PutRuleResponse: S.Schema<PutRuleResponse>;
export interface PutTargetsRequest {
    Rule: string;
    EventBusName?: string;
    Targets: Target[];
}
export declare const PutTargetsRequest: S.Schema<PutTargetsRequest>;
export interface PutTargetsResultEntry {
    TargetId?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const PutTargetsResultEntry: S.Schema<PutTargetsResultEntry>;
export type PutTargetsResultEntryList = PutTargetsResultEntry[];
export declare const PutTargetsResultEntryList: any;
export interface PutTargetsResponse {
    FailedEntryCount?: number;
    FailedEntries?: PutTargetsResultEntry[];
}
export declare const PutTargetsResponse: S.Schema<PutTargetsResponse>;
export interface RemovePermissionRequest {
    StatementId?: string;
    RemoveAllPermissions?: boolean;
    EventBusName?: string;
}
export declare const RemovePermissionRequest: S.Schema<RemovePermissionRequest>;
export interface RemovePermissionResponse {
}
export declare const RemovePermissionResponse: S.Schema<RemovePermissionResponse>;
export type TargetIdList = string[];
export declare const TargetIdList: any;
export interface RemoveTargetsRequest {
    Rule: string;
    EventBusName?: string;
    Ids: string[];
    Force?: boolean;
}
export declare const RemoveTargetsRequest: S.Schema<RemoveTargetsRequest>;
export interface RemoveTargetsResultEntry {
    TargetId?: string;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const RemoveTargetsResultEntry: S.Schema<RemoveTargetsResultEntry>;
export type RemoveTargetsResultEntryList = RemoveTargetsResultEntry[];
export declare const RemoveTargetsResultEntryList: any;
export interface RemoveTargetsResponse {
    FailedEntryCount?: number;
    FailedEntries?: RemoveTargetsResultEntry[];
}
export declare const RemoveTargetsResponse: S.Schema<RemoveTargetsResponse>;
export interface StartReplayRequest {
    ReplayName: string;
    Description?: string;
    EventSourceArn: string;
    EventStartTime: Date;
    EventEndTime: Date;
    Destination: ReplayDestination;
}
export declare const StartReplayRequest: S.Schema<StartReplayRequest>;
export interface StartReplayResponse {
    ReplayArn?: string;
    State?: ReplayState;
    StateReason?: string;
    ReplayStartTime?: Date;
}
export declare const StartReplayResponse: S.Schema<StartReplayResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface TestEventPatternRequest {
    EventPattern: string;
    Event: string;
}
export declare const TestEventPatternRequest: S.Schema<TestEventPatternRequest>;
export interface TestEventPatternResponse {
    Result?: boolean;
}
export declare const TestEventPatternResponse: S.Schema<TestEventPatternResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateApiDestinationRequest {
    Name: string;
    Description?: string;
    ConnectionArn?: string;
    InvocationEndpoint?: string;
    HttpMethod?: ApiDestinationHttpMethod;
    InvocationRateLimitPerSecond?: number;
}
export declare const UpdateApiDestinationRequest: S.Schema<UpdateApiDestinationRequest>;
export interface UpdateApiDestinationResponse {
    ApiDestinationArn?: string;
    ApiDestinationState?: ApiDestinationState;
    CreationTime?: Date;
    LastModifiedTime?: Date;
}
export declare const UpdateApiDestinationResponse: S.Schema<UpdateApiDestinationResponse>;
export interface UpdateArchiveRequest {
    ArchiveName: string;
    Description?: string;
    EventPattern?: string;
    RetentionDays?: number;
    KmsKeyIdentifier?: string;
}
export declare const UpdateArchiveRequest: S.Schema<UpdateArchiveRequest>;
export interface UpdateArchiveResponse {
    ArchiveArn?: string;
    State?: ArchiveState;
    StateReason?: string;
    CreationTime?: Date;
}
export declare const UpdateArchiveResponse: S.Schema<UpdateArchiveResponse>;
export interface UpdateConnectionBasicAuthRequestParameters {
    Username?: string;
    Password?: string | redacted.Redacted<string>;
}
export declare const UpdateConnectionBasicAuthRequestParameters: S.Schema<UpdateConnectionBasicAuthRequestParameters>;
export interface UpdateConnectionOAuthClientRequestParameters {
    ClientID?: string;
    ClientSecret?: string | redacted.Redacted<string>;
}
export declare const UpdateConnectionOAuthClientRequestParameters: S.Schema<UpdateConnectionOAuthClientRequestParameters>;
export interface UpdateConnectionOAuthRequestParameters {
    ClientParameters?: UpdateConnectionOAuthClientRequestParameters;
    AuthorizationEndpoint?: string;
    HttpMethod?: ConnectionOAuthHttpMethod;
    OAuthHttpParameters?: ConnectionHttpParameters;
}
export declare const UpdateConnectionOAuthRequestParameters: S.Schema<UpdateConnectionOAuthRequestParameters>;
export interface UpdateConnectionApiKeyAuthRequestParameters {
    ApiKeyName?: string;
    ApiKeyValue?: string | redacted.Redacted<string>;
}
export declare const UpdateConnectionApiKeyAuthRequestParameters: S.Schema<UpdateConnectionApiKeyAuthRequestParameters>;
export interface UpdateConnectionAuthRequestParameters {
    BasicAuthParameters?: UpdateConnectionBasicAuthRequestParameters;
    OAuthParameters?: UpdateConnectionOAuthRequestParameters;
    ApiKeyAuthParameters?: UpdateConnectionApiKeyAuthRequestParameters;
    InvocationHttpParameters?: ConnectionHttpParameters;
    ConnectivityParameters?: ConnectivityResourceParameters;
}
export declare const UpdateConnectionAuthRequestParameters: S.Schema<UpdateConnectionAuthRequestParameters>;
export interface UpdateConnectionRequest {
    Name: string;
    Description?: string;
    AuthorizationType?: ConnectionAuthorizationType;
    AuthParameters?: UpdateConnectionAuthRequestParameters;
    InvocationConnectivityParameters?: ConnectivityResourceParameters;
    KmsKeyIdentifier?: string;
}
export declare const UpdateConnectionRequest: S.Schema<UpdateConnectionRequest>;
export interface UpdateConnectionResponse {
    ConnectionArn?: string;
    ConnectionState?: ConnectionState;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LastAuthorizedTime?: Date;
}
export declare const UpdateConnectionResponse: S.Schema<UpdateConnectionResponse>;
export interface UpdateEndpointRequest {
    Name: string;
    Description?: string;
    RoutingConfig?: RoutingConfig;
    ReplicationConfig?: ReplicationConfig;
    EventBuses?: EndpointEventBus[];
    RoleArn?: string;
}
export declare const UpdateEndpointRequest: S.Schema<UpdateEndpointRequest>;
export interface UpdateEndpointResponse {
    Name?: string;
    Arn?: string;
    RoutingConfig?: RoutingConfig;
    ReplicationConfig?: ReplicationConfig;
    EventBuses?: EndpointEventBus[];
    RoleArn?: string;
    EndpointId?: string;
    EndpointUrl?: string;
    State?: EndpointState;
}
export declare const UpdateEndpointResponse: S.Schema<UpdateEndpointResponse>;
export interface UpdateEventBusRequest {
    Name?: string;
    KmsKeyIdentifier?: string;
    Description?: string;
    DeadLetterConfig?: DeadLetterConfig;
    LogConfig?: LogConfig;
}
export declare const UpdateEventBusRequest: S.Schema<UpdateEventBusRequest>;
export interface UpdateEventBusResponse {
    Arn?: string;
    Name?: string;
    KmsKeyIdentifier?: string;
    Description?: string;
    DeadLetterConfig?: DeadLetterConfig;
    LogConfig?: LogConfig;
}
export declare const UpdateEventBusResponse: S.Schema<UpdateEventBusResponse>;
export type ActivateEventSourceError = ConcurrentModificationException | InternalException | InvalidStateException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * Activates a partner event source that has been deactivated. Once activated, your matching
 * event bus will start receiving events from the event source.
 */
export declare const activateEventSource: API.OperationMethod<ActivateEventSourceRequest, ActivateEventSourceResponse, ActivateEventSourceError, Credentials | HttpClient.HttpClient>;
export type CancelReplayError = ConcurrentModificationException | IllegalStatusException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels the specified replay.
 */
export declare const cancelReplay: API.OperationMethod<CancelReplayRequest, CancelReplayResponse, CancelReplayError, Credentials | HttpClient.HttpClient>;
export type CreateApiDestinationError = InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an API destination, which is an HTTP invocation endpoint configured as a target
 * for events.
 *
 * API destinations do not support private destinations, such as interface VPC
 * endpoints.
 *
 * For more information, see API destinations in the
 * *EventBridge User Guide*.
 */
export declare const createApiDestination: API.OperationMethod<CreateApiDestinationRequest, CreateApiDestinationResponse, CreateApiDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateArchiveError = ConcurrentModificationException | InternalException | InvalidEventPatternException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an archive of events with the specified settings. When you create an archive,
 * incoming events might not immediately start being sent to the archive. Allow a short period of
 * time for changes to take effect. If you do not specify a pattern to filter events sent to the
 * archive, all events are sent to the archive except replayed events. Replayed events are not
 * sent to an archive.
 *
 * If you have specified that EventBridge use a customer managed key for encrypting the source event bus, we strongly recommend you also specify a
 * customer managed key for any archives for the event bus as well.
 *
 * For more information, see Encrypting archives in the *Amazon EventBridge User Guide*.
 */
export declare const createArchive: API.OperationMethod<CreateArchiveRequest, CreateArchiveResponse, CreateArchiveError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = AccessDeniedException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a connection. A connection defines the authorization type and credentials to use
 * for authorization with an API destination HTTP endpoint.
 *
 * For more information, see Connections for endpoint targets in the *Amazon EventBridge User Guide*.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointError = InternalException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a global endpoint. Global endpoints improve your application's availability by
 * making it regional-fault tolerant. To do this, you define a primary and secondary Region with
 * event buses in each Region. You also create a Amazon Route 53 health check that will
 * tell EventBridge to route events to the secondary Region when an "unhealthy" state is
 * encountered and events will be routed back to the primary Region when the health check reports
 * a "healthy" state.
 */
export declare const createEndpoint: API.OperationMethod<CreateEndpointRequest, CreateEndpointResponse, CreateEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateEventBusError = ConcurrentModificationException | InternalException | InvalidStateException | LimitExceededException | OperationDisabledException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new event bus within your account. This can be a custom event bus which you can
 * use to receive events from your custom applications and services, or it can be a partner event
 * bus which can be matched to a partner event source.
 */
export declare const createEventBus: API.OperationMethod<CreateEventBusRequest, CreateEventBusResponse, CreateEventBusError, Credentials | HttpClient.HttpClient>;
export type CreatePartnerEventSourceError = ConcurrentModificationException | InternalException | LimitExceededException | OperationDisabledException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Called by an SaaS partner to create a partner event source. This operation is not used by
 * Amazon Web Services customers.
 *
 * Each partner event source can be used by one Amazon Web Services account to create a
 * matching partner event bus in that Amazon Web Services account. A SaaS partner must create one
 * partner event source for each Amazon Web Services account that wants to receive those event
 * types.
 *
 * A partner event source creates events based on resources within the SaaS partner's service
 * or application.
 *
 * An Amazon Web Services account that creates a partner event bus that matches the partner
 * event source can use that event bus to receive events from the partner, and then process them
 * using Amazon Web Services Events rules and targets.
 *
 * Partner event source names follow this format:
 *
 * *partner_name*\/*event_namespace*\/*event_name*
 *
 * - *partner_name* is determined during partner registration, and
 * identifies the partner to Amazon Web Services customers.
 *
 * - *event_namespace* is determined by the partner, and is a way for
 * the partner to categorize their events.
 *
 * - *event_name* is determined by the partner, and should uniquely
 * identify an event-generating resource within the partner system.
 *
 * The *event_name* must be unique across all Amazon Web Services
 * customers. This is because the event source is a shared resource between the partner and
 * customer accounts, and each partner event source unique in the partner account.
 *
 * The combination of *event_namespace* and
 * *event_name* should help Amazon Web Services customers decide whether to
 * create an event bus to receive these events.
 */
export declare const createPartnerEventSource: API.OperationMethod<CreatePartnerEventSourceRequest, CreatePartnerEventSourceResponse, CreatePartnerEventSourceError, Credentials | HttpClient.HttpClient>;
export type DeactivateEventSourceError = ConcurrentModificationException | InternalException | InvalidStateException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * You can use this operation to temporarily stop receiving events from the specified partner
 * event source. The matching event bus is not deleted.
 *
 * When you deactivate a partner event source, the source goes into PENDING state. If it
 * remains in PENDING state for more than two weeks, it is deleted.
 *
 * To activate a deactivated partner event source, use ActivateEventSource.
 */
export declare const deactivateEventSource: API.OperationMethod<DeactivateEventSourceRequest, DeactivateEventSourceResponse, DeactivateEventSourceError, Credentials | HttpClient.HttpClient>;
export type DeauthorizeConnectionError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Removes all authorization parameters from the connection. This lets you remove the secret
 * from the connection so you can reuse it without having to create a new connection.
 */
export declare const deauthorizeConnection: API.OperationMethod<DeauthorizeConnectionRequest, DeauthorizeConnectionResponse, DeauthorizeConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteApiDestinationError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified API destination.
 */
export declare const deleteApiDestination: API.OperationMethod<DeleteApiDestinationRequest, DeleteApiDestinationResponse, DeleteApiDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteArchiveError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified archive.
 */
export declare const deleteArchive: API.OperationMethod<DeleteArchiveRequest, DeleteArchiveResponse, DeleteArchiveError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a connection.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an existing global endpoint. For more information about global endpoints, see
 * Making applications Regional-fault tolerant with global endpoints and event
 * replication in the
 * *Amazon EventBridge User Guide*
 * .
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointRequest, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEventBusError = ConcurrentModificationException | InternalException | ResourceNotFoundException | EventBusHasRules | CommonErrors;
/**
 * Deletes the specified custom event bus or partner event bus. All rules associated with
 * this event bus need to be deleted. You can't delete your account's default event bus.
 */
export declare const deleteEventBus: API.OperationMethod<DeleteEventBusRequest, DeleteEventBusResponse, DeleteEventBusError, Credentials | HttpClient.HttpClient>;
export type DeletePartnerEventSourceError = ConcurrentModificationException | InternalException | OperationDisabledException | CommonErrors;
/**
 * This operation is used by SaaS partners to delete a partner event source. This operation
 * is not used by Amazon Web Services customers.
 *
 * When you delete an event source, the status of the corresponding partner event bus in the
 * Amazon Web Services customer account becomes DELETED.
 */
export declare const deletePartnerEventSource: API.OperationMethod<DeletePartnerEventSourceRequest, DeletePartnerEventSourceResponse, DeletePartnerEventSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified rule.
 *
 * Before you can delete the rule, you must remove all targets, using RemoveTargets.
 *
 * When you delete a rule, incoming events might continue to match to the deleted rule. Allow
 * a short period of time for changes to take effect.
 *
 * If you call delete rule multiple times for the same rule, all calls will succeed. When you
 * call delete rule for a non-existent custom eventbus, `ResourceNotFoundException` is
 * returned.
 *
 * Managed rules are rules created and managed by another Amazon Web Services service on your
 * behalf. These rules are created by those other Amazon Web Services services to support
 * functionality in those services. You can delete these rules using the `Force`
 * option, but you should do so only if you are sure the other service is not still using that
 * rule.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DescribeApiDestinationError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about an API destination.
 */
export declare const describeApiDestination: API.OperationMethod<DescribeApiDestinationRequest, DescribeApiDestinationResponse, DescribeApiDestinationError, Credentials | HttpClient.HttpClient>;
export type DescribeArchiveError = InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about an archive.
 */
export declare const describeArchive: API.OperationMethod<DescribeArchiveRequest, DescribeArchiveResponse, DescribeArchiveError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about a connection.
 */
export declare const describeConnection: API.OperationMethod<DescribeConnectionRequest, DescribeConnectionResponse, DescribeConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Get the information about an existing global endpoint. For more information about global
 * endpoints, see Making applications
 * Regional-fault tolerant with global endpoints and event replication in the
 *
 * *Amazon EventBridge User Guide*
 * .
 */
export declare const describeEndpoint: API.OperationMethod<DescribeEndpointRequest, DescribeEndpointResponse, DescribeEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeEventBusError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Displays details about an event bus in your account. This can include the external Amazon Web Services accounts that are permitted to write events to your default event bus, and the
 * associated policy. For custom event buses and partner event buses, it displays the name, ARN,
 * policy, state, and creation time.
 *
 * To enable your account to receive events from other accounts on its default event bus,
 * use PutPermission.
 *
 * For more information about partner event buses, see CreateEventBus.
 */
export declare const describeEventBus: API.OperationMethod<DescribeEventBusRequest, DescribeEventBusResponse, DescribeEventBusError, Credentials | HttpClient.HttpClient>;
export type DescribeEventSourceError = InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * This operation lists details about a partner event source that is shared with your
 * account.
 */
export declare const describeEventSource: API.OperationMethod<DescribeEventSourceRequest, DescribeEventSourceResponse, DescribeEventSourceError, Credentials | HttpClient.HttpClient>;
export type DescribePartnerEventSourceError = InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * An SaaS partner can use this operation to list details about a partner event source that
 * they have created. Amazon Web Services customers do not use this operation. Instead, Amazon Web Services customers can use DescribeEventSource to see details about a partner event source that is shared with
 * them.
 */
export declare const describePartnerEventSource: API.OperationMethod<DescribePartnerEventSourceRequest, DescribePartnerEventSourceResponse, DescribePartnerEventSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeReplayError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about a replay. Use `DescribeReplay` to determine the
 * progress of a running replay. A replay processes events to replay based on the time in the
 * event, and replays them using 1 minute intervals. If you use `StartReplay` and
 * specify an `EventStartTime` and an `EventEndTime` that covers a 20
 * minute time range, the events are replayed from the first minute of that 20 minute range
 * first. Then the events from the second minute are replayed. You can use
 * `DescribeReplay` to determine the progress of a replay. The value returned for
 * `EventLastReplayedTime` indicates the time within the specified time range
 * associated with the last event replayed.
 */
export declare const describeReplay: API.OperationMethod<DescribeReplayRequest, DescribeReplayResponse, DescribeReplayError, Credentials | HttpClient.HttpClient>;
export type DescribeRuleError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the specified rule.
 *
 * DescribeRule does not list the targets of a rule. To see the targets associated with a
 * rule, use ListTargetsByRule.
 */
export declare const describeRule: API.OperationMethod<DescribeRuleRequest, DescribeRuleResponse, DescribeRuleError, Credentials | HttpClient.HttpClient>;
export type DisableRuleError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Disables the specified rule. A disabled rule won't match any events, and won't
 * self-trigger if it has a schedule expression.
 *
 * When you disable a rule, incoming events might continue to match to the disabled rule.
 * Allow a short period of time for changes to take effect.
 */
export declare const disableRule: API.OperationMethod<DisableRuleRequest, DisableRuleResponse, DisableRuleError, Credentials | HttpClient.HttpClient>;
export type EnableRuleError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Enables the specified rule. If the rule does not exist, the operation fails.
 *
 * When you enable a rule, incoming events might not immediately start matching to a newly
 * enabled rule. Allow a short period of time for changes to take effect.
 */
export declare const enableRule: API.OperationMethod<EnableRuleRequest, EnableRuleResponse, EnableRuleError, Credentials | HttpClient.HttpClient>;
export type ListApiDestinationsError = InternalException | CommonErrors;
/**
 * Retrieves a list of API destination in the account in the current Region.
 */
export declare const listApiDestinations: API.OperationMethod<ListApiDestinationsRequest, ListApiDestinationsResponse, ListApiDestinationsError, Credentials | HttpClient.HttpClient>;
export type ListArchivesError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists your archives. You can either list all the archives or you can provide a prefix to
 * match to the archive names. Filter parameters are exclusive.
 */
export declare const listArchives: API.OperationMethod<ListArchivesRequest, ListArchivesResponse, ListArchivesError, Credentials | HttpClient.HttpClient>;
export type ListConnectionsError = InternalException | CommonErrors;
/**
 * Retrieves a list of connections from the account.
 */
export declare const listConnections: API.OperationMethod<ListConnectionsRequest, ListConnectionsResponse, ListConnectionsError, Credentials | HttpClient.HttpClient>;
export type ListEndpointsError = InternalException | CommonErrors;
/**
 * List the global endpoints associated with this account. For more information about global
 * endpoints, see Making applications
 * Regional-fault tolerant with global endpoints and event replication in the
 *
 * *Amazon EventBridge User Guide*
 * .
 */
export declare const listEndpoints: API.OperationMethod<ListEndpointsRequest, ListEndpointsResponse, ListEndpointsError, Credentials | HttpClient.HttpClient>;
export type ListEventBusesError = InternalException | CommonErrors;
/**
 * Lists all the event buses in your account, including the default event bus, custom event
 * buses, and partner event buses.
 */
export declare const listEventBuses: API.OperationMethod<ListEventBusesRequest, ListEventBusesResponse, ListEventBusesError, Credentials | HttpClient.HttpClient>;
export type ListEventSourcesError = InternalException | OperationDisabledException | CommonErrors;
/**
 * You can use this to see all the partner event sources that have been shared with your
 * Amazon Web Services account. For more information about partner event sources, see CreateEventBus.
 */
export declare const listEventSources: API.OperationMethod<ListEventSourcesRequest, ListEventSourcesResponse, ListEventSourcesError, Credentials | HttpClient.HttpClient>;
export type ListPartnerEventSourceAccountsError = InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * An SaaS partner can use this operation to display the Amazon Web Services account ID that a
 * particular partner event source name is associated with. This operation is not used by Amazon Web Services customers.
 */
export declare const listPartnerEventSourceAccounts: API.OperationMethod<ListPartnerEventSourceAccountsRequest, ListPartnerEventSourceAccountsResponse, ListPartnerEventSourceAccountsError, Credentials | HttpClient.HttpClient>;
export type ListPartnerEventSourcesError = InternalException | OperationDisabledException | CommonErrors;
/**
 * An SaaS partner can use this operation to list all the partner event source names that
 * they have created. This operation is not used by Amazon Web Services customers.
 */
export declare const listPartnerEventSources: API.OperationMethod<ListPartnerEventSourcesRequest, ListPartnerEventSourcesResponse, ListPartnerEventSourcesError, Credentials | HttpClient.HttpClient>;
export type ListReplaysError = InternalException | CommonErrors;
/**
 * Lists your replays. You can either list all the replays or you can provide a prefix to
 * match to the replay names. Filter parameters are exclusive.
 */
export declare const listReplays: API.OperationMethod<ListReplaysRequest, ListReplaysResponse, ListReplaysError, Credentials | HttpClient.HttpClient>;
export type ListRuleNamesByTargetError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the rules for the specified target. You can see which of the rules in Amazon
 * EventBridge can invoke a specific target in your account.
 *
 * The maximum number of results per page for requests is 100.
 */
export declare const listRuleNamesByTarget: API.OperationMethod<ListRuleNamesByTargetRequest, ListRuleNamesByTargetResponse, ListRuleNamesByTargetError, Credentials | HttpClient.HttpClient>;
export type ListRulesError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists your Amazon EventBridge rules. You can either list all the rules or you can
 * provide a prefix to match to the rule names.
 *
 * The maximum number of results per page for requests is 100.
 *
 * ListRules does not list the targets of a rule. To see the targets associated with a rule,
 * use ListTargetsByRule.
 */
export declare const listRules: API.OperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Displays the tags associated with an EventBridge resource. In EventBridge, rules and event
 * buses can be tagged.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetsByRuleError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the targets assigned to the specified rule.
 *
 * The maximum number of results per page for requests is 100.
 */
export declare const listTargetsByRule: API.OperationMethod<ListTargetsByRuleRequest, ListTargetsByRuleResponse, ListTargetsByRuleError, Credentials | HttpClient.HttpClient>;
export type PutEventsError = InternalException | CommonErrors;
/**
 * Sends custom events to Amazon EventBridge so that they can be matched to rules.
 *
 * You can batch multiple event entries into one request for efficiency.
 * However, the total entry size must be less than 256KB. You can calculate the entry size before you send the events.
 * For more information, see Calculating PutEvents event entry
 * size in the
 * *Amazon EventBridge User Guide*
 * .
 *
 * PutEvents accepts the data in JSON format. For the JSON number (integer) data type, the
 * constraints are: a minimum value of -9,223,372,036,854,775,808 and a maximum value of
 * 9,223,372,036,854,775,807.
 *
 * PutEvents will only process nested JSON up to 1000 levels deep.
 */
export declare const putEvents: API.OperationMethod<PutEventsRequest, PutEventsResponse, PutEventsError, Credentials | HttpClient.HttpClient>;
export type PutPartnerEventsError = InternalException | OperationDisabledException | CommonErrors;
/**
 * This is used by SaaS partners to write events to a customer's partner event bus. Amazon Web Services customers do not use this operation.
 *
 * For information on calculating event batch size, see Calculating EventBridge PutEvents event
 * entry size in the *EventBridge User Guide*.
 */
export declare const putPartnerEvents: API.OperationMethod<PutPartnerEventsRequest, PutPartnerEventsResponse, PutPartnerEventsError, Credentials | HttpClient.HttpClient>;
export type PutPermissionError = ConcurrentModificationException | InternalException | OperationDisabledException | PolicyLengthExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Running `PutPermission` permits the specified Amazon Web Services account or Amazon Web Services organization
 * to put events to the specified *event bus*. Amazon EventBridge rules in your account are triggered by these events arriving to an event bus in your
 * account.
 *
 * For another account to send events to your account, that external account must have an
 * EventBridge rule with your account's event bus as a target.
 *
 * To enable multiple Amazon Web Services accounts to put events to your event bus, run
 * `PutPermission` once for each of these accounts. Or, if all the accounts are
 * members of the same Amazon Web Services organization, you can run `PutPermission`
 * once specifying `Principal` as "*" and specifying the Amazon Web Services
 * organization ID in `Condition`, to grant permissions to all accounts in that
 * organization.
 *
 * If you grant permissions using an organization, then accounts in that organization must
 * specify a `RoleArn` with proper permissions when they use `PutTarget` to
 * add your account's event bus as a target. For more information, see Sending and
 * Receiving Events Between Amazon Web Services Accounts in the *Amazon EventBridge User Guide*.
 *
 * The permission policy on the event bus cannot exceed 10 KB in size.
 */
export declare const putPermission: API.OperationMethod<PutPermissionRequest, PutPermissionResponse, PutPermissionError, Credentials | HttpClient.HttpClient>;
export type PutRuleError = ConcurrentModificationException | InternalException | InvalidEventPatternException | LimitExceededException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Creates or updates the specified rule. Rules are enabled by default, or based on value of
 * the state. You can disable a rule using DisableRule.
 *
 * A single rule watches for events from a single event bus. Events generated by Amazon Web Services services go to your account's default event bus. Events generated by SaaS partner
 * services or applications go to the matching partner event bus. If you have custom applications
 * or services, you can specify whether their events go to your default event bus or a custom
 * event bus that you have created. For more information, see CreateEventBus.
 *
 * If you are updating an existing rule, the rule is replaced with what you specify in this
 * `PutRule` command. If you omit arguments in `PutRule`, the old values
 * for those arguments are not kept. Instead, they are replaced with null values.
 *
 * When you create or update a rule, incoming events might not immediately start matching to
 * new or updated rules. Allow a short period of time for changes to take effect.
 *
 * A rule must contain at least an EventPattern or ScheduleExpression. Rules with
 * EventPatterns are triggered when a matching event is observed. Rules with ScheduleExpressions
 * self-trigger based on the given schedule. A rule can have both an EventPattern and a
 * ScheduleExpression, in which case the rule triggers on matching events as well as on a
 * schedule.
 *
 * When you initially create a rule, you can optionally assign one or more tags to the rule.
 * Tags can help you organize and categorize your resources. You can also use them to scope user
 * permissions, by granting a user permission to access or change only rules with certain tag
 * values. To use the `PutRule` operation and assign tags, you must have both the
 * `events:PutRule` and `events:TagResource` permissions.
 *
 * If you are updating an existing rule, any tags you specify in the `PutRule`
 * operation are ignored. To update the tags of an existing rule, use TagResource and UntagResource.
 *
 * Most services in Amazon Web Services treat : or / as the same character in Amazon Resource
 * Names (ARNs). However, EventBridge uses an exact match in event patterns and rules. Be sure to
 * use the correct ARN characters when creating event patterns so that they match the ARN syntax
 * in the event you want to match.
 *
 * In EventBridge, it is possible to create rules that lead to infinite loops, where a rule
 * is fired repeatedly. For example, a rule might detect that ACLs have changed on an S3 bucket,
 * and trigger software to change them to the desired state. If the rule is not written
 * carefully, the subsequent change to the ACLs fires the rule again, creating an infinite
 * loop.
 *
 * To prevent this, write the rules so that the triggered actions do not re-fire the same
 * rule. For example, your rule could fire only if ACLs are found to be in a bad state, instead
 * of after any change.
 *
 * An infinite loop can quickly cause higher than expected charges. We recommend that you use
 * budgeting, which alerts you when charges exceed your specified limit. For more information,
 * see Managing Your Costs with
 * Budgets.
 *
 * To create a rule that filters for management events from Amazon Web Services services, see
 * Receiving read-only management events from Amazon Web Services services in the
 * *EventBridge User Guide*.
 */
export declare const putRule: API.OperationMethod<PutRuleRequest, PutRuleResponse, PutRuleError, Credentials | HttpClient.HttpClient>;
export type PutTargetsError = ConcurrentModificationException | InternalException | LimitExceededException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Adds the specified targets to the specified rule, or updates the targets if they are
 * already associated with the rule.
 *
 * Targets are the resources that are invoked when a rule is triggered.
 *
 * The maximum number of entries per request is 10.
 *
 * Each rule can have up to five (5) targets associated with it at one time.
 *
 * For a list of services you can configure as targets for events, see EventBridge targets
 * in the
 * *Amazon EventBridge User Guide*
 * .
 *
 * Creating rules with built-in targets is supported only in the Amazon Web Services Management Console. The
 * built-in targets are:
 *
 * - `Amazon EBS CreateSnapshot API call`
 *
 * - `Amazon EC2 RebootInstances API call`
 *
 * - `Amazon EC2 StopInstances API call`
 *
 * - `Amazon EC2 TerminateInstances API call`
 *
 * For some target types, `PutTargets` provides target-specific parameters. If the
 * target is a Kinesis data stream, you can optionally specify which shard the event
 * goes to by using the `KinesisParameters` argument. To invoke a command on multiple
 * EC2 instances with one rule, you can use the `RunCommandParameters` field.
 *
 * To be able to make API calls against the resources that you own, Amazon EventBridge
 * needs the appropriate permissions:
 *
 * - For Lambda and Amazon SNS resources, EventBridge relies
 * on resource-based policies.
 *
 * - For EC2 instances, Kinesis Data Streams, Step Functions state machines and
 * API Gateway APIs, EventBridge relies on IAM roles that you specify in the
 * `RoleARN` argument in `PutTargets`.
 *
 * For more information, see Authentication
 * and Access Control in the
 * *Amazon EventBridge User Guide*
 * .
 *
 * If another Amazon Web Services account is in the same region and has granted you permission
 * (using `PutPermission`), you can send events to that account. Set that account's
 * event bus as a target of the rules in your account. To send the matched events to the other
 * account, specify that account's event bus as the `Arn` value when you run
 * `PutTargets`. If your account sends events to another account, your account is
 * charged for each sent event. Each event sent to another account is charged as a custom event.
 * The account receiving the event is not charged. For more information, see Amazon EventBridge Pricing.
 *
 * `Input`, `InputPath`, and `InputTransformer` are not
 * available with `PutTarget` if the target is an event bus of a different Amazon Web Services account.
 *
 * If you are setting the event bus of another account as the target, and that account
 * granted permission to your account through an organization instead of directly by the account
 * ID, then you must specify a `RoleArn` with proper permissions in the
 * `Target` structure. For more information, see Sending and
 * Receiving Events Between Amazon Web Services Accounts in the *Amazon EventBridge User Guide*.
 *
 * If you have an IAM role on a cross-account event bus target, a `PutTargets`
 * call without a role on the same target (same `Id` and `Arn`) will not
 * remove the role.
 *
 * For more information about enabling cross-account events, see PutPermission.
 *
 * **Input**, **InputPath**, and
 * **InputTransformer** are mutually exclusive and optional
 * parameters of a target. When a rule is triggered due to a matched event:
 *
 * - If none of the following arguments are specified for a target, then the entire event
 * is passed to the target in JSON format (unless the target is Amazon EC2 Run Command or
 * Amazon ECS task, in which case nothing from the event is passed to the target).
 *
 * - If **Input** is specified in the form of valid JSON, then
 * the matched event is overridden with this constant.
 *
 * - If **InputPath** is specified in the form of JSONPath
 * (for example, `$.detail`), then only the part of the event specified in the
 * path is passed to the target (for example, only the detail part of the event is
 * passed).
 *
 * - If **InputTransformer** is specified, then one or more
 * specified JSONPaths are extracted from the event and used as values in a template that you
 * specify as the input to the target.
 *
 * When you specify `InputPath` or `InputTransformer`, you must use
 * JSON dot notation, not bracket notation.
 *
 * When you add targets to a rule and the associated rule triggers soon after, new or updated
 * targets might not be immediately invoked. Allow a short period of time for changes to take
 * effect.
 *
 * This action can partially fail if too many requests are made at the same time. If that
 * happens, `FailedEntryCount` is non-zero in the response and each entry in
 * `FailedEntries` provides the ID of the failed target and the error code.
 */
export declare const putTargets: API.OperationMethod<PutTargetsRequest, PutTargetsResponse, PutTargetsError, Credentials | HttpClient.HttpClient>;
export type RemovePermissionError = ConcurrentModificationException | InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * Revokes the permission of another Amazon Web Services account to be able to put events to
 * the specified event bus. Specify the account to revoke by the `StatementId` value
 * that you associated with the account when you granted it permission with
 * `PutPermission`. You can find the `StatementId` by using DescribeEventBus.
 */
export declare const removePermission: API.OperationMethod<RemovePermissionRequest, RemovePermissionResponse, RemovePermissionError, Credentials | HttpClient.HttpClient>;
export type RemoveTargetsError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the specified targets from the specified rule. When the rule is triggered, those
 * targets are no longer be invoked.
 *
 * A successful execution of `RemoveTargets` doesn't guarantee all targets are
 * removed from the rule, it means that the target(s) listed in the request are removed.
 *
 * When you remove a target, when the associated rule triggers, removed targets might
 * continue to be invoked. Allow a short period of time for changes to take effect.
 *
 * This action can partially fail if too many requests are made at the same time. If that
 * happens, `FailedEntryCount` is non-zero in the response and each entry in
 * `FailedEntries` provides the ID of the failed target and the error code.
 *
 * The maximum number of entries per request is 10.
 */
export declare const removeTargets: API.OperationMethod<RemoveTargetsRequest, RemoveTargetsResponse, RemoveTargetsError, Credentials | HttpClient.HttpClient>;
export type StartReplayError = InternalException | InvalidEventPatternException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the specified replay. Events are not necessarily replayed in the exact same order
 * that they were added to the archive. A replay processes events to replay based on the time in
 * the event, and replays them using 1 minute intervals. If you specify an
 * `EventStartTime` and an `EventEndTime` that covers a 20 minute time
 * range, the events are replayed from the first minute of that 20 minute range first. Then the
 * events from the second minute are replayed. You can use `DescribeReplay` to
 * determine the progress of a replay. The value returned for `EventLastReplayedTime`
 * indicates the time within the specified time range associated with the last event
 * replayed.
 */
export declare const startReplay: API.OperationMethod<StartReplayRequest, StartReplayResponse, StartReplayError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified EventBridge resource. Tags can
 * help you organize and categorize your resources. You can also use them to scope user
 * permissions by granting a user permission to access or change only resources with certain tag
 * values. In EventBridge, rules and event buses can be tagged.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as
 * strings of characters.
 *
 * You can use the `TagResource` action with a resource that already has tags. If
 * you specify a new tag key, this tag is appended to the list of tags associated with the
 * resource. If you specify a tag key that is already associated with the resource, the new tag
 * value that you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestEventPatternError = InternalException | InvalidEventPatternException | CommonErrors;
/**
 * Tests whether the specified event pattern matches the provided event.
 *
 * Most services in Amazon Web Services treat : or / as the same character in Amazon Resource
 * Names (ARNs). However, EventBridge uses an exact match in event patterns and rules. Be
 * sure to use the correct ARN characters when creating event patterns so that they match the ARN
 * syntax in the event you want to match.
 */
export declare const testEventPattern: API.OperationMethod<TestEventPatternRequest, TestEventPatternResponse, TestEventPatternError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes one or more tags from the specified EventBridge resource. In Amazon EventBridge, rules and event buses can be tagged.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApiDestinationError = ConcurrentModificationException | InternalException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an API destination.
 */
export declare const updateApiDestination: API.OperationMethod<UpdateApiDestinationRequest, UpdateApiDestinationResponse, UpdateApiDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateArchiveError = ConcurrentModificationException | InternalException | InvalidEventPatternException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified archive.
 */
export declare const updateArchive: API.OperationMethod<UpdateArchiveRequest, UpdateArchiveResponse, UpdateArchiveError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = AccessDeniedException | ConcurrentModificationException | InternalException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates settings for a connection.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest, UpdateConnectionResponse, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Update an existing endpoint. For more information about global endpoints, see Making
 * applications Regional-fault tolerant with global endpoints and event replication in
 * the
 * *Amazon EventBridge User Guide*
 * .
 */
export declare const updateEndpoint: API.OperationMethod<UpdateEndpointRequest, UpdateEndpointResponse, UpdateEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateEventBusError = ConcurrentModificationException | InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified event bus.
 */
export declare const updateEventBus: API.OperationMethod<UpdateEventBusRequest, UpdateEventBusResponse, UpdateEventBusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=eventbridge.d.ts.map