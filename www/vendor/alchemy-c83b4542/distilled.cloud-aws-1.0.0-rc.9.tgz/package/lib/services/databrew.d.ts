import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DataBrewRoleNotAssumable_base: S.Class<DataBrewRoleNotAssumable, S.TaggedStruct<"DataBrewRoleNotAssumable", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DataBrewRoleNotAssumable extends /*@__PURE__*/ DataBrewRoleNotAssumable_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RecipeName = string;
export type RecipeVersion = string;
export type RecipeVersionList = string[];
export declare const RecipeVersionList: any;
export interface BatchDeleteRecipeVersionRequest {
    Name: string;
    RecipeVersions: string[];
}
export declare const BatchDeleteRecipeVersionRequest: S.Schema<BatchDeleteRecipeVersionRequest>;
export type ErrorCode = string;
export type RecipeErrorMessage = string;
export interface RecipeVersionErrorDetail {
    ErrorCode?: string;
    ErrorMessage?: string;
    RecipeVersion?: string;
}
export declare const RecipeVersionErrorDetail: S.Schema<RecipeVersionErrorDetail>;
export type RecipeErrorList = RecipeVersionErrorDetail[];
export declare const RecipeErrorList: any;
export interface BatchDeleteRecipeVersionResponse {
    Name: string;
    Errors?: RecipeVersionErrorDetail[];
}
export declare const BatchDeleteRecipeVersionResponse: S.Schema<BatchDeleteRecipeVersionResponse>;
export type DatasetName = string;
export type InputFormat = "CSV" | "JSON" | "PARQUET" | "EXCEL" | "ORC" | (string & {});
export declare const InputFormat: any;
export type MultiLine = boolean;
export interface JsonOptions {
    MultiLine?: boolean;
}
export declare const JsonOptions: S.Schema<JsonOptions>;
export type SheetName = string;
export type SheetNameList = string[];
export declare const SheetNameList: any;
export type SheetIndex = number;
export type SheetIndexList = number[];
export declare const SheetIndexList: any;
export type HeaderRow = boolean;
export interface ExcelOptions {
    SheetNames?: string[];
    SheetIndexes?: number[];
    HeaderRow?: boolean;
}
export declare const ExcelOptions: S.Schema<ExcelOptions>;
export type Delimiter = string;
export interface CsvOptions {
    Delimiter?: string;
    HeaderRow?: boolean;
}
export declare const CsvOptions: S.Schema<CsvOptions>;
export interface FormatOptions {
    Json?: JsonOptions;
    Excel?: ExcelOptions;
    Csv?: CsvOptions;
}
export declare const FormatOptions: S.Schema<FormatOptions>;
export type Bucket = string;
export type Key = string;
export type BucketOwner = string;
export interface S3Location {
    Bucket: string;
    Key?: string;
    BucketOwner?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type CatalogId = string;
export type DatabaseName = string;
export type TableName = string;
export interface DataCatalogInputDefinition {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    TempDirectory?: S3Location;
}
export declare const DataCatalogInputDefinition: S.Schema<DataCatalogInputDefinition>;
export type GlueConnectionName = string;
export type DatabaseTableName = string;
export type QueryString = string;
export interface DatabaseInputDefinition {
    GlueConnectionName: string;
    DatabaseTableName?: string;
    TempDirectory?: S3Location;
    QueryString?: string;
}
export declare const DatabaseInputDefinition: S.Schema<DatabaseInputDefinition>;
export type Arn = string;
export interface Metadata {
    SourceArn?: string;
}
export declare const Metadata: S.Schema<Metadata>;
export interface Input {
    S3InputDefinition?: S3Location;
    DataCatalogInputDefinition?: DataCatalogInputDefinition;
    DatabaseInputDefinition?: DatabaseInputDefinition;
    Metadata?: Metadata;
}
export declare const Input: S.Schema<Input>;
export type Expression = string;
export type ValueReference = string;
export type ConditionValue = string;
export type ValuesMap = {
    [key: string]: string | undefined;
};
export declare const ValuesMap: any;
export interface FilterExpression {
    Expression: string;
    ValuesMap: {
        [key: string]: string | undefined;
    };
}
export declare const FilterExpression: S.Schema<FilterExpression>;
export type MaxFiles = number;
export type OrderedBy = "LAST_MODIFIED_DATE" | (string & {});
export declare const OrderedBy: any;
export type Order = "DESCENDING" | "ASCENDING" | (string & {});
export declare const Order: any;
export interface FilesLimit {
    MaxFiles: number;
    OrderedBy?: OrderedBy;
    Order?: Order;
}
export declare const FilesLimit: S.Schema<FilesLimit>;
export type PathParameterName = string;
export type ParameterType = "Datetime" | "Number" | "String" | (string & {});
export declare const ParameterType: any;
export type DatetimeFormat = string;
export type TimezoneOffset = string;
export type LocaleCode = string;
export interface DatetimeOptions {
    Format: string;
    TimezoneOffset?: string;
    LocaleCode?: string;
}
export declare const DatetimeOptions: S.Schema<DatetimeOptions>;
export type CreateColumn = boolean;
export interface DatasetParameter {
    Name: string;
    Type: ParameterType;
    DatetimeOptions?: DatetimeOptions;
    CreateColumn?: boolean;
    Filter?: FilterExpression;
}
export declare const DatasetParameter: S.Schema<DatasetParameter>;
export type PathParametersMap = {
    [key: string]: DatasetParameter | undefined;
};
export declare const PathParametersMap: any;
export interface PathOptions {
    LastModifiedDateCondition?: FilterExpression;
    FilesLimit?: FilesLimit;
    Parameters?: {
        [key: string]: DatasetParameter | undefined;
    };
}
export declare const PathOptions: S.Schema<PathOptions>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateDatasetRequest {
    Name: string;
    Format?: InputFormat;
    FormatOptions?: FormatOptions;
    Input: Input;
    PathOptions?: PathOptions;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
export interface CreateDatasetResponse {
    Name: string;
}
export declare const CreateDatasetResponse: S.Schema<CreateDatasetResponse>;
export type EncryptionKeyArn = string;
export type EncryptionMode = "SSE-KMS" | "SSE-S3" | (string & {});
export declare const EncryptionMode: any;
export type JobName = string;
export type LogSubscription = "ENABLE" | "DISABLE" | (string & {});
export declare const LogSubscription: any;
export type MaxCapacity = number;
export type MaxRetries = number;
export type Statistic = string;
export type StatisticList = string[];
export declare const StatisticList: any;
export type ParameterName = string;
export type ParameterValue = string;
export type ParameterMap = {
    [key: string]: string | undefined;
};
export declare const ParameterMap: any;
export interface StatisticOverride {
    Statistic: string;
    Parameters: {
        [key: string]: string | undefined;
    };
}
export declare const StatisticOverride: S.Schema<StatisticOverride>;
export type StatisticOverrideList = StatisticOverride[];
export declare const StatisticOverrideList: any;
export interface StatisticsConfiguration {
    IncludedStatistics?: string[];
    Overrides?: StatisticOverride[];
}
export declare const StatisticsConfiguration: S.Schema<StatisticsConfiguration>;
export type ColumnName = string;
export interface ColumnSelector {
    Regex?: string;
    Name?: string;
}
export declare const ColumnSelector: S.Schema<ColumnSelector>;
export type ColumnSelectorList = ColumnSelector[];
export declare const ColumnSelectorList: any;
export interface ColumnStatisticsConfiguration {
    Selectors?: ColumnSelector[];
    Statistics: StatisticsConfiguration;
}
export declare const ColumnStatisticsConfiguration: S.Schema<ColumnStatisticsConfiguration>;
export type ColumnStatisticsConfigurationList = ColumnStatisticsConfiguration[];
export declare const ColumnStatisticsConfigurationList: any;
export type EntityType = string;
export type EntityTypeList = string[];
export declare const EntityTypeList: any;
export interface AllowedStatistics {
    Statistics: string[];
}
export declare const AllowedStatistics: S.Schema<AllowedStatistics>;
export type AllowedStatisticList = AllowedStatistics[];
export declare const AllowedStatisticList: any;
export interface EntityDetectorConfiguration {
    EntityTypes: string[];
    AllowedStatistics?: AllowedStatistics[];
}
export declare const EntityDetectorConfiguration: S.Schema<EntityDetectorConfiguration>;
export interface ProfileConfiguration {
    DatasetStatisticsConfiguration?: StatisticsConfiguration;
    ProfileColumns?: ColumnSelector[];
    ColumnStatisticsConfigurations?: ColumnStatisticsConfiguration[];
    EntityDetectorConfiguration?: EntityDetectorConfiguration;
}
export declare const ProfileConfiguration: S.Schema<ProfileConfiguration>;
export type ValidationMode = "CHECK_ALL" | (string & {});
export declare const ValidationMode: any;
export interface ValidationConfiguration {
    RulesetArn: string;
    ValidationMode?: ValidationMode;
}
export declare const ValidationConfiguration: S.Schema<ValidationConfiguration>;
export type ValidationConfigurationList = ValidationConfiguration[];
export declare const ValidationConfigurationList: any;
export type Timeout = number;
export type SampleMode = "FULL_DATASET" | "CUSTOM_ROWS" | (string & {});
export declare const SampleMode: any;
export type JobSize = number;
export interface JobSample {
    Mode?: SampleMode;
    Size?: number;
}
export declare const JobSample: S.Schema<JobSample>;
export interface CreateProfileJobRequest {
    DatasetName: string;
    EncryptionKeyArn?: string;
    EncryptionMode?: EncryptionMode;
    Name: string;
    LogSubscription?: LogSubscription;
    MaxCapacity?: number;
    MaxRetries?: number;
    OutputLocation: S3Location;
    Configuration?: ProfileConfiguration;
    ValidationConfigurations?: ValidationConfiguration[];
    RoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Timeout?: number;
    JobSample?: JobSample;
}
export declare const CreateProfileJobRequest: S.Schema<CreateProfileJobRequest>;
export interface CreateProfileJobResponse {
    Name: string;
}
export declare const CreateProfileJobResponse: S.Schema<CreateProfileJobResponse>;
export type ProjectName = string;
export type SampleSize = number;
export type SampleType = "FIRST_N" | "LAST_N" | "RANDOM" | (string & {});
export declare const SampleType: any;
export interface Sample {
    Size?: number;
    Type: SampleType;
}
export declare const Sample: S.Schema<Sample>;
export interface CreateProjectRequest {
    DatasetName: string;
    Name: string;
    RecipeName: string;
    Sample?: Sample;
    RoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateProjectRequest: S.Schema<CreateProjectRequest>;
export interface CreateProjectResponse {
    Name: string;
}
export declare const CreateProjectResponse: S.Schema<CreateProjectResponse>;
export type RecipeDescription = string;
export type Operation = string;
export interface RecipeAction {
    Operation: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const RecipeAction: S.Schema<RecipeAction>;
export type Condition = string;
export type TargetColumn = string;
export interface ConditionExpression {
    Condition: string;
    Value?: string;
    TargetColumn: string;
}
export declare const ConditionExpression: S.Schema<ConditionExpression>;
export type ConditionExpressionList = ConditionExpression[];
export declare const ConditionExpressionList: any;
export interface RecipeStep {
    Action: RecipeAction;
    ConditionExpressions?: ConditionExpression[];
}
export declare const RecipeStep: S.Schema<RecipeStep>;
export type RecipeStepList = RecipeStep[];
export declare const RecipeStepList: any;
export interface CreateRecipeRequest {
    Description?: string;
    Name: string;
    Steps: RecipeStep[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRecipeRequest: S.Schema<CreateRecipeRequest>;
export interface CreateRecipeResponse {
    Name: string;
}
export declare const CreateRecipeResponse: S.Schema<CreateRecipeResponse>;
export type CompressionFormat = "GZIP" | "LZ4" | "SNAPPY" | "BZIP2" | "DEFLATE" | "LZO" | "BROTLI" | "ZSTD" | "ZLIB" | (string & {});
export declare const CompressionFormat: any;
export type OutputFormat = "CSV" | "JSON" | "PARQUET" | "GLUEPARQUET" | "AVRO" | "ORC" | "XML" | "TABLEAUHYPER" | (string & {});
export declare const OutputFormat: any;
export type ColumnNameList = string[];
export declare const ColumnNameList: any;
export type OverwriteOutput = boolean;
export interface CsvOutputOptions {
    Delimiter?: string;
}
export declare const CsvOutputOptions: S.Schema<CsvOutputOptions>;
export interface OutputFormatOptions {
    Csv?: CsvOutputOptions;
}
export declare const OutputFormatOptions: S.Schema<OutputFormatOptions>;
export type MaxOutputFiles = number;
export interface Output {
    CompressionFormat?: CompressionFormat;
    Format?: OutputFormat;
    PartitionColumns?: string[];
    Location: S3Location;
    Overwrite?: boolean;
    FormatOptions?: OutputFormatOptions;
    MaxOutputFiles?: number;
}
export declare const Output: S.Schema<Output>;
export type OutputList = Output[];
export declare const OutputList: any;
export interface S3TableOutputOptions {
    Location: S3Location;
}
export declare const S3TableOutputOptions: S.Schema<S3TableOutputOptions>;
export interface DatabaseTableOutputOptions {
    TempDirectory?: S3Location;
    TableName: string;
}
export declare const DatabaseTableOutputOptions: S.Schema<DatabaseTableOutputOptions>;
export interface DataCatalogOutput {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    S3Options?: S3TableOutputOptions;
    DatabaseOptions?: DatabaseTableOutputOptions;
    Overwrite?: boolean;
}
export declare const DataCatalogOutput: S.Schema<DataCatalogOutput>;
export type DataCatalogOutputList = DataCatalogOutput[];
export declare const DataCatalogOutputList: any;
export type DatabaseOutputMode = "NEW_TABLE" | (string & {});
export declare const DatabaseOutputMode: any;
export interface DatabaseOutput {
    GlueConnectionName: string;
    DatabaseOptions: DatabaseTableOutputOptions;
    DatabaseOutputMode?: DatabaseOutputMode;
}
export declare const DatabaseOutput: S.Schema<DatabaseOutput>;
export type DatabaseOutputList = DatabaseOutput[];
export declare const DatabaseOutputList: any;
export interface RecipeReference {
    Name: string;
    RecipeVersion?: string;
}
export declare const RecipeReference: S.Schema<RecipeReference>;
export interface CreateRecipeJobRequest {
    DatasetName?: string;
    EncryptionKeyArn?: string;
    EncryptionMode?: EncryptionMode;
    Name: string;
    LogSubscription?: LogSubscription;
    MaxCapacity?: number;
    MaxRetries?: number;
    Outputs?: Output[];
    DataCatalogOutputs?: DataCatalogOutput[];
    DatabaseOutputs?: DatabaseOutput[];
    ProjectName?: string;
    RecipeReference?: RecipeReference;
    RoleArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Timeout?: number;
}
export declare const CreateRecipeJobRequest: S.Schema<CreateRecipeJobRequest>;
export interface CreateRecipeJobResponse {
    Name: string;
}
export declare const CreateRecipeJobResponse: S.Schema<CreateRecipeJobResponse>;
export type RulesetName = string;
export type RulesetDescription = string;
export type RuleName = string;
export type Disabled = boolean;
export type ThresholdValue = number;
export type ThresholdType = "GREATER_THAN_OR_EQUAL" | "LESS_THAN_OR_EQUAL" | "GREATER_THAN" | "LESS_THAN" | (string & {});
export declare const ThresholdType: any;
export type ThresholdUnit = "COUNT" | "PERCENTAGE" | (string & {});
export declare const ThresholdUnit: any;
export interface Threshold {
    Value: number;
    Type?: ThresholdType;
    Unit?: ThresholdUnit;
}
export declare const Threshold: S.Schema<Threshold>;
export interface Rule {
    Name: string;
    Disabled?: boolean;
    CheckExpression: string;
    SubstitutionMap?: {
        [key: string]: string | undefined;
    };
    Threshold?: Threshold;
    ColumnSelectors?: ColumnSelector[];
}
export declare const Rule: S.Schema<Rule>;
export type RuleList = Rule[];
export declare const RuleList: any;
export interface CreateRulesetRequest {
    Name: string;
    Description?: string;
    TargetArn: string;
    Rules: Rule[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRulesetRequest: S.Schema<CreateRulesetRequest>;
export interface CreateRulesetResponse {
    Name: string;
}
export declare const CreateRulesetResponse: S.Schema<CreateRulesetResponse>;
export type JobNameList = string[];
export declare const JobNameList: any;
export type CronExpression = string;
export type ScheduleName = string;
export interface CreateScheduleRequest {
    JobNames?: string[];
    CronExpression: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Name: string;
}
export declare const CreateScheduleRequest: S.Schema<CreateScheduleRequest>;
export interface CreateScheduleResponse {
    Name: string;
}
export declare const CreateScheduleResponse: S.Schema<CreateScheduleResponse>;
export interface DeleteDatasetRequest {
    Name: string;
}
export declare const DeleteDatasetRequest: S.Schema<DeleteDatasetRequest>;
export interface DeleteDatasetResponse {
    Name: string;
}
export declare const DeleteDatasetResponse: S.Schema<DeleteDatasetResponse>;
export interface DeleteJobRequest {
    Name: string;
}
export declare const DeleteJobRequest: S.Schema<DeleteJobRequest>;
export interface DeleteJobResponse {
    Name: string;
}
export declare const DeleteJobResponse: S.Schema<DeleteJobResponse>;
export interface DeleteProjectRequest {
    Name: string;
}
export declare const DeleteProjectRequest: S.Schema<DeleteProjectRequest>;
export interface DeleteProjectResponse {
    Name: string;
}
export declare const DeleteProjectResponse: S.Schema<DeleteProjectResponse>;
export interface DeleteRecipeVersionRequest {
    Name: string;
    RecipeVersion: string;
}
export declare const DeleteRecipeVersionRequest: S.Schema<DeleteRecipeVersionRequest>;
export interface DeleteRecipeVersionResponse {
    Name: string;
    RecipeVersion: string;
}
export declare const DeleteRecipeVersionResponse: S.Schema<DeleteRecipeVersionResponse>;
export interface DeleteRulesetRequest {
    Name: string;
}
export declare const DeleteRulesetRequest: S.Schema<DeleteRulesetRequest>;
export interface DeleteRulesetResponse {
    Name: string;
}
export declare const DeleteRulesetResponse: S.Schema<DeleteRulesetResponse>;
export interface DeleteScheduleRequest {
    Name: string;
}
export declare const DeleteScheduleRequest: S.Schema<DeleteScheduleRequest>;
export interface DeleteScheduleResponse {
    Name: string;
}
export declare const DeleteScheduleResponse: S.Schema<DeleteScheduleResponse>;
export interface DescribeDatasetRequest {
    Name: string;
}
export declare const DescribeDatasetRequest: S.Schema<DescribeDatasetRequest>;
export type CreatedBy = string;
export type LastModifiedBy = string;
export type Source = "S3" | "DATA-CATALOG" | "DATABASE" | (string & {});
export declare const Source: any;
export interface DescribeDatasetResponse {
    CreatedBy?: string;
    CreateDate?: Date;
    Name: string;
    Format?: InputFormat;
    FormatOptions?: FormatOptions;
    Input: Input;
    LastModifiedDate?: Date;
    LastModifiedBy?: string;
    Source?: Source;
    PathOptions?: PathOptions;
    Tags?: {
        [key: string]: string | undefined;
    };
    ResourceArn?: string;
}
export declare const DescribeDatasetResponse: S.Schema<DescribeDatasetResponse>;
export interface DescribeJobRequest {
    Name: string;
}
export declare const DescribeJobRequest: S.Schema<DescribeJobRequest>;
export type JobType = "PROFILE" | "RECIPE" | (string & {});
export declare const JobType: any;
export interface DescribeJobResponse {
    CreateDate?: Date;
    CreatedBy?: string;
    DatasetName?: string;
    EncryptionKeyArn?: string;
    EncryptionMode?: EncryptionMode;
    Name: string;
    Type?: JobType;
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    LogSubscription?: LogSubscription;
    MaxCapacity?: number;
    MaxRetries?: number;
    Outputs?: Output[];
    DataCatalogOutputs?: DataCatalogOutput[];
    DatabaseOutputs?: DatabaseOutput[];
    ProjectName?: string;
    ProfileConfiguration?: ProfileConfiguration;
    ValidationConfigurations?: ValidationConfiguration[];
    RecipeReference?: RecipeReference;
    ResourceArn?: string;
    RoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Timeout?: number;
    JobSample?: JobSample;
}
export declare const DescribeJobResponse: S.Schema<DescribeJobResponse>;
export type JobRunId = string;
export interface DescribeJobRunRequest {
    Name: string;
    RunId: string;
}
export declare const DescribeJobRunRequest: S.Schema<DescribeJobRunRequest>;
export type Attempt = number;
export type JobRunErrorMessage = string;
export type ExecutionTime = number;
export type JobRunState = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | "SUCCEEDED" | "FAILED" | "TIMEOUT" | (string & {});
export declare const JobRunState: any;
export type LogGroupName = string;
export type StartedBy = string;
export interface DescribeJobRunResponse {
    Attempt?: number;
    CompletedOn?: Date;
    DatasetName?: string;
    ErrorMessage?: string;
    ExecutionTime?: number;
    JobName: string;
    ProfileConfiguration?: ProfileConfiguration;
    ValidationConfigurations?: ValidationConfiguration[];
    RunId?: string;
    State?: JobRunState;
    LogSubscription?: LogSubscription;
    LogGroupName?: string;
    Outputs?: Output[];
    DataCatalogOutputs?: DataCatalogOutput[];
    DatabaseOutputs?: DatabaseOutput[];
    RecipeReference?: RecipeReference;
    StartedBy?: string;
    StartedOn?: Date;
    JobSample?: JobSample;
}
export declare const DescribeJobRunResponse: S.Schema<DescribeJobRunResponse>;
export interface DescribeProjectRequest {
    Name: string;
}
export declare const DescribeProjectRequest: S.Schema<DescribeProjectRequest>;
export type SessionStatus = "ASSIGNED" | "FAILED" | "INITIALIZING" | "PROVISIONING" | "READY" | "RECYCLING" | "ROTATING" | "TERMINATED" | "TERMINATING" | "UPDATING" | (string & {});
export declare const SessionStatus: any;
export type OpenedBy = string;
export interface DescribeProjectResponse {
    CreateDate?: Date;
    CreatedBy?: string;
    DatasetName?: string;
    LastModifiedDate?: Date;
    LastModifiedBy?: string;
    Name: string;
    RecipeName?: string;
    ResourceArn?: string;
    Sample?: Sample;
    RoleArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    SessionStatus?: SessionStatus;
    OpenedBy?: string;
    OpenDate?: Date;
}
export declare const DescribeProjectResponse: S.Schema<DescribeProjectResponse>;
export interface DescribeRecipeRequest {
    Name: string;
    RecipeVersion?: string;
}
export declare const DescribeRecipeRequest: S.Schema<DescribeRecipeRequest>;
export type PublishedBy = string;
export interface DescribeRecipeResponse {
    CreatedBy?: string;
    CreateDate?: Date;
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    ProjectName?: string;
    PublishedBy?: string;
    PublishedDate?: Date;
    Description?: string;
    Name: string;
    Steps?: RecipeStep[];
    Tags?: {
        [key: string]: string | undefined;
    };
    ResourceArn?: string;
    RecipeVersion?: string;
}
export declare const DescribeRecipeResponse: S.Schema<DescribeRecipeResponse>;
export interface DescribeRulesetRequest {
    Name: string;
}
export declare const DescribeRulesetRequest: S.Schema<DescribeRulesetRequest>;
export interface DescribeRulesetResponse {
    Name: string;
    Description?: string;
    TargetArn?: string;
    Rules?: Rule[];
    CreateDate?: Date;
    CreatedBy?: string;
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    ResourceArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeRulesetResponse: S.Schema<DescribeRulesetResponse>;
export interface DescribeScheduleRequest {
    Name: string;
}
export declare const DescribeScheduleRequest: S.Schema<DescribeScheduleRequest>;
export interface DescribeScheduleResponse {
    CreateDate?: Date;
    CreatedBy?: string;
    JobNames?: string[];
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    ResourceArn?: string;
    CronExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Name: string;
}
export declare const DescribeScheduleResponse: S.Schema<DescribeScheduleResponse>;
export type MaxResults100 = number;
export type NextToken = string;
export interface ListDatasetsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDatasetsRequest: S.Schema<ListDatasetsRequest>;
export type AccountId = string;
export interface Dataset {
    AccountId?: string;
    CreatedBy?: string;
    CreateDate?: Date;
    Name: string;
    Format?: InputFormat;
    FormatOptions?: FormatOptions;
    Input: Input;
    LastModifiedDate?: Date;
    LastModifiedBy?: string;
    Source?: Source;
    PathOptions?: PathOptions;
    Tags?: {
        [key: string]: string | undefined;
    };
    ResourceArn?: string;
}
export declare const Dataset: S.Schema<Dataset>;
export type DatasetList = Dataset[];
export declare const DatasetList: any;
export interface ListDatasetsResponse {
    Datasets: Dataset[];
    NextToken?: string;
}
export declare const ListDatasetsResponse: S.Schema<ListDatasetsResponse>;
export interface ListJobRunsRequest {
    Name: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListJobRunsRequest: S.Schema<ListJobRunsRequest>;
export interface JobRun {
    Attempt?: number;
    CompletedOn?: Date;
    DatasetName?: string;
    ErrorMessage?: string;
    ExecutionTime?: number;
    JobName?: string;
    RunId?: string;
    State?: JobRunState;
    LogSubscription?: LogSubscription;
    LogGroupName?: string;
    Outputs?: Output[];
    DataCatalogOutputs?: DataCatalogOutput[];
    DatabaseOutputs?: DatabaseOutput[];
    RecipeReference?: RecipeReference;
    StartedBy?: string;
    StartedOn?: Date;
    JobSample?: JobSample;
    ValidationConfigurations?: ValidationConfiguration[];
}
export declare const JobRun: S.Schema<JobRun>;
export type JobRunList = JobRun[];
export declare const JobRunList: any;
export interface ListJobRunsResponse {
    JobRuns: JobRun[];
    NextToken?: string;
}
export declare const ListJobRunsResponse: S.Schema<ListJobRunsResponse>;
export interface ListJobsRequest {
    DatasetName?: string;
    MaxResults?: number;
    NextToken?: string;
    ProjectName?: string;
}
export declare const ListJobsRequest: S.Schema<ListJobsRequest>;
export interface Job {
    AccountId?: string;
    CreatedBy?: string;
    CreateDate?: Date;
    DatasetName?: string;
    EncryptionKeyArn?: string;
    EncryptionMode?: EncryptionMode;
    Name: string;
    Type?: JobType;
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    LogSubscription?: LogSubscription;
    MaxCapacity?: number;
    MaxRetries?: number;
    Outputs?: Output[];
    DataCatalogOutputs?: DataCatalogOutput[];
    DatabaseOutputs?: DatabaseOutput[];
    ProjectName?: string;
    RecipeReference?: RecipeReference;
    ResourceArn?: string;
    RoleArn?: string;
    Timeout?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    JobSample?: JobSample;
    ValidationConfigurations?: ValidationConfiguration[];
}
export declare const Job: S.Schema<Job>;
export type JobList = Job[];
export declare const JobList: any;
export interface ListJobsResponse {
    Jobs: Job[];
    NextToken?: string;
}
export declare const ListJobsResponse: S.Schema<ListJobsResponse>;
export interface ListProjectsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListProjectsRequest: S.Schema<ListProjectsRequest>;
export interface Project {
    AccountId?: string;
    CreateDate?: Date;
    CreatedBy?: string;
    DatasetName?: string;
    LastModifiedDate?: Date;
    LastModifiedBy?: string;
    Name: string;
    RecipeName: string;
    ResourceArn?: string;
    Sample?: Sample;
    Tags?: {
        [key: string]: string | undefined;
    };
    RoleArn?: string;
    OpenedBy?: string;
    OpenDate?: Date;
}
export declare const Project: S.Schema<Project>;
export type ProjectList = Project[];
export declare const ProjectList: any;
export interface ListProjectsResponse {
    Projects: Project[];
    NextToken?: string;
}
export declare const ListProjectsResponse: S.Schema<ListProjectsResponse>;
export interface ListRecipesRequest {
    MaxResults?: number;
    NextToken?: string;
    RecipeVersion?: string;
}
export declare const ListRecipesRequest: S.Schema<ListRecipesRequest>;
export interface Recipe {
    CreatedBy?: string;
    CreateDate?: Date;
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    ProjectName?: string;
    PublishedBy?: string;
    PublishedDate?: Date;
    Description?: string;
    Name: string;
    ResourceArn?: string;
    Steps?: RecipeStep[];
    Tags?: {
        [key: string]: string | undefined;
    };
    RecipeVersion?: string;
}
export declare const Recipe: S.Schema<Recipe>;
export type RecipeList = Recipe[];
export declare const RecipeList: any;
export interface ListRecipesResponse {
    Recipes: Recipe[];
    NextToken?: string;
}
export declare const ListRecipesResponse: S.Schema<ListRecipesResponse>;
export interface ListRecipeVersionsRequest {
    MaxResults?: number;
    NextToken?: string;
    Name: string;
}
export declare const ListRecipeVersionsRequest: S.Schema<ListRecipeVersionsRequest>;
export interface ListRecipeVersionsResponse {
    NextToken?: string;
    Recipes: Recipe[];
}
export declare const ListRecipeVersionsResponse: S.Schema<ListRecipeVersionsResponse>;
export interface ListRulesetsRequest {
    TargetArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRulesetsRequest: S.Schema<ListRulesetsRequest>;
export type RuleCount = number;
export interface RulesetItem {
    AccountId?: string;
    CreatedBy?: string;
    CreateDate?: Date;
    Description?: string;
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    Name: string;
    ResourceArn?: string;
    RuleCount?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetArn: string;
}
export declare const RulesetItem: S.Schema<RulesetItem>;
export type RulesetItemList = RulesetItem[];
export declare const RulesetItemList: any;
export interface ListRulesetsResponse {
    Rulesets: RulesetItem[];
    NextToken?: string;
}
export declare const ListRulesetsResponse: S.Schema<ListRulesetsResponse>;
export interface ListSchedulesRequest {
    JobName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListSchedulesRequest: S.Schema<ListSchedulesRequest>;
export interface Schedule {
    AccountId?: string;
    CreatedBy?: string;
    CreateDate?: Date;
    JobNames?: string[];
    LastModifiedBy?: string;
    LastModifiedDate?: Date;
    ResourceArn?: string;
    CronExpression?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Name: string;
}
export declare const Schedule: S.Schema<Schedule>;
export type ScheduleList = Schedule[];
export declare const ScheduleList: any;
export interface ListSchedulesResponse {
    Schedules: Schedule[];
    NextToken?: string;
}
export declare const ListSchedulesResponse: S.Schema<ListSchedulesResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PublishRecipeRequest {
    Description?: string;
    Name: string;
}
export declare const PublishRecipeRequest: S.Schema<PublishRecipeRequest>;
export interface PublishRecipeResponse {
    Name: string;
}
export declare const PublishRecipeResponse: S.Schema<PublishRecipeResponse>;
export type Preview = boolean;
export type StepIndex = number;
export type ClientSessionId = string | redacted.Redacted<string>;
export type StartColumnIndex = number;
export type ColumnRange = number;
export type HiddenColumnList = string[];
export declare const HiddenColumnList: any;
export type StartRowIndex = number;
export type RowRange = number;
export type AnalyticsMode = "ENABLE" | "DISABLE" | (string & {});
export declare const AnalyticsMode: any;
export interface ViewFrame {
    StartColumnIndex: number;
    ColumnRange?: number;
    HiddenColumns?: string[];
    StartRowIndex?: number;
    RowRange?: number;
    Analytics?: AnalyticsMode;
}
export declare const ViewFrame: S.Schema<ViewFrame>;
export interface SendProjectSessionActionRequest {
    Preview?: boolean;
    Name: string;
    RecipeStep?: RecipeStep;
    StepIndex?: number;
    ClientSessionId?: string | redacted.Redacted<string>;
    ViewFrame?: ViewFrame;
}
export declare const SendProjectSessionActionRequest: S.Schema<SendProjectSessionActionRequest>;
export type Result = string;
export type ActionId = number;
export interface SendProjectSessionActionResponse {
    Result?: string;
    Name: string;
    ActionId?: number;
}
export declare const SendProjectSessionActionResponse: S.Schema<SendProjectSessionActionResponse>;
export interface StartJobRunRequest {
    Name: string;
}
export declare const StartJobRunRequest: S.Schema<StartJobRunRequest>;
export interface StartJobRunResponse {
    RunId: string;
}
export declare const StartJobRunResponse: S.Schema<StartJobRunResponse>;
export type AssumeControl = boolean;
export interface StartProjectSessionRequest {
    Name: string;
    AssumeControl?: boolean;
}
export declare const StartProjectSessionRequest: S.Schema<StartProjectSessionRequest>;
export interface StartProjectSessionResponse {
    Name: string;
    ClientSessionId?: string | redacted.Redacted<string>;
}
export declare const StartProjectSessionResponse: S.Schema<StartProjectSessionResponse>;
export interface StopJobRunRequest {
    Name: string;
    RunId: string;
}
export declare const StopJobRunRequest: S.Schema<StopJobRunRequest>;
export interface StopJobRunResponse {
    RunId: string;
}
export declare const StopJobRunResponse: S.Schema<StopJobRunResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDatasetRequest {
    Name: string;
    Format?: InputFormat;
    FormatOptions?: FormatOptions;
    Input: Input;
    PathOptions?: PathOptions;
}
export declare const UpdateDatasetRequest: S.Schema<UpdateDatasetRequest>;
export interface UpdateDatasetResponse {
    Name: string;
}
export declare const UpdateDatasetResponse: S.Schema<UpdateDatasetResponse>;
export interface UpdateProfileJobRequest {
    Configuration?: ProfileConfiguration;
    EncryptionKeyArn?: string;
    EncryptionMode?: EncryptionMode;
    Name: string;
    LogSubscription?: LogSubscription;
    MaxCapacity?: number;
    MaxRetries?: number;
    OutputLocation: S3Location;
    ValidationConfigurations?: ValidationConfiguration[];
    RoleArn: string;
    Timeout?: number;
    JobSample?: JobSample;
}
export declare const UpdateProfileJobRequest: S.Schema<UpdateProfileJobRequest>;
export interface UpdateProfileJobResponse {
    Name: string;
}
export declare const UpdateProfileJobResponse: S.Schema<UpdateProfileJobResponse>;
export interface UpdateProjectRequest {
    Sample?: Sample;
    RoleArn: string;
    Name: string;
}
export declare const UpdateProjectRequest: S.Schema<UpdateProjectRequest>;
export interface UpdateProjectResponse {
    LastModifiedDate?: Date;
    Name: string;
}
export declare const UpdateProjectResponse: S.Schema<UpdateProjectResponse>;
export interface UpdateRecipeRequest {
    Description?: string;
    Name: string;
    Steps?: RecipeStep[];
}
export declare const UpdateRecipeRequest: S.Schema<UpdateRecipeRequest>;
export interface UpdateRecipeResponse {
    Name: string;
}
export declare const UpdateRecipeResponse: S.Schema<UpdateRecipeResponse>;
export interface UpdateRecipeJobRequest {
    EncryptionKeyArn?: string;
    EncryptionMode?: EncryptionMode;
    Name: string;
    LogSubscription?: LogSubscription;
    MaxCapacity?: number;
    MaxRetries?: number;
    Outputs?: Output[];
    DataCatalogOutputs?: DataCatalogOutput[];
    DatabaseOutputs?: DatabaseOutput[];
    RoleArn: string;
    Timeout?: number;
}
export declare const UpdateRecipeJobRequest: S.Schema<UpdateRecipeJobRequest>;
export interface UpdateRecipeJobResponse {
    Name: string;
}
export declare const UpdateRecipeJobResponse: S.Schema<UpdateRecipeJobResponse>;
export interface UpdateRulesetRequest {
    Name: string;
    Description?: string;
    Rules: Rule[];
}
export declare const UpdateRulesetRequest: S.Schema<UpdateRulesetRequest>;
export interface UpdateRulesetResponse {
    Name: string;
}
export declare const UpdateRulesetResponse: S.Schema<UpdateRulesetResponse>;
export interface UpdateScheduleRequest {
    JobNames?: string[];
    CronExpression: string;
    Name: string;
}
export declare const UpdateScheduleRequest: S.Schema<UpdateScheduleRequest>;
export interface UpdateScheduleResponse {
    Name: string;
}
export declare const UpdateScheduleResponse: S.Schema<UpdateScheduleResponse>;
export type Message = string;
export type BatchDeleteRecipeVersionError = ConflictException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes one or more versions of a recipe at a time.
 *
 * The entire request will be rejected if:
 *
 * - The recipe does not exist.
 *
 * - There is an invalid version identifier in the list of versions.
 *
 * - The version list is empty.
 *
 * - The version list size exceeds 50.
 *
 * - The version list contains duplicate entries.
 *
 * The request will complete successfully, but with partial failures, if:
 *
 * - A version does not exist.
 *
 * - A version is being used by a job.
 *
 * - You specify `LATEST_WORKING`, but it's being used by a
 * project.
 *
 * - The version fails to be deleted.
 *
 * The `LATEST_WORKING` version will only be deleted if the recipe has no
 * other versions. If you try to delete `LATEST_WORKING` while other versions
 * exist (or if they can't be deleted), then `LATEST_WORKING` will be listed as
 * partial failure in the response.
 */
export declare const batchDeleteRecipeVersion: API.OperationMethod<BatchDeleteRecipeVersionRequest, BatchDeleteRecipeVersionResponse, BatchDeleteRecipeVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new DataBrew dataset.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateProfileJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | DataBrewRoleNotAssumable | CommonErrors;
/**
 * Creates a new job to analyze a dataset and create its data profile.
 */
export declare const createProfileJob: API.OperationMethod<CreateProfileJobRequest, CreateProfileJobResponse, CreateProfileJobError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | DataBrewRoleNotAssumable | CommonErrors;
/**
 * Creates a new DataBrew project.
 */
export declare const createProject: API.OperationMethod<CreateProjectRequest, CreateProjectResponse, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateRecipeError = ConflictException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new DataBrew recipe.
 */
export declare const createRecipe: API.OperationMethod<CreateRecipeRequest, CreateRecipeResponse, CreateRecipeError, Credentials | HttpClient.HttpClient>;
export type CreateRecipeJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | DataBrewRoleNotAssumable | CommonErrors;
/**
 * Creates a new job to transform input data, using steps defined in an existing Glue DataBrew recipe
 */
export declare const createRecipeJob: API.OperationMethod<CreateRecipeJobRequest, CreateRecipeJobResponse, CreateRecipeJobError, Credentials | HttpClient.HttpClient>;
export type CreateRulesetError = ConflictException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new ruleset that can be used in a profile job to validate
 * the data quality of a dataset.
 */
export declare const createRuleset: API.OperationMethod<CreateRulesetRequest, CreateRulesetResponse, CreateRulesetError, Credentials | HttpClient.HttpClient>;
export type CreateScheduleError = ConflictException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new schedule for one or more DataBrew jobs. Jobs can be run at a specific
 * date and time, or at regular intervals.
 */
export declare const createSchedule: API.OperationMethod<CreateScheduleRequest, CreateScheduleResponse, CreateScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = ConflictException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a dataset from DataBrew.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = ConflictException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified DataBrew job.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest, DeleteJobResponse, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = ConflictException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing DataBrew project.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest, DeleteProjectResponse, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteRecipeVersionError = ConflictException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a single version of a DataBrew recipe.
 */
export declare const deleteRecipeVersion: API.OperationMethod<DeleteRecipeVersionRequest, DeleteRecipeVersionResponse, DeleteRecipeVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteRulesetError = ConflictException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a ruleset.
 */
export declare const deleteRuleset: API.OperationMethod<DeleteRulesetRequest, DeleteRulesetResponse, DeleteRulesetError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduleError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the specified DataBrew schedule.
 */
export declare const deleteSchedule: API.OperationMethod<DeleteScheduleRequest, DeleteScheduleResponse, DeleteScheduleError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Returns the definition of a specific DataBrew dataset.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeJobError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Returns the definition of a specific DataBrew job.
 */
export declare const describeJob: API.OperationMethod<DescribeJobRequest, DescribeJobResponse, DescribeJobError, Credentials | HttpClient.HttpClient>;
export type DescribeJobRunError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Represents one run of a DataBrew job.
 */
export declare const describeJobRun: API.OperationMethod<DescribeJobRunRequest, DescribeJobRunResponse, DescribeJobRunError, Credentials | HttpClient.HttpClient>;
export type DescribeProjectError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Returns the definition of a specific DataBrew project.
 */
export declare const describeProject: API.OperationMethod<DescribeProjectRequest, DescribeProjectResponse, DescribeProjectError, Credentials | HttpClient.HttpClient>;
export type DescribeRecipeError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Returns the definition of a specific DataBrew recipe corresponding to a particular
 * version.
 */
export declare const describeRecipe: API.OperationMethod<DescribeRecipeRequest, DescribeRecipeResponse, DescribeRecipeError, Credentials | HttpClient.HttpClient>;
export type DescribeRulesetError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves detailed information about the ruleset.
 */
export declare const describeRuleset: API.OperationMethod<DescribeRulesetRequest, DescribeRulesetResponse, DescribeRulesetError, Credentials | HttpClient.HttpClient>;
export type DescribeScheduleError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Returns the definition of a specific DataBrew schedule.
 */
export declare const describeSchedule: API.OperationMethod<DescribeScheduleRequest, DescribeScheduleResponse, DescribeScheduleError, Credentials | HttpClient.HttpClient>;
export type ListDatasetsError = ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the DataBrew datasets.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, Dataset>;
export type ListJobRunsError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the previous runs of a particular DataBrew job.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsRequest, ListJobRunsResponse, ListJobRunsError, Credentials | HttpClient.HttpClient, JobRun>;
export type ListJobsError = ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the DataBrew jobs that are defined.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, Job>;
export type ListProjectsError = ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the DataBrew projects that are defined.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest, ListProjectsResponse, ListProjectsError, Credentials | HttpClient.HttpClient, Project>;
export type ListRecipesError = ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists all of the DataBrew recipes that are defined.
 */
export declare const listRecipes: API.PaginatedOperationMethod<ListRecipesRequest, ListRecipesResponse, ListRecipesError, Credentials | HttpClient.HttpClient, Recipe>;
export type ListRecipeVersionsError = ValidationException | TooManyRequestsException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the versions of a particular DataBrew recipe, except for
 * `LATEST_WORKING`.
 */
export declare const listRecipeVersions: API.PaginatedOperationMethod<ListRecipeVersionsRequest, ListRecipeVersionsResponse, ListRecipeVersionsError, Credentials | HttpClient.HttpClient, Recipe>;
export type ListRulesetsError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * List all rulesets available in the current account or rulesets associated
 * with a specific resource (dataset).
 */
export declare const listRulesets: API.PaginatedOperationMethod<ListRulesetsRequest, ListRulesetsResponse, ListRulesetsError, Credentials | HttpClient.HttpClient, RulesetItem>;
export type ListSchedulesError = ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists the DataBrew schedules that are defined.
 */
export declare const listSchedules: API.PaginatedOperationMethod<ListSchedulesRequest, ListSchedulesResponse, ListSchedulesError, Credentials | HttpClient.HttpClient, Schedule>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists all the tags for a DataBrew resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PublishRecipeError = ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Publishes a new version of a DataBrew recipe.
 */
export declare const publishRecipe: API.OperationMethod<PublishRecipeRequest, PublishRecipeResponse, PublishRecipeError, Credentials | HttpClient.HttpClient>;
export type SendProjectSessionActionError = ConflictException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Performs a recipe step within an interactive DataBrew session that's currently
 * open.
 */
export declare const sendProjectSessionAction: API.OperationMethod<SendProjectSessionActionRequest, SendProjectSessionActionResponse, SendProjectSessionActionError, Credentials | HttpClient.HttpClient>;
export type StartJobRunError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Runs a DataBrew job.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest, StartJobRunResponse, StartJobRunError, Credentials | HttpClient.HttpClient>;
export type StartProjectSessionError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an interactive session, enabling you to manipulate data in a DataBrew
 * project.
 */
export declare const startProjectSession: API.OperationMethod<StartProjectSessionRequest, StartProjectSessionResponse, StartProjectSessionError, Credentials | HttpClient.HttpClient>;
export type StopJobRunError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Stops a particular run of a job.
 */
export declare const stopJobRun: API.OperationMethod<StopJobRunRequest, StopJobRunResponse, StopJobRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Adds metadata tags to a DataBrew resource, such as a dataset, project, recipe, job, or
 * schedule.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Removes metadata tags from a DataBrew resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetError = AccessDeniedException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Modifies the definition of an existing DataBrew dataset.
 */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest, UpdateDatasetResponse, UpdateDatasetError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileJobError = AccessDeniedException | ResourceNotFoundException | ValidationException | TooManyRequestsException | DataBrewRoleNotAssumable | CommonErrors;
/**
 * Modifies the definition of an existing profile job.
 */
export declare const updateProfileJob: API.OperationMethod<UpdateProfileJobRequest, UpdateProfileJobResponse, UpdateProfileJobError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = ResourceNotFoundException | ValidationException | TooManyRequestsException | DataBrewRoleNotAssumable | CommonErrors;
/**
 * Modifies the definition of an existing DataBrew project.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectRequest, UpdateProjectResponse, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateRecipeError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Modifies the definition of the `LATEST_WORKING` version of a DataBrew
 * recipe.
 */
export declare const updateRecipe: API.OperationMethod<UpdateRecipeRequest, UpdateRecipeResponse, UpdateRecipeError, Credentials | HttpClient.HttpClient>;
export type UpdateRecipeJobError = AccessDeniedException | ResourceNotFoundException | ValidationException | TooManyRequestsException | DataBrewRoleNotAssumable | CommonErrors;
/**
 * Modifies the definition of an existing DataBrew recipe job.
 */
export declare const updateRecipeJob: API.OperationMethod<UpdateRecipeJobRequest, UpdateRecipeJobResponse, UpdateRecipeJobError, Credentials | HttpClient.HttpClient>;
export type UpdateRulesetError = ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Updates specified ruleset.
 */
export declare const updateRuleset: API.OperationMethod<UpdateRulesetRequest, UpdateRulesetResponse, UpdateRulesetError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduleError = ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Modifies the definition of an existing DataBrew schedule.
 */
export declare const updateSchedule: API.OperationMethod<UpdateScheduleRequest, UpdateScheduleResponse, UpdateScheduleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=databrew.d.ts.map