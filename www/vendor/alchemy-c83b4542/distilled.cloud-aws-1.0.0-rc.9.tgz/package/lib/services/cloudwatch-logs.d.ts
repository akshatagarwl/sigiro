import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as stream from "effect/Stream";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DataAlreadyAcceptedException_base: S.Class<DataAlreadyAcceptedException, S.TaggedStruct<"DataAlreadyAcceptedException", {
    readonly expectedSequenceToken: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DataAlreadyAcceptedException extends /*@__PURE__*/ DataAlreadyAcceptedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidOperationException_base: S.Class<InvalidOperationException, S.TaggedStruct<"InvalidOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidSequenceTokenException_base: S.Class<InvalidSequenceTokenException, S.TaggedStruct<"InvalidSequenceTokenException", {
    readonly expectedSequenceToken: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSequenceTokenException extends /*@__PURE__*/ InvalidSequenceTokenException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MalformedQueryException_base: S.Class<MalformedQueryException, S.TaggedStruct<"MalformedQueryException", {
    readonly queryCompileError: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MalformedQueryException extends /*@__PURE__*/ MalformedQueryException_base {
}
declare const OperationAbortedException_base: S.Class<OperationAbortedException, S.TaggedStruct<"OperationAbortedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class OperationAbortedException extends /*@__PURE__*/ OperationAbortedException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnrecognizedClientException_base: S.Class<UnrecognizedClientException, S.TaggedStruct<"UnrecognizedClientException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnrecognizedClientException extends /*@__PURE__*/ UnrecognizedClientException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type LogGroupName = string;
export type KmsKeyId = string;
export type ResourceIdentifier = string;
export interface AssociateKmsKeyRequest {
    logGroupName?: string;
    kmsKeyId: string;
    resourceIdentifier?: string;
}
export declare const AssociateKmsKeyRequest: S.Schema<AssociateKmsKeyRequest>;
export interface AssociateKmsKeyResponse {
}
export declare const AssociateKmsKeyResponse: S.Schema<AssociateKmsKeyResponse>;
export type Arn = string;
export type DataSourceName = string;
export type DataSourceType = string;
export interface DataSource {
    name: string;
    type?: string;
}
export declare const DataSource: S.Schema<DataSource>;
export interface AssociateSourceToS3TableIntegrationRequest {
    integrationArn: string;
    dataSource: DataSource;
}
export declare const AssociateSourceToS3TableIntegrationRequest: S.Schema<AssociateSourceToS3TableIntegrationRequest>;
export type S3TableIntegrationSourceIdentifier = string;
export interface AssociateSourceToS3TableIntegrationResponse {
    identifier?: string;
}
export declare const AssociateSourceToS3TableIntegrationResponse: S.Schema<AssociateSourceToS3TableIntegrationResponse>;
export type ExportTaskId = string;
export interface CancelExportTaskRequest {
    taskId: string;
}
export declare const CancelExportTaskRequest: S.Schema<CancelExportTaskRequest>;
export interface CancelExportTaskResponse {
}
export declare const CancelExportTaskResponse: S.Schema<CancelExportTaskResponse>;
export type ImportId = string;
export interface CancelImportTaskRequest {
    importId: string;
}
export declare const CancelImportTaskRequest: S.Schema<CancelImportTaskRequest>;
export type StoredBytes = number;
export interface ImportStatistics {
    bytesImported?: number;
}
export declare const ImportStatistics: S.Schema<ImportStatistics>;
export type ImportStatus = "IN_PROGRESS" | "CANCELLED" | "COMPLETED" | "FAILED" | (string & {});
export declare const ImportStatus: any;
export interface CancelImportTaskResponse {
    importId?: string;
    importStatistics?: ImportStatistics;
    importStatus?: ImportStatus;
    creationTime?: number;
    lastUpdatedTime?: number;
}
export declare const CancelImportTaskResponse: S.Schema<CancelImportTaskResponse>;
export type DeliverySourceName = string;
export type FieldHeader = string;
export type RecordFields = string[];
export declare const RecordFields: any;
export type FieldDelimiter = string;
export type DeliverySuffixPath = string;
export interface S3DeliveryConfiguration {
    suffixPath?: string;
    enableHiveCompatiblePath?: boolean;
}
export declare const S3DeliveryConfiguration: S.Schema<S3DeliveryConfiguration>;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CreateDeliveryRequest {
    deliverySourceName: string;
    deliveryDestinationArn: string;
    recordFields?: string[];
    fieldDelimiter?: string;
    s3DeliveryConfiguration?: S3DeliveryConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDeliveryRequest: S.Schema<CreateDeliveryRequest>;
export type DeliveryId = string;
export type DeliveryDestinationType = "S3" | "CWL" | "FH" | "XRAY" | (string & {});
export declare const DeliveryDestinationType: any;
export interface Delivery {
    id?: string;
    arn?: string;
    deliverySourceName?: string;
    deliveryDestinationArn?: string;
    deliveryDestinationType?: DeliveryDestinationType;
    recordFields?: string[];
    fieldDelimiter?: string;
    s3DeliveryConfiguration?: S3DeliveryConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Delivery: S.Schema<Delivery>;
export interface CreateDeliveryResponse {
    delivery?: Delivery;
}
export declare const CreateDeliveryResponse: S.Schema<CreateDeliveryResponse>;
export type ExportTaskName = string;
export type LogStreamName = string;
export type ExportDestinationBucket = string;
export type ExportDestinationPrefix = string;
export interface CreateExportTaskRequest {
    taskName?: string;
    logGroupName: string;
    logStreamNamePrefix?: string;
    from: number;
    to: number;
    destination: string;
    destinationPrefix?: string;
}
export declare const CreateExportTaskRequest: S.Schema<CreateExportTaskRequest>;
export interface CreateExportTaskResponse {
    taskId?: string;
}
export declare const CreateExportTaskResponse: S.Schema<CreateExportTaskResponse>;
export type RoleArn = string;
export interface ImportFilter {
    startEventTime?: number;
    endEventTime?: number;
}
export declare const ImportFilter: S.Schema<ImportFilter>;
export interface CreateImportTaskRequest {
    importSourceArn: string;
    importRoleArn: string;
    importFilter?: ImportFilter;
}
export declare const CreateImportTaskRequest: S.Schema<CreateImportTaskRequest>;
export interface CreateImportTaskResponse {
    importId?: string;
    importDestinationArn?: string;
    creationTime?: number;
}
export declare const CreateImportTaskResponse: S.Schema<CreateImportTaskResponse>;
export type LogGroupArn = string;
export type LogGroupArnList = string[];
export declare const LogGroupArnList: any;
export type DetectorName = string;
export type EvaluationFrequency = "ONE_MIN" | "FIVE_MIN" | "TEN_MIN" | "FIFTEEN_MIN" | "THIRTY_MIN" | "ONE_HOUR" | (string & {});
export declare const EvaluationFrequency: any;
export type FilterPattern = string;
export type DetectorKmsKeyArn = string;
export type AnomalyVisibilityTime = number;
export interface CreateLogAnomalyDetectorRequest {
    logGroupArnList: string[];
    detectorName?: string;
    evaluationFrequency?: EvaluationFrequency;
    filterPattern?: string;
    kmsKeyId?: string;
    anomalyVisibilityTime?: number;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateLogAnomalyDetectorRequest: S.Schema<CreateLogAnomalyDetectorRequest>;
export type AnomalyDetectorArn = string;
export interface CreateLogAnomalyDetectorResponse {
    anomalyDetectorArn?: string;
}
export declare const CreateLogAnomalyDetectorResponse: S.Schema<CreateLogAnomalyDetectorResponse>;
export type LogGroupClass = "STANDARD" | "INFREQUENT_ACCESS" | "DELIVERY" | (string & {});
export declare const LogGroupClass: any;
export type DeletionProtectionEnabled = boolean;
export interface CreateLogGroupRequest {
    logGroupName: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    logGroupClass?: LogGroupClass;
    deletionProtectionEnabled?: boolean;
}
export declare const CreateLogGroupRequest: S.Schema<CreateLogGroupRequest>;
export interface CreateLogGroupResponse {
}
export declare const CreateLogGroupResponse: S.Schema<CreateLogGroupResponse>;
export interface CreateLogStreamRequest {
    logGroupName: string;
    logStreamName: string;
}
export declare const CreateLogStreamRequest: S.Schema<CreateLogStreamRequest>;
export interface CreateLogStreamResponse {
}
export declare const CreateLogStreamResponse: S.Schema<CreateLogStreamResponse>;
export type LookupTableName = string;
export type LookupTableDescription = string;
export type TableBody = string;
export type QueryId = string;
export interface CreateLookupTableRequest {
    lookupTableName: string;
    description?: string;
    tableBody?: string;
    queryId?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateLookupTableRequest: S.Schema<CreateLookupTableRequest>;
export interface CreateLookupTableResponse {
    lookupTableArn?: string;
    createdAt?: number;
}
export declare const CreateLookupTableResponse: S.Schema<CreateLookupTableResponse>;
export type ScheduledQueryName = string;
export type ScheduledQueryDescription = string;
export type QueryLanguage = "CWLI" | "SQL" | "PPL" | (string & {});
export declare const QueryLanguage: any;
export type QueryString = string;
export type LogGroupIdentifier = string;
export type ScheduledQueryLogGroupIdentifiers = string[];
export declare const ScheduledQueryLogGroupIdentifiers: any;
export type ScheduleExpression = string;
export type ScheduleTimezone = string;
export type StartTimeOffset = number;
export type EndTimeOffset = number;
export type S3Uri = string;
export type AccountId = string;
export interface S3Configuration {
    destinationIdentifier: string;
    roleArn: string;
    ownerAccountId?: string;
    kmsKeyId?: string;
}
export declare const S3Configuration: S.Schema<S3Configuration>;
export interface LookupTableConfiguration {
    tableName: string;
    roleArn: string;
    description?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const LookupTableConfiguration: S.Schema<LookupTableConfiguration>;
export interface DestinationConfiguration {
    s3Configuration?: S3Configuration;
    lookupTableConfiguration?: LookupTableConfiguration;
}
export declare const DestinationConfiguration: S.Schema<DestinationConfiguration>;
export type ScheduledQueryState = "ENABLED" | "DISABLED" | (string & {});
export declare const ScheduledQueryState: any;
export interface CreateScheduledQueryRequest {
    name: string;
    description?: string;
    queryLanguage: QueryLanguage;
    queryString: string;
    logGroupIdentifiers?: string[];
    scheduleExpression: string;
    timezone?: string;
    startTimeOffset?: number;
    endTimeOffset?: number;
    destinationConfiguration?: DestinationConfiguration;
    scheduleStartTime?: number;
    scheduleEndTime?: number;
    executionRoleArn: string;
    state?: ScheduledQueryState;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateScheduledQueryRequest: S.Schema<CreateScheduledQueryRequest>;
export interface CreateScheduledQueryResponse {
    scheduledQueryArn?: string;
    state?: ScheduledQueryState;
}
export declare const CreateScheduledQueryResponse: S.Schema<CreateScheduledQueryResponse>;
export type PolicyName = string;
export type PolicyType = "DATA_PROTECTION_POLICY" | "SUBSCRIPTION_FILTER_POLICY" | "FIELD_INDEX_POLICY" | "TRANSFORMER_POLICY" | "METRIC_EXTRACTION_POLICY" | (string & {});
export declare const PolicyType: any;
export interface DeleteAccountPolicyRequest {
    policyName: string;
    policyType: PolicyType;
}
export declare const DeleteAccountPolicyRequest: S.Schema<DeleteAccountPolicyRequest>;
export interface DeleteAccountPolicyResponse {
}
export declare const DeleteAccountPolicyResponse: S.Schema<DeleteAccountPolicyResponse>;
export interface DeleteDataProtectionPolicyRequest {
    logGroupIdentifier: string;
}
export declare const DeleteDataProtectionPolicyRequest: S.Schema<DeleteDataProtectionPolicyRequest>;
export interface DeleteDataProtectionPolicyResponse {
}
export declare const DeleteDataProtectionPolicyResponse: S.Schema<DeleteDataProtectionPolicyResponse>;
export interface DeleteDeliveryRequest {
    id: string;
}
export declare const DeleteDeliveryRequest: S.Schema<DeleteDeliveryRequest>;
export interface DeleteDeliveryResponse {
}
export declare const DeleteDeliveryResponse: S.Schema<DeleteDeliveryResponse>;
export type DeliveryDestinationName = string;
export interface DeleteDeliveryDestinationRequest {
    name: string;
}
export declare const DeleteDeliveryDestinationRequest: S.Schema<DeleteDeliveryDestinationRequest>;
export interface DeleteDeliveryDestinationResponse {
}
export declare const DeleteDeliveryDestinationResponse: S.Schema<DeleteDeliveryDestinationResponse>;
export interface DeleteDeliveryDestinationPolicyRequest {
    deliveryDestinationName: string;
}
export declare const DeleteDeliveryDestinationPolicyRequest: S.Schema<DeleteDeliveryDestinationPolicyRequest>;
export interface DeleteDeliveryDestinationPolicyResponse {
}
export declare const DeleteDeliveryDestinationPolicyResponse: S.Schema<DeleteDeliveryDestinationPolicyResponse>;
export interface DeleteDeliverySourceRequest {
    name: string;
}
export declare const DeleteDeliverySourceRequest: S.Schema<DeleteDeliverySourceRequest>;
export interface DeleteDeliverySourceResponse {
}
export declare const DeleteDeliverySourceResponse: S.Schema<DeleteDeliverySourceResponse>;
export type DestinationName = string;
export interface DeleteDestinationRequest {
    destinationName: string;
}
export declare const DeleteDestinationRequest: S.Schema<DeleteDestinationRequest>;
export interface DeleteDestinationResponse {
}
export declare const DeleteDestinationResponse: S.Schema<DeleteDestinationResponse>;
export interface DeleteIndexPolicyRequest {
    logGroupIdentifier: string;
}
export declare const DeleteIndexPolicyRequest: S.Schema<DeleteIndexPolicyRequest>;
export interface DeleteIndexPolicyResponse {
}
export declare const DeleteIndexPolicyResponse: S.Schema<DeleteIndexPolicyResponse>;
export type IntegrationName = string;
export type Force = boolean;
export interface DeleteIntegrationRequest {
    integrationName: string;
    force?: boolean;
}
export declare const DeleteIntegrationRequest: S.Schema<DeleteIntegrationRequest>;
export interface DeleteIntegrationResponse {
}
export declare const DeleteIntegrationResponse: S.Schema<DeleteIntegrationResponse>;
export interface DeleteLogAnomalyDetectorRequest {
    anomalyDetectorArn: string;
}
export declare const DeleteLogAnomalyDetectorRequest: S.Schema<DeleteLogAnomalyDetectorRequest>;
export interface DeleteLogAnomalyDetectorResponse {
}
export declare const DeleteLogAnomalyDetectorResponse: S.Schema<DeleteLogAnomalyDetectorResponse>;
export interface DeleteLogGroupRequest {
    logGroupName: string;
}
export declare const DeleteLogGroupRequest: S.Schema<DeleteLogGroupRequest>;
export interface DeleteLogGroupResponse {
}
export declare const DeleteLogGroupResponse: S.Schema<DeleteLogGroupResponse>;
export interface DeleteLogStreamRequest {
    logGroupName: string;
    logStreamName: string;
}
export declare const DeleteLogStreamRequest: S.Schema<DeleteLogStreamRequest>;
export interface DeleteLogStreamResponse {
}
export declare const DeleteLogStreamResponse: S.Schema<DeleteLogStreamResponse>;
export interface DeleteLookupTableRequest {
    lookupTableArn: string;
}
export declare const DeleteLookupTableRequest: S.Schema<DeleteLookupTableRequest>;
export interface DeleteLookupTableResponse {
}
export declare const DeleteLookupTableResponse: S.Schema<DeleteLookupTableResponse>;
export type FilterName = string;
export interface DeleteMetricFilterRequest {
    logGroupName: string;
    filterName: string;
}
export declare const DeleteMetricFilterRequest: S.Schema<DeleteMetricFilterRequest>;
export interface DeleteMetricFilterResponse {
}
export declare const DeleteMetricFilterResponse: S.Schema<DeleteMetricFilterResponse>;
export interface DeleteQueryDefinitionRequest {
    queryDefinitionId: string;
}
export declare const DeleteQueryDefinitionRequest: S.Schema<DeleteQueryDefinitionRequest>;
export type Success = boolean;
export interface DeleteQueryDefinitionResponse {
    success?: boolean;
}
export declare const DeleteQueryDefinitionResponse: S.Schema<DeleteQueryDefinitionResponse>;
export type ExpectedRevisionId = string;
export interface DeleteResourcePolicyRequest {
    policyName?: string;
    resourceArn?: string;
    expectedRevisionId?: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DeleteRetentionPolicyRequest {
    logGroupName: string;
}
export declare const DeleteRetentionPolicyRequest: S.Schema<DeleteRetentionPolicyRequest>;
export interface DeleteRetentionPolicyResponse {
}
export declare const DeleteRetentionPolicyResponse: S.Schema<DeleteRetentionPolicyResponse>;
export type ScheduledQueryIdentifier = string;
export interface DeleteScheduledQueryRequest {
    identifier: string;
}
export declare const DeleteScheduledQueryRequest: S.Schema<DeleteScheduledQueryRequest>;
export interface DeleteScheduledQueryResponse {
}
export declare const DeleteScheduledQueryResponse: S.Schema<DeleteScheduledQueryResponse>;
export interface DeleteSubscriptionFilterRequest {
    logGroupName: string;
    filterName: string;
}
export declare const DeleteSubscriptionFilterRequest: S.Schema<DeleteSubscriptionFilterRequest>;
export interface DeleteSubscriptionFilterResponse {
}
export declare const DeleteSubscriptionFilterResponse: S.Schema<DeleteSubscriptionFilterResponse>;
export type VpcEndpointId = string;
export interface DeleteSyslogConfigurationRequest {
    logGroupIdentifier: string;
    vpcEndpointId?: string;
}
export declare const DeleteSyslogConfigurationRequest: S.Schema<DeleteSyslogConfigurationRequest>;
export interface DeleteSyslogConfigurationResponse {
}
export declare const DeleteSyslogConfigurationResponse: S.Schema<DeleteSyslogConfigurationResponse>;
export interface DeleteTransformerRequest {
    logGroupIdentifier: string;
}
export declare const DeleteTransformerRequest: S.Schema<DeleteTransformerRequest>;
export interface DeleteTransformerResponse {
}
export declare const DeleteTransformerResponse: S.Schema<DeleteTransformerResponse>;
export type AccountIds = string[];
export declare const AccountIds: any;
export type NextToken = string;
export interface DescribeAccountPoliciesRequest {
    policyType: PolicyType;
    policyName?: string;
    accountIdentifiers?: string[];
    nextToken?: string;
}
export declare const DescribeAccountPoliciesRequest: S.Schema<DescribeAccountPoliciesRequest>;
export type AccountPolicyDocument = string;
export type Scope = "ALL" | (string & {});
export declare const Scope: any;
export type SelectionCriteria = string;
export interface AccountPolicy {
    policyName?: string;
    policyDocument?: string;
    lastUpdatedTime?: number;
    policyType?: PolicyType;
    scope?: Scope;
    selectionCriteria?: string;
    accountId?: string;
}
export declare const AccountPolicy: S.Schema<AccountPolicy>;
export type AccountPolicies = AccountPolicy[];
export declare const AccountPolicies: any;
export interface DescribeAccountPoliciesResponse {
    accountPolicies?: AccountPolicy[];
    nextToken?: string;
}
export declare const DescribeAccountPoliciesResponse: S.Schema<DescribeAccountPoliciesResponse>;
export type Service = string;
export type LogType = string;
export type LogTypes = string[];
export declare const LogTypes: any;
export type ResourceType = string;
export type ResourceTypes = string[];
export declare const ResourceTypes: any;
export type DeliveryDestinationTypes = DeliveryDestinationType[];
export declare const DeliveryDestinationTypes: any;
export type DescribeLimit = number;
export interface DescribeConfigurationTemplatesRequest {
    service?: string;
    logTypes?: string[];
    resourceTypes?: string[];
    deliveryDestinationTypes?: DeliveryDestinationType[];
    nextToken?: string;
    limit?: number;
}
export declare const DescribeConfigurationTemplatesRequest: S.Schema<DescribeConfigurationTemplatesRequest>;
export interface ConfigurationTemplateDeliveryConfigValues {
    recordFields?: string[];
    fieldDelimiter?: string;
    s3DeliveryConfiguration?: S3DeliveryConfiguration;
}
export declare const ConfigurationTemplateDeliveryConfigValues: S.Schema<ConfigurationTemplateDeliveryConfigValues>;
export interface RecordField {
    name?: string;
    mandatory?: boolean;
}
export declare const RecordField: S.Schema<RecordField>;
export type AllowedFields = RecordField[];
export declare const AllowedFields: any;
export type OutputFormat = "json" | "plain" | "w3c" | "raw" | "parquet" | (string & {});
export declare const OutputFormat: any;
export type OutputFormats = OutputFormat[];
export declare const OutputFormats: any;
export type AllowedActionForAllowVendedLogsDeliveryForResource = string;
export type AllowedFieldDelimiters = string[];
export declare const AllowedFieldDelimiters: any;
export type DeliverySourceConfigurationSchemaField = string;
export type DeliverySourceConfigurationSchemaValueType = "string" | "boolean" | "int" | "double" | "long" | (string & {});
export declare const DeliverySourceConfigurationSchemaValueType: any;
export type DeliverySourceConfigurationSupportedValues = string[];
export declare const DeliverySourceConfigurationSupportedValues: any;
export type DeliverySourceConfigurationNumericValue = number;
export interface DeliverySourceConfigurationSchema {
    keyName: string;
    valueType: DeliverySourceConfigurationSchemaValueType;
    defaultValue: string;
    supportedValues?: string[];
    minValue?: number;
    maxValue?: number;
}
export declare const DeliverySourceConfigurationSchema: S.Schema<DeliverySourceConfigurationSchema>;
export type DeliverySourceConfigurationSchemas = DeliverySourceConfigurationSchema[];
export declare const DeliverySourceConfigurationSchemas: any;
export type S3TablesDatasourceName = string;
export type S3TablesDatasourceType = string;
export interface S3TablesIntegration {
    datasourceName?: string;
    datasourceType?: string;
}
export declare const S3TablesIntegration: S.Schema<S3TablesIntegration>;
export interface ConfigurationTemplate {
    service?: string;
    logType?: string;
    resourceType?: string;
    deliveryDestinationType?: DeliveryDestinationType;
    defaultDeliveryConfigValues?: ConfigurationTemplateDeliveryConfigValues;
    allowedFields?: RecordField[];
    allowedOutputFormats?: OutputFormat[];
    allowedActionForAllowVendedLogsDeliveryForResource?: string;
    allowedFieldDelimiters?: string[];
    allowedSuffixPathFields?: string[];
    deliverySourceConfiguration?: DeliverySourceConfigurationSchema[];
    s3TablesIntegration?: S3TablesIntegration;
}
export declare const ConfigurationTemplate: S.Schema<ConfigurationTemplate>;
export type ConfigurationTemplates = ConfigurationTemplate[];
export declare const ConfigurationTemplates: any;
export interface DescribeConfigurationTemplatesResponse {
    configurationTemplates?: ConfigurationTemplate[];
    nextToken?: string;
}
export declare const DescribeConfigurationTemplatesResponse: S.Schema<DescribeConfigurationTemplatesResponse>;
export interface DescribeDeliveriesRequest {
    nextToken?: string;
    limit?: number;
}
export declare const DescribeDeliveriesRequest: S.Schema<DescribeDeliveriesRequest>;
export type Deliveries = Delivery[];
export declare const Deliveries: any;
export interface DescribeDeliveriesResponse {
    deliveries?: Delivery[];
    nextToken?: string;
}
export declare const DescribeDeliveriesResponse: S.Schema<DescribeDeliveriesResponse>;
export interface DescribeDeliveryDestinationsRequest {
    nextToken?: string;
    limit?: number;
}
export declare const DescribeDeliveryDestinationsRequest: S.Schema<DescribeDeliveryDestinationsRequest>;
export interface DeliveryDestinationConfiguration {
    destinationResourceArn: string;
}
export declare const DeliveryDestinationConfiguration: S.Schema<DeliveryDestinationConfiguration>;
export interface DeliveryDestination {
    name?: string;
    arn?: string;
    deliveryDestinationType?: DeliveryDestinationType;
    outputFormat?: OutputFormat;
    deliveryDestinationConfiguration?: DeliveryDestinationConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DeliveryDestination: S.Schema<DeliveryDestination>;
export type DeliveryDestinations = DeliveryDestination[];
export declare const DeliveryDestinations: any;
export interface DescribeDeliveryDestinationsResponse {
    deliveryDestinations?: DeliveryDestination[];
    nextToken?: string;
}
export declare const DescribeDeliveryDestinationsResponse: S.Schema<DescribeDeliveryDestinationsResponse>;
export interface DescribeDeliverySourcesRequest {
    nextToken?: string;
    limit?: number;
}
export declare const DescribeDeliverySourcesRequest: S.Schema<DescribeDeliverySourcesRequest>;
export type ResourceArns = string[];
export declare const ResourceArns: any;
export type DeliverySourceConfigurationKey = string;
export type DeliverySourceConfigurationValue = string;
export type DeliverySourceConfiguration = {
    [key: string]: string | undefined;
};
export declare const DeliverySourceConfiguration: any;
export type DeliverySourceStatus = "ACTIVE" | "INACTIVE" | (string & {});
export declare const DeliverySourceStatus: any;
export type DeliverySourceStatusReason = "RESOURCE_DELETED" | (string & {});
export declare const DeliverySourceStatusReason: any;
export interface DeliverySource {
    name?: string;
    arn?: string;
    resourceArns?: string[];
    service?: string;
    logType?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    deliverySourceConfiguration?: {
        [key: string]: string | undefined;
    };
    status?: DeliverySourceStatus;
    statusReason?: DeliverySourceStatusReason;
}
export declare const DeliverySource: S.Schema<DeliverySource>;
export type DeliverySources = DeliverySource[];
export declare const DeliverySources: any;
export interface DescribeDeliverySourcesResponse {
    deliverySources?: DeliverySource[];
    nextToken?: string;
}
export declare const DescribeDeliverySourcesResponse: S.Schema<DescribeDeliverySourcesResponse>;
export interface DescribeDestinationsRequest {
    DestinationNamePrefix?: string;
    nextToken?: string;
    limit?: number;
}
export declare const DescribeDestinationsRequest: S.Schema<DescribeDestinationsRequest>;
export type TargetArn = string;
export type AccessPolicy = string;
export interface Destination {
    destinationName?: string;
    targetArn?: string;
    roleArn?: string;
    accessPolicy?: string;
    arn?: string;
    creationTime?: number;
}
export declare const Destination: S.Schema<Destination>;
export type Destinations = Destination[];
export declare const Destinations: any;
export interface DescribeDestinationsResponse {
    destinations?: Destination[];
    nextToken?: string;
}
export declare const DescribeDestinationsResponse: S.Schema<DescribeDestinationsResponse>;
export type ExportTaskStatusCode = "CANCELLED" | "COMPLETED" | "FAILED" | "PENDING" | "PENDING_CANCEL" | "RUNNING" | (string & {});
export declare const ExportTaskStatusCode: any;
export interface DescribeExportTasksRequest {
    taskId?: string;
    statusCode?: ExportTaskStatusCode;
    nextToken?: string;
    limit?: number;
}
export declare const DescribeExportTasksRequest: S.Schema<DescribeExportTasksRequest>;
export type ExportTaskStatusMessage = string;
export interface ExportTaskStatus {
    code?: ExportTaskStatusCode;
    message?: string;
}
export declare const ExportTaskStatus: S.Schema<ExportTaskStatus>;
export interface ExportTaskExecutionInfo {
    creationTime?: number;
    completionTime?: number;
}
export declare const ExportTaskExecutionInfo: S.Schema<ExportTaskExecutionInfo>;
export interface ExportTask {
    taskId?: string;
    taskName?: string;
    logGroupName?: string;
    from?: number;
    to?: number;
    destination?: string;
    destinationPrefix?: string;
    status?: ExportTaskStatus;
    executionInfo?: ExportTaskExecutionInfo;
}
export declare const ExportTask: S.Schema<ExportTask>;
export type ExportTasks = ExportTask[];
export declare const ExportTasks: any;
export interface DescribeExportTasksResponse {
    exportTasks?: ExportTask[];
    nextToken?: string;
}
export declare const DescribeExportTasksResponse: S.Schema<DescribeExportTasksResponse>;
export type DescribeFieldIndexesLogGroupIdentifiers = string[];
export declare const DescribeFieldIndexesLogGroupIdentifiers: any;
export type IndexCategory = "DEFAULT" | "CUSTOM" | "AUTO" | "INACTIVE" | (string & {});
export declare const IndexCategory: any;
export type IndexCategories = IndexCategory[];
export declare const IndexCategories: any;
export interface DescribeFieldIndexesRequest {
    logGroupIdentifiers: string[];
    indexCategories?: IndexCategory[];
    nextToken?: string;
}
export declare const DescribeFieldIndexesRequest: S.Schema<DescribeFieldIndexesRequest>;
export type FieldIndexName = string;
export type IndexType = "FACET" | "FIELD_INDEX" | (string & {});
export declare const IndexType: any;
export interface FieldIndex {
    logGroupIdentifier?: string;
    fieldIndexName?: string;
    lastScanTime?: number;
    firstEventTime?: number;
    lastEventTime?: number;
    type?: IndexType;
    indexCategory?: IndexCategory;
}
export declare const FieldIndex: S.Schema<FieldIndex>;
export type FieldIndexes = FieldIndex[];
export declare const FieldIndexes: any;
export interface DescribeFieldIndexesResponse {
    fieldIndexes?: FieldIndex[];
    nextToken?: string;
}
export declare const DescribeFieldIndexesResponse: S.Schema<DescribeFieldIndexesResponse>;
export type ImportStatusList = ImportStatus[];
export declare const ImportStatusList: any;
export interface DescribeImportTaskBatchesRequest {
    importId: string;
    batchImportStatus?: ImportStatus[];
    limit?: number;
    nextToken?: string;
}
export declare const DescribeImportTaskBatchesRequest: S.Schema<DescribeImportTaskBatchesRequest>;
export type BatchId = string;
export type ErrorMessage = string;
export interface ImportBatch {
    batchId: string;
    status: ImportStatus;
    errorMessage?: string;
}
export declare const ImportBatch: S.Schema<ImportBatch>;
export type ImportBatchList = ImportBatch[];
export declare const ImportBatchList: any;
export interface DescribeImportTaskBatchesResponse {
    importSourceArn?: string;
    importId?: string;
    importBatches?: ImportBatch[];
    nextToken?: string;
}
export declare const DescribeImportTaskBatchesResponse: S.Schema<DescribeImportTaskBatchesResponse>;
export interface DescribeImportTasksRequest {
    importId?: string;
    importStatus?: ImportStatus;
    importSourceArn?: string;
    limit?: number;
    nextToken?: string;
}
export declare const DescribeImportTasksRequest: S.Schema<DescribeImportTasksRequest>;
export interface Import {
    importId?: string;
    importSourceArn?: string;
    importStatus?: ImportStatus;
    importDestinationArn?: string;
    importStatistics?: ImportStatistics;
    importFilter?: ImportFilter;
    creationTime?: number;
    lastUpdatedTime?: number;
    errorMessage?: string;
}
export declare const Import: S.Schema<Import>;
export type ImportList = Import[];
export declare const ImportList: any;
export interface DescribeImportTasksResponse {
    imports?: Import[];
    nextToken?: string;
}
export declare const DescribeImportTasksResponse: S.Schema<DescribeImportTasksResponse>;
export type DescribeIndexPoliciesLogGroupIdentifiers = string[];
export declare const DescribeIndexPoliciesLogGroupIdentifiers: any;
export interface DescribeIndexPoliciesRequest {
    logGroupIdentifiers: string[];
    nextToken?: string;
}
export declare const DescribeIndexPoliciesRequest: S.Schema<DescribeIndexPoliciesRequest>;
export type PolicyDocument = string;
export type IndexSource = "ACCOUNT" | "LOG_GROUP" | (string & {});
export declare const IndexSource: any;
export interface IndexPolicy {
    logGroupIdentifier?: string;
    lastUpdateTime?: number;
    policyDocument?: string;
    policyName?: string;
    source?: IndexSource;
}
export declare const IndexPolicy: S.Schema<IndexPolicy>;
export type IndexPolicies = IndexPolicy[];
export declare const IndexPolicies: any;
export interface DescribeIndexPoliciesResponse {
    indexPolicies?: IndexPolicy[];
    nextToken?: string;
}
export declare const DescribeIndexPoliciesResponse: S.Schema<DescribeIndexPoliciesResponse>;
export type LogGroupNamePattern = string;
export type IncludeLinkedAccounts = boolean;
export type DescribeLogGroupsLogGroupIdentifiers = string[];
export declare const DescribeLogGroupsLogGroupIdentifiers: any;
export interface DescribeLogGroupsRequest {
    accountIdentifiers?: string[];
    logGroupNamePrefix?: string;
    logGroupNamePattern?: string;
    nextToken?: string;
    limit?: number;
    includeLinkedAccounts?: boolean;
    logGroupClass?: LogGroupClass;
    logGroupIdentifiers?: string[];
}
export declare const DescribeLogGroupsRequest: S.Schema<DescribeLogGroupsRequest>;
export type Days = number;
export type FilterCount = number;
export type DataProtectionStatus = "ACTIVATED" | "DELETED" | "ARCHIVED" | "DISABLED" | (string & {});
export declare const DataProtectionStatus: any;
export type InheritedProperty = "ACCOUNT_DATA_PROTECTION" | (string & {});
export declare const InheritedProperty: any;
export type InheritedProperties = InheritedProperty[];
export declare const InheritedProperties: any;
export type BearerTokenAuthenticationEnabled = boolean;
export interface LogGroup {
    logGroupName?: string;
    creationTime?: number;
    retentionInDays?: number;
    metricFilterCount?: number;
    arn?: string;
    storedBytes?: number;
    kmsKeyId?: string;
    dataProtectionStatus?: DataProtectionStatus;
    inheritedProperties?: InheritedProperty[];
    logGroupClass?: LogGroupClass;
    logGroupArn?: string;
    deletionProtectionEnabled?: boolean;
    bearerTokenAuthenticationEnabled?: boolean;
}
export declare const LogGroup: S.Schema<LogGroup>;
export type LogGroups = LogGroup[];
export declare const LogGroups: any;
export interface DescribeLogGroupsResponse {
    logGroups?: LogGroup[];
    nextToken?: string;
}
export declare const DescribeLogGroupsResponse: S.Schema<DescribeLogGroupsResponse>;
export type OrderBy = "LogStreamName" | "LastEventTime" | (string & {});
export declare const OrderBy: any;
export type Descending = boolean;
export interface DescribeLogStreamsRequest {
    logGroupName?: string;
    logGroupIdentifier?: string;
    logStreamNamePrefix?: string;
    orderBy?: OrderBy;
    descending?: boolean;
    nextToken?: string;
    limit?: number;
}
export declare const DescribeLogStreamsRequest: S.Schema<DescribeLogStreamsRequest>;
export type SequenceToken = string;
export interface LogStream {
    logStreamName?: string;
    creationTime?: number;
    firstEventTimestamp?: number;
    lastEventTimestamp?: number;
    lastIngestionTime?: number;
    uploadSequenceToken?: string;
    arn?: string;
    storedBytes?: number;
}
export declare const LogStream: S.Schema<LogStream>;
export type LogStreams = LogStream[];
export declare const LogStreams: any;
export interface DescribeLogStreamsResponse {
    logStreams?: LogStream[];
    nextToken?: string;
}
export declare const DescribeLogStreamsResponse: S.Schema<DescribeLogStreamsResponse>;
export type DescribeLookupTablesMaxResults = number;
export interface DescribeLookupTablesRequest {
    lookupTableNamePrefix?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeLookupTablesRequest: S.Schema<DescribeLookupTablesRequest>;
export type TableFields = string[];
export declare const TableFields: any;
export type RecordsCount = number;
export interface LookupTable {
    lookupTableArn?: string;
    lookupTableName?: string;
    description?: string;
    tableFields?: string[];
    recordsCount?: number;
    sizeBytes?: number;
    lastUpdatedTime?: number;
    kmsKeyId?: string;
}
export declare const LookupTable: S.Schema<LookupTable>;
export type LookupTables = LookupTable[];
export declare const LookupTables: any;
export interface DescribeLookupTablesResponse {
    lookupTables?: LookupTable[];
    nextToken?: string;
}
export declare const DescribeLookupTablesResponse: S.Schema<DescribeLookupTablesResponse>;
export type MetricName = string;
export type MetricNamespace = string;
export interface DescribeMetricFiltersRequest {
    logGroupName?: string;
    filterNamePrefix?: string;
    nextToken?: string;
    limit?: number;
    metricName?: string;
    metricNamespace?: string;
}
export declare const DescribeMetricFiltersRequest: S.Schema<DescribeMetricFiltersRequest>;
export type MetricValue = string;
export type DefaultValue = number;
export type DimensionsKey = string;
export type DimensionsValue = string;
export type Dimensions = {
    [key: string]: string | undefined;
};
export declare const Dimensions: any;
export type StandardUnit = "Seconds" | "Microseconds" | "Milliseconds" | "Bytes" | "Kilobytes" | "Megabytes" | "Gigabytes" | "Terabytes" | "Bits" | "Kilobits" | "Megabits" | "Gigabits" | "Terabits" | "Percent" | "Count" | "Bytes/Second" | "Kilobytes/Second" | "Megabytes/Second" | "Gigabytes/Second" | "Terabytes/Second" | "Bits/Second" | "Kilobits/Second" | "Megabits/Second" | "Gigabits/Second" | "Terabits/Second" | "Count/Second" | "None" | (string & {});
export declare const StandardUnit: any;
export interface MetricTransformation {
    metricName: string;
    metricNamespace: string;
    metricValue: string;
    defaultValue?: number;
    dimensions?: {
        [key: string]: string | undefined;
    };
    unit?: StandardUnit;
}
export declare const MetricTransformation: S.Schema<MetricTransformation>;
export type MetricTransformations = MetricTransformation[];
export declare const MetricTransformations: any;
export type ApplyOnTransformedLogs = boolean;
export type FieldSelectionCriteria = string;
export type SystemField = string;
export type EmitSystemFields = string[];
export declare const EmitSystemFields: any;
export interface MetricFilter {
    filterName?: string;
    filterPattern?: string;
    metricTransformations?: MetricTransformation[];
    creationTime?: number;
    logGroupName?: string;
    applyOnTransformedLogs?: boolean;
    fieldSelectionCriteria?: string;
    emitSystemFieldDimensions?: string[];
}
export declare const MetricFilter: S.Schema<MetricFilter>;
export type MetricFilters = MetricFilter[];
export declare const MetricFilters: any;
export interface DescribeMetricFiltersResponse {
    metricFilters?: MetricFilter[];
    nextToken?: string;
}
export declare const DescribeMetricFiltersResponse: S.Schema<DescribeMetricFiltersResponse>;
export type QueryStatus = "Scheduled" | "Running" | "Complete" | "Failed" | "Cancelled" | "Timeout" | "Unknown" | (string & {});
export declare const QueryStatus: any;
export type DescribeQueriesMaxResults = number;
export interface DescribeQueriesRequest {
    logGroupName?: string;
    status?: QueryStatus;
    maxResults?: number;
    nextToken?: string;
    queryLanguage?: QueryLanguage;
}
export declare const DescribeQueriesRequest: S.Schema<DescribeQueriesRequest>;
export type QueryDuration = number;
export type BytesScannedValue = number;
export type UserIdentity = string;
export interface QueryInfo {
    queryLanguage?: QueryLanguage;
    queryId?: string;
    queryString?: string;
    status?: QueryStatus;
    createTime?: number;
    logGroupName?: string;
    queryDuration?: number;
    bytesScanned?: number;
    userIdentity?: string;
}
export declare const QueryInfo: S.Schema<QueryInfo>;
export type QueryInfoList = QueryInfo[];
export declare const QueryInfoList: any;
export interface DescribeQueriesResponse {
    queries?: QueryInfo[];
    nextToken?: string;
}
export declare const DescribeQueriesResponse: S.Schema<DescribeQueriesResponse>;
export type QueryDefinitionName = string;
export type QueryListMaxResults = number;
export interface DescribeQueryDefinitionsRequest {
    queryLanguage?: QueryLanguage;
    queryDefinitionNamePrefix?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const DescribeQueryDefinitionsRequest: S.Schema<DescribeQueryDefinitionsRequest>;
export type QueryDefinitionString = string;
export type LogGroupNames = string[];
export declare const LogGroupNames: any;
export type QueryParameterName = string;
export type QueryParameterDefaultValue = string;
export type QueryParameterDescription = string;
export interface QueryParameter {
    name: string;
    defaultValue?: string;
    description?: string;
}
export declare const QueryParameter: S.Schema<QueryParameter>;
export type QueryParameterList = QueryParameter[];
export declare const QueryParameterList: any;
export interface QueryDefinition {
    queryLanguage?: QueryLanguage;
    queryDefinitionId?: string;
    name?: string;
    queryString?: string;
    lastModified?: number;
    logGroupNames?: string[];
    parameters?: QueryParameter[];
}
export declare const QueryDefinition: S.Schema<QueryDefinition>;
export type QueryDefinitionList = QueryDefinition[];
export declare const QueryDefinitionList: any;
export interface DescribeQueryDefinitionsResponse {
    queryDefinitions?: QueryDefinition[];
    nextToken?: string;
}
export declare const DescribeQueryDefinitionsResponse: S.Schema<DescribeQueryDefinitionsResponse>;
export type PolicyScope = "ACCOUNT" | "RESOURCE" | (string & {});
export declare const PolicyScope: any;
export interface DescribeResourcePoliciesRequest {
    nextToken?: string;
    limit?: number;
    resourceArn?: string;
    policyScope?: PolicyScope;
}
export declare const DescribeResourcePoliciesRequest: S.Schema<DescribeResourcePoliciesRequest>;
export interface ResourcePolicy {
    policyName?: string;
    policyDocument?: string;
    lastUpdatedTime?: number;
    policyScope?: PolicyScope;
    resourceArn?: string;
    revisionId?: string;
}
export declare const ResourcePolicy: S.Schema<ResourcePolicy>;
export type ResourcePolicies = ResourcePolicy[];
export declare const ResourcePolicies: any;
export interface DescribeResourcePoliciesResponse {
    resourcePolicies?: ResourcePolicy[];
    nextToken?: string;
}
export declare const DescribeResourcePoliciesResponse: S.Schema<DescribeResourcePoliciesResponse>;
export interface DescribeSubscriptionFiltersRequest {
    logGroupName: string;
    filterNamePrefix?: string;
    nextToken?: string;
    limit?: number;
}
export declare const DescribeSubscriptionFiltersRequest: S.Schema<DescribeSubscriptionFiltersRequest>;
export type DestinationArn = string;
export type Distribution = "Random" | "ByLogStream" | (string & {});
export declare const Distribution: any;
export interface SubscriptionFilter {
    filterName?: string;
    logGroupName?: string;
    filterPattern?: string;
    destinationArn?: string;
    roleArn?: string;
    distribution?: Distribution;
    applyOnTransformedLogs?: boolean;
    creationTime?: number;
    fieldSelectionCriteria?: string;
    emitSystemFields?: string[];
}
export declare const SubscriptionFilter: S.Schema<SubscriptionFilter>;
export type SubscriptionFilters = SubscriptionFilter[];
export declare const SubscriptionFilters: any;
export interface DescribeSubscriptionFiltersResponse {
    subscriptionFilters?: SubscriptionFilter[];
    nextToken?: string;
}
export declare const DescribeSubscriptionFiltersResponse: S.Schema<DescribeSubscriptionFiltersResponse>;
export interface DisassociateKmsKeyRequest {
    logGroupName?: string;
    resourceIdentifier?: string;
}
export declare const DisassociateKmsKeyRequest: S.Schema<DisassociateKmsKeyRequest>;
export interface DisassociateKmsKeyResponse {
}
export declare const DisassociateKmsKeyResponse: S.Schema<DisassociateKmsKeyResponse>;
export interface DisassociateSourceFromS3TableIntegrationRequest {
    identifier: string;
}
export declare const DisassociateSourceFromS3TableIntegrationRequest: S.Schema<DisassociateSourceFromS3TableIntegrationRequest>;
export interface DisassociateSourceFromS3TableIntegrationResponse {
    identifier?: string;
}
export declare const DisassociateSourceFromS3TableIntegrationResponse: S.Schema<DisassociateSourceFromS3TableIntegrationResponse>;
export type InputLogStreamNames = string[];
export declare const InputLogStreamNames: any;
export type EventsLimit = number;
export type StartFromHead = boolean;
export type Interleaved = boolean;
export type Unmask = boolean;
export interface FilterLogEventsRequest {
    logGroupName?: string;
    logGroupIdentifier?: string;
    logStreamNames?: string[];
    logStreamNamePrefix?: string;
    startTime?: number;
    endTime?: number;
    filterPattern?: string;
    nextToken?: string;
    limit?: number;
    startFromHead?: boolean;
    interleaved?: boolean;
    unmask?: boolean;
}
export declare const FilterLogEventsRequest: S.Schema<FilterLogEventsRequest>;
export type EventMessage = string;
export type EventId = string;
export interface FilteredLogEvent {
    logStreamName?: string;
    timestamp?: number;
    message?: string;
    ingestionTime?: number;
    eventId?: string;
}
export declare const FilteredLogEvent: S.Schema<FilteredLogEvent>;
export type FilteredLogEvents = FilteredLogEvent[];
export declare const FilteredLogEvents: any;
export type LogStreamSearchedCompletely = boolean;
export interface SearchedLogStream {
    logStreamName?: string;
    searchedCompletely?: boolean;
}
export declare const SearchedLogStream: S.Schema<SearchedLogStream>;
export type SearchedLogStreams = SearchedLogStream[];
export declare const SearchedLogStreams: any;
export interface FilterLogEventsResponse {
    events?: FilteredLogEvent[];
    searchedLogStreams?: SearchedLogStream[];
    nextToken?: string;
}
export declare const FilterLogEventsResponse: S.Schema<FilterLogEventsResponse>;
export interface GetDataProtectionPolicyRequest {
    logGroupIdentifier: string;
}
export declare const GetDataProtectionPolicyRequest: S.Schema<GetDataProtectionPolicyRequest>;
export type DataProtectionPolicyDocument = string;
export interface GetDataProtectionPolicyResponse {
    logGroupIdentifier?: string;
    policyDocument?: string;
    lastUpdatedTime?: number;
}
export declare const GetDataProtectionPolicyResponse: S.Schema<GetDataProtectionPolicyResponse>;
export interface GetDeliveryRequest {
    id: string;
}
export declare const GetDeliveryRequest: S.Schema<GetDeliveryRequest>;
export interface GetDeliveryResponse {
    delivery?: Delivery;
}
export declare const GetDeliveryResponse: S.Schema<GetDeliveryResponse>;
export interface GetDeliveryDestinationRequest {
    name: string;
}
export declare const GetDeliveryDestinationRequest: S.Schema<GetDeliveryDestinationRequest>;
export interface GetDeliveryDestinationResponse {
    deliveryDestination?: DeliveryDestination;
}
export declare const GetDeliveryDestinationResponse: S.Schema<GetDeliveryDestinationResponse>;
export interface GetDeliveryDestinationPolicyRequest {
    deliveryDestinationName: string;
}
export declare const GetDeliveryDestinationPolicyRequest: S.Schema<GetDeliveryDestinationPolicyRequest>;
export type DeliveryDestinationPolicy = string;
export interface Policy {
    deliveryDestinationPolicy?: string;
}
export declare const Policy: S.Schema<Policy>;
export interface GetDeliveryDestinationPolicyResponse {
    policy?: Policy;
}
export declare const GetDeliveryDestinationPolicyResponse: S.Schema<GetDeliveryDestinationPolicyResponse>;
export interface GetDeliverySourceRequest {
    name: string;
}
export declare const GetDeliverySourceRequest: S.Schema<GetDeliverySourceRequest>;
export interface GetDeliverySourceResponse {
    deliverySource?: DeliverySource;
}
export declare const GetDeliverySourceResponse: S.Schema<GetDeliverySourceResponse>;
export interface GetIntegrationRequest {
    integrationName: string;
}
export declare const GetIntegrationRequest: S.Schema<GetIntegrationRequest>;
export type IntegrationType = "OPENSEARCH" | (string & {});
export declare const IntegrationType: any;
export type IntegrationStatus = "PROVISIONING" | "ACTIVE" | "FAILED" | (string & {});
export declare const IntegrationStatus: any;
export type OpenSearchDataSourceName = string;
export type OpenSearchResourceStatusType = "ACTIVE" | "NOT_FOUND" | "ERROR" | (string & {});
export declare const OpenSearchResourceStatusType: any;
export type IntegrationStatusMessage = string;
export interface OpenSearchResourceStatus {
    status?: OpenSearchResourceStatusType;
    statusMessage?: string;
}
export declare const OpenSearchResourceStatus: S.Schema<OpenSearchResourceStatus>;
export interface OpenSearchDataSource {
    dataSourceName?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchDataSource: S.Schema<OpenSearchDataSource>;
export type OpenSearchApplicationEndpoint = string;
export type OpenSearchApplicationId = string;
export interface OpenSearchApplication {
    applicationEndpoint?: string;
    applicationArn?: string;
    applicationId?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchApplication: S.Schema<OpenSearchApplication>;
export type OpenSearchCollectionEndpoint = string;
export interface OpenSearchCollection {
    collectionEndpoint?: string;
    collectionArn?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchCollection: S.Schema<OpenSearchCollection>;
export type OpenSearchWorkspaceId = string;
export interface OpenSearchWorkspace {
    workspaceId?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchWorkspace: S.Schema<OpenSearchWorkspace>;
export type OpenSearchPolicyName = string;
export interface OpenSearchEncryptionPolicy {
    policyName?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchEncryptionPolicy: S.Schema<OpenSearchEncryptionPolicy>;
export interface OpenSearchNetworkPolicy {
    policyName?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchNetworkPolicy: S.Schema<OpenSearchNetworkPolicy>;
export interface OpenSearchDataAccessPolicy {
    policyName?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchDataAccessPolicy: S.Schema<OpenSearchDataAccessPolicy>;
export interface OpenSearchLifecyclePolicy {
    policyName?: string;
    status?: OpenSearchResourceStatus;
}
export declare const OpenSearchLifecyclePolicy: S.Schema<OpenSearchLifecyclePolicy>;
export interface OpenSearchIntegrationDetails {
    dataSource?: OpenSearchDataSource;
    application?: OpenSearchApplication;
    collection?: OpenSearchCollection;
    workspace?: OpenSearchWorkspace;
    encryptionPolicy?: OpenSearchEncryptionPolicy;
    networkPolicy?: OpenSearchNetworkPolicy;
    accessPolicy?: OpenSearchDataAccessPolicy;
    lifecyclePolicy?: OpenSearchLifecyclePolicy;
}
export declare const OpenSearchIntegrationDetails: S.Schema<OpenSearchIntegrationDetails>;
export type IntegrationDetails = {
    openSearchIntegrationDetails: OpenSearchIntegrationDetails;
};
export declare const IntegrationDetails: any;
export interface GetIntegrationResponse {
    integrationName?: string;
    integrationType?: IntegrationType;
    integrationStatus?: IntegrationStatus;
    integrationDetails?: IntegrationDetails;
}
export declare const GetIntegrationResponse: S.Schema<GetIntegrationResponse>;
export interface GetLogAnomalyDetectorRequest {
    anomalyDetectorArn: string;
}
export declare const GetLogAnomalyDetectorRequest: S.Schema<GetLogAnomalyDetectorRequest>;
export type AnomalyDetectorStatus = "INITIALIZING" | "TRAINING" | "ANALYZING" | "FAILED" | "DELETED" | "PAUSED" | (string & {});
export declare const AnomalyDetectorStatus: any;
export type EpochMillis = number;
export interface GetLogAnomalyDetectorResponse {
    detectorName?: string;
    logGroupArnList?: string[];
    evaluationFrequency?: EvaluationFrequency;
    filterPattern?: string;
    anomalyDetectorStatus?: AnomalyDetectorStatus;
    kmsKeyId?: string;
    creationTimeStamp?: number;
    lastModifiedTimeStamp?: number;
    anomalyVisibilityTime?: number;
}
export declare const GetLogAnomalyDetectorResponse: S.Schema<GetLogAnomalyDetectorResponse>;
export interface GetLogEventsRequest {
    logGroupName?: string;
    logGroupIdentifier?: string;
    logStreamName: string;
    startTime?: number;
    endTime?: number;
    nextToken?: string;
    limit?: number;
    startFromHead?: boolean;
    unmask?: boolean;
}
export declare const GetLogEventsRequest: S.Schema<GetLogEventsRequest>;
export interface OutputLogEvent {
    timestamp?: number;
    message?: string;
    ingestionTime?: number;
}
export declare const OutputLogEvent: S.Schema<OutputLogEvent>;
export type OutputLogEvents = OutputLogEvent[];
export declare const OutputLogEvents: any;
export interface GetLogEventsResponse {
    events?: OutputLogEvent[];
    nextForwardToken?: string;
    nextBackwardToken?: string;
}
export declare const GetLogEventsResponse: S.Schema<GetLogEventsResponse>;
export interface GetLogFieldsRequest {
    dataSourceName: string;
    dataSourceType: string;
}
export declare const GetLogFieldsRequest: S.Schema<GetLogFieldsRequest>;
export type LogFieldName = string;
export type DataType = string;
export interface LogFieldType {
    type?: string;
    element?: LogFieldType;
    fields?: LogFieldsListItem[];
}
export declare const LogFieldType: S.Schema<LogFieldType>;
export interface LogFieldsListItem {
    logFieldName?: string;
    logFieldType?: LogFieldType;
}
export declare const LogFieldsListItem: S.Schema<LogFieldsListItem>;
export type LogFieldsList = LogFieldsListItem[];
export declare const LogFieldsList: S.Schema<LogFieldsList>;
export interface GetLogFieldsResponse {
    logFields?: LogFieldsListItem[];
}
export declare const GetLogFieldsResponse: S.Schema<GetLogFieldsResponse>;
export interface GetLogGroupFieldsRequest {
    logGroupName?: string;
    time?: number;
    logGroupIdentifier?: string;
}
export declare const GetLogGroupFieldsRequest: S.Schema<GetLogGroupFieldsRequest>;
export type Field = string;
export type Percentage = number;
export interface LogGroupField {
    name?: string;
    percent?: number;
}
export declare const LogGroupField: S.Schema<LogGroupField>;
export type LogGroupFieldList = LogGroupField[];
export declare const LogGroupFieldList: any;
export interface GetLogGroupFieldsResponse {
    logGroupFields?: LogGroupField[];
}
export declare const GetLogGroupFieldsResponse: S.Schema<GetLogGroupFieldsResponse>;
export type LogObjectPointer = string;
export interface GetLogObjectRequest {
    unmask?: boolean;
    logObjectPointer: string;
}
export declare const GetLogObjectRequest: S.Schema<GetLogObjectRequest>;
export type Data = Uint8Array;
export interface FieldsData {
    data?: Uint8Array;
}
export declare const FieldsData: S.Schema<FieldsData>;
export type Message = string;
export interface InternalStreamingException {
    message?: string;
}
export declare const InternalStreamingException: S.Schema<InternalStreamingException>;
export type GetLogObjectResponseStream = {
    fields: FieldsData;
    InternalStreamingException?: never;
} | {
    fields?: never;
    InternalStreamingException: InternalStreamingException;
};
export declare const GetLogObjectResponseStream: S.Schema<stream.Stream<GetLogObjectResponseStream, Error, never>>;
export interface GetLogObjectResponse {
    fieldStream?: stream.Stream<GetLogObjectResponseStream, Error, never>;
}
export declare const GetLogObjectResponse: S.Schema<GetLogObjectResponse>;
export type LogRecordPointer = string;
export interface GetLogRecordRequest {
    logRecordPointer: string;
    unmask?: boolean;
}
export declare const GetLogRecordRequest: S.Schema<GetLogRecordRequest>;
export type Value = string;
export type LogRecord = {
    [key: string]: string | undefined;
};
export declare const LogRecord: any;
export interface GetLogRecordResponse {
    logRecord?: {
        [key: string]: string | undefined;
    };
}
export declare const GetLogRecordResponse: S.Schema<GetLogRecordResponse>;
export interface GetLookupTableRequest {
    lookupTableArn: string;
}
export declare const GetLookupTableRequest: S.Schema<GetLookupTableRequest>;
export interface GetLookupTableResponse {
    lookupTableArn?: string;
    lookupTableName?: string;
    description?: string;
    tableBody?: string;
    sizeBytes?: number;
    lastUpdatedTime?: number;
    kmsKeyId?: string;
}
export declare const GetLookupTableResponse: S.Schema<GetLookupTableResponse>;
export type GetQueryResultsNextToken = string;
export type GetQueryResultsMaxItems = number;
export interface GetQueryResultsRequest {
    queryId: string;
    nextToken?: string;
    maxItems?: number;
}
export declare const GetQueryResultsRequest: S.Schema<GetQueryResultsRequest>;
export interface ResultField {
    field?: string;
    value?: string;
}
export declare const ResultField: S.Schema<ResultField>;
export type ResultRows = ResultField[];
export declare const ResultRows: any;
export type QueryResults = ResultField[][];
export declare const QueryResults: any;
export type StatsValue = number;
export interface QueryStatistics {
    recordsMatched?: number;
    recordsScanned?: number;
    estimatedRecordsSkipped?: number;
    bytesScanned?: number;
    estimatedBytesSkipped?: number;
    logGroupsScanned?: number;
    resultCount?: number;
}
export declare const QueryStatistics: S.Schema<QueryStatistics>;
export type EncryptionKey = string;
export interface GetQueryResultsResponse {
    queryLanguage?: QueryLanguage;
    results?: ResultField[][];
    statistics?: QueryStatistics;
    status?: QueryStatus;
    encryptionKey?: string;
    nextToken?: string;
}
export declare const GetQueryResultsResponse: S.Schema<GetQueryResultsResponse>;
export interface GetScheduledQueryRequest {
    identifier: string;
}
export declare const GetScheduledQueryRequest: S.Schema<GetScheduledQueryRequest>;
export type ScheduleType = "CUSTOMER_MANAGED" | "AWS_MANAGED" | (string & {});
export declare const ScheduleType: any;
export type ExecutionStatus = "Running" | "InvalidQuery" | "Complete" | "Failed" | "Timeout" | (string & {});
export declare const ExecutionStatus: any;
export interface GetScheduledQueryResponse {
    scheduledQueryArn?: string;
    name?: string;
    description?: string;
    queryLanguage?: QueryLanguage;
    queryString?: string;
    logGroupIdentifiers?: string[];
    scheduleExpression?: string;
    timezone?: string;
    startTimeOffset?: number;
    endTimeOffset?: number;
    destinationConfiguration?: DestinationConfiguration;
    state?: ScheduledQueryState;
    scheduleType?: ScheduleType;
    lastTriggeredTime?: number;
    lastExecutionStatus?: ExecutionStatus;
    scheduleStartTime?: number;
    scheduleEndTime?: number;
    executionRoleArn?: string;
    creationTime?: number;
    lastUpdatedTime?: number;
}
export declare const GetScheduledQueryResponse: S.Schema<GetScheduledQueryResponse>;
export type ExecutionStatusList = ExecutionStatus[];
export declare const ExecutionStatusList: any;
export type GetScheduledQueryHistoryMaxResults = number;
export interface GetScheduledQueryHistoryRequest {
    identifier: string;
    startTime: number;
    endTime: number;
    executionStatuses?: ExecutionStatus[];
    maxResults?: number;
    nextToken?: string;
}
export declare const GetScheduledQueryHistoryRequest: S.Schema<GetScheduledQueryHistoryRequest>;
export type ScheduledQueryDestinationType = "S3" | "LOOKUP_TABLE" | (string & {});
export declare const ScheduledQueryDestinationType: any;
export type ActionStatus = "IN_PROGRESS" | "CLIENT_ERROR" | "FAILED" | "COMPLETE" | (string & {});
export declare const ActionStatus: any;
export interface ScheduledQueryDestination {
    destinationType?: ScheduledQueryDestinationType;
    destinationIdentifier?: string;
    status?: ActionStatus;
    processedIdentifier?: string;
    errorMessage?: string;
}
export declare const ScheduledQueryDestination: S.Schema<ScheduledQueryDestination>;
export type ScheduledQueryDestinationList = ScheduledQueryDestination[];
export declare const ScheduledQueryDestinationList: any;
export interface TriggerHistoryRecord {
    queryId?: string;
    executionStatus?: ExecutionStatus;
    triggeredTimestamp?: number;
    errorMessage?: string;
    destinations?: ScheduledQueryDestination[];
}
export declare const TriggerHistoryRecord: S.Schema<TriggerHistoryRecord>;
export type TriggerHistoryRecordList = TriggerHistoryRecord[];
export declare const TriggerHistoryRecordList: any;
export interface GetScheduledQueryHistoryResponse {
    name?: string;
    scheduledQueryArn?: string;
    triggerHistory?: TriggerHistoryRecord[];
    nextToken?: string;
}
export declare const GetScheduledQueryHistoryResponse: S.Schema<GetScheduledQueryHistoryResponse>;
export interface GetStorageTierPolicyRequest {
}
export declare const GetStorageTierPolicyRequest: S.Schema<GetStorageTierPolicyRequest>;
export type StorageTier = "STANDARD" | "INTELLIGENT_TIERING" | (string & {});
export declare const StorageTier: any;
export interface GetStorageTierPolicyResponse {
    storageTier?: StorageTier;
    lastUpdatedTime?: number;
}
export declare const GetStorageTierPolicyResponse: S.Schema<GetStorageTierPolicyResponse>;
export interface GetTransformerRequest {
    logGroupIdentifier: string;
}
export declare const GetTransformerRequest: S.Schema<GetTransformerRequest>;
export type Key = string;
export type AddKeyValue = string;
export type OverwriteIfExists = boolean;
export interface AddKeyEntry {
    key: string;
    value: string;
    overwriteIfExists?: boolean;
}
export declare const AddKeyEntry: S.Schema<AddKeyEntry>;
export type AddKeyEntries = AddKeyEntry[];
export declare const AddKeyEntries: any;
export interface AddKeys {
    entries: AddKeyEntry[];
}
export declare const AddKeys: S.Schema<AddKeys>;
export type Source = string;
export type Target = string;
export interface CopyValueEntry {
    source: string;
    target: string;
    overwriteIfExists?: boolean;
}
export declare const CopyValueEntry: S.Schema<CopyValueEntry>;
export type CopyValueEntries = CopyValueEntry[];
export declare const CopyValueEntries: any;
export interface CopyValue {
    entries: CopyValueEntry[];
}
export declare const CopyValue: S.Schema<CopyValue>;
export type QuoteCharacter = string;
export type Delimiter = string;
export type Column = string;
export type Columns = string[];
export declare const Columns: any;
export type DestinationField = string;
export interface CSV {
    quoteCharacter?: string;
    delimiter?: string;
    columns?: string[];
    source?: string;
    destination?: string;
}
export declare const CSV: S.Schema<CSV>;
export type TargetFormat = string;
export type MatchPattern = string;
export type MatchPatterns = string[];
export declare const MatchPatterns: any;
export type SourceTimezone = string;
export type TargetTimezone = string;
export type Locale = string;
export interface DateTimeConverter {
    source: string;
    target: string;
    targetFormat?: string;
    matchPatterns: string[];
    sourceTimezone?: string;
    targetTimezone?: string;
    locale?: string;
}
export declare const DateTimeConverter: S.Schema<DateTimeConverter>;
export type WithKey = string;
export type DeleteWithKeys = string[];
export declare const DeleteWithKeys: any;
export interface DeleteKeys {
    withKeys: string[];
}
export declare const DeleteKeys: S.Schema<DeleteKeys>;
export type GrokMatch = string;
export interface Grok {
    source?: string;
    match: string;
}
export declare const Grok: S.Schema<Grok>;
export type ValueKey = string;
export type Flatten = boolean;
export type FlattenedElement = "first" | "last" | (string & {});
export declare const FlattenedElement: any;
export interface ListToMap {
    source: string;
    key: string;
    valueKey?: string;
    target?: string;
    flatten?: boolean;
    flattenedElement?: FlattenedElement;
}
export declare const ListToMap: S.Schema<ListToMap>;
export type LowerCaseStringWithKeys = string[];
export declare const LowerCaseStringWithKeys: any;
export interface LowerCaseString {
    withKeys: string[];
}
export declare const LowerCaseString: S.Schema<LowerCaseString>;
export interface MoveKeyEntry {
    source: string;
    target: string;
    overwriteIfExists?: boolean;
}
export declare const MoveKeyEntry: S.Schema<MoveKeyEntry>;
export type MoveKeyEntries = MoveKeyEntry[];
export declare const MoveKeyEntries: any;
export interface MoveKeys {
    entries: MoveKeyEntry[];
}
export declare const MoveKeys: S.Schema<MoveKeys>;
export interface ParseCloudfront {
    source?: string;
}
export declare const ParseCloudfront: S.Schema<ParseCloudfront>;
export interface ParseJSON {
    source?: string;
    destination?: string;
}
export declare const ParseJSON: S.Schema<ParseJSON>;
export type ParserFieldDelimiter = string;
export type KeyValueDelimiter = string;
export type KeyPrefix = string;
export type NonMatchValue = string;
export interface ParseKeyValue {
    source?: string;
    destination?: string;
    fieldDelimiter?: string;
    keyValueDelimiter?: string;
    keyPrefix?: string;
    nonMatchValue?: string;
    overwriteIfExists?: boolean;
}
export declare const ParseKeyValue: S.Schema<ParseKeyValue>;
export interface ParseRoute53 {
    source?: string;
}
export declare const ParseRoute53: S.Schema<ParseRoute53>;
export type EventSource = "CloudTrail" | "Route53Resolver" | "VPCFlow" | "EKSAudit" | "AWSWAF" | (string & {});
export declare const EventSource: any;
export type OCSFVersion = "V1.1" | "V1.5" | (string & {});
export declare const OCSFVersion: any;
export type MappingVersion = string;
export interface ParseToOCSF {
    source?: string;
    eventSource: EventSource;
    ocsfVersion: OCSFVersion;
    mappingVersion?: string;
}
export declare const ParseToOCSF: S.Schema<ParseToOCSF>;
export interface ParsePostgres {
    source?: string;
}
export declare const ParsePostgres: S.Schema<ParsePostgres>;
export interface ParseVPC {
    source?: string;
}
export declare const ParseVPC: S.Schema<ParseVPC>;
export interface ParseWAF {
    source?: string;
}
export declare const ParseWAF: S.Schema<ParseWAF>;
export type RenameTo = string;
export interface RenameKeyEntry {
    key: string;
    renameTo: string;
    overwriteIfExists?: boolean;
}
export declare const RenameKeyEntry: S.Schema<RenameKeyEntry>;
export type RenameKeyEntries = RenameKeyEntry[];
export declare const RenameKeyEntries: any;
export interface RenameKeys {
    entries: RenameKeyEntry[];
}
export declare const RenameKeys: S.Schema<RenameKeys>;
export type SplitStringDelimiter = string;
export interface SplitStringEntry {
    source: string;
    delimiter: string;
}
export declare const SplitStringEntry: S.Schema<SplitStringEntry>;
export type SplitStringEntries = SplitStringEntry[];
export declare const SplitStringEntries: any;
export interface SplitString {
    entries: SplitStringEntry[];
}
export declare const SplitString: S.Schema<SplitString>;
export type FromKey = string;
export type ToKey = string;
export interface SubstituteStringEntry {
    source: string;
    from: string;
    to: string;
}
export declare const SubstituteStringEntry: S.Schema<SubstituteStringEntry>;
export type SubstituteStringEntries = SubstituteStringEntry[];
export declare const SubstituteStringEntries: any;
export interface SubstituteString {
    entries: SubstituteStringEntry[];
}
export declare const SubstituteString: S.Schema<SubstituteString>;
export type TrimStringWithKeys = string[];
export declare const TrimStringWithKeys: any;
export interface TrimString {
    withKeys: string[];
}
export declare const TrimString: S.Schema<TrimString>;
export type Type = "boolean" | "integer" | "double" | "string" | (string & {});
export declare const Type: any;
export interface TypeConverterEntry {
    key: string;
    type: Type;
}
export declare const TypeConverterEntry: S.Schema<TypeConverterEntry>;
export type TypeConverterEntries = TypeConverterEntry[];
export declare const TypeConverterEntries: any;
export interface TypeConverter {
    entries: TypeConverterEntry[];
}
export declare const TypeConverter: S.Schema<TypeConverter>;
export type UpperCaseStringWithKeys = string[];
export declare const UpperCaseStringWithKeys: any;
export interface UpperCaseString {
    withKeys: string[];
}
export declare const UpperCaseString: S.Schema<UpperCaseString>;
export interface Processor {
    addKeys?: AddKeys;
    copyValue?: CopyValue;
    csv?: CSV;
    dateTimeConverter?: DateTimeConverter;
    deleteKeys?: DeleteKeys;
    grok?: Grok;
    listToMap?: ListToMap;
    lowerCaseString?: LowerCaseString;
    moveKeys?: MoveKeys;
    parseCloudfront?: ParseCloudfront;
    parseJSON?: ParseJSON;
    parseKeyValue?: ParseKeyValue;
    parseRoute53?: ParseRoute53;
    parseToOCSF?: ParseToOCSF;
    parsePostgres?: ParsePostgres;
    parseVPC?: ParseVPC;
    parseWAF?: ParseWAF;
    renameKeys?: RenameKeys;
    splitString?: SplitString;
    substituteString?: SubstituteString;
    trimString?: TrimString;
    typeConverter?: TypeConverter;
    upperCaseString?: UpperCaseString;
}
export declare const Processor: S.Schema<Processor>;
export type Processors = Processor[];
export declare const Processors: any;
export interface GetTransformerResponse {
    logGroupIdentifier?: string;
    creationTime?: number;
    lastModifiedTime?: number;
    transformerConfig?: Processor[];
}
export declare const GetTransformerResponse: S.Schema<GetTransformerResponse>;
export type LogGroupNameRegexPattern = string;
export interface DataSourceFilter {
    name: string;
    type?: string;
}
export declare const DataSourceFilter: S.Schema<DataSourceFilter>;
export type DataSourceFilters = DataSourceFilter[];
export declare const DataSourceFilters: any;
export type ListAggregateLogGroupSummariesGroupBy = "DATA_SOURCE_NAME_TYPE_AND_FORMAT" | "DATA_SOURCE_NAME_AND_TYPE" | (string & {});
export declare const ListAggregateLogGroupSummariesGroupBy: any;
export type ListLogGroupsRequestLimit = number;
export interface ListAggregateLogGroupSummariesRequest {
    accountIdentifiers?: string[];
    includeLinkedAccounts?: boolean;
    logGroupClass?: LogGroupClass;
    logGroupNamePattern?: string;
    dataSources?: DataSourceFilter[];
    groupBy: ListAggregateLogGroupSummariesGroupBy;
    nextToken?: string;
    limit?: number;
}
export declare const ListAggregateLogGroupSummariesRequest: S.Schema<ListAggregateLogGroupSummariesRequest>;
export type LogGroupCount = number;
export type GroupingIdentifierKey = string;
export type GroupingIdentifierValue = string;
export interface GroupingIdentifier {
    key?: string;
    value?: string;
}
export declare const GroupingIdentifier: S.Schema<GroupingIdentifier>;
export type GroupingIdentifiers = GroupingIdentifier[];
export declare const GroupingIdentifiers: any;
export interface AggregateLogGroupSummary {
    logGroupCount?: number;
    groupingIdentifiers?: GroupingIdentifier[];
}
export declare const AggregateLogGroupSummary: S.Schema<AggregateLogGroupSummary>;
export type AggregateLogGroupSummaries = AggregateLogGroupSummary[];
export declare const AggregateLogGroupSummaries: any;
export interface ListAggregateLogGroupSummariesResponse {
    aggregateLogGroupSummaries?: AggregateLogGroupSummary[];
    nextToken?: string;
}
export declare const ListAggregateLogGroupSummariesResponse: S.Schema<ListAggregateLogGroupSummariesResponse>;
export type SuppressionState = "SUPPRESSED" | "UNSUPPRESSED" | (string & {});
export declare const SuppressionState: any;
export type ListAnomaliesLimit = number;
export interface ListAnomaliesRequest {
    anomalyDetectorArn?: string;
    suppressionState?: SuppressionState;
    limit?: number;
    nextToken?: string;
}
export declare const ListAnomaliesRequest: S.Schema<ListAnomaliesRequest>;
export type AnomalyId = string;
export type PatternId = string;
export type PatternString = string;
export type PatternRegex = string;
export type Priority = string;
export type Description = string;
export type State = "Active" | "Suppressed" | "Baseline" | (string & {});
export declare const State: any;
export type Count = number;
export type Histogram = {
    [key: string]: number | undefined;
};
export declare const Histogram: any;
export interface LogEvent {
    timestamp?: number;
    message?: string;
}
export declare const LogEvent: S.Schema<LogEvent>;
export type LogSamples = LogEvent[];
export declare const LogSamples: any;
export type DynamicTokenPosition = number;
export type TokenString = string;
export type TokenValue = number;
export type Enumerations = {
    [key: string]: number | undefined;
};
export declare const Enumerations: any;
export type InferredTokenName = string;
export interface PatternToken {
    dynamicTokenPosition?: number;
    isDynamic?: boolean;
    tokenString?: string;
    enumerations?: {
        [key: string]: number | undefined;
    };
    inferredTokenName?: string;
}
export declare const PatternToken: S.Schema<PatternToken>;
export type PatternTokens = PatternToken[];
export declare const PatternTokens: any;
export interface Anomaly {
    anomalyId: string;
    patternId: string;
    anomalyDetectorArn: string;
    patternString: string;
    patternRegex?: string;
    priority?: string;
    firstSeen: number;
    lastSeen: number;
    description: string;
    active: boolean;
    state: State;
    histogram: {
        [key: string]: number | undefined;
    };
    logSamples: LogEvent[];
    patternTokens: PatternToken[];
    logGroupArnList: string[];
    suppressed?: boolean;
    suppressedDate?: number;
    suppressedUntil?: number;
    isPatternLevelSuppression?: boolean;
}
export declare const Anomaly: S.Schema<Anomaly>;
export type Anomalies = Anomaly[];
export declare const Anomalies: any;
export interface ListAnomaliesResponse {
    anomalies?: Anomaly[];
    nextToken?: string;
}
export declare const ListAnomaliesResponse: S.Schema<ListAnomaliesResponse>;
export type IntegrationNamePrefix = string;
export interface ListIntegrationsRequest {
    integrationNamePrefix?: string;
    integrationType?: IntegrationType;
    integrationStatus?: IntegrationStatus;
}
export declare const ListIntegrationsRequest: S.Schema<ListIntegrationsRequest>;
export interface IntegrationSummary {
    integrationName?: string;
    integrationType?: IntegrationType;
    integrationStatus?: IntegrationStatus;
}
export declare const IntegrationSummary: S.Schema<IntegrationSummary>;
export type IntegrationSummaries = IntegrationSummary[];
export declare const IntegrationSummaries: any;
export interface ListIntegrationsResponse {
    integrationSummaries?: IntegrationSummary[];
}
export declare const ListIntegrationsResponse: S.Schema<ListIntegrationsResponse>;
export type ListLogAnomalyDetectorsLimit = number;
export interface ListLogAnomalyDetectorsRequest {
    filterLogGroupArn?: string;
    limit?: number;
    nextToken?: string;
}
export declare const ListLogAnomalyDetectorsRequest: S.Schema<ListLogAnomalyDetectorsRequest>;
export interface AnomalyDetector {
    anomalyDetectorArn?: string;
    detectorName?: string;
    logGroupArnList?: string[];
    evaluationFrequency?: EvaluationFrequency;
    filterPattern?: string;
    anomalyDetectorStatus?: AnomalyDetectorStatus;
    kmsKeyId?: string;
    creationTimeStamp?: number;
    lastModifiedTimeStamp?: number;
    anomalyVisibilityTime?: number;
}
export declare const AnomalyDetector: S.Schema<AnomalyDetector>;
export type AnomalyDetectors = AnomalyDetector[];
export declare const AnomalyDetectors: any;
export interface ListLogAnomalyDetectorsResponse {
    anomalyDetectors?: AnomalyDetector[];
    nextToken?: string;
}
export declare const ListLogAnomalyDetectorsResponse: S.Schema<ListLogAnomalyDetectorsResponse>;
export type ListLimit = number;
export type FieldIndexNames = string[];
export declare const FieldIndexNames: any;
export type TagFilterKey = string;
export type TagFilterValue = string;
export type TagFilterValues = string[];
export declare const TagFilterValues: any;
export interface TagFilter {
    key: string;
    values?: string[];
}
export declare const TagFilter: S.Schema<TagFilter>;
export type TagFilters = TagFilter[];
export declare const TagFilters: any;
export interface ListLogGroupsRequest {
    logGroupNamePattern?: string;
    logGroupClass?: LogGroupClass;
    includeLinkedAccounts?: boolean;
    accountIdentifiers?: string[];
    nextToken?: string;
    limit?: number;
    dataSources?: DataSourceFilter[];
    fieldIndexNames?: string[];
    logGroupTags?: TagFilter[];
}
export declare const ListLogGroupsRequest: S.Schema<ListLogGroupsRequest>;
export interface LogGroupSummary {
    logGroupName?: string;
    logGroupArn?: string;
    logGroupClass?: LogGroupClass;
}
export declare const LogGroupSummary: S.Schema<LogGroupSummary>;
export type LogGroupSummaries = LogGroupSummary[];
export declare const LogGroupSummaries: any;
export interface ListLogGroupsResponse {
    logGroups?: LogGroupSummary[];
    nextToken?: string;
}
export declare const ListLogGroupsResponse: S.Schema<ListLogGroupsResponse>;
export type ListLogGroupsForQueryMaxResults = number;
export interface ListLogGroupsForQueryRequest {
    queryId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListLogGroupsForQueryRequest: S.Schema<ListLogGroupsForQueryRequest>;
export type LogGroupIdentifiers = string[];
export declare const LogGroupIdentifiers: any;
export interface ListLogGroupsForQueryResponse {
    logGroupIdentifiers?: string[];
    nextToken?: string;
}
export declare const ListLogGroupsForQueryResponse: S.Schema<ListLogGroupsForQueryResponse>;
export type ListScheduledQueriesMaxResults = number;
export interface ListScheduledQueriesRequest {
    maxResults?: number;
    nextToken?: string;
    state?: ScheduledQueryState;
    scheduleType?: ScheduleType;
}
export declare const ListScheduledQueriesRequest: S.Schema<ListScheduledQueriesRequest>;
export interface ScheduledQuerySummary {
    scheduledQueryArn?: string;
    name?: string;
    state?: ScheduledQueryState;
    scheduleType?: ScheduleType;
    lastTriggeredTime?: number;
    lastExecutionStatus?: ExecutionStatus;
    scheduleExpression?: string;
    timezone?: string;
    destinationConfiguration?: DestinationConfiguration;
    creationTime?: number;
    lastUpdatedTime?: number;
}
export declare const ScheduledQuerySummary: S.Schema<ScheduledQuerySummary>;
export type ScheduledQuerySummaryList = ScheduledQuerySummary[];
export declare const ScheduledQuerySummaryList: any;
export interface ListScheduledQueriesResponse {
    nextToken?: string;
    scheduledQueries?: ScheduledQuerySummary[];
}
export declare const ListScheduledQueriesResponse: S.Schema<ListScheduledQueriesResponse>;
export type ListSourcesForS3TableIntegrationMaxResults = number;
export interface ListSourcesForS3TableIntegrationRequest {
    integrationArn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSourcesForS3TableIntegrationRequest: S.Schema<ListSourcesForS3TableIntegrationRequest>;
export type S3TableIntegrationSourceStatus = "ACTIVE" | "UNHEALTHY" | "FAILED" | "DATA_SOURCE_DELETE_IN_PROGRESS" | (string & {});
export declare const S3TableIntegrationSourceStatus: any;
export type S3TableIntegrationSourceStatusReason = string;
export interface S3TableIntegrationSource {
    identifier?: string;
    dataSource?: DataSource;
    status?: S3TableIntegrationSourceStatus;
    statusReason?: string;
    createdTimeStamp?: number;
    parentSourceIdentifier?: string;
}
export declare const S3TableIntegrationSource: S.Schema<S3TableIntegrationSource>;
export type S3TableIntegrationSources = S3TableIntegrationSource[];
export declare const S3TableIntegrationSources: any;
export interface ListSourcesForS3TableIntegrationResponse {
    sources?: S3TableIntegrationSource[];
    nextToken?: string;
}
export declare const ListSourcesForS3TableIntegrationResponse: S.Schema<ListSourcesForS3TableIntegrationResponse>;
export type ListSyslogConfigurationsMaxResults = number;
export interface ListSyslogConfigurationsRequest {
    logGroupIdentifier?: string;
    vpcEndpointId?: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSyslogConfigurationsRequest: S.Schema<ListSyslogConfigurationsRequest>;
export type SyslogSourceType = "VPCE" | (string & {});
export declare const SyslogSourceType: any;
export interface SyslogConfiguration {
    logGroupArn?: string;
    sourceType?: SyslogSourceType;
    vpcEndpointId?: string;
    createdAt?: number;
}
export declare const SyslogConfiguration: S.Schema<SyslogConfiguration>;
export type SyslogConfigurations = SyslogConfiguration[];
export declare const SyslogConfigurations: any;
export interface ListSyslogConfigurationsResponse {
    syslogConfigurations?: SyslogConfiguration[];
    nextToken?: string;
}
export declare const ListSyslogConfigurationsResponse: S.Schema<ListSyslogConfigurationsResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTagsLogGroupRequest {
    logGroupName: string;
}
export declare const ListTagsLogGroupRequest: S.Schema<ListTagsLogGroupRequest>;
export interface ListTagsLogGroupResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsLogGroupResponse: S.Schema<ListTagsLogGroupResponse>;
export interface PutAccountPolicyRequest {
    policyName: string;
    policyDocument: string;
    policyType: PolicyType;
    scope?: Scope;
    selectionCriteria?: string;
}
export declare const PutAccountPolicyRequest: S.Schema<PutAccountPolicyRequest>;
export interface PutAccountPolicyResponse {
    accountPolicy?: AccountPolicy;
}
export declare const PutAccountPolicyResponse: S.Schema<PutAccountPolicyResponse>;
export interface PutBearerTokenAuthenticationRequest {
    logGroupIdentifier: string;
    bearerTokenAuthenticationEnabled: boolean;
}
export declare const PutBearerTokenAuthenticationRequest: S.Schema<PutBearerTokenAuthenticationRequest>;
export interface PutBearerTokenAuthenticationResponse {
}
export declare const PutBearerTokenAuthenticationResponse: S.Schema<PutBearerTokenAuthenticationResponse>;
export interface PutDataProtectionPolicyRequest {
    logGroupIdentifier: string;
    policyDocument: string;
}
export declare const PutDataProtectionPolicyRequest: S.Schema<PutDataProtectionPolicyRequest>;
export interface PutDataProtectionPolicyResponse {
    logGroupIdentifier?: string;
    policyDocument?: string;
    lastUpdatedTime?: number;
}
export declare const PutDataProtectionPolicyResponse: S.Schema<PutDataProtectionPolicyResponse>;
export interface PutDeliveryDestinationRequest {
    name: string;
    outputFormat?: OutputFormat;
    deliveryDestinationConfiguration?: DeliveryDestinationConfiguration;
    deliveryDestinationType?: DeliveryDestinationType;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PutDeliveryDestinationRequest: S.Schema<PutDeliveryDestinationRequest>;
export interface PutDeliveryDestinationResponse {
    deliveryDestination?: DeliveryDestination;
}
export declare const PutDeliveryDestinationResponse: S.Schema<PutDeliveryDestinationResponse>;
export interface PutDeliveryDestinationPolicyRequest {
    deliveryDestinationName: string;
    deliveryDestinationPolicy: string;
}
export declare const PutDeliveryDestinationPolicyRequest: S.Schema<PutDeliveryDestinationPolicyRequest>;
export interface PutDeliveryDestinationPolicyResponse {
    policy?: Policy;
}
export declare const PutDeliveryDestinationPolicyResponse: S.Schema<PutDeliveryDestinationPolicyResponse>;
export interface PutDeliverySourceRequest {
    name: string;
    resourceArn: string;
    logType: string;
    tags?: {
        [key: string]: string | undefined;
    };
    deliverySourceConfiguration?: {
        [key: string]: string | undefined;
    };
}
export declare const PutDeliverySourceRequest: S.Schema<PutDeliverySourceRequest>;
export interface PutDeliverySourceResponse {
    deliverySource?: DeliverySource;
}
export declare const PutDeliverySourceResponse: S.Schema<PutDeliverySourceResponse>;
export interface PutDestinationRequest {
    destinationName: string;
    targetArn: string;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const PutDestinationRequest: S.Schema<PutDestinationRequest>;
export interface PutDestinationResponse {
    destination?: Destination;
}
export declare const PutDestinationResponse: S.Schema<PutDestinationResponse>;
export type ForceUpdate = boolean;
export interface PutDestinationPolicyRequest {
    destinationName: string;
    accessPolicy: string;
    forceUpdate?: boolean;
}
export declare const PutDestinationPolicyRequest: S.Schema<PutDestinationPolicyRequest>;
export interface PutDestinationPolicyResponse {
}
export declare const PutDestinationPolicyResponse: S.Schema<PutDestinationPolicyResponse>;
export interface PutIndexPolicyRequest {
    logGroupIdentifier: string;
    policyDocument: string;
}
export declare const PutIndexPolicyRequest: S.Schema<PutIndexPolicyRequest>;
export interface PutIndexPolicyResponse {
    indexPolicy?: IndexPolicy;
}
export declare const PutIndexPolicyResponse: S.Schema<PutIndexPolicyResponse>;
export type DashboardViewerPrincipals = string[];
export declare const DashboardViewerPrincipals: any;
export type CollectionRetentionDays = number;
export interface OpenSearchResourceConfig {
    kmsKeyArn?: string;
    dataSourceRoleArn: string;
    dashboardViewerPrincipals: string[];
    applicationArn?: string;
    retentionDays: number;
}
export declare const OpenSearchResourceConfig: S.Schema<OpenSearchResourceConfig>;
export type ResourceConfig = {
    openSearchResourceConfig: OpenSearchResourceConfig;
};
export declare const ResourceConfig: any;
export interface PutIntegrationRequest {
    integrationName: string;
    resourceConfig: ResourceConfig;
    integrationType: IntegrationType;
}
export declare const PutIntegrationRequest: S.Schema<PutIntegrationRequest>;
export interface PutIntegrationResponse {
    integrationName?: string;
    integrationStatus?: IntegrationStatus;
}
export declare const PutIntegrationResponse: S.Schema<PutIntegrationResponse>;
export interface InputLogEvent {
    timestamp: number;
    message: string;
}
export declare const InputLogEvent: S.Schema<InputLogEvent>;
export type InputLogEvents = InputLogEvent[];
export declare const InputLogEvents: any;
export type EntityKeyAttributesKey = string;
export type EntityKeyAttributesValue = string;
export type EntityKeyAttributes = {
    [key: string]: string | undefined;
};
export declare const EntityKeyAttributes: any;
export type EntityAttributesKey = string;
export type EntityAttributesValue = string;
export type EntityAttributes = {
    [key: string]: string | undefined;
};
export declare const EntityAttributes: any;
export interface Entity {
    keyAttributes?: {
        [key: string]: string | undefined;
    };
    attributes?: {
        [key: string]: string | undefined;
    };
}
export declare const Entity: S.Schema<Entity>;
export interface PutLogEventsRequest {
    logGroupName: string;
    logStreamName: string;
    logEvents: InputLogEvent[];
    sequenceToken?: string;
    entity?: Entity;
}
export declare const PutLogEventsRequest: S.Schema<PutLogEventsRequest>;
export type LogEventIndex = number;
export interface RejectedLogEventsInfo {
    tooNewLogEventStartIndex?: number;
    tooOldLogEventEndIndex?: number;
    expiredLogEventEndIndex?: number;
}
export declare const RejectedLogEventsInfo: S.Schema<RejectedLogEventsInfo>;
export type EntityRejectionErrorType = "InvalidEntity" | "InvalidTypeValue" | "InvalidKeyAttributes" | "InvalidAttributes" | "EntitySizeTooLarge" | "UnsupportedLogGroupType" | "MissingRequiredFields" | (string & {});
export declare const EntityRejectionErrorType: any;
export interface RejectedEntityInfo {
    errorType: EntityRejectionErrorType;
}
export declare const RejectedEntityInfo: S.Schema<RejectedEntityInfo>;
export interface PutLogEventsResponse {
    nextSequenceToken?: string;
    rejectedLogEventsInfo?: RejectedLogEventsInfo;
    rejectedEntityInfo?: RejectedEntityInfo;
}
export declare const PutLogEventsResponse: S.Schema<PutLogEventsResponse>;
export interface PutLogGroupDeletionProtectionRequest {
    logGroupIdentifier: string;
    deletionProtectionEnabled: boolean;
}
export declare const PutLogGroupDeletionProtectionRequest: S.Schema<PutLogGroupDeletionProtectionRequest>;
export interface PutLogGroupDeletionProtectionResponse {
}
export declare const PutLogGroupDeletionProtectionResponse: S.Schema<PutLogGroupDeletionProtectionResponse>;
export interface PutMetricFilterRequest {
    logGroupName: string;
    filterName: string;
    filterPattern: string;
    metricTransformations: MetricTransformation[];
    applyOnTransformedLogs?: boolean;
    fieldSelectionCriteria?: string;
    emitSystemFieldDimensions?: string[];
}
export declare const PutMetricFilterRequest: S.Schema<PutMetricFilterRequest>;
export interface PutMetricFilterResponse {
}
export declare const PutMetricFilterResponse: S.Schema<PutMetricFilterResponse>;
export type ClientToken = string;
export interface PutQueryDefinitionRequest {
    queryLanguage?: QueryLanguage;
    name: string;
    queryDefinitionId?: string;
    logGroupNames?: string[];
    queryString: string;
    clientToken?: string;
    parameters?: QueryParameter[];
}
export declare const PutQueryDefinitionRequest: S.Schema<PutQueryDefinitionRequest>;
export interface PutQueryDefinitionResponse {
    queryDefinitionId?: string;
}
export declare const PutQueryDefinitionResponse: S.Schema<PutQueryDefinitionResponse>;
export interface PutResourcePolicyRequest {
    policyName?: string;
    policyDocument?: string;
    resourceArn?: string;
    expectedRevisionId?: string;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResponse {
    resourcePolicy?: ResourcePolicy;
    revisionId?: string;
}
export declare const PutResourcePolicyResponse: S.Schema<PutResourcePolicyResponse>;
export interface PutRetentionPolicyRequest {
    logGroupName: string;
    retentionInDays: number;
}
export declare const PutRetentionPolicyRequest: S.Schema<PutRetentionPolicyRequest>;
export interface PutRetentionPolicyResponse {
}
export declare const PutRetentionPolicyResponse: S.Schema<PutRetentionPolicyResponse>;
export interface PutStorageTierPolicyRequest {
    storageTier: StorageTier;
}
export declare const PutStorageTierPolicyRequest: S.Schema<PutStorageTierPolicyRequest>;
export interface PutStorageTierPolicyResponse {
    storageTier?: StorageTier;
    lastUpdatedTime?: number;
}
export declare const PutStorageTierPolicyResponse: S.Schema<PutStorageTierPolicyResponse>;
export interface PutSubscriptionFilterRequest {
    logGroupName: string;
    filterName: string;
    filterPattern: string;
    destinationArn: string;
    roleArn?: string;
    distribution?: Distribution;
    applyOnTransformedLogs?: boolean;
    fieldSelectionCriteria?: string;
    emitSystemFields?: string[];
}
export declare const PutSubscriptionFilterRequest: S.Schema<PutSubscriptionFilterRequest>;
export interface PutSubscriptionFilterResponse {
}
export declare const PutSubscriptionFilterResponse: S.Schema<PutSubscriptionFilterResponse>;
export interface PutSyslogConfigurationRequest {
    logGroupIdentifier: string;
    vpcEndpointId?: string;
}
export declare const PutSyslogConfigurationRequest: S.Schema<PutSyslogConfigurationRequest>;
export interface PutSyslogConfigurationResponse {
}
export declare const PutSyslogConfigurationResponse: S.Schema<PutSyslogConfigurationResponse>;
export interface PutTransformerRequest {
    logGroupIdentifier: string;
    transformerConfig: Processor[];
}
export declare const PutTransformerRequest: S.Schema<PutTransformerRequest>;
export interface PutTransformerResponse {
}
export declare const PutTransformerResponse: S.Schema<PutTransformerResponse>;
export type StartLiveTailLogGroupIdentifiers = string[];
export declare const StartLiveTailLogGroupIdentifiers: any;
export interface StartLiveTailRequest {
    logGroupIdentifiers: string[];
    logStreamNames?: string[];
    logStreamNamePrefixes?: string[];
    logEventFilterPattern?: string;
}
export declare const StartLiveTailRequest: S.Schema<StartLiveTailRequest>;
export type RequestId = string;
export type SessionId = string;
export interface LiveTailSessionStart {
    requestId?: string;
    sessionId?: string;
    logGroupIdentifiers?: string[];
    logStreamNames?: string[];
    logStreamNamePrefixes?: string[];
    logEventFilterPattern?: string;
}
export declare const LiveTailSessionStart: S.Schema<LiveTailSessionStart>;
export type IsSampled = boolean;
export interface LiveTailSessionMetadata {
    sampled?: boolean;
}
export declare const LiveTailSessionMetadata: S.Schema<LiveTailSessionMetadata>;
export interface LiveTailSessionLogEvent {
    logStreamName?: string;
    logGroupIdentifier?: string;
    message?: string;
    timestamp?: number;
    ingestionTime?: number;
}
export declare const LiveTailSessionLogEvent: S.Schema<LiveTailSessionLogEvent>;
export type LiveTailSessionResults = LiveTailSessionLogEvent[];
export declare const LiveTailSessionResults: any;
export interface LiveTailSessionUpdate {
    sessionMetadata?: LiveTailSessionMetadata;
    sessionResults?: LiveTailSessionLogEvent[];
}
export declare const LiveTailSessionUpdate: S.Schema<LiveTailSessionUpdate>;
export interface SessionTimeoutException {
    message?: string;
}
export declare const SessionTimeoutException: S.Schema<SessionTimeoutException>;
export interface SessionStreamingException {
    message?: string;
}
export declare const SessionStreamingException: S.Schema<SessionStreamingException>;
export type StartLiveTailResponseStream = {
    sessionStart: LiveTailSessionStart;
    sessionUpdate?: never;
    SessionTimeoutException?: never;
    SessionStreamingException?: never;
} | {
    sessionStart?: never;
    sessionUpdate: LiveTailSessionUpdate;
    SessionTimeoutException?: never;
    SessionStreamingException?: never;
} | {
    sessionStart?: never;
    sessionUpdate?: never;
    SessionTimeoutException: SessionTimeoutException;
    SessionStreamingException?: never;
} | {
    sessionStart?: never;
    sessionUpdate?: never;
    SessionTimeoutException?: never;
    SessionStreamingException: SessionStreamingException;
};
export declare const StartLiveTailResponseStream: S.Schema<stream.Stream<StartLiveTailResponseStream, Error, never>>;
export interface StartLiveTailResponse {
    responseStream?: stream.Stream<StartLiveTailResponseStream, Error, never>;
}
export declare const StartLiveTailResponse: S.Schema<StartLiveTailResponse>;
export type EventsLimitStartQuery = number;
export interface StartQueryRequest {
    queryLanguage?: QueryLanguage;
    logGroupName?: string;
    logGroupNames?: string[];
    logGroupIdentifiers?: string[];
    startTime: number;
    endTime: number;
    queryString: string;
    limit?: number;
}
export declare const StartQueryRequest: S.Schema<StartQueryRequest>;
export interface StartQueryResponse {
    queryId?: string;
}
export declare const StartQueryResponse: S.Schema<StartQueryResponse>;
export interface StopQueryRequest {
    queryId: string;
}
export declare const StopQueryRequest: S.Schema<StopQueryRequest>;
export interface StopQueryResponse {
    success?: boolean;
}
export declare const StopQueryResponse: S.Schema<StopQueryResponse>;
export interface TagLogGroupRequest {
    logGroupName: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagLogGroupRequest: S.Schema<TagLogGroupRequest>;
export interface TagLogGroupResponse {
}
export declare const TagLogGroupResponse: S.Schema<TagLogGroupResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TestEventMessages = string[];
export declare const TestEventMessages: any;
export interface TestMetricFilterRequest {
    filterPattern: string;
    logEventMessages: string[];
}
export declare const TestMetricFilterRequest: S.Schema<TestMetricFilterRequest>;
export type EventNumber = number;
export type Token = string;
export type ExtractedValues = {
    [key: string]: string | undefined;
};
export declare const ExtractedValues: any;
export interface MetricFilterMatchRecord {
    eventNumber?: number;
    eventMessage?: string;
    extractedValues?: {
        [key: string]: string | undefined;
    };
}
export declare const MetricFilterMatchRecord: S.Schema<MetricFilterMatchRecord>;
export type MetricFilterMatches = MetricFilterMatchRecord[];
export declare const MetricFilterMatches: any;
export interface TestMetricFilterResponse {
    matches?: MetricFilterMatchRecord[];
}
export declare const TestMetricFilterResponse: S.Schema<TestMetricFilterResponse>;
export interface TestTransformerRequest {
    transformerConfig: Processor[];
    logEventMessages: string[];
}
export declare const TestTransformerRequest: S.Schema<TestTransformerRequest>;
export type TransformedEventMessage = string;
export interface TransformedLogRecord {
    eventNumber?: number;
    eventMessage?: string;
    transformedEventMessage?: string;
}
export declare const TransformedLogRecord: S.Schema<TransformedLogRecord>;
export type TransformedLogs = TransformedLogRecord[];
export declare const TransformedLogs: any;
export interface TestTransformerResponse {
    transformedLogs?: TransformedLogRecord[];
}
export declare const TestTransformerResponse: S.Schema<TestTransformerResponse>;
export type TagList = string[];
export declare const TagList: any;
export interface UntagLogGroupRequest {
    logGroupName: string;
    tags: string[];
}
export declare const UntagLogGroupRequest: S.Schema<UntagLogGroupRequest>;
export interface UntagLogGroupResponse {
}
export declare const UntagLogGroupResponse: S.Schema<UntagLogGroupResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type SuppressionType = "LIMITED" | "INFINITE" | (string & {});
export declare const SuppressionType: any;
export type SuppressionUnit = "SECONDS" | "MINUTES" | "HOURS" | (string & {});
export declare const SuppressionUnit: any;
export interface SuppressionPeriod {
    value?: number;
    suppressionUnit?: SuppressionUnit;
}
export declare const SuppressionPeriod: S.Schema<SuppressionPeriod>;
export type Baseline = boolean;
export interface UpdateAnomalyRequest {
    anomalyId?: string;
    patternId?: string;
    anomalyDetectorArn: string;
    suppressionType?: SuppressionType;
    suppressionPeriod?: SuppressionPeriod;
    baseline?: boolean;
}
export declare const UpdateAnomalyRequest: S.Schema<UpdateAnomalyRequest>;
export interface UpdateAnomalyResponse {
}
export declare const UpdateAnomalyResponse: S.Schema<UpdateAnomalyResponse>;
export interface UpdateDeliveryConfigurationRequest {
    id: string;
    recordFields?: string[];
    fieldDelimiter?: string;
    s3DeliveryConfiguration?: S3DeliveryConfiguration;
}
export declare const UpdateDeliveryConfigurationRequest: S.Schema<UpdateDeliveryConfigurationRequest>;
export interface UpdateDeliveryConfigurationResponse {
}
export declare const UpdateDeliveryConfigurationResponse: S.Schema<UpdateDeliveryConfigurationResponse>;
export interface UpdateLogAnomalyDetectorRequest {
    anomalyDetectorArn: string;
    evaluationFrequency?: EvaluationFrequency;
    filterPattern?: string;
    anomalyVisibilityTime?: number;
    enabled: boolean;
}
export declare const UpdateLogAnomalyDetectorRequest: S.Schema<UpdateLogAnomalyDetectorRequest>;
export interface UpdateLogAnomalyDetectorResponse {
}
export declare const UpdateLogAnomalyDetectorResponse: S.Schema<UpdateLogAnomalyDetectorResponse>;
export interface UpdateLookupTableRequest {
    lookupTableArn: string;
    description?: string;
    tableBody?: string;
    queryId?: string;
    kmsKeyId?: string;
}
export declare const UpdateLookupTableRequest: S.Schema<UpdateLookupTableRequest>;
export interface UpdateLookupTableResponse {
    lookupTableArn?: string;
    lastUpdatedTime?: number;
}
export declare const UpdateLookupTableResponse: S.Schema<UpdateLookupTableResponse>;
export interface UpdateScheduledQueryRequest {
    identifier: string;
    description?: string;
    queryLanguage: QueryLanguage;
    queryString: string;
    logGroupIdentifiers?: string[];
    scheduleExpression: string;
    timezone?: string;
    startTimeOffset?: number;
    endTimeOffset?: number;
    destinationConfiguration?: DestinationConfiguration;
    scheduleStartTime?: number;
    scheduleEndTime?: number;
    executionRoleArn: string;
    state?: ScheduledQueryState;
}
export declare const UpdateScheduledQueryRequest: S.Schema<UpdateScheduledQueryRequest>;
export interface UpdateScheduledQueryResponse {
    scheduledQueryArn?: string;
    name?: string;
    description?: string;
    queryLanguage?: QueryLanguage;
    queryString?: string;
    logGroupIdentifiers?: string[];
    scheduleExpression?: string;
    timezone?: string;
    startTimeOffset?: number;
    endTimeOffset?: number;
    destinationConfiguration?: DestinationConfiguration;
    state?: ScheduledQueryState;
    scheduleType?: ScheduleType;
    lastTriggeredTime?: number;
    lastExecutionStatus?: ExecutionStatus;
    scheduleStartTime?: number;
    scheduleEndTime?: number;
    executionRoleArn?: string;
    creationTime?: number;
    lastUpdatedTime?: number;
}
export declare const UpdateScheduledQueryResponse: S.Schema<UpdateScheduledQueryResponse>;
export type QueryCharOffset = number;
export interface QueryCompileErrorLocation {
    startCharOffset?: number;
    endCharOffset?: number;
}
export declare const QueryCompileErrorLocation: S.Schema<QueryCompileErrorLocation>;
export interface QueryCompileError {
    location?: QueryCompileErrorLocation;
    message?: string;
}
export declare const QueryCompileError: S.Schema<QueryCompileError>;
export type AssociateKmsKeyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Associates the specified KMS key with either one log group in the
 * account, or with all stored CloudWatch Logs query insights results in the
 * account.
 *
 * When you use `AssociateKmsKey`, you specify either the
 * `logGroupName` parameter or the `resourceIdentifier` parameter. You
 * can't specify both of those parameters in the same operation.
 *
 * - Specify the `logGroupName` parameter to cause log events ingested into that
 * log group to be encrypted with that key. Only the log events ingested after the key is
 * associated are encrypted with that key.
 *
 * Associating a KMS key with a log group overrides any existing
 * associations between the log group and a KMS key. After a KMS key is associated with a log group, all newly ingested data for the log group
 * is encrypted using the KMS key. This association is stored as long as the
 * data encrypted with the KMS key is still within CloudWatch Logs. This
 * enables CloudWatch Logs to decrypt this data whenever it is requested.
 *
 * Associating a key with a log group does not cause the results of queries of that log
 * group to be encrypted with that key. To have query results encrypted with a KMS key, you must use an `AssociateKmsKey` operation with the
 * `resourceIdentifier` parameter that specifies a `query-result`
 * resource.
 *
 * - Specify the `resourceIdentifier` parameter with a `query-result`
 * resource, to use that key to encrypt the stored results of all future StartQuery operations in the account. The response from a GetQueryResults operation will still return the query results in plain
 * text.
 *
 * Even if you have not associated a key with your query results, the query results are
 * encrypted when stored, using the default CloudWatch Logs method.
 *
 * If you run a query from a monitoring account that queries logs in a source account,
 * the query results key from the monitoring account, if any, is used.
 *
 * If you delete the key that is used to encrypt log events or log group query results,
 * then all the associated stored log events or query results that were encrypted with that key
 * will be unencryptable and unusable.
 *
 * CloudWatch Logs supports only symmetric KMS keys. Do not associate an
 * asymmetric KMS key with your log group or query results. For more
 * information, see Using Symmetric and Asymmetric
 * Keys.
 *
 * It can take up to 5 minutes for this operation to take effect.
 *
 * If you attempt to associate a KMS key with a log group but the KMS key does not exist or the KMS key is disabled, you receive an
 * `InvalidParameterException` error.
 */
export declare const associateKmsKey: API.OperationMethod<AssociateKmsKeyRequest, AssociateKmsKeyResponse, AssociateKmsKeyError, Credentials | HttpClient.HttpClient>;
export type AssociateSourceToS3TableIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a data source with an S3 Table Integration for query access in the 'logs'
 * namespace. This enables querying log data using analytics engines that support Iceberg such as
 * Amazon Athena, Amazon Redshift, and Apache Spark.
 */
export declare const associateSourceToS3TableIntegration: API.OperationMethod<AssociateSourceToS3TableIntegrationRequest, AssociateSourceToS3TableIntegrationResponse, AssociateSourceToS3TableIntegrationError, Credentials | HttpClient.HttpClient>;
export type CancelExportTaskError = InvalidOperationException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Cancels the specified export task.
 *
 * The task must be in the `PENDING` or `RUNNING` state.
 */
export declare const cancelExportTask: API.OperationMethod<CancelExportTaskRequest, CancelExportTaskResponse, CancelExportTaskError, Credentials | HttpClient.HttpClient>;
export type CancelImportTaskError = AccessDeniedException | InvalidOperationException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels an active import task and stops importing data from the CloudTrail Lake Event Data Store.
 */
export declare const cancelImportTask: API.OperationMethod<CancelImportTaskRequest, CancelImportTaskResponse, CancelImportTaskError, Credentials | HttpClient.HttpClient>;
export type CreateDeliveryError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a *delivery*. A delivery is a connection between a logical
 * *delivery source* and a logical *delivery destination*
 * that you have already created.
 *
 * Only some Amazon Web Services services support being configured as a delivery source using
 * this operation. These services are listed as Supported [V2
 * Permissions] in the table at Enabling logging from
 * Amazon Web Services services.
 *
 * A delivery destination can represent a log group in CloudWatch Logs, an Amazon S3 bucket, a delivery stream in Firehose, or X-Ray.
 *
 * To configure logs delivery between a supported Amazon Web Services service and a
 * destination, you must do the following:
 *
 * - Create a delivery source, which is a logical object that represents the resource that
 * is actually sending the logs. For more information, see PutDeliverySource.
 *
 * - Create a *delivery destination*, which is a logical object that
 * represents the actual delivery destination. For more information, see PutDeliveryDestination.
 *
 * - If you are delivering logs cross-account, you must use PutDeliveryDestinationPolicy in the destination account to assign an IAM policy to the destination. This policy allows delivery to that destination.
 *
 * - Use `CreateDelivery` to create a *delivery* by pairing
 * exactly one delivery source and one delivery destination.
 *
 * You can configure a single delivery source to send logs to multiple destinations by
 * creating multiple deliveries. You can also create multiple deliveries to configure multiple
 * delivery sources to send logs to the same delivery destination.
 *
 * To update an existing delivery configuration, use UpdateDeliveryConfiguration.
 */
export declare const createDelivery: API.OperationMethod<CreateDeliveryRequest, CreateDeliveryResponse, CreateDeliveryError, Credentials | HttpClient.HttpClient>;
export type CreateExportTaskError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceAlreadyExistsException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates an export task so that you can efficiently export data from a log group to an
 * Amazon S3 bucket. When you perform a `CreateExportTask` operation, you must use
 * credentials that have permission to write to the S3 bucket that you specify as the
 * destination.
 *
 * Exporting log data to S3 buckets that are encrypted by KMS is supported.
 * Exporting log data to Amazon S3 buckets that have S3 Object Lock enabled with a
 * retention period is also supported.
 *
 * Exporting to S3 buckets that are encrypted with AES-256 is supported.
 *
 * This is an asynchronous call. If all the required information is provided, this
 * operation initiates an export task and responds with the ID of the task. After the task has
 * started, you can use DescribeExportTasks to get the status of the export task. Each account can only
 * have one active (`RUNNING` or `PENDING`) export task at a time. To
 * cancel an export task, use CancelExportTask.
 *
 * You can export logs from multiple log groups or multiple time ranges to the same S3
 * bucket. To separate log data for each export task, specify a prefix to be used as the Amazon
 * S3 key prefix for all exported objects.
 *
 * We recommend that you don't regularly export to Amazon S3 as a way to
 * continuously archive your logs. For that use case, we instead recommend that you use
 * subscriptions. For more information about subscriptions, see Real-time processing of log data
 * with subscriptions.
 *
 * Time-based sorting on chunks of log data inside an exported file is not guaranteed. You
 * can sort the exported log field data by using Linux utilities.
 */
export declare const createExportTask: API.OperationMethod<CreateExportTaskRequest, CreateExportTaskResponse, CreateExportTaskError, Credentials | HttpClient.HttpClient>;
export type CreateImportTaskError = AccessDeniedException | ConflictException | InvalidOperationException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an import from a data source to CloudWatch Log and creates a managed log group as the destination for the imported data.
 * Currently, CloudTrail Event Data Store is the only supported data source.
 *
 * The import task must satisfy the following constraints:
 *
 * - The specified source must be in an ACTIVE state.
 *
 * - The API caller must have permissions to access the data in the provided source and to perform iam:PassRole on the
 * provided import role which has the same permissions, as described below.
 *
 * - The provided IAM role must trust the "cloudtrail.amazonaws.com" principal and have the following permissions:
 *
 * - cloudtrail:GetEventDataStoreData
 *
 * - logs:CreateLogGroup
 *
 * - logs:CreateLogStream
 *
 * - logs:PutResourcePolicy
 *
 * - (If source has an associated Amazon Web Services KMS Key) kms:Decrypt
 *
 * - (If source has an associated Amazon Web Services KMS Key) kms:GenerateDataKey
 *
 * Example IAM policy for provided import role:
 *
 * `[ { "Effect": "Allow", "Action": "iam:PassRole", "Resource": "arn:aws:iam::123456789012:role/apiCallerCredentials", "Condition": { "StringLike": { "iam:AssociatedResourceARN": "arn:aws:logs:us-east-1:123456789012:log-group:aws/cloudtrail/f1d45bff-d0e3-4868-b5d9-2eb678aa32fb:*" } } }, { "Effect": "Allow", "Action": [ "cloudtrail:GetEventDataStoreData" ], "Resource": [ "arn:aws:cloudtrail:us-east-1:123456789012:eventdatastore/f1d45bff-d0e3-4868-b5d9-2eb678aa32fb" ] }, { "Effect": "Allow", "Action": [ "logs:CreateImportTask", "logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutResourcePolicy" ], "Resource": [ "arn:aws:logs:us-east-1:123456789012:log-group:/aws/cloudtrail/*" ] }, { "Effect": "Allow", "Action": [ "kms:Decrypt", "kms:GenerateDataKey" ], "Resource": [ "arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012" ] } ]`
 *
 * - If the import source has a customer managed key, the "cloudtrail.amazonaws.com" principal needs permissions to perform kms:Decrypt and kms:GenerateDataKey.
 *
 * - There can be no more than 3 active imports per account at a given time.
 *
 * - The startEventTime must be less than or equal to endEventTime.
 *
 * - The data being imported must be within the specified source's retention period.
 */
export declare const createImportTask: API.OperationMethod<CreateImportTaskRequest, CreateImportTaskResponse, CreateImportTaskError, Credentials | HttpClient.HttpClient>;
export type CreateLogAnomalyDetectorError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates an *anomaly detector* that regularly scans one or more log
 * groups and look for patterns and anomalies in the logs.
 *
 * An anomaly detector can help surface issues by automatically discovering anomalies in your
 * log event traffic. An anomaly detector uses machine learning algorithms to scan log events and
 * find *patterns*. A pattern is a shared text structure that recurs among
 * your log fields. Patterns provide a useful tool for analyzing large sets of logs because a
 * large number of log events can often be compressed into a few patterns.
 *
 * The anomaly detector uses pattern recognition to find `anomalies`, which are
 * unusual log events. It uses the `evaluationFrequency` to compare current log events
 * and patterns with trained baselines.
 *
 * Fields within a pattern are called *tokens*. Fields that vary within a
 * pattern, such as a request ID or timestamp, are referred to as dynamic
 * tokens and represented by ``.
 *
 * The following is an example of a pattern:
 *
 * `[INFO] Request time: ms`
 *
 * This pattern represents log events like `[INFO] Request time: 327 ms` and other
 * similar log events that differ only by the number, in this csse 327. When the pattern is
 * displayed, the different numbers are replaced by ``
 *
 * Any parts of log events that are masked as sensitive data are not scanned for anomalies.
 * For more information about masking sensitive data, see Help protect sensitive log
 * data with masking.
 */
export declare const createLogAnomalyDetector: API.OperationMethod<CreateLogAnomalyDetectorRequest, CreateLogAnomalyDetectorResponse, CreateLogAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type CreateLogGroupError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceAlreadyExistsException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a log group with the specified name. You can create up to 1,000,000 log groups
 * per Region per account.
 *
 * You must use the following guidelines when naming a log group:
 *
 * - Log group names must be unique within a Region for an Amazon Web Services
 * account.
 *
 * - Log group names can be between 1 and 512 characters long.
 *
 * - Log group names consist of the following characters: a-z, A-Z, 0-9, '_'
 * (underscore), '-' (hyphen), '/' (forward slash), '.' (period), and '#' (number
 * sign)
 *
 * - Log group names can't start with the string `aws/`
 *
 * When you create a log group, by default the log events in the log group do not expire.
 * To set a retention policy so that events expire and are deleted after a specified time, use
 * PutRetentionPolicy.
 *
 * If you associate an KMS key with the log group, ingested data is
 * encrypted using the KMS key. This association is stored as long as the data
 * encrypted with the KMS key is still within CloudWatch Logs. This enables
 * CloudWatch Logs to decrypt this data whenever it is requested.
 *
 * If you attempt to associate a KMS key with the log group but the KMS key does not exist or the KMS key is disabled, you receive an
 * `InvalidParameterException` error.
 *
 * CloudWatch Logs supports only symmetric KMS keys. Do not associate an
 * asymmetric KMS key with your log group. For more information, see Using
 * Symmetric and Asymmetric Keys.
 */
export declare const createLogGroup: API.OperationMethod<CreateLogGroupRequest, CreateLogGroupResponse, CreateLogGroupError, Credentials | HttpClient.HttpClient>;
export type CreateLogStreamError = InvalidParameterException | ResourceAlreadyExistsException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a log stream for the specified log group. A log stream is a sequence of log
 * events that originate from a single source, such as an application instance or a resource that
 * is being monitored.
 *
 * There is no limit on the number of log streams that you can create for a log group.
 * There is a limit of 50 TPS on `CreateLogStream` operations, after which
 * transactions are throttled.
 *
 * You must use the following guidelines when naming a log stream:
 *
 * - Log stream names must be unique within the log group.
 *
 * - Log stream names can be between 1 and 512 characters long.
 *
 * - Don't use ':' (colon) or '*' (asterisk) characters.
 */
export declare const createLogStream: API.OperationMethod<CreateLogStreamRequest, CreateLogStreamResponse, CreateLogStreamError, Credentials | HttpClient.HttpClient>;
export type CreateLookupTableError = AccessDeniedException | InvalidParameterException | LimitExceededException | ResourceAlreadyExistsException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Creates a lookup table by uploading CSV data or from CloudWatch Logs query
 * results. You can use lookup tables to enrich log data in CloudWatch Logs queries with
 * reference data such as user details, application names, or error descriptions.
 *
 * The table name must be unique within your account and Region. You must specify either
 * `tableBody` or `queryId`, but not both. If you use
 * `tableBody`, the CSV content must include a header row with column names, use
 * UTF-8 encoding, and not exceed 10 MB.
 */
export declare const createLookupTable: API.OperationMethod<CreateLookupTableRequest, CreateLookupTableResponse, CreateLookupTableError, Credentials | HttpClient.HttpClient>;
export type CreateScheduledQueryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scheduled query that runs CloudWatch Logs Insights queries at regular intervals.
 * Scheduled queries enable proactive monitoring by automatically executing queries to detect
 * patterns and anomalies in your log data. Query results can be delivered to Amazon S3 for analysis
 * or further processing.
 */
export declare const createScheduledQuery: API.OperationMethod<CreateScheduledQueryRequest, CreateScheduledQueryResponse, CreateScheduledQueryError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountPolicyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a CloudWatch Logs account policy. This stops the account-wide policy from
 * applying to log groups or data sources in the account. If you delete a data protection policy
 * or subscription filter policy, any log-group level policies of those types remain in effect.
 * This operation supports deletion of data source-based field index policies, including facet
 * configurations, in addition to log group-based policies.
 *
 * To use this operation, you must be signed on with the correct permissions depending on the
 * type of policy that you are deleting.
 *
 * - To delete a data protection policy, you must have the
 * `logs:DeleteDataProtectionPolicy` and `logs:DeleteAccountPolicy`
 * permissions.
 *
 * - To delete a subscription filter policy, you must have the
 * `logs:DeleteSubscriptionFilter` and `logs:DeleteAccountPolicy`
 * permissions.
 *
 * - To delete a transformer policy, you must have the `logs:DeleteTransformer`
 * and `logs:DeleteAccountPolicy` permissions.
 *
 * - To delete a field index policy, you must have the `logs:DeleteIndexPolicy`
 * and `logs:DeleteAccountPolicy` permissions.
 *
 * If you delete a field index policy that included facet configurations, those facets
 * will no longer be available for interactive exploration in the CloudWatch Logs Insights
 * console. However, facet data is retained for up to 30 days.
 *
 * If you delete a field index policy, the indexing of the log events that happened before
 * you deleted the policy will still be used for up to 30 days to improve CloudWatch Logs
 * Insights queries.
 */
export declare const deleteAccountPolicy: API.OperationMethod<DeleteAccountPolicyRequest, DeleteAccountPolicyResponse, DeleteAccountPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteDataProtectionPolicyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the data protection policy from the specified log group.
 *
 * For more information about data protection policies, see PutDataProtectionPolicy.
 */
export declare const deleteDataProtectionPolicy: API.OperationMethod<DeleteDataProtectionPolicyRequest, DeleteDataProtectionPolicyResponse, DeleteDataProtectionPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteDeliveryError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a *delivery*. A delivery is a connection between a logical
 * *delivery source* and a logical delivery
 * destination. Deleting a delivery only deletes the connection between the delivery
 * source and delivery destination. It does not delete the delivery destination or the delivery
 * source.
 */
export declare const deleteDelivery: API.OperationMethod<DeleteDeliveryRequest, DeleteDeliveryResponse, DeleteDeliveryError, Credentials | HttpClient.HttpClient>;
export type DeleteDeliveryDestinationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a *delivery destination*. A delivery is a connection between a
 * logical *delivery source* and a logical delivery
 * destination.
 *
 * You can't delete a delivery destination if any current deliveries are associated with it.
 * To find whether any deliveries are associated with this delivery destination, use the DescribeDeliveries operation and check the `deliveryDestinationArn`
 * field in the results.
 */
export declare const deleteDeliveryDestination: API.OperationMethod<DeleteDeliveryDestinationRequest, DeleteDeliveryDestinationResponse, DeleteDeliveryDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeliveryDestinationPolicyError = ConflictException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Deletes a delivery destination policy. For more information about these policies, see
 * PutDeliveryDestinationPolicy.
 */
export declare const deleteDeliveryDestinationPolicy: API.OperationMethod<DeleteDeliveryDestinationPolicyRequest, DeleteDeliveryDestinationPolicyResponse, DeleteDeliveryDestinationPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteDeliverySourceError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a *delivery source*. A delivery is a connection between a
 * logical *delivery source* and a logical delivery
 * destination.
 *
 * You can't delete a delivery source if any current deliveries are associated with it. To
 * find whether any deliveries are associated with this delivery source, use the DescribeDeliveries operation and check the `deliverySourceName` field in
 * the results.
 */
export declare const deleteDeliverySource: API.OperationMethod<DeleteDeliverySourceRequest, DeleteDeliverySourceResponse, DeleteDeliverySourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDestinationError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified destination, and eventually disables all the subscription filters
 * that publish to it. This operation does not delete the physical resource encapsulated by the
 * destination.
 */
export declare const deleteDestination: API.OperationMethod<DeleteDestinationRequest, DeleteDestinationResponse, DeleteDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexPolicyError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a log-group level field index policy that was applied to a single log group. The
 * indexing of the log events that happened before you delete the policy will still be used for
 * as many as 30 days to improve CloudWatch Logs Insights queries.
 *
 * If the deleted policy included facet configurations, those facets will no longer be
 * available for interactive exploration in the CloudWatch Logs Insights console for this log
 * group. However, facet data is retained for up to 30 days.
 *
 * You can't use this operation to delete an account-level index policy. Instead, use DeleteAccountPolicy.
 *
 * If you delete a log-group level field index policy and there is an account-level field
 * index policy, in a few minutes the log group begins using that account-wide policy to index
 * new incoming log events. This operation only affects log group-level policies, including any
 * facet configurations, and preserves any data source-based account policies that may apply to
 * the log group.
 */
export declare const deleteIndexPolicy: API.OperationMethod<DeleteIndexPolicyRequest, DeleteIndexPolicyResponse, DeleteIndexPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Deletes the integration between CloudWatch Logs and OpenSearch Service. If your
 * integration has active vended logs dashboards, you must specify `true` for the
 * `force` parameter, otherwise the operation will fail. If you delete the
 * integration by setting `force` to `true`, all your vended logs
 * dashboards powered by OpenSearch Service will be deleted and the data that was on them will no
 * longer be accessible.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteLogAnomalyDetectorError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified CloudWatch Logs anomaly detector.
 */
export declare const deleteLogAnomalyDetector: API.OperationMethod<DeleteLogAnomalyDetectorRequest, DeleteLogAnomalyDetectorResponse, DeleteLogAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type DeleteLogGroupError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Deletes the specified log group and permanently deletes all the archived log events
 * associated with the log group.
 */
export declare const deleteLogGroup: API.OperationMethod<DeleteLogGroupRequest, DeleteLogGroupResponse, DeleteLogGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteLogStreamError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Deletes the specified log stream and permanently deletes all the archived log events
 * associated with the log stream.
 */
export declare const deleteLogStream: API.OperationMethod<DeleteLogStreamRequest, DeleteLogStreamResponse, DeleteLogStreamError, Credentials | HttpClient.HttpClient>;
export type DeleteLookupTableError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a lookup table permanently. This operation cannot be undone.
 *
 * Queries that reference a deleted table will return an error. Before deleting a lookup
 * table, review any saved queries or dashboards that may reference it.
 */
export declare const deleteLookupTable: API.OperationMethod<DeleteLookupTableRequest, DeleteLookupTableResponse, DeleteLookupTableError, Credentials | HttpClient.HttpClient>;
export type DeleteMetricFilterError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified metric filter.
 */
export declare const deleteMetricFilter: API.OperationMethod<DeleteMetricFilterRequest, DeleteMetricFilterResponse, DeleteMetricFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteQueryDefinitionError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a saved CloudWatch Logs Insights query definition. A query definition contains
 * details about a saved CloudWatch Logs Insights query.
 *
 * Each `DeleteQueryDefinition` operation can delete one query definition.
 *
 * You must have the `logs:DeleteQueryDefinition` permission to be able to perform
 * this operation.
 */
export declare const deleteQueryDefinition: API.OperationMethod<DeleteQueryDefinitionRequest, DeleteQueryDefinitionResponse, DeleteQueryDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes a resource policy from this account. This revokes the access of the identities
 * in that policy to put log events to this account.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRetentionPolicyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified retention policy.
 *
 * Log events do not expire if they belong to log groups without a retention
 * policy.
 */
export declare const deleteRetentionPolicy: API.OperationMethod<DeleteRetentionPolicyRequest, DeleteRetentionPolicyResponse, DeleteRetentionPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a scheduled query and stops all future executions. This operation also removes any
 * configured actions and associated resources.
 */
export declare const deleteScheduledQuery: API.OperationMethod<DeleteScheduledQueryRequest, DeleteScheduledQueryResponse, DeleteScheduledQueryError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionFilterError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified subscription filter.
 */
export declare const deleteSubscriptionFilter: API.OperationMethod<DeleteSubscriptionFilterRequest, DeleteSubscriptionFilterResponse, DeleteSubscriptionFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteSyslogConfigurationError = AccessDeniedException | InvalidOperationException | InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a syslog configuration for a log group. After deletion, syslog data is no
 * longer ingested through the specified VPC endpoint.
 */
export declare const deleteSyslogConfiguration: API.OperationMethod<DeleteSyslogConfigurationRequest, DeleteSyslogConfigurationResponse, DeleteSyslogConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteTransformerError = InvalidOperationException | InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the log transformer for the specified log group. As soon as you do this, the
 * transformation of incoming log events according to that transformer stops. If this account has
 * an account-level transformer that applies to this log group, the log group begins using that
 * account-level transformer when this log-group level transformer is deleted.
 *
 * After you delete a transformer, be sure to edit any metric filters or subscription filters
 * that relied on the transformed versions of the log events.
 */
export declare const deleteTransformer: API.OperationMethod<DeleteTransformerRequest, DeleteTransformerResponse, DeleteTransformerError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountPoliciesError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of all CloudWatch Logs account policies in the account.
 *
 * To use this operation, you must be signed on with the correct permissions depending on the
 * type of policy that you are retrieving information for.
 *
 * - To see data protection policies, you must have the
 * `logs:GetDataProtectionPolicy` and `logs:DescribeAccountPolicies`
 * permissions.
 *
 * - To see subscription filter policies, you must have the
 * `logs:DescribeSubscriptionFilters` and
 * `logs:DescribeAccountPolicies` permissions.
 *
 * - To see transformer policies, you must have the `logs:GetTransformer` and
 * `logs:DescribeAccountPolicies` permissions.
 *
 * - To see field index policies, you must have the `logs:DescribeIndexPolicies`
 * and `logs:DescribeAccountPolicies` permissions.
 */
export declare const describeAccountPolicies: API.OperationMethod<DescribeAccountPoliciesRequest, DescribeAccountPoliciesResponse, DescribeAccountPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationTemplatesError = ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to return the valid and default values that are used when creating
 * delivery sources, delivery destinations, and deliveries. For more information about
 * deliveries, see CreateDelivery.
 */
export declare const describeConfigurationTemplates: API.PaginatedOperationMethod<DescribeConfigurationTemplatesRequest, DescribeConfigurationTemplatesResponse, DescribeConfigurationTemplatesError, Credentials | HttpClient.HttpClient, ConfigurationTemplate>;
export type DescribeDeliveriesError = ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of the deliveries that have been created in the account.
 *
 * A *delivery* is a connection between a
 * delivery
 * source
 * and a
 * *delivery destination*
 * .
 *
 * A delivery source represents an Amazon Web Services resource that sends logs to an logs
 * delivery destination. The destination can be CloudWatch Logs, Amazon S3, Firehose or X-Ray. Only some Amazon Web Services services support being
 * configured as a delivery source. These services are listed in Enable logging from
 * Amazon Web Services services.
 */
export declare const describeDeliveries: API.PaginatedOperationMethod<DescribeDeliveriesRequest, DescribeDeliveriesResponse, DescribeDeliveriesError, Credentials | HttpClient.HttpClient, Delivery>;
export type DescribeDeliveryDestinationsError = ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of the delivery destinations that have been created in the
 * account.
 */
export declare const describeDeliveryDestinations: API.PaginatedOperationMethod<DescribeDeliveryDestinationsRequest, DescribeDeliveryDestinationsResponse, DescribeDeliveryDestinationsError, Credentials | HttpClient.HttpClient, DeliveryDestination>;
export type DescribeDeliverySourcesError = ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of the delivery sources that have been created in the account.
 */
export declare const describeDeliverySources: API.PaginatedOperationMethod<DescribeDeliverySourcesRequest, DescribeDeliverySourcesResponse, DescribeDeliverySourcesError, Credentials | HttpClient.HttpClient, DeliverySource>;
export type DescribeDestinationsError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Lists all your destinations. The results are ASCII-sorted by destination
 * name.
 */
export declare const describeDestinations: API.PaginatedOperationMethod<DescribeDestinationsRequest, DescribeDestinationsResponse, DescribeDestinationsError, Credentials | HttpClient.HttpClient, Destination>;
export type DescribeExportTasksError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the specified export tasks. You can list all your export tasks or filter the
 * results based on task ID or task status.
 */
export declare const describeExportTasks: API.OperationMethod<DescribeExportTasksRequest, DescribeExportTasksResponse, DescribeExportTasksError, Credentials | HttpClient.HttpClient>;
export type DescribeFieldIndexesError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of field indexes discovered in log data. By default, the response includes
 * the `DEFAULT`, `CUSTOM`, and `INACTIVE` index categories. To
 * return indexes from other categories, use the `indexCategories` parameter.
 *
 * For more information about field index policies, see PutIndexPolicy.
 */
export declare const describeFieldIndexes: API.OperationMethod<DescribeFieldIndexesRequest, DescribeFieldIndexesResponse, DescribeFieldIndexesError, Credentials | HttpClient.HttpClient>;
export type DescribeImportTaskBatchesError = AccessDeniedException | InvalidOperationException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Gets detailed information about the individual batches within an import task, including their status and any error messages.
 * For CloudTrail Event Data Store sources, a batch refers to a subset of stored events grouped by their eventTime.
 */
export declare const describeImportTaskBatches: API.OperationMethod<DescribeImportTaskBatchesRequest, DescribeImportTaskBatchesResponse, DescribeImportTaskBatchesError, Credentials | HttpClient.HttpClient>;
export type DescribeImportTasksError = AccessDeniedException | InvalidOperationException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists and describes import tasks, with optional filtering by import status and source ARN.
 */
export declare const describeImportTasks: API.OperationMethod<DescribeImportTasksRequest, DescribeImportTasksResponse, DescribeImportTasksError, Credentials | HttpClient.HttpClient>;
export type DescribeIndexPoliciesError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the field index policies of the specified log group. For more information about
 * field index policies, see PutIndexPolicy.
 *
 * If a specified log group has a log-group level index policy, that policy is returned by
 * this operation.
 *
 * If a specified log group doesn't have a log-group level index policy, but an account-wide
 * index policy applies to it, that account-wide policy is returned by this operation.
 *
 * To find information about only account-level policies, use DescribeAccountPolicies instead.
 */
export declare const describeIndexPolicies: API.OperationMethod<DescribeIndexPoliciesRequest, DescribeIndexPoliciesResponse, DescribeIndexPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeLogGroupsError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Returns information about log groups, including data sources that ingest into each log
 * group. You can return all your log groups or filter the results by prefix. The results are
 * ASCII-sorted by log group name.
 *
 * CloudWatch Logs doesn't support IAM policies that control access to the
 * `DescribeLogGroups` action by using the
 * aws:ResourceTag/*key-name*
 * condition key. Other CloudWatch
 * Logs actions do support the use of the
 * aws:ResourceTag/*key-name*
 * condition key to control access.
 * For more information about using tags to control access, see Controlling access to Amazon Web Services
 * resources using tags.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation
 * in a monitoring account and view data from the linked source accounts. For more information,
 * see CloudWatch cross-account observability.
 */
export declare const describeLogGroups: API.PaginatedOperationMethod<DescribeLogGroupsRequest, DescribeLogGroupsResponse, DescribeLogGroupsError, Credentials | HttpClient.HttpClient, LogGroup>;
export type DescribeLogStreamsError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the log streams for the specified log group. You can list all the log streams or
 * filter the results by prefix. You can also control how the results are ordered.
 *
 * You can specify the log group to search by using either `logGroupIdentifier` or
 * `logGroupName`. You must include one of these two parameters, but you can't
 * include both.
 *
 * This operation has a limit of 25 transactions per second, after which transactions are
 * throttled.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation
 * in a monitoring account and view data from the linked source accounts. For more information,
 * see CloudWatch cross-account observability.
 */
export declare const describeLogStreams: API.PaginatedOperationMethod<DescribeLogStreamsRequest, DescribeLogStreamsResponse, DescribeLogStreamsError, Credentials | HttpClient.HttpClient, LogStream>;
export type DescribeLookupTablesError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves metadata about lookup tables in your account. You can optionally filter the
 * results by table name prefix. Results are sorted by table name in ascending order.
 */
export declare const describeLookupTables: API.OperationMethod<DescribeLookupTablesRequest, DescribeLookupTablesResponse, DescribeLookupTablesError, Credentials | HttpClient.HttpClient>;
export type DescribeMetricFiltersError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the specified metric filters. You can list all of the metric filters or filter
 * the results by log name, prefix, metric name, or metric namespace. The results are
 * ASCII-sorted by filter name.
 */
export declare const describeMetricFilters: API.PaginatedOperationMethod<DescribeMetricFiltersRequest, DescribeMetricFiltersResponse, DescribeMetricFiltersError, Credentials | HttpClient.HttpClient, MetricFilter>;
export type DescribeQueriesError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of CloudWatch Logs Insights queries that are scheduled, running, or have
 * been run recently in this account. You can request all queries or limit it to queries of a
 * specific log group or queries with a certain status.
 *
 * This operation includes both interactive queries started directly by users and automated
 * queries executed by scheduled query configurations. Scheduled query executions appear in the
 * results alongside manually initiated queries, providing visibility into all query activity in
 * your account.
 */
export declare const describeQueries: API.OperationMethod<DescribeQueriesRequest, DescribeQueriesResponse, DescribeQueriesError, Credentials | HttpClient.HttpClient>;
export type DescribeQueryDefinitionsError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * This operation returns a paginated list of your saved CloudWatch Logs Insights query
 * definitions. You can retrieve query definitions from the current account or from a source
 * account that is linked to the current account.
 *
 * You can use the `queryDefinitionNamePrefix` parameter to limit the results to
 * only the query definitions that have names that start with a certain string.
 */
export declare const describeQueryDefinitions: API.OperationMethod<DescribeQueryDefinitionsRequest, DescribeQueryDefinitionsResponse, DescribeQueryDefinitionsError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePoliciesError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the resource policies in this account.
 */
export declare const describeResourcePolicies: API.OperationMethod<DescribeResourcePoliciesRequest, DescribeResourcePoliciesResponse, DescribeResourcePoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeSubscriptionFiltersError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the subscription filters for the specified log group. You can list all the
 * subscription filters or filter the results by prefix. The results are ASCII-sorted by filter
 * name.
 */
export declare const describeSubscriptionFilters: API.PaginatedOperationMethod<DescribeSubscriptionFiltersRequest, DescribeSubscriptionFiltersResponse, DescribeSubscriptionFiltersError, Credentials | HttpClient.HttpClient, SubscriptionFilter>;
export type DisassociateKmsKeyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Disassociates the specified KMS key from the specified log group or
 * from all CloudWatch Logs Insights query results in the account.
 *
 * When you use `DisassociateKmsKey`, you specify either the
 * `logGroupName` parameter or the `resourceIdentifier` parameter. You
 * can't specify both of those parameters in the same operation.
 *
 * - Specify the `logGroupName` parameter to stop using the KMS key to encrypt future log events ingested and stored in the log group.
 * Instead, they will be encrypted with the default CloudWatch Logs method. The log events
 * that were ingested while the key was associated with the log group are still encrypted
 * with that key. Therefore, CloudWatch Logs will need permissions for the key whenever
 * that data is accessed.
 *
 * - Specify the `resourceIdentifier` parameter with the
 * `query-result` resource to stop using the KMS key to
 * encrypt the results of all future StartQuery
 * operations in the account. They will instead be encrypted with the default CloudWatch Logs method. The results from queries that ran while the key was associated with
 * the account are still encrypted with that key. Therefore, CloudWatch Logs will need
 * permissions for the key whenever that data is accessed.
 *
 * It can take up to 5 minutes for this operation to take effect.
 */
export declare const disassociateKmsKey: API.OperationMethod<DisassociateKmsKeyRequest, DisassociateKmsKeyResponse, DisassociateKmsKeyError, Credentials | HttpClient.HttpClient>;
export type DisassociateSourceFromS3TableIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a data source from an S3 Table Integration, removing query access and
 * deleting all associated data from the integration.
 */
export declare const disassociateSourceFromS3TableIntegration: API.OperationMethod<DisassociateSourceFromS3TableIntegrationRequest, DisassociateSourceFromS3TableIntegrationResponse, DisassociateSourceFromS3TableIntegrationError, Credentials | HttpClient.HttpClient>;
export type FilterLogEventsError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists log events from the specified log group. You can list all the log events or
 * filter the results using one or more of the following:
 *
 * - A filter pattern
 *
 * - A time range
 *
 * - The log stream name, or a log stream name prefix that matches multiple log
 * streams
 *
 * You must have the `logs:FilterLogEvents` permission to perform this
 * operation.
 *
 * You can specify the log group to search by using either `logGroupIdentifier` or
 * `logGroupName`. You must include one of these two parameters, but you can't
 * include both.
 *
 * `FilterLogEvents` is a paginated operation. Each page returned can contain up
 * to 1 MB of log events or up to 10,000 log events. A returned page might only be partially
 * full, or even empty. For example, if the result of a query would return 15,000 log events, the
 * first page isn't guaranteed to have 10,000 log events even if they all fit into 1 MB.
 *
 * Partially full or empty pages don't necessarily mean that pagination is finished. If the
 * results include a `nextToken`, there might be more log events available. You can
 * return these additional log events by providing the nextToken in a subsequent
 * `FilterLogEvents` operation. If the results don't include a
 * `nextToken`, then pagination is finished.
 *
 * Specifying the `limit` parameter only guarantees that a single page doesn't
 * return more log events than the specified limit, but it might return fewer events than the
 * limit. This is the expected API behavior.
 *
 * The returned log events are sorted by event timestamp, the timestamp when the event was
 * ingested by CloudWatch Logs, and the ID of the `PutLogEvents` request. By default,
 * the events are returned in ascending timestamp order (oldest first). To return events in
 * descending timestamp order (newest first), set the `startFromHead` parameter to
 * `false`.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation
 * in a monitoring account and view data from the linked source accounts. For more information,
 * see CloudWatch cross-account observability.
 *
 * If you are using log
 * transformation, the `FilterLogEvents` operation returns only the
 * original versions of log events, before they were transformed. To view the transformed
 * versions, you must use a CloudWatch Logs
 * query.
 */
export declare const filterLogEvents: API.PaginatedOperationMethod<FilterLogEventsRequest, FilterLogEventsResponse, FilterLogEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDataProtectionPolicyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns information about a log group data protection policy.
 */
export declare const getDataProtectionPolicy: API.OperationMethod<GetDataProtectionPolicyRequest, GetDataProtectionPolicyResponse, GetDataProtectionPolicyError, Credentials | HttpClient.HttpClient>;
export type GetDeliveryError = ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns complete information about one logical *delivery*. A delivery
 * is a connection between a
 * delivery
 * source
 * and a
 * *delivery destination*
 * .
 *
 * A delivery source represents an Amazon Web Services resource that sends logs to an logs
 * delivery destination. The destination can be CloudWatch Logs, Amazon S3, or Firehose. Only some Amazon Web Services services support being configured as a delivery
 * source. These services are listed in Enable logging from
 * Amazon Web Services services.
 *
 * You need to specify the delivery `id` in this operation. You can find the IDs
 * of the deliveries in your account with the DescribeDeliveries operation.
 */
export declare const getDelivery: API.OperationMethod<GetDeliveryRequest, GetDeliveryResponse, GetDeliveryError, Credentials | HttpClient.HttpClient>;
export type GetDeliveryDestinationError = ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves complete information about one delivery destination.
 */
export declare const getDeliveryDestination: API.OperationMethod<GetDeliveryDestinationRequest, GetDeliveryDestinationResponse, GetDeliveryDestinationError, Credentials | HttpClient.HttpClient>;
export type GetDeliveryDestinationPolicyError = ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Retrieves the delivery destination policy assigned to the delivery destination that you
 * specify. For more information about delivery destinations and their policies, see PutDeliveryDestinationPolicy.
 */
export declare const getDeliveryDestinationPolicy: API.OperationMethod<GetDeliveryDestinationPolicyRequest, GetDeliveryDestinationPolicyResponse, GetDeliveryDestinationPolicyError, Credentials | HttpClient.HttpClient>;
export type GetDeliverySourceError = ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves complete information about one delivery source.
 */
export declare const getDeliverySource: API.OperationMethod<GetDeliverySourceRequest, GetDeliverySourceResponse, GetDeliverySourceError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns information about one integration between CloudWatch Logs and OpenSearch Service.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationRequest, GetIntegrationResponse, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetLogAnomalyDetectorError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves information about the log anomaly detector that you specify. The KMS key ARN detected is valid.
 */
export declare const getLogAnomalyDetector: API.OperationMethod<GetLogAnomalyDetectorRequest, GetLogAnomalyDetectorResponse, GetLogAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type GetLogEventsError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists log events from the specified log stream. You can list all of the log events or
 * filter using a time range.
 *
 * `GetLogEvents` is a paginated operation. Each page returned can contain up to 1
 * MB of log events or up to 10,000 log events. A returned page might only be partially full, or
 * even empty. For example, if the result of a query would return 15,000 log events, the first
 * page isn't guaranteed to have 10,000 log events even if they all fit into 1 MB.
 *
 * Partially full or empty pages don't necessarily mean that pagination is finished. As long
 * as the `nextBackwardToken` or `nextForwardToken` returned is NOT equal
 * to the `nextToken` that you passed into the API call, there might be more log
 * events available. The token that you use depends on the direction you want to move in along
 * the log stream. The returned tokens are never null.
 *
 * If you set `startFromHead` to `true` and you don’t include
 * `endTime` in your request, you can end up in a situation where the pagination
 * doesn't terminate. This can happen when the new log events are being added to the target log
 * streams faster than they are being read. This situation is a good use case for the CloudWatch Logs
 * Live Tail feature.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation
 * in a monitoring account and view data from the linked source accounts. For more information,
 * see CloudWatch cross-account observability.
 *
 * You can specify the log group to search by using either `logGroupIdentifier` or
 * `logGroupName`. You must include one of these two parameters, but you can't
 * include both.
 *
 * If you are using log
 * transformation, the `GetLogEvents` operation returns only the original
 * versions of log events, before they were transformed. To view the transformed versions, you
 * must use a CloudWatch Logs
 * query.
 */
export declare const getLogEvents: API.PaginatedOperationMethod<GetLogEventsRequest, GetLogEventsResponse, GetLogEventsError, Credentials | HttpClient.HttpClient, OutputLogEvent>;
export type GetLogFieldsError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Discovers available fields for a specific data source and type. The response includes any
 * field modifications introduced through pipelines, such as new fields or changed field types.
 */
export declare const getLogFields: API.OperationMethod<GetLogFieldsRequest, GetLogFieldsResponse, GetLogFieldsError, Credentials | HttpClient.HttpClient>;
export type GetLogGroupFieldsError = InvalidParameterException | LimitExceededException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of the fields that are included in log events in the specified log group.
 * Includes the percentage of log events that contain each field. The search is limited to a time
 * period that you specify.
 *
 * This operation is used for discovering fields within log group events. For discovering
 * fields across data sources, use the GetLogFields operation.
 *
 * You can specify the log group to search by using either `logGroupIdentifier` or
 * `logGroupName`. You must specify one of these parameters, but you can't specify
 * both.
 *
 * In the results, fields that start with `@` are fields generated by CloudWatch
 * Logs. For example, `@timestamp` is the timestamp of each log event. For more
 * information about the fields that are generated by CloudWatch logs, see Supported
 * Logs and Discovered Fields.
 *
 * The response results are sorted by the frequency percentage, starting with the highest
 * percentage.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation
 * in a monitoring account and view data from the linked source accounts. For more information,
 * see CloudWatch cross-account observability.
 */
export declare const getLogGroupFields: API.OperationMethod<GetLogGroupFieldsRequest, GetLogGroupFieldsResponse, GetLogGroupFieldsError, Credentials | HttpClient.HttpClient>;
export type GetLogObjectError = AccessDeniedException | InvalidOperationException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a large logging object (LLO) and streams it back. This API is used to fetch the
 * content of large portions of log events that have been ingested through the
 * PutOpenTelemetryLogs API. When log events contain fields that would cause the total event size
 * to exceed 1MB, CloudWatch Logs automatically processes up to 10 fields, starting with the
 * largest fields. Each field is truncated as needed to keep the total event size as close to 1MB
 * as possible. The excess portions are stored as Large Log Objects (LLOs) and these fields are
 * processed separately and LLO reference system fields (in the format
 * `@ptr.$[path.to.field]`) are added. The path in the reference field reflects the
 * original JSON structure where the large field was located. For example, this could be
 * `@ptr.$['input']['message']`, `@ptr.$['AAA']['BBB']['CCC']['DDD']`,
 * `@ptr.$['AAA']`, or any other path matching your log structure.
 *
 * The `GetLogObject` API routes requests using SDK host prefix injection. SDK versions released before April 1, 2026 route to
 * `streaming-logs.*Region*.amazonaws.com`, which does not support VPC endpoints. SDK versions released on or after April 1, 2026 route to
 * `stream-logs.*Region*.amazonaws.com`, which supports VPC endpoints. To set up a VPC endpoint for this API, see Creating a VPC endpoint for CloudWatch Logs
 * .
 */
export declare const getLogObject: API.OperationMethod<GetLogObjectRequest, GetLogObjectResponse, GetLogObjectError, Credentials | HttpClient.HttpClient>;
export type GetLogRecordError = InvalidParameterException | LimitExceededException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves all of the fields and values of a single log event. All fields are retrieved,
 * even if the original query that produced the `logRecordPointer` retrieved only a
 * subset of fields. Fields are returned as field name/field value pairs.
 *
 * The full unparsed log event is returned within `@message`.
 */
export declare const getLogRecord: API.OperationMethod<GetLogRecordRequest, GetLogRecordResponse, GetLogRecordError, Credentials | HttpClient.HttpClient>;
export type GetLookupTableError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves the full content of a lookup table, including the CSV data.
 */
export declare const getLookupTable: API.OperationMethod<GetLookupTableRequest, GetLookupTableResponse, GetLookupTableError, Credentials | HttpClient.HttpClient>;
export type GetQueryResultsError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the results from the specified query.
 *
 * Only the fields requested in the query are returned, along with a `@ptr` field,
 * which is the identifier for the log record. You can use the value of `@ptr` in a
 * GetLogRecord
 * operation to get the full log record.
 *
 * `GetQueryResults` does not start running a query. To run a query, use StartQuery. For more information about how long results of previous queries are
 * available, see CloudWatch Logs
 * quotas.
 *
 * If the value of the `Status` field in the output is `Running`, this
 * operation returns only partial results. If you see a value of `Scheduled` or
 * `Running` for the status, you can retry the operation later to see the final
 * results.
 *
 * This operation is used both for retrieving results from interactive queries and from
 * automated scheduled query executions. Scheduled queries use `GetQueryResults`
 * internally to retrieve query results for processing and delivery to configured
 * destinations.
 *
 * You can retrieve up to 100,000 log event results from a query, if available, by using
 * pagination. Use the `nextToken` returned in the response to request additional
 * pages of results, with each page returning up to 10,000 log events. This is only supported for Logs Insights QL and is currently not supported for PPL and SQL query languages.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation
 * in a monitoring account to start queries in linked source accounts. For more information, see
 * CloudWatch cross-account observability.
 */
export declare const getQueryResults: API.OperationMethod<GetQueryResultsRequest, GetQueryResultsResponse, GetQueryResultsError, Credentials | HttpClient.HttpClient>;
export type GetScheduledQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific scheduled query, including its configuration, execution
 * status, and metadata.
 */
export declare const getScheduledQuery: API.OperationMethod<GetScheduledQueryRequest, GetScheduledQueryResponse, GetScheduledQueryError, Credentials | HttpClient.HttpClient>;
export type GetScheduledQueryHistoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the execution history of a scheduled query within a specified time range,
 * including query results and destination processing status.
 */
export declare const getScheduledQueryHistory: API.PaginatedOperationMethod<GetScheduledQueryHistoryRequest, GetScheduledQueryHistoryResponse, GetScheduledQueryHistoryError, Credentials | HttpClient.HttpClient, TriggerHistoryRecord>;
export type GetStorageTierPolicyError = AccessDeniedException | InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the storage tier policy for the account.
 */
export declare const getStorageTierPolicy: API.OperationMethod<GetStorageTierPolicyRequest, GetStorageTierPolicyResponse, GetStorageTierPolicyError, Credentials | HttpClient.HttpClient>;
export type GetTransformerError = InvalidOperationException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the information about the log transformer associated with this log group.
 *
 * This operation returns data only for transformers created at the log group level. To get
 * information for an account-level transformer, use DescribeAccountPolicies.
 */
export declare const getTransformer: API.OperationMethod<GetTransformerRequest, GetTransformerResponse, GetTransformerError, Credentials | HttpClient.HttpClient>;
export type ListAggregateLogGroupSummariesError = InvalidParameterException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Returns an aggregate summary of all log groups in the Region grouped by specified data
 * source characteristics. Supports optional filtering by log group class, name patterns, and
 * data sources. If you perform this action in a monitoring account, you can also return
 * aggregated summaries of log groups from source accounts that are linked to the monitoring
 * account. For more information about using cross-account observability to set up monitoring
 * accounts and source accounts, see CloudWatch
 * cross-account observability.
 *
 * The operation aggregates log groups by data source name and type and optionally format,
 * providing counts of log groups that share these characteristics. The operation paginates
 * results. By default, it returns up to 50 results and includes a token to retrieve more
 * results.
 */
export declare const listAggregateLogGroupSummaries: API.PaginatedOperationMethod<ListAggregateLogGroupSummariesRequest, ListAggregateLogGroupSummariesResponse, ListAggregateLogGroupSummariesError, Credentials | HttpClient.HttpClient, AggregateLogGroupSummary>;
export type ListAnomaliesError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of anomalies that log anomaly detectors have found. For details about the
 * structure format of each anomaly object that is returned, see the example in this
 * section.
 */
export declare const listAnomalies: API.PaginatedOperationMethod<ListAnomaliesRequest, ListAnomaliesResponse, ListAnomaliesError, Credentials | HttpClient.HttpClient, Anomaly>;
export type ListIntegrationsError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of integrations between CloudWatch Logs and other services in this
 * account. Currently, only one integration can be created in an account, and this integration
 * must be with OpenSearch Service.
 */
export declare const listIntegrations: API.OperationMethod<ListIntegrationsRequest, ListIntegrationsResponse, ListIntegrationsError, Credentials | HttpClient.HttpClient>;
export type ListLogAnomalyDetectorsError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Retrieves a list of the log anomaly detectors in the account.
 */
export declare const listLogAnomalyDetectors: API.PaginatedOperationMethod<ListLogAnomalyDetectorsRequest, ListLogAnomalyDetectorsResponse, ListLogAnomalyDetectorsError, Credentials | HttpClient.HttpClient, AnomalyDetector>;
export type ListLogGroupsError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of log groups in the Region in your account. If you are performing this
 * action in a monitoring account, you can choose to also return log groups from source accounts
 * that are linked to the monitoring account. For more information about using cross-account
 * observability to set up monitoring accounts and source accounts, see
 * CloudWatch cross-account observability.
 *
 * You can optionally filter the results by log group class, log group name pattern,
 * field indexes, data sources, field index names, or log group tags. If you specify more than
 * one filter type, the results include log groups that satisfy all filters.
 *
 * This operation is paginated. By default, your first use of this operation returns 50
 * results, and includes a token to use in a subsequent operation to return more results.
 */
export declare const listLogGroups: API.OperationMethod<ListLogGroupsRequest, ListLogGroupsResponse, ListLogGroupsError, Credentials | HttpClient.HttpClient>;
export type ListLogGroupsForQueryError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of the log groups that were analyzed during a single CloudWatch Logs
 * Insights query. This can be useful for queries that use log group name prefixes or the
 * `filterIndex` command, because the log groups are dynamically selected in these
 * cases.
 *
 * For more information about field indexes, see Create field indexes
 * to improve query performance and reduce costs.
 */
export declare const listLogGroupsForQuery: API.PaginatedOperationMethod<ListLogGroupsForQueryRequest, ListLogGroupsForQueryResponse, ListLogGroupsForQueryError, Credentials | HttpClient.HttpClient, LogGroupIdentifier>;
export type ListScheduledQueriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all scheduled queries in your account and region. You can filter results by state to
 * show only enabled or disabled queries.
 */
export declare const listScheduledQueries: API.PaginatedOperationMethod<ListScheduledQueriesRequest, ListScheduledQueriesResponse, ListScheduledQueriesError, Credentials | HttpClient.HttpClient, ScheduledQuerySummary>;
export type ListSourcesForS3TableIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of data source associations for a specified S3 Table Integration, showing
 * which data sources are currently associated for query access.
 */
export declare const listSourcesForS3TableIntegration: API.PaginatedOperationMethod<ListSourcesForS3TableIntegrationRequest, ListSourcesForS3TableIntegrationResponse, ListSourcesForS3TableIntegrationError, Credentials | HttpClient.HttpClient, S3TableIntegrationSource>;
export type ListSyslogConfigurationsError = AccessDeniedException | InvalidOperationException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns a list of syslog configurations. You can optionally filter the results by log
 * group or VPC endpoint.
 */
export declare const listSyslogConfigurations: API.OperationMethod<ListSyslogConfigurationsRequest, ListSyslogConfigurationsResponse, ListSyslogConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Displays the tags associated with a CloudWatch Logs resource. Currently, log groups and
 * destinations support tagging.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTagsLogGroupError = ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * The ListTagsLogGroup operation is on the path to deprecation. We recommend that you use
 * ListTagsForResource instead.
 *
 * Lists the tags for the specified log group.
 */
export declare const listTagsLogGroup: API.OperationMethod<ListTagsLogGroupRequest, ListTagsLogGroupResponse, ListTagsLogGroupError, Credentials | HttpClient.HttpClient>;
export type PutAccountPolicyError = InvalidParameterException | LimitExceededException | OperationAbortedException | ServiceUnavailableException | CommonErrors;
/**
 * Creates an account-level data protection policy, subscription filter policy, field index
 * policy, transformer policy, or metric extraction policy that applies to all log groups, a
 * subset of log groups, or a data source name and type combination in the account.
 *
 * `PutAccountPolicy` is an account-wide administrative operation intended for
 * CloudWatch Logs administrators. Because it affects all log groups (or a broad subset) in
 * the account, you should grant `logs:PutAccountPolicy` permissions only to
 * administrators who manage logging configuration across the account, not to application teams
 * or individual log group owners.
 *
 * Conflict resolution between account-level and log-group-level
 * policies
 *
 * When both an account-level policy and a log-group-level policy of the same type apply to a
 * log group, the resolution depends on the policy type:
 *
 * - *Data protection* — The two policies are cumulative. Any sensitive
 * term specified in either the account-level or the log-group-level policy is masked.
 *
 * - *Subscription filters* — Account-level and log-group-level
 * subscription filters are additive. A log group can have up to 1 account-level and up to 2
 * log-group-level subscription filters.
 *
 * - *Transformers* — A log-group-level transformer overrides the
 * account-level transformer. If a log group has its own transformer, it ignores the
 * account-level transformer policy.
 *
 * - *Field index policies* — If a log group has its own field index
 * policy (created with `PutIndexPolicy`), any account-level policy that uses
 * `LogGroupNamePrefix` selection criteria or has no selection criteria is ignored
 * for that log group. However, account-level policies that use `DataSourceName`
 * and `DataSourceType` selection criteria still apply alongside the log-group-level
 * policy.
 *
 * - *Metric extraction policies* — Metric extraction policies are
 * account-level only and have no log-group-level equivalent, so no conflict resolution
 * applies.
 *
 * For field index policies, you can configure indexed fields as *facets*
 * to enable interactive exploration of your logs. Facets provide value distributions and counts
 * for indexed fields in the CloudWatch Logs Insights console without requiring query
 * execution. For more information, see Use facets to group and
 * explore logs.
 *
 * To use this operation, you must be signed on with the correct permissions depending on the
 * type of policy that you are creating.
 *
 * - To create a data protection policy, you must have the
 * `logs:PutDataProtectionPolicy` and `logs:PutAccountPolicy`
 * permissions.
 *
 * - To create a subscription filter policy, you must have the
 * `logs:PutSubscriptionFilter` and `logs:PutAccountPolicy`
 * permissions.
 *
 * - To create a transformer policy, you must have the `logs:PutTransformer` and
 * `logs:PutAccountPolicy` permissions.
 *
 * - To create a field index policy, you must have the `logs:PutIndexPolicy` and
 * `logs:PutAccountPolicy` permissions.
 *
 * - To configure facets for field index policies, you must have the
 * `logs:PutIndexPolicy` and `logs:PutAccountPolicy`
 * permissions.
 *
 * - To create a metric extraction policy, you must have the
 * `logs:PutMetricExtractionPolicy` and `logs:PutAccountPolicy`
 * permissions.
 *
 * **Data protection policy**
 *
 * A data protection policy can help safeguard sensitive data that's ingested by your log
 * groups by auditing and masking the sensitive log data. Each account can have only one
 * account-level data protection policy.
 *
 * Sensitive data is detected and masked when it is ingested into a log group. When you set
 * a data protection policy, log events ingested into the log groups before that time are not
 * masked.
 *
 * If you use `PutAccountPolicy` to create a data protection policy for your whole
 * account, it applies to both existing log groups and all log groups that are created later in
 * this account. The account-level policy is applied to existing log groups with eventual
 * consistency. It might take up to 5 minutes before sensitive data in existing log groups begins
 * to be masked.
 *
 * By default, when a user views a log event that includes masked data, the sensitive data is
 * replaced by asterisks. A user who has the `logs:Unmask` permission can use a GetLogEvents or FilterLogEvents operation with the `unmask` parameter set to
 * `true` to view the unmasked log events. Users with the `logs:Unmask`
 * can also view unmasked data in the CloudWatch Logs console by running a CloudWatch Logs
 * Insights query with the `unmask` query command.
 *
 * For more information, including a list of types of data that can be audited and masked,
 * see Protect sensitive log data
 * with masking.
 *
 * To use the `PutAccountPolicy` operation for a data protection policy, you must
 * be signed on with the `logs:PutDataProtectionPolicy` and
 * `logs:PutAccountPolicy` permissions.
 *
 * The `PutAccountPolicy` operation applies to all log groups in the account. You
 * can use PutDataProtectionPolicy to create a data protection policy that applies to just one
 * log group. If a log group has its own data protection policy and the account also has an
 * account-level data protection policy, then the two policies are cumulative. Any sensitive term
 * specified in either policy is masked.
 *
 * **Subscription filter policy**
 *
 * A subscription filter policy sets up a real-time feed of log events from CloudWatch Logs to other Amazon Web Services services. Account-level subscription filter policies apply to
 * both existing log groups and log groups that are created later in this account. Supported
 * destinations are Kinesis Data Streams, Firehose, and Lambda. When log
 * events are sent to the receiving service, they are Base64 encoded and compressed with the GZIP
 * format.
 *
 * The following destinations are supported for subscription filters:
 *
 * - An Kinesis Data Streams data stream in the same account as the subscription policy, for
 * same-account delivery.
 *
 * - An Firehose data stream in the same account as the subscription policy, for
 * same-account delivery.
 *
 * - A Lambda function in the same account as the subscription policy, for
 * same-account delivery.
 *
 * - A logical destination in a different account created with PutDestination, for cross-account delivery. Kinesis Data Streams and Firehose are supported as logical destinations.
 *
 * Each account can have one account-level subscription filter policy per Region. If you are
 * updating an existing filter, you must specify the correct name in `PolicyName`. To
 * perform a `PutAccountPolicy` subscription filter operation for any destination
 * except a Lambda function, you must also have the `iam:PassRole`
 * permission.
 *
 * **Transformer policy**
 *
 * Creates or updates a *log transformer policy* for your account. You use
 * log transformers to transform log events into a different format, making them easier for you
 * to process and analyze. You can also transform logs from different sources into standardized
 * formats that contain relevant, source-specific information. After you have created a
 * transformer, CloudWatch Logs performs this transformation at the time of log ingestion. You
 * can then refer to the transformed versions of the logs during operations such as querying with
 * CloudWatch Logs Insights or creating metric filters or subscription filters.
 *
 * You can also use a transformer to copy metadata from metadata keys into the log events
 * themselves. This metadata can include log group name, log stream name, account ID and
 * Region.
 *
 * A transformer for a log group is a series of processors, where each processor applies one
 * type of transformation to the log events ingested into this log group. For more information
 * about the available processors to use in a transformer, see Processors that you can use.
 *
 * Having log events in standardized format enables visibility across your applications for
 * your log analysis, reporting, and alarming needs. CloudWatch Logs provides transformation
 * for common log types with out-of-the-box transformation templates for major Amazon Web Services
 * log sources such as VPC flow logs, Lambda, and Amazon RDS. You can use
 * pre-built transformation templates or create custom transformation policies.
 *
 * You can create transformers only for the log groups in the Standard log class.
 *
 * You can have one account-level transformer policy that applies to all log groups in the
 * account. Or you can create as many as 20 account-level transformer policies that are each
 * scoped to a subset of log groups with the `selectionCriteria` parameter. If you
 * have multiple account-level transformer policies with selection criteria, no two of them can
 * use the same or overlapping log group name prefixes. For example, if you have one policy
 * filtered to log groups that start with `my-log`, you can't have another transformer
 * policy filtered to `my-logpprod` or `my-logging`.
 *
 * You can also set up a transformer at the log-group level. For more information, see PutTransformer. If there is both a log-group level transformer created with
 * `PutTransformer` and an account-level transformer that could apply to the same
 * log group, the log group uses only the log-group level transformer. It ignores the
 * account-level transformer.
 *
 * **Field index policy**
 *
 * You can use field index policies to create indexes on fields found in log events for a log
 * group or data source name and type combination. Creating field indexes can help lower the scan
 * volume for CloudWatch Logs Insights queries that reference those fields, because these
 * queries attempt to skip the processing of log events that are known to not match the indexed
 * field. Good fields to index are fields that you often need to query for and fields or values
 * that match only a small fraction of the total log events. Common examples of indexes include
 * request ID, session ID, user IDs, or instance IDs. For more information, see Create field indexes to improve query performance and reduce costs
 *
 * To find the fields that are in your log group events, use the GetLogGroupFields operation. To find the fields for a data source use the GetLogFields operation.
 *
 * For example, suppose you have created a field index for `requestId`. Then, any
 * CloudWatch Logs Insights query on that log group that includes requestId =
 * *value*
 * or requestId in [*value*,
 * *value*, ...] will attempt to process only the log events where
 * the indexed field matches the specified value.
 *
 * Matches of log events to the names of indexed fields are case-sensitive. For example, an
 * indexed field of `RequestId` won't match a log event containing
 * `requestId`.
 *
 * You can have one account-level field index policy that applies to all log groups in the
 * account. Or you can create as many as 20 account-level field index policies that are each
 * scoped to a subset of log groups using `LogGroupNamePrefix` with the
 * `selectionCriteria` parameter. You can have another 20 account-level field index
 * policies using `DataSourceName` and `DataSourceType` for the
 * `selectionCriteria` parameter. If you have multiple account-level index policies
 * with `LogGroupNamePrefix` selection criteria, no two of them can use the same or
 * overlapping log group name prefixes. For example, if you have one policy filtered to log
 * groups that start with *my-log*, you can't have another field index policy
 * filtered to *my-logpprod* or *my-logging*. Similarly, if
 * you have multiple account-level index policies with `DataSourceName` and
 * `DataSourceType` selection criteria, no two of them can use the same data source
 * name and type combination. For example, if you have one policy filtered to the data source
 * name `amazon_vpc` and data source type `flow` you cannot create another
 * policy with this combination.
 *
 * If you create an account-level field index policy in a monitoring account in cross-account
 * observability, the policy is applied only to the monitoring account and not to any source
 * accounts.
 *
 * CloudWatch Logs provides default field indexes for all log groups in the Standard log
 * class. Default field indexes are automatically available for the following fields:
 *
 * - `@logStream`
 *
 * - `@aws.region`
 *
 * - `@aws.account`
 *
 * - `@source.log`
 *
 * - `@data_source_name`
 *
 * - `@data_source_type`
 *
 * - `@data_format`
 *
 * - `traceId`
 *
 * - `severityText`
 *
 * - `attributes.session.id`
 *
 * CloudWatch Logs provides default field indexes for certain data source name and type
 * combinations as well. Default field indexes are automatically available for the following data
 * source name and type combinations as identified in the following list:
 *
 * `amazon_vpc.flow`
 *
 * - `action`
 *
 * - `logStatus`
 *
 * - `region`
 *
 * - `flowDirection`
 *
 * - `type`
 *
 * `amazon_route53.resolver_query`
 *
 * - `transport`
 *
 * - `rcode`
 *
 * `aws_waf.access`
 *
 * - `action`
 *
 * - `httpRequest.country`
 *
 * `aws_cloudtrail.data`, `aws_cloudtrail.management`
 *
 * - `eventSource`
 *
 * - `eventName`
 *
 * - `awsRegion`
 *
 * - `userAgent`
 *
 * - `errorCode`
 *
 * - `eventType`
 *
 * - `managementEvent`
 *
 * - `readOnly`
 *
 * - `eventCategory`
 *
 * - `requestId`
 *
 * Default field indexes are in addition to any custom field indexes you define within your
 * policy. Default field indexes are not counted towards your field index
 * quota.
 *
 * If you want to create a field index policy for a single log group, you can use PutIndexPolicy instead of `PutAccountPolicy`. If you do so, that log
 * group will use that log-group level policy and any account-level policies that match at the
 * data source level; any account-level policy that matches at the log group level (for example,
 * no selection criteria or log group name prefix selection criteria) will be ignored.
 *
 * **Metric extraction policy**
 *
 * A metric extraction policy controls whether CloudWatch Metrics can be created through the
 * Embedded Metrics Format (EMF) for log groups in your account. By default, EMF metric creation
 * is enabled for all log groups. You can use metric extraction policies to disable EMF metric
 * creation for your entire account or specific log groups.
 *
 * When a policy disables EMF metric creation for a log group, log events in the EMF format
 * are still ingested, but no CloudWatch Metrics are created from them.
 *
 * Creating a policy disables metrics for Amazon Web Services features that use EMF to create metrics, such
 * as CloudWatch Container Insights and CloudWatch Application Signals. To prevent turning off
 * those features by accident, we recommend that you exclude the underlying log-groups through
 * a selection-criteria such as LogGroupNamePrefix NOT IN ["/aws/containerinsights",
 * "/aws/ecs/containerinsights", "/aws/application-signals/data"].
 *
 * Each account can have either one account-level metric extraction policy that applies to
 * all log groups, or up to 5 policies that are each scoped to a subset of log groups with the
 * `selectionCriteria` parameter. The selection criteria supports filtering by
 * `LogGroupName` and `LogGroupNamePrefix` using the operators
 * `IN` and `NOT IN`. You can specify up to 50 values in each
 * `IN` or `NOT IN` list.
 *
 * The selection criteria can be specified in these formats:
 *
 * `LogGroupName IN ["log-group-1", "log-group-2"]`
 *
 * `LogGroupNamePrefix NOT IN ["/aws/prefix1", "/aws/prefix2"]`
 *
 * If you have multiple account-level metric extraction policies with selection criteria, no
 * two of them can have overlapping criteria. For example, if you have one policy with selection
 * criteria `LogGroupNamePrefix IN ["my-log"]`, you can't have another metric
 * extraction policy with selection criteria `LogGroupNamePrefix IN ["/my-log-prod"]`
 * or `LogGroupNamePrefix IN ["/my-logging"]`, as the set of log groups matching these
 * prefixes would be a subset of the log groups matching the first policy's prefix, creating an
 * overlap.
 *
 * When using `NOT IN`, only one policy with this operator is allowed per
 * account.
 *
 * When combining policies with `IN` and `NOT IN` operators, the
 * overlap check ensures that policies don't have conflicting effects. Two policies with
 * `IN` and `NOT IN` operators do not overlap if and only if every value
 * in the `IN `policy is completely contained within some value in the NOT
 * IN policy. For example:
 *
 * - If you have a `NOT IN` policy for prefix `"/aws/lambda"`, you
 * can create an `IN` policy for the exact log group name
 * `"/aws/lambda/function1"` because the set of log groups matching
 * `"/aws/lambda/function1"` is a subset of the log groups matching
 * `"/aws/lambda"`.
 *
 * - If you have a `NOT IN` policy for prefix `"/aws/lambda"`, you
 * cannot create an `IN` policy for prefix `"/aws"` because the set of
 * log groups matching `"/aws"` is not a subset of the log groups matching
 * `"/aws/lambda"`.
 */
export declare const putAccountPolicy: API.OperationMethod<PutAccountPolicyRequest, PutAccountPolicyResponse, PutAccountPolicyError, Credentials | HttpClient.HttpClient>;
export type PutBearerTokenAuthenticationError = AccessDeniedException | InvalidOperationException | InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Enables or disables bearer token authentication for the specified log group. When enabled on a
 * log group, bearer token authentication is enabled on operations until it is explicitly
 * disabled.
 *
 * For information about the parameters that are common to all actions, see Common Parameters.
 */
export declare const putBearerTokenAuthentication: API.OperationMethod<PutBearerTokenAuthenticationRequest, PutBearerTokenAuthenticationResponse, PutBearerTokenAuthenticationError, Credentials | HttpClient.HttpClient>;
export type PutDataProtectionPolicyError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a data protection policy for the specified log group. A data protection policy can
 * help safeguard sensitive data that's ingested by the log group by auditing and masking the
 * sensitive log data.
 *
 * Sensitive data is detected and masked when it is ingested into the log group. When you
 * set a data protection policy, log events ingested into the log group before that time are
 * not masked.
 *
 * By default, when a user views a log event that includes masked data, the sensitive data is
 * replaced by asterisks. A user who has the `logs:Unmask` permission can use a GetLogEvents or FilterLogEvents operation with the `unmask` parameter set to
 * `true` to view the unmasked log events. Users with the `logs:Unmask`
 * can also view unmasked data in the CloudWatch Logs console by running a CloudWatch Logs
 * Insights query with the `unmask` query command.
 *
 * For more information, including a list of types of data that can be audited and masked,
 * see Protect sensitive log data
 * with masking.
 *
 * The `PutDataProtectionPolicy` operation applies to only the specified log
 * group. You can also use PutAccountPolicy to create an account-level data protection policy that applies to
 * all log groups in the account, including both existing log groups and log groups that are
 * created level. If a log group has its own data protection policy and the account also has an
 * account-level data protection policy, then the two policies are cumulative. Any sensitive term
 * specified in either policy is masked.
 */
export declare const putDataProtectionPolicy: API.OperationMethod<PutDataProtectionPolicyRequest, PutDataProtectionPolicyResponse, PutDataProtectionPolicyError, Credentials | HttpClient.HttpClient>;
export type PutDeliveryDestinationError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates a logical *delivery destination*. A delivery
 * destination is an Amazon Web Services resource that represents an Amazon Web Services service
 * that logs can be sent to. CloudWatch Logs, Amazon S3, and Firehose are
 * supported as logs delivery destinations and X-Ray as the trace delivery
 * destination.
 *
 * To configure logs delivery between a supported Amazon Web Services service and a
 * destination, you must do the following:
 *
 * - Create a delivery source, which is a logical object that represents the resource that
 * is actually sending the logs. For more information, see PutDeliverySource.
 *
 * - Use `PutDeliveryDestination` to create a delivery
 * destination in the same account of the actual delivery destination. The
 * delivery destination that you create is a logical object that represents the actual
 * delivery destination.
 *
 * - If you are delivering logs cross-account, you must use PutDeliveryDestinationPolicy in the destination account to assign an IAM policy to the destination. This policy allows delivery to that destination.
 *
 * - Use `CreateDelivery` to create a *delivery* by pairing
 * exactly one delivery source and one delivery destination. For more information, see CreateDelivery.
 *
 * You can configure a single delivery source to send logs to multiple destinations by
 * creating multiple deliveries. You can also create multiple deliveries to configure multiple
 * delivery sources to send logs to the same delivery destination.
 *
 * Only some Amazon Web Services services support being configured as a delivery source. These
 * services are listed as **Supported [V2 Permissions]** in the
 * table at Enabling logging from
 * Amazon Web Services services.
 *
 * If you use this operation to update an existing delivery destination, all the current
 * delivery destination parameters are overwritten with the new parameter values that you
 * specify.
 */
export declare const putDeliveryDestination: API.OperationMethod<PutDeliveryDestinationRequest, PutDeliveryDestinationResponse, PutDeliveryDestinationError, Credentials | HttpClient.HttpClient>;
export type PutDeliveryDestinationPolicyError = ConflictException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Creates and assigns an IAM policy that grants permissions to CloudWatch Logs to deliver logs cross-account to a specified destination in this account. To
 * configure the delivery of logs from an Amazon Web Services service in another account to a logs
 * delivery destination in the current account, you must do the following:
 *
 * - Create a delivery source, which is a logical object that represents the resource that
 * is actually sending the logs. For more information, see PutDeliverySource.
 *
 * - Create a *delivery destination*, which is a logical object that
 * represents the actual delivery destination. For more information, see PutDeliveryDestination.
 *
 * - Use this operation in the destination account to assign an IAM policy
 * to the destination. This policy allows delivery to that destination.
 *
 * - Create a *delivery* by pairing exactly one delivery source and one
 * delivery destination. For more information, see CreateDelivery.
 *
 * Only some Amazon Web Services services support being configured as a delivery source. These
 * services are listed as **Supported [V2 Permissions]** in the
 * table at Enabling logging from
 * Amazon Web Services services.
 *
 * The contents of the policy must include two statements. One statement enables general logs
 * delivery, and the other allows delivery to the chosen destination. See the examples for the
 * needed policies.
 */
export declare const putDeliveryDestinationPolicy: API.OperationMethod<PutDeliveryDestinationPolicyRequest, PutDeliveryDestinationPolicyResponse, PutDeliveryDestinationPolicyError, Credentials | HttpClient.HttpClient>;
export type PutDeliverySourceError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates a logical *delivery source*. A delivery source
 * represents an Amazon Web Services resource that sends logs to an logs delivery destination. The
 * destination can be CloudWatch Logs, Amazon S3, Firehose or X-Ray for sending traces.
 *
 * To configure logs delivery between a delivery destination and an Amazon Web Services
 * service that is supported as a delivery source, you must do the following:
 *
 * - Use `PutDeliverySource` to create a delivery source, which is a logical
 * object that represents the resource that is actually sending the logs.
 *
 * - Use `PutDeliveryDestination` to create a delivery
 * destination, which is a logical object that represents the actual delivery
 * destination. For more information, see PutDeliveryDestination.
 *
 * - If you are delivering logs cross-account, you must use PutDeliveryDestinationPolicy in the destination account to assign an IAM policy to the destination. This policy allows delivery to that destination.
 *
 * - Use `CreateDelivery` to create a *delivery* by pairing
 * exactly one delivery source and one delivery destination. For more information, see CreateDelivery.
 *
 * You can configure a single delivery source to send logs to multiple destinations by
 * creating multiple deliveries. You can also create multiple deliveries to configure multiple
 * delivery sources to send logs to the same delivery destination.
 *
 * Only some Amazon Web Services services support being configured as a delivery source. These
 * services are listed as **Supported [V2 Permissions]** in the
 * table at Enabling logging from
 * Amazon Web Services services.
 *
 * If you use this operation to update an existing delivery source, all the current delivery
 * source parameters are overwritten with the new parameter values that you specify.
 */
export declare const putDeliverySource: API.OperationMethod<PutDeliverySourceRequest, PutDeliverySourceResponse, PutDeliverySourceError, Credentials | HttpClient.HttpClient>;
export type PutDestinationError = InvalidParameterException | OperationAbortedException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates a destination. This operation is used only to create destinations
 * for cross-account subscriptions.
 *
 * A destination encapsulates a physical resource (such as an Amazon Kinesis stream). With
 * a destination, you can subscribe to a real-time stream of log events for a different account,
 * ingested using PutLogEvents.
 *
 * Through an access policy, a destination controls what is written to it. By default,
 * `PutDestination` does not set any access policy with the destination, which means
 * a cross-account user cannot call PutSubscriptionFilter against this destination. To enable this, the destination
 * owner must call PutDestinationPolicy after `PutDestination`.
 *
 * To perform a `PutDestination` operation, you must also have the
 * `iam:PassRole` permission.
 */
export declare const putDestination: API.OperationMethod<PutDestinationRequest, PutDestinationResponse, PutDestinationError, Credentials | HttpClient.HttpClient>;
export type PutDestinationPolicyError = InvalidParameterException | OperationAbortedException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates an access policy associated with an existing destination. An access
 * policy is an IAM
 * policy document that is used to authorize claims to register a subscription filter
 * against a given destination.
 */
export declare const putDestinationPolicy: API.OperationMethod<PutDestinationPolicyRequest, PutDestinationPolicyResponse, PutDestinationPolicyError, Credentials | HttpClient.HttpClient>;
export type PutIndexPolicyError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates a *field index policy* for the specified log group.
 * Only log groups in the Standard log class support field index policies. For more information
 * about log classes, see Log
 * classes.
 *
 * You can use field index policies to create *field indexes* on fields
 * found in log events in the log group. Creating field indexes speeds up and lowers the costs
 * for CloudWatch Logs Insights queries that reference those field indexes, because these
 * queries attempt to skip the processing of log events that are known to not match the indexed
 * field. Good fields to index are fields that you often need to query for and fields or values
 * that match only a small fraction of the total log events. Common examples of indexes include
 * request ID, session ID, userID, and instance IDs. For more information, see Create field indexes to improve query performance and reduce costs.
 *
 * You can configure indexed fields as *facets* to enable interactive
 * exploration and filtering of your logs in the CloudWatch Logs Insights console. Facets
 * allow you to view value distributions and counts for indexed fields without running queries.
 * When you create a field index, you can optionally set it as a facet to enable this interactive
 * analysis capability. For more information, see Use facets to group and
 * explore logs.
 *
 * To find the fields that are in your log group events, use the GetLogGroupFields operation.
 *
 * For example, suppose you have created a field index for `requestId`. Then, any
 * CloudWatch Logs Insights query on that log group that includes requestId =
 * *value*
 * or requestId IN [*value*,
 * *value*, ...] will process fewer log events to reduce costs, and
 * have improved performance.
 *
 * CloudWatch Logs provides default field indexes for all log groups in the Standard log
 * class. Default field indexes are automatically available for the following fields:
 *
 * - `@logStream`
 *
 * - `@aws.region`
 *
 * - `@aws.account`
 *
 * - `@source.log`
 *
 * - `traceId`
 *
 * Default field indexes are in addition to any custom field indexes you define within your
 * policy. Default field indexes are not counted towards your field index quota.
 *
 * Each index policy has the following quotas and restrictions:
 *
 * - As many as 20 fields can be included in the policy.
 *
 * - Each field name can include as many as 100 characters.
 *
 * Matches of log events to the names of indexed fields are case-sensitive. For example, a
 * field index of `RequestId` won't match a log event containing
 * `requestId`.
 *
 * Log group-level field index policies created with `PutIndexPolicy` override
 * account-level field index policies created with PutAccountPolicy that apply to log groups. If you use `PutIndexPolicy`
 * to create a field index policy for a log group, that log group uses only that policy for log
 * group-level indexing, including any facet configurations. The log group ignores any
 * account-wide field index policy that applies to log groups, but data source-based account
 * policies may still apply.
 */
export declare const putIndexPolicy: API.OperationMethod<PutIndexPolicyRequest, PutIndexPolicyResponse, PutIndexPolicyError, Credentials | HttpClient.HttpClient>;
export type PutIntegrationError = InvalidParameterException | LimitExceededException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Creates an integration between CloudWatch Logs and another service in this account.
 * Currently, only integrations with OpenSearch Service are supported, and currently you can have
 * only one integration in your account.
 *
 * Integrating with OpenSearch Service makes it possible for you to create curated vended
 * logs dashboards, powered by OpenSearch Service analytics. For more information, see Vended log
 * dashboards powered by Amazon OpenSearch Service.
 *
 * You can use this operation only to create a new integration. You can't modify an existing
 * integration.
 */
export declare const putIntegration: API.OperationMethod<PutIntegrationRequest, PutIntegrationResponse, PutIntegrationError, Credentials | HttpClient.HttpClient>;
export type PutLogEventsError = DataAlreadyAcceptedException | InvalidParameterException | InvalidSequenceTokenException | ResourceNotFoundException | ServiceUnavailableException | UnrecognizedClientException | CommonErrors;
/**
 * Uploads a batch of log events to the specified log stream.
 *
 * The sequence token is now ignored in `PutLogEvents` actions.
 * `PutLogEvents` actions are always accepted and never return
 * `InvalidSequenceTokenException` or `DataAlreadyAcceptedException`
 * even if the sequence token is not valid. You can use parallel `PutLogEvents`
 * actions on the same log stream.
 *
 * The batch of events must satisfy the following constraints:
 *
 * - The maximum batch size is 1,048,576 bytes. This size is calculated as the sum of
 * all event messages in UTF-8, plus 26 bytes for each log event.
 *
 * - Events more than 2 hours in the future are rejected while processing remaining
 * valid events.
 *
 * - Events older than 14 days or preceding the log group's retention period are
 * rejected while processing remaining valid events.
 *
 * - The log events in the batch must be in chronological order by their timestamp. The
 * timestamp is the time that the event occurred, expressed as the number of milliseconds
 * after `Jan 1, 1970 00:00:00 UTC`. (In Amazon Web Services Tools for PowerShell
 * and the Amazon Web Services SDK for .NET, the timestamp is specified in .NET format:
 * `yyyy-mm-ddThh:mm:ss`. For example, `2017-09-15T13:45:30`.)
 *
 * - A batch of log events in a single request must be in a chronological order.
 * Otherwise, the operation fails.
 *
 * - Each log event can be no larger than 1 MB.
 *
 * - The maximum number of log events in a batch is 10,000.
 *
 * - For valid events (within 14 days in the past to 2 hours in future), the time span
 * in a single batch cannot exceed 24 hours. Otherwise, the operation fails.
 *
 * The quota of five requests per second per log stream has been removed. Instead,
 * `PutLogEvents` actions are throttled based on a per-second per-account quota.
 * You can request an increase to the per-second throttling quota by using the Service Quotas service.
 *
 * If a call to `PutLogEvents` returns "UnrecognizedClientException" the most
 * likely cause is a non-valid Amazon Web Services access key ID or secret key.
 */
export declare const putLogEvents: API.OperationMethod<PutLogEventsRequest, PutLogEventsResponse, PutLogEventsError, Credentials | HttpClient.HttpClient>;
export type PutLogGroupDeletionProtectionError = AccessDeniedException | InvalidOperationException | InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Enables or disables deletion protection for the specified log group. When enabled on a
 * log group, deletion protection blocks all deletion operations until it is explicitly
 * disabled.
 *
 * For information about the parameters that are common to all actions, see Common Parameters.
 */
export declare const putLogGroupDeletionProtection: API.OperationMethod<PutLogGroupDeletionProtectionRequest, PutLogGroupDeletionProtectionResponse, PutLogGroupDeletionProtectionError, Credentials | HttpClient.HttpClient>;
export type PutMetricFilterError = InvalidOperationException | InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates a metric filter and associates it with the specified log group. With
 * metric filters, you can configure rules to extract metric data from log events ingested
 * through PutLogEvents.
 *
 * The maximum number of metric filters that can be associated with a log group is
 * 100.
 *
 * Using regular expressions in filter patterns is supported. For these filters, there is a
 * quota of two regular expression patterns within a single filter pattern. There is also a quota
 * of five regular expression patterns per log group. For more information about using regular
 * expressions in filter patterns, see Filter pattern syntax for
 * metric filters, subscription filters, filter log events, and Live Tail.
 *
 * When you create a metric filter, you can also optionally assign a unit and dimensions to
 * the metric that is created.
 *
 * Metrics extracted from log events are charged as custom metrics. To prevent unexpected
 * high charges, do not specify high-cardinality fields such as `IPAddress` or
 * `requestID` as dimensions. Each different value found for a dimension is
 * treated as a separate metric and accrues charges as a separate custom metric.
 *
 * CloudWatch Logs might disable a metric filter if it generates 1,000 different
 * name/value pairs for your specified dimensions within one hour.
 *
 * You can also set up a billing alarm to alert you if your charges are higher than
 * expected. For more information, see
 * Creating a Billing Alarm to Monitor Your Estimated Amazon Web Services Charges.
 */
export declare const putMetricFilter: API.OperationMethod<PutMetricFilterRequest, PutMetricFilterResponse, PutMetricFilterError, Credentials | HttpClient.HttpClient>;
export type PutQueryDefinitionError = InvalidParameterException | LimitExceededException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates a query definition for CloudWatch Logs Insights. For more information,
 * see Analyzing Log Data with CloudWatch Logs Insights.
 *
 * To update a query definition, specify its `queryDefinitionId` in your request.
 * The values of `name`, `queryString`, and `logGroupNames` are
 * changed to the values that you specify in your update operation. No current values are
 * retained from the current query definition. For example, imagine updating a current query
 * definition that includes log groups. If you don't specify the `logGroupNames`
 * parameter in your update operation, the query definition changes to contain no log
 * groups.
 *
 * You must have the `logs:PutQueryDefinition` permission to be able to perform
 * this operation.
 */
export declare const putQueryDefinition: API.OperationMethod<PutQueryDefinitionRequest, PutQueryDefinitionResponse, PutQueryDefinitionError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates a resource policy allowing other Amazon Web Services services to put
 * log events to this account, such as Amazon Route 53. This API has the following
 * restrictions:
 *
 * - **Supported actions** - Policy only supports
 * `logs:PutLogEvents` and `logs:CreateLogStream ` actions
 *
 * - **Supported principals** - Policy only applies when
 * operations are invoked by Amazon Web Services service principals (not IAM
 * users, roles, or cross-account principals
 *
 * - **Policy limits** - An account can have a maximum of 10
 * policies without resourceARN and one per LogGroup resourceARN
 *
 * Resource policies with actions invoked by non-Amazon Web Services service principals
 * (such as IAM users, roles, or other Amazon Web Services accounts) will not be
 * enforced. For access control involving these principals, use the IAM
 * policies.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutRetentionPolicyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Sets the retention of the specified log group. With a retention policy, you can
 * configure the number of days for which to retain log events in the specified log
 * group.
 *
 * CloudWatch Logs doesn't immediately delete log events when they reach their retention
 * setting. It typically takes up to 72 hours after that before log events are deleted, but in
 * rare situations might take longer.
 *
 * To illustrate, imagine that you change a log group to have a longer retention setting
 * when it contains log events that are past the expiration date, but haven't been deleted.
 * Those log events will take up to 72 hours to be deleted after the new retention date is
 * reached. To make sure that log data is deleted permanently, keep a log group at its lower
 * retention setting until 72 hours after the previous retention period ends. Alternatively,
 * wait to change the retention setting until you confirm that the earlier log events are
 * deleted.
 *
 * When log events reach their retention setting they are marked for deletion. After they
 * are marked for deletion, they do not add to your archival storage costs anymore, even if
 * they are not actually deleted until later. These log events marked for deletion are also not
 * included when you use an API to retrieve the `storedBytes` value to see how many
 * bytes a log group is storing.
 */
export declare const putRetentionPolicy: API.OperationMethod<PutRetentionPolicyRequest, PutRetentionPolicyResponse, PutRetentionPolicyError, Credentials | HttpClient.HttpClient>;
export type PutStorageTierPolicyError = AccessDeniedException | InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Sets the storage tier policy for the account. When you set the storage tier to
 * `INTELLIGENT_TIERING`, the service automatically moves log data to the most
 * cost-effective storage tier based on access frequency.
 */
export declare const putStorageTierPolicy: API.OperationMethod<PutStorageTierPolicyRequest, PutStorageTierPolicyResponse, PutStorageTierPolicyError, Credentials | HttpClient.HttpClient>;
export type PutSubscriptionFilterError = InvalidOperationException | InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates a subscription filter and associates it with the specified log
 * group. With subscription filters, you can subscribe to a real-time stream of log events
 * ingested through PutLogEvents
 * and have them delivered to a specific destination. When log events are sent to the receiving
 * service, they are Base64 encoded and compressed with the GZIP format.
 *
 * The following destinations are supported for subscription filters:
 *
 * - An Amazon Kinesis data stream belonging to the same account as the subscription
 * filter, for same-account delivery.
 *
 * - A logical destination created with PutDestination that belongs to a different account, for cross-account delivery.
 * We currently support Kinesis Data Streams and Firehose as logical
 * destinations.
 *
 * - An Amazon Kinesis Data Firehose delivery stream that belongs to the same account as
 * the subscription filter, for same-account delivery.
 *
 * - An Lambda function that belongs to the same account as the
 * subscription filter, for same-account delivery.
 *
 * Each log group can have up to two subscription filters associated with it. If you are
 * updating an existing filter, you must specify the correct name in `filterName`.
 *
 * Using regular expressions in filter patterns is supported. For these filters, there is a
 * quotas of quota of two regular expression patterns within a single filter pattern. There is
 * also a quota of five regular expression patterns per log group. For more information about
 * using regular expressions in filter patterns, see Filter pattern syntax for
 * metric filters, subscription filters, filter log events, and Live Tail.
 *
 * To perform a `PutSubscriptionFilter` operation for any destination except a
 * Lambda function, you must also have the `iam:PassRole`
 * permission.
 */
export declare const putSubscriptionFilter: API.OperationMethod<PutSubscriptionFilterRequest, PutSubscriptionFilterResponse, PutSubscriptionFilterError, Credentials | HttpClient.HttpClient>;
export type PutSyslogConfigurationError = AccessDeniedException | InvalidOperationException | InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates or updates a syslog configuration for a log group. This enables ingestion of
 * syslog data through the specified VPC endpoint into the log group.
 */
export declare const putSyslogConfiguration: API.OperationMethod<PutSyslogConfigurationRequest, PutSyslogConfigurationResponse, PutSyslogConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutTransformerError = InvalidOperationException | InvalidParameterException | LimitExceededException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates or updates a *log transformer* for a single log group. You use
 * log transformers to transform log events into a different format, making them easier for you
 * to process and analyze. You can also transform logs from different sources into standardized
 * formats that contains relevant, source-specific information.
 *
 * After you have created a transformer, CloudWatch Logs performs the transformations at
 * the time of log ingestion. You can then refer to the transformed versions of the logs during
 * operations such as querying with CloudWatch Logs Insights or creating metric filters or
 * subscription filers.
 *
 * You can also use a transformer to copy metadata from metadata keys into the log events
 * themselves. This metadata can include log group name, log stream name, account ID and
 * Region.
 *
 * A transformer for a log group is a series of processors, where each processor applies one
 * type of transformation to the log events ingested into this log group. The processors work one
 * after another, in the order that you list them, like a pipeline. For more information about
 * the available processors to use in a transformer, see Processors that you can use.
 *
 * Having log events in standardized format enables visibility across your applications for
 * your log analysis, reporting, and alarming needs. CloudWatch Logs provides transformation
 * for common log types with out-of-the-box transformation templates for major Amazon Web Services
 * log sources such as VPC flow logs, Lambda, and Amazon RDS. You can use
 * pre-built transformation templates or create custom transformation policies.
 *
 * You can create transformers only for the log groups in the Standard log class.
 *
 * You can also set up a transformer at the account level. For more information, see PutAccountPolicy. If there is both a log-group level transformer created with
 * `PutTransformer` and an account-level transformer that could apply to the same
 * log group, the log group uses only the log-group level transformer. It ignores the
 * account-level transformer.
 */
export declare const putTransformer: API.OperationMethod<PutTransformerRequest, PutTransformerResponse, PutTransformerError, Credentials | HttpClient.HttpClient>;
export type StartLiveTailError = AccessDeniedException | InvalidOperationException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a Live Tail streaming session for one or more log groups. A Live Tail session
 * returns a stream of log events that have been recently ingested in the log groups. For more
 * information, see Use Live Tail to view logs
 * in near real time.
 *
 * The response to this operation is a response stream, over which the server sends live log
 * events and the client receives them.
 *
 * The following objects are sent over the stream:
 *
 * - A single LiveTailSessionStart object is sent at the start of the session.
 *
 * - Every second, a LiveTailSessionUpdate object is sent. Each of these objects contains an array
 * of the actual log events.
 *
 * If no new log events were ingested in the past second, the
 * `LiveTailSessionUpdate` object will contain an empty array.
 *
 * The array of log events contained in a `LiveTailSessionUpdate` can include
 * as many as 500 log events. If the number of log events matching the request exceeds 500
 * per second, the log events are sampled down to 500 log events to be included in each
 * `LiveTailSessionUpdate` object.
 *
 * If your client consumes the log events slower than the server produces them, CloudWatch Logs buffers up to 10 `LiveTailSessionUpdate` events or 5000 log
 * events, after which it starts dropping the oldest events.
 *
 * - A SessionStreamingException object is returned if an unknown error occurs on the
 * server side.
 *
 * - A SessionTimeoutException object is returned when the session times out, after it
 * has been kept open for three hours.
 *
 * The `StartLiveTail` API routes requests using SDK host prefix injection. SDK versions released before April 1, 2026 route to
 * `streaming-logs.*Region*.amazonaws.com`, which does not support VPC endpoints. SDK versions released on or after April 1, 2026 route to
 * `stream-logs.*Region*.amazonaws.com`, which supports VPC endpoints. To set up a VPC endpoint for this API, see Creating a VPC endpoint for CloudWatch Logs
 * .
 *
 * You can end a session before it times out by closing the session stream or by closing
 * the client that is receiving the stream. The session also ends if the established connection
 * between the client and the server breaks.
 *
 * For examples of using an SDK to start a Live Tail session, see Start
 * a Live Tail session using an Amazon Web Services SDK.
 */
export declare const startLiveTail: API.OperationMethod<StartLiveTailRequest, StartLiveTailResponse, StartLiveTailError, Credentials | HttpClient.HttpClient>;
export type StartQueryError = InvalidParameterException | LimitExceededException | MalformedQueryException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Starts a query of one or more log groups or data sources using CloudWatch Logs
 * Insights. You specify the log groups or data sources and time range to query and the query
 * string to use. You can query up to 10 data sources in a single query.
 *
 * For more information, see CloudWatch Logs Insights Query
 * Syntax.
 *
 * After you run a query using `StartQuery`, the query results are stored by
 * CloudWatch Logs. You can use GetQueryResults to retrieve the results of a query, using the `queryId`
 * that `StartQuery` returns.
 *
 * Interactive queries started with `StartQuery` share concurrency limits with
 * automated scheduled query executions. Both types of queries count toward the same regional
 * concurrent query quota, so high scheduled query activity may affect the availability of
 * concurrent slots for interactive queries.
 *
 * To specify the log groups to query, a `StartQuery` operation must include one
 * of the following:
 *
 * - Either exactly one of the following parameters: `logGroupName`,
 * `logGroupNames`, or `logGroupIdentifiers`
 *
 * - Or the `queryString` must include a `SOURCE` command to select
 * log groups for the query. The `SOURCE` command can select log groups based on
 * log group name prefix, account ID, and log class, or select data sources using
 * dataSource syntax in LogsQL, PPL, and SQL. In LogsQL, the `SOURCE` command
 * also supports filtering by log group tags.
 *
 * For more information about the `SOURCE` command, see SOURCE.
 *
 * If you have associated a KMS key with the query results in this
 * account, then StartQuery uses
 * that key to encrypt the results when it stores them. If no key is associated with query
 * results, the query results are encrypted with the default CloudWatch Logs encryption
 * method.
 *
 * Queries time out after 60 minutes of runtime. If your queries are timing out, reduce the
 * time range being searched or partition your query into a number of queries.
 *
 * If you are using CloudWatch cross-account observability, you can use this operation
 * in a monitoring account to start a query in a linked source account. For more information, see
 * CloudWatch cross-account observability. For a cross-account `StartQuery`
 * operation, the query definition must be defined in the monitoring account.
 *
 * You can have up to 100 concurrent CloudWatch Logs insights queries, including queries
 * that have been added to dashboards.
 */
export declare const startQuery: API.OperationMethod<StartQueryRequest, StartQueryResponse, StartQueryError, Credentials | HttpClient.HttpClient>;
export type StopQueryError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Stops a CloudWatch Logs Insights query that is in progress. If the query has already
 * ended, the operation returns an error indicating that the specified query is not
 * running.
 *
 * This operation can be used to cancel both interactive queries and individual scheduled
 * query executions. When used with scheduled queries, `StopQuery` cancels only the
 * specific execution identified by the query ID, not the scheduled query configuration
 * itself.
 */
export declare const stopQuery: API.OperationMethod<StopQueryRequest, StopQueryResponse, StopQueryError, Credentials | HttpClient.HttpClient>;
export type TagLogGroupError = InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * The TagLogGroup operation is on the path to deprecation. We recommend that you use
 * TagResource
 * instead.
 *
 * Adds or updates the specified tags for the specified log group.
 *
 * To list the tags for a log group, use ListTagsForResource. To remove tags, use UntagResource.
 *
 * For more information about tags, see Tag Log Groups in Amazon CloudWatch Logs in the Amazon CloudWatch Logs
 * User Guide.
 *
 * CloudWatch Logs doesn't support IAM policies that prevent users from assigning specified
 * tags to log groups using the aws:Resource/*key-name*
 * or
 * `aws:TagKeys` condition keys. For more information about using tags to control
 * access, see Controlling access to Amazon Web Services resources using tags.
 */
export declare const tagLogGroup: API.OperationMethod<TagLogGroupRequest, TagLogGroupResponse, TagLogGroupError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | TooManyTagsException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified CloudWatch Logs resource.
 * Currently, the only CloudWatch Logs resources that can be tagged are log groups and
 * destinations.
 *
 * Tags can help you organize and categorize your resources. You can also use them to scope
 * user permissions by granting a user permission to access or change only resources with certain
 * tag values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as
 * strings of characters.
 *
 * You can use the `TagResource` action with a resource that already has tags. If
 * you specify a new tag key for the alarm, this tag is appended to the list of tags associated
 * with the alarm. If you specify a tag key that is already associated with the alarm, the new
 * tag value that you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a CloudWatch Logs resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestMetricFilterError = InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Tests the filter pattern of a metric filter against a sample of log event messages. You
 * can use this operation to validate the correctness of a metric filter pattern.
 */
export declare const testMetricFilter: API.OperationMethod<TestMetricFilterRequest, TestMetricFilterResponse, TestMetricFilterError, Credentials | HttpClient.HttpClient>;
export type TestTransformerError = InvalidOperationException | InvalidParameterException | ServiceUnavailableException | CommonErrors;
/**
 * Use this operation to test a log transformer. You enter the transformer configuration and
 * a set of log events to test with. The operation responds with an array that includes the
 * original log events and the transformed versions.
 */
export declare const testTransformer: API.OperationMethod<TestTransformerRequest, TestTransformerResponse, TestTransformerError, Credentials | HttpClient.HttpClient>;
export type UntagLogGroupError = ResourceNotFoundException | CommonErrors;
/**
 * The UntagLogGroup operation is on the path to deprecation. We recommend that you use
 * UntagResource instead.
 *
 * Removes the specified tags from the specified log group.
 *
 * To list the tags for a log group, use ListTagsForResource. To add tags, use TagResource.
 *
 * When using IAM policies to control tag management for CloudWatch Logs log groups, the
 * condition keys `aws:Resource/key-name` and `aws:TagKeys` cannot be used
 * to restrict which tags users can assign.
 */
export declare const untagLogGroup: API.OperationMethod<UntagLogGroupRequest, UntagLogGroupResponse, UntagLogGroupError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnomalyError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Use this operation to *suppress* anomaly detection for a specified
 * anomaly or pattern. If you suppress an anomaly, CloudWatch Logs won't report new
 * occurrences of that anomaly and won't update that anomaly with new data. If you suppress a
 * pattern, CloudWatch Logs won't report any anomalies related to that pattern.
 *
 * You must specify either `anomalyId` or `patternId`, but you can't
 * specify both parameters in the same operation.
 *
 * If you have previously used this operation to suppress detection of a pattern or anomaly,
 * you can use it again to cause CloudWatch Logs to end the suppression. To do this, use this
 * operation and specify the anomaly or pattern to stop suppressing, and omit the
 * `suppressionType` and `suppressionPeriod` parameters.
 */
export declare const updateAnomaly: API.OperationMethod<UpdateAnomalyRequest, UpdateAnomalyResponse, UpdateAnomalyError, Credentials | HttpClient.HttpClient>;
export type UpdateDeliveryConfigurationError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to update the configuration of a delivery to change
 * either the S3 path pattern or the format of the delivered logs. You can't use this operation
 * to change the source or destination of the delivery.
 */
export declare const updateDeliveryConfiguration: API.OperationMethod<UpdateDeliveryConfigurationRequest, UpdateDeliveryConfigurationResponse, UpdateDeliveryConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLogAnomalyDetectorError = InvalidParameterException | OperationAbortedException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates an existing log anomaly detector.
 */
export declare const updateLogAnomalyDetector: API.OperationMethod<UpdateLogAnomalyDetectorRequest, UpdateLogAnomalyDetectorResponse, UpdateLogAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type UpdateLookupTableError = AccessDeniedException | InvalidParameterException | ResourceNotFoundException | ServiceUnavailableException | ValidationException | CommonErrors;
/**
 * Updates an existing lookup table by replacing all of its content with new CSV data or
 * CloudWatch Logs query results. After the update completes, queries that use this table
 * use the new data.
 *
 * This is a full replacement operation. All existing content is replaced. You must specify
 * either `tableBody` or `queryId`, but not both.
 */
export declare const updateLookupTable: API.OperationMethod<UpdateLookupTableRequest, UpdateLookupTableResponse, UpdateLookupTableError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduledQueryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing scheduled query with new configuration. This operation uses PUT
 * semantics, allowing modification of query parameters, schedule, and destinations.
 */
export declare const updateScheduledQuery: API.OperationMethod<UpdateScheduledQueryRequest, UpdateScheduledQueryResponse, UpdateScheduledQueryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudwatch-logs.d.ts.map