import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TagPolicyException_base: S.Class<TagPolicyException, S.TaggedStruct<"TagPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagPolicyException extends /*@__PURE__*/ TagPolicyException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type EnvironmentId = string;
export type AllocationId = string;
export interface AssociateEipToVlanRequest {
    clientToken?: string;
    environmentId: string;
    vlanName: string;
    allocationId: string;
}
export declare const AssociateEipToVlanRequest: S.Schema<AssociateEipToVlanRequest>;
export type VlanId = number;
export type Cidr = string;
export type SubnetId = string;
export type VlanState = "CREATING" | "CREATED" | "DELETING" | "DELETED" | "CREATE_FAILED" | (string & {});
export declare const VlanState: any;
export type StateDetails = string;
export type AssociationId = string;
export type IpAddress = string;
export interface EipAssociation {
    associationId?: string;
    allocationId?: string;
    ipAddress?: string;
}
export declare const EipAssociation: S.Schema<EipAssociation>;
export type EipAssociationList = EipAssociation[];
export declare const EipAssociationList: any;
export type NetworkAclId = string;
export interface Vlan {
    vlanId?: number;
    cidr?: string;
    availabilityZone?: string;
    functionName?: string;
    subnetId?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    vlanState?: VlanState;
    stateDetails?: string;
    eipAssociations?: EipAssociation[];
    isPublic?: boolean;
    networkAclId?: string;
}
export declare const Vlan: S.Schema<Vlan>;
export interface AssociateEipToVlanResponse {
    vlan?: Vlan;
}
export declare const AssociateEipToVlanResponse: S.Schema<AssociateEipToVlanResponse>;
export type ConnectorId = string;
export type EntitlementType = "WINDOWS_SERVER" | (string & {});
export declare const EntitlementType: any;
export type VmId = string;
export type VmIdList = string[];
export declare const VmIdList: any;
export interface CreateEntitlementRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
    entitlementType: EntitlementType;
    vmIds: string[];
}
export declare const CreateEntitlementRequest: S.Schema<CreateEntitlementRequest>;
export type VmName = string;
export type EntitlementStatus = "CREATING" | "CREATED" | "DELETED" | "AT_RISK" | "ENTITLEMENT_REMOVED" | "CREATE_FAILED" | (string & {});
export declare const EntitlementStatus: any;
export interface ErrorDetail {
    errorCode: string;
    errorMessage: string;
}
export declare const ErrorDetail: S.Schema<ErrorDetail>;
export interface VmEntitlement {
    vmId?: string;
    environmentId?: string;
    connectorId?: string;
    vmName?: string;
    type?: EntitlementType;
    status?: EntitlementStatus;
    lastSyncedAt?: Date;
    startedAt?: Date;
    stoppedAt?: Date;
    errorDetail?: ErrorDetail;
}
export declare const VmEntitlement: S.Schema<VmEntitlement>;
export type VmEntitlementList = VmEntitlement[];
export declare const VmEntitlementList: any;
export interface CreateEntitlementResponse {
    entitlements?: VmEntitlement[];
}
export declare const CreateEntitlementResponse: S.Schema<CreateEntitlementResponse>;
export type EnvironmentName = string;
export type TagKey = string;
export type TagValue = string;
export type RequestTagMap = {
    [key: string]: string | undefined;
};
export declare const RequestTagMap: any;
export type SecurityGroupId = string;
export type SecurityGroups = string[];
export declare const SecurityGroups: any;
export interface ServiceAccessSecurityGroups {
    securityGroups?: string[];
}
export declare const ServiceAccessSecurityGroups: S.Schema<ServiceAccessSecurityGroups>;
export type VpcId = string;
export type VcfVersion = "VCF-5.2.1" | "VCF-5.2.2" | "SELF_DEPLOYED" | (string & {});
export declare const VcfVersion: any;
export interface InitialVlanInfo {
    cidr: string;
}
export declare const InitialVlanInfo: S.Schema<InitialVlanInfo>;
export interface InitialVlans {
    vmkManagement: InitialVlanInfo;
    vmManagement: InitialVlanInfo;
    vMotion: InitialVlanInfo;
    vSan: InitialVlanInfo;
    vTep: InitialVlanInfo;
    edgeVTep: InitialVlanInfo;
    nsxUplink: InitialVlanInfo;
    hcx: InitialVlanInfo;
    expansionVlan1: InitialVlanInfo;
    expansionVlan2: InitialVlanInfo;
    isHcxPublic?: boolean;
    hcxNetworkAclId?: string;
}
export declare const InitialVlans: S.Schema<InitialVlans>;
export type RouteServerPeering = string;
export type RouteServerPeeringList = string[];
export declare const RouteServerPeeringList: any;
export interface ConnectivityInfo {
    privateRouteServerPeerings: string[];
}
export declare const ConnectivityInfo: S.Schema<ConnectivityInfo>;
export type SolutionKey = string | redacted.Redacted<string>;
export type VSanLicenseKey = string | redacted.Redacted<string>;
export interface LicenseInfo {
    solutionKey: string | redacted.Redacted<string>;
    vsanKey: string | redacted.Redacted<string>;
}
export declare const LicenseInfo: S.Schema<LicenseInfo>;
export type LicenseInfoList = LicenseInfo[];
export declare const LicenseInfoList: any;
export type HostName = string;
export type KeyName = string;
export type InstanceType = "i4i.metal" | "i7i.metal-24xl" | "i7i.metal-48xl" | (string & {});
export declare const InstanceType: any;
export type PlacementGroupId = string;
export type DedicatedHostId = string;
export interface HostInfoForCreate {
    hostName: string;
    keyName: string;
    instanceType: InstanceType;
    placementGroupId?: string;
    dedicatedHostId?: string;
}
export declare const HostInfoForCreate: S.Schema<HostInfoForCreate>;
export type HostInfoForCreateList = HostInfoForCreate[];
export declare const HostInfoForCreateList: any;
export interface VcfHostnames {
    vCenter: string;
    nsx: string;
    nsxManager1: string;
    nsxManager2: string;
    nsxManager3: string;
    nsxEdge1: string;
    nsxEdge2: string;
    sddcManager: string;
    cloudBuilder: string;
}
export declare const VcfHostnames: S.Schema<VcfHostnames>;
export interface CreateEnvironmentRequest {
    clientToken?: string;
    environmentName?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    serviceAccessSecurityGroups?: ServiceAccessSecurityGroups;
    vpcId: string;
    serviceAccessSubnetId: string;
    vcfVersion: VcfVersion;
    termsAccepted: boolean;
    initialVlans: InitialVlans;
    connectivityInfo?: ConnectivityInfo;
    licenseInfo?: LicenseInfo[];
    hosts?: HostInfoForCreate[];
    vcfHostnames?: VcfHostnames;
    siteId?: string;
}
export declare const CreateEnvironmentRequest: S.Schema<CreateEnvironmentRequest>;
export type EnvironmentState = "CREATING" | "CREATED" | "DELETING" | "DELETED" | "CREATE_FAILED" | (string & {});
export declare const EnvironmentState: any;
export type Arn = string;
export type CheckResult = "PASSED" | "FAILED" | "UNKNOWN" | (string & {});
export declare const CheckResult: any;
export type CheckType = "KEY_REUSE" | "KEY_COVERAGE" | "REACHABILITY" | "HOST_COUNT" | "VCENTER_REACHABILITY" | "VCENTER_VM_SYNC" | "VCENTER_VM_EVENT" | "OPERATIONS_MANAGER_REACHABILITY" | "SDDC_MANAGER_REACHABILITY" | "SDDC_MANAGER_HOST_COUNT" | "SDDC_MANAGER_KEY_COVERAGE" | "SDDC_MANAGER_KEY_REUSE" | "CONNECTOR_HEALTH" | (string & {});
export declare const CheckType: any;
export interface Check {
    type?: CheckType;
    id?: string;
    result?: CheckResult;
    impairedSince?: Date;
}
export declare const Check: S.Schema<Check>;
export type ChecksList = Check[];
export declare const ChecksList: any;
export interface Secret {
    secretArn?: string;
}
export declare const Secret: S.Schema<Secret>;
export type SecretList = Secret[];
export declare const SecretList: any;
export interface Environment {
    environmentId?: string;
    environmentState?: EnvironmentState;
    stateDetails?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    environmentArn?: string;
    environmentName?: string;
    vpcId?: string;
    serviceAccessSubnetId?: string;
    vcfVersion?: VcfVersion;
    termsAccepted?: boolean;
    licenseInfo?: LicenseInfo[];
    siteId?: string;
    environmentStatus?: CheckResult;
    checks?: Check[];
    connectivityInfo?: ConnectivityInfo;
    vcfHostnames?: VcfHostnames;
    kmsKeyId?: string;
    serviceAccessSecurityGroups?: ServiceAccessSecurityGroups;
    credentials?: Secret[];
}
export declare const Environment: S.Schema<Environment>;
export interface CreateEnvironmentResponse {
    environment?: Environment;
}
export declare const CreateEnvironmentResponse: S.Schema<CreateEnvironmentResponse>;
export type ConnectorType = "OPERATIONS_MANAGER" | "SDDC_MANAGER" | "VCENTER" | (string & {});
export declare const ConnectorType: any;
export type ApplianceFqdn = string;
export type SecretIdentifier = string;
export interface CreateEnvironmentConnectorRequest {
    clientToken?: string;
    environmentId: string;
    type: ConnectorType;
    applianceFqdn: string;
    secretIdentifier: string;
}
export declare const CreateEnvironmentConnectorRequest: S.Schema<CreateEnvironmentConnectorRequest>;
export type ConnectorState = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETED" | (string & {});
export declare const ConnectorState: any;
export interface ConnectorCheck {
    type?: CheckType;
    result?: CheckResult;
    lastCheckAttempt?: Date;
    impairedSince?: Date;
}
export declare const ConnectorCheck: S.Schema<ConnectorCheck>;
export type ConnectorsChecksList = ConnectorCheck[];
export declare const ConnectorsChecksList: any;
export interface Connector {
    environmentId?: string;
    connectorId?: string;
    type?: ConnectorType;
    applianceFqdn?: string;
    secretArn?: string;
    state?: ConnectorState;
    stateDetails?: string;
    status?: CheckResult;
    checks?: ConnectorCheck[];
    createdAt?: Date;
    modifiedAt?: Date;
}
export declare const Connector: S.Schema<Connector>;
export interface CreateEnvironmentConnectorResponse {
    connector?: Connector;
}
export declare const CreateEnvironmentConnectorResponse: S.Schema<CreateEnvironmentConnectorResponse>;
export type EsxVersion = string;
export interface CreateEnvironmentHostRequest {
    clientToken?: string;
    environmentId: string;
    host: HostInfoForCreate;
    esxVersion?: string;
}
export declare const CreateEnvironmentHostRequest: S.Schema<CreateEnvironmentHostRequest>;
export interface EnvironmentSummary {
    environmentId?: string;
    environmentName?: string;
    vcfVersion?: VcfVersion;
    environmentStatus?: CheckResult;
    environmentState?: EnvironmentState;
    createdAt?: Date;
    modifiedAt?: Date;
    environmentArn?: string;
}
export declare const EnvironmentSummary: S.Schema<EnvironmentSummary>;
export type HostState = "CREATING" | "CREATED" | "UPDATING" | "DELETING" | "DELETED" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export declare const HostState: any;
export type NetworkInterfaceId = string;
export interface NetworkInterface {
    networkInterfaceId?: string;
}
export declare const NetworkInterface: S.Schema<NetworkInterface>;
export type NetworkInterfaceList = NetworkInterface[];
export declare const NetworkInterfaceList: any;
export interface Host {
    hostName?: string;
    ipAddress?: string;
    keyName?: string;
    instanceType?: InstanceType;
    placementGroupId?: string;
    dedicatedHostId?: string;
    createdAt?: Date;
    modifiedAt?: Date;
    hostState?: HostState;
    stateDetails?: string;
    ec2InstanceId?: string;
    networkInterfaces?: NetworkInterface[];
}
export declare const Host: S.Schema<Host>;
export interface CreateEnvironmentHostResponse {
    environmentSummary?: EnvironmentSummary;
    host?: Host;
}
export declare const CreateEnvironmentHostResponse: S.Schema<CreateEnvironmentHostResponse>;
export interface DeleteEntitlementRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
    entitlementType: EntitlementType;
    vmIds: string[];
}
export declare const DeleteEntitlementRequest: S.Schema<DeleteEntitlementRequest>;
export interface DeleteEntitlementResponse {
    entitlements?: VmEntitlement[];
}
export declare const DeleteEntitlementResponse: S.Schema<DeleteEntitlementResponse>;
export interface DeleteEnvironmentRequest {
    clientToken?: string;
    environmentId: string;
}
export declare const DeleteEnvironmentRequest: S.Schema<DeleteEnvironmentRequest>;
export interface DeleteEnvironmentResponse {
    environment?: Environment;
}
export declare const DeleteEnvironmentResponse: S.Schema<DeleteEnvironmentResponse>;
export interface DeleteEnvironmentConnectorRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
}
export declare const DeleteEnvironmentConnectorRequest: S.Schema<DeleteEnvironmentConnectorRequest>;
export interface DeleteEnvironmentConnectorResponse {
    connector?: Connector;
    environmentSummary?: EnvironmentSummary;
}
export declare const DeleteEnvironmentConnectorResponse: S.Schema<DeleteEnvironmentConnectorResponse>;
export interface DeleteEnvironmentHostRequest {
    clientToken?: string;
    environmentId: string;
    hostName: string;
}
export declare const DeleteEnvironmentHostRequest: S.Schema<DeleteEnvironmentHostRequest>;
export interface DeleteEnvironmentHostResponse {
    environmentSummary?: EnvironmentSummary;
    host?: Host;
}
export declare const DeleteEnvironmentHostResponse: S.Schema<DeleteEnvironmentHostResponse>;
export interface DisassociateEipFromVlanRequest {
    clientToken?: string;
    environmentId: string;
    vlanName: string;
    associationId: string;
}
export declare const DisassociateEipFromVlanRequest: S.Schema<DisassociateEipFromVlanRequest>;
export interface DisassociateEipFromVlanResponse {
    vlan?: Vlan;
}
export declare const DisassociateEipFromVlanResponse: S.Schema<DisassociateEipFromVlanResponse>;
export interface GetDepotUrlRequest {
    environmentId: string;
    rotate?: boolean;
}
export declare const GetDepotUrlRequest: S.Schema<GetDepotUrlRequest>;
export interface GetDepotUrlResponse {
    depotUrl: string;
    token: string;
}
export declare const GetDepotUrlResponse: S.Schema<GetDepotUrlResponse>;
export interface GetEnvironmentRequest {
    environmentId: string;
}
export declare const GetEnvironmentRequest: S.Schema<GetEnvironmentRequest>;
export interface GetEnvironmentResponse {
    environment?: Environment;
}
export declare const GetEnvironmentResponse: S.Schema<GetEnvironmentResponse>;
export interface GetVersionsRequest {
}
export declare const GetVersionsRequest: S.Schema<GetVersionsRequest>;
export type InstanceTypeList = InstanceType[];
export declare const InstanceTypeList: any;
export interface VcfVersionInfo {
    vcfVersion: VcfVersion;
    status: string;
    defaultEsxVersion: string;
    instanceTypes: InstanceType[];
}
export declare const VcfVersionInfo: S.Schema<VcfVersionInfo>;
export type VcfVersionList = VcfVersionInfo[];
export declare const VcfVersionList: any;
export type EsxVersionList = string[];
export declare const EsxVersionList: any;
export interface InstanceTypeEsxVersionsInfo {
    instanceType: InstanceType;
    esxVersions: string[];
}
export declare const InstanceTypeEsxVersionsInfo: S.Schema<InstanceTypeEsxVersionsInfo>;
export type InstanceTypeEsxVersionsList = InstanceTypeEsxVersionsInfo[];
export declare const InstanceTypeEsxVersionsList: any;
export interface GetVersionsResponse {
    vcfVersions: VcfVersionInfo[];
    instanceTypeEsxVersions: InstanceTypeEsxVersionsInfo[];
}
export declare const GetVersionsResponse: S.Schema<GetVersionsResponse>;
export type PaginationToken = string;
export type MaxResults = number;
export interface ListEnvironmentConnectorsRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
}
export declare const ListEnvironmentConnectorsRequest: S.Schema<ListEnvironmentConnectorsRequest>;
export type ConnectorList = Connector[];
export declare const ConnectorList: any;
export interface ListEnvironmentConnectorsResponse {
    nextToken?: string;
    connectors?: Connector[];
}
export declare const ListEnvironmentConnectorsResponse: S.Schema<ListEnvironmentConnectorsResponse>;
export interface ListEnvironmentHostsRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
}
export declare const ListEnvironmentHostsRequest: S.Schema<ListEnvironmentHostsRequest>;
export type HostList = Host[];
export declare const HostList: any;
export interface ListEnvironmentHostsResponse {
    nextToken?: string;
    environmentHosts?: Host[];
}
export declare const ListEnvironmentHostsResponse: S.Schema<ListEnvironmentHostsResponse>;
export type EnvironmentStateList = EnvironmentState[];
export declare const EnvironmentStateList: any;
export interface ListEnvironmentsRequest {
    nextToken?: string;
    maxResults?: number;
    state?: EnvironmentState[];
}
export declare const ListEnvironmentsRequest: S.Schema<ListEnvironmentsRequest>;
export type EnvironmentSummaryList = EnvironmentSummary[];
export declare const EnvironmentSummaryList: any;
export interface ListEnvironmentsResponse {
    nextToken?: string;
    environmentSummaries?: EnvironmentSummary[];
}
export declare const ListEnvironmentsResponse: S.Schema<ListEnvironmentsResponse>;
export interface ListEnvironmentVlansRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
}
export declare const ListEnvironmentVlansRequest: S.Schema<ListEnvironmentVlansRequest>;
export type VlanList = Vlan[];
export declare const VlanList: any;
export interface ListEnvironmentVlansResponse {
    nextToken?: string;
    environmentVlans?: Vlan[];
}
export declare const ListEnvironmentVlansResponse: S.Schema<ListEnvironmentVlansResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export type ResponseTagMap = {
    [key: string]: string | undefined;
};
export declare const ResponseTagMap: any;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListVmEntitlementsRequest {
    nextToken?: string;
    maxResults?: number;
    environmentId: string;
    connectorId: string;
    entitlementType: EntitlementType;
}
export declare const ListVmEntitlementsRequest: S.Schema<ListVmEntitlementsRequest>;
export interface ListVmEntitlementsResponse {
    nextToken?: string;
    entitlements?: VmEntitlement[];
}
export declare const ListVmEntitlementsResponse: S.Schema<ListVmEntitlementsResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateEnvironmentConnectorRequest {
    clientToken?: string;
    environmentId: string;
    connectorId: string;
    applianceFqdn?: string;
    secretIdentifier?: string;
}
export declare const UpdateEnvironmentConnectorRequest: S.Schema<UpdateEnvironmentConnectorRequest>;
export interface UpdateEnvironmentConnectorResponse {
    connector?: Connector;
}
export declare const UpdateEnvironmentConnectorResponse: S.Schema<UpdateEnvironmentConnectorResponse>;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AssociateEipToVlanError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an Elastic IP address with a public HCX VLAN. This operation is only allowed for public HCX VLANs at this time.
 */
export declare const associateEipToVlan: API.OperationMethod<AssociateEipToVlanRequest, AssociateEipToVlanResponse, AssociateEipToVlanError, Credentials | HttpClient.HttpClient>;
export type CreateEntitlementError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Windows Server License entitlement for virtual machines in an Amazon EVS environment using the provided vCenter Server connector. This is an asynchronous operation. Amazon EVS validates the specified virtual machines before starting usage tracking.
 */
export declare const createEntitlement: API.OperationMethod<CreateEntitlementRequest, CreateEntitlementResponse, CreateEntitlementError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = ValidationException | CommonErrors;
/**
 * Creates an Amazon EVS environment that runs VCF software, such as SDDC Manager, NSX Manager, and vCenter Server.
 *
 * When you specify `SELF_DEPLOYED` for `vcfVersion`, Amazon EVS provisions only the VLAN subnets; no hosts are added and no VCF installation is performed. After the environment is created, you can add hosts with `CreateEnvironmentHost` and install VCF yourself. The `licenseInfo`, `hosts`, `vcfHostnames`, `siteId`, and `connectivityInfo` parameters are not supported in this mode.
 *
 * When you specify any other VCF version, Amazon EVS installs and configures VCF for you. For more information, see Self-deployed mode in the *Amazon EVS User Guide*.
 *
 * When Amazon EVS installs VCF, the default ESX version for the selected VCF version will be used. After a host is added with a specific ESX version, it can only be upgraded using vCenter Lifecycle Manager.
 *
 * You cannot use the `dedicatedHostId` and `placementGroupId` parameters together in the same `CreateEnvironment` action. This results in a `ValidationException` response.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentConnectorError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connector for an Amazon EVS environment. A connector allows the Amazon EVS control plane to interface with VCF appliances using a fully qualified domain name.
 *
 * You can create only one connector of each type per environment. For environments where Amazon EVS installs VCF, the `SDDC_MANAGER` connector is created automatically.
 *
 * Amazon EVS requires an active connector to SDDC Manager or VCF Operations Manager to monitor environment health and license compliance.
 */
export declare const createEnvironmentConnector: API.OperationMethod<CreateEnvironmentConnectorRequest, CreateEnvironmentConnectorResponse, CreateEnvironmentConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentHostError = ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ESX host and adds it to an Amazon EVS environment.
 *
 * This action can only be used after the Amazon EVS environment is deployed.
 *
 * You can use the `dedicatedHostId` parameter to specify an Amazon EC2 Dedicated Host for ESX host creation.
 *
 * You can use the `placementGroupId` parameter to specify a cluster or partition placement group to launch EC2 instances into.
 *
 * If you don't specify an ESX version when adding hosts using `CreateEnvironmentHost` action, Amazon EVS automatically uses the default ESX version for your environment's VCF version. To find the available ESX versions for a particular VCF version, use the `GetVersions` action.
 *
 * You cannot use the `dedicatedHostId` and `placementGroupId` parameters together in the same `CreateEnvironmentHost` action. This results in a `ValidationException` response.
 */
export declare const createEnvironmentHost: API.OperationMethod<CreateEnvironmentHostRequest, CreateEnvironmentHostResponse, CreateEnvironmentHostError, Credentials | HttpClient.HttpClient>;
export type DeleteEntitlementError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Windows Server License entitlement for virtual machines in an Amazon EVS environment. Deleting an entitlement stops usage tracking for the specified virtual machines.
 */
export declare const deleteEntitlement: API.OperationMethod<DeleteEntitlementRequest, DeleteEntitlementResponse, DeleteEntitlementError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon EVS environment.
 *
 * Amazon EVS environments will only be enabled for deletion once the hosts are deleted. You can delete hosts using the `DeleteEnvironmentHost` action.
 *
 * Environment deletion also deletes the associated Amazon EVS VLAN subnets and Amazon Web Services Secrets Manager secrets that Amazon EVS created. Amazon Web Services resources that you create are not deleted. These resources may continue to incur costs.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentConnectorError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connector from an Amazon EVS environment.
 *
 * Before deleting a connector, you must remove all entitlements that are associated with the same vCenter.
 */
export declare const deleteEnvironmentConnector: API.OperationMethod<DeleteEnvironmentConnectorRequest, DeleteEnvironmentConnectorResponse, DeleteEnvironmentConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentHostError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a host from an Amazon EVS environment.
 *
 * Before deleting a host, you must unassign and decommission the host from within the SDDC Manager user interface. Not doing so could impact the availability of your virtual machines or result in data loss.
 */
export declare const deleteEnvironmentHost: API.OperationMethod<DeleteEnvironmentHostRequest, DeleteEnvironmentHostResponse, DeleteEnvironmentHostError, Credentials | HttpClient.HttpClient>;
export type DisassociateEipFromVlanError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an Elastic IP address from a public HCX VLAN. This operation is only allowed for public HCX VLANs at this time.
 */
export declare const disassociateEipFromVlan: API.OperationMethod<DisassociateEipFromVlanRequest, DisassociateEipFromVlanResponse, DisassociateEipFromVlanError, Credentials | HttpClient.HttpClient>;
export type GetDepotUrlError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a URL and authentication token for accessing the Amazon EVS Custom Addon depot. Configure the depot URL as a download source in vSphere Lifecycle Manager (vLCM) to sync and install the Amazon EVS Custom Addon.
 *
 * The depot URL remains active until you rotate the authentication token by calling this action with `rotate` set to `true`.
 */
export declare const getDepotUrl: API.OperationMethod<GetDepotUrlRequest, GetDepotUrlResponse, GetDepotUrlError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a description of the specified environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetVersionsError = InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns information about VCF versions, ESX versions and EC2 instance types provided by Amazon EVS. For each VCF version, the response also includes the default ESX version and provided EC2 instance types.
 */
export declare const getVersions: API.OperationMethod<GetVersionsRequest, GetVersionsResponse, GetVersionsError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentConnectorsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the connectors within an environment. Returns the status of each connector and its applicable checks, among other connector details.
 */
export declare const listEnvironmentConnectors: API.PaginatedOperationMethod<ListEnvironmentConnectorsRequest, ListEnvironmentConnectorsResponse, ListEnvironmentConnectorsError, Credentials | HttpClient.HttpClient, Connector>;
export type ListEnvironmentHostsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the hosts within an environment.
 */
export declare const listEnvironmentHosts: API.PaginatedOperationMethod<ListEnvironmentHostsRequest, ListEnvironmentHostsResponse, ListEnvironmentHostsError, Credentials | HttpClient.HttpClient, Host>;
export type ListEnvironmentsError = ValidationException | CommonErrors;
/**
 * Lists the Amazon EVS environments in your Amazon Web Services account in the specified Amazon Web Services Region.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListEnvironmentVlansError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists environment VLANs that are associated with the specified environment.
 */
export declare const listEnvironmentVlans: API.PaginatedOperationMethod<ListEnvironmentVlansRequest, ListEnvironmentVlansResponse, ListEnvironmentVlansError, Credentials | HttpClient.HttpClient, Vlan>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for an Amazon EVS resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVmEntitlementsError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the Windows Server License entitlements for virtual machines in an Amazon EVS environment. Returns existing entitlements for virtual machines associated with the specified environment and connector.
 */
export declare const listVmEntitlements: API.PaginatedOperationMethod<ListVmEntitlementsRequest, ListVmEntitlementsResponse, ListVmEntitlementsError, Credentials | HttpClient.HttpClient, VmEntitlement>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Associates the specified tags to an Amazon EVS resource with the specified `resourceArn`. If existing tags on a resource are not specified in the request parameters, they aren't changed. When a resource is deleted, the tags associated with that resource are also deleted. Tags that you create for Amazon EVS resources don't propagate to any other resources associated with the environment. For example, if you tag an environment with this operation, that tag doesn't automatically propagate to the VLAN subnets and hosts associated with the environment.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | TagPolicyException | CommonErrors;
/**
 * Deletes specified tags from an Amazon EVS resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentConnectorError = ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a connector for an Amazon EVS environment. You can update the Amazon Web Services Secrets Manager secret ARN or the appliance FQDN to reconfigure the connector metadata.
 *
 * You cannot update both the secret and the FQDN in the same request.
 */
export declare const updateEnvironmentConnector: API.OperationMethod<UpdateEnvironmentConnectorRequest, UpdateEnvironmentConnectorResponse, UpdateEnvironmentConnectorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=evs.d.ts.map