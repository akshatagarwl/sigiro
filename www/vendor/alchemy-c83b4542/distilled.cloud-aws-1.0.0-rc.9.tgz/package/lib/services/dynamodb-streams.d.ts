import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ExpiredIteratorException_base: S.Class<ExpiredIteratorException, S.TaggedStruct<"ExpiredIteratorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ExpiredIteratorException extends /*@__PURE__*/ ExpiredIteratorException_base {
}
declare const InternalServerError_base: S.Class<InternalServerError, S.TaggedStruct<"InternalServerError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TrimmedDataAccessException_base: S.Class<TrimmedDataAccessException, S.TaggedStruct<"TrimmedDataAccessException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TrimmedDataAccessException extends /*@__PURE__*/ TrimmedDataAccessException_base {
}
export type StreamArn = string;
export type PositiveIntegerObject = number;
export type ShardId = string;
export type ShardFilterType = "CHILD_SHARDS" | (string & {});
export declare const ShardFilterType: any;
export interface ShardFilter {
    Type?: ShardFilterType;
    ShardId?: string;
}
export declare const ShardFilter: S.Schema<ShardFilter>;
export interface DescribeStreamInput {
    StreamArn: string;
    Limit?: number;
    ExclusiveStartShardId?: string;
    ShardFilter?: ShardFilter;
}
export declare const DescribeStreamInput: S.Schema<DescribeStreamInput>;
export type StreamStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | (string & {});
export declare const StreamStatus: any;
export type StreamViewType = "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY" | (string & {});
export declare const StreamViewType: any;
export type TableName = string;
export type KeySchemaAttributeName = string;
export type KeyType = "HASH" | "RANGE" | (string & {});
export declare const KeyType: any;
export interface KeySchemaElement {
    AttributeName: string;
    KeyType: KeyType;
}
export declare const KeySchemaElement: S.Schema<KeySchemaElement>;
export type KeySchema = KeySchemaElement[];
export declare const KeySchema: any;
export type SequenceNumber = string;
export interface SequenceNumberRange {
    StartingSequenceNumber?: string;
    EndingSequenceNumber?: string;
}
export declare const SequenceNumberRange: S.Schema<SequenceNumberRange>;
export interface Shard {
    ShardId?: string;
    SequenceNumberRange?: SequenceNumberRange;
    ParentShardId?: string;
}
export declare const Shard: S.Schema<Shard>;
export type ShardDescriptionList = Shard[];
export declare const ShardDescriptionList: any;
export interface StreamDescription {
    StreamArn?: string;
    StreamLabel?: string;
    StreamStatus?: StreamStatus;
    StreamViewType?: StreamViewType;
    CreationRequestDateTime?: Date;
    TableName?: string;
    KeySchema?: KeySchemaElement[];
    Shards?: Shard[];
    LastEvaluatedShardId?: string;
}
export declare const StreamDescription: S.Schema<StreamDescription>;
export interface DescribeStreamOutput {
    StreamDescription?: StreamDescription;
}
export declare const DescribeStreamOutput: S.Schema<DescribeStreamOutput>;
export type ShardIterator = string;
export interface GetRecordsInput {
    ShardIterator: string;
    Limit?: number;
}
export declare const GetRecordsInput: S.Schema<GetRecordsInput>;
export type OperationType = "INSERT" | "MODIFY" | "REMOVE" | (string & {});
export declare const OperationType: any;
export type AttributeName = string;
export type StringAttributeValue = string;
export type NumberAttributeValue = string;
export type BinaryAttributeValue = Uint8Array;
export type StringSetAttributeValue = string[];
export declare const StringSetAttributeValue: any;
export type NumberSetAttributeValue = string[];
export declare const NumberSetAttributeValue: any;
export type BinarySetAttributeValue = Uint8Array[];
export declare const BinarySetAttributeValue: any;
export type MapAttributeValue = {
    [key: string]: AttributeValue | undefined;
};
export declare const MapAttributeValue: S.Schema<MapAttributeValue>;
export type ListAttributeValue = AttributeValue[];
export declare const ListAttributeValue: S.Schema<ListAttributeValue>;
export type NullAttributeValue = boolean;
export type BooleanAttributeValue = boolean;
export type AttributeValue = {
    S: string;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N: string;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B: Uint8Array;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS: string[];
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS: string[];
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS: Uint8Array[];
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M: {
        [key: string]: AttributeValue | undefined;
    };
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L: AttributeValue[];
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL: boolean;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL: boolean;
};
export declare const AttributeValue: S.Schema<AttributeValue>;
export type AttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export declare const AttributeMap: any;
export type PositiveLongObject = number;
export interface StreamRecord {
    ApproximateCreationDateTime?: Date;
    Keys?: {
        [key: string]: AttributeValue | undefined;
    };
    NewImage?: {
        [key: string]: AttributeValue | undefined;
    };
    OldImage?: {
        [key: string]: AttributeValue | undefined;
    };
    SequenceNumber?: string;
    SizeBytes?: number;
    StreamViewType?: StreamViewType;
}
export declare const StreamRecord: S.Schema<StreamRecord>;
export interface Identity {
    PrincipalId?: string;
    Type?: string;
}
export declare const Identity: S.Schema<Identity>;
export interface Record {
    eventID?: string;
    eventName?: OperationType;
    eventVersion?: string;
    eventSource?: string;
    awsRegion?: string;
    dynamodb?: StreamRecord;
    userIdentity?: Identity;
}
export declare const Record: S.Schema<Record>;
export type RecordList = Record[];
export declare const RecordList: any;
export interface GetRecordsOutput {
    Records?: Record[];
    NextShardIterator?: string;
}
export declare const GetRecordsOutput: S.Schema<GetRecordsOutput>;
export type ShardIteratorType = "TRIM_HORIZON" | "LATEST" | "AT_SEQUENCE_NUMBER" | "AFTER_SEQUENCE_NUMBER" | (string & {});
export declare const ShardIteratorType: any;
export interface GetShardIteratorInput {
    StreamArn: string;
    ShardId: string;
    ShardIteratorType: ShardIteratorType;
    SequenceNumber?: string;
}
export declare const GetShardIteratorInput: S.Schema<GetShardIteratorInput>;
export interface GetShardIteratorOutput {
    ShardIterator?: string;
}
export declare const GetShardIteratorOutput: S.Schema<GetShardIteratorOutput>;
export interface ListStreamsInput {
    TableName?: string;
    Limit?: number;
    ExclusiveStartStreamArn?: string;
}
export declare const ListStreamsInput: S.Schema<ListStreamsInput>;
export interface Stream {
    StreamArn?: string;
    TableName?: string;
    StreamLabel?: string;
}
export declare const Stream: S.Schema<Stream>;
export type StreamList = Stream[];
export declare const StreamList: any;
export interface ListStreamsOutput {
    Streams?: Stream[];
    LastEvaluatedStreamArn?: string;
}
export declare const ListStreamsOutput: S.Schema<ListStreamsOutput>;
export type ErrorMessage = string;
export type DescribeStreamError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about a stream, including the current status of the stream, its Amazon Resource Name (ARN), the composition of its shards, and its corresponding DynamoDB table.
 *
 * You can call `DescribeStream` at a maximum rate of 10 times per second.
 *
 * Each shard in the stream has a `SequenceNumberRange` associated with it. If the
 * `SequenceNumberRange` has a `StartingSequenceNumber` but no
 * `EndingSequenceNumber`, then the shard is still open (able to receive more stream
 * records). If both `StartingSequenceNumber` and `EndingSequenceNumber`
 * are present, then that shard is closed and can no longer receive more data.
 */
export declare const describeStream: API.OperationMethod<DescribeStreamInput, DescribeStreamOutput, DescribeStreamError, Credentials | HttpClient.HttpClient>;
export type GetRecordsError = ExpiredIteratorException | InternalServerError | LimitExceededException | ResourceNotFoundException | TrimmedDataAccessException | CommonErrors;
/**
 * Retrieves the stream records from a given shard.
 *
 * Specify a shard iterator using the `ShardIterator` parameter. The shard iterator
 * specifies the position in the shard from which you want to start reading stream records
 * sequentially. If there are no stream records available in the portion of the shard that the
 * iterator points to, `GetRecords` returns an empty list. Note that it might take
 * multiple calls to get to a portion of the shard that contains stream records.
 *
 * `GetRecords` can retrieve a maximum of 1 MB of data or 1000 stream records,
 * whichever comes first.
 */
export declare const getRecords: API.OperationMethod<GetRecordsInput, GetRecordsOutput, GetRecordsError, Credentials | HttpClient.HttpClient>;
export type GetShardIteratorError = InternalServerError | ResourceNotFoundException | TrimmedDataAccessException | CommonErrors;
/**
 * Returns a shard iterator. A shard iterator provides information
 * about how to retrieve the stream records from within a shard. Use
 * the shard iterator in a subsequent
 * `GetRecords` request to read the stream records
 * from the shard.
 *
 * A shard iterator expires 15 minutes after it is returned to the requester.
 */
export declare const getShardIterator: API.OperationMethod<GetShardIteratorInput, GetShardIteratorOutput, GetShardIteratorError, Credentials | HttpClient.HttpClient>;
export type ListStreamsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns an array of stream ARNs associated with the current account and endpoint. If the
 * `TableName` parameter is present, then `ListStreams` will return only the
 * streams ARNs for that table.
 *
 * You can call `ListStreams` at a maximum rate of 5 times per second.
 */
export declare const listStreams: API.OperationMethod<ListStreamsInput, ListStreamsOutput, ListStreamsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dynamodb-streams.d.ts.map