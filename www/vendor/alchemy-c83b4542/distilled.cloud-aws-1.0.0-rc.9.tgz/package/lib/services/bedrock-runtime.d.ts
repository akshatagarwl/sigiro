import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as stream from "effect/Stream";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ModelErrorException_base: S.Class<ModelErrorException, S.TaggedStruct<"ModelErrorException", {
    readonly message: any;
    readonly originalStatusCode: any;
    readonly resourceName: any;
}>, import("effect/Cause").YieldableError>;
export declare class ModelErrorException extends /*@__PURE__*/ ModelErrorException_base {
}
declare const ModelNotReadyException_base: S.Class<ModelNotReadyException, S.TaggedStruct<"ModelNotReadyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ModelNotReadyException extends /*@__PURE__*/ ModelNotReadyException_base {
}
declare const ModelStreamErrorException_base: S.Class<ModelStreamErrorException, S.TaggedStruct<"ModelStreamErrorException", {
    readonly message: any;
    readonly originalStatusCode: any;
    readonly originalMessage: any;
}>, import("effect/Cause").YieldableError>;
export declare class ModelStreamErrorException extends /*@__PURE__*/ ModelStreamErrorException_base {
}
declare const ModelTimeoutException_base: S.Class<ModelTimeoutException, S.TaggedStruct<"ModelTimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class ModelTimeoutException extends /*@__PURE__*/ ModelTimeoutException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GuardrailIdentifier = string;
export type GuardrailVersion = string;
export type GuardrailContentSource = "INPUT" | "OUTPUT" | (string & {});
export declare const GuardrailContentSource: any;
export type GuardrailContentQualifier = "grounding_source" | "query" | "guard_content" | (string & {});
export declare const GuardrailContentQualifier: any;
export type GuardrailContentQualifierList = GuardrailContentQualifier[];
export declare const GuardrailContentQualifierList: any;
export interface GuardrailTextBlock {
    text: string;
    qualifiers?: GuardrailContentQualifier[];
}
export declare const GuardrailTextBlock: S.Schema<GuardrailTextBlock>;
export type GuardrailImageFormat = "png" | "jpeg" | (string & {});
export declare const GuardrailImageFormat: any;
export type GuardrailImageSource = {
    bytes: Uint8Array;
};
export declare const GuardrailImageSource: any;
export interface GuardrailImageBlock {
    format: GuardrailImageFormat;
    source: GuardrailImageSource;
}
export declare const GuardrailImageBlock: S.Schema<GuardrailImageBlock>;
export type GuardrailContentBlock = {
    text: GuardrailTextBlock;
    image?: never;
} | {
    text?: never;
    image: GuardrailImageBlock;
};
export declare const GuardrailContentBlock: any;
export type GuardrailContentBlockList = GuardrailContentBlock[];
export declare const GuardrailContentBlockList: any;
export type GuardrailOutputScope = "INTERVENTIONS" | "FULL" | (string & {});
export declare const GuardrailOutputScope: any;
export interface ApplyGuardrailRequest {
    guardrailIdentifier: string;
    guardrailVersion: string;
    source: GuardrailContentSource;
    content: GuardrailContentBlock[];
    outputScope?: GuardrailOutputScope;
}
export declare const ApplyGuardrailRequest: S.Schema<ApplyGuardrailRequest>;
export type GuardrailTopicPolicyUnitsProcessed = number;
export type GuardrailContentPolicyUnitsProcessed = number;
export type GuardrailWordPolicyUnitsProcessed = number;
export type GuardrailSensitiveInformationPolicyUnitsProcessed = number;
export type GuardrailSensitiveInformationPolicyFreeUnitsProcessed = number;
export type GuardrailContextualGroundingPolicyUnitsProcessed = number;
export type GuardrailContentPolicyImageUnitsProcessed = number;
export type GuardrailAutomatedReasoningPolicyUnitsProcessed = number;
export type GuardrailAutomatedReasoningPoliciesProcessed = number;
export interface GuardrailUsage {
    topicPolicyUnits: number;
    contentPolicyUnits: number;
    wordPolicyUnits: number;
    sensitiveInformationPolicyUnits: number;
    sensitiveInformationPolicyFreeUnits: number;
    contextualGroundingPolicyUnits: number;
    contentPolicyImageUnits?: number;
    automatedReasoningPolicyUnits?: number;
    automatedReasoningPolicies?: number;
}
export declare const GuardrailUsage: S.Schema<GuardrailUsage>;
export type GuardrailAction = "NONE" | "GUARDRAIL_INTERVENED" | (string & {});
export declare const GuardrailAction: any;
export type GuardrailOutputText = string;
export interface GuardrailOutputContent {
    text?: string;
}
export declare const GuardrailOutputContent: S.Schema<GuardrailOutputContent>;
export type GuardrailOutputContentList = GuardrailOutputContent[];
export declare const GuardrailOutputContentList: any;
export type GuardrailTopicType = "DENY" | (string & {});
export declare const GuardrailTopicType: any;
export type GuardrailTopicPolicyAction = "BLOCKED" | "NONE" | (string & {});
export declare const GuardrailTopicPolicyAction: any;
export interface GuardrailTopic {
    name: string;
    type: GuardrailTopicType;
    action: GuardrailTopicPolicyAction;
    detected?: boolean;
}
export declare const GuardrailTopic: S.Schema<GuardrailTopic>;
export type GuardrailTopicList = GuardrailTopic[];
export declare const GuardrailTopicList: any;
export interface GuardrailTopicPolicyAssessment {
    topics: GuardrailTopic[];
}
export declare const GuardrailTopicPolicyAssessment: S.Schema<GuardrailTopicPolicyAssessment>;
export type GuardrailContentFilterType = "INSULTS" | "HATE" | "SEXUAL" | "VIOLENCE" | "MISCONDUCT" | "PROMPT_ATTACK" | (string & {});
export declare const GuardrailContentFilterType: any;
export type GuardrailContentFilterConfidence = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export declare const GuardrailContentFilterConfidence: any;
export type GuardrailContentFilterStrength = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export declare const GuardrailContentFilterStrength: any;
export type GuardrailContentPolicyAction = "BLOCKED" | "NONE" | (string & {});
export declare const GuardrailContentPolicyAction: any;
export interface GuardrailContentFilter {
    type: GuardrailContentFilterType;
    confidence: GuardrailContentFilterConfidence;
    filterStrength?: GuardrailContentFilterStrength;
    action: GuardrailContentPolicyAction;
    detected?: boolean;
}
export declare const GuardrailContentFilter: S.Schema<GuardrailContentFilter>;
export type GuardrailContentFilterList = GuardrailContentFilter[];
export declare const GuardrailContentFilterList: any;
export interface GuardrailContentPolicyAssessment {
    filters: GuardrailContentFilter[];
}
export declare const GuardrailContentPolicyAssessment: S.Schema<GuardrailContentPolicyAssessment>;
export type GuardrailWordPolicyAction = "BLOCKED" | "NONE" | (string & {});
export declare const GuardrailWordPolicyAction: any;
export interface GuardrailCustomWord {
    match: string;
    action: GuardrailWordPolicyAction;
    detected?: boolean;
}
export declare const GuardrailCustomWord: S.Schema<GuardrailCustomWord>;
export type GuardrailCustomWordList = GuardrailCustomWord[];
export declare const GuardrailCustomWordList: any;
export type GuardrailManagedWordType = "PROFANITY" | (string & {});
export declare const GuardrailManagedWordType: any;
export interface GuardrailManagedWord {
    match: string;
    type: GuardrailManagedWordType;
    action: GuardrailWordPolicyAction;
    detected?: boolean;
}
export declare const GuardrailManagedWord: S.Schema<GuardrailManagedWord>;
export type GuardrailManagedWordList = GuardrailManagedWord[];
export declare const GuardrailManagedWordList: any;
export interface GuardrailWordPolicyAssessment {
    customWords: GuardrailCustomWord[];
    managedWordLists: GuardrailManagedWord[];
}
export declare const GuardrailWordPolicyAssessment: S.Schema<GuardrailWordPolicyAssessment>;
export type GuardrailPiiEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export declare const GuardrailPiiEntityType: any;
export type GuardrailSensitiveInformationPolicyAction = "ANONYMIZED" | "BLOCKED" | "NONE" | (string & {});
export declare const GuardrailSensitiveInformationPolicyAction: any;
export interface GuardrailPiiEntityFilter {
    match: string;
    type: GuardrailPiiEntityType;
    action: GuardrailSensitiveInformationPolicyAction;
    detected?: boolean;
}
export declare const GuardrailPiiEntityFilter: S.Schema<GuardrailPiiEntityFilter>;
export type GuardrailPiiEntityFilterList = GuardrailPiiEntityFilter[];
export declare const GuardrailPiiEntityFilterList: any;
export interface GuardrailRegexFilter {
    name?: string;
    match?: string;
    regex?: string;
    action: GuardrailSensitiveInformationPolicyAction;
    detected?: boolean;
}
export declare const GuardrailRegexFilter: S.Schema<GuardrailRegexFilter>;
export type GuardrailRegexFilterList = GuardrailRegexFilter[];
export declare const GuardrailRegexFilterList: any;
export interface GuardrailSensitiveInformationPolicyAssessment {
    piiEntities: GuardrailPiiEntityFilter[];
    regexes: GuardrailRegexFilter[];
}
export declare const GuardrailSensitiveInformationPolicyAssessment: S.Schema<GuardrailSensitiveInformationPolicyAssessment>;
export type GuardrailContextualGroundingFilterType = "GROUNDING" | "RELEVANCE" | (string & {});
export declare const GuardrailContextualGroundingFilterType: any;
export type GuardrailContextualGroundingPolicyAction = "BLOCKED" | "NONE" | (string & {});
export declare const GuardrailContextualGroundingPolicyAction: any;
export interface GuardrailContextualGroundingFilter {
    type: GuardrailContextualGroundingFilterType;
    threshold: number;
    score: number;
    action: GuardrailContextualGroundingPolicyAction;
    detected?: boolean;
}
export declare const GuardrailContextualGroundingFilter: S.Schema<GuardrailContextualGroundingFilter>;
export type GuardrailContextualGroundingFilters = GuardrailContextualGroundingFilter[];
export declare const GuardrailContextualGroundingFilters: any;
export interface GuardrailContextualGroundingPolicyAssessment {
    filters?: GuardrailContextualGroundingFilter[];
}
export declare const GuardrailContextualGroundingPolicyAssessment: S.Schema<GuardrailContextualGroundingPolicyAssessment>;
export type GuardrailAutomatedReasoningStatementLogicContent = string | redacted.Redacted<string>;
export type GuardrailAutomatedReasoningStatementNaturalLanguageContent = string | redacted.Redacted<string>;
export interface GuardrailAutomatedReasoningStatement {
    logic?: string | redacted.Redacted<string>;
    naturalLanguage?: string | redacted.Redacted<string>;
}
export declare const GuardrailAutomatedReasoningStatement: S.Schema<GuardrailAutomatedReasoningStatement>;
export type GuardrailAutomatedReasoningStatementList = GuardrailAutomatedReasoningStatement[];
export declare const GuardrailAutomatedReasoningStatementList: any;
export interface GuardrailAutomatedReasoningInputTextReference {
    text?: string | redacted.Redacted<string>;
}
export declare const GuardrailAutomatedReasoningInputTextReference: S.Schema<GuardrailAutomatedReasoningInputTextReference>;
export type GuardrailAutomatedReasoningInputTextReferenceList = GuardrailAutomatedReasoningInputTextReference[];
export declare const GuardrailAutomatedReasoningInputTextReferenceList: any;
export type GuardrailAutomatedReasoningTranslationConfidence = number;
export interface GuardrailAutomatedReasoningTranslation {
    premises?: GuardrailAutomatedReasoningStatement[];
    claims?: GuardrailAutomatedReasoningStatement[];
    untranslatedPremises?: GuardrailAutomatedReasoningInputTextReference[];
    untranslatedClaims?: GuardrailAutomatedReasoningInputTextReference[];
    confidence?: number;
}
export declare const GuardrailAutomatedReasoningTranslation: S.Schema<GuardrailAutomatedReasoningTranslation>;
export interface GuardrailAutomatedReasoningScenario {
    statements?: GuardrailAutomatedReasoningStatement[];
}
export declare const GuardrailAutomatedReasoningScenario: S.Schema<GuardrailAutomatedReasoningScenario>;
export type AutomatedReasoningRuleIdentifier = string;
export type GuardrailAutomatedReasoningPolicyVersionArn = string;
export interface GuardrailAutomatedReasoningRule {
    identifier?: string;
    policyVersionArn?: string;
}
export declare const GuardrailAutomatedReasoningRule: S.Schema<GuardrailAutomatedReasoningRule>;
export type GuardrailAutomatedReasoningRuleList = GuardrailAutomatedReasoningRule[];
export declare const GuardrailAutomatedReasoningRuleList: any;
export type GuardrailAutomatedReasoningLogicWarningType = "ALWAYS_FALSE" | "ALWAYS_TRUE" | (string & {});
export declare const GuardrailAutomatedReasoningLogicWarningType: any;
export interface GuardrailAutomatedReasoningLogicWarning {
    type?: GuardrailAutomatedReasoningLogicWarningType;
    premises?: GuardrailAutomatedReasoningStatement[];
    claims?: GuardrailAutomatedReasoningStatement[];
}
export declare const GuardrailAutomatedReasoningLogicWarning: S.Schema<GuardrailAutomatedReasoningLogicWarning>;
export interface GuardrailAutomatedReasoningValidFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    claimsTrueScenario?: GuardrailAutomatedReasoningScenario;
    supportingRules?: GuardrailAutomatedReasoningRule[];
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export declare const GuardrailAutomatedReasoningValidFinding: S.Schema<GuardrailAutomatedReasoningValidFinding>;
export interface GuardrailAutomatedReasoningInvalidFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    contradictingRules?: GuardrailAutomatedReasoningRule[];
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export declare const GuardrailAutomatedReasoningInvalidFinding: S.Schema<GuardrailAutomatedReasoningInvalidFinding>;
export interface GuardrailAutomatedReasoningSatisfiableFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    claimsTrueScenario?: GuardrailAutomatedReasoningScenario;
    claimsFalseScenario?: GuardrailAutomatedReasoningScenario;
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export declare const GuardrailAutomatedReasoningSatisfiableFinding: S.Schema<GuardrailAutomatedReasoningSatisfiableFinding>;
export interface GuardrailAutomatedReasoningImpossibleFinding {
    translation?: GuardrailAutomatedReasoningTranslation;
    contradictingRules?: GuardrailAutomatedReasoningRule[];
    logicWarning?: GuardrailAutomatedReasoningLogicWarning;
}
export declare const GuardrailAutomatedReasoningImpossibleFinding: S.Schema<GuardrailAutomatedReasoningImpossibleFinding>;
export type GuardrailAutomatedReasoningTranslationList = GuardrailAutomatedReasoningTranslation[];
export declare const GuardrailAutomatedReasoningTranslationList: any;
export interface GuardrailAutomatedReasoningTranslationOption {
    translations?: GuardrailAutomatedReasoningTranslation[];
}
export declare const GuardrailAutomatedReasoningTranslationOption: S.Schema<GuardrailAutomatedReasoningTranslationOption>;
export type GuardrailAutomatedReasoningTranslationOptionList = GuardrailAutomatedReasoningTranslationOption[];
export declare const GuardrailAutomatedReasoningTranslationOptionList: any;
export type GuardrailAutomatedReasoningDifferenceScenarioList = GuardrailAutomatedReasoningScenario[];
export declare const GuardrailAutomatedReasoningDifferenceScenarioList: any;
export interface GuardrailAutomatedReasoningTranslationAmbiguousFinding {
    options?: GuardrailAutomatedReasoningTranslationOption[];
    differenceScenarios?: GuardrailAutomatedReasoningScenario[];
}
export declare const GuardrailAutomatedReasoningTranslationAmbiguousFinding: S.Schema<GuardrailAutomatedReasoningTranslationAmbiguousFinding>;
export interface GuardrailAutomatedReasoningTooComplexFinding {
}
export declare const GuardrailAutomatedReasoningTooComplexFinding: S.Schema<GuardrailAutomatedReasoningTooComplexFinding>;
export interface GuardrailAutomatedReasoningNoTranslationsFinding {
}
export declare const GuardrailAutomatedReasoningNoTranslationsFinding: S.Schema<GuardrailAutomatedReasoningNoTranslationsFinding>;
export type GuardrailAutomatedReasoningFinding = {
    valid: GuardrailAutomatedReasoningValidFinding;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid: GuardrailAutomatedReasoningInvalidFinding;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable: GuardrailAutomatedReasoningSatisfiableFinding;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible: GuardrailAutomatedReasoningImpossibleFinding;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous: GuardrailAutomatedReasoningTranslationAmbiguousFinding;
    tooComplex?: never;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex: GuardrailAutomatedReasoningTooComplexFinding;
    noTranslations?: never;
} | {
    valid?: never;
    invalid?: never;
    satisfiable?: never;
    impossible?: never;
    translationAmbiguous?: never;
    tooComplex?: never;
    noTranslations: GuardrailAutomatedReasoningNoTranslationsFinding;
};
export declare const GuardrailAutomatedReasoningFinding: any;
export type GuardrailAutomatedReasoningFindingList = GuardrailAutomatedReasoningFinding[];
export declare const GuardrailAutomatedReasoningFindingList: any;
export interface GuardrailAutomatedReasoningPolicyAssessment {
    findings?: GuardrailAutomatedReasoningFinding[];
}
export declare const GuardrailAutomatedReasoningPolicyAssessment: S.Schema<GuardrailAutomatedReasoningPolicyAssessment>;
export type GuardrailProcessingLatency = number;
export type TextCharactersGuarded = number;
export type TextCharactersTotal = number;
export interface GuardrailTextCharactersCoverage {
    guarded?: number;
    total?: number;
}
export declare const GuardrailTextCharactersCoverage: S.Schema<GuardrailTextCharactersCoverage>;
export type ImagesGuarded = number;
export type ImagesTotal = number;
export interface GuardrailImageCoverage {
    guarded?: number;
    total?: number;
}
export declare const GuardrailImageCoverage: S.Schema<GuardrailImageCoverage>;
export interface GuardrailCoverage {
    textCharacters?: GuardrailTextCharactersCoverage;
    images?: GuardrailImageCoverage;
}
export declare const GuardrailCoverage: S.Schema<GuardrailCoverage>;
export interface GuardrailInvocationMetrics {
    guardrailProcessingLatency?: number;
    usage?: GuardrailUsage;
    guardrailCoverage?: GuardrailCoverage;
}
export declare const GuardrailInvocationMetrics: S.Schema<GuardrailInvocationMetrics>;
export type GuardrailId = string;
export type GuardrailArn = string;
export type GuardrailOrigin = "REQUEST" | "ACCOUNT_ENFORCED" | "ORGANIZATION_ENFORCED" | (string & {});
export declare const GuardrailOrigin: any;
export type GuardrailOriginList = GuardrailOrigin[];
export declare const GuardrailOriginList: any;
export type GuardrailOwnership = "SELF" | "CROSS_ACCOUNT" | (string & {});
export declare const GuardrailOwnership: any;
export interface AppliedGuardrailDetails {
    guardrailId?: string;
    guardrailVersion?: string;
    guardrailArn?: string;
    guardrailOrigin?: GuardrailOrigin[];
    guardrailOwnership?: GuardrailOwnership;
}
export declare const AppliedGuardrailDetails: S.Schema<AppliedGuardrailDetails>;
export interface GuardrailAssessment {
    topicPolicy?: GuardrailTopicPolicyAssessment;
    contentPolicy?: GuardrailContentPolicyAssessment;
    wordPolicy?: GuardrailWordPolicyAssessment;
    sensitiveInformationPolicy?: GuardrailSensitiveInformationPolicyAssessment;
    contextualGroundingPolicy?: GuardrailContextualGroundingPolicyAssessment;
    automatedReasoningPolicy?: GuardrailAutomatedReasoningPolicyAssessment;
    invocationMetrics?: GuardrailInvocationMetrics;
    appliedGuardrailDetails?: AppliedGuardrailDetails;
}
export declare const GuardrailAssessment: S.Schema<GuardrailAssessment>;
export type GuardrailAssessmentList = GuardrailAssessment[];
export declare const GuardrailAssessmentList: any;
export interface ApplyGuardrailResponse {
    usage: GuardrailUsage;
    action: GuardrailAction;
    actionReason?: string;
    outputs: GuardrailOutputContent[];
    assessments: GuardrailAssessment[];
    guardrailCoverage?: GuardrailCoverage;
}
export declare const ApplyGuardrailResponse: S.Schema<ApplyGuardrailResponse>;
export type ConversationalModelId = string;
export type ConversationRole = "user" | "assistant" | "system" | (string & {});
export declare const ConversationRole: any;
export type ImageFormat = "png" | "jpeg" | "gif" | "webp" | (string & {});
export declare const ImageFormat: any;
export type S3Uri = string;
export type AccountId = string;
export interface S3Location {
    uri: string;
    bucketOwner?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type ImageSource = {
    bytes: Uint8Array;
    s3Location?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
};
export declare const ImageSource: any;
export interface ErrorBlock {
    message?: string;
}
export declare const ErrorBlock: S.Schema<ErrorBlock>;
export interface ImageBlock {
    format: ImageFormat;
    source: ImageSource;
    error?: ErrorBlock;
}
export declare const ImageBlock: S.Schema<ImageBlock>;
export type DocumentFormat = "pdf" | "csv" | "doc" | "docx" | "xls" | "xlsx" | "html" | "txt" | "md" | (string & {});
export declare const DocumentFormat: any;
export type DocumentContentBlock = {
    text: string;
};
export declare const DocumentContentBlock: any;
export type DocumentContentBlocks = DocumentContentBlock[];
export declare const DocumentContentBlocks: any;
export type DocumentSource = {
    bytes: Uint8Array;
    s3Location?: never;
    text?: never;
    content?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
    text?: never;
    content?: never;
} | {
    bytes?: never;
    s3Location?: never;
    text: string;
    content?: never;
} | {
    bytes?: never;
    s3Location?: never;
    text?: never;
    content: DocumentContentBlock[];
};
export declare const DocumentSource: any;
export interface CitationsConfig {
    enabled: boolean;
}
export declare const CitationsConfig: S.Schema<CitationsConfig>;
export interface DocumentBlock {
    format?: DocumentFormat;
    name: string;
    source: DocumentSource;
    context?: string;
    citations?: CitationsConfig;
}
export declare const DocumentBlock: S.Schema<DocumentBlock>;
export type VideoFormat = "mkv" | "mov" | "mp4" | "webm" | "flv" | "mpeg" | "mpg" | "wmv" | "three_gp" | (string & {});
export declare const VideoFormat: any;
export type VideoSource = {
    bytes: Uint8Array;
    s3Location?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
};
export declare const VideoSource: any;
export interface VideoBlock {
    format: VideoFormat;
    source: VideoSource;
}
export declare const VideoBlock: S.Schema<VideoBlock>;
export type AudioFormat = "mp3" | "opus" | "wav" | "aac" | "flac" | "mp4" | "ogg" | "mkv" | "mka" | "x-aac" | "m4a" | "mpeg" | "mpga" | "pcm" | "webm" | (string & {});
export declare const AudioFormat: any;
export type AudioSource = {
    bytes: Uint8Array;
    s3Location?: never;
} | {
    bytes?: never;
    s3Location: S3Location;
};
export declare const AudioSource: any;
export interface AudioBlock {
    format: AudioFormat;
    source: AudioSource;
    error?: ErrorBlock;
}
export declare const AudioBlock: S.Schema<AudioBlock>;
export type ToolUseId = string;
export type ToolName = string;
export type ToolUseType = "server_tool_use" | (string & {});
export declare const ToolUseType: any;
export interface ToolUseBlock {
    toolUseId: string;
    name: string;
    input: any;
    type?: ToolUseType;
}
export declare const ToolUseBlock: S.Schema<ToolUseBlock>;
export interface SearchResultContentBlock {
    text: string;
}
export declare const SearchResultContentBlock: S.Schema<SearchResultContentBlock>;
export type SearchResultContentBlocks = SearchResultContentBlock[];
export declare const SearchResultContentBlocks: any;
export interface SearchResultBlock {
    source: string;
    title: string;
    content: SearchResultContentBlock[];
    citations?: CitationsConfig;
}
export declare const SearchResultBlock: S.Schema<SearchResultBlock>;
export type ToolResultContentBlock = {
    json: any;
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text: string;
    image?: never;
    document?: never;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image: ImageBlock;
    document?: never;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image?: never;
    document: DocumentBlock;
    video?: never;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image?: never;
    document?: never;
    video: VideoBlock;
    searchResult?: never;
} | {
    json?: never;
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    searchResult: SearchResultBlock;
};
export declare const ToolResultContentBlock: any;
export type ToolResultContentBlocks = ToolResultContentBlock[];
export declare const ToolResultContentBlocks: any;
export type ToolResultStatus = "success" | "error" | (string & {});
export declare const ToolResultStatus: any;
export interface ToolResultBlock {
    toolUseId: string;
    content: ToolResultContentBlock[];
    status?: ToolResultStatus;
    type?: string;
}
export declare const ToolResultBlock: S.Schema<ToolResultBlock>;
export type GuardrailConverseContentQualifier = "grounding_source" | "query" | "guard_content" | (string & {});
export declare const GuardrailConverseContentQualifier: any;
export type GuardrailConverseContentQualifierList = GuardrailConverseContentQualifier[];
export declare const GuardrailConverseContentQualifierList: any;
export interface GuardrailConverseTextBlock {
    text: string;
    qualifiers?: GuardrailConverseContentQualifier[];
}
export declare const GuardrailConverseTextBlock: S.Schema<GuardrailConverseTextBlock>;
export type GuardrailConverseImageFormat = "png" | "jpeg" | (string & {});
export declare const GuardrailConverseImageFormat: any;
export type GuardrailConverseImageSource = {
    bytes: Uint8Array;
};
export declare const GuardrailConverseImageSource: any;
export interface GuardrailConverseImageBlock {
    format: GuardrailConverseImageFormat;
    source: GuardrailConverseImageSource;
}
export declare const GuardrailConverseImageBlock: S.Schema<GuardrailConverseImageBlock>;
export type GuardrailConverseContentBlock = {
    text: GuardrailConverseTextBlock;
    image?: never;
} | {
    text?: never;
    image: GuardrailConverseImageBlock;
};
export declare const GuardrailConverseContentBlock: any;
export type CachePointType = "default" | (string & {});
export declare const CachePointType: any;
export type CacheTTL = "5m" | "1h" | (string & {});
export declare const CacheTTL: any;
export interface CachePointBlock {
    type: CachePointType;
    ttl?: CacheTTL;
}
export declare const CachePointBlock: S.Schema<CachePointBlock>;
export interface ReasoningTextBlock {
    text: string;
    signature?: string;
}
export declare const ReasoningTextBlock: S.Schema<ReasoningTextBlock>;
export type ReasoningContentBlock = {
    reasoningText: ReasoningTextBlock;
    redactedContent?: never;
} | {
    reasoningText?: never;
    redactedContent: Uint8Array;
};
export declare const ReasoningContentBlock: any;
export type CitationGeneratedContent = {
    text: string;
};
export declare const CitationGeneratedContent: any;
export type CitationGeneratedContentList = CitationGeneratedContent[];
export declare const CitationGeneratedContentList: any;
export type CitationSourceContent = {
    text: string;
};
export declare const CitationSourceContent: any;
export type CitationSourceContentList = CitationSourceContent[];
export declare const CitationSourceContentList: any;
export interface WebLocation {
    url?: string;
    domain?: string;
}
export declare const WebLocation: S.Schema<WebLocation>;
export interface DocumentCharLocation {
    documentIndex?: number;
    start?: number;
    end?: number;
}
export declare const DocumentCharLocation: S.Schema<DocumentCharLocation>;
export interface DocumentPageLocation {
    documentIndex?: number;
    start?: number;
    end?: number;
}
export declare const DocumentPageLocation: S.Schema<DocumentPageLocation>;
export interface DocumentChunkLocation {
    documentIndex?: number;
    start?: number;
    end?: number;
}
export declare const DocumentChunkLocation: S.Schema<DocumentChunkLocation>;
export interface SearchResultLocation {
    searchResultIndex?: number;
    start?: number;
    end?: number;
}
export declare const SearchResultLocation: S.Schema<SearchResultLocation>;
export type CitationLocation = {
    web: WebLocation;
    documentChar?: never;
    documentPage?: never;
    documentChunk?: never;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar: DocumentCharLocation;
    documentPage?: never;
    documentChunk?: never;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar?: never;
    documentPage: DocumentPageLocation;
    documentChunk?: never;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar?: never;
    documentPage?: never;
    documentChunk: DocumentChunkLocation;
    searchResultLocation?: never;
} | {
    web?: never;
    documentChar?: never;
    documentPage?: never;
    documentChunk?: never;
    searchResultLocation: SearchResultLocation;
};
export declare const CitationLocation: any;
export interface Citation {
    title?: string;
    source?: string;
    sourceContent?: CitationSourceContent[];
    location?: CitationLocation;
}
export declare const Citation: S.Schema<Citation>;
export type Citations = Citation[];
export declare const Citations: any;
export interface CitationsContentBlock {
    content?: CitationGeneratedContent[];
    citations?: Citation[];
}
export declare const CitationsContentBlock: S.Schema<CitationsContentBlock>;
export interface ToolReference {
    type?: string;
    name?: string;
    serverName?: string;
}
export declare const ToolReference: S.Schema<ToolReference>;
export interface ToolAdditionBlock {
    tool: ToolReference;
}
export declare const ToolAdditionBlock: S.Schema<ToolAdditionBlock>;
export interface ToolRemovalBlock {
    tool: ToolReference;
}
export declare const ToolRemovalBlock: S.Schema<ToolRemovalBlock>;
export type ContentBlock = {
    text: string;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image: ImageBlock;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document: DocumentBlock;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video: VideoBlock;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio: AudioBlock;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse: ToolUseBlock;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult: ToolResultBlock;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent: GuardrailConverseContentBlock;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint: CachePointBlock;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent: ReasoningContentBlock;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent: CitationsContentBlock;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult: SearchResultBlock;
    toolAddition?: never;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition: ToolAdditionBlock;
    toolRemoval?: never;
} | {
    text?: never;
    image?: never;
    document?: never;
    video?: never;
    audio?: never;
    toolUse?: never;
    toolResult?: never;
    guardContent?: never;
    cachePoint?: never;
    reasoningContent?: never;
    citationsContent?: never;
    searchResult?: never;
    toolAddition?: never;
    toolRemoval: ToolRemovalBlock;
};
export declare const ContentBlock: any;
export type ContentBlocks = ContentBlock[];
export declare const ContentBlocks: any;
export interface Message {
    role: ConversationRole;
    content: ContentBlock[];
}
export declare const Message: S.Schema<Message>;
export type Messages = Message[];
export declare const Messages: any;
export type NonEmptyString = string;
export type SystemContentBlock = {
    text: string;
    guardContent?: never;
    cachePoint?: never;
} | {
    text?: never;
    guardContent: GuardrailConverseContentBlock;
    cachePoint?: never;
} | {
    text?: never;
    guardContent?: never;
    cachePoint: CachePointBlock;
};
export declare const SystemContentBlock: any;
export type SystemContentBlocks = SystemContentBlock[];
export declare const SystemContentBlocks: any;
export type NonEmptyStringList = string[];
export declare const NonEmptyStringList: any;
export interface InferenceConfiguration {
    maxTokens?: number;
    temperature?: number;
    topP?: number;
    stopSequences?: string[];
}
export declare const InferenceConfiguration: S.Schema<InferenceConfiguration>;
export type ToolInputSchema = {
    json: any;
};
export declare const ToolInputSchema: any;
export interface ToolSpecification {
    name: string;
    description?: string;
    inputSchema: ToolInputSchema;
    strict?: boolean;
}
export declare const ToolSpecification: S.Schema<ToolSpecification>;
export interface SystemTool {
    name: string;
}
export declare const SystemTool: S.Schema<SystemTool>;
export type Tool = {
    toolSpec: ToolSpecification;
    systemTool?: never;
    cachePoint?: never;
} | {
    toolSpec?: never;
    systemTool: SystemTool;
    cachePoint?: never;
} | {
    toolSpec?: never;
    systemTool?: never;
    cachePoint: CachePointBlock;
};
export declare const Tool: any;
export type Tools = Tool[];
export declare const Tools: any;
export interface AutoToolChoice {
}
export declare const AutoToolChoice: S.Schema<AutoToolChoice>;
export interface AnyToolChoice {
}
export declare const AnyToolChoice: S.Schema<AnyToolChoice>;
export interface SpecificToolChoice {
    name: string;
}
export declare const SpecificToolChoice: S.Schema<SpecificToolChoice>;
export type ToolChoice = {
    auto: AutoToolChoice;
    any?: never;
    tool?: never;
} | {
    auto?: never;
    any: AnyToolChoice;
    tool?: never;
} | {
    auto?: never;
    any?: never;
    tool: SpecificToolChoice;
};
export declare const ToolChoice: any;
export interface ToolConfiguration {
    tools: Tool[];
    toolChoice?: ToolChoice;
}
export declare const ToolConfiguration: S.Schema<ToolConfiguration>;
export type GuardrailTrace = "enabled" | "disabled" | "enabled_full" | (string & {});
export declare const GuardrailTrace: any;
export interface GuardrailConfiguration {
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    trace?: GuardrailTrace;
}
export declare const GuardrailConfiguration: S.Schema<GuardrailConfiguration>;
export type PromptVariableValues = {
    text: string;
};
export declare const PromptVariableValues: any;
export type PromptVariableMap = {
    [key: string]: PromptVariableValues | undefined;
};
export declare const PromptVariableMap: any;
export type AdditionalModelResponseFieldPaths = string[];
export declare const AdditionalModelResponseFieldPaths: any;
export type RequestMetadata = {
    [key: string]: string | undefined;
};
export declare const RequestMetadata: any;
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export declare const PerformanceConfigLatency: any;
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency;
}
export declare const PerformanceConfiguration: S.Schema<PerformanceConfiguration>;
export type ServiceTierType = "priority" | "default" | "flex" | "reserved" | (string & {});
export declare const ServiceTierType: any;
export interface ServiceTier {
    type: ServiceTierType;
}
export declare const ServiceTier: S.Schema<ServiceTier>;
export type OutputFormatType = "json_schema" | (string & {});
export declare const OutputFormatType: any;
export interface JsonSchemaDefinition {
    schema: string;
    name?: string;
    description?: string;
}
export declare const JsonSchemaDefinition: S.Schema<JsonSchemaDefinition>;
export type OutputFormatStructure = {
    jsonSchema: JsonSchemaDefinition;
};
export declare const OutputFormatStructure: any;
export interface OutputFormat {
    type: OutputFormatType;
    structure: OutputFormatStructure;
}
export declare const OutputFormat: S.Schema<OutputFormat>;
export interface OutputConfig {
    textFormat?: OutputFormat;
    effort?: string;
}
export declare const OutputConfig: S.Schema<OutputConfig>;
export interface ConverseRequest {
    modelId: string;
    messages?: Message[];
    system?: SystemContentBlock[];
    inferenceConfig?: InferenceConfiguration;
    toolConfig?: ToolConfiguration;
    guardrailConfig?: GuardrailConfiguration;
    additionalModelRequestFields?: any;
    promptVariables?: {
        [key: string]: PromptVariableValues | undefined;
    };
    additionalModelResponseFieldPaths?: string[];
    requestMetadata?: {
        [key: string]: string | undefined;
    };
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
    outputConfig?: OutputConfig;
}
export declare const ConverseRequest: S.Schema<ConverseRequest>;
export type ConverseOutput = {
    message: Message;
};
export declare const ConverseOutput: any;
export type StopReason = "end_turn" | "tool_use" | "max_tokens" | "stop_sequence" | "guardrail_intervened" | "content_filtered" | "malformed_model_output" | "malformed_tool_use" | "model_context_window_exceeded" | (string & {});
export declare const StopReason: any;
export interface CacheDetail {
    ttl: CacheTTL;
    inputTokens: number;
}
export declare const CacheDetail: S.Schema<CacheDetail>;
export type CacheDetailsList = CacheDetail[];
export declare const CacheDetailsList: any;
export interface TokenUsage {
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
    cacheReadInputTokens?: number;
    cacheWriteInputTokens?: number;
    cacheDetails?: CacheDetail[];
}
export declare const TokenUsage: S.Schema<TokenUsage>;
export interface ConverseMetrics {
    latencyMs: number;
}
export declare const ConverseMetrics: S.Schema<ConverseMetrics>;
export type ModelOutputs = string[];
export declare const ModelOutputs: any;
export type GuardrailAssessmentMap = {
    [key: string]: GuardrailAssessment | undefined;
};
export declare const GuardrailAssessmentMap: any;
export type GuardrailAssessmentListMap = {
    [key: string]: GuardrailAssessment[] | undefined;
};
export declare const GuardrailAssessmentListMap: any;
export interface GuardrailTraceAssessment {
    modelOutput?: string[];
    inputAssessment?: {
        [key: string]: GuardrailAssessment | undefined;
    };
    outputAssessments?: {
        [key: string]: GuardrailAssessment[] | undefined;
    };
    actionReason?: string;
}
export declare const GuardrailTraceAssessment: S.Schema<GuardrailTraceAssessment>;
export type InvokedModelId = string;
export interface PromptRouterTrace {
    invokedModelId?: string;
}
export declare const PromptRouterTrace: S.Schema<PromptRouterTrace>;
export interface ConverseTrace {
    guardrail?: GuardrailTraceAssessment;
    promptRouter?: PromptRouterTrace;
}
export declare const ConverseTrace: S.Schema<ConverseTrace>;
export interface ConverseResponse {
    output: ConverseOutput;
    stopReason: StopReason;
    usage: TokenUsage;
    metrics: ConverseMetrics;
    additionalModelResponseFields?: any;
    trace?: ConverseTrace;
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
}
export declare const ConverseResponse: S.Schema<ConverseResponse>;
export type GuardrailStreamProcessingMode = "sync" | "async" | (string & {});
export declare const GuardrailStreamProcessingMode: any;
export interface GuardrailStreamConfiguration {
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    trace?: GuardrailTrace;
    streamProcessingMode?: GuardrailStreamProcessingMode;
}
export declare const GuardrailStreamConfiguration: S.Schema<GuardrailStreamConfiguration>;
export interface ConverseStreamRequest {
    modelId: string;
    messages?: Message[];
    system?: SystemContentBlock[];
    inferenceConfig?: InferenceConfiguration;
    toolConfig?: ToolConfiguration;
    guardrailConfig?: GuardrailStreamConfiguration;
    additionalModelRequestFields?: any;
    promptVariables?: {
        [key: string]: PromptVariableValues | undefined;
    };
    additionalModelResponseFieldPaths?: string[];
    requestMetadata?: {
        [key: string]: string | undefined;
    };
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
    outputConfig?: OutputConfig;
}
export declare const ConverseStreamRequest: S.Schema<ConverseStreamRequest>;
export interface MessageStartEvent {
    role: ConversationRole;
}
export declare const MessageStartEvent: S.Schema<MessageStartEvent>;
export interface ToolUseBlockStart {
    toolUseId: string;
    name: string;
    type?: ToolUseType;
}
export declare const ToolUseBlockStart: S.Schema<ToolUseBlockStart>;
export interface ToolResultBlockStart {
    toolUseId: string;
    type?: string;
    status?: ToolResultStatus;
}
export declare const ToolResultBlockStart: S.Schema<ToolResultBlockStart>;
export interface ImageBlockStart {
    format: ImageFormat;
}
export declare const ImageBlockStart: S.Schema<ImageBlockStart>;
export type ContentBlockStart = {
    toolUse: ToolUseBlockStart;
    toolResult?: never;
    image?: never;
} | {
    toolUse?: never;
    toolResult: ToolResultBlockStart;
    image?: never;
} | {
    toolUse?: never;
    toolResult?: never;
    image: ImageBlockStart;
};
export declare const ContentBlockStart: any;
export type NonNegativeInteger = number;
export interface ContentBlockStartEvent {
    start: ContentBlockStart;
    contentBlockIndex: number;
}
export declare const ContentBlockStartEvent: S.Schema<ContentBlockStartEvent>;
export interface ToolUseBlockDelta {
    input: string;
}
export declare const ToolUseBlockDelta: S.Schema<ToolUseBlockDelta>;
export type ToolResultBlockDelta = {
    text: string;
    json?: never;
} | {
    text?: never;
    json: any;
};
export declare const ToolResultBlockDelta: any;
export type ToolResultBlocksDelta = ToolResultBlockDelta[];
export declare const ToolResultBlocksDelta: any;
export type ReasoningContentBlockDelta = {
    text: string;
    redactedContent?: never;
    signature?: never;
} | {
    text?: never;
    redactedContent: Uint8Array;
    signature?: never;
} | {
    text?: never;
    redactedContent?: never;
    signature: string;
};
export declare const ReasoningContentBlockDelta: any;
export interface CitationSourceContentDelta {
    text?: string;
}
export declare const CitationSourceContentDelta: S.Schema<CitationSourceContentDelta>;
export type CitationSourceContentListDelta = CitationSourceContentDelta[];
export declare const CitationSourceContentListDelta: any;
export interface CitationsDelta {
    title?: string;
    source?: string;
    sourceContent?: CitationSourceContentDelta[];
    location?: CitationLocation;
}
export declare const CitationsDelta: S.Schema<CitationsDelta>;
export interface ImageBlockDelta {
    source?: ImageSource;
    error?: ErrorBlock;
}
export declare const ImageBlockDelta: S.Schema<ImageBlockDelta>;
export type ContentBlockDelta = {
    text: string;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse: ToolUseBlockDelta;
    toolResult?: never;
    reasoningContent?: never;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult: ToolResultBlockDelta[];
    reasoningContent?: never;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent: ReasoningContentBlockDelta;
    citation?: never;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    citation: CitationsDelta;
    image?: never;
} | {
    text?: never;
    toolUse?: never;
    toolResult?: never;
    reasoningContent?: never;
    citation?: never;
    image: ImageBlockDelta;
};
export declare const ContentBlockDelta: any;
export interface ContentBlockDeltaEvent {
    delta: ContentBlockDelta;
    contentBlockIndex: number;
}
export declare const ContentBlockDeltaEvent: S.Schema<ContentBlockDeltaEvent>;
export interface ContentBlockStopEvent {
    contentBlockIndex: number;
}
export declare const ContentBlockStopEvent: S.Schema<ContentBlockStopEvent>;
export interface MessageStopEvent {
    stopReason: StopReason;
    additionalModelResponseFields?: any;
}
export declare const MessageStopEvent: S.Schema<MessageStopEvent>;
export interface ConverseStreamMetrics {
    latencyMs: number;
}
export declare const ConverseStreamMetrics: S.Schema<ConverseStreamMetrics>;
export interface ConverseStreamTrace {
    guardrail?: GuardrailTraceAssessment;
    promptRouter?: PromptRouterTrace;
}
export declare const ConverseStreamTrace: S.Schema<ConverseStreamTrace>;
export interface ConverseStreamMetadataEvent {
    usage: TokenUsage;
    metrics: ConverseStreamMetrics;
    trace?: ConverseStreamTrace;
    performanceConfig?: PerformanceConfiguration;
    serviceTier?: ServiceTier;
}
export declare const ConverseStreamMetadataEvent: S.Schema<ConverseStreamMetadataEvent>;
export type NonBlankString = string;
export type StatusCode = number;
export type ConverseStreamOutput = {
    messageStart: MessageStartEvent;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart: ContentBlockStartEvent;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta: ContentBlockDeltaEvent;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop: ContentBlockStopEvent;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop: MessageStopEvent;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata: ConverseStreamMetadataEvent;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException: InternalServerException;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException: ValidationException;
    throttlingException?: never;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException: ThrottlingException;
    serviceUnavailableException?: never;
} | {
    messageStart?: never;
    contentBlockStart?: never;
    contentBlockDelta?: never;
    contentBlockStop?: never;
    messageStop?: never;
    metadata?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    serviceUnavailableException: ServiceUnavailableException;
};
export declare const ConverseStreamOutput: S.Schema<stream.Stream<ConverseStreamOutput, Error, never>>;
export interface ConverseStreamResponse {
    stream?: stream.Stream<ConverseStreamOutput, Error, never>;
}
export declare const ConverseStreamResponse: S.Schema<ConverseStreamResponse>;
export type FoundationModelVersionIdentifier = string;
export type Body = Uint8Array | redacted.Redacted<Uint8Array>;
export interface InvokeModelTokensRequest {
    body: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const InvokeModelTokensRequest: S.Schema<InvokeModelTokensRequest>;
export interface ConverseTokensRequest {
    messages?: Message[];
    system?: SystemContentBlock[];
    toolConfig?: ToolConfiguration;
    additionalModelRequestFields?: any;
}
export declare const ConverseTokensRequest: S.Schema<ConverseTokensRequest>;
export type CountTokensInput = {
    invokeModel: InvokeModelTokensRequest;
    converse?: never;
} | {
    invokeModel?: never;
    converse: ConverseTokensRequest;
};
export declare const CountTokensInput: any;
export interface CountTokensRequest {
    modelId: string;
    input: CountTokensInput;
}
export declare const CountTokensRequest: S.Schema<CountTokensRequest>;
export interface CountTokensResponse {
    inputTokens: number;
}
export declare const CountTokensResponse: S.Schema<CountTokensResponse>;
export type InvocationArn = string;
export interface GetAsyncInvokeRequest {
    invocationArn: string;
}
export declare const GetAsyncInvokeRequest: S.Schema<GetAsyncInvokeRequest>;
export type AsyncInvokeArn = string;
export type AsyncInvokeIdempotencyToken = string;
export type AsyncInvokeStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export declare const AsyncInvokeStatus: any;
export type AsyncInvokeMessage = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export interface AsyncInvokeS3OutputDataConfig {
    s3Uri: string;
    kmsKeyId?: string;
    bucketOwner?: string;
}
export declare const AsyncInvokeS3OutputDataConfig: S.Schema<AsyncInvokeS3OutputDataConfig>;
export type AsyncInvokeOutputDataConfig = {
    s3OutputDataConfig: AsyncInvokeS3OutputDataConfig;
};
export declare const AsyncInvokeOutputDataConfig: any;
export interface GetAsyncInvokeResponse {
    invocationArn: string;
    modelArn: string;
    clientRequestToken?: string;
    status: AsyncInvokeStatus;
    failureMessage?: string | redacted.Redacted<string>;
    submitTime: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    outputDataConfig: AsyncInvokeOutputDataConfig;
}
export declare const GetAsyncInvokeResponse: S.Schema<GetAsyncInvokeResponse>;
export type GuardrailChecksRole = "user" | "assistant" | "system" | (string & {});
export declare const GuardrailChecksRole: any;
export type GuardrailChecksTextContent = string | redacted.Redacted<string>;
export type GuardrailChecksContentBlock = {
    text: string | redacted.Redacted<string>;
};
export declare const GuardrailChecksContentBlock: any;
export type GuardrailChecksContentBlockList = GuardrailChecksContentBlock[];
export declare const GuardrailChecksContentBlockList: any;
export interface GuardrailChecksMessage {
    role: GuardrailChecksRole;
    content: GuardrailChecksContentBlock[];
}
export declare const GuardrailChecksMessage: S.Schema<GuardrailChecksMessage>;
export type GuardrailChecksMessageList = GuardrailChecksMessage[];
export declare const GuardrailChecksMessageList: any;
export type GuardrailChecksContentFilterCategory = "VIOLENCE" | "HATE" | "SEXUAL" | "MISCONDUCT" | "INSULTS" | (string & {});
export declare const GuardrailChecksContentFilterCategory: any;
export interface GuardrailChecksContentFilterCategoryConfig {
    category: GuardrailChecksContentFilterCategory;
}
export declare const GuardrailChecksContentFilterCategoryConfig: S.Schema<GuardrailChecksContentFilterCategoryConfig>;
export type GuardrailChecksContentFilterCategoryConfigList = GuardrailChecksContentFilterCategoryConfig[];
export declare const GuardrailChecksContentFilterCategoryConfigList: any;
export interface GuardrailChecksContentFilterConfig {
    categories: GuardrailChecksContentFilterCategoryConfig[];
}
export declare const GuardrailChecksContentFilterConfig: S.Schema<GuardrailChecksContentFilterConfig>;
export type GuardrailChecksPromptAttackCategory = "JAILBREAK" | "PROMPT_INJECTION" | "PROMPT_LEAKAGE" | (string & {});
export declare const GuardrailChecksPromptAttackCategory: any;
export interface GuardrailChecksPromptAttackCategoryConfig {
    category: GuardrailChecksPromptAttackCategory;
}
export declare const GuardrailChecksPromptAttackCategoryConfig: S.Schema<GuardrailChecksPromptAttackCategoryConfig>;
export type GuardrailChecksPromptAttackCategoryConfigList = GuardrailChecksPromptAttackCategoryConfig[];
export declare const GuardrailChecksPromptAttackCategoryConfigList: any;
export interface GuardrailChecksPromptAttackConfig {
    categories: GuardrailChecksPromptAttackCategoryConfig[];
}
export declare const GuardrailChecksPromptAttackConfig: S.Schema<GuardrailChecksPromptAttackConfig>;
export type GuardrailChecksSensitiveInformationEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export declare const GuardrailChecksSensitiveInformationEntityType: any;
export interface GuardrailChecksSensitiveInformationEntityConfig {
    type: GuardrailChecksSensitiveInformationEntityType;
}
export declare const GuardrailChecksSensitiveInformationEntityConfig: S.Schema<GuardrailChecksSensitiveInformationEntityConfig>;
export type GuardrailChecksSensitiveInformationEntityConfigList = GuardrailChecksSensitiveInformationEntityConfig[];
export declare const GuardrailChecksSensitiveInformationEntityConfigList: any;
export interface GuardrailChecksSensitiveInformationConfig {
    entities: GuardrailChecksSensitiveInformationEntityConfig[];
}
export declare const GuardrailChecksSensitiveInformationConfig: S.Schema<GuardrailChecksSensitiveInformationConfig>;
export interface GuardrailChecksConfig {
    contentFilter?: GuardrailChecksContentFilterConfig;
    promptAttack?: GuardrailChecksPromptAttackConfig;
    sensitiveInformation?: GuardrailChecksSensitiveInformationConfig;
}
export declare const GuardrailChecksConfig: S.Schema<GuardrailChecksConfig>;
export interface InvokeGuardrailChecksRequest {
    messages: GuardrailChecksMessage[];
    checks: GuardrailChecksConfig;
}
export declare const InvokeGuardrailChecksRequest: S.Schema<InvokeGuardrailChecksRequest>;
export interface GuardrailChecksContentFilterResultEntry {
    category: GuardrailChecksContentFilterCategory;
    severityScore: number;
}
export declare const GuardrailChecksContentFilterResultEntry: S.Schema<GuardrailChecksContentFilterResultEntry>;
export type GuardrailChecksContentFilterResultList = GuardrailChecksContentFilterResultEntry[];
export declare const GuardrailChecksContentFilterResultList: any;
export interface GuardrailChecksContentFilterResult {
    results: GuardrailChecksContentFilterResultEntry[];
}
export declare const GuardrailChecksContentFilterResult: S.Schema<GuardrailChecksContentFilterResult>;
export interface GuardrailChecksPromptAttackResultEntry {
    category: GuardrailChecksPromptAttackCategory;
    severityScore: number;
}
export declare const GuardrailChecksPromptAttackResultEntry: S.Schema<GuardrailChecksPromptAttackResultEntry>;
export type GuardrailChecksPromptAttackResultList = GuardrailChecksPromptAttackResultEntry[];
export declare const GuardrailChecksPromptAttackResultList: any;
export interface GuardrailChecksPromptAttackResult {
    results: GuardrailChecksPromptAttackResultEntry[];
}
export declare const GuardrailChecksPromptAttackResult: S.Schema<GuardrailChecksPromptAttackResult>;
export interface GuardrailChecksSensitiveInformationResultEntry {
    type: GuardrailChecksSensitiveInformationEntityType;
    confidenceScore: number;
    beginOffset: number;
    endOffset: number;
    messageIndex: number;
    contentIndex: number;
}
export declare const GuardrailChecksSensitiveInformationResultEntry: S.Schema<GuardrailChecksSensitiveInformationResultEntry>;
export type GuardrailChecksSensitiveInformationResultList = GuardrailChecksSensitiveInformationResultEntry[];
export declare const GuardrailChecksSensitiveInformationResultList: any;
export interface GuardrailChecksSensitiveInformationResult {
    results: GuardrailChecksSensitiveInformationResultEntry[];
    truncated?: boolean;
}
export declare const GuardrailChecksSensitiveInformationResult: S.Schema<GuardrailChecksSensitiveInformationResult>;
export interface GuardrailChecksResults {
    contentFilter?: GuardrailChecksContentFilterResult;
    promptAttack?: GuardrailChecksPromptAttackResult;
    sensitiveInformation?: GuardrailChecksSensitiveInformationResult;
}
export declare const GuardrailChecksResults: S.Schema<GuardrailChecksResults>;
export interface GuardrailChecksContentFilterUsage {
    textUnits: number;
}
export declare const GuardrailChecksContentFilterUsage: S.Schema<GuardrailChecksContentFilterUsage>;
export interface GuardrailChecksPromptAttackUsage {
    textUnits: number;
}
export declare const GuardrailChecksPromptAttackUsage: S.Schema<GuardrailChecksPromptAttackUsage>;
export interface GuardrailChecksSensitiveInformationUsage {
    textUnits: number;
}
export declare const GuardrailChecksSensitiveInformationUsage: S.Schema<GuardrailChecksSensitiveInformationUsage>;
export interface GuardrailChecksUsageResults {
    contentFilter?: GuardrailChecksContentFilterUsage;
    promptAttack?: GuardrailChecksPromptAttackUsage;
    sensitiveInformation?: GuardrailChecksSensitiveInformationUsage;
}
export declare const GuardrailChecksUsageResults: S.Schema<GuardrailChecksUsageResults>;
export interface InvokeGuardrailChecksResponse {
    results: GuardrailChecksResults;
    usage: GuardrailChecksUsageResults;
}
export declare const InvokeGuardrailChecksResponse: S.Schema<InvokeGuardrailChecksResponse>;
export type MimeType = string;
export type InvokeModelIdentifier = string;
export type Trace = "ENABLED" | "DISABLED" | "ENABLED_FULL" | (string & {});
export declare const Trace: any;
export type RequestMetadataJson = string | redacted.Redacted<string>;
export interface InvokeModelRequest {
    body?: T.StreamingInputBody;
    contentType?: string;
    accept?: string;
    modelId: string;
    trace?: Trace;
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
    requestMetadata?: string | redacted.Redacted<string>;
}
export declare const InvokeModelRequest: S.Schema<InvokeModelRequest>;
export interface InvokeModelResponse {
    body: T.StreamingOutputBody;
    contentType: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
}
export declare const InvokeModelResponse: S.Schema<InvokeModelResponse>;
export type PartBody = Uint8Array | redacted.Redacted<Uint8Array>;
export interface BidirectionalInputPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const BidirectionalInputPayloadPart: S.Schema<BidirectionalInputPayloadPart>;
export type InvokeModelWithBidirectionalStreamInput = {
    chunk: BidirectionalInputPayloadPart;
};
export declare const InvokeModelWithBidirectionalStreamInput: S.Schema<stream.Stream<InvokeModelWithBidirectionalStreamInput, Error, never>>;
export interface InvokeModelWithBidirectionalStreamRequest {
    modelId: string;
    body: stream.Stream<InvokeModelWithBidirectionalStreamInput, Error, never>;
}
export declare const InvokeModelWithBidirectionalStreamRequest: S.Schema<InvokeModelWithBidirectionalStreamRequest>;
export interface BidirectionalOutputPayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const BidirectionalOutputPayloadPart: S.Schema<BidirectionalOutputPayloadPart>;
export type InvokeModelWithBidirectionalStreamOutput = {
    chunk: BidirectionalOutputPayloadPart;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException: InternalServerException;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException: ValidationException;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException: ThrottlingException;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException: ModelTimeoutException;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException: ServiceUnavailableException;
};
export declare const InvokeModelWithBidirectionalStreamOutput: S.Schema<stream.Stream<InvokeModelWithBidirectionalStreamOutput, Error, never>>;
export interface InvokeModelWithBidirectionalStreamResponse {
    body: stream.Stream<InvokeModelWithBidirectionalStreamOutput, Error, never>;
}
export declare const InvokeModelWithBidirectionalStreamResponse: S.Schema<InvokeModelWithBidirectionalStreamResponse>;
export interface InvokeModelWithResponseStreamRequest {
    body?: T.StreamingInputBody;
    contentType?: string;
    accept?: string;
    modelId: string;
    trace?: Trace;
    guardrailIdentifier?: string;
    guardrailVersion?: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
    requestMetadata?: string | redacted.Redacted<string>;
}
export declare const InvokeModelWithResponseStreamRequest: S.Schema<InvokeModelWithResponseStreamRequest>;
export interface PayloadPart {
    bytes?: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const PayloadPart: S.Schema<PayloadPart>;
export type ResponseStream = {
    chunk: PayloadPart;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException: InternalServerException;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException: ModelStreamErrorException;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException: ValidationException;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException: ThrottlingException;
    modelTimeoutException?: never;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException: ModelTimeoutException;
    serviceUnavailableException?: never;
} | {
    chunk?: never;
    internalServerException?: never;
    modelStreamErrorException?: never;
    validationException?: never;
    throttlingException?: never;
    modelTimeoutException?: never;
    serviceUnavailableException: ServiceUnavailableException;
};
export declare const ResponseStream: S.Schema<stream.Stream<ResponseStream, Error, never>>;
export interface InvokeModelWithResponseStreamResponse {
    body: stream.Stream<ResponseStream, Error, never>;
    contentType: string;
    performanceConfigLatency?: PerformanceConfigLatency;
    serviceTier?: ServiceTierType;
}
export declare const InvokeModelWithResponseStreamResponse: S.Schema<InvokeModelWithResponseStreamResponse>;
export type MaxResults = number;
export type PaginationToken = string;
export type SortAsyncInvocationBy = "SubmissionTime" | (string & {});
export declare const SortAsyncInvocationBy: any;
export type SortOrder = "Ascending" | "Descending" | (string & {});
export declare const SortOrder: any;
export interface ListAsyncInvokesRequest {
    submitTimeAfter?: Date;
    submitTimeBefore?: Date;
    statusEquals?: AsyncInvokeStatus;
    maxResults?: number;
    nextToken?: string;
    sortBy?: SortAsyncInvocationBy;
    sortOrder?: SortOrder;
}
export declare const ListAsyncInvokesRequest: S.Schema<ListAsyncInvokesRequest>;
export interface AsyncInvokeSummary {
    invocationArn: string;
    modelArn: string;
    clientRequestToken?: string;
    status?: AsyncInvokeStatus;
    failureMessage?: string | redacted.Redacted<string>;
    submitTime: Date;
    lastModifiedTime?: Date;
    endTime?: Date;
    outputDataConfig: AsyncInvokeOutputDataConfig;
}
export declare const AsyncInvokeSummary: S.Schema<AsyncInvokeSummary>;
export type AsyncInvokeSummaries = AsyncInvokeSummary[];
export declare const AsyncInvokeSummaries: any;
export interface ListAsyncInvokesResponse {
    nextToken?: string;
    asyncInvokeSummaries?: AsyncInvokeSummary[];
}
export declare const ListAsyncInvokesResponse: S.Schema<ListAsyncInvokesResponse>;
export type AsyncInvokeIdentifier = string;
export type ModelInputPayload = unknown;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface StartAsyncInvokeRequest {
    clientRequestToken?: string;
    modelId: string;
    modelInput: any;
    outputDataConfig: AsyncInvokeOutputDataConfig;
    tags?: Tag[];
}
export declare const StartAsyncInvokeRequest: S.Schema<StartAsyncInvokeRequest>;
export interface StartAsyncInvokeResponse {
    invocationArn: string;
}
export declare const StartAsyncInvokeResponse: S.Schema<StartAsyncInvokeResponse>;
export type ApplyGuardrailError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The action to apply a guardrail.
 *
 * For troubleshooting some of the common errors you might encounter when using the `ApplyGuardrail` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const applyGuardrail: API.OperationMethod<ApplyGuardrailRequest, ApplyGuardrailResponse, ApplyGuardrailError, Credentials | HttpClient.HttpClient>;
export type ConverseError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends messages to the specified Amazon Bedrock model. `Converse` provides a consistent interface that works with all models that support messages. This allows you to write code once and use it with different models. If a model has unique inference parameters, you can also pass those unique parameters to the model.
 *
 * Amazon Bedrock doesn't store any text, images, or documents that you provide as content. The data is only used to generate the response.
 *
 * You can submit a prompt by including it in the `messages` field, specifying the `modelId` of a foundation model or inference profile to run inference on it, and including any other fields that are relevant to your use case.
 *
 * You can also submit a prompt from Prompt management by specifying the ARN of the prompt version and including a map of variables to values in the `promptVariables` field. You can append more messages to the prompt by using the `messages` field. If you use a prompt from Prompt management, you can't include the following fields in the request: `additionalModelRequestFields`, `inferenceConfig`, `system`, or `toolConfig`. Instead, these fields must be defined through Prompt management. For more information, see Use a prompt from Prompt management.
 *
 * For information about the Converse API, see *Use the Converse API* in the *Amazon Bedrock User Guide*. To use a guardrail, see *Use a guardrail with the Converse API* in the *Amazon Bedrock User Guide*. To use a tool with a model, see *Tool use (Function calling)* in the *Amazon Bedrock User Guide*
 *
 * For example code, see *Converse API examples* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the base inference actions (InvokeModel and InvokeModelWithResponseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `Converse` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const converse: API.OperationMethod<ConverseRequest, ConverseResponse, ConverseError, Credentials | HttpClient.HttpClient>;
export type ConverseStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends messages to the specified Amazon Bedrock model and returns the response in a stream. `ConverseStream` provides a consistent API that works with all Amazon Bedrock models that support messages. This allows you to write code once and use it with different models. Should a model have unique inference parameters, you can also pass those unique parameters to the model.
 *
 * To find out if a model supports streaming, call GetFoundationModel and check the `responseStreamingSupported` field in the response.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `ConverseStream`.
 *
 * Amazon Bedrock doesn't store any text, images, or documents that you provide as content. The data is only used to generate the response.
 *
 * You can submit a prompt by including it in the `messages` field, specifying the `modelId` of a foundation model or inference profile to run inference on it, and including any other fields that are relevant to your use case.
 *
 * You can also submit a prompt from Prompt management by specifying the ARN of the prompt version and including a map of variables to values in the `promptVariables` field. You can append more messages to the prompt by using the `messages` field. If you use a prompt from Prompt management, you can't include the following fields in the request: `additionalModelRequestFields`, `inferenceConfig`, `system`, or `toolConfig`. Instead, these fields must be defined through Prompt management. For more information, see Use a prompt from Prompt management.
 *
 * For information about the Converse API, see *Use the Converse API* in the *Amazon Bedrock User Guide*. To use a guardrail, see *Use a guardrail with the Converse API* in the *Amazon Bedrock User Guide*. To use a tool with a model, see *Tool use (Function calling)* in the *Amazon Bedrock User Guide*
 *
 * For example code, see *Conversation streaming example* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModelWithResponseStream` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the base inference actions (InvokeModel and InvokeModelWithResponseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `ConverseStream` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const converseStream: API.OperationMethod<ConverseStreamRequest, ConverseStreamResponse, ConverseStreamError, Credentials | HttpClient.HttpClient>;
export type CountTokensError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the token count for a given inference request. This operation helps you estimate token usage before sending requests to foundation models by returning the token count that would be used if the same input were sent to the model in an inference request.
 *
 * Token counting is model-specific because different models use different tokenization strategies. The token count returned by this operation will match the token count that would be charged if the same input were sent to the model in an `InvokeModel` or `Converse` request.
 *
 * You can use this operation to:
 *
 * - Estimate costs before sending inference requests.
 *
 * - Optimize prompts to fit within token limits.
 *
 * - Plan for token usage in your applications.
 *
 * This operation accepts the same input formats as `InvokeModel` and `Converse`, allowing you to count tokens for both raw text inputs and structured conversation formats.
 *
 * The following operations are related to `CountTokens`:
 *
 * - InvokeModel - Sends inference requests to foundation models
 *
 * - Converse - Sends conversation-based inference requests to foundation models
 */
export declare const countTokens: API.OperationMethod<CountTokensRequest, CountTokensResponse, CountTokensError, Credentials | HttpClient.HttpClient>;
export type GetAsyncInvokeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve information about an asynchronous invocation.
 */
export declare const getAsyncInvoke: API.OperationMethod<GetAsyncInvokeRequest, GetAsyncInvokeResponse, GetAsyncInvokeError, Credentials | HttpClient.HttpClient>;
export type InvokeGuardrailChecksError = AccessDeniedException | InternalServerException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates messages against inline guardrail checks. You specify the check configurations directly in the request, and Amazon Bedrock returns per-check results with severity or confidence scores.
 */
export declare const invokeGuardrailChecks: API.OperationMethod<InvokeGuardrailChecksRequest, InvokeGuardrailChecksResponse, InvokeGuardrailChecksError, Credentials | HttpClient.HttpClient>;
export type InvokeModelError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invokes the specified Amazon Bedrock model to run inference using the prompt and inference parameters provided in the request body. You use model inference to generate text, images, and embeddings.
 *
 * For example code, see *Invoke model code examples* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `InvokeModel` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const invokeModel: API.OperationMethod<InvokeModelRequest, InvokeModelResponse, InvokeModelError, Credentials | HttpClient.HttpClient>;
export type InvokeModelWithBidirectionalStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelStreamErrorException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke the specified Amazon Bedrock model to run inference using the bidirectional stream. The response is returned in a stream that remains open for 8 minutes. A single session can contain multiple prompts and responses from the model. The prompts to the model are provided as audio files and the model's responses are spoken back to the user and transcribed.
 *
 * It is possible for users to interrupt the model's response with a new prompt, which will halt the response speech. The model will retain contextual awareness of the conversation while pivoting to respond to the new prompt.
 */
export declare const invokeModelWithBidirectionalStream: API.OperationMethod<InvokeModelWithBidirectionalStreamRequest, InvokeModelWithBidirectionalStreamResponse, InvokeModelWithBidirectionalStreamError, Credentials | HttpClient.HttpClient>;
export type InvokeModelWithResponseStreamError = AccessDeniedException | InternalServerException | ModelErrorException | ModelNotReadyException | ModelStreamErrorException | ModelTimeoutException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Invoke the specified Amazon Bedrock model to run inference using the prompt and inference parameters provided in the request body. The response is returned in a stream.
 *
 * To see if a model supports streaming, call GetFoundationModel and check the `responseStreamingSupported` field in the response.
 *
 * The CLI doesn't support streaming operations in Amazon Bedrock, including `InvokeModelWithResponseStream`.
 *
 * For example code, see *Invoke model with streaming code example* in the *Amazon Bedrock User Guide*.
 *
 * This operation requires permissions to perform the `bedrock:InvokeModelWithResponseStream` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 *
 * For troubleshooting some of the common errors you might encounter when using the `InvokeModelWithResponseStream` API, see Troubleshooting Amazon Bedrock API Error Codes in the Amazon Bedrock User Guide
 */
export declare const invokeModelWithResponseStream: API.OperationMethod<InvokeModelWithResponseStreamRequest, InvokeModelWithResponseStreamResponse, InvokeModelWithResponseStreamError, Credentials | HttpClient.HttpClient>;
export type ListAsyncInvokesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists asynchronous invocations.
 */
export declare const listAsyncInvokes: API.PaginatedOperationMethod<ListAsyncInvokesRequest, ListAsyncInvokesResponse, ListAsyncInvokesError, Credentials | HttpClient.HttpClient, AsyncInvokeSummary>;
export type StartAsyncInvokeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an asynchronous invocation.
 *
 * This operation requires permission for the `bedrock:InvokeModel` action.
 *
 * To deny all inference access to resources that you specify in the modelId field, you need to deny access to the `bedrock:InvokeModel` and `bedrock:InvokeModelWithResponseStream` actions. Doing this also denies access to the resource through the Converse API actions (Converse and ConverseStream). For more information see Deny access for inference on specific models.
 */
export declare const startAsyncInvoke: API.OperationMethod<StartAsyncInvokeRequest, StartAsyncInvokeResponse, StartAsyncInvokeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-runtime.d.ts.map