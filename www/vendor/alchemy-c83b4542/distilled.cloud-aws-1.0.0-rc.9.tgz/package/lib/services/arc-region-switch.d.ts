import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const IllegalArgumentException_base: S.Class<IllegalArgumentException, S.TaggedStruct<"IllegalArgumentException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalArgumentException extends /*@__PURE__*/ IllegalArgumentException_base {
}
declare const IllegalStateException_base: S.Class<IllegalStateException, S.TaggedStruct<"IllegalStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalStateException extends /*@__PURE__*/ IllegalStateException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type PlanArn = string;
export type ExecutionId = string;
export type StepName = string;
export type Approval = "approve" | "decline" | (string & {});
export declare const Approval: any;
export type ExecutionComment = string;
export interface ApprovePlanExecutionStepRequest {
    planArn: string;
    executionId: string;
    stepName: string;
    approval: Approval;
    comment?: string;
}
export declare const ApprovePlanExecutionStepRequest: S.Schema<ApprovePlanExecutionStepRequest>;
export interface ApprovePlanExecutionStepResponse {
}
export declare const ApprovePlanExecutionStepResponse: S.Schema<ApprovePlanExecutionStepResponse>;
export interface CancelPlanExecutionRequest {
    planArn: string;
    executionId: string;
    comment?: string;
}
export declare const CancelPlanExecutionRequest: S.Schema<CancelPlanExecutionRequest>;
export interface CancelPlanExecutionResponse {
}
export declare const CancelPlanExecutionResponse: S.Schema<CancelPlanExecutionResponse>;
export type IamRoleArn = string;
export type LambdaArn = string;
export interface Lambdas {
    crossAccountRole?: string;
    externalId?: string;
    arn?: string;
}
export declare const Lambdas: S.Schema<Lambdas>;
export type LambdaList = Lambdas[];
export declare const LambdaList: any;
export type RegionToRunIn = "activatingRegion" | "deactivatingRegion" | "activeRegion" | "inactiveRegion" | (string & {});
export declare const RegionToRunIn: any;
export type LambdaUngracefulBehavior = "skip" | (string & {});
export declare const LambdaUngracefulBehavior: any;
export interface LambdaUngraceful {
    behavior?: LambdaUngracefulBehavior;
}
export declare const LambdaUngraceful: S.Schema<LambdaUngraceful>;
export interface CustomActionLambdaConfiguration {
    timeoutMinutes?: number;
    lambdas: Lambdas[];
    retryIntervalMinutes: number;
    regionToRun: RegionToRunIn;
    ungraceful?: LambdaUngraceful;
}
export declare const CustomActionLambdaConfiguration: S.Schema<CustomActionLambdaConfiguration>;
export type AsgArn = string;
export interface Asg {
    crossAccountRole?: string;
    externalId?: string;
    arn?: string;
}
export declare const Asg: S.Schema<Asg>;
export type AsgList = Asg[];
export declare const AsgList: any;
export interface Ec2Ungraceful {
    minimumSuccessPercentage: number;
}
export declare const Ec2Ungraceful: S.Schema<Ec2Ungraceful>;
export type Ec2AsgCapacityMonitoringApproach = "sampledMaxInLast24Hours" | "autoscalingMaxInLast24Hours" | (string & {});
export declare const Ec2AsgCapacityMonitoringApproach: any;
export interface Ec2AsgCapacityIncreaseConfiguration {
    timeoutMinutes?: number;
    asgs: Asg[];
    ungraceful?: Ec2Ungraceful;
    targetPercent?: number;
    capacityMonitoringApproach?: Ec2AsgCapacityMonitoringApproach;
}
export declare const Ec2AsgCapacityIncreaseConfiguration: S.Schema<Ec2AsgCapacityIncreaseConfiguration>;
export type RoleArn = string;
export interface ExecutionApprovalConfiguration {
    timeoutMinutes?: number;
    approvalRole: string;
}
export declare const ExecutionApprovalConfiguration: S.Schema<ExecutionApprovalConfiguration>;
export type RoutingControlArn = string;
export type RoutingControlStateChange = "On" | "Off" | (string & {});
export declare const RoutingControlStateChange: any;
export interface ArcRoutingControlState {
    routingControlArn: string;
    state: RoutingControlStateChange;
}
export declare const ArcRoutingControlState: S.Schema<ArcRoutingControlState>;
export type ArcRoutingControlStates = ArcRoutingControlState[];
export declare const ArcRoutingControlStates: any;
export type RegionAndRoutingControls = {
    [key: string]: ArcRoutingControlState[] | undefined;
};
export declare const RegionAndRoutingControls: any;
export interface ArcRoutingControlConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    regionAndRoutingControls: {
        [key: string]: ArcRoutingControlState[] | undefined;
    };
}
export declare const ArcRoutingControlConfiguration: S.Schema<ArcRoutingControlConfiguration>;
export type GlobalAuroraDefaultBehavior = "switchoverOnly" | "failover" | (string & {});
export declare const GlobalAuroraDefaultBehavior: any;
export type GlobalAuroraUngracefulBehavior = "failover" | (string & {});
export declare const GlobalAuroraUngracefulBehavior: any;
export interface GlobalAuroraUngraceful {
    ungraceful?: GlobalAuroraUngracefulBehavior;
}
export declare const GlobalAuroraUngraceful: S.Schema<GlobalAuroraUngraceful>;
export type GlobalClusterIdentifier = string;
export type AuroraClusterArn = string;
export type AuroraClusterArns = string[];
export declare const AuroraClusterArns: any;
export interface GlobalAuroraConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    behavior: GlobalAuroraDefaultBehavior;
    ungraceful?: GlobalAuroraUngraceful;
    globalClusterIdentifier: string;
    databaseClusterArns: string[];
}
export declare const GlobalAuroraConfiguration: S.Schema<GlobalAuroraConfiguration>;
export interface ParallelExecutionBlockConfiguration {
    steps: Step[];
}
export declare const ParallelExecutionBlockConfiguration: S.Schema<ParallelExecutionBlockConfiguration>;
export interface RegionSwitchPlanConfiguration {
    crossAccountRole?: string;
    externalId?: string;
    arn: string;
}
export declare const RegionSwitchPlanConfiguration: S.Schema<RegionSwitchPlanConfiguration>;
export type EcsClusterArn = string;
export type EcsServiceArn = string;
export interface Service {
    crossAccountRole?: string;
    externalId?: string;
    clusterArn?: string;
    serviceArn?: string;
}
export declare const Service: S.Schema<Service>;
export type ServiceList = Service[];
export declare const ServiceList: any;
export interface EcsUngraceful {
    minimumSuccessPercentage: number;
}
export declare const EcsUngraceful: S.Schema<EcsUngraceful>;
export type EcsCapacityMonitoringApproach = "sampledMaxInLast24Hours" | "containerInsightsMaxInLast24Hours" | (string & {});
export declare const EcsCapacityMonitoringApproach: any;
export interface EcsCapacityIncreaseConfiguration {
    timeoutMinutes?: number;
    services: Service[];
    ungraceful?: EcsUngraceful;
    targetPercent?: number;
    capacityMonitoringApproach?: EcsCapacityMonitoringApproach;
}
export declare const EcsCapacityIncreaseConfiguration: S.Schema<EcsCapacityIncreaseConfiguration>;
export interface KubernetesResourceType {
    apiVersion: string;
    kind: string;
}
export declare const KubernetesResourceType: S.Schema<KubernetesResourceType>;
export type Region = string;
export type KubernetesNamespace = string;
export interface KubernetesScalingResource {
    namespace: string;
    name: string;
    hpaName?: string;
}
export declare const KubernetesScalingResource: S.Schema<KubernetesScalingResource>;
export type RegionalScalingResource = {
    [key: string]: KubernetesScalingResource | undefined;
};
export declare const RegionalScalingResource: any;
export type KubernetesScalingApplication = {
    [key: string]: {
        [key: string]: KubernetesScalingResource | undefined;
    } | undefined;
};
export declare const KubernetesScalingApplication: any;
export type KubernetesScalingApps = {
    [key: string]: {
        [key: string]: KubernetesScalingResource | undefined;
    } | undefined;
}[];
export declare const KubernetesScalingApps: any;
export type EksClusterArn = string;
export interface EksCluster {
    crossAccountRole?: string;
    externalId?: string;
    clusterArn: string;
}
export declare const EksCluster: S.Schema<EksCluster>;
export type EksClusters = EksCluster[];
export declare const EksClusters: any;
export interface EksResourceScalingUngraceful {
    minimumSuccessPercentage: number;
}
export declare const EksResourceScalingUngraceful: S.Schema<EksResourceScalingUngraceful>;
export type EksCapacityMonitoringApproach = "sampledMaxInLast24Hours" | (string & {});
export declare const EksCapacityMonitoringApproach: any;
export interface EksResourceScalingConfiguration {
    timeoutMinutes?: number;
    kubernetesResourceType: KubernetesResourceType;
    scalingResources?: {
        [key: string]: {
            [key: string]: KubernetesScalingResource | undefined;
        } | undefined;
    }[];
    eksClusters?: EksCluster[];
    ungraceful?: EksResourceScalingUngraceful;
    targetPercent?: number;
    capacityMonitoringApproach?: EksCapacityMonitoringApproach;
}
export declare const EksResourceScalingConfiguration: S.Schema<EksResourceScalingConfiguration>;
export type Route53HostedZoneId = string;
export type Route53RecordName = string;
export type Route53ResourceRecordSetIdentifier = string;
export interface Route53ResourceRecordSet {
    recordSetIdentifier?: string;
    region?: string;
}
export declare const Route53ResourceRecordSet: S.Schema<Route53ResourceRecordSet>;
export type Route53ResourceRecordSetList = Route53ResourceRecordSet[];
export declare const Route53ResourceRecordSetList: any;
export interface Route53HealthCheckConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    hostedZoneId: string;
    recordName: string;
    recordSets?: Route53ResourceRecordSet[];
}
export declare const Route53HealthCheckConfiguration: S.Schema<Route53HealthCheckConfiguration>;
export type DocumentDbDefaultBehavior = "switchoverOnly" | "failover" | (string & {});
export declare const DocumentDbDefaultBehavior: any;
export type DocumentDbUngracefulBehavior = "failover" | (string & {});
export declare const DocumentDbUngracefulBehavior: any;
export interface DocumentDbUngraceful {
    ungraceful?: DocumentDbUngracefulBehavior;
}
export declare const DocumentDbUngraceful: S.Schema<DocumentDbUngraceful>;
export type DocumentDbGlobalClusterIdentifier = string;
export type DocumentDbClusterArn = string;
export type DocumentDbClusterArns = string[];
export declare const DocumentDbClusterArns: any;
export interface DocumentDbConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    behavior: DocumentDbDefaultBehavior;
    ungraceful?: DocumentDbUngraceful;
    globalClusterIdentifier: string;
    databaseClusterArns: string[];
}
export declare const DocumentDbConfiguration: S.Schema<DocumentDbConfiguration>;
export type RdsDbInstanceArn = string;
export type RdsDbInstanceArnMap = {
    [key: string]: string | undefined;
};
export declare const RdsDbInstanceArnMap: any;
export interface RdsPromoteReadReplicaConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    dbInstanceArnMap: {
        [key: string]: string | undefined;
    };
}
export declare const RdsPromoteReadReplicaConfiguration: S.Schema<RdsPromoteReadReplicaConfiguration>;
export interface RdsCreateCrossRegionReplicaConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    dbInstanceArnMap: {
        [key: string]: string | undefined;
    };
}
export declare const RdsCreateCrossRegionReplicaConfiguration: S.Schema<RdsCreateCrossRegionReplicaConfiguration>;
export type EventSourceMappingAction = "enable" | "disable" | (string & {});
export declare const EventSourceMappingAction: any;
export type EventSourceMappingArn = string;
export interface EventSourceMapping {
    crossAccountRole?: string;
    externalId?: string;
    arn: string;
}
export declare const EventSourceMapping: S.Schema<EventSourceMapping>;
export type RegionEventSourceMappingMap = {
    [key: string]: EventSourceMapping | undefined;
};
export declare const RegionEventSourceMappingMap: any;
export type LambdaEventSourceMappingUngracefulBehavior = "skip" | (string & {});
export declare const LambdaEventSourceMappingUngracefulBehavior: any;
export interface LambdaEventSourceMappingUngraceful {
    behavior?: LambdaEventSourceMappingUngracefulBehavior;
}
export declare const LambdaEventSourceMappingUngraceful: S.Schema<LambdaEventSourceMappingUngraceful>;
export interface LambdaEventSourceMappingConfiguration {
    timeoutMinutes?: number;
    action: EventSourceMappingAction;
    regionEventSourceMappings: {
        [key: string]: EventSourceMapping | undefined;
    };
    ungraceful?: LambdaEventSourceMappingUngraceful;
}
export declare const LambdaEventSourceMappingConfiguration: S.Schema<LambdaEventSourceMappingConfiguration>;
export type RegionAuroraClusterMap = {
    [key: string]: string | undefined;
};
export declare const RegionAuroraClusterMap: any;
export interface AuroraServerlessScalingConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    globalClusterIdentifier: string;
    regionDatabaseClusterArns: {
        [key: string]: string | undefined;
    };
    targetPercent?: number;
}
export declare const AuroraServerlessScalingConfiguration: S.Schema<AuroraServerlessScalingConfiguration>;
export type AuroraInstanceArn = string;
export type RegionAuroraInstanceArnMap = {
    [key: string]: string | undefined;
};
export declare const RegionAuroraInstanceArnMap: any;
export interface AuroraProvisionedScalingConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    globalClusterIdentifier: string;
    regionDatabaseClusterArns: {
        [key: string]: string | undefined;
    };
    instanceArns: {
        [key: string]: string | undefined;
    };
}
export declare const AuroraProvisionedScalingConfiguration: S.Schema<AuroraProvisionedScalingConfiguration>;
export type NeptuneDefaultBehavior = "switchoverOnly" | "failover" | (string & {});
export declare const NeptuneDefaultBehavior: any;
export type NeptuneUngracefulBehavior = "failover" | (string & {});
export declare const NeptuneUngracefulBehavior: any;
export interface NeptuneUngraceful {
    ungraceful?: NeptuneUngracefulBehavior;
}
export declare const NeptuneUngraceful: S.Schema<NeptuneUngraceful>;
export type NeptuneGlobalClusterIdentifier = string;
export type NeptuneClusterArn = string;
export type RegionNeptuneClusterArnMap = {
    [key: string]: string | undefined;
};
export declare const RegionNeptuneClusterArnMap: any;
export interface NeptuneGlobalDatabaseConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    behavior: NeptuneDefaultBehavior;
    ungraceful?: NeptuneUngraceful;
    globalClusterIdentifier: string;
    regionDatabaseClusterArns: {
        [key: string]: string | undefined;
    };
}
export declare const NeptuneGlobalDatabaseConfiguration: S.Schema<NeptuneGlobalDatabaseConfiguration>;
export type RdsUngracefulBehavior = "promoteReadReplica" | (string & {});
export declare const RdsUngracefulBehavior: any;
export interface RdsUngraceful {
    ungraceful?: RdsUngracefulBehavior;
}
export declare const RdsUngraceful: S.Schema<RdsUngraceful>;
export interface RdsSwitchoverReadReplicaConfiguration {
    timeoutMinutes?: number;
    crossAccountRole?: string;
    externalId?: string;
    dbInstanceArnMap: {
        [key: string]: string | undefined;
    };
    ungraceful?: RdsUngraceful;
}
export declare const RdsSwitchoverReadReplicaConfiguration: S.Schema<RdsSwitchoverReadReplicaConfiguration>;
export type ExecutionBlockConfiguration = {
    customActionLambdaConfig: CustomActionLambdaConfiguration;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig: Ec2AsgCapacityIncreaseConfiguration;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig: ExecutionApprovalConfiguration;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig: ArcRoutingControlConfiguration;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig: GlobalAuroraConfiguration;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig: ParallelExecutionBlockConfiguration;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig: RegionSwitchPlanConfiguration;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig: EcsCapacityIncreaseConfiguration;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig: EksResourceScalingConfiguration;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig: Route53HealthCheckConfiguration;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig: DocumentDbConfiguration;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig: RdsPromoteReadReplicaConfiguration;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig: RdsCreateCrossRegionReplicaConfiguration;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig: LambdaEventSourceMappingConfiguration;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig: AuroraServerlessScalingConfiguration;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig: AuroraProvisionedScalingConfiguration;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig: NeptuneGlobalDatabaseConfiguration;
    rdsSwitchoverReadReplicaConfig?: never;
} | {
    customActionLambdaConfig?: never;
    ec2AsgCapacityIncreaseConfig?: never;
    executionApprovalConfig?: never;
    arcRoutingControlConfig?: never;
    globalAuroraConfig?: never;
    parallelConfig?: never;
    regionSwitchPlanConfig?: never;
    ecsCapacityIncreaseConfig?: never;
    eksResourceScalingConfig?: never;
    route53HealthCheckConfig?: never;
    documentDbConfig?: never;
    rdsPromoteReadReplicaConfig?: never;
    rdsCreateCrossRegionReadReplicaConfig?: never;
    lambdaEventSourceMappingConfig?: never;
    auroraServerlessScalingConfig?: never;
    auroraProvisionedScalingConfig?: never;
    neptuneGlobalDatabaseConfig?: never;
    rdsSwitchoverReadReplicaConfig: RdsSwitchoverReadReplicaConfiguration;
};
export declare const ExecutionBlockConfiguration: S.Schema<ExecutionBlockConfiguration>;
export type ExecutionBlockType = "CustomActionLambda" | "ManualApproval" | "AuroraGlobalDatabase" | "EC2AutoScaling" | "ARCRoutingControl" | "ARCRegionSwitchPlan" | "Parallel" | "ECSServiceScaling" | "EKSResourceScaling" | "Route53HealthCheck" | "DocumentDb" | "RdsPromoteReadReplica" | "RdsCreateCrossRegionReplica" | "LambdaEventSourceMapping" | "AuroraServerlessScaling" | "AuroraProvisionedScaling" | "NeptuneGlobalDatabase" | "RdsSwitchoverReadReplica" | (string & {});
export declare const ExecutionBlockType: any;
export interface Step {
    name: string;
    description?: string;
    executionBlockConfiguration: ExecutionBlockConfiguration;
    executionBlockType: ExecutionBlockType;
}
export declare const Step: S.Schema<Step>;
export type Steps = Step[];
export declare const Steps: S.Schema<Steps>;
export type WorkflowTargetAction = "activate" | "deactivate" | "postRecovery" | (string & {});
export declare const WorkflowTargetAction: any;
export interface Workflow {
    steps?: Step[];
    workflowTargetAction: WorkflowTargetAction;
    workflowTargetRegion?: string;
    workflowDescription?: string;
}
export declare const Workflow: S.Schema<Workflow>;
export type WorkflowList = Workflow[];
export declare const WorkflowList: any;
export type AlarmType = "applicationHealth" | "trigger" | (string & {});
export declare const AlarmType: any;
export interface AssociatedAlarm {
    crossAccountRole?: string;
    externalId?: string;
    resourceIdentifier: string;
    alarmType: AlarmType;
}
export declare const AssociatedAlarm: S.Schema<AssociatedAlarm>;
export type AssociatedAlarmMap = {
    [key: string]: AssociatedAlarm | undefined;
};
export declare const AssociatedAlarmMap: any;
export type AlarmCondition = "red" | "green" | (string & {});
export declare const AlarmCondition: any;
export interface TriggerCondition {
    associatedAlarmName: string;
    condition: AlarmCondition;
}
export declare const TriggerCondition: S.Schema<TriggerCondition>;
export type TriggerConditionList = TriggerCondition[];
export declare const TriggerConditionList: any;
export interface Trigger {
    description?: string;
    targetRegion: string;
    action: WorkflowTargetAction;
    conditions: TriggerCondition[];
    minDelayMinutesBetweenExecutions: number;
}
export declare const Trigger: S.Schema<Trigger>;
export type TriggerList = Trigger[];
export declare const TriggerList: any;
export type AccountId = string;
export interface S3ReportOutputConfiguration {
    bucketPath?: string;
    bucketOwner?: string;
}
export declare const S3ReportOutputConfiguration: S.Schema<S3ReportOutputConfiguration>;
export type ReportOutputConfiguration = {
    s3Configuration: S3ReportOutputConfiguration;
};
export declare const ReportOutputConfiguration: any;
export type ReportOutputList = ReportOutputConfiguration[];
export declare const ReportOutputList: any;
export interface ReportConfiguration {
    reportOutput?: ReportOutputConfiguration[];
}
export declare const ReportConfiguration: S.Schema<ReportConfiguration>;
export type PlanName = string;
export type RegionList = string[];
export declare const RegionList: any;
export type RecoveryApproach = "activeActive" | "activePassive" | (string & {});
export declare const RecoveryApproach: any;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CreatePlanRequest {
    description?: string;
    workflows: Workflow[];
    executionRole: string;
    recoveryTimeObjectiveMinutes?: number;
    associatedAlarms?: {
        [key: string]: AssociatedAlarm | undefined;
    };
    triggers?: Trigger[];
    reportConfiguration?: ReportConfiguration;
    name: string;
    regions: string[];
    recoveryApproach: RecoveryApproach;
    primaryRegion?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreatePlanRequest: S.Schema<CreatePlanRequest>;
export interface Plan {
    arn: string;
    description?: string;
    workflows: Workflow[];
    executionRole: string;
    recoveryTimeObjectiveMinutes?: number;
    associatedAlarms?: {
        [key: string]: AssociatedAlarm | undefined;
    };
    triggers?: Trigger[];
    reportConfiguration?: ReportConfiguration;
    name: string;
    regions: string[];
    recoveryApproach: RecoveryApproach;
    primaryRegion?: string;
    owner: string;
    version?: string;
    updatedAt?: Date;
}
export declare const Plan: S.Schema<Plan>;
export interface CreatePlanResponse {
    plan?: Plan;
}
export declare const CreatePlanResponse: S.Schema<CreatePlanResponse>;
export interface DeletePlanRequest {
    arn: string;
}
export declare const DeletePlanRequest: S.Schema<DeletePlanRequest>;
export interface DeletePlanResponse {
}
export declare const DeletePlanResponse: S.Schema<DeletePlanResponse>;
export interface GetPlanRequest {
    arn: string;
}
export declare const GetPlanRequest: S.Schema<GetPlanRequest>;
export interface GetPlanResponse {
    plan?: Plan;
}
export declare const GetPlanResponse: S.Schema<GetPlanResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface GetPlanEvaluationStatusRequest {
    planArn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetPlanEvaluationStatusRequest: S.Schema<GetPlanEvaluationStatusRequest>;
export type EvaluationStatus = "passed" | "actionRequired" | "pendingEvaluation" | "unknown" | (string & {});
export declare const EvaluationStatus: any;
export type ExecutionAction = "activate" | "deactivate" | "postRecovery" | (string & {});
export declare const ExecutionAction: any;
export interface MinimalWorkflow {
    action?: ExecutionAction;
    name?: string;
}
export declare const MinimalWorkflow: S.Schema<MinimalWorkflow>;
export type ResourceArn = string;
export type ResourceWarningStatus = "active" | "resolved" | (string & {});
export declare const ResourceWarningStatus: any;
export interface ResourceWarning {
    workflow?: MinimalWorkflow;
    version: string;
    stepName?: string;
    resourceArn?: string;
    warningStatus: ResourceWarningStatus;
    warningUpdatedTime: Date;
    warningMessage: string;
}
export declare const ResourceWarning: S.Schema<ResourceWarning>;
export type PlanWarnings = ResourceWarning[];
export declare const PlanWarnings: any;
export interface GetPlanEvaluationStatusResponse {
    planArn: string;
    lastEvaluationTime?: Date;
    lastEvaluatedVersion?: string;
    region?: string;
    evaluationState?: EvaluationStatus;
    warnings?: ResourceWarning[];
    nextToken?: string;
}
export declare const GetPlanEvaluationStatusResponse: S.Schema<GetPlanEvaluationStatusResponse>;
export type GetPlanExecutionStepStatesMaxResults = number;
export interface GetPlanExecutionRequest {
    planArn: string;
    executionId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const GetPlanExecutionRequest: S.Schema<GetPlanExecutionRequest>;
export type ExecutionMode = "graceful" | "ungraceful" | (string & {});
export declare const ExecutionMode: any;
export type ExecutionState = "inProgress" | "pausedByFailedStep" | "pausedByOperator" | "completed" | "completedWithExceptions" | "canceled" | "planExecutionTimedOut" | "pendingManualApproval" | "failed" | "pending" | "completedMonitoringApplicationHealth" | (string & {});
export declare const ExecutionState: any;
export type StepStatus = "notStarted" | "running" | "failed" | "completed" | "canceled" | "skipped" | "pendingApproval" | (string & {});
export declare const StepStatus: any;
export interface StepState {
    name?: string;
    status?: StepStatus;
    startTime?: Date;
    endTime?: Date;
    stepMode?: ExecutionMode;
}
export declare const StepState: S.Schema<StepState>;
export type StepStates = StepState[];
export declare const StepStates: any;
export type Duration = string;
export interface S3ReportOutput {
    s3ObjectKey?: string;
}
export declare const S3ReportOutput: S.Schema<S3ReportOutput>;
export type FailedReportErrorCode = "insufficientPermissions" | "invalidResource" | "configurationError" | (string & {});
export declare const FailedReportErrorCode: any;
export interface FailedReportOutput {
    errorCode?: FailedReportErrorCode;
    errorMessage?: string;
}
export declare const FailedReportOutput: S.Schema<FailedReportOutput>;
export type ReportOutput = {
    s3ReportOutput: S3ReportOutput;
    failedReportOutput?: never;
} | {
    s3ReportOutput?: never;
    failedReportOutput: FailedReportOutput;
};
export declare const ReportOutput: any;
export interface GeneratedReport {
    reportGenerationTime?: Date;
    reportOutput?: ReportOutput;
}
export declare const GeneratedReport: S.Schema<GeneratedReport>;
export type GeneratedReportDetails = GeneratedReport[];
export declare const GeneratedReportDetails: any;
export interface GetPlanExecutionResponse {
    planArn: string;
    executionId: string;
    version?: string;
    updatedAt?: Date;
    comment?: string;
    startTime: Date;
    endTime?: Date;
    mode: ExecutionMode;
    executionState: ExecutionState;
    executionAction: ExecutionAction;
    executionRegion: string;
    recoveryExecutionId?: string;
    stepStates?: StepState[];
    plan?: Plan;
    actualRecoveryTime?: string;
    generatedReportDetails?: GeneratedReport[];
    nextToken?: string;
}
export declare const GetPlanExecutionResponse: S.Schema<GetPlanExecutionResponse>;
export interface GetPlanInRegionRequest {
    arn: string;
}
export declare const GetPlanInRegionRequest: S.Schema<GetPlanInRegionRequest>;
export interface GetPlanInRegionResponse {
    plan?: Plan;
}
export declare const GetPlanInRegionResponse: S.Schema<GetPlanInRegionResponse>;
export type ListExecutionEventsMaxResults = number;
export interface ListPlanExecutionEventsRequest {
    planArn: string;
    executionId: string;
    maxResults?: number;
    nextToken?: string;
    name?: string;
}
export declare const ListPlanExecutionEventsRequest: S.Schema<ListPlanExecutionEventsRequest>;
export type ExecutionEventType = "unknown" | "executionPending" | "executionStarted" | "executionSucceeded" | "executionFailed" | "executionPausing" | "executionPaused" | "executionCanceling" | "executionCanceled" | "executionPendingApproval" | "executionBehaviorChangedToUngraceful" | "executionBehaviorChangedToGraceful" | "executionPendingChildPlanManualApproval" | "executionSuccessMonitoringApplicationHealth" | "stepStarted" | "stepUpdate" | "stepSucceeded" | "stepFailed" | "stepSkipped" | "stepPausedByError" | "stepPausedByOperator" | "stepCanceled" | "stepPendingApproval" | "stepExecutionBehaviorChangedToUngraceful" | "stepPendingApplicationHealthMonitor" | "planEvaluationWarning" | (string & {});
export declare const ExecutionEventType: any;
export type Resources = string[];
export declare const Resources: any;
export interface ExecutionEvent {
    timestamp?: Date;
    type?: ExecutionEventType;
    stepName?: string;
    executionBlockType?: ExecutionBlockType;
    resources?: string[];
    error?: string;
    description?: string;
    eventId: string;
    previousEventId?: string;
}
export declare const ExecutionEvent: S.Schema<ExecutionEvent>;
export type ExecutionEventList = ExecutionEvent[];
export declare const ExecutionEventList: any;
export interface ListPlanExecutionEventsResponse {
    items?: ExecutionEvent[];
    nextToken?: string;
}
export declare const ListPlanExecutionEventsResponse: S.Schema<ListPlanExecutionEventsResponse>;
export type ListExecutionsMaxResults = number;
export interface ListPlanExecutionsRequest {
    planArn: string;
    maxResults?: number;
    nextToken?: string;
    state?: ExecutionState;
}
export declare const ListPlanExecutionsRequest: S.Schema<ListPlanExecutionsRequest>;
export interface AbbreviatedExecution {
    planArn: string;
    executionId: string;
    version?: string;
    updatedAt?: Date;
    comment?: string;
    startTime: Date;
    endTime?: Date;
    mode: ExecutionMode;
    executionState: ExecutionState;
    executionAction: ExecutionAction;
    executionRegion: string;
    recoveryExecutionId?: string;
    actualRecoveryTime?: string;
}
export declare const AbbreviatedExecution: S.Schema<AbbreviatedExecution>;
export type AbbreviatedExecutionsList = AbbreviatedExecution[];
export declare const AbbreviatedExecutionsList: any;
export interface ListPlanExecutionsResponse {
    items?: AbbreviatedExecution[];
    nextToken?: string;
}
export declare const ListPlanExecutionsResponse: S.Schema<ListPlanExecutionsResponse>;
export interface ListPlansRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPlansRequest: S.Schema<ListPlansRequest>;
export interface AbbreviatedPlan {
    arn: string;
    owner: string;
    name: string;
    regions: string[];
    recoveryApproach: RecoveryApproach;
    primaryRegion?: string;
    version?: string;
    updatedAt?: Date;
    description?: string;
    executionRole?: string;
    activePlanExecution?: string;
    recoveryTimeObjectiveMinutes?: number;
}
export declare const AbbreviatedPlan: S.Schema<AbbreviatedPlan>;
export type PlanList = AbbreviatedPlan[];
export declare const PlanList: any;
export interface ListPlansResponse {
    plans?: AbbreviatedPlan[];
    nextToken?: string;
}
export declare const ListPlansResponse: S.Schema<ListPlansResponse>;
export interface ListPlansInRegionRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListPlansInRegionRequest: S.Schema<ListPlansInRegionRequest>;
export interface ListPlansInRegionResponse {
    plans?: AbbreviatedPlan[];
    nextToken?: string;
}
export declare const ListPlansInRegionResponse: S.Schema<ListPlansInRegionResponse>;
export interface ListRoute53HealthChecksRequest {
    arn: string;
    hostedZoneId?: string;
    recordName?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRoute53HealthChecksRequest: S.Schema<ListRoute53HealthChecksRequest>;
export type Route53HealthCheckId = string;
export type Route53HealthCheckStatus = "healthy" | "unhealthy" | "unknown" | (string & {});
export declare const Route53HealthCheckStatus: any;
export interface Route53HealthCheck {
    hostedZoneId: string;
    recordName: string;
    healthCheckId?: string;
    status?: Route53HealthCheckStatus;
    region: string;
}
export declare const Route53HealthCheck: S.Schema<Route53HealthCheck>;
export type Route53HealthCheckList = Route53HealthCheck[];
export declare const Route53HealthCheckList: any;
export interface ListRoute53HealthChecksResponse {
    healthChecks?: Route53HealthCheck[];
    nextToken?: string;
}
export declare const ListRoute53HealthChecksResponse: S.Schema<ListRoute53HealthChecksResponse>;
export interface ListRoute53HealthChecksInRegionRequest {
    arn: string;
    hostedZoneId?: string;
    recordName?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRoute53HealthChecksInRegionRequest: S.Schema<ListRoute53HealthChecksInRegionRequest>;
export interface ListRoute53HealthChecksInRegionResponse {
    healthChecks?: Route53HealthCheck[];
    nextToken?: string;
}
export declare const ListRoute53HealthChecksInRegionResponse: S.Schema<ListRoute53HealthChecksInRegionResponse>;
export interface ListTagsForResourceRequest {
    arn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    resourceTags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type RecoveryExecutionId = string;
export interface StartPlanExecutionRequest {
    planArn: string;
    targetRegion: string;
    action: ExecutionAction;
    mode?: ExecutionMode;
    comment?: string;
    latestVersion?: string;
    recoveryExecutionId?: string;
    clientToken?: string;
}
export declare const StartPlanExecutionRequest: S.Schema<StartPlanExecutionRequest>;
export interface StartPlanExecutionResponse {
    executionId?: string;
    plan?: string;
    planVersion?: string;
    activateRegion?: string;
    deactivateRegion?: string;
}
export declare const StartPlanExecutionResponse: S.Schema<StartPlanExecutionResponse>;
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    arn: string;
    resourceTagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdatePlanRequest {
    arn: string;
    description?: string;
    workflows: Workflow[];
    executionRole: string;
    recoveryTimeObjectiveMinutes?: number;
    associatedAlarms?: {
        [key: string]: AssociatedAlarm | undefined;
    };
    triggers?: Trigger[];
    reportConfiguration?: ReportConfiguration;
}
export declare const UpdatePlanRequest: S.Schema<UpdatePlanRequest>;
export interface UpdatePlanResponse {
    plan?: Plan;
}
export declare const UpdatePlanResponse: S.Schema<UpdatePlanResponse>;
export type UpdatePlanExecutionAction = "switchToGraceful" | "switchToUngraceful" | "pause" | "resume" | (string & {});
export declare const UpdatePlanExecutionAction: any;
export interface UpdatePlanExecutionRequest {
    planArn: string;
    executionId: string;
    action: UpdatePlanExecutionAction;
    comment?: string;
}
export declare const UpdatePlanExecutionRequest: S.Schema<UpdatePlanExecutionRequest>;
export interface UpdatePlanExecutionResponse {
}
export declare const UpdatePlanExecutionResponse: S.Schema<UpdatePlanExecutionResponse>;
export type UpdatePlanExecutionStepAction = "switchToUngraceful" | "skip" | (string & {});
export declare const UpdatePlanExecutionStepAction: any;
export interface UpdatePlanExecutionStepRequest {
    planArn: string;
    executionId: string;
    comment: string;
    stepName: string;
    actionToTake: UpdatePlanExecutionStepAction;
}
export declare const UpdatePlanExecutionStepRequest: S.Schema<UpdatePlanExecutionStepRequest>;
export interface UpdatePlanExecutionStepResponse {
}
export declare const UpdatePlanExecutionStepResponse: S.Schema<UpdatePlanExecutionStepResponse>;
export type ApprovePlanExecutionStepError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Approves a step in a plan execution that requires manual approval. When you create a plan, you can include approval steps that require manual intervention before the execution can proceed. This operation allows you to provide that approval.
 *
 * You must specify the plan ARN, execution ID, step name, and approval status. You can also provide an optional comment explaining the approval decision.
 */
export declare const approvePlanExecutionStep: API.OperationMethod<ApprovePlanExecutionStepRequest, ApprovePlanExecutionStepResponse, ApprovePlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export type CancelPlanExecutionError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels an in-progress plan execution. This operation stops the execution of the plan and prevents any further steps from being processed.
 *
 * You must specify the plan ARN and execution ID. You can also provide an optional comment explaining why the execution was canceled.
 */
export declare const cancelPlanExecution: API.OperationMethod<CancelPlanExecutionRequest, CancelPlanExecutionResponse, CancelPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type CreatePlanError = CommonErrors;
/**
 * Creates a new Region switch plan. A plan defines the steps required to shift traffic from one Amazon Web Services Region to another.
 *
 * You must specify a name for the plan, the primary Region, and at least one additional Region. You can also provide a description, execution role, recovery time objective, associated alarms, triggers, and workflows that define the steps to execute during a Region switch.
 */
export declare const createPlan: API.OperationMethod<CreatePlanRequest, CreatePlanResponse, CreatePlanError, Credentials | HttpClient.HttpClient>;
export type DeletePlanError = IllegalStateException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a Region switch plan. You must specify the ARN of the plan to delete.
 *
 * You cannot delete a plan that has an active execution in progress.
 */
export declare const deletePlan: API.OperationMethod<DeletePlanRequest, DeletePlanResponse, DeletePlanError, Credentials | HttpClient.HttpClient>;
export type GetPlanError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves detailed information about a Region switch plan. You must specify the ARN of the plan.
 */
export declare const getPlan: API.OperationMethod<GetPlanRequest, GetPlanResponse, GetPlanError, Credentials | HttpClient.HttpClient>;
export type GetPlanEvaluationStatusError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the evaluation status of a Region switch plan. The evaluation status provides information about the last time the plan was evaluated and any warnings or issues detected.
 */
export declare const getPlanEvaluationStatus: API.PaginatedOperationMethod<GetPlanEvaluationStatusRequest, GetPlanEvaluationStatusResponse, GetPlanEvaluationStatusError, Credentials | HttpClient.HttpClient, ResourceWarning>;
export type GetPlanExecutionError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves detailed information about a specific plan execution. You must specify the plan ARN and execution ID.
 */
export declare const getPlanExecution: API.PaginatedOperationMethod<GetPlanExecutionRequest, GetPlanExecutionResponse, GetPlanExecutionError, Credentials | HttpClient.HttpClient, StepState>;
export type GetPlanInRegionError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about a Region switch plan in a specific Amazon Web Services Region. This operation is useful for getting Region-specific information about a plan.
 */
export declare const getPlanInRegion: API.OperationMethod<GetPlanInRegionRequest, GetPlanInRegionResponse, GetPlanInRegionError, Credentials | HttpClient.HttpClient>;
export type ListPlanExecutionEventsError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the events that occurred during a plan execution. These events provide a detailed timeline of the execution process.
 */
export declare const listPlanExecutionEvents: API.PaginatedOperationMethod<ListPlanExecutionEventsRequest, ListPlanExecutionEventsResponse, ListPlanExecutionEventsError, Credentials | HttpClient.HttpClient, ExecutionEvent>;
export type ListPlanExecutionsError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the executions of a Region switch plan. This operation returns information about both current and historical executions.
 */
export declare const listPlanExecutions: API.PaginatedOperationMethod<ListPlanExecutionsRequest, ListPlanExecutionsResponse, ListPlanExecutionsError, Credentials | HttpClient.HttpClient, AbbreviatedExecution>;
export type ListPlansError = CommonErrors;
/**
 * Lists all Region switch plans in your Amazon Web Services account.
 */
export declare const listPlans: API.PaginatedOperationMethod<ListPlansRequest, ListPlansResponse, ListPlansError, Credentials | HttpClient.HttpClient, AbbreviatedPlan>;
export type ListPlansInRegionError = AccessDeniedException | CommonErrors;
/**
 * Lists all Region switch plans in your Amazon Web Services account that are available in the current Amazon Web Services Region.
 */
export declare const listPlansInRegion: API.PaginatedOperationMethod<ListPlansInRegionRequest, ListPlansInRegionResponse, ListPlansInRegionError, Credentials | HttpClient.HttpClient, AbbreviatedPlan>;
export type ListRoute53HealthChecksError = AccessDeniedException | IllegalArgumentException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * List the Amazon Route 53 health checks.
 */
export declare const listRoute53HealthChecks: API.PaginatedOperationMethod<ListRoute53HealthChecksRequest, ListRoute53HealthChecksResponse, ListRoute53HealthChecksError, Credentials | HttpClient.HttpClient, Route53HealthCheck>;
export type ListRoute53HealthChecksInRegionError = AccessDeniedException | IllegalArgumentException | InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * List the Amazon Route 53 health checks in a specific Amazon Web Services Region.
 */
export declare const listRoute53HealthChecksInRegion: API.PaginatedOperationMethod<ListRoute53HealthChecksInRegionRequest, ListRoute53HealthChecksInRegionResponse, ListRoute53HealthChecksInRegionError, Credentials | HttpClient.HttpClient, Route53HealthCheck>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags attached to a Region switch resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartPlanExecutionError = AccessDeniedException | ConflictException | IllegalArgumentException | IllegalStateException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the execution of a Region switch plan. You can execute a plan in either `graceful` or `ungraceful` mode.
 *
 * Specifing `ungraceful` mode either changes the behavior of the execution blocks in a workflow or skips specific execution blocks.
 */
export declare const startPlanExecution: API.OperationMethod<StartPlanExecutionRequest, StartPlanExecutionResponse, StartPlanExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Adds or updates tags for a Region switch resource. You can assign metadata to your resources in the form of tags, which are key-value pairs.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from a Region switch resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePlanError = ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing Region switch plan. You can modify the plan's description, workflows, execution role, recovery time objective, associated alarms, and triggers.
 */
export declare const updatePlan: API.OperationMethod<UpdatePlanRequest, UpdatePlanResponse, UpdatePlanError, Credentials | HttpClient.HttpClient>;
export type UpdatePlanExecutionError = AccessDeniedException | IllegalStateException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an in-progress plan execution. This operation allows you to modify certain aspects of the execution, such as adding a comment or changing the action.
 */
export declare const updatePlanExecution: API.OperationMethod<UpdatePlanExecutionRequest, UpdatePlanExecutionResponse, UpdatePlanExecutionError, Credentials | HttpClient.HttpClient>;
export type UpdatePlanExecutionStepError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a specific step in an in-progress plan execution. This operation allows you to modify the step's comment or action.
 */
export declare const updatePlanExecutionStep: API.OperationMethod<UpdatePlanExecutionStepRequest, UpdatePlanExecutionStepResponse, UpdatePlanExecutionStepError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=arc-region-switch.d.ts.map