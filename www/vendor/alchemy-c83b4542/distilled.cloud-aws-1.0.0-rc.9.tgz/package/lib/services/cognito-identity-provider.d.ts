import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AliasExistsException_base: S.Class<AliasExistsException, S.TaggedStruct<"AliasExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AliasExistsException extends /*@__PURE__*/ AliasExistsException_base {
}
declare const CodeDeliveryFailureException_base: S.Class<CodeDeliveryFailureException, S.TaggedStruct<"CodeDeliveryFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeDeliveryFailureException extends /*@__PURE__*/ CodeDeliveryFailureException_base {
}
declare const CodeMismatchException_base: S.Class<CodeMismatchException, S.TaggedStruct<"CodeMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeMismatchException extends /*@__PURE__*/ CodeMismatchException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const DeviceKeyExistsException_base: S.Class<DeviceKeyExistsException, S.TaggedStruct<"DeviceKeyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DeviceKeyExistsException extends /*@__PURE__*/ DeviceKeyExistsException_base {
}
declare const DuplicateProviderException_base: S.Class<DuplicateProviderException, S.TaggedStruct<"DuplicateProviderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateProviderException extends /*@__PURE__*/ DuplicateProviderException_base {
}
declare const EnableSoftwareTokenMFAException_base: S.Class<EnableSoftwareTokenMFAException, S.TaggedStruct<"EnableSoftwareTokenMFAException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EnableSoftwareTokenMFAException extends /*@__PURE__*/ EnableSoftwareTokenMFAException_base {
}
declare const ExpiredCodeException_base: S.Class<ExpiredCodeException, S.TaggedStruct<"ExpiredCodeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredCodeException extends /*@__PURE__*/ ExpiredCodeException_base {
}
declare const FeatureUnavailableInTierException_base: S.Class<FeatureUnavailableInTierException, S.TaggedStruct<"FeatureUnavailableInTierException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class FeatureUnavailableInTierException extends /*@__PURE__*/ FeatureUnavailableInTierException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GroupExistsException_base: S.Class<GroupExistsException, S.TaggedStruct<"GroupExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GroupExistsException extends /*@__PURE__*/ GroupExistsException_base {
}
declare const InternalErrorException_base: S.Class<InternalErrorException, S.TaggedStruct<"InternalErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidEmailRoleAccessPolicyException_base: S.Class<InvalidEmailRoleAccessPolicyException, S.TaggedStruct<"InvalidEmailRoleAccessPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEmailRoleAccessPolicyException extends /*@__PURE__*/ InvalidEmailRoleAccessPolicyException_base {
}
declare const InvalidLambdaResponseException_base: S.Class<InvalidLambdaResponseException, S.TaggedStruct<"InvalidLambdaResponseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidLambdaResponseException extends /*@__PURE__*/ InvalidLambdaResponseException_base {
}
declare const InvalidOAuthFlowException_base: S.Class<InvalidOAuthFlowException, S.TaggedStruct<"InvalidOAuthFlowException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOAuthFlowException extends /*@__PURE__*/ InvalidOAuthFlowException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
    readonly reasonCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidPasswordException_base: S.Class<InvalidPasswordException, S.TaggedStruct<"InvalidPasswordException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPasswordException extends /*@__PURE__*/ InvalidPasswordException_base {
}
declare const InvalidSmsRoleAccessPolicyException_base: S.Class<InvalidSmsRoleAccessPolicyException, S.TaggedStruct<"InvalidSmsRoleAccessPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSmsRoleAccessPolicyException extends /*@__PURE__*/ InvalidSmsRoleAccessPolicyException_base {
}
declare const InvalidSmsRoleTrustRelationshipException_base: S.Class<InvalidSmsRoleTrustRelationshipException, S.TaggedStruct<"InvalidSmsRoleTrustRelationshipException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSmsRoleTrustRelationshipException extends /*@__PURE__*/ InvalidSmsRoleTrustRelationshipException_base {
}
declare const InvalidUserPoolConfigurationException_base: S.Class<InvalidUserPoolConfigurationException, S.TaggedStruct<"InvalidUserPoolConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserPoolConfigurationException extends /*@__PURE__*/ InvalidUserPoolConfigurationException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ManagedLoginBrandingExistsException_base: S.Class<ManagedLoginBrandingExistsException, S.TaggedStruct<"ManagedLoginBrandingExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ManagedLoginBrandingExistsException extends /*@__PURE__*/ ManagedLoginBrandingExistsException_base {
}
declare const MFAMethodNotFoundException_base: S.Class<MFAMethodNotFoundException, S.TaggedStruct<"MFAMethodNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MFAMethodNotFoundException extends /*@__PURE__*/ MFAMethodNotFoundException_base {
}
declare const NotAuthorizedException_base: S.Class<NotAuthorizedException, S.TaggedStruct<"NotAuthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const OperationNotEnabledException_base: S.Class<OperationNotEnabledException, S.TaggedStruct<"OperationNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotEnabledException extends /*@__PURE__*/ OperationNotEnabledException_base {
}
declare const PasswordHistoryPolicyViolationException_base: S.Class<PasswordHistoryPolicyViolationException, S.TaggedStruct<"PasswordHistoryPolicyViolationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PasswordHistoryPolicyViolationException extends /*@__PURE__*/ PasswordHistoryPolicyViolationException_base {
}
declare const PasswordResetRequiredException_base: S.Class<PasswordResetRequiredException, S.TaggedStruct<"PasswordResetRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PasswordResetRequiredException extends /*@__PURE__*/ PasswordResetRequiredException_base {
}
declare const PreconditionNotMetException_base: S.Class<PreconditionNotMetException, S.TaggedStruct<"PreconditionNotMetException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PreconditionNotMetException extends /*@__PURE__*/ PreconditionNotMetException_base {
}
declare const RefreshTokenReuseException_base: S.Class<RefreshTokenReuseException, S.TaggedStruct<"RefreshTokenReuseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RefreshTokenReuseException extends /*@__PURE__*/ RefreshTokenReuseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ScopeDoesNotExistException_base: S.Class<ScopeDoesNotExistException, S.TaggedStruct<"ScopeDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ScopeDoesNotExistException extends /*@__PURE__*/ ScopeDoesNotExistException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SoftwareTokenMFANotFoundException_base: S.Class<SoftwareTokenMFANotFoundException, S.TaggedStruct<"SoftwareTokenMFANotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SoftwareTokenMFANotFoundException extends /*@__PURE__*/ SoftwareTokenMFANotFoundException_base {
}
declare const TermsExistsException_base: S.Class<TermsExistsException, S.TaggedStruct<"TermsExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TermsExistsException extends /*@__PURE__*/ TermsExistsException_base {
}
declare const TierChangeNotAllowedException_base: S.Class<TierChangeNotAllowedException, S.TaggedStruct<"TierChangeNotAllowedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class TierChangeNotAllowedException extends /*@__PURE__*/ TierChangeNotAllowedException_base {
}
declare const TooManyFailedAttemptsException_base: S.Class<TooManyFailedAttemptsException, S.TaggedStruct<"TooManyFailedAttemptsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyFailedAttemptsException extends /*@__PURE__*/ TooManyFailedAttemptsException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnexpectedLambdaException_base: S.Class<UnexpectedLambdaException, S.TaggedStruct<"UnexpectedLambdaException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnexpectedLambdaException extends /*@__PURE__*/ UnexpectedLambdaException_base {
}
declare const UnsupportedIdentityProviderException_base: S.Class<UnsupportedIdentityProviderException, S.TaggedStruct<"UnsupportedIdentityProviderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedIdentityProviderException extends /*@__PURE__*/ UnsupportedIdentityProviderException_base {
}
declare const UnsupportedOperationException_base: S.Class<UnsupportedOperationException, S.TaggedStruct<"UnsupportedOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
declare const UnsupportedTokenTypeException_base: S.Class<UnsupportedTokenTypeException, S.TaggedStruct<"UnsupportedTokenTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedTokenTypeException extends /*@__PURE__*/ UnsupportedTokenTypeException_base {
}
declare const UnsupportedUserStateException_base: S.Class<UnsupportedUserStateException, S.TaggedStruct<"UnsupportedUserStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedUserStateException extends /*@__PURE__*/ UnsupportedUserStateException_base {
}
declare const UserImportInProgressException_base: S.Class<UserImportInProgressException, S.TaggedStruct<"UserImportInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserImportInProgressException extends /*@__PURE__*/ UserImportInProgressException_base {
}
declare const UserLambdaValidationException_base: S.Class<UserLambdaValidationException, S.TaggedStruct<"UserLambdaValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserLambdaValidationException extends /*@__PURE__*/ UserLambdaValidationException_base {
}
declare const UsernameExistsException_base: S.Class<UsernameExistsException, S.TaggedStruct<"UsernameExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UsernameExistsException extends /*@__PURE__*/ UsernameExistsException_base {
}
declare const UserNotConfirmedException_base: S.Class<UserNotConfirmedException, S.TaggedStruct<"UserNotConfirmedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotConfirmedException extends /*@__PURE__*/ UserNotConfirmedException_base {
}
declare const UserNotFoundException_base: S.Class<UserNotFoundException, S.TaggedStruct<"UserNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundException extends /*@__PURE__*/ UserNotFoundException_base {
}
declare const UserPoolAddOnNotEnabledException_base: S.Class<UserPoolAddOnNotEnabledException, S.TaggedStruct<"UserPoolAddOnNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserPoolAddOnNotEnabledException extends /*@__PURE__*/ UserPoolAddOnNotEnabledException_base {
}
declare const UserPoolTaggingException_base: S.Class<UserPoolTaggingException, S.TaggedStruct<"UserPoolTaggingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserPoolTaggingException extends /*@__PURE__*/ UserPoolTaggingException_base {
}
declare const WebAuthnChallengeNotFoundException_base: S.Class<WebAuthnChallengeNotFoundException, S.TaggedStruct<"WebAuthnChallengeNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnChallengeNotFoundException extends /*@__PURE__*/ WebAuthnChallengeNotFoundException_base {
}
declare const WebAuthnClientMismatchException_base: S.Class<WebAuthnClientMismatchException, S.TaggedStruct<"WebAuthnClientMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnClientMismatchException extends /*@__PURE__*/ WebAuthnClientMismatchException_base {
}
declare const WebAuthnConfigurationMissingException_base: S.Class<WebAuthnConfigurationMissingException, S.TaggedStruct<"WebAuthnConfigurationMissingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnConfigurationMissingException extends /*@__PURE__*/ WebAuthnConfigurationMissingException_base {
}
declare const WebAuthnCredentialNotSupportedException_base: S.Class<WebAuthnCredentialNotSupportedException, S.TaggedStruct<"WebAuthnCredentialNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnCredentialNotSupportedException extends /*@__PURE__*/ WebAuthnCredentialNotSupportedException_base {
}
declare const WebAuthnNotEnabledException_base: S.Class<WebAuthnNotEnabledException, S.TaggedStruct<"WebAuthnNotEnabledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnNotEnabledException extends /*@__PURE__*/ WebAuthnNotEnabledException_base {
}
declare const WebAuthnOriginNotAllowedException_base: S.Class<WebAuthnOriginNotAllowedException, S.TaggedStruct<"WebAuthnOriginNotAllowedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnOriginNotAllowedException extends /*@__PURE__*/ WebAuthnOriginNotAllowedException_base {
}
declare const WebAuthnRelyingPartyMismatchException_base: S.Class<WebAuthnRelyingPartyMismatchException, S.TaggedStruct<"WebAuthnRelyingPartyMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class WebAuthnRelyingPartyMismatchException extends /*@__PURE__*/ WebAuthnRelyingPartyMismatchException_base {
}
export type UserPoolIdType = string;
export type CustomAttributeNameType = string;
export type AttributeDataType = "String" | "Number" | "DateTime" | "Boolean" | (string & {});
export declare const AttributeDataType: any;
export type StringType = string;
export interface NumberAttributeConstraintsType {
    MinValue?: string;
    MaxValue?: string;
}
export declare const NumberAttributeConstraintsType: S.Schema<NumberAttributeConstraintsType>;
export interface StringAttributeConstraintsType {
    MinLength?: string;
    MaxLength?: string;
}
export declare const StringAttributeConstraintsType: S.Schema<StringAttributeConstraintsType>;
export interface SchemaAttributeType {
    Name?: string;
    AttributeDataType?: AttributeDataType;
    DeveloperOnlyAttribute?: boolean;
    Mutable?: boolean;
    Required?: boolean;
    NumberAttributeConstraints?: NumberAttributeConstraintsType;
    StringAttributeConstraints?: StringAttributeConstraintsType;
}
export declare const SchemaAttributeType: S.Schema<SchemaAttributeType>;
export type CustomAttributesListType = SchemaAttributeType[];
export declare const CustomAttributesListType: any;
export interface AddCustomAttributesRequest {
    UserPoolId: string;
    CustomAttributes: SchemaAttributeType[];
}
export declare const AddCustomAttributesRequest: S.Schema<AddCustomAttributesRequest>;
export interface AddCustomAttributesResponse {
}
export declare const AddCustomAttributesResponse: S.Schema<AddCustomAttributesResponse>;
export type ClientIdType = string | redacted.Redacted<string>;
export type ClientSecretType = string | redacted.Redacted<string>;
export interface AddUserPoolClientSecretRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ClientSecret?: string | redacted.Redacted<string>;
}
export declare const AddUserPoolClientSecretRequest: S.Schema<AddUserPoolClientSecretRequest>;
export type ClientSecretIdType = string;
export interface ClientSecretDescriptorType {
    ClientSecretId?: string;
    ClientSecretValue?: string | redacted.Redacted<string>;
    ClientSecretCreateDate?: Date;
}
export declare const ClientSecretDescriptorType: S.Schema<ClientSecretDescriptorType>;
export interface AddUserPoolClientSecretResponse {
    ClientSecretDescriptor?: ClientSecretDescriptorType;
}
export declare const AddUserPoolClientSecretResponse: S.Schema<AddUserPoolClientSecretResponse>;
export type UsernameType = string | redacted.Redacted<string>;
export type GroupNameType = string;
export interface AdminAddUserToGroupRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    GroupName: string;
}
export declare const AdminAddUserToGroupRequest: S.Schema<AdminAddUserToGroupRequest>;
export interface AdminAddUserToGroupResponse {
}
export declare const AdminAddUserToGroupResponse: S.Schema<AdminAddUserToGroupResponse>;
export type ClientMetadataType = {
    [key: string]: string | undefined;
};
export declare const ClientMetadataType: any;
export interface AdminConfirmSignUpRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const AdminConfirmSignUpRequest: S.Schema<AdminConfirmSignUpRequest>;
export interface AdminConfirmSignUpResponse {
}
export declare const AdminConfirmSignUpResponse: S.Schema<AdminConfirmSignUpResponse>;
export type AttributeNameType = string;
export type AttributeValueType = string | redacted.Redacted<string>;
export interface AttributeType {
    Name: string;
    Value?: string | redacted.Redacted<string>;
}
export declare const AttributeType: S.Schema<AttributeType>;
export type AttributeListType = AttributeType[];
export declare const AttributeListType: any;
export type PasswordType = string | redacted.Redacted<string>;
export type ForceAliasCreation = boolean;
export type MessageActionType = "RESEND" | "SUPPRESS" | (string & {});
export declare const MessageActionType: any;
export type DeliveryMediumType = "SMS" | "EMAIL" | (string & {});
export declare const DeliveryMediumType: any;
export type DeliveryMediumListType = DeliveryMediumType[];
export declare const DeliveryMediumListType: any;
export interface AdminCreateUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    UserAttributes?: AttributeType[];
    ValidationData?: AttributeType[];
    TemporaryPassword?: string | redacted.Redacted<string>;
    ForceAliasCreation?: boolean;
    MessageAction?: MessageActionType;
    DesiredDeliveryMediums?: DeliveryMediumType[];
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const AdminCreateUserRequest: S.Schema<AdminCreateUserRequest>;
export type UserStatusType = "UNCONFIRMED" | "CONFIRMED" | "ARCHIVED" | "COMPROMISED" | "UNKNOWN" | "RESET_REQUIRED" | "FORCE_CHANGE_PASSWORD" | "EXTERNAL_PROVIDER" | (string & {});
export declare const UserStatusType: any;
export interface MFAOptionType {
    DeliveryMedium?: DeliveryMediumType;
    AttributeName?: string;
}
export declare const MFAOptionType: S.Schema<MFAOptionType>;
export type MFAOptionListType = MFAOptionType[];
export declare const MFAOptionListType: any;
export interface UserType {
    Username?: string | redacted.Redacted<string>;
    Attributes?: AttributeType[];
    UserCreateDate?: Date;
    UserLastModifiedDate?: Date;
    Enabled?: boolean;
    UserStatus?: UserStatusType;
    MFAOptions?: MFAOptionType[];
}
export declare const UserType: S.Schema<UserType>;
export interface AdminCreateUserResponse {
    User?: UserType;
}
export declare const AdminCreateUserResponse: S.Schema<AdminCreateUserResponse>;
export interface AdminDeleteSoftwareTokenRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminDeleteSoftwareTokenRequest: S.Schema<AdminDeleteSoftwareTokenRequest>;
export interface AdminDeleteSoftwareTokenResponse {
}
export declare const AdminDeleteSoftwareTokenResponse: S.Schema<AdminDeleteSoftwareTokenResponse>;
export interface AdminDeleteUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminDeleteUserRequest: S.Schema<AdminDeleteUserRequest>;
export interface AdminDeleteUserResponse {
}
export declare const AdminDeleteUserResponse: S.Schema<AdminDeleteUserResponse>;
export type AttributeNameListType = string[];
export declare const AttributeNameListType: any;
export interface AdminDeleteUserAttributesRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    UserAttributeNames: string[];
}
export declare const AdminDeleteUserAttributesRequest: S.Schema<AdminDeleteUserAttributesRequest>;
export interface AdminDeleteUserAttributesResponse {
}
export declare const AdminDeleteUserAttributesResponse: S.Schema<AdminDeleteUserAttributesResponse>;
export type ProviderNameType = string;
export interface ProviderUserIdentifierType {
    ProviderName?: string;
    ProviderAttributeName?: string;
    ProviderAttributeValue?: string;
}
export declare const ProviderUserIdentifierType: S.Schema<ProviderUserIdentifierType>;
export interface AdminDisableProviderForUserRequest {
    UserPoolId: string;
    User: ProviderUserIdentifierType;
}
export declare const AdminDisableProviderForUserRequest: S.Schema<AdminDisableProviderForUserRequest>;
export interface AdminDisableProviderForUserResponse {
}
export declare const AdminDisableProviderForUserResponse: S.Schema<AdminDisableProviderForUserResponse>;
export interface AdminDisableUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminDisableUserRequest: S.Schema<AdminDisableUserRequest>;
export interface AdminDisableUserResponse {
}
export declare const AdminDisableUserResponse: S.Schema<AdminDisableUserResponse>;
export interface AdminEnableUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminEnableUserRequest: S.Schema<AdminEnableUserRequest>;
export interface AdminEnableUserResponse {
}
export declare const AdminEnableUserResponse: S.Schema<AdminEnableUserResponse>;
export type DeviceKeyType = string;
export interface AdminForgetDeviceRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    DeviceKey: string;
}
export declare const AdminForgetDeviceRequest: S.Schema<AdminForgetDeviceRequest>;
export interface AdminForgetDeviceResponse {
}
export declare const AdminForgetDeviceResponse: S.Schema<AdminForgetDeviceResponse>;
export interface AdminGetDeviceRequest {
    DeviceKey: string;
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminGetDeviceRequest: S.Schema<AdminGetDeviceRequest>;
export interface DeviceType {
    DeviceKey?: string;
    DeviceAttributes?: AttributeType[];
    DeviceCreateDate?: Date;
    DeviceLastModifiedDate?: Date;
    DeviceLastAuthenticatedDate?: Date;
}
export declare const DeviceType: S.Schema<DeviceType>;
export interface AdminGetDeviceResponse {
    Device: DeviceType;
}
export declare const AdminGetDeviceResponse: S.Schema<AdminGetDeviceResponse>;
export interface AdminGetUserRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminGetUserRequest: S.Schema<AdminGetUserRequest>;
export type UserMFASettingListType = string[];
export declare const UserMFASettingListType: any;
export interface AdminGetUserResponse {
    Username: string | redacted.Redacted<string>;
    UserAttributes?: AttributeType[];
    UserCreateDate?: Date;
    UserLastModifiedDate?: Date;
    Enabled?: boolean;
    UserStatus?: UserStatusType;
    MFAOptions?: MFAOptionType[];
    PreferredMfaSetting?: string;
    UserMFASettingList?: string[];
}
export declare const AdminGetUserResponse: S.Schema<AdminGetUserResponse>;
export interface AdminGetUserAuthFactorsRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminGetUserAuthFactorsRequest: S.Schema<AdminGetUserAuthFactorsRequest>;
export type AuthFactorType = "PASSWORD" | "EMAIL_OTP" | "SMS_OTP" | "WEB_AUTHN" | "SOFTWARE_TOKEN" | (string & {});
export declare const AuthFactorType: any;
export type ConfiguredUserAuthFactorsListType = AuthFactorType[];
export declare const ConfiguredUserAuthFactorsListType: any;
export interface AdminGetUserAuthFactorsResponse {
    Username: string | redacted.Redacted<string>;
    PreferredMfaSetting?: string;
    UserMFASettingList?: string[];
    ConfiguredUserAuthFactors?: AuthFactorType[];
}
export declare const AdminGetUserAuthFactorsResponse: S.Schema<AdminGetUserAuthFactorsResponse>;
export type AuthFlowType = "USER_SRP_AUTH" | "REFRESH_TOKEN_AUTH" | "REFRESH_TOKEN" | "CUSTOM_AUTH" | "ADMIN_NO_SRP_AUTH" | "USER_PASSWORD_AUTH" | "ADMIN_USER_PASSWORD_AUTH" | "USER_AUTH" | (string & {});
export declare const AuthFlowType: any;
export type AuthParametersType = {
    [key: string]: string | undefined;
};
export declare const AuthParametersType: any;
export interface AnalyticsMetadataType {
    AnalyticsEndpointId?: string;
}
export declare const AnalyticsMetadataType: S.Schema<AnalyticsMetadataType>;
export interface HttpHeader {
    headerName?: string;
    headerValue?: string;
}
export declare const HttpHeader: S.Schema<HttpHeader>;
export type HttpHeaderList = HttpHeader[];
export declare const HttpHeaderList: any;
export interface ContextDataType {
    IpAddress: string;
    ServerName: string;
    ServerPath: string;
    HttpHeaders: HttpHeader[];
    EncodedData?: string;
}
export declare const ContextDataType: S.Schema<ContextDataType>;
export type SessionType = string | redacted.Redacted<string>;
export interface AdminInitiateAuthRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    AuthFlow: AuthFlowType;
    AuthParameters?: {
        [key: string]: string | undefined;
    };
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
    AnalyticsMetadata?: AnalyticsMetadataType;
    ContextData?: ContextDataType;
    Session?: string | redacted.Redacted<string>;
}
export declare const AdminInitiateAuthRequest: S.Schema<AdminInitiateAuthRequest>;
export type ChallengeNameType = "SMS_MFA" | "EMAIL_OTP" | "SOFTWARE_TOKEN_MFA" | "SELECT_MFA_TYPE" | "MFA_SETUP" | "PASSWORD_VERIFIER" | "CUSTOM_CHALLENGE" | "SELECT_CHALLENGE" | "DEVICE_SRP_AUTH" | "DEVICE_PASSWORD_VERIFIER" | "ADMIN_NO_SRP_AUTH" | "NEW_PASSWORD_REQUIRED" | "SMS_OTP" | "PASSWORD" | "WEB_AUTHN" | "PASSWORD_SRP" | (string & {});
export declare const ChallengeNameType: any;
export type ChallengeParametersType = {
    [key: string]: string | undefined;
};
export declare const ChallengeParametersType: any;
export type TokenModelType = string | redacted.Redacted<string>;
export type IntegerType = number;
export interface NewDeviceMetadataType {
    DeviceKey?: string;
    DeviceGroupKey?: string;
}
export declare const NewDeviceMetadataType: S.Schema<NewDeviceMetadataType>;
export interface AuthenticationResultType {
    AccessToken?: string | redacted.Redacted<string>;
    ExpiresIn?: number;
    TokenType?: string;
    RefreshToken?: string | redacted.Redacted<string>;
    IdToken?: string | redacted.Redacted<string>;
    NewDeviceMetadata?: NewDeviceMetadataType;
}
export declare const AuthenticationResultType: S.Schema<AuthenticationResultType>;
export type AvailableChallengeListType = ChallengeNameType[];
export declare const AvailableChallengeListType: any;
export interface AdminInitiateAuthResponse {
    ChallengeName?: ChallengeNameType;
    Session?: string | redacted.Redacted<string>;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    };
    AuthenticationResult?: AuthenticationResultType;
    AvailableChallenges?: ChallengeNameType[];
}
export declare const AdminInitiateAuthResponse: S.Schema<AdminInitiateAuthResponse>;
export interface AdminLinkProviderForUserRequest {
    UserPoolId: string;
    DestinationUser: ProviderUserIdentifierType;
    SourceUser: ProviderUserIdentifierType;
}
export declare const AdminLinkProviderForUserRequest: S.Schema<AdminLinkProviderForUserRequest>;
export interface AdminLinkProviderForUserResponse {
}
export declare const AdminLinkProviderForUserResponse: S.Schema<AdminLinkProviderForUserResponse>;
export type QueryLimitType = number;
export type SearchPaginationTokenType = string;
export interface AdminListDevicesRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    Limit?: number;
    PaginationToken?: string;
}
export declare const AdminListDevicesRequest: S.Schema<AdminListDevicesRequest>;
export type DeviceListType = DeviceType[];
export declare const DeviceListType: any;
export interface AdminListDevicesResponse {
    Devices?: DeviceType[];
    PaginationToken?: string;
}
export declare const AdminListDevicesResponse: S.Schema<AdminListDevicesResponse>;
export type PaginationKey = string;
export interface AdminListGroupsForUserRequest {
    Username: string | redacted.Redacted<string>;
    UserPoolId: string;
    Limit?: number;
    NextToken?: string;
}
export declare const AdminListGroupsForUserRequest: S.Schema<AdminListGroupsForUserRequest>;
export type DescriptionType = string;
export type ArnType = string;
export type PrecedenceType = number;
export interface GroupType {
    GroupName?: string;
    UserPoolId?: string;
    Description?: string;
    RoleArn?: string;
    Precedence?: number;
    LastModifiedDate?: Date;
    CreationDate?: Date;
}
export declare const GroupType: S.Schema<GroupType>;
export type GroupListType = GroupType[];
export declare const GroupListType: any;
export interface AdminListGroupsForUserResponse {
    Groups?: GroupType[];
    NextToken?: string;
}
export declare const AdminListGroupsForUserResponse: S.Schema<AdminListGroupsForUserResponse>;
export interface AdminListUserAuthEventsRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    MaxResults?: number;
    NextToken?: string;
}
export declare const AdminListUserAuthEventsRequest: S.Schema<AdminListUserAuthEventsRequest>;
export type EventType = "SignIn" | "SignUp" | "ForgotPassword" | "PasswordChange" | "ResendCode" | (string & {});
export declare const EventType: any;
export type EventResponseType = "Pass" | "Fail" | "InProgress" | (string & {});
export declare const EventResponseType: any;
export type RiskDecisionType = "NoRisk" | "AccountTakeover" | "Block" | (string & {});
export declare const RiskDecisionType: any;
export type RiskLevelType = "Low" | "Medium" | "High" | (string & {});
export declare const RiskLevelType: any;
export type WrappedBooleanType = boolean;
export interface EventRiskType {
    RiskDecision?: RiskDecisionType;
    RiskLevel?: RiskLevelType;
    CompromisedCredentialsDetected?: boolean;
}
export declare const EventRiskType: S.Schema<EventRiskType>;
export type ChallengeName = "Password" | "Mfa" | (string & {});
export declare const ChallengeName: any;
export type ChallengeResponse = "Success" | "Failure" | (string & {});
export declare const ChallengeResponse: any;
export interface ChallengeResponseType {
    ChallengeName?: ChallengeName;
    ChallengeResponse?: ChallengeResponse;
}
export declare const ChallengeResponseType: S.Schema<ChallengeResponseType>;
export type ChallengeResponseListType = ChallengeResponseType[];
export declare const ChallengeResponseListType: any;
export interface EventContextDataType {
    IpAddress?: string;
    DeviceName?: string;
    Timezone?: string;
    City?: string;
    Country?: string;
}
export declare const EventContextDataType: S.Schema<EventContextDataType>;
export type FeedbackValueType = "Valid" | "Invalid" | (string & {});
export declare const FeedbackValueType: any;
export interface EventFeedbackType {
    FeedbackValue: FeedbackValueType;
    Provider: string;
    FeedbackDate?: Date;
}
export declare const EventFeedbackType: S.Schema<EventFeedbackType>;
export interface AuthEventType {
    EventId?: string;
    EventType?: EventType;
    CreationDate?: Date;
    EventResponse?: EventResponseType;
    EventRisk?: EventRiskType;
    ChallengeResponses?: ChallengeResponseType[];
    EventContextData?: EventContextDataType;
    EventFeedback?: EventFeedbackType;
}
export declare const AuthEventType: S.Schema<AuthEventType>;
export type AuthEventsType = AuthEventType[];
export declare const AuthEventsType: any;
export interface AdminListUserAuthEventsResponse {
    AuthEvents?: AuthEventType[];
    NextToken?: string;
}
export declare const AdminListUserAuthEventsResponse: S.Schema<AdminListUserAuthEventsResponse>;
export interface AdminRemoveUserFromGroupRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    GroupName: string;
}
export declare const AdminRemoveUserFromGroupRequest: S.Schema<AdminRemoveUserFromGroupRequest>;
export interface AdminRemoveUserFromGroupResponse {
}
export declare const AdminRemoveUserFromGroupResponse: S.Schema<AdminRemoveUserFromGroupResponse>;
export interface AdminResetUserPasswordRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const AdminResetUserPasswordRequest: S.Schema<AdminResetUserPasswordRequest>;
export interface AdminResetUserPasswordResponse {
}
export declare const AdminResetUserPasswordResponse: S.Schema<AdminResetUserPasswordResponse>;
export type ChallengeResponsesType = {
    [key: string]: string | undefined;
};
export declare const ChallengeResponsesType: any;
export interface AdminRespondToAuthChallengeRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ChallengeName: ChallengeNameType;
    ChallengeResponses?: {
        [key: string]: string | undefined;
    };
    Session?: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType;
    ContextData?: ContextDataType;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const AdminRespondToAuthChallengeRequest: S.Schema<AdminRespondToAuthChallengeRequest>;
export interface AdminRespondToAuthChallengeResponse {
    ChallengeName?: ChallengeNameType;
    Session?: string | redacted.Redacted<string>;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    };
    AuthenticationResult?: AuthenticationResultType;
}
export declare const AdminRespondToAuthChallengeResponse: S.Schema<AdminRespondToAuthChallengeResponse>;
export interface SMSMfaSettingsType {
    Enabled?: boolean;
    PreferredMfa?: boolean;
}
export declare const SMSMfaSettingsType: S.Schema<SMSMfaSettingsType>;
export interface SoftwareTokenMfaSettingsType {
    Enabled?: boolean;
    PreferredMfa?: boolean;
}
export declare const SoftwareTokenMfaSettingsType: S.Schema<SoftwareTokenMfaSettingsType>;
export interface EmailMfaSettingsType {
    Enabled?: boolean;
    PreferredMfa?: boolean;
}
export declare const EmailMfaSettingsType: S.Schema<EmailMfaSettingsType>;
export interface WebAuthnMfaSettingsType {
    Enabled?: boolean;
}
export declare const WebAuthnMfaSettingsType: S.Schema<WebAuthnMfaSettingsType>;
export interface AdminSetUserMFAPreferenceRequest {
    SMSMfaSettings?: SMSMfaSettingsType;
    SoftwareTokenMfaSettings?: SoftwareTokenMfaSettingsType;
    EmailMfaSettings?: EmailMfaSettingsType;
    WebAuthnMfaSettings?: WebAuthnMfaSettingsType;
    Username: string | redacted.Redacted<string>;
    UserPoolId: string;
}
export declare const AdminSetUserMFAPreferenceRequest: S.Schema<AdminSetUserMFAPreferenceRequest>;
export interface AdminSetUserMFAPreferenceResponse {
}
export declare const AdminSetUserMFAPreferenceResponse: S.Schema<AdminSetUserMFAPreferenceResponse>;
export interface AdminSetUserPasswordRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    Password: string | redacted.Redacted<string>;
    Permanent?: boolean;
}
export declare const AdminSetUserPasswordRequest: S.Schema<AdminSetUserPasswordRequest>;
export interface AdminSetUserPasswordResponse {
}
export declare const AdminSetUserPasswordResponse: S.Schema<AdminSetUserPasswordResponse>;
export interface AdminSetUserSettingsRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    MFAOptions: MFAOptionType[];
}
export declare const AdminSetUserSettingsRequest: S.Schema<AdminSetUserSettingsRequest>;
export interface AdminSetUserSettingsResponse {
}
export declare const AdminSetUserSettingsResponse: S.Schema<AdminSetUserSettingsResponse>;
export type EventIdType = string;
export interface AdminUpdateAuthEventFeedbackRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    EventId: string;
    FeedbackValue: FeedbackValueType;
}
export declare const AdminUpdateAuthEventFeedbackRequest: S.Schema<AdminUpdateAuthEventFeedbackRequest>;
export interface AdminUpdateAuthEventFeedbackResponse {
}
export declare const AdminUpdateAuthEventFeedbackResponse: S.Schema<AdminUpdateAuthEventFeedbackResponse>;
export type DeviceRememberedStatusType = "remembered" | "not_remembered" | (string & {});
export declare const DeviceRememberedStatusType: any;
export interface AdminUpdateDeviceStatusRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    DeviceKey: string;
    DeviceRememberedStatus?: DeviceRememberedStatusType;
}
export declare const AdminUpdateDeviceStatusRequest: S.Schema<AdminUpdateDeviceStatusRequest>;
export interface AdminUpdateDeviceStatusResponse {
}
export declare const AdminUpdateDeviceStatusResponse: S.Schema<AdminUpdateDeviceStatusResponse>;
export interface AdminUpdateUserAttributesRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    UserAttributes: AttributeType[];
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const AdminUpdateUserAttributesRequest: S.Schema<AdminUpdateUserAttributesRequest>;
export interface AdminUpdateUserAttributesResponse {
}
export declare const AdminUpdateUserAttributesResponse: S.Schema<AdminUpdateUserAttributesResponse>;
export interface AdminUserGlobalSignOutRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
}
export declare const AdminUserGlobalSignOutRequest: S.Schema<AdminUserGlobalSignOutRequest>;
export interface AdminUserGlobalSignOutResponse {
}
export declare const AdminUserGlobalSignOutResponse: S.Schema<AdminUserGlobalSignOutResponse>;
export interface AssociateSoftwareTokenRequest {
    AccessToken?: string | redacted.Redacted<string>;
    Session?: string | redacted.Redacted<string>;
}
export declare const AssociateSoftwareTokenRequest: S.Schema<AssociateSoftwareTokenRequest>;
export type SecretCodeType = string | redacted.Redacted<string>;
export interface AssociateSoftwareTokenResponse {
    SecretCode?: string | redacted.Redacted<string>;
    Session?: string | redacted.Redacted<string>;
}
export declare const AssociateSoftwareTokenResponse: S.Schema<AssociateSoftwareTokenResponse>;
export interface ChangePasswordRequest {
    PreviousPassword?: string | redacted.Redacted<string>;
    ProposedPassword: string | redacted.Redacted<string>;
    AccessToken: string | redacted.Redacted<string>;
}
export declare const ChangePasswordRequest: S.Schema<ChangePasswordRequest>;
export interface ChangePasswordResponse {
}
export declare const ChangePasswordResponse: S.Schema<ChangePasswordResponse>;
export type Document = unknown;
export interface CompleteWebAuthnRegistrationRequest {
    AccessToken: string | redacted.Redacted<string>;
    Credential: any;
}
export declare const CompleteWebAuthnRegistrationRequest: S.Schema<CompleteWebAuthnRegistrationRequest>;
export interface CompleteWebAuthnRegistrationResponse {
}
export declare const CompleteWebAuthnRegistrationResponse: S.Schema<CompleteWebAuthnRegistrationResponse>;
export interface DeviceSecretVerifierConfigType {
    PasswordVerifier?: string;
    Salt?: string;
}
export declare const DeviceSecretVerifierConfigType: S.Schema<DeviceSecretVerifierConfigType>;
export type DeviceNameType = string;
export interface ConfirmDeviceRequest {
    AccessToken: string | redacted.Redacted<string>;
    DeviceKey: string;
    DeviceSecretVerifierConfig?: DeviceSecretVerifierConfigType;
    DeviceName?: string;
}
export declare const ConfirmDeviceRequest: S.Schema<ConfirmDeviceRequest>;
export interface ConfirmDeviceResponse {
    UserConfirmationNecessary?: boolean;
}
export declare const ConfirmDeviceResponse: S.Schema<ConfirmDeviceResponse>;
export type SecretHashType = string | redacted.Redacted<string>;
export type ConfirmationCodeType = string;
export interface UserContextDataType {
    IpAddress?: string;
    EncodedData?: string;
}
export declare const UserContextDataType: S.Schema<UserContextDataType>;
export interface ConfirmForgotPasswordRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string>;
    Username: string | redacted.Redacted<string>;
    ConfirmationCode: string;
    Password: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType;
    UserContextData?: UserContextDataType;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const ConfirmForgotPasswordRequest: S.Schema<ConfirmForgotPasswordRequest>;
export interface ConfirmForgotPasswordResponse {
}
export declare const ConfirmForgotPasswordResponse: S.Schema<ConfirmForgotPasswordResponse>;
export interface ConfirmSignUpRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string>;
    Username: string | redacted.Redacted<string>;
    ConfirmationCode: string;
    ForceAliasCreation?: boolean;
    AnalyticsMetadata?: AnalyticsMetadataType;
    UserContextData?: UserContextDataType;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
    Session?: string | redacted.Redacted<string>;
}
export declare const ConfirmSignUpRequest: S.Schema<ConfirmSignUpRequest>;
export interface ConfirmSignUpResponse {
    Session?: string | redacted.Redacted<string>;
}
export declare const ConfirmSignUpResponse: S.Schema<ConfirmSignUpResponse>;
export interface CreateGroupRequest {
    GroupName: string;
    UserPoolId: string;
    Description?: string;
    RoleArn?: string;
    Precedence?: number;
}
export declare const CreateGroupRequest: S.Schema<CreateGroupRequest>;
export interface CreateGroupResponse {
    Group?: GroupType;
}
export declare const CreateGroupResponse: S.Schema<CreateGroupResponse>;
export type ProviderNameTypeV2 = string;
export type IdentityProviderTypeType = "SAML" | "Facebook" | "Google" | "LoginWithAmazon" | "SignInWithApple" | "OIDC" | (string & {});
export declare const IdentityProviderTypeType: any;
export type ProviderDetailsType = {
    [key: string]: string | undefined;
};
export declare const ProviderDetailsType: any;
export type AttributeMappingKeyType = string;
export type AttributeMappingType = {
    [key: string]: string | undefined;
};
export declare const AttributeMappingType: any;
export type IdpIdentifierType = string;
export type IdpIdentifiersListType = string[];
export declare const IdpIdentifiersListType: any;
export interface CreateIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
    ProviderType: IdentityProviderTypeType;
    ProviderDetails: {
        [key: string]: string | undefined;
    };
    AttributeMapping?: {
        [key: string]: string | undefined;
    };
    IdpIdentifiers?: string[];
}
export declare const CreateIdentityProviderRequest: S.Schema<CreateIdentityProviderRequest>;
export interface IdentityProviderType {
    UserPoolId?: string;
    ProviderName?: string;
    ProviderType?: IdentityProviderTypeType;
    ProviderDetails?: {
        [key: string]: string | undefined;
    };
    AttributeMapping?: {
        [key: string]: string | undefined;
    };
    IdpIdentifiers?: string[];
    LastModifiedDate?: Date;
    CreationDate?: Date;
}
export declare const IdentityProviderType: S.Schema<IdentityProviderType>;
export interface CreateIdentityProviderResponse {
    IdentityProvider: IdentityProviderType;
}
export declare const CreateIdentityProviderResponse: S.Schema<CreateIdentityProviderResponse>;
export type AssetCategoryType = "FAVICON_ICO" | "FAVICON_SVG" | "EMAIL_GRAPHIC" | "SMS_GRAPHIC" | "AUTH_APP_GRAPHIC" | "PASSWORD_GRAPHIC" | "PASSKEY_GRAPHIC" | "PAGE_HEADER_LOGO" | "PAGE_HEADER_BACKGROUND" | "PAGE_FOOTER_LOGO" | "PAGE_FOOTER_BACKGROUND" | "PAGE_BACKGROUND" | "FORM_BACKGROUND" | "FORM_LOGO" | "IDP_BUTTON_ICON" | (string & {});
export declare const AssetCategoryType: any;
export type ColorSchemeModeType = "LIGHT" | "DARK" | "DYNAMIC" | (string & {});
export declare const ColorSchemeModeType: any;
export type AssetExtensionType = "ICO" | "JPEG" | "PNG" | "SVG" | "WEBP" | (string & {});
export declare const AssetExtensionType: any;
export type AssetBytesType = Uint8Array;
export type ResourceIdType = string;
export interface AssetType {
    Category: AssetCategoryType;
    ColorMode: ColorSchemeModeType;
    Extension: AssetExtensionType;
    Bytes?: Uint8Array;
    ResourceId?: string;
}
export declare const AssetType: S.Schema<AssetType>;
export type AssetListType = AssetType[];
export declare const AssetListType: any;
export interface CreateManagedLoginBrandingRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    UseCognitoProvidedValues?: boolean;
    Settings?: any;
    Assets?: AssetType[];
}
export declare const CreateManagedLoginBrandingRequest: S.Schema<CreateManagedLoginBrandingRequest>;
export type ManagedLoginBrandingIdType = string;
export interface ManagedLoginBrandingType {
    ManagedLoginBrandingId?: string;
    UserPoolId?: string;
    UseCognitoProvidedValues?: boolean;
    Settings?: any;
    Assets?: AssetType[];
    CreationDate?: Date;
    LastModifiedDate?: Date;
}
export declare const ManagedLoginBrandingType: S.Schema<ManagedLoginBrandingType>;
export interface CreateManagedLoginBrandingResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType;
}
export declare const CreateManagedLoginBrandingResponse: S.Schema<CreateManagedLoginBrandingResponse>;
export type ResourceServerIdentifierType = string;
export type ResourceServerNameType = string;
export type ResourceServerScopeNameType = string;
export type ResourceServerScopeDescriptionType = string;
export interface ResourceServerScopeType {
    ScopeName: string;
    ScopeDescription: string;
}
export declare const ResourceServerScopeType: S.Schema<ResourceServerScopeType>;
export type ResourceServerScopeListType = ResourceServerScopeType[];
export declare const ResourceServerScopeListType: any;
export interface CreateResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
    Name: string;
    Scopes?: ResourceServerScopeType[];
}
export declare const CreateResourceServerRequest: S.Schema<CreateResourceServerRequest>;
export interface ResourceServerType {
    UserPoolId?: string;
    Identifier?: string;
    Name?: string;
    Scopes?: ResourceServerScopeType[];
}
export declare const ResourceServerType: S.Schema<ResourceServerType>;
export interface CreateResourceServerResponse {
    ResourceServer: ResourceServerType;
}
export declare const CreateResourceServerResponse: S.Schema<CreateResourceServerResponse>;
export type TermsNameType = string;
export type TermsSourceType = "LINK" | (string & {});
export declare const TermsSourceType: any;
export type TermsEnforcementType = "NONE" | (string & {});
export declare const TermsEnforcementType: any;
export type LanguageIdType = string;
export type LinkUrlType = string;
export type LinksType = {
    [key: string]: string | undefined;
};
export declare const LinksType: any;
export interface CreateTermsRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    TermsName: string;
    TermsSource: TermsSourceType;
    Enforcement: TermsEnforcementType;
    Links?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateTermsRequest: S.Schema<CreateTermsRequest>;
export type TermsIdType = string;
export interface TermsType {
    TermsId: string;
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    TermsName: string;
    TermsSource: TermsSourceType;
    Enforcement: TermsEnforcementType;
    Links: {
        [key: string]: string | undefined;
    };
    CreationDate: Date;
    LastModifiedDate: Date;
}
export declare const TermsType: S.Schema<TermsType>;
export interface CreateTermsResponse {
    Terms?: TermsType;
}
export declare const CreateTermsResponse: S.Schema<CreateTermsResponse>;
export type UserImportJobNameType = string;
export type PasswordHashingAlgorithmType = "BCRYPT" | "SCRYPT" | "ARGON2ID" | "PBKDF2_SHA256" | (string & {});
export declare const PasswordHashingAlgorithmType: any;
export interface CreateUserImportJobRequest {
    JobName: string;
    UserPoolId: string;
    CloudWatchLogsRoleArn: string;
    PasswordHashingAlgorithm?: PasswordHashingAlgorithmType;
}
export declare const CreateUserImportJobRequest: S.Schema<CreateUserImportJobRequest>;
export type UserImportJobIdType = string;
export type PreSignedUrlType = string;
export type UserImportJobStatusType = "Created" | "Pending" | "InProgress" | "Stopping" | "Expired" | "Stopped" | "Failed" | "Succeeded" | (string & {});
export declare const UserImportJobStatusType: any;
export type LongType = number;
export type CompletionMessageType = string;
export interface UserImportJobType {
    JobName?: string;
    JobId?: string;
    UserPoolId?: string;
    PreSignedUrl?: string;
    CreationDate?: Date;
    StartDate?: Date;
    CompletionDate?: Date;
    Status?: UserImportJobStatusType;
    CloudWatchLogsRoleArn?: string;
    ImportedUsers?: number;
    SkippedUsers?: number;
    FailedUsers?: number;
    CompletionMessage?: string;
    PasswordHashingAlgorithm?: PasswordHashingAlgorithmType;
}
export declare const UserImportJobType: S.Schema<UserImportJobType>;
export interface CreateUserImportJobResponse {
    UserImportJob?: UserImportJobType;
}
export declare const CreateUserImportJobResponse: S.Schema<CreateUserImportJobResponse>;
export type UserPoolNameType = string;
export type PasswordPolicyMinLengthType = number;
export type PasswordHistorySizeType = number;
export type TemporaryPasswordValidityDaysType = number;
export interface PasswordPolicyType {
    MinimumLength?: number;
    RequireUppercase?: boolean;
    RequireLowercase?: boolean;
    RequireNumbers?: boolean;
    RequireSymbols?: boolean;
    PasswordHistorySize?: number;
    TemporaryPasswordValidityDays?: number;
}
export declare const PasswordPolicyType: S.Schema<PasswordPolicyType>;
export type AllowedFirstAuthFactorsListType = AuthFactorType[];
export declare const AllowedFirstAuthFactorsListType: any;
export interface SignInPolicyType {
    AllowedFirstAuthFactors?: AuthFactorType[];
}
export declare const SignInPolicyType: S.Schema<SignInPolicyType>;
export interface UserPoolPolicyType {
    PasswordPolicy?: PasswordPolicyType;
    SignInPolicy?: SignInPolicyType;
}
export declare const UserPoolPolicyType: S.Schema<UserPoolPolicyType>;
export type DeletionProtectionType = "ACTIVE" | "INACTIVE" | (string & {});
export declare const DeletionProtectionType: any;
export type PreTokenGenerationLambdaVersionType = "V1_0" | "V2_0" | "V3_0" | (string & {});
export declare const PreTokenGenerationLambdaVersionType: any;
export interface PreTokenGenerationVersionConfigType {
    LambdaVersion: PreTokenGenerationLambdaVersionType;
    LambdaArn: string;
}
export declare const PreTokenGenerationVersionConfigType: S.Schema<PreTokenGenerationVersionConfigType>;
export type CustomSMSSenderLambdaVersionType = "V1_0" | (string & {});
export declare const CustomSMSSenderLambdaVersionType: any;
export interface CustomSMSLambdaVersionConfigType {
    LambdaVersion: CustomSMSSenderLambdaVersionType;
    LambdaArn: string;
}
export declare const CustomSMSLambdaVersionConfigType: S.Schema<CustomSMSLambdaVersionConfigType>;
export type CustomEmailSenderLambdaVersionType = "V1_0" | (string & {});
export declare const CustomEmailSenderLambdaVersionType: any;
export interface CustomEmailLambdaVersionConfigType {
    LambdaVersion: CustomEmailSenderLambdaVersionType;
    LambdaArn: string;
}
export declare const CustomEmailLambdaVersionConfigType: S.Schema<CustomEmailLambdaVersionConfigType>;
export type InboundFederationLambdaVersionType = "V1_0" | (string & {});
export declare const InboundFederationLambdaVersionType: any;
export interface InboundFederationLambdaType {
    LambdaVersion: InboundFederationLambdaVersionType;
    LambdaArn: string;
}
export declare const InboundFederationLambdaType: S.Schema<InboundFederationLambdaType>;
export interface LambdaConfigType {
    PreSignUp?: string;
    CustomMessage?: string;
    PostConfirmation?: string;
    PreAuthentication?: string;
    PostAuthentication?: string;
    DefineAuthChallenge?: string;
    CreateAuthChallenge?: string;
    VerifyAuthChallengeResponse?: string;
    PreTokenGeneration?: string;
    UserMigration?: string;
    PreTokenGenerationConfig?: PreTokenGenerationVersionConfigType;
    CustomSMSSender?: CustomSMSLambdaVersionConfigType;
    CustomEmailSender?: CustomEmailLambdaVersionConfigType;
    KMSKeyID?: string;
    InboundFederation?: InboundFederationLambdaType;
}
export declare const LambdaConfigType: S.Schema<LambdaConfigType>;
export type VerifiedAttributeType = "phone_number" | "email" | (string & {});
export declare const VerifiedAttributeType: any;
export type VerifiedAttributesListType = VerifiedAttributeType[];
export declare const VerifiedAttributesListType: any;
export type AliasAttributeType = "phone_number" | "email" | "preferred_username" | (string & {});
export declare const AliasAttributeType: any;
export type AliasAttributesListType = AliasAttributeType[];
export declare const AliasAttributesListType: any;
export type UsernameAttributeType = "phone_number" | "email" | (string & {});
export declare const UsernameAttributeType: any;
export type UsernameAttributesListType = UsernameAttributeType[];
export declare const UsernameAttributesListType: any;
export type SmsVerificationMessageType = string;
export type EmailVerificationMessageType = string;
export type EmailVerificationSubjectType = string;
export type EmailVerificationMessageByLinkType = string;
export type EmailVerificationSubjectByLinkType = string;
export type DefaultEmailOptionType = "CONFIRM_WITH_LINK" | "CONFIRM_WITH_CODE" | (string & {});
export declare const DefaultEmailOptionType: any;
export interface VerificationMessageTemplateType {
    SmsMessage?: string;
    EmailMessage?: string;
    EmailSubject?: string;
    EmailMessageByLink?: string;
    EmailSubjectByLink?: string;
    DefaultEmailOption?: DefaultEmailOptionType;
}
export declare const VerificationMessageTemplateType: S.Schema<VerificationMessageTemplateType>;
export type UserPoolMfaType = "OFF" | "ON" | "OPTIONAL" | (string & {});
export declare const UserPoolMfaType: any;
export type AttributesRequireVerificationBeforeUpdateType = VerifiedAttributeType[];
export declare const AttributesRequireVerificationBeforeUpdateType: any;
export interface UserAttributeUpdateSettingsType {
    AttributesRequireVerificationBeforeUpdate?: VerifiedAttributeType[];
}
export declare const UserAttributeUpdateSettingsType: S.Schema<UserAttributeUpdateSettingsType>;
export interface DeviceConfigurationType {
    ChallengeRequiredOnNewDevice?: boolean;
    DeviceOnlyRememberedOnUserPrompt?: boolean;
}
export declare const DeviceConfigurationType: S.Schema<DeviceConfigurationType>;
export type EmailAddressType = string;
export type EmailSendingAccountType = "COGNITO_DEFAULT" | "DEVELOPER" | (string & {});
export declare const EmailSendingAccountType: any;
export type SESConfigurationSet = string;
export interface EmailConfigurationType {
    SourceArn?: string;
    ReplyToEmailAddress?: string;
    EmailSendingAccount?: EmailSendingAccountType;
    From?: string;
    ConfigurationSet?: string;
}
export declare const EmailConfigurationType: S.Schema<EmailConfigurationType>;
export type OptionalArnType = string;
export type RegionCodeType = string;
export interface EumsSmsConfigurationType {
    CallerArn: string;
    ExternalId?: string;
    OriginationIdentity?: string;
    ConfigurationSetName?: string;
    InEntityId?: string;
    InTemplateId?: string;
    Region?: string;
}
export declare const EumsSmsConfigurationType: S.Schema<EumsSmsConfigurationType>;
export interface SmsConfigurationType {
    SnsCallerArn?: string;
    ExternalId?: string;
    SnsRegion?: string;
    EumsSms?: EumsSmsConfigurationType;
}
export declare const SmsConfigurationType: S.Schema<SmsConfigurationType>;
export type TagKeysType = string;
export type TagValueType = string;
export type UserPoolTagsType = {
    [key: string]: string | undefined;
};
export declare const UserPoolTagsType: any;
export type AdminCreateUserUnusedAccountValidityDaysType = number;
export type SmsInviteMessageType = string;
export type EmailInviteMessageType = string;
export interface MessageTemplateType {
    SMSMessage?: string;
    EmailMessage?: string;
    EmailSubject?: string;
}
export declare const MessageTemplateType: S.Schema<MessageTemplateType>;
export interface AdminCreateUserConfigType {
    AllowAdminCreateUserOnly?: boolean;
    UnusedAccountValidityDays?: number;
    InviteMessageTemplate?: MessageTemplateType;
}
export declare const AdminCreateUserConfigType: S.Schema<AdminCreateUserConfigType>;
export type SchemaAttributesListType = SchemaAttributeType[];
export declare const SchemaAttributesListType: any;
export type AdvancedSecurityModeType = "OFF" | "AUDIT" | "ENFORCED" | (string & {});
export declare const AdvancedSecurityModeType: any;
export type AdvancedSecurityEnabledModeType = "AUDIT" | "ENFORCED" | (string & {});
export declare const AdvancedSecurityEnabledModeType: any;
export interface AdvancedSecurityAdditionalFlowsType {
    CustomAuthMode?: AdvancedSecurityEnabledModeType;
}
export declare const AdvancedSecurityAdditionalFlowsType: S.Schema<AdvancedSecurityAdditionalFlowsType>;
export interface UserPoolAddOnsType {
    AdvancedSecurityMode: AdvancedSecurityModeType;
    AdvancedSecurityAdditionalFlows?: AdvancedSecurityAdditionalFlowsType;
}
export declare const UserPoolAddOnsType: S.Schema<UserPoolAddOnsType>;
export interface UsernameConfigurationType {
    CaseSensitive: boolean;
}
export declare const UsernameConfigurationType: S.Schema<UsernameConfigurationType>;
export type PriorityType = number;
export type RecoveryOptionNameType = "verified_email" | "verified_phone_number" | "admin_only" | (string & {});
export declare const RecoveryOptionNameType: any;
export interface RecoveryOptionType {
    Priority: number;
    Name: RecoveryOptionNameType;
}
export declare const RecoveryOptionType: S.Schema<RecoveryOptionType>;
export type RecoveryMechanismsType = RecoveryOptionType[];
export declare const RecoveryMechanismsType: any;
export interface AccountRecoverySettingType {
    RecoveryMechanisms?: RecoveryOptionType[];
}
export declare const AccountRecoverySettingType: S.Schema<AccountRecoverySettingType>;
export type UserPoolTierType = "LITE" | "ESSENTIALS" | "PLUS" | (string & {});
export declare const UserPoolTierType: any;
export type EncryptionKeyType = "AWS_OWNED_KEY" | "CUSTOMER_MANAGED_KEY" | (string & {});
export declare const EncryptionKeyType: any;
export type EncryptionKeyArnType = string;
export interface KeyConfigurationType {
    KeyType?: EncryptionKeyType;
    KmsKeyArn?: string;
}
export declare const KeyConfigurationType: S.Schema<KeyConfigurationType>;
export type IssuerType = "ORIGINAL" | "UPDATED" | (string & {});
export declare const IssuerType: any;
export interface IssuerConfigurationType {
    Type?: IssuerType;
}
export declare const IssuerConfigurationType: S.Schema<IssuerConfigurationType>;
export interface CreateUserPoolRequest {
    PoolName: string;
    Policies?: UserPoolPolicyType;
    DeletionProtection?: DeletionProtectionType;
    LambdaConfig?: LambdaConfigType;
    AutoVerifiedAttributes?: VerifiedAttributeType[];
    AliasAttributes?: AliasAttributeType[];
    UsernameAttributes?: UsernameAttributeType[];
    SmsVerificationMessage?: string;
    EmailVerificationMessage?: string;
    EmailVerificationSubject?: string;
    VerificationMessageTemplate?: VerificationMessageTemplateType;
    SmsAuthenticationMessage?: string;
    MfaConfiguration?: UserPoolMfaType;
    UserAttributeUpdateSettings?: UserAttributeUpdateSettingsType;
    DeviceConfiguration?: DeviceConfigurationType;
    EmailConfiguration?: EmailConfigurationType;
    SmsConfiguration?: SmsConfigurationType;
    UserPoolTags?: {
        [key: string]: string | undefined;
    };
    AdminCreateUserConfig?: AdminCreateUserConfigType;
    Schema?: SchemaAttributeType[];
    UserPoolAddOns?: UserPoolAddOnsType;
    UsernameConfiguration?: UsernameConfigurationType;
    AccountRecoverySetting?: AccountRecoverySettingType;
    UserPoolTier?: UserPoolTierType;
    KeyConfiguration?: KeyConfigurationType;
    IssuerConfiguration?: IssuerConfigurationType;
}
export declare const CreateUserPoolRequest: S.Schema<CreateUserPoolRequest>;
export type StatusType = "Enabled" | "Disabled" | (string & {});
export declare const StatusType: any;
export type DomainType = string;
export interface UserPoolType {
    Id?: string;
    Name?: string;
    Policies?: UserPoolPolicyType;
    DeletionProtection?: DeletionProtectionType;
    LambdaConfig?: LambdaConfigType;
    Status?: StatusType;
    LastModifiedDate?: Date;
    CreationDate?: Date;
    SchemaAttributes?: SchemaAttributeType[];
    AutoVerifiedAttributes?: VerifiedAttributeType[];
    AliasAttributes?: AliasAttributeType[];
    UsernameAttributes?: UsernameAttributeType[];
    SmsVerificationMessage?: string;
    EmailVerificationMessage?: string;
    EmailVerificationSubject?: string;
    VerificationMessageTemplate?: VerificationMessageTemplateType;
    SmsAuthenticationMessage?: string;
    UserAttributeUpdateSettings?: UserAttributeUpdateSettingsType;
    MfaConfiguration?: UserPoolMfaType;
    DeviceConfiguration?: DeviceConfigurationType;
    EstimatedNumberOfUsers?: number;
    EmailConfiguration?: EmailConfigurationType;
    SmsConfiguration?: SmsConfigurationType;
    UserPoolTags?: {
        [key: string]: string | undefined;
    };
    SmsConfigurationFailure?: string;
    EmailConfigurationFailure?: string;
    Domain?: string;
    CustomDomain?: string;
    AdminCreateUserConfig?: AdminCreateUserConfigType;
    UserPoolAddOns?: UserPoolAddOnsType;
    UsernameConfiguration?: UsernameConfigurationType;
    Arn?: string;
    AccountRecoverySetting?: AccountRecoverySettingType;
    UserPoolTier?: UserPoolTierType;
    KeyConfiguration?: KeyConfigurationType;
    IssuerConfiguration?: IssuerConfigurationType;
}
export declare const UserPoolType: S.Schema<UserPoolType>;
export interface CreateUserPoolResponse {
    UserPool?: UserPoolType;
}
export declare const CreateUserPoolResponse: S.Schema<CreateUserPoolResponse>;
export type ClientNameType = string;
export type GenerateSecret = boolean;
export type RefreshTokenValidityType = number;
export type AccessTokenValidityType = number;
export type IdTokenValidityType = number;
export type TimeUnitsType = "seconds" | "minutes" | "hours" | "days" | (string & {});
export declare const TimeUnitsType: any;
export interface TokenValidityUnitsType {
    AccessToken?: TimeUnitsType;
    IdToken?: TimeUnitsType;
    RefreshToken?: TimeUnitsType;
}
export declare const TokenValidityUnitsType: S.Schema<TokenValidityUnitsType>;
export type ClientPermissionType = string;
export type ClientPermissionListType = string[];
export declare const ClientPermissionListType: any;
export type ExplicitAuthFlowsType = "ADMIN_NO_SRP_AUTH" | "CUSTOM_AUTH_FLOW_ONLY" | "USER_PASSWORD_AUTH" | "ALLOW_ADMIN_USER_PASSWORD_AUTH" | "ALLOW_CUSTOM_AUTH" | "ALLOW_USER_PASSWORD_AUTH" | "ALLOW_USER_SRP_AUTH" | "ALLOW_REFRESH_TOKEN_AUTH" | "ALLOW_USER_AUTH" | (string & {});
export declare const ExplicitAuthFlowsType: any;
export type ExplicitAuthFlowsListType = ExplicitAuthFlowsType[];
export declare const ExplicitAuthFlowsListType: any;
export type SupportedIdentityProvidersListType = string[];
export declare const SupportedIdentityProvidersListType: any;
export type RedirectUrlType = string;
export type CallbackURLsListType = string[];
export declare const CallbackURLsListType: any;
export type LogoutURLsListType = string[];
export declare const LogoutURLsListType: any;
export type OAuthFlowType = "code" | "implicit" | "client_credentials" | (string & {});
export declare const OAuthFlowType: any;
export type OAuthFlowsType = OAuthFlowType[];
export declare const OAuthFlowsType: any;
export type ScopeType = string;
export type ScopeListType = string[];
export declare const ScopeListType: any;
export type HexStringType = string;
export interface AnalyticsConfigurationType {
    ApplicationId?: string;
    ApplicationArn?: string;
    RoleArn?: string;
    ExternalId?: string;
    UserDataShared?: boolean;
}
export declare const AnalyticsConfigurationType: S.Schema<AnalyticsConfigurationType>;
export type PreventUserExistenceErrorTypes = "LEGACY" | "ENABLED" | (string & {});
export declare const PreventUserExistenceErrorTypes: any;
export type AuthSessionValidityType = number;
export type FeatureType = "ENABLED" | "DISABLED" | (string & {});
export declare const FeatureType: any;
export type RetryGracePeriodSecondsType = number;
export interface RefreshTokenRotationType {
    Feature: FeatureType;
    RetryGracePeriodSeconds?: number;
}
export declare const RefreshTokenRotationType: S.Schema<RefreshTokenRotationType>;
export interface CreateUserPoolClientRequest {
    UserPoolId: string;
    ClientName: string;
    GenerateSecret?: boolean;
    ClientSecret?: string | redacted.Redacted<string>;
    RefreshTokenValidity?: number;
    AccessTokenValidity?: number;
    IdTokenValidity?: number;
    TokenValidityUnits?: TokenValidityUnitsType;
    ReadAttributes?: string[];
    WriteAttributes?: string[];
    ExplicitAuthFlows?: ExplicitAuthFlowsType[];
    SupportedIdentityProviders?: string[];
    CallbackURLs?: string[];
    LogoutURLs?: string[];
    DefaultRedirectURI?: string;
    AllowedOAuthFlows?: OAuthFlowType[];
    AllowedOAuthScopes?: string[];
    AllowedOAuthFlowsUserPoolClient?: boolean;
    AnalyticsConfiguration?: AnalyticsConfigurationType;
    PreventUserExistenceErrors?: PreventUserExistenceErrorTypes;
    EnableTokenRevocation?: boolean;
    EnablePropagateAdditionalUserContextData?: boolean;
    AuthSessionValidity?: number;
    RefreshTokenRotation?: RefreshTokenRotationType;
}
export declare const CreateUserPoolClientRequest: S.Schema<CreateUserPoolClientRequest>;
export interface UserPoolClientType {
    UserPoolId?: string;
    ClientName?: string;
    ClientId?: string | redacted.Redacted<string>;
    ClientSecret?: string | redacted.Redacted<string>;
    LastModifiedDate?: Date;
    CreationDate?: Date;
    RefreshTokenValidity?: number;
    AccessTokenValidity?: number;
    IdTokenValidity?: number;
    TokenValidityUnits?: TokenValidityUnitsType;
    ReadAttributes?: string[];
    WriteAttributes?: string[];
    ExplicitAuthFlows?: ExplicitAuthFlowsType[];
    SupportedIdentityProviders?: string[];
    CallbackURLs?: string[];
    LogoutURLs?: string[];
    DefaultRedirectURI?: string;
    AllowedOAuthFlows?: OAuthFlowType[];
    AllowedOAuthScopes?: string[];
    AllowedOAuthFlowsUserPoolClient?: boolean;
    AnalyticsConfiguration?: AnalyticsConfigurationType;
    PreventUserExistenceErrors?: PreventUserExistenceErrorTypes;
    EnableTokenRevocation?: boolean;
    EnablePropagateAdditionalUserContextData?: boolean;
    AuthSessionValidity?: number;
    RefreshTokenRotation?: RefreshTokenRotationType;
}
export declare const UserPoolClientType: S.Schema<UserPoolClientType>;
export interface CreateUserPoolClientResponse {
    UserPoolClient?: UserPoolClientType;
}
export declare const CreateUserPoolClientResponse: S.Schema<CreateUserPoolClientResponse>;
export type WrappedIntegerType = number;
export type SecurityPolicyType = "TLS_V1" | "TLS_V1_2_2021" | "TLS_V1_3_2025" | (string & {});
export declare const SecurityPolicyType: any;
export interface CustomDomainConfigType {
    CertificateArn: string;
    SecurityPolicy?: SecurityPolicyType;
}
export declare const CustomDomainConfigType: S.Schema<CustomDomainConfigType>;
export type RegionNameType = string;
export type HealthCheckIdType = string;
export interface FailoverType {
    SecondaryRegion: string;
    PrimaryRoute53HealthCheckId: string;
}
export declare const FailoverType: S.Schema<FailoverType>;
export interface RoutingType {
    Failover?: FailoverType;
}
export declare const RoutingType: S.Schema<RoutingType>;
export interface CreateUserPoolDomainRequest {
    Domain: string;
    UserPoolId: string;
    ManagedLoginVersion?: number;
    CustomDomainConfig?: CustomDomainConfigType;
    Routing?: RoutingType;
}
export declare const CreateUserPoolDomainRequest: S.Schema<CreateUserPoolDomainRequest>;
export interface CreateUserPoolDomainResponse {
    ManagedLoginVersion?: number;
    CloudFrontDomain?: string;
    Routing?: RoutingType;
}
export declare const CreateUserPoolDomainResponse: S.Schema<CreateUserPoolDomainResponse>;
export interface CreateUserPoolReplicaRequest {
    UserPoolId: string;
    RegionName: string;
    UserPoolTags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateUserPoolReplicaRequest: S.Schema<CreateUserPoolReplicaRequest>;
export type ReplicaStatusType = "CREATING" | "ACTIVE" | "INACTIVE" | "DELETING" | (string & {});
export declare const ReplicaStatusType: any;
export type ReplicaRoleType = "PRIMARY" | "SECONDARY" | (string & {});
export declare const ReplicaRoleType: any;
export interface UserPoolReplicaType {
    RegionName?: string;
    Status?: ReplicaStatusType;
    Role?: ReplicaRoleType;
    UserPoolArn?: string;
}
export declare const UserPoolReplicaType: S.Schema<UserPoolReplicaType>;
export interface CreateUserPoolReplicaResponse {
    UserPoolReplica?: UserPoolReplicaType;
}
export declare const CreateUserPoolReplicaResponse: S.Schema<CreateUserPoolReplicaResponse>;
export interface DeleteGroupRequest {
    GroupName: string;
    UserPoolId: string;
}
export declare const DeleteGroupRequest: S.Schema<DeleteGroupRequest>;
export interface DeleteGroupResponse {
}
export declare const DeleteGroupResponse: S.Schema<DeleteGroupResponse>;
export interface DeleteIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
}
export declare const DeleteIdentityProviderRequest: S.Schema<DeleteIdentityProviderRequest>;
export interface DeleteIdentityProviderResponse {
}
export declare const DeleteIdentityProviderResponse: S.Schema<DeleteIdentityProviderResponse>;
export interface DeleteManagedLoginBrandingRequest {
    ManagedLoginBrandingId: string;
    UserPoolId: string;
}
export declare const DeleteManagedLoginBrandingRequest: S.Schema<DeleteManagedLoginBrandingRequest>;
export interface DeleteManagedLoginBrandingResponse {
}
export declare const DeleteManagedLoginBrandingResponse: S.Schema<DeleteManagedLoginBrandingResponse>;
export interface DeleteResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
}
export declare const DeleteResourceServerRequest: S.Schema<DeleteResourceServerRequest>;
export interface DeleteResourceServerResponse {
}
export declare const DeleteResourceServerResponse: S.Schema<DeleteResourceServerResponse>;
export interface DeleteTermsRequest {
    TermsId: string;
    UserPoolId: string;
}
export declare const DeleteTermsRequest: S.Schema<DeleteTermsRequest>;
export interface DeleteTermsResponse {
}
export declare const DeleteTermsResponse: S.Schema<DeleteTermsResponse>;
export interface DeleteUserRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export declare const DeleteUserRequest: S.Schema<DeleteUserRequest>;
export interface DeleteUserResponse {
}
export declare const DeleteUserResponse: S.Schema<DeleteUserResponse>;
export interface DeleteUserAttributesRequest {
    UserAttributeNames: string[];
    AccessToken: string | redacted.Redacted<string>;
}
export declare const DeleteUserAttributesRequest: S.Schema<DeleteUserAttributesRequest>;
export interface DeleteUserAttributesResponse {
}
export declare const DeleteUserAttributesResponse: S.Schema<DeleteUserAttributesResponse>;
export interface DeleteUserPoolRequest {
    UserPoolId: string;
}
export declare const DeleteUserPoolRequest: S.Schema<DeleteUserPoolRequest>;
export interface DeleteUserPoolResponse {
}
export declare const DeleteUserPoolResponse: S.Schema<DeleteUserPoolResponse>;
export interface DeleteUserPoolClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
}
export declare const DeleteUserPoolClientRequest: S.Schema<DeleteUserPoolClientRequest>;
export interface DeleteUserPoolClientResponse {
}
export declare const DeleteUserPoolClientResponse: S.Schema<DeleteUserPoolClientResponse>;
export interface DeleteUserPoolClientSecretRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ClientSecretId: string;
}
export declare const DeleteUserPoolClientSecretRequest: S.Schema<DeleteUserPoolClientSecretRequest>;
export interface DeleteUserPoolClientSecretResponse {
}
export declare const DeleteUserPoolClientSecretResponse: S.Schema<DeleteUserPoolClientSecretResponse>;
export interface DeleteUserPoolDomainRequest {
    Domain: string;
    UserPoolId: string;
}
export declare const DeleteUserPoolDomainRequest: S.Schema<DeleteUserPoolDomainRequest>;
export interface DeleteUserPoolDomainResponse {
}
export declare const DeleteUserPoolDomainResponse: S.Schema<DeleteUserPoolDomainResponse>;
export interface DeleteUserPoolReplicaRequest {
    UserPoolId: string;
    RegionName: string;
}
export declare const DeleteUserPoolReplicaRequest: S.Schema<DeleteUserPoolReplicaRequest>;
export interface DeleteUserPoolReplicaResponse {
    UserPoolReplica?: UserPoolReplicaType;
}
export declare const DeleteUserPoolReplicaResponse: S.Schema<DeleteUserPoolReplicaResponse>;
export interface DeleteWebAuthnCredentialRequest {
    AccessToken: string | redacted.Redacted<string>;
    CredentialId: string;
}
export declare const DeleteWebAuthnCredentialRequest: S.Schema<DeleteWebAuthnCredentialRequest>;
export interface DeleteWebAuthnCredentialResponse {
}
export declare const DeleteWebAuthnCredentialResponse: S.Schema<DeleteWebAuthnCredentialResponse>;
export interface DescribeIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
}
export declare const DescribeIdentityProviderRequest: S.Schema<DescribeIdentityProviderRequest>;
export interface DescribeIdentityProviderResponse {
    IdentityProvider: IdentityProviderType;
}
export declare const DescribeIdentityProviderResponse: S.Schema<DescribeIdentityProviderResponse>;
export interface DescribeManagedLoginBrandingRequest {
    UserPoolId: string;
    ManagedLoginBrandingId: string;
    ReturnMergedResources?: boolean;
}
export declare const DescribeManagedLoginBrandingRequest: S.Schema<DescribeManagedLoginBrandingRequest>;
export interface DescribeManagedLoginBrandingResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType;
}
export declare const DescribeManagedLoginBrandingResponse: S.Schema<DescribeManagedLoginBrandingResponse>;
export interface DescribeManagedLoginBrandingByClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ReturnMergedResources?: boolean;
}
export declare const DescribeManagedLoginBrandingByClientRequest: S.Schema<DescribeManagedLoginBrandingByClientRequest>;
export interface DescribeManagedLoginBrandingByClientResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType;
}
export declare const DescribeManagedLoginBrandingByClientResponse: S.Schema<DescribeManagedLoginBrandingByClientResponse>;
export interface DescribeResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
}
export declare const DescribeResourceServerRequest: S.Schema<DescribeResourceServerRequest>;
export interface DescribeResourceServerResponse {
    ResourceServer: ResourceServerType;
}
export declare const DescribeResourceServerResponse: S.Schema<DescribeResourceServerResponse>;
export interface DescribeRiskConfigurationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string>;
}
export declare const DescribeRiskConfigurationRequest: S.Schema<DescribeRiskConfigurationRequest>;
export type EventFilterType = "SIGN_IN" | "PASSWORD_CHANGE" | "SIGN_UP" | (string & {});
export declare const EventFilterType: any;
export type EventFiltersType = EventFilterType[];
export declare const EventFiltersType: any;
export type CompromisedCredentialsEventActionType = "BLOCK" | "NO_ACTION" | (string & {});
export declare const CompromisedCredentialsEventActionType: any;
export interface CompromisedCredentialsActionsType {
    EventAction: CompromisedCredentialsEventActionType;
}
export declare const CompromisedCredentialsActionsType: S.Schema<CompromisedCredentialsActionsType>;
export interface CompromisedCredentialsRiskConfigurationType {
    EventFilter?: EventFilterType[];
    Actions: CompromisedCredentialsActionsType;
}
export declare const CompromisedCredentialsRiskConfigurationType: S.Schema<CompromisedCredentialsRiskConfigurationType>;
export type EmailNotificationSubjectType = string;
export type EmailNotificationBodyType = string;
export interface NotifyEmailType {
    Subject: string;
    HtmlBody?: string;
    TextBody?: string;
}
export declare const NotifyEmailType: S.Schema<NotifyEmailType>;
export interface NotifyConfigurationType {
    From?: string;
    ReplyTo?: string;
    SourceArn: string;
    BlockEmail?: NotifyEmailType;
    NoActionEmail?: NotifyEmailType;
    MfaEmail?: NotifyEmailType;
}
export declare const NotifyConfigurationType: S.Schema<NotifyConfigurationType>;
export type AccountTakeoverActionNotifyType = boolean;
export type AccountTakeoverEventActionType = "BLOCK" | "MFA_IF_CONFIGURED" | "MFA_REQUIRED" | "NO_ACTION" | (string & {});
export declare const AccountTakeoverEventActionType: any;
export interface AccountTakeoverActionType {
    Notify: boolean;
    EventAction: AccountTakeoverEventActionType;
}
export declare const AccountTakeoverActionType: S.Schema<AccountTakeoverActionType>;
export interface AccountTakeoverActionsType {
    LowAction?: AccountTakeoverActionType;
    MediumAction?: AccountTakeoverActionType;
    HighAction?: AccountTakeoverActionType;
}
export declare const AccountTakeoverActionsType: S.Schema<AccountTakeoverActionsType>;
export interface AccountTakeoverRiskConfigurationType {
    NotifyConfiguration?: NotifyConfigurationType;
    Actions: AccountTakeoverActionsType;
}
export declare const AccountTakeoverRiskConfigurationType: S.Schema<AccountTakeoverRiskConfigurationType>;
export type BlockedIPRangeListType = string[];
export declare const BlockedIPRangeListType: any;
export type SkippedIPRangeListType = string[];
export declare const SkippedIPRangeListType: any;
export interface RiskExceptionConfigurationType {
    BlockedIPRangeList?: string[];
    SkippedIPRangeList?: string[];
}
export declare const RiskExceptionConfigurationType: S.Schema<RiskExceptionConfigurationType>;
export interface RiskConfigurationType {
    UserPoolId?: string;
    ClientId?: string | redacted.Redacted<string>;
    CompromisedCredentialsRiskConfiguration?: CompromisedCredentialsRiskConfigurationType;
    AccountTakeoverRiskConfiguration?: AccountTakeoverRiskConfigurationType;
    RiskExceptionConfiguration?: RiskExceptionConfigurationType;
    LastModifiedDate?: Date;
}
export declare const RiskConfigurationType: S.Schema<RiskConfigurationType>;
export interface DescribeRiskConfigurationResponse {
    RiskConfiguration: RiskConfigurationType;
}
export declare const DescribeRiskConfigurationResponse: S.Schema<DescribeRiskConfigurationResponse>;
export interface DescribeTermsRequest {
    TermsId: string;
    UserPoolId: string;
}
export declare const DescribeTermsRequest: S.Schema<DescribeTermsRequest>;
export interface DescribeTermsResponse {
    Terms?: TermsType;
}
export declare const DescribeTermsResponse: S.Schema<DescribeTermsResponse>;
export interface DescribeTermsByClientRequest {
    ClientId: string | redacted.Redacted<string>;
    UserPoolId: string;
    TermsName: string;
}
export declare const DescribeTermsByClientRequest: S.Schema<DescribeTermsByClientRequest>;
export interface DescribeTermsByClientResponse {
    Terms?: TermsType;
}
export declare const DescribeTermsByClientResponse: S.Schema<DescribeTermsByClientResponse>;
export interface DescribeUserImportJobRequest {
    UserPoolId: string;
    JobId: string;
}
export declare const DescribeUserImportJobRequest: S.Schema<DescribeUserImportJobRequest>;
export interface DescribeUserImportJobResponse {
    UserImportJob?: UserImportJobType;
}
export declare const DescribeUserImportJobResponse: S.Schema<DescribeUserImportJobResponse>;
export interface DescribeUserPoolRequest {
    UserPoolId: string;
}
export declare const DescribeUserPoolRequest: S.Schema<DescribeUserPoolRequest>;
export interface DescribeUserPoolResponse {
    UserPool?: UserPoolType;
}
export declare const DescribeUserPoolResponse: S.Schema<DescribeUserPoolResponse>;
export interface DescribeUserPoolClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
}
export declare const DescribeUserPoolClientRequest: S.Schema<DescribeUserPoolClientRequest>;
export interface DescribeUserPoolClientResponse {
    UserPoolClient?: UserPoolClientType;
}
export declare const DescribeUserPoolClientResponse: S.Schema<DescribeUserPoolClientResponse>;
export interface DescribeUserPoolDomainRequest {
    Domain: string;
}
export declare const DescribeUserPoolDomainRequest: S.Schema<DescribeUserPoolDomainRequest>;
export type AWSAccountIdType = string;
export type S3BucketType = string;
export type DomainVersionType = string;
export type DomainStatusType = "CREATING" | "DELETING" | "UPDATING" | "ACTIVE" | "FAILED" | (string & {});
export declare const DomainStatusType: any;
export interface DomainDescriptionType {
    UserPoolId?: string;
    AWSAccountId?: string;
    Domain?: string;
    S3Bucket?: string;
    CloudFrontDistribution?: string;
    Version?: string;
    Status?: DomainStatusType;
    CustomDomainConfig?: CustomDomainConfigType;
    ManagedLoginVersion?: number;
    Routing?: RoutingType;
}
export declare const DomainDescriptionType: S.Schema<DomainDescriptionType>;
export interface DescribeUserPoolDomainResponse {
    DomainDescription?: DomainDescriptionType;
}
export declare const DescribeUserPoolDomainResponse: S.Schema<DescribeUserPoolDomainResponse>;
export interface ForgetDeviceRequest {
    AccessToken?: string | redacted.Redacted<string>;
    DeviceKey: string;
}
export declare const ForgetDeviceRequest: S.Schema<ForgetDeviceRequest>;
export interface ForgetDeviceResponse {
}
export declare const ForgetDeviceResponse: S.Schema<ForgetDeviceResponse>;
export interface ForgotPasswordRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string>;
    UserContextData?: UserContextDataType;
    Username: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const ForgotPasswordRequest: S.Schema<ForgotPasswordRequest>;
export interface CodeDeliveryDetailsType {
    Destination?: string;
    DeliveryMedium?: DeliveryMediumType;
    AttributeName?: string;
}
export declare const CodeDeliveryDetailsType: S.Schema<CodeDeliveryDetailsType>;
export interface ForgotPasswordResponse {
    CodeDeliveryDetails?: CodeDeliveryDetailsType;
}
export declare const ForgotPasswordResponse: S.Schema<ForgotPasswordResponse>;
export interface GetClientTokenRequest {
    ClientId: string | redacted.Redacted<string>;
    Secret: string | redacted.Redacted<string>;
    Scopes?: string[];
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const GetClientTokenRequest: S.Schema<GetClientTokenRequest>;
export interface ClientAuthenticationResultType {
    AccessToken?: string | redacted.Redacted<string>;
    ExpiresIn?: number;
    TokenType?: string;
}
export declare const ClientAuthenticationResultType: S.Schema<ClientAuthenticationResultType>;
export interface GetClientTokenResponse {
    ClientAuthenticationResult?: ClientAuthenticationResultType;
}
export declare const GetClientTokenResponse: S.Schema<GetClientTokenResponse>;
export interface GetCSVHeaderRequest {
    UserPoolId: string;
}
export declare const GetCSVHeaderRequest: S.Schema<GetCSVHeaderRequest>;
export type ListOfStringTypes = string[];
export declare const ListOfStringTypes: any;
export interface GetCSVHeaderResponse {
    UserPoolId?: string;
    CSVHeader?: string[];
}
export declare const GetCSVHeaderResponse: S.Schema<GetCSVHeaderResponse>;
export interface GetDeviceRequest {
    DeviceKey: string;
    AccessToken?: string | redacted.Redacted<string>;
}
export declare const GetDeviceRequest: S.Schema<GetDeviceRequest>;
export interface GetDeviceResponse {
    Device: DeviceType;
}
export declare const GetDeviceResponse: S.Schema<GetDeviceResponse>;
export interface GetGroupRequest {
    GroupName: string;
    UserPoolId: string;
}
export declare const GetGroupRequest: S.Schema<GetGroupRequest>;
export interface GetGroupResponse {
    Group?: GroupType;
}
export declare const GetGroupResponse: S.Schema<GetGroupResponse>;
export interface GetIdentityProviderByIdentifierRequest {
    UserPoolId: string;
    IdpIdentifier: string;
}
export declare const GetIdentityProviderByIdentifierRequest: S.Schema<GetIdentityProviderByIdentifierRequest>;
export interface GetIdentityProviderByIdentifierResponse {
    IdentityProvider: IdentityProviderType;
}
export declare const GetIdentityProviderByIdentifierResponse: S.Schema<GetIdentityProviderByIdentifierResponse>;
export interface GetLogDeliveryConfigurationRequest {
    UserPoolId: string;
}
export declare const GetLogDeliveryConfigurationRequest: S.Schema<GetLogDeliveryConfigurationRequest>;
export type LogLevel = "ERROR" | "INFO" | (string & {});
export declare const LogLevel: any;
export type EventSourceName = "userNotification" | "userAuthEvents" | (string & {});
export declare const EventSourceName: any;
export interface CloudWatchLogsConfigurationType {
    LogGroupArn?: string;
}
export declare const CloudWatchLogsConfigurationType: S.Schema<CloudWatchLogsConfigurationType>;
export type S3ArnType = string;
export interface S3ConfigurationType {
    BucketArn?: string;
}
export declare const S3ConfigurationType: S.Schema<S3ConfigurationType>;
export interface FirehoseConfigurationType {
    StreamArn?: string;
}
export declare const FirehoseConfigurationType: S.Schema<FirehoseConfigurationType>;
export interface LogConfigurationType {
    LogLevel: LogLevel;
    EventSource: EventSourceName;
    CloudWatchLogsConfiguration?: CloudWatchLogsConfigurationType;
    S3Configuration?: S3ConfigurationType;
    FirehoseConfiguration?: FirehoseConfigurationType;
}
export declare const LogConfigurationType: S.Schema<LogConfigurationType>;
export type LogConfigurationListType = LogConfigurationType[];
export declare const LogConfigurationListType: any;
export interface LogDeliveryConfigurationType {
    UserPoolId: string;
    LogConfigurations: LogConfigurationType[];
}
export declare const LogDeliveryConfigurationType: S.Schema<LogDeliveryConfigurationType>;
export interface GetLogDeliveryConfigurationResponse {
    LogDeliveryConfiguration?: LogDeliveryConfigurationType;
}
export declare const GetLogDeliveryConfigurationResponse: S.Schema<GetLogDeliveryConfigurationResponse>;
export type LimitClass = "API_CATEGORY" | (string & {});
export declare const LimitClass: any;
export type StringToStringMapType = {
    [key: string]: string | undefined;
};
export declare const StringToStringMapType: any;
export interface LimitDefinitionType {
    LimitClass: LimitClass;
    Attributes: {
        [key: string]: string | undefined;
    };
}
export declare const LimitDefinitionType: S.Schema<LimitDefinitionType>;
export interface GetProvisionedLimitRequest {
    LimitDefinition: LimitDefinitionType;
}
export declare const GetProvisionedLimitRequest: S.Schema<GetProvisionedLimitRequest>;
export interface LimitType {
    LimitDefinition: LimitDefinitionType;
    ProvisionedLimitValue: number;
    FreeLimitValue: number;
}
export declare const LimitType: S.Schema<LimitType>;
export interface GetProvisionedLimitResponse {
    Limit: LimitType;
}
export declare const GetProvisionedLimitResponse: S.Schema<GetProvisionedLimitResponse>;
export interface GetSigningCertificateRequest {
    UserPoolId: string;
}
export declare const GetSigningCertificateRequest: S.Schema<GetSigningCertificateRequest>;
export interface GetSigningCertificateResponse {
    Certificate?: string;
}
export declare const GetSigningCertificateResponse: S.Schema<GetSigningCertificateResponse>;
export interface GetTokensFromRefreshTokenRequest {
    RefreshToken: string | redacted.Redacted<string>;
    ClientId: string | redacted.Redacted<string>;
    ClientSecret?: string | redacted.Redacted<string>;
    DeviceKey?: string;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const GetTokensFromRefreshTokenRequest: S.Schema<GetTokensFromRefreshTokenRequest>;
export interface GetTokensFromRefreshTokenResponse {
    AuthenticationResult?: AuthenticationResultType;
}
export declare const GetTokensFromRefreshTokenResponse: S.Schema<GetTokensFromRefreshTokenResponse>;
export interface GetUICustomizationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string>;
}
export declare const GetUICustomizationRequest: S.Schema<GetUICustomizationRequest>;
export type ImageUrlType = string;
export type CSSType = string;
export type CSSVersionType = string;
export interface UICustomizationType {
    UserPoolId?: string;
    ClientId?: string | redacted.Redacted<string>;
    ImageUrl?: string;
    CSS?: string;
    CSSVersion?: string;
    LastModifiedDate?: Date;
    CreationDate?: Date;
}
export declare const UICustomizationType: S.Schema<UICustomizationType>;
export interface GetUICustomizationResponse {
    UICustomization: UICustomizationType;
}
export declare const GetUICustomizationResponse: S.Schema<GetUICustomizationResponse>;
export interface GetUserRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export declare const GetUserRequest: S.Schema<GetUserRequest>;
export interface GetUserResponse {
    Username: string | redacted.Redacted<string>;
    UserAttributes: AttributeType[];
    MFAOptions?: MFAOptionType[];
    PreferredMfaSetting?: string;
    UserMFASettingList?: string[];
}
export declare const GetUserResponse: S.Schema<GetUserResponse>;
export interface GetUserAttributeVerificationCodeRequest {
    AccessToken: string | redacted.Redacted<string>;
    AttributeName: string;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const GetUserAttributeVerificationCodeRequest: S.Schema<GetUserAttributeVerificationCodeRequest>;
export interface GetUserAttributeVerificationCodeResponse {
    CodeDeliveryDetails?: CodeDeliveryDetailsType;
}
export declare const GetUserAttributeVerificationCodeResponse: S.Schema<GetUserAttributeVerificationCodeResponse>;
export interface GetUserAuthFactorsRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export declare const GetUserAuthFactorsRequest: S.Schema<GetUserAuthFactorsRequest>;
export interface GetUserAuthFactorsResponse {
    Username: string | redacted.Redacted<string>;
    PreferredMfaSetting?: string;
    UserMFASettingList?: string[];
    ConfiguredUserAuthFactors?: AuthFactorType[];
}
export declare const GetUserAuthFactorsResponse: S.Schema<GetUserAuthFactorsResponse>;
export interface GetUserPoolMfaConfigRequest {
    UserPoolId: string;
}
export declare const GetUserPoolMfaConfigRequest: S.Schema<GetUserPoolMfaConfigRequest>;
export interface SmsMfaConfigType {
    SmsAuthenticationMessage?: string;
    SmsConfiguration?: SmsConfigurationType;
}
export declare const SmsMfaConfigType: S.Schema<SmsMfaConfigType>;
export interface SoftwareTokenMfaConfigType {
    Enabled?: boolean;
}
export declare const SoftwareTokenMfaConfigType: S.Schema<SoftwareTokenMfaConfigType>;
export type EmailMfaMessageType = string;
export type EmailMfaSubjectType = string;
export interface EmailMfaConfigType {
    Message?: string;
    Subject?: string;
}
export declare const EmailMfaConfigType: S.Schema<EmailMfaConfigType>;
export type RelyingPartyIdType = string;
export type UserVerificationType = "required" | "preferred" | (string & {});
export declare const UserVerificationType: any;
export type WebAuthnFactorConfigurationType = "SINGLE_FACTOR" | "MULTI_FACTOR_WITH_USER_VERIFICATION" | (string & {});
export declare const WebAuthnFactorConfigurationType: any;
export interface WebAuthnConfigurationType {
    RelyingPartyId?: string;
    UserVerification?: UserVerificationType;
    FactorConfiguration?: WebAuthnFactorConfigurationType;
}
export declare const WebAuthnConfigurationType: S.Schema<WebAuthnConfigurationType>;
export interface GetUserPoolMfaConfigResponse {
    SmsMfaConfiguration?: SmsMfaConfigType;
    SoftwareTokenMfaConfiguration?: SoftwareTokenMfaConfigType;
    EmailMfaConfiguration?: EmailMfaConfigType;
    MfaConfiguration?: UserPoolMfaType;
    WebAuthnConfiguration?: WebAuthnConfigurationType;
}
export declare const GetUserPoolMfaConfigResponse: S.Schema<GetUserPoolMfaConfigResponse>;
export interface GlobalSignOutRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export declare const GlobalSignOutRequest: S.Schema<GlobalSignOutRequest>;
export interface GlobalSignOutResponse {
}
export declare const GlobalSignOutResponse: S.Schema<GlobalSignOutResponse>;
export interface InitiateAuthRequest {
    AuthFlow: AuthFlowType;
    AuthParameters?: {
        [key: string]: string | undefined;
    };
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
    ClientId: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType;
    UserContextData?: UserContextDataType;
    Session?: string | redacted.Redacted<string>;
}
export declare const InitiateAuthRequest: S.Schema<InitiateAuthRequest>;
export interface InitiateAuthResponse {
    ChallengeName?: ChallengeNameType;
    Session?: string | redacted.Redacted<string>;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    };
    AuthenticationResult?: AuthenticationResultType;
    AvailableChallenges?: ChallengeNameType[];
}
export declare const InitiateAuthResponse: S.Schema<InitiateAuthResponse>;
export interface ListDevicesRequest {
    AccessToken: string | redacted.Redacted<string>;
    Limit?: number;
    PaginationToken?: string;
}
export declare const ListDevicesRequest: S.Schema<ListDevicesRequest>;
export interface ListDevicesResponse {
    Devices?: DeviceType[];
    PaginationToken?: string;
}
export declare const ListDevicesResponse: S.Schema<ListDevicesResponse>;
export interface ListGroupsRequest {
    UserPoolId: string;
    Limit?: number;
    NextToken?: string;
}
export declare const ListGroupsRequest: S.Schema<ListGroupsRequest>;
export interface ListGroupsResponse {
    Groups?: GroupType[];
    NextToken?: string;
}
export declare const ListGroupsResponse: S.Schema<ListGroupsResponse>;
export type ListProvidersLimitType = number;
export type PaginationKeyType = string;
export interface ListIdentityProvidersRequest {
    UserPoolId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListIdentityProvidersRequest: S.Schema<ListIdentityProvidersRequest>;
export interface ProviderDescription {
    ProviderName?: string;
    ProviderType?: IdentityProviderTypeType;
    LastModifiedDate?: Date;
    CreationDate?: Date;
}
export declare const ProviderDescription: S.Schema<ProviderDescription>;
export type ProvidersListType = ProviderDescription[];
export declare const ProvidersListType: any;
export interface ListIdentityProvidersResponse {
    Providers: ProviderDescription[];
    NextToken?: string;
}
export declare const ListIdentityProvidersResponse: S.Schema<ListIdentityProvidersResponse>;
export type ListResourceServersLimitType = number;
export interface ListResourceServersRequest {
    UserPoolId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListResourceServersRequest: S.Schema<ListResourceServersRequest>;
export type ResourceServersListType = ResourceServerType[];
export declare const ResourceServersListType: any;
export interface ListResourceServersResponse {
    ResourceServers: ResourceServerType[];
    NextToken?: string;
}
export declare const ListResourceServersResponse: S.Schema<ListResourceServersResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type ListTermsRequestMaxResultsInteger = number;
export interface ListTermsRequest {
    UserPoolId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTermsRequest: S.Schema<ListTermsRequest>;
export interface TermsDescriptionType {
    TermsId: string;
    TermsName: string;
    Enforcement: TermsEnforcementType;
    CreationDate: Date;
    LastModifiedDate: Date;
}
export declare const TermsDescriptionType: S.Schema<TermsDescriptionType>;
export type TermsDescriptionListType = TermsDescriptionType[];
export declare const TermsDescriptionListType: any;
export interface ListTermsResponse {
    Terms: TermsDescriptionType[];
    NextToken?: string;
}
export declare const ListTermsResponse: S.Schema<ListTermsResponse>;
export type PoolQueryLimitType = number;
export interface ListUserImportJobsRequest {
    UserPoolId: string;
    MaxResults: number;
    PaginationToken?: string;
}
export declare const ListUserImportJobsRequest: S.Schema<ListUserImportJobsRequest>;
export type UserImportJobsListType = UserImportJobType[];
export declare const UserImportJobsListType: any;
export interface ListUserImportJobsResponse {
    UserImportJobs?: UserImportJobType[];
    PaginationToken?: string;
}
export declare const ListUserImportJobsResponse: S.Schema<ListUserImportJobsResponse>;
export type QueryLimit = number;
export interface ListUserPoolClientsRequest {
    UserPoolId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListUserPoolClientsRequest: S.Schema<ListUserPoolClientsRequest>;
export interface UserPoolClientDescription {
    ClientId?: string | redacted.Redacted<string>;
    UserPoolId?: string;
    ClientName?: string;
}
export declare const UserPoolClientDescription: S.Schema<UserPoolClientDescription>;
export type UserPoolClientListType = UserPoolClientDescription[];
export declare const UserPoolClientListType: any;
export interface ListUserPoolClientsResponse {
    UserPoolClients?: UserPoolClientDescription[];
    NextToken?: string;
}
export declare const ListUserPoolClientsResponse: S.Schema<ListUserPoolClientsResponse>;
export interface ListUserPoolClientSecretsRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    NextToken?: string;
}
export declare const ListUserPoolClientSecretsRequest: S.Schema<ListUserPoolClientSecretsRequest>;
export type ClientSecretDescriptorListType = ClientSecretDescriptorType[];
export declare const ClientSecretDescriptorListType: any;
export interface ListUserPoolClientSecretsResponse {
    ClientSecrets?: ClientSecretDescriptorType[];
    NextToken?: string;
}
export declare const ListUserPoolClientSecretsResponse: S.Schema<ListUserPoolClientSecretsResponse>;
export interface ListUserPoolReplicasRequest {
    UserPoolId: string;
    NextToken?: string;
}
export declare const ListUserPoolReplicasRequest: S.Schema<ListUserPoolReplicasRequest>;
export type UserPoolReplicaListType = UserPoolReplicaType[];
export declare const UserPoolReplicaListType: any;
export interface ListUserPoolReplicasResponse {
    UserPoolReplicas?: UserPoolReplicaType[];
    NextToken?: string;
}
export declare const ListUserPoolReplicasResponse: S.Schema<ListUserPoolReplicasResponse>;
export interface ListUserPoolsRequest {
    NextToken?: string;
    MaxResults: number;
}
export declare const ListUserPoolsRequest: S.Schema<ListUserPoolsRequest>;
export type ReplicaRegionsType = string[];
export declare const ReplicaRegionsType: any;
export interface UserPoolDescriptionType {
    Id?: string;
    Name?: string;
    LambdaConfig?: LambdaConfigType;
    Status?: StatusType;
    LastModifiedDate?: Date;
    CreationDate?: Date;
    ReplicaRegions?: string[];
}
export declare const UserPoolDescriptionType: S.Schema<UserPoolDescriptionType>;
export type UserPoolListType = UserPoolDescriptionType[];
export declare const UserPoolListType: any;
export interface ListUserPoolsResponse {
    UserPools?: UserPoolDescriptionType[];
    NextToken?: string;
}
export declare const ListUserPoolsResponse: S.Schema<ListUserPoolsResponse>;
export type SearchedAttributeNamesListType = string[];
export declare const SearchedAttributeNamesListType: any;
export type UserFilterType = string;
export interface ListUsersRequest {
    UserPoolId: string;
    AttributesToGet?: string[];
    Limit?: number;
    PaginationToken?: string;
    Filter?: string;
}
export declare const ListUsersRequest: S.Schema<ListUsersRequest>;
export type UsersListType = UserType[];
export declare const UsersListType: any;
export interface ListUsersResponse {
    Users?: UserType[];
    PaginationToken?: string;
}
export declare const ListUsersResponse: S.Schema<ListUsersResponse>;
export interface ListUsersInGroupRequest {
    UserPoolId: string;
    GroupName: string;
    Limit?: number;
    NextToken?: string;
}
export declare const ListUsersInGroupRequest: S.Schema<ListUsersInGroupRequest>;
export interface ListUsersInGroupResponse {
    Users?: UserType[];
    NextToken?: string;
}
export declare const ListUsersInGroupResponse: S.Schema<ListUsersInGroupResponse>;
export type WebAuthnCredentialsQueryLimitType = number;
export interface ListWebAuthnCredentialsRequest {
    AccessToken: string | redacted.Redacted<string>;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListWebAuthnCredentialsRequest: S.Schema<ListWebAuthnCredentialsRequest>;
export type WebAuthnAuthenticatorAttachmentType = string;
export type WebAuthnAuthenticatorTransportType = string;
export type WebAuthnAuthenticatorTransportsList = string[];
export declare const WebAuthnAuthenticatorTransportsList: any;
export interface WebAuthnCredentialDescription {
    CredentialId: string;
    FriendlyCredentialName: string;
    RelyingPartyId: string;
    AuthenticatorAttachment?: string;
    AuthenticatorTransports: string[];
    CreatedAt: Date;
}
export declare const WebAuthnCredentialDescription: S.Schema<WebAuthnCredentialDescription>;
export type WebAuthnCredentialDescriptionListType = WebAuthnCredentialDescription[];
export declare const WebAuthnCredentialDescriptionListType: any;
export interface ListWebAuthnCredentialsResponse {
    Credentials: WebAuthnCredentialDescription[];
    NextToken?: string;
}
export declare const ListWebAuthnCredentialsResponse: S.Schema<ListWebAuthnCredentialsResponse>;
export interface ResendConfirmationCodeRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string>;
    UserContextData?: UserContextDataType;
    Username: string | redacted.Redacted<string>;
    AnalyticsMetadata?: AnalyticsMetadataType;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const ResendConfirmationCodeRequest: S.Schema<ResendConfirmationCodeRequest>;
export interface ResendConfirmationCodeResponse {
    CodeDeliveryDetails?: CodeDeliveryDetailsType;
}
export declare const ResendConfirmationCodeResponse: S.Schema<ResendConfirmationCodeResponse>;
export interface RespondToAuthChallengeRequest {
    ClientId: string | redacted.Redacted<string>;
    ChallengeName: ChallengeNameType;
    Session?: string | redacted.Redacted<string>;
    ChallengeResponses?: {
        [key: string]: string | undefined;
    };
    AnalyticsMetadata?: AnalyticsMetadataType;
    UserContextData?: UserContextDataType;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const RespondToAuthChallengeRequest: S.Schema<RespondToAuthChallengeRequest>;
export interface RespondToAuthChallengeResponse {
    ChallengeName?: ChallengeNameType;
    Session?: string | redacted.Redacted<string>;
    ChallengeParameters?: {
        [key: string]: string | undefined;
    };
    AuthenticationResult?: AuthenticationResultType;
}
export declare const RespondToAuthChallengeResponse: S.Schema<RespondToAuthChallengeResponse>;
export interface RevokeTokenRequest {
    Token: string | redacted.Redacted<string>;
    ClientId: string | redacted.Redacted<string>;
    ClientSecret?: string | redacted.Redacted<string>;
}
export declare const RevokeTokenRequest: S.Schema<RevokeTokenRequest>;
export interface RevokeTokenResponse {
}
export declare const RevokeTokenResponse: S.Schema<RevokeTokenResponse>;
export interface SetLogDeliveryConfigurationRequest {
    UserPoolId: string;
    LogConfigurations: LogConfigurationType[];
}
export declare const SetLogDeliveryConfigurationRequest: S.Schema<SetLogDeliveryConfigurationRequest>;
export interface SetLogDeliveryConfigurationResponse {
    LogDeliveryConfiguration?: LogDeliveryConfigurationType;
}
export declare const SetLogDeliveryConfigurationResponse: S.Schema<SetLogDeliveryConfigurationResponse>;
export interface SetRiskConfigurationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string>;
    CompromisedCredentialsRiskConfiguration?: CompromisedCredentialsRiskConfigurationType;
    AccountTakeoverRiskConfiguration?: AccountTakeoverRiskConfigurationType;
    RiskExceptionConfiguration?: RiskExceptionConfigurationType;
}
export declare const SetRiskConfigurationRequest: S.Schema<SetRiskConfigurationRequest>;
export interface SetRiskConfigurationResponse {
    RiskConfiguration: RiskConfigurationType;
}
export declare const SetRiskConfigurationResponse: S.Schema<SetRiskConfigurationResponse>;
export type ImageFileType = Uint8Array;
export interface SetUICustomizationRequest {
    UserPoolId: string;
    ClientId?: string | redacted.Redacted<string>;
    CSS?: string;
    ImageFile?: Uint8Array;
}
export declare const SetUICustomizationRequest: S.Schema<SetUICustomizationRequest>;
export interface SetUICustomizationResponse {
    UICustomization: UICustomizationType;
}
export declare const SetUICustomizationResponse: S.Schema<SetUICustomizationResponse>;
export interface SetUserMFAPreferenceRequest {
    SMSMfaSettings?: SMSMfaSettingsType;
    SoftwareTokenMfaSettings?: SoftwareTokenMfaSettingsType;
    EmailMfaSettings?: EmailMfaSettingsType;
    WebAuthnMfaSettings?: WebAuthnMfaSettingsType;
    AccessToken: string | redacted.Redacted<string>;
}
export declare const SetUserMFAPreferenceRequest: S.Schema<SetUserMFAPreferenceRequest>;
export interface SetUserMFAPreferenceResponse {
}
export declare const SetUserMFAPreferenceResponse: S.Schema<SetUserMFAPreferenceResponse>;
export interface SetUserPoolMfaConfigRequest {
    UserPoolId: string;
    SmsMfaConfiguration?: SmsMfaConfigType;
    SoftwareTokenMfaConfiguration?: SoftwareTokenMfaConfigType;
    EmailMfaConfiguration?: EmailMfaConfigType;
    MfaConfiguration?: UserPoolMfaType;
    WebAuthnConfiguration?: WebAuthnConfigurationType;
}
export declare const SetUserPoolMfaConfigRequest: S.Schema<SetUserPoolMfaConfigRequest>;
export interface SetUserPoolMfaConfigResponse {
    SmsMfaConfiguration?: SmsMfaConfigType;
    SoftwareTokenMfaConfiguration?: SoftwareTokenMfaConfigType;
    EmailMfaConfiguration?: EmailMfaConfigType;
    MfaConfiguration?: UserPoolMfaType;
    WebAuthnConfiguration?: WebAuthnConfigurationType;
}
export declare const SetUserPoolMfaConfigResponse: S.Schema<SetUserPoolMfaConfigResponse>;
export interface SetUserSettingsRequest {
    AccessToken: string | redacted.Redacted<string>;
    MFAOptions: MFAOptionType[];
}
export declare const SetUserSettingsRequest: S.Schema<SetUserSettingsRequest>;
export interface SetUserSettingsResponse {
}
export declare const SetUserSettingsResponse: S.Schema<SetUserSettingsResponse>;
export interface SignUpRequest {
    ClientId: string | redacted.Redacted<string>;
    SecretHash?: string | redacted.Redacted<string>;
    Username: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
    UserAttributes?: AttributeType[];
    ValidationData?: AttributeType[];
    AnalyticsMetadata?: AnalyticsMetadataType;
    UserContextData?: UserContextDataType;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const SignUpRequest: S.Schema<SignUpRequest>;
export interface SignUpResponse {
    UserConfirmed: boolean;
    CodeDeliveryDetails?: CodeDeliveryDetailsType;
    UserSub: string;
    Session?: string | redacted.Redacted<string>;
}
export declare const SignUpResponse: S.Schema<SignUpResponse>;
export interface StartUserImportJobRequest {
    UserPoolId: string;
    JobId: string;
}
export declare const StartUserImportJobRequest: S.Schema<StartUserImportJobRequest>;
export interface StartUserImportJobResponse {
    UserImportJob?: UserImportJobType;
}
export declare const StartUserImportJobResponse: S.Schema<StartUserImportJobResponse>;
export interface StartWebAuthnRegistrationRequest {
    AccessToken: string | redacted.Redacted<string>;
}
export declare const StartWebAuthnRegistrationRequest: S.Schema<StartWebAuthnRegistrationRequest>;
export interface StartWebAuthnRegistrationResponse {
    CredentialCreationOptions: any;
}
export declare const StartWebAuthnRegistrationResponse: S.Schema<StartWebAuthnRegistrationResponse>;
export interface StopUserImportJobRequest {
    UserPoolId: string;
    JobId: string;
}
export declare const StopUserImportJobRequest: S.Schema<StopUserImportJobRequest>;
export interface StopUserImportJobResponse {
    UserImportJob?: UserImportJobType;
}
export declare const StopUserImportJobResponse: S.Schema<StopUserImportJobResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type UserPoolTagsListType = string[];
export declare const UserPoolTagsListType: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAuthEventFeedbackRequest {
    UserPoolId: string;
    Username: string | redacted.Redacted<string>;
    EventId: string;
    FeedbackToken: string | redacted.Redacted<string>;
    FeedbackValue: FeedbackValueType;
}
export declare const UpdateAuthEventFeedbackRequest: S.Schema<UpdateAuthEventFeedbackRequest>;
export interface UpdateAuthEventFeedbackResponse {
}
export declare const UpdateAuthEventFeedbackResponse: S.Schema<UpdateAuthEventFeedbackResponse>;
export interface UpdateDeviceStatusRequest {
    AccessToken: string | redacted.Redacted<string>;
    DeviceKey: string;
    DeviceRememberedStatus?: DeviceRememberedStatusType;
}
export declare const UpdateDeviceStatusRequest: S.Schema<UpdateDeviceStatusRequest>;
export interface UpdateDeviceStatusResponse {
}
export declare const UpdateDeviceStatusResponse: S.Schema<UpdateDeviceStatusResponse>;
export interface UpdateGroupRequest {
    GroupName: string;
    UserPoolId: string;
    Description?: string;
    RoleArn?: string;
    Precedence?: number;
}
export declare const UpdateGroupRequest: S.Schema<UpdateGroupRequest>;
export interface UpdateGroupResponse {
    Group?: GroupType;
}
export declare const UpdateGroupResponse: S.Schema<UpdateGroupResponse>;
export interface UpdateIdentityProviderRequest {
    UserPoolId: string;
    ProviderName: string;
    ProviderDetails?: {
        [key: string]: string | undefined;
    };
    AttributeMapping?: {
        [key: string]: string | undefined;
    };
    IdpIdentifiers?: string[];
}
export declare const UpdateIdentityProviderRequest: S.Schema<UpdateIdentityProviderRequest>;
export interface UpdateIdentityProviderResponse {
    IdentityProvider: IdentityProviderType;
}
export declare const UpdateIdentityProviderResponse: S.Schema<UpdateIdentityProviderResponse>;
export interface UpdateManagedLoginBrandingRequest {
    UserPoolId?: string;
    ManagedLoginBrandingId?: string;
    UseCognitoProvidedValues?: boolean;
    Settings?: any;
    Assets?: AssetType[];
}
export declare const UpdateManagedLoginBrandingRequest: S.Schema<UpdateManagedLoginBrandingRequest>;
export interface UpdateManagedLoginBrandingResponse {
    ManagedLoginBranding?: ManagedLoginBrandingType;
}
export declare const UpdateManagedLoginBrandingResponse: S.Schema<UpdateManagedLoginBrandingResponse>;
export interface UpdateProvisionedLimitRequest {
    LimitDefinition: LimitDefinitionType;
    RequestedLimitValue: number;
}
export declare const UpdateProvisionedLimitRequest: S.Schema<UpdateProvisionedLimitRequest>;
export interface UpdateProvisionedLimitResponse {
    Limit: LimitType;
}
export declare const UpdateProvisionedLimitResponse: S.Schema<UpdateProvisionedLimitResponse>;
export interface UpdateResourceServerRequest {
    UserPoolId: string;
    Identifier: string;
    Name: string;
    Scopes?: ResourceServerScopeType[];
}
export declare const UpdateResourceServerRequest: S.Schema<UpdateResourceServerRequest>;
export interface UpdateResourceServerResponse {
    ResourceServer: ResourceServerType;
}
export declare const UpdateResourceServerResponse: S.Schema<UpdateResourceServerResponse>;
export interface UpdateTermsRequest {
    TermsId: string;
    UserPoolId: string;
    TermsName?: string;
    TermsSource?: TermsSourceType;
    Enforcement?: TermsEnforcementType;
    Links?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateTermsRequest: S.Schema<UpdateTermsRequest>;
export interface UpdateTermsResponse {
    Terms?: TermsType;
}
export declare const UpdateTermsResponse: S.Schema<UpdateTermsResponse>;
export interface UpdateUserAttributesRequest {
    UserAttributes: AttributeType[];
    AccessToken: string | redacted.Redacted<string>;
    ClientMetadata?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateUserAttributesRequest: S.Schema<UpdateUserAttributesRequest>;
export type CodeDeliveryDetailsListType = CodeDeliveryDetailsType[];
export declare const CodeDeliveryDetailsListType: any;
export interface UpdateUserAttributesResponse {
    CodeDeliveryDetailsList?: CodeDeliveryDetailsType[];
}
export declare const UpdateUserAttributesResponse: S.Schema<UpdateUserAttributesResponse>;
export interface UpdateUserPoolRequest {
    UserPoolId: string;
    Policies?: UserPoolPolicyType;
    DeletionProtection?: DeletionProtectionType;
    LambdaConfig?: LambdaConfigType;
    AutoVerifiedAttributes?: VerifiedAttributeType[];
    SmsVerificationMessage?: string;
    EmailVerificationMessage?: string;
    EmailVerificationSubject?: string;
    VerificationMessageTemplate?: VerificationMessageTemplateType;
    SmsAuthenticationMessage?: string;
    UserAttributeUpdateSettings?: UserAttributeUpdateSettingsType;
    MfaConfiguration?: UserPoolMfaType;
    DeviceConfiguration?: DeviceConfigurationType;
    EmailConfiguration?: EmailConfigurationType;
    SmsConfiguration?: SmsConfigurationType;
    UserPoolTags?: {
        [key: string]: string | undefined;
    };
    AdminCreateUserConfig?: AdminCreateUserConfigType;
    UserPoolAddOns?: UserPoolAddOnsType;
    AccountRecoverySetting?: AccountRecoverySettingType;
    PoolName?: string;
    UserPoolTier?: UserPoolTierType;
    KeyConfiguration?: KeyConfigurationType;
    IssuerConfiguration?: IssuerConfigurationType;
}
export declare const UpdateUserPoolRequest: S.Schema<UpdateUserPoolRequest>;
export interface UpdateUserPoolResponse {
}
export declare const UpdateUserPoolResponse: S.Schema<UpdateUserPoolResponse>;
export interface UpdateUserPoolClientRequest {
    UserPoolId: string;
    ClientId: string | redacted.Redacted<string>;
    ClientName?: string;
    RefreshTokenValidity?: number;
    AccessTokenValidity?: number;
    IdTokenValidity?: number;
    TokenValidityUnits?: TokenValidityUnitsType;
    ReadAttributes?: string[];
    WriteAttributes?: string[];
    ExplicitAuthFlows?: ExplicitAuthFlowsType[];
    SupportedIdentityProviders?: string[];
    CallbackURLs?: string[];
    LogoutURLs?: string[];
    DefaultRedirectURI?: string;
    AllowedOAuthFlows?: OAuthFlowType[];
    AllowedOAuthScopes?: string[];
    AllowedOAuthFlowsUserPoolClient?: boolean;
    AnalyticsConfiguration?: AnalyticsConfigurationType;
    PreventUserExistenceErrors?: PreventUserExistenceErrorTypes;
    EnableTokenRevocation?: boolean;
    EnablePropagateAdditionalUserContextData?: boolean;
    AuthSessionValidity?: number;
    RefreshTokenRotation?: RefreshTokenRotationType;
}
export declare const UpdateUserPoolClientRequest: S.Schema<UpdateUserPoolClientRequest>;
export interface UpdateUserPoolClientResponse {
    UserPoolClient?: UserPoolClientType;
}
export declare const UpdateUserPoolClientResponse: S.Schema<UpdateUserPoolClientResponse>;
export interface UpdateUserPoolDomainRequest {
    Domain: string;
    UserPoolId: string;
    ManagedLoginVersion?: number;
    CustomDomainConfig?: CustomDomainConfigType;
    Routing?: RoutingType;
}
export declare const UpdateUserPoolDomainRequest: S.Schema<UpdateUserPoolDomainRequest>;
export interface UpdateUserPoolDomainResponse {
    ManagedLoginVersion?: number;
    CloudFrontDomain?: string;
    Routing?: RoutingType;
}
export declare const UpdateUserPoolDomainResponse: S.Schema<UpdateUserPoolDomainResponse>;
export type UpdateReplicaStatusType = "ACTIVE" | "INACTIVE" | (string & {});
export declare const UpdateReplicaStatusType: any;
export interface UpdateUserPoolReplicaRequest {
    UserPoolId: string;
    RegionName: string;
    Status: UpdateReplicaStatusType;
}
export declare const UpdateUserPoolReplicaRequest: S.Schema<UpdateUserPoolReplicaRequest>;
export interface UpdateUserPoolReplicaResponse {
    UserPoolReplica?: UserPoolReplicaType;
}
export declare const UpdateUserPoolReplicaResponse: S.Schema<UpdateUserPoolReplicaResponse>;
export type SoftwareTokenMFAUserCodeType = string | redacted.Redacted<string>;
export interface VerifySoftwareTokenRequest {
    AccessToken?: string | redacted.Redacted<string>;
    Session?: string | redacted.Redacted<string>;
    UserCode: string | redacted.Redacted<string>;
    FriendlyDeviceName?: string;
}
export declare const VerifySoftwareTokenRequest: S.Schema<VerifySoftwareTokenRequest>;
export type VerifySoftwareTokenResponseType = "SUCCESS" | "ERROR" | (string & {});
export declare const VerifySoftwareTokenResponseType: any;
export interface VerifySoftwareTokenResponse {
    Status?: VerifySoftwareTokenResponseType;
    Session?: string | redacted.Redacted<string>;
}
export declare const VerifySoftwareTokenResponse: S.Schema<VerifySoftwareTokenResponse>;
export interface VerifyUserAttributeRequest {
    AccessToken: string | redacted.Redacted<string>;
    AttributeName: string;
    Code: string;
}
export declare const VerifyUserAttributeRequest: S.Schema<VerifyUserAttributeRequest>;
export interface VerifyUserAttributeResponse {
}
export declare const VerifyUserAttributeResponse: S.Schema<VerifyUserAttributeResponse>;
export type MessageType = string;
export type InvalidParameterExceptionReasonCodeType = string;
export type AddCustomAttributesError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserImportInProgressException | CommonErrors;
/**
 * Adds additional user attributes to the user pool schema. Custom attributes can be
 * mutable or immutable and have a `custom:` or `dev:` prefix. For
 * more information, see Custom attributes.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const addCustomAttributes: API.OperationMethod<AddCustomAttributesRequest, AddCustomAttributesResponse, AddCustomAttributesError, Credentials | HttpClient.HttpClient>;
export type AddUserPoolClientSecretError = AccessDeniedException | InternalServerException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new client secret for an existing confidential user pool app client. Supports up to 2 active secrets per app client for zero-downtime credential rotation workflows.
 */
export declare const addUserPoolClientSecret: API.OperationMethod<AddUserPoolClientSecretRequest, AddUserPoolClientSecretResponse, AddUserPoolClientSecretError, Credentials | HttpClient.HttpClient>;
export type AdminAddUserToGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Adds a user to a group. A user who is in a group can present a preferred-role claim to
 * an identity pool, and populates a `cognito:groups` claim to their access and
 * identity tokens.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminAddUserToGroup: API.OperationMethod<AdminAddUserToGroupRequest, AdminAddUserToGroupResponse, AdminAddUserToGroupError, Credentials | HttpClient.HttpClient>;
export type AdminConfirmSignUpError = InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyFailedAttemptsException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Confirms user sign-up as an administrator.
 *
 * This request sets a user account active in a user pool that requires confirmation of new user accounts before they can sign in. You can
 * configure your user pool to not send confirmation codes to new users and instead confirm
 * them with this API operation on the back end.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 *
 * To configure your user pool to require administrative confirmation of users, set
 * `AllowAdminCreateUserOnly` to `true` in a
 * `CreateUserPool` or `UpdateUserPool` request.
 */
export declare const adminConfirmSignUp: API.OperationMethod<AdminConfirmSignUpRequest, AdminConfirmSignUpResponse, AdminConfirmSignUpError, Credentials | HttpClient.HttpClient>;
export type AdminCreateUserError = CodeDeliveryFailureException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UnsupportedUserStateException | UserLambdaValidationException | UsernameExistsException | UserNotFoundException | CommonErrors;
/**
 * Creates a new user in the specified user pool.
 *
 * If `MessageAction` isn't set, the default is to send a welcome message via
 * email or phone (SMS).
 *
 * This message is based on a template that you configured in your call to create or
 * update a user pool. This template includes your custom sign-up instructions and
 * placeholders for user name and temporary password.
 *
 * Alternatively, you can call `AdminCreateUser` with `SUPPRESS`
 * for the `MessageAction` parameter, and Amazon Cognito won't send any email.
 *
 * In either case, if the user has a password, they will be in the
 * `FORCE_CHANGE_PASSWORD` state until they sign in and set their password.
 * Your invitation message template must have the `{####}` password placeholder
 * if your users have passwords. If your template doesn't have this placeholder, Amazon Cognito
 * doesn't deliver the invitation message. In this case, you must update your message
 * template and resend the password with a new `AdminCreateUser` request with a
 * `MessageAction` value of `RESEND`.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminCreateUser: API.OperationMethod<AdminCreateUserRequest, AdminCreateUserResponse, AdminCreateUserError, Credentials | HttpClient.HttpClient>;
export type AdminDeleteSoftwareTokenError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Deletes a user's registered time-based one-time password (TOTP) multi-factor
 * authentication (MFA) factor, also known as a software token. After this operation, the
 * user can no longer sign in with TOTP MFA, and can register a new TOTP factor with
 * `AssociateSoftwareToken`. Use this operation when a user loses access to
 * their TOTP-generating device, for example, a lost or reset phone, and needs to register
 * a new one.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDeleteSoftwareToken: API.OperationMethod<AdminDeleteSoftwareTokenRequest, AdminDeleteSoftwareTokenResponse, AdminDeleteSoftwareTokenError, Credentials | HttpClient.HttpClient>;
export type AdminDeleteUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Deletes a user profile in your user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDeleteUser: API.OperationMethod<AdminDeleteUserRequest, AdminDeleteUserResponse, AdminDeleteUserError, Credentials | HttpClient.HttpClient>;
export type AdminDeleteUserAttributesError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Deletes attribute values from a user. This operation doesn't affect tokens for
 * existing user sessions. The next ID token that the user receives will no longer have the
 * deleted attributes.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDeleteUserAttributes: API.OperationMethod<AdminDeleteUserAttributesRequest, AdminDeleteUserAttributesResponse, AdminDeleteUserAttributesError, Credentials | HttpClient.HttpClient>;
export type AdminDisableProviderForUserError = AliasExistsException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Prevents the user from signing in with the specified external (SAML or social)
 * identity provider (IdP). If the user that you want to deactivate is a Amazon Cognito user pools
 * native username + password user, they can't use their password to sign in. If the user
 * to deactivate is a linked external IdP user, any link between that user and an existing
 * user is removed. When the external user signs in again, and the user is no longer
 * attached to the previously linked `DestinationUser`, the user must create a
 * new user account.
 *
 * The value of `ProviderName` must match the name of a user pool IdP.
 *
 * To deactivate a local user, set `ProviderName` to `Cognito` and
 * the `ProviderAttributeName` to `Cognito_Subject`. The
 * `ProviderAttributeValue` must be user's local username.
 *
 * The `ProviderAttributeName` must always be `Cognito_Subject` for
 * social IdPs. The `ProviderAttributeValue` must always be the exact subject
 * that was used when the user was originally linked as a source user.
 *
 * For de-linking a SAML identity, there are two scenarios. If the linked identity has
 * not yet been used to sign in, the `ProviderAttributeName` and
 * `ProviderAttributeValue` must be the same values that were used for the
 * `SourceUser` when the identities were originally linked using
 * AdminLinkProviderForUser call. This is also true if the linking was done with
 * `ProviderAttributeName` set to `Cognito_Subject`. If the user
 * has already signed in, the `ProviderAttributeName` must be
 * `Cognito_Subject` and `ProviderAttributeValue` must be the
 * `NameID` from their SAML assertion.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDisableProviderForUser: API.OperationMethod<AdminDisableProviderForUserRequest, AdminDisableProviderForUserResponse, AdminDisableProviderForUserError, Credentials | HttpClient.HttpClient>;
export type AdminDisableUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Deactivates a user profile and revokes all access tokens for the user. A deactivated
 * user can't sign in, but still appears in the responses to `ListUsers`
 * API requests.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminDisableUser: API.OperationMethod<AdminDisableUserRequest, AdminDisableUserResponse, AdminDisableUserError, Credentials | HttpClient.HttpClient>;
export type AdminEnableUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Activates sign-in for a user profile that previously had sign-in access
 * disabled.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminEnableUser: API.OperationMethod<AdminEnableUserRequest, AdminEnableUserResponse, AdminEnableUserError, Credentials | HttpClient.HttpClient>;
export type AdminForgetDeviceError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Forgets, or deletes, a remembered device from a user's profile. After you forget
 * the device, the user can no longer complete device authentication with that device and
 * when applicable, must submit MFA codes again. For more information, see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminForgetDevice: API.OperationMethod<AdminForgetDeviceRequest, AdminForgetDeviceResponse, AdminForgetDeviceError, Credentials | HttpClient.HttpClient>;
export type AdminGetDeviceError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the device key, returns details for a user's device. For more information,
 * see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminGetDevice: API.OperationMethod<AdminGetDeviceRequest, AdminGetDeviceResponse, AdminGetDeviceError, Credentials | HttpClient.HttpClient>;
export type AdminGetUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Given a username, returns details about a user profile in a user pool. You can specify
 * alias attributes in the `Username` request parameter.
 *
 * This operation contributes to your monthly active user (MAU) count for the purpose of
 * billing.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminGetUser: API.OperationMethod<AdminGetUserRequest, AdminGetUserResponse, AdminGetUserError, Credentials | HttpClient.HttpClient>;
export type AdminGetUserAuthFactorsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Lists the authentication options for a user in a user pool. Returns the
 * following:
 *
 * - The user's multi-factor authentication (MFA) preferences.
 *
 * - The user's options for choice-based authentication with the
 * `USER_AUTH` flow.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminGetUserAuthFactors: API.OperationMethod<AdminGetUserAuthFactorsRequest, AdminGetUserAuthFactorsResponse, AdminGetUserAuthFactorsError, Credentials | HttpClient.HttpClient>;
export type AdminInitiateAuthError = InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | MFAMethodNotFoundException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UnsupportedOperationException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Starts sign-in for applications with a server-side component, for example a
 * traditional web application. This operation specifies the authentication flow that
 * you'd like to begin. The authentication flow that you specify must be supported in
 * your app client configuration. For more information about authentication flows, see
 * Authentication flows.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminInitiateAuth: API.OperationMethod<AdminInitiateAuthRequest, AdminInitiateAuthResponse, AdminInitiateAuthError, Credentials | HttpClient.HttpClient>;
export type AdminLinkProviderForUserError = AliasExistsException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Links an existing user account in a user pool, or `DestinationUser`, to an
 * identity from an external IdP, or `SourceUser`, based on a specified
 * attribute name and value from the external IdP.
 *
 * This operation connects a local user profile with a user identity who hasn't yet
 * signed in from their third-party IdP. When the user signs in with their IdP, they get
 * access-control configuration from the local user profile. Linked local users can also
 * sign in with SDK-based API operations like `InitiateAuth` after they sign in
 * at least once through their IdP. For more information, see Linking federated users.
 *
 * The maximum number of federated identities linked to a user is five.
 *
 * Because this API allows a user with an external federated identity to sign in as a
 * local user, it is critical that it only be used with external IdPs and linked
 * attributes that you trust.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminLinkProviderForUser: API.OperationMethod<AdminLinkProviderForUserRequest, AdminLinkProviderForUserResponse, AdminLinkProviderForUserError, Credentials | HttpClient.HttpClient>;
export type AdminListDevicesError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists a user's registered devices. Remembered devices are used in authentication
 * services where you offer a "Remember me" option for users who you want to permit to sign
 * in without MFA from a trusted device. Users can bypass MFA while your application
 * performs device SRP authentication on the back end. For more information, see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminListDevices: API.OperationMethod<AdminListDevicesRequest, AdminListDevicesResponse, AdminListDevicesError, Credentials | HttpClient.HttpClient>;
export type AdminListGroupsForUserError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Lists the groups that a user belongs to. User pool groups are identifiers that you can
 * reference from the contents of ID and access tokens, and set preferred IAM roles for
 * identity-pool authentication. For more information, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminListGroupsForUser: API.PaginatedOperationMethod<AdminListGroupsForUserRequest, AdminListGroupsForUserResponse, AdminListGroupsForUserError, Credentials | HttpClient.HttpClient, GroupType>;
export type AdminListUserAuthEventsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Requests a history of user activity and any risks detected as part of Amazon Cognito threat
 * protection. For more information, see Viewing user event history.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminListUserAuthEvents: API.PaginatedOperationMethod<AdminListUserAuthEventsRequest, AdminListUserAuthEventsResponse, AdminListUserAuthEventsError, Credentials | HttpClient.HttpClient, AuthEventType>;
export type AdminRemoveUserFromGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Given a username and a group name, removes them from the group. User pool groups are
 * identifiers that you can reference from the contents of ID and access tokens, and set
 * preferred IAM roles for identity-pool authentication. For more information, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminRemoveUserFromGroup: API.OperationMethod<AdminRemoveUserFromGroupRequest, AdminRemoveUserFromGroupResponse, AdminRemoveUserFromGroupError, Credentials | HttpClient.HttpClient>;
export type AdminResetUserPasswordError = InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Begins the password reset process. Sets the requested user’s account into a
 * `RESET_REQUIRED` status, and sends them a password-reset code. Your user
 * pool also sends the user a notification with a reset code and the information that their
 * password has been reset. At sign-in, your application or the managed login session
 * receives a challenge to complete the reset by confirming the code and setting a new
 * password.
 *
 * To use this API operation, your user pool must have self-service account recovery
 * configured.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminResetUserPassword: API.OperationMethod<AdminResetUserPasswordRequest, AdminResetUserPasswordResponse, AdminResetUserPasswordError, Credentials | HttpClient.HttpClient>;
export type AdminRespondToAuthChallengeError = AliasExistsException | CodeMismatchException | ExpiredCodeException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | MFAMethodNotFoundException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | PasswordResetRequiredException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Some API operations in a user pool generate a challenge, like a prompt for an MFA
 * code, for device authentication that bypasses MFA, or for a custom authentication
 * challenge. An `AdminRespondToAuthChallenge` API request provides the answer
 * to that challenge, like a code or a secure remote password (SRP). The parameters of a
 * response to an authentication challenge vary with the type of challenge.
 *
 * For more information about custom authentication challenges, see Custom
 * authentication challenge Lambda triggers.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminRespondToAuthChallenge: API.OperationMethod<AdminRespondToAuthChallengeRequest, AdminRespondToAuthChallengeResponse, AdminRespondToAuthChallengeError, Credentials | HttpClient.HttpClient>;
export type AdminSetUserMFAPreferenceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Sets the user's multi-factor authentication (MFA) preference, including which MFA
 * options are activated, and if any are preferred. Only one factor can be set as
 * preferred. The preferred MFA factor will be used to authenticate a user if multiple
 * factors are activated. If multiple options are activated and no preference is set, a
 * challenge to choose an MFA option will be returned during sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminSetUserMFAPreference: API.OperationMethod<AdminSetUserMFAPreferenceRequest, AdminSetUserMFAPreferenceResponse, AdminSetUserMFAPreferenceError, Credentials | HttpClient.HttpClient>;
export type AdminSetUserPasswordError = InternalErrorException | InvalidParameterException | InvalidPasswordException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Sets the specified user's password in a user pool. This operation administratively
 * sets a temporary or permanent password for a user. With this operation, you can bypass
 * self-service password changes and permit immediate sign-in with the password that you
 * set. To do this, set `Permanent` to `true`.
 *
 * You can also set a new temporary password in this request, send it to a user, and
 * require them to choose a new password on their next sign-in. To do this, set
 * `Permanent` to `false`.
 *
 * If the password is temporary, the user's `Status` becomes
 * `FORCE_CHANGE_PASSWORD`. When the user next tries to sign in, the
 * `InitiateAuth` or `AdminInitiateAuth` response includes the
 * `NEW_PASSWORD_REQUIRED` challenge. If the user doesn't sign in
 * before the temporary password expires, they can no longer sign in and you must repeat
 * this operation to set a temporary or permanent password for them.
 *
 * After the user sets a new password, or if you set a permanent password, their status
 * becomes `Confirmed`.
 *
 * `AdminSetUserPassword` can set a password for the user profile that Amazon Cognito
 * creates for third-party federated users. When you set a password, the federated user's
 * status changes from `EXTERNAL_PROVIDER` to `CONFIRMED`. A user in
 * this state can sign in as a federated user, and initiate authentication flows in the API
 * like a linked native user. They can also modify their password and attributes in
 * token-authenticated API requests like `ChangePassword` and
 * `UpdateUserAttributes`. As a best security practice and to keep users in
 * sync with your external IdP, don't set passwords on federated user profiles. To set up a
 * federated user for native sign-in with a linked native user, refer to Linking federated users to an existing user
 * profile.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminSetUserPassword: API.OperationMethod<AdminSetUserPasswordRequest, AdminSetUserPasswordResponse, AdminSetUserPasswordError, Credentials | HttpClient.HttpClient>;
export type AdminSetUserSettingsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | UserNotFoundException | CommonErrors;
/**
 * *This action is no longer supported.* You can use it to configure
 * only SMS MFA. You can't use it to configure time-based one-time password (TOTP) software
 * token MFA.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminSetUserSettings: API.OperationMethod<AdminSetUserSettingsRequest, AdminSetUserSettingsResponse, AdminSetUserSettingsError, Credentials | HttpClient.HttpClient>;
export type AdminUpdateAuthEventFeedbackError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Provides the feedback for an authentication event generated by threat protection
 * features. Your response indicates that you think that the event either was from a valid
 * user or was an unwanted authentication attempt. This feedback improves the risk
 * evaluation decision for the user pool as part of Amazon Cognito threat protection.
 * To activate this setting, your user pool must be on the
 * Plus tier.
 *
 * To train the threat-protection model to recognize trusted and untrusted sign-in
 * characteristics, configure threat protection in audit-only mode and provide a mechanism
 * for users or administrators to submit feedback. Your feedback can tell Amazon Cognito that a risk
 * rating was assigned at a level you don't agree with.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminUpdateAuthEventFeedback: API.OperationMethod<AdminUpdateAuthEventFeedbackRequest, AdminUpdateAuthEventFeedbackResponse, AdminUpdateAuthEventFeedbackError, Credentials | HttpClient.HttpClient>;
export type AdminUpdateDeviceStatusError = InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Updates the status of a user's device so that it is marked as remembered or not
 * remembered for the purpose of device authentication. Device authentication is a
 * "remember me" mechanism that silently completes sign-in from trusted devices with a
 * device key instead of a user-provided MFA code. This operation changes the status of a
 * device without deleting it, so you can enable it again later. For more information about
 * device authentication, see Working with devices.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminUpdateDeviceStatus: API.OperationMethod<AdminUpdateDeviceStatusRequest, AdminUpdateDeviceStatusResponse, AdminUpdateDeviceStatusError, Credentials | HttpClient.HttpClient>;
export type AdminUpdateUserAttributesError = AliasExistsException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Updates the specified user's attributes. To delete an attribute from your user,
 * submit the attribute in your API request with a blank value.
 *
 * For custom attributes, you must add a `custom:` prefix to the attribute
 * name, for example `custom:department`.
 *
 * This operation can set a user's email address or phone number as verified and
 * permit immediate sign-in in user pools that require verification of these attributes. To
 * do this, set the `email_verified` or `phone_number_verified`
 * attribute to `true`.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const adminUpdateUserAttributes: API.OperationMethod<AdminUpdateUserAttributesRequest, AdminUpdateUserAttributesResponse, AdminUpdateUserAttributesError, Credentials | HttpClient.HttpClient>;
export type AdminUserGlobalSignOutError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | CommonErrors;
/**
 * Invalidates the identity, access, and refresh tokens that Amazon Cognito issued to a user. Call
 * this operation with your administrative credentials when your user signs out of your
 * app. This results in the following behavior.
 *
 * - Amazon Cognito no longer accepts *token-authorized* user operations
 * that you authorize with a signed-out user's access tokens. For more information,
 * see Using the Amazon Cognito user pools API and user pool
 * endpoints.
 *
 * Amazon Cognito returns an `Access Token has been revoked` error when your
 * app attempts to authorize a user pools API request with a revoked access token
 * that contains the scope `aws.cognito.signin.user.admin`.
 *
 * - Amazon Cognito no longer accepts a signed-out user's ID token in a GetId request to an identity pool with
 * `ServerSideTokenCheck` enabled for its user pool IdP
 * configuration in CognitoIdentityProvider.
 *
 * - Amazon Cognito no longer accepts a signed-out user's refresh tokens in refresh
 * requests.
 *
 * Other requests might be valid until your user's token expires. This operation
 * doesn't clear the managed login session cookie. To clear the session for
 * a user who signed in with managed login or the classic hosted UI, direct their browser
 * session to the logout endpoint.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const adminUserGlobalSignOut: API.OperationMethod<AdminUserGlobalSignOutRequest, AdminUserGlobalSignOutResponse, AdminUserGlobalSignOutError, Credentials | HttpClient.HttpClient>;
export type AssociateSoftwareTokenError = ConcurrentModificationException | ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | CommonErrors;
/**
 * Begins setup of time-based one-time password (TOTP) multi-factor authentication (MFA)
 * for a user, with a unique private key that Amazon Cognito generates and returns in the API
 * response. You can authorize an `AssociateSoftwareToken` request with either
 * the user's access token, or a session string from a challenge response that you received
 * from Amazon Cognito.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 */
export declare const associateSoftwareToken: API.OperationMethod<AssociateSoftwareTokenRequest, AssociateSoftwareTokenResponse, AssociateSoftwareTokenError, Credentials | HttpClient.HttpClient>;
export type ChangePasswordError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidPasswordException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Changes the password for the currently signed-in user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const changePassword: API.OperationMethod<ChangePasswordRequest, ChangePasswordResponse, ChangePasswordError, Credentials | HttpClient.HttpClient>;
export type CompleteWebAuthnRegistrationError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | TooManyRequestsException | WebAuthnChallengeNotFoundException | WebAuthnClientMismatchException | WebAuthnCredentialNotSupportedException | WebAuthnNotEnabledException | WebAuthnOriginNotAllowedException | WebAuthnRelyingPartyMismatchException | CommonErrors;
/**
 * Completes registration of a passkey authenticator for the currently signed-in
 * user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 */
export declare const completeWebAuthnRegistration: API.OperationMethod<CompleteWebAuthnRegistrationRequest, CompleteWebAuthnRegistrationResponse, CompleteWebAuthnRegistrationError, Credentials | HttpClient.HttpClient>;
export type ConfirmDeviceError = DeviceKeyExistsException | ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UsernameExistsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Confirms a device that a user wants to remember. A remembered device is a "Remember me
 * on this device" option for user pools that perform authentication with the device key of
 * a trusted device in the back end, instead of a user-provided MFA code. For more
 * information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const confirmDevice: API.OperationMethod<ConfirmDeviceRequest, ConfirmDeviceResponse, ConfirmDeviceError, Credentials | HttpClient.HttpClient>;
export type ConfirmForgotPasswordError = CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | ResourceNotFoundException | TooManyFailedAttemptsException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * This public API operation accepts a confirmation code that Amazon Cognito sent to a user and
 * accepts a new password for that user.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const confirmForgotPassword: API.OperationMethod<ConfirmForgotPasswordRequest, ConfirmForgotPasswordResponse, ConfirmForgotPasswordError, Credentials | HttpClient.HttpClient>;
export type ConfirmSignUpError = AliasExistsException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyFailedAttemptsException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Confirms the account of a new user. This public API operation submits a code that
 * Amazon Cognito sent to your user when they signed up in your user pool. After your user enters
 * their code, they confirm ownership of the email address or phone number that they
 * provided, and their user account becomes active. Depending on your user pool
 * configuration, your users will receive their confirmation code in an email or SMS
 * message.
 *
 * Local users who signed up in your user pool are the only type of user who can confirm
 * sign-up with a code. Users who federate through an external identity provider (IdP) have
 * already been confirmed by their IdP.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const confirmSignUp: API.OperationMethod<ConfirmSignUpRequest, ConfirmSignUpResponse, ConfirmSignUpError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = GroupExistsException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new group in the specified user pool. For more information about user pool
 * groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateIdentityProviderError = DuplicateProviderException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Adds a configuration and trust relationship between a third-party identity provider
 * (IdP) and a user pool. Amazon Cognito accepts sign-in with third-party identity providers through
 * managed login and OIDC relying-party libraries. For more information, see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createIdentityProvider: API.OperationMethod<CreateIdentityProviderRequest, CreateIdentityProviderResponse, CreateIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type CreateManagedLoginBrandingError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | LimitExceededException | ManagedLoginBrandingExistsException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new set of branding settings for a user pool style and associates it with an
 * app client. This operation is the programmatic option for the creation of a new style in
 * the branding editor.
 *
 * Provides values for UI customization in a `Settings` JSON object and image
 * files in an `Assets` array. To send the JSON object `Document`
 * type parameter in `Settings`, you might need to update to the most recent
 * version of your Amazon Web Services SDK. To create a new style with default settings, set
 * `UseCognitoProvidedValues` to `true` and don't provide
 * values for any other options.
 *
 * This operation has a 2-megabyte request-size limit and include the CSS settings and
 * image assets for your app client. Your branding settings might exceed 2MB in size. Amazon Cognito
 * doesn't require that you pass all parameters in one request and preserves existing
 * style settings that you don't specify. If your request is larger than 2MB, separate it
 * into multiple requests, each with a size smaller than the limit.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createManagedLoginBranding: API.OperationMethod<CreateManagedLoginBrandingRequest, CreateManagedLoginBrandingResponse, CreateManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type CreateResourceServerError = InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a new OAuth2.0 resource server and defines custom scopes within it. Resource
 * servers are associated with custom scopes and machine-to-machine (M2M) authorization.
 * For more information, see Access control with resource servers.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createResourceServer: API.OperationMethod<CreateResourceServerRequest, CreateResourceServerResponse, CreateResourceServerError, Credentials | HttpClient.HttpClient>;
export type CreateTermsError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TermsExistsException | TooManyRequestsException | CommonErrors;
/**
 * Creates terms documents for the requested app client. When Terms and conditions and
 * Privacy policy documents are configured, the app client displays links to them in the
 * sign-up page of managed login for the app client.
 *
 * You can provide URLs for terms documents in the languages that are supported by managed login localization. Amazon Cognito directs users to the terms documents for
 * their current language, with fallback to `default` if no document exists for
 * the language.
 *
 * Each request accepts one type of terms document and a map of language-to-link for that
 * document type. You must provide both types of terms documents in at least one language
 * before Amazon Cognito displays your terms documents. Supply each type in separate
 * requests.
 *
 * For more information, see Terms documents.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createTerms: API.OperationMethod<CreateTermsRequest, CreateTermsResponse, CreateTermsError, Credentials | HttpClient.HttpClient>;
export type CreateUserImportJobError = InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Creates a user import job. You can import users into user pools from a comma-separated
 * values (CSV) file without adding Amazon Cognito MAU costs to your Amazon Web Services bill.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserImportJob: API.OperationMethod<CreateUserImportJobRequest, CreateUserImportJobResponse, CreateUserImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolError = FeatureUnavailableInTierException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | TierChangeNotAllowedException | TooManyRequestsException | UserPoolTaggingException | CommonErrors;
/**
 * Creates a new Amazon Cognito user pool. This operation sets basic and advanced configuration
 * options.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPool: API.OperationMethod<CreateUserPoolRequest, CreateUserPoolResponse, CreateUserPoolError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolClientError = FeatureUnavailableInTierException | InternalErrorException | InvalidOAuthFlowException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | ScopeDoesNotExistException | TooManyRequestsException | CommonErrors;
/**
 * Creates an app client in a user pool. This operation sets basic and advanced
 * configuration options.
 *
 * Unlike app clients created in the console, Amazon Cognito doesn't automatically assign a
 * branding style to app clients that you configure with this API operation. Managed login and classic hosted UI pages aren't
 * available for your client until after you apply a branding style.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPoolClient: API.OperationMethod<CreateUserPoolClientRequest, CreateUserPoolClientResponse, CreateUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolDomainError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * A user pool domain hosts managed login, an authorization server and web server for
 * authentication in your application. This operation creates a new user pool prefix domain
 * or custom domain and sets the managed login branding version. Set the branding version
 * to `1` for hosted UI (classic) or `2` for managed login. When you
 * choose a custom domain, you must provide an SSL certificate in the US East (N. Virginia)
 * Amazon Web Services Region in your request.
 *
 * Your prefix domain might take up to one minute to take effect. Your custom domain is
 * online within five minutes, but it can take up to one hour to distribute your SSL
 * certificate.
 *
 * For more information about adding a custom domain to your user pool, see Configuring a user pool domain.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPoolDomain: API.OperationMethod<CreateUserPoolDomainRequest, CreateUserPoolDomainResponse, CreateUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type CreateUserPoolReplicaError = FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolTaggingException | CommonErrors;
/**
 * Creates a replica of an existing user pool in a specified Amazon Web Services Region. The replica
 * enables multi-region replication for high availability and disaster recovery. To create
 * a replica, you must have permissions to create user pools in the target Region.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const createUserPoolReplica: API.OperationMethod<CreateUserPoolReplicaRequest, CreateUserPoolReplicaResponse, CreateUserPoolReplicaError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a group from the specified user pool. When you delete a group, that group no
 * longer contributes to users' `cognito:preferred_group` or
 * `cognito:groups` claims, and no longer influence access-control decision
 * that are based on group membership. For more information about user pool groups, see
 * Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityProviderError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | UnsupportedIdentityProviderException | CommonErrors;
/**
 * Deletes a user pool identity provider (IdP). After you delete an IdP, users can no
 * longer sign in to your user pool through that IdP. For more information about user pool
 * IdPs, see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteIdentityProvider: API.OperationMethod<DeleteIdentityProviderRequest, DeleteIdentityProviderResponse, DeleteIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteManagedLoginBrandingError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a managed login branding style. When you delete a style, you delete the
 * branding association for an app client. When an app client doesn't have a style
 * assigned, your managed login pages for that app client are nonfunctional until you
 * create a new style or switch the domain branding version.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteManagedLoginBranding: API.OperationMethod<DeleteManagedLoginBrandingRequest, DeleteManagedLoginBrandingResponse, DeleteManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceServerError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a resource server. After you delete a resource server, users can no longer
 * generate access tokens with scopes that are associate with that resource server.
 *
 * Resource servers are associated with custom scopes and machine-to-machine (M2M)
 * authorization. For more information, see Access control with resource servers.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteResourceServer: API.OperationMethod<DeleteResourceServerRequest, DeleteResourceServerResponse, DeleteResourceServerError, Credentials | HttpClient.HttpClient>;
export type DeleteTermsError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes the terms documents with the requested ID from your app client.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteTerms: API.OperationMethod<DeleteTermsRequest, DeleteTermsResponse, DeleteTermsError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Deletes the profile of the currently signed-in user. A deleted user profile can no
 * longer be used to sign in and can't be restored.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteUserAttributesError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Deletes attributes from the currently signed-in user. For example, your application
 * can submit a request to this operation when a user wants to remove their
 * `birthdate` attribute value.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const deleteUserAttributes: API.OperationMethod<DeleteUserAttributesRequest, DeleteUserAttributesResponse, DeleteUserAttributesError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserImportInProgressException | CommonErrors;
/**
 * Deletes a user pool. After you delete a user pool, users can no longer sign in to any
 * associated applications.
 *
 * When you delete a user pool, it's no longer visible or operational in your Amazon Web Services account. Amazon Cognito retains deleted user pools in an inactive state for 14
 * days, then begins a cleanup process that fully removes them from Amazon Web Services systems. In case
 * of accidental deletion, contact Amazon Web Services Support within 14 days for restoration
 * assistance.
 *
 * Amazon Cognito begins full deletion of all resources from deleted user pools after 14 days. In
 * the case of large user pools, the cleanup process might take significant additional time
 * before all user data is permanently deleted.
 */
export declare const deleteUserPool: API.OperationMethod<DeleteUserPoolRequest, DeleteUserPoolResponse, DeleteUserPoolError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolClientError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a user pool app client. After you delete an app client, users can no longer
 * sign in to the associated application.
 */
export declare const deleteUserPoolClient: API.OperationMethod<DeleteUserPoolClientRequest, DeleteUserPoolClientResponse, DeleteUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolClientSecretError = InternalServerException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a specific client secret from a user pool app client. You cannot delete the last remaining secret for an app client.
 */
export declare const deleteUserPoolClientSecret: API.OperationMethod<DeleteUserPoolClientSecretRequest, DeleteUserPoolClientSecretResponse, DeleteUserPoolClientSecretError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolDomainError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * Given a user pool ID and domain identifier, deletes a user pool domain. After you
 * delete a user pool domain, your managed login pages and authorization server are no
 * longer available.
 */
export declare const deleteUserPoolDomain: API.OperationMethod<DeleteUserPoolDomainRequest, DeleteUserPoolDomainResponse, DeleteUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteUserPoolReplicaError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a secondary replica user pool. You can only delete replicas that are in the
 * INACTIVE status. This operation must be called from the primary Region.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const deleteUserPoolReplica: API.OperationMethod<DeleteUserPoolReplicaRequest, DeleteUserPoolReplicaResponse, DeleteUserPoolReplicaError, Credentials | HttpClient.HttpClient>;
export type DeleteWebAuthnCredentialError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a registered passkey, or WebAuthn, authenticator for the currently signed-in
 * user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const deleteWebAuthnCredential: API.OperationMethod<DeleteWebAuthnCredentialRequest, DeleteWebAuthnCredentialResponse, DeleteWebAuthnCredentialError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityProviderError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID and identity provider (IdP) name, returns details about the
 * IdP.
 */
export declare const describeIdentityProvider: API.OperationMethod<DescribeIdentityProviderRequest, DescribeIdentityProviderResponse, DescribeIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type DescribeManagedLoginBrandingError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the ID of a managed login branding style, returns detailed information about the
 * style.
 */
export declare const describeManagedLoginBranding: API.OperationMethod<DescribeManagedLoginBrandingRequest, DescribeManagedLoginBrandingResponse, DescribeManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type DescribeManagedLoginBrandingByClientError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the ID of a user pool app client, returns detailed information about the style
 * assigned to the app client.
 */
export declare const describeManagedLoginBrandingByClient: API.OperationMethod<DescribeManagedLoginBrandingByClientRequest, DescribeManagedLoginBrandingByClientResponse, DescribeManagedLoginBrandingByClientError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceServerError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Describes a resource server. For more information about resource servers, see Access control with resource servers.
 */
export declare const describeResourceServer: API.OperationMethod<DescribeResourceServerRequest, DescribeResourceServerResponse, DescribeResourceServerError, Credentials | HttpClient.HttpClient>;
export type DescribeRiskConfigurationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Given an app client or user pool ID where threat protection is configured, describes
 * the risk configuration. This operation returns details about adaptive authentication,
 * compromised credentials, and IP-address allow- and denylists. For more information about
 * threat protection, see Threat protection.
 */
export declare const describeRiskConfiguration: API.OperationMethod<DescribeRiskConfigurationRequest, DescribeRiskConfigurationResponse, DescribeRiskConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeTermsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns details for the requested terms documents ID. For more information, see Terms documents.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeTerms: API.OperationMethod<DescribeTermsRequest, DescribeTermsResponse, DescribeTermsError, Credentials | HttpClient.HttpClient>;
export type DescribeTermsByClientError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns details for the terms documents that are associated with an app client,
 * identified by the app client ID, user pool ID, and terms name. For
 * more information, see Terms documents.
 *
 * To call `DescribeTermsByClient`, you must have the
 * `cognito-idp:DescribeTermsByClient` Identity and Access Management (IAM) permission. This
 * operation additionally validates your permission for
 * `cognito-idp:DescribeTerms`, the action for . As a result, an IAM policy that denies
 * `cognito-idp:DescribeTerms` also denies requests to
 * `DescribeTermsByClient`.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeTermsByClient: API.OperationMethod<DescribeTermsByClientRequest, DescribeTermsByClientResponse, DescribeTermsByClientError, Credentials | HttpClient.HttpClient>;
export type DescribeUserImportJobError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Describes a user import job. For more information about user CSV import, see Importing users from a CSV file.
 */
export declare const describeUserImportJob: API.OperationMethod<DescribeUserImportJobRequest, DescribeUserImportJobResponse, DescribeUserImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeUserPoolError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolTaggingException | CommonErrors;
/**
 * Given a user pool ID, returns configuration information. This operation is useful when
 * you want to inspect an existing user pool and programmatically replicate the
 * configuration to another user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeUserPool: API.OperationMethod<DescribeUserPoolRequest, DescribeUserPoolResponse, DescribeUserPoolError, Credentials | HttpClient.HttpClient>;
export type DescribeUserPoolClientError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given an app client ID, returns configuration information. This operation is useful
 * when you want to inspect an existing app client and programmatically replicate the
 * configuration to another app client. For more information about app clients, see App clients.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeUserPoolClient: API.OperationMethod<DescribeUserPoolClientRequest, DescribeUserPoolClientResponse, DescribeUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type DescribeUserPoolDomainError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * Given a user pool domain name, returns information about the domain
 * configuration.
 *
 * This operation doesn't return results when you query a prefix domain in a
 * secondary Region. Prefix domains are Region-specific and can only be described in
 * the Region where they were created. To describe a prefix domain for a replica user
 * pool, make the request to the primary Region's endpoint.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const describeUserPoolDomain: API.OperationMethod<DescribeUserPoolDomainRequest, DescribeUserPoolDomainResponse, DescribeUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type ForgetDeviceError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Given a device key, deletes a remembered device as the currently signed-in user. For
 * more information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const forgetDevice: API.OperationMethod<ForgetDeviceRequest, ForgetDeviceResponse, ForgetDeviceError, Credentials | HttpClient.HttpClient>;
export type ForgotPasswordError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Sends a password-reset confirmation code to the email address or phone number of the
 * requested username. The message delivery method is determined by the user's
 * available attributes and the `AccountRecoverySetting` configuration of the
 * user pool.
 *
 * For the `Username` parameter, you can use the username or an email, phone,
 * or preferred username alias.
 *
 * If neither a verified phone number nor a verified email exists, Amazon Cognito responds with an
 * `InvalidParameterException` error . If your app client has a client
 * secret and you don't provide a `SECRET_HASH` parameter, this API returns
 * `NotAuthorizedException`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const forgotPassword: API.OperationMethod<ForgotPasswordRequest, ForgotPasswordResponse, ForgotPasswordError, Credentials | HttpClient.HttpClient>;
export type GetClientTokenError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Issues an access token for machine-to-machine (M2M) authorization. Your app client
 * provides its client ID and secret, and receives an access token that authorizes requests
 * to your resource servers. `GetClientToken` provides the same functionality as
 * the OAuth2 client-credentials grant; both authorize an application rather than a user.
 *
 * To use this operation, you must configure the app client with a client secret and
 * enable the `ALLOW_CLIENT_TOKEN_AUTH` authentication flow. The
 * `ALLOW_CLIENT_TOKEN_AUTH` flow is mutually exclusive with user authentication
 * flows. It must be the only authentication flow that you configure for the app client. For
 * more information, see Scopes, M2M, and resource servers.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getClientToken: API.OperationMethod<GetClientTokenRequest, GetClientTokenResponse, GetClientTokenError, Credentials | HttpClient.HttpClient>;
export type GetCSVHeaderError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, generates a comma-separated value (CSV) list populated with
 * available user attributes in the user pool. This list is the header for the CSV file
 * that determines the users in a user import job. Save the content of
 * `CSVHeader` in the response as a `.csv` file and populate it
 * with the usernames and attributes of users that you want to import. For more information
 * about CSV user import, see Importing users from a CSV file.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getCSVHeader: API.OperationMethod<GetCSVHeaderRequest, GetCSVHeaderResponse, GetCSVHeaderError, Credentials | HttpClient.HttpClient>;
export type GetDeviceError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Given a device key, returns information about a remembered device for the current
 * user. For more information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getDevice: API.OperationMethod<GetDeviceRequest, GetDeviceResponse, GetDeviceError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID and a group name, returns information about the user
 * group.
 *
 * For more information about user pool groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient>;
export type GetIdentityProviderByIdentifierError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the identifier of an identity provider (IdP), for example
 * `examplecorp`, returns information about the user pool configuration for
 * that IdP. For more information about IdPs, see Third-party IdP sign-in.
 */
export declare const getIdentityProviderByIdentifier: API.OperationMethod<GetIdentityProviderByIdentifierRequest, GetIdentityProviderByIdentifierResponse, GetIdentityProviderByIdentifierError, Credentials | HttpClient.HttpClient>;
export type GetLogDeliveryConfigurationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns the logging configuration. User pools can export
 * message-delivery error and threat-protection activity logs to external Amazon Web Services services. For more information, see Exporting user pool logs.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getLogDeliveryConfiguration: API.OperationMethod<GetLogDeliveryConfigurationRequest, GetLogDeliveryConfigurationResponse, GetLogDeliveryConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetProvisionedLimitError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns the current provisioned limit for a specific API category.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getProvisionedLimit: API.OperationMethod<GetProvisionedLimitRequest, GetProvisionedLimitResponse, GetProvisionedLimitError, Credentials | HttpClient.HttpClient>;
export type GetSigningCertificateError = InternalErrorException | InvalidParameterException | OperationNotEnabledException | ResourceNotFoundException | CommonErrors;
/**
 * Given a user pool ID, returns the signing certificate for SAML 2.0 federation.
 *
 * Issued certificates are valid for 10 years from the date of issue. Amazon Cognito issues and
 * assigns a new signing certificate annually. This renewal process returns a new value in
 * the response to `GetSigningCertificate`, but doesn't invalidate the original
 * certificate.
 *
 * For more information, see Signing SAML requests.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getSigningCertificate: API.OperationMethod<GetSigningCertificateRequest, GetSigningCertificateResponse, GetSigningCertificateError, Credentials | HttpClient.HttpClient>;
export type GetTokensFromRefreshTokenError = ForbiddenException | InternalErrorException | InvalidLambdaResponseException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | RefreshTokenReuseException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Given a refresh token, issues new ID, access, and optionally refresh tokens for the
 * user who owns the submitted token. This operation issues a new refresh token and
 * invalidates the original refresh token after an optional grace period when refresh token
 * rotation is enabled. If refresh token rotation is disabled, issues new ID and access
 * tokens only.
 */
export declare const getTokensFromRefreshToken: API.OperationMethod<GetTokensFromRefreshTokenRequest, GetTokensFromRefreshTokenResponse, GetTokensFromRefreshTokenError, Credentials | HttpClient.HttpClient>;
export type GetUICustomizationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID or app client, returns information about classic hosted UI
 * branding that you applied, if any. Returns user-pool level branding information if no
 * app client branding is applied, or if you don't specify an app client ID. Returns
 * an empty object if you haven't applied hosted UI branding to either the client or
 * the user pool. For more information, see Hosted UI (classic) branding.
 */
export declare const getUICustomization: API.OperationMethod<GetUICustomizationRequest, GetUICustomizationResponse, GetUICustomizationError, Credentials | HttpClient.HttpClient>;
export type GetUserError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Gets user attributes and and MFA settings for the currently signed-in user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getUser: API.OperationMethod<GetUserRequest, GetUserResponse, GetUserError, Credentials | HttpClient.HttpClient>;
export type GetUserAttributeVerificationCodeError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Given an attribute name, sends a user attribute verification code for the specified
 * attribute name to the currently signed-in user.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const getUserAttributeVerificationCode: API.OperationMethod<GetUserAttributeVerificationCodeRequest, GetUserAttributeVerificationCodeResponse, GetUserAttributeVerificationCodeError, Credentials | HttpClient.HttpClient>;
export type GetUserAuthFactorsError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Lists the authentication options for the currently signed-in user. Returns the
 * following:
 *
 * - The user's multi-factor authentication (MFA) preferences.
 *
 * - The user's options for choice-based authentication with the
 * `USER_AUTH` flow.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const getUserAuthFactors: API.OperationMethod<GetUserAuthFactorsRequest, GetUserAuthFactorsResponse, GetUserAuthFactorsError, Credentials | HttpClient.HttpClient>;
export type GetUserPoolMfaConfigError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns configuration for sign-in with WebAuthn authenticators
 * and for multi-factor authentication (MFA). This operation describes the
 * following:
 *
 * - The WebAuthn relying party (RP) ID and user-verification settings.
 *
 * - The required, optional, or disabled state of MFA for all user pool
 * users.
 *
 * - The message templates for email and SMS MFA.
 *
 * - The enabled or disabled state of time-based one-time password (TOTP)
 * MFA.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const getUserPoolMfaConfig: API.OperationMethod<GetUserPoolMfaConfigRequest, GetUserPoolMfaConfigResponse, GetUserPoolMfaConfigError, Credentials | HttpClient.HttpClient>;
export type GlobalSignOutError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | CommonErrors;
/**
 * Invalidates the identity, access, and refresh tokens that Amazon Cognito issued to a user. Call
 * this operation when your user signs out of your app. This results in the following
 * behavior.
 *
 * - Amazon Cognito no longer accepts *token-authorized* user operations
 * that you authorize with a signed-out user's access tokens. For more information,
 * see Using the Amazon Cognito user pools API and user pool
 * endpoints.
 *
 * Amazon Cognito returns an `Access Token has been revoked` error when your
 * app attempts to authorize a user pools API request with a revoked access token
 * that contains the scope `aws.cognito.signin.user.admin`.
 *
 * - Amazon Cognito no longer accepts a signed-out user's ID token in a GetId request to an identity pool with
 * `ServerSideTokenCheck` enabled for its user pool IdP
 * configuration in CognitoIdentityProvider.
 *
 * - Amazon Cognito no longer accepts a signed-out user's refresh tokens in refresh
 * requests.
 *
 * Other requests might be valid until your user's token expires. This operation
 * doesn't clear the managed login session cookie. To clear the session for
 * a user who signed in with managed login or the classic hosted UI, direct their browser
 * session to the logout endpoint.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const globalSignOut: API.OperationMethod<GlobalSignOutRequest, GlobalSignOutResponse, GlobalSignOutError, Credentials | HttpClient.HttpClient>;
export type InitiateAuthError = ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UnsupportedOperationException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Declares an authentication flow and initiates sign-in for a user in the Amazon Cognito user
 * directory. Amazon Cognito might respond with an additional challenge or an
 * `AuthenticationResult` that contains the outcome of a successful
 * authentication. You can't sign in a user with a federated IdP with
 * `InitiateAuth`. For more information, see Authentication.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const initiateAuth: API.OperationMethod<InitiateAuthRequest, InitiateAuthResponse, InitiateAuthError, Credentials | HttpClient.HttpClient>;
export type ListDevicesError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Lists the devices that Amazon Cognito has registered to the currently signed-in user. For more
 * information about device authentication, see Working with user devices in your user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const listDevices: API.OperationMethod<ListDevicesRequest, ListDevicesResponse, ListDevicesError, Credentials | HttpClient.HttpClient>;
export type ListGroupsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns user pool groups and their details.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, GroupType>;
export type ListIdentityProvidersError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns information about configured identity providers (IdPs).
 * For more information about IdPs, see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listIdentityProviders: API.PaginatedOperationMethod<ListIdentityProvidersRequest, ListIdentityProvidersResponse, ListIdentityProvidersError, Credentials | HttpClient.HttpClient, ProviderDescription>;
export type ListResourceServersError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns all resource servers and their details. For more
 * information about resource servers, see Access control with resource servers.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listResourceServers: API.PaginatedOperationMethod<ListResourceServersRequest, ListResourceServersResponse, ListResourceServersError, Credentials | HttpClient.HttpClient, ResourceServerType>;
export type ListTagsForResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags that are assigned to an Amazon Cognito user pool. For more information, see
 * Tagging
 * resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTermsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns details about all terms documents for the requested user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listTerms: API.OperationMethod<ListTermsRequest, ListTermsResponse, ListTermsError, Credentials | HttpClient.HttpClient>;
export type ListUserImportJobsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns user import jobs and their details. Import jobs are
 * retained in user pool configuration so that you can stage, stop, start, review, and
 * delete them. For more information about user import, see Importing users from a CSV file.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserImportJobs: API.OperationMethod<ListUserImportJobsRequest, ListUserImportJobsResponse, ListUserImportJobsError, Credentials | HttpClient.HttpClient>;
export type ListUserPoolClientsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, lists app clients. App clients are sets of rules for the access
 * that you want a user pool to grant to one application. For more information, see App clients.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserPoolClients: API.PaginatedOperationMethod<ListUserPoolClientsRequest, ListUserPoolClientsResponse, ListUserPoolClientsError, Credentials | HttpClient.HttpClient, UserPoolClientDescription>;
export type ListUserPoolClientSecretsError = InternalServerException | InvalidParameterException | LimitExceededException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists all client secrets associated with a user pool app client. Returns metadata about the secrets. The response does not include pagination tokens as there are only 2 secrets at any given time and we return both with every ListUserPoolClientSecrets call. For security reasons, the response never reveals the actual secret value in ClientSecretValue.
 */
export declare const listUserPoolClientSecrets: API.OperationMethod<ListUserPoolClientSecretsRequest, ListUserPoolClientSecretsResponse, ListUserPoolClientSecretsError, Credentials | HttpClient.HttpClient>;
export type ListUserPoolReplicasError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Lists all replicas for a user pool, including both primary and secondary replicas. We
 * recommend using pagination to ensure that the operation returns quickly and
 * successfully.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserPoolReplicas: API.OperationMethod<ListUserPoolReplicasRequest, ListUserPoolReplicasResponse, ListUserPoolReplicasError, Credentials | HttpClient.HttpClient>;
export type ListUserPoolsError = InternalErrorException | InvalidParameterException | NotAuthorizedException | TooManyRequestsException | CommonErrors;
/**
 * Lists user pools and their details in the current Amazon Web Services account.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUserPools: API.PaginatedOperationMethod<ListUserPoolsRequest, ListUserPoolsResponse, ListUserPoolsError, Credentials | HttpClient.HttpClient, UserPoolDescriptionType>;
export type ListUsersError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID, returns a list of users and their basic details in a user
 * pool.
 *
 * This operation is eventually consistent. You might experience a delay before results
 * are up-to-date. To validate the existence or configuration of an individual user, use
 * `AdminGetUser`.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, UserType>;
export type ListUsersInGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool ID and a group name, returns a list of users in the group. For more
 * information about user pool groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const listUsersInGroup: API.PaginatedOperationMethod<ListUsersInGroupRequest, ListUsersInGroupResponse, ListUsersInGroupError, Credentials | HttpClient.HttpClient, UserType>;
export type ListWebAuthnCredentialsError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | TooManyRequestsException | CommonErrors;
/**
 * Generates a list of the currently signed-in user's registered passkey, or
 * WebAuthn, credentials.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const listWebAuthnCredentials: API.OperationMethod<ListWebAuthnCredentialsRequest, ListWebAuthnCredentialsResponse, ListWebAuthnCredentialsError, Credentials | HttpClient.HttpClient>;
export type ResendConfirmationCodeError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotFoundException | CommonErrors;
/**
 * Resends the code that confirms a new account for a user who has signed up in your user
 * pool. Amazon Cognito sends confirmation codes to the user attribute in the
 * `AutoVerifiedAttributes` property of your user pool. When you prompt new
 * users for the confirmation code, include a "Resend code" option that generates a call to
 * this API operation.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const resendConfirmationCode: API.OperationMethod<ResendConfirmationCodeRequest, ResendConfirmationCodeResponse, ResendConfirmationCodeError, Credentials | HttpClient.HttpClient>;
export type RespondToAuthChallengeError = AliasExistsException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | InvalidUserPoolConfigurationException | MFAMethodNotFoundException | NotAuthorizedException | OperationNotEnabledException | PasswordHistoryPolicyViolationException | PasswordResetRequiredException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Some API operations in a user pool generate a challenge, like a prompt for an MFA
 * code, for device authentication that bypasses MFA, or for a custom authentication
 * challenge. A `RespondToAuthChallenge` API request provides the answer to that
 * challenge, like a code or a secure remote password (SRP). The parameters of a response
 * to an authentication challenge vary with the type of challenge.
 *
 * For more information about custom authentication challenges, see Custom
 * authentication challenge Lambda triggers.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const respondToAuthChallenge: API.OperationMethod<RespondToAuthChallengeRequest, RespondToAuthChallengeResponse, RespondToAuthChallengeError, Credentials | HttpClient.HttpClient>;
export type RevokeTokenError = ForbiddenException | InternalErrorException | InvalidParameterException | OperationNotEnabledException | TooManyRequestsException | UnauthorizedException | UnsupportedOperationException | UnsupportedTokenTypeException | CommonErrors;
/**
 * Revokes all of the access tokens generated by, and at the same time as, the specified
 * refresh token. After a token is revoked, you can't use the revoked token to access Amazon Cognito
 * user APIs, or to authorize access to your resource server.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const revokeToken: API.OperationMethod<RevokeTokenRequest, RevokeTokenResponse, RevokeTokenError, Credentials | HttpClient.HttpClient>;
export type SetLogDeliveryConfigurationError = FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets up or modifies the logging configuration of a user pool. User pools can export
 * user notification logs and, when threat protection is active, user-activity logs. For
 * more information, see Exporting user
 * pool logs.
 */
export declare const setLogDeliveryConfiguration: API.OperationMethod<SetLogDeliveryConfigurationRequest, SetLogDeliveryConfigurationResponse, SetLogDeliveryConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetRiskConfigurationError = CodeDeliveryFailureException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Configures threat protection for a user pool or app client. Sets configuration for the
 * following.
 *
 * - Responses to risks with adaptive authentication
 *
 * - Responses to vulnerable passwords with compromised-credentials
 * detection
 *
 * - Notifications to users who have had risky activity detected
 *
 * - IP-address denylist and allowlist
 *
 * To set the risk configuration for the user pool to defaults, send this request with
 * only the `UserPoolId` parameter. To reset the threat protection settings of
 * an app client to be inherited from the user pool, send `UserPoolId` and
 * `ClientId` parameters only. To change threat protection to audit-only or
 * off, update the value of `UserPoolAddOns` in an `UpdateUserPool`
 * request. To activate this setting, your user pool must be on the
 * Plus tier.
 *
 * In secondary regions for user pools with multi-region replication, only the
 * `SourceARN` and `From` attributes of
 * `NotifyConfiguration` can be modified to configure region-specific SES
 * integration. All other risk configuration settings must match the existing values to
 * maintain consistency across replicas.
 */
export declare const setRiskConfiguration: API.OperationMethod<SetRiskConfigurationRequest, SetRiskConfigurationResponse, SetRiskConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetUICustomizationError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Configures UI branding settings for domains with the hosted UI (classic) branding
 * version. Your user pool must have a domain. Configure a domain with .
 *
 * Set the default configuration for all clients with a `ClientId` of
 * `ALL`. When the `ClientId` value is an app client ID, the
 * settings you pass in this request apply to that app client and override the default
 * `ALL` configuration.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const setUICustomization: API.OperationMethod<SetUICustomizationRequest, SetUICustomizationResponse, SetUICustomizationError, Credentials | HttpClient.HttpClient>;
export type SetUserMFAPreferenceError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Set the user's multi-factor authentication (MFA) method preference, including which
 * MFA factors are activated and if any are preferred. Only one factor can be set as
 * preferred. The preferred MFA factor will be used to authenticate a user if multiple
 * factors are activated. If multiple options are activated and no preference is set, a
 * challenge to choose an MFA option will be returned during sign-in. If an MFA type is
 * activated for a user, the user will be prompted for MFA during all sign-in attempts
 * unless device tracking is turned on and the device has been trusted. If you want MFA to
 * be applied selectively based on the assessed risk level of sign-in attempts, deactivate
 * MFA for users and turn on Adaptive Authentication for the user pool.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const setUserMFAPreference: API.OperationMethod<SetUserMFAPreferenceRequest, SetUserMFAPreferenceResponse, SetUserMFAPreferenceError, Credentials | HttpClient.HttpClient>;
export type SetUserPoolMfaConfigError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Sets user pool multi-factor authentication (MFA) and passkey configuration. For more
 * information about user pool MFA, see Adding MFA. For more information about WebAuthn passkeys see Authentication flows.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const setUserPoolMfaConfig: API.OperationMethod<SetUserPoolMfaConfigRequest, SetUserPoolMfaConfigResponse, SetUserPoolMfaConfigError, Credentials | HttpClient.HttpClient>;
export type SetUserSettingsError = ForbiddenException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * *This action is no longer supported.* You can use it to configure
 * only SMS MFA. You can't use it to configure time-based one-time password (TOTP) software
 * token or email MFA.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const setUserSettings: API.OperationMethod<SetUserSettingsRequest, SetUserSettingsResponse, SetUserSettingsError, Credentials | HttpClient.HttpClient>;
export type SignUpError = CodeDeliveryFailureException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidPasswordException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UsernameExistsException | CommonErrors;
/**
 * Registers a user with an app client and requests a user name, password, and user
 * attributes in the user pool.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * You might receive a `LimitExceeded` exception in response to this request
 * if you have exceeded a rate quota for email or SMS messages, and if your user pool
 * automatically verifies email addresses or phone numbers. When you get this exception in
 * the response, the user is successfully created and is in an `UNCONFIRMED`
 * state.
 */
export declare const signUp: API.OperationMethod<SignUpRequest, SignUpResponse, SignUpError, Credentials | HttpClient.HttpClient>;
export type StartUserImportJobError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Instructs your user pool to start importing users from a CSV file that contains their
 * usernames and attributes. For more information about importing users from a CSV file,
 * see Importing users from a CSV file.
 */
export declare const startUserImportJob: API.OperationMethod<StartUserImportJobRequest, StartUserImportJobResponse, StartUserImportJobError, Credentials | HttpClient.HttpClient>;
export type StartWebAuthnRegistrationError = ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | TooManyRequestsException | WebAuthnConfigurationMissingException | WebAuthnNotEnabledException | CommonErrors;
/**
 * Requests credential creation options from your user pool for the currently signed-in
 * user. Returns information about the user pool, the user profile, and authentication
 * requirements. Users must provide this information in their request to enroll your
 * application with their passkey provider.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 */
export declare const startWebAuthnRegistration: API.OperationMethod<StartWebAuthnRegistrationRequest, StartWebAuthnRegistrationResponse, StartWebAuthnRegistrationError, Credentials | HttpClient.HttpClient>;
export type StopUserImportJobError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | PreconditionNotMetException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Instructs your user pool to stop a running job that's importing users from a CSV
 * file that contains their usernames and attributes. For more information about importing
 * users from a CSV file, see Importing users from a CSV file.
 */
export declare const stopUserImportJob: API.OperationMethod<StopUserImportJobRequest, StopUserImportJobResponse, StopUserImportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Assigns a set of tags to an Amazon Cognito user pool. A tag is a label that you can use to
 * categorize and manage user pools in different ways, such as by purpose, owner,
 * environment, or other criteria.
 *
 * Each tag consists of a key and value, both of which you define. A key is a general
 * category for more specific values. For example, if you have two versions of a user pool,
 * one for testing and another for production, you might assign an `Environment`
 * tag key to both user pools. The value of this key might be `Test` for one
 * user pool, and `Production` for the other.
 *
 * Tags are useful for cost tracking and access control. You can activate your tags so
 * that they appear on the Billing and Cost Management console, where you can track the
 * costs associated with your user pools. In an Identity and Access Management policy, you can constrain
 * permissions for user pools based on specific tags or tag values.
 *
 * You can use this action up to 5 times per second, per account. A user pool can have as
 * many as 50 tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given tag IDs that you previously assigned to a user pool, removes them.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAuthEventFeedbackError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | UserNotFoundException | UserPoolAddOnNotEnabledException | CommonErrors;
/**
 * Provides the feedback for an authentication event generated by threat protection
 * features. The user's response indicates that you think that the event either was from a
 * valid user or was an unwanted authentication attempt. This feedback improves the risk
 * evaluation decision for the user pool as part of Amazon Cognito threat protection.
 * To activate this setting, your user pool must be on the
 * Plus tier.
 *
 * This operation requires a `FeedbackToken` that Amazon Cognito generates and adds to
 * notification emails when users have potentially suspicious authentication events. Users
 * invoke this operation when they select the link that corresponds to
 * `{one-click-link-valid}` or `{one-click-link-invalid}` in your
 * notification template. Because `FeedbackToken` is a required parameter, you
 * can't make requests to `UpdateAuthEventFeedback` without the contents of
 * the notification email message.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const updateAuthEventFeedback: API.OperationMethod<UpdateAuthEventFeedbackRequest, UpdateAuthEventFeedbackResponse, UpdateAuthEventFeedbackError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceStatusError = ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Updates the status of a the currently signed-in user's device so that it is
 * marked as remembered or not remembered for the purpose of device authentication. Device
 * authentication is a "remember me" mechanism that silently completes sign-in from trusted
 * devices with a device key instead of a user-provided MFA code. This operation changes
 * the status of a device without deleting it, so you can enable it again later. For more
 * information about device authentication, see Working with devices.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const updateDeviceStatus: API.OperationMethod<UpdateDeviceStatusRequest, UpdateDeviceStatusResponse, UpdateDeviceStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Given the name of a user pool group, updates any of the properties for precedence,
 * IAM role, or description. For more information about user pool groups, see Adding groups to a user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentityProviderError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | TooManyRequestsException | UnsupportedIdentityProviderException | CommonErrors;
/**
 * Modifies the configuration and trust relationship between a third-party identity
 * provider (IdP) and a user pool. Amazon Cognito accepts sign-in with third-party identity
 * providers through managed login and OIDC relying-party libraries. For more information,
 * see Third-party IdP sign-in.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateIdentityProvider: API.OperationMethod<UpdateIdentityProviderRequest, UpdateIdentityProviderResponse, UpdateIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateManagedLoginBrandingError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Configures the branding settings for a user pool style. This operation is the
 * programmatic option for the configuration of a style in the branding editor.
 *
 * Provides values for UI customization in a `Settings` JSON object and image
 * files in an `Assets` array.
 *
 * This operation has a 2-megabyte request-size limit and include the CSS settings and
 * image assets for your app client. Your branding settings might exceed 2MB in size. Amazon Cognito
 * doesn't require that you pass all parameters in one request and preserves existing
 * style settings that you don't specify. If your request is larger than 2MB, separate it
 * into multiple requests, each with a size smaller than the limit.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateManagedLoginBranding: API.OperationMethod<UpdateManagedLoginBrandingRequest, UpdateManagedLoginBrandingResponse, UpdateManagedLoginBrandingError, Credentials | HttpClient.HttpClient>;
export type UpdateProvisionedLimitError = InternalErrorException | InvalidParameterException | NotAuthorizedException | ResourceNotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Sets the provisioned limit for a specific API category. The value must be between the
 * default limit and your account-level maximum limit in Service Quotas.
 *
 * Managed login user pools don't support adjustments to the
 * `UserAuthentication` or `UserFederation` categories. To
 * increase these limits, submit a Service Quotas increase request.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateProvisionedLimit: API.OperationMethod<UpdateProvisionedLimitRequest, UpdateProvisionedLimitResponse, UpdateProvisionedLimitError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceServerError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates the name and scopes of a resource server. All other fields are read-only. For
 * more information about resource servers, see Access control with resource servers.
 *
 * If you don't provide a value for an attribute, it is set to the default
 * value.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateResourceServer: API.OperationMethod<UpdateResourceServerRequest, UpdateResourceServerResponse, UpdateResourceServerError, Credentials | HttpClient.HttpClient>;
export type UpdateTermsError = ConcurrentModificationException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TermsExistsException | TooManyRequestsException | CommonErrors;
/**
 * Modifies existing terms documents for the requested app client. When Terms and
 * conditions and Privacy policy documents are configured, the app client displays links to
 * them in the sign-up page of managed login for the app client.
 *
 * You can provide URLs for terms documents in the languages that are supported by managed login localization. Amazon Cognito directs users to the terms documents for
 * their current language, with fallback to `default` if no document exists for
 * the language.
 *
 * Each request accepts one type of terms document and a map of language-to-link for that
 * document type. You must provide both types of terms documents in at least one language
 * before Amazon Cognito displays your terms documents. Supply each type in separate
 * requests.
 *
 * For more information, see Terms documents.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateTerms: API.OperationMethod<UpdateTermsRequest, UpdateTermsResponse, UpdateTermsError, Credentials | HttpClient.HttpClient>;
export type UpdateUserAttributesError = AliasExistsException | CodeDeliveryFailureException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidLambdaResponseException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UnexpectedLambdaException | UserLambdaValidationException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Updates the currently signed-in user's attributes. To delete an attribute from
 * the user, submit the attribute in your API request with a blank value.
 *
 * For custom attributes, you must add a `custom:` prefix to the attribute
 * name, for example `custom:department`.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 */
export declare const updateUserAttributes: API.OperationMethod<UpdateUserAttributesRequest, UpdateUserAttributesResponse, UpdateUserAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidEmailRoleAccessPolicyException | InvalidParameterException | InvalidSmsRoleAccessPolicyException | InvalidSmsRoleTrustRelationshipException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TierChangeNotAllowedException | TooManyRequestsException | UserImportInProgressException | UserPoolTaggingException | CommonErrors;
/**
 * Updates the configuration of a user pool. To avoid setting parameters to Amazon Cognito
 * defaults, construct this API request to pass the existing configuration of your user
 * pool, modified to include the changes that you want to make.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * In secondary regions for user pools with multi-region replication, regional
 * configurations for email, SMS, Lambda functions, and tags can be updated. Both global
 * and regional settings must be provided as inputs, with global settings required to match
 * existing values to maintain consistency across replicas.
 *
 * This action might generate an SMS text message. Starting June 1, 2021, US telecom carriers
 * require you to register an origination phone number before you can send SMS messages
 * to US phone numbers. If you use SMS text messages in Amazon Cognito, you must register a
 * phone number with Amazon Pinpoint.
 * Amazon Cognito uses the registered number automatically. Otherwise, Amazon Cognito users who must
 * receive SMS messages might not be able to sign up, activate their accounts, or sign
 * in.
 *
 * If you have never used SMS text messages with Amazon Cognito or any other Amazon Web Services service,
 * Amazon Simple Notification Service might place your account in the SMS sandbox. In
 * sandbox
 * mode
 * , you can send messages only to verified phone
 * numbers. After you test your app while in the sandbox environment, you can move out
 * of the sandbox and into production. For more information, see SMS message settings for Amazon Cognito user pools in the Amazon Cognito
 * Developer Guide.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPool: API.OperationMethod<UpdateUserPoolRequest, UpdateUserPoolResponse, UpdateUserPoolError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolClientError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidOAuthFlowException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | ScopeDoesNotExistException | TooManyRequestsException | CommonErrors;
/**
 * Given a user pool app client ID, updates the configuration. To avoid setting
 * parameters to Amazon Cognito defaults, construct this API request to pass the existing
 * configuration of your app client, modified to include the changes that you want to
 * make.
 *
 * If you don't provide a value for an attribute, Amazon Cognito sets it to its default value.
 *
 * Unlike app clients created in the console, Amazon Cognito doesn't automatically assign a
 * branding style to app clients that you configure with this API operation. Managed login and classic hosted UI pages aren't
 * available for your client until after you apply a branding style.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPoolClient: API.OperationMethod<UpdateUserPoolClientRequest, UpdateUserPoolClientResponse, UpdateUserPoolClientError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolDomainError = ConcurrentModificationException | FeatureUnavailableInTierException | InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * A user pool domain hosts managed login, an authorization server and web server for
 * authentication in your application. This operation updates the branding version for user
 * pool domains between `1` for hosted UI (classic) and `2` for
 * managed login. It also updates the SSL certificate for user pool custom domains.
 *
 * Changes to the domain branding version take up to one minute to take effect for a
 * prefix domain and up to five minutes for a custom domain.
 *
 * This operation doesn't change the name of your user pool domain. To change your
 * domain, delete it with `DeleteUserPoolDomain` and create a new domain with
 * `CreateUserPoolDomain`.
 *
 * You can pass the ARN of a new Certificate Manager certificate in this request. Typically, ACM
 * certificates automatically renew and you user pool can continue to use the same ARN. But
 * if you generate a new certificate for your custom domain name, replace the original
 * configuration with the new ARN in this request.
 *
 * ACM certificates for custom domains must be in the US East (N. Virginia)
 * Amazon Web Services Region. After you submit your request, Amazon Cognito requires up to 1 hour to distribute
 * your new certificate to your custom domain.
 *
 * For more information about adding a custom domain to your user pool, see Configuring a user pool domain.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPoolDomain: API.OperationMethod<UpdateUserPoolDomainRequest, UpdateUserPoolDomainResponse, UpdateUserPoolDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateUserPoolReplicaError = InternalErrorException | InvalidParameterException | NotAuthorizedException | OperationNotEnabledException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Updates replica-specific settings for a user pool replica. You can modify the status
 * to activate or deactivate the replica. This request can be made in both primary and secondary
 * regions of the user pool.
 *
 * Amazon Cognito evaluates Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you must use IAM credentials to authorize requests, and you must
 * grant yourself the corresponding IAM permission in a policy.
 *
 * **Learn more**
 *
 * - Signing Amazon Web Services API Requests
 *
 * - Using the Amazon Cognito user pools API and user pool endpoints
 */
export declare const updateUserPoolReplica: API.OperationMethod<UpdateUserPoolReplicaRequest, UpdateUserPoolReplicaResponse, UpdateUserPoolReplicaError, Credentials | HttpClient.HttpClient>;
export type VerifySoftwareTokenError = CodeMismatchException | EnableSoftwareTokenMFAException | ForbiddenException | InternalErrorException | InvalidParameterException | InvalidUserPoolConfigurationException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | SoftwareTokenMFANotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Registers the current user's time-based one-time password (TOTP) authenticator
 * with a code generated in their authenticator app from a private key that's supplied
 * by your user pool. Marks the user's software token MFA status as "verified" if
 * successful. The request takes an access token or a session string, but not both.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const verifySoftwareToken: API.OperationMethod<VerifySoftwareTokenRequest, VerifySoftwareTokenResponse, VerifySoftwareTokenError, Credentials | HttpClient.HttpClient>;
export type VerifyUserAttributeError = AliasExistsException | CodeMismatchException | ExpiredCodeException | ForbiddenException | InternalErrorException | InvalidParameterException | LimitExceededException | NotAuthorizedException | OperationNotEnabledException | PasswordResetRequiredException | ResourceNotFoundException | TooManyRequestsException | UserNotConfirmedException | UserNotFoundException | CommonErrors;
/**
 * Submits a verification code for a signed-in user who has added or changed a value of
 * an auto-verified attribute. When successful, the user's attribute becomes verified
 * and the attribute `email_verified` or `phone_number_verified`
 * becomes `true`.
 *
 * If your user pool requires verification before Amazon Cognito updates the attribute value,
 * this operation updates the affected attribute to its pending value.
 *
 * Authorize this action with a signed-in user's access token. It must include the scope `aws.cognito.signin.user.admin`.
 *
 * Amazon Cognito doesn't evaluate Identity and Access Management (IAM) policies in requests for this API operation. For
 * this operation, you can't use IAM credentials to authorize requests, and you can't
 * grant IAM permissions in policies. For more information about authorization models in
 * Amazon Cognito, see Using the Amazon Cognito user pools API and user pool endpoints.
 */
export declare const verifyUserAttribute: API.OperationMethod<VerifyUserAttributeRequest, VerifyUserAttributeResponse, VerifyUserAttributeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cognito-identity-provider.d.ts.map