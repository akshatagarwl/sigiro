import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly ErrorCode: any;
    readonly ErrorCodeReason: any;
    readonly SubErrorCode: any;
    readonly SubErrorCodeReason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Resources: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly ErrorCode: any;
    readonly ErrorCodeReason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GraphArn = string;
export interface AcceptInvitationRequest {
    GraphArn: string;
}
export declare const AcceptInvitationRequest: S.Schema<AcceptInvitationRequest>;
export interface AcceptInvitationResponse {
}
export declare const AcceptInvitationResponse: S.Schema<AcceptInvitationResponse>;
export type AccountId = string;
export type AccountIdExtendedList = string[];
export declare const AccountIdExtendedList: any;
export interface BatchGetGraphMemberDatasourcesRequest {
    GraphArn: string;
    AccountIds: string[];
}
export declare const BatchGetGraphMemberDatasourcesRequest: S.Schema<BatchGetGraphMemberDatasourcesRequest>;
export type DatasourcePackage = "DETECTIVE_CORE" | "EKS_AUDIT" | "ASFF_SECURITYHUB_FINDING" | (string & {});
export declare const DatasourcePackage: any;
export type DatasourcePackageIngestState = "STARTED" | "STOPPED" | "DISABLED" | (string & {});
export declare const DatasourcePackageIngestState: any;
export interface TimestampForCollection {
    Timestamp?: Date;
}
export declare const TimestampForCollection: S.Schema<TimestampForCollection>;
export type LastIngestStateChangeDates = {
    [key in DatasourcePackageIngestState]?: TimestampForCollection;
};
export declare const LastIngestStateChangeDates: any;
export type DatasourcePackageIngestHistory = {
    [key in DatasourcePackage]?: {
        [key: string]: TimestampForCollection | undefined;
    };
};
export declare const DatasourcePackageIngestHistory: any;
export interface MembershipDatasources {
    AccountId?: string;
    GraphArn?: string;
    DatasourcePackageIngestHistory?: {
        [key: string]: {
            [key: string]: TimestampForCollection | undefined;
        } | undefined;
    };
}
export declare const MembershipDatasources: S.Schema<MembershipDatasources>;
export type MembershipDatasourcesList = MembershipDatasources[];
export declare const MembershipDatasourcesList: any;
export type UnprocessedReason = string;
export interface UnprocessedAccount {
    AccountId?: string;
    Reason?: string;
}
export declare const UnprocessedAccount: S.Schema<UnprocessedAccount>;
export type UnprocessedAccountList = UnprocessedAccount[];
export declare const UnprocessedAccountList: any;
export interface BatchGetGraphMemberDatasourcesResponse {
    MemberDatasources?: MembershipDatasources[];
    UnprocessedAccounts?: UnprocessedAccount[];
}
export declare const BatchGetGraphMemberDatasourcesResponse: S.Schema<BatchGetGraphMemberDatasourcesResponse>;
export type GraphArnList = string[];
export declare const GraphArnList: any;
export interface BatchGetMembershipDatasourcesRequest {
    GraphArns: string[];
}
export declare const BatchGetMembershipDatasourcesRequest: S.Schema<BatchGetMembershipDatasourcesRequest>;
export interface UnprocessedGraph {
    GraphArn?: string;
    Reason?: string;
}
export declare const UnprocessedGraph: S.Schema<UnprocessedGraph>;
export type UnprocessedGraphList = UnprocessedGraph[];
export declare const UnprocessedGraphList: any;
export interface BatchGetMembershipDatasourcesResponse {
    MembershipDatasources?: MembershipDatasources[];
    UnprocessedGraphs?: UnprocessedGraph[];
}
export declare const BatchGetMembershipDatasourcesResponse: S.Schema<BatchGetMembershipDatasourcesResponse>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateGraphRequest {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateGraphRequest: S.Schema<CreateGraphRequest>;
export interface CreateGraphResponse {
    GraphArn?: string;
}
export declare const CreateGraphResponse: S.Schema<CreateGraphResponse>;
export type EmailMessage = string | redacted.Redacted<string>;
export type EmailAddress = string | redacted.Redacted<string>;
export interface Account {
    AccountId: string;
    EmailAddress: string | redacted.Redacted<string>;
}
export declare const Account: S.Schema<Account>;
export type AccountList = Account[];
export declare const AccountList: any;
export interface CreateMembersRequest {
    GraphArn: string;
    Message?: string | redacted.Redacted<string>;
    DisableEmailNotification?: boolean;
    Accounts: Account[];
}
export declare const CreateMembersRequest: S.Schema<CreateMembersRequest>;
export type MemberStatus = "INVITED" | "VERIFICATION_IN_PROGRESS" | "VERIFICATION_FAILED" | "ENABLED" | "ACCEPTED_BUT_DISABLED" | (string & {});
export declare const MemberStatus: any;
export type MemberDisabledReason = "VOLUME_TOO_HIGH" | "VOLUME_UNKNOWN" | (string & {});
export declare const MemberDisabledReason: any;
export type ByteValue = number;
export type Percentage = number;
export type InvitationType = "INVITATION" | "ORGANIZATION" | (string & {});
export declare const InvitationType: any;
export interface DatasourcePackageUsageInfo {
    VolumeUsageInBytes?: number;
    VolumeUsageUpdateTime?: Date;
}
export declare const DatasourcePackageUsageInfo: S.Schema<DatasourcePackageUsageInfo>;
export type VolumeUsageByDatasourcePackage = {
    [key in DatasourcePackage]?: DatasourcePackageUsageInfo;
};
export declare const VolumeUsageByDatasourcePackage: any;
export type DatasourcePackageIngestStates = {
    [key in DatasourcePackage]?: DatasourcePackageIngestState;
};
export declare const DatasourcePackageIngestStates: any;
export interface MemberDetail {
    AccountId?: string;
    EmailAddress?: string | redacted.Redacted<string>;
    GraphArn?: string;
    MasterId?: string;
    AdministratorId?: string;
    Status?: MemberStatus;
    DisabledReason?: MemberDisabledReason;
    InvitedTime?: Date;
    UpdatedTime?: Date;
    VolumeUsageInBytes?: number;
    VolumeUsageUpdatedTime?: Date;
    PercentOfGraphUtilization?: number;
    PercentOfGraphUtilizationUpdatedTime?: Date;
    InvitationType?: InvitationType;
    VolumeUsageByDatasourcePackage?: {
        [key: string]: DatasourcePackageUsageInfo | undefined;
    };
    DatasourcePackageIngestStates?: {
        [key: string]: DatasourcePackageIngestState | undefined;
    };
}
export declare const MemberDetail: S.Schema<MemberDetail>;
export type MemberDetailList = MemberDetail[];
export declare const MemberDetailList: any;
export interface CreateMembersResponse {
    Members?: MemberDetail[];
    UnprocessedAccounts?: UnprocessedAccount[];
}
export declare const CreateMembersResponse: S.Schema<CreateMembersResponse>;
export interface DeleteGraphRequest {
    GraphArn: string;
}
export declare const DeleteGraphRequest: S.Schema<DeleteGraphRequest>;
export interface DeleteGraphResponse {
}
export declare const DeleteGraphResponse: S.Schema<DeleteGraphResponse>;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export interface DeleteMembersRequest {
    GraphArn: string;
    AccountIds: string[];
}
export declare const DeleteMembersRequest: S.Schema<DeleteMembersRequest>;
export interface DeleteMembersResponse {
    AccountIds?: string[];
    UnprocessedAccounts?: UnprocessedAccount[];
}
export declare const DeleteMembersResponse: S.Schema<DeleteMembersResponse>;
export interface DescribeOrganizationConfigurationRequest {
    GraphArn: string;
}
export declare const DescribeOrganizationConfigurationRequest: S.Schema<DescribeOrganizationConfigurationRequest>;
export interface DescribeOrganizationConfigurationResponse {
    AutoEnable?: boolean;
}
export declare const DescribeOrganizationConfigurationResponse: S.Schema<DescribeOrganizationConfigurationResponse>;
export interface DisableOrganizationAdminAccountRequest {
}
export declare const DisableOrganizationAdminAccountRequest: S.Schema<DisableOrganizationAdminAccountRequest>;
export interface DisableOrganizationAdminAccountResponse {
}
export declare const DisableOrganizationAdminAccountResponse: S.Schema<DisableOrganizationAdminAccountResponse>;
export interface DisassociateMembershipRequest {
    GraphArn: string;
}
export declare const DisassociateMembershipRequest: S.Schema<DisassociateMembershipRequest>;
export interface DisassociateMembershipResponse {
}
export declare const DisassociateMembershipResponse: S.Schema<DisassociateMembershipResponse>;
export interface EnableOrganizationAdminAccountRequest {
    AccountId: string;
}
export declare const EnableOrganizationAdminAccountRequest: S.Schema<EnableOrganizationAdminAccountRequest>;
export interface EnableOrganizationAdminAccountResponse {
}
export declare const EnableOrganizationAdminAccountResponse: S.Schema<EnableOrganizationAdminAccountResponse>;
export type InvestigationId = string;
export interface GetInvestigationRequest {
    GraphArn: string;
    InvestigationId: string;
}
export declare const GetInvestigationRequest: S.Schema<GetInvestigationRequest>;
export type EntityArn = string;
export type EntityType = "IAM_ROLE" | "IAM_USER" | (string & {});
export declare const EntityType: any;
export type Status = "RUNNING" | "FAILED" | "SUCCESSFUL" | (string & {});
export declare const Status: any;
export type Severity = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export declare const Severity: any;
export type State = "ACTIVE" | "ARCHIVED" | (string & {});
export declare const State: any;
export interface GetInvestigationResponse {
    GraphArn?: string;
    InvestigationId?: string;
    EntityArn?: string;
    EntityType?: EntityType;
    CreatedTime?: Date;
    ScopeStartTime?: Date;
    ScopeEndTime?: Date;
    Status?: Status;
    Severity?: Severity;
    State?: State;
}
export declare const GetInvestigationResponse: S.Schema<GetInvestigationResponse>;
export interface GetMembersRequest {
    GraphArn: string;
    AccountIds: string[];
}
export declare const GetMembersRequest: S.Schema<GetMembersRequest>;
export interface GetMembersResponse {
    MemberDetails?: MemberDetail[];
    UnprocessedAccounts?: UnprocessedAccount[];
}
export declare const GetMembersResponse: S.Schema<GetMembersResponse>;
export type PaginationToken = string;
export type MemberResultsLimit = number;
export interface ListDatasourcePackagesRequest {
    GraphArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDatasourcePackagesRequest: S.Schema<ListDatasourcePackagesRequest>;
export interface DatasourcePackageIngestDetail {
    DatasourcePackageIngestState?: DatasourcePackageIngestState;
    LastIngestStateChange?: {
        [key: string]: TimestampForCollection | undefined;
    };
}
export declare const DatasourcePackageIngestDetail: S.Schema<DatasourcePackageIngestDetail>;
export type DatasourcePackageIngestDetails = {
    [key in DatasourcePackage]?: DatasourcePackageIngestDetail;
};
export declare const DatasourcePackageIngestDetails: any;
export interface ListDatasourcePackagesResponse {
    DatasourcePackages?: {
        [key: string]: DatasourcePackageIngestDetail | undefined;
    };
    NextToken?: string;
}
export declare const ListDatasourcePackagesResponse: S.Schema<ListDatasourcePackagesResponse>;
export interface ListGraphsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListGraphsRequest: S.Schema<ListGraphsRequest>;
export interface Graph {
    Arn?: string;
    CreatedTime?: Date;
}
export declare const Graph: S.Schema<Graph>;
export type GraphList = Graph[];
export declare const GraphList: any;
export interface ListGraphsResponse {
    GraphList?: Graph[];
    NextToken?: string;
}
export declare const ListGraphsResponse: S.Schema<ListGraphsResponse>;
export type IndicatorType = "TTP_OBSERVED" | "IMPOSSIBLE_TRAVEL" | "FLAGGED_IP_ADDRESS" | "NEW_GEOLOCATION" | "NEW_ASO" | "NEW_USER_AGENT" | "RELATED_FINDING" | "RELATED_FINDING_GROUP" | (string & {});
export declare const IndicatorType: any;
export type AiPaginationToken = string;
export type MaxResults = number;
export interface ListIndicatorsRequest {
    GraphArn: string;
    InvestigationId: string;
    IndicatorType?: IndicatorType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListIndicatorsRequest: S.Schema<ListIndicatorsRequest>;
export type Tactic = string;
export type Technique = string;
export type Procedure = string;
export type IpAddress = string;
export type APIName = string;
export type APISuccessCount = number;
export type APIFailureCount = number;
export interface TTPsObservedDetail {
    Tactic?: string;
    Technique?: string;
    Procedure?: string;
    IpAddress?: string;
    APIName?: string;
    APISuccessCount?: number;
    APIFailureCount?: number;
}
export declare const TTPsObservedDetail: S.Schema<TTPsObservedDetail>;
export type Location = string;
export type HourlyTimeDelta = number;
export interface ImpossibleTravelDetail {
    StartingIpAddress?: string;
    EndingIpAddress?: string;
    StartingLocation?: string;
    EndingLocation?: string;
    HourlyTimeDelta?: number;
}
export declare const ImpossibleTravelDetail: S.Schema<ImpossibleTravelDetail>;
export type Reason = "AWS_THREAT_INTELLIGENCE" | (string & {});
export declare const Reason: any;
export interface FlaggedIpAddressDetail {
    IpAddress?: string;
    Reason?: Reason;
}
export declare const FlaggedIpAddressDetail: S.Schema<FlaggedIpAddressDetail>;
export type IsNewForEntireAccount = boolean;
export interface NewGeolocationDetail {
    Location?: string;
    IpAddress?: string;
    IsNewForEntireAccount?: boolean;
}
export declare const NewGeolocationDetail: S.Schema<NewGeolocationDetail>;
export type Aso = string;
export interface NewAsoDetail {
    Aso?: string;
    IsNewForEntireAccount?: boolean;
}
export declare const NewAsoDetail: S.Schema<NewAsoDetail>;
export type UserAgent = string;
export interface NewUserAgentDetail {
    UserAgent?: string;
    IsNewForEntireAccount?: boolean;
}
export declare const NewUserAgentDetail: S.Schema<NewUserAgentDetail>;
export type Type = string;
export interface RelatedFindingDetail {
    Arn?: string;
    Type?: string;
    IpAddress?: string;
}
export declare const RelatedFindingDetail: S.Schema<RelatedFindingDetail>;
export type Id = string;
export interface RelatedFindingGroupDetail {
    Id?: string;
}
export declare const RelatedFindingGroupDetail: S.Schema<RelatedFindingGroupDetail>;
export interface IndicatorDetail {
    TTPsObservedDetail?: TTPsObservedDetail;
    ImpossibleTravelDetail?: ImpossibleTravelDetail;
    FlaggedIpAddressDetail?: FlaggedIpAddressDetail;
    NewGeolocationDetail?: NewGeolocationDetail;
    NewAsoDetail?: NewAsoDetail;
    NewUserAgentDetail?: NewUserAgentDetail;
    RelatedFindingDetail?: RelatedFindingDetail;
    RelatedFindingGroupDetail?: RelatedFindingGroupDetail;
}
export declare const IndicatorDetail: S.Schema<IndicatorDetail>;
export interface Indicator {
    IndicatorType?: IndicatorType;
    IndicatorDetail?: IndicatorDetail;
}
export declare const Indicator: S.Schema<Indicator>;
export type Indicators = Indicator[];
export declare const Indicators: any;
export interface ListIndicatorsResponse {
    GraphArn?: string;
    InvestigationId?: string;
    NextToken?: string;
    Indicators?: Indicator[];
}
export declare const ListIndicatorsResponse: S.Schema<ListIndicatorsResponse>;
export type Value = string;
export interface StringFilter {
    Value: string;
}
export declare const StringFilter: S.Schema<StringFilter>;
export interface DateFilter {
    StartInclusive: Date;
    EndInclusive: Date;
}
export declare const DateFilter: S.Schema<DateFilter>;
export interface FilterCriteria {
    Severity?: StringFilter;
    Status?: StringFilter;
    State?: StringFilter;
    EntityArn?: StringFilter;
    CreatedTime?: DateFilter;
}
export declare const FilterCriteria: S.Schema<FilterCriteria>;
export type Field = "SEVERITY" | "STATUS" | "CREATED_TIME" | (string & {});
export declare const Field: any;
export type SortOrder = "ASC" | "DESC" | (string & {});
export declare const SortOrder: any;
export interface SortCriteria {
    Field?: Field;
    SortOrder?: SortOrder;
}
export declare const SortCriteria: S.Schema<SortCriteria>;
export interface ListInvestigationsRequest {
    GraphArn: string;
    NextToken?: string;
    MaxResults?: number;
    FilterCriteria?: FilterCriteria;
    SortCriteria?: SortCriteria;
}
export declare const ListInvestigationsRequest: S.Schema<ListInvestigationsRequest>;
export interface InvestigationDetail {
    InvestigationId?: string;
    Severity?: Severity;
    Status?: Status;
    State?: State;
    CreatedTime?: Date;
    EntityArn?: string;
    EntityType?: EntityType;
}
export declare const InvestigationDetail: S.Schema<InvestigationDetail>;
export type InvestigationDetails = InvestigationDetail[];
export declare const InvestigationDetails: any;
export interface ListInvestigationsResponse {
    InvestigationDetails?: InvestigationDetail[];
    NextToken?: string;
}
export declare const ListInvestigationsResponse: S.Schema<ListInvestigationsResponse>;
export interface ListInvitationsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListInvitationsRequest: S.Schema<ListInvitationsRequest>;
export interface ListInvitationsResponse {
    Invitations?: MemberDetail[];
    NextToken?: string;
}
export declare const ListInvitationsResponse: S.Schema<ListInvitationsResponse>;
export interface ListMembersRequest {
    GraphArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListMembersRequest: S.Schema<ListMembersRequest>;
export interface ListMembersResponse {
    MemberDetails?: MemberDetail[];
    NextToken?: string;
}
export declare const ListMembersResponse: S.Schema<ListMembersResponse>;
export interface ListOrganizationAdminAccountsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListOrganizationAdminAccountsRequest: S.Schema<ListOrganizationAdminAccountsRequest>;
export interface Administrator {
    AccountId?: string;
    GraphArn?: string;
    DelegationTime?: Date;
}
export declare const Administrator: S.Schema<Administrator>;
export type AdministratorList = Administrator[];
export declare const AdministratorList: any;
export interface ListOrganizationAdminAccountsResponse {
    Administrators?: Administrator[];
    NextToken?: string;
}
export declare const ListOrganizationAdminAccountsResponse: S.Schema<ListOrganizationAdminAccountsResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface RejectInvitationRequest {
    GraphArn: string;
}
export declare const RejectInvitationRequest: S.Schema<RejectInvitationRequest>;
export interface RejectInvitationResponse {
}
export declare const RejectInvitationResponse: S.Schema<RejectInvitationResponse>;
export interface StartInvestigationRequest {
    GraphArn: string;
    EntityArn: string;
    ScopeStartTime: Date;
    ScopeEndTime: Date;
}
export declare const StartInvestigationRequest: S.Schema<StartInvestigationRequest>;
export interface StartInvestigationResponse {
    InvestigationId?: string;
}
export declare const StartInvestigationResponse: S.Schema<StartInvestigationResponse>;
export interface StartMonitoringMemberRequest {
    GraphArn: string;
    AccountId: string;
}
export declare const StartMonitoringMemberRequest: S.Schema<StartMonitoringMemberRequest>;
export interface StartMonitoringMemberResponse {
}
export declare const StartMonitoringMemberResponse: S.Schema<StartMonitoringMemberResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type DatasourcePackageList = DatasourcePackage[];
export declare const DatasourcePackageList: any;
export interface UpdateDatasourcePackagesRequest {
    GraphArn: string;
    DatasourcePackages: DatasourcePackage[];
}
export declare const UpdateDatasourcePackagesRequest: S.Schema<UpdateDatasourcePackagesRequest>;
export interface UpdateDatasourcePackagesResponse {
}
export declare const UpdateDatasourcePackagesResponse: S.Schema<UpdateDatasourcePackagesResponse>;
export interface UpdateInvestigationStateRequest {
    GraphArn: string;
    InvestigationId: string;
    State: State;
}
export declare const UpdateInvestigationStateRequest: S.Schema<UpdateInvestigationStateRequest>;
export interface UpdateInvestigationStateResponse {
}
export declare const UpdateInvestigationStateResponse: S.Schema<UpdateInvestigationStateResponse>;
export interface UpdateOrganizationConfigurationRequest {
    GraphArn: string;
    AutoEnable?: boolean;
}
export declare const UpdateOrganizationConfigurationRequest: S.Schema<UpdateOrganizationConfigurationRequest>;
export interface UpdateOrganizationConfigurationResponse {
}
export declare const UpdateOrganizationConfigurationResponse: S.Schema<UpdateOrganizationConfigurationResponse>;
export type ErrorMessage = string;
export type ErrorCode = "INVALID_GRAPH_ARN" | "INVALID_REQUEST_BODY" | "INTERNAL_ERROR" | (string & {});
export declare const ErrorCode: any;
export type ErrorCodeReason = string;
export type Resource = string;
export type ResourceList = string[];
export declare const ResourceList: any;
export type AcceptInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Accepts an invitation for the member account to contribute data to a behavior graph.
 * This operation can only be called by an invited member account.
 *
 * The request provides the ARN of behavior graph.
 *
 * The member account status in the graph must be `INVITED`.
 */
export declare const acceptInvitation: API.OperationMethod<AcceptInvitationRequest, AcceptInvitationResponse, AcceptInvitationError, Credentials | HttpClient.HttpClient>;
export type BatchGetGraphMemberDatasourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets data source package information for the behavior graph.
 */
export declare const batchGetGraphMemberDatasources: API.OperationMethod<BatchGetGraphMemberDatasourcesRequest, BatchGetGraphMemberDatasourcesResponse, BatchGetGraphMemberDatasourcesError, Credentials | HttpClient.HttpClient>;
export type BatchGetMembershipDatasourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information on the data source package history for an account.
 */
export declare const batchGetMembershipDatasources: API.OperationMethod<BatchGetMembershipDatasourcesRequest, BatchGetMembershipDatasourcesResponse, BatchGetMembershipDatasourcesError, Credentials | HttpClient.HttpClient>;
export type CreateGraphError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a new behavior graph for the calling account, and sets that account as the
 * administrator account. This operation is called by the account that is enabling Detective.
 *
 * The operation also enables Detective for the calling account in the currently
 * selected Region. It returns the ARN of the new behavior graph.
 *
 * `CreateGraph` triggers a process to create the corresponding data tables for
 * the new behavior graph.
 *
 * An account can only be the administrator account for one behavior graph within a Region.
 * If the same account calls `CreateGraph` with the same administrator account, it
 * always returns the same behavior graph ARN. It does not create a new behavior graph.
 */
export declare const createGraph: API.OperationMethod<CreateGraphRequest, CreateGraphResponse, CreateGraphError, Credentials | HttpClient.HttpClient>;
export type CreateMembersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * `CreateMembers` is used to send invitations to accounts. For the organization
 * behavior graph, the Detective administrator account uses
 * `CreateMembers` to enable organization accounts as member accounts.
 *
 * For invited accounts, `CreateMembers` sends a request to invite the specified
 * Amazon Web Services accounts to be member accounts in the behavior graph. This operation
 * can only be called by the administrator account for a behavior graph.
 *
 * `CreateMembers` verifies the accounts and then invites the verified accounts.
 * The administrator can optionally specify to not send invitation emails to the member
 * accounts. This would be used when the administrator manages their member accounts
 * centrally.
 *
 * For organization accounts in the organization behavior graph, `CreateMembers`
 * attempts to enable the accounts. The organization accounts do not receive
 * invitations.
 *
 * The request provides the behavior graph ARN and the list of accounts to invite or to
 * enable.
 *
 * The response separates the requested accounts into two lists:
 *
 * - The accounts that `CreateMembers` was able to process. For invited
 * accounts, includes member accounts that are being verified, that have passed
 * verification and are to be invited, and that have failed verification. For
 * organization accounts in the organization behavior graph, includes accounts that can
 * be enabled and that cannot be enabled.
 *
 * - The accounts that `CreateMembers` was unable to process. This list
 * includes accounts that were already invited to be member accounts in the behavior
 * graph.
 */
export declare const createMembers: API.OperationMethod<CreateMembersRequest, CreateMembersResponse, CreateMembersError, Credentials | HttpClient.HttpClient>;
export type DeleteGraphError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Disables the specified behavior graph and queues it to be deleted. This operation
 * removes the behavior graph from each member account's list of behavior graphs.
 *
 * `DeleteGraph` can only be called by the administrator account for a behavior
 * graph.
 */
export declare const deleteGraph: API.OperationMethod<DeleteGraphRequest, DeleteGraphResponse, DeleteGraphError, Credentials | HttpClient.HttpClient>;
export type DeleteMembersError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified member accounts from the behavior graph. The removed accounts no
 * longer contribute data to the behavior graph. This operation can only be called by the
 * administrator account for the behavior graph.
 *
 * For invited accounts, the removed accounts are deleted from the list of accounts in the
 * behavior graph. To restore the account, the administrator account must send another
 * invitation.
 *
 * For organization accounts in the organization behavior graph, the Detective
 * administrator account can always enable the organization account again. Organization
 * accounts that are not enabled as member accounts are not included in the
 * `ListMembers` results for the organization behavior graph.
 *
 * An administrator account cannot use `DeleteMembers` to remove their own
 * account from the behavior graph. To disable a behavior graph, the administrator account
 * uses the `DeleteGraph` API method.
 */
export declare const deleteMembers: API.OperationMethod<DeleteMembersRequest, DeleteMembersResponse, DeleteMembersError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationConfigurationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Returns information about the configuration for the organization behavior graph.
 * Currently indicates whether to automatically enable new organization accounts as member
 * accounts.
 *
 * Can only be called by the Detective administrator account for the organization.
 */
export declare const describeOrganizationConfiguration: API.OperationMethod<DescribeOrganizationConfigurationRequest, DescribeOrganizationConfigurationResponse, DescribeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationAdminAccountError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Removes the Detective administrator account in the current Region. Deletes the
 * organization behavior graph.
 *
 * Can only be called by the organization management account.
 *
 * Removing the Detective administrator account does not affect the delegated
 * administrator account for Detective in Organizations.
 *
 * To remove the delegated administrator account in Organizations, use the Organizations API. Removing the delegated administrator account also removes the Detective administrator account in all Regions, except for Regions where the Detective administrator account is the organization management account.
 */
export declare const disableOrganizationAdminAccount: API.OperationMethod<DisableOrganizationAdminAccountRequest, DisableOrganizationAdminAccountResponse, DisableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMembershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the member account from the specified behavior graph. This operation can only be
 * called by an invited member account that has the `ENABLED` status.
 *
 * `DisassociateMembership` cannot be called by an organization account in the
 * organization behavior graph. For the organization behavior graph, the Detective
 * administrator account determines which organization accounts to enable or disable as member
 * accounts.
 */
export declare const disassociateMembership: API.OperationMethod<DisassociateMembershipRequest, DisassociateMembershipResponse, DisassociateMembershipError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationAdminAccountError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Designates the Detective administrator account for the organization in the
 * current Region.
 *
 * If the account does not have Detective enabled, then enables Detective
 * for that account and creates a new behavior graph.
 *
 * Can only be called by the organization management account.
 *
 * If the organization has a delegated administrator account in Organizations, then the
 * Detective administrator account must be either the delegated administrator
 * account or the organization management account.
 *
 * If the organization does not have a delegated administrator account in Organizations, then you can choose any account in the organization. If you choose an account other
 * than the organization management account, Detective calls Organizations to
 * make that account the delegated administrator account for Detective. The
 * organization management account cannot be the delegated administrator account.
 */
export declare const enableOrganizationAdminAccount: API.OperationMethod<EnableOrganizationAdminAccountRequest, EnableOrganizationAdminAccountResponse, EnableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetInvestigationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Detective investigations lets you investigate IAM users and IAM roles using indicators of compromise. An indicator of compromise (IOC) is an artifact observed in or on a network, system, or environment that can (with a high level of confidence) identify malicious activity or a security incident. `GetInvestigation` returns the investigation results of an investigation for a behavior graph.
 */
export declare const getInvestigation: API.OperationMethod<GetInvestigationRequest, GetInvestigationResponse, GetInvestigationError, Credentials | HttpClient.HttpClient>;
export type GetMembersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the membership details for specified member accounts for a behavior
 * graph.
 */
export declare const getMembers: API.OperationMethod<GetMembersRequest, GetMembersResponse, GetMembersError, Credentials | HttpClient.HttpClient>;
export type ListDatasourcePackagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists data source packages in the behavior graph.
 */
export declare const listDatasourcePackages: API.PaginatedOperationMethod<ListDatasourcePackagesRequest, ListDatasourcePackagesResponse, ListDatasourcePackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGraphsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns the list of behavior graphs that the calling account is an administrator account
 * of. This operation can only be called by an administrator account.
 *
 * Because an account can currently only be the administrator of one behavior graph within
 * a Region, the results always contain a single behavior graph.
 */
export declare const listGraphs: API.PaginatedOperationMethod<ListGraphsRequest, ListGraphsResponse, ListGraphsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIndicatorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets the indicators from an investigation. You can use the information from the indicators to determine if an IAM user and/or IAM role is involved in an unusual activity that could indicate malicious behavior and its impact.
 */
export declare const listIndicators: API.OperationMethod<ListIndicatorsRequest, ListIndicatorsResponse, ListIndicatorsError, Credentials | HttpClient.HttpClient>;
export type ListInvestigationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Detective investigations lets you investigate IAM users and
 * IAM roles using indicators of compromise. An indicator of compromise
 * (IOC) is an artifact observed in or on a network, system, or environment that can (with a
 * high level of confidence) identify malicious activity or a security incident.
 * `ListInvestigations` lists all active Detective
 * investigations.
 */
export declare const listInvestigations: API.OperationMethod<ListInvestigationsRequest, ListInvestigationsResponse, ListInvestigationsError, Credentials | HttpClient.HttpClient>;
export type ListInvitationsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Retrieves the list of open and accepted behavior graph invitations for the member
 * account. This operation can only be called by an invited member account.
 *
 * Open invitations are invitations that the member account has not responded to.
 *
 * The results do not include behavior graphs for which the member account declined the
 * invitation. The results also do not include behavior graphs that the member account
 * resigned from or was removed from.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsRequest, ListInvitationsResponse, ListInvitationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMembersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the list of member accounts for a behavior graph.
 *
 * For invited accounts, the results do not include member accounts that were removed from
 * the behavior graph.
 *
 * For the organization behavior graph, the results do not include organization accounts
 * that the Detective administrator account has not enabled as member
 * accounts.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOrganizationAdminAccountsError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Returns information about the Detective administrator account for an
 * organization. Can only be called by the organization management account.
 */
export declare const listOrganizationAdminAccounts: API.PaginatedOperationMethod<ListOrganizationAdminAccountsRequest, ListOrganizationAdminAccountsResponse, ListOrganizationAdminAccountsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the tag values that are assigned to a behavior graph.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RejectInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Rejects an invitation to contribute the account data to a behavior graph. This operation
 * must be called by an invited member account that has the `INVITED`
 * status.
 *
 * `RejectInvitation` cannot be called by an organization account in the
 * organization behavior graph. In the organization behavior graph, organization accounts do
 * not receive an invitation.
 */
export declare const rejectInvitation: API.OperationMethod<RejectInvitationRequest, RejectInvitationResponse, RejectInvitationError, Credentials | HttpClient.HttpClient>;
export type StartInvestigationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Detective investigations lets you investigate IAM users and IAM roles using indicators of compromise. An indicator of compromise (IOC) is an artifact observed in or on a network, system, or environment that can (with a high level of confidence) identify malicious activity or a security incident. `StartInvestigation` initiates an investigation on an entity in a behavior graph.
 */
export declare const startInvestigation: API.OperationMethod<StartInvestigationRequest, StartInvestigationResponse, StartInvestigationError, Credentials | HttpClient.HttpClient>;
export type StartMonitoringMemberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Sends a request to enable data ingest for a member account that has a status of
 * `ACCEPTED_BUT_DISABLED`.
 *
 * For valid member accounts, the status is updated as follows.
 *
 * - If Detective enabled the member account, then the new status is
 * `ENABLED`.
 *
 * - If Detective cannot enable the member account, the status remains
 * `ACCEPTED_BUT_DISABLED`.
 */
export declare const startMonitoringMember: API.OperationMethod<StartMonitoringMemberRequest, StartMonitoringMemberResponse, StartMonitoringMemberError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Applies tag values to a behavior graph.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from a behavior graph.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasourcePackagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Starts a data source package for the Detective behavior graph.
 */
export declare const updateDatasourcePackages: API.OperationMethod<UpdateDatasourcePackagesRequest, UpdateDatasourcePackagesResponse, UpdateDatasourcePackagesError, Credentials | HttpClient.HttpClient>;
export type UpdateInvestigationStateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates the state of an investigation.
 */
export declare const updateInvestigationState: API.OperationMethod<UpdateInvestigationStateRequest, UpdateInvestigationStateResponse, UpdateInvestigationStateError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationConfigurationError = AccessDeniedException | InternalServerException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Updates the configuration for the Organizations integration in the current Region.
 * Can only be called by the Detective administrator account for the
 * organization.
 */
export declare const updateOrganizationConfiguration: API.OperationMethod<UpdateOrganizationConfigurationRequest, UpdateOrganizationConfigurationResponse, UpdateOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=detective.d.ts.map