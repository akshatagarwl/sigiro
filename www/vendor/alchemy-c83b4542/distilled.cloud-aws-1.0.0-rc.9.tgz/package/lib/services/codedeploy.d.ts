import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AlarmsLimitExceededException_base: S.Class<AlarmsLimitExceededException, S.TaggedStruct<"AlarmsLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AlarmsLimitExceededException extends /*@__PURE__*/ AlarmsLimitExceededException_base {
}
declare const ApplicationAlreadyExistsException_base: S.Class<ApplicationAlreadyExistsException, S.TaggedStruct<"ApplicationAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ApplicationAlreadyExistsException extends /*@__PURE__*/ ApplicationAlreadyExistsException_base {
}
declare const ApplicationDoesNotExistException_base: S.Class<ApplicationDoesNotExistException, S.TaggedStruct<"ApplicationDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApplicationDoesNotExistException extends /*@__PURE__*/ ApplicationDoesNotExistException_base {
}
declare const ApplicationLimitExceededException_base: S.Class<ApplicationLimitExceededException, S.TaggedStruct<"ApplicationLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApplicationLimitExceededException extends /*@__PURE__*/ ApplicationLimitExceededException_base {
}
declare const ApplicationNameRequiredException_base: S.Class<ApplicationNameRequiredException, S.TaggedStruct<"ApplicationNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ApplicationNameRequiredException extends /*@__PURE__*/ ApplicationNameRequiredException_base {
}
declare const ArnNotSupportedException_base: S.Class<ArnNotSupportedException, S.TaggedStruct<"ArnNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ArnNotSupportedException extends /*@__PURE__*/ ArnNotSupportedException_base {
}
declare const BatchLimitExceededException_base: S.Class<BatchLimitExceededException, S.TaggedStruct<"BatchLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BatchLimitExceededException extends /*@__PURE__*/ BatchLimitExceededException_base {
}
declare const BucketNameFilterRequiredException_base: S.Class<BucketNameFilterRequiredException, S.TaggedStruct<"BucketNameFilterRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BucketNameFilterRequiredException extends /*@__PURE__*/ BucketNameFilterRequiredException_base {
}
declare const DeploymentAlreadyCompletedException_base: S.Class<DeploymentAlreadyCompletedException, S.TaggedStruct<"DeploymentAlreadyCompletedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentAlreadyCompletedException extends /*@__PURE__*/ DeploymentAlreadyCompletedException_base {
}
declare const DeploymentConfigAlreadyExistsException_base: S.Class<DeploymentConfigAlreadyExistsException, S.TaggedStruct<"DeploymentConfigAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DeploymentConfigAlreadyExistsException extends /*@__PURE__*/ DeploymentConfigAlreadyExistsException_base {
}
declare const DeploymentConfigDoesNotExistException_base: S.Class<DeploymentConfigDoesNotExistException, S.TaggedStruct<"DeploymentConfigDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentConfigDoesNotExistException extends /*@__PURE__*/ DeploymentConfigDoesNotExistException_base {
}
declare const DeploymentConfigInUseException_base: S.Class<DeploymentConfigInUseException, S.TaggedStruct<"DeploymentConfigInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentConfigInUseException extends /*@__PURE__*/ DeploymentConfigInUseException_base {
}
declare const DeploymentConfigLimitExceededException_base: S.Class<DeploymentConfigLimitExceededException, S.TaggedStruct<"DeploymentConfigLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentConfigLimitExceededException extends /*@__PURE__*/ DeploymentConfigLimitExceededException_base {
}
declare const DeploymentConfigNameRequiredException_base: S.Class<DeploymentConfigNameRequiredException, S.TaggedStruct<"DeploymentConfigNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentConfigNameRequiredException extends /*@__PURE__*/ DeploymentConfigNameRequiredException_base {
}
declare const DeploymentDoesNotExistException_base: S.Class<DeploymentDoesNotExistException, S.TaggedStruct<"DeploymentDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentDoesNotExistException extends /*@__PURE__*/ DeploymentDoesNotExistException_base {
}
declare const DeploymentGroupAlreadyExistsException_base: S.Class<DeploymentGroupAlreadyExistsException, S.TaggedStruct<"DeploymentGroupAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DeploymentGroupAlreadyExistsException extends /*@__PURE__*/ DeploymentGroupAlreadyExistsException_base {
}
declare const DeploymentGroupDoesNotExistException_base: S.Class<DeploymentGroupDoesNotExistException, S.TaggedStruct<"DeploymentGroupDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentGroupDoesNotExistException extends /*@__PURE__*/ DeploymentGroupDoesNotExistException_base {
}
declare const DeploymentGroupLimitExceededException_base: S.Class<DeploymentGroupLimitExceededException, S.TaggedStruct<"DeploymentGroupLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentGroupLimitExceededException extends /*@__PURE__*/ DeploymentGroupLimitExceededException_base {
}
declare const DeploymentGroupNameRequiredException_base: S.Class<DeploymentGroupNameRequiredException, S.TaggedStruct<"DeploymentGroupNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentGroupNameRequiredException extends /*@__PURE__*/ DeploymentGroupNameRequiredException_base {
}
declare const DeploymentIdRequiredException_base: S.Class<DeploymentIdRequiredException, S.TaggedStruct<"DeploymentIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentIdRequiredException extends /*@__PURE__*/ DeploymentIdRequiredException_base {
}
declare const DeploymentIsNotInReadyStateException_base: S.Class<DeploymentIsNotInReadyStateException, S.TaggedStruct<"DeploymentIsNotInReadyStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentIsNotInReadyStateException extends /*@__PURE__*/ DeploymentIsNotInReadyStateException_base {
}
declare const DeploymentLimitExceededException_base: S.Class<DeploymentLimitExceededException, S.TaggedStruct<"DeploymentLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentLimitExceededException extends /*@__PURE__*/ DeploymentLimitExceededException_base {
}
declare const DeploymentNotStartedException_base: S.Class<DeploymentNotStartedException, S.TaggedStruct<"DeploymentNotStartedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentNotStartedException extends /*@__PURE__*/ DeploymentNotStartedException_base {
}
declare const DeploymentTargetDoesNotExistException_base: S.Class<DeploymentTargetDoesNotExistException, S.TaggedStruct<"DeploymentTargetDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentTargetDoesNotExistException extends /*@__PURE__*/ DeploymentTargetDoesNotExistException_base {
}
declare const DeploymentTargetIdRequiredException_base: S.Class<DeploymentTargetIdRequiredException, S.TaggedStruct<"DeploymentTargetIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentTargetIdRequiredException extends /*@__PURE__*/ DeploymentTargetIdRequiredException_base {
}
declare const DeploymentTargetListSizeExceededException_base: S.Class<DeploymentTargetListSizeExceededException, S.TaggedStruct<"DeploymentTargetListSizeExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentTargetListSizeExceededException extends /*@__PURE__*/ DeploymentTargetListSizeExceededException_base {
}
declare const DescriptionTooLongException_base: S.Class<DescriptionTooLongException, S.TaggedStruct<"DescriptionTooLongException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DescriptionTooLongException extends /*@__PURE__*/ DescriptionTooLongException_base {
}
declare const ECSServiceMappingLimitExceededException_base: S.Class<ECSServiceMappingLimitExceededException, S.TaggedStruct<"ECSServiceMappingLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ECSServiceMappingLimitExceededException extends /*@__PURE__*/ ECSServiceMappingLimitExceededException_base {
}
declare const GitHubAccountTokenDoesNotExistException_base: S.Class<GitHubAccountTokenDoesNotExistException, S.TaggedStruct<"GitHubAccountTokenDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class GitHubAccountTokenDoesNotExistException extends /*@__PURE__*/ GitHubAccountTokenDoesNotExistException_base {
}
declare const GitHubAccountTokenNameRequiredException_base: S.Class<GitHubAccountTokenNameRequiredException, S.TaggedStruct<"GitHubAccountTokenNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class GitHubAccountTokenNameRequiredException extends /*@__PURE__*/ GitHubAccountTokenNameRequiredException_base {
}
declare const IamArnRequiredException_base: S.Class<IamArnRequiredException, S.TaggedStruct<"IamArnRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IamArnRequiredException extends /*@__PURE__*/ IamArnRequiredException_base {
}
declare const IamSessionArnAlreadyRegisteredException_base: S.Class<IamSessionArnAlreadyRegisteredException, S.TaggedStruct<"IamSessionArnAlreadyRegisteredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IamSessionArnAlreadyRegisteredException extends /*@__PURE__*/ IamSessionArnAlreadyRegisteredException_base {
}
declare const IamUserArnAlreadyRegisteredException_base: S.Class<IamUserArnAlreadyRegisteredException, S.TaggedStruct<"IamUserArnAlreadyRegisteredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IamUserArnAlreadyRegisteredException extends /*@__PURE__*/ IamUserArnAlreadyRegisteredException_base {
}
declare const IamUserArnRequiredException_base: S.Class<IamUserArnRequiredException, S.TaggedStruct<"IamUserArnRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IamUserArnRequiredException extends /*@__PURE__*/ IamUserArnRequiredException_base {
}
declare const InstanceDoesNotExistException_base: S.Class<InstanceDoesNotExistException, S.TaggedStruct<"InstanceDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceDoesNotExistException extends /*@__PURE__*/ InstanceDoesNotExistException_base {
}
declare const InstanceIdRequiredException_base: S.Class<InstanceIdRequiredException, S.TaggedStruct<"InstanceIdRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceIdRequiredException extends /*@__PURE__*/ InstanceIdRequiredException_base {
}
declare const InstanceLimitExceededException_base: S.Class<InstanceLimitExceededException, S.TaggedStruct<"InstanceLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceLimitExceededException extends /*@__PURE__*/ InstanceLimitExceededException_base {
}
declare const InstanceNameAlreadyRegisteredException_base: S.Class<InstanceNameAlreadyRegisteredException, S.TaggedStruct<"InstanceNameAlreadyRegisteredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceNameAlreadyRegisteredException extends /*@__PURE__*/ InstanceNameAlreadyRegisteredException_base {
}
declare const InstanceNameRequiredException_base: S.Class<InstanceNameRequiredException, S.TaggedStruct<"InstanceNameRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceNameRequiredException extends /*@__PURE__*/ InstanceNameRequiredException_base {
}
declare const InstanceNotRegisteredException_base: S.Class<InstanceNotRegisteredException, S.TaggedStruct<"InstanceNotRegisteredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceNotRegisteredException extends /*@__PURE__*/ InstanceNotRegisteredException_base {
}
declare const InvalidAlarmConfigException_base: S.Class<InvalidAlarmConfigException, S.TaggedStruct<"InvalidAlarmConfigException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidAlarmConfigException extends /*@__PURE__*/ InvalidAlarmConfigException_base {
}
declare const InvalidApplicationNameException_base: S.Class<InvalidApplicationNameException, S.TaggedStruct<"InvalidApplicationNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidApplicationNameException extends /*@__PURE__*/ InvalidApplicationNameException_base {
}
declare const InvalidArnException_base: S.Class<InvalidArnException, S.TaggedStruct<"InvalidArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidAutoRollbackConfigException_base: S.Class<InvalidAutoRollbackConfigException, S.TaggedStruct<"InvalidAutoRollbackConfigException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidAutoRollbackConfigException extends /*@__PURE__*/ InvalidAutoRollbackConfigException_base {
}
declare const InvalidAutoScalingGroupException_base: S.Class<InvalidAutoScalingGroupException, S.TaggedStruct<"InvalidAutoScalingGroupException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidAutoScalingGroupException extends /*@__PURE__*/ InvalidAutoScalingGroupException_base {
}
declare const InvalidBlueGreenDeploymentConfigurationException_base: S.Class<InvalidBlueGreenDeploymentConfigurationException, S.TaggedStruct<"InvalidBlueGreenDeploymentConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidBlueGreenDeploymentConfigurationException extends /*@__PURE__*/ InvalidBlueGreenDeploymentConfigurationException_base {
}
declare const InvalidBucketNameFilterException_base: S.Class<InvalidBucketNameFilterException, S.TaggedStruct<"InvalidBucketNameFilterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidBucketNameFilterException extends /*@__PURE__*/ InvalidBucketNameFilterException_base {
}
declare const InvalidComputePlatformException_base: S.Class<InvalidComputePlatformException, S.TaggedStruct<"InvalidComputePlatformException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidComputePlatformException extends /*@__PURE__*/ InvalidComputePlatformException_base {
}
declare const InvalidDeployedStateFilterException_base: S.Class<InvalidDeployedStateFilterException, S.TaggedStruct<"InvalidDeployedStateFilterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeployedStateFilterException extends /*@__PURE__*/ InvalidDeployedStateFilterException_base {
}
declare const InvalidDeploymentConfigNameException_base: S.Class<InvalidDeploymentConfigNameException, S.TaggedStruct<"InvalidDeploymentConfigNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentConfigNameException extends /*@__PURE__*/ InvalidDeploymentConfigNameException_base {
}
declare const InvalidDeploymentGroupNameException_base: S.Class<InvalidDeploymentGroupNameException, S.TaggedStruct<"InvalidDeploymentGroupNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentGroupNameException extends /*@__PURE__*/ InvalidDeploymentGroupNameException_base {
}
declare const InvalidDeploymentIdException_base: S.Class<InvalidDeploymentIdException, S.TaggedStruct<"InvalidDeploymentIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentIdException extends /*@__PURE__*/ InvalidDeploymentIdException_base {
}
declare const InvalidDeploymentInstanceTypeException_base: S.Class<InvalidDeploymentInstanceTypeException, S.TaggedStruct<"InvalidDeploymentInstanceTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentInstanceTypeException extends /*@__PURE__*/ InvalidDeploymentInstanceTypeException_base {
}
declare const InvalidDeploymentStatusException_base: S.Class<InvalidDeploymentStatusException, S.TaggedStruct<"InvalidDeploymentStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentStatusException extends /*@__PURE__*/ InvalidDeploymentStatusException_base {
}
declare const InvalidDeploymentStyleException_base: S.Class<InvalidDeploymentStyleException, S.TaggedStruct<"InvalidDeploymentStyleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentStyleException extends /*@__PURE__*/ InvalidDeploymentStyleException_base {
}
declare const InvalidDeploymentTargetIdException_base: S.Class<InvalidDeploymentTargetIdException, S.TaggedStruct<"InvalidDeploymentTargetIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentTargetIdException extends /*@__PURE__*/ InvalidDeploymentTargetIdException_base {
}
declare const InvalidDeploymentWaitTypeException_base: S.Class<InvalidDeploymentWaitTypeException, S.TaggedStruct<"InvalidDeploymentWaitTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDeploymentWaitTypeException extends /*@__PURE__*/ InvalidDeploymentWaitTypeException_base {
}
declare const InvalidEC2TagCombinationException_base: S.Class<InvalidEC2TagCombinationException, S.TaggedStruct<"InvalidEC2TagCombinationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidEC2TagCombinationException extends /*@__PURE__*/ InvalidEC2TagCombinationException_base {
}
declare const InvalidEC2TagException_base: S.Class<InvalidEC2TagException, S.TaggedStruct<"InvalidEC2TagException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidEC2TagException extends /*@__PURE__*/ InvalidEC2TagException_base {
}
declare const InvalidECSServiceException_base: S.Class<InvalidECSServiceException, S.TaggedStruct<"InvalidECSServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidECSServiceException extends /*@__PURE__*/ InvalidECSServiceException_base {
}
declare const InvalidExternalIdException_base: S.Class<InvalidExternalIdException, S.TaggedStruct<"InvalidExternalIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidExternalIdException extends /*@__PURE__*/ InvalidExternalIdException_base {
}
declare const InvalidFileExistsBehaviorException_base: S.Class<InvalidFileExistsBehaviorException, S.TaggedStruct<"InvalidFileExistsBehaviorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidFileExistsBehaviorException extends /*@__PURE__*/ InvalidFileExistsBehaviorException_base {
}
declare const InvalidGitHubAccountTokenException_base: S.Class<InvalidGitHubAccountTokenException, S.TaggedStruct<"InvalidGitHubAccountTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidGitHubAccountTokenException extends /*@__PURE__*/ InvalidGitHubAccountTokenException_base {
}
declare const InvalidGitHubAccountTokenNameException_base: S.Class<InvalidGitHubAccountTokenNameException, S.TaggedStruct<"InvalidGitHubAccountTokenNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidGitHubAccountTokenNameException extends /*@__PURE__*/ InvalidGitHubAccountTokenNameException_base {
}
declare const InvalidIamSessionArnException_base: S.Class<InvalidIamSessionArnException, S.TaggedStruct<"InvalidIamSessionArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidIamSessionArnException extends /*@__PURE__*/ InvalidIamSessionArnException_base {
}
declare const InvalidIamUserArnException_base: S.Class<InvalidIamUserArnException, S.TaggedStruct<"InvalidIamUserArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidIamUserArnException extends /*@__PURE__*/ InvalidIamUserArnException_base {
}
declare const InvalidIgnoreApplicationStopFailuresValueException_base: S.Class<InvalidIgnoreApplicationStopFailuresValueException, S.TaggedStruct<"InvalidIgnoreApplicationStopFailuresValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidIgnoreApplicationStopFailuresValueException extends /*@__PURE__*/ InvalidIgnoreApplicationStopFailuresValueException_base {
}
declare const InvalidInputException_base: S.Class<InvalidInputException, S.TaggedStruct<"InvalidInputException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidInstanceNameException_base: S.Class<InvalidInstanceNameException, S.TaggedStruct<"InvalidInstanceNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInstanceNameException extends /*@__PURE__*/ InvalidInstanceNameException_base {
}
declare const InvalidInstanceStatusException_base: S.Class<InvalidInstanceStatusException, S.TaggedStruct<"InvalidInstanceStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInstanceStatusException extends /*@__PURE__*/ InvalidInstanceStatusException_base {
}
declare const InvalidInstanceTypeException_base: S.Class<InvalidInstanceTypeException, S.TaggedStruct<"InvalidInstanceTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInstanceTypeException extends /*@__PURE__*/ InvalidInstanceTypeException_base {
}
declare const InvalidKeyPrefixFilterException_base: S.Class<InvalidKeyPrefixFilterException, S.TaggedStruct<"InvalidKeyPrefixFilterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidKeyPrefixFilterException extends /*@__PURE__*/ InvalidKeyPrefixFilterException_base {
}
declare const InvalidLifecycleEventHookExecutionIdException_base: S.Class<InvalidLifecycleEventHookExecutionIdException, S.TaggedStruct<"InvalidLifecycleEventHookExecutionIdException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLifecycleEventHookExecutionIdException extends /*@__PURE__*/ InvalidLifecycleEventHookExecutionIdException_base {
}
declare const InvalidLifecycleEventHookExecutionStatusException_base: S.Class<InvalidLifecycleEventHookExecutionStatusException, S.TaggedStruct<"InvalidLifecycleEventHookExecutionStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLifecycleEventHookExecutionStatusException extends /*@__PURE__*/ InvalidLifecycleEventHookExecutionStatusException_base {
}
declare const InvalidLoadBalancerInfoException_base: S.Class<InvalidLoadBalancerInfoException, S.TaggedStruct<"InvalidLoadBalancerInfoException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidLoadBalancerInfoException extends /*@__PURE__*/ InvalidLoadBalancerInfoException_base {
}
declare const InvalidMinimumHealthyHostValueException_base: S.Class<InvalidMinimumHealthyHostValueException, S.TaggedStruct<"InvalidMinimumHealthyHostValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMinimumHealthyHostValueException extends /*@__PURE__*/ InvalidMinimumHealthyHostValueException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidOnPremisesTagCombinationException_base: S.Class<InvalidOnPremisesTagCombinationException, S.TaggedStruct<"InvalidOnPremisesTagCombinationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidOnPremisesTagCombinationException extends /*@__PURE__*/ InvalidOnPremisesTagCombinationException_base {
}
declare const InvalidOperationException_base: S.Class<InvalidOperationException, S.TaggedStruct<"InvalidOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidRegistrationStatusException_base: S.Class<InvalidRegistrationStatusException, S.TaggedStruct<"InvalidRegistrationStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRegistrationStatusException extends /*@__PURE__*/ InvalidRegistrationStatusException_base {
}
declare const InvalidRevisionException_base: S.Class<InvalidRevisionException, S.TaggedStruct<"InvalidRevisionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRevisionException extends /*@__PURE__*/ InvalidRevisionException_base {
}
declare const InvalidRoleException_base: S.Class<InvalidRoleException, S.TaggedStruct<"InvalidRoleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoleException extends /*@__PURE__*/ InvalidRoleException_base {
}
declare const InvalidSortByException_base: S.Class<InvalidSortByException, S.TaggedStruct<"InvalidSortByException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSortByException extends /*@__PURE__*/ InvalidSortByException_base {
}
declare const InvalidSortOrderException_base: S.Class<InvalidSortOrderException, S.TaggedStruct<"InvalidSortOrderException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSortOrderException extends /*@__PURE__*/ InvalidSortOrderException_base {
}
declare const InvalidTagException_base: S.Class<InvalidTagException, S.TaggedStruct<"InvalidTagException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const InvalidTagFilterException_base: S.Class<InvalidTagFilterException, S.TaggedStruct<"InvalidTagFilterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagFilterException extends /*@__PURE__*/ InvalidTagFilterException_base {
}
declare const InvalidTagsToAddException_base: S.Class<InvalidTagsToAddException, S.TaggedStruct<"InvalidTagsToAddException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagsToAddException extends /*@__PURE__*/ InvalidTagsToAddException_base {
}
declare const InvalidTargetFilterNameException_base: S.Class<InvalidTargetFilterNameException, S.TaggedStruct<"InvalidTargetFilterNameException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTargetFilterNameException extends /*@__PURE__*/ InvalidTargetFilterNameException_base {
}
declare const InvalidTargetGroupPairException_base: S.Class<InvalidTargetGroupPairException, S.TaggedStruct<"InvalidTargetGroupPairException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTargetGroupPairException extends /*@__PURE__*/ InvalidTargetGroupPairException_base {
}
declare const InvalidTargetInstancesException_base: S.Class<InvalidTargetInstancesException, S.TaggedStruct<"InvalidTargetInstancesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTargetInstancesException extends /*@__PURE__*/ InvalidTargetInstancesException_base {
}
declare const InvalidTimeRangeException_base: S.Class<InvalidTimeRangeException, S.TaggedStruct<"InvalidTimeRangeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTimeRangeException extends /*@__PURE__*/ InvalidTimeRangeException_base {
}
declare const InvalidTrafficRoutingConfigurationException_base: S.Class<InvalidTrafficRoutingConfigurationException, S.TaggedStruct<"InvalidTrafficRoutingConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTrafficRoutingConfigurationException extends /*@__PURE__*/ InvalidTrafficRoutingConfigurationException_base {
}
declare const InvalidTriggerConfigException_base: S.Class<InvalidTriggerConfigException, S.TaggedStruct<"InvalidTriggerConfigException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTriggerConfigException extends /*@__PURE__*/ InvalidTriggerConfigException_base {
}
declare const InvalidUpdateOutdatedInstancesOnlyValueException_base: S.Class<InvalidUpdateOutdatedInstancesOnlyValueException, S.TaggedStruct<"InvalidUpdateOutdatedInstancesOnlyValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidUpdateOutdatedInstancesOnlyValueException extends /*@__PURE__*/ InvalidUpdateOutdatedInstancesOnlyValueException_base {
}
declare const InvalidZonalDeploymentConfigurationException_base: S.Class<InvalidZonalDeploymentConfigurationException, S.TaggedStruct<"InvalidZonalDeploymentConfigurationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidZonalDeploymentConfigurationException extends /*@__PURE__*/ InvalidZonalDeploymentConfigurationException_base {
}
declare const LifecycleEventAlreadyCompletedException_base: S.Class<LifecycleEventAlreadyCompletedException, S.TaggedStruct<"LifecycleEventAlreadyCompletedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LifecycleEventAlreadyCompletedException extends /*@__PURE__*/ LifecycleEventAlreadyCompletedException_base {
}
declare const LifecycleHookLimitExceededException_base: S.Class<LifecycleHookLimitExceededException, S.TaggedStruct<"LifecycleHookLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LifecycleHookLimitExceededException extends /*@__PURE__*/ LifecycleHookLimitExceededException_base {
}
declare const MultipleIamArnsProvidedException_base: S.Class<MultipleIamArnsProvidedException, S.TaggedStruct<"MultipleIamArnsProvidedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MultipleIamArnsProvidedException extends /*@__PURE__*/ MultipleIamArnsProvidedException_base {
}
declare const OperationNotSupportedException_base: S.Class<OperationNotSupportedException, S.TaggedStruct<"OperationNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OperationNotSupportedException extends /*@__PURE__*/ OperationNotSupportedException_base {
}
declare const ResourceArnRequiredException_base: S.Class<ResourceArnRequiredException, S.TaggedStruct<"ResourceArnRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceArnRequiredException extends /*@__PURE__*/ ResourceArnRequiredException_base {
}
declare const ResourceValidationException_base: S.Class<ResourceValidationException, S.TaggedStruct<"ResourceValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceValidationException extends /*@__PURE__*/ ResourceValidationException_base {
}
declare const RevisionDoesNotExistException_base: S.Class<RevisionDoesNotExistException, S.TaggedStruct<"RevisionDoesNotExistException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RevisionDoesNotExistException extends /*@__PURE__*/ RevisionDoesNotExistException_base {
}
declare const RevisionRequiredException_base: S.Class<RevisionRequiredException, S.TaggedStruct<"RevisionRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RevisionRequiredException extends /*@__PURE__*/ RevisionRequiredException_base {
}
declare const RoleRequiredException_base: S.Class<RoleRequiredException, S.TaggedStruct<"RoleRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RoleRequiredException extends /*@__PURE__*/ RoleRequiredException_base {
}
declare const TagLimitExceededException_base: S.Class<TagLimitExceededException, S.TaggedStruct<"TagLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagLimitExceededException extends /*@__PURE__*/ TagLimitExceededException_base {
}
declare const TagRequiredException_base: S.Class<TagRequiredException, S.TaggedStruct<"TagRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagRequiredException extends /*@__PURE__*/ TagRequiredException_base {
}
declare const TagSetListLimitExceededException_base: S.Class<TagSetListLimitExceededException, S.TaggedStruct<"TagSetListLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagSetListLimitExceededException extends /*@__PURE__*/ TagSetListLimitExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TriggerTargetsLimitExceededException_base: S.Class<TriggerTargetsLimitExceededException, S.TaggedStruct<"TriggerTargetsLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TriggerTargetsLimitExceededException extends /*@__PURE__*/ TriggerTargetsLimitExceededException_base {
}
declare const UnsupportedActionForDeploymentTypeException_base: S.Class<UnsupportedActionForDeploymentTypeException, S.TaggedStruct<"UnsupportedActionForDeploymentTypeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnsupportedActionForDeploymentTypeException extends /*@__PURE__*/ UnsupportedActionForDeploymentTypeException_base {
}
export type Key = string;
export type Value = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type InstanceName = string;
export type InstanceNameList = string[];
export declare const InstanceNameList: any;
export interface AddTagsToOnPremisesInstancesInput {
    tags: Tag[];
    instanceNames: string[];
}
export declare const AddTagsToOnPremisesInstancesInput: S.Schema<AddTagsToOnPremisesInstancesInput>;
export interface AddTagsToOnPremisesInstancesResponse {
}
export declare const AddTagsToOnPremisesInstancesResponse: S.Schema<AddTagsToOnPremisesInstancesResponse>;
export type ApplicationName = string;
export type RevisionLocationType = "S3" | "GitHub" | "String" | "AppSpecContent" | (string & {});
export declare const RevisionLocationType: any;
export type S3Bucket = string;
export type S3Key = string;
export type BundleType = "tar" | "tgz" | "zip" | "YAML" | "JSON" | (string & {});
export declare const BundleType: any;
export type VersionId = string;
export type ETag = string;
export interface S3Location {
    bucket?: string;
    key?: string;
    bundleType?: BundleType;
    version?: string;
    eTag?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export type Repository = string;
export type CommitId = string;
export interface GitHubLocation {
    repository?: string;
    commitId?: string;
}
export declare const GitHubLocation: S.Schema<GitHubLocation>;
export type RawStringContent = string;
export type RawStringSha256 = string;
export interface RawString {
    content?: string;
    sha256?: string;
}
export declare const RawString: S.Schema<RawString>;
export interface AppSpecContent {
    content?: string;
    sha256?: string;
}
export declare const AppSpecContent: S.Schema<AppSpecContent>;
export interface RevisionLocation {
    revisionType?: RevisionLocationType;
    s3Location?: S3Location;
    gitHubLocation?: GitHubLocation;
    string?: RawString;
    appSpecContent?: AppSpecContent;
}
export declare const RevisionLocation: S.Schema<RevisionLocation>;
export type RevisionLocationList = RevisionLocation[];
export declare const RevisionLocationList: any;
export interface BatchGetApplicationRevisionsInput {
    applicationName: string;
    revisions: RevisionLocation[];
}
export declare const BatchGetApplicationRevisionsInput: S.Schema<BatchGetApplicationRevisionsInput>;
export type ErrorMessage = string;
export type Description = string;
export type DeploymentGroupName = string;
export type DeploymentGroupsList = string[];
export declare const DeploymentGroupsList: any;
export interface GenericRevisionInfo {
    description?: string;
    deploymentGroups?: string[];
    firstUsedTime?: Date;
    lastUsedTime?: Date;
    registerTime?: Date;
}
export declare const GenericRevisionInfo: S.Schema<GenericRevisionInfo>;
export interface RevisionInfo {
    revisionLocation?: RevisionLocation;
    genericRevisionInfo?: GenericRevisionInfo;
}
export declare const RevisionInfo: S.Schema<RevisionInfo>;
export type RevisionInfoList = RevisionInfo[];
export declare const RevisionInfoList: any;
export interface BatchGetApplicationRevisionsOutput {
    applicationName?: string;
    errorMessage?: string;
    revisions?: RevisionInfo[];
}
export declare const BatchGetApplicationRevisionsOutput: S.Schema<BatchGetApplicationRevisionsOutput>;
export type ApplicationsList = string[];
export declare const ApplicationsList: any;
export interface BatchGetApplicationsInput {
    applicationNames: string[];
}
export declare const BatchGetApplicationsInput: S.Schema<BatchGetApplicationsInput>;
export type ApplicationId = string;
export type GitHubAccountTokenName = string;
export type ComputePlatform = "Server" | "Lambda" | "ECS" | (string & {});
export declare const ComputePlatform: any;
export interface ApplicationInfo {
    applicationId?: string;
    applicationName?: string;
    createTime?: Date;
    linkedToGitHub?: boolean;
    gitHubAccountName?: string;
    computePlatform?: ComputePlatform;
}
export declare const ApplicationInfo: S.Schema<ApplicationInfo>;
export type ApplicationsInfoList = ApplicationInfo[];
export declare const ApplicationsInfoList: any;
export interface BatchGetApplicationsOutput {
    applicationsInfo?: ApplicationInfo[];
}
export declare const BatchGetApplicationsOutput: S.Schema<BatchGetApplicationsOutput>;
export interface BatchGetDeploymentGroupsInput {
    applicationName: string;
    deploymentGroupNames: string[];
}
export declare const BatchGetDeploymentGroupsInput: S.Schema<BatchGetDeploymentGroupsInput>;
export type DeploymentGroupId = string;
export type DeploymentConfigName = string;
export type EC2TagFilterType = "KEY_ONLY" | "VALUE_ONLY" | "KEY_AND_VALUE" | (string & {});
export declare const EC2TagFilterType: any;
export interface EC2TagFilter {
    Key?: string;
    Value?: string;
    Type?: EC2TagFilterType;
}
export declare const EC2TagFilter: S.Schema<EC2TagFilter>;
export type EC2TagFilterList = EC2TagFilter[];
export declare const EC2TagFilterList: any;
export type TagFilterType = "KEY_ONLY" | "VALUE_ONLY" | "KEY_AND_VALUE" | (string & {});
export declare const TagFilterType: any;
export interface TagFilter {
    Key?: string;
    Value?: string;
    Type?: TagFilterType;
}
export declare const TagFilter: S.Schema<TagFilter>;
export type TagFilterList = TagFilter[];
export declare const TagFilterList: any;
export type AutoScalingGroupName = string;
export type AutoScalingGroupHook = string;
export interface AutoScalingGroup {
    name?: string;
    hook?: string;
    terminationHook?: string;
}
export declare const AutoScalingGroup: S.Schema<AutoScalingGroup>;
export type AutoScalingGroupList = AutoScalingGroup[];
export declare const AutoScalingGroupList: any;
export type Role = string;
export type TriggerName = string;
export type TriggerTargetArn = string;
export type TriggerEventType = "DeploymentStart" | "DeploymentSuccess" | "DeploymentFailure" | "DeploymentStop" | "DeploymentRollback" | "DeploymentReady" | "InstanceStart" | "InstanceSuccess" | "InstanceFailure" | "InstanceReady" | (string & {});
export declare const TriggerEventType: any;
export type TriggerEventTypeList = TriggerEventType[];
export declare const TriggerEventTypeList: any;
export interface TriggerConfig {
    triggerName?: string;
    triggerTargetArn?: string;
    triggerEvents?: TriggerEventType[];
}
export declare const TriggerConfig: S.Schema<TriggerConfig>;
export type TriggerConfigList = TriggerConfig[];
export declare const TriggerConfigList: any;
export type AlarmName = string;
export interface Alarm {
    name?: string;
}
export declare const Alarm: S.Schema<Alarm>;
export type AlarmList = Alarm[];
export declare const AlarmList: any;
export interface AlarmConfiguration {
    enabled?: boolean;
    ignorePollAlarmFailure?: boolean;
    alarms?: Alarm[];
}
export declare const AlarmConfiguration: S.Schema<AlarmConfiguration>;
export type AutoRollbackEvent = "DEPLOYMENT_FAILURE" | "DEPLOYMENT_STOP_ON_ALARM" | "DEPLOYMENT_STOP_ON_REQUEST" | (string & {});
export declare const AutoRollbackEvent: any;
export type AutoRollbackEventsList = AutoRollbackEvent[];
export declare const AutoRollbackEventsList: any;
export interface AutoRollbackConfiguration {
    enabled?: boolean;
    events?: AutoRollbackEvent[];
}
export declare const AutoRollbackConfiguration: S.Schema<AutoRollbackConfiguration>;
export type DeploymentType = "IN_PLACE" | "BLUE_GREEN" | (string & {});
export declare const DeploymentType: any;
export type DeploymentOption = "WITH_TRAFFIC_CONTROL" | "WITHOUT_TRAFFIC_CONTROL" | (string & {});
export declare const DeploymentOption: any;
export interface DeploymentStyle {
    deploymentType?: DeploymentType;
    deploymentOption?: DeploymentOption;
}
export declare const DeploymentStyle: S.Schema<DeploymentStyle>;
export type OutdatedInstancesStrategy = "UPDATE" | "IGNORE" | (string & {});
export declare const OutdatedInstancesStrategy: any;
export type InstanceAction = "TERMINATE" | "KEEP_ALIVE" | (string & {});
export declare const InstanceAction: any;
export type Duration = number;
export interface BlueInstanceTerminationOption {
    action?: InstanceAction;
    terminationWaitTimeInMinutes?: number;
}
export declare const BlueInstanceTerminationOption: S.Schema<BlueInstanceTerminationOption>;
export type DeploymentReadyAction = "CONTINUE_DEPLOYMENT" | "STOP_DEPLOYMENT" | (string & {});
export declare const DeploymentReadyAction: any;
export interface DeploymentReadyOption {
    actionOnTimeout?: DeploymentReadyAction;
    waitTimeInMinutes?: number;
}
export declare const DeploymentReadyOption: S.Schema<DeploymentReadyOption>;
export type GreenFleetProvisioningAction = "DISCOVER_EXISTING" | "COPY_AUTO_SCALING_GROUP" | (string & {});
export declare const GreenFleetProvisioningAction: any;
export interface GreenFleetProvisioningOption {
    action?: GreenFleetProvisioningAction;
}
export declare const GreenFleetProvisioningOption: S.Schema<GreenFleetProvisioningOption>;
export interface BlueGreenDeploymentConfiguration {
    terminateBlueInstancesOnDeploymentSuccess?: BlueInstanceTerminationOption;
    deploymentReadyOption?: DeploymentReadyOption;
    greenFleetProvisioningOption?: GreenFleetProvisioningOption;
}
export declare const BlueGreenDeploymentConfiguration: S.Schema<BlueGreenDeploymentConfiguration>;
export type ELBName = string;
export interface ELBInfo {
    name?: string;
}
export declare const ELBInfo: S.Schema<ELBInfo>;
export type ELBInfoList = ELBInfo[];
export declare const ELBInfoList: any;
export type TargetGroupName = string;
export interface TargetGroupInfo {
    name?: string;
}
export declare const TargetGroupInfo: S.Schema<TargetGroupInfo>;
export type TargetGroupInfoList = TargetGroupInfo[];
export declare const TargetGroupInfoList: any;
export type ListenerArn = string;
export type ListenerArnList = string[];
export declare const ListenerArnList: any;
export interface TrafficRoute {
    listenerArns?: string[];
}
export declare const TrafficRoute: S.Schema<TrafficRoute>;
export interface TargetGroupPairInfo {
    targetGroups?: TargetGroupInfo[];
    prodTrafficRoute?: TrafficRoute;
    testTrafficRoute?: TrafficRoute;
}
export declare const TargetGroupPairInfo: S.Schema<TargetGroupPairInfo>;
export type TargetGroupPairInfoList = TargetGroupPairInfo[];
export declare const TargetGroupPairInfoList: any;
export interface LoadBalancerInfo {
    elbInfoList?: ELBInfo[];
    targetGroupInfoList?: TargetGroupInfo[];
    targetGroupPairInfoList?: TargetGroupPairInfo[];
}
export declare const LoadBalancerInfo: S.Schema<LoadBalancerInfo>;
export type DeploymentId = string;
export type DeploymentStatus = "Created" | "Queued" | "InProgress" | "Baking" | "Succeeded" | "Failed" | "Stopped" | "Ready" | (string & {});
export declare const DeploymentStatus: any;
export interface LastDeploymentInfo {
    deploymentId?: string;
    status?: DeploymentStatus;
    endTime?: Date;
    createTime?: Date;
}
export declare const LastDeploymentInfo: S.Schema<LastDeploymentInfo>;
export type EC2TagSetList = EC2TagFilter[][];
export declare const EC2TagSetList: any;
export interface EC2TagSet {
    ec2TagSetList?: EC2TagFilter[][];
}
export declare const EC2TagSet: S.Schema<EC2TagSet>;
export type OnPremisesTagSetList = TagFilter[][];
export declare const OnPremisesTagSetList: any;
export interface OnPremisesTagSet {
    onPremisesTagSetList?: TagFilter[][];
}
export declare const OnPremisesTagSet: S.Schema<OnPremisesTagSet>;
export type ECSServiceName = string;
export type ECSClusterName = string;
export interface ECSService {
    serviceName?: string;
    clusterName?: string;
}
export declare const ECSService: S.Schema<ECSService>;
export type ECSServiceList = ECSService[];
export declare const ECSServiceList: any;
export interface DeploymentGroupInfo {
    applicationName?: string;
    deploymentGroupId?: string;
    deploymentGroupName?: string;
    deploymentConfigName?: string;
    ec2TagFilters?: EC2TagFilter[];
    onPremisesInstanceTagFilters?: TagFilter[];
    autoScalingGroups?: AutoScalingGroup[];
    serviceRoleArn?: string;
    targetRevision?: RevisionLocation;
    triggerConfigurations?: TriggerConfig[];
    alarmConfiguration?: AlarmConfiguration;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    deploymentStyle?: DeploymentStyle;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    lastSuccessfulDeployment?: LastDeploymentInfo;
    lastAttemptedDeployment?: LastDeploymentInfo;
    ec2TagSet?: EC2TagSet;
    onPremisesTagSet?: OnPremisesTagSet;
    computePlatform?: ComputePlatform;
    ecsServices?: ECSService[];
    terminationHookEnabled?: boolean;
}
export declare const DeploymentGroupInfo: S.Schema<DeploymentGroupInfo>;
export type DeploymentGroupInfoList = DeploymentGroupInfo[];
export declare const DeploymentGroupInfoList: any;
export interface BatchGetDeploymentGroupsOutput {
    deploymentGroupsInfo?: DeploymentGroupInfo[];
    errorMessage?: string;
}
export declare const BatchGetDeploymentGroupsOutput: S.Schema<BatchGetDeploymentGroupsOutput>;
export type InstanceId = string;
export type InstancesList = string[];
export declare const InstancesList: any;
export interface BatchGetDeploymentInstancesInput {
    deploymentId: string;
    instanceIds: string[];
}
export declare const BatchGetDeploymentInstancesInput: S.Schema<BatchGetDeploymentInstancesInput>;
export type InstanceStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | "Ready" | (string & {});
export declare const InstanceStatus: any;
export type LifecycleEventName = string;
export type LifecycleErrorCode = "Success" | "ScriptMissing" | "ScriptNotExecutable" | "ScriptTimedOut" | "ScriptFailed" | "UnknownError" | (string & {});
export declare const LifecycleErrorCode: any;
export type ScriptName = string;
export type LifecycleMessage = string;
export type LogTail = string;
export interface Diagnostics {
    errorCode?: LifecycleErrorCode;
    scriptName?: string;
    message?: string;
    logTail?: string;
}
export declare const Diagnostics: S.Schema<Diagnostics>;
export type LifecycleEventStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | (string & {});
export declare const LifecycleEventStatus: any;
export interface LifecycleEvent {
    lifecycleEventName?: string;
    diagnostics?: Diagnostics;
    startTime?: Date;
    endTime?: Date;
    status?: LifecycleEventStatus;
}
export declare const LifecycleEvent: S.Schema<LifecycleEvent>;
export type LifecycleEventList = LifecycleEvent[];
export declare const LifecycleEventList: any;
export type InstanceType = "Blue" | "Green" | (string & {});
export declare const InstanceType: any;
export interface InstanceSummary {
    deploymentId?: string;
    instanceId?: string;
    status?: InstanceStatus;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    instanceType?: InstanceType;
}
export declare const InstanceSummary: S.Schema<InstanceSummary>;
export type InstanceSummaryList = InstanceSummary[];
export declare const InstanceSummaryList: any;
export interface BatchGetDeploymentInstancesOutput {
    instancesSummary?: InstanceSummary[];
    errorMessage?: string;
}
export declare const BatchGetDeploymentInstancesOutput: S.Schema<BatchGetDeploymentInstancesOutput>;
export type DeploymentsList = string[];
export declare const DeploymentsList: any;
export interface BatchGetDeploymentsInput {
    deploymentIds: string[];
}
export declare const BatchGetDeploymentsInput: S.Schema<BatchGetDeploymentsInput>;
export type ErrorCode = "AGENT_ISSUE" | "ALARM_ACTIVE" | "APPLICATION_MISSING" | "AUTOSCALING_VALIDATION_ERROR" | "AUTO_SCALING_CONFIGURATION" | "AUTO_SCALING_IAM_ROLE_PERMISSIONS" | "CODEDEPLOY_RESOURCE_CANNOT_BE_FOUND" | "CUSTOMER_APPLICATION_UNHEALTHY" | "DEPLOYMENT_GROUP_MISSING" | "ECS_UPDATE_ERROR" | "ELASTIC_LOAD_BALANCING_INVALID" | "ELB_INVALID_INSTANCE" | "HEALTH_CONSTRAINTS" | "HEALTH_CONSTRAINTS_INVALID" | "HOOK_EXECUTION_FAILURE" | "IAM_ROLE_MISSING" | "IAM_ROLE_PERMISSIONS" | "INTERNAL_ERROR" | "INVALID_ECS_SERVICE" | "INVALID_LAMBDA_CONFIGURATION" | "INVALID_LAMBDA_FUNCTION" | "INVALID_REVISION" | "MANUAL_STOP" | "MISSING_BLUE_GREEN_DEPLOYMENT_CONFIGURATION" | "MISSING_ELB_INFORMATION" | "MISSING_GITHUB_TOKEN" | "NO_EC2_SUBSCRIPTION" | "NO_INSTANCES" | "OVER_MAX_INSTANCES" | "RESOURCE_LIMIT_EXCEEDED" | "REVISION_MISSING" | "THROTTLED" | "TIMEOUT" | "CLOUDFORMATION_STACK_FAILURE" | (string & {});
export declare const ErrorCode: any;
export interface ErrorInformation {
    code?: ErrorCode;
    message?: string;
}
export declare const ErrorInformation: S.Schema<ErrorInformation>;
export type InstanceCount = number;
export interface DeploymentOverview {
    Pending?: number;
    InProgress?: number;
    Succeeded?: number;
    Failed?: number;
    Skipped?: number;
    Ready?: number;
}
export declare const DeploymentOverview: S.Schema<DeploymentOverview>;
export type DeploymentCreator = "user" | "autoscaling" | "codeDeployRollback" | "CodeDeploy" | "CodeDeployAutoUpdate" | "CloudFormation" | "CloudFormationRollback" | "autoscalingTermination" | (string & {});
export declare const DeploymentCreator: any;
export interface RollbackInfo {
    rollbackDeploymentId?: string;
    rollbackTriggeringDeploymentId?: string;
    rollbackMessage?: string;
}
export declare const RollbackInfo: S.Schema<RollbackInfo>;
export type AutoScalingGroupNameList = string[];
export declare const AutoScalingGroupNameList: any;
export interface TargetInstances {
    tagFilters?: EC2TagFilter[];
    autoScalingGroups?: string[];
    ec2TagSet?: EC2TagSet;
}
export declare const TargetInstances: S.Schema<TargetInstances>;
export type AdditionalDeploymentStatusInfo = string;
export type FileExistsBehavior = "DISALLOW" | "OVERWRITE" | "RETAIN" | (string & {});
export declare const FileExistsBehavior: any;
export type DeploymentStatusMessageList = string[];
export declare const DeploymentStatusMessageList: any;
export type ExternalId = string;
export interface RelatedDeployments {
    autoUpdateOutdatedInstancesRootDeploymentId?: string;
    autoUpdateOutdatedInstancesDeploymentIds?: string[];
}
export declare const RelatedDeployments: S.Schema<RelatedDeployments>;
export interface DeploymentInfo {
    applicationName?: string;
    deploymentGroupName?: string;
    deploymentConfigName?: string;
    deploymentId?: string;
    previousRevision?: RevisionLocation;
    revision?: RevisionLocation;
    status?: DeploymentStatus;
    errorInformation?: ErrorInformation;
    createTime?: Date;
    startTime?: Date;
    completeTime?: Date;
    deploymentOverview?: DeploymentOverview;
    description?: string;
    creator?: DeploymentCreator;
    ignoreApplicationStopFailures?: boolean;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    updateOutdatedInstancesOnly?: boolean;
    rollbackInfo?: RollbackInfo;
    deploymentStyle?: DeploymentStyle;
    targetInstances?: TargetInstances;
    instanceTerminationWaitTimeStarted?: boolean;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    additionalDeploymentStatusInfo?: string;
    fileExistsBehavior?: FileExistsBehavior;
    deploymentStatusMessages?: string[];
    computePlatform?: ComputePlatform;
    externalId?: string;
    relatedDeployments?: RelatedDeployments;
    overrideAlarmConfiguration?: AlarmConfiguration;
}
export declare const DeploymentInfo: S.Schema<DeploymentInfo>;
export type DeploymentsInfoList = DeploymentInfo[];
export declare const DeploymentsInfoList: any;
export interface BatchGetDeploymentsOutput {
    deploymentsInfo?: DeploymentInfo[];
}
export declare const BatchGetDeploymentsOutput: S.Schema<BatchGetDeploymentsOutput>;
export type TargetId = string;
export type TargetIdList = string[];
export declare const TargetIdList: any;
export interface BatchGetDeploymentTargetsInput {
    deploymentId: string;
    targetIds: string[];
}
export declare const BatchGetDeploymentTargetsInput: S.Schema<BatchGetDeploymentTargetsInput>;
export type DeploymentTargetType = "InstanceTarget" | "LambdaTarget" | "ECSTarget" | "CloudFormationTarget" | (string & {});
export declare const DeploymentTargetType: any;
export type TargetArn = string;
export type TargetStatus = "Pending" | "InProgress" | "Succeeded" | "Failed" | "Skipped" | "Unknown" | "Ready" | (string & {});
export declare const TargetStatus: any;
export type TargetLabel = "Blue" | "Green" | (string & {});
export declare const TargetLabel: any;
export interface InstanceTarget {
    deploymentId?: string;
    targetId?: string;
    targetArn?: string;
    status?: TargetStatus;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    instanceLabel?: TargetLabel;
}
export declare const InstanceTarget: S.Schema<InstanceTarget>;
export type LambdaFunctionName = string;
export type LambdaFunctionAlias = string;
export type Version = string;
export type TrafficWeight = number;
export interface LambdaFunctionInfo {
    functionName?: string;
    functionAlias?: string;
    currentVersion?: string;
    targetVersion?: string;
    targetVersionWeight?: number;
}
export declare const LambdaFunctionInfo: S.Schema<LambdaFunctionInfo>;
export interface LambdaTarget {
    deploymentId?: string;
    targetId?: string;
    targetArn?: string;
    status?: TargetStatus;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    lambdaFunctionInfo?: LambdaFunctionInfo;
}
export declare const LambdaTarget: S.Schema<LambdaTarget>;
export type ECSTaskSetIdentifier = string;
export type ECSTaskSetCount = number;
export type ECSTaskSetStatus = string;
export interface ECSTaskSet {
    identifer?: string;
    desiredCount?: number;
    pendingCount?: number;
    runningCount?: number;
    status?: string;
    trafficWeight?: number;
    targetGroup?: TargetGroupInfo;
    taskSetLabel?: TargetLabel;
}
export declare const ECSTaskSet: S.Schema<ECSTaskSet>;
export type ECSTaskSetList = ECSTaskSet[];
export declare const ECSTaskSetList: any;
export interface ECSTarget {
    deploymentId?: string;
    targetId?: string;
    targetArn?: string;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    status?: TargetStatus;
    taskSetsInfo?: ECSTaskSet[];
}
export declare const ECSTarget: S.Schema<ECSTarget>;
export type CloudFormationResourceType = string;
export interface CloudFormationTarget {
    deploymentId?: string;
    targetId?: string;
    lastUpdatedAt?: Date;
    lifecycleEvents?: LifecycleEvent[];
    status?: TargetStatus;
    resourceType?: string;
    targetVersionWeight?: number;
}
export declare const CloudFormationTarget: S.Schema<CloudFormationTarget>;
export interface DeploymentTarget {
    deploymentTargetType?: DeploymentTargetType;
    instanceTarget?: InstanceTarget;
    lambdaTarget?: LambdaTarget;
    ecsTarget?: ECSTarget;
    cloudFormationTarget?: CloudFormationTarget;
}
export declare const DeploymentTarget: S.Schema<DeploymentTarget>;
export type DeploymentTargetList = DeploymentTarget[];
export declare const DeploymentTargetList: any;
export interface BatchGetDeploymentTargetsOutput {
    deploymentTargets?: DeploymentTarget[];
}
export declare const BatchGetDeploymentTargetsOutput: S.Schema<BatchGetDeploymentTargetsOutput>;
export interface BatchGetOnPremisesInstancesInput {
    instanceNames: string[];
}
export declare const BatchGetOnPremisesInstancesInput: S.Schema<BatchGetOnPremisesInstancesInput>;
export type IamSessionArn = string;
export type IamUserArn = string;
export type InstanceArn = string;
export interface InstanceInfo {
    instanceName?: string;
    iamSessionArn?: string;
    iamUserArn?: string;
    instanceArn?: string;
    registerTime?: Date;
    deregisterTime?: Date;
    tags?: Tag[];
}
export declare const InstanceInfo: S.Schema<InstanceInfo>;
export type InstanceInfoList = InstanceInfo[];
export declare const InstanceInfoList: any;
export interface BatchGetOnPremisesInstancesOutput {
    instanceInfos?: InstanceInfo[];
}
export declare const BatchGetOnPremisesInstancesOutput: S.Schema<BatchGetOnPremisesInstancesOutput>;
export type DeploymentWaitType = "READY_WAIT" | "TERMINATION_WAIT" | (string & {});
export declare const DeploymentWaitType: any;
export interface ContinueDeploymentInput {
    deploymentId?: string;
    deploymentWaitType?: DeploymentWaitType;
}
export declare const ContinueDeploymentInput: S.Schema<ContinueDeploymentInput>;
export interface ContinueDeploymentResponse {
}
export declare const ContinueDeploymentResponse: S.Schema<ContinueDeploymentResponse>;
export interface CreateApplicationInput {
    applicationName: string;
    computePlatform?: ComputePlatform;
    tags?: Tag[];
}
export declare const CreateApplicationInput: S.Schema<CreateApplicationInput>;
export interface CreateApplicationOutput {
    applicationId?: string;
}
export declare const CreateApplicationOutput: S.Schema<CreateApplicationOutput>;
export type DeploymentMode = "STANDARD" | "RESTART" | (string & {});
export declare const DeploymentMode: any;
export interface CreateDeploymentInput {
    applicationName: string;
    deploymentGroupName?: string;
    revision?: RevisionLocation;
    deploymentConfigName?: string;
    description?: string;
    ignoreApplicationStopFailures?: boolean;
    targetInstances?: TargetInstances;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    updateOutdatedInstancesOnly?: boolean;
    fileExistsBehavior?: FileExistsBehavior;
    deploymentMode?: DeploymentMode;
    overrideAlarmConfiguration?: AlarmConfiguration;
}
export declare const CreateDeploymentInput: S.Schema<CreateDeploymentInput>;
export interface CreateDeploymentOutput {
    deploymentId?: string;
}
export declare const CreateDeploymentOutput: S.Schema<CreateDeploymentOutput>;
export type MinimumHealthyHostsType = "HOST_COUNT" | "FLEET_PERCENT" | (string & {});
export declare const MinimumHealthyHostsType: any;
export type MinimumHealthyHostsValue = number;
export interface MinimumHealthyHosts {
    type?: MinimumHealthyHostsType;
    value?: number;
}
export declare const MinimumHealthyHosts: S.Schema<MinimumHealthyHosts>;
export type TrafficRoutingType = "TimeBasedCanary" | "TimeBasedLinear" | "AllAtOnce" | (string & {});
export declare const TrafficRoutingType: any;
export type Percentage = number;
export type WaitTimeInMins = number;
export interface TimeBasedCanary {
    canaryPercentage?: number;
    canaryInterval?: number;
}
export declare const TimeBasedCanary: S.Schema<TimeBasedCanary>;
export interface TimeBasedLinear {
    linearPercentage?: number;
    linearInterval?: number;
}
export declare const TimeBasedLinear: S.Schema<TimeBasedLinear>;
export interface TrafficRoutingConfig {
    type?: TrafficRoutingType;
    timeBasedCanary?: TimeBasedCanary;
    timeBasedLinear?: TimeBasedLinear;
}
export declare const TrafficRoutingConfig: S.Schema<TrafficRoutingConfig>;
export type WaitTimeInSeconds = number;
export type MinimumHealthyHostsPerZoneType = "HOST_COUNT" | "FLEET_PERCENT" | (string & {});
export declare const MinimumHealthyHostsPerZoneType: any;
export type MinimumHealthyHostsPerZoneValue = number;
export interface MinimumHealthyHostsPerZone {
    type?: MinimumHealthyHostsPerZoneType;
    value?: number;
}
export declare const MinimumHealthyHostsPerZone: S.Schema<MinimumHealthyHostsPerZone>;
export interface ZonalConfig {
    firstZoneMonitorDurationInSeconds?: number;
    monitorDurationInSeconds?: number;
    minimumHealthyHostsPerZone?: MinimumHealthyHostsPerZone;
}
export declare const ZonalConfig: S.Schema<ZonalConfig>;
export interface CreateDeploymentConfigInput {
    deploymentConfigName: string;
    minimumHealthyHosts?: MinimumHealthyHosts;
    trafficRoutingConfig?: TrafficRoutingConfig;
    computePlatform?: ComputePlatform;
    zonalConfig?: ZonalConfig;
}
export declare const CreateDeploymentConfigInput: S.Schema<CreateDeploymentConfigInput>;
export type DeploymentConfigId = string;
export interface CreateDeploymentConfigOutput {
    deploymentConfigId?: string;
}
export declare const CreateDeploymentConfigOutput: S.Schema<CreateDeploymentConfigOutput>;
export interface CreateDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
    deploymentConfigName?: string;
    ec2TagFilters?: EC2TagFilter[];
    onPremisesInstanceTagFilters?: TagFilter[];
    autoScalingGroups?: string[];
    serviceRoleArn: string;
    triggerConfigurations?: TriggerConfig[];
    alarmConfiguration?: AlarmConfiguration;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy;
    deploymentStyle?: DeploymentStyle;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    ec2TagSet?: EC2TagSet;
    ecsServices?: ECSService[];
    onPremisesTagSet?: OnPremisesTagSet;
    tags?: Tag[];
    terminationHookEnabled?: boolean;
}
export declare const CreateDeploymentGroupInput: S.Schema<CreateDeploymentGroupInput>;
export interface CreateDeploymentGroupOutput {
    deploymentGroupId?: string;
}
export declare const CreateDeploymentGroupOutput: S.Schema<CreateDeploymentGroupOutput>;
export interface DeleteApplicationInput {
    applicationName: string;
}
export declare const DeleteApplicationInput: S.Schema<DeleteApplicationInput>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export interface DeleteDeploymentConfigInput {
    deploymentConfigName: string;
}
export declare const DeleteDeploymentConfigInput: S.Schema<DeleteDeploymentConfigInput>;
export interface DeleteDeploymentConfigResponse {
}
export declare const DeleteDeploymentConfigResponse: S.Schema<DeleteDeploymentConfigResponse>;
export interface DeleteDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
}
export declare const DeleteDeploymentGroupInput: S.Schema<DeleteDeploymentGroupInput>;
export interface DeleteDeploymentGroupOutput {
    hooksNotCleanedUp?: AutoScalingGroup[];
}
export declare const DeleteDeploymentGroupOutput: S.Schema<DeleteDeploymentGroupOutput>;
export interface DeleteGitHubAccountTokenInput {
    tokenName?: string;
}
export declare const DeleteGitHubAccountTokenInput: S.Schema<DeleteGitHubAccountTokenInput>;
export interface DeleteGitHubAccountTokenOutput {
    tokenName?: string;
}
export declare const DeleteGitHubAccountTokenOutput: S.Schema<DeleteGitHubAccountTokenOutput>;
export interface DeleteResourcesByExternalIdInput {
    externalId?: string;
}
export declare const DeleteResourcesByExternalIdInput: S.Schema<DeleteResourcesByExternalIdInput>;
export interface DeleteResourcesByExternalIdOutput {
}
export declare const DeleteResourcesByExternalIdOutput: S.Schema<DeleteResourcesByExternalIdOutput>;
export interface DeregisterOnPremisesInstanceInput {
    instanceName: string;
}
export declare const DeregisterOnPremisesInstanceInput: S.Schema<DeregisterOnPremisesInstanceInput>;
export interface DeregisterOnPremisesInstanceResponse {
}
export declare const DeregisterOnPremisesInstanceResponse: S.Schema<DeregisterOnPremisesInstanceResponse>;
export interface GetApplicationInput {
    applicationName: string;
}
export declare const GetApplicationInput: S.Schema<GetApplicationInput>;
export interface GetApplicationOutput {
    application?: ApplicationInfo;
}
export declare const GetApplicationOutput: S.Schema<GetApplicationOutput>;
export interface GetApplicationRevisionInput {
    applicationName: string;
    revision: RevisionLocation;
}
export declare const GetApplicationRevisionInput: S.Schema<GetApplicationRevisionInput>;
export interface GetApplicationRevisionOutput {
    applicationName?: string;
    revision?: RevisionLocation;
    revisionInfo?: GenericRevisionInfo;
}
export declare const GetApplicationRevisionOutput: S.Schema<GetApplicationRevisionOutput>;
export interface GetDeploymentInput {
    deploymentId: string;
}
export declare const GetDeploymentInput: S.Schema<GetDeploymentInput>;
export interface GetDeploymentOutput {
    deploymentInfo?: DeploymentInfo;
}
export declare const GetDeploymentOutput: S.Schema<GetDeploymentOutput>;
export interface GetDeploymentConfigInput {
    deploymentConfigName: string;
}
export declare const GetDeploymentConfigInput: S.Schema<GetDeploymentConfigInput>;
export interface DeploymentConfigInfo {
    deploymentConfigId?: string;
    deploymentConfigName?: string;
    minimumHealthyHosts?: MinimumHealthyHosts;
    createTime?: Date;
    computePlatform?: ComputePlatform;
    trafficRoutingConfig?: TrafficRoutingConfig;
    zonalConfig?: ZonalConfig;
}
export declare const DeploymentConfigInfo: S.Schema<DeploymentConfigInfo>;
export interface GetDeploymentConfigOutput {
    deploymentConfigInfo?: DeploymentConfigInfo;
}
export declare const GetDeploymentConfigOutput: S.Schema<GetDeploymentConfigOutput>;
export interface GetDeploymentGroupInput {
    applicationName: string;
    deploymentGroupName: string;
}
export declare const GetDeploymentGroupInput: S.Schema<GetDeploymentGroupInput>;
export interface GetDeploymentGroupOutput {
    deploymentGroupInfo?: DeploymentGroupInfo;
}
export declare const GetDeploymentGroupOutput: S.Schema<GetDeploymentGroupOutput>;
export interface GetDeploymentInstanceInput {
    deploymentId: string;
    instanceId: string;
}
export declare const GetDeploymentInstanceInput: S.Schema<GetDeploymentInstanceInput>;
export interface GetDeploymentInstanceOutput {
    instanceSummary?: InstanceSummary;
}
export declare const GetDeploymentInstanceOutput: S.Schema<GetDeploymentInstanceOutput>;
export interface GetDeploymentTargetInput {
    deploymentId: string;
    targetId: string;
}
export declare const GetDeploymentTargetInput: S.Schema<GetDeploymentTargetInput>;
export interface GetDeploymentTargetOutput {
    deploymentTarget?: DeploymentTarget;
}
export declare const GetDeploymentTargetOutput: S.Schema<GetDeploymentTargetOutput>;
export interface GetOnPremisesInstanceInput {
    instanceName: string;
}
export declare const GetOnPremisesInstanceInput: S.Schema<GetOnPremisesInstanceInput>;
export interface GetOnPremisesInstanceOutput {
    instanceInfo?: InstanceInfo;
}
export declare const GetOnPremisesInstanceOutput: S.Schema<GetOnPremisesInstanceOutput>;
export type ApplicationRevisionSortBy = "registerTime" | "firstUsedTime" | "lastUsedTime" | (string & {});
export declare const ApplicationRevisionSortBy: any;
export type SortOrder = "ascending" | "descending" | (string & {});
export declare const SortOrder: any;
export type ListStateFilterAction = "include" | "exclude" | "ignore" | (string & {});
export declare const ListStateFilterAction: any;
export type NextToken = string;
export interface ListApplicationRevisionsInput {
    applicationName: string;
    sortBy?: ApplicationRevisionSortBy;
    sortOrder?: SortOrder;
    s3Bucket?: string;
    s3KeyPrefix?: string;
    deployed?: ListStateFilterAction;
    nextToken?: string;
}
export declare const ListApplicationRevisionsInput: S.Schema<ListApplicationRevisionsInput>;
export interface ListApplicationRevisionsOutput {
    revisions?: RevisionLocation[];
    nextToken?: string;
}
export declare const ListApplicationRevisionsOutput: S.Schema<ListApplicationRevisionsOutput>;
export interface ListApplicationsInput {
    nextToken?: string;
}
export declare const ListApplicationsInput: S.Schema<ListApplicationsInput>;
export interface ListApplicationsOutput {
    applications?: string[];
    nextToken?: string;
}
export declare const ListApplicationsOutput: S.Schema<ListApplicationsOutput>;
export interface ListDeploymentConfigsInput {
    nextToken?: string;
}
export declare const ListDeploymentConfigsInput: S.Schema<ListDeploymentConfigsInput>;
export type DeploymentConfigsList = string[];
export declare const DeploymentConfigsList: any;
export interface ListDeploymentConfigsOutput {
    deploymentConfigsList?: string[];
    nextToken?: string;
}
export declare const ListDeploymentConfigsOutput: S.Schema<ListDeploymentConfigsOutput>;
export interface ListDeploymentGroupsInput {
    applicationName: string;
    nextToken?: string;
}
export declare const ListDeploymentGroupsInput: S.Schema<ListDeploymentGroupsInput>;
export interface ListDeploymentGroupsOutput {
    applicationName?: string;
    deploymentGroups?: string[];
    nextToken?: string;
}
export declare const ListDeploymentGroupsOutput: S.Schema<ListDeploymentGroupsOutput>;
export type InstanceStatusList = InstanceStatus[];
export declare const InstanceStatusList: any;
export type InstanceTypeList = InstanceType[];
export declare const InstanceTypeList: any;
export interface ListDeploymentInstancesInput {
    deploymentId: string;
    nextToken?: string;
    instanceStatusFilter?: InstanceStatus[];
    instanceTypeFilter?: InstanceType[];
}
export declare const ListDeploymentInstancesInput: S.Schema<ListDeploymentInstancesInput>;
export interface ListDeploymentInstancesOutput {
    instancesList?: string[];
    nextToken?: string;
}
export declare const ListDeploymentInstancesOutput: S.Schema<ListDeploymentInstancesOutput>;
export type DeploymentStatusList = DeploymentStatus[];
export declare const DeploymentStatusList: any;
export interface TimeRange {
    start?: Date;
    end?: Date;
}
export declare const TimeRange: S.Schema<TimeRange>;
export interface ListDeploymentsInput {
    applicationName?: string;
    deploymentGroupName?: string;
    externalId?: string;
    includeOnlyStatuses?: DeploymentStatus[];
    createTimeRange?: TimeRange;
    nextToken?: string;
}
export declare const ListDeploymentsInput: S.Schema<ListDeploymentsInput>;
export interface ListDeploymentsOutput {
    deployments?: string[];
    nextToken?: string;
}
export declare const ListDeploymentsOutput: S.Schema<ListDeploymentsOutput>;
export type TargetFilterName = "TargetStatus" | "ServerInstanceLabel" | (string & {});
export declare const TargetFilterName: any;
export type FilterValue = string;
export type FilterValueList = string[];
export declare const FilterValueList: any;
export type TargetFilters = {
    [key in TargetFilterName]?: string[];
};
export declare const TargetFilters: any;
export interface ListDeploymentTargetsInput {
    deploymentId: string;
    nextToken?: string;
    targetFilters?: {
        [key: string]: string[] | undefined;
    };
}
export declare const ListDeploymentTargetsInput: S.Schema<ListDeploymentTargetsInput>;
export interface ListDeploymentTargetsOutput {
    targetIds?: string[];
    nextToken?: string;
}
export declare const ListDeploymentTargetsOutput: S.Schema<ListDeploymentTargetsOutput>;
export interface ListGitHubAccountTokenNamesInput {
    nextToken?: string;
}
export declare const ListGitHubAccountTokenNamesInput: S.Schema<ListGitHubAccountTokenNamesInput>;
export type GitHubAccountTokenNameList = string[];
export declare const GitHubAccountTokenNameList: any;
export interface ListGitHubAccountTokenNamesOutput {
    tokenNameList?: string[];
    nextToken?: string;
}
export declare const ListGitHubAccountTokenNamesOutput: S.Schema<ListGitHubAccountTokenNamesOutput>;
export type RegistrationStatus = "Registered" | "Deregistered" | (string & {});
export declare const RegistrationStatus: any;
export interface ListOnPremisesInstancesInput {
    registrationStatus?: RegistrationStatus;
    tagFilters?: TagFilter[];
    nextToken?: string;
}
export declare const ListOnPremisesInstancesInput: S.Schema<ListOnPremisesInstancesInput>;
export interface ListOnPremisesInstancesOutput {
    instanceNames?: string[];
    nextToken?: string;
}
export declare const ListOnPremisesInstancesOutput: S.Schema<ListOnPremisesInstancesOutput>;
export type Arn = string;
export interface ListTagsForResourceInput {
    ResourceArn: string;
    NextToken?: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    Tags?: Tag[];
    NextToken?: string;
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export type LifecycleEventHookExecutionId = string;
export interface PutLifecycleEventHookExecutionStatusInput {
    deploymentId?: string;
    lifecycleEventHookExecutionId?: string;
    status?: LifecycleEventStatus;
}
export declare const PutLifecycleEventHookExecutionStatusInput: S.Schema<PutLifecycleEventHookExecutionStatusInput>;
export interface PutLifecycleEventHookExecutionStatusOutput {
    lifecycleEventHookExecutionId?: string;
}
export declare const PutLifecycleEventHookExecutionStatusOutput: S.Schema<PutLifecycleEventHookExecutionStatusOutput>;
export interface RegisterApplicationRevisionInput {
    applicationName: string;
    description?: string;
    revision: RevisionLocation;
}
export declare const RegisterApplicationRevisionInput: S.Schema<RegisterApplicationRevisionInput>;
export interface RegisterApplicationRevisionResponse {
}
export declare const RegisterApplicationRevisionResponse: S.Schema<RegisterApplicationRevisionResponse>;
export interface RegisterOnPremisesInstanceInput {
    instanceName: string;
    iamSessionArn?: string;
    iamUserArn?: string;
}
export declare const RegisterOnPremisesInstanceInput: S.Schema<RegisterOnPremisesInstanceInput>;
export interface RegisterOnPremisesInstanceResponse {
}
export declare const RegisterOnPremisesInstanceResponse: S.Schema<RegisterOnPremisesInstanceResponse>;
export interface RemoveTagsFromOnPremisesInstancesInput {
    tags: Tag[];
    instanceNames: string[];
}
export declare const RemoveTagsFromOnPremisesInstancesInput: S.Schema<RemoveTagsFromOnPremisesInstancesInput>;
export interface RemoveTagsFromOnPremisesInstancesResponse {
}
export declare const RemoveTagsFromOnPremisesInstancesResponse: S.Schema<RemoveTagsFromOnPremisesInstancesResponse>;
export interface SkipWaitTimeForInstanceTerminationInput {
    deploymentId?: string;
}
export declare const SkipWaitTimeForInstanceTerminationInput: S.Schema<SkipWaitTimeForInstanceTerminationInput>;
export interface SkipWaitTimeForInstanceTerminationResponse {
}
export declare const SkipWaitTimeForInstanceTerminationResponse: S.Schema<SkipWaitTimeForInstanceTerminationResponse>;
export interface StopDeploymentInput {
    deploymentId: string;
    autoRollbackEnabled?: boolean;
}
export declare const StopDeploymentInput: S.Schema<StopDeploymentInput>;
export type StopStatus = "Pending" | "Succeeded" | (string & {});
export declare const StopStatus: any;
export type Message = string;
export interface StopDeploymentOutput {
    status?: StopStatus;
    statusMessage?: string;
}
export declare const StopDeploymentOutput: S.Schema<StopDeploymentOutput>;
export interface TagResourceInput {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceOutput {
}
export declare const TagResourceOutput: S.Schema<TagResourceOutput>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceOutput {
}
export declare const UntagResourceOutput: S.Schema<UntagResourceOutput>;
export interface UpdateApplicationInput {
    applicationName?: string;
    newApplicationName?: string;
}
export declare const UpdateApplicationInput: S.Schema<UpdateApplicationInput>;
export interface UpdateApplicationResponse {
}
export declare const UpdateApplicationResponse: S.Schema<UpdateApplicationResponse>;
export interface UpdateDeploymentGroupInput {
    applicationName: string;
    currentDeploymentGroupName: string;
    newDeploymentGroupName?: string;
    deploymentConfigName?: string;
    ec2TagFilters?: EC2TagFilter[];
    onPremisesInstanceTagFilters?: TagFilter[];
    autoScalingGroups?: string[];
    serviceRoleArn?: string;
    triggerConfigurations?: TriggerConfig[];
    alarmConfiguration?: AlarmConfiguration;
    autoRollbackConfiguration?: AutoRollbackConfiguration;
    outdatedInstancesStrategy?: OutdatedInstancesStrategy;
    deploymentStyle?: DeploymentStyle;
    blueGreenDeploymentConfiguration?: BlueGreenDeploymentConfiguration;
    loadBalancerInfo?: LoadBalancerInfo;
    ec2TagSet?: EC2TagSet;
    ecsServices?: ECSService[];
    onPremisesTagSet?: OnPremisesTagSet;
    terminationHookEnabled?: boolean;
}
export declare const UpdateDeploymentGroupInput: S.Schema<UpdateDeploymentGroupInput>;
export interface UpdateDeploymentGroupOutput {
    hooksNotCleanedUp?: AutoScalingGroup[];
}
export declare const UpdateDeploymentGroupOutput: S.Schema<UpdateDeploymentGroupOutput>;
export type AddTagsToOnPremisesInstancesError = InstanceLimitExceededException | InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | InvalidTagException | TagLimitExceededException | TagRequiredException | CommonErrors;
/**
 * Adds tags to on-premises instances.
 */
export declare const addTagsToOnPremisesInstances: API.OperationMethod<AddTagsToOnPremisesInstancesInput, AddTagsToOnPremisesInstancesResponse, AddTagsToOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type BatchGetApplicationRevisionsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | InvalidApplicationNameException | InvalidRevisionException | RevisionRequiredException | CommonErrors;
/**
 * Gets information about one or more application revisions. The maximum number of
 * application revisions that can be returned is 25.
 */
export declare const batchGetApplicationRevisions: API.OperationMethod<BatchGetApplicationRevisionsInput, BatchGetApplicationRevisionsOutput, BatchGetApplicationRevisionsError, Credentials | HttpClient.HttpClient>;
export type BatchGetApplicationsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | InvalidApplicationNameException | CommonErrors;
/**
 * Gets information about one or more applications. The maximum number of applications
 * that can be returned is 100.
 */
export declare const batchGetApplications: API.OperationMethod<BatchGetApplicationsInput, BatchGetApplicationsOutput, BatchGetApplicationsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentGroupsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BatchLimitExceededException | DeploymentConfigDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | CommonErrors;
/**
 * Gets information about one or more deployment groups.
 */
export declare const batchGetDeploymentGroups: API.OperationMethod<BatchGetDeploymentGroupsInput, BatchGetDeploymentGroupsOutput, BatchGetDeploymentGroupsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentInstancesError = BatchLimitExceededException | DeploymentDoesNotExistException | DeploymentIdRequiredException | InstanceIdRequiredException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidInstanceNameException | CommonErrors;
/**
 * This method works, but is deprecated. Use `BatchGetDeploymentTargets`
 * instead.
 *
 * Returns an array of one or more instances associated with a deployment. This method
 * works with EC2/On-premises and Lambda compute platforms. The newer
 * `BatchGetDeploymentTargets` works with all compute platforms. The maximum
 * number of instances that can be returned is 25.
 */
export declare const batchGetDeploymentInstances: API.OperationMethod<BatchGetDeploymentInstancesInput, BatchGetDeploymentInstancesOutput, BatchGetDeploymentInstancesError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentsError = BatchLimitExceededException | DeploymentIdRequiredException | InvalidDeploymentIdException | CommonErrors;
/**
 * Gets information about one or more deployments. The maximum number of deployments that
 * can be returned is 25.
 */
export declare const batchGetDeployments: API.OperationMethod<BatchGetDeploymentsInput, BatchGetDeploymentsOutput, BatchGetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type BatchGetDeploymentTargetsError = DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | DeploymentTargetDoesNotExistException | DeploymentTargetIdRequiredException | DeploymentTargetListSizeExceededException | InstanceDoesNotExistException | InvalidDeploymentIdException | InvalidDeploymentTargetIdException | CommonErrors;
/**
 * Returns an array of one or more targets associated with a deployment. This method
 * works with all compute types and should be used instead of the deprecated
 * `BatchGetDeploymentInstances`. The maximum number of targets that can be
 * returned is 25.
 *
 * The type of targets returned depends on the deployment's compute platform or
 * deployment method:
 *
 * - **EC2/On-premises**: Information about Amazon EC2 instance targets.
 *
 * - **Lambda**: Information about
 * Lambda functions targets.
 *
 * - **Amazon ECS**: Information about Amazon ECS service targets.
 *
 * - **CloudFormation**: Information about
 * targets of blue/green deployments initiated by a CloudFormation stack
 * update.
 */
export declare const batchGetDeploymentTargets: API.OperationMethod<BatchGetDeploymentTargetsInput, BatchGetDeploymentTargetsOutput, BatchGetDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type BatchGetOnPremisesInstancesError = BatchLimitExceededException | InstanceNameRequiredException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about one or more on-premises instances. The maximum number of
 * on-premises instances that can be returned is 25.
 */
export declare const batchGetOnPremisesInstances: API.OperationMethod<BatchGetOnPremisesInstancesInput, BatchGetOnPremisesInstancesOutput, BatchGetOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type ContinueDeploymentError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentIsNotInReadyStateException | InvalidDeploymentIdException | InvalidDeploymentStatusException | InvalidDeploymentWaitTypeException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * For a blue/green deployment, starts the process of rerouting traffic from instances in
 * the original environment to instances in the replacement environment without waiting for
 * a specified wait time to elapse. (Traffic rerouting, which is achieved by registering
 * instances in the replacement environment with the load balancer, can start as soon as
 * all instances have a status of Ready.)
 */
export declare const continueDeployment: API.OperationMethod<ContinueDeploymentInput, ContinueDeploymentResponse, ContinueDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ApplicationAlreadyExistsException | ApplicationLimitExceededException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidComputePlatformException | InvalidTagsToAddException | ThrottlingException | CommonErrors;
/**
 * Creates an application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationInput, CreateApplicationOutput, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | DeploymentLimitExceededException | DescriptionTooLongException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidECSServiceException | InvalidFileExistsBehaviorException | InvalidGitHubAccountTokenException | InvalidIgnoreApplicationStopFailuresValueException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidRevisionException | InvalidRoleException | InvalidTargetInstancesException | InvalidTrafficRoutingConfigurationException | InvalidUpdateOutdatedInstancesOnlyValueException | RevisionDoesNotExistException | RevisionRequiredException | ThrottlingException | CommonErrors;
/**
 * Deploys an application revision through the specified deployment group.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentInput, CreateDeploymentOutput, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentConfigError = DeploymentConfigAlreadyExistsException | DeploymentConfigLimitExceededException | DeploymentConfigNameRequiredException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | InvalidMinimumHealthyHostValueException | InvalidTrafficRoutingConfigurationException | InvalidZonalDeploymentConfigurationException | CommonErrors;
/**
 * Creates a deployment configuration.
 */
export declare const createDeploymentConfig: API.OperationMethod<CreateDeploymentConfigInput, CreateDeploymentConfigOutput, CreateDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentGroupError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupAlreadyExistsException | DeploymentGroupLimitExceededException | DeploymentGroupNameRequiredException | ECSServiceMappingLimitExceededException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidBlueGreenDeploymentConfigurationException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStyleException | InvalidEC2TagCombinationException | InvalidEC2TagException | InvalidECSServiceException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidOnPremisesTagCombinationException | InvalidRoleException | InvalidTagException | InvalidTagsToAddException | InvalidTargetGroupPairException | InvalidTrafficRoutingConfigurationException | InvalidTriggerConfigException | LifecycleHookLimitExceededException | RoleRequiredException | TagSetListLimitExceededException | ThrottlingException | TriggerTargetsLimitExceededException | CommonErrors;
/**
 * Creates a deployment group to which application revisions are deployed.
 */
export declare const createDeploymentGroup: API.OperationMethod<CreateDeploymentGroupInput, CreateDeploymentGroupOutput, CreateDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ApplicationNameRequiredException | InvalidApplicationNameException | InvalidRoleException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentConfigError = DeploymentConfigInUseException | DeploymentConfigNameRequiredException | InvalidDeploymentConfigNameException | InvalidOperationException | CommonErrors;
/**
 * Deletes a deployment configuration.
 *
 * A deployment configuration cannot be deleted if it is currently in use. Predefined
 * configurations cannot be deleted.
 */
export declare const deleteDeploymentConfig: API.OperationMethod<DeleteDeploymentConfigInput, DeleteDeploymentConfigResponse, DeleteDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentGroupError = ApplicationNameRequiredException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | InvalidRoleException | CommonErrors;
/**
 * Deletes a deployment group.
 */
export declare const deleteDeploymentGroup: API.OperationMethod<DeleteDeploymentGroupInput, DeleteDeploymentGroupOutput, DeleteDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGitHubAccountTokenError = GitHubAccountTokenDoesNotExistException | GitHubAccountTokenNameRequiredException | InvalidGitHubAccountTokenNameException | OperationNotSupportedException | ResourceValidationException | CommonErrors;
/**
 * Deletes a GitHub account connection.
 */
export declare const deleteGitHubAccountToken: API.OperationMethod<DeleteGitHubAccountTokenInput, DeleteGitHubAccountTokenOutput, DeleteGitHubAccountTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcesByExternalIdError = CommonErrors;
/**
 * Deletes resources linked to an external ID. This action only applies if you have
 * configured blue/green deployments through CloudFormation.
 *
 * It is not necessary to call this action directly. CloudFormation calls it
 * on your behalf when it needs to delete stack resources. This action is offered
 * publicly in case you need to delete resources to comply with General Data Protection
 * Regulation (GDPR) requirements.
 */
export declare const deleteResourcesByExternalId: API.OperationMethod<DeleteResourcesByExternalIdInput, DeleteResourcesByExternalIdOutput, DeleteResourcesByExternalIdError, Credentials | HttpClient.HttpClient>;
export type DeregisterOnPremisesInstanceError = InstanceNameRequiredException | InvalidInstanceNameException | CommonErrors;
/**
 * Deregisters an on-premises instance.
 */
export declare const deregisterOnPremisesInstance: API.OperationMethod<DeregisterOnPremisesInstanceInput, DeregisterOnPremisesInstanceResponse, DeregisterOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | CommonErrors;
/**
 * Gets information about an application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationInput, GetApplicationOutput, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationRevisionError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidRevisionException | RevisionDoesNotExistException | RevisionRequiredException | CommonErrors;
/**
 * Gets information about an application revision.
 */
export declare const getApplicationRevision: API.OperationMethod<GetApplicationRevisionInput, GetApplicationRevisionOutput, GetApplicationRevisionError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | CommonErrors;
/**
 * Gets information about a deployment.
 *
 * The `content` property of the `appSpecContent` object in
 * the returned revision is always null. Use `GetApplicationRevision` and
 * the `sha256` property of the returned `appSpecContent` object
 * to get the content of the deployment’s AppSpec file.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentInput, GetDeploymentOutput, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentConfigError = DeploymentConfigDoesNotExistException | DeploymentConfigNameRequiredException | InvalidComputePlatformException | InvalidDeploymentConfigNameException | CommonErrors;
/**
 * Gets information about a deployment configuration.
 */
export declare const getDeploymentConfig: API.OperationMethod<GetDeploymentConfigInput, GetDeploymentConfigOutput, GetDeploymentConfigError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentGroupError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | CommonErrors;
/**
 * Gets information about a deployment group.
 */
export declare const getDeploymentGroup: API.OperationMethod<GetDeploymentGroupInput, GetDeploymentGroupOutput, GetDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentInstanceError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InstanceDoesNotExistException | InstanceIdRequiredException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about an instance as part of a deployment.
 */
export declare const getDeploymentInstance: API.OperationMethod<GetDeploymentInstanceInput, GetDeploymentInstanceOutput, GetDeploymentInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentTargetError = DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | DeploymentTargetDoesNotExistException | DeploymentTargetIdRequiredException | InvalidDeploymentIdException | InvalidDeploymentTargetIdException | InvalidInstanceNameException | CommonErrors;
/**
 * Returns information about a deployment target.
 */
export declare const getDeploymentTarget: API.OperationMethod<GetDeploymentTargetInput, GetDeploymentTargetOutput, GetDeploymentTargetError, Credentials | HttpClient.HttpClient>;
export type GetOnPremisesInstanceError = InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | CommonErrors;
/**
 * Gets information about an on-premises instance.
 */
export declare const getOnPremisesInstance: API.OperationMethod<GetOnPremisesInstanceInput, GetOnPremisesInstanceOutput, GetOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type ListApplicationRevisionsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | BucketNameFilterRequiredException | InvalidApplicationNameException | InvalidBucketNameFilterException | InvalidDeployedStateFilterException | InvalidKeyPrefixFilterException | InvalidNextTokenException | InvalidSortByException | InvalidSortOrderException | CommonErrors;
/**
 * Lists information about revisions for an application.
 */
export declare const listApplicationRevisions: API.PaginatedOperationMethod<ListApplicationRevisionsInput, ListApplicationRevisionsOutput, ListApplicationRevisionsError, Credentials | HttpClient.HttpClient, RevisionLocation>;
export type ListApplicationsError = InvalidNextTokenException | CommonErrors;
/**
 * Lists the applications registered with the user or Amazon Web Services account.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsInput, ListApplicationsOutput, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationName>;
export type ListDeploymentConfigsError = InvalidNextTokenException | CommonErrors;
/**
 * Lists the deployment configurations with the user or Amazon Web Services account.
 */
export declare const listDeploymentConfigs: API.PaginatedOperationMethod<ListDeploymentConfigsInput, ListDeploymentConfigsOutput, ListDeploymentConfigsError, Credentials | HttpClient.HttpClient, DeploymentConfigName>;
export type ListDeploymentGroupsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | InvalidNextTokenException | CommonErrors;
/**
 * Lists the deployment groups for an application registered with the Amazon Web Services
 * user or Amazon Web Services account.
 */
export declare const listDeploymentGroups: API.PaginatedOperationMethod<ListDeploymentGroupsInput, ListDeploymentGroupsOutput, ListDeploymentGroupsError, Credentials | HttpClient.HttpClient, DeploymentGroupName>;
export type ListDeploymentInstancesError = ApplicationDoesNotExistException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidComputePlatformException | InvalidDeploymentIdException | InvalidDeploymentInstanceTypeException | InvalidInstanceStatusException | InvalidInstanceTypeException | InvalidNextTokenException | InvalidTargetFilterNameException | CommonErrors;
/**
 * The newer `BatchGetDeploymentTargets` should be used instead because
 * it works with all compute types. `ListDeploymentInstances` throws an
 * exception if it is used with a compute platform other than EC2/On-premises or
 * Lambda.
 *
 * Lists the instance for a deployment associated with the user or Amazon Web Services account.
 */
export declare const listDeploymentInstances: API.PaginatedOperationMethod<ListDeploymentInstancesInput, ListDeploymentInstancesOutput, ListDeploymentInstancesError, Credentials | HttpClient.HttpClient, InstanceId>;
export type ListDeploymentsError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | InvalidApplicationNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStatusException | InvalidExternalIdException | InvalidInputException | InvalidNextTokenException | InvalidTimeRangeException | CommonErrors;
/**
 * Lists the deployments in a deployment group for an application registered with the
 * user or Amazon Web Services account.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsInput, ListDeploymentsOutput, ListDeploymentsError, Credentials | HttpClient.HttpClient, DeploymentId>;
export type ListDeploymentTargetsError = ApplicationDoesNotExistException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidDeploymentIdException | InvalidDeploymentInstanceTypeException | InvalidInstanceStatusException | InvalidInstanceTypeException | InvalidNextTokenException | InvalidTargetFilterNameException | CommonErrors;
/**
 * Returns an array of target IDs that are associated a deployment.
 */
export declare const listDeploymentTargets: API.OperationMethod<ListDeploymentTargetsInput, ListDeploymentTargetsOutput, ListDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type ListGitHubAccountTokenNamesError = InvalidNextTokenException | OperationNotSupportedException | ResourceValidationException | CommonErrors;
/**
 * Lists the names of stored connections to GitHub accounts.
 */
export declare const listGitHubAccountTokenNames: API.OperationMethod<ListGitHubAccountTokenNamesInput, ListGitHubAccountTokenNamesOutput, ListGitHubAccountTokenNamesError, Credentials | HttpClient.HttpClient>;
export type ListOnPremisesInstancesError = InvalidNextTokenException | InvalidRegistrationStatusException | InvalidTagFilterException | CommonErrors;
/**
 * Gets a list of names for one or more on-premises instances.
 *
 * Unless otherwise specified, both registered and deregistered on-premises instance
 * names are listed. To list only registered or deregistered on-premises instance names,
 * use the registration status parameter.
 */
export declare const listOnPremisesInstances: API.OperationMethod<ListOnPremisesInstancesInput, ListOnPremisesInstancesOutput, ListOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ArnNotSupportedException | InvalidArnException | ResourceArnRequiredException | CommonErrors;
/**
 * Returns a list of tags for the resource identified by a specified Amazon Resource
 * Name (ARN). Tags are used to organize and categorize your CodeDeploy resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutLifecycleEventHookExecutionStatusError = DeploymentDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | InvalidLifecycleEventHookExecutionIdException | InvalidLifecycleEventHookExecutionStatusException | LifecycleEventAlreadyCompletedException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * Sets the result of a Lambda validation function. The function validates
 * lifecycle hooks during a deployment that uses the Lambda or Amazon ECS compute platform. For Lambda deployments, the available
 * lifecycle hooks are `BeforeAllowTraffic` and `AfterAllowTraffic`.
 * For Amazon ECS deployments, the available lifecycle hooks are
 * `BeforeInstall`, `AfterInstall`,
 * `AfterAllowTestTraffic`, `BeforeAllowTraffic`, and
 * `AfterAllowTraffic`. Lambda validation functions return
 * `Succeeded` or `Failed`. For more information, see AppSpec 'hooks' Section for an Lambda Deployment and
 * AppSpec 'hooks' Section for an Amazon ECS Deployment.
 */
export declare const putLifecycleEventHookExecutionStatus: API.OperationMethod<PutLifecycleEventHookExecutionStatusInput, PutLifecycleEventHookExecutionStatusOutput, PutLifecycleEventHookExecutionStatusError, Credentials | HttpClient.HttpClient>;
export type RegisterApplicationRevisionError = ApplicationDoesNotExistException | ApplicationNameRequiredException | DescriptionTooLongException | InvalidApplicationNameException | InvalidRevisionException | RevisionRequiredException | CommonErrors;
/**
 * Registers with CodeDeploy a revision for the specified application.
 */
export declare const registerApplicationRevision: API.OperationMethod<RegisterApplicationRevisionInput, RegisterApplicationRevisionResponse, RegisterApplicationRevisionError, Credentials | HttpClient.HttpClient>;
export type RegisterOnPremisesInstanceError = IamArnRequiredException | IamSessionArnAlreadyRegisteredException | IamUserArnAlreadyRegisteredException | IamUserArnRequiredException | InstanceNameAlreadyRegisteredException | InstanceNameRequiredException | InvalidIamSessionArnException | InvalidIamUserArnException | InvalidInstanceNameException | MultipleIamArnsProvidedException | CommonErrors;
/**
 * Registers an on-premises instance.
 *
 * Only one IAM ARN (an IAM session ARN or IAM user ARN) is supported in the request. You cannot use both.
 */
export declare const registerOnPremisesInstance: API.OperationMethod<RegisterOnPremisesInstanceInput, RegisterOnPremisesInstanceResponse, RegisterOnPremisesInstanceError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromOnPremisesInstancesError = InstanceLimitExceededException | InstanceNameRequiredException | InstanceNotRegisteredException | InvalidInstanceNameException | InvalidTagException | TagLimitExceededException | TagRequiredException | CommonErrors;
/**
 * Removes one or more tags from one or more on-premises instances.
 */
export declare const removeTagsFromOnPremisesInstances: API.OperationMethod<RemoveTagsFromOnPremisesInstancesInput, RemoveTagsFromOnPremisesInstancesResponse, RemoveTagsFromOnPremisesInstancesError, Credentials | HttpClient.HttpClient>;
export type SkipWaitTimeForInstanceTerminationError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentIdRequiredException | DeploymentNotStartedException | InvalidDeploymentIdException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * In a blue/green deployment, overrides any specified wait time and starts terminating
 * instances immediately after the traffic routing is complete.
 */
export declare const skipWaitTimeForInstanceTermination: API.OperationMethod<SkipWaitTimeForInstanceTerminationInput, SkipWaitTimeForInstanceTerminationResponse, SkipWaitTimeForInstanceTerminationError, Credentials | HttpClient.HttpClient>;
export type StopDeploymentError = DeploymentAlreadyCompletedException | DeploymentDoesNotExistException | DeploymentGroupDoesNotExistException | DeploymentIdRequiredException | InvalidDeploymentIdException | UnsupportedActionForDeploymentTypeException | CommonErrors;
/**
 * Attempts to stop an ongoing deployment.
 */
export declare const stopDeployment: API.OperationMethod<StopDeploymentInput, StopDeploymentOutput, StopDeploymentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ApplicationDoesNotExistException | ArnNotSupportedException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | InvalidArnException | InvalidTagsToAddException | ResourceArnRequiredException | TagRequiredException | CommonErrors;
/**
 * Associates the list of tags in the input `Tags` parameter with the
 * resource identified by the `ResourceArn` input parameter.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ApplicationDoesNotExistException | ArnNotSupportedException | DeploymentConfigDoesNotExistException | DeploymentGroupDoesNotExistException | InvalidArnException | InvalidTagsToAddException | ResourceArnRequiredException | TagRequiredException | CommonErrors;
/**
 * Disassociates a resource from a list of tags. The resource is identified by the
 * `ResourceArn` input parameter. The tags are identified by the list of
 * keys in the `TagKeys` input parameter.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = ApplicationAlreadyExistsException | ApplicationDoesNotExistException | ApplicationNameRequiredException | InvalidApplicationNameException | CommonErrors;
/**
 * Changes the name of an application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentGroupError = AlarmsLimitExceededException | ApplicationDoesNotExistException | ApplicationNameRequiredException | DeploymentConfigDoesNotExistException | DeploymentGroupAlreadyExistsException | DeploymentGroupDoesNotExistException | DeploymentGroupNameRequiredException | ECSServiceMappingLimitExceededException | InvalidAlarmConfigException | InvalidApplicationNameException | InvalidAutoRollbackConfigException | InvalidAutoScalingGroupException | InvalidBlueGreenDeploymentConfigurationException | InvalidDeploymentConfigNameException | InvalidDeploymentGroupNameException | InvalidDeploymentStyleException | InvalidEC2TagCombinationException | InvalidEC2TagException | InvalidECSServiceException | InvalidInputException | InvalidLoadBalancerInfoException | InvalidOnPremisesTagCombinationException | InvalidRoleException | InvalidTagException | InvalidTargetGroupPairException | InvalidTrafficRoutingConfigurationException | InvalidTriggerConfigException | LifecycleHookLimitExceededException | TagSetListLimitExceededException | ThrottlingException | TriggerTargetsLimitExceededException | CommonErrors;
/**
 * Changes information about a deployment group.
 */
export declare const updateDeploymentGroup: API.OperationMethod<UpdateDeploymentGroupInput, UpdateDeploymentGroupOutput, UpdateDeploymentGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codedeploy.d.ts.map