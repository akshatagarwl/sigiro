import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConcurrentUpdateException_base: S.Class<ConcurrentUpdateException, S.TaggedStruct<"ConcurrentUpdateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ConcurrentUpdateException extends /*@__PURE__*/ ConcurrentUpdateException_base {
}
declare const InternalServiceException_base: S.Class<InternalServiceException, S.TaggedStruct<"InternalServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ObjectNotFoundException_base: S.Class<ObjectNotFoundException, S.TaggedStruct<"ObjectNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectNotFoundException extends /*@__PURE__*/ ObjectNotFoundException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ScalingPlanName = string;
export type XmlString = string;
export type XmlStringMaxLen128 = string;
export type XmlStringMaxLen256 = string;
export type TagValues = string[];
export declare const TagValues: any;
export interface TagFilter {
    Key?: string;
    Values?: string[];
}
export declare const TagFilter: S.Schema<TagFilter>;
export type TagFilters = TagFilter[];
export declare const TagFilters: any;
export interface ApplicationSource {
    CloudFormationStackARN?: string;
    TagFilters?: TagFilter[];
}
export declare const ApplicationSource: S.Schema<ApplicationSource>;
export type ServiceNamespace = "autoscaling" | "ecs" | "ec2" | "rds" | "dynamodb" | (string & {});
export declare const ServiceNamespace: any;
export type ResourceIdMaxLen1600 = string;
export type ScalableDimension = "autoscaling:autoScalingGroup:DesiredCapacity" | "ecs:service:DesiredCount" | "ec2:spot-fleet-request:TargetCapacity" | "rds:cluster:ReadReplicaCount" | "dynamodb:table:ReadCapacityUnits" | "dynamodb:table:WriteCapacityUnits" | "dynamodb:index:ReadCapacityUnits" | "dynamodb:index:WriteCapacityUnits" | (string & {});
export declare const ScalableDimension: any;
export type ResourceCapacity = number;
export type ScalingMetricType = "ASGAverageCPUUtilization" | "ASGAverageNetworkIn" | "ASGAverageNetworkOut" | "DynamoDBReadCapacityUtilization" | "DynamoDBWriteCapacityUtilization" | "ECSServiceAverageCPUUtilization" | "ECSServiceAverageMemoryUtilization" | "ALBRequestCountPerTarget" | "RDSReaderAverageCPUUtilization" | "RDSReaderAverageDatabaseConnections" | "EC2SpotFleetRequestAverageCPUUtilization" | "EC2SpotFleetRequestAverageNetworkIn" | "EC2SpotFleetRequestAverageNetworkOut" | (string & {});
export declare const ScalingMetricType: any;
export type ResourceLabel = string;
export interface PredefinedScalingMetricSpecification {
    PredefinedScalingMetricType: ScalingMetricType;
    ResourceLabel?: string;
}
export declare const PredefinedScalingMetricSpecification: S.Schema<PredefinedScalingMetricSpecification>;
export type MetricName = string;
export type MetricNamespace = string;
export type MetricDimensionName = string;
export type MetricDimensionValue = string;
export interface MetricDimension {
    Name: string;
    Value: string;
}
export declare const MetricDimension: S.Schema<MetricDimension>;
export type MetricDimensions = MetricDimension[];
export declare const MetricDimensions: any;
export type MetricStatistic = "Average" | "Minimum" | "Maximum" | "SampleCount" | "Sum" | (string & {});
export declare const MetricStatistic: any;
export type MetricUnit = string;
export interface CustomizedScalingMetricSpecification {
    MetricName: string;
    Namespace: string;
    Dimensions?: MetricDimension[];
    Statistic: MetricStatistic;
    Unit?: string;
}
export declare const CustomizedScalingMetricSpecification: S.Schema<CustomizedScalingMetricSpecification>;
export type MetricScale = number;
export type DisableScaleIn = boolean;
export type Cooldown = number;
export interface TargetTrackingConfiguration {
    PredefinedScalingMetricSpecification?: PredefinedScalingMetricSpecification;
    CustomizedScalingMetricSpecification?: CustomizedScalingMetricSpecification;
    TargetValue: number;
    DisableScaleIn?: boolean;
    ScaleOutCooldown?: number;
    ScaleInCooldown?: number;
    EstimatedInstanceWarmup?: number;
}
export declare const TargetTrackingConfiguration: S.Schema<TargetTrackingConfiguration>;
export type TargetTrackingConfigurations = TargetTrackingConfiguration[];
export declare const TargetTrackingConfigurations: any;
export type LoadMetricType = "ASGTotalCPUUtilization" | "ASGTotalNetworkIn" | "ASGTotalNetworkOut" | "ALBTargetGroupRequestCount" | (string & {});
export declare const LoadMetricType: any;
export interface PredefinedLoadMetricSpecification {
    PredefinedLoadMetricType: LoadMetricType;
    ResourceLabel?: string;
}
export declare const PredefinedLoadMetricSpecification: S.Schema<PredefinedLoadMetricSpecification>;
export interface CustomizedLoadMetricSpecification {
    MetricName: string;
    Namespace: string;
    Dimensions?: MetricDimension[];
    Statistic: MetricStatistic;
    Unit?: string;
}
export declare const CustomizedLoadMetricSpecification: S.Schema<CustomizedLoadMetricSpecification>;
export type ScheduledActionBufferTime = number;
export type PredictiveScalingMaxCapacityBehavior = "SetForecastCapacityToMaxCapacity" | "SetMaxCapacityToForecastCapacity" | "SetMaxCapacityAboveForecastCapacity" | (string & {});
export declare const PredictiveScalingMaxCapacityBehavior: any;
export type PredictiveScalingMode = "ForecastAndScale" | "ForecastOnly" | (string & {});
export declare const PredictiveScalingMode: any;
export type ScalingPolicyUpdateBehavior = "KeepExternalPolicies" | "ReplaceExternalPolicies" | (string & {});
export declare const ScalingPolicyUpdateBehavior: any;
export type DisableDynamicScaling = boolean;
export interface ScalingInstruction {
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    MinCapacity: number;
    MaxCapacity: number;
    TargetTrackingConfigurations: TargetTrackingConfiguration[];
    PredefinedLoadMetricSpecification?: PredefinedLoadMetricSpecification;
    CustomizedLoadMetricSpecification?: CustomizedLoadMetricSpecification;
    ScheduledActionBufferTime?: number;
    PredictiveScalingMaxCapacityBehavior?: PredictiveScalingMaxCapacityBehavior;
    PredictiveScalingMaxCapacityBuffer?: number;
    PredictiveScalingMode?: PredictiveScalingMode;
    ScalingPolicyUpdateBehavior?: ScalingPolicyUpdateBehavior;
    DisableDynamicScaling?: boolean;
}
export declare const ScalingInstruction: S.Schema<ScalingInstruction>;
export type ScalingInstructions = ScalingInstruction[];
export declare const ScalingInstructions: any;
export interface CreateScalingPlanRequest {
    ScalingPlanName: string;
    ApplicationSource: ApplicationSource;
    ScalingInstructions: ScalingInstruction[];
}
export declare const CreateScalingPlanRequest: S.Schema<CreateScalingPlanRequest>;
export type ScalingPlanVersion = number;
export interface CreateScalingPlanResponse {
    ScalingPlanVersion: number;
}
export declare const CreateScalingPlanResponse: S.Schema<CreateScalingPlanResponse>;
export interface DeleteScalingPlanRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
}
export declare const DeleteScalingPlanRequest: S.Schema<DeleteScalingPlanRequest>;
export interface DeleteScalingPlanResponse {
}
export declare const DeleteScalingPlanResponse: S.Schema<DeleteScalingPlanResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface DescribeScalingPlanResourcesRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeScalingPlanResourcesRequest: S.Schema<DescribeScalingPlanResourcesRequest>;
export type PolicyName = string;
export type PolicyType = "TargetTrackingScaling" | (string & {});
export declare const PolicyType: any;
export interface ScalingPolicy {
    PolicyName: string;
    PolicyType: PolicyType;
    TargetTrackingConfiguration?: TargetTrackingConfiguration;
}
export declare const ScalingPolicy: S.Schema<ScalingPolicy>;
export type ScalingPolicies = ScalingPolicy[];
export declare const ScalingPolicies: any;
export type ScalingStatusCode = "Inactive" | "PartiallyActive" | "Active" | (string & {});
export declare const ScalingStatusCode: any;
export interface ScalingPlanResource {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    ScalingPolicies?: ScalingPolicy[];
    ScalingStatusCode: ScalingStatusCode;
    ScalingStatusMessage?: string;
}
export declare const ScalingPlanResource: S.Schema<ScalingPlanResource>;
export type ScalingPlanResources = ScalingPlanResource[];
export declare const ScalingPlanResources: any;
export interface DescribeScalingPlanResourcesResponse {
    ScalingPlanResources?: ScalingPlanResource[];
    NextToken?: string;
}
export declare const DescribeScalingPlanResourcesResponse: S.Schema<DescribeScalingPlanResourcesResponse>;
export type ScalingPlanNames = string[];
export declare const ScalingPlanNames: any;
export type ApplicationSources = ApplicationSource[];
export declare const ApplicationSources: any;
export interface DescribeScalingPlansRequest {
    ScalingPlanNames?: string[];
    ScalingPlanVersion?: number;
    ApplicationSources?: ApplicationSource[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeScalingPlansRequest: S.Schema<DescribeScalingPlansRequest>;
export type ScalingPlanStatusCode = "Active" | "ActiveWithProblems" | "CreationInProgress" | "CreationFailed" | "DeletionInProgress" | "DeletionFailed" | "UpdateInProgress" | "UpdateFailed" | (string & {});
export declare const ScalingPlanStatusCode: any;
export interface ScalingPlan {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ApplicationSource: ApplicationSource;
    ScalingInstructions: ScalingInstruction[];
    StatusCode: ScalingPlanStatusCode;
    StatusMessage?: string;
    StatusStartTime?: Date;
    CreationTime?: Date;
}
export declare const ScalingPlan: S.Schema<ScalingPlan>;
export type ScalingPlans = ScalingPlan[];
export declare const ScalingPlans: any;
export interface DescribeScalingPlansResponse {
    ScalingPlans?: ScalingPlan[];
    NextToken?: string;
}
export declare const DescribeScalingPlansResponse: S.Schema<DescribeScalingPlansResponse>;
export type ForecastDataType = "CapacityForecast" | "LoadForecast" | "ScheduledActionMinCapacity" | "ScheduledActionMaxCapacity" | (string & {});
export declare const ForecastDataType: any;
export interface GetScalingPlanResourceForecastDataRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ServiceNamespace: ServiceNamespace;
    ResourceId: string;
    ScalableDimension: ScalableDimension;
    ForecastDataType: ForecastDataType;
    StartTime: Date;
    EndTime: Date;
}
export declare const GetScalingPlanResourceForecastDataRequest: S.Schema<GetScalingPlanResourceForecastDataRequest>;
export interface Datapoint {
    Timestamp?: Date;
    Value?: number;
}
export declare const Datapoint: S.Schema<Datapoint>;
export type Datapoints = Datapoint[];
export declare const Datapoints: any;
export interface GetScalingPlanResourceForecastDataResponse {
    Datapoints: Datapoint[];
}
export declare const GetScalingPlanResourceForecastDataResponse: S.Schema<GetScalingPlanResourceForecastDataResponse>;
export interface UpdateScalingPlanRequest {
    ScalingPlanName: string;
    ScalingPlanVersion: number;
    ApplicationSource?: ApplicationSource;
    ScalingInstructions?: ScalingInstruction[];
}
export declare const UpdateScalingPlanRequest: S.Schema<UpdateScalingPlanRequest>;
export interface UpdateScalingPlanResponse {
}
export declare const UpdateScalingPlanResponse: S.Schema<UpdateScalingPlanResponse>;
export type ErrorMessage = string;
export type CreateScalingPlanError = ConcurrentUpdateException | InternalServiceException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a scaling plan.
 */
export declare const createScalingPlan: API.OperationMethod<CreateScalingPlanRequest, CreateScalingPlanResponse, CreateScalingPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteScalingPlanError = ConcurrentUpdateException | InternalServiceException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified scaling plan.
 *
 * Deleting a scaling plan deletes the underlying ScalingInstruction for
 * all of the scalable resources that are covered by the plan.
 *
 * If the plan has launched resources or has scaling activities in progress, you must
 * delete those resources separately.
 */
export declare const deleteScalingPlan: API.OperationMethod<DeleteScalingPlanRequest, DeleteScalingPlanResponse, DeleteScalingPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeScalingPlanResourcesError = ConcurrentUpdateException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Describes the scalable resources in the specified scaling plan.
 */
export declare const describeScalingPlanResources: API.OperationMethod<DescribeScalingPlanResourcesRequest, DescribeScalingPlanResourcesResponse, DescribeScalingPlanResourcesError, Credentials | HttpClient.HttpClient>;
export type DescribeScalingPlansError = ConcurrentUpdateException | InternalServiceException | InvalidNextTokenException | ValidationException | CommonErrors;
/**
 * Describes one or more of your scaling plans.
 */
export declare const describeScalingPlans: API.OperationMethod<DescribeScalingPlansRequest, DescribeScalingPlansResponse, DescribeScalingPlansError, Credentials | HttpClient.HttpClient>;
export type GetScalingPlanResourceForecastDataError = InternalServiceException | ValidationException | CommonErrors;
/**
 * Retrieves the forecast data for a scalable resource.
 *
 * Capacity forecasts are represented as predicted values, or data points, that are
 * calculated using historical data points from a specified CloudWatch load metric. Data points are
 * available for up to 56 days.
 */
export declare const getScalingPlanResourceForecastData: API.OperationMethod<GetScalingPlanResourceForecastDataRequest, GetScalingPlanResourceForecastDataResponse, GetScalingPlanResourceForecastDataError, Credentials | HttpClient.HttpClient>;
export type UpdateScalingPlanError = ConcurrentUpdateException | InternalServiceException | ObjectNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the specified scaling plan.
 *
 * You cannot update a scaling plan if it is in the process of being created, updated, or
 * deleted.
 */
export declare const updateScalingPlan: API.OperationMethod<UpdateScalingPlanRequest, UpdateScalingPlanResponse, UpdateScalingPlanError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=auto-scaling-plans.d.ts.map