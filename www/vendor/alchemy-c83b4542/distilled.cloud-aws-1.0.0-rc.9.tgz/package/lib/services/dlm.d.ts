import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly Code: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
    readonly Code: any;
    readonly RequiredParameters: any;
    readonly MutuallyExclusiveParameters: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
    readonly Code: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly Code: any;
    readonly ResourceType: any;
    readonly ResourceIds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type ExecutionRoleArn = string;
export type PolicyDescription = string;
export type SettablePolicyStateValues = "ENABLED" | "DISABLED" | (string & {});
export declare const SettablePolicyStateValues: any;
export type PolicyTypeValues = "EBS_SNAPSHOT_MANAGEMENT" | "IMAGE_MANAGEMENT" | "EVENT_BASED_POLICY" | (string & {});
export declare const PolicyTypeValues: any;
export type ResourceTypeValues = "VOLUME" | "INSTANCE" | (string & {});
export declare const ResourceTypeValues: any;
export type ResourceTypeValuesList = ResourceTypeValues[];
export declare const ResourceTypeValuesList: any;
export type ResourceLocationValues = "CLOUD" | "OUTPOST" | "LOCAL_ZONE" | (string & {});
export declare const ResourceLocationValues: any;
export type ResourceLocationList = ResourceLocationValues[];
export declare const ResourceLocationList: any;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TargetTagList = Tag[];
export declare const TargetTagList: any;
export type ScheduleName = string;
export type CopyTags = boolean;
export type TagsToAddList = Tag[];
export declare const TagsToAddList: any;
export type VariableTagsList = Tag[];
export declare const VariableTagsList: any;
export type LocationValues = "CLOUD" | "OUTPOST_LOCAL" | "LOCAL_ZONE" | (string & {});
export declare const LocationValues: any;
export type Interval = number;
export type IntervalUnitValues = "HOURS" | (string & {});
export declare const IntervalUnitValues: any;
export type TimesList = string[];
export declare const TimesList: any;
export type CronExpression = string;
export type StageValues = "PRE" | "POST" | (string & {});
export declare const StageValues: any;
export type StagesList = StageValues[];
export declare const StagesList: any;
export type ExecutionHandlerServiceValues = "AWS_SYSTEMS_MANAGER" | (string & {});
export declare const ExecutionHandlerServiceValues: any;
export type ExecutionHandler = string;
export type ExecuteOperationOnScriptFailure = boolean;
export type ScriptExecutionTimeout = number;
export type ScriptMaximumRetryCount = number;
export interface Script {
    Stages?: StageValues[];
    ExecutionHandlerService?: ExecutionHandlerServiceValues;
    ExecutionHandler?: string;
    ExecuteOperationOnScriptFailure?: boolean;
    ExecutionTimeout?: number;
    MaximumRetryCount?: number;
}
export declare const Script: S.Schema<Script>;
export type ScriptsList = Script[];
export declare const ScriptsList: any;
export interface CreateRule {
    Location?: LocationValues;
    Interval?: number;
    IntervalUnit?: IntervalUnitValues;
    Times?: string[];
    CronExpression?: string;
    Scripts?: Script[];
}
export declare const CreateRule: S.Schema<CreateRule>;
export type StandardTierRetainRuleCount = number;
export type StandardTierRetainRuleInterval = number;
export type RetentionIntervalUnitValues = "DAYS" | "WEEKS" | "MONTHS" | "YEARS" | (string & {});
export declare const RetentionIntervalUnitValues: any;
export interface RetainRule {
    Count?: number;
    Interval?: number;
    IntervalUnit?: RetentionIntervalUnitValues;
}
export declare const RetainRule: S.Schema<RetainRule>;
export type Count = number;
export type AvailabilityZone = string;
export type AvailabilityZoneList = string[];
export declare const AvailabilityZoneList: any;
export type AvailabilityZoneId = string;
export type AvailabilityZoneIdList = string[];
export declare const AvailabilityZoneIdList: any;
export interface FastRestoreRule {
    Count?: number;
    Interval?: number;
    IntervalUnit?: RetentionIntervalUnitValues;
    AvailabilityZones?: string[];
    AvailabilityZoneIds?: string[];
}
export declare const FastRestoreRule: S.Schema<FastRestoreRule>;
export type TargetRegion = string;
export type Target = string;
export type Encrypted = boolean;
export type CmkArn = string;
export type CopyTagsNullable = boolean;
export interface CrossRegionCopyRetainRule {
    Interval?: number;
    IntervalUnit?: RetentionIntervalUnitValues;
}
export declare const CrossRegionCopyRetainRule: S.Schema<CrossRegionCopyRetainRule>;
export interface CrossRegionCopyDeprecateRule {
    Interval?: number;
    IntervalUnit?: RetentionIntervalUnitValues;
}
export declare const CrossRegionCopyDeprecateRule: S.Schema<CrossRegionCopyDeprecateRule>;
export interface CrossRegionCopyRule {
    TargetRegion?: string;
    Target?: string;
    Encrypted?: boolean;
    CmkArn?: string;
    CopyTags?: boolean;
    RetainRule?: CrossRegionCopyRetainRule;
    DeprecateRule?: CrossRegionCopyDeprecateRule;
}
export declare const CrossRegionCopyRule: S.Schema<CrossRegionCopyRule>;
export type CrossRegionCopyRules = CrossRegionCopyRule[];
export declare const CrossRegionCopyRules: any;
export type AwsAccountId = string;
export type ShareTargetAccountList = string[];
export declare const ShareTargetAccountList: any;
export interface ShareRule {
    TargetAccounts?: string[];
    UnshareInterval?: number;
    UnshareIntervalUnit?: RetentionIntervalUnitValues;
}
export declare const ShareRule: S.Schema<ShareRule>;
export type ShareRules = ShareRule[];
export declare const ShareRules: any;
export interface DeprecateRule {
    Count?: number;
    Interval?: number;
    IntervalUnit?: RetentionIntervalUnitValues;
}
export declare const DeprecateRule: S.Schema<DeprecateRule>;
export interface RetentionArchiveTier {
    Count?: number;
    Interval?: number;
    IntervalUnit?: RetentionIntervalUnitValues;
}
export declare const RetentionArchiveTier: S.Schema<RetentionArchiveTier>;
export interface ArchiveRetainRule {
    RetentionArchiveTier?: RetentionArchiveTier;
}
export declare const ArchiveRetainRule: S.Schema<ArchiveRetainRule>;
export interface ArchiveRule {
    RetainRule?: ArchiveRetainRule;
}
export declare const ArchiveRule: S.Schema<ArchiveRule>;
export interface Schedule {
    Name?: string;
    CopyTags?: boolean;
    TagsToAdd?: Tag[];
    VariableTags?: Tag[];
    CreateRule?: CreateRule;
    RetainRule?: RetainRule;
    FastRestoreRule?: FastRestoreRule;
    CrossRegionCopyRules?: CrossRegionCopyRule[];
    ShareRules?: ShareRule[];
    DeprecateRule?: DeprecateRule;
    ArchiveRule?: ArchiveRule;
}
export declare const Schedule: S.Schema<Schedule>;
export type ScheduleList = Schedule[];
export declare const ScheduleList: any;
export type ExcludeBootVolume = boolean;
export type NoReboot = boolean;
export type ExcludeDataVolumeTagList = Tag[];
export declare const ExcludeDataVolumeTagList: any;
export interface Parameters {
    ExcludeBootVolume?: boolean;
    NoReboot?: boolean;
    ExcludeDataVolumeTags?: Tag[];
}
export declare const Parameters: S.Schema<Parameters>;
export type EventSourceValues = "MANAGED_CWE" | (string & {});
export declare const EventSourceValues: any;
export type EventTypeValues = "shareSnapshot" | (string & {});
export declare const EventTypeValues: any;
export type SnapshotOwnerList = string[];
export declare const SnapshotOwnerList: any;
export type DescriptionRegex = string;
export interface EventParameters {
    EventType?: EventTypeValues;
    SnapshotOwner?: string[];
    DescriptionRegex?: string;
}
export declare const EventParameters: S.Schema<EventParameters>;
export interface EventSource {
    Type?: EventSourceValues;
    Parameters?: EventParameters;
}
export declare const EventSource: S.Schema<EventSource>;
export type ActionName = string;
export interface EncryptionConfiguration {
    Encrypted?: boolean;
    CmkArn?: string;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export interface CrossRegionCopyAction {
    Target?: string;
    EncryptionConfiguration?: EncryptionConfiguration;
    RetainRule?: CrossRegionCopyRetainRule;
}
export declare const CrossRegionCopyAction: S.Schema<CrossRegionCopyAction>;
export type CrossRegionCopyActionList = CrossRegionCopyAction[];
export declare const CrossRegionCopyActionList: any;
export interface Action {
    Name?: string;
    CrossRegionCopy?: CrossRegionCopyAction[];
}
export declare const Action: S.Schema<Action>;
export type ActionList = Action[];
export declare const ActionList: any;
export type PolicyLanguageValues = "SIMPLIFIED" | "STANDARD" | (string & {});
export declare const PolicyLanguageValues: any;
export type CreateInterval = number;
export type RetainInterval = number;
export interface CrossRegionCopyTarget {
    TargetRegion?: string;
}
export declare const CrossRegionCopyTarget: S.Schema<CrossRegionCopyTarget>;
export type CrossRegionCopyTargetList = CrossRegionCopyTarget[];
export declare const CrossRegionCopyTargetList: any;
export type ExtendDeletion = boolean;
export type ExcludeBootVolumes = boolean;
export type VolumeTypeValues = string;
export type ExcludeVolumeTypesList = string[];
export declare const ExcludeVolumeTypesList: any;
export type ExcludeTagsList = Tag[];
export declare const ExcludeTagsList: any;
export interface Exclusions {
    ExcludeBootVolumes?: boolean;
    ExcludeVolumeTypes?: string[];
    ExcludeTags?: Tag[];
}
export declare const Exclusions: S.Schema<Exclusions>;
export interface PolicyDetails {
    PolicyType?: PolicyTypeValues;
    ResourceTypes?: ResourceTypeValues[];
    ResourceLocations?: ResourceLocationValues[];
    TargetTags?: Tag[];
    Schedules?: Schedule[];
    Parameters?: Parameters;
    EventSource?: EventSource;
    Actions?: Action[];
    PolicyLanguage?: PolicyLanguageValues;
    ResourceType?: ResourceTypeValues;
    CreateInterval?: number;
    RetainInterval?: number;
    CopyTags?: boolean;
    CrossRegionCopyTargets?: CrossRegionCopyTarget[];
    ExtendDeletion?: boolean;
    Exclusions?: Exclusions;
}
export declare const PolicyDetails: S.Schema<PolicyDetails>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type DefaultPolicyTypeValues = "VOLUME" | "INSTANCE" | (string & {});
export declare const DefaultPolicyTypeValues: any;
export interface CreateLifecyclePolicyRequest {
    ExecutionRoleArn?: string;
    Description?: string;
    State?: SettablePolicyStateValues;
    PolicyDetails?: PolicyDetails;
    Tags?: {
        [key: string]: string | undefined;
    };
    DefaultPolicy?: DefaultPolicyTypeValues;
    CreateInterval?: number;
    RetainInterval?: number;
    CopyTags?: boolean;
    ExtendDeletion?: boolean;
    CrossRegionCopyTargets?: CrossRegionCopyTarget[];
    Exclusions?: Exclusions;
}
export declare const CreateLifecyclePolicyRequest: S.Schema<CreateLifecyclePolicyRequest>;
export type PolicyId = string;
export interface CreateLifecyclePolicyResponse {
    PolicyId?: string;
}
export declare const CreateLifecyclePolicyResponse: S.Schema<CreateLifecyclePolicyResponse>;
export interface DeleteLifecyclePolicyRequest {
    PolicyId: string;
}
export declare const DeleteLifecyclePolicyRequest: S.Schema<DeleteLifecyclePolicyRequest>;
export interface DeleteLifecyclePolicyResponse {
}
export declare const DeleteLifecyclePolicyResponse: S.Schema<DeleteLifecyclePolicyResponse>;
export type PolicyIdList = string[];
export declare const PolicyIdList: any;
export type GettablePolicyStateValues = "ENABLED" | "DISABLED" | "ERROR" | (string & {});
export declare const GettablePolicyStateValues: any;
export type TagFilter = string;
export type TargetTagsFilterList = string[];
export declare const TargetTagsFilterList: any;
export type TagsToAddFilterList = string[];
export declare const TagsToAddFilterList: any;
export type DefaultPoliciesTypeValues = "VOLUME" | "INSTANCE" | "ALL" | (string & {});
export declare const DefaultPoliciesTypeValues: any;
export interface GetLifecyclePoliciesRequest {
    PolicyIds?: string[];
    State?: GettablePolicyStateValues;
    ResourceTypes?: ResourceTypeValues[];
    TargetTags?: string[];
    TagsToAdd?: string[];
    DefaultPolicyType?: DefaultPoliciesTypeValues;
}
export declare const GetLifecyclePoliciesRequest: S.Schema<GetLifecyclePoliciesRequest>;
export type DefaultPolicy = boolean;
export interface LifecyclePolicySummary {
    PolicyId?: string;
    Description?: string;
    State?: GettablePolicyStateValues;
    Tags?: {
        [key: string]: string | undefined;
    };
    PolicyType?: PolicyTypeValues;
    DefaultPolicy?: boolean;
}
export declare const LifecyclePolicySummary: S.Schema<LifecyclePolicySummary>;
export type LifecyclePolicySummaryList = LifecyclePolicySummary[];
export declare const LifecyclePolicySummaryList: any;
export interface GetLifecyclePoliciesResponse {
    Policies?: LifecyclePolicySummary[];
}
export declare const GetLifecyclePoliciesResponse: S.Schema<GetLifecyclePoliciesResponse>;
export interface GetLifecyclePolicyRequest {
    PolicyId: string;
}
export declare const GetLifecyclePolicyRequest: S.Schema<GetLifecyclePolicyRequest>;
export type StatusMessage = string;
export type PolicyArn = string;
export interface LifecyclePolicy {
    PolicyId?: string;
    Description?: string;
    State?: GettablePolicyStateValues;
    StatusMessage?: string;
    ExecutionRoleArn?: string;
    DateCreated?: Date;
    DateModified?: Date;
    PolicyDetails?: PolicyDetails;
    Tags?: {
        [key: string]: string | undefined;
    };
    PolicyArn?: string;
    DefaultPolicy?: boolean;
}
export declare const LifecyclePolicy: S.Schema<LifecyclePolicy>;
export interface GetLifecyclePolicyResponse {
    Policy?: LifecyclePolicy & {
        PolicyDetails: PolicyDetails & {
            TargetTags: (Tag & {
                Key: string;
                Value: string;
            })[];
            Schedules: (Schedule & {
                TagsToAdd: (Tag & {
                    Key: string;
                    Value: string;
                })[];
                VariableTags: (Tag & {
                    Key: string;
                    Value: string;
                })[];
                CreateRule: CreateRule & {
                    Scripts: (Script & {
                        ExecutionHandler: ExecutionHandler;
                    })[];
                };
                CrossRegionCopyRules: (CrossRegionCopyRule & {
                    Encrypted: Encrypted;
                })[];
                ShareRules: (ShareRule & {
                    TargetAccounts: ShareTargetAccountList;
                })[];
                ArchiveRule: ArchiveRule & {
                    RetainRule: ArchiveRetainRule & {
                        RetentionArchiveTier: RetentionArchiveTier;
                    };
                };
            })[];
            Parameters: Parameters & {
                ExcludeDataVolumeTags: (Tag & {
                    Key: string;
                    Value: string;
                })[];
            };
            EventSource: EventSource & {
                Type: EventSourceValues;
                Parameters: EventParameters & {
                    EventType: EventTypeValues;
                    SnapshotOwner: SnapshotOwnerList;
                    DescriptionRegex: DescriptionRegex;
                };
            };
            Actions: (Action & {
                Name: ActionName;
                CrossRegionCopy: (CrossRegionCopyAction & {
                    Target: Target;
                    EncryptionConfiguration: EncryptionConfiguration & {
                        Encrypted: Encrypted;
                    };
                })[];
            })[];
            Exclusions: Exclusions & {
                ExcludeTags: (Tag & {
                    Key: string;
                    Value: string;
                })[];
            };
        };
    };
}
export declare const GetLifecyclePolicyResponse: S.Schema<GetLifecyclePolicyResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateLifecyclePolicyRequest {
    PolicyId: string;
    ExecutionRoleArn?: string;
    State?: SettablePolicyStateValues;
    Description?: string;
    PolicyDetails?: PolicyDetails;
    CreateInterval?: number;
    RetainInterval?: number;
    CopyTags?: boolean;
    ExtendDeletion?: boolean;
    CrossRegionCopyTargets?: CrossRegionCopyTarget[];
    Exclusions?: Exclusions;
}
export declare const UpdateLifecyclePolicyRequest: S.Schema<UpdateLifecyclePolicyRequest>;
export interface UpdateLifecyclePolicyResponse {
}
export declare const UpdateLifecyclePolicyResponse: S.Schema<UpdateLifecyclePolicyResponse>;
export type ErrorMessage = string;
export type ErrorCode = string;
export type Parameter = string;
export type ParameterList = string[];
export declare const ParameterList: any;
export type CreateLifecyclePolicyError = InternalServerException | InvalidRequestException | LimitExceededException | CommonErrors;
/**
 * Creates an Amazon Data Lifecycle Manager lifecycle policy. Amazon Data Lifecycle Manager supports the following policy types:
 *
 * - Custom EBS snapshot policy
 *
 * - Custom EBS-backed AMI policy
 *
 * - Cross-account copy event policy
 *
 * - Default policy for EBS snapshots
 *
 * - Default policy for EBS-backed AMIs
 *
 * For more information, see
 * Default policies vs custom policies.
 *
 * If you create a default policy, you can specify the request parameters either in
 * the request body, or in the PolicyDetails request structure, but not both.
 */
export declare const createLifecyclePolicy: API.OperationMethod<CreateLifecyclePolicyRequest, CreateLifecyclePolicyResponse, CreateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = InternalServerException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified lifecycle policy and halts the automated operations that the
 * policy specified.
 *
 * For more information about deleting a policy, see Delete lifecycle
 * policies.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePoliciesError = InternalServerException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Gets summary information about all or the specified data lifecycle policies.
 *
 * To get complete information about a policy, use GetLifecyclePolicy.
 */
export declare const getLifecyclePolicies: API.OperationMethod<GetLifecyclePoliciesRequest, GetLifecyclePoliciesResponse, GetLifecyclePoliciesError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyError = InternalServerException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Gets detailed information about the specified lifecycle policy.
 */
export declare const getLifecyclePolicy: API.OperationMethod<GetLifecyclePolicyRequest, GetLifecyclePolicyResponse, GetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLifecyclePolicyError = InternalServerException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified lifecycle policy.
 *
 * For more information about updating a policy, see Modify lifecycle
 * policies.
 */
export declare const updateLifecyclePolicy: API.OperationMethod<UpdateLifecyclePolicyRequest, UpdateLifecyclePolicyResponse, UpdateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dlm.d.ts.map