import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resource: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DecoderManifestValidationException_base: S.Class<DecoderManifestValidationException, S.TaggedStruct<"DecoderManifestValidationException", {
    readonly invalidSignals: any;
    readonly invalidNetworkInterfaces: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DecoderManifestValidationException extends /*@__PURE__*/ DecoderManifestValidationException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidNodeException_base: S.Class<InvalidNodeException, S.TaggedStruct<"InvalidNodeException", {
    readonly invalidNodes: any;
    readonly reason: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNodeException extends /*@__PURE__*/ InvalidNodeException_base {
}
declare const InvalidSignalsException_base: S.Class<InvalidSignalsException, S.TaggedStruct<"InvalidSignalsException", {
    readonly message: any;
    readonly invalidSignals: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSignalsException extends /*@__PURE__*/ InvalidSignalsException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type VehicleName = string;
export type FleetId = string;
export interface AssociateVehicleFleetRequest {
    vehicleName: string;
    fleetId: string;
}
export declare const AssociateVehicleFleetRequest: S.Schema<AssociateVehicleFleetRequest>;
export interface AssociateVehicleFleetResponse {
}
export declare const AssociateVehicleFleetResponse: S.Schema<AssociateVehicleFleetResponse>;
export type Arn = string;
export type AttributeName = string;
export type AttributeValue = string;
export type AttributesMap = {
    [key: string]: string | undefined;
};
export declare const AttributesMap: any;
export type VehicleAssociationBehavior = "CreateIotThing" | "ValidateIotThingExists" | (string & {});
export declare const VehicleAssociationBehavior: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type ResourceIdentifier = string;
export type TimeUnit = "MILLISECOND" | "SECOND" | "MINUTE" | "HOUR" | (string & {});
export declare const TimeUnit: any;
export type PositiveInteger = number;
export interface TimePeriod {
    unit: TimeUnit;
    value: number;
}
export declare const TimePeriod: S.Schema<TimePeriod>;
export interface PeriodicStateTemplateUpdateStrategy {
    stateTemplateUpdateRate: TimePeriod;
}
export declare const PeriodicStateTemplateUpdateStrategy: S.Schema<PeriodicStateTemplateUpdateStrategy>;
export interface OnChangeStateTemplateUpdateStrategy {
}
export declare const OnChangeStateTemplateUpdateStrategy: S.Schema<OnChangeStateTemplateUpdateStrategy>;
export type StateTemplateUpdateStrategy = {
    periodic: PeriodicStateTemplateUpdateStrategy;
    onChange?: never;
} | {
    periodic?: never;
    onChange: OnChangeStateTemplateUpdateStrategy;
};
export declare const StateTemplateUpdateStrategy: any;
export interface StateTemplateAssociation {
    identifier: string;
    stateTemplateUpdateStrategy: StateTemplateUpdateStrategy;
}
export declare const StateTemplateAssociation: S.Schema<StateTemplateAssociation>;
export type StateTemplateAssociations = StateTemplateAssociation[];
export declare const StateTemplateAssociations: any;
export interface CreateVehicleRequestItem {
    vehicleName: string;
    modelManifestArn: string;
    decoderManifestArn: string;
    attributes?: {
        [key: string]: string | undefined;
    };
    associationBehavior?: VehicleAssociationBehavior;
    tags?: Tag[];
    stateTemplates?: StateTemplateAssociation[];
}
export declare const CreateVehicleRequestItem: S.Schema<CreateVehicleRequestItem>;
export type CreateVehicleRequestItems = CreateVehicleRequestItem[];
export declare const CreateVehicleRequestItems: any;
export interface BatchCreateVehicleRequest {
    vehicles: CreateVehicleRequestItem[];
}
export declare const BatchCreateVehicleRequest: S.Schema<BatchCreateVehicleRequest>;
export interface CreateVehicleResponseItem {
    vehicleName?: string;
    arn?: string;
    thingArn?: string;
}
export declare const CreateVehicleResponseItem: S.Schema<CreateVehicleResponseItem>;
export type CreateVehicleResponses = CreateVehicleResponseItem[];
export declare const CreateVehicleResponses: any;
export interface CreateVehicleError_ {
    vehicleName?: string;
    code?: string;
    message?: string;
}
export declare const CreateVehicleError_: S.Schema<CreateVehicleError_>;
export type CreateVehicleErrors = CreateVehicleError_[];
export declare const CreateVehicleErrors: any;
export interface BatchCreateVehicleResponse {
    vehicles?: CreateVehicleResponseItem[];
    errors?: CreateVehicleError_[];
}
export declare const BatchCreateVehicleResponse: S.Schema<BatchCreateVehicleResponse>;
export type UpdateMode = "Overwrite" | "Merge" | (string & {});
export declare const UpdateMode: any;
export type StateTemplateAssociationIdentifiers = string[];
export declare const StateTemplateAssociationIdentifiers: any;
export interface UpdateVehicleRequestItem {
    vehicleName: string;
    modelManifestArn?: string;
    decoderManifestArn?: string;
    attributes?: {
        [key: string]: string | undefined;
    };
    attributeUpdateMode?: UpdateMode;
    stateTemplatesToAdd?: StateTemplateAssociation[];
    stateTemplatesToRemove?: string[];
    stateTemplatesToUpdate?: StateTemplateAssociation[];
}
export declare const UpdateVehicleRequestItem: S.Schema<UpdateVehicleRequestItem>;
export type UpdateVehicleRequestItems = UpdateVehicleRequestItem[];
export declare const UpdateVehicleRequestItems: any;
export interface BatchUpdateVehicleRequest {
    vehicles: UpdateVehicleRequestItem[];
}
export declare const BatchUpdateVehicleRequest: S.Schema<BatchUpdateVehicleRequest>;
export interface UpdateVehicleResponseItem {
    vehicleName?: string;
    arn?: string;
}
export declare const UpdateVehicleResponseItem: S.Schema<UpdateVehicleResponseItem>;
export type UpdateVehicleResponseItems = UpdateVehicleResponseItem[];
export declare const UpdateVehicleResponseItems: any;
export interface UpdateVehicleError_ {
    vehicleName?: string;
    code?: number;
    message?: string;
}
export declare const UpdateVehicleError_: S.Schema<UpdateVehicleError_>;
export type UpdateVehicleErrors = UpdateVehicleError_[];
export declare const UpdateVehicleErrors: any;
export interface BatchUpdateVehicleResponse {
    vehicles?: UpdateVehicleResponseItem[];
    errors?: UpdateVehicleError_[];
}
export declare const BatchUpdateVehicleResponse: S.Schema<BatchUpdateVehicleResponse>;
export type CampaignName = string;
export type Description = string;
export type Uint32 = number;
export type DiagnosticsMode = "OFF" | "SEND_ACTIVE_DTCS" | (string & {});
export declare const DiagnosticsMode: any;
export type SpoolingMode = "OFF" | "TO_DISK" | (string & {});
export declare const SpoolingMode: any;
export type Compression = "OFF" | "SNAPPY" | (string & {});
export declare const Compression: any;
export type Priority = number;
export type WildcardSignalName = string;
export type MaxSampleCount = number;
export type DataPartitionId = string;
export interface SignalInformation {
    name: string;
    maxSampleCount?: number;
    minimumSamplingIntervalMs?: number;
    dataPartitionId?: string;
}
export declare const SignalInformation: S.Schema<SignalInformation>;
export type SignalInformationList = SignalInformation[];
export declare const SignalInformationList: any;
export type CollectionPeriodMs = number;
export interface TimeBasedCollectionScheme {
    periodMs: number;
}
export declare const TimeBasedCollectionScheme: S.Schema<TimeBasedCollectionScheme>;
export type EventExpression = string | redacted.Redacted<string>;
export type TriggerMode = "ALWAYS" | "RISING_EDGE" | (string & {});
export declare const TriggerMode: any;
export type LanguageVersion = number;
export interface ConditionBasedCollectionScheme {
    expression: string | redacted.Redacted<string>;
    minimumTriggerIntervalMs?: number;
    triggerMode?: TriggerMode;
    conditionLanguageVersion?: number;
}
export declare const ConditionBasedCollectionScheme: S.Schema<ConditionBasedCollectionScheme>;
export type CollectionScheme = {
    timeBasedCollectionScheme: TimeBasedCollectionScheme;
    conditionBasedCollectionScheme?: never;
} | {
    timeBasedCollectionScheme?: never;
    conditionBasedCollectionScheme: ConditionBasedCollectionScheme;
};
export declare const CollectionScheme: any;
export type NodePath = string;
export type DataExtraDimensionNodePathList = string[];
export declare const DataExtraDimensionNodePathList: any;
export type S3BucketArn = string;
export type DataFormat = "JSON" | "PARQUET" | (string & {});
export declare const DataFormat: any;
export type StorageCompressionFormat = "NONE" | "GZIP" | (string & {});
export declare const StorageCompressionFormat: any;
export type Prefix = string;
export interface S3Config {
    bucketArn: string;
    dataFormat?: DataFormat;
    storageCompressionFormat?: StorageCompressionFormat;
    prefix?: string;
}
export declare const S3Config: S.Schema<S3Config>;
export type TimestreamTableArn = string;
export type IAMRoleArn = string;
export interface TimestreamConfig {
    timestreamTableArn: string;
    executionRoleArn: string;
}
export declare const TimestreamConfig: S.Schema<TimestreamConfig>;
export type MqttTopicArn = string;
export interface MqttTopicConfig {
    mqttTopicArn: string;
    executionRoleArn: string;
}
export declare const MqttTopicConfig: S.Schema<MqttTopicConfig>;
export type DataDestinationConfig = {
    s3Config: S3Config;
    timestreamConfig?: never;
    mqttTopicConfig?: never;
} | {
    s3Config?: never;
    timestreamConfig: TimestreamConfig;
    mqttTopicConfig?: never;
} | {
    s3Config?: never;
    timestreamConfig?: never;
    mqttTopicConfig: MqttTopicConfig;
};
export declare const DataDestinationConfig: any;
export type DataDestinationConfigs = DataDestinationConfig[];
export declare const DataDestinationConfigs: any;
export type StorageMaximumSizeUnit = "MB" | "GB" | "TB" | (string & {});
export declare const StorageMaximumSizeUnit: any;
export type StorageMaximumSizeValue = number;
export interface StorageMaximumSize {
    unit: StorageMaximumSizeUnit;
    value: number;
}
export declare const StorageMaximumSize: S.Schema<StorageMaximumSize>;
export type StorageLocation = string | redacted.Redacted<string>;
export type StorageMinimumTimeToLiveUnit = "HOURS" | "DAYS" | "WEEKS" | (string & {});
export declare const StorageMinimumTimeToLiveUnit: any;
export type StorageMinimumTimeToLiveValue = number;
export interface StorageMinimumTimeToLive {
    unit: StorageMinimumTimeToLiveUnit;
    value: number;
}
export declare const StorageMinimumTimeToLive: S.Schema<StorageMinimumTimeToLive>;
export interface DataPartitionStorageOptions {
    maximumSize: StorageMaximumSize;
    storageLocation: string | redacted.Redacted<string>;
    minimumTimeToLive: StorageMinimumTimeToLive;
}
export declare const DataPartitionStorageOptions: S.Schema<DataPartitionStorageOptions>;
export interface DataPartitionUploadOptions {
    expression: string | redacted.Redacted<string>;
    conditionLanguageVersion?: number;
}
export declare const DataPartitionUploadOptions: S.Schema<DataPartitionUploadOptions>;
export interface DataPartition {
    id: string;
    storageOptions: DataPartitionStorageOptions;
    uploadOptions?: DataPartitionUploadOptions;
}
export declare const DataPartition: S.Schema<DataPartition>;
export type DataPartitions = DataPartition[];
export declare const DataPartitions: any;
export type PositiveLong = number;
export interface TimeBasedSignalFetchConfig {
    executionFrequencyMs: number;
}
export declare const TimeBasedSignalFetchConfig: S.Schema<TimeBasedSignalFetchConfig>;
export type FetchConfigEventExpression = string | redacted.Redacted<string>;
export interface ConditionBasedSignalFetchConfig {
    conditionExpression: string | redacted.Redacted<string>;
    triggerMode: TriggerMode;
}
export declare const ConditionBasedSignalFetchConfig: S.Schema<ConditionBasedSignalFetchConfig>;
export type SignalFetchConfig = {
    timeBased: TimeBasedSignalFetchConfig;
    conditionBased?: never;
} | {
    timeBased?: never;
    conditionBased: ConditionBasedSignalFetchConfig;
};
export declare const SignalFetchConfig: any;
export type ActionEventExpression = string | redacted.Redacted<string>;
export type EventExpressionList = (string | redacted.Redacted<string>)[];
export declare const EventExpressionList: any;
export interface SignalFetchInformation {
    fullyQualifiedName: string;
    signalFetchConfig: SignalFetchConfig;
    conditionLanguageVersion?: number;
    actions: (string | redacted.Redacted<string>)[];
}
export declare const SignalFetchInformation: S.Schema<SignalFetchInformation>;
export type SignalFetchInformationList = SignalFetchInformation[];
export declare const SignalFetchInformationList: any;
export interface CreateCampaignRequest {
    name: string;
    description?: string;
    signalCatalogArn: string;
    targetArn: string;
    startTime?: Date;
    expiryTime?: Date;
    postTriggerCollectionDuration?: number;
    diagnosticsMode?: DiagnosticsMode;
    spoolingMode?: SpoolingMode;
    compression?: Compression;
    priority?: number;
    signalsToCollect?: SignalInformation[];
    collectionScheme: CollectionScheme;
    dataExtraDimensions?: string[];
    tags?: Tag[];
    dataDestinationConfigs?: DataDestinationConfig[];
    dataPartitions?: DataPartition[];
    signalsToFetch?: SignalFetchInformation[];
}
export declare const CreateCampaignRequest: S.Schema<CreateCampaignRequest>;
export type CampaignArn = string;
export interface CreateCampaignResponse {
    name?: string;
    arn?: string;
}
export declare const CreateCampaignResponse: S.Schema<CreateCampaignResponse>;
export type ResourceName = string;
export type FullyQualifiedName = string;
export type SignalDecoderType = "CAN_SIGNAL" | "OBD_SIGNAL" | "MESSAGE_SIGNAL" | "CUSTOM_DECODING_SIGNAL" | (string & {});
export declare const SignalDecoderType: any;
export type InterfaceId = string;
export type NonNegativeInteger = number;
export type CanSignalName = string;
export type SignalValueType = "INTEGER" | "FLOATING_POINT" | (string & {});
export declare const SignalValueType: any;
export interface CanSignal {
    messageId: number;
    isBigEndian: boolean;
    isSigned: boolean;
    startBit: number;
    offset: number;
    factor: number;
    length: number;
    name?: string;
    signalValueType?: SignalValueType;
}
export declare const CanSignal: S.Schema<CanSignal>;
export type ObdByteLength = number;
export type ObdBitmaskLength = number;
export interface ObdSignal {
    pidResponseLength: number;
    serviceMode: number;
    pid: number;
    scaling: number;
    offset: number;
    startByte: number;
    byteLength: number;
    bitRightShift?: number;
    bitMaskLength?: number;
    isSigned?: boolean;
    signalValueType?: SignalValueType;
}
export declare const ObdSignal: S.Schema<ObdSignal>;
export type TopicName = string;
export type ROS2PrimitiveType = "BOOL" | "BYTE" | "CHAR" | "FLOAT32" | "FLOAT64" | "INT8" | "UINT8" | "INT16" | "UINT16" | "INT32" | "UINT32" | "INT64" | "UINT64" | "STRING" | "WSTRING" | (string & {});
export declare const ROS2PrimitiveType: any;
export type MaxStringSize = number;
export interface ROS2PrimitiveMessageDefinition {
    primitiveType: ROS2PrimitiveType;
    offset?: number;
    scaling?: number;
    upperBound?: number;
}
export declare const ROS2PrimitiveMessageDefinition: S.Schema<ROS2PrimitiveMessageDefinition>;
export type PrimitiveMessageDefinition = {
    ros2PrimitiveMessageDefinition: ROS2PrimitiveMessageDefinition;
};
export declare const PrimitiveMessageDefinition: any;
export type StructureMessageName = string;
export type StructuredMessageListType = "FIXED_CAPACITY" | "DYNAMIC_UNBOUNDED_CAPACITY" | "DYNAMIC_BOUNDED_CAPACITY" | (string & {});
export declare const StructuredMessageListType: any;
export interface StructuredMessageListDefinition {
    name: string;
    memberType: StructuredMessage;
    listType: StructuredMessageListType;
    capacity?: number;
}
export declare const StructuredMessageListDefinition: S.Schema<StructuredMessageListDefinition>;
export interface StructuredMessageFieldNameAndDataTypePair {
    fieldName: string;
    dataType: StructuredMessage;
}
export declare const StructuredMessageFieldNameAndDataTypePair: S.Schema<StructuredMessageFieldNameAndDataTypePair>;
export type StructuredMessageDefinition = StructuredMessageFieldNameAndDataTypePair[];
export declare const StructuredMessageDefinition: S.Schema<StructuredMessageDefinition>;
export type StructuredMessage = {
    primitiveMessageDefinition: PrimitiveMessageDefinition;
    structuredMessageListDefinition?: never;
    structuredMessageDefinition?: never;
} | {
    primitiveMessageDefinition?: never;
    structuredMessageListDefinition: StructuredMessageListDefinition;
    structuredMessageDefinition?: never;
} | {
    primitiveMessageDefinition?: never;
    structuredMessageListDefinition?: never;
    structuredMessageDefinition: StructuredMessageFieldNameAndDataTypePair[];
};
export declare const StructuredMessage: S.Schema<StructuredMessage>;
export interface MessageSignal {
    topicName: string;
    structuredMessage: StructuredMessage;
}
export declare const MessageSignal: S.Schema<MessageSignal>;
export type CustomDecodingId = string;
export interface CustomDecodingSignal {
    id: string;
}
export declare const CustomDecodingSignal: S.Schema<CustomDecodingSignal>;
export interface SignalDecoder {
    fullyQualifiedName: string;
    type: SignalDecoderType;
    interfaceId: string;
    canSignal?: CanSignal;
    obdSignal?: ObdSignal;
    messageSignal?: MessageSignal;
    customDecodingSignal?: CustomDecodingSignal;
}
export declare const SignalDecoder: S.Schema<SignalDecoder>;
export type SignalDecoders = SignalDecoder[];
export declare const SignalDecoders: any;
export type NetworkInterfaceType = "CAN_INTERFACE" | "OBD_INTERFACE" | "VEHICLE_MIDDLEWARE" | "CUSTOM_DECODING_INTERFACE" | (string & {});
export declare const NetworkInterfaceType: any;
export type CanInterfaceName = string;
export type ProtocolName = string;
export type ProtocolVersion = string;
export interface CanInterface {
    name: string;
    protocolName?: string;
    protocolVersion?: string;
}
export declare const CanInterface: S.Schema<CanInterface>;
export type ObdInterfaceName = string;
export type ObdStandard = string;
export interface ObdInterface {
    name: string;
    requestMessageId: number;
    obdStandard?: string;
    pidRequestIntervalSeconds?: number;
    dtcRequestIntervalSeconds?: number;
    useExtendedIds?: boolean;
    hasTransmissionEcu?: boolean;
}
export declare const ObdInterface: S.Schema<ObdInterface>;
export type VehicleMiddlewareName = string;
export type VehicleMiddlewareProtocol = "ROS_2" | (string & {});
export declare const VehicleMiddlewareProtocol: any;
export interface VehicleMiddleware {
    name: string;
    protocolName: VehicleMiddlewareProtocol;
}
export declare const VehicleMiddleware: S.Schema<VehicleMiddleware>;
export type CustomDecodingSignalInterfaceName = string;
export interface CustomDecodingInterface {
    name: string;
}
export declare const CustomDecodingInterface: S.Schema<CustomDecodingInterface>;
export interface NetworkInterface {
    interfaceId: string;
    type: NetworkInterfaceType;
    canInterface?: CanInterface;
    obdInterface?: ObdInterface;
    vehicleMiddleware?: VehicleMiddleware;
    customDecodingInterface?: CustomDecodingInterface;
}
export declare const NetworkInterface: S.Schema<NetworkInterface>;
export type NetworkInterfaces = NetworkInterface[];
export declare const NetworkInterfaces: any;
export type DefaultForUnmappedSignalsType = "CUSTOM_DECODING" | (string & {});
export declare const DefaultForUnmappedSignalsType: any;
export interface CreateDecoderManifestRequest {
    name: string;
    description?: string;
    modelManifestArn: string;
    signalDecoders?: SignalDecoder[];
    networkInterfaces?: NetworkInterface[];
    defaultForUnmappedSignals?: DefaultForUnmappedSignalsType;
    tags?: Tag[];
}
export declare const CreateDecoderManifestRequest: S.Schema<CreateDecoderManifestRequest>;
export interface CreateDecoderManifestResponse {
    name: string;
    arn: string;
}
export declare const CreateDecoderManifestResponse: S.Schema<CreateDecoderManifestResponse>;
export interface CreateFleetRequest {
    fleetId: string;
    description?: string;
    signalCatalogArn: string;
    tags?: Tag[];
}
export declare const CreateFleetRequest: S.Schema<CreateFleetRequest>;
export interface CreateFleetResponse {
    id: string;
    arn: string;
}
export declare const CreateFleetResponse: S.Schema<CreateFleetResponse>;
export type ListOfStrings = string[];
export declare const ListOfStrings: any;
export interface CreateModelManifestRequest {
    name: string;
    description?: string;
    nodes: string[];
    signalCatalogArn: string;
    tags?: Tag[];
}
export declare const CreateModelManifestRequest: S.Schema<CreateModelManifestRequest>;
export interface CreateModelManifestResponse {
    name: string;
    arn: string;
}
export declare const CreateModelManifestResponse: S.Schema<CreateModelManifestResponse>;
export type Message = string;
export interface Branch {
    fullyQualifiedName: string;
    description?: string;
    deprecationMessage?: string;
    comment?: string;
}
export declare const Branch: S.Schema<Branch>;
export type NodeDataType = "INT8" | "UINT8" | "INT16" | "UINT16" | "INT32" | "UINT32" | "INT64" | "UINT64" | "BOOLEAN" | "FLOAT" | "DOUBLE" | "STRING" | "UNIX_TIMESTAMP" | "INT8_ARRAY" | "UINT8_ARRAY" | "INT16_ARRAY" | "UINT16_ARRAY" | "INT32_ARRAY" | "UINT32_ARRAY" | "INT64_ARRAY" | "UINT64_ARRAY" | "BOOLEAN_ARRAY" | "FLOAT_ARRAY" | "DOUBLE_ARRAY" | "STRING_ARRAY" | "UNIX_TIMESTAMP_ARRAY" | "UNKNOWN" | "STRUCT" | "STRUCT_ARRAY" | (string & {});
export declare const NodeDataType: any;
export interface Sensor {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    description?: string;
    unit?: string;
    allowedValues?: string[];
    min?: number;
    max?: number;
    deprecationMessage?: string;
    comment?: string;
    structFullyQualifiedName?: string;
}
export declare const Sensor: S.Schema<Sensor>;
export interface Actuator {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    description?: string;
    unit?: string;
    allowedValues?: string[];
    min?: number;
    max?: number;
    assignedValue?: string;
    deprecationMessage?: string;
    comment?: string;
    structFullyQualifiedName?: string;
}
export declare const Actuator: S.Schema<Actuator>;
export interface Attribute {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    description?: string;
    unit?: string;
    allowedValues?: string[];
    min?: number;
    max?: number;
    assignedValue?: string;
    defaultValue?: string;
    deprecationMessage?: string;
    comment?: string;
}
export declare const Attribute: S.Schema<Attribute>;
export interface CustomStruct {
    fullyQualifiedName: string;
    description?: string;
    deprecationMessage?: string;
    comment?: string;
}
export declare const CustomStruct: S.Schema<CustomStruct>;
export type NodeDataEncoding = "BINARY" | "TYPED" | (string & {});
export declare const NodeDataEncoding: any;
export interface CustomProperty {
    fullyQualifiedName: string;
    dataType: NodeDataType;
    dataEncoding?: NodeDataEncoding;
    description?: string;
    deprecationMessage?: string;
    comment?: string;
    structFullyQualifiedName?: string;
}
export declare const CustomProperty: S.Schema<CustomProperty>;
export type Node = {
    branch: Branch;
    sensor?: never;
    actuator?: never;
    attribute?: never;
    struct?: never;
    property?: never;
} | {
    branch?: never;
    sensor: Sensor;
    actuator?: never;
    attribute?: never;
    struct?: never;
    property?: never;
} | {
    branch?: never;
    sensor?: never;
    actuator: Actuator;
    attribute?: never;
    struct?: never;
    property?: never;
} | {
    branch?: never;
    sensor?: never;
    actuator?: never;
    attribute: Attribute;
    struct?: never;
    property?: never;
} | {
    branch?: never;
    sensor?: never;
    actuator?: never;
    attribute?: never;
    struct: CustomStruct;
    property?: never;
} | {
    branch?: never;
    sensor?: never;
    actuator?: never;
    attribute?: never;
    struct?: never;
    property: CustomProperty;
};
export declare const Node: any;
export type Nodes = Node[];
export declare const Nodes: any;
export interface CreateSignalCatalogRequest {
    name: string;
    description?: string;
    nodes?: Node[];
    tags?: Tag[];
}
export declare const CreateSignalCatalogRequest: S.Schema<CreateSignalCatalogRequest>;
export interface CreateSignalCatalogResponse {
    name: string;
    arn: string;
}
export declare const CreateSignalCatalogResponse: S.Schema<CreateSignalCatalogResponse>;
export type StateTemplateProperties = string[];
export declare const StateTemplateProperties: any;
export type StateTemplateDataExtraDimensionNodePathList = string[];
export declare const StateTemplateDataExtraDimensionNodePathList: any;
export type StateTemplateMetadataExtraDimensionNodePathList = string[];
export declare const StateTemplateMetadataExtraDimensionNodePathList: any;
export interface CreateStateTemplateRequest {
    name: string;
    description?: string;
    signalCatalogArn: string;
    stateTemplateProperties: string[];
    dataExtraDimensions?: string[];
    metadataExtraDimensions?: string[];
    tags?: Tag[];
}
export declare const CreateStateTemplateRequest: S.Schema<CreateStateTemplateRequest>;
export type ResourceUniqueId = string;
export interface CreateStateTemplateResponse {
    name?: string;
    arn?: string;
    id?: string;
}
export declare const CreateStateTemplateResponse: S.Schema<CreateStateTemplateResponse>;
export interface CreateVehicleRequest {
    vehicleName: string;
    modelManifestArn: string;
    decoderManifestArn: string;
    attributes?: {
        [key: string]: string | undefined;
    };
    associationBehavior?: VehicleAssociationBehavior;
    tags?: Tag[];
    stateTemplates?: StateTemplateAssociation[];
}
export declare const CreateVehicleRequest: S.Schema<CreateVehicleRequest>;
export interface CreateVehicleResponse {
    vehicleName?: string;
    arn?: string;
    thingArn?: string;
}
export declare const CreateVehicleResponse: S.Schema<CreateVehicleResponse>;
export interface DeleteCampaignRequest {
    name: string;
}
export declare const DeleteCampaignRequest: S.Schema<DeleteCampaignRequest>;
export interface DeleteCampaignResponse {
    name?: string;
    arn?: string;
}
export declare const DeleteCampaignResponse: S.Schema<DeleteCampaignResponse>;
export interface DeleteDecoderManifestRequest {
    name: string;
}
export declare const DeleteDecoderManifestRequest: S.Schema<DeleteDecoderManifestRequest>;
export interface DeleteDecoderManifestResponse {
    name: string;
    arn: string;
}
export declare const DeleteDecoderManifestResponse: S.Schema<DeleteDecoderManifestResponse>;
export interface DeleteFleetRequest {
    fleetId: string;
}
export declare const DeleteFleetRequest: S.Schema<DeleteFleetRequest>;
export interface DeleteFleetResponse {
    id?: string;
    arn?: string;
}
export declare const DeleteFleetResponse: S.Schema<DeleteFleetResponse>;
export interface DeleteModelManifestRequest {
    name: string;
}
export declare const DeleteModelManifestRequest: S.Schema<DeleteModelManifestRequest>;
export interface DeleteModelManifestResponse {
    name: string;
    arn: string;
}
export declare const DeleteModelManifestResponse: S.Schema<DeleteModelManifestResponse>;
export interface DeleteSignalCatalogRequest {
    name: string;
}
export declare const DeleteSignalCatalogRequest: S.Schema<DeleteSignalCatalogRequest>;
export interface DeleteSignalCatalogResponse {
    name: string;
    arn: string;
}
export declare const DeleteSignalCatalogResponse: S.Schema<DeleteSignalCatalogResponse>;
export interface DeleteStateTemplateRequest {
    identifier: string;
}
export declare const DeleteStateTemplateRequest: S.Schema<DeleteStateTemplateRequest>;
export interface DeleteStateTemplateResponse {
    name?: string;
    arn?: string;
    id?: string;
}
export declare const DeleteStateTemplateResponse: S.Schema<DeleteStateTemplateResponse>;
export interface DeleteVehicleRequest {
    vehicleName: string;
}
export declare const DeleteVehicleRequest: S.Schema<DeleteVehicleRequest>;
export interface DeleteVehicleResponse {
    vehicleName: string;
    arn: string;
}
export declare const DeleteVehicleResponse: S.Schema<DeleteVehicleResponse>;
export interface DisassociateVehicleFleetRequest {
    vehicleName: string;
    fleetId: string;
}
export declare const DisassociateVehicleFleetRequest: S.Schema<DisassociateVehicleFleetRequest>;
export interface DisassociateVehicleFleetResponse {
}
export declare const DisassociateVehicleFleetResponse: S.Schema<DisassociateVehicleFleetResponse>;
export interface GetCampaignRequest {
    name: string;
}
export declare const GetCampaignRequest: S.Schema<GetCampaignRequest>;
export type CampaignStatus = "CREATING" | "WAITING_FOR_APPROVAL" | "RUNNING" | "SUSPENDED" | (string & {});
export declare const CampaignStatus: any;
export interface GetCampaignResponse {
    name?: string;
    arn?: string;
    description?: string;
    signalCatalogArn?: string;
    targetArn?: string;
    status?: CampaignStatus;
    startTime?: Date;
    expiryTime?: Date;
    postTriggerCollectionDuration?: number;
    diagnosticsMode?: DiagnosticsMode;
    spoolingMode?: SpoolingMode;
    compression?: Compression;
    priority?: number;
    signalsToCollect?: SignalInformation[];
    collectionScheme?: CollectionScheme;
    dataExtraDimensions?: string[];
    creationTime?: Date;
    lastModificationTime?: Date;
    dataDestinationConfigs?: DataDestinationConfig[];
    dataPartitions?: DataPartition[];
    signalsToFetch?: SignalFetchInformation[];
}
export declare const GetCampaignResponse: S.Schema<GetCampaignResponse>;
export interface GetDecoderManifestRequest {
    name: string;
}
export declare const GetDecoderManifestRequest: S.Schema<GetDecoderManifestRequest>;
export type ManifestStatus = "ACTIVE" | "DRAFT" | "INVALID" | "VALIDATING" | (string & {});
export declare const ManifestStatus: any;
export interface GetDecoderManifestResponse {
    name: string;
    arn: string;
    description?: string;
    modelManifestArn?: string;
    status?: ManifestStatus;
    creationTime: Date;
    lastModificationTime: Date;
    message?: string;
}
export declare const GetDecoderManifestResponse: S.Schema<GetDecoderManifestResponse>;
export interface GetEncryptionConfigurationRequest {
}
export declare const GetEncryptionConfigurationRequest: S.Schema<GetEncryptionConfigurationRequest>;
export type EncryptionStatus = "PENDING" | "SUCCESS" | "FAILURE" | (string & {});
export declare const EncryptionStatus: any;
export type EncryptionType = "KMS_BASED_ENCRYPTION" | "FLEETWISE_DEFAULT_ENCRYPTION" | (string & {});
export declare const EncryptionType: any;
export type ErrorMessage = string;
export interface GetEncryptionConfigurationResponse {
    kmsKeyId?: string;
    encryptionStatus: EncryptionStatus;
    encryptionType: EncryptionType;
    errorMessage?: string;
    creationTime?: Date;
    lastModificationTime?: Date;
}
export declare const GetEncryptionConfigurationResponse: S.Schema<GetEncryptionConfigurationResponse>;
export interface GetFleetRequest {
    fleetId: string;
}
export declare const GetFleetRequest: S.Schema<GetFleetRequest>;
export interface GetFleetResponse {
    id: string;
    arn: string;
    description?: string;
    signalCatalogArn: string;
    creationTime: Date;
    lastModificationTime: Date;
}
export declare const GetFleetResponse: S.Schema<GetFleetResponse>;
export interface GetLoggingOptionsRequest {
}
export declare const GetLoggingOptionsRequest: S.Schema<GetLoggingOptionsRequest>;
export type LogType = "OFF" | "ERROR" | (string & {});
export declare const LogType: any;
export type CloudWatchLogGroupName = string;
export interface CloudWatchLogDeliveryOptions {
    logType: LogType;
    logGroupName?: string;
}
export declare const CloudWatchLogDeliveryOptions: S.Schema<CloudWatchLogDeliveryOptions>;
export interface GetLoggingOptionsResponse {
    cloudWatchLogDelivery: CloudWatchLogDeliveryOptions;
}
export declare const GetLoggingOptionsResponse: S.Schema<GetLoggingOptionsResponse>;
export interface GetModelManifestRequest {
    name: string;
}
export declare const GetModelManifestRequest: S.Schema<GetModelManifestRequest>;
export interface GetModelManifestResponse {
    name: string;
    arn: string;
    description?: string;
    signalCatalogArn?: string;
    status?: ManifestStatus;
    creationTime: Date;
    lastModificationTime: Date;
}
export declare const GetModelManifestResponse: S.Schema<GetModelManifestResponse>;
export interface GetRegisterAccountStatusRequest {
}
export declare const GetRegisterAccountStatusRequest: S.Schema<GetRegisterAccountStatusRequest>;
export type CustomerAccountId = string;
export type RegistrationStatus = "REGISTRATION_PENDING" | "REGISTRATION_SUCCESS" | "REGISTRATION_FAILURE" | (string & {});
export declare const RegistrationStatus: any;
export type TimestreamDatabaseName = string;
export type TimestreamTableName = string;
export interface TimestreamRegistrationResponse {
    timestreamDatabaseName: string;
    timestreamTableName: string;
    timestreamDatabaseArn?: string;
    timestreamTableArn?: string;
    registrationStatus: RegistrationStatus;
    errorMessage?: string;
}
export declare const TimestreamRegistrationResponse: S.Schema<TimestreamRegistrationResponse>;
export interface IamRegistrationResponse {
    roleArn: string;
    registrationStatus: RegistrationStatus;
    errorMessage?: string;
}
export declare const IamRegistrationResponse: S.Schema<IamRegistrationResponse>;
export interface GetRegisterAccountStatusResponse {
    customerAccountId: string;
    accountStatus: RegistrationStatus;
    timestreamRegistrationResponse?: TimestreamRegistrationResponse;
    iamRegistrationResponse: IamRegistrationResponse;
    creationTime: Date;
    lastModificationTime: Date;
}
export declare const GetRegisterAccountStatusResponse: S.Schema<GetRegisterAccountStatusResponse>;
export interface GetSignalCatalogRequest {
    name: string;
}
export declare const GetSignalCatalogRequest: S.Schema<GetSignalCatalogRequest>;
export interface NodeCounts {
    totalNodes?: number;
    totalBranches?: number;
    totalSensors?: number;
    totalAttributes?: number;
    totalActuators?: number;
    totalStructs?: number;
    totalProperties?: number;
}
export declare const NodeCounts: S.Schema<NodeCounts>;
export interface GetSignalCatalogResponse {
    name: string;
    arn: string;
    description?: string;
    nodeCounts?: NodeCounts;
    creationTime: Date;
    lastModificationTime: Date;
}
export declare const GetSignalCatalogResponse: S.Schema<GetSignalCatalogResponse>;
export interface GetStateTemplateRequest {
    identifier: string;
}
export declare const GetStateTemplateRequest: S.Schema<GetStateTemplateRequest>;
export interface GetStateTemplateResponse {
    name?: string;
    arn?: string;
    description?: string;
    signalCatalogArn?: string;
    stateTemplateProperties?: string[];
    dataExtraDimensions?: string[];
    metadataExtraDimensions?: string[];
    creationTime?: Date;
    lastModificationTime?: Date;
    id?: string;
}
export declare const GetStateTemplateResponse: S.Schema<GetStateTemplateResponse>;
export interface GetVehicleRequest {
    vehicleName: string;
}
export declare const GetVehicleRequest: S.Schema<GetVehicleRequest>;
export interface GetVehicleResponse {
    vehicleName?: string;
    arn?: string;
    modelManifestArn?: string;
    decoderManifestArn?: string;
    attributes?: {
        [key: string]: string | undefined;
    };
    stateTemplates?: StateTemplateAssociation[];
    creationTime?: Date;
    lastModificationTime?: Date;
}
export declare const GetVehicleResponse: S.Schema<GetVehicleResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface GetVehicleStatusRequest {
    nextToken?: string;
    maxResults?: number;
    vehicleName: string;
}
export declare const GetVehicleStatusRequest: S.Schema<GetVehicleStatusRequest>;
export type VehicleState = "CREATED" | "READY" | "HEALTHY" | "SUSPENDED" | "DELETING" | "READY_FOR_CHECKIN" | (string & {});
export declare const VehicleState: any;
export interface VehicleStatus {
    campaignName?: string;
    vehicleName?: string;
    status?: VehicleState;
}
export declare const VehicleStatus: S.Schema<VehicleStatus>;
export type VehicleStatusList = VehicleStatus[];
export declare const VehicleStatusList: any;
export interface GetVehicleStatusResponse {
    campaigns?: VehicleStatus[];
    nextToken?: string;
}
export declare const GetVehicleStatusResponse: S.Schema<GetVehicleStatusResponse>;
export type NetworkFileBlob = Uint8Array;
export type NetworkFilesList = Uint8Array[];
export declare const NetworkFilesList: any;
export type ModelSignalsMap = {
    [key: string]: string | undefined;
};
export declare const ModelSignalsMap: any;
export interface CanDbcDefinition {
    networkInterface: string;
    canDbcFiles: Uint8Array[];
    signalsMap?: {
        [key: string]: string | undefined;
    };
}
export declare const CanDbcDefinition: S.Schema<CanDbcDefinition>;
export type NetworkFileDefinition = {
    canDbc: CanDbcDefinition;
};
export declare const NetworkFileDefinition: any;
export type NetworkFileDefinitions = NetworkFileDefinition[];
export declare const NetworkFileDefinitions: any;
export interface ImportDecoderManifestRequest {
    name: string;
    networkFileDefinitions: NetworkFileDefinition[];
}
export declare const ImportDecoderManifestRequest: S.Schema<ImportDecoderManifestRequest>;
export interface ImportDecoderManifestResponse {
    name: string;
    arn: string;
}
export declare const ImportDecoderManifestResponse: S.Schema<ImportDecoderManifestResponse>;
export type FormattedVss = {
    vssJson: string;
};
export declare const FormattedVss: any;
export interface ImportSignalCatalogRequest {
    name: string;
    description?: string;
    vss?: FormattedVss;
    tags?: Tag[];
}
export declare const ImportSignalCatalogRequest: S.Schema<ImportSignalCatalogRequest>;
export interface ImportSignalCatalogResponse {
    name: string;
    arn: string;
}
export declare const ImportSignalCatalogResponse: S.Schema<ImportSignalCatalogResponse>;
export type StatusStr = string;
export type ListResponseScope = "METADATA_ONLY" | (string & {});
export declare const ListResponseScope: any;
export interface ListCampaignsRequest {
    nextToken?: string;
    maxResults?: number;
    status?: string;
    listResponseScope?: ListResponseScope;
}
export declare const ListCampaignsRequest: S.Schema<ListCampaignsRequest>;
export interface CampaignSummary {
    arn?: string;
    name?: string;
    description?: string;
    signalCatalogArn?: string;
    targetArn?: string;
    status?: CampaignStatus;
    creationTime: Date;
    lastModificationTime: Date;
}
export declare const CampaignSummary: S.Schema<CampaignSummary>;
export type CampaignSummaries = CampaignSummary[];
export declare const CampaignSummaries: any;
export interface ListCampaignsResponse {
    campaignSummaries?: CampaignSummary[];
    nextToken?: string;
}
export declare const ListCampaignsResponse: S.Schema<ListCampaignsResponse>;
export interface ListDecoderManifestNetworkInterfacesRequest {
    name: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDecoderManifestNetworkInterfacesRequest: S.Schema<ListDecoderManifestNetworkInterfacesRequest>;
export interface ListDecoderManifestNetworkInterfacesResponse {
    networkInterfaces?: NetworkInterface[];
    nextToken?: string;
}
export declare const ListDecoderManifestNetworkInterfacesResponse: S.Schema<ListDecoderManifestNetworkInterfacesResponse>;
export interface ListDecoderManifestsRequest {
    modelManifestArn?: string;
    nextToken?: string;
    maxResults?: number;
    listResponseScope?: ListResponseScope;
}
export declare const ListDecoderManifestsRequest: S.Schema<ListDecoderManifestsRequest>;
export interface DecoderManifestSummary {
    name?: string;
    arn?: string;
    modelManifestArn?: string;
    description?: string;
    status?: ManifestStatus;
    creationTime: Date;
    lastModificationTime: Date;
    message?: string;
}
export declare const DecoderManifestSummary: S.Schema<DecoderManifestSummary>;
export type DecoderManifestSummaries = DecoderManifestSummary[];
export declare const DecoderManifestSummaries: any;
export interface ListDecoderManifestsResponse {
    summaries?: DecoderManifestSummary[];
    nextToken?: string;
}
export declare const ListDecoderManifestsResponse: S.Schema<ListDecoderManifestsResponse>;
export interface ListDecoderManifestSignalsRequest {
    name: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDecoderManifestSignalsRequest: S.Schema<ListDecoderManifestSignalsRequest>;
export interface ListDecoderManifestSignalsResponse {
    signalDecoders?: SignalDecoder[];
    nextToken?: string;
}
export declare const ListDecoderManifestSignalsResponse: S.Schema<ListDecoderManifestSignalsResponse>;
export interface ListFleetsRequest {
    nextToken?: string;
    maxResults?: number;
    listResponseScope?: ListResponseScope;
}
export declare const ListFleetsRequest: S.Schema<ListFleetsRequest>;
export interface FleetSummary {
    id: string;
    arn: string;
    description?: string;
    signalCatalogArn: string;
    creationTime: Date;
    lastModificationTime?: Date;
}
export declare const FleetSummary: S.Schema<FleetSummary>;
export type FleetSummaries = FleetSummary[];
export declare const FleetSummaries: any;
export interface ListFleetsResponse {
    fleetSummaries?: FleetSummary[];
    nextToken?: string;
}
export declare const ListFleetsResponse: S.Schema<ListFleetsResponse>;
export interface ListFleetsForVehicleRequest {
    vehicleName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListFleetsForVehicleRequest: S.Schema<ListFleetsForVehicleRequest>;
export type Fleets = string[];
export declare const Fleets: any;
export interface ListFleetsForVehicleResponse {
    fleets?: string[];
    nextToken?: string;
}
export declare const ListFleetsForVehicleResponse: S.Schema<ListFleetsForVehicleResponse>;
export interface ListModelManifestNodesRequest {
    name: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListModelManifestNodesRequest: S.Schema<ListModelManifestNodesRequest>;
export interface ListModelManifestNodesResponse {
    nodes?: Node[];
    nextToken?: string;
}
export declare const ListModelManifestNodesResponse: S.Schema<ListModelManifestNodesResponse>;
export interface ListModelManifestsRequest {
    signalCatalogArn?: string;
    nextToken?: string;
    maxResults?: number;
    listResponseScope?: ListResponseScope;
}
export declare const ListModelManifestsRequest: S.Schema<ListModelManifestsRequest>;
export interface ModelManifestSummary {
    name?: string;
    arn?: string;
    signalCatalogArn?: string;
    description?: string;
    status?: ManifestStatus;
    creationTime: Date;
    lastModificationTime: Date;
}
export declare const ModelManifestSummary: S.Schema<ModelManifestSummary>;
export type ModelManifestSummaries = ModelManifestSummary[];
export declare const ModelManifestSummaries: any;
export interface ListModelManifestsResponse {
    summaries?: ModelManifestSummary[];
    nextToken?: string;
}
export declare const ListModelManifestsResponse: S.Schema<ListModelManifestsResponse>;
export type SignalNodeType = "SENSOR" | "ACTUATOR" | "ATTRIBUTE" | "BRANCH" | "CUSTOM_STRUCT" | "CUSTOM_PROPERTY" | (string & {});
export declare const SignalNodeType: any;
export interface ListSignalCatalogNodesRequest {
    name: string;
    nextToken?: string;
    maxResults?: number;
    signalNodeType?: SignalNodeType;
}
export declare const ListSignalCatalogNodesRequest: S.Schema<ListSignalCatalogNodesRequest>;
export interface ListSignalCatalogNodesResponse {
    nodes?: Node[];
    nextToken?: string;
}
export declare const ListSignalCatalogNodesResponse: S.Schema<ListSignalCatalogNodesResponse>;
export interface ListSignalCatalogsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSignalCatalogsRequest: S.Schema<ListSignalCatalogsRequest>;
export interface SignalCatalogSummary {
    name?: string;
    arn?: string;
    creationTime?: Date;
    lastModificationTime?: Date;
}
export declare const SignalCatalogSummary: S.Schema<SignalCatalogSummary>;
export type SignalCatalogSummaries = SignalCatalogSummary[];
export declare const SignalCatalogSummaries: any;
export interface ListSignalCatalogsResponse {
    summaries?: SignalCatalogSummary[];
    nextToken?: string;
}
export declare const ListSignalCatalogsResponse: S.Schema<ListSignalCatalogsResponse>;
export interface ListStateTemplatesRequest {
    nextToken?: string;
    maxResults?: number;
    listResponseScope?: ListResponseScope;
}
export declare const ListStateTemplatesRequest: S.Schema<ListStateTemplatesRequest>;
export interface StateTemplateSummary {
    name?: string;
    arn?: string;
    signalCatalogArn?: string;
    description?: string;
    creationTime?: Date;
    lastModificationTime?: Date;
    id?: string;
}
export declare const StateTemplateSummary: S.Schema<StateTemplateSummary>;
export type StateTemplateSummaries = StateTemplateSummary[];
export declare const StateTemplateSummaries: any;
export interface ListStateTemplatesResponse {
    summaries?: StateTemplateSummary[];
    nextToken?: string;
}
export declare const ListStateTemplatesResponse: S.Schema<ListStateTemplatesResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type AttributeNamesList = string[];
export declare const AttributeNamesList: any;
export type AttributeValuesList = string[];
export declare const AttributeValuesList: any;
export type ListVehiclesMaxResults = number;
export interface ListVehiclesRequest {
    modelManifestArn?: string;
    attributeNames?: string[];
    attributeValues?: string[];
    nextToken?: string;
    maxResults?: number;
    listResponseScope?: ListResponseScope;
}
export declare const ListVehiclesRequest: S.Schema<ListVehiclesRequest>;
export interface VehicleSummary {
    vehicleName: string;
    arn: string;
    modelManifestArn: string;
    decoderManifestArn: string;
    creationTime: Date;
    lastModificationTime: Date;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export declare const VehicleSummary: S.Schema<VehicleSummary>;
export type VehicleSummaries = VehicleSummary[];
export declare const VehicleSummaries: any;
export interface ListVehiclesResponse {
    vehicleSummaries?: VehicleSummary[];
    nextToken?: string;
}
export declare const ListVehiclesResponse: S.Schema<ListVehiclesResponse>;
export interface ListVehiclesInFleetRequest {
    fleetId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListVehiclesInFleetRequest: S.Schema<ListVehiclesInFleetRequest>;
export type Vehicles = string[];
export declare const Vehicles: any;
export interface ListVehiclesInFleetResponse {
    vehicles?: string[];
    nextToken?: string;
}
export declare const ListVehiclesInFleetResponse: S.Schema<ListVehiclesInFleetResponse>;
export interface PutEncryptionConfigurationRequest {
    kmsKeyId?: string;
    encryptionType: EncryptionType;
}
export declare const PutEncryptionConfigurationRequest: S.Schema<PutEncryptionConfigurationRequest>;
export interface PutEncryptionConfigurationResponse {
    kmsKeyId?: string;
    encryptionStatus: EncryptionStatus;
    encryptionType: EncryptionType;
}
export declare const PutEncryptionConfigurationResponse: S.Schema<PutEncryptionConfigurationResponse>;
export interface PutLoggingOptionsRequest {
    cloudWatchLogDelivery: CloudWatchLogDeliveryOptions;
}
export declare const PutLoggingOptionsRequest: S.Schema<PutLoggingOptionsRequest>;
export interface PutLoggingOptionsResponse {
}
export declare const PutLoggingOptionsResponse: S.Schema<PutLoggingOptionsResponse>;
export interface TimestreamResources {
    timestreamDatabaseName: string;
    timestreamTableName: string;
}
export declare const TimestreamResources: S.Schema<TimestreamResources>;
export interface IamResources {
    roleArn: string;
}
export declare const IamResources: S.Schema<IamResources>;
export interface RegisterAccountRequest {
    timestreamResources?: TimestreamResources;
    iamResources?: IamResources;
}
export declare const RegisterAccountRequest: S.Schema<RegisterAccountRequest>;
export interface RegisterAccountResponse {
    registerAccountStatus: RegistrationStatus;
    timestreamResources?: TimestreamResources;
    iamResources: IamResources;
    creationTime: Date;
    lastModificationTime: Date;
}
export declare const RegisterAccountResponse: S.Schema<RegisterAccountResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type UpdateCampaignAction = "APPROVE" | "SUSPEND" | "RESUME" | "UPDATE" | (string & {});
export declare const UpdateCampaignAction: any;
export interface UpdateCampaignRequest {
    name: string;
    description?: string;
    dataExtraDimensions?: string[];
    action: UpdateCampaignAction;
}
export declare const UpdateCampaignRequest: S.Schema<UpdateCampaignRequest>;
export interface UpdateCampaignResponse {
    arn?: string;
    name?: string;
    status?: CampaignStatus;
}
export declare const UpdateCampaignResponse: S.Schema<UpdateCampaignResponse>;
export type Fqns = string[];
export declare const Fqns: any;
export type InterfaceIds = string[];
export declare const InterfaceIds: any;
export interface UpdateDecoderManifestRequest {
    name: string;
    description?: string;
    signalDecodersToAdd?: SignalDecoder[];
    signalDecodersToUpdate?: SignalDecoder[];
    signalDecodersToRemove?: string[];
    networkInterfacesToAdd?: NetworkInterface[];
    networkInterfacesToUpdate?: NetworkInterface[];
    networkInterfacesToRemove?: string[];
    status?: ManifestStatus;
    defaultForUnmappedSignals?: DefaultForUnmappedSignalsType;
}
export declare const UpdateDecoderManifestRequest: S.Schema<UpdateDecoderManifestRequest>;
export interface UpdateDecoderManifestResponse {
    name: string;
    arn: string;
}
export declare const UpdateDecoderManifestResponse: S.Schema<UpdateDecoderManifestResponse>;
export interface UpdateFleetRequest {
    fleetId: string;
    description?: string;
}
export declare const UpdateFleetRequest: S.Schema<UpdateFleetRequest>;
export interface UpdateFleetResponse {
    id?: string;
    arn?: string;
}
export declare const UpdateFleetResponse: S.Schema<UpdateFleetResponse>;
export type NodePaths = string[];
export declare const NodePaths: any;
export interface UpdateModelManifestRequest {
    name: string;
    description?: string;
    nodesToAdd?: string[];
    nodesToRemove?: string[];
    status?: ManifestStatus;
}
export declare const UpdateModelManifestRequest: S.Schema<UpdateModelManifestRequest>;
export interface UpdateModelManifestResponse {
    name: string;
    arn: string;
}
export declare const UpdateModelManifestResponse: S.Schema<UpdateModelManifestResponse>;
export interface UpdateSignalCatalogRequest {
    name: string;
    description?: string;
    nodesToAdd?: Node[];
    nodesToUpdate?: Node[];
    nodesToRemove?: string[];
}
export declare const UpdateSignalCatalogRequest: S.Schema<UpdateSignalCatalogRequest>;
export interface UpdateSignalCatalogResponse {
    name: string;
    arn: string;
}
export declare const UpdateSignalCatalogResponse: S.Schema<UpdateSignalCatalogResponse>;
export interface UpdateStateTemplateRequest {
    identifier: string;
    description?: string;
    stateTemplatePropertiesToAdd?: string[];
    stateTemplatePropertiesToRemove?: string[];
    dataExtraDimensions?: string[];
    metadataExtraDimensions?: string[];
}
export declare const UpdateStateTemplateRequest: S.Schema<UpdateStateTemplateRequest>;
export interface UpdateStateTemplateResponse {
    name?: string;
    arn?: string;
    id?: string;
}
export declare const UpdateStateTemplateResponse: S.Schema<UpdateStateTemplateResponse>;
export interface UpdateVehicleRequest {
    vehicleName: string;
    modelManifestArn?: string;
    decoderManifestArn?: string;
    attributes?: {
        [key: string]: string | undefined;
    };
    attributeUpdateMode?: UpdateMode;
    stateTemplatesToAdd?: StateTemplateAssociation[];
    stateTemplatesToRemove?: string[];
    stateTemplatesToUpdate?: StateTemplateAssociation[];
}
export declare const UpdateVehicleRequest: S.Schema<UpdateVehicleRequest>;
export interface UpdateVehicleResponse {
    vehicleName?: string;
    arn?: string;
}
export declare const UpdateVehicleResponse: S.Schema<UpdateVehicleResponse>;
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type SignalDecoderFailureReason = "DUPLICATE_SIGNAL" | "CONFLICTING_SIGNAL" | "SIGNAL_TO_ADD_ALREADY_EXISTS" | "SIGNAL_NOT_ASSOCIATED_WITH_NETWORK_INTERFACE" | "NETWORK_INTERFACE_TYPE_INCOMPATIBLE_WITH_SIGNAL_DECODER_TYPE" | "SIGNAL_NOT_IN_MODEL" | "CAN_SIGNAL_INFO_IS_NULL" | "OBD_SIGNAL_INFO_IS_NULL" | "NO_DECODER_INFO_FOR_SIGNAL_IN_MODEL" | "MESSAGE_SIGNAL_INFO_IS_NULL" | "SIGNAL_DECODER_TYPE_INCOMPATIBLE_WITH_MESSAGE_SIGNAL_TYPE" | "STRUCT_SIZE_MISMATCH" | "NO_SIGNAL_IN_CATALOG_FOR_DECODER_SIGNAL" | "SIGNAL_DECODER_INCOMPATIBLE_WITH_SIGNAL_CATALOG" | "EMPTY_MESSAGE_SIGNAL" | "CUSTOM_DECODING_SIGNAL_INFO_IS_NULL" | (string & {});
export declare const SignalDecoderFailureReason: any;
export interface InvalidSignalDecoder {
    name?: string;
    reason?: SignalDecoderFailureReason;
    hint?: string;
}
export declare const InvalidSignalDecoder: S.Schema<InvalidSignalDecoder>;
export type InvalidSignalDecoders = InvalidSignalDecoder[];
export declare const InvalidSignalDecoders: any;
export type NetworkInterfaceFailureReason = "DUPLICATE_NETWORK_INTERFACE" | "CONFLICTING_NETWORK_INTERFACE" | "NETWORK_INTERFACE_TO_ADD_ALREADY_EXISTS" | "CAN_NETWORK_INTERFACE_INFO_IS_NULL" | "OBD_NETWORK_INTERFACE_INFO_IS_NULL" | "NETWORK_INTERFACE_TO_REMOVE_ASSOCIATED_WITH_SIGNALS" | "VEHICLE_MIDDLEWARE_NETWORK_INTERFACE_INFO_IS_NULL" | "CUSTOM_DECODING_SIGNAL_NETWORK_INTERFACE_INFO_IS_NULL" | (string & {});
export declare const NetworkInterfaceFailureReason: any;
export interface InvalidNetworkInterface {
    interfaceId?: string;
    reason?: NetworkInterfaceFailureReason;
}
export declare const InvalidNetworkInterface: S.Schema<InvalidNetworkInterface>;
export type InvalidNetworkInterfaces = InvalidNetworkInterface[];
export declare const InvalidNetworkInterfaces: any;
export interface InvalidSignal {
    name?: string;
    reason?: string;
}
export declare const InvalidSignal: S.Schema<InvalidSignal>;
export type InvalidSignals = InvalidSignal[];
export declare const InvalidSignals: any;
export type AssociateVehicleFleetError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds, or associates, a vehicle with a fleet.
 */
export declare const associateVehicleFleet: API.OperationMethod<AssociateVehicleFleetRequest, AssociateVehicleFleetResponse, AssociateVehicleFleetError, Credentials | HttpClient.HttpClient>;
export type BatchCreateVehicleError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a group, or batch, of vehicles.
 *
 * You must specify a decoder manifest and a vehicle model (model manifest) for each
 * vehicle.
 *
 * For more information, see Create multiple
 * vehicles (AWS CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const batchCreateVehicle: API.OperationMethod<BatchCreateVehicleRequest, BatchCreateVehicleResponse, BatchCreateVehicleError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateVehicleError = AccessDeniedException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a group, or batch, of vehicles.
 *
 * You must specify a decoder manifest and a vehicle model (model manifest) for each
 * vehicle.
 *
 * For more information, see Update multiple
 * vehicles (AWS CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const batchUpdateVehicle: API.OperationMethod<BatchUpdateVehicleRequest, BatchUpdateVehicleResponse, BatchUpdateVehicleError, Credentials | HttpClient.HttpClient>;
export type CreateCampaignError = AccessDeniedException | ConflictException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an orchestration of data collection rules. The Amazon Web Services IoT FleetWise Edge Agent software
 * running in vehicles uses campaigns to decide how to collect and transfer data to the
 * cloud. You create campaigns in the cloud. After you or your team approve campaigns,
 * Amazon Web Services IoT FleetWise automatically deploys them to vehicles.
 *
 * For more information, see Collect and transfer data
 * with campaigns in the *Amazon Web Services IoT FleetWise Developer Guide*.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type CreateDecoderManifestError = AccessDeniedException | ConflictException | DecoderManifestValidationException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates the decoder manifest associated with a model manifest. To create a decoder
 * manifest, the following must be true:
 *
 * - Every signal decoder has a unique name.
 *
 * - Each signal decoder is associated with a network interface.
 *
 * - Each network interface has a unique ID.
 *
 * - The signal decoders are specified in the model manifest.
 */
export declare const createDecoderManifest: API.OperationMethod<CreateDecoderManifestRequest, CreateDecoderManifestResponse, CreateDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type CreateFleetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a fleet that represents a group of vehicles.
 *
 * You must create both a signal catalog and vehicles before you can create a fleet.
 *
 * For more information, see Fleets in the
 * *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createFleet: API.OperationMethod<CreateFleetRequest, CreateFleetResponse, CreateFleetError, Credentials | HttpClient.HttpClient>;
export type CreateModelManifestError = AccessDeniedException | ConflictException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a vehicle model (model manifest) that specifies signals (attributes,
 * branches, sensors, and actuators).
 *
 * For more information, see Vehicle models
 * in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createModelManifest: API.OperationMethod<CreateModelManifestRequest, CreateModelManifestResponse, CreateModelManifestError, Credentials | HttpClient.HttpClient>;
export type CreateSignalCatalogError = AccessDeniedException | ConflictException | InvalidNodeException | InvalidSignalsException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a collection of standardized signals that can be reused to create vehicle
 * models.
 */
export declare const createSignalCatalog: API.OperationMethod<CreateSignalCatalogRequest, CreateSignalCatalogResponse, CreateSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type CreateStateTemplateError = AccessDeniedException | ConflictException | InternalServerException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a state template. State templates contain state properties, which are signals that belong to a signal catalog that is synchronized between the Amazon Web Services IoT FleetWise Edge and the Amazon Web Services Cloud.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createStateTemplate: API.OperationMethod<CreateStateTemplateRequest, CreateStateTemplateResponse, CreateStateTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateVehicleError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a vehicle, which is an instance of a vehicle model (model manifest). Vehicles
 * created from the same vehicle model consist of the same signals inherited from the
 * vehicle model.
 *
 * If you have an existing Amazon Web Services IoT thing, you can use Amazon Web Services IoT FleetWise to create a
 * vehicle and collect data from your thing.
 *
 * For more information, see Create a vehicle
 * (AWS CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const createVehicle: API.OperationMethod<CreateVehicleRequest, CreateVehicleResponse, CreateVehicleError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a data collection campaign. Deleting a campaign suspends all data collection
 * and removes it from any vehicles.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteDecoderManifestError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a decoder manifest. You can't delete a decoder manifest if it has vehicles
 * associated with it.
 */
export declare const deleteDecoderManifest: API.OperationMethod<DeleteDecoderManifestRequest, DeleteDecoderManifestResponse, DeleteDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a fleet. Before you delete a fleet, all vehicles must be
 * dissociated from the fleet. For more information, see Delete a fleet (AWS
 * CLI) in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const deleteFleet: API.OperationMethod<DeleteFleetRequest, DeleteFleetResponse, DeleteFleetError, Credentials | HttpClient.HttpClient>;
export type DeleteModelManifestError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a vehicle model (model manifest).
 */
export declare const deleteModelManifest: API.OperationMethod<DeleteModelManifestRequest, DeleteModelManifestResponse, DeleteModelManifestError, Credentials | HttpClient.HttpClient>;
export type DeleteSignalCatalogError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a signal catalog.
 */
export declare const deleteSignalCatalog: API.OperationMethod<DeleteSignalCatalogRequest, DeleteSignalCatalogResponse, DeleteSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type DeleteStateTemplateError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a state template.
 */
export declare const deleteStateTemplate: API.OperationMethod<DeleteStateTemplateRequest, DeleteStateTemplateResponse, DeleteStateTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteVehicleError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a vehicle and removes it from any campaigns.
 */
export declare const deleteVehicle: API.OperationMethod<DeleteVehicleRequest, DeleteVehicleResponse, DeleteVehicleError, Credentials | HttpClient.HttpClient>;
export type DisassociateVehicleFleetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes, or disassociates, a vehicle from a fleet. Disassociating a vehicle from a
 * fleet doesn't delete the vehicle.
 */
export declare const disassociateVehicleFleet: API.OperationMethod<DisassociateVehicleFleetRequest, DisassociateVehicleFleetResponse, DisassociateVehicleFleetError, Credentials | HttpClient.HttpClient>;
export type GetCampaignError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a campaign.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const getCampaign: API.OperationMethod<GetCampaignRequest, GetCampaignResponse, GetCampaignError, Credentials | HttpClient.HttpClient>;
export type GetDecoderManifestError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a created decoder manifest.
 */
export declare const getDecoderManifest: API.OperationMethod<GetDecoderManifestRequest, GetDecoderManifestResponse, GetDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type GetEncryptionConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the encryption configuration for resources and data in Amazon Web Services IoT FleetWise.
 */
export declare const getEncryptionConfiguration: API.OperationMethod<GetEncryptionConfigurationRequest, GetEncryptionConfigurationResponse, GetEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetFleetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a fleet.
 */
export declare const getFleet: API.OperationMethod<GetFleetRequest, GetFleetResponse, GetFleetError, Credentials | HttpClient.HttpClient>;
export type GetLoggingOptionsError = AccessDeniedException | ThrottlingException | CommonErrors;
/**
 * Retrieves the logging options.
 */
export declare const getLoggingOptions: API.OperationMethod<GetLoggingOptionsRequest, GetLoggingOptionsResponse, GetLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type GetModelManifestError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a vehicle model (model manifest).
 */
export declare const getModelManifest: API.OperationMethod<GetModelManifestRequest, GetModelManifestResponse, GetModelManifestError, Credentials | HttpClient.HttpClient>;
export type GetRegisterAccountStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the status of registering your Amazon Web Services account, IAM, and
 * Amazon Timestream resources so that Amazon Web Services IoT FleetWise can transfer your vehicle data to the Amazon Web Services
 * Cloud.
 *
 * For more information, including step-by-step procedures, see Setting up Amazon Web Services IoT FleetWise.
 *
 * This API operation doesn't require input parameters.
 */
export declare const getRegisterAccountStatus: API.OperationMethod<GetRegisterAccountStatusRequest, GetRegisterAccountStatusResponse, GetRegisterAccountStatusError, Credentials | HttpClient.HttpClient>;
export type GetSignalCatalogError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a signal catalog.
 */
export declare const getSignalCatalog: API.OperationMethod<GetSignalCatalogRequest, GetSignalCatalogResponse, GetSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type GetStateTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a state template.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const getStateTemplate: API.OperationMethod<GetStateTemplateRequest, GetStateTemplateResponse, GetStateTemplateError, Credentials | HttpClient.HttpClient>;
export type GetVehicleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a vehicle.
 */
export declare const getVehicle: API.OperationMethod<GetVehicleRequest, GetVehicleResponse, GetVehicleError, Credentials | HttpClient.HttpClient>;
export type GetVehicleStatusError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the status of campaigns, decoder manifests, or state templates
 * associated with a vehicle.
 */
export declare const getVehicleStatus: API.PaginatedOperationMethod<GetVehicleStatusRequest, GetVehicleStatusResponse, GetVehicleStatusError, Credentials | HttpClient.HttpClient, VehicleStatus>;
export type ImportDecoderManifestError = AccessDeniedException | ConflictException | DecoderManifestValidationException | InvalidSignalsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a decoder manifest using your existing CAN DBC file from your local device.
 *
 * The CAN signal name must be unique and not repeated across CAN message definitions in a .dbc file.
 */
export declare const importDecoderManifest: API.OperationMethod<ImportDecoderManifestRequest, ImportDecoderManifestResponse, ImportDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type ImportSignalCatalogError = AccessDeniedException | ConflictException | InternalServerException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a signal catalog using your existing VSS formatted content from your local
 * device.
 */
export declare const importSignalCatalog: API.OperationMethod<ImportSignalCatalogRequest, ImportSignalCatalogResponse, ImportSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type ListCampaignsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about created campaigns.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listCampaigns: API.PaginatedOperationMethod<ListCampaignsRequest, ListCampaignsResponse, ListCampaignsError, Credentials | HttpClient.HttpClient, CampaignSummary>;
export type ListDecoderManifestNetworkInterfacesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the network interfaces specified in a decoder manifest.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listDecoderManifestNetworkInterfaces: API.PaginatedOperationMethod<ListDecoderManifestNetworkInterfacesRequest, ListDecoderManifestNetworkInterfacesResponse, ListDecoderManifestNetworkInterfacesError, Credentials | HttpClient.HttpClient, NetworkInterface>;
export type ListDecoderManifestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists decoder manifests.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listDecoderManifests: API.PaginatedOperationMethod<ListDecoderManifestsRequest, ListDecoderManifestsResponse, ListDecoderManifestsError, Credentials | HttpClient.HttpClient, DecoderManifestSummary>;
export type ListDecoderManifestSignalsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A list of information about signal decoders specified in a decoder manifest.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listDecoderManifestSignals: API.PaginatedOperationMethod<ListDecoderManifestSignalsRequest, ListDecoderManifestSignalsResponse, ListDecoderManifestSignalsError, Credentials | HttpClient.HttpClient, SignalDecoder>;
export type ListFleetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information for each created fleet in an Amazon Web Services account.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listFleets: API.PaginatedOperationMethod<ListFleetsRequest, ListFleetsResponse, ListFleetsError, Credentials | HttpClient.HttpClient, FleetSummary>;
export type ListFleetsForVehicleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of IDs for all fleets that the vehicle is associated with.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listFleetsForVehicle: API.PaginatedOperationMethod<ListFleetsForVehicleRequest, ListFleetsForVehicleResponse, ListFleetsForVehicleError, Credentials | HttpClient.HttpClient, FleetId>;
export type ListModelManifestNodesError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about nodes specified in a vehicle model (model manifest).
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listModelManifestNodes: API.PaginatedOperationMethod<ListModelManifestNodesRequest, ListModelManifestNodesResponse, ListModelManifestNodesError, Credentials | HttpClient.HttpClient, Node>;
export type ListModelManifestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of vehicle models (model manifests).
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listModelManifests: API.PaginatedOperationMethod<ListModelManifestsRequest, ListModelManifestsResponse, ListModelManifestsError, Credentials | HttpClient.HttpClient, ModelManifestSummary>;
export type ListSignalCatalogNodesError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists of information about the signals (nodes) specified in a signal catalog.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listSignalCatalogNodes: API.PaginatedOperationMethod<ListSignalCatalogNodesRequest, ListSignalCatalogNodesResponse, ListSignalCatalogNodesError, Credentials | HttpClient.HttpClient, Node>;
export type ListSignalCatalogsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the created signal catalogs in an Amazon Web Services account.
 *
 * You can use to list information about
 * each signal (node) specified in a signal catalog.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listSignalCatalogs: API.PaginatedOperationMethod<ListSignalCatalogsRequest, ListSignalCatalogsResponse, ListSignalCatalogsError, Credentials | HttpClient.HttpClient, SignalCatalogSummary>;
export type ListStateTemplatesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about created state templates.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const listStateTemplates: API.PaginatedOperationMethod<ListStateTemplatesRequest, ListStateTemplatesResponse, ListStateTemplatesError, Credentials | HttpClient.HttpClient, StateTemplateSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags (metadata) you have assigned to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVehiclesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of summaries of created vehicles.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listVehicles: API.PaginatedOperationMethod<ListVehiclesRequest, ListVehiclesResponse, ListVehiclesError, Credentials | HttpClient.HttpClient, VehicleSummary>;
export type ListVehiclesInFleetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of summaries of all vehicles associated with a fleet.
 *
 * This API operation uses pagination. Specify the `nextToken` parameter in the request to return more results.
 */
export declare const listVehiclesInFleet: API.PaginatedOperationMethod<ListVehiclesInFleetRequest, ListVehiclesInFleetResponse, ListVehiclesInFleetError, Credentials | HttpClient.HttpClient, VehicleName>;
export type PutEncryptionConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates the encryption configuration. Amazon Web Services IoT FleetWise can encrypt your data and
 * resources using an Amazon Web Services managed key. Or, you can use a KMS key that you own and
 * manage. For more information, see Data
 * encryption in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const putEncryptionConfiguration: API.OperationMethod<PutEncryptionConfigurationRequest, PutEncryptionConfigurationResponse, PutEncryptionConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutLoggingOptionsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates the logging option.
 */
export declare const putLoggingOptions: API.OperationMethod<PutLoggingOptionsRequest, PutLoggingOptionsResponse, PutLoggingOptionsError, Credentials | HttpClient.HttpClient>;
export type RegisterAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This API operation contains deprecated parameters. Register your account again
 * without the Timestream resources parameter so that Amazon Web Services IoT FleetWise can remove the Timestream
 * metadata stored. You should then pass the data destination into the CreateCampaign API operation.
 *
 * You must delete any existing campaigns that include an empty data destination
 * before you register your account again. For more information, see the DeleteCampaign API operation.
 *
 * If you want to delete the Timestream inline policy from the service-linked role, such
 * as to mitigate an overly permissive policy, you must first delete any existing
 * campaigns. Then delete the service-linked role and register your account again to
 * enable CloudWatch metrics. For more information, see DeleteServiceLinkedRole in the Identity and Access Management API
 * Reference.
 *
 * Registers your Amazon Web Services account, IAM, and Amazon Timestream resources so Amazon Web Services IoT FleetWise can
 * transfer your vehicle data to the Amazon Web Services Cloud. For more information, including
 * step-by-step procedures, see Setting up
 * Amazon Web Services IoT FleetWise.
 *
 * An Amazon Web Services account is **not** the same thing as a
 * "user." An Amazon Web Services user is an identity that you create using Identity and Access Management (IAM) and
 * takes the form of either an IAM user or an IAM role, both
 * with credentials. A single Amazon Web Services account can, and typically does,
 * contain many users and roles.
 */
export declare const registerAccount: API.OperationMethod<RegisterAccountRequest, RegisterAccountResponse, RegisterAccountError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds to or modifies the tags of the given resource. Tags are metadata which can be
 * used to manage a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the given tags (metadata) from the resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a campaign.
 */
export declare const updateCampaign: API.OperationMethod<UpdateCampaignRequest, UpdateCampaignResponse, UpdateCampaignError, Credentials | HttpClient.HttpClient>;
export type UpdateDecoderManifestError = AccessDeniedException | ConflictException | DecoderManifestValidationException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a decoder manifest.
 *
 * A decoder manifest can only be updated when the status is `DRAFT`. Only
 * `ACTIVE` decoder manifests can be associated with vehicles.
 */
export declare const updateDecoderManifest: API.OperationMethod<UpdateDecoderManifestRequest, UpdateDecoderManifestResponse, UpdateDecoderManifestError, Credentials | HttpClient.HttpClient>;
export type UpdateFleetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the description of an existing fleet.
 */
export declare const updateFleet: API.OperationMethod<UpdateFleetRequest, UpdateFleetResponse, UpdateFleetError, Credentials | HttpClient.HttpClient>;
export type UpdateModelManifestError = AccessDeniedException | ConflictException | InternalServerException | InvalidSignalsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a vehicle model (model manifest). If created vehicles are associated with a
 * vehicle model, it can't be updated.
 */
export declare const updateModelManifest: API.OperationMethod<UpdateModelManifestRequest, UpdateModelManifestResponse, UpdateModelManifestError, Credentials | HttpClient.HttpClient>;
export type UpdateSignalCatalogError = AccessDeniedException | ConflictException | InternalServerException | InvalidNodeException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a signal catalog.
 */
export declare const updateSignalCatalog: API.OperationMethod<UpdateSignalCatalogRequest, UpdateSignalCatalogResponse, UpdateSignalCatalogError, Credentials | HttpClient.HttpClient>;
export type UpdateStateTemplateError = AccessDeniedException | InternalServerException | InvalidSignalsException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a state template.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const updateStateTemplate: API.OperationMethod<UpdateStateTemplateRequest, UpdateStateTemplateResponse, UpdateStateTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateVehicleError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a vehicle.
 *
 * Access to certain Amazon Web Services IoT FleetWise features is currently gated. For more information, see Amazon Web Services Region and feature availability in the *Amazon Web Services IoT FleetWise Developer Guide*.
 */
export declare const updateVehicle: API.OperationMethod<UpdateVehicleRequest, UpdateVehicleResponse, UpdateVehicleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotfleetwise.d.ts.map