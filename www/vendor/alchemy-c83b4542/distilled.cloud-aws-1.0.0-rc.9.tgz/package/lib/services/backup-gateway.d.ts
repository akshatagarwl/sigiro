import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly ErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type GatewayArn = string;
export type ServerArn = string;
export interface AssociateGatewayToServerInput {
    GatewayArn: string;
    ServerArn: string;
}
export declare const AssociateGatewayToServerInput: S.Schema<AssociateGatewayToServerInput>;
export interface AssociateGatewayToServerOutput {
    GatewayArn?: string;
}
export declare const AssociateGatewayToServerOutput: S.Schema<AssociateGatewayToServerOutput>;
export type ActivationKey = string;
export type Name = string;
export type GatewayType = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export interface CreateGatewayInput {
    ActivationKey: string;
    GatewayDisplayName: string;
    GatewayType: string;
    Tags?: Tag[];
}
export declare const CreateGatewayInput: S.Schema<CreateGatewayInput>;
export interface CreateGatewayOutput {
    GatewayArn?: string;
}
export declare const CreateGatewayOutput: S.Schema<CreateGatewayOutput>;
export interface DeleteGatewayInput {
    GatewayArn: string;
}
export declare const DeleteGatewayInput: S.Schema<DeleteGatewayInput>;
export interface DeleteGatewayOutput {
    GatewayArn?: string;
}
export declare const DeleteGatewayOutput: S.Schema<DeleteGatewayOutput>;
export interface DeleteHypervisorInput {
    HypervisorArn: string;
}
export declare const DeleteHypervisorInput: S.Schema<DeleteHypervisorInput>;
export interface DeleteHypervisorOutput {
    HypervisorArn?: string;
}
export declare const DeleteHypervisorOutput: S.Schema<DeleteHypervisorOutput>;
export interface DisassociateGatewayFromServerInput {
    GatewayArn: string;
}
export declare const DisassociateGatewayFromServerInput: S.Schema<DisassociateGatewayFromServerInput>;
export interface DisassociateGatewayFromServerOutput {
    GatewayArn?: string;
}
export declare const DisassociateGatewayFromServerOutput: S.Schema<DisassociateGatewayFromServerOutput>;
export interface GetBandwidthRateLimitScheduleInput {
    GatewayArn: string;
}
export declare const GetBandwidthRateLimitScheduleInput: S.Schema<GetBandwidthRateLimitScheduleInput>;
export type AverageUploadRateLimit = number;
export type HourOfDay = number;
export type MinuteOfHour = number;
export type DayOfWeek = number;
export type DaysOfWeek = number[];
export declare const DaysOfWeek: any;
export interface BandwidthRateLimitInterval {
    AverageUploadRateLimitInBitsPerSec?: number;
    StartHourOfDay: number;
    EndHourOfDay: number;
    StartMinuteOfHour: number;
    EndMinuteOfHour: number;
    DaysOfWeek: number[];
}
export declare const BandwidthRateLimitInterval: S.Schema<BandwidthRateLimitInterval>;
export type BandwidthRateLimitIntervals = BandwidthRateLimitInterval[];
export declare const BandwidthRateLimitIntervals: any;
export interface GetBandwidthRateLimitScheduleOutput {
    GatewayArn?: string;
    BandwidthRateLimitIntervals?: BandwidthRateLimitInterval[];
}
export declare const GetBandwidthRateLimitScheduleOutput: S.Schema<GetBandwidthRateLimitScheduleOutput>;
export interface GetGatewayInput {
    GatewayArn: string;
}
export declare const GetGatewayInput: S.Schema<GetGatewayInput>;
export type HypervisorId = string;
export type DayOfMonth = number;
export interface MaintenanceStartTime {
    DayOfMonth?: number;
    DayOfWeek?: number;
    HourOfDay: number;
    MinuteOfHour: number;
}
export declare const MaintenanceStartTime: S.Schema<MaintenanceStartTime>;
export type VpcEndpoint = string;
export interface GatewayDetails {
    GatewayArn?: string;
    GatewayDisplayName?: string;
    GatewayType?: string;
    HypervisorId?: string;
    LastSeenTime?: Date;
    MaintenanceStartTime?: MaintenanceStartTime;
    NextUpdateAvailabilityTime?: Date;
    VpcEndpoint?: string;
    DeprecationDate?: Date;
    SoftwareVersion?: string;
}
export declare const GatewayDetails: S.Schema<GatewayDetails>;
export interface GetGatewayOutput {
    Gateway?: GatewayDetails;
}
export declare const GetGatewayOutput: S.Schema<GetGatewayOutput>;
export interface GetHypervisorInput {
    HypervisorArn: string;
}
export declare const GetHypervisorInput: S.Schema<GetHypervisorInput>;
export type Host = string;
export type KmsKeyArn = string;
export type LogGroupArn = string;
export type HypervisorState = string;
export type SyncMetadataStatus = string;
export interface HypervisorDetails {
    Host?: string;
    HypervisorArn?: string;
    KmsKeyArn?: string;
    Name?: string;
    LogGroupArn?: string;
    State?: string;
    LastSuccessfulMetadataSyncTime?: Date;
    LatestMetadataSyncStatusMessage?: string;
    LatestMetadataSyncStatus?: string;
}
export declare const HypervisorDetails: S.Schema<HypervisorDetails>;
export interface GetHypervisorOutput {
    Hypervisor?: HypervisorDetails;
}
export declare const GetHypervisorOutput: S.Schema<GetHypervisorOutput>;
export interface GetHypervisorPropertyMappingsInput {
    HypervisorArn: string;
}
export declare const GetHypervisorPropertyMappingsInput: S.Schema<GetHypervisorPropertyMappingsInput>;
export type VmwareCategory = string;
export type VmwareTagName = string;
export interface VmwareToAwsTagMapping {
    VmwareCategory: string;
    VmwareTagName: string;
    AwsTagKey: string;
    AwsTagValue: string;
}
export declare const VmwareToAwsTagMapping: S.Schema<VmwareToAwsTagMapping>;
export type VmwareToAwsTagMappings = VmwareToAwsTagMapping[];
export declare const VmwareToAwsTagMappings: any;
export type IamRoleArn = string;
export interface GetHypervisorPropertyMappingsOutput {
    HypervisorArn?: string;
    VmwareToAwsTagMappings?: VmwareToAwsTagMapping[];
    IamRoleArn?: string;
}
export declare const GetHypervisorPropertyMappingsOutput: S.Schema<GetHypervisorPropertyMappingsOutput>;
export type ResourceArn = string;
export interface GetVirtualMachineInput {
    ResourceArn: string;
}
export declare const GetVirtualMachineInput: S.Schema<GetVirtualMachineInput>;
export type Path = string;
export interface VmwareTag {
    VmwareCategory?: string;
    VmwareTagName?: string;
    VmwareTagDescription?: string;
}
export declare const VmwareTag: S.Schema<VmwareTag>;
export type VmwareTags = VmwareTag[];
export declare const VmwareTags: any;
export interface VirtualMachineDetails {
    HostName?: string;
    HypervisorId?: string;
    Name?: string;
    Path?: string;
    ResourceArn?: string;
    LastBackupDate?: Date;
    VmwareTags?: VmwareTag[];
}
export declare const VirtualMachineDetails: S.Schema<VirtualMachineDetails>;
export interface GetVirtualMachineOutput {
    VirtualMachine?: VirtualMachineDetails;
}
export declare const GetVirtualMachineOutput: S.Schema<GetVirtualMachineOutput>;
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export interface ImportHypervisorConfigurationInput {
    Name: string;
    Host: string;
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
    KmsKeyArn?: string;
    Tags?: Tag[];
}
export declare const ImportHypervisorConfigurationInput: S.Schema<ImportHypervisorConfigurationInput>;
export interface ImportHypervisorConfigurationOutput {
    HypervisorArn?: string;
}
export declare const ImportHypervisorConfigurationOutput: S.Schema<ImportHypervisorConfigurationOutput>;
export type MaxResults = number;
export type NextToken = string;
export interface ListGatewaysInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListGatewaysInput: S.Schema<ListGatewaysInput>;
export interface Gateway {
    GatewayArn?: string;
    GatewayDisplayName?: string;
    GatewayType?: string;
    HypervisorId?: string;
    LastSeenTime?: Date;
}
export declare const Gateway: S.Schema<Gateway>;
export type Gateways = Gateway[];
export declare const Gateways: any;
export interface ListGatewaysOutput {
    Gateways?: Gateway[];
    NextToken?: string;
}
export declare const ListGatewaysOutput: S.Schema<ListGatewaysOutput>;
export interface ListHypervisorsInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListHypervisorsInput: S.Schema<ListHypervisorsInput>;
export interface Hypervisor {
    Host?: string;
    HypervisorArn?: string;
    KmsKeyArn?: string;
    Name?: string;
    State?: string;
}
export declare const Hypervisor: S.Schema<Hypervisor>;
export type Hypervisors = Hypervisor[];
export declare const Hypervisors: any;
export interface ListHypervisorsOutput {
    Hypervisors?: Hypervisor[];
    NextToken?: string;
}
export declare const ListHypervisorsOutput: S.Schema<ListHypervisorsOutput>;
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export declare const ListTagsForResourceInput: S.Schema<ListTagsForResourceInput>;
export interface ListTagsForResourceOutput {
    ResourceArn?: string;
    Tags?: Tag[];
}
export declare const ListTagsForResourceOutput: S.Schema<ListTagsForResourceOutput>;
export interface ListVirtualMachinesInput {
    HypervisorArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListVirtualMachinesInput: S.Schema<ListVirtualMachinesInput>;
export interface VirtualMachine {
    HostName?: string;
    HypervisorId?: string;
    Name?: string;
    Path?: string;
    ResourceArn?: string;
    LastBackupDate?: Date;
}
export declare const VirtualMachine: S.Schema<VirtualMachine>;
export type VirtualMachines = VirtualMachine[];
export declare const VirtualMachines: any;
export interface ListVirtualMachinesOutput {
    VirtualMachines?: VirtualMachine[];
    NextToken?: string;
}
export declare const ListVirtualMachinesOutput: S.Schema<ListVirtualMachinesOutput>;
export interface PutBandwidthRateLimitScheduleInput {
    GatewayArn: string;
    BandwidthRateLimitIntervals: BandwidthRateLimitInterval[];
}
export declare const PutBandwidthRateLimitScheduleInput: S.Schema<PutBandwidthRateLimitScheduleInput>;
export interface PutBandwidthRateLimitScheduleOutput {
    GatewayArn?: string;
}
export declare const PutBandwidthRateLimitScheduleOutput: S.Schema<PutBandwidthRateLimitScheduleOutput>;
export interface PutHypervisorPropertyMappingsInput {
    HypervisorArn: string;
    VmwareToAwsTagMappings: VmwareToAwsTagMapping[];
    IamRoleArn: string;
}
export declare const PutHypervisorPropertyMappingsInput: S.Schema<PutHypervisorPropertyMappingsInput>;
export interface PutHypervisorPropertyMappingsOutput {
    HypervisorArn?: string;
}
export declare const PutHypervisorPropertyMappingsOutput: S.Schema<PutHypervisorPropertyMappingsOutput>;
export interface PutMaintenanceStartTimeInput {
    GatewayArn: string;
    HourOfDay: number;
    MinuteOfHour: number;
    DayOfWeek?: number;
    DayOfMonth?: number;
}
export declare const PutMaintenanceStartTimeInput: S.Schema<PutMaintenanceStartTimeInput>;
export interface PutMaintenanceStartTimeOutput {
    GatewayArn?: string;
}
export declare const PutMaintenanceStartTimeOutput: S.Schema<PutMaintenanceStartTimeOutput>;
export interface StartVirtualMachinesMetadataSyncInput {
    HypervisorArn: string;
}
export declare const StartVirtualMachinesMetadataSyncInput: S.Schema<StartVirtualMachinesMetadataSyncInput>;
export interface StartVirtualMachinesMetadataSyncOutput {
    HypervisorArn?: string;
}
export declare const StartVirtualMachinesMetadataSyncOutput: S.Schema<StartVirtualMachinesMetadataSyncOutput>;
export interface TagResourceInput {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceOutput {
    ResourceARN?: string;
}
export declare const TagResourceOutput: S.Schema<TagResourceOutput>;
export interface TestHypervisorConfigurationInput {
    GatewayArn: string;
    Host: string;
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
}
export declare const TestHypervisorConfigurationInput: S.Schema<TestHypervisorConfigurationInput>;
export interface TestHypervisorConfigurationOutput {
}
export declare const TestHypervisorConfigurationOutput: S.Schema<TestHypervisorConfigurationOutput>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceInput {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceOutput {
    ResourceARN?: string;
}
export declare const UntagResourceOutput: S.Schema<UntagResourceOutput>;
export interface UpdateGatewayInformationInput {
    GatewayArn: string;
    GatewayDisplayName?: string;
}
export declare const UpdateGatewayInformationInput: S.Schema<UpdateGatewayInformationInput>;
export interface UpdateGatewayInformationOutput {
    GatewayArn?: string;
}
export declare const UpdateGatewayInformationOutput: S.Schema<UpdateGatewayInformationOutput>;
export interface UpdateGatewaySoftwareNowInput {
    GatewayArn: string;
}
export declare const UpdateGatewaySoftwareNowInput: S.Schema<UpdateGatewaySoftwareNowInput>;
export interface UpdateGatewaySoftwareNowOutput {
    GatewayArn?: string;
}
export declare const UpdateGatewaySoftwareNowOutput: S.Schema<UpdateGatewaySoftwareNowOutput>;
export interface UpdateHypervisorInput {
    HypervisorArn: string;
    Host?: string;
    Username?: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string>;
    Name?: string;
    LogGroupArn?: string;
}
export declare const UpdateHypervisorInput: S.Schema<UpdateHypervisorInput>;
export interface UpdateHypervisorOutput {
    HypervisorArn?: string;
}
export declare const UpdateHypervisorOutput: S.Schema<UpdateHypervisorOutput>;
export type AssociateGatewayToServerError = ConflictException | CommonErrors;
/**
 * Associates a backup gateway with your server. After you complete the association process, you can back up and restore your VMs through the gateway.
 */
export declare const associateGatewayToServer: API.OperationMethod<AssociateGatewayToServerInput, AssociateGatewayToServerOutput, AssociateGatewayToServerError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = CommonErrors;
/**
 * Creates a backup gateway. After you create a gateway, you can associate it with a server using the `AssociateGatewayToServer` operation.
 */
export declare const createGateway: API.OperationMethod<CreateGatewayInput, CreateGatewayOutput, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = ResourceNotFoundException | CommonErrors;
/**
 * Deletes a backup gateway.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayInput, DeleteGatewayOutput, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteHypervisorError = AccessDeniedException | ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a hypervisor.
 */
export declare const deleteHypervisor: API.OperationMethod<DeleteHypervisorInput, DeleteHypervisorOutput, DeleteHypervisorError, Credentials | HttpClient.HttpClient>;
export type DisassociateGatewayFromServerError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a backup gateway from the specified server. After the disassociation process finishes, the gateway can no longer access the virtual machines on the server.
 */
export declare const disassociateGatewayFromServer: API.OperationMethod<DisassociateGatewayFromServerInput, DisassociateGatewayFromServerOutput, DisassociateGatewayFromServerError, Credentials | HttpClient.HttpClient>;
export type GetBandwidthRateLimitScheduleError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the bandwidth rate limit schedule for a specified gateway. By default, gateways do not have bandwidth rate limit schedules, which means no bandwidth rate limiting is in effect. Use this to get a gateway's bandwidth rate limit schedule.
 */
export declare const getBandwidthRateLimitSchedule: API.OperationMethod<GetBandwidthRateLimitScheduleInput, GetBandwidthRateLimitScheduleOutput, GetBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type GetGatewayError = ResourceNotFoundException | CommonErrors;
/**
 * By providing the ARN (Amazon Resource Name), this API returns the gateway.
 */
export declare const getGateway: API.OperationMethod<GetGatewayInput, GetGatewayOutput, GetGatewayError, Credentials | HttpClient.HttpClient>;
export type GetHypervisorError = ResourceNotFoundException | CommonErrors;
/**
 * This action requests information about the specified hypervisor to which the gateway will connect. A hypervisor is hardware, software, or firmware that creates and manages virtual machines, and allocates resources to them.
 */
export declare const getHypervisor: API.OperationMethod<GetHypervisorInput, GetHypervisorOutput, GetHypervisorError, Credentials | HttpClient.HttpClient>;
export type GetHypervisorPropertyMappingsError = ResourceNotFoundException | CommonErrors;
/**
 * This action retrieves the property mappings for the specified hypervisor. A hypervisor property mapping displays the relationship of entity properties available from the hypervisor to the properties available in Amazon Web Services.
 */
export declare const getHypervisorPropertyMappings: API.OperationMethod<GetHypervisorPropertyMappingsInput, GetHypervisorPropertyMappingsOutput, GetHypervisorPropertyMappingsError, Credentials | HttpClient.HttpClient>;
export type GetVirtualMachineError = ResourceNotFoundException | CommonErrors;
/**
 * By providing the ARN (Amazon Resource Name), this API returns the virtual machine.
 */
export declare const getVirtualMachine: API.OperationMethod<GetVirtualMachineInput, GetVirtualMachineOutput, GetVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type ImportHypervisorConfigurationError = AccessDeniedException | ConflictException | CommonErrors;
/**
 * Connect to a hypervisor by importing its configuration.
 */
export declare const importHypervisorConfiguration: API.OperationMethod<ImportHypervisorConfigurationInput, ImportHypervisorConfigurationOutput, ImportHypervisorConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListGatewaysError = CommonErrors;
/**
 * Lists backup gateways owned by an Amazon Web Services account in an Amazon Web Services Region. The returned list is ordered by gateway Amazon Resource Name (ARN).
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysInput, ListGatewaysOutput, ListGatewaysError, Credentials | HttpClient.HttpClient, Gateway>;
export type ListHypervisorsError = CommonErrors;
/**
 * Lists your hypervisors.
 */
export declare const listHypervisors: API.PaginatedOperationMethod<ListHypervisorsInput, ListHypervisorsOutput, ListHypervisorsError, Credentials | HttpClient.HttpClient, Hypervisor>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags applied to the resource identified by its Amazon Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVirtualMachinesError = CommonErrors;
/**
 * Lists your virtual machines.
 */
export declare const listVirtualMachines: API.PaginatedOperationMethod<ListVirtualMachinesInput, ListVirtualMachinesOutput, ListVirtualMachinesError, Credentials | HttpClient.HttpClient, VirtualMachine>;
export type PutBandwidthRateLimitScheduleError = ResourceNotFoundException | CommonErrors;
/**
 * This action sets the bandwidth rate limit schedule for a specified gateway. By default, gateways do not have a bandwidth rate limit schedule, which means no bandwidth rate limiting is in effect. Use this to initiate a gateway's bandwidth rate limit schedule.
 */
export declare const putBandwidthRateLimitSchedule: API.OperationMethod<PutBandwidthRateLimitScheduleInput, PutBandwidthRateLimitScheduleOutput, PutBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type PutHypervisorPropertyMappingsError = AccessDeniedException | ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * This action sets the property mappings for the specified hypervisor. A hypervisor property mapping displays the relationship of entity properties available from the hypervisor to the properties available in Amazon Web Services.
 */
export declare const putHypervisorPropertyMappings: API.OperationMethod<PutHypervisorPropertyMappingsInput, PutHypervisorPropertyMappingsOutput, PutHypervisorPropertyMappingsError, Credentials | HttpClient.HttpClient>;
export type PutMaintenanceStartTimeError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Set the maintenance start time for a gateway.
 */
export declare const putMaintenanceStartTime: API.OperationMethod<PutMaintenanceStartTimeInput, PutMaintenanceStartTimeOutput, PutMaintenanceStartTimeError, Credentials | HttpClient.HttpClient>;
export type StartVirtualMachinesMetadataSyncError = AccessDeniedException | ResourceNotFoundException | CommonErrors;
/**
 * This action sends a request to sync metadata across the specified virtual machines.
 */
export declare const startVirtualMachinesMetadataSync: API.OperationMethod<StartVirtualMachinesMetadataSyncInput, StartVirtualMachinesMetadataSyncOutput, StartVirtualMachinesMetadataSyncError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Tag the resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestHypervisorConfigurationError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Tests your hypervisor configuration to validate that backup gateway can connect with the hypervisor and its resources.
 */
export declare const testHypervisorConfiguration: API.OperationMethod<TestHypervisorConfigurationInput, TestHypervisorConfigurationOutput, TestHypervisorConfigurationError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from the resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayInformationError = ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a gateway's name. Specify which gateway to update using the Amazon Resource Name (ARN) of the gateway in your request.
 */
export declare const updateGatewayInformation: API.OperationMethod<UpdateGatewayInformationInput, UpdateGatewayInformationOutput, UpdateGatewayInformationError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewaySoftwareNowError = ResourceNotFoundException | CommonErrors;
/**
 * Updates the gateway virtual machine (VM) software. The request immediately triggers the software update.
 *
 * When you make this request, you get a `200 OK` success response immediately. However, it might take some time for the update to complete.
 */
export declare const updateGatewaySoftwareNow: API.OperationMethod<UpdateGatewaySoftwareNowInput, UpdateGatewaySoftwareNowOutput, UpdateGatewaySoftwareNowError, Credentials | HttpClient.HttpClient>;
export type UpdateHypervisorError = AccessDeniedException | ConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a hypervisor metadata, including its host, username, and password. Specify which hypervisor to update using the Amazon Resource Name (ARN) of the hypervisor in your request.
 */
export declare const updateHypervisor: API.OperationMethod<UpdateHypervisorInput, UpdateHypervisorOutput, UpdateHypervisorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=backup-gateway.d.ts.map