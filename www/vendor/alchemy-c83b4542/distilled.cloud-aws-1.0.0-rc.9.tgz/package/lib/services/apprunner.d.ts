import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServiceErrorException_base: S.Class<InternalServiceErrorException, S.TaggedStruct<"InternalServiceErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type AppRunnerResourceArn = string;
export type DomainName = string;
export interface AssociateCustomDomainRequest {
    ServiceArn: string;
    DomainName: string;
    EnableWWWSubdomain?: boolean;
}
export declare const AssociateCustomDomainRequest: S.Schema<AssociateCustomDomainRequest>;
export type CertificateValidationRecordStatus = "PENDING_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export declare const CertificateValidationRecordStatus: any;
export interface CertificateValidationRecord {
    Name?: string;
    Type?: string;
    Value?: string;
    Status?: CertificateValidationRecordStatus;
}
export declare const CertificateValidationRecord: S.Schema<CertificateValidationRecord>;
export type CertificateValidationRecordList = CertificateValidationRecord[];
export declare const CertificateValidationRecordList: any;
export type CustomDomainAssociationStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "DELETE_FAILED" | "PENDING_CERTIFICATE_DNS_VALIDATION" | "BINDING_CERTIFICATE" | (string & {});
export declare const CustomDomainAssociationStatus: any;
export interface CustomDomain {
    DomainName: string;
    EnableWWWSubdomain: boolean;
    CertificateValidationRecords?: CertificateValidationRecord[];
    Status: CustomDomainAssociationStatus;
}
export declare const CustomDomain: S.Schema<CustomDomain>;
export interface VpcDNSTarget {
    VpcIngressConnectionArn?: string;
    VpcId?: string;
    DomainName?: string;
}
export declare const VpcDNSTarget: S.Schema<VpcDNSTarget>;
export type VpcDNSTargetList = VpcDNSTarget[];
export declare const VpcDNSTargetList: any;
export interface AssociateCustomDomainResponse {
    DNSTarget: string;
    ServiceArn: string;
    CustomDomain: CustomDomain;
    VpcDNSTargets: VpcDNSTarget[];
}
export declare const AssociateCustomDomainResponse: S.Schema<AssociateCustomDomainResponse>;
export type AutoScalingConfigurationName = string;
export type ASConfigMaxConcurrency = number;
export type ASConfigMinSize = number;
export type ASConfigMaxSize = number;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateAutoScalingConfigurationRequest {
    AutoScalingConfigurationName: string;
    MaxConcurrency?: number;
    MinSize?: number;
    MaxSize?: number;
    Tags?: Tag[];
}
export declare const CreateAutoScalingConfigurationRequest: S.Schema<CreateAutoScalingConfigurationRequest>;
export type AutoScalingConfigurationRevision = number;
export type Latest = boolean;
export type AutoScalingConfigurationStatus = "ACTIVE" | "INACTIVE" | "active" | "inactive" | (string & {});
export declare const AutoScalingConfigurationStatus: any;
export type MaxConcurrency = number;
export type MinSize = number;
export type MaxSize = number;
export type HasAssociatedService = boolean;
export type IsDefault = boolean;
export interface AutoScalingConfiguration {
    AutoScalingConfigurationArn?: string;
    AutoScalingConfigurationName?: string;
    AutoScalingConfigurationRevision?: number;
    Latest?: boolean;
    Status?: AutoScalingConfigurationStatus;
    MaxConcurrency?: number;
    MinSize?: number;
    MaxSize?: number;
    CreatedAt?: Date;
    DeletedAt?: Date;
    HasAssociatedService?: boolean;
    IsDefault?: boolean;
}
export declare const AutoScalingConfiguration: S.Schema<AutoScalingConfiguration>;
export interface CreateAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export declare const CreateAutoScalingConfigurationResponse: S.Schema<CreateAutoScalingConfigurationResponse>;
export type ConnectionName = string;
export type ProviderType = "GITHUB" | "BITBUCKET" | (string & {});
export declare const ProviderType: any;
export interface CreateConnectionRequest {
    ConnectionName: string;
    ProviderType: ProviderType;
    Tags?: Tag[];
}
export declare const CreateConnectionRequest: S.Schema<CreateConnectionRequest>;
export type ConnectionStatus = "PENDING_HANDSHAKE" | "AVAILABLE" | "ERROR" | "DELETED" | (string & {});
export declare const ConnectionStatus: any;
export interface Connection {
    ConnectionName?: string;
    ConnectionArn?: string;
    ProviderType?: ProviderType;
    Status?: ConnectionStatus;
    CreatedAt?: Date;
}
export declare const Connection: S.Schema<Connection>;
export interface CreateConnectionResponse {
    Connection: Connection;
}
export declare const CreateConnectionResponse: S.Schema<CreateConnectionResponse>;
export type ObservabilityConfigurationName = string;
export type TracingVendor = "AWSXRAY" | (string & {});
export declare const TracingVendor: any;
export interface TraceConfiguration {
    Vendor: TracingVendor;
}
export declare const TraceConfiguration: S.Schema<TraceConfiguration>;
export interface CreateObservabilityConfigurationRequest {
    ObservabilityConfigurationName: string;
    TraceConfiguration?: TraceConfiguration;
    Tags?: Tag[];
}
export declare const CreateObservabilityConfigurationRequest: S.Schema<CreateObservabilityConfigurationRequest>;
export type ObservabilityConfigurationStatus = "ACTIVE" | "INACTIVE" | (string & {});
export declare const ObservabilityConfigurationStatus: any;
export interface ObservabilityConfiguration {
    ObservabilityConfigurationArn?: string;
    ObservabilityConfigurationName?: string;
    TraceConfiguration?: TraceConfiguration;
    ObservabilityConfigurationRevision?: number;
    Latest?: boolean;
    Status?: ObservabilityConfigurationStatus;
    CreatedAt?: Date;
    DeletedAt?: Date;
}
export declare const ObservabilityConfiguration: S.Schema<ObservabilityConfiguration>;
export interface CreateObservabilityConfigurationResponse {
    ObservabilityConfiguration: ObservabilityConfiguration;
}
export declare const CreateObservabilityConfigurationResponse: S.Schema<CreateObservabilityConfigurationResponse>;
export type ServiceName = string;
export type SourceCodeVersionType = "BRANCH" | (string & {});
export declare const SourceCodeVersionType: any;
export interface SourceCodeVersion {
    Type: SourceCodeVersionType;
    Value: string;
}
export declare const SourceCodeVersion: S.Schema<SourceCodeVersion>;
export type ConfigurationSource = "REPOSITORY" | "API" | (string & {});
export declare const ConfigurationSource: any;
export type Runtime = "PYTHON_3" | "NODEJS_12" | "NODEJS_14" | "CORRETTO_8" | "CORRETTO_11" | "NODEJS_16" | "GO_1" | "DOTNET_6" | "PHP_81" | "RUBY_31" | "PYTHON_311" | "NODEJS_18" | "NODEJS_22" | (string & {});
export declare const Runtime: any;
export type BuildCommand = string | redacted.Redacted<string>;
export type StartCommand = string | redacted.Redacted<string>;
export type RuntimeEnvironmentVariablesKey = string | redacted.Redacted<string>;
export type RuntimeEnvironmentVariablesValue = string | redacted.Redacted<string>;
export type RuntimeEnvironmentVariables = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const RuntimeEnvironmentVariables: any;
export type RuntimeEnvironmentSecretsName = string | redacted.Redacted<string>;
export type RuntimeEnvironmentSecretsValue = string | redacted.Redacted<string>;
export type RuntimeEnvironmentSecrets = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export declare const RuntimeEnvironmentSecrets: any;
export interface CodeConfigurationValues {
    Runtime: Runtime;
    BuildCommand?: string | redacted.Redacted<string>;
    StartCommand?: string | redacted.Redacted<string>;
    Port?: string;
    RuntimeEnvironmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    RuntimeEnvironmentSecrets?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const CodeConfigurationValues: S.Schema<CodeConfigurationValues>;
export interface CodeConfiguration {
    ConfigurationSource: ConfigurationSource;
    CodeConfigurationValues?: CodeConfigurationValues;
}
export declare const CodeConfiguration: S.Schema<CodeConfiguration>;
export type SourceDirectory = string;
export interface CodeRepository {
    RepositoryUrl: string;
    SourceCodeVersion: SourceCodeVersion;
    CodeConfiguration?: CodeConfiguration;
    SourceDirectory?: string;
}
export declare const CodeRepository: S.Schema<CodeRepository>;
export type ImageIdentifier = string;
export interface ImageConfiguration {
    RuntimeEnvironmentVariables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    StartCommand?: string | redacted.Redacted<string>;
    Port?: string;
    RuntimeEnvironmentSecrets?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
}
export declare const ImageConfiguration: S.Schema<ImageConfiguration>;
export type ImageRepositoryType = "ECR" | "ECR_PUBLIC" | (string & {});
export declare const ImageRepositoryType: any;
export interface ImageRepository {
    ImageIdentifier: string;
    ImageConfiguration?: ImageConfiguration;
    ImageRepositoryType: ImageRepositoryType;
}
export declare const ImageRepository: S.Schema<ImageRepository>;
export type RoleArn = string;
export interface AuthenticationConfiguration {
    ConnectionArn?: string;
    AccessRoleArn?: string;
}
export declare const AuthenticationConfiguration: S.Schema<AuthenticationConfiguration>;
export interface SourceConfiguration {
    CodeRepository?: CodeRepository;
    ImageRepository?: ImageRepository;
    AutoDeploymentsEnabled?: boolean;
    AuthenticationConfiguration?: AuthenticationConfiguration;
}
export declare const SourceConfiguration: S.Schema<SourceConfiguration>;
export type Cpu = string;
export type Memory = string;
export interface InstanceConfiguration {
    Cpu?: string;
    Memory?: string;
    InstanceRoleArn?: string;
}
export declare const InstanceConfiguration: S.Schema<InstanceConfiguration>;
export type KmsKeyArn = string;
export interface EncryptionConfiguration {
    KmsKey: string;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export type HealthCheckProtocol = "TCP" | "HTTP" | (string & {});
export declare const HealthCheckProtocol: any;
export type HealthCheckPath = string;
export type HealthCheckInterval = number;
export type HealthCheckTimeout = number;
export type HealthCheckHealthyThreshold = number;
export type HealthCheckUnhealthyThreshold = number;
export interface HealthCheckConfiguration {
    Protocol?: HealthCheckProtocol;
    Path?: string;
    Interval?: number;
    Timeout?: number;
    HealthyThreshold?: number;
    UnhealthyThreshold?: number;
}
export declare const HealthCheckConfiguration: S.Schema<HealthCheckConfiguration>;
export type EgressType = "DEFAULT" | "VPC" | (string & {});
export declare const EgressType: any;
export interface EgressConfiguration {
    EgressType?: EgressType;
    VpcConnectorArn?: string;
}
export declare const EgressConfiguration: S.Schema<EgressConfiguration>;
export interface IngressConfiguration {
    IsPubliclyAccessible?: boolean;
}
export declare const IngressConfiguration: S.Schema<IngressConfiguration>;
export type IpAddressType = "IPV4" | "DUAL_STACK" | (string & {});
export declare const IpAddressType: any;
export interface NetworkConfiguration {
    EgressConfiguration?: EgressConfiguration;
    IngressConfiguration?: IngressConfiguration;
    IpAddressType?: IpAddressType;
}
export declare const NetworkConfiguration: S.Schema<NetworkConfiguration>;
export interface ServiceObservabilityConfiguration {
    ObservabilityEnabled: boolean;
    ObservabilityConfigurationArn?: string;
}
export declare const ServiceObservabilityConfiguration: S.Schema<ServiceObservabilityConfiguration>;
export interface CreateServiceRequest {
    ServiceName: string;
    SourceConfiguration: SourceConfiguration;
    InstanceConfiguration?: InstanceConfiguration;
    Tags?: Tag[];
    EncryptionConfiguration?: EncryptionConfiguration;
    HealthCheckConfiguration?: HealthCheckConfiguration;
    AutoScalingConfigurationArn?: string;
    NetworkConfiguration?: NetworkConfiguration;
    ObservabilityConfiguration?: ServiceObservabilityConfiguration;
}
export declare const CreateServiceRequest: S.Schema<CreateServiceRequest>;
export type ServiceId = string;
export type ServiceStatus = "CREATE_FAILED" | "RUNNING" | "DELETED" | "DELETE_FAILED" | "PAUSED" | "OPERATION_IN_PROGRESS" | (string & {});
export declare const ServiceStatus: any;
export interface AutoScalingConfigurationSummary {
    AutoScalingConfigurationArn?: string;
    AutoScalingConfigurationName?: string;
    AutoScalingConfigurationRevision?: number;
    Status?: AutoScalingConfigurationStatus;
    CreatedAt?: Date;
    HasAssociatedService?: boolean;
    IsDefault?: boolean;
}
export declare const AutoScalingConfigurationSummary: S.Schema<AutoScalingConfigurationSummary>;
export interface Service {
    ServiceName: string;
    ServiceId: string;
    ServiceArn: string;
    ServiceUrl?: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    DeletedAt?: Date;
    Status: ServiceStatus;
    SourceConfiguration: SourceConfiguration;
    InstanceConfiguration: InstanceConfiguration;
    EncryptionConfiguration?: EncryptionConfiguration;
    HealthCheckConfiguration?: HealthCheckConfiguration;
    AutoScalingConfigurationSummary: AutoScalingConfigurationSummary;
    NetworkConfiguration: NetworkConfiguration;
    ObservabilityConfiguration?: ServiceObservabilityConfiguration;
}
export declare const Service: S.Schema<Service>;
export type UUID = string;
export interface CreateServiceResponse {
    Service: Service;
    OperationId: string;
}
export declare const CreateServiceResponse: S.Schema<CreateServiceResponse>;
export type VpcConnectorName = string;
export type StringList = string[];
export declare const StringList: any;
export interface CreateVpcConnectorRequest {
    VpcConnectorName: string;
    Subnets: string[];
    SecurityGroups?: string[];
    Tags?: Tag[];
}
export declare const CreateVpcConnectorRequest: S.Schema<CreateVpcConnectorRequest>;
export type VpcConnectorStatus = "ACTIVE" | "INACTIVE" | "active" | "inactive" | (string & {});
export declare const VpcConnectorStatus: any;
export interface VpcConnector {
    VpcConnectorName?: string;
    VpcConnectorArn?: string;
    VpcConnectorRevision?: number;
    Subnets?: string[];
    SecurityGroups?: string[];
    Status?: VpcConnectorStatus;
    CreatedAt?: Date;
    DeletedAt?: Date;
}
export declare const VpcConnector: S.Schema<VpcConnector>;
export interface CreateVpcConnectorResponse {
    VpcConnector: VpcConnector;
}
export declare const CreateVpcConnectorResponse: S.Schema<CreateVpcConnectorResponse>;
export type VpcIngressConnectionName = string;
export interface IngressVpcConfiguration {
    VpcId?: string;
    VpcEndpointId?: string;
}
export declare const IngressVpcConfiguration: S.Schema<IngressVpcConfiguration>;
export interface CreateVpcIngressConnectionRequest {
    ServiceArn: string;
    VpcIngressConnectionName: string;
    IngressVpcConfiguration: IngressVpcConfiguration;
    Tags?: Tag[];
}
export declare const CreateVpcIngressConnectionRequest: S.Schema<CreateVpcIngressConnectionRequest>;
export type VpcIngressConnectionStatus = "AVAILABLE" | "PENDING_CREATION" | "PENDING_UPDATE" | "PENDING_DELETION" | "FAILED_CREATION" | "FAILED_UPDATE" | "FAILED_DELETION" | "DELETED" | (string & {});
export declare const VpcIngressConnectionStatus: any;
export type CustomerAccountId = string;
export interface VpcIngressConnection {
    VpcIngressConnectionArn?: string;
    VpcIngressConnectionName?: string;
    ServiceArn?: string;
    Status?: VpcIngressConnectionStatus;
    AccountId?: string;
    DomainName?: string;
    IngressVpcConfiguration?: IngressVpcConfiguration;
    CreatedAt?: Date;
    DeletedAt?: Date;
}
export declare const VpcIngressConnection: S.Schema<VpcIngressConnection>;
export interface CreateVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export declare const CreateVpcIngressConnectionResponse: S.Schema<CreateVpcIngressConnectionResponse>;
export interface DeleteAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
    DeleteAllRevisions?: boolean;
}
export declare const DeleteAutoScalingConfigurationRequest: S.Schema<DeleteAutoScalingConfigurationRequest>;
export interface DeleteAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export declare const DeleteAutoScalingConfigurationResponse: S.Schema<DeleteAutoScalingConfigurationResponse>;
export interface DeleteConnectionRequest {
    ConnectionArn: string;
}
export declare const DeleteConnectionRequest: S.Schema<DeleteConnectionRequest>;
export interface DeleteConnectionResponse {
    Connection?: Connection;
}
export declare const DeleteConnectionResponse: S.Schema<DeleteConnectionResponse>;
export interface DeleteObservabilityConfigurationRequest {
    ObservabilityConfigurationArn: string;
}
export declare const DeleteObservabilityConfigurationRequest: S.Schema<DeleteObservabilityConfigurationRequest>;
export interface DeleteObservabilityConfigurationResponse {
    ObservabilityConfiguration: ObservabilityConfiguration;
}
export declare const DeleteObservabilityConfigurationResponse: S.Schema<DeleteObservabilityConfigurationResponse>;
export interface DeleteServiceRequest {
    ServiceArn: string;
}
export declare const DeleteServiceRequest: S.Schema<DeleteServiceRequest>;
export interface DeleteServiceResponse {
    Service: Service;
    OperationId: string;
}
export declare const DeleteServiceResponse: S.Schema<DeleteServiceResponse>;
export interface DeleteVpcConnectorRequest {
    VpcConnectorArn: string;
}
export declare const DeleteVpcConnectorRequest: S.Schema<DeleteVpcConnectorRequest>;
export interface DeleteVpcConnectorResponse {
    VpcConnector: VpcConnector;
}
export declare const DeleteVpcConnectorResponse: S.Schema<DeleteVpcConnectorResponse>;
export interface DeleteVpcIngressConnectionRequest {
    VpcIngressConnectionArn: string;
}
export declare const DeleteVpcIngressConnectionRequest: S.Schema<DeleteVpcIngressConnectionRequest>;
export interface DeleteVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export declare const DeleteVpcIngressConnectionResponse: S.Schema<DeleteVpcIngressConnectionResponse>;
export interface DescribeAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
}
export declare const DescribeAutoScalingConfigurationRequest: S.Schema<DescribeAutoScalingConfigurationRequest>;
export interface DescribeAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export declare const DescribeAutoScalingConfigurationResponse: S.Schema<DescribeAutoScalingConfigurationResponse>;
export type DescribeCustomDomainsMaxResults = number;
export interface DescribeCustomDomainsRequest {
    ServiceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeCustomDomainsRequest: S.Schema<DescribeCustomDomainsRequest>;
export type CustomDomainList = CustomDomain[];
export declare const CustomDomainList: any;
export interface DescribeCustomDomainsResponse {
    DNSTarget: string;
    ServiceArn: string;
    CustomDomains: CustomDomain[];
    VpcDNSTargets: VpcDNSTarget[];
    NextToken?: string;
}
export declare const DescribeCustomDomainsResponse: S.Schema<DescribeCustomDomainsResponse>;
export interface DescribeObservabilityConfigurationRequest {
    ObservabilityConfigurationArn: string;
}
export declare const DescribeObservabilityConfigurationRequest: S.Schema<DescribeObservabilityConfigurationRequest>;
export interface DescribeObservabilityConfigurationResponse {
    ObservabilityConfiguration: ObservabilityConfiguration;
}
export declare const DescribeObservabilityConfigurationResponse: S.Schema<DescribeObservabilityConfigurationResponse>;
export interface DescribeServiceRequest {
    ServiceArn: string;
}
export declare const DescribeServiceRequest: S.Schema<DescribeServiceRequest>;
export interface DescribeServiceResponse {
    Service: Service;
}
export declare const DescribeServiceResponse: S.Schema<DescribeServiceResponse>;
export interface DescribeVpcConnectorRequest {
    VpcConnectorArn: string;
}
export declare const DescribeVpcConnectorRequest: S.Schema<DescribeVpcConnectorRequest>;
export interface DescribeVpcConnectorResponse {
    VpcConnector: VpcConnector;
}
export declare const DescribeVpcConnectorResponse: S.Schema<DescribeVpcConnectorResponse>;
export interface DescribeVpcIngressConnectionRequest {
    VpcIngressConnectionArn: string;
}
export declare const DescribeVpcIngressConnectionRequest: S.Schema<DescribeVpcIngressConnectionRequest>;
export interface DescribeVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export declare const DescribeVpcIngressConnectionResponse: S.Schema<DescribeVpcIngressConnectionResponse>;
export interface DisassociateCustomDomainRequest {
    ServiceArn: string;
    DomainName: string;
}
export declare const DisassociateCustomDomainRequest: S.Schema<DisassociateCustomDomainRequest>;
export interface DisassociateCustomDomainResponse {
    DNSTarget: string;
    ServiceArn: string;
    CustomDomain: CustomDomain;
    VpcDNSTargets: VpcDNSTarget[];
}
export declare const DisassociateCustomDomainResponse: S.Schema<DisassociateCustomDomainResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListAutoScalingConfigurationsRequest {
    AutoScalingConfigurationName?: string;
    LatestOnly?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAutoScalingConfigurationsRequest: S.Schema<ListAutoScalingConfigurationsRequest>;
export type AutoScalingConfigurationSummaryList = AutoScalingConfigurationSummary[];
export declare const AutoScalingConfigurationSummaryList: any;
export interface ListAutoScalingConfigurationsResponse {
    AutoScalingConfigurationSummaryList: AutoScalingConfigurationSummary[];
    NextToken?: string;
}
export declare const ListAutoScalingConfigurationsResponse: S.Schema<ListAutoScalingConfigurationsResponse>;
export interface ListConnectionsRequest {
    ConnectionName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListConnectionsRequest: S.Schema<ListConnectionsRequest>;
export interface ConnectionSummary {
    ConnectionName?: string;
    ConnectionArn?: string;
    ProviderType?: ProviderType;
    Status?: ConnectionStatus;
    CreatedAt?: Date;
}
export declare const ConnectionSummary: S.Schema<ConnectionSummary>;
export type ConnectionSummaryList = ConnectionSummary[];
export declare const ConnectionSummaryList: any;
export interface ListConnectionsResponse {
    ConnectionSummaryList: ConnectionSummary[];
    NextToken?: string;
}
export declare const ListConnectionsResponse: S.Schema<ListConnectionsResponse>;
export interface ListObservabilityConfigurationsRequest {
    ObservabilityConfigurationName?: string;
    LatestOnly?: boolean;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListObservabilityConfigurationsRequest: S.Schema<ListObservabilityConfigurationsRequest>;
export interface ObservabilityConfigurationSummary {
    ObservabilityConfigurationArn?: string;
    ObservabilityConfigurationName?: string;
    ObservabilityConfigurationRevision?: number;
}
export declare const ObservabilityConfigurationSummary: S.Schema<ObservabilityConfigurationSummary>;
export type ObservabilityConfigurationSummaryList = ObservabilityConfigurationSummary[];
export declare const ObservabilityConfigurationSummaryList: any;
export interface ListObservabilityConfigurationsResponse {
    ObservabilityConfigurationSummaryList: ObservabilityConfigurationSummary[];
    NextToken?: string;
}
export declare const ListObservabilityConfigurationsResponse: S.Schema<ListObservabilityConfigurationsResponse>;
export type ListOperationsMaxResults = number;
export interface ListOperationsRequest {
    ServiceArn: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListOperationsRequest: S.Schema<ListOperationsRequest>;
export type OperationType = "START_DEPLOYMENT" | "CREATE_SERVICE" | "PAUSE_SERVICE" | "RESUME_SERVICE" | "DELETE_SERVICE" | "UPDATE_SERVICE" | (string & {});
export declare const OperationType: any;
export type OperationStatus = "PENDING" | "IN_PROGRESS" | "FAILED" | "SUCCEEDED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_FAILED" | "ROLLBACK_SUCCEEDED" | (string & {});
export declare const OperationStatus: any;
export interface OperationSummary {
    Id?: string;
    Type?: OperationType;
    Status?: OperationStatus;
    TargetArn?: string;
    StartedAt?: Date;
    EndedAt?: Date;
    UpdatedAt?: Date;
}
export declare const OperationSummary: S.Schema<OperationSummary>;
export type OperationSummaryList = OperationSummary[];
export declare const OperationSummaryList: any;
export interface ListOperationsResponse {
    OperationSummaryList?: OperationSummary[];
    NextToken?: string;
}
export declare const ListOperationsResponse: S.Schema<ListOperationsResponse>;
export type ServiceMaxResults = number;
export interface ListServicesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListServicesRequest: S.Schema<ListServicesRequest>;
export interface ServiceSummary {
    ServiceName?: string;
    ServiceId?: string;
    ServiceArn?: string;
    ServiceUrl?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Status?: ServiceStatus;
}
export declare const ServiceSummary: S.Schema<ServiceSummary>;
export type ServiceSummaryList = ServiceSummary[];
export declare const ServiceSummaryList: any;
export interface ListServicesResponse {
    ServiceSummaryList: ServiceSummary[];
    NextToken?: string;
}
export declare const ListServicesResponse: S.Schema<ListServicesResponse>;
export interface ListServicesForAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListServicesForAutoScalingConfigurationRequest: S.Schema<ListServicesForAutoScalingConfigurationRequest>;
export type ServiceArnList = string[];
export declare const ServiceArnList: any;
export interface ListServicesForAutoScalingConfigurationResponse {
    ServiceArnList: string[];
    NextToken?: string;
}
export declare const ListServicesForAutoScalingConfigurationResponse: S.Schema<ListServicesForAutoScalingConfigurationResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListVpcConnectorsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListVpcConnectorsRequest: S.Schema<ListVpcConnectorsRequest>;
export type VpcConnectors = VpcConnector[];
export declare const VpcConnectors: any;
export interface ListVpcConnectorsResponse {
    VpcConnectors: VpcConnector[];
    NextToken?: string;
}
export declare const ListVpcConnectorsResponse: S.Schema<ListVpcConnectorsResponse>;
export interface ListVpcIngressConnectionsFilter {
    ServiceArn?: string;
    VpcEndpointId?: string;
}
export declare const ListVpcIngressConnectionsFilter: S.Schema<ListVpcIngressConnectionsFilter>;
export interface ListVpcIngressConnectionsRequest {
    Filter?: ListVpcIngressConnectionsFilter;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListVpcIngressConnectionsRequest: S.Schema<ListVpcIngressConnectionsRequest>;
export interface VpcIngressConnectionSummary {
    VpcIngressConnectionArn?: string;
    ServiceArn?: string;
}
export declare const VpcIngressConnectionSummary: S.Schema<VpcIngressConnectionSummary>;
export type VpcIngressConnectionSummaryList = VpcIngressConnectionSummary[];
export declare const VpcIngressConnectionSummaryList: any;
export interface ListVpcIngressConnectionsResponse {
    VpcIngressConnectionSummaryList: VpcIngressConnectionSummary[];
    NextToken?: string;
}
export declare const ListVpcIngressConnectionsResponse: S.Schema<ListVpcIngressConnectionsResponse>;
export interface PauseServiceRequest {
    ServiceArn: string;
}
export declare const PauseServiceRequest: S.Schema<PauseServiceRequest>;
export interface PauseServiceResponse {
    Service: Service;
    OperationId?: string;
}
export declare const PauseServiceResponse: S.Schema<PauseServiceResponse>;
export interface ResumeServiceRequest {
    ServiceArn: string;
}
export declare const ResumeServiceRequest: S.Schema<ResumeServiceRequest>;
export interface ResumeServiceResponse {
    Service: Service;
    OperationId?: string;
}
export declare const ResumeServiceResponse: S.Schema<ResumeServiceResponse>;
export interface StartDeploymentRequest {
    ServiceArn: string;
}
export declare const StartDeploymentRequest: S.Schema<StartDeploymentRequest>;
export interface StartDeploymentResponse {
    OperationId: string;
}
export declare const StartDeploymentResponse: S.Schema<StartDeploymentResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDefaultAutoScalingConfigurationRequest {
    AutoScalingConfigurationArn: string;
}
export declare const UpdateDefaultAutoScalingConfigurationRequest: S.Schema<UpdateDefaultAutoScalingConfigurationRequest>;
export interface UpdateDefaultAutoScalingConfigurationResponse {
    AutoScalingConfiguration: AutoScalingConfiguration;
}
export declare const UpdateDefaultAutoScalingConfigurationResponse: S.Schema<UpdateDefaultAutoScalingConfigurationResponse>;
export interface UpdateServiceRequest {
    ServiceArn: string;
    SourceConfiguration?: SourceConfiguration;
    InstanceConfiguration?: InstanceConfiguration;
    AutoScalingConfigurationArn?: string;
    HealthCheckConfiguration?: HealthCheckConfiguration;
    NetworkConfiguration?: NetworkConfiguration;
    ObservabilityConfiguration?: ServiceObservabilityConfiguration;
}
export declare const UpdateServiceRequest: S.Schema<UpdateServiceRequest>;
export interface UpdateServiceResponse {
    Service: Service;
    OperationId: string;
}
export declare const UpdateServiceResponse: S.Schema<UpdateServiceResponse>;
export interface UpdateVpcIngressConnectionRequest {
    VpcIngressConnectionArn: string;
    IngressVpcConfiguration: IngressVpcConfiguration;
}
export declare const UpdateVpcIngressConnectionRequest: S.Schema<UpdateVpcIngressConnectionRequest>;
export interface UpdateVpcIngressConnectionResponse {
    VpcIngressConnection: VpcIngressConnection;
}
export declare const UpdateVpcIngressConnectionResponse: S.Schema<UpdateVpcIngressConnectionResponse>;
export type ErrorMessage = string;
export type AssociateCustomDomainError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | CommonErrors;
/**
 * Associate your own domain name with the App Runner subdomain URL of your App Runner service.
 *
 * After you call `AssociateCustomDomain` and receive a successful response, use the information in the CustomDomain record
 * that's returned to add CNAME records to your Domain Name System (DNS). For each mapped domain name, add a mapping to the target App Runner subdomain and one or
 * more certificate validation records. App Runner then performs DNS validation to verify that you own or control the domain name that you associated. App Runner tracks
 * domain validity in a certificate stored in AWS Certificate Manager (ACM).
 */
export declare const associateCustomDomain: API.OperationMethod<AssociateCustomDomainRequest, AssociateCustomDomainResponse, AssociateCustomDomainError, Credentials | HttpClient.HttpClient>;
export type CreateAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner automatic scaling configuration resource. App Runner requires this resource when you create or update App Runner services and you require
 * non-default auto scaling settings. You can share an auto scaling configuration across multiple services.
 *
 * Create multiple revisions of a configuration by calling this action multiple times using the same `AutoScalingConfigurationName`. The call
 * returns incremental `AutoScalingConfigurationRevision` values. When you create a service and configure an auto scaling configuration resource,
 * the service uses the latest active revision of the auto scaling configuration by default. You can optionally configure the service to use a specific
 * revision.
 *
 * Configure a higher `MinSize` to increase the spread of your App Runner service over more Availability Zones in the Amazon Web Services Region. The
 * tradeoff is a higher minimal cost.
 *
 * Configure a lower `MaxSize` to control your cost. The tradeoff is lower responsiveness during peak demand.
 */
export declare const createAutoScalingConfiguration: API.OperationMethod<CreateAutoScalingConfigurationRequest, CreateAutoScalingConfigurationResponse, CreateAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner connection resource. App Runner requires a connection resource when you create App Runner services that access private repositories from
 * certain third-party providers. You can share a connection across multiple services.
 *
 * A connection resource is needed to access GitHub and Bitbucket repositories. Both require
 * a user interface approval process through the App Runner console before you can use the
 * connection.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateObservabilityConfigurationError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner observability configuration resource. App Runner requires this resource when you create or update App Runner services and you want to enable
 * non-default observability features. You can share an observability configuration across multiple services.
 *
 * Create multiple revisions of a configuration by calling this action multiple times using the same `ObservabilityConfigurationName`. The
 * call returns incremental `ObservabilityConfigurationRevision` values. When you create a service and configure an observability configuration
 * resource, the service uses the latest active revision of the observability configuration by default. You can optionally configure the service to use a
 * specific revision.
 *
 * The observability configuration resource is designed to configure multiple features (currently one feature, tracing). This action takes optional
 * parameters that describe the configuration of these features (currently one parameter, `TraceConfiguration`). If you don't specify a feature
 * parameter, App Runner doesn't enable the feature.
 */
export declare const createObservabilityConfiguration: API.OperationMethod<CreateObservabilityConfigurationRequest, CreateObservabilityConfigurationResponse, CreateObservabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner service. After the service is created, the action also automatically starts a deployment.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations call to track the operation's progress.
 */
export declare const createService: API.OperationMethod<CreateServiceRequest, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateVpcConnectorError = InternalServiceErrorException | InvalidRequestException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner VPC connector resource. App Runner requires this resource when you want to associate your App Runner service to a custom Amazon Virtual Private Cloud
 * (Amazon VPC).
 */
export declare const createVpcConnector: API.OperationMethod<CreateVpcConnectorRequest, CreateVpcConnectorResponse, CreateVpcConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ServiceQuotaExceededException | CommonErrors;
/**
 * Create an App Runner VPC Ingress Connection resource. App Runner requires this resource when you want to associate your App Runner service with an Amazon VPC endpoint.
 */
export declare const createVpcIngressConnection: API.OperationMethod<CreateVpcIngressConnectionRequest, CreateVpcIngressConnectionResponse, CreateVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner automatic scaling configuration resource. You can delete a top level auto scaling configuration, a specific revision of one, or all
 * revisions associated with the top level configuration. You can't delete the default auto scaling configuration or a configuration that's used by one or
 * more App Runner services.
 */
export declare const deleteAutoScalingConfiguration: API.OperationMethod<DeleteAutoScalingConfigurationRequest, DeleteAutoScalingConfigurationResponse, DeleteAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner connection. You must first ensure that there are no running App Runner services that use this connection. If there are any, the
 * `DeleteConnection` action fails.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteObservabilityConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner observability configuration resource. You can delete a specific revision or the latest active revision. You can't delete a
 * configuration that's used by one or more App Runner services.
 */
export declare const deleteObservabilityConfiguration: API.OperationMethod<DeleteObservabilityConfigurationRequest, DeleteObservabilityConfigurationResponse, DeleteObservabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner service.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 *
 * Make sure that you don't have any active VPCIngressConnections associated with the service you want to delete.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcConnectorError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner VPC connector resource. You can't delete a
 * connector that's used by one or more App Runner services.
 */
export declare const deleteVpcConnector: API.OperationMethod<DeleteVpcConnectorRequest, DeleteVpcConnectorResponse, DeleteVpcConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an App Runner VPC Ingress Connection resource that's associated with an App Runner service. The VPC Ingress Connection must be in one of the following states to be deleted:
 *
 * - `AVAILABLE`
 *
 * - `FAILED_CREATION`
 *
 * - `FAILED_UPDATE`
 *
 * - `FAILED_DELETION`
 */
export declare const deleteVpcIngressConnection: API.OperationMethod<DeleteVpcIngressConnectionRequest, DeleteVpcIngressConnectionResponse, DeleteVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner automatic scaling configuration resource.
 */
export declare const describeAutoScalingConfiguration: API.OperationMethod<DescribeAutoScalingConfigurationRequest, DescribeAutoScalingConfigurationResponse, DescribeAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomDomainsError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a description of custom domain names that are associated with an App Runner service.
 */
export declare const describeCustomDomains: API.PaginatedOperationMethod<DescribeCustomDomainsRequest, DescribeCustomDomainsResponse, DescribeCustomDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeObservabilityConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner observability configuration resource.
 */
export declare const describeObservabilityConfiguration: API.OperationMethod<DescribeObservabilityConfigurationRequest, DescribeObservabilityConfigurationResponse, DescribeObservabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner service.
 */
export declare const describeService: API.OperationMethod<DescribeServiceRequest, DescribeServiceResponse, DescribeServiceError, Credentials | HttpClient.HttpClient>;
export type DescribeVpcConnectorError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a description of an App Runner VPC connector resource.
 */
export declare const describeVpcConnector: API.OperationMethod<DescribeVpcConnectorRequest, DescribeVpcConnectorResponse, DescribeVpcConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a full description of an App Runner VPC Ingress Connection resource.
 */
export declare const describeVpcIngressConnection: API.OperationMethod<DescribeVpcIngressConnectionRequest, DescribeVpcIngressConnectionResponse, DescribeVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export type DisassociateCustomDomainError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociate a custom domain name from an App Runner service.
 *
 * Certificates tracking domain validity are associated with a custom domain and are stored in AWS
 * Certificate Manager (ACM). These certificates aren't deleted as part of this action. App Runner delays certificate deletion for
 * 30 days after a domain is disassociated from your service.
 */
export declare const disassociateCustomDomain: API.OperationMethod<DisassociateCustomDomainRequest, DisassociateCustomDomainResponse, DisassociateCustomDomainError, Credentials | HttpClient.HttpClient>;
export type ListAutoScalingConfigurationsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of active App Runner automatic scaling configurations in your Amazon Web Services account. You can query the revisions for a specific
 * configuration name or the revisions for all active configurations in your account. You can optionally query only the latest revision of each requested
 * name.
 *
 * To retrieve a full description of a particular configuration revision, call and provide one of
 * the ARNs returned by `ListAutoScalingConfigurations`.
 */
export declare const listAutoScalingConfigurations: API.PaginatedOperationMethod<ListAutoScalingConfigurationsRequest, ListAutoScalingConfigurationsResponse, ListAutoScalingConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectionsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of App Runner connections that are associated with your Amazon Web Services account.
 */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsRequest, ListConnectionsResponse, ListConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObservabilityConfigurationsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of active App Runner observability configurations in your Amazon Web Services account. You can query the revisions for a specific
 * configuration name or the revisions for all active configurations in your account. You can optionally query only the latest revision of each requested
 * name.
 *
 * To retrieve a full description of a particular configuration revision, call and provide one
 * of the ARNs returned by `ListObservabilityConfigurations`.
 */
export declare const listObservabilityConfigurations: API.PaginatedOperationMethod<ListObservabilityConfigurationsRequest, ListObservabilityConfigurationsResponse, ListObservabilityConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOperationsError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Return a list of operations that occurred on an App Runner service.
 *
 * The resulting list of OperationSummary objects is sorted in reverse chronological order. The first object on the list represents the
 * last started operation.
 */
export declare const listOperations: API.PaginatedOperationMethod<ListOperationsRequest, ListOperationsResponse, ListOperationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServicesError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of running App Runner services in your Amazon Web Services account.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServicesForAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of the associated App Runner services using an auto scaling configuration.
 */
export declare const listServicesForAutoScalingConfiguration: API.PaginatedOperationMethod<ListServicesForAutoScalingConfigurationRequest, ListServicesForAutoScalingConfigurationResponse, ListServicesForAutoScalingConfigurationError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * List tags that are associated with for an App Runner resource. The response contains a list of tag key-value pairs.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVpcConnectorsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of App Runner VPC connectors in your Amazon Web Services account.
 */
export declare const listVpcConnectors: API.PaginatedOperationMethod<ListVpcConnectorsRequest, ListVpcConnectorsResponse, ListVpcConnectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListVpcIngressConnectionsError = InternalServiceErrorException | InvalidRequestException | CommonErrors;
/**
 * Return a list of App Runner VPC Ingress Connections in your Amazon Web Services account.
 */
export declare const listVpcIngressConnections: API.PaginatedOperationMethod<ListVpcIngressConnectionsRequest, ListVpcIngressConnectionsResponse, ListVpcIngressConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PauseServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Pause an active App Runner service. App Runner reduces compute capacity for the service to zero and loses state (for example, ephemeral storage is
 * removed).
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const pauseService: API.OperationMethod<PauseServiceRequest, PauseServiceResponse, PauseServiceError, Credentials | HttpClient.HttpClient>;
export type ResumeServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Resume an active App Runner service. App Runner provisions compute capacity for the service.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const resumeService: API.OperationMethod<ResumeServiceRequest, ResumeServiceResponse, ResumeServiceError, Credentials | HttpClient.HttpClient>;
export type StartDeploymentError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Initiate a manual deployment of the latest commit in a source code repository or the latest image in a source image repository to an App Runner
 * service.
 *
 * For a source code repository, App Runner retrieves the commit and builds a Docker image. For a source image repository, App Runner retrieves the latest Docker
 * image. In both cases, App Runner then deploys the new image to your service and starts a new container instance.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const startDeployment: API.OperationMethod<StartDeploymentRequest, StartDeploymentResponse, StartDeploymentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Add tags to, or update the tag values of, an App Runner resource. A tag is a key-value pair.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Remove tags from an App Runner resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDefaultAutoScalingConfigurationError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Update an auto scaling configuration to be the default. The existing default auto scaling configuration will be set to non-default
 * automatically.
 */
export declare const updateDefaultAutoScalingConfiguration: API.OperationMethod<UpdateDefaultAutoScalingConfigurationRequest, UpdateDefaultAutoScalingConfigurationResponse, UpdateDefaultAutoScalingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Update an App Runner service. You can update the source configuration and instance configuration of the service. You can also update the ARN of the auto
 * scaling configuration resource that's associated with the service. However, you can't change the name or the encryption configuration of the service.
 * These can be set only when you create the service.
 *
 * To update the tags applied to your service, use the separate actions TagResource and UntagResource.
 *
 * This is an asynchronous operation. On a successful call, you can use the returned `OperationId` and the ListOperations
 * call to track the operation's progress.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcIngressConnectionError = InternalServiceErrorException | InvalidRequestException | InvalidStateException | ResourceNotFoundException | CommonErrors;
/**
 * Update an existing App Runner VPC Ingress Connection resource. The VPC Ingress Connection must be in one of the following states to be updated:
 *
 * - AVAILABLE
 *
 * - FAILED_CREATION
 *
 * - FAILED_UPDATE
 */
export declare const updateVpcIngressConnection: API.OperationMethod<UpdateVpcIngressConnectionRequest, UpdateVpcIngressConnectionResponse, UpdateVpcIngressConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=apprunner.d.ts.map