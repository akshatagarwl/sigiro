import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const DryRunOperationException_base: S.Class<DryRunOperationException, S.TaggedStruct<"DryRunOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DryRunOperationException extends /*@__PURE__*/ DryRunOperationException_base {
}
declare const EntitlementAlreadyExistsException_base: S.Class<EntitlementAlreadyExistsException, S.TaggedStruct<"EntitlementAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EntitlementAlreadyExistsException extends /*@__PURE__*/ EntitlementAlreadyExistsException_base {
}
declare const EntitlementNotFoundException_base: S.Class<EntitlementNotFoundException, S.TaggedStruct<"EntitlementNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EntitlementNotFoundException extends /*@__PURE__*/ EntitlementNotFoundException_base {
}
declare const IncompatibleImageException_base: S.Class<IncompatibleImageException, S.TaggedStruct<"IncompatibleImageException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncompatibleImageException extends /*@__PURE__*/ IncompatibleImageException_base {
}
declare const InvalidAccountStatusException_base: S.Class<InvalidAccountStatusException, S.TaggedStruct<"InvalidAccountStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAccountStatusException extends /*@__PURE__*/ InvalidAccountStatusException_base {
}
declare const InvalidParameterCombinationException_base: S.Class<InvalidParameterCombinationException, S.TaggedStruct<"InvalidParameterCombinationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidRoleException_base: S.Class<InvalidRoleException, S.TaggedStruct<"InvalidRoleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRoleException extends /*@__PURE__*/ InvalidRoleException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const OperationNotPermittedException_base: S.Class<OperationNotPermittedException, S.TaggedStruct<"OperationNotPermittedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const RequestLimitExceededException_base: S.Class<RequestLimitExceededException, S.TaggedStruct<"RequestLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestLimitExceededException extends /*@__PURE__*/ RequestLimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotAvailableException_base: S.Class<ResourceNotAvailableException, S.TaggedStruct<"ResourceNotAvailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotAvailableException extends /*@__PURE__*/ ResourceNotAvailableException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type Arn = string;
export type Name = string;
export interface AssociateAppBlockBuilderAppBlockRequest {
    AppBlockArn?: string;
    AppBlockBuilderName?: string;
}
export declare const AssociateAppBlockBuilderAppBlockRequest: S.Schema<AssociateAppBlockBuilderAppBlockRequest>;
export interface AppBlockBuilderAppBlockAssociation {
    AppBlockArn?: string;
    AppBlockBuilderName?: string;
}
export declare const AppBlockBuilderAppBlockAssociation: S.Schema<AppBlockBuilderAppBlockAssociation>;
export interface AssociateAppBlockBuilderAppBlockResult {
    AppBlockBuilderAppBlockAssociation?: AppBlockBuilderAppBlockAssociation & {
        AppBlockArn: Arn;
        AppBlockBuilderName: Name;
    };
}
export declare const AssociateAppBlockBuilderAppBlockResult: S.Schema<AssociateAppBlockBuilderAppBlockResult>;
export interface AssociateApplicationFleetRequest {
    FleetName?: string;
    ApplicationArn?: string;
}
export declare const AssociateApplicationFleetRequest: S.Schema<AssociateApplicationFleetRequest>;
export interface ApplicationFleetAssociation {
    FleetName?: string;
    ApplicationArn?: string;
}
export declare const ApplicationFleetAssociation: S.Schema<ApplicationFleetAssociation>;
export interface AssociateApplicationFleetResult {
    ApplicationFleetAssociation?: ApplicationFleetAssociation & {
        FleetName: string;
        ApplicationArn: Arn;
    };
}
export declare const AssociateApplicationFleetResult: S.Schema<AssociateApplicationFleetResult>;
export interface AssociateApplicationToEntitlementRequest {
    StackName?: string;
    EntitlementName?: string;
    ApplicationIdentifier?: string;
}
export declare const AssociateApplicationToEntitlementRequest: S.Schema<AssociateApplicationToEntitlementRequest>;
export interface AssociateApplicationToEntitlementResult {
}
export declare const AssociateApplicationToEntitlementResult: S.Schema<AssociateApplicationToEntitlementResult>;
export interface AssociateFleetRequest {
    FleetName?: string;
    StackName?: string;
}
export declare const AssociateFleetRequest: S.Schema<AssociateFleetRequest>;
export interface AssociateFleetResult {
}
export declare const AssociateFleetResult: S.Schema<AssociateFleetResult>;
export type StringList = string[];
export declare const StringList: any;
export interface AssociateSoftwareToImageBuilderRequest {
    ImageBuilderName?: string;
    SoftwareNames?: string[];
}
export declare const AssociateSoftwareToImageBuilderRequest: S.Schema<AssociateSoftwareToImageBuilderRequest>;
export interface AssociateSoftwareToImageBuilderResult {
}
export declare const AssociateSoftwareToImageBuilderResult: S.Schema<AssociateSoftwareToImageBuilderResult>;
export type Username = string | redacted.Redacted<string>;
export type AuthenticationType = "API" | "SAML" | "USERPOOL" | "AWS_AD" | (string & {});
export declare const AuthenticationType: any;
export interface UserStackAssociation {
    StackName?: string;
    UserName?: string | redacted.Redacted<string>;
    AuthenticationType?: AuthenticationType;
    SendEmailNotification?: boolean;
}
export declare const UserStackAssociation: S.Schema<UserStackAssociation>;
export type UserStackAssociationList = UserStackAssociation[];
export declare const UserStackAssociationList: any;
export interface BatchAssociateUserStackRequest {
    UserStackAssociations?: UserStackAssociation[];
}
export declare const BatchAssociateUserStackRequest: S.Schema<BatchAssociateUserStackRequest>;
export type UserStackAssociationErrorCode = "STACK_NOT_FOUND" | "USER_NAME_NOT_FOUND" | "DIRECTORY_NOT_FOUND" | "INTERNAL_ERROR" | (string & {});
export declare const UserStackAssociationErrorCode: any;
export interface UserStackAssociationError {
    UserStackAssociation?: UserStackAssociation;
    ErrorCode?: UserStackAssociationErrorCode;
    ErrorMessage?: string;
}
export declare const UserStackAssociationError: S.Schema<UserStackAssociationError>;
export type UserStackAssociationErrorList = UserStackAssociationError[];
export declare const UserStackAssociationErrorList: any;
export interface BatchAssociateUserStackResult {
    errors?: (UserStackAssociationError & {
        UserStackAssociation: UserStackAssociation & {
            StackName: string;
            UserName: Username;
            AuthenticationType: AuthenticationType;
        };
    })[];
}
export declare const BatchAssociateUserStackResult: S.Schema<BatchAssociateUserStackResult>;
export interface BatchDisassociateUserStackRequest {
    UserStackAssociations?: UserStackAssociation[];
}
export declare const BatchDisassociateUserStackRequest: S.Schema<BatchDisassociateUserStackRequest>;
export interface BatchDisassociateUserStackResult {
    errors?: (UserStackAssociationError & {
        UserStackAssociation: UserStackAssociation & {
            StackName: string;
            UserName: Username;
            AuthenticationType: AuthenticationType;
        };
    })[];
}
export declare const BatchDisassociateUserStackResult: S.Schema<BatchDisassociateUserStackResult>;
export type RegionName = string;
export type Description = string;
export interface CopyImageRequest {
    SourceImageName?: string;
    DestinationImageName?: string;
    DestinationRegion?: string;
    DestinationImageDescription?: string;
}
export declare const CopyImageRequest: S.Schema<CopyImageRequest>;
export interface CopyImageResponse {
    DestinationImageName?: string;
}
export declare const CopyImageResponse: S.Schema<CopyImageResponse>;
export type DisplayName = string;
export type S3Bucket = string;
export type S3Key = string;
export interface S3Location {
    S3Bucket?: string;
    S3Key?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export interface ScriptDetails {
    ScriptS3Location?: S3Location;
    ExecutablePath?: string;
    ExecutableParameters?: string;
    TimeoutInSeconds?: number;
}
export declare const ScriptDetails: S.Schema<ScriptDetails>;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export type PackagingType = "CUSTOM" | "APPSTREAM2" | (string & {});
export declare const PackagingType: any;
export interface CreateAppBlockRequest {
    Name?: string;
    Description?: string;
    DisplayName?: string;
    SourceS3Location?: S3Location;
    SetupScriptDetails?: ScriptDetails;
    Tags?: {
        [key: string]: string | undefined;
    };
    PostSetupScriptDetails?: ScriptDetails;
    PackagingType?: PackagingType;
}
export declare const CreateAppBlockRequest: S.Schema<CreateAppBlockRequest>;
export type AppBlockState = "INACTIVE" | "ACTIVE" | (string & {});
export declare const AppBlockState: any;
export interface ErrorDetails {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export type ErrorDetailsList = ErrorDetails[];
export declare const ErrorDetailsList: any;
export interface AppBlock {
    Name?: string;
    Arn?: string;
    Description?: string;
    DisplayName?: string;
    SourceS3Location?: S3Location;
    SetupScriptDetails?: ScriptDetails;
    CreatedTime?: Date;
    PostSetupScriptDetails?: ScriptDetails;
    PackagingType?: PackagingType;
    State?: AppBlockState;
    AppBlockErrors?: ErrorDetails[];
}
export declare const AppBlock: S.Schema<AppBlock>;
export interface CreateAppBlockResult {
    AppBlock?: AppBlock & {
        Name: string;
        Arn: Arn;
        SourceS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
        SetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
        PostSetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
    };
}
export declare const CreateAppBlockResult: S.Schema<CreateAppBlockResult>;
export type AppBlockBuilderPlatformType = "WINDOWS_SERVER_2019" | (string & {});
export declare const AppBlockBuilderPlatformType: any;
export type SubnetIdList = string[];
export declare const SubnetIdList: any;
export type SecurityGroupIdList = string[];
export declare const SecurityGroupIdList: any;
export interface VpcConfig {
    SubnetIds?: string[];
    SecurityGroupIds?: string[];
}
export declare const VpcConfig: S.Schema<VpcConfig>;
export type AccessEndpointType = "STREAMING" | (string & {});
export declare const AccessEndpointType: any;
export interface AccessEndpoint {
    EndpointType?: AccessEndpointType;
    VpceId?: string;
}
export declare const AccessEndpoint: S.Schema<AccessEndpoint>;
export type AccessEndpointList = AccessEndpoint[];
export declare const AccessEndpointList: any;
export interface CreateAppBlockBuilderRequest {
    Name?: string;
    Description?: string;
    DisplayName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Platform?: AppBlockBuilderPlatformType;
    InstanceType?: string;
    VpcConfig?: VpcConfig;
    EnableDefaultInternetAccess?: boolean;
    IamRoleArn?: string;
    AccessEndpoints?: AccessEndpoint[];
    DisableIMDSV1?: boolean;
}
export declare const CreateAppBlockBuilderRequest: S.Schema<CreateAppBlockBuilderRequest>;
export type AppBlockBuilderState = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | (string & {});
export declare const AppBlockBuilderState: any;
export type FleetErrorCode = "IAM_SERVICE_ROLE_MISSING_ENI_DESCRIBE_ACTION" | "IAM_SERVICE_ROLE_MISSING_ENI_CREATE_ACTION" | "IAM_SERVICE_ROLE_MISSING_ENI_DELETE_ACTION" | "NETWORK_INTERFACE_LIMIT_EXCEEDED" | "INTERNAL_SERVICE_ERROR" | "IAM_SERVICE_ROLE_IS_MISSING" | "MACHINE_ROLE_IS_MISSING" | "STS_DISABLED_IN_REGION" | "SUBNET_HAS_INSUFFICIENT_IP_ADDRESSES" | "IAM_SERVICE_ROLE_MISSING_DESCRIBE_SUBNET_ACTION" | "SUBNET_NOT_FOUND" | "IMAGE_NOT_FOUND" | "INVALID_SUBNET_CONFIGURATION" | "SECURITY_GROUPS_NOT_FOUND" | "IGW_NOT_ATTACHED" | "IAM_SERVICE_ROLE_MISSING_DESCRIBE_SECURITY_GROUPS_ACTION" | "FLEET_STOPPED" | "FLEET_INSTANCE_PROVISIONING_FAILURE" | "DOMAIN_JOIN_ERROR_FILE_NOT_FOUND" | "DOMAIN_JOIN_ERROR_ACCESS_DENIED" | "DOMAIN_JOIN_ERROR_LOGON_FAILURE" | "DOMAIN_JOIN_ERROR_INVALID_PARAMETER" | "DOMAIN_JOIN_ERROR_MORE_DATA" | "DOMAIN_JOIN_ERROR_NO_SUCH_DOMAIN" | "DOMAIN_JOIN_ERROR_NOT_SUPPORTED" | "DOMAIN_JOIN_NERR_INVALID_WORKGROUP_NAME" | "DOMAIN_JOIN_NERR_WORKSTATION_NOT_STARTED" | "DOMAIN_JOIN_ERROR_DS_MACHINE_ACCOUNT_QUOTA_EXCEEDED" | "DOMAIN_JOIN_NERR_PASSWORD_EXPIRED" | "DOMAIN_JOIN_INTERNAL_SERVICE_ERROR" | "VALIDATION_ERROR" | (string & {});
export declare const FleetErrorCode: any;
export interface ResourceError {
    ErrorCode?: FleetErrorCode;
    ErrorMessage?: string;
    ErrorTimestamp?: Date;
}
export declare const ResourceError: S.Schema<ResourceError>;
export type ResourceErrors = ResourceError[];
export declare const ResourceErrors: any;
export type AppBlockBuilderStateChangeReasonCode = "INTERNAL_ERROR" | (string & {});
export declare const AppBlockBuilderStateChangeReasonCode: any;
export interface AppBlockBuilderStateChangeReason {
    Code?: AppBlockBuilderStateChangeReasonCode;
    Message?: string;
}
export declare const AppBlockBuilderStateChangeReason: S.Schema<AppBlockBuilderStateChangeReason>;
export interface AppBlockBuilder {
    Arn?: string;
    Name?: string;
    DisplayName?: string;
    Description?: string;
    Platform?: AppBlockBuilderPlatformType;
    InstanceType?: string;
    EnableDefaultInternetAccess?: boolean;
    IamRoleArn?: string;
    VpcConfig?: VpcConfig;
    State?: AppBlockBuilderState;
    CreatedTime?: Date;
    AppBlockBuilderErrors?: ResourceError[];
    StateChangeReason?: AppBlockBuilderStateChangeReason;
    AccessEndpoints?: AccessEndpoint[];
    DisableIMDSV1?: boolean;
}
export declare const AppBlockBuilder: S.Schema<AppBlockBuilder>;
export interface CreateAppBlockBuilderResult {
    AppBlockBuilder?: AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const CreateAppBlockBuilderResult: S.Schema<CreateAppBlockBuilderResult>;
export interface CreateAppBlockBuilderStreamingURLRequest {
    AppBlockBuilderName?: string;
    Validity?: number;
}
export declare const CreateAppBlockBuilderStreamingURLRequest: S.Schema<CreateAppBlockBuilderStreamingURLRequest>;
export interface CreateAppBlockBuilderStreamingURLResult {
    StreamingURL?: string;
    Expires?: Date;
}
export declare const CreateAppBlockBuilderStreamingURLResult: S.Schema<CreateAppBlockBuilderStreamingURLResult>;
export type PlatformType = "WINDOWS" | "WINDOWS_SERVER_2016" | "WINDOWS_SERVER_2019" | "WINDOWS_SERVER_2022" | "WINDOWS_SERVER_2025" | "AMAZON_LINUX2" | "RHEL8" | "ROCKY_LINUX8" | "UBUNTU_PRO_2404" | (string & {});
export declare const PlatformType: any;
export type Platforms = PlatformType[];
export declare const Platforms: any;
export interface CreateApplicationRequest {
    Name?: string;
    DisplayName?: string;
    Description?: string;
    IconS3Location?: S3Location;
    LaunchPath?: string;
    WorkingDirectory?: string;
    LaunchParameters?: string;
    Platforms?: PlatformType[];
    InstanceFamilies?: string[];
    AppBlockArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type Metadata = {
    [key: string]: string | undefined;
};
export declare const Metadata: any;
export interface Application {
    Name?: string;
    DisplayName?: string;
    IconURL?: string;
    LaunchPath?: string;
    LaunchParameters?: string;
    Enabled?: boolean;
    Metadata?: {
        [key: string]: string | undefined;
    };
    WorkingDirectory?: string;
    Description?: string;
    Arn?: string;
    AppBlockArn?: string;
    IconS3Location?: S3Location;
    Platforms?: PlatformType[];
    InstanceFamilies?: string[];
    CreatedTime?: Date;
}
export declare const Application: S.Schema<Application>;
export interface CreateApplicationResult {
    Application?: Application & {
        IconS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    };
}
export declare const CreateApplicationResult: S.Schema<CreateApplicationResult>;
export type DirectoryName = string;
export type OrganizationalUnitDistinguishedName = string;
export type OrganizationalUnitDistinguishedNamesList = string[];
export declare const OrganizationalUnitDistinguishedNamesList: any;
export type AccountName = string | redacted.Redacted<string>;
export type AccountPassword = string | redacted.Redacted<string>;
export interface ServiceAccountCredentials {
    AccountName?: string | redacted.Redacted<string>;
    AccountPassword?: string | redacted.Redacted<string>;
}
export declare const ServiceAccountCredentials: S.Schema<ServiceAccountCredentials>;
export type CertificateBasedAuthStatus = "DISABLED" | "ENABLED" | "ENABLED_NO_DIRECTORY_LOGIN_FALLBACK" | (string & {});
export declare const CertificateBasedAuthStatus: any;
export interface CertificateBasedAuthProperties {
    Status?: CertificateBasedAuthStatus;
    CertificateAuthorityArn?: string;
}
export declare const CertificateBasedAuthProperties: S.Schema<CertificateBasedAuthProperties>;
export interface CreateDirectoryConfigRequest {
    DirectoryName?: string;
    OrganizationalUnitDistinguishedNames?: string[];
    ServiceAccountCredentials?: ServiceAccountCredentials;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties;
}
export declare const CreateDirectoryConfigRequest: S.Schema<CreateDirectoryConfigRequest>;
export interface DirectoryConfig {
    DirectoryName?: string;
    OrganizationalUnitDistinguishedNames?: string[];
    ServiceAccountCredentials?: ServiceAccountCredentials;
    CreatedTime?: Date;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties;
}
export declare const DirectoryConfig: S.Schema<DirectoryConfig>;
export interface CreateDirectoryConfigResult {
    DirectoryConfig?: DirectoryConfig & {
        DirectoryName: DirectoryName;
        ServiceAccountCredentials: ServiceAccountCredentials & {
            AccountName: AccountName;
            AccountPassword: AccountPassword;
        };
    };
}
export declare const CreateDirectoryConfigResult: S.Schema<CreateDirectoryConfigResult>;
export type AppVisibility = "ALL" | "ASSOCIATED" | (string & {});
export declare const AppVisibility: any;
export interface EntitlementAttribute {
    Name?: string;
    Value?: string;
}
export declare const EntitlementAttribute: S.Schema<EntitlementAttribute>;
export type EntitlementAttributeList = EntitlementAttribute[];
export declare const EntitlementAttributeList: any;
export interface CreateEntitlementRequest {
    Name?: string;
    StackName?: string;
    Description?: string;
    AppVisibility?: AppVisibility;
    Attributes?: EntitlementAttribute[];
}
export declare const CreateEntitlementRequest: S.Schema<CreateEntitlementRequest>;
export interface Entitlement {
    Name?: string;
    StackName?: string;
    Description?: string;
    AppVisibility?: AppVisibility;
    Attributes?: EntitlementAttribute[];
    CreatedTime?: Date;
    LastModifiedTime?: Date;
}
export declare const Entitlement: S.Schema<Entitlement>;
export interface CreateEntitlementResult {
    Entitlement?: Entitlement & {
        Name: Name;
        StackName: Name;
        AppVisibility: AppVisibility;
        Attributes: (EntitlementAttribute & {
            Name: string;
            Value: string;
        })[];
    };
}
export declare const CreateEntitlementResult: S.Schema<CreateEntitlementResult>;
export type AmiName = string;
export interface CreateExportImageTaskRequest {
    ImageName?: string;
    AmiName?: string;
    IamRoleArn?: string;
    TagSpecifications?: {
        [key: string]: string | undefined;
    };
    AmiDescription?: string;
}
export declare const CreateExportImageTaskRequest: S.Schema<CreateExportImageTaskRequest>;
export type UUID = string;
export type ExportImageTaskState = "EXPORTING" | "COMPLETED" | "FAILED" | "TIMED_OUT" | (string & {});
export declare const ExportImageTaskState: any;
export type PhotonAmiId = string;
export interface ExportImageTask {
    TaskId?: string;
    ImageArn?: string;
    AmiName?: string;
    CreatedDate?: Date;
    AmiDescription?: string;
    State?: ExportImageTaskState;
    AmiId?: string;
    TagSpecifications?: {
        [key: string]: string | undefined;
    };
    ErrorDetails?: ErrorDetails[];
}
export declare const ExportImageTask: S.Schema<ExportImageTask>;
export interface CreateExportImageTaskResult {
    ExportImageTask?: ExportImageTask & {
        TaskId: UUID;
        ImageArn: Arn;
        AmiName: AmiName;
        CreatedDate: Date;
    };
}
export declare const CreateExportImageTaskResult: S.Schema<CreateExportImageTaskResult>;
export type FleetType = "ALWAYS_ON" | "ON_DEMAND" | "ELASTIC" | (string & {});
export declare const FleetType: any;
export interface ComputeCapacity {
    DesiredInstances?: number;
    DesiredSessions?: number;
}
export declare const ComputeCapacity: S.Schema<ComputeCapacity>;
export interface DomainJoinInfo {
    DirectoryName?: string;
    OrganizationalUnitDistinguishedName?: string;
}
export declare const DomainJoinInfo: S.Schema<DomainJoinInfo>;
export type StreamView = "APP" | "DESKTOP" | (string & {});
export declare const StreamView: any;
export type UsbDeviceFilterString = string;
export type UsbDeviceFilterStrings = string[];
export declare const UsbDeviceFilterStrings: any;
export interface VolumeConfig {
    VolumeSizeInGb?: number;
}
export declare const VolumeConfig: S.Schema<VolumeConfig>;
export interface CreateFleetRequest {
    Name?: string;
    ImageName?: string;
    ImageArn?: string;
    InstanceType?: string;
    FleetType?: FleetType;
    ComputeCapacity?: ComputeCapacity;
    VpcConfig?: VpcConfig;
    MaxUserDurationInSeconds?: number;
    DisconnectTimeoutInSeconds?: number;
    Description?: string;
    DisplayName?: string;
    EnableDefaultInternetAccess?: boolean;
    DomainJoinInfo?: DomainJoinInfo;
    Tags?: {
        [key: string]: string | undefined;
    };
    IdleDisconnectTimeoutInSeconds?: number;
    IamRoleArn?: string;
    StreamView?: StreamView;
    Platform?: PlatformType;
    MaxConcurrentSessions?: number;
    UsbDeviceFilterStrings?: string[];
    SessionScriptS3Location?: S3Location;
    MaxSessionsPerInstance?: number;
    RootVolumeConfig?: VolumeConfig;
    DisableIMDSV1?: boolean;
}
export declare const CreateFleetRequest: S.Schema<CreateFleetRequest>;
export interface ComputeCapacityStatus {
    Desired?: number;
    Running?: number;
    InUse?: number;
    Available?: number;
    DesiredUserSessions?: number;
    AvailableUserSessions?: number;
    ActiveUserSessions?: number;
    ActualUserSessions?: number;
    Draining?: number;
    DrainModeActiveUserSessions?: number;
    DrainModeUnusedUserSessions?: number;
}
export declare const ComputeCapacityStatus: S.Schema<ComputeCapacityStatus>;
export type FleetState = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | (string & {});
export declare const FleetState: any;
export interface FleetError {
    ErrorCode?: FleetErrorCode;
    ErrorMessage?: string;
}
export declare const FleetError: S.Schema<FleetError>;
export type FleetErrors = FleetError[];
export declare const FleetErrors: any;
export interface Fleet {
    Arn?: string;
    Name?: string;
    DisplayName?: string;
    Description?: string;
    ImageName?: string;
    ImageArn?: string;
    InstanceType?: string;
    FleetType?: FleetType;
    ComputeCapacityStatus?: ComputeCapacityStatus;
    MaxUserDurationInSeconds?: number;
    DisconnectTimeoutInSeconds?: number;
    State?: FleetState;
    VpcConfig?: VpcConfig;
    CreatedTime?: Date;
    FleetErrors?: FleetError[];
    EnableDefaultInternetAccess?: boolean;
    DomainJoinInfo?: DomainJoinInfo;
    IdleDisconnectTimeoutInSeconds?: number;
    IamRoleArn?: string;
    StreamView?: StreamView;
    Platform?: PlatformType;
    MaxConcurrentSessions?: number;
    UsbDeviceFilterStrings?: string[];
    SessionScriptS3Location?: S3Location;
    MaxSessionsPerInstance?: number;
    RootVolumeConfig?: VolumeConfig;
    DisableIMDSV1?: boolean;
}
export declare const Fleet: S.Schema<Fleet>;
export interface CreateFleetResult {
    Fleet?: Fleet & {
        Arn: Arn;
        Name: string;
        InstanceType: string;
        ComputeCapacityStatus: ComputeCapacityStatus & {
            Desired: number;
        };
        State: FleetState;
        SessionScriptS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    };
}
export declare const CreateFleetResult: S.Schema<CreateFleetResult>;
export type AppstreamAgentVersion = string;
export interface CreateImageBuilderRequest {
    Name?: string;
    ImageName?: string;
    ImageArn?: string;
    InstanceType?: string;
    Description?: string;
    DisplayName?: string;
    VpcConfig?: VpcConfig;
    IamRoleArn?: string;
    EnableDefaultInternetAccess?: boolean;
    DomainJoinInfo?: DomainJoinInfo;
    AppstreamAgentVersion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    AccessEndpoints?: AccessEndpoint[];
    RootVolumeConfig?: VolumeConfig;
    SoftwaresToInstall?: string[];
    SoftwaresToUninstall?: string[];
    DisableIMDSV1?: boolean;
}
export declare const CreateImageBuilderRequest: S.Schema<CreateImageBuilderRequest>;
export type ImageBuilderState = "PENDING" | "UPDATING_AGENT" | "RUNNING" | "STOPPING" | "STOPPED" | "REBOOTING" | "SNAPSHOTTING" | "DELETING" | "FAILED" | "UPDATING" | "PENDING_QUALIFICATION" | "PENDING_SYNCING_APPS" | "SYNCING_APPS" | "PENDING_IMAGE_IMPORT" | (string & {});
export declare const ImageBuilderState: any;
export type ImageBuilderStateChangeReasonCode = "INTERNAL_ERROR" | "IMAGE_UNAVAILABLE" | (string & {});
export declare const ImageBuilderStateChangeReasonCode: any;
export interface ImageBuilderStateChangeReason {
    Code?: ImageBuilderStateChangeReasonCode;
    Message?: string;
}
export declare const ImageBuilderStateChangeReason: S.Schema<ImageBuilderStateChangeReason>;
export interface NetworkAccessConfiguration {
    EniPrivateIpAddress?: string;
    EniIpv6Addresses?: string[];
    EniId?: string;
}
export declare const NetworkAccessConfiguration: S.Schema<NetworkAccessConfiguration>;
export type LatestAppstreamAgentVersion = "TRUE" | "FALSE" | (string & {});
export declare const LatestAppstreamAgentVersion: any;
export interface ImageBuilder {
    Name?: string;
    Arn?: string;
    ImageArn?: string;
    Description?: string;
    DisplayName?: string;
    VpcConfig?: VpcConfig;
    InstanceType?: string;
    Platform?: PlatformType;
    IamRoleArn?: string;
    State?: ImageBuilderState;
    StateChangeReason?: ImageBuilderStateChangeReason;
    CreatedTime?: Date;
    EnableDefaultInternetAccess?: boolean;
    DomainJoinInfo?: DomainJoinInfo;
    NetworkAccessConfiguration?: NetworkAccessConfiguration;
    ImageBuilderErrors?: ResourceError[];
    AppstreamAgentVersion?: string;
    AccessEndpoints?: AccessEndpoint[];
    RootVolumeConfig?: VolumeConfig;
    LatestAppstreamAgentVersion?: LatestAppstreamAgentVersion;
    DisableIMDSV1?: boolean;
}
export declare const ImageBuilder: S.Schema<ImageBuilder>;
export interface CreateImageBuilderResult {
    ImageBuilder?: ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const CreateImageBuilderResult: S.Schema<CreateImageBuilderResult>;
export interface CreateImageBuilderStreamingURLRequest {
    Name?: string;
    Validity?: number;
}
export declare const CreateImageBuilderStreamingURLRequest: S.Schema<CreateImageBuilderStreamingURLRequest>;
export interface CreateImageBuilderStreamingURLResult {
    StreamingURL?: string;
    Expires?: Date;
}
export declare const CreateImageBuilderStreamingURLResult: S.Schema<CreateImageBuilderStreamingURLResult>;
export type WorkspaceImageId = string;
export type ImageImportDescription = string;
export type ImageImportDisplayName = string;
export type InstanceType = string;
export interface RuntimeValidationConfig {
    IntendedInstanceType?: string;
}
export declare const RuntimeValidationConfig: S.Schema<RuntimeValidationConfig>;
export type AgentSoftwareVersion = "CURRENT_LATEST" | "ALWAYS_LATEST" | (string & {});
export declare const AgentSoftwareVersion: any;
export type AppName = string;
export type AppDisplayName = string;
export type FilePath = string | redacted.Redacted<string>;
export type LaunchParameters = string | redacted.Redacted<string>;
export interface ApplicationConfig {
    Name?: string;
    DisplayName?: string;
    AbsoluteAppPath?: string | redacted.Redacted<string>;
    AbsoluteIconPath?: string | redacted.Redacted<string>;
    AbsoluteManifestPath?: string | redacted.Redacted<string>;
    WorkingDirectory?: string | redacted.Redacted<string>;
    LaunchParameters?: string | redacted.Redacted<string>;
}
export declare const ApplicationConfig: S.Schema<ApplicationConfig>;
export type AppCatalogConfig = ApplicationConfig[];
export declare const AppCatalogConfig: any;
export interface CreateImportedImageRequest {
    Name?: string;
    SourceAmiId?: string;
    WorkspaceImageId?: string;
    IamRoleArn?: string;
    Description?: string;
    DisplayName?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RuntimeValidationConfig?: RuntimeValidationConfig;
    AgentSoftwareVersion?: AgentSoftwareVersion;
    AppCatalogConfig?: ApplicationConfig[];
    DryRun?: boolean;
}
export declare const CreateImportedImageRequest: S.Schema<CreateImportedImageRequest>;
export type ImageState = "PENDING" | "AVAILABLE" | "FAILED" | "COPYING" | "DELETING" | "CREATING" | "IMPORTING" | "VALIDATING" | (string & {});
export declare const ImageState: any;
export type VisibilityType = "PUBLIC" | "PRIVATE" | "SHARED" | (string & {});
export declare const VisibilityType: any;
export type ImageStateChangeReasonCode = "INTERNAL_ERROR" | "IMAGE_BUILDER_NOT_AVAILABLE" | "IMAGE_COPY_FAILURE" | "IMAGE_UPDATE_FAILURE" | "IMAGE_IMPORT_FAILURE" | (string & {});
export declare const ImageStateChangeReasonCode: any;
export interface ImageStateChangeReason {
    Code?: ImageStateChangeReasonCode;
    Message?: string;
}
export declare const ImageStateChangeReason: S.Schema<ImageStateChangeReason>;
export type Applications = Application[];
export declare const Applications: any;
export interface ImagePermissions {
    allowFleet?: boolean;
    allowImageBuilder?: boolean;
}
export declare const ImagePermissions: S.Schema<ImagePermissions>;
export type DynamicAppProvidersEnabled = "ENABLED" | "DISABLED" | (string & {});
export declare const DynamicAppProvidersEnabled: any;
export type ImageSharedWithOthers = "TRUE" | "FALSE" | (string & {});
export declare const ImageSharedWithOthers: any;
export type ImageType = "CUSTOM" | "NATIVE" | "BYOL" | (string & {});
export declare const ImageType: any;
export interface Image {
    Name?: string;
    Arn?: string;
    BaseImageArn?: string;
    DisplayName?: string;
    State?: ImageState;
    Visibility?: VisibilityType;
    ImageBuilderSupported?: boolean;
    ImageBuilderName?: string;
    Platform?: PlatformType;
    Description?: string;
    StateChangeReason?: ImageStateChangeReason;
    Applications?: Application[];
    CreatedTime?: Date;
    PublicBaseImageReleasedDate?: Date;
    AppstreamAgentVersion?: string;
    ImagePermissions?: ImagePermissions;
    ImageErrors?: ResourceError[];
    LatestAppstreamAgentVersion?: LatestAppstreamAgentVersion;
    SupportedInstanceFamilies?: string[];
    DynamicAppProvidersEnabled?: DynamicAppProvidersEnabled;
    ImageSharedWithOthers?: ImageSharedWithOthers;
    ManagedSoftwareIncluded?: boolean;
    ImageType?: ImageType;
}
export declare const Image: S.Schema<Image>;
export interface CreateImportedImageResult {
    Image?: Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    };
}
export declare const CreateImportedImageResult: S.Schema<CreateImportedImageResult>;
export type StorageConnectorType = "HOMEFOLDERS" | "GOOGLE_DRIVE" | "ONE_DRIVE" | (string & {});
export declare const StorageConnectorType: any;
export type ResourceIdentifier = string;
export type Domain = string;
export type DomainList = string[];
export declare const DomainList: any;
export interface StorageConnector {
    ConnectorType?: StorageConnectorType;
    ResourceIdentifier?: string;
    Domains?: string[];
    DomainsRequireAdminConsent?: string[];
}
export declare const StorageConnector: S.Schema<StorageConnector>;
export type StorageConnectorList = StorageConnector[];
export declare const StorageConnectorList: any;
export type RedirectURL = string;
export type FeedbackURL = string;
export type Action = "CLIPBOARD_COPY_FROM_LOCAL_DEVICE" | "CLIPBOARD_COPY_TO_LOCAL_DEVICE" | "FILE_UPLOAD" | "FILE_DOWNLOAD" | "PRINTING_TO_LOCAL_DEVICE" | "DOMAIN_PASSWORD_SIGNIN" | "DOMAIN_SMART_CARD_SIGNIN" | "AUTO_TIME_ZONE_REDIRECTION" | (string & {});
export declare const Action: any;
export type Permission = "ENABLED" | "DISABLED" | (string & {});
export declare const Permission: any;
export interface UserSetting {
    Action?: Action;
    Permission?: Permission;
    MaximumLength?: number;
}
export declare const UserSetting: S.Schema<UserSetting>;
export type UserSettingList = UserSetting[];
export declare const UserSettingList: any;
export type SettingsGroup = string;
export interface ApplicationSettings {
    Enabled?: boolean;
    SettingsGroup?: string;
}
export declare const ApplicationSettings: S.Schema<ApplicationSettings>;
export type EmbedHostDomain = string;
export type EmbedHostDomains = string[];
export declare const EmbedHostDomains: any;
export type PreferredProtocol = "TCP" | "UDP" | (string & {});
export declare const PreferredProtocol: any;
export interface StreamingExperienceSettings {
    PreferredProtocol?: PreferredProtocol;
}
export declare const StreamingExperienceSettings: S.Schema<StreamingExperienceSettings>;
export type UrlPattern = string;
export type UrlPatternList = string[];
export declare const UrlPatternList: any;
export interface UrlRedirectionConfig {
    Enabled?: boolean;
    AllowedUrls?: string[];
    DeniedUrls?: string[];
}
export declare const UrlRedirectionConfig: S.Schema<UrlRedirectionConfig>;
export interface ContentRedirection {
    HostToClient?: UrlRedirectionConfig;
}
export declare const ContentRedirection: S.Schema<ContentRedirection>;
export type AgentAction = "COMPUTER_VISION" | "COMPUTER_INPUT" | "FORWARD_MCP_TOOLS" | (string & {});
export declare const AgentAction: any;
export interface AgentAccessSetting {
    AgentAction?: AgentAction;
    Permission?: Permission;
}
export declare const AgentAccessSetting: S.Schema<AgentAccessSetting>;
export type AgentAccessSettingList = AgentAccessSetting[];
export declare const AgentAccessSettingList: any;
export type S3BucketArn = string;
export type ScreenResolution = "W_1280xH_720" | (string & {});
export declare const ScreenResolution: any;
export type ScreenImageFormat = "PNG" | "JPEG" | (string & {});
export declare const ScreenImageFormat: any;
export type UserControlMode = "VIEW_ONLY" | "VIEW_STOP" | "DISABLED" | (string & {});
export declare const UserControlMode: any;
export interface AgentAccessConfig {
    Settings?: AgentAccessSetting[];
    S3BucketArn?: string;
    ScreenshotsUploadEnabled?: boolean;
    ScreenResolution?: ScreenResolution;
    ScreenImageFormat?: ScreenImageFormat;
    UserControlMode?: UserControlMode;
}
export declare const AgentAccessConfig: S.Schema<AgentAccessConfig>;
export interface CreateStackRequest {
    Name?: string;
    Description?: string;
    DisplayName?: string;
    StorageConnectors?: StorageConnector[];
    RedirectURL?: string;
    FeedbackURL?: string;
    UserSettings?: UserSetting[];
    ApplicationSettings?: ApplicationSettings;
    Tags?: {
        [key: string]: string | undefined;
    };
    AccessEndpoints?: AccessEndpoint[];
    EmbedHostDomains?: string[];
    StreamingExperienceSettings?: StreamingExperienceSettings;
    ContentRedirection?: ContentRedirection;
    AgentAccessConfig?: AgentAccessConfig;
}
export declare const CreateStackRequest: S.Schema<CreateStackRequest>;
export type StackErrorCode = "STORAGE_CONNECTOR_ERROR" | "INTERNAL_SERVICE_ERROR" | (string & {});
export declare const StackErrorCode: any;
export interface StackError {
    ErrorCode?: StackErrorCode;
    ErrorMessage?: string;
}
export declare const StackError: S.Schema<StackError>;
export type StackErrors = StackError[];
export declare const StackErrors: any;
export interface ApplicationSettingsResponse {
    Enabled?: boolean;
    SettingsGroup?: string;
    S3BucketName?: string;
}
export declare const ApplicationSettingsResponse: S.Schema<ApplicationSettingsResponse>;
export interface Stack {
    Arn?: string;
    Name?: string;
    Description?: string;
    DisplayName?: string;
    CreatedTime?: Date;
    StorageConnectors?: StorageConnector[];
    RedirectURL?: string;
    FeedbackURL?: string;
    StackErrors?: StackError[];
    UserSettings?: UserSetting[];
    ApplicationSettings?: ApplicationSettingsResponse;
    AccessEndpoints?: AccessEndpoint[];
    EmbedHostDomains?: string[];
    StreamingExperienceSettings?: StreamingExperienceSettings;
    ContentRedirection?: ContentRedirection;
    AgentAccessConfig?: AgentAccessConfig;
}
export declare const Stack: S.Schema<Stack>;
export interface CreateStackResult {
    Stack?: Stack & {
        Name: string;
        StorageConnectors: (StorageConnector & {
            ConnectorType: StorageConnectorType;
        })[];
        UserSettings: (UserSetting & {
            Action: Action;
            Permission: Permission;
        })[];
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        ContentRedirection: ContentRedirection & {
            HostToClient: UrlRedirectionConfig & {
                Enabled: boolean;
            };
        };
        AgentAccessConfig: AgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    };
}
export declare const CreateStackResult: S.Schema<CreateStackResult>;
export type StreamingUrlUserId = string;
export interface CreateStreamingURLRequest {
    StackName?: string;
    FleetName?: string;
    UserId?: string;
    ApplicationId?: string;
    Validity?: number;
    SessionContext?: string;
}
export declare const CreateStreamingURLRequest: S.Schema<CreateStreamingURLRequest>;
export interface CreateStreamingURLResult {
    StreamingURL?: string;
    Expires?: Date;
}
export declare const CreateStreamingURLResult: S.Schema<CreateStreamingURLResult>;
export type ThemeFooterLinkDisplayName = string;
export type ThemeFooterLinkURL = string;
export interface ThemeFooterLink {
    DisplayName?: string;
    FooterLinkURL?: string;
}
export declare const ThemeFooterLink: S.Schema<ThemeFooterLink>;
export type ThemeFooterLinks = ThemeFooterLink[];
export declare const ThemeFooterLinks: any;
export type ThemeTitleText = string;
export type ThemeStyling = "LIGHT_BLUE" | "BLUE" | "PINK" | "RED" | (string & {});
export declare const ThemeStyling: any;
export interface CreateThemeForStackRequest {
    StackName?: string;
    FooterLinks?: ThemeFooterLink[];
    TitleText?: string;
    ThemeStyling?: ThemeStyling;
    OrganizationLogoS3Location?: S3Location;
    FaviconS3Location?: S3Location;
}
export declare const CreateThemeForStackRequest: S.Schema<CreateThemeForStackRequest>;
export type ThemeState = "ENABLED" | "DISABLED" | (string & {});
export declare const ThemeState: any;
export interface Theme {
    StackName?: string;
    State?: ThemeState;
    ThemeTitleText?: string;
    ThemeStyling?: ThemeStyling;
    ThemeFooterLinks?: ThemeFooterLink[];
    ThemeOrganizationLogoURL?: string;
    ThemeFaviconURL?: string;
    CreatedTime?: Date;
}
export declare const Theme: S.Schema<Theme>;
export interface CreateThemeForStackResult {
    Theme?: Theme;
}
export declare const CreateThemeForStackResult: S.Schema<CreateThemeForStackResult>;
export interface CreateUpdatedImageRequest {
    existingImageName?: string;
    newImageName?: string;
    newImageDescription?: string;
    newImageDisplayName?: string;
    newImageTags?: {
        [key: string]: string | undefined;
    };
    dryRun?: boolean;
}
export declare const CreateUpdatedImageRequest: S.Schema<CreateUpdatedImageRequest>;
export interface CreateUpdatedImageResult {
    image?: Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    };
    canUpdateImage?: boolean;
}
export declare const CreateUpdatedImageResult: S.Schema<CreateUpdatedImageResult>;
export interface CreateUsageReportSubscriptionRequest {
}
export declare const CreateUsageReportSubscriptionRequest: S.Schema<CreateUsageReportSubscriptionRequest>;
export type UsageReportSchedule = "DAILY" | (string & {});
export declare const UsageReportSchedule: any;
export interface CreateUsageReportSubscriptionResult {
    S3BucketName?: string;
    Schedule?: UsageReportSchedule;
}
export declare const CreateUsageReportSubscriptionResult: S.Schema<CreateUsageReportSubscriptionResult>;
export type MessageAction = "SUPPRESS" | "RESEND" | (string & {});
export declare const MessageAction: any;
export type UserAttributeValue = string | redacted.Redacted<string>;
export interface CreateUserRequest {
    UserName?: string | redacted.Redacted<string>;
    MessageAction?: MessageAction;
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
    AuthenticationType?: AuthenticationType;
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
export interface CreateUserResult {
}
export declare const CreateUserResult: S.Schema<CreateUserResult>;
export interface DeleteAppBlockRequest {
    Name?: string;
}
export declare const DeleteAppBlockRequest: S.Schema<DeleteAppBlockRequest>;
export interface DeleteAppBlockResult {
}
export declare const DeleteAppBlockResult: S.Schema<DeleteAppBlockResult>;
export interface DeleteAppBlockBuilderRequest {
    Name?: string;
}
export declare const DeleteAppBlockBuilderRequest: S.Schema<DeleteAppBlockBuilderRequest>;
export interface DeleteAppBlockBuilderResult {
}
export declare const DeleteAppBlockBuilderResult: S.Schema<DeleteAppBlockBuilderResult>;
export interface DeleteApplicationRequest {
    Name?: string;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResult {
}
export declare const DeleteApplicationResult: S.Schema<DeleteApplicationResult>;
export interface DeleteDirectoryConfigRequest {
    DirectoryName?: string;
}
export declare const DeleteDirectoryConfigRequest: S.Schema<DeleteDirectoryConfigRequest>;
export interface DeleteDirectoryConfigResult {
}
export declare const DeleteDirectoryConfigResult: S.Schema<DeleteDirectoryConfigResult>;
export interface DeleteEntitlementRequest {
    Name?: string;
    StackName?: string;
}
export declare const DeleteEntitlementRequest: S.Schema<DeleteEntitlementRequest>;
export interface DeleteEntitlementResult {
}
export declare const DeleteEntitlementResult: S.Schema<DeleteEntitlementResult>;
export interface DeleteFleetRequest {
    Name?: string;
}
export declare const DeleteFleetRequest: S.Schema<DeleteFleetRequest>;
export interface DeleteFleetResult {
}
export declare const DeleteFleetResult: S.Schema<DeleteFleetResult>;
export interface DeleteImageRequest {
    Name?: string;
}
export declare const DeleteImageRequest: S.Schema<DeleteImageRequest>;
export interface DeleteImageResult {
    Image?: Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    };
}
export declare const DeleteImageResult: S.Schema<DeleteImageResult>;
export interface DeleteImageBuilderRequest {
    Name?: string;
}
export declare const DeleteImageBuilderRequest: S.Schema<DeleteImageBuilderRequest>;
export interface DeleteImageBuilderResult {
    ImageBuilder?: ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const DeleteImageBuilderResult: S.Schema<DeleteImageBuilderResult>;
export type AwsAccountId = string;
export interface DeleteImagePermissionsRequest {
    Name?: string;
    SharedAccountId?: string;
}
export declare const DeleteImagePermissionsRequest: S.Schema<DeleteImagePermissionsRequest>;
export interface DeleteImagePermissionsResult {
}
export declare const DeleteImagePermissionsResult: S.Schema<DeleteImagePermissionsResult>;
export interface DeleteStackRequest {
    Name?: string;
}
export declare const DeleteStackRequest: S.Schema<DeleteStackRequest>;
export interface DeleteStackResult {
}
export declare const DeleteStackResult: S.Schema<DeleteStackResult>;
export interface DeleteThemeForStackRequest {
    StackName?: string;
}
export declare const DeleteThemeForStackRequest: S.Schema<DeleteThemeForStackRequest>;
export interface DeleteThemeForStackResult {
}
export declare const DeleteThemeForStackResult: S.Schema<DeleteThemeForStackResult>;
export interface DeleteUsageReportSubscriptionRequest {
}
export declare const DeleteUsageReportSubscriptionRequest: S.Schema<DeleteUsageReportSubscriptionRequest>;
export interface DeleteUsageReportSubscriptionResult {
}
export declare const DeleteUsageReportSubscriptionResult: S.Schema<DeleteUsageReportSubscriptionResult>;
export interface DeleteUserRequest {
    UserName?: string | redacted.Redacted<string>;
    AuthenticationType?: AuthenticationType;
}
export declare const DeleteUserRequest: S.Schema<DeleteUserRequest>;
export interface DeleteUserResult {
}
export declare const DeleteUserResult: S.Schema<DeleteUserResult>;
export interface DescribeAppBlockBuilderAppBlockAssociationsRequest {
    AppBlockArn?: string;
    AppBlockBuilderName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeAppBlockBuilderAppBlockAssociationsRequest: S.Schema<DescribeAppBlockBuilderAppBlockAssociationsRequest>;
export type AppBlockBuilderAppBlockAssociationsList = AppBlockBuilderAppBlockAssociation[];
export declare const AppBlockBuilderAppBlockAssociationsList: any;
export interface DescribeAppBlockBuilderAppBlockAssociationsResult {
    AppBlockBuilderAppBlockAssociations?: (AppBlockBuilderAppBlockAssociation & {
        AppBlockArn: Arn;
        AppBlockBuilderName: Name;
    })[];
    NextToken?: string;
}
export declare const DescribeAppBlockBuilderAppBlockAssociationsResult: S.Schema<DescribeAppBlockBuilderAppBlockAssociationsResult>;
export interface DescribeAppBlockBuildersRequest {
    Names?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeAppBlockBuildersRequest: S.Schema<DescribeAppBlockBuildersRequest>;
export type AppBlockBuilderList = AppBlockBuilder[];
export declare const AppBlockBuilderList: any;
export interface DescribeAppBlockBuildersResult {
    AppBlockBuilders?: (AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeAppBlockBuildersResult: S.Schema<DescribeAppBlockBuildersResult>;
export type ArnList = string[];
export declare const ArnList: any;
export interface DescribeAppBlocksRequest {
    Arns?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeAppBlocksRequest: S.Schema<DescribeAppBlocksRequest>;
export type AppBlocks = AppBlock[];
export declare const AppBlocks: any;
export interface DescribeAppBlocksResult {
    AppBlocks?: (AppBlock & {
        Name: string;
        Arn: Arn;
        SourceS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
        SetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
        PostSetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeAppBlocksResult: S.Schema<DescribeAppBlocksResult>;
export interface DescribeApplicationFleetAssociationsRequest {
    FleetName?: string;
    ApplicationArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeApplicationFleetAssociationsRequest: S.Schema<DescribeApplicationFleetAssociationsRequest>;
export type ApplicationFleetAssociationList = ApplicationFleetAssociation[];
export declare const ApplicationFleetAssociationList: any;
export interface DescribeApplicationFleetAssociationsResult {
    ApplicationFleetAssociations?: (ApplicationFleetAssociation & {
        FleetName: string;
        ApplicationArn: Arn;
    })[];
    NextToken?: string;
}
export declare const DescribeApplicationFleetAssociationsResult: S.Schema<DescribeApplicationFleetAssociationsResult>;
export interface DescribeApplicationsRequest {
    Arns?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeApplicationsRequest: S.Schema<DescribeApplicationsRequest>;
export interface DescribeApplicationsResult {
    Applications?: (Application & {
        IconS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeApplicationsResult: S.Schema<DescribeApplicationsResult>;
export interface DescribeAppLicenseUsageRequest {
    BillingPeriod?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeAppLicenseUsageRequest: S.Schema<DescribeAppLicenseUsageRequest>;
export interface AdminAppLicenseUsageRecord {
    UserArn?: string;
    BillingPeriod?: string;
    OwnerAWSAccountId?: string;
    SubscriptionFirstUsedDate?: Date;
    SubscriptionLastUsedDate?: Date;
    LicenseType?: string;
    UserId?: string;
}
export declare const AdminAppLicenseUsageRecord: S.Schema<AdminAppLicenseUsageRecord>;
export type AdminAppLicenseUsageList = AdminAppLicenseUsageRecord[];
export declare const AdminAppLicenseUsageList: any;
export interface DescribeAppLicenseUsageResult {
    AppLicenseUsages?: (AdminAppLicenseUsageRecord & {
        UserArn: string;
        BillingPeriod: string;
        OwnerAWSAccountId: AwsAccountId;
        SubscriptionFirstUsedDate: Date;
        SubscriptionLastUsedDate: Date;
        LicenseType: string;
        UserId: string;
    })[];
    NextToken?: string;
}
export declare const DescribeAppLicenseUsageResult: S.Schema<DescribeAppLicenseUsageResult>;
export type DirectoryNameList = string[];
export declare const DirectoryNameList: any;
export interface DescribeDirectoryConfigsRequest {
    DirectoryNames?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeDirectoryConfigsRequest: S.Schema<DescribeDirectoryConfigsRequest>;
export type DirectoryConfigList = DirectoryConfig[];
export declare const DirectoryConfigList: any;
export interface DescribeDirectoryConfigsResult {
    DirectoryConfigs?: (DirectoryConfig & {
        DirectoryName: DirectoryName;
        ServiceAccountCredentials: ServiceAccountCredentials & {
            AccountName: AccountName;
            AccountPassword: AccountPassword;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeDirectoryConfigsResult: S.Schema<DescribeDirectoryConfigsResult>;
export interface DescribeEntitlementsRequest {
    Name?: string;
    StackName?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeEntitlementsRequest: S.Schema<DescribeEntitlementsRequest>;
export type EntitlementList = Entitlement[];
export declare const EntitlementList: any;
export interface DescribeEntitlementsResult {
    Entitlements?: (Entitlement & {
        Name: Name;
        StackName: Name;
        AppVisibility: AppVisibility;
        Attributes: (EntitlementAttribute & {
            Name: string;
            Value: string;
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeEntitlementsResult: S.Schema<DescribeEntitlementsResult>;
export interface DescribeFleetsRequest {
    Names?: string[];
    NextToken?: string;
}
export declare const DescribeFleetsRequest: S.Schema<DescribeFleetsRequest>;
export type FleetList = Fleet[];
export declare const FleetList: any;
export interface DescribeFleetsResult {
    Fleets?: (Fleet & {
        Arn: Arn;
        Name: string;
        InstanceType: string;
        ComputeCapacityStatus: ComputeCapacityStatus & {
            Desired: number;
        };
        State: FleetState;
        SessionScriptS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeFleetsResult: S.Schema<DescribeFleetsResult>;
export interface DescribeImageBuildersRequest {
    Names?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeImageBuildersRequest: S.Schema<DescribeImageBuildersRequest>;
export type ImageBuilderList = ImageBuilder[];
export declare const ImageBuilderList: any;
export interface DescribeImageBuildersResult {
    ImageBuilders?: (ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeImageBuildersResult: S.Schema<DescribeImageBuildersResult>;
export type MaxResults = number;
export type AwsAccountIdList = string[];
export declare const AwsAccountIdList: any;
export interface DescribeImagePermissionsRequest {
    Name?: string;
    MaxResults?: number;
    SharedAwsAccountIds?: string[];
    NextToken?: string;
}
export declare const DescribeImagePermissionsRequest: S.Schema<DescribeImagePermissionsRequest>;
export interface SharedImagePermissions {
    sharedAccountId?: string;
    imagePermissions?: ImagePermissions;
}
export declare const SharedImagePermissions: S.Schema<SharedImagePermissions>;
export type SharedImagePermissionsList = SharedImagePermissions[];
export declare const SharedImagePermissionsList: any;
export interface DescribeImagePermissionsResult {
    Name?: string;
    SharedImagePermissionsList?: (SharedImagePermissions & {
        sharedAccountId: AwsAccountId;
        imagePermissions: ImagePermissions;
    })[];
    NextToken?: string;
}
export declare const DescribeImagePermissionsResult: S.Schema<DescribeImagePermissionsResult>;
export type DescribeImagesMaxResults = number;
export interface DescribeImagesRequest {
    Names?: string[];
    Arns?: string[];
    Type?: VisibilityType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeImagesRequest: S.Schema<DescribeImagesRequest>;
export type ImageList = Image[];
export declare const ImageList: any;
export interface DescribeImagesResult {
    Images?: (Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeImagesResult: S.Schema<DescribeImagesResult>;
export type UserId = string;
export interface DescribeSessionsRequest {
    StackName?: string;
    FleetName?: string;
    UserId?: string;
    NextToken?: string;
    Limit?: number;
    AuthenticationType?: AuthenticationType;
    InstanceId?: string;
}
export declare const DescribeSessionsRequest: S.Schema<DescribeSessionsRequest>;
export type SessionState = "ACTIVE" | "PENDING" | "EXPIRED" | (string & {});
export declare const SessionState: any;
export type SessionConnectionState = "CONNECTED" | "NOT_CONNECTED" | (string & {});
export declare const SessionConnectionState: any;
export type InstanceDrainStatus = "ACTIVE" | "DRAINING" | "NOT_APPLICABLE" | (string & {});
export declare const InstanceDrainStatus: any;
export interface Session {
    Id?: string;
    UserId?: string;
    StackName?: string;
    FleetName?: string;
    State?: SessionState;
    ConnectionState?: SessionConnectionState;
    StartTime?: Date;
    MaxExpirationTime?: Date;
    AuthenticationType?: AuthenticationType;
    NetworkAccessConfiguration?: NetworkAccessConfiguration;
    InstanceId?: string;
    InstanceDrainStatus?: InstanceDrainStatus;
}
export declare const Session: S.Schema<Session>;
export type SessionList = Session[];
export declare const SessionList: any;
export interface DescribeSessionsResult {
    Sessions?: (Session & {
        Id: string;
        UserId: UserId;
        StackName: string;
        FleetName: string;
        State: SessionState;
    })[];
    NextToken?: string;
}
export declare const DescribeSessionsResult: S.Schema<DescribeSessionsResult>;
export interface DescribeSoftwareAssociationsRequest {
    AssociatedResource?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeSoftwareAssociationsRequest: S.Schema<DescribeSoftwareAssociationsRequest>;
export type SoftwareDeploymentStatus = "STAGED_FOR_INSTALLATION" | "PENDING_INSTALLATION" | "INSTALLED" | "STAGED_FOR_UNINSTALLATION" | "PENDING_UNINSTALLATION" | "FAILED_TO_INSTALL" | "FAILED_TO_UNINSTALL" | (string & {});
export declare const SoftwareDeploymentStatus: any;
export interface SoftwareAssociations {
    SoftwareName?: string;
    Status?: SoftwareDeploymentStatus;
    DeploymentError?: ErrorDetails[];
}
export declare const SoftwareAssociations: S.Schema<SoftwareAssociations>;
export type SoftwareAssociationsList = SoftwareAssociations[];
export declare const SoftwareAssociationsList: any;
export interface DescribeSoftwareAssociationsResult {
    AssociatedResource?: string;
    SoftwareAssociations?: SoftwareAssociations[];
    NextToken?: string;
}
export declare const DescribeSoftwareAssociationsResult: S.Schema<DescribeSoftwareAssociationsResult>;
export interface DescribeStacksRequest {
    Names?: string[];
    NextToken?: string;
}
export declare const DescribeStacksRequest: S.Schema<DescribeStacksRequest>;
export type StackList = Stack[];
export declare const StackList: any;
export interface DescribeStacksResult {
    Stacks?: (Stack & {
        Name: string;
        StorageConnectors: (StorageConnector & {
            ConnectorType: StorageConnectorType;
        })[];
        UserSettings: (UserSetting & {
            Action: Action;
            Permission: Permission;
        })[];
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        ContentRedirection: ContentRedirection & {
            HostToClient: UrlRedirectionConfig & {
                Enabled: boolean;
            };
        };
        AgentAccessConfig: AgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeStacksResult: S.Schema<DescribeStacksResult>;
export interface DescribeThemeForStackRequest {
    StackName?: string;
}
export declare const DescribeThemeForStackRequest: S.Schema<DescribeThemeForStackRequest>;
export interface DescribeThemeForStackResult {
    Theme?: Theme;
}
export declare const DescribeThemeForStackResult: S.Schema<DescribeThemeForStackResult>;
export interface DescribeUsageReportSubscriptionsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeUsageReportSubscriptionsRequest: S.Schema<DescribeUsageReportSubscriptionsRequest>;
export type UsageReportExecutionErrorCode = "RESOURCE_NOT_FOUND" | "ACCESS_DENIED" | "INTERNAL_SERVICE_ERROR" | (string & {});
export declare const UsageReportExecutionErrorCode: any;
export interface LastReportGenerationExecutionError {
    ErrorCode?: UsageReportExecutionErrorCode;
    ErrorMessage?: string;
}
export declare const LastReportGenerationExecutionError: S.Schema<LastReportGenerationExecutionError>;
export type LastReportGenerationExecutionErrors = LastReportGenerationExecutionError[];
export declare const LastReportGenerationExecutionErrors: any;
export interface UsageReportSubscription {
    S3BucketName?: string;
    Schedule?: UsageReportSchedule;
    LastGeneratedReportDate?: Date;
    SubscriptionErrors?: LastReportGenerationExecutionError[];
}
export declare const UsageReportSubscription: S.Schema<UsageReportSubscription>;
export type UsageReportSubscriptionList = UsageReportSubscription[];
export declare const UsageReportSubscriptionList: any;
export interface DescribeUsageReportSubscriptionsResult {
    UsageReportSubscriptions?: UsageReportSubscription[];
    NextToken?: string;
}
export declare const DescribeUsageReportSubscriptionsResult: S.Schema<DescribeUsageReportSubscriptionsResult>;
export interface DescribeUsersRequest {
    AuthenticationType?: AuthenticationType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeUsersRequest: S.Schema<DescribeUsersRequest>;
export interface User {
    Arn?: string;
    UserName?: string | redacted.Redacted<string>;
    Enabled?: boolean;
    Status?: string;
    FirstName?: string | redacted.Redacted<string>;
    LastName?: string | redacted.Redacted<string>;
    CreatedTime?: Date;
    AuthenticationType?: AuthenticationType;
}
export declare const User: S.Schema<User>;
export type UserList = User[];
export declare const UserList: any;
export interface DescribeUsersResult {
    Users?: (User & {
        AuthenticationType: AuthenticationType;
    })[];
    NextToken?: string;
}
export declare const DescribeUsersResult: S.Schema<DescribeUsersResult>;
export interface DescribeUserStackAssociationsRequest {
    StackName?: string;
    UserName?: string | redacted.Redacted<string>;
    AuthenticationType?: AuthenticationType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeUserStackAssociationsRequest: S.Schema<DescribeUserStackAssociationsRequest>;
export interface DescribeUserStackAssociationsResult {
    UserStackAssociations?: (UserStackAssociation & {
        StackName: string;
        UserName: Username;
        AuthenticationType: AuthenticationType;
    })[];
    NextToken?: string;
}
export declare const DescribeUserStackAssociationsResult: S.Schema<DescribeUserStackAssociationsResult>;
export interface DisableUserRequest {
    UserName?: string | redacted.Redacted<string>;
    AuthenticationType?: AuthenticationType;
}
export declare const DisableUserRequest: S.Schema<DisableUserRequest>;
export interface DisableUserResult {
}
export declare const DisableUserResult: S.Schema<DisableUserResult>;
export interface DisassociateAppBlockBuilderAppBlockRequest {
    AppBlockArn?: string;
    AppBlockBuilderName?: string;
}
export declare const DisassociateAppBlockBuilderAppBlockRequest: S.Schema<DisassociateAppBlockBuilderAppBlockRequest>;
export interface DisassociateAppBlockBuilderAppBlockResult {
}
export declare const DisassociateAppBlockBuilderAppBlockResult: S.Schema<DisassociateAppBlockBuilderAppBlockResult>;
export interface DisassociateApplicationFleetRequest {
    FleetName?: string;
    ApplicationArn?: string;
}
export declare const DisassociateApplicationFleetRequest: S.Schema<DisassociateApplicationFleetRequest>;
export interface DisassociateApplicationFleetResult {
}
export declare const DisassociateApplicationFleetResult: S.Schema<DisassociateApplicationFleetResult>;
export interface DisassociateApplicationFromEntitlementRequest {
    StackName?: string;
    EntitlementName?: string;
    ApplicationIdentifier?: string;
}
export declare const DisassociateApplicationFromEntitlementRequest: S.Schema<DisassociateApplicationFromEntitlementRequest>;
export interface DisassociateApplicationFromEntitlementResult {
}
export declare const DisassociateApplicationFromEntitlementResult: S.Schema<DisassociateApplicationFromEntitlementResult>;
export interface DisassociateFleetRequest {
    FleetName?: string;
    StackName?: string;
}
export declare const DisassociateFleetRequest: S.Schema<DisassociateFleetRequest>;
export interface DisassociateFleetResult {
}
export declare const DisassociateFleetResult: S.Schema<DisassociateFleetResult>;
export interface DisassociateSoftwareFromImageBuilderRequest {
    ImageBuilderName?: string;
    SoftwareNames?: string[];
}
export declare const DisassociateSoftwareFromImageBuilderRequest: S.Schema<DisassociateSoftwareFromImageBuilderRequest>;
export interface DisassociateSoftwareFromImageBuilderResult {
}
export declare const DisassociateSoftwareFromImageBuilderResult: S.Schema<DisassociateSoftwareFromImageBuilderResult>;
export interface DrainSessionInstanceRequest {
    SessionId?: string;
}
export declare const DrainSessionInstanceRequest: S.Schema<DrainSessionInstanceRequest>;
export interface DrainSessionInstanceResult {
}
export declare const DrainSessionInstanceResult: S.Schema<DrainSessionInstanceResult>;
export interface EnableUserRequest {
    UserName?: string | redacted.Redacted<string>;
    AuthenticationType?: AuthenticationType;
}
export declare const EnableUserRequest: S.Schema<EnableUserRequest>;
export interface EnableUserResult {
}
export declare const EnableUserResult: S.Schema<EnableUserResult>;
export interface ExpireSessionRequest {
    SessionId?: string;
}
export declare const ExpireSessionRequest: S.Schema<ExpireSessionRequest>;
export interface ExpireSessionResult {
}
export declare const ExpireSessionResult: S.Schema<ExpireSessionResult>;
export interface GetExportImageTaskRequest {
    TaskId?: string;
}
export declare const GetExportImageTaskRequest: S.Schema<GetExportImageTaskRequest>;
export interface GetExportImageTaskResult {
    ExportImageTask?: ExportImageTask & {
        TaskId: UUID;
        ImageArn: Arn;
        AmiName: AmiName;
        CreatedDate: Date;
    };
}
export declare const GetExportImageTaskResult: S.Schema<GetExportImageTaskResult>;
export interface ListAssociatedFleetsRequest {
    StackName?: string;
    NextToken?: string;
}
export declare const ListAssociatedFleetsRequest: S.Schema<ListAssociatedFleetsRequest>;
export interface ListAssociatedFleetsResult {
    Names?: string[];
    NextToken?: string;
}
export declare const ListAssociatedFleetsResult: S.Schema<ListAssociatedFleetsResult>;
export interface ListAssociatedStacksRequest {
    FleetName?: string;
    NextToken?: string;
}
export declare const ListAssociatedStacksRequest: S.Schema<ListAssociatedStacksRequest>;
export interface ListAssociatedStacksResult {
    Names?: string[];
    NextToken?: string;
}
export declare const ListAssociatedStacksResult: S.Schema<ListAssociatedStacksResult>;
export interface ListEntitledApplicationsRequest {
    StackName?: string;
    EntitlementName?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEntitledApplicationsRequest: S.Schema<ListEntitledApplicationsRequest>;
export interface EntitledApplication {
    ApplicationIdentifier?: string;
}
export declare const EntitledApplication: S.Schema<EntitledApplication>;
export type EntitledApplicationList = EntitledApplication[];
export declare const EntitledApplicationList: any;
export interface ListEntitledApplicationsResult {
    EntitledApplications?: (EntitledApplication & {
        ApplicationIdentifier: string;
    })[];
    NextToken?: string;
}
export declare const ListEntitledApplicationsResult: S.Schema<ListEntitledApplicationsResult>;
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export interface Filter {
    Name?: string;
    Values?: string[];
}
export declare const Filter: S.Schema<Filter>;
export type Filters = Filter[];
export declare const Filters: any;
export interface ListExportImageTasksRequest {
    Filters?: Filter[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExportImageTasksRequest: S.Schema<ListExportImageTasksRequest>;
export type ExportImageTasks = ExportImageTask[];
export declare const ExportImageTasks: any;
export interface ListExportImageTasksResult {
    ExportImageTasks?: (ExportImageTask & {
        TaskId: UUID;
        ImageArn: Arn;
        AmiName: AmiName;
        CreatedDate: Date;
    })[];
    NextToken?: string;
}
export declare const ListExportImageTasksResult: S.Schema<ListExportImageTasksResult>;
export interface ListTagsForResourceRequest {
    ResourceArn?: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface StartAppBlockBuilderRequest {
    Name?: string;
}
export declare const StartAppBlockBuilderRequest: S.Schema<StartAppBlockBuilderRequest>;
export interface StartAppBlockBuilderResult {
    AppBlockBuilder?: AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const StartAppBlockBuilderResult: S.Schema<StartAppBlockBuilderResult>;
export interface StartFleetRequest {
    Name?: string;
}
export declare const StartFleetRequest: S.Schema<StartFleetRequest>;
export interface StartFleetResult {
}
export declare const StartFleetResult: S.Schema<StartFleetResult>;
export interface StartImageBuilderRequest {
    Name?: string;
    AppstreamAgentVersion?: string;
}
export declare const StartImageBuilderRequest: S.Schema<StartImageBuilderRequest>;
export interface StartImageBuilderResult {
    ImageBuilder?: ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const StartImageBuilderResult: S.Schema<StartImageBuilderResult>;
export interface StartSoftwareDeploymentToImageBuilderRequest {
    ImageBuilderName?: string;
    RetryFailedDeployments?: boolean;
}
export declare const StartSoftwareDeploymentToImageBuilderRequest: S.Schema<StartSoftwareDeploymentToImageBuilderRequest>;
export interface StartSoftwareDeploymentToImageBuilderResult {
}
export declare const StartSoftwareDeploymentToImageBuilderResult: S.Schema<StartSoftwareDeploymentToImageBuilderResult>;
export interface StopAppBlockBuilderRequest {
    Name?: string;
}
export declare const StopAppBlockBuilderRequest: S.Schema<StopAppBlockBuilderRequest>;
export interface StopAppBlockBuilderResult {
    AppBlockBuilder?: AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const StopAppBlockBuilderResult: S.Schema<StopAppBlockBuilderResult>;
export interface StopFleetRequest {
    Name?: string;
}
export declare const StopFleetRequest: S.Schema<StopFleetRequest>;
export interface StopFleetResult {
}
export declare const StopFleetResult: S.Schema<StopFleetResult>;
export interface StopImageBuilderRequest {
    Name?: string;
}
export declare const StopImageBuilderRequest: S.Schema<StopImageBuilderRequest>;
export interface StopImageBuilderResult {
    ImageBuilder?: ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const StopImageBuilderResult: S.Schema<StopImageBuilderResult>;
export interface TagResourceRequest {
    ResourceArn?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn?: string;
    TagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export type AppBlockBuilderAttribute = "IAM_ROLE_ARN" | "ACCESS_ENDPOINTS" | "VPC_CONFIGURATION_SECURITY_GROUP_IDS" | (string & {});
export declare const AppBlockBuilderAttribute: any;
export type AppBlockBuilderAttributes = AppBlockBuilderAttribute[];
export declare const AppBlockBuilderAttributes: any;
export interface UpdateAppBlockBuilderRequest {
    Name?: string;
    Description?: string;
    DisplayName?: string;
    Platform?: PlatformType;
    InstanceType?: string;
    VpcConfig?: VpcConfig;
    EnableDefaultInternetAccess?: boolean;
    IamRoleArn?: string;
    AccessEndpoints?: AccessEndpoint[];
    AttributesToDelete?: AppBlockBuilderAttribute[];
    DisableIMDSV1?: boolean;
}
export declare const UpdateAppBlockBuilderRequest: S.Schema<UpdateAppBlockBuilderRequest>;
export interface UpdateAppBlockBuilderResult {
    AppBlockBuilder?: AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    };
}
export declare const UpdateAppBlockBuilderResult: S.Schema<UpdateAppBlockBuilderResult>;
export type ApplicationAttribute = "LAUNCH_PARAMETERS" | "WORKING_DIRECTORY" | (string & {});
export declare const ApplicationAttribute: any;
export type ApplicationAttributes = ApplicationAttribute[];
export declare const ApplicationAttributes: any;
export interface UpdateApplicationRequest {
    Name?: string;
    DisplayName?: string;
    Description?: string;
    IconS3Location?: S3Location;
    LaunchPath?: string;
    WorkingDirectory?: string;
    LaunchParameters?: string;
    AppBlockArn?: string;
    AttributesToDelete?: ApplicationAttribute[];
}
export declare const UpdateApplicationRequest: S.Schema<UpdateApplicationRequest>;
export interface UpdateApplicationResult {
    Application?: Application & {
        IconS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    };
}
export declare const UpdateApplicationResult: S.Schema<UpdateApplicationResult>;
export interface UpdateDirectoryConfigRequest {
    DirectoryName?: string;
    OrganizationalUnitDistinguishedNames?: string[];
    ServiceAccountCredentials?: ServiceAccountCredentials;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties;
}
export declare const UpdateDirectoryConfigRequest: S.Schema<UpdateDirectoryConfigRequest>;
export interface UpdateDirectoryConfigResult {
    DirectoryConfig?: DirectoryConfig & {
        DirectoryName: DirectoryName;
        ServiceAccountCredentials: ServiceAccountCredentials & {
            AccountName: AccountName;
            AccountPassword: AccountPassword;
        };
    };
}
export declare const UpdateDirectoryConfigResult: S.Schema<UpdateDirectoryConfigResult>;
export interface UpdateEntitlementRequest {
    Name?: string;
    StackName?: string;
    Description?: string;
    AppVisibility?: AppVisibility;
    Attributes?: EntitlementAttribute[];
}
export declare const UpdateEntitlementRequest: S.Schema<UpdateEntitlementRequest>;
export interface UpdateEntitlementResult {
    Entitlement?: Entitlement & {
        Name: Name;
        StackName: Name;
        AppVisibility: AppVisibility;
        Attributes: (EntitlementAttribute & {
            Name: string;
            Value: string;
        })[];
    };
}
export declare const UpdateEntitlementResult: S.Schema<UpdateEntitlementResult>;
export type FleetAttribute = "VPC_CONFIGURATION" | "VPC_CONFIGURATION_SECURITY_GROUP_IDS" | "DOMAIN_JOIN_INFO" | "IAM_ROLE_ARN" | "USB_DEVICE_FILTER_STRINGS" | "SESSION_SCRIPT_S3_LOCATION" | "MAX_SESSIONS_PER_INSTANCE" | "VOLUME_CONFIGURATION" | (string & {});
export declare const FleetAttribute: any;
export type FleetAttributes = FleetAttribute[];
export declare const FleetAttributes: any;
export interface UpdateFleetRequest {
    ImageName?: string;
    ImageArn?: string;
    Name?: string;
    InstanceType?: string;
    ComputeCapacity?: ComputeCapacity;
    VpcConfig?: VpcConfig;
    MaxUserDurationInSeconds?: number;
    DisconnectTimeoutInSeconds?: number;
    DeleteVpcConfig?: boolean;
    Description?: string;
    DisplayName?: string;
    EnableDefaultInternetAccess?: boolean;
    DomainJoinInfo?: DomainJoinInfo;
    IdleDisconnectTimeoutInSeconds?: number;
    AttributesToDelete?: FleetAttribute[];
    IamRoleArn?: string;
    StreamView?: StreamView;
    Platform?: PlatformType;
    MaxConcurrentSessions?: number;
    UsbDeviceFilterStrings?: string[];
    SessionScriptS3Location?: S3Location;
    MaxSessionsPerInstance?: number;
    RootVolumeConfig?: VolumeConfig;
    DisableIMDSV1?: boolean;
}
export declare const UpdateFleetRequest: S.Schema<UpdateFleetRequest>;
export interface UpdateFleetResult {
    Fleet?: Fleet & {
        Arn: Arn;
        Name: string;
        InstanceType: string;
        ComputeCapacityStatus: ComputeCapacityStatus & {
            Desired: number;
        };
        State: FleetState;
        SessionScriptS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    };
}
export declare const UpdateFleetResult: S.Schema<UpdateFleetResult>;
export interface UpdateImagePermissionsRequest {
    Name?: string;
    SharedAccountId?: string;
    ImagePermissions?: ImagePermissions;
}
export declare const UpdateImagePermissionsRequest: S.Schema<UpdateImagePermissionsRequest>;
export interface UpdateImagePermissionsResult {
}
export declare const UpdateImagePermissionsResult: S.Schema<UpdateImagePermissionsResult>;
export type StackAttribute = "STORAGE_CONNECTORS" | "STORAGE_CONNECTOR_HOMEFOLDERS" | "STORAGE_CONNECTOR_GOOGLE_DRIVE" | "STORAGE_CONNECTOR_ONE_DRIVE" | "REDIRECT_URL" | "FEEDBACK_URL" | "THEME_NAME" | "USER_SETTINGS" | "EMBED_HOST_DOMAINS" | "IAM_ROLE_ARN" | "ACCESS_ENDPOINTS" | "STREAMING_EXPERIENCE_SETTINGS" | "CONTENT_REDIRECTION" | "AGENT_ACCESS_CONFIG" | (string & {});
export declare const StackAttribute: any;
export type StackAttributes = StackAttribute[];
export declare const StackAttributes: any;
export interface AgentAccessConfigForUpdate {
    Settings?: AgentAccessSetting[];
    S3BucketArn?: string;
    ScreenshotsUploadEnabled?: boolean;
    ScreenResolution?: ScreenResolution;
    ScreenImageFormat?: ScreenImageFormat;
    UserControlMode?: UserControlMode;
}
export declare const AgentAccessConfigForUpdate: S.Schema<AgentAccessConfigForUpdate>;
export interface UpdateStackRequest {
    DisplayName?: string;
    Description?: string;
    Name?: string;
    StorageConnectors?: StorageConnector[];
    DeleteStorageConnectors?: boolean;
    RedirectURL?: string;
    FeedbackURL?: string;
    AttributesToDelete?: StackAttribute[];
    UserSettings?: UserSetting[];
    ApplicationSettings?: ApplicationSettings;
    AccessEndpoints?: AccessEndpoint[];
    EmbedHostDomains?: string[];
    StreamingExperienceSettings?: StreamingExperienceSettings;
    ContentRedirection?: ContentRedirection;
    AgentAccessConfig?: AgentAccessConfigForUpdate;
}
export declare const UpdateStackRequest: S.Schema<UpdateStackRequest>;
export interface UpdateStackResult {
    Stack?: Stack & {
        Name: string;
        StorageConnectors: (StorageConnector & {
            ConnectorType: StorageConnectorType;
        })[];
        UserSettings: (UserSetting & {
            Action: Action;
            Permission: Permission;
        })[];
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        ContentRedirection: ContentRedirection & {
            HostToClient: UrlRedirectionConfig & {
                Enabled: boolean;
            };
        };
        AgentAccessConfig: AgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    };
}
export declare const UpdateStackResult: S.Schema<UpdateStackResult>;
export type ThemeAttribute = "FOOTER_LINKS" | (string & {});
export declare const ThemeAttribute: any;
export type ThemeAttributes = ThemeAttribute[];
export declare const ThemeAttributes: any;
export interface UpdateThemeForStackRequest {
    StackName?: string;
    FooterLinks?: ThemeFooterLink[];
    TitleText?: string;
    ThemeStyling?: ThemeStyling;
    OrganizationLogoS3Location?: S3Location;
    FaviconS3Location?: S3Location;
    State?: ThemeState;
    AttributesToDelete?: ThemeAttribute[];
}
export declare const UpdateThemeForStackRequest: S.Schema<UpdateThemeForStackRequest>;
export interface UpdateThemeForStackResult {
    Theme?: Theme;
}
export declare const UpdateThemeForStackResult: S.Schema<UpdateThemeForStackResult>;
export type ErrorMessage = string;
export type AssociateAppBlockBuilderAppBlockError = ConcurrentModificationException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified app block builder with the specified app block.
 */
export declare const associateAppBlockBuilderAppBlock: API.OperationMethod<AssociateAppBlockBuilderAppBlockRequest, AssociateAppBlockBuilderAppBlockResult, AssociateAppBlockBuilderAppBlockError, Credentials | HttpClient.HttpClient>;
export type AssociateApplicationFleetError = ConcurrentModificationException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified application with the specified fleet. This is only supported for Elastic fleets.
 */
export declare const associateApplicationFleet: API.OperationMethod<AssociateApplicationFleetRequest, AssociateApplicationFleetResult, AssociateApplicationFleetError, Credentials | HttpClient.HttpClient>;
export type AssociateApplicationToEntitlementError = EntitlementNotFoundException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates an application to entitle.
 */
export declare const associateApplicationToEntitlement: API.OperationMethod<AssociateApplicationToEntitlementRequest, AssociateApplicationToEntitlementResult, AssociateApplicationToEntitlementError, Credentials | HttpClient.HttpClient>;
export type AssociateFleetError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified fleet with the specified stack.
 */
export declare const associateFleet: API.OperationMethod<AssociateFleetRequest, AssociateFleetResult, AssociateFleetError, Credentials | HttpClient.HttpClient>;
export type AssociateSoftwareToImageBuilderError = ConcurrentModificationException | IncompatibleImageException | InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates license included application(s) with an existing image builder instance.
 */
export declare const associateSoftwareToImageBuilder: API.OperationMethod<AssociateSoftwareToImageBuilderRequest, AssociateSoftwareToImageBuilderResult, AssociateSoftwareToImageBuilderError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateUserStackError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Associates the specified users with the specified stacks. Users in a user pool cannot be assigned to stacks with fleets that are joined to an Active Directory domain.
 */
export declare const batchAssociateUserStack: API.OperationMethod<BatchAssociateUserStackRequest, BatchAssociateUserStackResult, BatchAssociateUserStackError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateUserStackError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Disassociates the specified users from the specified stacks.
 */
export declare const batchDisassociateUserStack: API.OperationMethod<BatchDisassociateUserStackRequest, BatchDisassociateUserStackResult, BatchDisassociateUserStackError, Credentials | HttpClient.HttpClient>;
export type CopyImageError = IncompatibleImageException | InvalidAccountStatusException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Copies the image within the same region or to a new region within the same AWS account. Note that any tags you added to the image will not be copied.
 */
export declare const copyImage: API.OperationMethod<CopyImageRequest, CopyImageResponse, CopyImageError, Credentials | HttpClient.HttpClient>;
export type CreateAppBlockError = ConcurrentModificationException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates an app block.
 *
 * App blocks are a WorkSpaces Applications resource that stores the details about the
 * virtual hard disk in an S3 bucket. It also stores the setup script with details about
 * how to mount the virtual hard disk. The virtual hard disk includes the application
 * binaries and other files necessary to launch your applications. Multiple applications
 * can be assigned to a single app block.
 *
 * This is only supported for Elastic fleets.
 */
export declare const createAppBlock: API.OperationMethod<CreateAppBlockRequest, CreateAppBlockResult, CreateAppBlockError, Credentials | HttpClient.HttpClient>;
export type CreateAppBlockBuilderError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an app block builder.
 */
export declare const createAppBlockBuilder: API.OperationMethod<CreateAppBlockBuilderRequest, CreateAppBlockBuilderResult, CreateAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type CreateAppBlockBuilderStreamingURLError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a URL to start a create app block builder streaming session.
 */
export declare const createAppBlockBuilderStreamingURL: API.OperationMethod<CreateAppBlockBuilderStreamingURLRequest, CreateAppBlockBuilderStreamingURLResult, CreateAppBlockBuilderStreamingURLError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ConcurrentModificationException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an application.
 *
 * Applications are a WorkSpaces Applications resource that stores the details about how to
 * launch applications on Elastic fleet streaming instances. An application consists of the
 * launch details, icon, and display name. Applications are associated with an app block
 * that contains the application binaries and other files. The applications assigned to an
 * Elastic fleet are the applications users can launch.
 *
 * This is only supported for Elastic fleets.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResult, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDirectoryConfigError = InvalidAccountStatusException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a Directory Config object in WorkSpaces Applications. This object includes the configuration information required to join fleets and image builders to Microsoft Active Directory domains.
 */
export declare const createDirectoryConfig: API.OperationMethod<CreateDirectoryConfigRequest, CreateDirectoryConfigResult, CreateDirectoryConfigError, Credentials | HttpClient.HttpClient>;
export type CreateEntitlementError = EntitlementAlreadyExistsException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new entitlement. Entitlements control access to specific applications within
 * a stack, based on user attributes. Entitlements apply to SAML 2.0 federated user
 * identities. WorkSpaces Applications user pool and streaming URL users are entitled to all
 * applications in a stack. Entitlements don't apply to the desktop stream view
 * application, or to applications managed by a dynamic app provider using the Dynamic
 * Application Framework.
 */
export declare const createEntitlement: API.OperationMethod<CreateEntitlementRequest, CreateEntitlementResult, CreateEntitlementError, Credentials | HttpClient.HttpClient>;
export type CreateExportImageTaskError = ConcurrentModificationException | InvalidAccountStatusException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a task to export a WorkSpaces Applications image to an EC2 AMI. This allows you to use your customized WorkSpaces Applications images with other AWS services or for backup purposes.
 */
export declare const createExportImageTask: API.OperationMethod<CreateExportImageTaskRequest, CreateExportImageTaskResult, CreateExportImageTaskError, Credentials | HttpClient.HttpClient>;
export type CreateFleetError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a fleet. A fleet consists of streaming instances that your users access for their applications and desktops.
 */
export declare const createFleet: API.OperationMethod<CreateFleetRequest, CreateFleetResult, CreateFleetError, Credentials | HttpClient.HttpClient>;
export type CreateImageBuilderError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an image builder. An image builder is a virtual machine that is used to create an image.
 *
 * The initial state of the builder is `PENDING`. When it is ready, the state is `RUNNING`.
 */
export declare const createImageBuilder: API.OperationMethod<CreateImageBuilderRequest, CreateImageBuilderResult, CreateImageBuilderError, Credentials | HttpClient.HttpClient>;
export type CreateImageBuilderStreamingURLError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a URL to start an image builder streaming session.
 */
export declare const createImageBuilderStreamingURL: API.OperationMethod<CreateImageBuilderStreamingURLRequest, CreateImageBuilderStreamingURLResult, CreateImageBuilderStreamingURLError, Credentials | HttpClient.HttpClient>;
export type CreateImportedImageError = DryRunOperationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a custom WorkSpaces Applications image by importing an EC2 AMI. This allows you to use your own customized AMI to create WorkSpaces Applications images that support additional instance types beyond the standard stream.* instances.
 */
export declare const createImportedImage: API.OperationMethod<CreateImportedImageRequest, CreateImportedImageResult, CreateImportedImageError, Credentials | HttpClient.HttpClient>;
export type CreateStackError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a stack to start streaming applications to users. A stack consists of an associated fleet, user access policies, and storage configurations.
 */
export declare const createStack: API.OperationMethod<CreateStackRequest, CreateStackResult, CreateStackError, Credentials | HttpClient.HttpClient>;
export type CreateStreamingURLError = InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a temporary URL to start an WorkSpaces Applications streaming session for the specified user. A streaming URL enables application streaming to be tested without user setup.
 */
export declare const createStreamingURL: API.OperationMethod<CreateStreamingURLRequest, CreateStreamingURLResult, CreateStreamingURLError, Credentials | HttpClient.HttpClient>;
export type CreateThemeForStackError = ConcurrentModificationException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const createThemeForStack: API.OperationMethod<CreateThemeForStackRequest, CreateThemeForStackResult, CreateThemeForStackError, Credentials | HttpClient.HttpClient>;
export type CreateUpdatedImageError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new image with the latest Windows operating system updates, driver updates, and WorkSpaces Applications agent software.
 *
 * For more information, see the "Update an Image by Using
 * Managed WorkSpaces Applications Image Updates" section in Administer Your WorkSpaces Applications Images, in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const createUpdatedImage: API.OperationMethod<CreateUpdatedImageRequest, CreateUpdatedImageResult, CreateUpdatedImageError, Credentials | HttpClient.HttpClient>;
export type CreateUsageReportSubscriptionError = InvalidAccountStatusException | InvalidRoleException | LimitExceededException | CommonErrors;
/**
 * Creates a usage report subscription. Usage reports are generated daily.
 */
export declare const createUsageReportSubscription: API.OperationMethod<CreateUsageReportSubscriptionRequest, CreateUsageReportSubscriptionResult, CreateUsageReportSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = InvalidAccountStatusException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a new user in the user pool.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResult, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteAppBlockError = ConcurrentModificationException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an app block.
 */
export declare const deleteAppBlock: API.OperationMethod<DeleteAppBlockRequest, DeleteAppBlockResult, DeleteAppBlockError, Credentials | HttpClient.HttpClient>;
export type DeleteAppBlockBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an app block builder.
 *
 * An app block builder can only be deleted when it has no association with an app
 * block.
 */
export declare const deleteAppBlockBuilder: API.OperationMethod<DeleteAppBlockBuilderRequest, DeleteAppBlockBuilderResult, DeleteAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResult, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectoryConfigError = ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified Directory Config object from WorkSpaces Applications. This object includes the information required to join streaming instances to an Active Directory domain.
 */
export declare const deleteDirectoryConfig: API.OperationMethod<DeleteDirectoryConfigRequest, DeleteDirectoryConfigResult, DeleteDirectoryConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteEntitlementError = ConcurrentModificationException | EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified entitlement.
 */
export declare const deleteEntitlement: API.OperationMethod<DeleteEntitlementRequest, DeleteEntitlementResult, DeleteEntitlementError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetError = ConcurrentModificationException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified fleet.
 */
export declare const deleteFleet: API.OperationMethod<DeleteFleetRequest, DeleteFleetResult, DeleteFleetError, Credentials | HttpClient.HttpClient>;
export type DeleteImageError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified image. You cannot delete an image when it is in use.
 * After you delete an image, you cannot provision new capacity using the image.
 */
export declare const deleteImage: API.OperationMethod<DeleteImageRequest, DeleteImageResult, DeleteImageError, Credentials | HttpClient.HttpClient>;
export type DeleteImageBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified image builder and releases the capacity.
 */
export declare const deleteImageBuilder: API.OperationMethod<DeleteImageBuilderRequest, DeleteImageBuilderResult, DeleteImageBuilderError, Credentials | HttpClient.HttpClient>;
export type DeleteImagePermissionsError = ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes permissions for the specified private image. After you delete permissions for an image, AWS accounts to which you previously granted these permissions can no longer use the image.
 */
export declare const deleteImagePermissions: API.OperationMethod<DeleteImagePermissionsRequest, DeleteImagePermissionsResult, DeleteImagePermissionsError, Credentials | HttpClient.HttpClient>;
export type DeleteStackError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified stack. After the stack is deleted, the application streaming environment provided by the stack is no longer available to users. Also, any reservations made for application streaming sessions for the stack are released.
 */
export declare const deleteStack: API.OperationMethod<DeleteStackRequest, DeleteStackResult, DeleteStackError, Credentials | HttpClient.HttpClient>;
export type DeleteThemeForStackError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const deleteThemeForStack: API.OperationMethod<DeleteThemeForStackRequest, DeleteThemeForStackResult, DeleteThemeForStackError, Credentials | HttpClient.HttpClient>;
export type DeleteUsageReportSubscriptionError = InvalidAccountStatusException | ResourceNotFoundException | CommonErrors;
/**
 * Disables usage report generation.
 */
export declare const deleteUsageReportSubscription: API.OperationMethod<DeleteUsageReportSubscriptionRequest, DeleteUsageReportSubscriptionResult, DeleteUsageReportSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ResourceNotFoundException | CommonErrors;
/**
 * Deletes a user from the user pool.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResult, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeAppBlockBuilderAppBlockAssociationsError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Retrieves a list that describes one or more app block builder associations.
 */
export declare const describeAppBlockBuilderAppBlockAssociations: API.PaginatedOperationMethod<DescribeAppBlockBuilderAppBlockAssociationsRequest, DescribeAppBlockBuilderAppBlockAssociationsResult, DescribeAppBlockBuilderAppBlockAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeAppBlockBuildersError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more app block builders.
 */
export declare const describeAppBlockBuilders: API.PaginatedOperationMethod<DescribeAppBlockBuildersRequest, DescribeAppBlockBuildersResult, DescribeAppBlockBuildersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeAppBlocksError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more app blocks.
 */
export declare const describeAppBlocks: API.OperationMethod<DescribeAppBlocksRequest, DescribeAppBlocksResult, DescribeAppBlocksError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationFleetAssociationsError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Retrieves a list that describes one or more application fleet associations. Either ApplicationArn or FleetName must be specified.
 */
export declare const describeApplicationFleetAssociations: API.OperationMethod<DescribeApplicationFleetAssociationsRequest, DescribeApplicationFleetAssociationsResult, DescribeApplicationFleetAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationsError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more applications.
 */
export declare const describeApplications: API.OperationMethod<DescribeApplicationsRequest, DescribeApplicationsResult, DescribeApplicationsError, Credentials | HttpClient.HttpClient>;
export type DescribeAppLicenseUsageError = InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves license included application usage information.
 */
export declare const describeAppLicenseUsage: API.OperationMethod<DescribeAppLicenseUsageRequest, DescribeAppLicenseUsageResult, DescribeAppLicenseUsageError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectoryConfigsError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified Directory Config objects for WorkSpaces Applications, if the names for these objects are provided. Otherwise, all Directory Config objects in the account are described. These objects include the configuration information required to join fleets and image builders to Microsoft Active Directory domains.
 *
 * Although the response syntax in this topic includes the account password, this password is not returned in the actual response.
 */
export declare const describeDirectoryConfigs: API.OperationMethod<DescribeDirectoryConfigsRequest, DescribeDirectoryConfigsResult, DescribeDirectoryConfigsError, Credentials | HttpClient.HttpClient>;
export type DescribeEntitlementsError = EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one of more entitlements.
 */
export declare const describeEntitlements: API.OperationMethod<DescribeEntitlementsRequest, DescribeEntitlementsResult, DescribeEntitlementsError, Credentials | HttpClient.HttpClient>;
export type DescribeFleetsError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified fleets, if the fleet names are provided. Otherwise, all fleets in the account are described.
 */
export declare const describeFleets: API.OperationMethod<DescribeFleetsRequest, DescribeFleetsResult, DescribeFleetsError, Credentials | HttpClient.HttpClient>;
export type DescribeImageBuildersError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified image builders, if the image builder names are provided. Otherwise, all image builders in the account are described.
 */
export declare const describeImageBuilders: API.OperationMethod<DescribeImageBuildersRequest, DescribeImageBuildersResult, DescribeImageBuildersError, Credentials | HttpClient.HttpClient>;
export type DescribeImagePermissionsError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes the permissions for shared AWS account IDs on a private image that you own.
 */
export declare const describeImagePermissions: API.PaginatedOperationMethod<DescribeImagePermissionsRequest, DescribeImagePermissionsResult, DescribeImagePermissionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeImagesError = InvalidParameterCombinationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified images, if the image names or image ARNs are provided. Otherwise, all images in the account are described.
 */
export declare const describeImages: API.PaginatedOperationMethod<DescribeImagesRequest, DescribeImagesResult, DescribeImagesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeSessionsError = InvalidParameterCombinationException | CommonErrors;
/**
 * Retrieves a list that describes the streaming sessions for a specified stack and fleet. If a UserId is provided for the stack and fleet,
 * only streaming sessions for that user are described. If an authentication type is not provided,
 * the default is to authenticate users using a streaming URL.
 */
export declare const describeSessions: API.OperationMethod<DescribeSessionsRequest, DescribeSessionsResult, DescribeSessionsError, Credentials | HttpClient.HttpClient>;
export type DescribeSoftwareAssociationsError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves license included application associations for a specified resource.
 */
export declare const describeSoftwareAssociations: API.OperationMethod<DescribeSoftwareAssociationsRequest, DescribeSoftwareAssociationsResult, DescribeSoftwareAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeStacksError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified stacks, if the stack names are provided. Otherwise, all stacks in the account are described.
 */
export declare const describeStacks: API.OperationMethod<DescribeStacksRequest, DescribeStacksResult, DescribeStacksError, Credentials | HttpClient.HttpClient>;
export type DescribeThemeForStackError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes the theme for a specified stack. A theme is custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const describeThemeForStack: API.OperationMethod<DescribeThemeForStackRequest, DescribeThemeForStackResult, DescribeThemeForStackError, Credentials | HttpClient.HttpClient>;
export type DescribeUsageReportSubscriptionsError = InvalidAccountStatusException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more usage report subscriptions.
 */
export declare const describeUsageReportSubscriptions: API.OperationMethod<DescribeUsageReportSubscriptionsRequest, DescribeUsageReportSubscriptionsResult, DescribeUsageReportSubscriptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeUsersError = InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified users in the user pool.
 */
export declare const describeUsers: API.OperationMethod<DescribeUsersRequest, DescribeUsersResult, DescribeUsersError, Credentials | HttpClient.HttpClient>;
export type DescribeUserStackAssociationsError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Retrieves a list that describes the UserStackAssociation objects. You must specify either or both of the following:
 *
 * - The stack name
 *
 * - The user name (email address of the user associated with the stack) and the authentication type for the user
 */
export declare const describeUserStackAssociations: API.OperationMethod<DescribeUserStackAssociationsRequest, DescribeUserStackAssociationsResult, DescribeUserStackAssociationsError, Credentials | HttpClient.HttpClient>;
export type DisableUserError = ResourceNotFoundException | CommonErrors;
/**
 * Disables the specified user in the user pool. Users can't sign in to WorkSpaces Applications until they are re-enabled. This action does not delete the user.
 */
export declare const disableUser: API.OperationMethod<DisableUserRequest, DisableUserResult, DisableUserError, Credentials | HttpClient.HttpClient>;
export type DisassociateAppBlockBuilderAppBlockError = ConcurrentModificationException | InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a specified app block builder from a specified app block.
 */
export declare const disassociateAppBlockBuilderAppBlock: API.OperationMethod<DisassociateAppBlockBuilderAppBlockRequest, DisassociateAppBlockBuilderAppBlockResult, DisassociateAppBlockBuilderAppBlockError, Credentials | HttpClient.HttpClient>;
export type DisassociateApplicationFleetError = ConcurrentModificationException | InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Disassociates the specified application from the fleet.
 */
export declare const disassociateApplicationFleet: API.OperationMethod<DisassociateApplicationFleetRequest, DisassociateApplicationFleetResult, DisassociateApplicationFleetError, Credentials | HttpClient.HttpClient>;
export type DisassociateApplicationFromEntitlementError = EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified application from the specified entitlement.
 */
export declare const disassociateApplicationFromEntitlement: API.OperationMethod<DisassociateApplicationFromEntitlementRequest, DisassociateApplicationFromEntitlementResult, DisassociateApplicationFromEntitlementError, Credentials | HttpClient.HttpClient>;
export type DisassociateFleetError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified fleet from the specified stack.
 */
export declare const disassociateFleet: API.OperationMethod<DisassociateFleetRequest, DisassociateFleetResult, DisassociateFleetError, Credentials | HttpClient.HttpClient>;
export type DisassociateSoftwareFromImageBuilderError = ConcurrentModificationException | InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Removes license included application(s) association(s) from an image builder instance.
 */
export declare const disassociateSoftwareFromImageBuilder: API.OperationMethod<DisassociateSoftwareFromImageBuilderRequest, DisassociateSoftwareFromImageBuilderResult, DisassociateSoftwareFromImageBuilderError, Credentials | HttpClient.HttpClient>;
export type DrainSessionInstanceError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Drains the instance hosting the specified streaming session. The instance stops accepting new sessions while existing sessions continue uninterrupted. Once all sessions end, the instance is reclaimed and replaced. This only applies to multi-session fleets.
 */
export declare const drainSessionInstance: API.OperationMethod<DrainSessionInstanceRequest, DrainSessionInstanceResult, DrainSessionInstanceError, Credentials | HttpClient.HttpClient>;
export type EnableUserError = InvalidAccountStatusException | ResourceNotFoundException | CommonErrors;
/**
 * Enables a user in the user pool. After being enabled, users can sign in to WorkSpaces Applications and open applications from the stacks to which they are assigned.
 */
export declare const enableUser: API.OperationMethod<EnableUserRequest, EnableUserResult, EnableUserError, Credentials | HttpClient.HttpClient>;
export type ExpireSessionError = CommonErrors;
/**
 * Immediately stops the specified streaming session.
 */
export declare const expireSession: API.OperationMethod<ExpireSessionRequest, ExpireSessionResult, ExpireSessionError, Credentials | HttpClient.HttpClient>;
export type GetExportImageTaskError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an export image task, including its current state, progress, and any error details.
 */
export declare const getExportImageTask: API.OperationMethod<GetExportImageTaskRequest, GetExportImageTaskResult, GetExportImageTaskError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedFleetsError = CommonErrors;
/**
 * Retrieves the name of the fleet that is associated with the specified stack.
 */
export declare const listAssociatedFleets: API.OperationMethod<ListAssociatedFleetsRequest, ListAssociatedFleetsResult, ListAssociatedFleetsError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedStacksError = CommonErrors;
/**
 * Retrieves the name of the stack with which the specified fleet is associated.
 */
export declare const listAssociatedStacks: API.OperationMethod<ListAssociatedStacksRequest, ListAssociatedStacksResult, ListAssociatedStacksError, Credentials | HttpClient.HttpClient>;
export type ListEntitledApplicationsError = EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of entitled applications.
 */
export declare const listEntitledApplications: API.OperationMethod<ListEntitledApplicationsRequest, ListEntitledApplicationsResult, ListEntitledApplicationsError, Credentials | HttpClient.HttpClient>;
export type ListExportImageTasksError = OperationNotPermittedException | CommonErrors;
/**
 * Lists export image tasks, with optional filtering and pagination. Use this operation to monitor the status of multiple export operations.
 */
export declare const listExportImageTasks: API.OperationMethod<ListExportImageTasksRequest, ListExportImageTasksResult, ListExportImageTasksError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of all tags for the specified WorkSpaces Applications resource. You can tag WorkSpaces Applications image builders, images, fleets, and stacks.
 *
 * For more information about tags, see Tagging Your Resources in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartAppBlockBuilderError = ConcurrentModificationException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Starts an app block builder.
 *
 * An app block builder can only be started when it's associated with an app
 * block.
 *
 * Starting an app block builder starts a new instance, which is equivalent to an elastic
 * fleet instance with application builder assistance functionality.
 */
export declare const startAppBlockBuilder: API.OperationMethod<StartAppBlockBuilderRequest, StartAppBlockBuilderResult, StartAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type StartFleetError = ConcurrentModificationException | InvalidAccountStatusException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the specified fleet.
 */
export declare const startFleet: API.OperationMethod<StartFleetRequest, StartFleetResult, StartFleetError, Credentials | HttpClient.HttpClient>;
export type StartImageBuilderError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the specified image builder.
 */
export declare const startImageBuilder: API.OperationMethod<StartImageBuilderRequest, StartImageBuilderResult, StartImageBuilderError, Credentials | HttpClient.HttpClient>;
export type StartSoftwareDeploymentToImageBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Initiates license included applications deployment to an image builder instance.
 */
export declare const startSoftwareDeploymentToImageBuilder: API.OperationMethod<StartSoftwareDeploymentToImageBuilderRequest, StartSoftwareDeploymentToImageBuilderResult, StartSoftwareDeploymentToImageBuilderError, Credentials | HttpClient.HttpClient>;
export type StopAppBlockBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Stops an app block builder.
 *
 * Stopping an app block builder terminates the instance, and the instance state is not
 * persisted.
 */
export declare const stopAppBlockBuilder: API.OperationMethod<StopAppBlockBuilderRequest, StopAppBlockBuilderResult, StopAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type StopFleetError = ConcurrentModificationException | ResourceNotFoundException | CommonErrors;
/**
 * Stops the specified fleet.
 */
export declare const stopFleet: API.OperationMethod<StopFleetRequest, StopFleetResult, StopFleetError, Credentials | HttpClient.HttpClient>;
export type StopImageBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Stops the specified image builder.
 */
export declare const stopImageBuilder: API.OperationMethod<StopImageBuilderRequest, StopImageBuilderResult, StopImageBuilderError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidAccountStatusException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Adds or overwrites one or more tags for the specified WorkSpaces Applications resource. You can tag WorkSpaces Applications image builders, images, fleets, and stacks.
 *
 * Each tag consists of a key and an optional value. If a resource already has a tag with the same key,
 * this operation updates its value.
 *
 * To list the current tags for your resources, use ListTagsForResource.
 * To disassociate tags from your resources, use UntagResource.
 *
 * For more information about tags, see Tagging Your Resources in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Disassociates one or more specified tags from the specified WorkSpaces Applications resource.
 *
 * To list the current tags for your resources, use ListTagsForResource.
 *
 * For more information about tags, see Tagging Your Resources in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppBlockBuilderError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceInUseException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an app block builder.
 *
 * If the app block builder is in the `STARTING` or `STOPPING`
 * state, you can't update it. If the app block builder is in the `RUNNING`
 * state, you can only update the DisplayName and Description. If the app block builder is
 * in the `STOPPED` state, you can update any attribute except the Name.
 */
export declare const updateAppBlockBuilder: API.OperationMethod<UpdateAppBlockBuilderRequest, UpdateAppBlockBuilderResult, UpdateAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResult, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectoryConfigError = ConcurrentModificationException | IncompatibleImageException | InvalidRoleException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified Directory Config object in WorkSpaces Applications. This object includes the configuration information required to join fleets and image builders to Microsoft Active Directory domains.
 */
export declare const updateDirectoryConfig: API.OperationMethod<UpdateDirectoryConfigRequest, UpdateDirectoryConfigResult, UpdateDirectoryConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateEntitlementError = ConcurrentModificationException | EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified entitlement.
 */
export declare const updateEntitlement: API.OperationMethod<UpdateEntitlementRequest, UpdateEntitlementResult, UpdateEntitlementError, Credentials | HttpClient.HttpClient>;
export type UpdateFleetError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceInUseException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified fleet.
 *
 * If the fleet is in the `STOPPED` state, you can update any attribute except
 * the fleet name.
 *
 * If the fleet is in the `RUNNING` state, you can update the following based
 * on the fleet type:
 *
 * - Always-On and On-Demand fleet types
 *
 * You can update the `DisplayName`, `ComputeCapacity`,
 * `ImageARN`, `ImageName`,
 * `IdleDisconnectTimeoutInSeconds`, and
 * `DisconnectTimeoutInSeconds` attributes.
 *
 * - Elastic fleet type
 *
 * You can update the `DisplayName`,
 * `IdleDisconnectTimeoutInSeconds`,
 * `DisconnectTimeoutInSeconds`, `MaxConcurrentSessions`, `SessionScriptS3Location`
 * and `UsbDeviceFilterStrings` attributes.
 *
 * If the fleet is in the `STARTING` or `STOPPED` state, you can't update it.
 */
export declare const updateFleet: API.OperationMethod<UpdateFleetRequest, UpdateFleetResult, UpdateFleetError, Credentials | HttpClient.HttpClient>;
export type UpdateImagePermissionsError = LimitExceededException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Adds or updates permissions for the specified private image.
 */
export declare const updateImagePermissions: API.OperationMethod<UpdateImagePermissionsRequest, UpdateImagePermissionsResult, UpdateImagePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateStackError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified fields for the specified stack.
 */
export declare const updateStack: API.OperationMethod<UpdateStackRequest, UpdateStackResult, UpdateStackError, Credentials | HttpClient.HttpClient>;
export type UpdateThemeForStackError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const updateThemeForStack: API.OperationMethod<UpdateThemeForStackRequest, UpdateThemeForStackResult, UpdateThemeForStackError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appstream.d.ts.map