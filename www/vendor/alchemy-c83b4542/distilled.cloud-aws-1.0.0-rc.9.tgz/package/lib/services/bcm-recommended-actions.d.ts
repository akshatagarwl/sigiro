import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type FilterName = "FEATURE" | "SEVERITY" | "TYPE" | (string & {});
export declare const FilterName: any;
export type MatchOption = "EQUALS" | "NOT_EQUALS" | (string & {});
export declare const MatchOption: any;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export interface ActionFilter {
    key: FilterName;
    matchOption: MatchOption;
    values: string[];
}
export declare const ActionFilter: S.Schema<ActionFilter>;
export type ActionFilterList = ActionFilter[];
export declare const ActionFilterList: any;
export interface RequestFilter {
    actions?: ActionFilter[];
}
export declare const RequestFilter: S.Schema<RequestFilter>;
export type MaxResults = number;
export type NextToken = string;
export interface ListRecommendedActionsRequest {
    filter?: RequestFilter;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecommendedActionsRequest: S.Schema<ListRecommendedActionsRequest>;
export type ActionType = "ADD_ALTERNATE_BILLING_CONTACT" | "CREATE_ANOMALY_MONITOR" | "CREATE_BUDGET" | "ENABLE_COST_OPTIMIZATION_HUB" | "MIGRATE_TO_GRANULAR_PERMISSIONS" | "PAYMENTS_DUE" | "PAYMENTS_PAST_DUE" | "REVIEW_ANOMALIES" | "REVIEW_BUDGET_ALERTS" | "REVIEW_BUDGETS_EXCEEDED" | "REVIEW_EXPIRING_RI" | "REVIEW_EXPIRING_SP" | "REVIEW_FREETIER_USAGE_ALERTS" | "REVIEW_FREETIER_CREDITS_REMAINING" | "REVIEW_FREETIER_DAYS_REMAINING" | "REVIEW_SAVINGS_OPPORTUNITY_RECOMMENDATIONS" | "UPDATE_EXPIRED_PAYMENT_METHOD" | "UPDATE_INVALID_PAYMENT_METHOD" | "UPDATE_TAX_EXEMPTION_CERTIFICATE" | "UPDATE_TAX_REGISTRATION_NUMBER" | (string & {});
export declare const ActionType: any;
export type AccountId = string;
export type Severity = "INFO" | "WARNING" | "CRITICAL" | (string & {});
export declare const Severity: any;
export type Feature = "ACCOUNT" | "BUDGETS" | "COST_ANOMALY_DETECTION" | "COST_OPTIMIZATION_HUB" | "FREE_TIER" | "IAM" | "PAYMENTS" | "RESERVATIONS" | "SAVINGS_PLANS" | "TAX_SETTINGS" | (string & {});
export declare const Feature: any;
export type Context = {
    [key: string]: string | undefined;
};
export declare const Context: any;
export type NextStep = string;
export type NextSteps = string[];
export declare const NextSteps: any;
export interface RecommendedAction {
    id?: string;
    type?: ActionType;
    accountId?: string;
    severity?: Severity;
    feature?: Feature;
    context?: {
        [key: string]: string | undefined;
    };
    nextSteps?: string[];
    lastUpdatedTimeStamp?: string;
}
export declare const RecommendedAction: S.Schema<RecommendedAction>;
export type RecommendedActions = RecommendedAction[];
export declare const RecommendedActions: any;
export interface ListRecommendedActionsResponse {
    recommendedActions: RecommendedAction[];
    nextToken?: string;
}
export declare const ListRecommendedActionsResponse: S.Schema<ListRecommendedActionsResponse>;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type ListRecommendedActionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of recommended actions that match the filter criteria.
 */
export declare const listRecommendedActions: API.PaginatedOperationMethod<ListRecommendedActionsRequest, ListRecommendedActionsResponse, ListRecommendedActionsError, Credentials | HttpClient.HttpClient, RecommendedAction>;
export {};
//# sourceMappingURL=bcm-recommended-actions.d.ts.map