import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly ErrorDetails: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServerErrorException_base: S.Class<InternalServerErrorException, S.TaggedStruct<"InternalServerErrorException", {
    readonly ErrorDetails: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
export interface AssociateRoleToGroupRequest {
    GroupId: string;
    RoleArn?: string;
}
export declare const AssociateRoleToGroupRequest: S.Schema<AssociateRoleToGroupRequest>;
export interface AssociateRoleToGroupResponse {
    AssociatedAt?: string;
}
export declare const AssociateRoleToGroupResponse: S.Schema<AssociateRoleToGroupResponse>;
export interface AssociateServiceRoleToAccountRequest {
    RoleArn?: string;
}
export declare const AssociateServiceRoleToAccountRequest: S.Schema<AssociateServiceRoleToAccountRequest>;
export interface AssociateServiceRoleToAccountResponse {
    AssociatedAt?: string;
}
export declare const AssociateServiceRoleToAccountResponse: S.Schema<AssociateServiceRoleToAccountResponse>;
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export declare const __mapOf__string: any;
export interface Connector {
    ConnectorArn?: string;
    Id?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const Connector: S.Schema<Connector>;
export type __listOfConnector = Connector[];
export declare const __listOfConnector: any;
export interface ConnectorDefinitionVersion {
    Connectors?: Connector[];
}
export declare const ConnectorDefinitionVersion: S.Schema<ConnectorDefinitionVersion>;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CreateConnectorDefinitionRequest {
    AmznClientToken?: string;
    InitialVersion?: ConnectorDefinitionVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConnectorDefinitionRequest: S.Schema<CreateConnectorDefinitionRequest>;
export interface CreateConnectorDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateConnectorDefinitionResponse: S.Schema<CreateConnectorDefinitionResponse>;
export interface CreateConnectorDefinitionVersionRequest {
    AmznClientToken?: string;
    ConnectorDefinitionId: string;
    Connectors?: Connector[];
}
export declare const CreateConnectorDefinitionVersionRequest: S.Schema<CreateConnectorDefinitionVersionRequest>;
export interface CreateConnectorDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateConnectorDefinitionVersionResponse: S.Schema<CreateConnectorDefinitionVersionResponse>;
export interface Core {
    CertificateArn?: string;
    Id?: string;
    SyncShadow?: boolean;
    ThingArn?: string;
}
export declare const Core: S.Schema<Core>;
export type __listOfCore = Core[];
export declare const __listOfCore: any;
export interface CoreDefinitionVersion {
    Cores?: Core[];
}
export declare const CoreDefinitionVersion: S.Schema<CoreDefinitionVersion>;
export interface CreateCoreDefinitionRequest {
    AmznClientToken?: string;
    InitialVersion?: CoreDefinitionVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCoreDefinitionRequest: S.Schema<CreateCoreDefinitionRequest>;
export interface CreateCoreDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateCoreDefinitionResponse: S.Schema<CreateCoreDefinitionResponse>;
export interface CreateCoreDefinitionVersionRequest {
    AmznClientToken?: string;
    CoreDefinitionId: string;
    Cores?: Core[];
}
export declare const CreateCoreDefinitionVersionRequest: S.Schema<CreateCoreDefinitionVersionRequest>;
export interface CreateCoreDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateCoreDefinitionVersionResponse: S.Schema<CreateCoreDefinitionVersionResponse>;
export type DeploymentType = "NewDeployment" | "Redeployment" | "ResetDeployment" | "ForceResetDeployment" | (string & {});
export declare const DeploymentType: any;
export interface CreateDeploymentRequest {
    AmznClientToken?: string;
    DeploymentId?: string;
    DeploymentType?: DeploymentType;
    GroupId: string;
    GroupVersionId?: string;
}
export declare const CreateDeploymentRequest: S.Schema<CreateDeploymentRequest>;
export interface CreateDeploymentResponse {
    DeploymentArn?: string;
    DeploymentId?: string;
}
export declare const CreateDeploymentResponse: S.Schema<CreateDeploymentResponse>;
export interface Device {
    CertificateArn?: string;
    Id?: string;
    SyncShadow?: boolean;
    ThingArn?: string;
}
export declare const Device: S.Schema<Device>;
export type __listOfDevice = Device[];
export declare const __listOfDevice: any;
export interface DeviceDefinitionVersion {
    Devices?: Device[];
}
export declare const DeviceDefinitionVersion: S.Schema<DeviceDefinitionVersion>;
export interface CreateDeviceDefinitionRequest {
    AmznClientToken?: string;
    InitialVersion?: DeviceDefinitionVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDeviceDefinitionRequest: S.Schema<CreateDeviceDefinitionRequest>;
export interface CreateDeviceDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateDeviceDefinitionResponse: S.Schema<CreateDeviceDefinitionResponse>;
export interface CreateDeviceDefinitionVersionRequest {
    AmznClientToken?: string;
    DeviceDefinitionId: string;
    Devices?: Device[];
}
export declare const CreateDeviceDefinitionVersionRequest: S.Schema<CreateDeviceDefinitionVersionRequest>;
export interface CreateDeviceDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateDeviceDefinitionVersionResponse: S.Schema<CreateDeviceDefinitionVersionResponse>;
export type FunctionIsolationMode = "GreengrassContainer" | "NoContainer" | (string & {});
export declare const FunctionIsolationMode: any;
export interface FunctionRunAsConfig {
    Gid?: number;
    Uid?: number;
}
export declare const FunctionRunAsConfig: S.Schema<FunctionRunAsConfig>;
export interface FunctionDefaultExecutionConfig {
    IsolationMode?: FunctionIsolationMode;
    RunAs?: FunctionRunAsConfig;
}
export declare const FunctionDefaultExecutionConfig: S.Schema<FunctionDefaultExecutionConfig>;
export interface FunctionDefaultConfig {
    Execution?: FunctionDefaultExecutionConfig;
}
export declare const FunctionDefaultConfig: S.Schema<FunctionDefaultConfig>;
export type EncodingType = "binary" | "json" | (string & {});
export declare const EncodingType: any;
export interface FunctionExecutionConfig {
    IsolationMode?: FunctionIsolationMode;
    RunAs?: FunctionRunAsConfig;
}
export declare const FunctionExecutionConfig: S.Schema<FunctionExecutionConfig>;
export type Permission = "ro" | "rw" | (string & {});
export declare const Permission: any;
export interface ResourceAccessPolicy {
    Permission?: Permission;
    ResourceId?: string;
}
export declare const ResourceAccessPolicy: S.Schema<ResourceAccessPolicy>;
export type __listOfResourceAccessPolicy = ResourceAccessPolicy[];
export declare const __listOfResourceAccessPolicy: any;
export interface FunctionConfigurationEnvironment {
    AccessSysfs?: boolean;
    Execution?: FunctionExecutionConfig;
    ResourceAccessPolicies?: ResourceAccessPolicy[];
    Variables?: {
        [key: string]: string | undefined;
    };
}
export declare const FunctionConfigurationEnvironment: S.Schema<FunctionConfigurationEnvironment>;
export interface FunctionConfiguration {
    EncodingType?: EncodingType;
    Environment?: FunctionConfigurationEnvironment;
    ExecArgs?: string;
    Executable?: string;
    MemorySize?: number;
    Pinned?: boolean;
    Timeout?: number;
    FunctionRuntimeOverride?: string;
}
export declare const FunctionConfiguration: S.Schema<FunctionConfiguration>;
export interface Function {
    FunctionArn?: string;
    FunctionConfiguration?: FunctionConfiguration;
    Id?: string;
}
export declare const Function: S.Schema<Function>;
export type __listOfFunction = Function[];
export declare const __listOfFunction: any;
export interface FunctionDefinitionVersion {
    DefaultConfig?: FunctionDefaultConfig;
    Functions?: Function[];
}
export declare const FunctionDefinitionVersion: S.Schema<FunctionDefinitionVersion>;
export interface CreateFunctionDefinitionRequest {
    AmznClientToken?: string;
    InitialVersion?: FunctionDefinitionVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateFunctionDefinitionRequest: S.Schema<CreateFunctionDefinitionRequest>;
export interface CreateFunctionDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateFunctionDefinitionResponse: S.Schema<CreateFunctionDefinitionResponse>;
export interface CreateFunctionDefinitionVersionRequest {
    AmznClientToken?: string;
    DefaultConfig?: FunctionDefaultConfig;
    FunctionDefinitionId: string;
    Functions?: Function[];
}
export declare const CreateFunctionDefinitionVersionRequest: S.Schema<CreateFunctionDefinitionVersionRequest>;
export interface CreateFunctionDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateFunctionDefinitionVersionResponse: S.Schema<CreateFunctionDefinitionVersionResponse>;
export interface GroupVersion {
    ConnectorDefinitionVersionArn?: string;
    CoreDefinitionVersionArn?: string;
    DeviceDefinitionVersionArn?: string;
    FunctionDefinitionVersionArn?: string;
    LoggerDefinitionVersionArn?: string;
    ResourceDefinitionVersionArn?: string;
    SubscriptionDefinitionVersionArn?: string;
}
export declare const GroupVersion: S.Schema<GroupVersion>;
export interface CreateGroupRequest {
    AmznClientToken?: string;
    InitialVersion?: GroupVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateGroupRequest: S.Schema<CreateGroupRequest>;
export interface CreateGroupResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateGroupResponse: S.Schema<CreateGroupResponse>;
export interface CreateGroupCertificateAuthorityRequest {
    AmznClientToken?: string;
    GroupId: string;
}
export declare const CreateGroupCertificateAuthorityRequest: S.Schema<CreateGroupCertificateAuthorityRequest>;
export interface CreateGroupCertificateAuthorityResponse {
    GroupCertificateAuthorityArn?: string;
}
export declare const CreateGroupCertificateAuthorityResponse: S.Schema<CreateGroupCertificateAuthorityResponse>;
export interface CreateGroupVersionRequest {
    AmznClientToken?: string;
    ConnectorDefinitionVersionArn?: string;
    CoreDefinitionVersionArn?: string;
    DeviceDefinitionVersionArn?: string;
    FunctionDefinitionVersionArn?: string;
    GroupId: string;
    LoggerDefinitionVersionArn?: string;
    ResourceDefinitionVersionArn?: string;
    SubscriptionDefinitionVersionArn?: string;
}
export declare const CreateGroupVersionRequest: S.Schema<CreateGroupVersionRequest>;
export interface CreateGroupVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateGroupVersionResponse: S.Schema<CreateGroupVersionResponse>;
export type LoggerComponent = "GreengrassSystem" | "Lambda" | (string & {});
export declare const LoggerComponent: any;
export type LoggerLevel = "DEBUG" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export declare const LoggerLevel: any;
export type LoggerType = "FileSystem" | "AWSCloudWatch" | (string & {});
export declare const LoggerType: any;
export interface Logger {
    Component?: LoggerComponent;
    Id?: string;
    Level?: LoggerLevel;
    Space?: number;
    Type?: LoggerType;
}
export declare const Logger: S.Schema<Logger>;
export type __listOfLogger = Logger[];
export declare const __listOfLogger: any;
export interface LoggerDefinitionVersion {
    Loggers?: Logger[];
}
export declare const LoggerDefinitionVersion: S.Schema<LoggerDefinitionVersion>;
export interface CreateLoggerDefinitionRequest {
    AmznClientToken?: string;
    InitialVersion?: LoggerDefinitionVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateLoggerDefinitionRequest: S.Schema<CreateLoggerDefinitionRequest>;
export interface CreateLoggerDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateLoggerDefinitionResponse: S.Schema<CreateLoggerDefinitionResponse>;
export interface CreateLoggerDefinitionVersionRequest {
    AmznClientToken?: string;
    LoggerDefinitionId: string;
    Loggers?: Logger[];
}
export declare const CreateLoggerDefinitionVersionRequest: S.Schema<CreateLoggerDefinitionVersionRequest>;
export interface CreateLoggerDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateLoggerDefinitionVersionResponse: S.Schema<CreateLoggerDefinitionVersionResponse>;
export interface GroupOwnerSetting {
    AutoAddGroupOwner?: boolean;
    GroupOwner?: string;
}
export declare const GroupOwnerSetting: S.Schema<GroupOwnerSetting>;
export interface LocalDeviceResourceData {
    GroupOwnerSetting?: GroupOwnerSetting;
    SourcePath?: string;
}
export declare const LocalDeviceResourceData: S.Schema<LocalDeviceResourceData>;
export interface LocalVolumeResourceData {
    DestinationPath?: string;
    GroupOwnerSetting?: GroupOwnerSetting;
    SourcePath?: string;
}
export declare const LocalVolumeResourceData: S.Schema<LocalVolumeResourceData>;
export interface ResourceDownloadOwnerSetting {
    GroupOwner?: string;
    GroupPermission?: Permission;
}
export declare const ResourceDownloadOwnerSetting: S.Schema<ResourceDownloadOwnerSetting>;
export interface S3MachineLearningModelResourceData {
    DestinationPath?: string;
    OwnerSetting?: ResourceDownloadOwnerSetting;
    S3Uri?: string;
}
export declare const S3MachineLearningModelResourceData: S.Schema<S3MachineLearningModelResourceData>;
export interface SageMakerMachineLearningModelResourceData {
    DestinationPath?: string;
    OwnerSetting?: ResourceDownloadOwnerSetting;
    SageMakerJobArn?: string;
}
export declare const SageMakerMachineLearningModelResourceData: S.Schema<SageMakerMachineLearningModelResourceData>;
export type __listOf__string = string[];
export declare const __listOf__string: any;
export interface SecretsManagerSecretResourceData {
    ARN?: string;
    AdditionalStagingLabelsToDownload?: string[];
}
export declare const SecretsManagerSecretResourceData: S.Schema<SecretsManagerSecretResourceData>;
export interface ResourceDataContainer {
    LocalDeviceResourceData?: LocalDeviceResourceData;
    LocalVolumeResourceData?: LocalVolumeResourceData;
    S3MachineLearningModelResourceData?: S3MachineLearningModelResourceData;
    SageMakerMachineLearningModelResourceData?: SageMakerMachineLearningModelResourceData;
    SecretsManagerSecretResourceData?: SecretsManagerSecretResourceData;
}
export declare const ResourceDataContainer: S.Schema<ResourceDataContainer>;
export interface Resource {
    Id?: string;
    Name?: string;
    ResourceDataContainer?: ResourceDataContainer;
}
export declare const Resource: S.Schema<Resource>;
export type __listOfResource = Resource[];
export declare const __listOfResource: any;
export interface ResourceDefinitionVersion {
    Resources?: Resource[];
}
export declare const ResourceDefinitionVersion: S.Schema<ResourceDefinitionVersion>;
export interface CreateResourceDefinitionRequest {
    AmznClientToken?: string;
    InitialVersion?: ResourceDefinitionVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateResourceDefinitionRequest: S.Schema<CreateResourceDefinitionRequest>;
export interface CreateResourceDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateResourceDefinitionResponse: S.Schema<CreateResourceDefinitionResponse>;
export interface CreateResourceDefinitionVersionRequest {
    AmznClientToken?: string;
    ResourceDefinitionId: string;
    Resources?: Resource[];
}
export declare const CreateResourceDefinitionVersionRequest: S.Schema<CreateResourceDefinitionVersionRequest>;
export interface CreateResourceDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateResourceDefinitionVersionResponse: S.Schema<CreateResourceDefinitionVersionResponse>;
export type S3UrlSignerRole = string;
export type SoftwareToUpdate = "core" | "ota_agent" | (string & {});
export declare const SoftwareToUpdate: any;
export type UpdateAgentLogLevel = "NONE" | "TRACE" | "DEBUG" | "VERBOSE" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export declare const UpdateAgentLogLevel: any;
export type UpdateTargets = string[];
export declare const UpdateTargets: any;
export type UpdateTargetsArchitecture = "armv6l" | "armv7l" | "x86_64" | "aarch64" | (string & {});
export declare const UpdateTargetsArchitecture: any;
export type UpdateTargetsOperatingSystem = "ubuntu" | "raspbian" | "amazon_linux" | "openwrt" | (string & {});
export declare const UpdateTargetsOperatingSystem: any;
export interface CreateSoftwareUpdateJobRequest {
    AmznClientToken?: string;
    S3UrlSignerRole?: string;
    SoftwareToUpdate?: SoftwareToUpdate;
    UpdateAgentLogLevel?: UpdateAgentLogLevel;
    UpdateTargets?: string[];
    UpdateTargetsArchitecture?: UpdateTargetsArchitecture;
    UpdateTargetsOperatingSystem?: UpdateTargetsOperatingSystem;
}
export declare const CreateSoftwareUpdateJobRequest: S.Schema<CreateSoftwareUpdateJobRequest>;
export interface CreateSoftwareUpdateJobResponse {
    IotJobArn?: string;
    IotJobId?: string;
    PlatformSoftwareVersion?: string;
}
export declare const CreateSoftwareUpdateJobResponse: S.Schema<CreateSoftwareUpdateJobResponse>;
export interface Subscription {
    Id?: string;
    Source?: string;
    Subject?: string;
    Target?: string;
}
export declare const Subscription: S.Schema<Subscription>;
export type __listOfSubscription = Subscription[];
export declare const __listOfSubscription: any;
export interface SubscriptionDefinitionVersion {
    Subscriptions?: Subscription[];
}
export declare const SubscriptionDefinitionVersion: S.Schema<SubscriptionDefinitionVersion>;
export interface CreateSubscriptionDefinitionRequest {
    AmznClientToken?: string;
    InitialVersion?: SubscriptionDefinitionVersion;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSubscriptionDefinitionRequest: S.Schema<CreateSubscriptionDefinitionRequest>;
export interface CreateSubscriptionDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const CreateSubscriptionDefinitionResponse: S.Schema<CreateSubscriptionDefinitionResponse>;
export interface CreateSubscriptionDefinitionVersionRequest {
    AmznClientToken?: string;
    SubscriptionDefinitionId: string;
    Subscriptions?: Subscription[];
}
export declare const CreateSubscriptionDefinitionVersionRequest: S.Schema<CreateSubscriptionDefinitionVersionRequest>;
export interface CreateSubscriptionDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const CreateSubscriptionDefinitionVersionResponse: S.Schema<CreateSubscriptionDefinitionVersionResponse>;
export interface DeleteConnectorDefinitionRequest {
    ConnectorDefinitionId: string;
}
export declare const DeleteConnectorDefinitionRequest: S.Schema<DeleteConnectorDefinitionRequest>;
export interface DeleteConnectorDefinitionResponse {
}
export declare const DeleteConnectorDefinitionResponse: S.Schema<DeleteConnectorDefinitionResponse>;
export interface DeleteCoreDefinitionRequest {
    CoreDefinitionId: string;
}
export declare const DeleteCoreDefinitionRequest: S.Schema<DeleteCoreDefinitionRequest>;
export interface DeleteCoreDefinitionResponse {
}
export declare const DeleteCoreDefinitionResponse: S.Schema<DeleteCoreDefinitionResponse>;
export interface DeleteDeviceDefinitionRequest {
    DeviceDefinitionId: string;
}
export declare const DeleteDeviceDefinitionRequest: S.Schema<DeleteDeviceDefinitionRequest>;
export interface DeleteDeviceDefinitionResponse {
}
export declare const DeleteDeviceDefinitionResponse: S.Schema<DeleteDeviceDefinitionResponse>;
export interface DeleteFunctionDefinitionRequest {
    FunctionDefinitionId: string;
}
export declare const DeleteFunctionDefinitionRequest: S.Schema<DeleteFunctionDefinitionRequest>;
export interface DeleteFunctionDefinitionResponse {
}
export declare const DeleteFunctionDefinitionResponse: S.Schema<DeleteFunctionDefinitionResponse>;
export interface DeleteGroupRequest {
    GroupId: string;
}
export declare const DeleteGroupRequest: S.Schema<DeleteGroupRequest>;
export interface DeleteGroupResponse {
}
export declare const DeleteGroupResponse: S.Schema<DeleteGroupResponse>;
export interface DeleteLoggerDefinitionRequest {
    LoggerDefinitionId: string;
}
export declare const DeleteLoggerDefinitionRequest: S.Schema<DeleteLoggerDefinitionRequest>;
export interface DeleteLoggerDefinitionResponse {
}
export declare const DeleteLoggerDefinitionResponse: S.Schema<DeleteLoggerDefinitionResponse>;
export interface DeleteResourceDefinitionRequest {
    ResourceDefinitionId: string;
}
export declare const DeleteResourceDefinitionRequest: S.Schema<DeleteResourceDefinitionRequest>;
export interface DeleteResourceDefinitionResponse {
}
export declare const DeleteResourceDefinitionResponse: S.Schema<DeleteResourceDefinitionResponse>;
export interface DeleteSubscriptionDefinitionRequest {
    SubscriptionDefinitionId: string;
}
export declare const DeleteSubscriptionDefinitionRequest: S.Schema<DeleteSubscriptionDefinitionRequest>;
export interface DeleteSubscriptionDefinitionResponse {
}
export declare const DeleteSubscriptionDefinitionResponse: S.Schema<DeleteSubscriptionDefinitionResponse>;
export interface DisassociateRoleFromGroupRequest {
    GroupId: string;
}
export declare const DisassociateRoleFromGroupRequest: S.Schema<DisassociateRoleFromGroupRequest>;
export interface DisassociateRoleFromGroupResponse {
    DisassociatedAt?: string;
}
export declare const DisassociateRoleFromGroupResponse: S.Schema<DisassociateRoleFromGroupResponse>;
export interface DisassociateServiceRoleFromAccountRequest {
}
export declare const DisassociateServiceRoleFromAccountRequest: S.Schema<DisassociateServiceRoleFromAccountRequest>;
export interface DisassociateServiceRoleFromAccountResponse {
    DisassociatedAt?: string;
}
export declare const DisassociateServiceRoleFromAccountResponse: S.Schema<DisassociateServiceRoleFromAccountResponse>;
export interface GetAssociatedRoleRequest {
    GroupId: string;
}
export declare const GetAssociatedRoleRequest: S.Schema<GetAssociatedRoleRequest>;
export interface GetAssociatedRoleResponse {
    AssociatedAt?: string;
    RoleArn?: string;
}
export declare const GetAssociatedRoleResponse: S.Schema<GetAssociatedRoleResponse>;
export interface GetBulkDeploymentStatusRequest {
    BulkDeploymentId: string;
}
export declare const GetBulkDeploymentStatusRequest: S.Schema<GetBulkDeploymentStatusRequest>;
export interface BulkDeploymentMetrics {
    InvalidInputRecords?: number;
    RecordsProcessed?: number;
    RetryAttempts?: number;
}
export declare const BulkDeploymentMetrics: S.Schema<BulkDeploymentMetrics>;
export type BulkDeploymentStatus = "Initializing" | "Running" | "Completed" | "Stopping" | "Stopped" | "Failed" | (string & {});
export declare const BulkDeploymentStatus: any;
export interface ErrorDetail {
    DetailedErrorCode?: string;
    DetailedErrorMessage?: string;
}
export declare const ErrorDetail: S.Schema<ErrorDetail>;
export type ErrorDetails = ErrorDetail[];
export declare const ErrorDetails: any;
export interface GetBulkDeploymentStatusResponse {
    BulkDeploymentMetrics?: BulkDeploymentMetrics;
    BulkDeploymentStatus?: BulkDeploymentStatus;
    CreatedAt?: string;
    ErrorDetails?: ErrorDetail[];
    ErrorMessage?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetBulkDeploymentStatusResponse: S.Schema<GetBulkDeploymentStatusResponse>;
export interface GetConnectivityInfoRequest {
    ThingName: string;
}
export declare const GetConnectivityInfoRequest: S.Schema<GetConnectivityInfoRequest>;
export interface ConnectivityInfo {
    HostAddress?: string;
    Id?: string;
    Metadata?: string;
    PortNumber?: number;
}
export declare const ConnectivityInfo: S.Schema<ConnectivityInfo>;
export type __listOfConnectivityInfo = ConnectivityInfo[];
export declare const __listOfConnectivityInfo: any;
export interface GetConnectivityInfoResponse {
    ConnectivityInfo?: ConnectivityInfo[];
    Message?: string;
}
export declare const GetConnectivityInfoResponse: S.Schema<GetConnectivityInfoResponse>;
export interface GetConnectorDefinitionRequest {
    ConnectorDefinitionId: string;
}
export declare const GetConnectorDefinitionRequest: S.Schema<GetConnectorDefinitionRequest>;
export interface GetConnectorDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetConnectorDefinitionResponse: S.Schema<GetConnectorDefinitionResponse>;
export interface GetConnectorDefinitionVersionRequest {
    ConnectorDefinitionId: string;
    ConnectorDefinitionVersionId: string;
    NextToken?: string;
}
export declare const GetConnectorDefinitionVersionRequest: S.Schema<GetConnectorDefinitionVersionRequest>;
export interface GetConnectorDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: ConnectorDefinitionVersion & {
        Connectors: (Connector & {
            ConnectorArn: string;
            Id: string;
        })[];
    };
    Id?: string;
    NextToken?: string;
    Version?: string;
}
export declare const GetConnectorDefinitionVersionResponse: S.Schema<GetConnectorDefinitionVersionResponse>;
export interface GetCoreDefinitionRequest {
    CoreDefinitionId: string;
}
export declare const GetCoreDefinitionRequest: S.Schema<GetCoreDefinitionRequest>;
export interface GetCoreDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetCoreDefinitionResponse: S.Schema<GetCoreDefinitionResponse>;
export interface GetCoreDefinitionVersionRequest {
    CoreDefinitionId: string;
    CoreDefinitionVersionId: string;
}
export declare const GetCoreDefinitionVersionRequest: S.Schema<GetCoreDefinitionVersionRequest>;
export interface GetCoreDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: CoreDefinitionVersion & {
        Cores: (Core & {
            CertificateArn: string;
            Id: string;
            ThingArn: string;
        })[];
    };
    Id?: string;
    NextToken?: string;
    Version?: string;
}
export declare const GetCoreDefinitionVersionResponse: S.Schema<GetCoreDefinitionVersionResponse>;
export interface GetDeploymentStatusRequest {
    DeploymentId: string;
    GroupId: string;
}
export declare const GetDeploymentStatusRequest: S.Schema<GetDeploymentStatusRequest>;
export interface GetDeploymentStatusResponse {
    DeploymentStatus?: string;
    DeploymentType?: DeploymentType;
    ErrorDetails?: ErrorDetail[];
    ErrorMessage?: string;
    UpdatedAt?: string;
}
export declare const GetDeploymentStatusResponse: S.Schema<GetDeploymentStatusResponse>;
export interface GetDeviceDefinitionRequest {
    DeviceDefinitionId: string;
}
export declare const GetDeviceDefinitionRequest: S.Schema<GetDeviceDefinitionRequest>;
export interface GetDeviceDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDeviceDefinitionResponse: S.Schema<GetDeviceDefinitionResponse>;
export interface GetDeviceDefinitionVersionRequest {
    DeviceDefinitionId: string;
    DeviceDefinitionVersionId: string;
    NextToken?: string;
}
export declare const GetDeviceDefinitionVersionRequest: S.Schema<GetDeviceDefinitionVersionRequest>;
export interface GetDeviceDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: DeviceDefinitionVersion & {
        Devices: (Device & {
            CertificateArn: string;
            Id: string;
            ThingArn: string;
        })[];
    };
    Id?: string;
    NextToken?: string;
    Version?: string;
}
export declare const GetDeviceDefinitionVersionResponse: S.Schema<GetDeviceDefinitionVersionResponse>;
export interface GetFunctionDefinitionRequest {
    FunctionDefinitionId: string;
}
export declare const GetFunctionDefinitionRequest: S.Schema<GetFunctionDefinitionRequest>;
export interface GetFunctionDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetFunctionDefinitionResponse: S.Schema<GetFunctionDefinitionResponse>;
export interface GetFunctionDefinitionVersionRequest {
    FunctionDefinitionId: string;
    FunctionDefinitionVersionId: string;
    NextToken?: string;
}
export declare const GetFunctionDefinitionVersionRequest: S.Schema<GetFunctionDefinitionVersionRequest>;
export interface GetFunctionDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: FunctionDefinitionVersion & {
        Functions: (Function & {
            Id: string;
            FunctionConfiguration: FunctionConfiguration & {
                Environment: FunctionConfigurationEnvironment & {
                    ResourceAccessPolicies: (ResourceAccessPolicy & {
                        ResourceId: string;
                    })[];
                };
            };
        })[];
    };
    Id?: string;
    NextToken?: string;
    Version?: string;
}
export declare const GetFunctionDefinitionVersionResponse: S.Schema<GetFunctionDefinitionVersionResponse>;
export interface GetGroupRequest {
    GroupId: string;
}
export declare const GetGroupRequest: S.Schema<GetGroupRequest>;
export interface GetGroupResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetGroupResponse: S.Schema<GetGroupResponse>;
export interface GetGroupCertificateAuthorityRequest {
    CertificateAuthorityId: string;
    GroupId: string;
}
export declare const GetGroupCertificateAuthorityRequest: S.Schema<GetGroupCertificateAuthorityRequest>;
export interface GetGroupCertificateAuthorityResponse {
    GroupCertificateAuthorityArn?: string;
    GroupCertificateAuthorityId?: string;
    PemEncodedCertificate?: string;
}
export declare const GetGroupCertificateAuthorityResponse: S.Schema<GetGroupCertificateAuthorityResponse>;
export interface GetGroupCertificateConfigurationRequest {
    GroupId: string;
}
export declare const GetGroupCertificateConfigurationRequest: S.Schema<GetGroupCertificateConfigurationRequest>;
export interface GetGroupCertificateConfigurationResponse {
    CertificateAuthorityExpiryInMilliseconds?: string;
    CertificateExpiryInMilliseconds?: string;
    GroupId?: string;
}
export declare const GetGroupCertificateConfigurationResponse: S.Schema<GetGroupCertificateConfigurationResponse>;
export interface GetGroupVersionRequest {
    GroupId: string;
    GroupVersionId: string;
}
export declare const GetGroupVersionRequest: S.Schema<GetGroupVersionRequest>;
export interface GetGroupVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: GroupVersion;
    Id?: string;
    Version?: string;
}
export declare const GetGroupVersionResponse: S.Schema<GetGroupVersionResponse>;
export interface GetLoggerDefinitionRequest {
    LoggerDefinitionId: string;
}
export declare const GetLoggerDefinitionRequest: S.Schema<GetLoggerDefinitionRequest>;
export interface GetLoggerDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetLoggerDefinitionResponse: S.Schema<GetLoggerDefinitionResponse>;
export interface GetLoggerDefinitionVersionRequest {
    LoggerDefinitionId: string;
    LoggerDefinitionVersionId: string;
    NextToken?: string;
}
export declare const GetLoggerDefinitionVersionRequest: S.Schema<GetLoggerDefinitionVersionRequest>;
export interface GetLoggerDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: LoggerDefinitionVersion & {
        Loggers: (Logger & {
            Component: LoggerComponent;
            Id: string;
            Level: LoggerLevel;
            Type: LoggerType;
        })[];
    };
    Id?: string;
    Version?: string;
}
export declare const GetLoggerDefinitionVersionResponse: S.Schema<GetLoggerDefinitionVersionResponse>;
export interface GetResourceDefinitionRequest {
    ResourceDefinitionId: string;
}
export declare const GetResourceDefinitionRequest: S.Schema<GetResourceDefinitionRequest>;
export interface GetResourceDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetResourceDefinitionResponse: S.Schema<GetResourceDefinitionResponse>;
export interface GetResourceDefinitionVersionRequest {
    ResourceDefinitionId: string;
    ResourceDefinitionVersionId: string;
}
export declare const GetResourceDefinitionVersionRequest: S.Schema<GetResourceDefinitionVersionRequest>;
export interface GetResourceDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: ResourceDefinitionVersion & {
        Resources: (Resource & {
            Id: string;
            Name: string;
            ResourceDataContainer: ResourceDataContainer & {
                S3MachineLearningModelResourceData: S3MachineLearningModelResourceData & {
                    OwnerSetting: ResourceDownloadOwnerSetting & {
                        GroupOwner: string;
                        GroupPermission: Permission;
                    };
                };
                SageMakerMachineLearningModelResourceData: SageMakerMachineLearningModelResourceData & {
                    OwnerSetting: ResourceDownloadOwnerSetting & {
                        GroupOwner: string;
                        GroupPermission: Permission;
                    };
                };
            };
        })[];
    };
    Id?: string;
    Version?: string;
}
export declare const GetResourceDefinitionVersionResponse: S.Schema<GetResourceDefinitionVersionResponse>;
export interface GetServiceRoleForAccountRequest {
}
export declare const GetServiceRoleForAccountRequest: S.Schema<GetServiceRoleForAccountRequest>;
export interface GetServiceRoleForAccountResponse {
    AssociatedAt?: string;
    RoleArn?: string;
}
export declare const GetServiceRoleForAccountResponse: S.Schema<GetServiceRoleForAccountResponse>;
export interface GetSubscriptionDefinitionRequest {
    SubscriptionDefinitionId: string;
}
export declare const GetSubscriptionDefinitionRequest: S.Schema<GetSubscriptionDefinitionRequest>;
export interface GetSubscriptionDefinitionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetSubscriptionDefinitionResponse: S.Schema<GetSubscriptionDefinitionResponse>;
export interface GetSubscriptionDefinitionVersionRequest {
    NextToken?: string;
    SubscriptionDefinitionId: string;
    SubscriptionDefinitionVersionId: string;
}
export declare const GetSubscriptionDefinitionVersionRequest: S.Schema<GetSubscriptionDefinitionVersionRequest>;
export interface GetSubscriptionDefinitionVersionResponse {
    Arn?: string;
    CreationTimestamp?: string;
    Definition?: SubscriptionDefinitionVersion & {
        Subscriptions: (Subscription & {
            Id: string;
            Source: string;
            Subject: string;
            Target: string;
        })[];
    };
    Id?: string;
    NextToken?: string;
    Version?: string;
}
export declare const GetSubscriptionDefinitionVersionResponse: S.Schema<GetSubscriptionDefinitionVersionResponse>;
export interface GetThingRuntimeConfigurationRequest {
    ThingName: string;
}
export declare const GetThingRuntimeConfigurationRequest: S.Schema<GetThingRuntimeConfigurationRequest>;
export type ConfigurationSyncStatus = "InSync" | "OutOfSync" | (string & {});
export declare const ConfigurationSyncStatus: any;
export type Telemetry = "On" | "Off" | (string & {});
export declare const Telemetry: any;
export interface TelemetryConfiguration {
    ConfigurationSyncStatus?: ConfigurationSyncStatus;
    Telemetry?: Telemetry;
}
export declare const TelemetryConfiguration: S.Schema<TelemetryConfiguration>;
export interface RuntimeConfiguration {
    TelemetryConfiguration?: TelemetryConfiguration;
}
export declare const RuntimeConfiguration: S.Schema<RuntimeConfiguration>;
export interface GetThingRuntimeConfigurationResponse {
    RuntimeConfiguration?: RuntimeConfiguration & {
        TelemetryConfiguration: TelemetryConfiguration & {
            Telemetry: Telemetry;
        };
    };
}
export declare const GetThingRuntimeConfigurationResponse: S.Schema<GetThingRuntimeConfigurationResponse>;
export interface ListBulkDeploymentDetailedReportsRequest {
    BulkDeploymentId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListBulkDeploymentDetailedReportsRequest: S.Schema<ListBulkDeploymentDetailedReportsRequest>;
export interface BulkDeploymentResult {
    CreatedAt?: string;
    DeploymentArn?: string;
    DeploymentId?: string;
    DeploymentStatus?: string;
    DeploymentType?: DeploymentType;
    ErrorDetails?: ErrorDetail[];
    ErrorMessage?: string;
    GroupArn?: string;
}
export declare const BulkDeploymentResult: S.Schema<BulkDeploymentResult>;
export type BulkDeploymentResults = BulkDeploymentResult[];
export declare const BulkDeploymentResults: any;
export interface ListBulkDeploymentDetailedReportsResponse {
    Deployments?: BulkDeploymentResult[];
    NextToken?: string;
}
export declare const ListBulkDeploymentDetailedReportsResponse: S.Schema<ListBulkDeploymentDetailedReportsResponse>;
export interface ListBulkDeploymentsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListBulkDeploymentsRequest: S.Schema<ListBulkDeploymentsRequest>;
export interface BulkDeployment {
    BulkDeploymentArn?: string;
    BulkDeploymentId?: string;
    CreatedAt?: string;
}
export declare const BulkDeployment: S.Schema<BulkDeployment>;
export type BulkDeployments = BulkDeployment[];
export declare const BulkDeployments: any;
export interface ListBulkDeploymentsResponse {
    BulkDeployments?: BulkDeployment[];
    NextToken?: string;
}
export declare const ListBulkDeploymentsResponse: S.Schema<ListBulkDeploymentsResponse>;
export interface ListConnectorDefinitionsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListConnectorDefinitionsRequest: S.Schema<ListConnectorDefinitionsRequest>;
export interface DefinitionInformation {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DefinitionInformation: S.Schema<DefinitionInformation>;
export type __listOfDefinitionInformation = DefinitionInformation[];
export declare const __listOfDefinitionInformation: any;
export interface ListConnectorDefinitionsResponse {
    Definitions?: DefinitionInformation[];
    NextToken?: string;
}
export declare const ListConnectorDefinitionsResponse: S.Schema<ListConnectorDefinitionsResponse>;
export interface ListConnectorDefinitionVersionsRequest {
    ConnectorDefinitionId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListConnectorDefinitionVersionsRequest: S.Schema<ListConnectorDefinitionVersionsRequest>;
export interface VersionInformation {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    Version?: string;
}
export declare const VersionInformation: S.Schema<VersionInformation>;
export type __listOfVersionInformation = VersionInformation[];
export declare const __listOfVersionInformation: any;
export interface ListConnectorDefinitionVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListConnectorDefinitionVersionsResponse: S.Schema<ListConnectorDefinitionVersionsResponse>;
export interface ListCoreDefinitionsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListCoreDefinitionsRequest: S.Schema<ListCoreDefinitionsRequest>;
export interface ListCoreDefinitionsResponse {
    Definitions?: DefinitionInformation[];
    NextToken?: string;
}
export declare const ListCoreDefinitionsResponse: S.Schema<ListCoreDefinitionsResponse>;
export interface ListCoreDefinitionVersionsRequest {
    CoreDefinitionId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListCoreDefinitionVersionsRequest: S.Schema<ListCoreDefinitionVersionsRequest>;
export interface ListCoreDefinitionVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListCoreDefinitionVersionsResponse: S.Schema<ListCoreDefinitionVersionsResponse>;
export interface ListDeploymentsRequest {
    GroupId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListDeploymentsRequest: S.Schema<ListDeploymentsRequest>;
export interface Deployment {
    CreatedAt?: string;
    DeploymentArn?: string;
    DeploymentId?: string;
    DeploymentType?: DeploymentType;
    GroupArn?: string;
}
export declare const Deployment: S.Schema<Deployment>;
export type Deployments = Deployment[];
export declare const Deployments: any;
export interface ListDeploymentsResponse {
    Deployments?: Deployment[];
    NextToken?: string;
}
export declare const ListDeploymentsResponse: S.Schema<ListDeploymentsResponse>;
export interface ListDeviceDefinitionsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListDeviceDefinitionsRequest: S.Schema<ListDeviceDefinitionsRequest>;
export interface ListDeviceDefinitionsResponse {
    Definitions?: DefinitionInformation[];
    NextToken?: string;
}
export declare const ListDeviceDefinitionsResponse: S.Schema<ListDeviceDefinitionsResponse>;
export interface ListDeviceDefinitionVersionsRequest {
    DeviceDefinitionId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListDeviceDefinitionVersionsRequest: S.Schema<ListDeviceDefinitionVersionsRequest>;
export interface ListDeviceDefinitionVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListDeviceDefinitionVersionsResponse: S.Schema<ListDeviceDefinitionVersionsResponse>;
export interface ListFunctionDefinitionsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListFunctionDefinitionsRequest: S.Schema<ListFunctionDefinitionsRequest>;
export interface ListFunctionDefinitionsResponse {
    Definitions?: DefinitionInformation[];
    NextToken?: string;
}
export declare const ListFunctionDefinitionsResponse: S.Schema<ListFunctionDefinitionsResponse>;
export interface ListFunctionDefinitionVersionsRequest {
    FunctionDefinitionId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListFunctionDefinitionVersionsRequest: S.Schema<ListFunctionDefinitionVersionsRequest>;
export interface ListFunctionDefinitionVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListFunctionDefinitionVersionsResponse: S.Schema<ListFunctionDefinitionVersionsResponse>;
export interface ListGroupCertificateAuthoritiesRequest {
    GroupId: string;
}
export declare const ListGroupCertificateAuthoritiesRequest: S.Schema<ListGroupCertificateAuthoritiesRequest>;
export interface GroupCertificateAuthorityProperties {
    GroupCertificateAuthorityArn?: string;
    GroupCertificateAuthorityId?: string;
}
export declare const GroupCertificateAuthorityProperties: S.Schema<GroupCertificateAuthorityProperties>;
export type __listOfGroupCertificateAuthorityProperties = GroupCertificateAuthorityProperties[];
export declare const __listOfGroupCertificateAuthorityProperties: any;
export interface ListGroupCertificateAuthoritiesResponse {
    GroupCertificateAuthorities?: GroupCertificateAuthorityProperties[];
}
export declare const ListGroupCertificateAuthoritiesResponse: S.Schema<ListGroupCertificateAuthoritiesResponse>;
export interface ListGroupsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListGroupsRequest: S.Schema<ListGroupsRequest>;
export interface GroupInformation {
    Arn?: string;
    CreationTimestamp?: string;
    Id?: string;
    LastUpdatedTimestamp?: string;
    LatestVersion?: string;
    LatestVersionArn?: string;
    Name?: string;
}
export declare const GroupInformation: S.Schema<GroupInformation>;
export type __listOfGroupInformation = GroupInformation[];
export declare const __listOfGroupInformation: any;
export interface ListGroupsResponse {
    Groups?: GroupInformation[];
    NextToken?: string;
}
export declare const ListGroupsResponse: S.Schema<ListGroupsResponse>;
export interface ListGroupVersionsRequest {
    GroupId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListGroupVersionsRequest: S.Schema<ListGroupVersionsRequest>;
export interface ListGroupVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListGroupVersionsResponse: S.Schema<ListGroupVersionsResponse>;
export interface ListLoggerDefinitionsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListLoggerDefinitionsRequest: S.Schema<ListLoggerDefinitionsRequest>;
export interface ListLoggerDefinitionsResponse {
    Definitions?: DefinitionInformation[];
    NextToken?: string;
}
export declare const ListLoggerDefinitionsResponse: S.Schema<ListLoggerDefinitionsResponse>;
export interface ListLoggerDefinitionVersionsRequest {
    LoggerDefinitionId: string;
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListLoggerDefinitionVersionsRequest: S.Schema<ListLoggerDefinitionVersionsRequest>;
export interface ListLoggerDefinitionVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListLoggerDefinitionVersionsResponse: S.Schema<ListLoggerDefinitionVersionsResponse>;
export interface ListResourceDefinitionsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListResourceDefinitionsRequest: S.Schema<ListResourceDefinitionsRequest>;
export interface ListResourceDefinitionsResponse {
    Definitions?: DefinitionInformation[];
    NextToken?: string;
}
export declare const ListResourceDefinitionsResponse: S.Schema<ListResourceDefinitionsResponse>;
export interface ListResourceDefinitionVersionsRequest {
    MaxResults?: string;
    NextToken?: string;
    ResourceDefinitionId: string;
}
export declare const ListResourceDefinitionVersionsRequest: S.Schema<ListResourceDefinitionVersionsRequest>;
export interface ListResourceDefinitionVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListResourceDefinitionVersionsResponse: S.Schema<ListResourceDefinitionVersionsResponse>;
export interface ListSubscriptionDefinitionsRequest {
    MaxResults?: string;
    NextToken?: string;
}
export declare const ListSubscriptionDefinitionsRequest: S.Schema<ListSubscriptionDefinitionsRequest>;
export interface ListSubscriptionDefinitionsResponse {
    Definitions?: DefinitionInformation[];
    NextToken?: string;
}
export declare const ListSubscriptionDefinitionsResponse: S.Schema<ListSubscriptionDefinitionsResponse>;
export interface ListSubscriptionDefinitionVersionsRequest {
    MaxResults?: string;
    NextToken?: string;
    SubscriptionDefinitionId: string;
}
export declare const ListSubscriptionDefinitionVersionsRequest: S.Schema<ListSubscriptionDefinitionVersionsRequest>;
export interface ListSubscriptionDefinitionVersionsResponse {
    NextToken?: string;
    Versions?: VersionInformation[];
}
export declare const ListSubscriptionDefinitionVersionsResponse: S.Schema<ListSubscriptionDefinitionVersionsResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ResetDeploymentsRequest {
    AmznClientToken?: string;
    Force?: boolean;
    GroupId: string;
}
export declare const ResetDeploymentsRequest: S.Schema<ResetDeploymentsRequest>;
export interface ResetDeploymentsResponse {
    DeploymentArn?: string;
    DeploymentId?: string;
}
export declare const ResetDeploymentsResponse: S.Schema<ResetDeploymentsResponse>;
export interface StartBulkDeploymentRequest {
    AmznClientToken?: string;
    ExecutionRoleArn?: string;
    InputFileUri?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartBulkDeploymentRequest: S.Schema<StartBulkDeploymentRequest>;
export interface StartBulkDeploymentResponse {
    BulkDeploymentArn?: string;
    BulkDeploymentId?: string;
}
export declare const StartBulkDeploymentResponse: S.Schema<StartBulkDeploymentResponse>;
export interface StopBulkDeploymentRequest {
    BulkDeploymentId: string;
}
export declare const StopBulkDeploymentRequest: S.Schema<StopBulkDeploymentRequest>;
export interface StopBulkDeploymentResponse {
}
export declare const StopBulkDeploymentResponse: S.Schema<StopBulkDeploymentResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateConnectivityInfoRequest {
    ConnectivityInfo?: ConnectivityInfo[];
    ThingName: string;
}
export declare const UpdateConnectivityInfoRequest: S.Schema<UpdateConnectivityInfoRequest>;
export interface UpdateConnectivityInfoResponse {
    Message?: string;
    Version?: string;
}
export declare const UpdateConnectivityInfoResponse: S.Schema<UpdateConnectivityInfoResponse>;
export interface UpdateConnectorDefinitionRequest {
    ConnectorDefinitionId: string;
    Name?: string;
}
export declare const UpdateConnectorDefinitionRequest: S.Schema<UpdateConnectorDefinitionRequest>;
export interface UpdateConnectorDefinitionResponse {
}
export declare const UpdateConnectorDefinitionResponse: S.Schema<UpdateConnectorDefinitionResponse>;
export interface UpdateCoreDefinitionRequest {
    CoreDefinitionId: string;
    Name?: string;
}
export declare const UpdateCoreDefinitionRequest: S.Schema<UpdateCoreDefinitionRequest>;
export interface UpdateCoreDefinitionResponse {
}
export declare const UpdateCoreDefinitionResponse: S.Schema<UpdateCoreDefinitionResponse>;
export interface UpdateDeviceDefinitionRequest {
    DeviceDefinitionId: string;
    Name?: string;
}
export declare const UpdateDeviceDefinitionRequest: S.Schema<UpdateDeviceDefinitionRequest>;
export interface UpdateDeviceDefinitionResponse {
}
export declare const UpdateDeviceDefinitionResponse: S.Schema<UpdateDeviceDefinitionResponse>;
export interface UpdateFunctionDefinitionRequest {
    FunctionDefinitionId: string;
    Name?: string;
}
export declare const UpdateFunctionDefinitionRequest: S.Schema<UpdateFunctionDefinitionRequest>;
export interface UpdateFunctionDefinitionResponse {
}
export declare const UpdateFunctionDefinitionResponse: S.Schema<UpdateFunctionDefinitionResponse>;
export interface UpdateGroupRequest {
    GroupId: string;
    Name?: string;
}
export declare const UpdateGroupRequest: S.Schema<UpdateGroupRequest>;
export interface UpdateGroupResponse {
}
export declare const UpdateGroupResponse: S.Schema<UpdateGroupResponse>;
export interface UpdateGroupCertificateConfigurationRequest {
    CertificateExpiryInMilliseconds?: string;
    GroupId: string;
}
export declare const UpdateGroupCertificateConfigurationRequest: S.Schema<UpdateGroupCertificateConfigurationRequest>;
export interface UpdateGroupCertificateConfigurationResponse {
    CertificateAuthorityExpiryInMilliseconds?: string;
    CertificateExpiryInMilliseconds?: string;
    GroupId?: string;
}
export declare const UpdateGroupCertificateConfigurationResponse: S.Schema<UpdateGroupCertificateConfigurationResponse>;
export interface UpdateLoggerDefinitionRequest {
    LoggerDefinitionId: string;
    Name?: string;
}
export declare const UpdateLoggerDefinitionRequest: S.Schema<UpdateLoggerDefinitionRequest>;
export interface UpdateLoggerDefinitionResponse {
}
export declare const UpdateLoggerDefinitionResponse: S.Schema<UpdateLoggerDefinitionResponse>;
export interface UpdateResourceDefinitionRequest {
    Name?: string;
    ResourceDefinitionId: string;
}
export declare const UpdateResourceDefinitionRequest: S.Schema<UpdateResourceDefinitionRequest>;
export interface UpdateResourceDefinitionResponse {
}
export declare const UpdateResourceDefinitionResponse: S.Schema<UpdateResourceDefinitionResponse>;
export interface UpdateSubscriptionDefinitionRequest {
    Name?: string;
    SubscriptionDefinitionId: string;
}
export declare const UpdateSubscriptionDefinitionRequest: S.Schema<UpdateSubscriptionDefinitionRequest>;
export interface UpdateSubscriptionDefinitionResponse {
}
export declare const UpdateSubscriptionDefinitionResponse: S.Schema<UpdateSubscriptionDefinitionResponse>;
export interface TelemetryConfigurationUpdate {
    Telemetry?: Telemetry;
}
export declare const TelemetryConfigurationUpdate: S.Schema<TelemetryConfigurationUpdate>;
export interface UpdateThingRuntimeConfigurationRequest {
    TelemetryConfiguration?: TelemetryConfigurationUpdate;
    ThingName: string;
}
export declare const UpdateThingRuntimeConfigurationRequest: S.Schema<UpdateThingRuntimeConfigurationRequest>;
export interface UpdateThingRuntimeConfigurationResponse {
}
export declare const UpdateThingRuntimeConfigurationResponse: S.Schema<UpdateThingRuntimeConfigurationResponse>;
export type AssociateRoleToGroupError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Associates a role with a group. Your Greengrass core will use the role to access AWS cloud services. The role's permissions should allow Greengrass core Lambda functions to perform actions against the cloud.
 */
export declare const associateRoleToGroup: API.OperationMethod<AssociateRoleToGroupRequest, AssociateRoleToGroupResponse, AssociateRoleToGroupError, Credentials | HttpClient.HttpClient>;
export type AssociateServiceRoleToAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Associates a role with your account. AWS IoT Greengrass will use the role to access your Lambda functions and AWS IoT resources. This is necessary for deployments to succeed. The role must have at least minimum permissions in the policy ''AWSGreengrassResourceAccessRolePolicy''.
 */
export declare const associateServiceRoleToAccount: API.OperationMethod<AssociateServiceRoleToAccountRequest, AssociateServiceRoleToAccountResponse, AssociateServiceRoleToAccountError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a connector definition. You may provide the initial version of the connector definition now or use ''CreateConnectorDefinitionVersion'' at a later time.
 */
export declare const createConnectorDefinition: API.OperationMethod<CreateConnectorDefinitionRequest, CreateConnectorDefinitionResponse, CreateConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a connector definition which has already been defined.
 */
export declare const createConnectorDefinitionVersion: API.OperationMethod<CreateConnectorDefinitionVersionRequest, CreateConnectorDefinitionVersionResponse, CreateConnectorDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a core definition. You may provide the initial version of the core definition now or use ''CreateCoreDefinitionVersion'' at a later time. Greengrass groups must each contain exactly one Greengrass core.
 */
export declare const createCoreDefinition: API.OperationMethod<CreateCoreDefinitionRequest, CreateCoreDefinitionResponse, CreateCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateCoreDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a core definition that has already been defined. Greengrass groups must each contain exactly one Greengrass core.
 */
export declare const createCoreDefinitionVersion: API.OperationMethod<CreateCoreDefinitionVersionRequest, CreateCoreDefinitionVersionResponse, CreateCoreDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | CommonErrors;
/**
 * Creates a deployment. ''CreateDeployment'' requests are idempotent with respect to the ''X-Amzn-Client-Token'' token and the request parameters.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a device definition. You may provide the initial version of the device definition now or use ''CreateDeviceDefinitionVersion'' at a later time.
 */
export declare const createDeviceDefinition: API.OperationMethod<CreateDeviceDefinitionRequest, CreateDeviceDefinitionResponse, CreateDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateDeviceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a device definition that has already been defined.
 */
export declare const createDeviceDefinitionVersion: API.OperationMethod<CreateDeviceDefinitionVersionRequest, CreateDeviceDefinitionVersionResponse, CreateDeviceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a Lambda function definition which contains a list of Lambda functions and their configurations to be used in a group. You can create an initial version of the definition by providing a list of Lambda functions and their configurations now, or use ''CreateFunctionDefinitionVersion'' later.
 */
export declare const createFunctionDefinition: API.OperationMethod<CreateFunctionDefinitionRequest, CreateFunctionDefinitionResponse, CreateFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a Lambda function definition that has already been defined.
 */
export declare const createFunctionDefinitionVersion: API.OperationMethod<CreateFunctionDefinitionVersionRequest, CreateFunctionDefinitionVersionResponse, CreateFunctionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = BadRequestException | CommonErrors;
/**
 * Creates a group. You may provide the initial version of the group or use ''CreateGroupVersion'' at a later time. Tip: You can use the ''gg_group_setup'' package (https://github.com/awslabs/aws-greengrass-group-setup) as a library or command-line application to create and deploy Greengrass groups.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGroupCertificateAuthorityError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a CA for the group. If a CA already exists, it will rotate the existing CA.
 */
export declare const createGroupCertificateAuthority: API.OperationMethod<CreateGroupCertificateAuthorityRequest, CreateGroupCertificateAuthorityResponse, CreateGroupCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type CreateGroupVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a group which has already been defined.
 */
export declare const createGroupVersion: API.OperationMethod<CreateGroupVersionRequest, CreateGroupVersionResponse, CreateGroupVersionError, Credentials | HttpClient.HttpClient>;
export type CreateLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a logger definition. You may provide the initial version of the logger definition now or use ''CreateLoggerDefinitionVersion'' at a later time.
 */
export declare const createLoggerDefinition: API.OperationMethod<CreateLoggerDefinitionRequest, CreateLoggerDefinitionResponse, CreateLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateLoggerDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a logger definition that has already been defined.
 */
export declare const createLoggerDefinitionVersion: API.OperationMethod<CreateLoggerDefinitionVersionRequest, CreateLoggerDefinitionVersionResponse, CreateLoggerDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a resource definition which contains a list of resources to be used in a group. You can create an initial version of the definition by providing a list of resources now, or use ''CreateResourceDefinitionVersion'' later.
 */
export declare const createResourceDefinition: API.OperationMethod<CreateResourceDefinitionRequest, CreateResourceDefinitionResponse, CreateResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateResourceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a resource definition that has already been defined.
 */
export declare const createResourceDefinitionVersion: API.OperationMethod<CreateResourceDefinitionVersionRequest, CreateResourceDefinitionVersionResponse, CreateResourceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateSoftwareUpdateJobError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a software update for a core or group of cores (specified as an IoT thing group.) Use this to update the OTA Agent as well as the Greengrass core software. It makes use of the IoT Jobs feature which provides additional commands to manage a Greengrass core software update job.
 */
export declare const createSoftwareUpdateJob: API.OperationMethod<CreateSoftwareUpdateJobRequest, CreateSoftwareUpdateJobResponse, CreateSoftwareUpdateJobError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a subscription definition. You may provide the initial version of the subscription definition now or use ''CreateSubscriptionDefinitionVersion'' at a later time.
 */
export declare const createSubscriptionDefinition: API.OperationMethod<CreateSubscriptionDefinitionRequest, CreateSubscriptionDefinitionResponse, CreateSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a subscription definition which has already been defined.
 */
export declare const createSubscriptionDefinitionVersion: API.OperationMethod<CreateSubscriptionDefinitionVersionRequest, CreateSubscriptionDefinitionVersionResponse, CreateSubscriptionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a connector definition.
 */
export declare const deleteConnectorDefinition: API.OperationMethod<DeleteConnectorDefinitionRequest, DeleteConnectorDefinitionResponse, DeleteConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a core definition.
 */
export declare const deleteCoreDefinition: API.OperationMethod<DeleteCoreDefinitionRequest, DeleteCoreDefinitionResponse, DeleteCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a device definition.
 */
export declare const deleteDeviceDefinition: API.OperationMethod<DeleteDeviceDefinitionRequest, DeleteDeviceDefinitionResponse, DeleteDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a Lambda function definition.
 */
export declare const deleteFunctionDefinition: API.OperationMethod<DeleteFunctionDefinitionRequest, DeleteFunctionDefinitionResponse, DeleteFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = BadRequestException | CommonErrors;
/**
 * Deletes a group.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a logger definition.
 */
export declare const deleteLoggerDefinition: API.OperationMethod<DeleteLoggerDefinitionRequest, DeleteLoggerDefinitionResponse, DeleteLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a resource definition.
 */
export declare const deleteResourceDefinition: API.OperationMethod<DeleteResourceDefinitionRequest, DeleteResourceDefinitionResponse, DeleteResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a subscription definition.
 */
export declare const deleteSubscriptionDefinition: API.OperationMethod<DeleteSubscriptionDefinitionRequest, DeleteSubscriptionDefinitionResponse, DeleteSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type DisassociateRoleFromGroupError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates the role from a group.
 */
export declare const disassociateRoleFromGroup: API.OperationMethod<DisassociateRoleFromGroupRequest, DisassociateRoleFromGroupResponse, DisassociateRoleFromGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceRoleFromAccountError = InternalServerErrorException | CommonErrors;
/**
 * Disassociates the service role from your account. Without a service role, deployments will not work.
 */
export declare const disassociateServiceRoleFromAccount: API.OperationMethod<DisassociateServiceRoleFromAccountRequest, DisassociateServiceRoleFromAccountResponse, DisassociateServiceRoleFromAccountError, Credentials | HttpClient.HttpClient>;
export type GetAssociatedRoleError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the role associated with a particular group.
 */
export declare const getAssociatedRole: API.OperationMethod<GetAssociatedRoleRequest, GetAssociatedRoleResponse, GetAssociatedRoleError, Credentials | HttpClient.HttpClient>;
export type GetBulkDeploymentStatusError = BadRequestException | CommonErrors;
/**
 * Returns the status of a bulk deployment.
 */
export declare const getBulkDeploymentStatus: API.OperationMethod<GetBulkDeploymentStatusRequest, GetBulkDeploymentStatusResponse, GetBulkDeploymentStatusError, Credentials | HttpClient.HttpClient>;
export type GetConnectivityInfoError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the connectivity information for a core.
 */
export declare const getConnectivityInfo: API.OperationMethod<GetConnectivityInfoRequest, GetConnectivityInfoResponse, GetConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export type GetConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a connector definition.
 */
export declare const getConnectorDefinition: API.OperationMethod<GetConnectorDefinitionRequest, GetConnectorDefinitionResponse, GetConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetConnectorDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a connector definition version, including the connectors that the version contains. Connectors are prebuilt modules that interact with local infrastructure, device protocols, AWS, and other cloud services.
 */
export declare const getConnectorDefinitionVersion: API.OperationMethod<GetConnectorDefinitionVersionRequest, GetConnectorDefinitionVersionResponse, GetConnectorDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a core definition version.
 */
export declare const getCoreDefinition: API.OperationMethod<GetCoreDefinitionRequest, GetCoreDefinitionResponse, GetCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetCoreDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a core definition version.
 */
export declare const getCoreDefinitionVersion: API.OperationMethod<GetCoreDefinitionVersionRequest, GetCoreDefinitionVersionResponse, GetCoreDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentStatusError = BadRequestException | CommonErrors;
/**
 * Returns the status of a deployment.
 */
export declare const getDeploymentStatus: API.OperationMethod<GetDeploymentStatusRequest, GetDeploymentStatusResponse, GetDeploymentStatusError, Credentials | HttpClient.HttpClient>;
export type GetDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a device definition.
 */
export declare const getDeviceDefinition: API.OperationMethod<GetDeviceDefinitionRequest, GetDeviceDefinitionResponse, GetDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetDeviceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a device definition version.
 */
export declare const getDeviceDefinitionVersion: API.OperationMethod<GetDeviceDefinitionVersionRequest, GetDeviceDefinitionVersionResponse, GetDeviceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a Lambda function definition, including its creation time and latest version.
 */
export declare const getFunctionDefinition: API.OperationMethod<GetFunctionDefinitionRequest, GetFunctionDefinitionResponse, GetFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetFunctionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a Lambda function definition version, including which Lambda functions are included in the version and their configurations.
 */
export declare const getFunctionDefinitionVersion: API.OperationMethod<GetFunctionDefinitionVersionRequest, GetFunctionDefinitionVersionResponse, GetFunctionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a group.
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient>;
export type GetGroupCertificateAuthorityError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retreives the CA associated with a group. Returns the public key of the CA.
 */
export declare const getGroupCertificateAuthority: API.OperationMethod<GetGroupCertificateAuthorityRequest, GetGroupCertificateAuthorityResponse, GetGroupCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type GetGroupCertificateConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the current configuration for the CA used by the group.
 */
export declare const getGroupCertificateConfiguration: API.OperationMethod<GetGroupCertificateConfigurationRequest, GetGroupCertificateConfigurationResponse, GetGroupCertificateConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetGroupVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a group version.
 */
export declare const getGroupVersion: API.OperationMethod<GetGroupVersionRequest, GetGroupVersionResponse, GetGroupVersionError, Credentials | HttpClient.HttpClient>;
export type GetLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a logger definition.
 */
export declare const getLoggerDefinition: API.OperationMethod<GetLoggerDefinitionRequest, GetLoggerDefinitionResponse, GetLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetLoggerDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a logger definition version.
 */
export declare const getLoggerDefinitionVersion: API.OperationMethod<GetLoggerDefinitionVersionRequest, GetLoggerDefinitionVersionResponse, GetLoggerDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a resource definition, including its creation time and latest version.
 */
export declare const getResourceDefinition: API.OperationMethod<GetResourceDefinitionRequest, GetResourceDefinitionResponse, GetResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetResourceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a resource definition version, including which resources are included in the version.
 */
export declare const getResourceDefinitionVersion: API.OperationMethod<GetResourceDefinitionVersionRequest, GetResourceDefinitionVersionResponse, GetResourceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetServiceRoleForAccountError = InternalServerErrorException | CommonErrors;
/**
 * Retrieves the service role that is attached to your account.
 */
export declare const getServiceRoleForAccount: API.OperationMethod<GetServiceRoleForAccountRequest, GetServiceRoleForAccountResponse, GetServiceRoleForAccountError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a subscription definition.
 */
export declare const getSubscriptionDefinition: API.OperationMethod<GetSubscriptionDefinitionRequest, GetSubscriptionDefinitionResponse, GetSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a subscription definition version.
 */
export declare const getSubscriptionDefinitionVersion: API.OperationMethod<GetSubscriptionDefinitionVersionRequest, GetSubscriptionDefinitionVersionResponse, GetSubscriptionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetThingRuntimeConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Get the runtime configuration of a thing.
 */
export declare const getThingRuntimeConfiguration: API.OperationMethod<GetThingRuntimeConfigurationRequest, GetThingRuntimeConfigurationResponse, GetThingRuntimeConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListBulkDeploymentDetailedReportsError = BadRequestException | CommonErrors;
/**
 * Gets a paginated list of the deployments that have been started in a bulk deployment operation, and their current deployment status.
 */
export declare const listBulkDeploymentDetailedReports: API.OperationMethod<ListBulkDeploymentDetailedReportsRequest, ListBulkDeploymentDetailedReportsResponse, ListBulkDeploymentDetailedReportsError, Credentials | HttpClient.HttpClient>;
export type ListBulkDeploymentsError = BadRequestException | CommonErrors;
/**
 * Returns a list of bulk deployments.
 */
export declare const listBulkDeployments: API.OperationMethod<ListBulkDeploymentsRequest, ListBulkDeploymentsResponse, ListBulkDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListConnectorDefinitionsError = CommonErrors;
/**
 * Retrieves a list of connector definitions.
 */
export declare const listConnectorDefinitions: API.OperationMethod<ListConnectorDefinitionsRequest, ListConnectorDefinitionsResponse, ListConnectorDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListConnectorDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a connector definition, which are containers for connectors. Connectors run on the Greengrass core and contain built-in integration with local infrastructure, device protocols, AWS, and other cloud services.
 */
export declare const listConnectorDefinitionVersions: API.OperationMethod<ListConnectorDefinitionVersionsRequest, ListConnectorDefinitionVersionsResponse, ListConnectorDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListCoreDefinitionsError = CommonErrors;
/**
 * Retrieves a list of core definitions.
 */
export declare const listCoreDefinitions: API.OperationMethod<ListCoreDefinitionsRequest, ListCoreDefinitionsResponse, ListCoreDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListCoreDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a core definition.
 */
export declare const listCoreDefinitionVersions: API.OperationMethod<ListCoreDefinitionVersionsRequest, ListCoreDefinitionVersionsResponse, ListCoreDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListDeploymentsError = BadRequestException | CommonErrors;
/**
 * Returns a history of deployments for the group.
 */
export declare const listDeployments: API.OperationMethod<ListDeploymentsRequest, ListDeploymentsResponse, ListDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListDeviceDefinitionsError = CommonErrors;
/**
 * Retrieves a list of device definitions.
 */
export declare const listDeviceDefinitions: API.OperationMethod<ListDeviceDefinitionsRequest, ListDeviceDefinitionsResponse, ListDeviceDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListDeviceDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a device definition.
 */
export declare const listDeviceDefinitionVersions: API.OperationMethod<ListDeviceDefinitionVersionsRequest, ListDeviceDefinitionVersionsResponse, ListDeviceDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListFunctionDefinitionsError = CommonErrors;
/**
 * Retrieves a list of Lambda function definitions.
 */
export declare const listFunctionDefinitions: API.OperationMethod<ListFunctionDefinitionsRequest, ListFunctionDefinitionsResponse, ListFunctionDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListFunctionDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a Lambda function definition.
 */
export declare const listFunctionDefinitionVersions: API.OperationMethod<ListFunctionDefinitionVersionsRequest, ListFunctionDefinitionVersionsResponse, ListFunctionDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListGroupCertificateAuthoritiesError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the current CAs for a group.
 */
export declare const listGroupCertificateAuthorities: API.OperationMethod<ListGroupCertificateAuthoritiesRequest, ListGroupCertificateAuthoritiesResponse, ListGroupCertificateAuthoritiesError, Credentials | HttpClient.HttpClient>;
export type ListGroupsError = CommonErrors;
/**
 * Retrieves a list of groups.
 */
export declare const listGroups: API.OperationMethod<ListGroupsRequest, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient>;
export type ListGroupVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a group.
 */
export declare const listGroupVersions: API.OperationMethod<ListGroupVersionsRequest, ListGroupVersionsResponse, ListGroupVersionsError, Credentials | HttpClient.HttpClient>;
export type ListLoggerDefinitionsError = CommonErrors;
/**
 * Retrieves a list of logger definitions.
 */
export declare const listLoggerDefinitions: API.OperationMethod<ListLoggerDefinitionsRequest, ListLoggerDefinitionsResponse, ListLoggerDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListLoggerDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a logger definition.
 */
export declare const listLoggerDefinitionVersions: API.OperationMethod<ListLoggerDefinitionVersionsRequest, ListLoggerDefinitionVersionsResponse, ListLoggerDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListResourceDefinitionsError = CommonErrors;
/**
 * Retrieves a list of resource definitions.
 */
export declare const listResourceDefinitions: API.OperationMethod<ListResourceDefinitionsRequest, ListResourceDefinitionsResponse, ListResourceDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListResourceDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a resource definition.
 */
export declare const listResourceDefinitionVersions: API.OperationMethod<ListResourceDefinitionVersionsRequest, ListResourceDefinitionVersionsResponse, ListResourceDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListSubscriptionDefinitionsError = CommonErrors;
/**
 * Retrieves a list of subscription definitions.
 */
export declare const listSubscriptionDefinitions: API.OperationMethod<ListSubscriptionDefinitionsRequest, ListSubscriptionDefinitionsResponse, ListSubscriptionDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListSubscriptionDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a subscription definition.
 */
export declare const listSubscriptionDefinitionVersions: API.OperationMethod<ListSubscriptionDefinitionVersionsRequest, ListSubscriptionDefinitionVersionsResponse, ListSubscriptionDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | CommonErrors;
/**
 * Retrieves a list of resource tags for a resource arn.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResetDeploymentsError = BadRequestException | CommonErrors;
/**
 * Resets a group's deployments.
 */
export declare const resetDeployments: API.OperationMethod<ResetDeploymentsRequest, ResetDeploymentsResponse, ResetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type StartBulkDeploymentError = BadRequestException | CommonErrors;
/**
 * Deploys multiple groups in one operation. This action starts the bulk deployment of a specified set of group versions. Each group version deployment will be triggered with an adaptive rate that has a fixed upper limit. We recommend that you include an ''X-Amzn-Client-Token'' token in every ''StartBulkDeployment'' request. These requests are idempotent with respect to the token and the request parameters.
 */
export declare const startBulkDeployment: API.OperationMethod<StartBulkDeploymentRequest, StartBulkDeploymentResponse, StartBulkDeploymentError, Credentials | HttpClient.HttpClient>;
export type StopBulkDeploymentError = BadRequestException | CommonErrors;
/**
 * Stops the execution of a bulk deployment. This action returns a status of ''Stopping'' until the deployment is stopped. You cannot start a new bulk deployment while a previous deployment is in the ''Stopping'' state. This action doesn't rollback completed deployments or cancel pending deployments.
 */
export declare const stopBulkDeployment: API.OperationMethod<StopBulkDeploymentRequest, StopBulkDeploymentResponse, StopBulkDeploymentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | CommonErrors;
/**
 * Adds tags to a Greengrass resource. Valid resources are 'Group', 'ConnectorDefinition', 'CoreDefinition', 'DeviceDefinition', 'FunctionDefinition', 'LoggerDefinition', 'SubscriptionDefinition', 'ResourceDefinition', and 'BulkDeployment'.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | CommonErrors;
/**
 * Remove resource tags from a Greengrass Resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectivityInfoError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the connectivity information for the core. Any devices that belong to the group which has this core will receive this information in order to find the location of the core and connect to it.
 */
export declare const updateConnectivityInfo: API.OperationMethod<UpdateConnectivityInfoRequest, UpdateConnectivityInfoResponse, UpdateConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a connector definition.
 */
export declare const updateConnectorDefinition: API.OperationMethod<UpdateConnectorDefinitionRequest, UpdateConnectorDefinitionResponse, UpdateConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a core definition.
 */
export declare const updateCoreDefinition: API.OperationMethod<UpdateCoreDefinitionRequest, UpdateCoreDefinitionResponse, UpdateCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a device definition.
 */
export declare const updateDeviceDefinition: API.OperationMethod<UpdateDeviceDefinitionRequest, UpdateDeviceDefinitionResponse, UpdateDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a Lambda function definition.
 */
export declare const updateFunctionDefinition: API.OperationMethod<UpdateFunctionDefinitionRequest, UpdateFunctionDefinitionResponse, UpdateFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = BadRequestException | CommonErrors;
/**
 * Updates a group.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupCertificateConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the Certificate expiry time for a group.
 */
export declare const updateGroupCertificateConfiguration: API.OperationMethod<UpdateGroupCertificateConfigurationRequest, UpdateGroupCertificateConfigurationResponse, UpdateGroupCertificateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a logger definition.
 */
export declare const updateLoggerDefinition: API.OperationMethod<UpdateLoggerDefinitionRequest, UpdateLoggerDefinitionResponse, UpdateLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a resource definition.
 */
export declare const updateResourceDefinition: API.OperationMethod<UpdateResourceDefinitionRequest, UpdateResourceDefinitionResponse, UpdateResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a subscription definition.
 */
export declare const updateSubscriptionDefinition: API.OperationMethod<UpdateSubscriptionDefinitionRequest, UpdateSubscriptionDefinitionResponse, UpdateSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateThingRuntimeConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the runtime configuration of a thing.
 */
export declare const updateThingRuntimeConfiguration: API.OperationMethod<UpdateThingRuntimeConfigurationRequest, UpdateThingRuntimeConfigurationResponse, UpdateThingRuntimeConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=greengrass.d.ts.map