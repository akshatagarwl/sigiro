import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ApiKeyLimitExceededException_base: S.Class<ApiKeyLimitExceededException, S.TaggedStruct<"ApiKeyLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ApiKeyLimitExceededException extends /*@__PURE__*/ ApiKeyLimitExceededException_base {
}
declare const ApiKeyValidityOutOfBoundsException_base: S.Class<ApiKeyValidityOutOfBoundsException, S.TaggedStruct<"ApiKeyValidityOutOfBoundsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ApiKeyValidityOutOfBoundsException extends /*@__PURE__*/ ApiKeyValidityOutOfBoundsException_base {
}
declare const ApiLimitExceededException_base: S.Class<ApiLimitExceededException, S.TaggedStruct<"ApiLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ApiLimitExceededException extends /*@__PURE__*/ ApiLimitExceededException_base {
}
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
    readonly reason: any;
    readonly detail: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const GraphQLSchemaException_base: S.Class<GraphQLSchemaException, S.TaggedStruct<"GraphQLSchemaException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GraphQLSchemaException extends /*@__PURE__*/ GraphQLSchemaException_base {
}
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type DomainName = string;
export interface AssociateApiRequest {
    domainName: string;
    apiId: string;
}
export declare const AssociateApiRequest: S.Schema<AssociateApiRequest>;
export type AssociationStatus = "PROCESSING" | "FAILED" | "SUCCESS" | (string & {});
export declare const AssociationStatus: any;
export interface ApiAssociation {
    domainName?: string;
    apiId?: string;
    associationStatus?: AssociationStatus;
    deploymentDetail?: string;
}
export declare const ApiAssociation: S.Schema<ApiAssociation>;
export interface AssociateApiResponse {
    apiAssociation?: ApiAssociation;
}
export declare const AssociateApiResponse: S.Schema<AssociateApiResponse>;
export type MergeType = "MANUAL_MERGE" | "AUTO_MERGE" | (string & {});
export declare const MergeType: any;
export interface SourceApiAssociationConfig {
    mergeType?: MergeType;
}
export declare const SourceApiAssociationConfig: S.Schema<SourceApiAssociationConfig>;
export interface AssociateMergedGraphqlApiRequest {
    sourceApiIdentifier: string;
    mergedApiIdentifier: string;
    description?: string;
    sourceApiAssociationConfig?: SourceApiAssociationConfig;
}
export declare const AssociateMergedGraphqlApiRequest: S.Schema<AssociateMergedGraphqlApiRequest>;
export type SourceApiAssociationStatus = "MERGE_SCHEDULED" | "MERGE_FAILED" | "MERGE_SUCCESS" | "MERGE_IN_PROGRESS" | "AUTO_MERGE_SCHEDULE_FAILED" | "DELETION_SCHEDULED" | "DELETION_IN_PROGRESS" | "DELETION_FAILED" | (string & {});
export declare const SourceApiAssociationStatus: any;
export interface SourceApiAssociation {
    associationId?: string;
    associationArn?: string;
    sourceApiId?: string;
    sourceApiArn?: string;
    mergedApiArn?: string;
    mergedApiId?: string;
    description?: string;
    sourceApiAssociationConfig?: SourceApiAssociationConfig;
    sourceApiAssociationStatus?: SourceApiAssociationStatus;
    sourceApiAssociationStatusDetail?: string;
    lastSuccessfulMergeDate?: Date;
}
export declare const SourceApiAssociation: S.Schema<SourceApiAssociation>;
export interface AssociateMergedGraphqlApiResponse {
    sourceApiAssociation?: SourceApiAssociation;
}
export declare const AssociateMergedGraphqlApiResponse: S.Schema<AssociateMergedGraphqlApiResponse>;
export interface AssociateSourceGraphqlApiRequest {
    mergedApiIdentifier: string;
    sourceApiIdentifier: string;
    description?: string;
    sourceApiAssociationConfig?: SourceApiAssociationConfig;
}
export declare const AssociateSourceGraphqlApiRequest: S.Schema<AssociateSourceGraphqlApiRequest>;
export interface AssociateSourceGraphqlApiResponse {
    sourceApiAssociation?: SourceApiAssociation;
}
export declare const AssociateSourceGraphqlApiResponse: S.Schema<AssociateSourceGraphqlApiResponse>;
export type ApiName = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type AuthenticationType = "API_KEY" | "AWS_IAM" | "AMAZON_COGNITO_USER_POOLS" | "OPENID_CONNECT" | "AWS_LAMBDA" | (string & {});
export declare const AuthenticationType: any;
export interface CognitoConfig {
    userPoolId: string;
    awsRegion: string;
    appIdClientRegex?: string;
}
export declare const CognitoConfig: S.Schema<CognitoConfig>;
export interface OpenIDConnectConfig {
    issuer: string;
    clientId?: string;
    iatTTL?: number;
    authTTL?: number;
}
export declare const OpenIDConnectConfig: S.Schema<OpenIDConnectConfig>;
export type TTL = number;
export interface LambdaAuthorizerConfig {
    authorizerResultTtlInSeconds?: number;
    authorizerUri: string;
    identityValidationExpression?: string;
}
export declare const LambdaAuthorizerConfig: S.Schema<LambdaAuthorizerConfig>;
export interface AuthProvider {
    authType: AuthenticationType;
    cognitoConfig?: CognitoConfig;
    openIDConnectConfig?: OpenIDConnectConfig;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig;
}
export declare const AuthProvider: S.Schema<AuthProvider>;
export type AuthProviders = AuthProvider[];
export declare const AuthProviders: any;
export interface AuthMode {
    authType: AuthenticationType;
}
export declare const AuthMode: S.Schema<AuthMode>;
export type AuthModes = AuthMode[];
export declare const AuthModes: any;
export type EventLogLevel = "NONE" | "ERROR" | "ALL" | "INFO" | "DEBUG" | (string & {});
export declare const EventLogLevel: any;
export interface EventLogConfig {
    logLevel: EventLogLevel;
    cloudWatchLogsRoleArn: string;
}
export declare const EventLogConfig: S.Schema<EventLogConfig>;
export interface EventConfig {
    authProviders: AuthProvider[];
    connectionAuthModes: AuthMode[];
    defaultPublishAuthModes: AuthMode[];
    defaultSubscribeAuthModes: AuthMode[];
    logConfig?: EventLogConfig;
}
export declare const EventConfig: S.Schema<EventConfig>;
export interface CreateApiRequest {
    name: string;
    ownerContact?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    eventConfig: EventConfig;
}
export declare const CreateApiRequest: S.Schema<CreateApiRequest>;
export type OwnerContact = string;
export type MapOfStringToString = {
    [key: string]: string | undefined;
};
export declare const MapOfStringToString: any;
export interface Api {
    apiId?: string;
    name?: string;
    ownerContact?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    dns?: {
        [key: string]: string | undefined;
    };
    apiArn?: string;
    created?: Date;
    xrayEnabled?: boolean;
    wafWebAclArn?: string;
    eventConfig?: EventConfig;
}
export declare const Api: S.Schema<Api>;
export interface CreateApiResponse {
    api?: Api;
}
export declare const CreateApiResponse: S.Schema<CreateApiResponse>;
export type ApiCachingBehavior = "FULL_REQUEST_CACHING" | "PER_RESOLVER_CACHING" | "OPERATION_LEVEL_CACHING" | (string & {});
export declare const ApiCachingBehavior: any;
export type ApiCacheType = "T2_SMALL" | "T2_MEDIUM" | "R4_LARGE" | "R4_XLARGE" | "R4_2XLARGE" | "R4_4XLARGE" | "R4_8XLARGE" | "SMALL" | "MEDIUM" | "LARGE" | "XLARGE" | "LARGE_2X" | "LARGE_4X" | "LARGE_8X" | "LARGE_12X" | (string & {});
export declare const ApiCacheType: any;
export type CacheHealthMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export declare const CacheHealthMetricsConfig: any;
export interface CreateApiCacheRequest {
    apiId: string;
    ttl: number;
    transitEncryptionEnabled?: boolean;
    atRestEncryptionEnabled?: boolean;
    apiCachingBehavior: ApiCachingBehavior;
    type: ApiCacheType;
    healthMetricsConfig?: CacheHealthMetricsConfig;
}
export declare const CreateApiCacheRequest: S.Schema<CreateApiCacheRequest>;
export type ApiCacheStatus = "AVAILABLE" | "CREATING" | "DELETING" | "MODIFYING" | "FAILED" | (string & {});
export declare const ApiCacheStatus: any;
export interface ApiCache {
    ttl?: number;
    apiCachingBehavior?: ApiCachingBehavior;
    transitEncryptionEnabled?: boolean;
    atRestEncryptionEnabled?: boolean;
    type?: ApiCacheType;
    status?: ApiCacheStatus;
    healthMetricsConfig?: CacheHealthMetricsConfig;
}
export declare const ApiCache: S.Schema<ApiCache>;
export interface CreateApiCacheResponse {
    apiCache?: ApiCache;
}
export declare const CreateApiCacheResponse: S.Schema<CreateApiCacheResponse>;
export interface CreateApiKeyRequest {
    apiId: string;
    description?: string;
    expires?: number;
}
export declare const CreateApiKeyRequest: S.Schema<CreateApiKeyRequest>;
export interface ApiKey {
    id?: string;
    description?: string;
    expires?: number;
    deletes?: number;
}
export declare const ApiKey: S.Schema<ApiKey>;
export interface CreateApiKeyResponse {
    apiKey?: ApiKey;
}
export declare const CreateApiKeyResponse: S.Schema<CreateApiKeyResponse>;
export type Namespace = string;
export type Code = string;
export type HandlerBehavior = "CODE" | "DIRECT" | (string & {});
export declare const HandlerBehavior: any;
export type InvokeType = "REQUEST_RESPONSE" | "EVENT" | (string & {});
export declare const InvokeType: any;
export interface LambdaConfig {
    invokeType?: InvokeType;
}
export declare const LambdaConfig: S.Schema<LambdaConfig>;
export interface Integration {
    dataSourceName: string;
    lambdaConfig?: LambdaConfig;
}
export declare const Integration: S.Schema<Integration>;
export interface HandlerConfig {
    behavior: HandlerBehavior;
    integration: Integration;
}
export declare const HandlerConfig: S.Schema<HandlerConfig>;
export interface HandlerConfigs {
    onPublish?: HandlerConfig;
    onSubscribe?: HandlerConfig;
}
export declare const HandlerConfigs: S.Schema<HandlerConfigs>;
export interface CreateChannelNamespaceRequest {
    apiId: string;
    name: string;
    subscribeAuthModes?: AuthMode[];
    publishAuthModes?: AuthMode[];
    codeHandlers?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    handlerConfigs?: HandlerConfigs;
}
export declare const CreateChannelNamespaceRequest: S.Schema<CreateChannelNamespaceRequest>;
export interface ChannelNamespace {
    apiId?: string;
    name?: string;
    subscribeAuthModes?: AuthMode[];
    publishAuthModes?: AuthMode[];
    codeHandlers?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    channelNamespaceArn?: string;
    created?: Date;
    lastModified?: Date;
    handlerConfigs?: HandlerConfigs;
}
export declare const ChannelNamespace: S.Schema<ChannelNamespace>;
export interface CreateChannelNamespaceResponse {
    channelNamespace?: ChannelNamespace;
}
export declare const CreateChannelNamespaceResponse: S.Schema<CreateChannelNamespaceResponse>;
export type ResourceName = string;
export type DataSourceType = "AWS_LAMBDA" | "AMAZON_DYNAMODB" | "AMAZON_ELASTICSEARCH" | "NONE" | "HTTP" | "RELATIONAL_DATABASE" | "AMAZON_OPENSEARCH_SERVICE" | "AMAZON_EVENTBRIDGE" | "AMAZON_BEDROCK_RUNTIME" | (string & {});
export declare const DataSourceType: any;
export interface DeltaSyncConfig {
    baseTableTTL?: number;
    deltaSyncTableName?: string;
    deltaSyncTableTTL?: number;
}
export declare const DeltaSyncConfig: S.Schema<DeltaSyncConfig>;
export interface DynamodbDataSourceConfig {
    tableName: string;
    awsRegion: string;
    useCallerCredentials?: boolean;
    deltaSyncConfig?: DeltaSyncConfig;
    versioned?: boolean;
}
export declare const DynamodbDataSourceConfig: S.Schema<DynamodbDataSourceConfig>;
export interface LambdaDataSourceConfig {
    lambdaFunctionArn: string;
}
export declare const LambdaDataSourceConfig: S.Schema<LambdaDataSourceConfig>;
export interface ElasticsearchDataSourceConfig {
    endpoint: string;
    awsRegion: string;
}
export declare const ElasticsearchDataSourceConfig: S.Schema<ElasticsearchDataSourceConfig>;
export interface OpenSearchServiceDataSourceConfig {
    endpoint: string;
    awsRegion: string;
}
export declare const OpenSearchServiceDataSourceConfig: S.Schema<OpenSearchServiceDataSourceConfig>;
export type AuthorizationType = "AWS_IAM" | (string & {});
export declare const AuthorizationType: any;
export interface AwsIamConfig {
    signingRegion?: string;
    signingServiceName?: string;
}
export declare const AwsIamConfig: S.Schema<AwsIamConfig>;
export interface AuthorizationConfig {
    authorizationType: AuthorizationType;
    awsIamConfig?: AwsIamConfig;
}
export declare const AuthorizationConfig: S.Schema<AuthorizationConfig>;
export interface HttpDataSourceConfig {
    endpoint?: string;
    authorizationConfig?: AuthorizationConfig;
}
export declare const HttpDataSourceConfig: S.Schema<HttpDataSourceConfig>;
export type RelationalDatabaseSourceType = "RDS_HTTP_ENDPOINT" | (string & {});
export declare const RelationalDatabaseSourceType: any;
export interface RdsHttpEndpointConfig {
    awsRegion?: string;
    dbClusterIdentifier?: string;
    databaseName?: string;
    schema?: string;
    awsSecretStoreArn?: string;
}
export declare const RdsHttpEndpointConfig: S.Schema<RdsHttpEndpointConfig>;
export interface RelationalDatabaseDataSourceConfig {
    relationalDatabaseSourceType?: RelationalDatabaseSourceType;
    rdsHttpEndpointConfig?: RdsHttpEndpointConfig;
}
export declare const RelationalDatabaseDataSourceConfig: S.Schema<RelationalDatabaseDataSourceConfig>;
export interface EventBridgeDataSourceConfig {
    eventBusArn: string;
}
export declare const EventBridgeDataSourceConfig: S.Schema<EventBridgeDataSourceConfig>;
export type DataSourceLevelMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export declare const DataSourceLevelMetricsConfig: any;
export interface CreateDataSourceRequest {
    apiId: string;
    name: string;
    description?: string;
    type: DataSourceType;
    serviceRoleArn?: string;
    dynamodbConfig?: DynamodbDataSourceConfig;
    lambdaConfig?: LambdaDataSourceConfig;
    elasticsearchConfig?: ElasticsearchDataSourceConfig;
    openSearchServiceConfig?: OpenSearchServiceDataSourceConfig;
    httpConfig?: HttpDataSourceConfig;
    relationalDatabaseConfig?: RelationalDatabaseDataSourceConfig;
    eventBridgeConfig?: EventBridgeDataSourceConfig;
    metricsConfig?: DataSourceLevelMetricsConfig;
}
export declare const CreateDataSourceRequest: S.Schema<CreateDataSourceRequest>;
export interface DataSource {
    dataSourceArn?: string;
    name?: string;
    description?: string;
    type?: DataSourceType;
    serviceRoleArn?: string;
    dynamodbConfig?: DynamodbDataSourceConfig;
    lambdaConfig?: LambdaDataSourceConfig;
    elasticsearchConfig?: ElasticsearchDataSourceConfig;
    openSearchServiceConfig?: OpenSearchServiceDataSourceConfig;
    httpConfig?: HttpDataSourceConfig;
    relationalDatabaseConfig?: RelationalDatabaseDataSourceConfig;
    eventBridgeConfig?: EventBridgeDataSourceConfig;
    metricsConfig?: DataSourceLevelMetricsConfig;
}
export declare const DataSource: S.Schema<DataSource>;
export interface CreateDataSourceResponse {
    dataSource?: DataSource;
}
export declare const CreateDataSourceResponse: S.Schema<CreateDataSourceResponse>;
export type CertificateArn = string;
export type Description = string;
export interface CreateDomainNameRequest {
    domainName: string;
    certificateArn: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDomainNameRequest: S.Schema<CreateDomainNameRequest>;
export interface DomainNameConfig {
    domainName?: string;
    description?: string;
    certificateArn?: string;
    appsyncDomainName?: string;
    hostedZoneId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    domainNameArn?: string;
}
export declare const DomainNameConfig: S.Schema<DomainNameConfig>;
export interface CreateDomainNameResponse {
    domainNameConfig?: DomainNameConfig;
}
export declare const CreateDomainNameResponse: S.Schema<CreateDomainNameResponse>;
export type MappingTemplate = string;
export type ConflictHandlerType = "OPTIMISTIC_CONCURRENCY" | "LAMBDA" | "AUTOMERGE" | "NONE" | (string & {});
export declare const ConflictHandlerType: any;
export type ConflictDetectionType = "VERSION" | "NONE" | (string & {});
export declare const ConflictDetectionType: any;
export interface LambdaConflictHandlerConfig {
    lambdaConflictHandlerArn?: string;
}
export declare const LambdaConflictHandlerConfig: S.Schema<LambdaConflictHandlerConfig>;
export interface SyncConfig {
    conflictHandler?: ConflictHandlerType;
    conflictDetection?: ConflictDetectionType;
    lambdaConflictHandlerConfig?: LambdaConflictHandlerConfig;
}
export declare const SyncConfig: S.Schema<SyncConfig>;
export type MaxBatchSize = number;
export type RuntimeName = "APPSYNC_JS" | (string & {});
export declare const RuntimeName: any;
export interface AppSyncRuntime {
    name: RuntimeName;
    runtimeVersion: string;
}
export declare const AppSyncRuntime: S.Schema<AppSyncRuntime>;
export interface CreateFunctionRequest {
    apiId: string;
    name: string;
    description?: string;
    dataSourceName: string;
    requestMappingTemplate?: string;
    responseMappingTemplate?: string;
    functionVersion?: string;
    syncConfig?: SyncConfig;
    maxBatchSize?: number;
    runtime?: AppSyncRuntime;
    code?: string;
}
export declare const CreateFunctionRequest: S.Schema<CreateFunctionRequest>;
export interface FunctionConfiguration {
    functionId?: string;
    functionArn?: string;
    name?: string;
    description?: string;
    dataSourceName?: string;
    requestMappingTemplate?: string;
    responseMappingTemplate?: string;
    functionVersion?: string;
    syncConfig?: SyncConfig;
    maxBatchSize?: number;
    runtime?: AppSyncRuntime;
    code?: string;
}
export declare const FunctionConfiguration: S.Schema<FunctionConfiguration>;
export interface CreateFunctionResponse {
    functionConfiguration?: FunctionConfiguration;
}
export declare const CreateFunctionResponse: S.Schema<CreateFunctionResponse>;
export type FieldLogLevel = "NONE" | "ERROR" | "ALL" | "INFO" | "DEBUG" | (string & {});
export declare const FieldLogLevel: any;
export interface LogConfig {
    fieldLogLevel: FieldLogLevel;
    cloudWatchLogsRoleArn: string;
    excludeVerboseContent?: boolean;
}
export declare const LogConfig: S.Schema<LogConfig>;
export type DefaultAction = "ALLOW" | "DENY" | (string & {});
export declare const DefaultAction: any;
export interface UserPoolConfig {
    userPoolId: string;
    awsRegion: string;
    defaultAction: DefaultAction;
    appIdClientRegex?: string;
}
export declare const UserPoolConfig: S.Schema<UserPoolConfig>;
export interface CognitoUserPoolConfig {
    userPoolId: string;
    awsRegion: string;
    appIdClientRegex?: string;
}
export declare const CognitoUserPoolConfig: S.Schema<CognitoUserPoolConfig>;
export interface AdditionalAuthenticationProvider {
    authenticationType?: AuthenticationType;
    openIDConnectConfig?: OpenIDConnectConfig;
    userPoolConfig?: CognitoUserPoolConfig;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig;
}
export declare const AdditionalAuthenticationProvider: S.Schema<AdditionalAuthenticationProvider>;
export type AdditionalAuthenticationProviders = AdditionalAuthenticationProvider[];
export declare const AdditionalAuthenticationProviders: any;
export type GraphQLApiType = "GRAPHQL" | "MERGED" | (string & {});
export declare const GraphQLApiType: any;
export type GraphQLApiVisibility = "GLOBAL" | "PRIVATE" | (string & {});
export declare const GraphQLApiVisibility: any;
export type GraphQLApiIntrospectionConfig = "ENABLED" | "DISABLED" | (string & {});
export declare const GraphQLApiIntrospectionConfig: any;
export type QueryDepthLimit = number;
export type ResolverCountLimit = number;
export type ResolverLevelMetricsBehavior = "FULL_REQUEST_RESOLVER_METRICS" | "PER_RESOLVER_METRICS" | (string & {});
export declare const ResolverLevelMetricsBehavior: any;
export type DataSourceLevelMetricsBehavior = "FULL_REQUEST_DATA_SOURCE_METRICS" | "PER_DATA_SOURCE_METRICS" | (string & {});
export declare const DataSourceLevelMetricsBehavior: any;
export type OperationLevelMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export declare const OperationLevelMetricsConfig: any;
export interface EnhancedMetricsConfig {
    resolverLevelMetricsBehavior: ResolverLevelMetricsBehavior;
    dataSourceLevelMetricsBehavior: DataSourceLevelMetricsBehavior;
    operationLevelMetricsConfig: OperationLevelMetricsConfig;
}
export declare const EnhancedMetricsConfig: S.Schema<EnhancedMetricsConfig>;
export interface CreateGraphqlApiRequest {
    name: string;
    logConfig?: LogConfig;
    authenticationType: AuthenticationType;
    userPoolConfig?: UserPoolConfig;
    openIDConnectConfig?: OpenIDConnectConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    additionalAuthenticationProviders?: AdditionalAuthenticationProvider[];
    xrayEnabled?: boolean;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig;
    apiType?: GraphQLApiType;
    mergedApiExecutionRoleArn?: string;
    visibility?: GraphQLApiVisibility;
    ownerContact?: string;
    introspectionConfig?: GraphQLApiIntrospectionConfig;
    queryDepthLimit?: number;
    resolverCountLimit?: number;
    enhancedMetricsConfig?: EnhancedMetricsConfig;
}
export declare const CreateGraphqlApiRequest: S.Schema<CreateGraphqlApiRequest>;
export interface GraphqlApi {
    name?: string;
    apiId?: string;
    authenticationType?: AuthenticationType;
    logConfig?: LogConfig;
    userPoolConfig?: UserPoolConfig;
    openIDConnectConfig?: OpenIDConnectConfig;
    arn?: string;
    uris?: {
        [key: string]: string | undefined;
    };
    tags?: {
        [key: string]: string | undefined;
    };
    additionalAuthenticationProviders?: AdditionalAuthenticationProvider[];
    xrayEnabled?: boolean;
    wafWebAclArn?: string;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig;
    dns?: {
        [key: string]: string | undefined;
    };
    visibility?: GraphQLApiVisibility;
    apiType?: GraphQLApiType;
    mergedApiExecutionRoleArn?: string;
    owner?: string;
    ownerContact?: string;
    introspectionConfig?: GraphQLApiIntrospectionConfig;
    queryDepthLimit?: number;
    resolverCountLimit?: number;
    enhancedMetricsConfig?: EnhancedMetricsConfig;
}
export declare const GraphqlApi: S.Schema<GraphqlApi>;
export interface CreateGraphqlApiResponse {
    graphqlApi?: GraphqlApi;
}
export declare const CreateGraphqlApiResponse: S.Schema<CreateGraphqlApiResponse>;
export type ResolverKind = "UNIT" | "PIPELINE" | (string & {});
export declare const ResolverKind: any;
export type FunctionsIds = string[];
export declare const FunctionsIds: any;
export interface PipelineConfig {
    functions?: string[];
}
export declare const PipelineConfig: S.Schema<PipelineConfig>;
export type CachingKeys = string[];
export declare const CachingKeys: any;
export interface CachingConfig {
    ttl: number;
    cachingKeys?: string[];
}
export declare const CachingConfig: S.Schema<CachingConfig>;
export type ResolverLevelMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export declare const ResolverLevelMetricsConfig: any;
export interface CreateResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
    dataSourceName?: string;
    requestMappingTemplate?: string;
    responseMappingTemplate?: string;
    kind?: ResolverKind;
    pipelineConfig?: PipelineConfig;
    syncConfig?: SyncConfig;
    cachingConfig?: CachingConfig;
    maxBatchSize?: number;
    runtime?: AppSyncRuntime;
    code?: string;
    metricsConfig?: ResolverLevelMetricsConfig;
}
export declare const CreateResolverRequest: S.Schema<CreateResolverRequest>;
export interface Resolver {
    typeName?: string;
    fieldName?: string;
    dataSourceName?: string;
    resolverArn?: string;
    requestMappingTemplate?: string;
    responseMappingTemplate?: string;
    kind?: ResolverKind;
    pipelineConfig?: PipelineConfig;
    syncConfig?: SyncConfig;
    cachingConfig?: CachingConfig;
    maxBatchSize?: number;
    runtime?: AppSyncRuntime;
    code?: string;
    metricsConfig?: ResolverLevelMetricsConfig;
}
export declare const Resolver: S.Schema<Resolver>;
export interface CreateResolverResponse {
    resolver?: Resolver;
}
export declare const CreateResolverResponse: S.Schema<CreateResolverResponse>;
export type TypeDefinitionFormat = "SDL" | "JSON" | (string & {});
export declare const TypeDefinitionFormat: any;
export interface CreateTypeRequest {
    apiId: string;
    definition: string;
    format: TypeDefinitionFormat;
}
export declare const CreateTypeRequest: S.Schema<CreateTypeRequest>;
export interface Type {
    name?: string;
    description?: string;
    arn?: string;
    definition?: string;
    format?: TypeDefinitionFormat;
}
export declare const Type: S.Schema<Type>;
export interface CreateTypeResponse {
    type?: Type;
}
export declare const CreateTypeResponse: S.Schema<CreateTypeResponse>;
export interface DeleteApiRequest {
    apiId: string;
}
export declare const DeleteApiRequest: S.Schema<DeleteApiRequest>;
export interface DeleteApiResponse {
}
export declare const DeleteApiResponse: S.Schema<DeleteApiResponse>;
export interface DeleteApiCacheRequest {
    apiId: string;
}
export declare const DeleteApiCacheRequest: S.Schema<DeleteApiCacheRequest>;
export interface DeleteApiCacheResponse {
}
export declare const DeleteApiCacheResponse: S.Schema<DeleteApiCacheResponse>;
export interface DeleteApiKeyRequest {
    apiId: string;
    id: string;
}
export declare const DeleteApiKeyRequest: S.Schema<DeleteApiKeyRequest>;
export interface DeleteApiKeyResponse {
}
export declare const DeleteApiKeyResponse: S.Schema<DeleteApiKeyResponse>;
export interface DeleteChannelNamespaceRequest {
    apiId: string;
    name: string;
}
export declare const DeleteChannelNamespaceRequest: S.Schema<DeleteChannelNamespaceRequest>;
export interface DeleteChannelNamespaceResponse {
}
export declare const DeleteChannelNamespaceResponse: S.Schema<DeleteChannelNamespaceResponse>;
export interface DeleteDataSourceRequest {
    apiId: string;
    name: string;
}
export declare const DeleteDataSourceRequest: S.Schema<DeleteDataSourceRequest>;
export interface DeleteDataSourceResponse {
}
export declare const DeleteDataSourceResponse: S.Schema<DeleteDataSourceResponse>;
export interface DeleteDomainNameRequest {
    domainName: string;
}
export declare const DeleteDomainNameRequest: S.Schema<DeleteDomainNameRequest>;
export interface DeleteDomainNameResponse {
}
export declare const DeleteDomainNameResponse: S.Schema<DeleteDomainNameResponse>;
export interface DeleteFunctionRequest {
    apiId: string;
    functionId: string;
}
export declare const DeleteFunctionRequest: S.Schema<DeleteFunctionRequest>;
export interface DeleteFunctionResponse {
}
export declare const DeleteFunctionResponse: S.Schema<DeleteFunctionResponse>;
export interface DeleteGraphqlApiRequest {
    apiId: string;
}
export declare const DeleteGraphqlApiRequest: S.Schema<DeleteGraphqlApiRequest>;
export interface DeleteGraphqlApiResponse {
}
export declare const DeleteGraphqlApiResponse: S.Schema<DeleteGraphqlApiResponse>;
export interface DeleteResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
}
export declare const DeleteResolverRequest: S.Schema<DeleteResolverRequest>;
export interface DeleteResolverResponse {
}
export declare const DeleteResolverResponse: S.Schema<DeleteResolverResponse>;
export interface DeleteTypeRequest {
    apiId: string;
    typeName: string;
}
export declare const DeleteTypeRequest: S.Schema<DeleteTypeRequest>;
export interface DeleteTypeResponse {
}
export declare const DeleteTypeResponse: S.Schema<DeleteTypeResponse>;
export interface DisassociateApiRequest {
    domainName: string;
}
export declare const DisassociateApiRequest: S.Schema<DisassociateApiRequest>;
export interface DisassociateApiResponse {
}
export declare const DisassociateApiResponse: S.Schema<DisassociateApiResponse>;
export interface DisassociateMergedGraphqlApiRequest {
    sourceApiIdentifier: string;
    associationId: string;
}
export declare const DisassociateMergedGraphqlApiRequest: S.Schema<DisassociateMergedGraphqlApiRequest>;
export interface DisassociateMergedGraphqlApiResponse {
    sourceApiAssociationStatus?: SourceApiAssociationStatus;
}
export declare const DisassociateMergedGraphqlApiResponse: S.Schema<DisassociateMergedGraphqlApiResponse>;
export interface DisassociateSourceGraphqlApiRequest {
    mergedApiIdentifier: string;
    associationId: string;
}
export declare const DisassociateSourceGraphqlApiRequest: S.Schema<DisassociateSourceGraphqlApiRequest>;
export interface DisassociateSourceGraphqlApiResponse {
    sourceApiAssociationStatus?: SourceApiAssociationStatus;
}
export declare const DisassociateSourceGraphqlApiResponse: S.Schema<DisassociateSourceGraphqlApiResponse>;
export type Context = string;
export interface EvaluateCodeRequest {
    runtime: AppSyncRuntime;
    code: string;
    context: string;
    function?: string;
}
export declare const EvaluateCodeRequest: S.Schema<EvaluateCodeRequest>;
export type EvaluationResult = string;
export type ErrorMessage = string;
export type CodeErrorLine = number;
export type CodeErrorColumn = number;
export type CodeErrorSpan = number;
export interface CodeErrorLocation {
    line?: number;
    column?: number;
    span?: number;
}
export declare const CodeErrorLocation: S.Schema<CodeErrorLocation>;
export interface CodeError {
    errorType?: string;
    value?: string;
    location?: CodeErrorLocation;
}
export declare const CodeError: S.Schema<CodeError>;
export type CodeErrors = CodeError[];
export declare const CodeErrors: any;
export interface EvaluateCodeErrorDetail {
    message?: string;
    codeErrors?: CodeError[];
}
export declare const EvaluateCodeErrorDetail: S.Schema<EvaluateCodeErrorDetail>;
export type Logs = string[];
export declare const Logs: any;
export type Stash = string;
export type OutErrors = string;
export interface EvaluateCodeResponse {
    evaluationResult?: string;
    error?: EvaluateCodeErrorDetail;
    logs?: string[];
    stash?: string;
    outErrors?: string;
}
export declare const EvaluateCodeResponse: S.Schema<EvaluateCodeResponse>;
export type Template = string;
export interface EvaluateMappingTemplateRequest {
    template: string;
    context: string;
}
export declare const EvaluateMappingTemplateRequest: S.Schema<EvaluateMappingTemplateRequest>;
export interface ErrorDetail {
    message?: string;
}
export declare const ErrorDetail: S.Schema<ErrorDetail>;
export interface EvaluateMappingTemplateResponse {
    evaluationResult?: string;
    error?: ErrorDetail;
    logs?: string[];
    stash?: string;
    outErrors?: string;
}
export declare const EvaluateMappingTemplateResponse: S.Schema<EvaluateMappingTemplateResponse>;
export interface FlushApiCacheRequest {
    apiId: string;
}
export declare const FlushApiCacheRequest: S.Schema<FlushApiCacheRequest>;
export interface FlushApiCacheResponse {
}
export declare const FlushApiCacheResponse: S.Schema<FlushApiCacheResponse>;
export interface GetApiRequest {
    apiId: string;
}
export declare const GetApiRequest: S.Schema<GetApiRequest>;
export interface GetApiResponse {
    api?: Api;
}
export declare const GetApiResponse: S.Schema<GetApiResponse>;
export interface GetApiAssociationRequest {
    domainName: string;
}
export declare const GetApiAssociationRequest: S.Schema<GetApiAssociationRequest>;
export interface GetApiAssociationResponse {
    apiAssociation?: ApiAssociation;
}
export declare const GetApiAssociationResponse: S.Schema<GetApiAssociationResponse>;
export interface GetApiCacheRequest {
    apiId: string;
}
export declare const GetApiCacheRequest: S.Schema<GetApiCacheRequest>;
export interface GetApiCacheResponse {
    apiCache?: ApiCache;
}
export declare const GetApiCacheResponse: S.Schema<GetApiCacheResponse>;
export interface GetChannelNamespaceRequest {
    apiId: string;
    name: string;
}
export declare const GetChannelNamespaceRequest: S.Schema<GetChannelNamespaceRequest>;
export interface GetChannelNamespaceResponse {
    channelNamespace?: ChannelNamespace;
}
export declare const GetChannelNamespaceResponse: S.Schema<GetChannelNamespaceResponse>;
export interface GetDataSourceRequest {
    apiId: string;
    name: string;
}
export declare const GetDataSourceRequest: S.Schema<GetDataSourceRequest>;
export interface GetDataSourceResponse {
    dataSource?: DataSource;
}
export declare const GetDataSourceResponse: S.Schema<GetDataSourceResponse>;
export type PaginationToken = string;
export type MaxResults = number;
export interface GetDataSourceIntrospectionRequest {
    introspectionId: string;
    includeModelsSDL?: boolean;
    nextToken?: string;
    maxResults?: number;
}
export declare const GetDataSourceIntrospectionRequest: S.Schema<GetDataSourceIntrospectionRequest>;
export type DataSourceIntrospectionStatus = "PROCESSING" | "FAILED" | "SUCCESS" | (string & {});
export declare const DataSourceIntrospectionStatus: any;
export type DataSourceIntrospectionModelFieldTypeValues = string[];
export declare const DataSourceIntrospectionModelFieldTypeValues: any;
export interface DataSourceIntrospectionModelFieldType {
    kind?: string;
    name?: string;
    type?: DataSourceIntrospectionModelFieldType;
    values?: string[];
}
export declare const DataSourceIntrospectionModelFieldType: S.Schema<DataSourceIntrospectionModelFieldType>;
export interface DataSourceIntrospectionModelField {
    name?: string;
    type?: DataSourceIntrospectionModelFieldType;
    length?: number;
}
export declare const DataSourceIntrospectionModelField: S.Schema<DataSourceIntrospectionModelField>;
export type DataSourceIntrospectionModelFields = DataSourceIntrospectionModelField[];
export declare const DataSourceIntrospectionModelFields: any;
export type DataSourceIntrospectionModelIndexFields = string[];
export declare const DataSourceIntrospectionModelIndexFields: any;
export interface DataSourceIntrospectionModelIndex {
    name?: string;
    fields?: string[];
}
export declare const DataSourceIntrospectionModelIndex: S.Schema<DataSourceIntrospectionModelIndex>;
export type DataSourceIntrospectionModelIndexes = DataSourceIntrospectionModelIndex[];
export declare const DataSourceIntrospectionModelIndexes: any;
export interface DataSourceIntrospectionModel {
    name?: string;
    fields?: DataSourceIntrospectionModelField[];
    primaryKey?: DataSourceIntrospectionModelIndex;
    indexes?: DataSourceIntrospectionModelIndex[];
    sdl?: string;
}
export declare const DataSourceIntrospectionModel: S.Schema<DataSourceIntrospectionModel>;
export type DataSourceIntrospectionModels = DataSourceIntrospectionModel[];
export declare const DataSourceIntrospectionModels: any;
export interface DataSourceIntrospectionResult {
    models?: DataSourceIntrospectionModel[];
    nextToken?: string;
}
export declare const DataSourceIntrospectionResult: S.Schema<DataSourceIntrospectionResult>;
export interface GetDataSourceIntrospectionResponse {
    introspectionId?: string;
    introspectionStatus?: DataSourceIntrospectionStatus;
    introspectionStatusDetail?: string;
    introspectionResult?: DataSourceIntrospectionResult;
}
export declare const GetDataSourceIntrospectionResponse: S.Schema<GetDataSourceIntrospectionResponse>;
export interface GetDomainNameRequest {
    domainName: string;
}
export declare const GetDomainNameRequest: S.Schema<GetDomainNameRequest>;
export interface GetDomainNameResponse {
    domainNameConfig?: DomainNameConfig;
}
export declare const GetDomainNameResponse: S.Schema<GetDomainNameResponse>;
export interface GetFunctionRequest {
    apiId: string;
    functionId: string;
}
export declare const GetFunctionRequest: S.Schema<GetFunctionRequest>;
export interface GetFunctionResponse {
    functionConfiguration?: FunctionConfiguration;
}
export declare const GetFunctionResponse: S.Schema<GetFunctionResponse>;
export interface GetGraphqlApiRequest {
    apiId: string;
}
export declare const GetGraphqlApiRequest: S.Schema<GetGraphqlApiRequest>;
export interface GetGraphqlApiResponse {
    graphqlApi?: GraphqlApi;
}
export declare const GetGraphqlApiResponse: S.Schema<GetGraphqlApiResponse>;
export interface GetGraphqlApiEnvironmentVariablesRequest {
    apiId: string;
}
export declare const GetGraphqlApiEnvironmentVariablesRequest: S.Schema<GetGraphqlApiEnvironmentVariablesRequest>;
export type EnvironmentVariableKey = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariableMap = {
    [key: string]: string | undefined;
};
export declare const EnvironmentVariableMap: any;
export interface GetGraphqlApiEnvironmentVariablesResponse {
    environmentVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const GetGraphqlApiEnvironmentVariablesResponse: S.Schema<GetGraphqlApiEnvironmentVariablesResponse>;
export type OutputType = "SDL" | "JSON" | (string & {});
export declare const OutputType: any;
export interface GetIntrospectionSchemaRequest {
    apiId: string;
    format: OutputType;
    includeDirectives?: boolean;
}
export declare const GetIntrospectionSchemaRequest: S.Schema<GetIntrospectionSchemaRequest>;
export interface GetIntrospectionSchemaResponse {
    schema?: T.StreamingOutputBody;
}
export declare const GetIntrospectionSchemaResponse: S.Schema<GetIntrospectionSchemaResponse>;
export interface GetResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
}
export declare const GetResolverRequest: S.Schema<GetResolverRequest>;
export interface GetResolverResponse {
    resolver?: Resolver;
}
export declare const GetResolverResponse: S.Schema<GetResolverResponse>;
export interface GetSchemaCreationStatusRequest {
    apiId: string;
}
export declare const GetSchemaCreationStatusRequest: S.Schema<GetSchemaCreationStatusRequest>;
export type SchemaStatus = "PROCESSING" | "ACTIVE" | "DELETING" | "FAILED" | "SUCCESS" | "NOT_APPLICABLE" | (string & {});
export declare const SchemaStatus: any;
export interface GetSchemaCreationStatusResponse {
    status?: SchemaStatus;
    details?: string;
}
export declare const GetSchemaCreationStatusResponse: S.Schema<GetSchemaCreationStatusResponse>;
export interface GetSourceApiAssociationRequest {
    mergedApiIdentifier: string;
    associationId: string;
}
export declare const GetSourceApiAssociationRequest: S.Schema<GetSourceApiAssociationRequest>;
export interface GetSourceApiAssociationResponse {
    sourceApiAssociation?: SourceApiAssociation;
}
export declare const GetSourceApiAssociationResponse: S.Schema<GetSourceApiAssociationResponse>;
export interface GetTypeRequest {
    apiId: string;
    typeName: string;
    format: TypeDefinitionFormat;
}
export declare const GetTypeRequest: S.Schema<GetTypeRequest>;
export interface GetTypeResponse {
    type?: Type;
}
export declare const GetTypeResponse: S.Schema<GetTypeResponse>;
export interface ListApiKeysRequest {
    apiId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListApiKeysRequest: S.Schema<ListApiKeysRequest>;
export type ApiKeys = ApiKey[];
export declare const ApiKeys: any;
export interface ListApiKeysResponse {
    apiKeys?: ApiKey[];
    nextToken?: string;
}
export declare const ListApiKeysResponse: S.Schema<ListApiKeysResponse>;
export interface ListApisRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListApisRequest: S.Schema<ListApisRequest>;
export type Apis = Api[];
export declare const Apis: any;
export interface ListApisResponse {
    apis?: Api[];
    nextToken?: string;
}
export declare const ListApisResponse: S.Schema<ListApisResponse>;
export interface ListChannelNamespacesRequest {
    apiId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListChannelNamespacesRequest: S.Schema<ListChannelNamespacesRequest>;
export type ChannelNamespaces = ChannelNamespace[];
export declare const ChannelNamespaces: any;
export interface ListChannelNamespacesResponse {
    channelNamespaces?: ChannelNamespace[];
    nextToken?: string;
}
export declare const ListChannelNamespacesResponse: S.Schema<ListChannelNamespacesResponse>;
export interface ListDataSourcesRequest {
    apiId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDataSourcesRequest: S.Schema<ListDataSourcesRequest>;
export type DataSources = DataSource[];
export declare const DataSources: any;
export interface ListDataSourcesResponse {
    dataSources?: DataSource[];
    nextToken?: string;
}
export declare const ListDataSourcesResponse: S.Schema<ListDataSourcesResponse>;
export interface ListDomainNamesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListDomainNamesRequest: S.Schema<ListDomainNamesRequest>;
export type DomainNameConfigs = DomainNameConfig[];
export declare const DomainNameConfigs: any;
export interface ListDomainNamesResponse {
    domainNameConfigs?: DomainNameConfig[];
    nextToken?: string;
}
export declare const ListDomainNamesResponse: S.Schema<ListDomainNamesResponse>;
export interface ListFunctionsRequest {
    apiId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListFunctionsRequest: S.Schema<ListFunctionsRequest>;
export type Functions = FunctionConfiguration[];
export declare const Functions: any;
export interface ListFunctionsResponse {
    functions?: FunctionConfiguration[];
    nextToken?: string;
}
export declare const ListFunctionsResponse: S.Schema<ListFunctionsResponse>;
export type Ownership = "CURRENT_ACCOUNT" | "OTHER_ACCOUNTS" | (string & {});
export declare const Ownership: any;
export interface ListGraphqlApisRequest {
    nextToken?: string;
    maxResults?: number;
    apiType?: GraphQLApiType;
    owner?: Ownership;
}
export declare const ListGraphqlApisRequest: S.Schema<ListGraphqlApisRequest>;
export type GraphqlApis = GraphqlApi[];
export declare const GraphqlApis: any;
export interface ListGraphqlApisResponse {
    graphqlApis?: GraphqlApi[];
    nextToken?: string;
}
export declare const ListGraphqlApisResponse: S.Schema<ListGraphqlApisResponse>;
export interface ListResolversRequest {
    apiId: string;
    typeName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListResolversRequest: S.Schema<ListResolversRequest>;
export type Resolvers = Resolver[];
export declare const Resolvers: any;
export interface ListResolversResponse {
    resolvers?: Resolver[];
    nextToken?: string;
}
export declare const ListResolversResponse: S.Schema<ListResolversResponse>;
export interface ListResolversByFunctionRequest {
    apiId: string;
    functionId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListResolversByFunctionRequest: S.Schema<ListResolversByFunctionRequest>;
export interface ListResolversByFunctionResponse {
    resolvers?: Resolver[];
    nextToken?: string;
}
export declare const ListResolversByFunctionResponse: S.Schema<ListResolversByFunctionResponse>;
export interface ListSourceApiAssociationsRequest {
    apiId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSourceApiAssociationsRequest: S.Schema<ListSourceApiAssociationsRequest>;
export interface SourceApiAssociationSummary {
    associationId?: string;
    associationArn?: string;
    sourceApiId?: string;
    sourceApiArn?: string;
    mergedApiId?: string;
    mergedApiArn?: string;
    description?: string;
}
export declare const SourceApiAssociationSummary: S.Schema<SourceApiAssociationSummary>;
export type SourceApiAssociationSummaryList = SourceApiAssociationSummary[];
export declare const SourceApiAssociationSummaryList: any;
export interface ListSourceApiAssociationsResponse {
    sourceApiAssociationSummaries?: SourceApiAssociationSummary[];
    nextToken?: string;
}
export declare const ListSourceApiAssociationsResponse: S.Schema<ListSourceApiAssociationsResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTypesRequest {
    apiId: string;
    format: TypeDefinitionFormat;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTypesRequest: S.Schema<ListTypesRequest>;
export type TypeList = Type[];
export declare const TypeList: any;
export interface ListTypesResponse {
    types?: Type[];
    nextToken?: string;
}
export declare const ListTypesResponse: S.Schema<ListTypesResponse>;
export interface ListTypesByAssociationRequest {
    mergedApiIdentifier: string;
    associationId: string;
    format: TypeDefinitionFormat;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTypesByAssociationRequest: S.Schema<ListTypesByAssociationRequest>;
export interface ListTypesByAssociationResponse {
    types?: Type[];
    nextToken?: string;
}
export declare const ListTypesByAssociationResponse: S.Schema<ListTypesByAssociationResponse>;
export interface PutGraphqlApiEnvironmentVariablesRequest {
    apiId: string;
    environmentVariables: {
        [key: string]: string | undefined;
    };
}
export declare const PutGraphqlApiEnvironmentVariablesRequest: S.Schema<PutGraphqlApiEnvironmentVariablesRequest>;
export interface PutGraphqlApiEnvironmentVariablesResponse {
    environmentVariables?: {
        [key: string]: string | undefined;
    };
}
export declare const PutGraphqlApiEnvironmentVariablesResponse: S.Schema<PutGraphqlApiEnvironmentVariablesResponse>;
export type RdsDataApiConfigResourceArn = string;
export type RdsDataApiConfigSecretArn = string;
export type RdsDataApiConfigDatabaseName = string;
export interface RdsDataApiConfig {
    resourceArn: string;
    secretArn: string;
    databaseName: string;
}
export declare const RdsDataApiConfig: S.Schema<RdsDataApiConfig>;
export interface StartDataSourceIntrospectionRequest {
    rdsDataApiConfig?: RdsDataApiConfig;
}
export declare const StartDataSourceIntrospectionRequest: S.Schema<StartDataSourceIntrospectionRequest>;
export interface StartDataSourceIntrospectionResponse {
    introspectionId?: string;
    introspectionStatus?: DataSourceIntrospectionStatus;
    introspectionStatusDetail?: string;
}
export declare const StartDataSourceIntrospectionResponse: S.Schema<StartDataSourceIntrospectionResponse>;
export interface StartSchemaCreationRequest {
    apiId: string;
    definition: Uint8Array;
}
export declare const StartSchemaCreationRequest: S.Schema<StartSchemaCreationRequest>;
export interface StartSchemaCreationResponse {
    status?: SchemaStatus;
}
export declare const StartSchemaCreationResponse: S.Schema<StartSchemaCreationResponse>;
export interface StartSchemaMergeRequest {
    associationId: string;
    mergedApiIdentifier: string;
}
export declare const StartSchemaMergeRequest: S.Schema<StartSchemaMergeRequest>;
export interface StartSchemaMergeResponse {
    sourceApiAssociationStatus?: SourceApiAssociationStatus;
}
export declare const StartSchemaMergeResponse: S.Schema<StartSchemaMergeResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateApiRequest {
    apiId: string;
    name: string;
    ownerContact?: string;
    eventConfig: EventConfig;
}
export declare const UpdateApiRequest: S.Schema<UpdateApiRequest>;
export interface UpdateApiResponse {
    api?: Api;
}
export declare const UpdateApiResponse: S.Schema<UpdateApiResponse>;
export interface UpdateApiCacheRequest {
    apiId: string;
    ttl: number;
    apiCachingBehavior: ApiCachingBehavior;
    type: ApiCacheType;
    healthMetricsConfig?: CacheHealthMetricsConfig;
}
export declare const UpdateApiCacheRequest: S.Schema<UpdateApiCacheRequest>;
export interface UpdateApiCacheResponse {
    apiCache?: ApiCache;
}
export declare const UpdateApiCacheResponse: S.Schema<UpdateApiCacheResponse>;
export interface UpdateApiKeyRequest {
    apiId: string;
    id: string;
    description?: string;
    expires?: number;
}
export declare const UpdateApiKeyRequest: S.Schema<UpdateApiKeyRequest>;
export interface UpdateApiKeyResponse {
    apiKey?: ApiKey;
}
export declare const UpdateApiKeyResponse: S.Schema<UpdateApiKeyResponse>;
export interface UpdateChannelNamespaceRequest {
    apiId: string;
    name: string;
    subscribeAuthModes?: AuthMode[];
    publishAuthModes?: AuthMode[];
    codeHandlers?: string;
    handlerConfigs?: HandlerConfigs;
}
export declare const UpdateChannelNamespaceRequest: S.Schema<UpdateChannelNamespaceRequest>;
export interface UpdateChannelNamespaceResponse {
    channelNamespace?: ChannelNamespace;
}
export declare const UpdateChannelNamespaceResponse: S.Schema<UpdateChannelNamespaceResponse>;
export interface UpdateDataSourceRequest {
    apiId: string;
    name: string;
    description?: string;
    type: DataSourceType;
    serviceRoleArn?: string;
    dynamodbConfig?: DynamodbDataSourceConfig;
    lambdaConfig?: LambdaDataSourceConfig;
    elasticsearchConfig?: ElasticsearchDataSourceConfig;
    openSearchServiceConfig?: OpenSearchServiceDataSourceConfig;
    httpConfig?: HttpDataSourceConfig;
    relationalDatabaseConfig?: RelationalDatabaseDataSourceConfig;
    eventBridgeConfig?: EventBridgeDataSourceConfig;
    metricsConfig?: DataSourceLevelMetricsConfig;
}
export declare const UpdateDataSourceRequest: S.Schema<UpdateDataSourceRequest>;
export interface UpdateDataSourceResponse {
    dataSource?: DataSource;
}
export declare const UpdateDataSourceResponse: S.Schema<UpdateDataSourceResponse>;
export interface UpdateDomainNameRequest {
    domainName: string;
    description?: string;
}
export declare const UpdateDomainNameRequest: S.Schema<UpdateDomainNameRequest>;
export interface UpdateDomainNameResponse {
    domainNameConfig?: DomainNameConfig;
}
export declare const UpdateDomainNameResponse: S.Schema<UpdateDomainNameResponse>;
export interface UpdateFunctionRequest {
    apiId: string;
    name: string;
    description?: string;
    functionId: string;
    dataSourceName: string;
    requestMappingTemplate?: string;
    responseMappingTemplate?: string;
    functionVersion?: string;
    syncConfig?: SyncConfig;
    maxBatchSize?: number;
    runtime?: AppSyncRuntime;
    code?: string;
}
export declare const UpdateFunctionRequest: S.Schema<UpdateFunctionRequest>;
export interface UpdateFunctionResponse {
    functionConfiguration?: FunctionConfiguration;
}
export declare const UpdateFunctionResponse: S.Schema<UpdateFunctionResponse>;
export interface UpdateGraphqlApiRequest {
    apiId: string;
    name: string;
    logConfig?: LogConfig;
    authenticationType: AuthenticationType;
    userPoolConfig?: UserPoolConfig;
    openIDConnectConfig?: OpenIDConnectConfig;
    additionalAuthenticationProviders?: AdditionalAuthenticationProvider[];
    xrayEnabled?: boolean;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig;
    mergedApiExecutionRoleArn?: string;
    ownerContact?: string;
    introspectionConfig?: GraphQLApiIntrospectionConfig;
    queryDepthLimit?: number;
    resolverCountLimit?: number;
    enhancedMetricsConfig?: EnhancedMetricsConfig;
}
export declare const UpdateGraphqlApiRequest: S.Schema<UpdateGraphqlApiRequest>;
export interface UpdateGraphqlApiResponse {
    graphqlApi?: GraphqlApi;
}
export declare const UpdateGraphqlApiResponse: S.Schema<UpdateGraphqlApiResponse>;
export interface UpdateResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
    dataSourceName?: string;
    requestMappingTemplate?: string;
    responseMappingTemplate?: string;
    kind?: ResolverKind;
    pipelineConfig?: PipelineConfig;
    syncConfig?: SyncConfig;
    cachingConfig?: CachingConfig;
    maxBatchSize?: number;
    runtime?: AppSyncRuntime;
    code?: string;
    metricsConfig?: ResolverLevelMetricsConfig;
}
export declare const UpdateResolverRequest: S.Schema<UpdateResolverRequest>;
export interface UpdateResolverResponse {
    resolver?: Resolver;
}
export declare const UpdateResolverResponse: S.Schema<UpdateResolverResponse>;
export interface UpdateSourceApiAssociationRequest {
    associationId: string;
    mergedApiIdentifier: string;
    description?: string;
    sourceApiAssociationConfig?: SourceApiAssociationConfig;
}
export declare const UpdateSourceApiAssociationRequest: S.Schema<UpdateSourceApiAssociationRequest>;
export interface UpdateSourceApiAssociationResponse {
    sourceApiAssociation?: SourceApiAssociation;
}
export declare const UpdateSourceApiAssociationResponse: S.Schema<UpdateSourceApiAssociationResponse>;
export interface UpdateTypeRequest {
    apiId: string;
    typeName: string;
    definition?: string;
    format: TypeDefinitionFormat;
}
export declare const UpdateTypeRequest: S.Schema<UpdateTypeRequest>;
export interface UpdateTypeResponse {
    type?: Type;
}
export declare const UpdateTypeResponse: S.Schema<UpdateTypeResponse>;
export type BadRequestReason = "CODE_ERROR" | (string & {});
export declare const BadRequestReason: any;
export interface BadRequestDetail {
    codeErrors?: CodeError[];
}
export declare const BadRequestDetail: S.Schema<BadRequestDetail>;
export type AssociateApiError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Maps an endpoint to your custom domain.
 */
export declare const associateApi: API.OperationMethod<AssociateApiRequest, AssociateApiResponse, AssociateApiError, Credentials | HttpClient.HttpClient>;
export type AssociateMergedGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates an association between a Merged API and source API using the source API's
 * identifier.
 */
export declare const associateMergedGraphqlApi: API.OperationMethod<AssociateMergedGraphqlApiRequest, AssociateMergedGraphqlApiResponse, AssociateMergedGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type AssociateSourceGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates an association between a Merged API and source API using the Merged API's
 * identifier.
 */
export declare const associateSourceGraphqlApi: API.OperationMethod<AssociateSourceGraphqlApiRequest, AssociateSourceGraphqlApiResponse, AssociateSourceGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type CreateApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | ServiceQuotaExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates an `Api` object. Use this operation to create an AppSync
 * API with your preferred configuration, such as an Event API that provides real-time message
 * publishing and message subscriptions over WebSockets.
 */
export declare const createApi: API.OperationMethod<CreateApiRequest, CreateApiResponse, CreateApiError, Credentials | HttpClient.HttpClient>;
export type CreateApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a cache for the GraphQL API.
 */
export declare const createApiCache: API.OperationMethod<CreateApiCacheRequest, CreateApiCacheResponse, CreateApiCacheError, Credentials | HttpClient.HttpClient>;
export type CreateApiKeyError = ApiKeyLimitExceededException | ApiKeyValidityOutOfBoundsException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a unique key that you can distribute to clients who invoke your API.
 */
export declare const createApiKey: API.OperationMethod<CreateApiKeyRequest, CreateApiKeyResponse, CreateApiKeyError, Credentials | HttpClient.HttpClient>;
export type CreateChannelNamespaceError = BadRequestException | ConcurrentModificationException | ConflictException | InternalFailureException | NotFoundException | ServiceQuotaExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates a `ChannelNamespace` for an `Api`.
 */
export declare const createChannelNamespace: API.OperationMethod<CreateChannelNamespaceRequest, CreateChannelNamespaceResponse, CreateChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `DataSource` object.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Creates a custom `DomainName` object.
 */
export declare const createDomainName: API.OperationMethod<CreateDomainNameRequest, CreateDomainNameResponse, CreateDomainNameError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `Function` object.
 *
 * A function is a reusable entity. You can use multiple functions to compose the resolver
 * logic.
 */
export declare const createFunction: API.OperationMethod<CreateFunctionRequest, CreateFunctionResponse, CreateFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateGraphqlApiError = ApiLimitExceededException | BadRequestException | ConcurrentModificationException | InternalFailureException | LimitExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates a `GraphqlApi` object.
 */
export declare const createGraphqlApi: API.OperationMethod<CreateGraphqlApiRequest, CreateGraphqlApiResponse, CreateGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type CreateResolverError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `Resolver` object.
 *
 * A resolver converts incoming requests into a format that a data source can understand,
 * and converts the data source's responses into GraphQL.
 */
export declare const createResolver: API.OperationMethod<CreateResolverRequest, CreateResolverResponse, CreateResolverError, Credentials | HttpClient.HttpClient>;
export type CreateTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `Type` object.
 */
export declare const createType: API.OperationMethod<CreateTypeRequest, CreateTypeResponse, CreateTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an `Api` object
 */
export declare const deleteApi: API.OperationMethod<DeleteApiRequest, DeleteApiResponse, DeleteApiError, Credentials | HttpClient.HttpClient>;
export type DeleteApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an `ApiCache` object.
 */
export declare const deleteApiCache: API.OperationMethod<DeleteApiCacheRequest, DeleteApiCacheResponse, DeleteApiCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteApiKeyError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an API key.
 */
export declare const deleteApiKey: API.OperationMethod<DeleteApiKeyRequest, DeleteApiKeyResponse, DeleteApiKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelNamespaceError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `ChannelNamespace`.
 */
export declare const deleteChannelNamespace: API.OperationMethod<DeleteChannelNamespaceRequest, DeleteChannelNamespaceResponse, DeleteChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `DataSource` object.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Deletes a custom `DomainName` object.
 */
export declare const deleteDomainName: API.OperationMethod<DeleteDomainNameRequest, DeleteDomainNameResponse, DeleteDomainNameError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `Function`.
 */
export declare const deleteFunction: API.OperationMethod<DeleteFunctionRequest, DeleteFunctionResponse, DeleteFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteGraphqlApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `GraphqlApi` object.
 */
export declare const deleteGraphqlApi: API.OperationMethod<DeleteGraphqlApiRequest, DeleteGraphqlApiResponse, DeleteGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type DeleteResolverError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `Resolver` object.
 */
export declare const deleteResolver: API.OperationMethod<DeleteResolverRequest, DeleteResolverResponse, DeleteResolverError, Credentials | HttpClient.HttpClient>;
export type DeleteTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `Type` object.
 */
export declare const deleteType: API.OperationMethod<DeleteTypeRequest, DeleteTypeResponse, DeleteTypeError, Credentials | HttpClient.HttpClient>;
export type DisassociateApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Removes an `ApiAssociation` object from a custom domain.
 */
export declare const disassociateApi: API.OperationMethod<DisassociateApiRequest, DisassociateApiResponse, DisassociateApiError, Credentials | HttpClient.HttpClient>;
export type DisassociateMergedGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an association between a Merged API and source API using the source API's
 * identifier and the association ID.
 */
export declare const disassociateMergedGraphqlApi: API.OperationMethod<DisassociateMergedGraphqlApiRequest, DisassociateMergedGraphqlApiResponse, DisassociateMergedGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type DisassociateSourceGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an association between a Merged API and source API using the Merged API's
 * identifier and the association ID.
 */
export declare const disassociateSourceGraphqlApi: API.OperationMethod<DisassociateSourceGraphqlApiRequest, DisassociateSourceGraphqlApiResponse, DisassociateSourceGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type EvaluateCodeError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Evaluates the given code and returns the response. The code definition requirements
 * depend on the specified runtime. For `APPSYNC_JS` runtimes, the code defines the
 * request and response functions. The request function takes the incoming request after a
 * GraphQL operation is parsed and converts it into a request configuration for the selected
 * data source operation. The response function interprets responses from the data source and
 * maps it to the shape of the GraphQL field output type.
 */
export declare const evaluateCode: API.OperationMethod<EvaluateCodeRequest, EvaluateCodeResponse, EvaluateCodeError, Credentials | HttpClient.HttpClient>;
export type EvaluateMappingTemplateError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Evaluates a given template and returns the response. The mapping template can be a
 * request or response template.
 *
 * Request templates take the incoming request after a GraphQL operation is parsed and
 * convert it into a request configuration for the selected data source operation. Response
 * templates interpret responses from the data source and map it to the shape of the GraphQL
 * field output type.
 *
 * Mapping templates are written in the Apache Velocity Template Language (VTL).
 */
export declare const evaluateMappingTemplate: API.OperationMethod<EvaluateMappingTemplateRequest, EvaluateMappingTemplateResponse, EvaluateMappingTemplateError, Credentials | HttpClient.HttpClient>;
export type FlushApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Flushes an `ApiCache` object.
 */
export declare const flushApiCache: API.OperationMethod<FlushApiCacheRequest, FlushApiCacheResponse, FlushApiCacheError, Credentials | HttpClient.HttpClient>;
export type GetApiError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves an `Api` object.
 */
export declare const getApi: API.OperationMethod<GetApiRequest, GetApiResponse, GetApiError, Credentials | HttpClient.HttpClient>;
export type GetApiAssociationError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Retrieves an `ApiAssociation` object.
 */
export declare const getApiAssociation: API.OperationMethod<GetApiAssociationRequest, GetApiAssociationResponse, GetApiAssociationError, Credentials | HttpClient.HttpClient>;
export type GetApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves an `ApiCache` object.
 */
export declare const getApiCache: API.OperationMethod<GetApiCacheRequest, GetApiCacheResponse, GetApiCacheError, Credentials | HttpClient.HttpClient>;
export type GetChannelNamespaceError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the channel namespace for a specified `Api`.
 */
export declare const getChannelNamespace: API.OperationMethod<GetChannelNamespaceRequest, GetChannelNamespaceResponse, GetChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `DataSource` object.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceRequest, GetDataSourceResponse, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceIntrospectionError = BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Retrieves the record of an existing introspection. If the retrieval is successful, the
 * result of the instrospection will also be returned. If the retrieval fails the operation,
 * an error message will be returned instead.
 */
export declare const getDataSourceIntrospection: API.OperationMethod<GetDataSourceIntrospectionRequest, GetDataSourceIntrospectionResponse, GetDataSourceIntrospectionError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Retrieves a custom `DomainName` object.
 */
export declare const getDomainName: API.OperationMethod<GetDomainNameRequest, GetDomainNameResponse, GetDomainNameError, Credentials | HttpClient.HttpClient>;
export type GetFunctionError = ConcurrentModificationException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Get a `Function`.
 */
export declare const getFunction: API.OperationMethod<GetFunctionRequest, GetFunctionResponse, GetFunctionError, Credentials | HttpClient.HttpClient>;
export type GetGraphqlApiError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `GraphqlApi` object.
 */
export declare const getGraphqlApi: API.OperationMethod<GetGraphqlApiRequest, GetGraphqlApiResponse, GetGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type GetGraphqlApiEnvironmentVariablesError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the list of environmental variable key-value pairs associated with an API by
 * its ID value.
 */
export declare const getGraphqlApiEnvironmentVariables: API.OperationMethod<GetGraphqlApiEnvironmentVariablesRequest, GetGraphqlApiEnvironmentVariablesResponse, GetGraphqlApiEnvironmentVariablesError, Credentials | HttpClient.HttpClient>;
export type GetIntrospectionSchemaError = GraphQLSchemaException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the introspection schema for a GraphQL API.
 */
export declare const getIntrospectionSchema: API.OperationMethod<GetIntrospectionSchemaRequest, GetIntrospectionSchemaResponse, GetIntrospectionSchemaError, Credentials | HttpClient.HttpClient>;
export type GetResolverError = ConcurrentModificationException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `Resolver` object.
 */
export declare const getResolver: API.OperationMethod<GetResolverRequest, GetResolverResponse, GetResolverError, Credentials | HttpClient.HttpClient>;
export type GetSchemaCreationStatusError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the current status of a schema creation operation.
 */
export declare const getSchemaCreationStatus: API.OperationMethod<GetSchemaCreationStatusRequest, GetSchemaCreationStatusResponse, GetSchemaCreationStatusError, Credentials | HttpClient.HttpClient>;
export type GetSourceApiAssociationError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `SourceApiAssociation` object.
 */
export declare const getSourceApiAssociation: API.OperationMethod<GetSourceApiAssociationRequest, GetSourceApiAssociationResponse, GetSourceApiAssociationError, Credentials | HttpClient.HttpClient>;
export type GetTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `Type` object.
 */
export declare const getType: API.OperationMethod<GetTypeRequest, GetTypeResponse, GetTypeError, Credentials | HttpClient.HttpClient>;
export type ListApiKeysError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the API keys for a given API.
 *
 * API keys are deleted automatically 60 days after they expire. However, they may still
 * be included in the response until they have actually been deleted. You can safely call
 * `DeleteApiKey` to manually delete a key before it's automatically
 * deleted.
 */
export declare const listApiKeys: API.PaginatedOperationMethod<ListApiKeysRequest, ListApiKeysResponse, ListApiKeysError, Credentials | HttpClient.HttpClient, ApiKey>;
export type ListApisError = BadRequestException | InternalFailureException | UnauthorizedException | CommonErrors;
/**
 * Lists the APIs in your AppSync account.
 *
 * `ListApis` returns only the high level API details. For more detailed
 * information about an API, use `GetApi`.
 */
export declare const listApis: API.PaginatedOperationMethod<ListApisRequest, ListApisResponse, ListApisError, Credentials | HttpClient.HttpClient, Api>;
export type ListChannelNamespacesError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the channel namespaces for a specified `Api`.
 *
 * `ListChannelNamespaces` returns only high level details for the channel
 * namespace. To retrieve code handlers, use `GetChannelNamespace`.
 */
export declare const listChannelNamespaces: API.PaginatedOperationMethod<ListChannelNamespacesRequest, ListChannelNamespacesResponse, ListChannelNamespacesError, Credentials | HttpClient.HttpClient, ChannelNamespace>;
export type ListDataSourcesError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the data sources for a given API.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSource>;
export type ListDomainNamesError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Lists multiple custom domain names.
 */
export declare const listDomainNames: API.PaginatedOperationMethod<ListDomainNamesRequest, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient, DomainNameConfig>;
export type ListFunctionsError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * List multiple functions.
 */
export declare const listFunctions: API.PaginatedOperationMethod<ListFunctionsRequest, ListFunctionsResponse, ListFunctionsError, Credentials | HttpClient.HttpClient, FunctionConfiguration>;
export type ListGraphqlApisError = BadRequestException | InternalFailureException | UnauthorizedException | CommonErrors;
/**
 * Lists your GraphQL APIs.
 */
export declare const listGraphqlApis: API.PaginatedOperationMethod<ListGraphqlApisRequest, ListGraphqlApisResponse, ListGraphqlApisError, Credentials | HttpClient.HttpClient, GraphqlApi>;
export type ListResolversError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the resolvers for a given API and type.
 */
export declare const listResolvers: API.PaginatedOperationMethod<ListResolversRequest, ListResolversResponse, ListResolversError, Credentials | HttpClient.HttpClient, Resolver>;
export type ListResolversByFunctionError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * List the resolvers that are associated with a specific function.
 */
export declare const listResolversByFunction: API.PaginatedOperationMethod<ListResolversByFunctionRequest, ListResolversByFunctionResponse, ListResolversByFunctionError, Credentials | HttpClient.HttpClient, Resolver>;
export type ListSourceApiAssociationsError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the `SourceApiAssociationSummary` data.
 */
export declare const listSourceApiAssociations: API.PaginatedOperationMethod<ListSourceApiAssociationsRequest, ListSourceApiAssociationsResponse, ListSourceApiAssociationsError, Credentials | HttpClient.HttpClient, SourceApiAssociationSummary>;
export type ListTagsForResourceError = AccessDeniedException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTypesError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the types for a given API.
 */
export declare const listTypes: API.PaginatedOperationMethod<ListTypesRequest, ListTypesResponse, ListTypesError, Credentials | HttpClient.HttpClient, Type>;
export type ListTypesByAssociationError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists `Type` objects by the source API association ID.
 */
export declare const listTypesByAssociation: API.PaginatedOperationMethod<ListTypesByAssociationRequest, ListTypesByAssociationResponse, ListTypesByAssociationError, Credentials | HttpClient.HttpClient, Type>;
export type PutGraphqlApiEnvironmentVariablesError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a list of environmental variables in an API by its ID value.
 *
 * When creating an environmental variable, it must follow the constraints below:
 *
 * - Both JavaScript and VTL templates support environmental variables.
 *
 * - Environmental variables are not evaluated before function invocation.
 *
 * - Environmental variables only support string values.
 *
 * - Any defined value in an environmental variable is considered a string literal
 * and not expanded.
 *
 * - Variable evaluations should ideally be performed in the function
 * code.
 *
 * When creating an environmental variable key-value pair, it must follow the additional
 * constraints below:
 *
 * - Keys must begin with a letter.
 *
 * - Keys must be at least two characters long.
 *
 * - Keys can only contain letters, numbers, and the underscore character
 * (_).
 *
 * - Values can be up to 512 characters long.
 *
 * - You can configure up to 50 key-value pairs in a GraphQL API.
 *
 * You can create a list of environmental variables by adding it to the
 * `environmentVariables` payload as a list in the format
 * `{"key1":"value1","key2":"value2", …}`. Note that each call of the
 * `PutGraphqlApiEnvironmentVariables` action will result in the overwriting of
 * the existing environmental variable list of that API. This means the existing environmental
 * variables will be lost. To avoid this, you must include all existing and new environmental
 * variables in the list each time you call this action.
 */
export declare const putGraphqlApiEnvironmentVariables: API.OperationMethod<PutGraphqlApiEnvironmentVariablesRequest, PutGraphqlApiEnvironmentVariablesResponse, PutGraphqlApiEnvironmentVariablesError, Credentials | HttpClient.HttpClient>;
export type StartDataSourceIntrospectionError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a new introspection. Returns the `introspectionId` of the new
 * introspection after its creation.
 */
export declare const startDataSourceIntrospection: API.OperationMethod<StartDataSourceIntrospectionRequest, StartDataSourceIntrospectionResponse, StartDataSourceIntrospectionError, Credentials | HttpClient.HttpClient>;
export type StartSchemaCreationError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Adds a new schema to your GraphQL API.
 *
 * This operation is asynchronous. Use to
 * determine when it has completed.
 */
export declare const startSchemaCreation: API.OperationMethod<StartSchemaCreationRequest, StartSchemaCreationResponse, StartSchemaCreationError, Credentials | HttpClient.HttpClient>;
export type StartSchemaMergeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Initiates a merge operation. Returns a status that shows the result of the merge
 * operation.
 */
export declare const startSchemaMerge: API.OperationMethod<StartSchemaMergeRequest, StartSchemaMergeResponse, StartSchemaMergeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Tags a resource with user-supplied tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Untags a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates an `Api`.
 */
export declare const updateApi: API.OperationMethod<UpdateApiRequest, UpdateApiResponse, UpdateApiError, Credentials | HttpClient.HttpClient>;
export type UpdateApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates the cache for the GraphQL API.
 */
export declare const updateApiCache: API.OperationMethod<UpdateApiCacheRequest, UpdateApiCacheResponse, UpdateApiCacheError, Credentials | HttpClient.HttpClient>;
export type UpdateApiKeyError = ApiKeyValidityOutOfBoundsException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates an API key. You can update the key as long as it's not deleted.
 */
export declare const updateApiKey: API.OperationMethod<UpdateApiKeyRequest, UpdateApiKeyResponse, UpdateApiKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelNamespaceError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `ChannelNamespace` associated with an `Api`.
 */
export declare const updateChannelNamespace: API.OperationMethod<UpdateChannelNamespaceRequest, UpdateChannelNamespaceResponse, UpdateChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `DataSource` object.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainNameError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Updates a custom `DomainName` object.
 */
export declare const updateDomainName: API.OperationMethod<UpdateDomainNameRequest, UpdateDomainNameResponse, UpdateDomainNameError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `Function` object.
 */
export declare const updateFunction: API.OperationMethod<UpdateFunctionRequest, UpdateFunctionResponse, UpdateFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateGraphqlApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `GraphqlApi` object.
 */
export declare const updateGraphqlApi: API.OperationMethod<UpdateGraphqlApiRequest, UpdateGraphqlApiResponse, UpdateGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `Resolver` object.
 */
export declare const updateResolver: API.OperationMethod<UpdateResolverRequest, UpdateResolverResponse, UpdateResolverError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceApiAssociationError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates some of the configuration choices of a particular source API association.
 */
export declare const updateSourceApiAssociation: API.OperationMethod<UpdateSourceApiAssociationRequest, UpdateSourceApiAssociationResponse, UpdateSourceApiAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `Type` object.
 */
export declare const updateType: API.OperationMethod<UpdateTypeRequest, UpdateTypeResponse, UpdateTypeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appsync.d.ts.map