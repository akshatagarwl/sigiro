import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServiceException_base: S.Class<InternalServiceException, S.TaggedStruct<"InternalServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly quotaName: any;
    readonly quotaValue: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type UUID = string;
export type TrainedModelArn = string;
export interface CancelTrainedModelRequest {
    membershipIdentifier: string;
    trainedModelArn: string;
    versionIdentifier?: string;
}
export declare const CancelTrainedModelRequest: S.Schema<CancelTrainedModelRequest>;
export interface CancelTrainedModelResponse {
}
export declare const CancelTrainedModelResponse: S.Schema<CancelTrainedModelResponse>;
export type TrainedModelInferenceJobArn = string;
export interface CancelTrainedModelInferenceJobRequest {
    membershipIdentifier: string;
    trainedModelInferenceJobArn: string;
}
export declare const CancelTrainedModelInferenceJobRequest: S.Schema<CancelTrainedModelInferenceJobRequest>;
export interface CancelTrainedModelInferenceJobResponse {
}
export declare const CancelTrainedModelInferenceJobResponse: S.Schema<CancelTrainedModelInferenceJobResponse>;
export type NameString = string;
export type TrainingDatasetArn = string;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type ResourceDescription = string;
export interface CreateAudienceModelRequest {
    trainingDataStartTime?: Date;
    trainingDataEndTime?: Date;
    name: string;
    trainingDatasetArn: string;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
}
export declare const CreateAudienceModelRequest: S.Schema<CreateAudienceModelRequest>;
export type AudienceModelArn = string;
export interface CreateAudienceModelResponse {
    audienceModelArn: string;
}
export declare const CreateAudienceModelResponse: S.Schema<CreateAudienceModelResponse>;
export type S3Path = string;
export interface S3ConfigMap {
    s3Uri: string;
}
export declare const S3ConfigMap: S.Schema<S3ConfigMap>;
export interface AudienceDestination {
    s3Destination: S3ConfigMap;
}
export declare const AudienceDestination: S.Schema<AudienceDestination>;
export type IamRoleArn = string;
export interface ConfiguredAudienceModelOutputConfig {
    destination: AudienceDestination;
    roleArn: string;
}
export declare const ConfiguredAudienceModelOutputConfig: S.Schema<ConfiguredAudienceModelOutputConfig>;
export type SharedAudienceMetrics = "ALL" | "NONE" | (string & {});
export declare const SharedAudienceMetrics: any;
export type MetricsList = SharedAudienceMetrics[];
export declare const MetricsList: any;
export type MinMatchingSeedSize = number;
export type AudienceSizeType = "ABSOLUTE" | "PERCENTAGE" | (string & {});
export declare const AudienceSizeType: any;
export type AudienceSizeValue = number;
export type AudienceSizeBins = number[];
export declare const AudienceSizeBins: any;
export interface AudienceSizeConfig {
    audienceSizeType: AudienceSizeType;
    audienceSizeBins: number[];
}
export declare const AudienceSizeConfig: S.Schema<AudienceSizeConfig>;
export type TagOnCreatePolicy = "FROM_PARENT_RESOURCE" | "NONE" | (string & {});
export declare const TagOnCreatePolicy: any;
export interface CreateConfiguredAudienceModelRequest {
    name: string;
    audienceModelArn: string;
    outputConfig: ConfiguredAudienceModelOutputConfig;
    description?: string;
    sharedAudienceMetrics: SharedAudienceMetrics[];
    minMatchingSeedSize?: number;
    audienceSizeConfig?: AudienceSizeConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    childResourceTagOnCreatePolicy?: TagOnCreatePolicy;
}
export declare const CreateConfiguredAudienceModelRequest: S.Schema<CreateConfiguredAudienceModelRequest>;
export type ConfiguredAudienceModelArn = string;
export interface CreateConfiguredAudienceModelResponse {
    configuredAudienceModelArn: string;
}
export declare const CreateConfiguredAudienceModelResponse: S.Schema<CreateConfiguredAudienceModelResponse>;
export type AlgorithmImage = string;
export type ContainerEntrypointString = string;
export type ContainerEntrypoint = string[];
export declare const ContainerEntrypoint: any;
export type ContainerArgument = string;
export type ContainerArguments = string[];
export declare const ContainerArguments: any;
export type MetricName = string;
export type MetricRegex = string;
export interface MetricDefinition {
    name: string;
    regex: string;
}
export declare const MetricDefinition: S.Schema<MetricDefinition>;
export type MetricDefinitionList = MetricDefinition[];
export declare const MetricDefinitionList: any;
export interface ContainerConfig {
    imageUri: string;
    entrypoint?: string[];
    arguments?: string[];
    metricDefinitions?: MetricDefinition[];
}
export declare const ContainerConfig: S.Schema<ContainerConfig>;
export interface InferenceContainerConfig {
    imageUri: string;
}
export declare const InferenceContainerConfig: S.Schema<InferenceContainerConfig>;
export interface CreateConfiguredModelAlgorithmRequest {
    name: string;
    description?: string;
    roleArn: string;
    trainingContainerConfig?: ContainerConfig;
    inferenceContainerConfig?: InferenceContainerConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export declare const CreateConfiguredModelAlgorithmRequest: S.Schema<CreateConfiguredModelAlgorithmRequest>;
export type ConfiguredModelAlgorithmArn = string;
export interface CreateConfiguredModelAlgorithmResponse {
    configuredModelAlgorithmArn: string;
}
export declare const CreateConfiguredModelAlgorithmResponse: S.Schema<CreateConfiguredModelAlgorithmResponse>;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export type LogType = "ALL" | "ERROR_SUMMARY" | (string & {});
export declare const LogType: any;
export type EntityType = "ALL_PERSONALLY_IDENTIFIABLE_INFORMATION" | "NUMBERS" | "CUSTOM" | (string & {});
export declare const EntityType: any;
export type EntityTypeList = EntityType[];
export declare const EntityTypeList: any;
export type CustomDataIdentifier = string;
export type CustomDataIdentifierList = string[];
export declare const CustomDataIdentifierList: any;
export interface CustomEntityConfig {
    customDataIdentifiers: string[];
}
export declare const CustomEntityConfig: S.Schema<CustomEntityConfig>;
export interface LogRedactionConfiguration {
    entitiesToRedact: EntityType[];
    customEntityConfig?: CustomEntityConfig;
}
export declare const LogRedactionConfiguration: S.Schema<LogRedactionConfiguration>;
export interface LogsConfigurationPolicy {
    allowedAccountIds: string[];
    filterPattern?: string;
    logType?: LogType;
    logRedactionConfiguration?: LogRedactionConfiguration;
}
export declare const LogsConfigurationPolicy: S.Schema<LogsConfigurationPolicy>;
export type LogsConfigurationPolicyList = LogsConfigurationPolicy[];
export declare const LogsConfigurationPolicyList: any;
export type NoiseLevelType = "HIGH" | "MEDIUM" | "LOW" | "NONE" | (string & {});
export declare const NoiseLevelType: any;
export interface MetricsConfigurationPolicy {
    noiseLevel: NoiseLevelType;
}
export declare const MetricsConfigurationPolicy: S.Schema<MetricsConfigurationPolicy>;
export type TrainedModelArtifactMaxSizeUnitType = "GB" | (string & {});
export declare const TrainedModelArtifactMaxSizeUnitType: any;
export type TrainedModelArtifactMaxSizeValue = number;
export interface TrainedModelArtifactMaxSize {
    unit: TrainedModelArtifactMaxSizeUnitType;
    value: number;
}
export declare const TrainedModelArtifactMaxSize: S.Schema<TrainedModelArtifactMaxSize>;
export interface TrainedModelsConfigurationPolicy {
    containerLogs?: LogsConfigurationPolicy[];
    containerMetrics?: MetricsConfigurationPolicy;
    maxArtifactSize?: TrainedModelArtifactMaxSize;
}
export declare const TrainedModelsConfigurationPolicy: S.Schema<TrainedModelsConfigurationPolicy>;
export type TrainedModelExportsMaxSizeUnitType = "GB" | (string & {});
export declare const TrainedModelExportsMaxSizeUnitType: any;
export type TrainedModelExportsMaxSizeValue = number;
export interface TrainedModelExportsMaxSize {
    unit: TrainedModelExportsMaxSizeUnitType;
    value: number;
}
export declare const TrainedModelExportsMaxSize: S.Schema<TrainedModelExportsMaxSize>;
export type TrainedModelExportFileType = "MODEL" | "OUTPUT" | (string & {});
export declare const TrainedModelExportFileType: any;
export type TrainedModelExportFileTypeList = TrainedModelExportFileType[];
export declare const TrainedModelExportFileTypeList: any;
export interface TrainedModelExportsConfigurationPolicy {
    maxSize: TrainedModelExportsMaxSize;
    filesToExport: TrainedModelExportFileType[];
}
export declare const TrainedModelExportsConfigurationPolicy: S.Schema<TrainedModelExportsConfigurationPolicy>;
export type TrainedModelInferenceMaxOutputSizeUnitType = "GB" | (string & {});
export declare const TrainedModelInferenceMaxOutputSizeUnitType: any;
export type TrainedModelInferenceMaxOutputSizeValue = number;
export interface TrainedModelInferenceMaxOutputSize {
    unit: TrainedModelInferenceMaxOutputSizeUnitType;
    value: number;
}
export declare const TrainedModelInferenceMaxOutputSize: S.Schema<TrainedModelInferenceMaxOutputSize>;
export interface TrainedModelInferenceJobsConfigurationPolicy {
    containerLogs?: LogsConfigurationPolicy[];
    maxOutputSize?: TrainedModelInferenceMaxOutputSize;
}
export declare const TrainedModelInferenceJobsConfigurationPolicy: S.Schema<TrainedModelInferenceJobsConfigurationPolicy>;
export interface PrivacyConfigurationPolicies {
    trainedModels?: TrainedModelsConfigurationPolicy;
    trainedModelExports?: TrainedModelExportsConfigurationPolicy;
    trainedModelInferenceJobs?: TrainedModelInferenceJobsConfigurationPolicy;
}
export declare const PrivacyConfigurationPolicies: S.Schema<PrivacyConfigurationPolicies>;
export interface PrivacyConfiguration {
    policies: PrivacyConfigurationPolicies;
}
export declare const PrivacyConfiguration: S.Schema<PrivacyConfiguration>;
export interface CreateConfiguredModelAlgorithmAssociationRequest {
    membershipIdentifier: string;
    configuredModelAlgorithmArn: string;
    name: string;
    description?: string;
    privacyConfiguration?: PrivacyConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConfiguredModelAlgorithmAssociationRequest: S.Schema<CreateConfiguredModelAlgorithmAssociationRequest>;
export type ConfiguredModelAlgorithmAssociationArn = string;
export interface CreateConfiguredModelAlgorithmAssociationResponse {
    configuredModelAlgorithmAssociationArn: string;
}
export declare const CreateConfiguredModelAlgorithmAssociationResponse: S.Schema<CreateConfiguredModelAlgorithmAssociationResponse>;
export type ConfiguredModelAlgorithmAssociationArnList = string[];
export declare const ConfiguredModelAlgorithmAssociationArnList: any;
export type AnalysisTemplateArn = string;
export type ParameterName = string;
export type ParameterValue = string;
export type ParameterMap = {
    [key: string]: string | undefined;
};
export declare const ParameterMap: any;
export interface ProtectedQuerySQLParameters {
    queryString?: string;
    analysisTemplateArn?: string;
    parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const ProtectedQuerySQLParameters: S.Schema<ProtectedQuerySQLParameters>;
export type WorkerComputeType = "CR.1X" | "CR.4X" | "CR.8X" | (string & {});
export declare const WorkerComputeType: any;
export type SparkPropertyKey = string;
export type SparkPropertyValue = string;
export type SparkProperties = {
    [key: string]: string | undefined;
};
export declare const SparkProperties: any;
export type WorkerComputeConfigurationProperties = {
    spark: {
        [key: string]: string | undefined;
    };
};
export declare const WorkerComputeConfigurationProperties: any;
export interface WorkerComputeConfiguration {
    type?: WorkerComputeType;
    number?: number;
    properties?: WorkerComputeConfigurationProperties;
}
export declare const WorkerComputeConfiguration: S.Schema<WorkerComputeConfiguration>;
export type ComputeConfiguration = {
    worker: WorkerComputeConfiguration;
};
export declare const ComputeConfiguration: any;
export type ResultFormat = "CSV" | "PARQUET" | (string & {});
export declare const ResultFormat: any;
export interface ProtectedQueryInputParameters {
    sqlParameters: ProtectedQuerySQLParameters;
    computeConfiguration?: ComputeConfiguration;
    resultFormat?: ResultFormat;
}
export declare const ProtectedQueryInputParameters: S.Schema<ProtectedQueryInputParameters>;
export type InputChannelDataSource = {
    protectedQueryInputParameters: ProtectedQueryInputParameters;
};
export declare const InputChannelDataSource: any;
export interface InputChannel {
    dataSource: InputChannelDataSource;
    roleArn: string;
}
export declare const InputChannel: S.Schema<InputChannel>;
export type AccountId = string;
export interface PayerConfiguration {
    computePayerAccountId?: string;
    syntheticDataPayerAccountId?: string;
}
export declare const PayerConfiguration: S.Schema<PayerConfiguration>;
export interface CreateMLInputChannelRequest {
    membershipIdentifier: string;
    configuredModelAlgorithmAssociations: string[];
    inputChannel: InputChannel;
    name: string;
    retentionInDays: number;
    description?: string;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    payerConfiguration?: PayerConfiguration;
}
export declare const CreateMLInputChannelRequest: S.Schema<CreateMLInputChannelRequest>;
export type MLInputChannelArn = string;
export interface CreateMLInputChannelResponse {
    mlInputChannelArn: string;
}
export declare const CreateMLInputChannelResponse: S.Schema<CreateMLInputChannelResponse>;
export type HyperParameters = {
    [key: string]: string | undefined;
};
export declare const HyperParameters: any;
export type Environment = {
    [key: string]: string | undefined;
};
export declare const Environment: any;
export type InstanceType = "ml.m4.xlarge" | "ml.m4.2xlarge" | "ml.m4.4xlarge" | "ml.m4.10xlarge" | "ml.m4.16xlarge" | "ml.g4dn.xlarge" | "ml.g4dn.2xlarge" | "ml.g4dn.4xlarge" | "ml.g4dn.8xlarge" | "ml.g4dn.12xlarge" | "ml.g4dn.16xlarge" | "ml.m5.large" | "ml.m5.xlarge" | "ml.m5.2xlarge" | "ml.m5.4xlarge" | "ml.m5.12xlarge" | "ml.m5.24xlarge" | "ml.c4.xlarge" | "ml.c4.2xlarge" | "ml.c4.4xlarge" | "ml.c4.8xlarge" | "ml.p2.xlarge" | "ml.p2.8xlarge" | "ml.p2.16xlarge" | "ml.p4d.24xlarge" | "ml.p4de.24xlarge" | "ml.p5.48xlarge" | "ml.c5.xlarge" | "ml.c5.2xlarge" | "ml.c5.4xlarge" | "ml.c5.9xlarge" | "ml.c5.18xlarge" | "ml.c5n.xlarge" | "ml.c5n.2xlarge" | "ml.c5n.4xlarge" | "ml.c5n.9xlarge" | "ml.c5n.18xlarge" | "ml.g5.xlarge" | "ml.g5.2xlarge" | "ml.g5.4xlarge" | "ml.g5.8xlarge" | "ml.g5.16xlarge" | "ml.g5.12xlarge" | "ml.g5.24xlarge" | "ml.g5.48xlarge" | "ml.trn1.2xlarge" | "ml.trn1.32xlarge" | "ml.trn1n.32xlarge" | "ml.m6i.large" | "ml.m6i.xlarge" | "ml.m6i.2xlarge" | "ml.m6i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.12xlarge" | "ml.m6i.16xlarge" | "ml.m6i.24xlarge" | "ml.m6i.32xlarge" | "ml.c6i.xlarge" | "ml.c6i.2xlarge" | "ml.c6i.8xlarge" | "ml.c6i.4xlarge" | "ml.c6i.12xlarge" | "ml.c6i.16xlarge" | "ml.c6i.24xlarge" | "ml.c6i.32xlarge" | "ml.r5d.large" | "ml.r5d.xlarge" | "ml.r5d.2xlarge" | "ml.r5d.4xlarge" | "ml.r5d.8xlarge" | "ml.r5d.12xlarge" | "ml.r5d.16xlarge" | "ml.r5d.24xlarge" | "ml.t3.medium" | "ml.t3.large" | "ml.t3.xlarge" | "ml.t3.2xlarge" | "ml.r5.large" | "ml.r5.xlarge" | "ml.r5.2xlarge" | "ml.r5.4xlarge" | "ml.r5.8xlarge" | "ml.r5.12xlarge" | "ml.r5.16xlarge" | "ml.r5.24xlarge" | "ml.c7i.large" | "ml.c7i.xlarge" | "ml.c7i.2xlarge" | "ml.c7i.4xlarge" | "ml.c7i.8xlarge" | "ml.c7i.12xlarge" | "ml.c7i.16xlarge" | "ml.c7i.24xlarge" | "ml.c7i.48xlarge" | "ml.m7i.large" | "ml.m7i.xlarge" | "ml.m7i.2xlarge" | "ml.m7i.4xlarge" | "ml.m7i.8xlarge" | "ml.m7i.12xlarge" | "ml.m7i.16xlarge" | "ml.m7i.24xlarge" | "ml.m7i.48xlarge" | "ml.r7i.large" | "ml.r7i.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.4xlarge" | "ml.r7i.8xlarge" | "ml.r7i.12xlarge" | "ml.r7i.16xlarge" | "ml.r7i.24xlarge" | "ml.r7i.48xlarge" | "ml.g6.xlarge" | "ml.g6.2xlarge" | "ml.g6.4xlarge" | "ml.g6.8xlarge" | "ml.g6.12xlarge" | "ml.g6.16xlarge" | "ml.g6.24xlarge" | "ml.g6.48xlarge" | "ml.g6e.xlarge" | "ml.g6e.2xlarge" | "ml.g6e.4xlarge" | "ml.g6e.8xlarge" | "ml.g6e.12xlarge" | "ml.g6e.16xlarge" | "ml.g6e.24xlarge" | "ml.g6e.48xlarge" | "ml.p5en.48xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | "ml.p3.16xlarge" | "ml.p3dn.24xlarge" | (string & {});
export declare const InstanceType: any;
export interface ResourceConfig {
    instanceCount?: number;
    instanceType: InstanceType;
    volumeSizeInGB: number;
}
export declare const ResourceConfig: S.Schema<ResourceConfig>;
export interface StoppingCondition {
    maxRuntimeInSeconds?: number;
}
export declare const StoppingCondition: S.Schema<StoppingCondition>;
export type ModelTrainingDataChannelName = string;
export interface IncrementalTrainingDataChannel {
    trainedModelArn: string;
    versionIdentifier?: string;
    channelName: string;
}
export declare const IncrementalTrainingDataChannel: S.Schema<IncrementalTrainingDataChannel>;
export type IncrementalTrainingDataChannels = IncrementalTrainingDataChannel[];
export declare const IncrementalTrainingDataChannels: any;
export type S3DataDistributionType = "FullyReplicated" | "ShardedByS3Key" | (string & {});
export declare const S3DataDistributionType: any;
export interface ModelTrainingDataChannel {
    mlInputChannelArn: string;
    channelName: string;
    s3DataDistributionType?: S3DataDistributionType;
}
export declare const ModelTrainingDataChannel: S.Schema<ModelTrainingDataChannel>;
export type ModelTrainingDataChannels = ModelTrainingDataChannel[];
export declare const ModelTrainingDataChannels: any;
export type TrainingInputMode = "File" | "FastFile" | "Pipe" | (string & {});
export declare const TrainingInputMode: any;
export interface CreateTrainedModelRequest {
    membershipIdentifier: string;
    name: string;
    configuredModelAlgorithmAssociationArn: string;
    hyperparameters?: {
        [key: string]: string | undefined;
    };
    environment?: {
        [key: string]: string | undefined;
    };
    resourceConfig: ResourceConfig;
    stoppingCondition?: StoppingCondition;
    incrementalTrainingDataChannels?: IncrementalTrainingDataChannel[];
    dataChannels: ModelTrainingDataChannel[];
    trainingInputMode?: TrainingInputMode;
    description?: string;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    mlModelTrainingPayerAccountId?: string;
}
export declare const CreateTrainedModelRequest: S.Schema<CreateTrainedModelRequest>;
export interface CreateTrainedModelResponse {
    trainedModelArn: string;
    versionIdentifier?: string;
}
export declare const CreateTrainedModelResponse: S.Schema<CreateTrainedModelResponse>;
export type DatasetType = "INTERACTIONS" | (string & {});
export declare const DatasetType: any;
export type ColumnName = string;
export type ColumnType = "USER_ID" | "ITEM_ID" | "TIMESTAMP" | "CATEGORICAL_FEATURE" | "NUMERICAL_FEATURE" | (string & {});
export declare const ColumnType: any;
export type ColumnTypeList = ColumnType[];
export declare const ColumnTypeList: any;
export interface ColumnSchema {
    columnName: string;
    columnTypes: ColumnType[];
}
export declare const ColumnSchema: S.Schema<ColumnSchema>;
export type DatasetSchemaList = ColumnSchema[];
export declare const DatasetSchemaList: any;
export type GlueTableName = string;
export type GlueDatabaseName = string;
export interface GlueDataSource {
    tableName: string;
    databaseName: string;
    catalogId?: string;
}
export declare const GlueDataSource: S.Schema<GlueDataSource>;
export interface DataSource {
    glueDataSource: GlueDataSource;
}
export declare const DataSource: S.Schema<DataSource>;
export interface DatasetInputConfig {
    schema: ColumnSchema[];
    dataSource: DataSource;
}
export declare const DatasetInputConfig: S.Schema<DatasetInputConfig>;
export interface Dataset {
    type: DatasetType;
    inputConfig: DatasetInputConfig;
}
export declare const Dataset: S.Schema<Dataset>;
export type DatasetList = Dataset[];
export declare const DatasetList: any;
export interface CreateTrainingDatasetRequest {
    name: string;
    roleArn: string;
    trainingData: Dataset[];
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
}
export declare const CreateTrainingDatasetRequest: S.Schema<CreateTrainingDatasetRequest>;
export interface CreateTrainingDatasetResponse {
    trainingDatasetArn: string;
}
export declare const CreateTrainingDatasetResponse: S.Schema<CreateTrainingDatasetResponse>;
export type AudienceGenerationJobArn = string;
export interface DeleteAudienceGenerationJobRequest {
    audienceGenerationJobArn: string;
}
export declare const DeleteAudienceGenerationJobRequest: S.Schema<DeleteAudienceGenerationJobRequest>;
export interface DeleteAudienceGenerationJobResponse {
}
export declare const DeleteAudienceGenerationJobResponse: S.Schema<DeleteAudienceGenerationJobResponse>;
export interface DeleteAudienceModelRequest {
    audienceModelArn: string;
}
export declare const DeleteAudienceModelRequest: S.Schema<DeleteAudienceModelRequest>;
export interface DeleteAudienceModelResponse {
}
export declare const DeleteAudienceModelResponse: S.Schema<DeleteAudienceModelResponse>;
export interface DeleteConfiguredAudienceModelRequest {
    configuredAudienceModelArn: string;
}
export declare const DeleteConfiguredAudienceModelRequest: S.Schema<DeleteConfiguredAudienceModelRequest>;
export interface DeleteConfiguredAudienceModelResponse {
}
export declare const DeleteConfiguredAudienceModelResponse: S.Schema<DeleteConfiguredAudienceModelResponse>;
export interface DeleteConfiguredAudienceModelPolicyRequest {
    configuredAudienceModelArn: string;
}
export declare const DeleteConfiguredAudienceModelPolicyRequest: S.Schema<DeleteConfiguredAudienceModelPolicyRequest>;
export interface DeleteConfiguredAudienceModelPolicyResponse {
}
export declare const DeleteConfiguredAudienceModelPolicyResponse: S.Schema<DeleteConfiguredAudienceModelPolicyResponse>;
export interface DeleteConfiguredModelAlgorithmRequest {
    configuredModelAlgorithmArn: string;
}
export declare const DeleteConfiguredModelAlgorithmRequest: S.Schema<DeleteConfiguredModelAlgorithmRequest>;
export interface DeleteConfiguredModelAlgorithmResponse {
}
export declare const DeleteConfiguredModelAlgorithmResponse: S.Schema<DeleteConfiguredModelAlgorithmResponse>;
export interface DeleteConfiguredModelAlgorithmAssociationRequest {
    configuredModelAlgorithmAssociationArn: string;
    membershipIdentifier: string;
}
export declare const DeleteConfiguredModelAlgorithmAssociationRequest: S.Schema<DeleteConfiguredModelAlgorithmAssociationRequest>;
export interface DeleteConfiguredModelAlgorithmAssociationResponse {
}
export declare const DeleteConfiguredModelAlgorithmAssociationResponse: S.Schema<DeleteConfiguredModelAlgorithmAssociationResponse>;
export interface DeleteMLConfigurationRequest {
    membershipIdentifier: string;
}
export declare const DeleteMLConfigurationRequest: S.Schema<DeleteMLConfigurationRequest>;
export interface DeleteMLConfigurationResponse {
}
export declare const DeleteMLConfigurationResponse: S.Schema<DeleteMLConfigurationResponse>;
export interface DeleteMLInputChannelDataRequest {
    mlInputChannelArn: string;
    membershipIdentifier: string;
}
export declare const DeleteMLInputChannelDataRequest: S.Schema<DeleteMLInputChannelDataRequest>;
export interface DeleteMLInputChannelDataResponse {
}
export declare const DeleteMLInputChannelDataResponse: S.Schema<DeleteMLInputChannelDataResponse>;
export interface DeleteTrainedModelOutputRequest {
    trainedModelArn: string;
    membershipIdentifier: string;
    versionIdentifier?: string;
}
export declare const DeleteTrainedModelOutputRequest: S.Schema<DeleteTrainedModelOutputRequest>;
export interface DeleteTrainedModelOutputResponse {
}
export declare const DeleteTrainedModelOutputResponse: S.Schema<DeleteTrainedModelOutputResponse>;
export interface DeleteTrainingDatasetRequest {
    trainingDatasetArn: string;
}
export declare const DeleteTrainingDatasetRequest: S.Schema<DeleteTrainingDatasetRequest>;
export interface DeleteTrainingDatasetResponse {
}
export declare const DeleteTrainingDatasetResponse: S.Schema<DeleteTrainingDatasetResponse>;
export interface GetAudienceGenerationJobRequest {
    audienceGenerationJobArn: string;
}
export declare const GetAudienceGenerationJobRequest: S.Schema<GetAudienceGenerationJobRequest>;
export type AudienceGenerationJobStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "ACTIVE" | "DELETE_PENDING" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export declare const AudienceGenerationJobStatus: any;
export interface StatusDetails {
    statusCode?: string;
    message?: string;
}
export declare const StatusDetails: S.Schema<StatusDetails>;
export interface AudienceGenerationJobDataSource {
    dataSource?: S3ConfigMap;
    roleArn: string;
    sqlParameters?: ProtectedQuerySQLParameters;
    sqlComputeConfiguration?: ComputeConfiguration;
}
export declare const AudienceGenerationJobDataSource: S.Schema<AudienceGenerationJobDataSource>;
export interface AudienceSize {
    type: AudienceSizeType;
    value: number;
}
export declare const AudienceSize: S.Schema<AudienceSize>;
export interface RelevanceMetric {
    audienceSize: AudienceSize;
    score?: number;
}
export declare const RelevanceMetric: S.Schema<RelevanceMetric>;
export type RelevanceMetrics = RelevanceMetric[];
export declare const RelevanceMetrics: any;
export interface AudienceQualityMetrics {
    relevanceMetrics: RelevanceMetric[];
    recallMetric?: number;
}
export declare const AudienceQualityMetrics: S.Schema<AudienceQualityMetrics>;
export interface GetAudienceGenerationJobResponse {
    createTime: Date;
    updateTime: Date;
    audienceGenerationJobArn: string;
    name: string;
    description?: string;
    status: AudienceGenerationJobStatus;
    statusDetails?: StatusDetails;
    configuredAudienceModelArn: string;
    seedAudience?: AudienceGenerationJobDataSource;
    includeSeedInOutput?: boolean;
    collaborationId?: string;
    metrics?: AudienceQualityMetrics;
    startedBy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    protectedQueryIdentifier?: string;
}
export declare const GetAudienceGenerationJobResponse: S.Schema<GetAudienceGenerationJobResponse>;
export interface GetAudienceModelRequest {
    audienceModelArn: string;
}
export declare const GetAudienceModelRequest: S.Schema<GetAudienceModelRequest>;
export type AudienceModelStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "ACTIVE" | "DELETE_PENDING" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export declare const AudienceModelStatus: any;
export interface GetAudienceModelResponse {
    createTime: Date;
    updateTime: Date;
    trainingDataStartTime?: Date;
    trainingDataEndTime?: Date;
    audienceModelArn: string;
    name: string;
    trainingDatasetArn: string;
    status: AudienceModelStatus;
    statusDetails?: StatusDetails;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
}
export declare const GetAudienceModelResponse: S.Schema<GetAudienceModelResponse>;
export interface GetCollaborationConfiguredModelAlgorithmAssociationRequest {
    configuredModelAlgorithmAssociationArn: string;
    collaborationIdentifier: string;
}
export declare const GetCollaborationConfiguredModelAlgorithmAssociationRequest: S.Schema<GetCollaborationConfiguredModelAlgorithmAssociationRequest>;
export interface GetCollaborationConfiguredModelAlgorithmAssociationResponse {
    createTime: Date;
    updateTime: Date;
    configuredModelAlgorithmAssociationArn: string;
    membershipIdentifier: string;
    collaborationIdentifier: string;
    configuredModelAlgorithmArn: string;
    name: string;
    description?: string;
    creatorAccountId: string;
    privacyConfiguration?: PrivacyConfiguration;
}
export declare const GetCollaborationConfiguredModelAlgorithmAssociationResponse: S.Schema<GetCollaborationConfiguredModelAlgorithmAssociationResponse>;
export interface GetCollaborationMLInputChannelRequest {
    mlInputChannelArn: string;
    collaborationIdentifier: string;
}
export declare const GetCollaborationMLInputChannelRequest: S.Schema<GetCollaborationMLInputChannelRequest>;
export type MLInputChannelStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "ACTIVE" | "DELETE_PENDING" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "INACTIVE" | (string & {});
export declare const MLInputChannelStatus: any;
export type BudgetedResourceArn = string;
export type Budget = number;
export type AccessBudgetType = "CALENDAR_DAY" | "CALENDAR_MONTH" | "CALENDAR_WEEK" | "LIFETIME" | (string & {});
export declare const AccessBudgetType: any;
export type AutoRefreshMode = "ENABLED" | "DISABLED" | (string & {});
export declare const AutoRefreshMode: any;
export interface AccessBudgetDetails {
    startTime: Date;
    endTime?: Date;
    remainingBudget: number;
    budget: number;
    budgetType: AccessBudgetType;
    autoRefresh?: AutoRefreshMode;
}
export declare const AccessBudgetDetails: S.Schema<AccessBudgetDetails>;
export type AccessBudgetDetailsList = AccessBudgetDetails[];
export declare const AccessBudgetDetailsList: any;
export interface AccessBudget {
    resourceArn: string;
    details: AccessBudgetDetails[];
    aggregateRemainingBudget: number;
}
export declare const AccessBudget: S.Schema<AccessBudget>;
export type AccessBudgets = AccessBudget[];
export declare const AccessBudgets: any;
export type PrivacyBudgets = {
    accessBudgets: AccessBudget[];
};
export declare const PrivacyBudgets: any;
export type SyntheticDataColumnName = string;
export type SyntheticDataColumnType = "CATEGORICAL" | "NUMERICAL" | (string & {});
export declare const SyntheticDataColumnType: any;
export interface SyntheticDataColumnProperties {
    columnName: string;
    columnType: SyntheticDataColumnType;
    isPredictiveValue: boolean;
}
export declare const SyntheticDataColumnProperties: S.Schema<SyntheticDataColumnProperties>;
export type ColumnMappingList = SyntheticDataColumnProperties[];
export declare const ColumnMappingList: any;
export interface ColumnClassificationDetails {
    columnMapping: SyntheticDataColumnProperties[];
}
export declare const ColumnClassificationDetails: S.Schema<ColumnClassificationDetails>;
export interface MLSyntheticDataParameters {
    epsilon: number;
    maxMembershipInferenceAttackScore: number;
    columnClassification?: ColumnClassificationDetails;
}
export declare const MLSyntheticDataParameters: S.Schema<MLSyntheticDataParameters>;
export type MembershipInferenceAttackVersion = "DISTANCE_TO_CLOSEST_RECORD_V1" | (string & {});
export declare const MembershipInferenceAttackVersion: any;
export interface MembershipInferenceAttackScore {
    attackVersion: MembershipInferenceAttackVersion;
    score: number;
}
export declare const MembershipInferenceAttackScore: S.Schema<MembershipInferenceAttackScore>;
export type MembershipInferenceAttackScoreList = MembershipInferenceAttackScore[];
export declare const MembershipInferenceAttackScoreList: any;
export interface DataPrivacyScores {
    membershipInferenceAttackScores: MembershipInferenceAttackScore[];
}
export declare const DataPrivacyScores: S.Schema<DataPrivacyScores>;
export interface SyntheticDataEvaluationScores {
    dataPrivacyScores: DataPrivacyScores;
}
export declare const SyntheticDataEvaluationScores: S.Schema<SyntheticDataEvaluationScores>;
export interface SyntheticDataConfiguration {
    syntheticDataParameters: MLSyntheticDataParameters;
    syntheticDataEvaluationScores?: SyntheticDataEvaluationScores;
}
export declare const SyntheticDataConfiguration: S.Schema<SyntheticDataConfiguration>;
export interface GetCollaborationMLInputChannelResponse {
    membershipIdentifier: string;
    collaborationIdentifier: string;
    mlInputChannelArn: string;
    name: string;
    configuredModelAlgorithmAssociations: string[];
    status: MLInputChannelStatus;
    statusDetails?: StatusDetails;
    retentionInDays: number;
    numberOfRecords?: number;
    privacyBudgets?: PrivacyBudgets;
    description?: string;
    syntheticDataConfiguration?: SyntheticDataConfiguration;
    payerConfiguration?: PayerConfiguration;
    createTime: Date;
    updateTime: Date;
    creatorAccountId: string;
}
export declare const GetCollaborationMLInputChannelResponse: S.Schema<GetCollaborationMLInputChannelResponse>;
export interface GetCollaborationTrainedModelRequest {
    trainedModelArn: string;
    collaborationIdentifier: string;
    versionIdentifier?: string;
}
export declare const GetCollaborationTrainedModelRequest: S.Schema<GetCollaborationTrainedModelRequest>;
export interface IncrementalTrainingDataChannelOutput {
    channelName: string;
    versionIdentifier?: string;
    modelName: string;
}
export declare const IncrementalTrainingDataChannelOutput: S.Schema<IncrementalTrainingDataChannelOutput>;
export type IncrementalTrainingDataChannelsOutput = IncrementalTrainingDataChannelOutput[];
export declare const IncrementalTrainingDataChannelsOutput: any;
export type TrainedModelStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "ACTIVE" | "DELETE_PENDING" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "INACTIVE" | "CANCEL_PENDING" | "CANCEL_IN_PROGRESS" | "CANCEL_FAILED" | (string & {});
export declare const TrainedModelStatus: any;
export type MetricsStatus = "PUBLISH_SUCCEEDED" | "PUBLISH_FAILED" | (string & {});
export declare const MetricsStatus: any;
export type LogsStatus = "PUBLISH_SUCCEEDED" | "PUBLISH_FAILED" | (string & {});
export declare const LogsStatus: any;
export interface GetCollaborationTrainedModelResponse {
    membershipIdentifier: string;
    collaborationIdentifier: string;
    trainedModelArn: string;
    versionIdentifier?: string;
    incrementalTrainingDataChannels?: IncrementalTrainingDataChannelOutput[];
    name: string;
    description?: string;
    status: TrainedModelStatus;
    statusDetails?: StatusDetails;
    configuredModelAlgorithmAssociationArn: string;
    resourceConfig?: ResourceConfig;
    trainingInputMode?: TrainingInputMode;
    stoppingCondition?: StoppingCondition;
    metricsStatus?: MetricsStatus;
    metricsStatusDetails?: string;
    logsStatus?: LogsStatus;
    logsStatusDetails?: string;
    trainingContainerImageDigest?: string;
    mlModelTrainingPayerAccountId?: string;
    createTime: Date;
    updateTime: Date;
    creatorAccountId: string;
}
export declare const GetCollaborationTrainedModelResponse: S.Schema<GetCollaborationTrainedModelResponse>;
export interface GetConfiguredAudienceModelRequest {
    configuredAudienceModelArn: string;
}
export declare const GetConfiguredAudienceModelRequest: S.Schema<GetConfiguredAudienceModelRequest>;
export type ConfiguredAudienceModelStatus = "ACTIVE" | (string & {});
export declare const ConfiguredAudienceModelStatus: any;
export interface GetConfiguredAudienceModelResponse {
    createTime: Date;
    updateTime: Date;
    configuredAudienceModelArn: string;
    name: string;
    audienceModelArn: string;
    outputConfig: ConfiguredAudienceModelOutputConfig;
    description?: string;
    status: ConfiguredAudienceModelStatus;
    sharedAudienceMetrics: SharedAudienceMetrics[];
    minMatchingSeedSize?: number;
    audienceSizeConfig?: AudienceSizeConfig;
    tags?: {
        [key: string]: string | undefined;
    };
    childResourceTagOnCreatePolicy?: TagOnCreatePolicy;
}
export declare const GetConfiguredAudienceModelResponse: S.Schema<GetConfiguredAudienceModelResponse>;
export interface GetConfiguredAudienceModelPolicyRequest {
    configuredAudienceModelArn: string;
}
export declare const GetConfiguredAudienceModelPolicyRequest: S.Schema<GetConfiguredAudienceModelPolicyRequest>;
export type ResourcePolicy = string;
export type Hash = string;
export interface GetConfiguredAudienceModelPolicyResponse {
    configuredAudienceModelArn: string;
    configuredAudienceModelPolicy: string;
    policyHash: string;
}
export declare const GetConfiguredAudienceModelPolicyResponse: S.Schema<GetConfiguredAudienceModelPolicyResponse>;
export interface GetConfiguredModelAlgorithmRequest {
    configuredModelAlgorithmArn: string;
}
export declare const GetConfiguredModelAlgorithmRequest: S.Schema<GetConfiguredModelAlgorithmRequest>;
export interface GetConfiguredModelAlgorithmResponse {
    createTime: Date;
    updateTime: Date;
    configuredModelAlgorithmArn: string;
    name: string;
    trainingContainerConfig?: ContainerConfig;
    inferenceContainerConfig?: InferenceContainerConfig;
    roleArn: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export declare const GetConfiguredModelAlgorithmResponse: S.Schema<GetConfiguredModelAlgorithmResponse>;
export interface GetConfiguredModelAlgorithmAssociationRequest {
    configuredModelAlgorithmAssociationArn: string;
    membershipIdentifier: string;
}
export declare const GetConfiguredModelAlgorithmAssociationRequest: S.Schema<GetConfiguredModelAlgorithmAssociationRequest>;
export interface GetConfiguredModelAlgorithmAssociationResponse {
    createTime: Date;
    updateTime: Date;
    configuredModelAlgorithmAssociationArn: string;
    membershipIdentifier: string;
    collaborationIdentifier: string;
    configuredModelAlgorithmArn: string;
    name: string;
    privacyConfiguration?: PrivacyConfiguration;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetConfiguredModelAlgorithmAssociationResponse: S.Schema<GetConfiguredModelAlgorithmAssociationResponse>;
export interface GetMLConfigurationRequest {
    membershipIdentifier: string;
}
export declare const GetMLConfigurationRequest: S.Schema<GetMLConfigurationRequest>;
export interface Destination {
    s3Destination: S3ConfigMap;
}
export declare const Destination: S.Schema<Destination>;
export interface MLOutputConfiguration {
    destination?: Destination;
    roleArn: string;
}
export declare const MLOutputConfiguration: S.Schema<MLOutputConfiguration>;
export interface GetMLConfigurationResponse {
    membershipIdentifier: string;
    defaultOutputLocation: MLOutputConfiguration;
    createTime: Date;
    updateTime: Date;
}
export declare const GetMLConfigurationResponse: S.Schema<GetMLConfigurationResponse>;
export interface GetMLInputChannelRequest {
    mlInputChannelArn: string;
    membershipIdentifier: string;
}
export declare const GetMLInputChannelRequest: S.Schema<GetMLInputChannelRequest>;
export interface GetMLInputChannelResponse {
    membershipIdentifier: string;
    collaborationIdentifier: string;
    mlInputChannelArn: string;
    name: string;
    configuredModelAlgorithmAssociations: string[];
    status: MLInputChannelStatus;
    statusDetails?: StatusDetails;
    retentionInDays: number;
    numberOfRecords?: number;
    privacyBudgets?: PrivacyBudgets;
    description?: string;
    syntheticDataConfiguration?: SyntheticDataConfiguration;
    payerConfiguration?: PayerConfiguration;
    createTime: Date;
    updateTime: Date;
    inputChannel: InputChannel;
    protectedQueryIdentifier?: string;
    numberOfFiles?: number;
    sizeInGb?: number;
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetMLInputChannelResponse: S.Schema<GetMLInputChannelResponse>;
export interface GetTrainedModelRequest {
    trainedModelArn: string;
    membershipIdentifier: string;
    versionIdentifier?: string;
}
export declare const GetTrainedModelRequest: S.Schema<GetTrainedModelRequest>;
export interface GetTrainedModelResponse {
    membershipIdentifier: string;
    collaborationIdentifier: string;
    trainedModelArn: string;
    versionIdentifier?: string;
    incrementalTrainingDataChannels?: IncrementalTrainingDataChannelOutput[];
    name: string;
    description?: string;
    status: TrainedModelStatus;
    statusDetails?: StatusDetails;
    configuredModelAlgorithmAssociationArn: string;
    resourceConfig?: ResourceConfig;
    trainingInputMode?: TrainingInputMode;
    stoppingCondition?: StoppingCondition;
    metricsStatus?: MetricsStatus;
    metricsStatusDetails?: string;
    logsStatus?: LogsStatus;
    logsStatusDetails?: string;
    trainingContainerImageDigest?: string;
    mlModelTrainingPayerAccountId?: string;
    createTime: Date;
    updateTime: Date;
    hyperparameters?: {
        [key: string]: string | undefined;
    };
    environment?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    dataChannels: ModelTrainingDataChannel[];
}
export declare const GetTrainedModelResponse: S.Schema<GetTrainedModelResponse>;
export interface GetTrainedModelInferenceJobRequest {
    membershipIdentifier: string;
    trainedModelInferenceJobArn: string;
}
export declare const GetTrainedModelInferenceJobRequest: S.Schema<GetTrainedModelInferenceJobRequest>;
export type TrainedModelInferenceJobStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "ACTIVE" | "CANCEL_PENDING" | "CANCEL_IN_PROGRESS" | "CANCEL_FAILED" | "INACTIVE" | (string & {});
export declare const TrainedModelInferenceJobStatus: any;
export type InferenceInstanceType = "ml.r7i.48xlarge" | "ml.r6i.16xlarge" | "ml.m6i.xlarge" | "ml.m5.4xlarge" | "ml.p2.xlarge" | "ml.m4.16xlarge" | "ml.r7i.16xlarge" | "ml.m7i.xlarge" | "ml.m6i.12xlarge" | "ml.r7i.8xlarge" | "ml.r7i.large" | "ml.m7i.12xlarge" | "ml.m6i.24xlarge" | "ml.m7i.24xlarge" | "ml.r6i.8xlarge" | "ml.r6i.large" | "ml.g5.2xlarge" | "ml.m5.large" | "ml.m7i.48xlarge" | "ml.m6i.16xlarge" | "ml.p2.16xlarge" | "ml.g5.4xlarge" | "ml.m7i.16xlarge" | "ml.c4.2xlarge" | "ml.c5.2xlarge" | "ml.c6i.32xlarge" | "ml.c4.4xlarge" | "ml.g5.8xlarge" | "ml.c6i.xlarge" | "ml.c5.4xlarge" | "ml.g4dn.xlarge" | "ml.c7i.xlarge" | "ml.c6i.12xlarge" | "ml.g4dn.12xlarge" | "ml.c7i.12xlarge" | "ml.c6i.24xlarge" | "ml.g4dn.2xlarge" | "ml.c7i.24xlarge" | "ml.c7i.2xlarge" | "ml.c4.8xlarge" | "ml.c6i.2xlarge" | "ml.g4dn.4xlarge" | "ml.c7i.48xlarge" | "ml.c7i.4xlarge" | "ml.c6i.16xlarge" | "ml.c5.9xlarge" | "ml.g4dn.16xlarge" | "ml.c7i.16xlarge" | "ml.c6i.4xlarge" | "ml.c5.xlarge" | "ml.c4.xlarge" | "ml.g4dn.8xlarge" | "ml.c7i.8xlarge" | "ml.c7i.large" | "ml.g5.xlarge" | "ml.c6i.8xlarge" | "ml.c6i.large" | "ml.g5.12xlarge" | "ml.g5.24xlarge" | "ml.m7i.2xlarge" | "ml.c5.18xlarge" | "ml.g5.48xlarge" | "ml.m6i.2xlarge" | "ml.g5.16xlarge" | "ml.m7i.4xlarge" | "ml.r6i.32xlarge" | "ml.m6i.4xlarge" | "ml.m5.xlarge" | "ml.m4.10xlarge" | "ml.r6i.xlarge" | "ml.m5.12xlarge" | "ml.m4.xlarge" | "ml.r7i.2xlarge" | "ml.r7i.xlarge" | "ml.r6i.12xlarge" | "ml.m5.24xlarge" | "ml.r7i.12xlarge" | "ml.m7i.8xlarge" | "ml.m7i.large" | "ml.r6i.24xlarge" | "ml.r6i.2xlarge" | "ml.m4.2xlarge" | "ml.r7i.24xlarge" | "ml.r7i.4xlarge" | "ml.m6i.8xlarge" | "ml.m6i.large" | "ml.m5.2xlarge" | "ml.p2.8xlarge" | "ml.r6i.4xlarge" | "ml.m6i.32xlarge" | "ml.m4.4xlarge" | "ml.p3.16xlarge" | "ml.p3.2xlarge" | "ml.p3.8xlarge" | (string & {});
export declare const InferenceInstanceType: any;
export interface InferenceResourceConfig {
    instanceType: InferenceInstanceType;
    instanceCount?: number;
}
export declare const InferenceResourceConfig: S.Schema<InferenceResourceConfig>;
export interface InferenceReceiverMember {
    accountId: string;
}
export declare const InferenceReceiverMember: S.Schema<InferenceReceiverMember>;
export type InferenceReceiverMembers = InferenceReceiverMember[];
export declare const InferenceReceiverMembers: any;
export interface InferenceOutputConfiguration {
    accept?: string;
    members: InferenceReceiverMember[];
}
export declare const InferenceOutputConfiguration: S.Schema<InferenceOutputConfiguration>;
export interface ModelInferenceDataSource {
    mlInputChannelArn: string;
}
export declare const ModelInferenceDataSource: S.Schema<ModelInferenceDataSource>;
export interface InferenceContainerExecutionParameters {
    maxPayloadInMB?: number;
}
export declare const InferenceContainerExecutionParameters: S.Schema<InferenceContainerExecutionParameters>;
export type InferenceEnvironmentMap = {
    [key: string]: string | undefined;
};
export declare const InferenceEnvironmentMap: any;
export interface GetTrainedModelInferenceJobResponse {
    createTime: Date;
    updateTime: Date;
    trainedModelInferenceJobArn: string;
    configuredModelAlgorithmAssociationArn?: string;
    name: string;
    status: TrainedModelInferenceJobStatus;
    trainedModelArn: string;
    trainedModelVersionIdentifier?: string;
    resourceConfig: InferenceResourceConfig;
    outputConfiguration: InferenceOutputConfiguration;
    membershipIdentifier: string;
    dataSource: ModelInferenceDataSource;
    containerExecutionParameters?: InferenceContainerExecutionParameters;
    statusDetails?: StatusDetails;
    description?: string;
    inferenceContainerImageDigest?: string;
    environment?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
    metricsStatus?: MetricsStatus;
    metricsStatusDetails?: string;
    logsStatus?: LogsStatus;
    logsStatusDetails?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    mlModelInferencePayerAccountId?: string;
}
export declare const GetTrainedModelInferenceJobResponse: S.Schema<GetTrainedModelInferenceJobResponse>;
export interface GetTrainingDatasetRequest {
    trainingDatasetArn: string;
}
export declare const GetTrainingDatasetRequest: S.Schema<GetTrainingDatasetRequest>;
export type TrainingDatasetStatus = "ACTIVE" | (string & {});
export declare const TrainingDatasetStatus: any;
export interface GetTrainingDatasetResponse {
    createTime: Date;
    updateTime: Date;
    trainingDatasetArn: string;
    name: string;
    trainingData: Dataset[];
    status: TrainingDatasetStatus;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    };
    description?: string;
}
export declare const GetTrainingDatasetResponse: S.Schema<GetTrainingDatasetResponse>;
export type NextToken = string;
export type MaxResults = number;
export interface ListAudienceExportJobsRequest {
    nextToken?: string;
    maxResults?: number;
    audienceGenerationJobArn?: string;
}
export declare const ListAudienceExportJobsRequest: S.Schema<ListAudienceExportJobsRequest>;
export type AudienceExportJobStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "ACTIVE" | (string & {});
export declare const AudienceExportJobStatus: any;
export interface AudienceExportJobSummary {
    createTime: Date;
    updateTime: Date;
    name: string;
    audienceGenerationJobArn: string;
    audienceSize: AudienceSize;
    description?: string;
    status: AudienceExportJobStatus;
    statusDetails?: StatusDetails;
    outputLocation?: string;
}
export declare const AudienceExportJobSummary: S.Schema<AudienceExportJobSummary>;
export type AudienceExportJobList = AudienceExportJobSummary[];
export declare const AudienceExportJobList: any;
export interface ListAudienceExportJobsResponse {
    nextToken?: string;
    audienceExportJobs: AudienceExportJobSummary[];
}
export declare const ListAudienceExportJobsResponse: S.Schema<ListAudienceExportJobsResponse>;
export interface ListAudienceGenerationJobsRequest {
    nextToken?: string;
    maxResults?: number;
    configuredAudienceModelArn?: string;
    collaborationId?: string;
}
export declare const ListAudienceGenerationJobsRequest: S.Schema<ListAudienceGenerationJobsRequest>;
export interface AudienceGenerationJobSummary {
    createTime: Date;
    updateTime: Date;
    audienceGenerationJobArn: string;
    name: string;
    description?: string;
    status: AudienceGenerationJobStatus;
    configuredAudienceModelArn: string;
    collaborationId?: string;
    startedBy?: string;
}
export declare const AudienceGenerationJobSummary: S.Schema<AudienceGenerationJobSummary>;
export type AudienceGenerationJobList = AudienceGenerationJobSummary[];
export declare const AudienceGenerationJobList: any;
export interface ListAudienceGenerationJobsResponse {
    nextToken?: string;
    audienceGenerationJobs: AudienceGenerationJobSummary[];
}
export declare const ListAudienceGenerationJobsResponse: S.Schema<ListAudienceGenerationJobsResponse>;
export interface ListAudienceModelsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListAudienceModelsRequest: S.Schema<ListAudienceModelsRequest>;
export interface AudienceModelSummary {
    createTime: Date;
    updateTime: Date;
    audienceModelArn: string;
    name: string;
    trainingDatasetArn: string;
    status: AudienceModelStatus;
    description?: string;
}
export declare const AudienceModelSummary: S.Schema<AudienceModelSummary>;
export type AudienceModelList = AudienceModelSummary[];
export declare const AudienceModelList: any;
export interface ListAudienceModelsResponse {
    nextToken?: string;
    audienceModels: AudienceModelSummary[];
}
export declare const ListAudienceModelsResponse: S.Schema<ListAudienceModelsResponse>;
export interface ListCollaborationConfiguredModelAlgorithmAssociationsRequest {
    nextToken?: string;
    maxResults?: number;
    collaborationIdentifier: string;
}
export declare const ListCollaborationConfiguredModelAlgorithmAssociationsRequest: S.Schema<ListCollaborationConfiguredModelAlgorithmAssociationsRequest>;
export interface CollaborationConfiguredModelAlgorithmAssociationSummary {
    createTime: Date;
    updateTime: Date;
    configuredModelAlgorithmAssociationArn: string;
    name: string;
    description?: string;
    membershipIdentifier: string;
    collaborationIdentifier: string;
    configuredModelAlgorithmArn: string;
    creatorAccountId: string;
}
export declare const CollaborationConfiguredModelAlgorithmAssociationSummary: S.Schema<CollaborationConfiguredModelAlgorithmAssociationSummary>;
export type CollaborationConfiguredModelAlgorithmAssociationList = CollaborationConfiguredModelAlgorithmAssociationSummary[];
export declare const CollaborationConfiguredModelAlgorithmAssociationList: any;
export interface ListCollaborationConfiguredModelAlgorithmAssociationsResponse {
    nextToken?: string;
    collaborationConfiguredModelAlgorithmAssociations: CollaborationConfiguredModelAlgorithmAssociationSummary[];
}
export declare const ListCollaborationConfiguredModelAlgorithmAssociationsResponse: S.Schema<ListCollaborationConfiguredModelAlgorithmAssociationsResponse>;
export interface ListCollaborationMLInputChannelsRequest {
    nextToken?: string;
    maxResults?: number;
    collaborationIdentifier: string;
}
export declare const ListCollaborationMLInputChannelsRequest: S.Schema<ListCollaborationMLInputChannelsRequest>;
export interface CollaborationMLInputChannelSummary {
    createTime: Date;
    updateTime: Date;
    membershipIdentifier: string;
    collaborationIdentifier: string;
    name: string;
    configuredModelAlgorithmAssociations: string[];
    mlInputChannelArn: string;
    status: MLInputChannelStatus;
    creatorAccountId: string;
    description?: string;
    payerConfiguration?: PayerConfiguration;
}
export declare const CollaborationMLInputChannelSummary: S.Schema<CollaborationMLInputChannelSummary>;
export type CollaborationMLInputChannelsList = CollaborationMLInputChannelSummary[];
export declare const CollaborationMLInputChannelsList: any;
export interface ListCollaborationMLInputChannelsResponse {
    nextToken?: string;
    collaborationMLInputChannelsList: CollaborationMLInputChannelSummary[];
}
export declare const ListCollaborationMLInputChannelsResponse: S.Schema<ListCollaborationMLInputChannelsResponse>;
export interface ListCollaborationTrainedModelExportJobsRequest {
    nextToken?: string;
    maxResults?: number;
    collaborationIdentifier: string;
    trainedModelArn: string;
    trainedModelVersionIdentifier?: string;
}
export declare const ListCollaborationTrainedModelExportJobsRequest: S.Schema<ListCollaborationTrainedModelExportJobsRequest>;
export interface TrainedModelExportReceiverMember {
    accountId: string;
}
export declare const TrainedModelExportReceiverMember: S.Schema<TrainedModelExportReceiverMember>;
export type TrainedModelExportReceiverMembers = TrainedModelExportReceiverMember[];
export declare const TrainedModelExportReceiverMembers: any;
export interface TrainedModelExportOutputConfiguration {
    members: TrainedModelExportReceiverMember[];
}
export declare const TrainedModelExportOutputConfiguration: S.Schema<TrainedModelExportOutputConfiguration>;
export type TrainedModelExportJobStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "ACTIVE" | (string & {});
export declare const TrainedModelExportJobStatus: any;
export interface CollaborationTrainedModelExportJobSummary {
    createTime: Date;
    updateTime: Date;
    name: string;
    outputConfiguration: TrainedModelExportOutputConfiguration;
    status: TrainedModelExportJobStatus;
    statusDetails?: StatusDetails;
    description?: string;
    creatorAccountId: string;
    trainedModelArn: string;
    trainedModelVersionIdentifier?: string;
    membershipIdentifier: string;
    collaborationIdentifier: string;
}
export declare const CollaborationTrainedModelExportJobSummary: S.Schema<CollaborationTrainedModelExportJobSummary>;
export type CollaborationTrainedModelExportJobList = CollaborationTrainedModelExportJobSummary[];
export declare const CollaborationTrainedModelExportJobList: any;
export interface ListCollaborationTrainedModelExportJobsResponse {
    nextToken?: string;
    collaborationTrainedModelExportJobs: CollaborationTrainedModelExportJobSummary[];
}
export declare const ListCollaborationTrainedModelExportJobsResponse: S.Schema<ListCollaborationTrainedModelExportJobsResponse>;
export interface ListCollaborationTrainedModelInferenceJobsRequest {
    nextToken?: string;
    maxResults?: number;
    collaborationIdentifier: string;
    trainedModelArn?: string;
    trainedModelVersionIdentifier?: string;
}
export declare const ListCollaborationTrainedModelInferenceJobsRequest: S.Schema<ListCollaborationTrainedModelInferenceJobsRequest>;
export interface CollaborationTrainedModelInferenceJobSummary {
    trainedModelInferenceJobArn: string;
    configuredModelAlgorithmAssociationArn?: string;
    membershipIdentifier: string;
    trainedModelArn: string;
    trainedModelVersionIdentifier?: string;
    collaborationIdentifier: string;
    status: TrainedModelInferenceJobStatus;
    outputConfiguration: InferenceOutputConfiguration;
    name: string;
    description?: string;
    metricsStatus?: MetricsStatus;
    metricsStatusDetails?: string;
    logsStatus?: LogsStatus;
    logsStatusDetails?: string;
    mlModelInferencePayerAccountId?: string;
    createTime: Date;
    updateTime: Date;
    creatorAccountId: string;
}
export declare const CollaborationTrainedModelInferenceJobSummary: S.Schema<CollaborationTrainedModelInferenceJobSummary>;
export type CollaborationTrainedModelInferenceJobList = CollaborationTrainedModelInferenceJobSummary[];
export declare const CollaborationTrainedModelInferenceJobList: any;
export interface ListCollaborationTrainedModelInferenceJobsResponse {
    nextToken?: string;
    collaborationTrainedModelInferenceJobs: CollaborationTrainedModelInferenceJobSummary[];
}
export declare const ListCollaborationTrainedModelInferenceJobsResponse: S.Schema<ListCollaborationTrainedModelInferenceJobsResponse>;
export interface ListCollaborationTrainedModelsRequest {
    nextToken?: string;
    maxResults?: number;
    collaborationIdentifier: string;
}
export declare const ListCollaborationTrainedModelsRequest: S.Schema<ListCollaborationTrainedModelsRequest>;
export interface CollaborationTrainedModelSummary {
    createTime: Date;
    updateTime: Date;
    trainedModelArn: string;
    name: string;
    versionIdentifier?: string;
    incrementalTrainingDataChannels?: IncrementalTrainingDataChannelOutput[];
    description?: string;
    membershipIdentifier: string;
    collaborationIdentifier: string;
    status: TrainedModelStatus;
    configuredModelAlgorithmAssociationArn: string;
    creatorAccountId: string;
    mlModelTrainingPayerAccountId?: string;
}
export declare const CollaborationTrainedModelSummary: S.Schema<CollaborationTrainedModelSummary>;
export type CollaborationTrainedModelList = CollaborationTrainedModelSummary[];
export declare const CollaborationTrainedModelList: any;
export interface ListCollaborationTrainedModelsResponse {
    nextToken?: string;
    collaborationTrainedModels: CollaborationTrainedModelSummary[];
}
export declare const ListCollaborationTrainedModelsResponse: S.Schema<ListCollaborationTrainedModelsResponse>;
export interface ListConfiguredAudienceModelsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListConfiguredAudienceModelsRequest: S.Schema<ListConfiguredAudienceModelsRequest>;
export interface ConfiguredAudienceModelSummary {
    createTime: Date;
    updateTime: Date;
    name: string;
    audienceModelArn: string;
    outputConfig: ConfiguredAudienceModelOutputConfig;
    description?: string;
    configuredAudienceModelArn: string;
    status: ConfiguredAudienceModelStatus;
}
export declare const ConfiguredAudienceModelSummary: S.Schema<ConfiguredAudienceModelSummary>;
export type ConfiguredAudienceModelList = ConfiguredAudienceModelSummary[];
export declare const ConfiguredAudienceModelList: any;
export interface ListConfiguredAudienceModelsResponse {
    nextToken?: string;
    configuredAudienceModels: ConfiguredAudienceModelSummary[];
}
export declare const ListConfiguredAudienceModelsResponse: S.Schema<ListConfiguredAudienceModelsResponse>;
export interface ListConfiguredModelAlgorithmAssociationsRequest {
    nextToken?: string;
    maxResults?: number;
    membershipIdentifier: string;
}
export declare const ListConfiguredModelAlgorithmAssociationsRequest: S.Schema<ListConfiguredModelAlgorithmAssociationsRequest>;
export interface ConfiguredModelAlgorithmAssociationSummary {
    createTime: Date;
    updateTime: Date;
    configuredModelAlgorithmAssociationArn: string;
    configuredModelAlgorithmArn: string;
    name: string;
    description?: string;
    membershipIdentifier: string;
    collaborationIdentifier: string;
}
export declare const ConfiguredModelAlgorithmAssociationSummary: S.Schema<ConfiguredModelAlgorithmAssociationSummary>;
export type ConfiguredModelAlgorithmAssociationList = ConfiguredModelAlgorithmAssociationSummary[];
export declare const ConfiguredModelAlgorithmAssociationList: any;
export interface ListConfiguredModelAlgorithmAssociationsResponse {
    nextToken?: string;
    configuredModelAlgorithmAssociations: ConfiguredModelAlgorithmAssociationSummary[];
}
export declare const ListConfiguredModelAlgorithmAssociationsResponse: S.Schema<ListConfiguredModelAlgorithmAssociationsResponse>;
export interface ListConfiguredModelAlgorithmsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListConfiguredModelAlgorithmsRequest: S.Schema<ListConfiguredModelAlgorithmsRequest>;
export interface ConfiguredModelAlgorithmSummary {
    createTime: Date;
    updateTime: Date;
    configuredModelAlgorithmArn: string;
    name: string;
    description?: string;
}
export declare const ConfiguredModelAlgorithmSummary: S.Schema<ConfiguredModelAlgorithmSummary>;
export type ConfiguredModelAlgorithmList = ConfiguredModelAlgorithmSummary[];
export declare const ConfiguredModelAlgorithmList: any;
export interface ListConfiguredModelAlgorithmsResponse {
    nextToken?: string;
    configuredModelAlgorithms: ConfiguredModelAlgorithmSummary[];
}
export declare const ListConfiguredModelAlgorithmsResponse: S.Schema<ListConfiguredModelAlgorithmsResponse>;
export interface ListMLInputChannelsRequest {
    nextToken?: string;
    maxResults?: number;
    membershipIdentifier: string;
}
export declare const ListMLInputChannelsRequest: S.Schema<ListMLInputChannelsRequest>;
export interface MLInputChannelSummary {
    createTime: Date;
    updateTime: Date;
    membershipIdentifier: string;
    collaborationIdentifier: string;
    name: string;
    configuredModelAlgorithmAssociations: string[];
    protectedQueryIdentifier?: string;
    mlInputChannelArn: string;
    status: MLInputChannelStatus;
    description?: string;
    payerConfiguration?: PayerConfiguration;
}
export declare const MLInputChannelSummary: S.Schema<MLInputChannelSummary>;
export type MLInputChannelsList = MLInputChannelSummary[];
export declare const MLInputChannelsList: any;
export interface ListMLInputChannelsResponse {
    nextToken?: string;
    mlInputChannelsList: MLInputChannelSummary[];
}
export declare const ListMLInputChannelsResponse: S.Schema<ListMLInputChannelsResponse>;
export type TaggableArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListTrainedModelInferenceJobsRequest {
    nextToken?: string;
    maxResults?: number;
    membershipIdentifier: string;
    trainedModelArn?: string;
    trainedModelVersionIdentifier?: string;
}
export declare const ListTrainedModelInferenceJobsRequest: S.Schema<ListTrainedModelInferenceJobsRequest>;
export interface TrainedModelInferenceJobSummary {
    trainedModelInferenceJobArn: string;
    configuredModelAlgorithmAssociationArn?: string;
    membershipIdentifier: string;
    trainedModelArn: string;
    trainedModelVersionIdentifier?: string;
    collaborationIdentifier: string;
    status: TrainedModelInferenceJobStatus;
    outputConfiguration: InferenceOutputConfiguration;
    name: string;
    description?: string;
    metricsStatus?: MetricsStatus;
    metricsStatusDetails?: string;
    logsStatus?: LogsStatus;
    logsStatusDetails?: string;
    mlModelInferencePayerAccountId?: string;
    createTime: Date;
    updateTime: Date;
}
export declare const TrainedModelInferenceJobSummary: S.Schema<TrainedModelInferenceJobSummary>;
export type TrainedModelInferenceJobList = TrainedModelInferenceJobSummary[];
export declare const TrainedModelInferenceJobList: any;
export interface ListTrainedModelInferenceJobsResponse {
    nextToken?: string;
    trainedModelInferenceJobs: TrainedModelInferenceJobSummary[];
}
export declare const ListTrainedModelInferenceJobsResponse: S.Schema<ListTrainedModelInferenceJobsResponse>;
export interface ListTrainedModelsRequest {
    nextToken?: string;
    maxResults?: number;
    membershipIdentifier: string;
}
export declare const ListTrainedModelsRequest: S.Schema<ListTrainedModelsRequest>;
export interface TrainedModelSummary {
    createTime: Date;
    updateTime: Date;
    trainedModelArn: string;
    versionIdentifier?: string;
    incrementalTrainingDataChannels?: IncrementalTrainingDataChannelOutput[];
    name: string;
    description?: string;
    membershipIdentifier: string;
    collaborationIdentifier: string;
    status: TrainedModelStatus;
    configuredModelAlgorithmAssociationArn: string;
    mlModelTrainingPayerAccountId?: string;
}
export declare const TrainedModelSummary: S.Schema<TrainedModelSummary>;
export type TrainedModelList = TrainedModelSummary[];
export declare const TrainedModelList: any;
export interface ListTrainedModelsResponse {
    nextToken?: string;
    trainedModels: TrainedModelSummary[];
}
export declare const ListTrainedModelsResponse: S.Schema<ListTrainedModelsResponse>;
export interface ListTrainedModelVersionsRequest {
    nextToken?: string;
    maxResults?: number;
    membershipIdentifier: string;
    trainedModelArn: string;
    status?: TrainedModelStatus;
}
export declare const ListTrainedModelVersionsRequest: S.Schema<ListTrainedModelVersionsRequest>;
export interface ListTrainedModelVersionsResponse {
    nextToken?: string;
    trainedModels: TrainedModelSummary[];
}
export declare const ListTrainedModelVersionsResponse: S.Schema<ListTrainedModelVersionsResponse>;
export interface ListTrainingDatasetsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListTrainingDatasetsRequest: S.Schema<ListTrainingDatasetsRequest>;
export interface TrainingDatasetSummary {
    createTime: Date;
    updateTime: Date;
    trainingDatasetArn: string;
    name: string;
    status: TrainingDatasetStatus;
    description?: string;
}
export declare const TrainingDatasetSummary: S.Schema<TrainingDatasetSummary>;
export type TrainingDatasetList = TrainingDatasetSummary[];
export declare const TrainingDatasetList: any;
export interface ListTrainingDatasetsResponse {
    nextToken?: string;
    trainingDatasets: TrainingDatasetSummary[];
}
export declare const ListTrainingDatasetsResponse: S.Schema<ListTrainingDatasetsResponse>;
export type PolicyExistenceCondition = "POLICY_MUST_EXIST" | "POLICY_MUST_NOT_EXIST" | (string & {});
export declare const PolicyExistenceCondition: any;
export interface PutConfiguredAudienceModelPolicyRequest {
    configuredAudienceModelArn: string;
    configuredAudienceModelPolicy: string;
    previousPolicyHash?: string;
    policyExistenceCondition?: PolicyExistenceCondition;
}
export declare const PutConfiguredAudienceModelPolicyRequest: S.Schema<PutConfiguredAudienceModelPolicyRequest>;
export interface PutConfiguredAudienceModelPolicyResponse {
    configuredAudienceModelPolicy: string;
    policyHash: string;
}
export declare const PutConfiguredAudienceModelPolicyResponse: S.Schema<PutConfiguredAudienceModelPolicyResponse>;
export interface PutMLConfigurationRequest {
    membershipIdentifier: string;
    defaultOutputLocation: MLOutputConfiguration;
}
export declare const PutMLConfigurationRequest: S.Schema<PutMLConfigurationRequest>;
export interface PutMLConfigurationResponse {
}
export declare const PutMLConfigurationResponse: S.Schema<PutMLConfigurationResponse>;
export interface StartAudienceExportJobRequest {
    name: string;
    audienceGenerationJobArn: string;
    audienceSize: AudienceSize;
    description?: string;
}
export declare const StartAudienceExportJobRequest: S.Schema<StartAudienceExportJobRequest>;
export interface StartAudienceExportJobResponse {
}
export declare const StartAudienceExportJobResponse: S.Schema<StartAudienceExportJobResponse>;
export interface StartAudienceGenerationJobRequest {
    name: string;
    configuredAudienceModelArn: string;
    seedAudience: AudienceGenerationJobDataSource;
    includeSeedInOutput?: boolean;
    collaborationId?: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const StartAudienceGenerationJobRequest: S.Schema<StartAudienceGenerationJobRequest>;
export interface StartAudienceGenerationJobResponse {
    audienceGenerationJobArn: string;
}
export declare const StartAudienceGenerationJobResponse: S.Schema<StartAudienceGenerationJobResponse>;
export interface StartTrainedModelExportJobRequest {
    name: string;
    trainedModelArn: string;
    trainedModelVersionIdentifier?: string;
    membershipIdentifier: string;
    outputConfiguration: TrainedModelExportOutputConfiguration;
    description?: string;
}
export declare const StartTrainedModelExportJobRequest: S.Schema<StartTrainedModelExportJobRequest>;
export interface StartTrainedModelExportJobResponse {
}
export declare const StartTrainedModelExportJobResponse: S.Schema<StartTrainedModelExportJobResponse>;
export interface StartTrainedModelInferenceJobRequest {
    membershipIdentifier: string;
    name: string;
    trainedModelArn: string;
    trainedModelVersionIdentifier?: string;
    configuredModelAlgorithmAssociationArn?: string;
    resourceConfig: InferenceResourceConfig;
    outputConfiguration: InferenceOutputConfiguration;
    dataSource: ModelInferenceDataSource;
    description?: string;
    containerExecutionParameters?: InferenceContainerExecutionParameters;
    environment?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    mlModelInferencePayerAccountId?: string;
}
export declare const StartTrainedModelInferenceJobRequest: S.Schema<StartTrainedModelInferenceJobRequest>;
export interface StartTrainedModelInferenceJobResponse {
    trainedModelInferenceJobArn: string;
}
export declare const StartTrainedModelInferenceJobResponse: S.Schema<StartTrainedModelInferenceJobResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeys = string[];
export declare const TagKeys: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateConfiguredAudienceModelRequest {
    configuredAudienceModelArn: string;
    outputConfig?: ConfiguredAudienceModelOutputConfig;
    audienceModelArn?: string;
    sharedAudienceMetrics?: SharedAudienceMetrics[];
    minMatchingSeedSize?: number;
    audienceSizeConfig?: AudienceSizeConfig;
    description?: string;
}
export declare const UpdateConfiguredAudienceModelRequest: S.Schema<UpdateConfiguredAudienceModelRequest>;
export interface UpdateConfiguredAudienceModelResponse {
    configuredAudienceModelArn: string;
}
export declare const UpdateConfiguredAudienceModelResponse: S.Schema<UpdateConfiguredAudienceModelResponse>;
export type CancelTrainedModelError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits a request to cancel the trained model job.
 */
export declare const cancelTrainedModel: API.OperationMethod<CancelTrainedModelRequest, CancelTrainedModelResponse, CancelTrainedModelError, Credentials | HttpClient.HttpClient>;
export type CancelTrainedModelInferenceJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Submits a request to cancel a trained model inference job.
 */
export declare const cancelTrainedModelInferenceJob: API.OperationMethod<CancelTrainedModelInferenceJobRequest, CancelTrainedModelInferenceJobResponse, CancelTrainedModelInferenceJobError, Credentials | HttpClient.HttpClient>;
export type CreateAudienceModelError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the information necessary to create an audience model. An audience model is a machine learning model that Clean Rooms ML trains to measure similarity between users. Clean Rooms ML manages training and storing the audience model. The audience model can be used in multiple calls to the StartAudienceGenerationJob API.
 */
export declare const createAudienceModel: API.OperationMethod<CreateAudienceModelRequest, CreateAudienceModelResponse, CreateAudienceModelError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredAudienceModelError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the information necessary to create a configured audience model.
 */
export declare const createConfiguredAudienceModel: API.OperationMethod<CreateConfiguredAudienceModelRequest, CreateConfiguredAudienceModelResponse, CreateConfiguredAudienceModelError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredModelAlgorithmError = AccessDeniedException | ConflictException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a configured model algorithm using a container image stored in an ECR repository.
 */
export declare const createConfiguredModelAlgorithm: API.OperationMethod<CreateConfiguredModelAlgorithmRequest, CreateConfiguredModelAlgorithmResponse, CreateConfiguredModelAlgorithmError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredModelAlgorithmAssociationError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a configured model algorithm to a collaboration for use by any member of the collaboration.
 */
export declare const createConfiguredModelAlgorithmAssociation: API.OperationMethod<CreateConfiguredModelAlgorithmAssociationRequest, CreateConfiguredModelAlgorithmAssociationResponse, CreateConfiguredModelAlgorithmAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateMLInputChannelError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the information to create an ML input channel. An ML input channel is the result of a query that can be used for ML modeling.
 */
export declare const createMLInputChannel: API.OperationMethod<CreateMLInputChannelRequest, CreateMLInputChannelResponse, CreateMLInputChannelError, Credentials | HttpClient.HttpClient>;
export type CreateTrainedModelError = AccessDeniedException | ConflictException | InternalServiceException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a trained model from an associated configured model algorithm using data from any member of the collaboration.
 */
export declare const createTrainedModel: API.OperationMethod<CreateTrainedModelRequest, CreateTrainedModelResponse, CreateTrainedModelError, Credentials | HttpClient.HttpClient>;
export type CreateTrainingDatasetError = AccessDeniedException | ConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the information necessary to create a training dataset. In Clean Rooms ML, the `TrainingDataset` is metadata that points to a Glue table, which is read only during `AudienceModel` creation.
 */
export declare const createTrainingDataset: API.OperationMethod<CreateTrainingDatasetRequest, CreateTrainingDatasetResponse, CreateTrainingDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteAudienceGenerationJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified audience generation job, and removes all data associated with the job.
 */
export declare const deleteAudienceGenerationJob: API.OperationMethod<DeleteAudienceGenerationJobRequest, DeleteAudienceGenerationJobResponse, DeleteAudienceGenerationJobError, Credentials | HttpClient.HttpClient>;
export type DeleteAudienceModelError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Specifies an audience model that you want to delete. You can't delete an audience model if there are any configured audience models that depend on the audience model.
 */
export declare const deleteAudienceModel: API.OperationMethod<DeleteAudienceModelRequest, DeleteAudienceModelResponse, DeleteAudienceModelError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredAudienceModelError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified configured audience model. You can't delete a configured audience model if there are any lookalike models that use the configured audience model. If you delete a configured audience model, it will be removed from any collaborations that it is associated to.
 */
export declare const deleteConfiguredAudienceModel: API.OperationMethod<DeleteConfiguredAudienceModelRequest, DeleteConfiguredAudienceModelResponse, DeleteConfiguredAudienceModelError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredAudienceModelPolicyError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified configured audience model policy.
 */
export declare const deleteConfiguredAudienceModelPolicy: API.OperationMethod<DeleteConfiguredAudienceModelPolicyRequest, DeleteConfiguredAudienceModelPolicyResponse, DeleteConfiguredAudienceModelPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredModelAlgorithmError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured model algorithm.
 */
export declare const deleteConfiguredModelAlgorithm: API.OperationMethod<DeleteConfiguredModelAlgorithmRequest, DeleteConfiguredModelAlgorithmResponse, DeleteConfiguredModelAlgorithmError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredModelAlgorithmAssociationError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured model algorithm association.
 */
export declare const deleteConfiguredModelAlgorithmAssociation: API.OperationMethod<DeleteConfiguredModelAlgorithmAssociationRequest, DeleteConfiguredModelAlgorithmAssociationResponse, DeleteConfiguredModelAlgorithmAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteMLConfigurationError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a ML modeling configuration.
 */
export declare const deleteMLConfiguration: API.OperationMethod<DeleteMLConfigurationRequest, DeleteMLConfigurationResponse, DeleteMLConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteMLInputChannelDataError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the information necessary to delete an ML input channel.
 */
export declare const deleteMLInputChannelData: API.OperationMethod<DeleteMLInputChannelDataRequest, DeleteMLInputChannelDataResponse, DeleteMLInputChannelDataError, Credentials | HttpClient.HttpClient>;
export type DeleteTrainedModelOutputError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the model artifacts stored by the service.
 */
export declare const deleteTrainedModelOutput: API.OperationMethod<DeleteTrainedModelOutputRequest, DeleteTrainedModelOutputResponse, DeleteTrainedModelOutputError, Credentials | HttpClient.HttpClient>;
export type DeleteTrainingDatasetError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Specifies a training dataset that you want to delete. You can't delete a training dataset if there are any audience models that depend on the training dataset. In Clean Rooms ML, the `TrainingDataset` is metadata that points to a Glue table, which is read only during `AudienceModel` creation. This action deletes the metadata.
 */
export declare const deleteTrainingDataset: API.OperationMethod<DeleteTrainingDatasetRequest, DeleteTrainingDatasetResponse, DeleteTrainingDatasetError, Credentials | HttpClient.HttpClient>;
export type GetAudienceGenerationJobError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an audience generation job.
 */
export declare const getAudienceGenerationJob: API.OperationMethod<GetAudienceGenerationJobRequest, GetAudienceGenerationJobResponse, GetAudienceGenerationJobError, Credentials | HttpClient.HttpClient>;
export type GetAudienceModelError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an audience model
 */
export declare const getAudienceModel: API.OperationMethod<GetAudienceModelRequest, GetAudienceModelResponse, GetAudienceModelError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationConfiguredModelAlgorithmAssociationError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the configured model algorithm association in a collaboration.
 */
export declare const getCollaborationConfiguredModelAlgorithmAssociation: API.OperationMethod<GetCollaborationConfiguredModelAlgorithmAssociationRequest, GetCollaborationConfiguredModelAlgorithmAssociationResponse, GetCollaborationConfiguredModelAlgorithmAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationMLInputChannelError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific ML input channel in a collaboration.
 */
export declare const getCollaborationMLInputChannel: API.OperationMethod<GetCollaborationMLInputChannelRequest, GetCollaborationMLInputChannelResponse, GetCollaborationMLInputChannelError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationTrainedModelError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a trained model in a collaboration.
 */
export declare const getCollaborationTrainedModel: API.OperationMethod<GetCollaborationTrainedModelRequest, GetCollaborationTrainedModelResponse, GetCollaborationTrainedModelError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredAudienceModelError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specified configured audience model.
 */
export declare const getConfiguredAudienceModel: API.OperationMethod<GetConfiguredAudienceModelRequest, GetConfiguredAudienceModelResponse, GetConfiguredAudienceModelError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredAudienceModelPolicyError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a configured audience model policy.
 */
export declare const getConfiguredAudienceModelPolicy: API.OperationMethod<GetConfiguredAudienceModelPolicyRequest, GetConfiguredAudienceModelPolicyResponse, GetConfiguredAudienceModelPolicyError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredModelAlgorithmError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a configured model algorithm.
 */
export declare const getConfiguredModelAlgorithm: API.OperationMethod<GetConfiguredModelAlgorithmRequest, GetConfiguredModelAlgorithmResponse, GetConfiguredModelAlgorithmError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredModelAlgorithmAssociationError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a configured model algorithm association.
 */
export declare const getConfiguredModelAlgorithmAssociation: API.OperationMethod<GetConfiguredModelAlgorithmAssociationRequest, GetConfiguredModelAlgorithmAssociationResponse, GetConfiguredModelAlgorithmAssociationError, Credentials | HttpClient.HttpClient>;
export type GetMLConfigurationError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific ML configuration.
 */
export declare const getMLConfiguration: API.OperationMethod<GetMLConfigurationRequest, GetMLConfigurationResponse, GetMLConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetMLInputChannelError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an ML input channel.
 */
export declare const getMLInputChannel: API.OperationMethod<GetMLInputChannelRequest, GetMLInputChannelResponse, GetMLInputChannelError, Credentials | HttpClient.HttpClient>;
export type GetTrainedModelError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a trained model.
 */
export declare const getTrainedModel: API.OperationMethod<GetTrainedModelRequest, GetTrainedModelResponse, GetTrainedModelError, Credentials | HttpClient.HttpClient>;
export type GetTrainedModelInferenceJobError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a trained model inference job.
 */
export declare const getTrainedModelInferenceJob: API.OperationMethod<GetTrainedModelInferenceJobRequest, GetTrainedModelInferenceJobResponse, GetTrainedModelInferenceJobError, Credentials | HttpClient.HttpClient>;
export type GetTrainingDatasetError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a training dataset.
 */
export declare const getTrainingDataset: API.OperationMethod<GetTrainingDatasetRequest, GetTrainingDatasetResponse, GetTrainingDatasetError, Credentials | HttpClient.HttpClient>;
export type ListAudienceExportJobsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the audience export jobs.
 */
export declare const listAudienceExportJobs: API.PaginatedOperationMethod<ListAudienceExportJobsRequest, ListAudienceExportJobsResponse, ListAudienceExportJobsError, Credentials | HttpClient.HttpClient, AudienceExportJobSummary>;
export type ListAudienceGenerationJobsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of audience generation jobs.
 */
export declare const listAudienceGenerationJobs: API.PaginatedOperationMethod<ListAudienceGenerationJobsRequest, ListAudienceGenerationJobsResponse, ListAudienceGenerationJobsError, Credentials | HttpClient.HttpClient, AudienceGenerationJobSummary>;
export type ListAudienceModelsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of audience models.
 */
export declare const listAudienceModels: API.PaginatedOperationMethod<ListAudienceModelsRequest, ListAudienceModelsResponse, ListAudienceModelsError, Credentials | HttpClient.HttpClient, AudienceModelSummary>;
export type ListCollaborationConfiguredModelAlgorithmAssociationsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the configured model algorithm associations in a collaboration.
 */
export declare const listCollaborationConfiguredModelAlgorithmAssociations: API.PaginatedOperationMethod<ListCollaborationConfiguredModelAlgorithmAssociationsRequest, ListCollaborationConfiguredModelAlgorithmAssociationsResponse, ListCollaborationConfiguredModelAlgorithmAssociationsError, Credentials | HttpClient.HttpClient, CollaborationConfiguredModelAlgorithmAssociationSummary>;
export type ListCollaborationMLInputChannelsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the ML input channels in a collaboration.
 */
export declare const listCollaborationMLInputChannels: API.PaginatedOperationMethod<ListCollaborationMLInputChannelsRequest, ListCollaborationMLInputChannelsResponse, ListCollaborationMLInputChannelsError, Credentials | HttpClient.HttpClient, CollaborationMLInputChannelSummary>;
export type ListCollaborationTrainedModelExportJobsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the export jobs for a trained model in a collaboration.
 */
export declare const listCollaborationTrainedModelExportJobs: API.PaginatedOperationMethod<ListCollaborationTrainedModelExportJobsRequest, ListCollaborationTrainedModelExportJobsResponse, ListCollaborationTrainedModelExportJobsError, Credentials | HttpClient.HttpClient, CollaborationTrainedModelExportJobSummary>;
export type ListCollaborationTrainedModelInferenceJobsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of trained model inference jobs in a specified collaboration.
 */
export declare const listCollaborationTrainedModelInferenceJobs: API.PaginatedOperationMethod<ListCollaborationTrainedModelInferenceJobsRequest, ListCollaborationTrainedModelInferenceJobsResponse, ListCollaborationTrainedModelInferenceJobsError, Credentials | HttpClient.HttpClient, CollaborationTrainedModelInferenceJobSummary>;
export type ListCollaborationTrainedModelsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the trained models in a collaboration.
 */
export declare const listCollaborationTrainedModels: API.PaginatedOperationMethod<ListCollaborationTrainedModelsRequest, ListCollaborationTrainedModelsResponse, ListCollaborationTrainedModelsError, Credentials | HttpClient.HttpClient, CollaborationTrainedModelSummary>;
export type ListConfiguredAudienceModelsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the configured audience models.
 */
export declare const listConfiguredAudienceModels: API.PaginatedOperationMethod<ListConfiguredAudienceModelsRequest, ListConfiguredAudienceModelsResponse, ListConfiguredAudienceModelsError, Credentials | HttpClient.HttpClient, ConfiguredAudienceModelSummary>;
export type ListConfiguredModelAlgorithmAssociationsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of configured model algorithm associations.
 */
export declare const listConfiguredModelAlgorithmAssociations: API.PaginatedOperationMethod<ListConfiguredModelAlgorithmAssociationsRequest, ListConfiguredModelAlgorithmAssociationsResponse, ListConfiguredModelAlgorithmAssociationsError, Credentials | HttpClient.HttpClient, ConfiguredModelAlgorithmAssociationSummary>;
export type ListConfiguredModelAlgorithmsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of configured model algorithms.
 */
export declare const listConfiguredModelAlgorithms: API.PaginatedOperationMethod<ListConfiguredModelAlgorithmsRequest, ListConfiguredModelAlgorithmsResponse, ListConfiguredModelAlgorithmsError, Credentials | HttpClient.HttpClient, ConfiguredModelAlgorithmSummary>;
export type ListMLInputChannelsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of ML input channels.
 */
export declare const listMLInputChannels: API.PaginatedOperationMethod<ListMLInputChannelsRequest, ListMLInputChannelsResponse, ListMLInputChannelsError, Credentials | HttpClient.HttpClient, MLInputChannelSummary>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a provided resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTrainedModelInferenceJobsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of trained model inference jobs that match the request parameters.
 */
export declare const listTrainedModelInferenceJobs: API.PaginatedOperationMethod<ListTrainedModelInferenceJobsRequest, ListTrainedModelInferenceJobsResponse, ListTrainedModelInferenceJobsError, Credentials | HttpClient.HttpClient, TrainedModelInferenceJobSummary>;
export type ListTrainedModelsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of trained models.
 */
export declare const listTrainedModels: API.PaginatedOperationMethod<ListTrainedModelsRequest, ListTrainedModelsResponse, ListTrainedModelsError, Credentials | HttpClient.HttpClient, TrainedModelSummary>;
export type ListTrainedModelVersionsError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of trained model versions for a specified trained model. This operation allows you to view all versions of a trained model, including information about their status and creation details. You can use this to track the evolution of your trained models and select specific versions for inference or further training.
 */
export declare const listTrainedModelVersions: API.PaginatedOperationMethod<ListTrainedModelVersionsRequest, ListTrainedModelVersionsResponse, ListTrainedModelVersionsError, Credentials | HttpClient.HttpClient, TrainedModelSummary>;
export type ListTrainingDatasetsError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of training datasets.
 */
export declare const listTrainingDatasets: API.PaginatedOperationMethod<ListTrainingDatasetsRequest, ListTrainingDatasetsResponse, ListTrainingDatasetsError, Credentials | HttpClient.HttpClient, TrainingDatasetSummary>;
export type PutConfiguredAudienceModelPolicyError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create or update the resource policy for a configured audience model.
 */
export declare const putConfiguredAudienceModelPolicy: API.OperationMethod<PutConfiguredAudienceModelPolicyRequest, PutConfiguredAudienceModelPolicyResponse, PutConfiguredAudienceModelPolicyError, Credentials | HttpClient.HttpClient>;
export type PutMLConfigurationError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns information about an ML configuration.
 */
export declare const putMLConfiguration: API.OperationMethod<PutMLConfigurationRequest, PutMLConfigurationResponse, PutMLConfigurationError, Credentials | HttpClient.HttpClient>;
export type StartAudienceExportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Export an audience of a specified size after you have generated an audience.
 */
export declare const startAudienceExportJob: API.OperationMethod<StartAudienceExportJobRequest, StartAudienceExportJobResponse, StartAudienceExportJobError, Credentials | HttpClient.HttpClient>;
export type StartAudienceGenerationJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Information necessary to start the audience generation job.
 */
export declare const startAudienceGenerationJob: API.OperationMethod<StartAudienceGenerationJobRequest, StartAudienceGenerationJobResponse, StartAudienceGenerationJobError, Credentials | HttpClient.HttpClient>;
export type StartTrainedModelExportJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the information necessary to start a trained model export job.
 */
export declare const startTrainedModelExportJob: API.OperationMethod<StartTrainedModelExportJobRequest, StartTrainedModelExportJobResponse, StartTrainedModelExportJobError, Credentials | HttpClient.HttpClient>;
export type StartTrainedModelInferenceJobError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the information necessary to begin a trained model inference job.
 */
export declare const startTrainedModelInferenceJob: API.OperationMethod<StartTrainedModelInferenceJobRequest, StartTrainedModelInferenceJobResponse, StartTrainedModelInferenceJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds metadata tags to a specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes metadata tags from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredAudienceModelError = AccessDeniedException | ConflictException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the information necessary to update a configured audience model. Updates that impact audience generation jobs take effect when a new job starts, but do not impact currently running jobs.
 */
export declare const updateConfiguredAudienceModel: API.OperationMethod<UpdateConfiguredAudienceModelRequest, UpdateConfiguredAudienceModelResponse, UpdateConfiguredAudienceModelError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cleanroomsml.d.ts.map