import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidEncodingException_base: S.Class<InvalidEncodingException, S.TaggedStruct<"InvalidEncodingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEncodingException extends /*@__PURE__*/ InvalidEncodingException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TextSizeLimitExceededException_base: S.Class<TextSizeLimitExceededException, S.TaggedStruct<"TextSizeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TextSizeLimitExceededException extends /*@__PURE__*/ TextSizeLimitExceededException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type JobId = string;
export interface DescribeEntitiesDetectionV2JobRequest {
    JobId: string;
}
export declare const DescribeEntitiesDetectionV2JobRequest: S.Schema<DescribeEntitiesDetectionV2JobRequest>;
export type JobName = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "COMPLETED" | "PARTIAL_SUCCESS" | "FAILED" | "STOP_REQUESTED" | "STOPPED" | (string & {});
export declare const JobStatus: any;
export type AnyLengthString = string;
export type S3Bucket = string;
export type S3Key = string;
export interface InputDataConfig {
    S3Bucket: string;
    S3Key?: string;
}
export declare const InputDataConfig: S.Schema<InputDataConfig>;
export interface OutputDataConfig {
    S3Bucket: string;
    S3Key?: string;
}
export declare const OutputDataConfig: S.Schema<OutputDataConfig>;
export type LanguageCode = "en" | (string & {});
export declare const LanguageCode: any;
export type IamRoleArn = string;
export type ManifestFilePath = string;
export type KMSKey = string;
export type ModelVersion = string;
export interface ComprehendMedicalAsyncJobProperties {
    JobId?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    ExpirationTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    LanguageCode?: LanguageCode;
    DataAccessRoleArn?: string;
    ManifestFilePath?: string;
    KMSKey?: string;
    ModelVersion?: string;
}
export declare const ComprehendMedicalAsyncJobProperties: S.Schema<ComprehendMedicalAsyncJobProperties>;
export interface DescribeEntitiesDetectionV2JobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties;
}
export declare const DescribeEntitiesDetectionV2JobResponse: S.Schema<DescribeEntitiesDetectionV2JobResponse>;
export interface DescribeICD10CMInferenceJobRequest {
    JobId: string;
}
export declare const DescribeICD10CMInferenceJobRequest: S.Schema<DescribeICD10CMInferenceJobRequest>;
export interface DescribeICD10CMInferenceJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties;
}
export declare const DescribeICD10CMInferenceJobResponse: S.Schema<DescribeICD10CMInferenceJobResponse>;
export interface DescribePHIDetectionJobRequest {
    JobId: string;
}
export declare const DescribePHIDetectionJobRequest: S.Schema<DescribePHIDetectionJobRequest>;
export interface DescribePHIDetectionJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties;
}
export declare const DescribePHIDetectionJobResponse: S.Schema<DescribePHIDetectionJobResponse>;
export interface DescribeRxNormInferenceJobRequest {
    JobId: string;
}
export declare const DescribeRxNormInferenceJobRequest: S.Schema<DescribeRxNormInferenceJobRequest>;
export interface DescribeRxNormInferenceJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties;
}
export declare const DescribeRxNormInferenceJobResponse: S.Schema<DescribeRxNormInferenceJobResponse>;
export interface DescribeSNOMEDCTInferenceJobRequest {
    JobId: string;
}
export declare const DescribeSNOMEDCTInferenceJobRequest: S.Schema<DescribeSNOMEDCTInferenceJobRequest>;
export interface DescribeSNOMEDCTInferenceJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties;
}
export declare const DescribeSNOMEDCTInferenceJobResponse: S.Schema<DescribeSNOMEDCTInferenceJobResponse>;
export type BoundedLengthString = string;
export interface DetectEntitiesRequest {
    Text: string;
}
export declare const DetectEntitiesRequest: S.Schema<DetectEntitiesRequest>;
export type EntityType = "MEDICATION" | "MEDICAL_CONDITION" | "PROTECTED_HEALTH_INFORMATION" | "TEST_TREATMENT_PROCEDURE" | "ANATOMY" | "TIME_EXPRESSION" | "BEHAVIORAL_ENVIRONMENTAL_SOCIAL" | (string & {});
export declare const EntityType: any;
export type EntitySubType = "NAME" | "DX_NAME" | "DOSAGE" | "ROUTE_OR_MODE" | "FORM" | "FREQUENCY" | "DURATION" | "GENERIC_NAME" | "BRAND_NAME" | "STRENGTH" | "RATE" | "ACUITY" | "TEST_NAME" | "TEST_VALUE" | "TEST_UNITS" | "TEST_UNIT" | "PROCEDURE_NAME" | "TREATMENT_NAME" | "DATE" | "AGE" | "CONTACT_POINT" | "PHONE_OR_FAX" | "EMAIL" | "IDENTIFIER" | "ID" | "URL" | "ADDRESS" | "PROFESSION" | "SYSTEM_ORGAN_SITE" | "DIRECTION" | "QUALITY" | "QUANTITY" | "TIME_EXPRESSION" | "TIME_TO_MEDICATION_NAME" | "TIME_TO_DX_NAME" | "TIME_TO_TEST_NAME" | "TIME_TO_PROCEDURE_NAME" | "TIME_TO_TREATMENT_NAME" | "AMOUNT" | "GENDER" | "RACE_ETHNICITY" | "ALLERGIES" | "TOBACCO_USE" | "ALCOHOL_CONSUMPTION" | "REC_DRUG_USE" | (string & {});
export declare const EntitySubType: any;
export type AttributeName = "SIGN" | "SYMPTOM" | "DIAGNOSIS" | "NEGATION" | "PERTAINS_TO_FAMILY" | "HYPOTHETICAL" | "LOW_CONFIDENCE" | "PAST_HISTORY" | "FUTURE" | (string & {});
export declare const AttributeName: any;
export interface Trait {
    Name?: AttributeName;
    Score?: number;
}
export declare const Trait: S.Schema<Trait>;
export type TraitList = Trait[];
export declare const TraitList: any;
export type RelationshipType = "EVERY" | "WITH_DOSAGE" | "ADMINISTERED_VIA" | "FOR" | "NEGATIVE" | "OVERLAP" | "DOSAGE" | "ROUTE_OR_MODE" | "FORM" | "FREQUENCY" | "DURATION" | "STRENGTH" | "RATE" | "ACUITY" | "TEST_VALUE" | "TEST_UNITS" | "TEST_UNIT" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "AMOUNT" | "USAGE" | "QUALITY" | (string & {});
export declare const RelationshipType: any;
export interface Attribute {
    Type?: EntitySubType;
    Score?: number;
    RelationshipScore?: number;
    RelationshipType?: RelationshipType;
    Id?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Text?: string;
    Category?: EntityType;
    Traits?: Trait[];
}
export declare const Attribute: S.Schema<Attribute>;
export type AttributeList = Attribute[];
export declare const AttributeList: any;
export interface Entity {
    Id?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Score?: number;
    Text?: string;
    Category?: EntityType;
    Type?: EntitySubType;
    Traits?: Trait[];
    Attributes?: Attribute[];
}
export declare const Entity: S.Schema<Entity>;
export type EntityList = Entity[];
export declare const EntityList: any;
export interface UnmappedAttribute {
    Type?: EntityType;
    Attribute?: Attribute;
}
export declare const UnmappedAttribute: S.Schema<UnmappedAttribute>;
export type UnmappedAttributeList = UnmappedAttribute[];
export declare const UnmappedAttributeList: any;
export interface DetectEntitiesResponse {
    Entities: Entity[];
    UnmappedAttributes?: UnmappedAttribute[];
    PaginationToken?: string;
    ModelVersion: string;
}
export declare const DetectEntitiesResponse: S.Schema<DetectEntitiesResponse>;
export interface DetectEntitiesV2Request {
    Text: string;
}
export declare const DetectEntitiesV2Request: S.Schema<DetectEntitiesV2Request>;
export interface DetectEntitiesV2Response {
    Entities: Entity[];
    UnmappedAttributes?: UnmappedAttribute[];
    PaginationToken?: string;
    ModelVersion: string;
}
export declare const DetectEntitiesV2Response: S.Schema<DetectEntitiesV2Response>;
export interface DetectPHIRequest {
    Text: string;
}
export declare const DetectPHIRequest: S.Schema<DetectPHIRequest>;
export interface DetectPHIResponse {
    Entities: Entity[];
    PaginationToken?: string;
    ModelVersion: string;
}
export declare const DetectPHIResponse: S.Schema<DetectPHIResponse>;
export type OntologyLinkingBoundedLengthString = string;
export interface InferICD10CMRequest {
    Text: string;
}
export declare const InferICD10CMRequest: S.Schema<InferICD10CMRequest>;
export type ICD10CMEntityCategory = "MEDICAL_CONDITION" | (string & {});
export declare const ICD10CMEntityCategory: any;
export type ICD10CMEntityType = "DX_NAME" | "TIME_EXPRESSION" | (string & {});
export declare const ICD10CMEntityType: any;
export type ICD10CMAttributeType = "ACUITY" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "QUALITY" | "QUANTITY" | "TIME_TO_DX_NAME" | "TIME_EXPRESSION" | (string & {});
export declare const ICD10CMAttributeType: any;
export type ICD10CMTraitName = "NEGATION" | "DIAGNOSIS" | "SIGN" | "SYMPTOM" | "PERTAINS_TO_FAMILY" | "HYPOTHETICAL" | "LOW_CONFIDENCE" | (string & {});
export declare const ICD10CMTraitName: any;
export interface ICD10CMTrait {
    Name?: ICD10CMTraitName;
    Score?: number;
}
export declare const ICD10CMTrait: S.Schema<ICD10CMTrait>;
export type ICD10CMTraitList = ICD10CMTrait[];
export declare const ICD10CMTraitList: any;
export type ICD10CMRelationshipType = "OVERLAP" | "SYSTEM_ORGAN_SITE" | "QUALITY" | (string & {});
export declare const ICD10CMRelationshipType: any;
export interface ICD10CMAttribute {
    Type?: ICD10CMAttributeType;
    Score?: number;
    RelationshipScore?: number;
    Id?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Text?: string;
    Traits?: ICD10CMTrait[];
    Category?: ICD10CMEntityType;
    RelationshipType?: ICD10CMRelationshipType;
}
export declare const ICD10CMAttribute: S.Schema<ICD10CMAttribute>;
export type ICD10CMAttributeList = ICD10CMAttribute[];
export declare const ICD10CMAttributeList: any;
export interface ICD10CMConcept {
    Description?: string;
    Code?: string;
    Score?: number;
}
export declare const ICD10CMConcept: S.Schema<ICD10CMConcept>;
export type ICD10CMConceptList = ICD10CMConcept[];
export declare const ICD10CMConceptList: any;
export interface ICD10CMEntity {
    Id?: number;
    Text?: string;
    Category?: ICD10CMEntityCategory;
    Type?: ICD10CMEntityType;
    Score?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Attributes?: ICD10CMAttribute[];
    Traits?: ICD10CMTrait[];
    ICD10CMConcepts?: ICD10CMConcept[];
}
export declare const ICD10CMEntity: S.Schema<ICD10CMEntity>;
export type ICD10CMEntityList = ICD10CMEntity[];
export declare const ICD10CMEntityList: any;
export interface InferICD10CMResponse {
    Entities: ICD10CMEntity[];
    PaginationToken?: string;
    ModelVersion?: string;
}
export declare const InferICD10CMResponse: S.Schema<InferICD10CMResponse>;
export interface InferRxNormRequest {
    Text: string;
}
export declare const InferRxNormRequest: S.Schema<InferRxNormRequest>;
export type RxNormEntityCategory = "MEDICATION" | (string & {});
export declare const RxNormEntityCategory: any;
export type RxNormEntityType = "BRAND_NAME" | "GENERIC_NAME" | (string & {});
export declare const RxNormEntityType: any;
export type RxNormAttributeType = "DOSAGE" | "DURATION" | "FORM" | "FREQUENCY" | "RATE" | "ROUTE_OR_MODE" | "STRENGTH" | (string & {});
export declare const RxNormAttributeType: any;
export type RxNormTraitName = "NEGATION" | "PAST_HISTORY" | (string & {});
export declare const RxNormTraitName: any;
export interface RxNormTrait {
    Name?: RxNormTraitName;
    Score?: number;
}
export declare const RxNormTrait: S.Schema<RxNormTrait>;
export type RxNormTraitList = RxNormTrait[];
export declare const RxNormTraitList: any;
export interface RxNormAttribute {
    Type?: RxNormAttributeType;
    Score?: number;
    RelationshipScore?: number;
    Id?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Text?: string;
    Traits?: RxNormTrait[];
}
export declare const RxNormAttribute: S.Schema<RxNormAttribute>;
export type RxNormAttributeList = RxNormAttribute[];
export declare const RxNormAttributeList: any;
export interface RxNormConcept {
    Description?: string;
    Code?: string;
    Score?: number;
}
export declare const RxNormConcept: S.Schema<RxNormConcept>;
export type RxNormConceptList = RxNormConcept[];
export declare const RxNormConceptList: any;
export interface RxNormEntity {
    Id?: number;
    Text?: string;
    Category?: RxNormEntityCategory;
    Type?: RxNormEntityType;
    Score?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Attributes?: RxNormAttribute[];
    Traits?: RxNormTrait[];
    RxNormConcepts?: RxNormConcept[];
}
export declare const RxNormEntity: S.Schema<RxNormEntity>;
export type RxNormEntityList = RxNormEntity[];
export declare const RxNormEntityList: any;
export interface InferRxNormResponse {
    Entities: RxNormEntity[];
    PaginationToken?: string;
    ModelVersion?: string;
}
export declare const InferRxNormResponse: S.Schema<InferRxNormResponse>;
export interface InferSNOMEDCTRequest {
    Text: string;
}
export declare const InferSNOMEDCTRequest: S.Schema<InferSNOMEDCTRequest>;
export type SNOMEDCTEntityCategory = "MEDICAL_CONDITION" | "ANATOMY" | "TEST_TREATMENT_PROCEDURE" | (string & {});
export declare const SNOMEDCTEntityCategory: any;
export type SNOMEDCTEntityType = "DX_NAME" | "TEST_NAME" | "PROCEDURE_NAME" | "TREATMENT_NAME" | (string & {});
export declare const SNOMEDCTEntityType: any;
export type SNOMEDCTAttributeType = "ACUITY" | "QUALITY" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "TEST_VALUE" | "TEST_UNIT" | (string & {});
export declare const SNOMEDCTAttributeType: any;
export type SNOMEDCTRelationshipType = "ACUITY" | "QUALITY" | "TEST_VALUE" | "TEST_UNITS" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "TEST_UNIT" | (string & {});
export declare const SNOMEDCTRelationshipType: any;
export type SNOMEDCTTraitName = "NEGATION" | "DIAGNOSIS" | "SIGN" | "SYMPTOM" | "PERTAINS_TO_FAMILY" | "HYPOTHETICAL" | "LOW_CONFIDENCE" | "PAST_HISTORY" | "FUTURE" | (string & {});
export declare const SNOMEDCTTraitName: any;
export interface SNOMEDCTTrait {
    Name?: SNOMEDCTTraitName;
    Score?: number;
}
export declare const SNOMEDCTTrait: S.Schema<SNOMEDCTTrait>;
export type SNOMEDCTTraitList = SNOMEDCTTrait[];
export declare const SNOMEDCTTraitList: any;
export interface SNOMEDCTConcept {
    Description?: string;
    Code?: string;
    Score?: number;
}
export declare const SNOMEDCTConcept: S.Schema<SNOMEDCTConcept>;
export type SNOMEDCTConceptList = SNOMEDCTConcept[];
export declare const SNOMEDCTConceptList: any;
export interface SNOMEDCTAttribute {
    Category?: SNOMEDCTEntityCategory;
    Type?: SNOMEDCTAttributeType;
    Score?: number;
    RelationshipScore?: number;
    RelationshipType?: SNOMEDCTRelationshipType;
    Id?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Text?: string;
    Traits?: SNOMEDCTTrait[];
    SNOMEDCTConcepts?: SNOMEDCTConcept[];
}
export declare const SNOMEDCTAttribute: S.Schema<SNOMEDCTAttribute>;
export type SNOMEDCTAttributeList = SNOMEDCTAttribute[];
export declare const SNOMEDCTAttributeList: any;
export interface SNOMEDCTEntity {
    Id?: number;
    Text?: string;
    Category?: SNOMEDCTEntityCategory;
    Type?: SNOMEDCTEntityType;
    Score?: number;
    BeginOffset?: number;
    EndOffset?: number;
    Attributes?: SNOMEDCTAttribute[];
    Traits?: SNOMEDCTTrait[];
    SNOMEDCTConcepts?: SNOMEDCTConcept[];
}
export declare const SNOMEDCTEntity: S.Schema<SNOMEDCTEntity>;
export type SNOMEDCTEntityList = SNOMEDCTEntity[];
export declare const SNOMEDCTEntityList: any;
export interface SNOMEDCTDetails {
    Edition?: string;
    Language?: string;
    VersionDate?: string;
}
export declare const SNOMEDCTDetails: S.Schema<SNOMEDCTDetails>;
export interface Characters {
    OriginalTextCharacters?: number;
}
export declare const Characters: S.Schema<Characters>;
export interface InferSNOMEDCTResponse {
    Entities: SNOMEDCTEntity[];
    PaginationToken?: string;
    ModelVersion?: string;
    SNOMEDCTDetails?: SNOMEDCTDetails;
    Characters?: Characters;
}
export declare const InferSNOMEDCTResponse: S.Schema<InferSNOMEDCTResponse>;
export interface ComprehendMedicalAsyncJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const ComprehendMedicalAsyncJobFilter: S.Schema<ComprehendMedicalAsyncJobFilter>;
export type MaxResultsInteger = number;
export interface ListEntitiesDetectionV2JobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEntitiesDetectionV2JobsRequest: S.Schema<ListEntitiesDetectionV2JobsRequest>;
export type ComprehendMedicalAsyncJobPropertiesList = ComprehendMedicalAsyncJobProperties[];
export declare const ComprehendMedicalAsyncJobPropertiesList: any;
export interface ListEntitiesDetectionV2JobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[];
    NextToken?: string;
}
export declare const ListEntitiesDetectionV2JobsResponse: S.Schema<ListEntitiesDetectionV2JobsResponse>;
export interface ListICD10CMInferenceJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListICD10CMInferenceJobsRequest: S.Schema<ListICD10CMInferenceJobsRequest>;
export interface ListICD10CMInferenceJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[];
    NextToken?: string;
}
export declare const ListICD10CMInferenceJobsResponse: S.Schema<ListICD10CMInferenceJobsResponse>;
export interface ListPHIDetectionJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPHIDetectionJobsRequest: S.Schema<ListPHIDetectionJobsRequest>;
export interface ListPHIDetectionJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[];
    NextToken?: string;
}
export declare const ListPHIDetectionJobsResponse: S.Schema<ListPHIDetectionJobsResponse>;
export interface ListRxNormInferenceJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRxNormInferenceJobsRequest: S.Schema<ListRxNormInferenceJobsRequest>;
export interface ListRxNormInferenceJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[];
    NextToken?: string;
}
export declare const ListRxNormInferenceJobsResponse: S.Schema<ListRxNormInferenceJobsResponse>;
export interface ListSNOMEDCTInferenceJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSNOMEDCTInferenceJobsRequest: S.Schema<ListSNOMEDCTInferenceJobsRequest>;
export interface ListSNOMEDCTInferenceJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[];
    NextToken?: string;
}
export declare const ListSNOMEDCTInferenceJobsResponse: S.Schema<ListSNOMEDCTInferenceJobsResponse>;
export type ClientRequestTokenString = string;
export interface StartEntitiesDetectionV2JobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    ClientRequestToken?: string;
    KMSKey?: string;
    LanguageCode: LanguageCode;
}
export declare const StartEntitiesDetectionV2JobRequest: S.Schema<StartEntitiesDetectionV2JobRequest>;
export interface StartEntitiesDetectionV2JobResponse {
    JobId?: string;
}
export declare const StartEntitiesDetectionV2JobResponse: S.Schema<StartEntitiesDetectionV2JobResponse>;
export interface StartICD10CMInferenceJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    ClientRequestToken?: string;
    KMSKey?: string;
    LanguageCode: LanguageCode;
}
export declare const StartICD10CMInferenceJobRequest: S.Schema<StartICD10CMInferenceJobRequest>;
export interface StartICD10CMInferenceJobResponse {
    JobId?: string;
}
export declare const StartICD10CMInferenceJobResponse: S.Schema<StartICD10CMInferenceJobResponse>;
export interface StartPHIDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    ClientRequestToken?: string;
    KMSKey?: string;
    LanguageCode: LanguageCode;
}
export declare const StartPHIDetectionJobRequest: S.Schema<StartPHIDetectionJobRequest>;
export interface StartPHIDetectionJobResponse {
    JobId?: string;
}
export declare const StartPHIDetectionJobResponse: S.Schema<StartPHIDetectionJobResponse>;
export interface StartRxNormInferenceJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    ClientRequestToken?: string;
    KMSKey?: string;
    LanguageCode: LanguageCode;
}
export declare const StartRxNormInferenceJobRequest: S.Schema<StartRxNormInferenceJobRequest>;
export interface StartRxNormInferenceJobResponse {
    JobId?: string;
}
export declare const StartRxNormInferenceJobResponse: S.Schema<StartRxNormInferenceJobResponse>;
export interface StartSNOMEDCTInferenceJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    ClientRequestToken?: string;
    KMSKey?: string;
    LanguageCode: LanguageCode;
}
export declare const StartSNOMEDCTInferenceJobRequest: S.Schema<StartSNOMEDCTInferenceJobRequest>;
export interface StartSNOMEDCTInferenceJobResponse {
    JobId?: string;
}
export declare const StartSNOMEDCTInferenceJobResponse: S.Schema<StartSNOMEDCTInferenceJobResponse>;
export interface StopEntitiesDetectionV2JobRequest {
    JobId: string;
}
export declare const StopEntitiesDetectionV2JobRequest: S.Schema<StopEntitiesDetectionV2JobRequest>;
export interface StopEntitiesDetectionV2JobResponse {
    JobId?: string;
}
export declare const StopEntitiesDetectionV2JobResponse: S.Schema<StopEntitiesDetectionV2JobResponse>;
export interface StopICD10CMInferenceJobRequest {
    JobId: string;
}
export declare const StopICD10CMInferenceJobRequest: S.Schema<StopICD10CMInferenceJobRequest>;
export interface StopICD10CMInferenceJobResponse {
    JobId?: string;
}
export declare const StopICD10CMInferenceJobResponse: S.Schema<StopICD10CMInferenceJobResponse>;
export interface StopPHIDetectionJobRequest {
    JobId: string;
}
export declare const StopPHIDetectionJobRequest: S.Schema<StopPHIDetectionJobRequest>;
export interface StopPHIDetectionJobResponse {
    JobId?: string;
}
export declare const StopPHIDetectionJobResponse: S.Schema<StopPHIDetectionJobResponse>;
export interface StopRxNormInferenceJobRequest {
    JobId: string;
}
export declare const StopRxNormInferenceJobRequest: S.Schema<StopRxNormInferenceJobRequest>;
export interface StopRxNormInferenceJobResponse {
    JobId?: string;
}
export declare const StopRxNormInferenceJobResponse: S.Schema<StopRxNormInferenceJobResponse>;
export interface StopSNOMEDCTInferenceJobRequest {
    JobId: string;
}
export declare const StopSNOMEDCTInferenceJobRequest: S.Schema<StopSNOMEDCTInferenceJobRequest>;
export interface StopSNOMEDCTInferenceJobResponse {
    JobId?: string;
}
export declare const StopSNOMEDCTInferenceJobResponse: S.Schema<StopSNOMEDCTInferenceJobResponse>;
export type DescribeEntitiesDetectionV2JobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a medical entities detection job. Use this operation
 * to get the status of a detection job.
 */
export declare const describeEntitiesDetectionV2Job: API.OperationMethod<DescribeEntitiesDetectionV2JobRequest, DescribeEntitiesDetectionV2JobResponse, DescribeEntitiesDetectionV2JobError, Credentials | HttpClient.HttpClient>;
export type DescribeICD10CMInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an InferICD10CM job. Use this operation to get the
 * status of an inference job.
 */
export declare const describeICD10CMInferenceJob: API.OperationMethod<DescribeICD10CMInferenceJobRequest, DescribeICD10CMInferenceJobResponse, DescribeICD10CMInferenceJobError, Credentials | HttpClient.HttpClient>;
export type DescribePHIDetectionJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a protected health information (PHI) detection job.
 * Use this operation to get the status of a detection job.
 */
export declare const describePHIDetectionJob: API.OperationMethod<DescribePHIDetectionJobRequest, DescribePHIDetectionJobResponse, DescribePHIDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeRxNormInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an InferRxNorm job. Use this operation to get the
 * status of an inference job.
 */
export declare const describeRxNormInferenceJob: API.OperationMethod<DescribeRxNormInferenceJobRequest, DescribeRxNormInferenceJobResponse, DescribeRxNormInferenceJobError, Credentials | HttpClient.HttpClient>;
export type DescribeSNOMEDCTInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an InferSNOMEDCT job. Use this operation to get the status of an inference job.
 */
export declare const describeSNOMEDCTInferenceJob: API.OperationMethod<DescribeSNOMEDCTInferenceJobRequest, DescribeSNOMEDCTInferenceJobResponse, DescribeSNOMEDCTInferenceJobError, Credentials | HttpClient.HttpClient>;
export type DetectEntitiesError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * The `DetectEntities` operation is deprecated. You should use the DetectEntitiesV2 operation instead.
 *
 * Inspects the clinical text for a variety of medical entities and returns specific
 * information about them such as entity category, location, and confidence score on that
 * information.
 */
export declare const detectEntities: API.OperationMethod<DetectEntitiesRequest, DetectEntitiesResponse, DetectEntitiesError, Credentials | HttpClient.HttpClient>;
export type DetectEntitiesV2Error = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Inspects the clinical text for a variety of medical entities and returns specific
 * information about them such as entity category, location, and confidence score on that
 * information. Amazon Comprehend Medical only detects medical entities in English language
 * texts.
 *
 * The `DetectEntitiesV2` operation replaces the DetectEntities
 * operation. This new action uses a different model for determining the entities in your medical
 * text and changes the way that some entities are returned in the output. You should use the
 * `DetectEntitiesV2` operation in all new applications.
 *
 * The `DetectEntitiesV2` operation returns the `Acuity` and
 * `Direction` entities as attributes instead of types.
 */
export declare const detectEntitiesV2: API.OperationMethod<DetectEntitiesV2Request, DetectEntitiesV2Response, DetectEntitiesV2Error, Credentials | HttpClient.HttpClient>;
export type DetectPHIError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Inspects the clinical text for protected health information (PHI) entities and returns
 * the entity category, location, and confidence score for each entity. Amazon Comprehend Medical
 * only detects entities in English language texts.
 */
export declare const detectPHI: API.OperationMethod<DetectPHIRequest, DetectPHIResponse, DetectPHIError, Credentials | HttpClient.HttpClient>;
export type InferICD10CMError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * InferICD10CM detects medical conditions as entities listed in a patient record and links
 * those entities to normalized concept identifiers in the ICD-10-CM knowledge base from the
 * Centers for Disease Control. Amazon Comprehend Medical only detects medical entities in
 * English language texts.
 */
export declare const inferICD10CM: API.OperationMethod<InferICD10CMRequest, InferICD10CMResponse, InferICD10CMError, Credentials | HttpClient.HttpClient>;
export type InferRxNormError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * InferRxNorm detects medications as entities listed in a patient record and links to the
 * normalized concept identifiers in the RxNorm database from the National Library of Medicine.
 * Amazon Comprehend Medical only detects medical entities in English language texts.
 */
export declare const inferRxNorm: API.OperationMethod<InferRxNormRequest, InferRxNormResponse, InferRxNormError, Credentials | HttpClient.HttpClient>;
export type InferSNOMEDCTError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * InferSNOMEDCT detects possible medical concepts as entities and links them to codes from the Systematized Nomenclature of Medicine, Clinical Terms (SNOMED-CT) ontology
 */
export declare const inferSNOMEDCT: API.OperationMethod<InferSNOMEDCTRequest, InferSNOMEDCTResponse, InferSNOMEDCTError, Credentials | HttpClient.HttpClient>;
export type ListEntitiesDetectionV2JobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of medical entity detection jobs that you have submitted.
 */
export declare const listEntitiesDetectionV2Jobs: API.OperationMethod<ListEntitiesDetectionV2JobsRequest, ListEntitiesDetectionV2JobsResponse, ListEntitiesDetectionV2JobsError, Credentials | HttpClient.HttpClient>;
export type ListICD10CMInferenceJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of InferICD10CM jobs that you have submitted.
 */
export declare const listICD10CMInferenceJobs: API.OperationMethod<ListICD10CMInferenceJobsRequest, ListICD10CMInferenceJobsResponse, ListICD10CMInferenceJobsError, Credentials | HttpClient.HttpClient>;
export type ListPHIDetectionJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of protected health information (PHI) detection jobs you have
 * submitted.
 */
export declare const listPHIDetectionJobs: API.OperationMethod<ListPHIDetectionJobsRequest, ListPHIDetectionJobsResponse, ListPHIDetectionJobsError, Credentials | HttpClient.HttpClient>;
export type ListRxNormInferenceJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of InferRxNorm jobs that you have submitted.
 */
export declare const listRxNormInferenceJobs: API.OperationMethod<ListRxNormInferenceJobsRequest, ListRxNormInferenceJobsResponse, ListRxNormInferenceJobsError, Credentials | HttpClient.HttpClient>;
export type ListSNOMEDCTInferenceJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of InferSNOMEDCT jobs a user has submitted.
 */
export declare const listSNOMEDCTInferenceJobs: API.OperationMethod<ListSNOMEDCTInferenceJobsRequest, ListSNOMEDCTInferenceJobsResponse, ListSNOMEDCTInferenceJobsError, Credentials | HttpClient.HttpClient>;
export type StartEntitiesDetectionV2JobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous medical entity detection job for a collection of documents. Use the
 * `DescribeEntitiesDetectionV2Job` operation to track the status of a job.
 */
export declare const startEntitiesDetectionV2Job: API.OperationMethod<StartEntitiesDetectionV2JobRequest, StartEntitiesDetectionV2JobResponse, StartEntitiesDetectionV2JobError, Credentials | HttpClient.HttpClient>;
export type StartICD10CMInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect medical conditions and link them to the ICD-10-CM
 * ontology. Use the `DescribeICD10CMInferenceJob` operation to track the status of a
 * job.
 */
export declare const startICD10CMInferenceJob: API.OperationMethod<StartICD10CMInferenceJobRequest, StartICD10CMInferenceJobResponse, StartICD10CMInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StartPHIDetectionJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect protected health information (PHI). Use the
 * `DescribePHIDetectionJob` operation to track the status of a job.
 */
export declare const startPHIDetectionJob: API.OperationMethod<StartPHIDetectionJobRequest, StartPHIDetectionJobResponse, StartPHIDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartRxNormInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect medication entities and link them to the RxNorm
 * ontology. Use the `DescribeRxNormInferenceJob` operation to track the status of a
 * job.
 */
export declare const startRxNormInferenceJob: API.OperationMethod<StartRxNormInferenceJobRequest, StartRxNormInferenceJobResponse, StartRxNormInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StartSNOMEDCTInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect medical concepts and link them to the SNOMED-CT ontology. Use the DescribeSNOMEDCTInferenceJob operation to track the status of a job.
 */
export declare const startSNOMEDCTInferenceJob: API.OperationMethod<StartSNOMEDCTInferenceJobRequest, StartSNOMEDCTInferenceJobResponse, StartSNOMEDCTInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StopEntitiesDetectionV2JobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a medical entities detection job in progress.
 */
export declare const stopEntitiesDetectionV2Job: API.OperationMethod<StopEntitiesDetectionV2JobRequest, StopEntitiesDetectionV2JobResponse, StopEntitiesDetectionV2JobError, Credentials | HttpClient.HttpClient>;
export type StopICD10CMInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops an InferICD10CM inference job in progress.
 */
export declare const stopICD10CMInferenceJob: API.OperationMethod<StopICD10CMInferenceJobRequest, StopICD10CMInferenceJobResponse, StopICD10CMInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StopPHIDetectionJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a protected health information (PHI) detection job in progress.
 */
export declare const stopPHIDetectionJob: API.OperationMethod<StopPHIDetectionJobRequest, StopPHIDetectionJobResponse, StopPHIDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopRxNormInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops an InferRxNorm inference job in progress.
 */
export declare const stopRxNormInferenceJob: API.OperationMethod<StopRxNormInferenceJobRequest, StopRxNormInferenceJobResponse, StopRxNormInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StopSNOMEDCTInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops an InferSNOMEDCT inference job in progress.
 */
export declare const stopSNOMEDCTInferenceJob: API.OperationMethod<StopSNOMEDCTInferenceJobRequest, StopSNOMEDCTInferenceJobResponse, StopSNOMEDCTInferenceJobError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=comprehendmedical.d.ts.map