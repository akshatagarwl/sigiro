import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type ExportName = string;
export type QueryStatement = string;
export type TableName = string;
export type TableProperty = string;
export type TablePropertyGenericString = string;
export type TableProperties = {
    [key: string]: string | undefined;
};
export declare const TableProperties: any;
export type TableConfigurations = {
    [key: string]: {
        [key: string]: string | undefined;
    } | undefined;
};
export declare const TableConfigurations: any;
export interface DataQuery {
    QueryStatement: string;
    TableConfigurations?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    };
}
export declare const DataQuery: S.Schema<DataQuery>;
export type AccountId = string;
export type S3OutputType = "CUSTOM" | "ATHENA" | "REDSHIFT" | (string & {});
export declare const S3OutputType: any;
export type FormatOption = "TEXT_OR_CSV" | "PARQUET" | (string & {});
export declare const FormatOption: any;
export type CompressionOption = "GZIP" | "PARQUET" | "ZIP" | (string & {});
export declare const CompressionOption: any;
export type OverwriteOption = "CREATE_NEW_REPORT" | "OVERWRITE_REPORT" | (string & {});
export declare const OverwriteOption: any;
export interface S3OutputConfigurations {
    OutputType: S3OutputType;
    Format: FormatOption;
    Compression: CompressionOption;
    Overwrite: OverwriteOption;
}
export declare const S3OutputConfigurations: S.Schema<S3OutputConfigurations>;
export interface S3Destination {
    S3Bucket: string;
    S3BucketOwner?: string;
    S3Prefix: string;
    S3Region: string;
    S3OutputConfigurations: S3OutputConfigurations;
}
export declare const S3Destination: S.Schema<S3Destination>;
export interface DestinationConfigurations {
    S3Destination: S3Destination;
}
export declare const DestinationConfigurations: S.Schema<DestinationConfigurations>;
export type FrequencyOption = "SYNCHRONOUS" | (string & {});
export declare const FrequencyOption: any;
export interface RefreshCadence {
    Frequency: FrequencyOption;
}
export declare const RefreshCadence: S.Schema<RefreshCadence>;
export interface Export {
    ExportArn?: string;
    Name: string;
    Description?: string;
    DataQuery: DataQuery;
    DestinationConfigurations: DestinationConfigurations;
    RefreshCadence: RefreshCadence;
}
export declare const Export: S.Schema<Export>;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value: string;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface CreateExportRequest {
    Export: Export;
    ResourceTags?: ResourceTag[];
}
export declare const CreateExportRequest: S.Schema<CreateExportRequest>;
export interface CreateExportResponse {
    ExportArn?: string;
}
export declare const CreateExportResponse: S.Schema<CreateExportResponse>;
export interface DeleteExportRequest {
    ExportArn: string;
}
export declare const DeleteExportRequest: S.Schema<DeleteExportRequest>;
export interface DeleteExportResponse {
    ExportArn?: string;
}
export declare const DeleteExportResponse: S.Schema<DeleteExportResponse>;
export interface GetExecutionRequest {
    ExportArn: string;
    ExecutionId: string;
}
export declare const GetExecutionRequest: S.Schema<GetExecutionRequest>;
export type ExecutionStatusCode = "INITIATION_IN_PROCESS" | "QUERY_QUEUED" | "QUERY_IN_PROCESS" | "QUERY_FAILURE" | "DELIVERY_IN_PROCESS" | "DELIVERY_SUCCESS" | "DELIVERY_FAILURE" | (string & {});
export declare const ExecutionStatusCode: any;
export type ExecutionStatusReason = "INSUFFICIENT_PERMISSION" | "BILL_OWNER_CHANGED" | "INTERNAL_FAILURE" | "DEPRECATED" | (string & {});
export declare const ExecutionStatusReason: any;
export interface ExecutionStatus {
    StatusCode?: ExecutionStatusCode;
    StatusReason?: ExecutionStatusReason;
    CreatedAt?: Date;
    CompletedAt?: Date;
    LastUpdatedAt?: Date;
}
export declare const ExecutionStatus: S.Schema<ExecutionStatus>;
export interface GetExecutionResponse {
    ExecutionId?: string;
    Export?: Export;
    ExecutionStatus?: ExecutionStatus;
}
export declare const GetExecutionResponse: S.Schema<GetExecutionResponse>;
export interface GetExportRequest {
    ExportArn: string;
}
export declare const GetExportRequest: S.Schema<GetExportRequest>;
export type ExportStatusCode = "HEALTHY" | "UNHEALTHY" | (string & {});
export declare const ExportStatusCode: any;
export interface ExportStatus {
    StatusCode?: ExportStatusCode;
    StatusReason?: ExecutionStatusReason;
    CreatedAt?: Date;
    LastUpdatedAt?: Date;
    LastRefreshedAt?: Date;
}
export declare const ExportStatus: S.Schema<ExportStatus>;
export interface GetExportResponse {
    Export?: Export;
    ExportStatus?: ExportStatus;
}
export declare const GetExportResponse: S.Schema<GetExportResponse>;
export interface GetTableRequest {
    TableName: string;
    TableProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const GetTableRequest: S.Schema<GetTableRequest>;
export interface Column {
    Name?: string;
    Type?: string;
    Description?: string;
}
export declare const Column: S.Schema<Column>;
export type ColumnList = Column[];
export declare const ColumnList: any;
export interface GetTableResponse {
    TableName?: string;
    Description?: string;
    TableProperties?: {
        [key: string]: string | undefined;
    };
    Schema?: Column[];
}
export declare const GetTableResponse: S.Schema<GetTableResponse>;
export type MaxResults = number;
export type NextPageToken = string;
export interface ListExecutionsRequest {
    ExportArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExecutionsRequest: S.Schema<ListExecutionsRequest>;
export interface ExecutionReference {
    ExecutionId: string;
    ExecutionStatus: ExecutionStatus;
}
export declare const ExecutionReference: S.Schema<ExecutionReference>;
export type ExecutionReferenceList = ExecutionReference[];
export declare const ExecutionReferenceList: any;
export interface ListExecutionsResponse {
    Executions?: ExecutionReference[];
    NextToken?: string;
}
export declare const ListExecutionsResponse: S.Schema<ListExecutionsResponse>;
export interface ListExportsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExportsRequest: S.Schema<ListExportsRequest>;
export interface ExportReference {
    ExportArn: string;
    ExportName: string;
    ExportStatus: ExportStatus;
}
export declare const ExportReference: S.Schema<ExportReference>;
export type ExportReferenceList = ExportReference[];
export declare const ExportReferenceList: any;
export interface ListExportsResponse {
    Exports?: ExportReference[];
    NextToken?: string;
}
export declare const ListExportsResponse: S.Schema<ListExportsResponse>;
export interface ListTablesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTablesRequest: S.Schema<ListTablesRequest>;
export type GenericStringList = string[];
export declare const GenericStringList: any;
export interface TablePropertyDescription {
    Name?: string;
    ValidValues?: string[];
    DefaultValue?: string;
    Description?: string;
}
export declare const TablePropertyDescription: S.Schema<TablePropertyDescription>;
export type TablePropertyDescriptionList = TablePropertyDescription[];
export declare const TablePropertyDescriptionList: any;
export interface Table {
    TableName?: string;
    Description?: string;
    TableProperties?: TablePropertyDescription[];
}
export declare const Table: S.Schema<Table>;
export type TableList = Table[];
export declare const TableList: any;
export interface ListTablesResponse {
    Tables?: Table[];
    NextToken?: string;
}
export declare const ListTablesResponse: S.Schema<ListTablesResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTag[];
    NextToken?: string;
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    ResourceTags: ResourceTag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ResourceTagKeyList = string[];
export declare const ResourceTagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    ResourceTagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateExportRequest {
    ExportArn: string;
    Export: Export;
}
export declare const UpdateExportRequest: S.Schema<UpdateExportRequest>;
export interface UpdateExportResponse {
    ExportArn?: string;
}
export declare const UpdateExportResponse: S.Schema<UpdateExportResponse>;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type CreateExportError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data export and specifies the data query, the delivery preference, and any optional resource tags.
 *
 * A `DataQuery` consists of both a `QueryStatement` and `TableConfigurations`.
 *
 * The `QueryStatement` is an SQL statement. Data Exports only supports a limited subset of the SQL syntax. For more information on the SQL syntax that is supported, see Data query. To view the available tables and columns, see the Data Exports table dictionary.
 *
 * The `TableConfigurations` is a collection of specified `TableProperties` for the table being queried in the `QueryStatement`. TableProperties are additional configurations you can provide to change the data and schema of a table. Each table can have different TableProperties. However, tables are not required to have any TableProperties. Each table property has a default value that it assumes if not specified. For more information on table configurations, see Data query. To view the table properties available for each table, see the Data Exports table dictionary or use the `ListTables` API to get a response of all tables and their available properties.
 */
export declare const createExport: API.OperationMethod<CreateExportRequest, CreateExportResponse, CreateExportError, Credentials | HttpClient.HttpClient>;
export type DeleteExportError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing data export.
 */
export declare const deleteExport: API.OperationMethod<DeleteExportRequest, DeleteExportResponse, DeleteExportError, Credentials | HttpClient.HttpClient>;
export type GetExecutionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Exports data based on the source data update.
 */
export declare const getExecution: API.OperationMethod<GetExecutionRequest, GetExecutionResponse, GetExecutionError, Credentials | HttpClient.HttpClient>;
export type GetExportError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Views the definition of an existing data export.
 */
export declare const getExport: API.OperationMethod<GetExportRequest, GetExportResponse, GetExportError, Credentials | HttpClient.HttpClient>;
export type GetTableError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the metadata for the specified table and table properties. This includes the list of columns in the table schema, their data types, and column descriptions.
 */
export declare const getTable: API.OperationMethod<GetTableRequest, GetTableResponse, GetTableError, Credentials | HttpClient.HttpClient>;
export type ListExecutionsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the historical executions for the export.
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsRequest, ListExecutionsResponse, ListExecutionsError, Credentials | HttpClient.HttpClient, ExecutionReference>;
export type ListExportsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all data export definitions.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsRequest, ListExportsResponse, ListExportsError, Credentials | HttpClient.HttpClient, ExportReference>;
export type ListTablesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available tables in data exports.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesRequest, ListTablesResponse, ListTablesError, Credentials | HttpClient.HttpClient, Table>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags associated with an existing data export.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags for an existing data export definition.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes tags associated with an existing data export definition.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateExportError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing data export by overwriting all export parameters. All export parameters must be provided in the UpdateExport request.
 */
export declare const updateExport: API.OperationMethod<UpdateExportRequest, UpdateExportResponse, UpdateExportError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bcm-data-exports.d.ts.map