import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Identifier = string;
export type UUID = string;
export type TaskIdList = string[];
export declare const TaskIdList: any;
export interface BatchGetUserAccessTasksRequest {
    appBundleIdentifier: string;
    taskIdList: string[];
}
export declare const BatchGetUserAccessTasksRequest: S.Schema<BatchGetUserAccessTasksRequest>;
export type String255 = string;
export type TenantIdentifier = string;
export type String2048 = string;
export type ResultStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | "EXPIRED" | (string & {});
export declare const ResultStatus: any;
export type Email = string | redacted.Redacted<string>;
export type SensitiveString2048 = string | redacted.Redacted<string>;
export interface TaskError {
    errorCode?: string;
    errorMessage?: string;
}
export declare const TaskError: S.Schema<TaskError>;
export interface UserAccessResultItem {
    app?: string;
    tenantId?: string;
    tenantDisplayName?: string;
    taskId?: string;
    resultStatus?: ResultStatus;
    email?: string | redacted.Redacted<string>;
    userId?: string | redacted.Redacted<string>;
    userFullName?: string | redacted.Redacted<string>;
    userFirstName?: string | redacted.Redacted<string>;
    userLastName?: string | redacted.Redacted<string>;
    userStatus?: string;
    taskError?: TaskError;
}
export declare const UserAccessResultItem: S.Schema<UserAccessResultItem>;
export type UserAccessResultsList = UserAccessResultItem[];
export declare const UserAccessResultsList: any;
export interface BatchGetUserAccessTasksResponse {
    userAccessResultsList?: UserAccessResultItem[];
}
export declare const BatchGetUserAccessTasksResponse: S.Schema<BatchGetUserAccessTasksResponse>;
export type RedirectUri = string;
export interface AuthRequest {
    redirectUri: string;
    code: string | redacted.Redacted<string>;
}
export declare const AuthRequest: S.Schema<AuthRequest>;
export interface ConnectAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
    authRequest?: AuthRequest;
}
export declare const ConnectAppAuthorizationRequest: S.Schema<ConnectAppAuthorizationRequest>;
export type Arn = string;
export interface Tenant {
    tenantIdentifier: string;
    tenantDisplayName: string;
}
export declare const Tenant: S.Schema<Tenant>;
export type AppAuthorizationStatus = "PendingConnect" | "Connected" | "ConnectionValidationFailed" | "TokenAutoRotationFailed" | (string & {});
export declare const AppAuthorizationStatus: any;
export interface AppAuthorizationSummary {
    appAuthorizationArn: string;
    appBundleArn: string;
    app: string;
    tenant: Tenant;
    status: AppAuthorizationStatus;
    updatedAt: Date;
}
export declare const AppAuthorizationSummary: S.Schema<AppAuthorizationSummary>;
export interface ConnectAppAuthorizationResponse {
    appAuthorizationSummary: AppAuthorizationSummary;
}
export declare const ConnectAppAuthorizationResponse: S.Schema<ConnectAppAuthorizationResponse>;
export interface Oauth2Credential {
    clientId: string;
    clientSecret: string | redacted.Redacted<string>;
}
export declare const Oauth2Credential: S.Schema<Oauth2Credential>;
export interface ApiKeyCredential {
    apiKey: string | redacted.Redacted<string>;
}
export declare const ApiKeyCredential: S.Schema<ApiKeyCredential>;
export type Credential = {
    oauth2Credential: Oauth2Credential;
    apiKeyCredential?: never;
} | {
    oauth2Credential?: never;
    apiKeyCredential: ApiKeyCredential;
};
export declare const Credential: any;
export type AuthType = "oauth2" | "apiKey" | (string & {});
export declare const AuthType: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateAppAuthorizationRequest {
    appBundleIdentifier: string;
    app: string;
    credential: Credential;
    tenant: Tenant;
    authType: AuthType;
    clientToken?: string;
    tags?: Tag[];
}
export declare const CreateAppAuthorizationRequest: S.Schema<CreateAppAuthorizationRequest>;
export type Persona = "admin" | "endUser" | (string & {});
export declare const Persona: any;
export interface AppAuthorization {
    appAuthorizationArn: string;
    appBundleArn: string;
    app: string;
    tenant: Tenant;
    authType: AuthType;
    status: AppAuthorizationStatus;
    createdAt: Date;
    updatedAt: Date;
    persona?: Persona;
    authUrl?: string;
}
export declare const AppAuthorization: S.Schema<AppAuthorization>;
export interface CreateAppAuthorizationResponse {
    appAuthorization: AppAuthorization;
}
export declare const CreateAppAuthorizationResponse: S.Schema<CreateAppAuthorizationResponse>;
export interface CreateAppBundleRequest {
    clientToken?: string;
    customerManagedKeyIdentifier?: string;
    tags?: Tag[];
}
export declare const CreateAppBundleRequest: S.Schema<CreateAppBundleRequest>;
export interface AppBundle {
    arn: string;
    customerManagedKeyArn?: string;
}
export declare const AppBundle: S.Schema<AppBundle>;
export interface CreateAppBundleResponse {
    appBundle: AppBundle;
}
export declare const CreateAppBundleResponse: S.Schema<CreateAppBundleResponse>;
export type IngestionType = "auditLog" | (string & {});
export declare const IngestionType: any;
export interface CreateIngestionRequest {
    appBundleIdentifier: string;
    app: string;
    tenantId: string;
    ingestionType: IngestionType;
    clientToken?: string;
    tags?: Tag[];
}
export declare const CreateIngestionRequest: S.Schema<CreateIngestionRequest>;
export type IngestionState = "enabled" | "disabled" | (string & {});
export declare const IngestionState: any;
export interface Ingestion {
    arn: string;
    appBundleArn: string;
    app: string;
    tenantId: string;
    createdAt: Date;
    updatedAt: Date;
    state: IngestionState;
    ingestionType: IngestionType;
}
export declare const Ingestion: S.Schema<Ingestion>;
export interface CreateIngestionResponse {
    ingestion: Ingestion;
}
export declare const CreateIngestionResponse: S.Schema<CreateIngestionResponse>;
export type Schema = "ocsf" | "raw" | (string & {});
export declare const Schema: any;
export type Format = "json" | "parquet" | (string & {});
export declare const Format: any;
export interface AuditLogProcessingConfiguration {
    schema: Schema;
    format: Format;
}
export declare const AuditLogProcessingConfiguration: S.Schema<AuditLogProcessingConfiguration>;
export type ProcessingConfiguration = {
    auditLog: AuditLogProcessingConfiguration;
};
export declare const ProcessingConfiguration: any;
export type String63 = string;
export type String120 = string;
export interface S3Bucket {
    bucketName: string;
    prefix?: string;
}
export declare const S3Bucket: S.Schema<S3Bucket>;
export type String64 = string;
export interface FirehoseStream {
    streamName: string;
}
export declare const FirehoseStream: S.Schema<FirehoseStream>;
export type Destination = {
    s3Bucket: S3Bucket;
    firehoseStream?: never;
} | {
    s3Bucket?: never;
    firehoseStream: FirehoseStream;
};
export declare const Destination: any;
export interface AuditLogDestinationConfiguration {
    destination: Destination;
}
export declare const AuditLogDestinationConfiguration: S.Schema<AuditLogDestinationConfiguration>;
export type DestinationConfiguration = {
    auditLog: AuditLogDestinationConfiguration;
};
export declare const DestinationConfiguration: any;
export interface CreateIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    processingConfiguration: ProcessingConfiguration;
    destinationConfiguration: DestinationConfiguration;
    clientToken?: string;
    tags?: Tag[];
}
export declare const CreateIngestionDestinationRequest: S.Schema<CreateIngestionDestinationRequest>;
export type IngestionDestinationStatus = "Active" | "Failed" | (string & {});
export declare const IngestionDestinationStatus: any;
export interface IngestionDestination {
    arn: string;
    ingestionArn: string;
    processingConfiguration: ProcessingConfiguration;
    destinationConfiguration: DestinationConfiguration;
    status?: IngestionDestinationStatus;
    statusReason?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
export declare const IngestionDestination: S.Schema<IngestionDestination>;
export interface CreateIngestionDestinationResponse {
    ingestionDestination: IngestionDestination;
}
export declare const CreateIngestionDestinationResponse: S.Schema<CreateIngestionDestinationResponse>;
export interface DeleteAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
}
export declare const DeleteAppAuthorizationRequest: S.Schema<DeleteAppAuthorizationRequest>;
export interface DeleteAppAuthorizationResponse {
}
export declare const DeleteAppAuthorizationResponse: S.Schema<DeleteAppAuthorizationResponse>;
export interface DeleteAppBundleRequest {
    appBundleIdentifier: string;
}
export declare const DeleteAppBundleRequest: S.Schema<DeleteAppBundleRequest>;
export interface DeleteAppBundleResponse {
}
export declare const DeleteAppBundleResponse: S.Schema<DeleteAppBundleResponse>;
export interface DeleteIngestionRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
}
export declare const DeleteIngestionRequest: S.Schema<DeleteIngestionRequest>;
export interface DeleteIngestionResponse {
}
export declare const DeleteIngestionResponse: S.Schema<DeleteIngestionResponse>;
export interface DeleteIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    ingestionDestinationIdentifier: string;
}
export declare const DeleteIngestionDestinationRequest: S.Schema<DeleteIngestionDestinationRequest>;
export interface DeleteIngestionDestinationResponse {
}
export declare const DeleteIngestionDestinationResponse: S.Schema<DeleteIngestionDestinationResponse>;
export interface GetAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
}
export declare const GetAppAuthorizationRequest: S.Schema<GetAppAuthorizationRequest>;
export interface GetAppAuthorizationResponse {
    appAuthorization: AppAuthorization;
}
export declare const GetAppAuthorizationResponse: S.Schema<GetAppAuthorizationResponse>;
export interface GetAppBundleRequest {
    appBundleIdentifier: string;
}
export declare const GetAppBundleRequest: S.Schema<GetAppBundleRequest>;
export interface GetAppBundleResponse {
    appBundle: AppBundle;
}
export declare const GetAppBundleResponse: S.Schema<GetAppBundleResponse>;
export interface GetIngestionRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
}
export declare const GetIngestionRequest: S.Schema<GetIngestionRequest>;
export interface GetIngestionResponse {
    ingestion: Ingestion;
}
export declare const GetIngestionResponse: S.Schema<GetIngestionResponse>;
export interface GetIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    ingestionDestinationIdentifier: string;
}
export declare const GetIngestionDestinationRequest: S.Schema<GetIngestionDestinationRequest>;
export interface GetIngestionDestinationResponse {
    ingestionDestination: IngestionDestination;
}
export declare const GetIngestionDestinationResponse: S.Schema<GetIngestionDestinationResponse>;
export type MaxResults = number;
export interface ListAppAuthorizationsRequest {
    appBundleIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAppAuthorizationsRequest: S.Schema<ListAppAuthorizationsRequest>;
export type AppAuthorizationSummaryList = AppAuthorizationSummary[];
export declare const AppAuthorizationSummaryList: any;
export interface ListAppAuthorizationsResponse {
    appAuthorizationSummaryList: AppAuthorizationSummary[];
    nextToken?: string;
}
export declare const ListAppAuthorizationsResponse: S.Schema<ListAppAuthorizationsResponse>;
export interface ListAppBundlesRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAppBundlesRequest: S.Schema<ListAppBundlesRequest>;
export interface AppBundleSummary {
    arn: string;
}
export declare const AppBundleSummary: S.Schema<AppBundleSummary>;
export type AppBundleSummaryList = AppBundleSummary[];
export declare const AppBundleSummaryList: any;
export interface ListAppBundlesResponse {
    appBundleSummaryList: AppBundleSummary[];
    nextToken?: string;
}
export declare const ListAppBundlesResponse: S.Schema<ListAppBundlesResponse>;
export interface ListIngestionDestinationsRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListIngestionDestinationsRequest: S.Schema<ListIngestionDestinationsRequest>;
export interface IngestionDestinationSummary {
    arn: string;
}
export declare const IngestionDestinationSummary: S.Schema<IngestionDestinationSummary>;
export type IngestionDestinationList = IngestionDestinationSummary[];
export declare const IngestionDestinationList: any;
export interface ListIngestionDestinationsResponse {
    ingestionDestinations: IngestionDestinationSummary[];
    nextToken?: string;
}
export declare const ListIngestionDestinationsResponse: S.Schema<ListIngestionDestinationsResponse>;
export interface ListIngestionsRequest {
    appBundleIdentifier: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListIngestionsRequest: S.Schema<ListIngestionsRequest>;
export interface IngestionSummary {
    arn: string;
    app: string;
    tenantId: string;
    state: IngestionState;
}
export declare const IngestionSummary: S.Schema<IngestionSummary>;
export type IngestionList = IngestionSummary[];
export declare const IngestionList: any;
export interface ListIngestionsResponse {
    ingestions: IngestionSummary[];
    nextToken?: string;
}
export declare const ListIngestionsResponse: S.Schema<ListIngestionsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface StartIngestionRequest {
    ingestionIdentifier: string;
    appBundleIdentifier: string;
}
export declare const StartIngestionRequest: S.Schema<StartIngestionRequest>;
export interface StartIngestionResponse {
}
export declare const StartIngestionResponse: S.Schema<StartIngestionResponse>;
export interface StartUserAccessTasksRequest {
    appBundleIdentifier: string;
    email: string | redacted.Redacted<string>;
}
export declare const StartUserAccessTasksRequest: S.Schema<StartUserAccessTasksRequest>;
export interface UserAccessTaskItem {
    app: string;
    tenantId: string;
    taskId?: string;
    error?: TaskError;
}
export declare const UserAccessTaskItem: S.Schema<UserAccessTaskItem>;
export type UserAccessTasksList = UserAccessTaskItem[];
export declare const UserAccessTasksList: any;
export interface StartUserAccessTasksResponse {
    userAccessTasksList?: UserAccessTaskItem[];
}
export declare const StartUserAccessTasksResponse: S.Schema<StartUserAccessTasksResponse>;
export interface StopIngestionRequest {
    ingestionIdentifier: string;
    appBundleIdentifier: string;
}
export declare const StopIngestionRequest: S.Schema<StopIngestionRequest>;
export interface StopIngestionResponse {
}
export declare const StopIngestionResponse: S.Schema<StopIngestionResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAppAuthorizationRequest {
    appBundleIdentifier: string;
    appAuthorizationIdentifier: string;
    credential?: Credential;
    tenant?: Tenant;
}
export declare const UpdateAppAuthorizationRequest: S.Schema<UpdateAppAuthorizationRequest>;
export interface UpdateAppAuthorizationResponse {
    appAuthorization: AppAuthorization;
}
export declare const UpdateAppAuthorizationResponse: S.Schema<UpdateAppAuthorizationResponse>;
export interface UpdateIngestionDestinationRequest {
    appBundleIdentifier: string;
    ingestionIdentifier: string;
    ingestionDestinationIdentifier: string;
    destinationConfiguration: DestinationConfiguration;
}
export declare const UpdateIngestionDestinationRequest: S.Schema<UpdateIngestionDestinationRequest>;
export interface UpdateIngestionDestinationResponse {
    ingestionDestination: IngestionDestination;
}
export declare const UpdateIngestionDestinationResponse: S.Schema<UpdateIngestionDestinationResponse>;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type BatchGetUserAccessTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets user access details in a batch request.
 *
 * This action polls data from the tasks that are kicked off by the
 * `StartUserAccessTasks` action.
 */
export declare const batchGetUserAccessTasks: API.OperationMethod<BatchGetUserAccessTasksRequest, BatchGetUserAccessTasksResponse, BatchGetUserAccessTasksError, Credentials | HttpClient.HttpClient>;
export type ConnectAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Establishes a connection between Amazon Web Services AppFabric and an application, which allows AppFabric to
 * call the APIs of the application.
 */
export declare const connectAppAuthorization: API.OperationMethod<ConnectAppAuthorizationRequest, ConnectAppAuthorizationResponse, ConnectAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type CreateAppAuthorizationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an app authorization within an app bundle, which allows AppFabric to connect to an
 * application.
 */
export declare const createAppAuthorization: API.OperationMethod<CreateAppAuthorizationRequest, CreateAppAuthorizationResponse, CreateAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type CreateAppBundleError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an app bundle to collect data from an application using AppFabric.
 */
export declare const createAppBundle: API.OperationMethod<CreateAppBundleRequest, CreateAppBundleResponse, CreateAppBundleError, Credentials | HttpClient.HttpClient>;
export type CreateIngestionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data ingestion for an application.
 */
export declare const createIngestion: API.OperationMethod<CreateIngestionRequest, CreateIngestionResponse, CreateIngestionError, Credentials | HttpClient.HttpClient>;
export type CreateIngestionDestinationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ingestion destination, which specifies how an application's ingested data is
 * processed by Amazon Web Services AppFabric and where it's delivered.
 */
export declare const createIngestionDestination: API.OperationMethod<CreateIngestionDestinationRequest, CreateIngestionDestinationResponse, CreateIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an app authorization. You must delete the associated ingestion before you can
 * delete an app authorization.
 */
export declare const deleteAppAuthorization: API.OperationMethod<DeleteAppAuthorizationRequest, DeleteAppAuthorizationResponse, DeleteAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type DeleteAppBundleError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an app bundle. You must delete all associated app authorizations before you can
 * delete an app bundle.
 */
export declare const deleteAppBundle: API.OperationMethod<DeleteAppBundleRequest, DeleteAppBundleResponse, DeleteAppBundleError, Credentials | HttpClient.HttpClient>;
export type DeleteIngestionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ingestion. You must stop (disable) the ingestion and you must delete all
 * associated ingestion destinations before you can delete an app ingestion.
 */
export declare const deleteIngestion: API.OperationMethod<DeleteIngestionRequest, DeleteIngestionResponse, DeleteIngestionError, Credentials | HttpClient.HttpClient>;
export type DeleteIngestionDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ingestion destination.
 *
 * This deletes the association between an ingestion and it's destination. It doesn't
 * delete previously ingested data or the storage destination, such as the Amazon S3
 * bucket where the data is delivered. If the ingestion destination is deleted while the
 * associated ingestion is enabled, the ingestion will fail and is eventually disabled.
 */
export declare const deleteIngestionDestination: API.OperationMethod<DeleteIngestionDestinationRequest, DeleteIngestionDestinationResponse, DeleteIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export type GetAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an app authorization.
 */
export declare const getAppAuthorization: API.OperationMethod<GetAppAuthorizationRequest, GetAppAuthorizationResponse, GetAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type GetAppBundleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an app bundle.
 */
export declare const getAppBundle: API.OperationMethod<GetAppBundleRequest, GetAppBundleResponse, GetAppBundleError, Credentials | HttpClient.HttpClient>;
export type GetIngestionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an ingestion.
 */
export declare const getIngestion: API.OperationMethod<GetIngestionRequest, GetIngestionResponse, GetIngestionError, Credentials | HttpClient.HttpClient>;
export type GetIngestionDestinationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an ingestion destination.
 */
export declare const getIngestionDestination: API.OperationMethod<GetIngestionDestinationRequest, GetIngestionDestinationResponse, GetIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export type ListAppAuthorizationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all app authorizations configured for an app bundle.
 */
export declare const listAppAuthorizations: API.PaginatedOperationMethod<ListAppAuthorizationsRequest, ListAppAuthorizationsResponse, ListAppAuthorizationsError, Credentials | HttpClient.HttpClient, AppAuthorizationSummary>;
export type ListAppBundlesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of app bundles.
 */
export declare const listAppBundles: API.PaginatedOperationMethod<ListAppBundlesRequest, ListAppBundlesResponse, ListAppBundlesError, Credentials | HttpClient.HttpClient, AppBundleSummary>;
export type ListIngestionDestinationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all ingestion destinations configured for an ingestion.
 */
export declare const listIngestionDestinations: API.PaginatedOperationMethod<ListIngestionDestinationsRequest, ListIngestionDestinationsResponse, ListIngestionDestinationsError, Credentials | HttpClient.HttpClient, IngestionDestinationSummary>;
export type ListIngestionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all ingestions configured for an app bundle.
 */
export declare const listIngestions: API.PaginatedOperationMethod<ListIngestionsRequest, ListIngestionsResponse, ListIngestionsError, Credentials | HttpClient.HttpClient, IngestionSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartIngestionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts (enables) an ingestion, which collects data from an application.
 */
export declare const startIngestion: API.OperationMethod<StartIngestionRequest, StartIngestionResponse, StartIngestionError, Credentials | HttpClient.HttpClient>;
export type StartUserAccessTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the tasks to search user access status for a specific email address.
 *
 * The tasks are stopped when the user access status data is found. The tasks are
 * terminated when the API calls to the application time out.
 */
export declare const startUserAccessTasks: API.OperationMethod<StartUserAccessTasksRequest, StartUserAccessTasksResponse, StartUserAccessTasksError, Credentials | HttpClient.HttpClient>;
export type StopIngestionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops (disables) an ingestion.
 */
export declare const stopIngestion: API.OperationMethod<StopIngestionRequest, StopIngestionResponse, StopIngestionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppAuthorizationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an app authorization within an app bundle, which allows AppFabric to connect to an
 * application.
 *
 * If the app authorization was in a `connected` state, updating the app
 * authorization will set it back to a `PendingConnect` state.
 */
export declare const updateAppAuthorization: API.OperationMethod<UpdateAppAuthorizationRequest, UpdateAppAuthorizationResponse, UpdateAppAuthorizationError, Credentials | HttpClient.HttpClient>;
export type UpdateIngestionDestinationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an ingestion destination, which specifies how an application's ingested data is
 * processed by Amazon Web Services AppFabric and where it's delivered.
 */
export declare const updateIngestionDestination: API.OperationMethod<UpdateIngestionDestinationRequest, UpdateIngestionDestinationResponse, UpdateIngestionDestinationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appfabric.d.ts.map