import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AlreadyExistsException_base: S.Class<AlreadyExistsException, S.TaggedStruct<"AlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const CFNRegistryException_base: S.Class<CFNRegistryException, S.TaggedStruct<"CFNRegistryException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CFNRegistryException extends /*@__PURE__*/ CFNRegistryException_base {
}
declare const ChangeSetNotFoundException_base: S.Class<ChangeSetNotFoundException, S.TaggedStruct<"ChangeSetNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChangeSetNotFoundException extends /*@__PURE__*/ ChangeSetNotFoundException_base {
}
declare const ConcurrentResourcesLimitExceededException_base: S.Class<ConcurrentResourcesLimitExceededException, S.TaggedStruct<"ConcurrentResourcesLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ConcurrentResourcesLimitExceededException extends /*@__PURE__*/ ConcurrentResourcesLimitExceededException_base {
}
declare const CreatedButModifiedException_base: S.Class<CreatedButModifiedException, S.TaggedStruct<"CreatedButModifiedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CreatedButModifiedException extends /*@__PURE__*/ CreatedButModifiedException_base {
}
declare const GeneratedTemplateNotFoundException_base: S.Class<GeneratedTemplateNotFoundException, S.TaggedStruct<"GeneratedTemplateNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GeneratedTemplateNotFoundException extends /*@__PURE__*/ GeneratedTemplateNotFoundException_base {
}
declare const HookResultNotFoundException_base: S.Class<HookResultNotFoundException, S.TaggedStruct<"HookResultNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HookResultNotFoundException extends /*@__PURE__*/ HookResultNotFoundException_base {
}
declare const InsufficientCapabilitiesException_base: S.Class<InsufficientCapabilitiesException, S.TaggedStruct<"InsufficientCapabilitiesException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientCapabilitiesException extends /*@__PURE__*/ InsufficientCapabilitiesException_base {
}
declare const InvalidChangeSetStatusException_base: S.Class<InvalidChangeSetStatusException, S.TaggedStruct<"InvalidChangeSetStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidChangeSetStatusException extends /*@__PURE__*/ InvalidChangeSetStatusException_base {
}
declare const InvalidOperationException_base: S.Class<InvalidOperationException, S.TaggedStruct<"InvalidOperationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidStateTransitionException_base: S.Class<InvalidStateTransitionException, S.TaggedStruct<"InvalidStateTransitionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateTransitionException extends /*@__PURE__*/ InvalidStateTransitionException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NameAlreadyExistsException_base: S.Class<NameAlreadyExistsException, S.TaggedStruct<"NameAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class NameAlreadyExistsException extends /*@__PURE__*/ NameAlreadyExistsException_base {
}
declare const NoUpdateToPerform_base: S.Class<NoUpdateToPerform, S.TaggedStruct<"NoUpdateToPerform", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoUpdateToPerform extends /*@__PURE__*/ NoUpdateToPerform_base {
}
declare const OperationIdAlreadyExistsException_base: S.Class<OperationIdAlreadyExistsException, S.TaggedStruct<"OperationIdAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OperationIdAlreadyExistsException extends /*@__PURE__*/ OperationIdAlreadyExistsException_base {
}
declare const OperationInProgressException_base: S.Class<OperationInProgressException, S.TaggedStruct<"OperationInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class OperationInProgressException extends /*@__PURE__*/ OperationInProgressException_base {
}
declare const OperationNotFoundException_base: S.Class<OperationNotFoundException, S.TaggedStruct<"OperationNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotFoundException extends /*@__PURE__*/ OperationNotFoundException_base {
}
declare const OperationStatusCheckFailedException_base: S.Class<OperationStatusCheckFailedException, S.TaggedStruct<"OperationStatusCheckFailedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationStatusCheckFailedException extends /*@__PURE__*/ OperationStatusCheckFailedException_base {
}
declare const ResourceScanInProgressException_base: S.Class<ResourceScanInProgressException, S.TaggedStruct<"ResourceScanInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceScanInProgressException extends /*@__PURE__*/ ResourceScanInProgressException_base {
}
declare const ResourceScanLimitExceededException_base: S.Class<ResourceScanLimitExceededException, S.TaggedStruct<"ResourceScanLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceScanLimitExceededException extends /*@__PURE__*/ ResourceScanLimitExceededException_base {
}
declare const ResourceScanNotFoundException_base: S.Class<ResourceScanNotFoundException, S.TaggedStruct<"ResourceScanNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceScanNotFoundException extends /*@__PURE__*/ ResourceScanNotFoundException_base {
}
declare const StackInstanceNotFoundException_base: S.Class<StackInstanceNotFoundException, S.TaggedStruct<"StackInstanceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackInstanceNotFoundException extends /*@__PURE__*/ StackInstanceNotFoundException_base {
}
declare const StackNotFound_base: S.Class<StackNotFound, S.TaggedStruct<"StackNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class StackNotFound extends /*@__PURE__*/ StackNotFound_base {
}
declare const StackNotFoundException_base: S.Class<StackNotFoundException, S.TaggedStruct<"StackNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackNotFoundException extends /*@__PURE__*/ StackNotFoundException_base {
}
declare const StackRefactorNotFoundException_base: S.Class<StackRefactorNotFoundException, S.TaggedStruct<"StackRefactorNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackRefactorNotFoundException extends /*@__PURE__*/ StackRefactorNotFoundException_base {
}
declare const StackSetNotEmptyException_base: S.Class<StackSetNotEmptyException, S.TaggedStruct<"StackSetNotEmptyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class StackSetNotEmptyException extends /*@__PURE__*/ StackSetNotEmptyException_base {
}
declare const StackSetNotFoundException_base: S.Class<StackSetNotFoundException, S.TaggedStruct<"StackSetNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackSetNotFoundException extends /*@__PURE__*/ StackSetNotFoundException_base {
}
declare const StaleRequestException_base: S.Class<StaleRequestException, S.TaggedStruct<"StaleRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class StaleRequestException extends /*@__PURE__*/ StaleRequestException_base {
}
declare const TokenAlreadyExistsException_base: S.Class<TokenAlreadyExistsException, S.TaggedStruct<"TokenAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TokenAlreadyExistsException extends /*@__PURE__*/ TokenAlreadyExistsException_base {
}
declare const TypeConfigurationNotFoundException_base: S.Class<TypeConfigurationNotFoundException, S.TaggedStruct<"TypeConfigurationNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TypeConfigurationNotFoundException extends /*@__PURE__*/ TypeConfigurationNotFoundException_base {
}
declare const TypeNotFoundException_base: S.Class<TypeNotFoundException, S.TaggedStruct<"TypeNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TypeNotFoundException extends /*@__PURE__*/ TypeNotFoundException_base {
}
export interface ActivateOrganizationsAccessInput {
}
export declare const ActivateOrganizationsAccessInput: S.Schema<ActivateOrganizationsAccessInput>;
export interface ActivateOrganizationsAccessOutput {
}
export declare const ActivateOrganizationsAccessOutput: S.Schema<ActivateOrganizationsAccessOutput>;
export type ThirdPartyType = "RESOURCE" | "MODULE" | "HOOK" | (string & {});
export declare const ThirdPartyType: any;
export type ThirdPartyTypeArn = string;
export type PublisherId = string;
export type TypeName = string;
export type AutoUpdate = boolean;
export type RoleARN2 = string;
export type LogGroupName = string;
export interface LoggingConfig {
    LogRoleArn?: string;
    LogGroupName?: string;
}
export declare const LoggingConfig: S.Schema<LoggingConfig>;
export type VersionBump = "MAJOR" | "MINOR" | (string & {});
export declare const VersionBump: any;
export type MajorVersion = number;
export interface ActivateTypeInput {
    Type?: ThirdPartyType;
    PublicTypeArn?: string;
    PublisherId?: string;
    TypeName?: string;
    TypeNameAlias?: string;
    AutoUpdate?: boolean;
    LoggingConfig?: LoggingConfig;
    ExecutionRoleArn?: string;
    VersionBump?: VersionBump;
    MajorVersion?: number;
}
export declare const ActivateTypeInput: S.Schema<ActivateTypeInput>;
export type PrivateTypeArn = string;
export interface ActivateTypeOutput {
    Arn?: string;
}
export declare const ActivateTypeOutput: S.Schema<ActivateTypeOutput>;
export type TypeArn = string;
export type TypeConfigurationAlias = string;
export type TypeConfigurationArn = string;
export interface TypeConfigurationIdentifier {
    TypeArn?: string;
    TypeConfigurationAlias?: string;
    TypeConfigurationArn?: string;
    Type?: ThirdPartyType;
    TypeName?: string;
}
export declare const TypeConfigurationIdentifier: S.Schema<TypeConfigurationIdentifier>;
export type TypeConfigurationIdentifiers = TypeConfigurationIdentifier[];
export declare const TypeConfigurationIdentifiers: any;
export interface BatchDescribeTypeConfigurationsInput {
    TypeConfigurationIdentifiers?: TypeConfigurationIdentifier[];
}
export declare const BatchDescribeTypeConfigurationsInput: S.Schema<BatchDescribeTypeConfigurationsInput>;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface BatchDescribeTypeConfigurationsError_ {
    ErrorCode?: string;
    ErrorMessage?: string;
    TypeConfigurationIdentifier?: TypeConfigurationIdentifier;
}
export declare const BatchDescribeTypeConfigurationsError_: S.Schema<BatchDescribeTypeConfigurationsError_>;
export type BatchDescribeTypeConfigurationsErrors = BatchDescribeTypeConfigurationsError_[];
export declare const BatchDescribeTypeConfigurationsErrors: any;
export type UnprocessedTypeConfigurations = TypeConfigurationIdentifier[];
export declare const UnprocessedTypeConfigurations: any;
export type TypeConfiguration = string;
export type IsDefaultConfiguration = boolean;
export interface TypeConfigurationDetails {
    Arn?: string;
    Alias?: string;
    Configuration?: string;
    LastUpdated?: Date;
    TypeArn?: string;
    TypeName?: string;
    IsDefaultConfiguration?: boolean;
}
export declare const TypeConfigurationDetails: S.Schema<TypeConfigurationDetails>;
export type TypeConfigurationDetailsList = TypeConfigurationDetails[];
export declare const TypeConfigurationDetailsList: any;
export interface BatchDescribeTypeConfigurationsOutput {
    Errors?: BatchDescribeTypeConfigurationsError_[];
    UnprocessedTypeConfigurations?: TypeConfigurationIdentifier[];
    TypeConfigurations?: TypeConfigurationDetails[];
}
export declare const BatchDescribeTypeConfigurationsOutput: S.Schema<BatchDescribeTypeConfigurationsOutput>;
export type StackName = string;
export type ClientRequestToken = string;
export interface CancelUpdateStackInput {
    StackName?: string;
    ClientRequestToken?: string;
}
export declare const CancelUpdateStackInput: S.Schema<CancelUpdateStackInput>;
export interface CancelUpdateStackResponse {
}
export declare const CancelUpdateStackResponse: S.Schema<CancelUpdateStackResponse>;
export type StackNameOrId = string;
export type RoleARN = string;
export type ResourceToSkip = string;
export type ResourcesToSkip = string[];
export declare const ResourcesToSkip: any;
export interface ContinueUpdateRollbackInput {
    StackName?: string;
    RoleARN?: string;
    ResourcesToSkip?: string[];
    ClientRequestToken?: string;
}
export declare const ContinueUpdateRollbackInput: S.Schema<ContinueUpdateRollbackInput>;
export interface ContinueUpdateRollbackOutput {
}
export declare const ContinueUpdateRollbackOutput: S.Schema<ContinueUpdateRollbackOutput>;
export type TemplateBody = string;
export type TemplateURL = string;
export type UsePreviousTemplate = boolean;
export type ParameterKey = string;
export type ParameterValue = string;
export type UsePreviousValue = boolean;
export interface Parameter {
    ParameterKey?: string;
    ParameterValue?: string;
    UsePreviousValue?: boolean;
    ResolvedValue?: string;
}
export declare const Parameter: S.Schema<Parameter>;
export type Parameters = Parameter[];
export declare const Parameters: any;
export type Capability = "CAPABILITY_IAM" | "CAPABILITY_NAMED_IAM" | "CAPABILITY_AUTO_EXPAND" | (string & {});
export declare const Capability: any;
export type Capabilities = Capability[];
export declare const Capabilities: any;
export type ResourceType = string;
export type ResourceTypes = string[];
export declare const ResourceTypes: any;
export type Arn = string;
export type Type = string;
export interface RollbackTrigger {
    Arn?: string;
    Type?: string;
}
export declare const RollbackTrigger: S.Schema<RollbackTrigger>;
export type RollbackTriggers = RollbackTrigger[];
export declare const RollbackTriggers: any;
export type MonitoringTimeInMinutes = number;
export interface RollbackConfiguration {
    RollbackTriggers?: RollbackTrigger[];
    MonitoringTimeInMinutes?: number;
}
export declare const RollbackConfiguration: S.Schema<RollbackConfiguration>;
export type NotificationARN = string;
export type NotificationARNs = string[];
export declare const NotificationARNs: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type Tags = Tag[];
export declare const Tags: any;
export type ChangeSetName = string;
export type ClientToken = string;
export type Description = string;
export type ChangeSetType = "CREATE" | "UPDATE" | "IMPORT" | (string & {});
export declare const ChangeSetType: any;
export type LogicalResourceId = string;
export type ResourceIdentifierPropertyKey = string;
export type ResourceIdentifierPropertyValue = string;
export type ResourceIdentifierProperties = {
    [key: string]: string | undefined;
};
export declare const ResourceIdentifierProperties: any;
export interface ResourceToImport {
    ResourceType?: string;
    LogicalResourceId?: string;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    };
}
export declare const ResourceToImport: S.Schema<ResourceToImport>;
export type ResourcesToImport = ResourceToImport[];
export declare const ResourcesToImport: any;
export type IncludeNestedStacks = boolean;
export type OnStackFailure = "DO_NOTHING" | "ROLLBACK" | "DELETE" | (string & {});
export declare const OnStackFailure: any;
export type ImportExistingResources = boolean;
export type DeploymentMode = "REVERT_DRIFT" | (string & {});
export declare const DeploymentMode: any;
export type DeploymentConfigMode = "STANDARD" | "EXPRESS" | (string & {});
export declare const DeploymentConfigMode: any;
export type DisableRollback = boolean;
export interface DeploymentConfig {
    Mode?: DeploymentConfigMode;
    DisableRollback?: boolean;
}
export declare const DeploymentConfig: S.Schema<DeploymentConfig>;
export type DisableValidation = boolean;
export interface CreateChangeSetInput {
    StackName?: string;
    TemplateBody?: string;
    TemplateURL?: string;
    UsePreviousTemplate?: boolean;
    Parameters?: Parameter[];
    Capabilities?: Capability[];
    ResourceTypes?: string[];
    RoleARN?: string;
    RollbackConfiguration?: RollbackConfiguration;
    NotificationARNs?: string[];
    Tags?: Tag[];
    ChangeSetName?: string;
    ClientToken?: string;
    Description?: string;
    ChangeSetType?: ChangeSetType;
    ResourcesToImport?: ResourceToImport[];
    IncludeNestedStacks?: boolean;
    OnStackFailure?: OnStackFailure;
    ImportExistingResources?: boolean;
    DeploymentMode?: DeploymentMode;
    DeploymentConfig?: DeploymentConfig;
    DisableValidation?: boolean;
}
export declare const CreateChangeSetInput: S.Schema<CreateChangeSetInput>;
export type ChangeSetId = string;
export type StackId = string;
export interface CreateChangeSetOutput {
    Id?: string;
    StackId?: string;
}
export declare const CreateChangeSetOutput: S.Schema<CreateChangeSetOutput>;
export interface ResourceDefinition {
    ResourceType?: string;
    LogicalResourceId?: string;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    };
}
export declare const ResourceDefinition: S.Schema<ResourceDefinition>;
export type ResourceDefinitions = ResourceDefinition[];
export declare const ResourceDefinitions: any;
export type GeneratedTemplateName = string;
export type GeneratedTemplateDeletionPolicy = "DELETE" | "RETAIN" | (string & {});
export declare const GeneratedTemplateDeletionPolicy: any;
export type GeneratedTemplateUpdateReplacePolicy = "DELETE" | "RETAIN" | (string & {});
export declare const GeneratedTemplateUpdateReplacePolicy: any;
export interface TemplateConfiguration {
    DeletionPolicy?: GeneratedTemplateDeletionPolicy;
    UpdateReplacePolicy?: GeneratedTemplateUpdateReplacePolicy;
}
export declare const TemplateConfiguration: S.Schema<TemplateConfiguration>;
export interface CreateGeneratedTemplateInput {
    Resources?: ResourceDefinition[];
    GeneratedTemplateName?: string;
    StackName?: string;
    TemplateConfiguration?: TemplateConfiguration;
}
export declare const CreateGeneratedTemplateInput: S.Schema<CreateGeneratedTemplateInput>;
export type GeneratedTemplateId = string;
export interface CreateGeneratedTemplateOutput {
    GeneratedTemplateId?: string;
}
export declare const CreateGeneratedTemplateOutput: S.Schema<CreateGeneratedTemplateOutput>;
export type TimeoutMinutes = number;
export type OnFailure = "DO_NOTHING" | "ROLLBACK" | "DELETE" | (string & {});
export declare const OnFailure: any;
export type StackPolicyBody = string;
export type StackPolicyURL = string;
export type EnableTerminationProtection = boolean;
export type RetainExceptOnCreate = boolean;
export interface CreateStackInput {
    StackName?: string;
    TemplateBody?: string;
    TemplateURL?: string;
    Parameters?: Parameter[];
    DisableRollback?: boolean;
    RollbackConfiguration?: RollbackConfiguration;
    TimeoutInMinutes?: number;
    NotificationARNs?: string[];
    Capabilities?: Capability[];
    ResourceTypes?: string[];
    RoleARN?: string;
    OnFailure?: OnFailure;
    StackPolicyBody?: string;
    StackPolicyURL?: string;
    Tags?: Tag[];
    ClientRequestToken?: string;
    EnableTerminationProtection?: boolean;
    RetainExceptOnCreate?: boolean;
    DeploymentConfig?: DeploymentConfig;
    DisableValidation?: boolean;
}
export declare const CreateStackInput: S.Schema<CreateStackInput>;
export type OperationId = string;
export interface CreateStackOutput {
    StackId?: string;
    OperationId?: string;
}
export declare const CreateStackOutput: S.Schema<CreateStackOutput>;
export type StackSetName = string;
export type Account = string;
export type AccountList = string[];
export declare const AccountList: any;
export type AccountsUrl = string;
export type OrganizationalUnitId = string;
export type OrganizationalUnitIdList = string[];
export declare const OrganizationalUnitIdList: any;
export type AccountFilterType = "NONE" | "INTERSECTION" | "DIFFERENCE" | "UNION" | (string & {});
export declare const AccountFilterType: any;
export interface DeploymentTargets {
    Accounts?: string[];
    AccountsUrl?: string;
    OrganizationalUnitIds?: string[];
    AccountFilterType?: AccountFilterType;
}
export declare const DeploymentTargets: S.Schema<DeploymentTargets>;
export type Region = string;
export type RegionList = string[];
export declare const RegionList: any;
export type RegionConcurrencyType = "SEQUENTIAL" | "PARALLEL" | (string & {});
export declare const RegionConcurrencyType: any;
export type FailureToleranceCount = number;
export type FailureTolerancePercentage = number;
export type MaxConcurrentCount = number;
export type MaxConcurrentPercentage = number;
export type ConcurrencyMode = "STRICT_FAILURE_TOLERANCE" | "SOFT_FAILURE_TOLERANCE" | (string & {});
export declare const ConcurrencyMode: any;
export interface StackSetOperationPreferences {
    RegionConcurrencyType?: RegionConcurrencyType;
    RegionOrder?: string[];
    FailureToleranceCount?: number;
    FailureTolerancePercentage?: number;
    MaxConcurrentCount?: number;
    MaxConcurrentPercentage?: number;
    ConcurrencyMode?: ConcurrencyMode;
}
export declare const StackSetOperationPreferences: S.Schema<StackSetOperationPreferences>;
export type CallAs = "SELF" | "DELEGATED_ADMIN" | (string & {});
export declare const CallAs: any;
export interface CreateStackInstancesInput {
    StackSetName?: string;
    Accounts?: string[];
    DeploymentTargets?: DeploymentTargets;
    Regions?: string[];
    ParameterOverrides?: Parameter[];
    OperationPreferences?: StackSetOperationPreferences;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const CreateStackInstancesInput: S.Schema<CreateStackInstancesInput>;
export interface CreateStackInstancesOutput {
    OperationId?: string;
}
export declare const CreateStackInstancesOutput: S.Schema<CreateStackInstancesOutput>;
export type EnableStackCreation = boolean;
export interface ResourceLocation {
    StackName?: string;
    LogicalResourceId?: string;
}
export declare const ResourceLocation: S.Schema<ResourceLocation>;
export interface ResourceMapping {
    Source?: ResourceLocation;
    Destination?: ResourceLocation;
}
export declare const ResourceMapping: S.Schema<ResourceMapping>;
export type ResourceMappings = ResourceMapping[];
export declare const ResourceMappings: any;
export interface StackDefinition {
    StackName?: string;
    TemplateBody?: string;
    TemplateURL?: string;
}
export declare const StackDefinition: S.Schema<StackDefinition>;
export type StackDefinitions = StackDefinition[];
export declare const StackDefinitions: any;
export interface CreateStackRefactorInput {
    Description?: string;
    EnableStackCreation?: boolean;
    ResourceMappings?: ResourceMapping[];
    StackDefinitions?: StackDefinition[];
}
export declare const CreateStackRefactorInput: S.Schema<CreateStackRefactorInput>;
export type StackRefactorId = string;
export interface CreateStackRefactorOutput {
    StackRefactorId: string;
}
export declare const CreateStackRefactorOutput: S.Schema<CreateStackRefactorOutput>;
export type ExecutionRoleName = string;
export type PermissionModels = "SERVICE_MANAGED" | "SELF_MANAGED" | (string & {});
export declare const PermissionModels: any;
export type AutoDeploymentNullable = boolean;
export type RetainStacksOnAccountRemovalNullable = boolean;
export type StackSetARN = string;
export type StackSetARNList = string[];
export declare const StackSetARNList: any;
export interface AutoDeployment {
    Enabled?: boolean;
    RetainStacksOnAccountRemoval?: boolean;
    DependsOn?: string[];
}
export declare const AutoDeployment: S.Schema<AutoDeployment>;
export type ManagedExecutionNullable = boolean;
export interface ManagedExecution {
    Active?: boolean;
}
export declare const ManagedExecution: S.Schema<ManagedExecution>;
export interface CreateStackSetInput {
    StackSetName?: string;
    Description?: string;
    TemplateBody?: string;
    TemplateURL?: string;
    StackId?: string;
    Parameters?: Parameter[];
    Capabilities?: Capability[];
    Tags?: Tag[];
    AdministrationRoleARN?: string;
    ExecutionRoleName?: string;
    PermissionModel?: PermissionModels;
    AutoDeployment?: AutoDeployment;
    CallAs?: CallAs;
    ClientRequestToken?: string;
    ManagedExecution?: ManagedExecution;
}
export declare const CreateStackSetInput: S.Schema<CreateStackSetInput>;
export type StackSetId = string;
export interface CreateStackSetOutput {
    StackSetId?: string;
}
export declare const CreateStackSetOutput: S.Schema<CreateStackSetOutput>;
export interface DeactivateOrganizationsAccessInput {
}
export declare const DeactivateOrganizationsAccessInput: S.Schema<DeactivateOrganizationsAccessInput>;
export interface DeactivateOrganizationsAccessOutput {
}
export declare const DeactivateOrganizationsAccessOutput: S.Schema<DeactivateOrganizationsAccessOutput>;
export interface DeactivateTypeInput {
    TypeName?: string;
    Type?: ThirdPartyType;
    Arn?: string;
}
export declare const DeactivateTypeInput: S.Schema<DeactivateTypeInput>;
export interface DeactivateTypeOutput {
}
export declare const DeactivateTypeOutput: S.Schema<DeactivateTypeOutput>;
export type ChangeSetNameOrId = string;
export interface DeleteChangeSetInput {
    ChangeSetName?: string;
    StackName?: string;
}
export declare const DeleteChangeSetInput: S.Schema<DeleteChangeSetInput>;
export interface DeleteChangeSetOutput {
}
export declare const DeleteChangeSetOutput: S.Schema<DeleteChangeSetOutput>;
export interface DeleteGeneratedTemplateInput {
    GeneratedTemplateName?: string;
}
export declare const DeleteGeneratedTemplateInput: S.Schema<DeleteGeneratedTemplateInput>;
export interface DeleteGeneratedTemplateResponse {
}
export declare const DeleteGeneratedTemplateResponse: S.Schema<DeleteGeneratedTemplateResponse>;
export type RetainResources = string[];
export declare const RetainResources: any;
export type DeletionMode = "STANDARD" | "FORCE_DELETE_STACK" | (string & {});
export declare const DeletionMode: any;
export interface DeleteStackInput {
    StackName?: string;
    RetainResources?: string[];
    RoleARN?: string;
    ClientRequestToken?: string;
    DeletionMode?: DeletionMode;
    DeploymentConfig?: DeploymentConfig;
}
export declare const DeleteStackInput: S.Schema<DeleteStackInput>;
export interface DeleteStackResponse {
}
export declare const DeleteStackResponse: S.Schema<DeleteStackResponse>;
export type RetainStacks = boolean;
export interface DeleteStackInstancesInput {
    StackSetName?: string;
    Accounts?: string[];
    DeploymentTargets?: DeploymentTargets;
    Regions?: string[];
    OperationPreferences?: StackSetOperationPreferences;
    RetainStacks?: boolean;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const DeleteStackInstancesInput: S.Schema<DeleteStackInstancesInput>;
export interface DeleteStackInstancesOutput {
    OperationId?: string;
}
export declare const DeleteStackInstancesOutput: S.Schema<DeleteStackInstancesOutput>;
export interface DeleteStackSetInput {
    StackSetName?: string;
    CallAs?: CallAs;
}
export declare const DeleteStackSetInput: S.Schema<DeleteStackSetInput>;
export interface DeleteStackSetOutput {
}
export declare const DeleteStackSetOutput: S.Schema<DeleteStackSetOutput>;
export type RegistryType = "RESOURCE" | "MODULE" | "HOOK" | (string & {});
export declare const RegistryType: any;
export type TypeVersionId = string;
export interface DeregisterTypeInput {
    Arn?: string;
    Type?: RegistryType;
    TypeName?: string;
    VersionId?: string;
}
export declare const DeregisterTypeInput: S.Schema<DeregisterTypeInput>;
export interface DeregisterTypeOutput {
}
export declare const DeregisterTypeOutput: S.Schema<DeregisterTypeOutput>;
export type NextToken = string;
export interface DescribeAccountLimitsInput {
    NextToken?: string;
}
export declare const DescribeAccountLimitsInput: S.Schema<DescribeAccountLimitsInput>;
export type LimitName = string;
export type LimitValue = number;
export interface AccountLimit {
    Name?: string;
    Value?: number;
}
export declare const AccountLimit: S.Schema<AccountLimit>;
export type AccountLimitList = AccountLimit[];
export declare const AccountLimitList: any;
export interface DescribeAccountLimitsOutput {
    AccountLimits?: AccountLimit[];
    NextToken?: string;
}
export declare const DescribeAccountLimitsOutput: S.Schema<DescribeAccountLimitsOutput>;
export type IncludePropertyValues = boolean;
export interface DescribeChangeSetInput {
    ChangeSetName?: string;
    StackName?: string;
    NextToken?: string;
    IncludePropertyValues?: boolean;
}
export declare const DescribeChangeSetInput: S.Schema<DescribeChangeSetInput>;
export type CreationTime = Date;
export type ExecutionStatus = "UNAVAILABLE" | "AVAILABLE" | "EXECUTE_IN_PROGRESS" | "EXECUTE_COMPLETE" | "EXECUTE_FAILED" | "OBSOLETE" | (string & {});
export declare const ExecutionStatus: any;
export type ChangeSetStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "DELETE_PENDING" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "FAILED" | (string & {});
export declare const ChangeSetStatus: any;
export type ChangeSetStatusReason = string;
export type StackDriftStatus = "DRIFTED" | "IN_SYNC" | "UNKNOWN" | "NOT_CHECKED" | (string & {});
export declare const StackDriftStatus: any;
export type ChangeType = "Resource" | (string & {});
export declare const ChangeType: any;
export type HookInvocationCount = number;
export type PolicyAction = "Delete" | "Retain" | "Snapshot" | "ReplaceAndDelete" | "ReplaceAndRetain" | "ReplaceAndSnapshot" | (string & {});
export declare const PolicyAction: any;
export type ChangeAction = "Add" | "Modify" | "Remove" | "Import" | "Dynamic" | "SyncWithActual" | (string & {});
export declare const ChangeAction: any;
export type PhysicalResourceId = string;
export type Replacement = "True" | "False" | "Conditional" | (string & {});
export declare const Replacement: any;
export type ResourceAttribute = "Properties" | "Metadata" | "CreationPolicy" | "UpdatePolicy" | "DeletionPolicy" | "UpdateReplacePolicy" | "Tags" | (string & {});
export declare const ResourceAttribute: any;
export type Scope = ResourceAttribute[];
export declare const Scope: any;
export type StackResourceDriftStatus = "IN_SYNC" | "MODIFIED" | "DELETED" | "NOT_CHECKED" | "UNKNOWN" | "UNSUPPORTED" | (string & {});
export declare const StackResourceDriftStatus: any;
export type ResourcePropertyPath = string;
export type DriftIgnoredReason = "MANAGED_BY_AWS" | "WRITE_ONLY_PROPERTY" | "SENSITIVE_PROPERTY" | (string & {});
export declare const DriftIgnoredReason: any;
export interface ResourceDriftIgnoredAttribute {
    Path?: string;
    Reason?: DriftIgnoredReason;
}
export declare const ResourceDriftIgnoredAttribute: S.Schema<ResourceDriftIgnoredAttribute>;
export type ResourceDriftIgnoredAttributes = ResourceDriftIgnoredAttribute[];
export declare const ResourceDriftIgnoredAttributes: any;
export type PropertyName = string;
export type RequiresRecreation = "Never" | "Conditionally" | "Always" | (string & {});
export declare const RequiresRecreation: any;
export type BeforeValue = string;
export type AfterValue = string;
export type BeforeValueFrom = "PREVIOUS_DEPLOYMENT_STATE" | "ACTUAL_STATE" | (string & {});
export declare const BeforeValueFrom: any;
export type AfterValueFrom = "TEMPLATE" | (string & {});
export declare const AfterValueFrom: any;
export type ResourceDriftPreviousValue = string;
export type ResourceDriftActualValue = string;
export interface LiveResourceDrift {
    PreviousValue?: string;
    ActualValue?: string;
    DriftDetectionTimestamp?: Date;
}
export declare const LiveResourceDrift: S.Schema<LiveResourceDrift>;
export type AttributeChangeType = "Add" | "Remove" | "Modify" | "SyncWithActual" | (string & {});
export declare const AttributeChangeType: any;
export interface ResourceTargetDefinition {
    Attribute?: ResourceAttribute;
    Name?: string;
    RequiresRecreation?: RequiresRecreation;
    Path?: string;
    BeforeValue?: string;
    AfterValue?: string;
    BeforeValueFrom?: BeforeValueFrom;
    AfterValueFrom?: AfterValueFrom;
    Drift?: LiveResourceDrift;
    AttributeChangeType?: AttributeChangeType;
}
export declare const ResourceTargetDefinition: S.Schema<ResourceTargetDefinition>;
export type EvaluationType = "Static" | "Dynamic" | (string & {});
export declare const EvaluationType: any;
export type ChangeSource = "ResourceReference" | "ParameterReference" | "ResourceAttribute" | "DirectModification" | "Automatic" | "NoModification" | (string & {});
export declare const ChangeSource: any;
export type CausingEntity = string;
export interface ResourceChangeDetail {
    Target?: ResourceTargetDefinition;
    Evaluation?: EvaluationType;
    ChangeSource?: ChangeSource;
    CausingEntity?: string;
}
export declare const ResourceChangeDetail: S.Schema<ResourceChangeDetail>;
export type ResourceChangeDetails = ResourceChangeDetail[];
export declare const ResourceChangeDetails: any;
export type TypeHierarchy = string;
export type LogicalIdHierarchy = string;
export interface ModuleInfo {
    TypeHierarchy?: string;
    LogicalIdHierarchy?: string;
}
export declare const ModuleInfo: S.Schema<ModuleInfo>;
export type BeforeContext = string;
export type AfterContext = string;
export type PreviousDeploymentContext = string;
export interface ResourceChange {
    PolicyAction?: PolicyAction;
    Action?: ChangeAction;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    ResourceType?: string;
    Replacement?: Replacement;
    Scope?: ResourceAttribute[];
    ResourceDriftStatus?: StackResourceDriftStatus;
    ResourceDriftIgnoredAttributes?: ResourceDriftIgnoredAttribute[];
    Details?: ResourceChangeDetail[];
    ChangeSetId?: string;
    ModuleInfo?: ModuleInfo;
    BeforeContext?: string;
    AfterContext?: string;
    PreviousDeploymentContext?: string;
}
export declare const ResourceChange: S.Schema<ResourceChange>;
export interface Change {
    Type?: ChangeType;
    HookInvocationCount?: number;
    ResourceChange?: ResourceChange;
}
export declare const Change: S.Schema<Change>;
export type Changes = Change[];
export declare const Changes: any;
export interface DescribeChangeSetOutput {
    ChangeSetName?: string;
    ChangeSetId?: string;
    StackId?: string;
    StackName?: string;
    Description?: string;
    Parameters?: Parameter[];
    CreationTime?: Date;
    ExecutionStatus?: ExecutionStatus;
    Status?: ChangeSetStatus;
    StatusReason?: string;
    StackDriftStatus?: StackDriftStatus;
    NotificationARNs?: string[];
    RollbackConfiguration?: RollbackConfiguration & {
        RollbackTriggers: (RollbackTrigger & {
            Arn: Arn;
            Type: Type;
        })[];
    };
    Capabilities?: Capability[];
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[];
    Changes?: Change[];
    NextToken?: string;
    IncludeNestedStacks?: boolean;
    ParentChangeSetId?: string;
    RootChangeSetId?: string;
    OnStackFailure?: OnStackFailure;
    ImportExistingResources?: boolean;
    DeploymentMode?: DeploymentMode;
    DeploymentConfig?: DeploymentConfig;
}
export declare const DescribeChangeSetOutput: S.Schema<DescribeChangeSetOutput>;
export interface DescribeChangeSetHooksInput {
    ChangeSetName?: string;
    StackName?: string;
    NextToken?: string;
    LogicalResourceId?: string;
}
export declare const DescribeChangeSetHooksInput: S.Schema<DescribeChangeSetHooksInput>;
export type HookInvocationPoint = "PRE_PROVISION" | (string & {});
export declare const HookInvocationPoint: any;
export type HookFailureMode = "FAIL" | "WARN" | (string & {});
export declare const HookFailureMode: any;
export type HookTypeName = string;
export type HookTypeVersionId = string;
export type HookTypeConfigurationVersionId = string;
export type HookTargetType = "RESOURCE" | (string & {});
export declare const HookTargetType: any;
export type HookTargetTypeName = string;
export interface ChangeSetHookResourceTargetDetails {
    LogicalResourceId?: string;
    ResourceType?: string;
    ResourceAction?: ChangeAction;
}
export declare const ChangeSetHookResourceTargetDetails: S.Schema<ChangeSetHookResourceTargetDetails>;
export interface ChangeSetHookTargetDetails {
    TargetType?: HookTargetType;
    ResourceTargetDetails?: ChangeSetHookResourceTargetDetails;
}
export declare const ChangeSetHookTargetDetails: S.Schema<ChangeSetHookTargetDetails>;
export interface ChangeSetHook {
    InvocationPoint?: HookInvocationPoint;
    FailureMode?: HookFailureMode;
    TypeName?: string;
    TypeVersionId?: string;
    TypeConfigurationVersionId?: string;
    TargetDetails?: ChangeSetHookTargetDetails;
}
export declare const ChangeSetHook: S.Schema<ChangeSetHook>;
export type ChangeSetHooks = ChangeSetHook[];
export declare const ChangeSetHooks: any;
export type ChangeSetHooksStatus = "PLANNING" | "PLANNED" | "UNAVAILABLE" | (string & {});
export declare const ChangeSetHooksStatus: any;
export interface DescribeChangeSetHooksOutput {
    ChangeSetId?: string;
    ChangeSetName?: string;
    Hooks?: ChangeSetHook[];
    Status?: ChangeSetHooksStatus;
    NextToken?: string;
    StackId?: string;
    StackName?: string;
}
export declare const DescribeChangeSetHooksOutput: S.Schema<DescribeChangeSetHooksOutput>;
export type FailedEventsFilter = boolean;
export interface EventFilter {
    FailedEvents?: boolean;
}
export declare const EventFilter: S.Schema<EventFilter>;
export interface DescribeEventsInput {
    StackName?: string;
    ChangeSetName?: string;
    OperationId?: string;
    Filters?: EventFilter;
    NextToken?: string;
}
export declare const DescribeEventsInput: S.Schema<DescribeEventsInput>;
export type EventId = string;
export type OperationType = "CREATE_STACK" | "UPDATE_STACK" | "DELETE_STACK" | "CONTINUE_ROLLBACK" | "ROLLBACK" | "CREATE_CHANGESET" | (string & {});
export declare const OperationType: any;
export type BeaconStackOperationStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const BeaconStackOperationStatus: any;
export type EventType = "STACK_EVENT" | "PROGRESS_EVENT" | "VALIDATION_ERROR" | "PROVISIONING_ERROR" | "HOOK_INVOCATION_ERROR" | (string & {});
export declare const EventType: any;
export type ResourceStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "CREATE_COMPLETE" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "DELETE_COMPLETE" | "DELETE_SKIPPED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | "UPDATE_COMPLETE" | "IMPORT_FAILED" | "IMPORT_COMPLETE" | "IMPORT_IN_PROGRESS" | "IMPORT_ROLLBACK_IN_PROGRESS" | "IMPORT_ROLLBACK_FAILED" | "IMPORT_ROLLBACK_COMPLETE" | "EXPORT_FAILED" | "EXPORT_COMPLETE" | "EXPORT_IN_PROGRESS" | "EXPORT_ROLLBACK_IN_PROGRESS" | "EXPORT_ROLLBACK_FAILED" | "EXPORT_ROLLBACK_COMPLETE" | "UPDATE_ROLLBACK_IN_PROGRESS" | "UPDATE_ROLLBACK_COMPLETE" | "UPDATE_ROLLBACK_FAILED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_COMPLETE" | "ROLLBACK_FAILED" | (string & {});
export declare const ResourceStatus: any;
export type ResourceStatusReason = string;
export type ResourceProperties = string;
export type HookType = string;
export type HookStatus = "HOOK_IN_PROGRESS" | "HOOK_COMPLETE_SUCCEEDED" | "HOOK_COMPLETE_FAILED" | "HOOK_FAILED" | (string & {});
export declare const HookStatus: any;
export type HookStatusReason = string;
export type DetailedStatus = "CONFIGURATION_COMPLETE" | "VALIDATION_FAILED" | (string & {});
export declare const DetailedStatus: any;
export type ValidationName = string;
export type ValidationStatus = "FAILED" | "SKIPPED" | (string & {});
export declare const ValidationStatus: any;
export type ValidationStatusReason = string;
export type ValidationPath = string;
export interface OperationEvent {
    EventId?: string;
    StackId?: string;
    OperationId?: string;
    OperationType?: OperationType;
    OperationStatus?: BeaconStackOperationStatus;
    EventType?: EventType;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    ResourceType?: string;
    Timestamp?: Date;
    StartTime?: Date;
    EndTime?: Date;
    ResourceStatus?: ResourceStatus;
    ResourceStatusReason?: string;
    ResourceProperties?: string;
    ClientRequestToken?: string;
    HookType?: string;
    HookStatus?: HookStatus;
    HookStatusReason?: string;
    HookInvocationPoint?: HookInvocationPoint;
    HookFailureMode?: HookFailureMode;
    DetailedStatus?: DetailedStatus;
    ValidationFailureMode?: HookFailureMode;
    ValidationName?: string;
    ValidationStatus?: ValidationStatus;
    ValidationStatusReason?: string;
    ValidationPath?: string;
}
export declare const OperationEvent: S.Schema<OperationEvent>;
export type OperationEvents = OperationEvent[];
export declare const OperationEvents: any;
export interface DescribeEventsOutput {
    OperationEvents?: OperationEvent[];
    NextToken?: string;
}
export declare const DescribeEventsOutput: S.Schema<DescribeEventsOutput>;
export interface DescribeGeneratedTemplateInput {
    GeneratedTemplateName?: string;
}
export declare const DescribeGeneratedTemplateInput: S.Schema<DescribeGeneratedTemplateInput>;
export type GeneratedTemplateResourceStatus = "PENDING" | "IN_PROGRESS" | "FAILED" | "COMPLETE" | (string & {});
export declare const GeneratedTemplateResourceStatus: any;
export type WarningType = "MUTUALLY_EXCLUSIVE_PROPERTIES" | "UNSUPPORTED_PROPERTIES" | "MUTUALLY_EXCLUSIVE_TYPES" | "EXCLUDED_PROPERTIES" | "EXCLUDED_RESOURCES" | (string & {});
export declare const WarningType: any;
export type PropertyPath = string;
export type RequiredProperty = boolean;
export type PropertyDescription = string;
export interface WarningProperty {
    PropertyPath?: string;
    Required?: boolean;
    Description?: string;
}
export declare const WarningProperty: S.Schema<WarningProperty>;
export type WarningProperties = WarningProperty[];
export declare const WarningProperties: any;
export interface WarningDetail {
    Type?: WarningType;
    Properties?: WarningProperty[];
}
export declare const WarningDetail: S.Schema<WarningDetail>;
export type WarningDetails = WarningDetail[];
export declare const WarningDetails: any;
export interface ResourceDetail {
    ResourceType?: string;
    LogicalResourceId?: string;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    };
    ResourceStatus?: GeneratedTemplateResourceStatus;
    ResourceStatusReason?: string;
    Warnings?: WarningDetail[];
}
export declare const ResourceDetail: S.Schema<ResourceDetail>;
export type ResourceDetails = ResourceDetail[];
export declare const ResourceDetails: any;
export type GeneratedTemplateStatus = "CREATE_PENDING" | "UPDATE_PENDING" | "DELETE_PENDING" | "CREATE_IN_PROGRESS" | "UPDATE_IN_PROGRESS" | "DELETE_IN_PROGRESS" | "FAILED" | "COMPLETE" | (string & {});
export declare const GeneratedTemplateStatus: any;
export type TemplateStatusReason = string;
export type LastUpdatedTime = Date;
export type ResourcesSucceeded = number;
export type ResourcesFailed = number;
export type ResourcesProcessing = number;
export type ResourcesPending = number;
export interface TemplateProgress {
    ResourcesSucceeded?: number;
    ResourcesFailed?: number;
    ResourcesProcessing?: number;
    ResourcesPending?: number;
}
export declare const TemplateProgress: S.Schema<TemplateProgress>;
export type TotalWarnings = number;
export interface DescribeGeneratedTemplateOutput {
    GeneratedTemplateId?: string;
    GeneratedTemplateName?: string;
    Resources?: ResourceDetail[];
    Status?: GeneratedTemplateStatus;
    StatusReason?: string;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
    Progress?: TemplateProgress;
    StackId?: string;
    TemplateConfiguration?: TemplateConfiguration;
    TotalWarnings?: number;
}
export declare const DescribeGeneratedTemplateOutput: S.Schema<DescribeGeneratedTemplateOutput>;
export interface DescribeOrganizationsAccessInput {
    CallAs?: CallAs;
}
export declare const DescribeOrganizationsAccessInput: S.Schema<DescribeOrganizationsAccessInput>;
export type OrganizationStatus = "ENABLED" | "DISABLED" | "DISABLED_PERMANENTLY" | (string & {});
export declare const OrganizationStatus: any;
export interface DescribeOrganizationsAccessOutput {
    Status?: OrganizationStatus;
}
export declare const DescribeOrganizationsAccessOutput: S.Schema<DescribeOrganizationsAccessOutput>;
export interface DescribePublisherInput {
    PublisherId?: string;
}
export declare const DescribePublisherInput: S.Schema<DescribePublisherInput>;
export type PublisherStatus = "VERIFIED" | "UNVERIFIED" | (string & {});
export declare const PublisherStatus: any;
export type IdentityProvider = "AWS_Marketplace" | "GitHub" | "Bitbucket" | (string & {});
export declare const IdentityProvider: any;
export type PublisherProfile = string;
export interface DescribePublisherOutput {
    PublisherId?: string;
    PublisherStatus?: PublisherStatus;
    IdentityProvider?: IdentityProvider;
    PublisherProfile?: string;
}
export declare const DescribePublisherOutput: S.Schema<DescribePublisherOutput>;
export type ResourceScanId = string;
export interface DescribeResourceScanInput {
    ResourceScanId?: string;
}
export declare const DescribeResourceScanInput: S.Schema<DescribeResourceScanInput>;
export type ResourceScanStatus = "IN_PROGRESS" | "FAILED" | "COMPLETE" | "EXPIRED" | (string & {});
export declare const ResourceScanStatus: any;
export type ResourceScanStatusReason = string;
export type PercentageCompleted = number;
export type ResourcesScanned = number;
export type ResourcesRead = number;
export type ResourceTypeFilter = string;
export type ResourceTypeFilters = string[];
export declare const ResourceTypeFilters: any;
export interface ScanFilter {
    Types?: string[];
}
export declare const ScanFilter: S.Schema<ScanFilter>;
export type ScanFilters = ScanFilter[];
export declare const ScanFilters: any;
export interface DescribeResourceScanOutput {
    ResourceScanId?: string;
    Status?: ResourceScanStatus;
    StatusReason?: string;
    StartTime?: Date;
    EndTime?: Date;
    PercentageCompleted?: number;
    ResourceTypes?: string[];
    ResourcesScanned?: number;
    ResourcesRead?: number;
    ScanFilters?: ScanFilter[];
}
export declare const DescribeResourceScanOutput: S.Schema<DescribeResourceScanOutput>;
export type StackDriftDetectionId = string;
export interface DescribeStackDriftDetectionStatusInput {
    StackDriftDetectionId?: string;
}
export declare const DescribeStackDriftDetectionStatusInput: S.Schema<DescribeStackDriftDetectionStatusInput>;
export type StackDriftDetectionStatus = "DETECTION_IN_PROGRESS" | "DETECTION_FAILED" | "DETECTION_COMPLETE" | (string & {});
export declare const StackDriftDetectionStatus: any;
export type StackDriftDetectionStatusReason = string;
export type BoxedInteger = number;
export interface DescribeStackDriftDetectionStatusOutput {
    StackId: string;
    StackDriftDetectionId: string;
    StackDriftStatus?: StackDriftStatus;
    DetectionStatus: StackDriftDetectionStatus;
    DetectionStatusReason?: string;
    DriftedStackResourceCount?: number;
    Timestamp: Date;
}
export declare const DescribeStackDriftDetectionStatusOutput: S.Schema<DescribeStackDriftDetectionStatusOutput>;
export interface DescribeStackEventsInput {
    StackName?: string;
    NextToken?: string;
}
export declare const DescribeStackEventsInput: S.Schema<DescribeStackEventsInput>;
export type HookInvocationId = string;
export interface StackEvent {
    StackId?: string;
    EventId?: string;
    StackName?: string;
    OperationId?: string;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    ResourceType?: string;
    Timestamp?: Date;
    ResourceStatus?: ResourceStatus;
    ResourceStatusReason?: string;
    ResourceProperties?: string;
    ClientRequestToken?: string;
    HookType?: string;
    HookStatus?: HookStatus;
    HookStatusReason?: string;
    HookInvocationPoint?: HookInvocationPoint;
    HookInvocationId?: string;
    HookFailureMode?: HookFailureMode;
    DetailedStatus?: DetailedStatus;
}
export declare const StackEvent: S.Schema<StackEvent>;
export type StackEvents = StackEvent[];
export declare const StackEvents: any;
export interface DescribeStackEventsOutput {
    StackEvents?: (StackEvent & {
        StackId: StackId;
        EventId: EventId;
        StackName: StackName;
        Timestamp: Date;
    })[];
    NextToken?: string;
}
export declare const DescribeStackEventsOutput: S.Schema<DescribeStackEventsOutput>;
export interface DescribeStackInstanceInput {
    StackSetName?: string;
    StackInstanceAccount?: string;
    StackInstanceRegion?: string;
    CallAs?: CallAs;
}
export declare const DescribeStackInstanceInput: S.Schema<DescribeStackInstanceInput>;
export type StackInstanceStatus = "CURRENT" | "OUTDATED" | "INOPERABLE" | (string & {});
export declare const StackInstanceStatus: any;
export type StackInstanceDetailedStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLED" | "INOPERABLE" | "SKIPPED_SUSPENDED_ACCOUNT" | "FAILED_IMPORT" | (string & {});
export declare const StackInstanceDetailedStatus: any;
export interface StackInstanceComprehensiveStatus {
    DetailedStatus?: StackInstanceDetailedStatus;
}
export declare const StackInstanceComprehensiveStatus: S.Schema<StackInstanceComprehensiveStatus>;
export type Reason = string;
export interface StackInstance {
    StackSetId?: string;
    Region?: string;
    Account?: string;
    StackId?: string;
    ParameterOverrides?: Parameter[];
    Status?: StackInstanceStatus;
    StackInstanceStatus?: StackInstanceComprehensiveStatus;
    StatusReason?: string;
    OrganizationalUnitId?: string;
    DriftStatus?: StackDriftStatus;
    LastDriftCheckTimestamp?: Date;
    LastOperationId?: string;
}
export declare const StackInstance: S.Schema<StackInstance>;
export interface DescribeStackInstanceOutput {
    StackInstance?: StackInstance;
}
export declare const DescribeStackInstanceOutput: S.Schema<DescribeStackInstanceOutput>;
export interface DescribeStackRefactorInput {
    StackRefactorId?: string;
}
export declare const DescribeStackRefactorInput: S.Schema<DescribeStackRefactorInput>;
export type StackIds = string[];
export declare const StackIds: any;
export type StackRefactorExecutionStatus = "UNAVAILABLE" | "AVAILABLE" | "OBSOLETE" | "EXECUTE_IN_PROGRESS" | "EXECUTE_COMPLETE" | "EXECUTE_FAILED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_COMPLETE" | "ROLLBACK_FAILED" | (string & {});
export declare const StackRefactorExecutionStatus: any;
export type ExecutionStatusReason = string;
export type StackRefactorStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | (string & {});
export declare const StackRefactorStatus: any;
export type StackRefactorStatusReason = string;
export interface DescribeStackRefactorOutput {
    Description?: string;
    StackRefactorId?: string;
    StackIds?: string[];
    ExecutionStatus?: StackRefactorExecutionStatus;
    ExecutionStatusReason?: string;
    Status?: StackRefactorStatus;
    StatusReason?: string;
}
export declare const DescribeStackRefactorOutput: S.Schema<DescribeStackRefactorOutput>;
export interface DescribeStackResourceInput {
    StackName?: string;
    LogicalResourceId?: string;
}
export declare const DescribeStackResourceInput: S.Schema<DescribeStackResourceInput>;
export type Metadata = string;
export interface StackResourceDriftInformation {
    StackResourceDriftStatus?: StackResourceDriftStatus;
    LastCheckTimestamp?: Date;
}
export declare const StackResourceDriftInformation: S.Schema<StackResourceDriftInformation>;
export interface StackResourceDetail {
    StackName?: string;
    StackId?: string;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    ResourceType?: string;
    LastUpdatedTimestamp?: Date;
    ResourceStatus?: ResourceStatus;
    ResourceStatusReason?: string;
    Description?: string;
    Metadata?: string;
    DriftInformation?: StackResourceDriftInformation;
    ModuleInfo?: ModuleInfo;
}
export declare const StackResourceDetail: S.Schema<StackResourceDetail>;
export interface DescribeStackResourceOutput {
    StackResourceDetail?: StackResourceDetail & {
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        LastUpdatedTimestamp: Date;
        ResourceStatus: ResourceStatus;
        DriftInformation: StackResourceDriftInformation & {
            StackResourceDriftStatus: StackResourceDriftStatus;
        };
    };
}
export declare const DescribeStackResourceOutput: S.Schema<DescribeStackResourceOutput>;
export type StackResourceDriftStatusFilters = StackResourceDriftStatus[];
export declare const StackResourceDriftStatusFilters: any;
export type BoxedMaxResults = number;
export interface DescribeStackResourceDriftsInput {
    StackName?: string;
    StackResourceDriftStatusFilters?: StackResourceDriftStatus[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeStackResourceDriftsInput: S.Schema<DescribeStackResourceDriftsInput>;
export type Key = string;
export type Value = string;
export interface PhysicalResourceIdContextKeyValuePair {
    Key?: string;
    Value?: string;
}
export declare const PhysicalResourceIdContextKeyValuePair: S.Schema<PhysicalResourceIdContextKeyValuePair>;
export type PhysicalResourceIdContext = PhysicalResourceIdContextKeyValuePair[];
export declare const PhysicalResourceIdContext: any;
export type Properties = string;
export type PropertyValue = string;
export type DifferenceType = "ADD" | "REMOVE" | "NOT_EQUAL" | (string & {});
export declare const DifferenceType: any;
export interface PropertyDifference {
    PropertyPath?: string;
    ExpectedValue?: string;
    ActualValue?: string;
    DifferenceType?: DifferenceType;
}
export declare const PropertyDifference: S.Schema<PropertyDifference>;
export type PropertyDifferences = PropertyDifference[];
export declare const PropertyDifferences: any;
export type StackResourceDriftStatusReason = string;
export interface StackResourceDrift {
    StackId?: string;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    PhysicalResourceIdContext?: PhysicalResourceIdContextKeyValuePair[];
    ResourceType?: string;
    ExpectedProperties?: string;
    ActualProperties?: string;
    PropertyDifferences?: PropertyDifference[];
    StackResourceDriftStatus?: StackResourceDriftStatus;
    Timestamp?: Date;
    ModuleInfo?: ModuleInfo;
    DriftStatusReason?: string;
}
export declare const StackResourceDrift: S.Schema<StackResourceDrift>;
export type StackResourceDrifts = StackResourceDrift[];
export declare const StackResourceDrifts: any;
export interface DescribeStackResourceDriftsOutput {
    StackResourceDrifts: (StackResourceDrift & {
        StackId: StackId;
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        StackResourceDriftStatus: StackResourceDriftStatus;
        Timestamp: Date;
        PhysicalResourceIdContext: (PhysicalResourceIdContextKeyValuePair & {
            Key: Key;
            Value: Value;
        })[];
        PropertyDifferences: (PropertyDifference & {
            PropertyPath: PropertyPath;
            ExpectedValue: PropertyValue;
            ActualValue: PropertyValue;
            DifferenceType: DifferenceType;
        })[];
    })[];
    NextToken?: string;
}
export declare const DescribeStackResourceDriftsOutput: S.Schema<DescribeStackResourceDriftsOutput>;
export interface DescribeStackResourcesInput {
    StackName?: string;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
}
export declare const DescribeStackResourcesInput: S.Schema<DescribeStackResourcesInput>;
export interface StackResource {
    StackName?: string;
    StackId?: string;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    ResourceType?: string;
    Timestamp?: Date;
    ResourceStatus?: ResourceStatus;
    ResourceStatusReason?: string;
    Description?: string;
    DriftInformation?: StackResourceDriftInformation;
    ModuleInfo?: ModuleInfo;
}
export declare const StackResource: S.Schema<StackResource>;
export type StackResources = StackResource[];
export declare const StackResources: any;
export interface DescribeStackResourcesOutput {
    StackResources?: (StackResource & {
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        Timestamp: Date;
        ResourceStatus: ResourceStatus;
        DriftInformation: StackResourceDriftInformation & {
            StackResourceDriftStatus: StackResourceDriftStatus;
        };
    })[];
}
export declare const DescribeStackResourcesOutput: S.Schema<DescribeStackResourcesOutput>;
export interface DescribeStacksInput {
    StackName?: string;
    NextToken?: string;
}
export declare const DescribeStacksInput: S.Schema<DescribeStacksInput>;
export type DeletionTime = Date;
export type StackStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "CREATE_COMPLETE" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_FAILED" | "ROLLBACK_COMPLETE" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "DELETE_COMPLETE" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE_CLEANUP_IN_PROGRESS" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | "UPDATE_ROLLBACK_IN_PROGRESS" | "UPDATE_ROLLBACK_FAILED" | "UPDATE_ROLLBACK_COMPLETE_CLEANUP_IN_PROGRESS" | "UPDATE_ROLLBACK_COMPLETE" | "REVIEW_IN_PROGRESS" | "IMPORT_IN_PROGRESS" | "IMPORT_COMPLETE" | "IMPORT_ROLLBACK_IN_PROGRESS" | "IMPORT_ROLLBACK_FAILED" | "IMPORT_ROLLBACK_COMPLETE" | (string & {});
export declare const StackStatus: any;
export type StackStatusReason = string;
export type OutputKey = string;
export type OutputValue = string;
export type ExportName = string;
export interface Output {
    OutputKey?: string;
    OutputValue?: string;
    Description?: string;
    ExportName?: string;
}
export declare const Output: S.Schema<Output>;
export type Outputs = Output[];
export declare const Outputs: any;
export interface StackDriftInformation {
    StackDriftStatus?: StackDriftStatus;
    LastCheckTimestamp?: Date;
}
export declare const StackDriftInformation: S.Schema<StackDriftInformation>;
export interface OperationEntry {
    OperationType?: OperationType;
    OperationId?: string;
}
export declare const OperationEntry: S.Schema<OperationEntry>;
export type LastOperations = OperationEntry[];
export declare const LastOperations: any;
export interface Stack {
    StackId?: string;
    StackName?: string;
    ChangeSetId?: string;
    Description?: string;
    Parameters?: Parameter[];
    CreationTime?: Date;
    DeletionTime?: Date;
    LastUpdatedTime?: Date;
    RollbackConfiguration?: RollbackConfiguration;
    StackStatus?: StackStatus;
    StackStatusReason?: string;
    DisableRollback?: boolean;
    DeploymentConfig?: DeploymentConfig;
    NotificationARNs?: string[];
    TimeoutInMinutes?: number;
    Capabilities?: Capability[];
    Outputs?: Output[];
    RoleARN?: string;
    Tags?: Tag[];
    EnableTerminationProtection?: boolean;
    ParentId?: string;
    RootId?: string;
    DriftInformation?: StackDriftInformation;
    RetainExceptOnCreate?: boolean;
    DeletionMode?: DeletionMode;
    DetailedStatus?: DetailedStatus;
    LastOperations?: OperationEntry[];
}
export declare const Stack: S.Schema<Stack>;
export type Stacks = Stack[];
export declare const Stacks: any;
export interface DescribeStacksOutput {
    Stacks?: (Stack & {
        StackName: StackName;
        CreationTime: CreationTime;
        StackStatus: StackStatus;
        RollbackConfiguration: RollbackConfiguration & {
            RollbackTriggers: (RollbackTrigger & {
                Arn: Arn;
                Type: Type;
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        DriftInformation: StackDriftInformation & {
            StackDriftStatus: StackDriftStatus;
        };
    })[];
    NextToken?: string;
}
export declare const DescribeStacksOutput: S.Schema<DescribeStacksOutput>;
export interface DescribeStackSetInput {
    StackSetName?: string;
    CallAs?: CallAs;
}
export declare const DescribeStackSetInput: S.Schema<DescribeStackSetInput>;
export type StackSetStatus = "ACTIVE" | "DELETED" | (string & {});
export declare const StackSetStatus: any;
export type StackSetDriftStatus = "DRIFTED" | "IN_SYNC" | "NOT_CHECKED" | (string & {});
export declare const StackSetDriftStatus: any;
export type StackSetDriftDetectionStatus = "COMPLETED" | "FAILED" | "PARTIAL_SUCCESS" | "IN_PROGRESS" | "STOPPED" | (string & {});
export declare const StackSetDriftDetectionStatus: any;
export type TotalStackInstancesCount = number;
export type DriftedStackInstancesCount = number;
export type InSyncStackInstancesCount = number;
export type InProgressStackInstancesCount = number;
export type FailedStackInstancesCount = number;
export interface StackSetDriftDetectionDetails {
    DriftStatus?: StackSetDriftStatus;
    DriftDetectionStatus?: StackSetDriftDetectionStatus;
    LastDriftCheckTimestamp?: Date;
    TotalStackInstancesCount?: number;
    DriftedStackInstancesCount?: number;
    InSyncStackInstancesCount?: number;
    InProgressStackInstancesCount?: number;
    FailedStackInstancesCount?: number;
}
export declare const StackSetDriftDetectionDetails: S.Schema<StackSetDriftDetectionDetails>;
export interface StackSet {
    StackSetName?: string;
    StackSetId?: string;
    Description?: string;
    Status?: StackSetStatus;
    TemplateBody?: string;
    Parameters?: Parameter[];
    Capabilities?: Capability[];
    Tags?: Tag[];
    StackSetARN?: string;
    AdministrationRoleARN?: string;
    ExecutionRoleName?: string;
    StackSetDriftDetectionDetails?: StackSetDriftDetectionDetails;
    AutoDeployment?: AutoDeployment;
    PermissionModel?: PermissionModels;
    OrganizationalUnitIds?: string[];
    ManagedExecution?: ManagedExecution;
    Regions?: string[];
}
export declare const StackSet: S.Schema<StackSet>;
export interface DescribeStackSetOutput {
    StackSet?: StackSet & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    };
}
export declare const DescribeStackSetOutput: S.Schema<DescribeStackSetOutput>;
export interface DescribeStackSetOperationInput {
    StackSetName?: string;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const DescribeStackSetOperationInput: S.Schema<DescribeStackSetOperationInput>;
export type StackSetOperationAction = "CREATE" | "UPDATE" | "DELETE" | "DETECT_DRIFT" | (string & {});
export declare const StackSetOperationAction: any;
export type StackSetOperationStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "STOPPING" | "STOPPED" | "QUEUED" | (string & {});
export declare const StackSetOperationStatus: any;
export type RetainStacksNullable = boolean;
export type StackSetOperationStatusReason = string;
export interface StackSetOperationStatusDetails {
    FailedStackInstancesCount?: number;
}
export declare const StackSetOperationStatusDetails: S.Schema<StackSetOperationStatusDetails>;
export interface StackSetOperation {
    OperationId?: string;
    StackSetId?: string;
    Action?: StackSetOperationAction;
    Status?: StackSetOperationStatus;
    OperationPreferences?: StackSetOperationPreferences;
    RetainStacks?: boolean;
    AdministrationRoleARN?: string;
    ExecutionRoleName?: string;
    CreationTimestamp?: Date;
    EndTimestamp?: Date;
    DeploymentTargets?: DeploymentTargets;
    StackSetDriftDetectionDetails?: StackSetDriftDetectionDetails;
    StatusReason?: string;
    StatusDetails?: StackSetOperationStatusDetails;
}
export declare const StackSetOperation: S.Schema<StackSetOperation>;
export interface DescribeStackSetOperationOutput {
    StackSetOperation?: StackSetOperation;
}
export declare const DescribeStackSetOperationOutput: S.Schema<DescribeStackSetOperationOutput>;
export type PublicVersionNumber = string;
export interface DescribeTypeInput {
    Type?: RegistryType;
    TypeName?: string;
    Arn?: string;
    VersionId?: string;
    PublisherId?: string;
    PublicVersionNumber?: string;
}
export declare const DescribeTypeInput: S.Schema<DescribeTypeInput>;
export type IsDefaultVersion = boolean;
export type TypeTestsStatus = "PASSED" | "FAILED" | "IN_PROGRESS" | "NOT_TESTED" | (string & {});
export declare const TypeTestsStatus: any;
export type TypeTestsStatusDescription = string;
export type TypeSchema = string;
export type ProvisioningType = "NON_PROVISIONABLE" | "IMMUTABLE" | "FULLY_MUTABLE" | (string & {});
export declare const ProvisioningType: any;
export type DeprecatedStatus = "LIVE" | "DEPRECATED" | (string & {});
export declare const DeprecatedStatus: any;
export type SupportedMajorVersion = number;
export type SupportedMajorVersions = number[];
export declare const SupportedMajorVersions: any;
export interface RequiredActivatedType {
    TypeNameAlias?: string;
    OriginalTypeName?: string;
    PublisherId?: string;
    SupportedMajorVersions?: number[];
}
export declare const RequiredActivatedType: S.Schema<RequiredActivatedType>;
export type RequiredActivatedTypes = RequiredActivatedType[];
export declare const RequiredActivatedTypes: any;
export type Visibility = "PUBLIC" | "PRIVATE" | (string & {});
export declare const Visibility: any;
export type OptionalSecureUrl = string;
export type ConfigurationSchema = string;
export type IsActivated = boolean;
export interface DescribeTypeOutput {
    Arn?: string;
    Type?: RegistryType;
    TypeName?: string;
    DefaultVersionId?: string;
    IsDefaultVersion?: boolean;
    TypeTestsStatus?: TypeTestsStatus;
    TypeTestsStatusDescription?: string;
    Description?: string;
    Schema?: string;
    ProvisioningType?: ProvisioningType;
    DeprecatedStatus?: DeprecatedStatus;
    LoggingConfig?: LoggingConfig & {
        LogRoleArn: RoleARN2;
        LogGroupName: LogGroupName;
    };
    RequiredActivatedTypes?: RequiredActivatedType[];
    ExecutionRoleArn?: string;
    Visibility?: Visibility;
    SourceUrl?: string;
    DocumentationUrl?: string;
    LastUpdated?: Date;
    TimeCreated?: Date;
    ConfigurationSchema?: string;
    PublisherId?: string;
    OriginalTypeName?: string;
    OriginalTypeArn?: string;
    PublicVersionNumber?: string;
    LatestPublicVersion?: string;
    IsActivated?: boolean;
    AutoUpdate?: boolean;
}
export declare const DescribeTypeOutput: S.Schema<DescribeTypeOutput>;
export type RegistrationToken = string;
export interface DescribeTypeRegistrationInput {
    RegistrationToken?: string;
}
export declare const DescribeTypeRegistrationInput: S.Schema<DescribeTypeRegistrationInput>;
export type RegistrationStatus = "COMPLETE" | "IN_PROGRESS" | "FAILED" | (string & {});
export declare const RegistrationStatus: any;
export interface DescribeTypeRegistrationOutput {
    ProgressStatus?: RegistrationStatus;
    Description?: string;
    TypeArn?: string;
    TypeVersionArn?: string;
}
export declare const DescribeTypeRegistrationOutput: S.Schema<DescribeTypeRegistrationOutput>;
export type LogicalResourceIds = string[];
export declare const LogicalResourceIds: any;
export interface DetectStackDriftInput {
    StackName?: string;
    LogicalResourceIds?: string[];
}
export declare const DetectStackDriftInput: S.Schema<DetectStackDriftInput>;
export interface DetectStackDriftOutput {
    StackDriftDetectionId: string;
}
export declare const DetectStackDriftOutput: S.Schema<DetectStackDriftOutput>;
export interface DetectStackResourceDriftInput {
    StackName?: string;
    LogicalResourceId?: string;
}
export declare const DetectStackResourceDriftInput: S.Schema<DetectStackResourceDriftInput>;
export interface DetectStackResourceDriftOutput {
    StackResourceDrift: StackResourceDrift & {
        StackId: StackId;
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        StackResourceDriftStatus: StackResourceDriftStatus;
        Timestamp: Date;
        PhysicalResourceIdContext: (PhysicalResourceIdContextKeyValuePair & {
            Key: Key;
            Value: Value;
        })[];
        PropertyDifferences: (PropertyDifference & {
            PropertyPath: PropertyPath;
            ExpectedValue: PropertyValue;
            ActualValue: PropertyValue;
            DifferenceType: DifferenceType;
        })[];
    };
}
export declare const DetectStackResourceDriftOutput: S.Schema<DetectStackResourceDriftOutput>;
export type StackSetNameOrId = string;
export interface DetectStackSetDriftInput {
    StackSetName?: string;
    OperationPreferences?: StackSetOperationPreferences;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const DetectStackSetDriftInput: S.Schema<DetectStackSetDriftInput>;
export interface DetectStackSetDriftOutput {
    OperationId?: string;
}
export declare const DetectStackSetDriftOutput: S.Schema<DetectStackSetDriftOutput>;
export interface EstimateTemplateCostInput {
    TemplateBody?: string;
    TemplateURL?: string;
    Parameters?: Parameter[];
}
export declare const EstimateTemplateCostInput: S.Schema<EstimateTemplateCostInput>;
export type Url = string;
export interface EstimateTemplateCostOutput {
    Url?: string;
}
export declare const EstimateTemplateCostOutput: S.Schema<EstimateTemplateCostOutput>;
export interface ExecuteChangeSetInput {
    ChangeSetName?: string;
    StackName?: string;
    ClientRequestToken?: string;
    DisableRollback?: boolean;
    RetainExceptOnCreate?: boolean;
}
export declare const ExecuteChangeSetInput: S.Schema<ExecuteChangeSetInput>;
export interface ExecuteChangeSetOutput {
}
export declare const ExecuteChangeSetOutput: S.Schema<ExecuteChangeSetOutput>;
export interface ExecuteStackRefactorInput {
    StackRefactorId?: string;
}
export declare const ExecuteStackRefactorInput: S.Schema<ExecuteStackRefactorInput>;
export interface ExecuteStackRefactorResponse {
}
export declare const ExecuteStackRefactorResponse: S.Schema<ExecuteStackRefactorResponse>;
export type TemplateFormat = "JSON" | "YAML" | (string & {});
export declare const TemplateFormat: any;
export interface GetGeneratedTemplateInput {
    Format?: TemplateFormat;
    GeneratedTemplateName?: string;
}
export declare const GetGeneratedTemplateInput: S.Schema<GetGeneratedTemplateInput>;
export interface GetGeneratedTemplateOutput {
    Status?: GeneratedTemplateStatus;
    TemplateBody?: string;
}
export declare const GetGeneratedTemplateOutput: S.Schema<GetGeneratedTemplateOutput>;
export interface GetHookResultInput {
    HookResultId?: string;
}
export declare const GetHookResultInput: S.Schema<GetHookResultInput>;
export type HookTypeArn = string;
export type HookTargetId = string;
export type HookTargetAction = "CREATE" | "UPDATE" | "DELETE" | "IMPORT" | (string & {});
export declare const HookTargetAction: any;
export interface HookTarget {
    TargetType?: HookTargetType;
    TargetTypeName?: string;
    TargetId?: string;
    Action?: HookTargetAction;
}
export declare const HookTarget: S.Schema<HookTarget>;
export type AnnotationName = string;
export type AnnotationStatus = "PASSED" | "FAILED" | "SKIPPED" | (string & {});
export declare const AnnotationStatus: any;
export type RemediationMessageStatusMessage = string;
export type RemediationMessageRemediationMessage = string;
export type AnnotationRemediationLink = string;
export type AnnotationSeverityLevel = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export declare const AnnotationSeverityLevel: any;
export interface Annotation {
    AnnotationName?: string;
    Status?: AnnotationStatus;
    StatusMessage?: string;
    RemediationMessage?: string;
    RemediationLink?: string;
    SeverityLevel?: AnnotationSeverityLevel;
}
export declare const Annotation: S.Schema<Annotation>;
export type AnnotationList = Annotation[];
export declare const AnnotationList: any;
export interface GetHookResultOutput {
    HookResultId?: string;
    InvocationPoint?: HookInvocationPoint;
    FailureMode?: HookFailureMode;
    TypeName?: string;
    OriginalTypeName?: string;
    TypeVersionId?: string;
    TypeConfigurationVersionId?: string;
    TypeArn?: string;
    Status?: HookStatus;
    HookStatusReason?: string;
    InvokedAt?: Date;
    Target?: HookTarget & {
        TargetType: HookTargetType;
        TargetTypeName: HookTargetTypeName;
        TargetId: HookTargetId;
        Action: HookTargetAction;
    };
    Annotations?: Annotation[];
}
export declare const GetHookResultOutput: S.Schema<GetHookResultOutput>;
export interface GetStackPolicyInput {
    StackName?: string;
}
export declare const GetStackPolicyInput: S.Schema<GetStackPolicyInput>;
export interface GetStackPolicyOutput {
    StackPolicyBody?: string;
}
export declare const GetStackPolicyOutput: S.Schema<GetStackPolicyOutput>;
export type TemplateStage = "Original" | "Processed" | (string & {});
export declare const TemplateStage: any;
export interface GetTemplateInput {
    StackName?: string;
    ChangeSetName?: string;
    TemplateStage?: TemplateStage;
}
export declare const GetTemplateInput: S.Schema<GetTemplateInput>;
export type StageList = TemplateStage[];
export declare const StageList: any;
export interface GetTemplateOutput {
    TemplateBody?: string;
    StagesAvailable?: TemplateStage[];
}
export declare const GetTemplateOutput: S.Schema<GetTemplateOutput>;
export type TreatUnrecognizedResourceTypesAsWarnings = boolean;
export interface TemplateSummaryConfig {
    TreatUnrecognizedResourceTypesAsWarnings?: boolean;
}
export declare const TemplateSummaryConfig: S.Schema<TemplateSummaryConfig>;
export interface GetTemplateSummaryInput {
    TemplateBody?: string;
    TemplateURL?: string;
    StackName?: string;
    StackSetName?: string;
    CallAs?: CallAs;
    TemplateSummaryConfig?: TemplateSummaryConfig;
}
export declare const GetTemplateSummaryInput: S.Schema<GetTemplateSummaryInput>;
export type ParameterType = string;
export type NoEcho = boolean;
export type AllowedValue = string;
export type AllowedValues = string[];
export declare const AllowedValues: any;
export interface ParameterConstraints {
    AllowedValues?: string[];
}
export declare const ParameterConstraints: S.Schema<ParameterConstraints>;
export interface ParameterDeclaration {
    ParameterKey?: string;
    DefaultValue?: string;
    ParameterType?: string;
    NoEcho?: boolean;
    Description?: string;
    ParameterConstraints?: ParameterConstraints;
}
export declare const ParameterDeclaration: S.Schema<ParameterDeclaration>;
export type ParameterDeclarations = ParameterDeclaration[];
export declare const ParameterDeclarations: any;
export type CapabilitiesReason = string;
export type Version = string;
export type TransformName = string;
export type TransformsList = string[];
export declare const TransformsList: any;
export type ResourceIdentifiers = string[];
export declare const ResourceIdentifiers: any;
export interface ResourceIdentifierSummary {
    ResourceType?: string;
    LogicalResourceIds?: string[];
    ResourceIdentifiers?: string[];
}
export declare const ResourceIdentifierSummary: S.Schema<ResourceIdentifierSummary>;
export type ResourceIdentifierSummaries = ResourceIdentifierSummary[];
export declare const ResourceIdentifierSummaries: any;
export interface Warnings {
    UnrecognizedResourceTypes?: string[];
}
export declare const Warnings: S.Schema<Warnings>;
export interface GetTemplateSummaryOutput {
    Parameters?: ParameterDeclaration[];
    Description?: string;
    Capabilities?: Capability[];
    CapabilitiesReason?: string;
    ResourceTypes?: string[];
    Version?: string;
    Metadata?: string;
    DeclaredTransforms?: string[];
    ResourceIdentifierSummaries?: ResourceIdentifierSummary[];
    Warnings?: Warnings;
}
export declare const GetTemplateSummaryOutput: S.Schema<GetTemplateSummaryOutput>;
export type StackIdList = string[];
export declare const StackIdList: any;
export type StackIdsUrl = string;
export interface ImportStacksToStackSetInput {
    StackSetName?: string;
    StackIds?: string[];
    StackIdsUrl?: string;
    OrganizationalUnitIds?: string[];
    OperationPreferences?: StackSetOperationPreferences;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const ImportStacksToStackSetInput: S.Schema<ImportStacksToStackSetInput>;
export interface ImportStacksToStackSetOutput {
    OperationId?: string;
}
export declare const ImportStacksToStackSetOutput: S.Schema<ImportStacksToStackSetOutput>;
export interface ListChangeSetsInput {
    StackName?: string;
    NextToken?: string;
}
export declare const ListChangeSetsInput: S.Schema<ListChangeSetsInput>;
export interface ChangeSetSummary {
    StackId?: string;
    StackName?: string;
    ChangeSetId?: string;
    ChangeSetName?: string;
    ExecutionStatus?: ExecutionStatus;
    Status?: ChangeSetStatus;
    StatusReason?: string;
    CreationTime?: Date;
    Description?: string;
    IncludeNestedStacks?: boolean;
    ParentChangeSetId?: string;
    RootChangeSetId?: string;
    ImportExistingResources?: boolean;
}
export declare const ChangeSetSummary: S.Schema<ChangeSetSummary>;
export type ChangeSetSummaries = ChangeSetSummary[];
export declare const ChangeSetSummaries: any;
export interface ListChangeSetsOutput {
    Summaries?: ChangeSetSummary[];
    NextToken?: string;
}
export declare const ListChangeSetsOutput: S.Schema<ListChangeSetsOutput>;
export interface ListExportsInput {
    NextToken?: string;
}
export declare const ListExportsInput: S.Schema<ListExportsInput>;
export type ExportValue = string;
export interface Export {
    ExportingStackId?: string;
    Name?: string;
    Value?: string;
}
export declare const Export: S.Schema<Export>;
export type Exports = Export[];
export declare const Exports: any;
export interface ListExportsOutput {
    Exports?: Export[];
    NextToken?: string;
}
export declare const ListExportsOutput: S.Schema<ListExportsOutput>;
export type MaxResults = number;
export interface ListGeneratedTemplatesInput {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListGeneratedTemplatesInput: S.Schema<ListGeneratedTemplatesInput>;
export type NumberOfResources = number;
export interface TemplateSummary {
    GeneratedTemplateId?: string;
    GeneratedTemplateName?: string;
    Status?: GeneratedTemplateStatus;
    StatusReason?: string;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
    NumberOfResources?: number;
}
export declare const TemplateSummary: S.Schema<TemplateSummary>;
export type TemplateSummaries = TemplateSummary[];
export declare const TemplateSummaries: any;
export interface ListGeneratedTemplatesOutput {
    Summaries?: TemplateSummary[];
    NextToken?: string;
}
export declare const ListGeneratedTemplatesOutput: S.Schema<ListGeneratedTemplatesOutput>;
export type ListHookResultsTargetType = "CHANGE_SET" | "STACK" | "RESOURCE" | "CLOUD_CONTROL" | (string & {});
export declare const ListHookResultsTargetType: any;
export type HookResultId = string;
export interface ListHookResultsInput {
    TargetType?: ListHookResultsTargetType;
    TargetId?: string;
    TypeArn?: string;
    Status?: HookStatus;
    NextToken?: string;
}
export declare const ListHookResultsInput: S.Schema<ListHookResultsInput>;
export interface HookResultSummary {
    HookResultId?: string;
    InvocationPoint?: HookInvocationPoint;
    FailureMode?: HookFailureMode;
    TypeName?: string;
    TypeVersionId?: string;
    TypeConfigurationVersionId?: string;
    Status?: HookStatus;
    HookStatusReason?: string;
    InvokedAt?: Date;
    TargetType?: ListHookResultsTargetType;
    TargetId?: string;
    TypeArn?: string;
    HookExecutionTarget?: string;
}
export declare const HookResultSummary: S.Schema<HookResultSummary>;
export type HookResultSummaries = HookResultSummary[];
export declare const HookResultSummaries: any;
export interface ListHookResultsOutput {
    TargetType?: ListHookResultsTargetType;
    TargetId?: string;
    HookResults?: HookResultSummary[];
    NextToken?: string;
}
export declare const ListHookResultsOutput: S.Schema<ListHookResultsOutput>;
export interface ListImportsInput {
    ExportName?: string;
    NextToken?: string;
}
export declare const ListImportsInput: S.Schema<ListImportsInput>;
export type Imports = string[];
export declare const Imports: any;
export interface ListImportsOutput {
    Imports?: string[];
    NextToken?: string;
}
export declare const ListImportsOutput: S.Schema<ListImportsOutput>;
export type JazzResourceIdentifierPropertyKey = string;
export type JazzResourceIdentifierPropertyValue = string;
export type JazzResourceIdentifierProperties = {
    [key: string]: string | undefined;
};
export declare const JazzResourceIdentifierProperties: any;
export interface ScannedResourceIdentifier {
    ResourceType?: string;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    };
}
export declare const ScannedResourceIdentifier: S.Schema<ScannedResourceIdentifier>;
export type ScannedResourceIdentifiers = ScannedResourceIdentifier[];
export declare const ScannedResourceIdentifiers: any;
export interface ListResourceScanRelatedResourcesInput {
    ResourceScanId?: string;
    Resources?: ScannedResourceIdentifier[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListResourceScanRelatedResourcesInput: S.Schema<ListResourceScanRelatedResourcesInput>;
export type ManagedByStack = boolean;
export interface ScannedResource {
    ResourceType?: string;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    };
    ManagedByStack?: boolean;
}
export declare const ScannedResource: S.Schema<ScannedResource>;
export type RelatedResources = ScannedResource[];
export declare const RelatedResources: any;
export interface ListResourceScanRelatedResourcesOutput {
    RelatedResources?: ScannedResource[];
    NextToken?: string;
}
export declare const ListResourceScanRelatedResourcesOutput: S.Schema<ListResourceScanRelatedResourcesOutput>;
export type ResourceIdentifier = string;
export type ResourceTypePrefix = string;
export type ResourceScannerMaxResults = number;
export interface ListResourceScanResourcesInput {
    ResourceScanId?: string;
    ResourceIdentifier?: string;
    ResourceTypePrefix?: string;
    TagKey?: string;
    TagValue?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListResourceScanResourcesInput: S.Schema<ListResourceScanResourcesInput>;
export type ScannedResources = ScannedResource[];
export declare const ScannedResources: any;
export interface ListResourceScanResourcesOutput {
    Resources?: ScannedResource[];
    NextToken?: string;
}
export declare const ListResourceScanResourcesOutput: S.Schema<ListResourceScanResourcesOutput>;
export type ScanType = "FULL" | "PARTIAL" | (string & {});
export declare const ScanType: any;
export interface ListResourceScansInput {
    NextToken?: string;
    MaxResults?: number;
    ScanTypeFilter?: ScanType;
}
export declare const ListResourceScansInput: S.Schema<ListResourceScansInput>;
export interface ResourceScanSummary {
    ResourceScanId?: string;
    Status?: ResourceScanStatus;
    StatusReason?: string;
    StartTime?: Date;
    EndTime?: Date;
    PercentageCompleted?: number;
    ScanType?: ScanType;
}
export declare const ResourceScanSummary: S.Schema<ResourceScanSummary>;
export type ResourceScanSummaries = ResourceScanSummary[];
export declare const ResourceScanSummaries: any;
export interface ListResourceScansOutput {
    ResourceScanSummaries?: ResourceScanSummary[];
    NextToken?: string;
}
export declare const ListResourceScansOutput: S.Schema<ListResourceScansOutput>;
export interface ListStackInstanceResourceDriftsInput {
    StackSetName?: string;
    NextToken?: string;
    MaxResults?: number;
    StackInstanceResourceDriftStatuses?: StackResourceDriftStatus[];
    StackInstanceAccount?: string;
    StackInstanceRegion?: string;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const ListStackInstanceResourceDriftsInput: S.Schema<ListStackInstanceResourceDriftsInput>;
export interface StackInstanceResourceDriftsSummary {
    StackId?: string;
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    PhysicalResourceIdContext?: PhysicalResourceIdContextKeyValuePair[];
    ResourceType?: string;
    PropertyDifferences?: PropertyDifference[];
    StackResourceDriftStatus?: StackResourceDriftStatus;
    Timestamp?: Date;
}
export declare const StackInstanceResourceDriftsSummary: S.Schema<StackInstanceResourceDriftsSummary>;
export type StackInstanceResourceDriftsSummaries = StackInstanceResourceDriftsSummary[];
export declare const StackInstanceResourceDriftsSummaries: any;
export interface ListStackInstanceResourceDriftsOutput {
    Summaries?: (StackInstanceResourceDriftsSummary & {
        StackId: StackId;
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        StackResourceDriftStatus: StackResourceDriftStatus;
        Timestamp: Date;
        PhysicalResourceIdContext: (PhysicalResourceIdContextKeyValuePair & {
            Key: Key;
            Value: Value;
        })[];
        PropertyDifferences: (PropertyDifference & {
            PropertyPath: PropertyPath;
            ExpectedValue: PropertyValue;
            ActualValue: PropertyValue;
            DifferenceType: DifferenceType;
        })[];
    })[];
    NextToken?: string;
}
export declare const ListStackInstanceResourceDriftsOutput: S.Schema<ListStackInstanceResourceDriftsOutput>;
export type StackInstanceFilterName = "DETAILED_STATUS" | "LAST_OPERATION_ID" | "DRIFT_STATUS" | (string & {});
export declare const StackInstanceFilterName: any;
export type StackInstanceFilterValues = string;
export interface StackInstanceFilter {
    Name?: StackInstanceFilterName;
    Values?: string;
}
export declare const StackInstanceFilter: S.Schema<StackInstanceFilter>;
export type StackInstanceFilters = StackInstanceFilter[];
export declare const StackInstanceFilters: any;
export interface ListStackInstancesInput {
    StackSetName?: string;
    NextToken?: string;
    MaxResults?: number;
    Filters?: StackInstanceFilter[];
    StackInstanceAccount?: string;
    StackInstanceRegion?: string;
    CallAs?: CallAs;
}
export declare const ListStackInstancesInput: S.Schema<ListStackInstancesInput>;
export interface StackInstanceSummary {
    StackSetId?: string;
    Region?: string;
    Account?: string;
    StackId?: string;
    Status?: StackInstanceStatus;
    StatusReason?: string;
    StackInstanceStatus?: StackInstanceComprehensiveStatus;
    OrganizationalUnitId?: string;
    DriftStatus?: StackDriftStatus;
    LastDriftCheckTimestamp?: Date;
    LastOperationId?: string;
}
export declare const StackInstanceSummary: S.Schema<StackInstanceSummary>;
export type StackInstanceSummaries = StackInstanceSummary[];
export declare const StackInstanceSummaries: any;
export interface ListStackInstancesOutput {
    Summaries?: StackInstanceSummary[];
    NextToken?: string;
}
export declare const ListStackInstancesOutput: S.Schema<ListStackInstancesOutput>;
export interface ListStackRefactorActionsInput {
    StackRefactorId?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListStackRefactorActionsInput: S.Schema<ListStackRefactorActionsInput>;
export type StackRefactorActionType = "MOVE" | "CREATE" | (string & {});
export declare const StackRefactorActionType: any;
export type StackRefactorActionEntity = "RESOURCE" | "STACK" | (string & {});
export declare const StackRefactorActionEntity: any;
export type StackRefactorResourceIdentifier = string;
export type StackRefactorDetection = "AUTO" | "MANUAL" | (string & {});
export declare const StackRefactorDetection: any;
export type DetectionReason = string;
export type StackRefactorTagResources = Tag[];
export declare const StackRefactorTagResources: any;
export type StackRefactorUntagResources = string[];
export declare const StackRefactorUntagResources: any;
export interface StackRefactorAction {
    Action?: StackRefactorActionType;
    Entity?: StackRefactorActionEntity;
    PhysicalResourceId?: string;
    ResourceIdentifier?: string;
    Description?: string;
    Detection?: StackRefactorDetection;
    DetectionReason?: string;
    TagResources?: Tag[];
    UntagResources?: string[];
    ResourceMapping?: ResourceMapping;
}
export declare const StackRefactorAction: S.Schema<StackRefactorAction>;
export type StackRefactorActions = StackRefactorAction[];
export declare const StackRefactorActions: any;
export interface ListStackRefactorActionsOutput {
    StackRefactorActions: (StackRefactorAction & {
        TagResources: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        ResourceMapping: ResourceMapping & {
            Source: ResourceLocation & {
                StackName: StackName;
                LogicalResourceId: LogicalResourceId;
            };
            Destination: ResourceLocation & {
                StackName: StackName;
                LogicalResourceId: LogicalResourceId;
            };
        };
    })[];
    NextToken?: string;
}
export declare const ListStackRefactorActionsOutput: S.Schema<ListStackRefactorActionsOutput>;
export type StackRefactorExecutionStatusFilter = StackRefactorExecutionStatus[];
export declare const StackRefactorExecutionStatusFilter: any;
export interface ListStackRefactorsInput {
    ExecutionStatusFilter?: StackRefactorExecutionStatus[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListStackRefactorsInput: S.Schema<ListStackRefactorsInput>;
export interface StackRefactorSummary {
    StackRefactorId?: string;
    Description?: string;
    ExecutionStatus?: StackRefactorExecutionStatus;
    ExecutionStatusReason?: string;
    Status?: StackRefactorStatus;
    StatusReason?: string;
}
export declare const StackRefactorSummary: S.Schema<StackRefactorSummary>;
export type StackRefactorSummaries = StackRefactorSummary[];
export declare const StackRefactorSummaries: any;
export interface ListStackRefactorsOutput {
    StackRefactorSummaries: StackRefactorSummary[];
    NextToken?: string;
}
export declare const ListStackRefactorsOutput: S.Schema<ListStackRefactorsOutput>;
export interface ListStackResourcesInput {
    StackName?: string;
    NextToken?: string;
}
export declare const ListStackResourcesInput: S.Schema<ListStackResourcesInput>;
export interface StackResourceDriftInformationSummary {
    StackResourceDriftStatus?: StackResourceDriftStatus;
    LastCheckTimestamp?: Date;
}
export declare const StackResourceDriftInformationSummary: S.Schema<StackResourceDriftInformationSummary>;
export interface StackResourceSummary {
    LogicalResourceId?: string;
    PhysicalResourceId?: string;
    ResourceType?: string;
    LastUpdatedTimestamp?: Date;
    ResourceStatus?: ResourceStatus;
    ResourceStatusReason?: string;
    DriftInformation?: StackResourceDriftInformationSummary;
    ModuleInfo?: ModuleInfo;
}
export declare const StackResourceSummary: S.Schema<StackResourceSummary>;
export type StackResourceSummaries = StackResourceSummary[];
export declare const StackResourceSummaries: any;
export interface ListStackResourcesOutput {
    StackResourceSummaries?: (StackResourceSummary & {
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        LastUpdatedTimestamp: Date;
        ResourceStatus: ResourceStatus;
        DriftInformation: StackResourceDriftInformationSummary & {
            StackResourceDriftStatus: StackResourceDriftStatus;
        };
    })[];
    NextToken?: string;
}
export declare const ListStackResourcesOutput: S.Schema<ListStackResourcesOutput>;
export type StackStatusFilter = StackStatus[];
export declare const StackStatusFilter: any;
export interface ListStacksInput {
    NextToken?: string;
    StackStatusFilter?: StackStatus[];
}
export declare const ListStacksInput: S.Schema<ListStacksInput>;
export type TemplateDescription = string;
export interface StackDriftInformationSummary {
    StackDriftStatus?: StackDriftStatus;
    LastCheckTimestamp?: Date;
}
export declare const StackDriftInformationSummary: S.Schema<StackDriftInformationSummary>;
export interface StackSummary {
    StackId?: string;
    StackName?: string;
    TemplateDescription?: string;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
    DeletionTime?: Date;
    StackStatus?: StackStatus;
    StackStatusReason?: string;
    ParentId?: string;
    RootId?: string;
    DriftInformation?: StackDriftInformationSummary;
    LastOperations?: OperationEntry[];
}
export declare const StackSummary: S.Schema<StackSummary>;
export type StackSummaries = StackSummary[];
export declare const StackSummaries: any;
export interface ListStacksOutput {
    StackSummaries?: (StackSummary & {
        StackName: StackName;
        CreationTime: CreationTime;
        StackStatus: StackStatus;
        DriftInformation: StackDriftInformationSummary & {
            StackDriftStatus: StackDriftStatus;
        };
    })[];
    NextToken?: string;
}
export declare const ListStacksOutput: S.Schema<ListStacksOutput>;
export interface ListStackSetAutoDeploymentTargetsInput {
    StackSetName?: string;
    NextToken?: string;
    MaxResults?: number;
    CallAs?: CallAs;
}
export declare const ListStackSetAutoDeploymentTargetsInput: S.Schema<ListStackSetAutoDeploymentTargetsInput>;
export interface StackSetAutoDeploymentTargetSummary {
    OrganizationalUnitId?: string;
    Regions?: string[];
}
export declare const StackSetAutoDeploymentTargetSummary: S.Schema<StackSetAutoDeploymentTargetSummary>;
export type StackSetAutoDeploymentTargetSummaries = StackSetAutoDeploymentTargetSummary[];
export declare const StackSetAutoDeploymentTargetSummaries: any;
export interface ListStackSetAutoDeploymentTargetsOutput {
    Summaries?: StackSetAutoDeploymentTargetSummary[];
    NextToken?: string;
}
export declare const ListStackSetAutoDeploymentTargetsOutput: S.Schema<ListStackSetAutoDeploymentTargetsOutput>;
export type OperationResultFilterName = "OPERATION_RESULT_STATUS" | (string & {});
export declare const OperationResultFilterName: any;
export type OperationResultFilterValues = string;
export interface OperationResultFilter {
    Name?: OperationResultFilterName;
    Values?: string;
}
export declare const OperationResultFilter: S.Schema<OperationResultFilter>;
export type OperationResultFilters = OperationResultFilter[];
export declare const OperationResultFilters: any;
export interface ListStackSetOperationResultsInput {
    StackSetName?: string;
    OperationId?: string;
    NextToken?: string;
    MaxResults?: number;
    CallAs?: CallAs;
    Filters?: OperationResultFilter[];
}
export declare const ListStackSetOperationResultsInput: S.Schema<ListStackSetOperationResultsInput>;
export type StackSetOperationResultStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLED" | (string & {});
export declare const StackSetOperationResultStatus: any;
export type AccountGateStatus = "SUCCEEDED" | "FAILED" | "SKIPPED" | (string & {});
export declare const AccountGateStatus: any;
export type AccountGateStatusReason = string;
export interface AccountGateResult {
    Status?: AccountGateStatus;
    StatusReason?: string;
}
export declare const AccountGateResult: S.Schema<AccountGateResult>;
export interface StackSetOperationResultSummary {
    Account?: string;
    Region?: string;
    Status?: StackSetOperationResultStatus;
    StatusReason?: string;
    AccountGateResult?: AccountGateResult;
    OrganizationalUnitId?: string;
}
export declare const StackSetOperationResultSummary: S.Schema<StackSetOperationResultSummary>;
export type StackSetOperationResultSummaries = StackSetOperationResultSummary[];
export declare const StackSetOperationResultSummaries: any;
export interface ListStackSetOperationResultsOutput {
    Summaries?: StackSetOperationResultSummary[];
    NextToken?: string;
}
export declare const ListStackSetOperationResultsOutput: S.Schema<ListStackSetOperationResultsOutput>;
export interface ListStackSetOperationsInput {
    StackSetName?: string;
    NextToken?: string;
    MaxResults?: number;
    CallAs?: CallAs;
}
export declare const ListStackSetOperationsInput: S.Schema<ListStackSetOperationsInput>;
export interface StackSetOperationSummary {
    OperationId?: string;
    Action?: StackSetOperationAction;
    Status?: StackSetOperationStatus;
    CreationTimestamp?: Date;
    EndTimestamp?: Date;
    StatusReason?: string;
    StatusDetails?: StackSetOperationStatusDetails;
    OperationPreferences?: StackSetOperationPreferences;
}
export declare const StackSetOperationSummary: S.Schema<StackSetOperationSummary>;
export type StackSetOperationSummaries = StackSetOperationSummary[];
export declare const StackSetOperationSummaries: any;
export interface ListStackSetOperationsOutput {
    Summaries?: StackSetOperationSummary[];
    NextToken?: string;
}
export declare const ListStackSetOperationsOutput: S.Schema<ListStackSetOperationsOutput>;
export interface ListStackSetsInput {
    NextToken?: string;
    MaxResults?: number;
    Status?: StackSetStatus;
    CallAs?: CallAs;
}
export declare const ListStackSetsInput: S.Schema<ListStackSetsInput>;
export interface StackSetSummary {
    StackSetName?: string;
    StackSetId?: string;
    Description?: string;
    Status?: StackSetStatus;
    AutoDeployment?: AutoDeployment;
    PermissionModel?: PermissionModels;
    DriftStatus?: StackDriftStatus;
    LastDriftCheckTimestamp?: Date;
    ManagedExecution?: ManagedExecution;
}
export declare const StackSetSummary: S.Schema<StackSetSummary>;
export type StackSetSummaries = StackSetSummary[];
export declare const StackSetSummaries: any;
export interface ListStackSetsOutput {
    Summaries?: StackSetSummary[];
    NextToken?: string;
}
export declare const ListStackSetsOutput: S.Schema<ListStackSetsOutput>;
export interface ListTypeRegistrationsInput {
    Type?: RegistryType;
    TypeName?: string;
    TypeArn?: string;
    RegistrationStatusFilter?: RegistrationStatus;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTypeRegistrationsInput: S.Schema<ListTypeRegistrationsInput>;
export type RegistrationTokenList = string[];
export declare const RegistrationTokenList: any;
export interface ListTypeRegistrationsOutput {
    RegistrationTokenList?: string[];
    NextToken?: string;
}
export declare const ListTypeRegistrationsOutput: S.Schema<ListTypeRegistrationsOutput>;
export type Category = "REGISTERED" | "ACTIVATED" | "THIRD_PARTY" | "AWS_TYPES" | (string & {});
export declare const Category: any;
export type TypeNamePrefix = string;
export interface TypeFilters {
    Category?: Category;
    PublisherId?: string;
    TypeNamePrefix?: string;
}
export declare const TypeFilters: S.Schema<TypeFilters>;
export interface ListTypesInput {
    Visibility?: Visibility;
    ProvisioningType?: ProvisioningType;
    DeprecatedStatus?: DeprecatedStatus;
    Type?: RegistryType;
    Filters?: TypeFilters;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTypesInput: S.Schema<ListTypesInput>;
export type PublisherName = string;
export interface TypeSummary {
    Type?: RegistryType;
    TypeName?: string;
    DefaultVersionId?: string;
    TypeArn?: string;
    LastUpdated?: Date;
    Description?: string;
    PublisherId?: string;
    OriginalTypeName?: string;
    PublicVersionNumber?: string;
    LatestPublicVersion?: string;
    PublisherIdentity?: IdentityProvider;
    PublisherName?: string;
    IsActivated?: boolean;
}
export declare const TypeSummary: S.Schema<TypeSummary>;
export type TypeSummaries = TypeSummary[];
export declare const TypeSummaries: any;
export interface ListTypesOutput {
    TypeSummaries?: TypeSummary[];
    NextToken?: string;
}
export declare const ListTypesOutput: S.Schema<ListTypesOutput>;
export interface ListTypeVersionsInput {
    Type?: RegistryType;
    TypeName?: string;
    Arn?: string;
    MaxResults?: number;
    NextToken?: string;
    DeprecatedStatus?: DeprecatedStatus;
    PublisherId?: string;
}
export declare const ListTypeVersionsInput: S.Schema<ListTypeVersionsInput>;
export interface TypeVersionSummary {
    Type?: RegistryType;
    TypeName?: string;
    VersionId?: string;
    IsDefaultVersion?: boolean;
    Arn?: string;
    TimeCreated?: Date;
    Description?: string;
    PublicVersionNumber?: string;
}
export declare const TypeVersionSummary: S.Schema<TypeVersionSummary>;
export type TypeVersionSummaries = TypeVersionSummary[];
export declare const TypeVersionSummaries: any;
export interface ListTypeVersionsOutput {
    TypeVersionSummaries?: TypeVersionSummary[];
    NextToken?: string;
}
export declare const ListTypeVersionsOutput: S.Schema<ListTypeVersionsOutput>;
export interface PublishTypeInput {
    Type?: ThirdPartyType;
    Arn?: string;
    TypeName?: string;
    PublicVersionNumber?: string;
}
export declare const PublishTypeInput: S.Schema<PublishTypeInput>;
export interface PublishTypeOutput {
    PublicTypeArn?: string;
}
export declare const PublishTypeOutput: S.Schema<PublishTypeOutput>;
export type OperationStatus = "PENDING" | "IN_PROGRESS" | "SUCCESS" | "FAILED" | (string & {});
export declare const OperationStatus: any;
export type StatusMessage = string;
export type HandlerErrorCode = "NotUpdatable" | "InvalidRequest" | "AccessDenied" | "InvalidCredentials" | "AlreadyExists" | "NotFound" | "ResourceConflict" | "Throttling" | "ServiceLimitExceeded" | "NotStabilized" | "GeneralServiceException" | "ServiceInternalError" | "NetworkFailure" | "InternalFailure" | "InvalidTypeConfiguration" | "HandlerInternalFailure" | "NonCompliant" | "Unknown" | "UnsupportedTarget" | (string & {});
export declare const HandlerErrorCode: any;
export type ResourceModel = string;
export interface RecordHandlerProgressInput {
    BearerToken?: string;
    OperationStatus?: OperationStatus;
    CurrentOperationStatus?: OperationStatus;
    StatusMessage?: string;
    ErrorCode?: HandlerErrorCode;
    ResourceModel?: string;
    ClientRequestToken?: string;
}
export declare const RecordHandlerProgressInput: S.Schema<RecordHandlerProgressInput>;
export interface RecordHandlerProgressOutput {
}
export declare const RecordHandlerProgressOutput: S.Schema<RecordHandlerProgressOutput>;
export type AcceptTermsAndConditions = boolean;
export type ConnectionArn = string;
export interface RegisterPublisherInput {
    AcceptTermsAndConditions?: boolean;
    ConnectionArn?: string;
}
export declare const RegisterPublisherInput: S.Schema<RegisterPublisherInput>;
export interface RegisterPublisherOutput {
    PublisherId?: string;
}
export declare const RegisterPublisherOutput: S.Schema<RegisterPublisherOutput>;
export type S3Url = string;
export type RequestToken = string;
export interface RegisterTypeInput {
    Type?: RegistryType;
    TypeName?: string;
    SchemaHandlerPackage?: string;
    LoggingConfig?: LoggingConfig;
    ExecutionRoleArn?: string;
    ClientRequestToken?: string;
}
export declare const RegisterTypeInput: S.Schema<RegisterTypeInput>;
export interface RegisterTypeOutput {
    RegistrationToken?: string;
}
export declare const RegisterTypeOutput: S.Schema<RegisterTypeOutput>;
export interface RollbackStackInput {
    StackName?: string;
    RoleARN?: string;
    ClientRequestToken?: string;
    RetainExceptOnCreate?: boolean;
    DeploymentConfig?: DeploymentConfig;
}
export declare const RollbackStackInput: S.Schema<RollbackStackInput>;
export interface RollbackStackOutput {
    StackId?: string;
    OperationId?: string;
}
export declare const RollbackStackOutput: S.Schema<RollbackStackOutput>;
export interface SetStackPolicyInput {
    StackName?: string;
    StackPolicyBody?: string;
    StackPolicyURL?: string;
}
export declare const SetStackPolicyInput: S.Schema<SetStackPolicyInput>;
export interface SetStackPolicyResponse {
}
export declare const SetStackPolicyResponse: S.Schema<SetStackPolicyResponse>;
export interface SetTypeConfigurationInput {
    TypeArn?: string;
    Configuration?: string;
    ConfigurationAlias?: string;
    TypeName?: string;
    Type?: ThirdPartyType;
}
export declare const SetTypeConfigurationInput: S.Schema<SetTypeConfigurationInput>;
export interface SetTypeConfigurationOutput {
    ConfigurationArn?: string;
}
export declare const SetTypeConfigurationOutput: S.Schema<SetTypeConfigurationOutput>;
export interface SetTypeDefaultVersionInput {
    Arn?: string;
    Type?: RegistryType;
    TypeName?: string;
    VersionId?: string;
}
export declare const SetTypeDefaultVersionInput: S.Schema<SetTypeDefaultVersionInput>;
export interface SetTypeDefaultVersionOutput {
}
export declare const SetTypeDefaultVersionOutput: S.Schema<SetTypeDefaultVersionOutput>;
export type ResourceSignalUniqueId = string;
export type ResourceSignalStatus = "SUCCESS" | "FAILURE" | (string & {});
export declare const ResourceSignalStatus: any;
export interface SignalResourceInput {
    StackName?: string;
    LogicalResourceId?: string;
    UniqueId?: string;
    Status?: ResourceSignalStatus;
}
export declare const SignalResourceInput: S.Schema<SignalResourceInput>;
export interface SignalResourceResponse {
}
export declare const SignalResourceResponse: S.Schema<SignalResourceResponse>;
export interface StartResourceScanInput {
    ClientRequestToken?: string;
    ScanFilters?: ScanFilter[];
}
export declare const StartResourceScanInput: S.Schema<StartResourceScanInput>;
export interface StartResourceScanOutput {
    ResourceScanId?: string;
}
export declare const StartResourceScanOutput: S.Schema<StartResourceScanOutput>;
export interface StopStackSetOperationInput {
    StackSetName?: string;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const StopStackSetOperationInput: S.Schema<StopStackSetOperationInput>;
export interface StopStackSetOperationOutput {
}
export declare const StopStackSetOperationOutput: S.Schema<StopStackSetOperationOutput>;
export type S3Bucket = string;
export interface TestTypeInput {
    Arn?: string;
    Type?: ThirdPartyType;
    TypeName?: string;
    VersionId?: string;
    LogDeliveryBucket?: string;
}
export declare const TestTypeInput: S.Schema<TestTypeInput>;
export interface TestTypeOutput {
    TypeVersionArn?: string;
}
export declare const TestTypeOutput: S.Schema<TestTypeOutput>;
export type JazzLogicalResourceIds = string[];
export declare const JazzLogicalResourceIds: any;
export type RefreshAllResources = boolean;
export interface UpdateGeneratedTemplateInput {
    GeneratedTemplateName?: string;
    NewGeneratedTemplateName?: string;
    AddResources?: ResourceDefinition[];
    RemoveResources?: string[];
    RefreshAllResources?: boolean;
    TemplateConfiguration?: TemplateConfiguration;
}
export declare const UpdateGeneratedTemplateInput: S.Schema<UpdateGeneratedTemplateInput>;
export interface UpdateGeneratedTemplateOutput {
    GeneratedTemplateId?: string;
}
export declare const UpdateGeneratedTemplateOutput: S.Schema<UpdateGeneratedTemplateOutput>;
export type StackPolicyDuringUpdateBody = string;
export type StackPolicyDuringUpdateURL = string;
export interface UpdateStackInput {
    StackName?: string;
    TemplateBody?: string;
    TemplateURL?: string;
    UsePreviousTemplate?: boolean;
    StackPolicyDuringUpdateBody?: string;
    StackPolicyDuringUpdateURL?: string;
    Parameters?: Parameter[];
    Capabilities?: Capability[];
    ResourceTypes?: string[];
    RoleARN?: string;
    RollbackConfiguration?: RollbackConfiguration;
    StackPolicyBody?: string;
    StackPolicyURL?: string;
    NotificationARNs?: string[];
    Tags?: Tag[];
    DisableRollback?: boolean;
    ClientRequestToken?: string;
    RetainExceptOnCreate?: boolean;
    DeploymentConfig?: DeploymentConfig;
    DisableValidation?: boolean;
}
export declare const UpdateStackInput: S.Schema<UpdateStackInput>;
export interface UpdateStackOutput {
    StackId?: string;
    OperationId?: string;
}
export declare const UpdateStackOutput: S.Schema<UpdateStackOutput>;
export interface UpdateStackInstancesInput {
    StackSetName?: string;
    Accounts?: string[];
    DeploymentTargets?: DeploymentTargets;
    Regions?: string[];
    ParameterOverrides?: Parameter[];
    OperationPreferences?: StackSetOperationPreferences;
    OperationId?: string;
    CallAs?: CallAs;
}
export declare const UpdateStackInstancesInput: S.Schema<UpdateStackInstancesInput>;
export interface UpdateStackInstancesOutput {
    OperationId?: string;
}
export declare const UpdateStackInstancesOutput: S.Schema<UpdateStackInstancesOutput>;
export interface UpdateStackSetInput {
    StackSetName?: string;
    Description?: string;
    TemplateBody?: string;
    TemplateURL?: string;
    UsePreviousTemplate?: boolean;
    Parameters?: Parameter[];
    Capabilities?: Capability[];
    Tags?: Tag[];
    OperationPreferences?: StackSetOperationPreferences;
    AdministrationRoleARN?: string;
    ExecutionRoleName?: string;
    DeploymentTargets?: DeploymentTargets;
    PermissionModel?: PermissionModels;
    AutoDeployment?: AutoDeployment;
    OperationId?: string;
    Accounts?: string[];
    Regions?: string[];
    CallAs?: CallAs;
    ManagedExecution?: ManagedExecution;
}
export declare const UpdateStackSetInput: S.Schema<UpdateStackSetInput>;
export interface UpdateStackSetOutput {
    OperationId?: string;
}
export declare const UpdateStackSetOutput: S.Schema<UpdateStackSetOutput>;
export interface UpdateTerminationProtectionInput {
    EnableTerminationProtection?: boolean;
    StackName?: string;
}
export declare const UpdateTerminationProtectionInput: S.Schema<UpdateTerminationProtectionInput>;
export interface UpdateTerminationProtectionOutput {
    StackId?: string;
}
export declare const UpdateTerminationProtectionOutput: S.Schema<UpdateTerminationProtectionOutput>;
export interface ValidateTemplateInput {
    TemplateBody?: string;
    TemplateURL?: string;
}
export declare const ValidateTemplateInput: S.Schema<ValidateTemplateInput>;
export interface TemplateParameter {
    ParameterKey?: string;
    DefaultValue?: string;
    NoEcho?: boolean;
    Description?: string;
}
export declare const TemplateParameter: S.Schema<TemplateParameter>;
export type TemplateParameters = TemplateParameter[];
export declare const TemplateParameters: any;
export interface ValidateTemplateOutput {
    Parameters?: TemplateParameter[];
    Description?: string;
    Capabilities?: Capability[];
    CapabilitiesReason?: string;
    DeclaredTransforms?: string[];
}
export declare const ValidateTemplateOutput: S.Schema<ValidateTemplateOutput>;
export type ActivateOrganizationsAccessError = InvalidOperationException | OperationNotFoundException | CommonErrors;
/**
 * Activate trusted access with Organizations. With trusted access between StackSets
 * and Organizations activated, the management account has permissions to create
 * and manage StackSets for your organization.
 */
export declare const activateOrganizationsAccess: API.OperationMethod<ActivateOrganizationsAccessInput, ActivateOrganizationsAccessOutput, ActivateOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type ActivateTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Activates a public third-party extension, such as a resource or module, to make it
 * available for use in stack templates in your current account and Region. It can also create
 * CloudFormation Hooks, which allow you to evaluate resource configurations before CloudFormation
 * provisions them. Hooks integrate with both CloudFormation and Cloud Control API operations.
 *
 * After you activate an extension, you can use SetTypeConfiguration to set specific properties for the extension.
 *
 * To see which extensions have been activated, use ListTypes. To see
 * configuration details for an extension, use DescribeType.
 *
 * For more information, see Activate a
 * third-party public extension in your account in the
 * *CloudFormation User Guide*. For information about creating Hooks, see the
 * CloudFormation Hooks User Guide.
 */
export declare const activateType: API.OperationMethod<ActivateTypeInput, ActivateTypeOutput, ActivateTypeError, Credentials | HttpClient.HttpClient>;
export type BatchDescribeTypeConfigurationsError = CFNRegistryException | TypeConfigurationNotFoundException | CommonErrors;
/**
 * Returns configuration data for the specified CloudFormation extensions, from the CloudFormation
 * registry in your current account and Region.
 *
 * For more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 */
export declare const batchDescribeTypeConfigurations: API.OperationMethod<BatchDescribeTypeConfigurationsInput, BatchDescribeTypeConfigurationsOutput, BatchDescribeTypeConfigurationsError, Credentials | HttpClient.HttpClient>;
export type CancelUpdateStackError = TokenAlreadyExistsException | CommonErrors;
/**
 * Cancels an update on the specified stack. If the call completes successfully, the stack
 * rolls back the update and reverts to the previous stack configuration.
 *
 * You can cancel only stacks that are in the `UPDATE_IN_PROGRESS` state.
 */
export declare const cancelUpdateStack: API.OperationMethod<CancelUpdateStackInput, CancelUpdateStackResponse, CancelUpdateStackError, Credentials | HttpClient.HttpClient>;
export type ContinueUpdateRollbackError = TokenAlreadyExistsException | CommonErrors;
/**
 * Continues rolling back a stack from `UPDATE_ROLLBACK_FAILED` to
 * `UPDATE_ROLLBACK_COMPLETE` state. Depending on the cause of the failure, you can
 * manually fix the error and continue the rollback. By continuing the rollback, you can return
 * your stack to a working state (the `UPDATE_ROLLBACK_COMPLETE` state) and then try
 * to update the stack again.
 *
 * A stack enters the `UPDATE_ROLLBACK_FAILED` state when CloudFormation can't roll
 * back all changes after a failed stack update. For example, this might occur when a stack
 * attempts to roll back to an old database that was deleted outside of CloudFormation. Because
 * CloudFormation doesn't know the instance was deleted, it assumes the instance still exists and
 * attempts to roll back to it, causing the update rollback to fail.
 *
 * For more information, see Continue rolling back an update in the *CloudFormation User Guide*. For
 * information for troubleshooting a failed update rollback, see Update rollback failed.
 */
export declare const continueUpdateRollback: API.OperationMethod<ContinueUpdateRollbackInput, ContinueUpdateRollbackOutput, ContinueUpdateRollbackError, Credentials | HttpClient.HttpClient>;
export type CreateChangeSetError = AlreadyExistsException | InsufficientCapabilitiesException | LimitExceededException | CommonErrors;
/**
 * Creates a list of changes that will be applied to a stack so that you can review the
 * changes before executing them. You can create a change set for a stack that doesn't exist or
 * an existing stack. If you create a change set for a stack that doesn't exist, the change set
 * shows all of the resources that CloudFormation will create. If you create a change set for an
 * existing stack, CloudFormation compares the stack's information with the information that you
 * submit in the change set and lists the differences. Use change sets to understand which
 * resources CloudFormation will create or change, and how it will change resources in an existing
 * stack, before you create or update a stack.
 *
 * To create a change set for a stack that doesn't exist, for the `ChangeSetType`
 * parameter, specify `CREATE`. To create a change set for an existing stack, specify
 * `UPDATE` for the `ChangeSetType` parameter. To create a change set for
 * an import operation, specify `IMPORT` for the `ChangeSetType` parameter.
 * After the `CreateChangeSet` call successfully completes, CloudFormation starts creating
 * the change set. To check the status of the change set or to review it, use the DescribeChangeSet action.
 *
 * When you are satisfied with the changes the change set will make, execute the change set
 * by using the ExecuteChangeSet action. CloudFormation doesn't make changes until
 * you execute the change set.
 *
 * To create a change set for the entire stack hierarchy, set
 * `IncludeNestedStacks` to `True`.
 */
export declare const createChangeSet: API.OperationMethod<CreateChangeSetInput, CreateChangeSetOutput, CreateChangeSetError, Credentials | HttpClient.HttpClient>;
export type CreateGeneratedTemplateError = AlreadyExistsException | ConcurrentResourcesLimitExceededException | LimitExceededException | CommonErrors;
/**
 * Creates a template from existing resources that are not already managed with CloudFormation.
 * You can check the status of the template generation using the
 * `DescribeGeneratedTemplate` API action.
 */
export declare const createGeneratedTemplate: API.OperationMethod<CreateGeneratedTemplateInput, CreateGeneratedTemplateOutput, CreateGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateStackError = AlreadyExistsException | InsufficientCapabilitiesException | LimitExceededException | TokenAlreadyExistsException | CommonErrors;
/**
 * Creates a stack as specified in the template. After the call completes successfully, the
 * stack creation starts. You can check the status of the stack through the DescribeStacks operation.
 *
 * For more information about creating a stack and monitoring stack progress, see Managing Amazon Web Services
 * resources as a single unit with CloudFormation stacks in the
 * *CloudFormation User Guide*.
 */
export declare const createStack: API.OperationMethod<CreateStackInput, CreateStackOutput, CreateStackError, Credentials | HttpClient.HttpClient>;
export type CreateStackInstancesError = InvalidOperationException | LimitExceededException | OperationIdAlreadyExistsException | OperationInProgressException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Creates stack instances for the specified accounts, within the specified Amazon Web Services Regions. A
 * stack instance refers to a stack in a specific account and Region. You must specify at least
 * one value for either `Accounts` or `DeploymentTargets`, and you must
 * specify at least one value for `Regions`.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `CreateStackInstances` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const createStackInstances: API.OperationMethod<CreateStackInstancesInput, CreateStackInstancesOutput, CreateStackInstancesError, Credentials | HttpClient.HttpClient>;
export type CreateStackRefactorError = CommonErrors;
/**
 * Creates a refactor across multiple stacks, with the list of stacks and resources that are
 * affected.
 */
export declare const createStackRefactor: API.OperationMethod<CreateStackRefactorInput, CreateStackRefactorOutput, CreateStackRefactorError, Credentials | HttpClient.HttpClient>;
export type CreateStackSetError = CreatedButModifiedException | LimitExceededException | NameAlreadyExistsException | CommonErrors;
/**
 * Creates a StackSet.
 */
export declare const createStackSet: API.OperationMethod<CreateStackSetInput, CreateStackSetOutput, CreateStackSetError, Credentials | HttpClient.HttpClient>;
export type DeactivateOrganizationsAccessError = InvalidOperationException | OperationNotFoundException | CommonErrors;
/**
 * Deactivates trusted access with Organizations. If trusted access is deactivated,
 * the management account does not have permissions to create and manage
 * service-managed StackSets for your organization.
 */
export declare const deactivateOrganizationsAccess: API.OperationMethod<DeactivateOrganizationsAccessInput, DeactivateOrganizationsAccessOutput, DeactivateOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type DeactivateTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Deactivates a public third-party extension, such as a resource or module, or a CloudFormation
 * Hook when you no longer use it.
 *
 * Deactivating an extension deletes the configuration details that are associated with it.
 * To temporarily disable a CloudFormation Hook instead, you can use SetTypeConfiguration.
 *
 * Once deactivated, an extension can't be used in any CloudFormation operation. This includes
 * stack update operations where the stack template includes the extension, even if no updates
 * are being made to the extension. In addition, deactivated extensions aren't automatically
 * updated if a new version of the extension is released.
 *
 * To see which extensions are currently activated, use ListTypes.
 */
export declare const deactivateType: API.OperationMethod<DeactivateTypeInput, DeactivateTypeOutput, DeactivateTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteChangeSetError = InvalidChangeSetStatusException | CommonErrors;
/**
 * Deletes the specified change set. Deleting change sets ensures that no one executes the
 * wrong change set.
 *
 * If the call successfully completes, CloudFormation successfully deleted the change set.
 *
 * If `IncludeNestedStacks` specifies `True` during the creation of the
 * nested change set, then `DeleteChangeSet` will delete all change sets that belong
 * to the stacks hierarchy and will also delete all change sets for nested stacks with the status
 * of `REVIEW_IN_PROGRESS`.
 */
export declare const deleteChangeSet: API.OperationMethod<DeleteChangeSetInput, DeleteChangeSetOutput, DeleteChangeSetError, Credentials | HttpClient.HttpClient>;
export type DeleteGeneratedTemplateError = ConcurrentResourcesLimitExceededException | GeneratedTemplateNotFoundException | CommonErrors;
/**
 * Deleted a generated template.
 */
export declare const deleteGeneratedTemplate: API.OperationMethod<DeleteGeneratedTemplateInput, DeleteGeneratedTemplateResponse, DeleteGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteStackError = TokenAlreadyExistsException | CommonErrors;
/**
 * Deletes a specified stack. Once the call completes successfully, stack deletion starts.
 * Deleted stacks don't show up in the DescribeStacks operation if the deletion
 * has been completed successfully.
 *
 * For more information about deleting a stack, see Delete a stack from
 * the CloudFormation console in the *CloudFormation User Guide*.
 */
export declare const deleteStack: API.OperationMethod<DeleteStackInput, DeleteStackResponse, DeleteStackError, Credentials | HttpClient.HttpClient>;
export type DeleteStackInstancesError = InvalidOperationException | OperationIdAlreadyExistsException | OperationInProgressException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Deletes stack instances for the specified accounts, in the specified Amazon Web Services Regions.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `DeleteStackInstances` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const deleteStackInstances: API.OperationMethod<DeleteStackInstancesInput, DeleteStackInstancesOutput, DeleteStackInstancesError, Credentials | HttpClient.HttpClient>;
export type DeleteStackSetError = OperationInProgressException | StackSetNotEmptyException | CommonErrors;
/**
 * Deletes a StackSet. Before you can delete a StackSet, all its member stack instances must
 * be deleted. For more information about how to complete this, see DeleteStackInstances.
 */
export declare const deleteStackSet: API.OperationMethod<DeleteStackSetInput, DeleteStackSetOutput, DeleteStackSetError, Credentials | HttpClient.HttpClient>;
export type DeregisterTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Marks an extension or extension version as `DEPRECATED` in the CloudFormation
 * registry, removing it from active use. Deprecated extensions or extension versions cannot be
 * used in CloudFormation operations.
 *
 * To deregister an entire extension, you must individually deregister all active versions of
 * that extension. If an extension has only a single active version, deregistering that version
 * results in the extension itself being deregistered and marked as deprecated in the
 * registry.
 *
 * You can't deregister the default version of an extension if there are other active version
 * of that extension. If you do deregister the default version of an extension, the extension
 * type itself is deregistered as well and marked as deprecated.
 *
 * To view the deprecation status of an extension or extension version, use DescribeType.
 *
 * For more information, see Remove
 * third-party private extensions from your account in the
 * *CloudFormation User Guide*.
 */
export declare const deregisterType: API.OperationMethod<DeregisterTypeInput, DeregisterTypeOutput, DeregisterTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountLimitsError = CommonErrors;
/**
 * Retrieves your account's CloudFormation limits, such as the maximum number of stacks that you
 * can create in your account. For more information about account limits, see Understand CloudFormation quotas in the *CloudFormation User Guide*.
 */
export declare const describeAccountLimits: API.PaginatedOperationMethod<DescribeAccountLimitsInput, DescribeAccountLimitsOutput, DescribeAccountLimitsError, Credentials | HttpClient.HttpClient, AccountLimit>;
export type DescribeChangeSetError = ChangeSetNotFoundException | CommonErrors;
/**
 * Returns the inputs for the change set and a list of changes that CloudFormation will make if
 * you execute the change set. For more information, see Update
 * CloudFormation stacks using change sets in the
 * *CloudFormation User Guide*.
 */
export declare const describeChangeSet: API.PaginatedOperationMethod<DescribeChangeSetInput, DescribeChangeSetOutput, DescribeChangeSetError, Credentials | HttpClient.HttpClient, Change>;
export type DescribeChangeSetHooksError = ChangeSetNotFoundException | CommonErrors;
/**
 * Returns Hook-related information for the change set and a list of changes that
 * CloudFormation makes when you run the change set.
 */
export declare const describeChangeSetHooks: API.OperationMethod<DescribeChangeSetHooksInput, DescribeChangeSetHooksOutput, DescribeChangeSetHooksError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns CloudFormation events based on flexible query criteria. Groups events by operation ID,
 * enabling you to focus on individual stack operations during deployment.
 *
 * An operation is any action performed on a stack, including stack lifecycle actions
 * (Create, Update, Delete, Rollback), change set creation, nested stack creation, and automatic
 * rollbacks triggered by failures. Each operation has a unique identifier (Operation ID) and
 * represents a discrete change attempt on the stack.
 *
 * Returns different types of events including:
 *
 * - **Progress events** - Status updates during stack operation
 * execution.
 *
 * - **Validation errors** - Failures from CloudFormation Early
 * Validations.
 *
 * - **Provisioning errors** - Resource creation and update
 * failures.
 *
 * - **Hook invocation errors** - Failures from CloudFormation
 * Hook during stack operations.
 *
 * One of `ChangeSetName`, `OperationId` or `StackName`
 * must be specified as input.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsInput, DescribeEventsOutput, DescribeEventsError, Credentials | HttpClient.HttpClient, OperationEvent>;
export type DescribeGeneratedTemplateError = GeneratedTemplateNotFoundException | CommonErrors;
/**
 * Describes a generated template. The output includes details about the progress of the
 * creation of a generated template started by a `CreateGeneratedTemplate` API action
 * or the update of a generated template started with an `UpdateGeneratedTemplate` API
 * action.
 */
export declare const describeGeneratedTemplate: API.OperationMethod<DescribeGeneratedTemplateInput, DescribeGeneratedTemplateOutput, DescribeGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationsAccessError = InvalidOperationException | OperationNotFoundException | CommonErrors;
/**
 * Retrieves information about the account's `OrganizationAccess` status. This API
 * can be called either by the management account or the delegated administrator by using the
 * `CallAs` parameter. This API can also be called without the `CallAs`
 * parameter by the management account.
 */
export declare const describeOrganizationsAccess: API.OperationMethod<DescribeOrganizationsAccessInput, DescribeOrganizationsAccessOutput, DescribeOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type DescribePublisherError = CFNRegistryException | CommonErrors;
/**
 * Returns information about a CloudFormation extension publisher.
 *
 * If you don't supply a `PublisherId`, and you have registered as an extension
 * publisher, `DescribePublisher` returns information about your own publisher
 * account.
 *
 * For more information about registering as a publisher, see:
 *
 * - RegisterPublisher
 *
 * - Publishing extensions
 * to make them available for public use in the
 * *CloudFormation Command Line Interface (CLI) User Guide*
 */
export declare const describePublisher: API.OperationMethod<DescribePublisherInput, DescribePublisherOutput, DescribePublisherError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceScanError = ResourceScanNotFoundException | CommonErrors;
/**
 * Describes details of a resource scan.
 */
export declare const describeResourceScan: API.OperationMethod<DescribeResourceScanInput, DescribeResourceScanOutput, DescribeResourceScanError, Credentials | HttpClient.HttpClient>;
export type DescribeStackDriftDetectionStatusError = CommonErrors;
/**
 * Returns information about a stack drift detection operation. A stack drift detection
 * operation detects whether a stack's actual configuration differs, or has
 * *drifted*, from its expected configuration, as defined in the stack
 * template and any values specified as template parameters. A stack is considered to have
 * drifted if one or more of its resources have drifted. For more information about stack and
 * resource drift, see Detect unmanaged
 * configuration changes to stacks and resources with drift detection.
 *
 * Use DetectStackDrift to initiate a stack drift detection operation.
 * `DetectStackDrift` returns a `StackDriftDetectionId` you can use to
 * monitor the progress of the operation using `DescribeStackDriftDetectionStatus`.
 * Once the drift detection operation has completed, use DescribeStackResourceDrifts to return drift information about the stack and its
 * resources.
 */
export declare const describeStackDriftDetectionStatus: API.OperationMethod<DescribeStackDriftDetectionStatusInput, DescribeStackDriftDetectionStatusOutput, DescribeStackDriftDetectionStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeStackEventsError = CommonErrors;
/**
 * Returns all stack related events for a specified stack in reverse chronological order. For
 * more information about a stack's event history, see Understand CloudFormation stack creation events in the
 * *CloudFormation User Guide*.
 *
 * You can list events for stacks that have failed to create or have been deleted by
 * specifying the unique stack identifier (stack ID).
 */
export declare const describeStackEvents: API.PaginatedOperationMethod<DescribeStackEventsInput, DescribeStackEventsOutput, DescribeStackEventsError, Credentials | HttpClient.HttpClient, StackEvent>;
export type DescribeStackInstanceError = StackInstanceNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns the stack instance that's associated with the specified StackSet, Amazon Web Services account,
 * and Amazon Web Services Region.
 *
 * For a list of stack instances that are associated with a specific StackSet, use ListStackInstances.
 */
export declare const describeStackInstance: API.OperationMethod<DescribeStackInstanceInput, DescribeStackInstanceOutput, DescribeStackInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeStackRefactorError = StackRefactorNotFoundException | CommonErrors;
/**
 * Describes the stack refactor status.
 */
export declare const describeStackRefactor: API.OperationMethod<DescribeStackRefactorInput, DescribeStackRefactorOutput, DescribeStackRefactorError, Credentials | HttpClient.HttpClient>;
export type DescribeStackResourceError = CommonErrors;
/**
 * Returns a description of the specified resource in the specified stack.
 *
 * For deleted stacks, DescribeStackResource returns resource information for up to 90 days
 * after the stack has been deleted.
 */
export declare const describeStackResource: API.OperationMethod<DescribeStackResourceInput, DescribeStackResourceOutput, DescribeStackResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeStackResourceDriftsError = CommonErrors;
/**
 * Returns drift information for the resources that have been checked for drift in the
 * specified stack. This includes actual and expected configuration values for resources where
 * CloudFormation detects configuration drift.
 *
 * For a given stack, there will be one `StackResourceDrift` for each stack
 * resource that has been checked for drift. Resources that haven't yet been checked for drift
 * aren't included. Resources that don't currently support drift detection aren't checked, and so
 * not included. For a list of resources that support drift detection, see Resource
 * type support for imports and drift detection.
 *
 * Use DetectStackResourceDrift to detect drift on individual resources, or
 * DetectStackDrift to detect drift on all supported resources for a given
 * stack.
 */
export declare const describeStackResourceDrifts: API.PaginatedOperationMethod<DescribeStackResourceDriftsInput, DescribeStackResourceDriftsOutput, DescribeStackResourceDriftsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeStackResourcesError = CommonErrors;
/**
 * Returns Amazon Web Services resource descriptions for running and deleted stacks. If
 * `StackName` is specified, all the associated resources that are part of the stack
 * are returned. If `PhysicalResourceId` is specified, the associated resources of the
 * stack that the resource belongs to are returned.
 *
 * Only the first 100 resources will be returned. If your stack has more resources than
 * this, you should use `ListStackResources` instead.
 *
 * For deleted stacks, `DescribeStackResources` returns resource information for
 * up to 90 days after the stack has been deleted.
 *
 * You must specify either `StackName` or `PhysicalResourceId`, but not
 * both. In addition, you can specify `LogicalResourceId` to filter the returned
 * result. For more information about resources, the `LogicalResourceId` and
 * `PhysicalResourceId`, see the CloudFormation User Guide.
 *
 * A `ValidationError` is returned if you specify both `StackName`
 * and `PhysicalResourceId` in the same request.
 */
export declare const describeStackResources: API.OperationMethod<DescribeStackResourcesInput, DescribeStackResourcesOutput, DescribeStackResourcesError, Credentials | HttpClient.HttpClient>;
export type DescribeStacksError = StackNotFound | CommonErrors;
/**
 * Returns the description for the specified stack; if no stack name was specified, then it
 * returns the description for all the stacks created. For more information about a stack's event
 * history, see Understand CloudFormation stack creation events in the
 * *CloudFormation User Guide*.
 *
 * If the stack doesn't exist, a `ValidationError` is returned.
 */
export declare const describeStacks: API.PaginatedOperationMethod<DescribeStacksInput, DescribeStacksOutput, DescribeStacksError, Credentials | HttpClient.HttpClient, Stack>;
export type DescribeStackSetError = StackSetNotFoundException | CommonErrors;
/**
 * Returns the description of the specified StackSet.
 *
 * This API provides *strongly consistent* reads meaning it will always
 * return the most up-to-date data.
 */
export declare const describeStackSet: API.OperationMethod<DescribeStackSetInput, DescribeStackSetOutput, DescribeStackSetError, Credentials | HttpClient.HttpClient>;
export type DescribeStackSetOperationError = OperationNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns the description of the specified StackSet operation.
 *
 * This API provides *strongly consistent* reads meaning it will always
 * return the most up-to-date data.
 */
export declare const describeStackSetOperation: API.OperationMethod<DescribeStackSetOperationInput, DescribeStackSetOperationOutput, DescribeStackSetOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Returns detailed information about an extension from the CloudFormation registry in your
 * current account and Region.
 *
 * If you specify a `VersionId`, `DescribeType` returns information
 * about that specific extension version. Otherwise, it returns information about the default
 * extension version.
 *
 * For more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 */
export declare const describeType: API.OperationMethod<DescribeTypeInput, DescribeTypeOutput, DescribeTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeTypeRegistrationError = CFNRegistryException | CommonErrors;
/**
 * Returns information about an extension's registration, including its current status and
 * type and version identifiers.
 *
 * When you initiate a registration request using RegisterType, you can
 * then use DescribeTypeRegistration to monitor the progress of that
 * registration request.
 *
 * Once the registration request has completed, use DescribeType to return
 * detailed information about an extension.
 */
export declare const describeTypeRegistration: API.OperationMethod<DescribeTypeRegistrationInput, DescribeTypeRegistrationOutput, DescribeTypeRegistrationError, Credentials | HttpClient.HttpClient>;
export type DetectStackDriftError = CommonErrors;
/**
 * Detects whether a stack's actual configuration differs, or has
 * *drifted*, from its expected configuration, as defined in the stack
 * template and any values specified as template parameters. For each resource in the stack that
 * supports drift detection, CloudFormation compares the actual configuration of the resource with
 * its expected template configuration. Only resource properties explicitly defined in the stack
 * template are checked for drift. A stack is considered to have drifted if one or more of its
 * resources differ from their expected template configurations. For more information, see Detect unmanaged configuration changes to stacks and resources with drift
 * detection.
 *
 * Use `DetectStackDrift` to detect drift on all supported resources for a given
 * stack, or DetectStackResourceDrift to detect drift on individual
 * resources.
 *
 * For a list of stack resources that currently support drift detection, see Resource
 * type support for imports and drift detection.
 *
 * `DetectStackDrift` can take up to several minutes, depending on the number of
 * resources contained within the stack. Use DescribeStackDriftDetectionStatus
 * to monitor the progress of a detect stack drift operation. Once the drift detection operation
 * has completed, use DescribeStackResourceDrifts to return drift information
 * about the stack and its resources.
 *
 * When detecting drift on a stack, CloudFormation doesn't detect drift on any nested stacks
 * belonging to that stack. Perform `DetectStackDrift` directly on the nested stack
 * itself.
 */
export declare const detectStackDrift: API.OperationMethod<DetectStackDriftInput, DetectStackDriftOutput, DetectStackDriftError, Credentials | HttpClient.HttpClient>;
export type DetectStackResourceDriftError = CommonErrors;
/**
 * Returns information about whether a resource's actual configuration differs, or has
 * *drifted*, from its expected configuration, as defined in the stack
 * template and any values specified as template parameters. This information includes actual and
 * expected property values for resources in which CloudFormation detects drift. Only resource
 * properties explicitly defined in the stack template are checked for drift. For more
 * information about stack and resource drift, see Detect unmanaged
 * configuration changes to stacks and resources with drift detection.
 *
 * Use `DetectStackResourceDrift` to detect drift on individual resources, or
 * DetectStackDrift to detect drift on all resources in a given stack that
 * support drift detection.
 *
 * Resources that don't currently support drift detection can't be checked. For a list of
 * resources that support drift detection, see Resource
 * type support for imports and drift detection.
 */
export declare const detectStackResourceDrift: API.OperationMethod<DetectStackResourceDriftInput, DetectStackResourceDriftOutput, DetectStackResourceDriftError, Credentials | HttpClient.HttpClient>;
export type DetectStackSetDriftError = InvalidOperationException | OperationInProgressException | StackSetNotFoundException | CommonErrors;
/**
 * Detect drift on a StackSet. When CloudFormation performs drift detection on a StackSet, it
 * performs drift detection on the stack associated with each stack instance in the StackSet. For
 * more information, see Performing drift detection on
 * CloudFormation StackSets.
 *
 * `DetectStackSetDrift` returns the `OperationId` of the StackSet
 * drift detection operation. Use this operation id with DescribeStackSetOperation to monitor the progress of the drift detection
 * operation. The drift detection operation may take some time, depending on the number of stack
 * instances included in the StackSet, in addition to the number of resources included in each
 * stack.
 *
 * Once the operation has completed, use the following actions to return drift
 * information:
 *
 * - Use DescribeStackSet to return detailed information about the stack
 * set, including detailed information about the last *completed* drift
 * operation performed on the StackSet. (Information about drift operations that are in
 * progress isn't included.)
 *
 * - Use ListStackInstances to return a list of stack instances belonging
 * to the StackSet, including the drift status and last drift time checked of each
 * instance.
 *
 * - Use DescribeStackInstance to return detailed information about a
 * specific stack instance, including its drift status and last drift time checked.
 *
 * You can only run a single drift detection operation on a given StackSet at one
 * time.
 *
 * To stop a drift detection StackSet operation, use StopStackSetOperation.
 */
export declare const detectStackSetDrift: API.OperationMethod<DetectStackSetDriftInput, DetectStackSetDriftOutput, DetectStackSetDriftError, Credentials | HttpClient.HttpClient>;
export type EstimateTemplateCostError = CommonErrors;
/**
 * Returns the estimated monthly cost of a template. The return value is an Amazon Web Services Simple
 * Monthly Calculator URL with a query string that describes the resources required to run the
 * template.
 */
export declare const estimateTemplateCost: API.OperationMethod<EstimateTemplateCostInput, EstimateTemplateCostOutput, EstimateTemplateCostError, Credentials | HttpClient.HttpClient>;
export type ExecuteChangeSetError = ChangeSetNotFoundException | InsufficientCapabilitiesException | InvalidChangeSetStatusException | TokenAlreadyExistsException | CommonErrors;
/**
 * Updates a stack using the input information that was provided when the specified change
 * set was created. After the call successfully completes, CloudFormation starts updating the stack.
 * Use the DescribeStacks action to view the status of the update.
 *
 * When you execute a change set, CloudFormation deletes all other change sets associated with
 * the stack because they aren't valid for the updated stack.
 *
 * If a stack policy is associated with the stack, CloudFormation enforces the policy during the
 * update. You can't specify a temporary stack policy that overrides the current policy.
 *
 * To create a change set for the entire stack hierarchy, `IncludeNestedStacks`
 * must have been set to `True`.
 */
export declare const executeChangeSet: API.OperationMethod<ExecuteChangeSetInput, ExecuteChangeSetOutput, ExecuteChangeSetError, Credentials | HttpClient.HttpClient>;
export type ExecuteStackRefactorError = CommonErrors;
/**
 * Executes the stack refactor operation.
 */
export declare const executeStackRefactor: API.OperationMethod<ExecuteStackRefactorInput, ExecuteStackRefactorResponse, ExecuteStackRefactorError, Credentials | HttpClient.HttpClient>;
export type GetGeneratedTemplateError = GeneratedTemplateNotFoundException | CommonErrors;
/**
 * Retrieves a generated template. If the template is in an `InProgress` or
 * `Pending` status then the template returned will be the template when the
 * template was last in a `Complete` status. If the template has not yet been in a
 * `Complete` status then an empty template will be returned.
 */
export declare const getGeneratedTemplate: API.OperationMethod<GetGeneratedTemplateInput, GetGeneratedTemplateOutput, GetGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type GetHookResultError = HookResultNotFoundException | CommonErrors;
/**
 * Retrieves detailed information and remediation guidance for a Hook invocation
 * result.
 *
 * If the Hook uses a KMS key to encrypt annotations, callers of the
 * `GetHookResult` operation must have `kms:Decrypt` permissions. For
 * more information, see KMS key policy
 * and permissions for encrypting CloudFormation Hooks results at rest in the
 * *CloudFormation Hooks User Guide*.
 */
export declare const getHookResult: API.OperationMethod<GetHookResultInput, GetHookResultOutput, GetHookResultError, Credentials | HttpClient.HttpClient>;
export type GetStackPolicyError = CommonErrors;
/**
 * Returns the stack policy for a specified stack. If a stack doesn't have a policy, a null
 * value is returned.
 */
export declare const getStackPolicy: API.OperationMethod<GetStackPolicyInput, GetStackPolicyOutput, GetStackPolicyError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = ChangeSetNotFoundException | CommonErrors;
/**
 * Returns the template body for a specified stack. You can get the template for running or
 * deleted stacks.
 *
 * For deleted stacks, `GetTemplate` returns the template for up to 90 days after
 * the stack has been deleted.
 *
 * If the template doesn't exist, a `ValidationError` is returned.
 */
export declare const getTemplate: API.OperationMethod<GetTemplateInput, GetTemplateOutput, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetTemplateSummaryError = StackSetNotFoundException | CommonErrors;
/**
 * Returns information about a new or existing template. The `GetTemplateSummary`
 * action is useful for viewing parameter information, such as default parameter values and
 * parameter types, before you create or update a stack or StackSet.
 *
 * You can use the `GetTemplateSummary` action when you submit a template, or you
 * can get template information for a StackSet, or a running or deleted stack.
 *
 * For deleted stacks, `GetTemplateSummary` returns the template information for
 * up to 90 days after the stack has been deleted. If the template doesn't exist, a
 * `ValidationError` is returned.
 */
export declare const getTemplateSummary: API.OperationMethod<GetTemplateSummaryInput, GetTemplateSummaryOutput, GetTemplateSummaryError, Credentials | HttpClient.HttpClient>;
export type ImportStacksToStackSetError = InvalidOperationException | LimitExceededException | OperationIdAlreadyExistsException | OperationInProgressException | StackNotFoundException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Import existing stacks into a new StackSets. Use the stack import operation to import up
 * to 10 stacks into a new StackSet in the same account as the source stack or in a different
 * administrator account and Region, by specifying the stack ID of the stack you intend to
 * import.
 */
export declare const importStacksToStackSet: API.OperationMethod<ImportStacksToStackSetInput, ImportStacksToStackSetOutput, ImportStacksToStackSetError, Credentials | HttpClient.HttpClient>;
export type ListChangeSetsError = CommonErrors;
/**
 * Returns the ID and status of each active change set for a stack. For example, CloudFormation
 * lists change sets that are in the `CREATE_IN_PROGRESS` or
 * `CREATE_PENDING` state.
 */
export declare const listChangeSets: API.PaginatedOperationMethod<ListChangeSetsInput, ListChangeSetsOutput, ListChangeSetsError, Credentials | HttpClient.HttpClient, ChangeSetSummary>;
export type ListExportsError = CommonErrors;
/**
 * Lists all exported output values in the account and Region in which you call this action.
 * Use this action to see the exported output values that you can import into other stacks. To
 * import values, use the Fn::ImportValue function.
 *
 * For more information, see Get exported outputs
 * from a deployed CloudFormation stack.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsInput, ListExportsOutput, ListExportsError, Credentials | HttpClient.HttpClient, Export>;
export type ListGeneratedTemplatesError = CommonErrors;
/**
 * Lists your generated templates in this Region.
 */
export declare const listGeneratedTemplates: API.PaginatedOperationMethod<ListGeneratedTemplatesInput, ListGeneratedTemplatesOutput, ListGeneratedTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type ListHookResultsError = HookResultNotFoundException | CommonErrors;
/**
 * Returns summaries of invoked Hooks. For more information, see View invocation
 * summaries for CloudFormation Hooks in the *CloudFormation Hooks User Guide*.
 *
 * This operation supports the following parameter combinations:
 *
 * - No parameters: Returns all Hook invocation summaries.
 *
 * - `TypeArn` only: Returns summaries for a specific Hook.
 *
 * - `TypeArn` and `Status`: Returns summaries for a specific Hook
 * filtered by status.
 *
 * - `TargetId` and `TargetType`: Returns summaries for a specific
 * Hook invocation target.
 */
export declare const listHookResults: API.OperationMethod<ListHookResultsInput, ListHookResultsOutput, ListHookResultsError, Credentials | HttpClient.HttpClient>;
export type ListImportsError = CommonErrors;
/**
 * Lists all stacks that are importing an exported output value. To modify or remove an
 * exported output value, first use this action to see which stacks are using it. To see the
 * exported output values in your account, see ListExports.
 *
 * For more information about importing an exported output value, see the Fn::ImportValue function.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsInput, ListImportsOutput, ListImportsError, Credentials | HttpClient.HttpClient, StackName>;
export type ListResourceScanRelatedResourcesError = ResourceScanInProgressException | ResourceScanNotFoundException | CommonErrors;
/**
 * Lists the related resources for a list of resources from a resource scan. The response
 * indicates whether each returned resource is already managed by CloudFormation.
 */
export declare const listResourceScanRelatedResources: API.PaginatedOperationMethod<ListResourceScanRelatedResourcesInput, ListResourceScanRelatedResourcesOutput, ListResourceScanRelatedResourcesError, Credentials | HttpClient.HttpClient, ScannedResource>;
export type ListResourceScanResourcesError = ResourceScanInProgressException | ResourceScanNotFoundException | CommonErrors;
/**
 * Lists the resources from a resource scan. The results can be filtered by resource
 * identifier, resource type prefix, tag key, and tag value. Only resources that match all
 * specified filters are returned. The response indicates whether each returned resource is
 * already managed by CloudFormation.
 */
export declare const listResourceScanResources: API.PaginatedOperationMethod<ListResourceScanResourcesInput, ListResourceScanResourcesOutput, ListResourceScanResourcesError, Credentials | HttpClient.HttpClient, ScannedResource>;
export type ListResourceScansError = CommonErrors;
/**
 * List the resource scans from newest to oldest. By default it will return up to 10 resource
 * scans.
 */
export declare const listResourceScans: API.PaginatedOperationMethod<ListResourceScansInput, ListResourceScansOutput, ListResourceScansError, Credentials | HttpClient.HttpClient, ResourceScanSummary>;
export type ListStackInstanceResourceDriftsError = OperationNotFoundException | StackInstanceNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns drift information for resources in a stack instance.
 *
 * `ListStackInstanceResourceDrifts` returns drift information for the most
 * recent drift detection operation. If an operation is in progress, it may only return partial
 * results.
 */
export declare const listStackInstanceResourceDrifts: API.OperationMethod<ListStackInstanceResourceDriftsInput, ListStackInstanceResourceDriftsOutput, ListStackInstanceResourceDriftsError, Credentials | HttpClient.HttpClient>;
export type ListStackInstancesError = StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about stack instances that are associated with the specified
 * StackSet. You can filter for stack instances that are associated with a specific Amazon Web Services account
 * name or Region, or that have a specific status.
 */
export declare const listStackInstances: API.PaginatedOperationMethod<ListStackInstancesInput, ListStackInstancesOutput, ListStackInstancesError, Credentials | HttpClient.HttpClient, StackInstanceSummary>;
export type ListStackRefactorActionsError = CommonErrors;
/**
 * Lists the stack refactor actions that will be taken after calling the ExecuteStackRefactor action.
 */
export declare const listStackRefactorActions: API.PaginatedOperationMethod<ListStackRefactorActionsInput, ListStackRefactorActionsOutput, ListStackRefactorActionsError, Credentials | HttpClient.HttpClient, StackRefactorAction>;
export type ListStackRefactorsError = CommonErrors;
/**
 * Lists all account stack refactor operations and their statuses.
 */
export declare const listStackRefactors: API.PaginatedOperationMethod<ListStackRefactorsInput, ListStackRefactorsOutput, ListStackRefactorsError, Credentials | HttpClient.HttpClient, StackRefactorSummary>;
export type ListStackResourcesError = CommonErrors;
/**
 * Returns descriptions of all resources of the specified stack.
 *
 * For deleted stacks, ListStackResources returns resource information for up to 90 days
 * after the stack has been deleted.
 */
export declare const listStackResources: API.PaginatedOperationMethod<ListStackResourcesInput, ListStackResourcesOutput, ListStackResourcesError, Credentials | HttpClient.HttpClient, StackResourceSummary>;
export type ListStacksError = CommonErrors;
/**
 * Returns the summary information for stacks whose status matches the specified
 * `StackStatusFilter`. Summary information for stacks that have been deleted is
 * kept for 90 days after the stack is deleted. If no `StackStatusFilter` is
 * specified, summary information for all stacks is returned (including existing stacks and
 * stacks that have been deleted).
 */
export declare const listStacks: API.PaginatedOperationMethod<ListStacksInput, ListStacksOutput, ListStacksError, Credentials | HttpClient.HttpClient, StackSummary>;
export type ListStackSetAutoDeploymentTargetsError = StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about deployment targets for a StackSet.
 */
export declare const listStackSetAutoDeploymentTargets: API.OperationMethod<ListStackSetAutoDeploymentTargetsInput, ListStackSetAutoDeploymentTargetsOutput, ListStackSetAutoDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type ListStackSetOperationResultsError = OperationNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about the results of a StackSet operation.
 *
 * This API provides *eventually consistent* reads meaning it may take
 * some time but will eventually return the most up-to-date data.
 */
export declare const listStackSetOperationResults: API.PaginatedOperationMethod<ListStackSetOperationResultsInput, ListStackSetOperationResultsOutput, ListStackSetOperationResultsError, Credentials | HttpClient.HttpClient, StackSetOperationResultSummary>;
export type ListStackSetOperationsError = StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about operations performed on a StackSet.
 *
 * This API provides *eventually consistent* reads meaning it may take
 * some time but will eventually return the most up-to-date data.
 */
export declare const listStackSetOperations: API.PaginatedOperationMethod<ListStackSetOperationsInput, ListStackSetOperationsOutput, ListStackSetOperationsError, Credentials | HttpClient.HttpClient, StackSetOperationSummary>;
export type ListStackSetsError = CommonErrors;
/**
 * Returns summary information about StackSets that are associated with the user.
 *
 * This API provides *strongly consistent* reads meaning it will always
 * return the most up-to-date data.
 *
 * - [Self-managed permissions] If you set the `CallAs` parameter to
 * `SELF` while signed in to your Amazon Web Services account, `ListStackSets`
 * returns all self-managed StackSets in your Amazon Web Services account.
 *
 * - [Service-managed permissions] If you set the `CallAs` parameter to
 * `SELF` while signed in to the organization's management account,
 * `ListStackSets` returns all StackSets in the management account.
 *
 * - [Service-managed permissions] If you set the `CallAs` parameter to
 * `DELEGATED_ADMIN` while signed in to your member account,
 * `ListStackSets` returns all StackSets with service-managed permissions in the
 * management account.
 */
export declare const listStackSets: API.PaginatedOperationMethod<ListStackSetsInput, ListStackSetsOutput, ListStackSetsError, Credentials | HttpClient.HttpClient, StackSetSummary>;
export type ListTypeRegistrationsError = CFNRegistryException | CommonErrors;
/**
 * Returns a list of registration tokens for the specified extension(s).
 */
export declare const listTypeRegistrations: API.PaginatedOperationMethod<ListTypeRegistrationsInput, ListTypeRegistrationsOutput, ListTypeRegistrationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTypesError = CFNRegistryException | CommonErrors;
/**
 * Returns summary information about all extensions, including your private resource types,
 * modules, and Hooks as well as all public extensions from Amazon Web Services and third-party
 * publishers.
 */
export declare const listTypes: API.PaginatedOperationMethod<ListTypesInput, ListTypesOutput, ListTypesError, Credentials | HttpClient.HttpClient, TypeSummary>;
export type ListTypeVersionsError = CFNRegistryException | CommonErrors;
/**
 * Returns summary information about the versions of an extension.
 */
export declare const listTypeVersions: API.PaginatedOperationMethod<ListTypeVersionsInput, ListTypeVersionsOutput, ListTypeVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PublishTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Publishes the specified extension to the CloudFormation registry as a public extension in this
 * Region. Public extensions are available for use by all CloudFormation users. For more information
 * about publishing extensions, see Publishing extensions to
 * make them available for public use in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 *
 * To publish an extension, you must be registered as a publisher with CloudFormation. For more
 * information, see RegisterPublisher.
 */
export declare const publishType: API.OperationMethod<PublishTypeInput, PublishTypeOutput, PublishTypeError, Credentials | HttpClient.HttpClient>;
export type RecordHandlerProgressError = InvalidStateTransitionException | OperationStatusCheckFailedException | CommonErrors;
/**
 * Reports progress of a resource handler to CloudFormation.
 *
 * Reserved for use by the CloudFormation
 * CLI. Don't use this API in your code.
 */
export declare const recordHandlerProgress: API.OperationMethod<RecordHandlerProgressInput, RecordHandlerProgressOutput, RecordHandlerProgressError, Credentials | HttpClient.HttpClient>;
export type RegisterPublisherError = CFNRegistryException | CommonErrors;
/**
 * Registers your account as a publisher of public extensions in the CloudFormation registry.
 * Public extensions are available for use by all CloudFormation users. This publisher ID applies to
 * your account in all Amazon Web Services Regions.
 *
 * For information about requirements for registering as a public extension publisher, see
 * Prerequisite: Registering your account to publish CloudFormation extensions in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 */
export declare const registerPublisher: API.OperationMethod<RegisterPublisherInput, RegisterPublisherOutput, RegisterPublisherError, Credentials | HttpClient.HttpClient>;
export type RegisterTypeError = CFNRegistryException | CommonErrors;
/**
 * Registers an extension with the CloudFormation service. Registering an extension makes it
 * available for use in CloudFormation templates in your Amazon Web Services account, and includes:
 *
 * - Validating the extension schema.
 *
 * - Determining which handlers, if any, have been specified for the extension.
 *
 * - Making the extension available for use in your account.
 *
 * For more information about how to develop extensions and ready them for registration, see
 * Creating resource types using the CloudFormation CLI in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 *
 * You can have a maximum of 50 resource extension versions registered at a time. This
 * maximum is per account and per Region. Use DeregisterType
 * to deregister specific extension versions if necessary.
 *
 * Once you have initiated a registration request using RegisterType, you
 * can use DescribeTypeRegistration to monitor the progress of the registration
 * request.
 *
 * Once you have registered a private extension in your account and Region, use SetTypeConfiguration to specify configuration properties for the extension. For
 * more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 */
export declare const registerType: API.OperationMethod<RegisterTypeInput, RegisterTypeOutput, RegisterTypeError, Credentials | HttpClient.HttpClient>;
export type RollbackStackError = TokenAlreadyExistsException | CommonErrors;
/**
 * When specifying `RollbackStack`, you preserve the state of previously
 * provisioned resources when an operation fails. You can check the status of the stack through
 * the DescribeStacks operation.
 *
 * Rolls back the specified stack to the last known stable state from
 * `CREATE_FAILED` or `UPDATE_FAILED` stack statuses.
 *
 * This operation will delete a stack if it doesn't contain a last known stable state. A last
 * known stable state includes any status in a `*_COMPLETE`. This includes the
 * following stack statuses.
 *
 * - `CREATE_COMPLETE`
 *
 * - `UPDATE_COMPLETE`
 *
 * - `UPDATE_ROLLBACK_COMPLETE`
 *
 * - `IMPORT_COMPLETE`
 *
 * - `IMPORT_ROLLBACK_COMPLETE`
 */
export declare const rollbackStack: API.OperationMethod<RollbackStackInput, RollbackStackOutput, RollbackStackError, Credentials | HttpClient.HttpClient>;
export type SetStackPolicyError = CommonErrors;
/**
 * Sets a stack policy for a specified stack.
 */
export declare const setStackPolicy: API.OperationMethod<SetStackPolicyInput, SetStackPolicyResponse, SetStackPolicyError, Credentials | HttpClient.HttpClient>;
export type SetTypeConfigurationError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Specifies the configuration data for a CloudFormation extension, such as a resource or Hook,
 * in the given account and Region.
 *
 * For more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 *
 * To view the current configuration data for an extension, refer to the
 * `ConfigurationSchema` element of DescribeType.
 *
 * It's strongly recommended that you use dynamic references to restrict sensitive
 * configuration definitions, such as third-party credentials. For more information, see Specify values stored in other services using dynamic references in the
 * *CloudFormation User Guide*.
 *
 * For more information about setting the configuration data for resource types, see Defining the account-level configuration of an extension in the
 * *CloudFormation Command Line Interface (CLI) User Guide*. For more information about setting the configuration
 * data for Hooks, see the CloudFormation Hooks User Guide.
 */
export declare const setTypeConfiguration: API.OperationMethod<SetTypeConfigurationInput, SetTypeConfigurationOutput, SetTypeConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetTypeDefaultVersionError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Specify the default version of an extension. The default version of an extension will be
 * used in CloudFormation operations.
 */
export declare const setTypeDefaultVersion: API.OperationMethod<SetTypeDefaultVersionInput, SetTypeDefaultVersionOutput, SetTypeDefaultVersionError, Credentials | HttpClient.HttpClient>;
export type SignalResourceError = CommonErrors;
/**
 * Sends a signal to the specified resource with a success or failure status. You can use the
 * `SignalResource` operation in conjunction with a creation policy or update
 * policy. CloudFormation doesn't proceed with a stack creation or update until resources receive the
 * required number of signals or the timeout period is exceeded. The `SignalResource`
 * operation is useful in cases where you want to send signals from anywhere other than an Amazon EC2
 * instance.
 */
export declare const signalResource: API.OperationMethod<SignalResourceInput, SignalResourceResponse, SignalResourceError, Credentials | HttpClient.HttpClient>;
export type StartResourceScanError = ResourceScanInProgressException | ResourceScanLimitExceededException | CommonErrors;
/**
 * Starts a scan of the resources in this account in this Region. You can the status of a
 * scan using the `ListResourceScans` API action.
 */
export declare const startResourceScan: API.OperationMethod<StartResourceScanInput, StartResourceScanOutput, StartResourceScanError, Credentials | HttpClient.HttpClient>;
export type StopStackSetOperationError = InvalidOperationException | OperationNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Stops an in-progress operation on a StackSet and its associated stack instances. StackSets
 * will cancel all the unstarted stack instance deployments and wait for those are in-progress to
 * complete.
 */
export declare const stopStackSetOperation: API.OperationMethod<StopStackSetOperationInput, StopStackSetOperationOutput, StopStackSetOperationError, Credentials | HttpClient.HttpClient>;
export type TestTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Tests a registered extension to make sure it meets all necessary requirements for being
 * published in the CloudFormation registry.
 *
 * - For resource types, this includes passing all contracts tests defined for the
 * type.
 *
 * - For modules, this includes determining if the module's model meets all necessary
 * requirements.
 *
 * For more information, see Testing your public extension before publishing in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 *
 * If you don't specify a version, CloudFormation uses the default version of the extension in
 * your account and Region for testing.
 *
 * To perform testing, CloudFormation assumes the execution role specified when the type was
 * registered. For more information, see RegisterType.
 *
 * Once you've initiated testing on an extension using `TestType`, you can pass
 * the returned `TypeVersionArn` into DescribeType to
 * monitor the current test status and test status description for the extension.
 *
 * An extension must have a test status of `PASSED` before it can be published.
 * For more information, see Publishing extensions
 * to make them available for public use in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 */
export declare const testType: API.OperationMethod<TestTypeInput, TestTypeOutput, TestTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateGeneratedTemplateError = AlreadyExistsException | GeneratedTemplateNotFoundException | LimitExceededException | CommonErrors;
/**
 * Updates a generated template. This can be used to change the name, add and remove
 * resources, refresh resources, and change the `DeletionPolicy` and
 * `UpdateReplacePolicy` settings. You can check the status of the update to the
 * generated template using the `DescribeGeneratedTemplate` API action.
 */
export declare const updateGeneratedTemplate: API.OperationMethod<UpdateGeneratedTemplateInput, UpdateGeneratedTemplateOutput, UpdateGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateStackError = InsufficientCapabilitiesException | TokenAlreadyExistsException | NoUpdateToPerform | CommonErrors;
/**
 * Updates a stack as specified in the template. After the call completes successfully, the
 * stack update starts. You can check the status of the stack through the DescribeStacks action.
 *
 * To get a copy of the template for an existing stack, you can use the GetTemplate action.
 *
 * For more information about updating a stack and monitoring the progress of the update, see
 * Managing
 * Amazon Web Services resources as a single unit with CloudFormation stacks in the
 * *CloudFormation User Guide*.
 */
export declare const updateStack: API.OperationMethod<UpdateStackInput, UpdateStackOutput, UpdateStackError, Credentials | HttpClient.HttpClient>;
export type UpdateStackInstancesError = InvalidOperationException | OperationIdAlreadyExistsException | OperationInProgressException | StackInstanceNotFoundException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Updates the parameter values for stack instances for the specified accounts, within the
 * specified Amazon Web Services Regions. A stack instance refers to a stack in a specific account and
 * Region.
 *
 * You can only update stack instances in Amazon Web Services Regions and accounts where they already
 * exist; to create additional stack instances, use CreateStackInstances.
 *
 * During StackSet updates, any parameters overridden for a stack instance aren't updated,
 * but retain their overridden value.
 *
 * You can only update the parameter *values* that are specified in the
 * StackSet. To add or delete a parameter itself, use UpdateStackSet
 * to update the StackSet template. If you add a parameter to a template, before you can override
 * the parameter value specified in the StackSet you must first use UpdateStackSet
 * to update all stack instances with the updated template and parameter value specified in the
 * StackSet. Once a stack instance has been updated with the new parameter, you can then override
 * the parameter value using `UpdateStackInstances`.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `UpdateStackInstances` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const updateStackInstances: API.OperationMethod<UpdateStackInstancesInput, UpdateStackInstancesOutput, UpdateStackInstancesError, Credentials | HttpClient.HttpClient>;
export type UpdateStackSetError = InvalidOperationException | OperationIdAlreadyExistsException | OperationInProgressException | StackInstanceNotFoundException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Updates the StackSet and associated stack instances in the specified accounts and
 * Amazon Web Services Regions.
 *
 * Even if the StackSet operation created by updating the StackSet fails (completely or
 * partially, below or above a specified failure tolerance), the StackSet is updated with your
 * changes. Subsequent CreateStackInstances calls on the specified StackSet use
 * the updated StackSet.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `UpdateStackSet` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const updateStackSet: API.OperationMethod<UpdateStackSetInput, UpdateStackSetOutput, UpdateStackSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTerminationProtectionError = CommonErrors;
/**
 * Updates termination protection for the specified stack. If a user attempts to delete a
 * stack with termination protection enabled, the operation fails and the stack remains
 * unchanged. For more information, see Protect a CloudFormation
 * stack from being deleted in the *CloudFormation User Guide*.
 *
 * For nested stacks,
 * termination protection is set on the root stack and can't be changed directly on the nested
 * stack.
 */
export declare const updateTerminationProtection: API.OperationMethod<UpdateTerminationProtectionInput, UpdateTerminationProtectionOutput, UpdateTerminationProtectionError, Credentials | HttpClient.HttpClient>;
export type ValidateTemplateError = CommonErrors;
/**
 * Validates a specified template. CloudFormation first checks if the template is valid JSON. If
 * it isn't, CloudFormation checks if the template is valid YAML. If both these checks fail,
 * CloudFormation returns a template validation error.
 */
export declare const validateTemplate: API.OperationMethod<ValidateTemplateInput, ValidateTemplateOutput, ValidateTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudformation.d.ts.map