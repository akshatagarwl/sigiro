import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DirectoryUnavailableException_base: S.Class<DirectoryUnavailableException, S.TaggedStruct<"DirectoryUnavailableException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DirectoryUnavailableException extends /*@__PURE__*/ DirectoryUnavailableException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DirectoryId = string;
export type GroupName = string;
export type MemberName = string;
export type Realm = string;
export type ClientToken = string;
export interface AddGroupMemberRequest {
    DirectoryId: string;
    GroupName: string;
    MemberName: string;
    MemberRealm?: string;
    ClientToken?: string;
}
export declare const AddGroupMemberRequest: S.Schema<AddGroupMemberRequest>;
export interface AddGroupMemberResult {
}
export declare const AddGroupMemberResult: S.Schema<AddGroupMemberResult>;
export type GroupType = "Distribution" | "Security" | (string & {});
export declare const GroupType: any;
export type GroupScope = "DomainLocal" | "Global" | "Universal" | "BuiltinLocal" | (string & {});
export declare const GroupScope: any;
export type LdapDisplayName = string;
export type StringAttributeValue = string | redacted.Redacted<string>;
export type NumberAttributeValue = number;
export type BooleanAttributeValue = boolean;
export type StringSetAttributeValue = (string | redacted.Redacted<string>)[];
export declare const StringSetAttributeValue: any;
export type AttributeValue = {
    S: string | redacted.Redacted<string>;
    N?: never;
    BOOL?: never;
    SS?: never;
} | {
    S?: never;
    N: number;
    BOOL?: never;
    SS?: never;
} | {
    S?: never;
    N?: never;
    BOOL: boolean;
    SS?: never;
} | {
    S?: never;
    N?: never;
    BOOL?: never;
    SS: (string | redacted.Redacted<string>)[];
};
export declare const AttributeValue: any;
export type Attributes = {
    [key: string]: AttributeValue | undefined;
};
export declare const Attributes: any;
export interface CreateGroupRequest {
    DirectoryId: string;
    SAMAccountName: string;
    GroupType?: GroupType;
    GroupScope?: GroupScope;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
    ClientToken?: string;
}
export declare const CreateGroupRequest: S.Schema<CreateGroupRequest>;
export type SID = string;
export interface CreateGroupResult {
    DirectoryId?: string;
    SAMAccountName?: string;
    SID?: string;
}
export declare const CreateGroupResult: S.Schema<CreateGroupResult>;
export type UserName = string;
export type EmailAddress = string | redacted.Redacted<string>;
export type GivenName = string | redacted.Redacted<string>;
export type Surname = string | redacted.Redacted<string>;
export interface CreateUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    EmailAddress?: string | redacted.Redacted<string>;
    GivenName?: string | redacted.Redacted<string>;
    Surname?: string | redacted.Redacted<string>;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
    ClientToken?: string;
}
export declare const CreateUserRequest: S.Schema<CreateUserRequest>;
export interface CreateUserResult {
    DirectoryId?: string;
    SID?: string;
    SAMAccountName?: string;
}
export declare const CreateUserResult: S.Schema<CreateUserResult>;
export interface DeleteGroupRequest {
    DirectoryId: string;
    SAMAccountName: string;
    ClientToken?: string;
}
export declare const DeleteGroupRequest: S.Schema<DeleteGroupRequest>;
export interface DeleteGroupResult {
}
export declare const DeleteGroupResult: S.Schema<DeleteGroupResult>;
export interface DeleteUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    ClientToken?: string;
}
export declare const DeleteUserRequest: S.Schema<DeleteUserRequest>;
export interface DeleteUserResult {
}
export declare const DeleteUserResult: S.Schema<DeleteUserResult>;
export type LdapDisplayNameList = string[];
export declare const LdapDisplayNameList: any;
export interface DescribeGroupRequest {
    DirectoryId: string;
    Realm?: string;
    SAMAccountName: string;
    OtherAttributes?: string[];
}
export declare const DescribeGroupRequest: S.Schema<DescribeGroupRequest>;
export type DistinguishedName = string | redacted.Redacted<string>;
export interface DescribeGroupResult {
    DirectoryId?: string;
    Realm?: string;
    SID?: string;
    SAMAccountName?: string;
    DistinguishedName?: string | redacted.Redacted<string>;
    GroupType?: GroupType;
    GroupScope?: GroupScope;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const DescribeGroupResult: S.Schema<DescribeGroupResult>;
export interface DescribeUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    OtherAttributes?: string[];
    Realm?: string;
}
export declare const DescribeUserRequest: S.Schema<DescribeUserRequest>;
export type UserPrincipalName = string | redacted.Redacted<string>;
export interface DescribeUserResult {
    DirectoryId?: string;
    Realm?: string;
    SID?: string;
    SAMAccountName?: string;
    DistinguishedName?: string | redacted.Redacted<string>;
    UserPrincipalName?: string | redacted.Redacted<string>;
    EmailAddress?: string | redacted.Redacted<string>;
    GivenName?: string | redacted.Redacted<string>;
    Surname?: string | redacted.Redacted<string>;
    Enabled?: boolean;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const DescribeUserResult: S.Schema<DescribeUserResult>;
export interface DisableUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    ClientToken?: string;
}
export declare const DisableUserRequest: S.Schema<DisableUserRequest>;
export interface DisableUserResult {
}
export declare const DisableUserResult: S.Schema<DisableUserResult>;
export type NextToken = string | redacted.Redacted<string>;
export type MaxResults = number;
export interface ListGroupMembersRequest {
    DirectoryId: string;
    Realm?: string;
    MemberRealm?: string;
    SAMAccountName: string;
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export declare const ListGroupMembersRequest: S.Schema<ListGroupMembersRequest>;
export type MemberType = "USER" | "GROUP" | "COMPUTER" | (string & {});
export declare const MemberType: any;
export interface Member {
    SID: string;
    SAMAccountName: string;
    MemberType: MemberType;
}
export declare const Member: S.Schema<Member>;
export type MemberList = Member[];
export declare const MemberList: any;
export interface ListGroupMembersResult {
    DirectoryId?: string;
    Realm?: string;
    MemberRealm?: string;
    Members?: Member[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListGroupMembersResult: S.Schema<ListGroupMembersResult>;
export interface ListGroupsRequest {
    DirectoryId: string;
    Realm?: string;
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export declare const ListGroupsRequest: S.Schema<ListGroupsRequest>;
export interface GroupSummary {
    SID: string;
    SAMAccountName: string;
    GroupType: GroupType;
    GroupScope: GroupScope;
}
export declare const GroupSummary: S.Schema<GroupSummary>;
export type GroupSummaryList = GroupSummary[];
export declare const GroupSummaryList: any;
export interface ListGroupsResult {
    DirectoryId?: string;
    Realm?: string;
    Groups?: GroupSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListGroupsResult: S.Schema<ListGroupsResult>;
export interface ListGroupsForMemberRequest {
    DirectoryId: string;
    Realm?: string;
    MemberRealm?: string;
    SAMAccountName: string;
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export declare const ListGroupsForMemberRequest: S.Schema<ListGroupsForMemberRequest>;
export interface ListGroupsForMemberResult {
    DirectoryId?: string;
    Realm?: string;
    MemberRealm?: string;
    Groups?: GroupSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListGroupsForMemberResult: S.Schema<ListGroupsForMemberResult>;
export interface ListUsersRequest {
    DirectoryId: string;
    Realm?: string;
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export declare const ListUsersRequest: S.Schema<ListUsersRequest>;
export interface UserSummary {
    SID: string;
    SAMAccountName: string;
    GivenName?: string | redacted.Redacted<string>;
    Surname?: string | redacted.Redacted<string>;
    Enabled: boolean;
}
export declare const UserSummary: S.Schema<UserSummary>;
export type UserSummaryList = UserSummary[];
export declare const UserSummaryList: any;
export interface ListUsersResult {
    DirectoryId?: string;
    Realm?: string;
    Users?: UserSummary[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const ListUsersResult: S.Schema<ListUsersResult>;
export interface RemoveGroupMemberRequest {
    DirectoryId: string;
    GroupName: string;
    MemberName: string;
    MemberRealm?: string;
    ClientToken?: string;
}
export declare const RemoveGroupMemberRequest: S.Schema<RemoveGroupMemberRequest>;
export interface RemoveGroupMemberResult {
}
export declare const RemoveGroupMemberResult: S.Schema<RemoveGroupMemberResult>;
export type SearchString = string | redacted.Redacted<string>;
export interface SearchGroupsRequest {
    DirectoryId: string;
    SearchString: string | redacted.Redacted<string>;
    SearchAttributes: string[];
    Realm?: string;
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export declare const SearchGroupsRequest: S.Schema<SearchGroupsRequest>;
export interface Group {
    SID?: string;
    SAMAccountName: string;
    DistinguishedName?: string | redacted.Redacted<string>;
    GroupType?: GroupType;
    GroupScope?: GroupScope;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const Group: S.Schema<Group>;
export type GroupList = Group[];
export declare const GroupList: any;
export interface SearchGroupsResult {
    DirectoryId?: string;
    Realm?: string;
    Groups?: Group[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const SearchGroupsResult: S.Schema<SearchGroupsResult>;
export interface SearchUsersRequest {
    DirectoryId: string;
    Realm?: string;
    SearchString: string | redacted.Redacted<string>;
    SearchAttributes: string[];
    NextToken?: string | redacted.Redacted<string>;
    MaxResults?: number;
}
export declare const SearchUsersRequest: S.Schema<SearchUsersRequest>;
export interface User {
    SID?: string;
    SAMAccountName: string;
    DistinguishedName?: string | redacted.Redacted<string>;
    UserPrincipalName?: string | redacted.Redacted<string>;
    EmailAddress?: string | redacted.Redacted<string>;
    GivenName?: string | redacted.Redacted<string>;
    Surname?: string | redacted.Redacted<string>;
    Enabled?: boolean;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const User: S.Schema<User>;
export type UserList = User[];
export declare const UserList: any;
export interface SearchUsersResult {
    DirectoryId?: string;
    Realm?: string;
    Users?: User[];
    NextToken?: string | redacted.Redacted<string>;
}
export declare const SearchUsersResult: S.Schema<SearchUsersResult>;
export type UpdateType = "ADD" | "REPLACE" | "REMOVE" | (string & {});
export declare const UpdateType: any;
export interface UpdateGroupRequest {
    DirectoryId: string;
    SAMAccountName: string;
    GroupType?: GroupType;
    GroupScope?: GroupScope;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
    UpdateType?: UpdateType;
    ClientToken?: string;
}
export declare const UpdateGroupRequest: S.Schema<UpdateGroupRequest>;
export interface UpdateGroupResult {
}
export declare const UpdateGroupResult: S.Schema<UpdateGroupResult>;
export interface UpdateUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    EmailAddress?: string | redacted.Redacted<string>;
    GivenName?: string | redacted.Redacted<string>;
    Surname?: string | redacted.Redacted<string>;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    };
    UpdateType?: UpdateType;
    ClientToken?: string;
}
export declare const UpdateUserRequest: S.Schema<UpdateUserRequest>;
export interface UpdateUserResult {
}
export declare const UpdateUserResult: S.Schema<UpdateUserResult>;
export type ExceptionMessage = string;
export type AccessDeniedReason = "IAM_AUTH" | "DIRECTORY_AUTH" | "DATA_DISABLED" | (string & {});
export declare const AccessDeniedReason: any;
export type DirectoryUnavailableReason = "INVALID_DIRECTORY_STATE" | "DIRECTORY_TIMEOUT" | "DIRECTORY_RESOURCES_EXCEEDED" | "NO_DISK_SPACE" | "TRUST_AUTH_FAILURE" | (string & {});
export declare const DirectoryUnavailableReason: any;
export type ValidationExceptionReason = "INVALID_REALM" | "INVALID_DIRECTORY_TYPE" | "INVALID_SECONDARY_REGION" | "INVALID_NEXT_TOKEN" | "INVALID_ATTRIBUTE_VALUE" | "INVALID_ATTRIBUTE_NAME" | "INVALID_ATTRIBUTE_FOR_USER" | "INVALID_ATTRIBUTE_FOR_GROUP" | "INVALID_ATTRIBUTE_FOR_SEARCH" | "INVALID_ATTRIBUTE_FOR_MODIFY" | "DUPLICATE_ATTRIBUTE" | "MISSING_ATTRIBUTE" | "ATTRIBUTE_EXISTS" | "LDAP_SIZE_LIMIT_EXCEEDED" | "LDAP_UNSUPPORTED_OPERATION" | (string & {});
export declare const ValidationExceptionReason: any;
export type AddGroupMemberError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds an existing user, group, or computer as a group member.
 */
export declare const addGroupMember: API.OperationMethod<AddGroupMemberRequest, AddGroupMemberResult, AddGroupMemberError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new group.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest, CreateGroupResult, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new user.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest, CreateUserResult, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a group.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest, DeleteGroupResult, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a user.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest, DeleteUserResult, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific group.
 */
export declare const describeGroup: API.OperationMethod<DescribeGroupRequest, DescribeGroupResult, DescribeGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific user.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest, DescribeUserResult, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type DisableUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deactivates an active user account. For information about how to enable an inactive user
 * account, see ResetUserPassword
 * in the *Directory Service API Reference*.
 */
export declare const disableUser: API.OperationMethod<DisableUserRequest, DisableUserResult, DisableUserError, Credentials | HttpClient.HttpClient>;
export type ListGroupMembersError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns member information for the specified group.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the
 * `ListGroupMembers.NextToken` member contains a token that you pass in the next
 * call to `ListGroupMembers`. This retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listGroupMembers: API.PaginatedOperationMethod<ListGroupMembersRequest, ListGroupMembersResult, ListGroupMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListGroupsError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns group information for the specified directory.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `ListGroups.NextToken`
 * member contains a token that you pass in the next call to `ListGroups`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest, ListGroupsResult, ListGroupsError, Credentials | HttpClient.HttpClient, GroupSummary>;
export type ListGroupsForMemberError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns group information for the specified member.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the
 * `ListGroupsForMember.NextToken` member contains a token that you pass in the next
 * call to `ListGroupsForMember`. This retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listGroupsForMember: API.PaginatedOperationMethod<ListGroupsForMemberRequest, ListGroupsForMemberResult, ListGroupsForMemberError, Credentials | HttpClient.HttpClient, GroupSummary>;
export type ListUsersError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns user information for the specified directory.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `ListUsers.NextToken`
 * member contains a token that you pass in the next call to `ListUsers`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest, ListUsersResult, ListUsersError, Credentials | HttpClient.HttpClient, UserSummary>;
export type RemoveGroupMemberError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a member from a group.
 */
export declare const removeGroupMember: API.OperationMethod<RemoveGroupMemberRequest, RemoveGroupMemberResult, RemoveGroupMemberError, Credentials | HttpClient.HttpClient>;
export type SearchGroupsError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches the specified directory for a group. You can find groups that match the
 * `SearchString` parameter with the value of their attributes included in the
 * `SearchString` parameter.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `SearchGroups.NextToken`
 * member contains a token that you pass in the next call to `SearchGroups`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const searchGroups: API.PaginatedOperationMethod<SearchGroupsRequest, SearchGroupsResult, SearchGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type SearchUsersError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches the specified directory for a user. You can find users that match the
 * `SearchString` parameter with the value of their attributes included in the
 * `SearchString` parameter.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `SearchUsers.NextToken`
 * member contains a token that you pass in the next call to `SearchUsers`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const searchUsers: API.PaginatedOperationMethod<SearchUsersRequest, SearchUsersResult, SearchUsersError, Credentials | HttpClient.HttpClient, User>;
export type UpdateGroupError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates group information.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest, UpdateGroupResult, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates user information.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest, UpdateUserResult, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=directory-service-data.d.ts.map