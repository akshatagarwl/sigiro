import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
export type DirectConnectGatewayAttachPoint = string;
export type AmazonResourceName = string;
export type AttachPoint = {
    directConnectGateway: string;
    arn?: never;
} | {
    directConnectGateway?: never;
    arn: string;
};
export declare const AttachPoint: any;
export type ActivationKey = string | redacted.Redacted<string>;
export type ConnectionDescription = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface AcceptConnectionProposalRequest {
    attachPoint: AttachPoint;
    activationKey: string | redacted.Redacted<string>;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const AcceptConnectionProposalRequest: S.Schema<AcceptConnectionProposalRequest>;
export type ConnectionId = string;
export type ConnectionBandwidth = string;
export type EnvironmentId = string;
export type CloudServiceProvider = string;
export type LastMileProvider = string;
export type Provider = {
    cloudServiceProvider: string;
    lastMileProvider?: never;
} | {
    cloudServiceProvider?: never;
    lastMileProvider: string;
};
export declare const Provider: any;
export type Location = string;
export type ProductType = string;
export type ConnectionState = "available" | "requested" | "pending" | "down" | "deleting" | "deleted" | "failed" | "updating" | (string & {});
export declare const ConnectionState: any;
export type ConnectionSharedId = string;
export type BillingTier = number;
export type OwnerAccountId = string;
export interface Connection {
    id: string;
    arn: string;
    description: string;
    bandwidth: string;
    attachPoint: AttachPoint;
    environmentId: string;
    provider: Provider;
    location: string;
    type: string;
    state: ConnectionState;
    sharedId: string;
    billingTier?: number;
    ownerAccount: string;
    activationKey: string | redacted.Redacted<string>;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Connection: S.Schema<Connection>;
export interface AcceptConnectionProposalResponse {
    connection?: Connection;
}
export declare const AcceptConnectionProposalResponse: S.Schema<AcceptConnectionProposalResponse>;
export type RemoteOwnerAccount = string;
export type RemoteAccountIdentifier = {
    identifier: string;
};
export declare const RemoteAccountIdentifier: any;
export interface CreateConnectionRequest {
    description?: string;
    bandwidth: string;
    attachPoint: AttachPoint;
    environmentId: string;
    remoteAccount?: RemoteAccountIdentifier;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateConnectionRequest: S.Schema<CreateConnectionRequest>;
export interface CreateConnectionResponse {
    connection?: Connection;
}
export declare const CreateConnectionResponse: S.Schema<CreateConnectionResponse>;
export interface DeleteConnectionRequest {
    identifier: string;
    clientToken?: string;
}
export declare const DeleteConnectionRequest: S.Schema<DeleteConnectionRequest>;
export interface DeleteConnectionResponse {
    connection: Connection;
}
export declare const DeleteConnectionResponse: S.Schema<DeleteConnectionResponse>;
export interface DescribeConnectionProposalRequest {
    activationKey: string | redacted.Redacted<string>;
}
export declare const DescribeConnectionProposalRequest: S.Schema<DescribeConnectionProposalRequest>;
export interface DescribeConnectionProposalResponse {
    bandwidth: string;
    environmentId: string;
    provider: Provider;
    location: string;
}
export declare const DescribeConnectionProposalResponse: S.Schema<DescribeConnectionProposalResponse>;
export interface GetConnectionRequest {
    identifier: string;
}
export declare const GetConnectionRequest: S.Schema<GetConnectionRequest>;
export interface GetConnectionResponse {
    connection?: Connection;
}
export declare const GetConnectionResponse: S.Schema<GetConnectionResponse>;
export interface GetEnvironmentRequest {
    id: string;
}
export declare const GetEnvironmentRequest: S.Schema<GetEnvironmentRequest>;
export type EnvironmentState = "available" | "limited" | "unavailable" | (string & {});
export declare const EnvironmentState: any;
export type BandwidthList = string[];
export declare const BandwidthList: any;
export interface Bandwidths {
    available?: string[];
    supported?: string[];
}
export declare const Bandwidths: S.Schema<Bandwidths>;
export type RemoteAccountIdentifierType = "account" | "email" | (string & {});
export declare const RemoteAccountIdentifierType: any;
export interface Environment {
    provider: Provider;
    location: string;
    environmentId: string;
    state: EnvironmentState;
    bandwidths: Bandwidths;
    type: string;
    activationPageUrl?: string;
    remoteIdentifierType?: RemoteAccountIdentifierType;
}
export declare const Environment: S.Schema<Environment>;
export interface GetEnvironmentResponse {
    environment: Environment;
}
export declare const GetEnvironmentResponse: S.Schema<GetEnvironmentResponse>;
export type MaxResults = number;
export type NextToken = string;
export interface ListAttachPointsRequest {
    environmentId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAttachPointsRequest: S.Schema<ListAttachPointsRequest>;
export type AttachPointType = "DirectConnectGateway" | (string & {});
export declare const AttachPointType: any;
export interface AttachPointDescriptor {
    type: AttachPointType;
    identifier: string;
    name: string;
}
export declare const AttachPointDescriptor: S.Schema<AttachPointDescriptor>;
export type AttachPointDescriptorList = AttachPointDescriptor[];
export declare const AttachPointDescriptorList: any;
export interface ListAttachPointsResponse {
    attachPoints: AttachPointDescriptor[];
    nextToken?: string;
}
export declare const ListAttachPointsResponse: S.Schema<ListAttachPointsResponse>;
export interface ListConnectionsRequest {
    maxResults?: number;
    nextToken?: string;
    state?: ConnectionState;
    environmentId?: string;
    provider?: Provider;
    attachPoint?: AttachPoint;
}
export declare const ListConnectionsRequest: S.Schema<ListConnectionsRequest>;
export interface ConnectionSummary {
    id: string;
    arn: string;
    description: string;
    bandwidth: string;
    attachPoint: AttachPoint;
    environmentId: string;
    provider: Provider;
    location: string;
    type: string;
    state: ConnectionState;
    sharedId: string;
    billingTier?: number;
}
export declare const ConnectionSummary: S.Schema<ConnectionSummary>;
export type ConnectionSummariesList = ConnectionSummary[];
export declare const ConnectionSummariesList: any;
export interface ListConnectionsResponse {
    connections?: ConnectionSummary[];
    nextToken?: string;
}
export declare const ListConnectionsResponse: S.Schema<ListConnectionsResponse>;
export interface ListEnvironmentsRequest {
    maxResults?: number;
    nextToken?: string;
    provider?: Provider;
    location?: string;
}
export declare const ListEnvironmentsRequest: S.Schema<ListEnvironmentsRequest>;
export type EnvironmentList = Environment[];
export declare const EnvironmentList: any;
export interface ListEnvironmentsResponse {
    environments: Environment[];
    nextToken?: string;
}
export declare const ListEnvironmentsResponse: S.Schema<ListEnvironmentsResponse>;
export interface ListTagsForResourceRequest {
    arn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateConnectionRequest {
    identifier: string;
    description?: string;
    bandwidth?: string;
    clientToken?: string;
}
export declare const UpdateConnectionRequest: S.Schema<UpdateConnectionRequest>;
export interface UpdateConnectionResponse {
    connection?: Connection;
}
export declare const UpdateConnectionResponse: S.Schema<UpdateConnectionResponse>;
export type AcceptConnectionProposalError = CommonErrors;
/**
 * Accepts a connection proposal which was generated at a supported partner's portal.
 *
 * The proposal contains the Environment and bandwidth that were chosen on the partner's portal and cannot be modified.
 *
 * Upon accepting the proposal a connection will be made between the AWS network as accessed via the selected Attach Point and the network previously selected network on the partner's portal.
 */
export declare const acceptConnectionProposal: API.OperationMethod<AcceptConnectionProposalRequest, AcceptConnectionProposalResponse, AcceptConnectionProposalError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = CommonErrors;
/**
 * Initiates the process to create a Connection across the specified Environment.
 *
 * The Environment dictates the specified partner and location to which the other end of the connection should attach. You can see a list of the available Environments by calling ListEnvironments
 *
 * The Attach Point specifies where within the AWS Network your connection will logically connect.
 *
 * After a successful call to this method, the resulting Connection will return an Activation Key which will need to be brought to the specific partner's portal to confirm the Connection on both sides. (See Environment$activationPageUrl for a direct link to the partner portal).
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = CommonErrors;
/**
 * Deletes an existing Connection with the supplied identifier.
 *
 * This operation will also inform the remote partner of your intention to delete your connection. Note, the partner may still require you to delete to fully clean up resources, but the network connectivity provided by the Connection will cease to exist.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionProposalError = CommonErrors;
/**
 * Describes the details of a connection proposal generated at a partner's portal.
 */
export declare const describeConnectionProposal: API.OperationMethod<DescribeConnectionProposalRequest, DescribeConnectionProposalResponse, DescribeConnectionProposalError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = CommonErrors;
/**
 * Describes the current state of a Connection resource as specified by the identifier.
 */
export declare const getConnection: API.OperationMethod<GetConnectionRequest, GetConnectionResponse, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = CommonErrors;
/**
 * Describes a specific Environment
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type ListAttachPointsError = CommonErrors;
/**
 * Lists all Attach Points the caller has access to that are valid for the specified Environment.
 */
export declare const listAttachPoints: API.PaginatedOperationMethod<ListAttachPointsRequest, ListAttachPointsResponse, ListAttachPointsError, Credentials | HttpClient.HttpClient, AttachPointDescriptor>;
export type ListConnectionsError = CommonErrors;
/**
 * Lists all connection objects to which the caller has access.
 *
 * Allows for optional filtering by the following properties:
 *
 * - `state`
 *
 * - `environmentId`
 *
 * - `provider`
 *
 * - `attach point`
 *
 * Only Connection objects matching all filters will be returned.
 */
export declare const listConnections: API.PaginatedOperationMethod<ListConnectionsRequest, ListConnectionsResponse, ListConnectionsError, Credentials | HttpClient.HttpClient, ConnectionSummary>;
export type ListEnvironmentsError = CommonErrors;
/**
 * Lists all of the environments that can produce connections that will land in the called AWS region.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient, Environment>;
export type ListTagsForResourceError = CommonErrors;
/**
 * List all current tags on the specified resource. Currently this supports Connection resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * Add new tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = CommonErrors;
/**
 * Modifies an existing connection. Currently we support modifications to the connection's description and/or bandwidth.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest, UpdateConnectionResponse, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
//# sourceMappingURL=interconnect.d.ts.map