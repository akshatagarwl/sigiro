import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
    readonly RetryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TopicArn = string;
export interface SnsChannelConfig {
    TopicArn?: string;
}
export declare const SnsChannelConfig: S.Schema<SnsChannelConfig>;
export type InsightSeverity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export declare const InsightSeverity: any;
export type InsightSeverities = InsightSeverity[];
export declare const InsightSeverities: any;
export type NotificationMessageType = "NEW_INSIGHT" | "CLOSED_INSIGHT" | "NEW_ASSOCIATION" | "SEVERITY_UPGRADED" | "NEW_RECOMMENDATION" | (string & {});
export declare const NotificationMessageType: any;
export type NotificationMessageTypes = NotificationMessageType[];
export declare const NotificationMessageTypes: any;
export interface NotificationFilterConfig {
    Severities?: InsightSeverity[];
    MessageTypes?: NotificationMessageType[];
}
export declare const NotificationFilterConfig: S.Schema<NotificationFilterConfig>;
export interface NotificationChannelConfig {
    Sns: SnsChannelConfig;
    Filters?: NotificationFilterConfig;
}
export declare const NotificationChannelConfig: S.Schema<NotificationChannelConfig>;
export interface AddNotificationChannelRequest {
    Config: NotificationChannelConfig;
}
export declare const AddNotificationChannelRequest: S.Schema<AddNotificationChannelRequest>;
export type NotificationChannelId = string;
export interface AddNotificationChannelResponse {
    Id: string;
}
export declare const AddNotificationChannelResponse: S.Schema<AddNotificationChannelResponse>;
export type InsightId = string;
export interface DeleteInsightRequest {
    Id: string;
}
export declare const DeleteInsightRequest: S.Schema<DeleteInsightRequest>;
export interface DeleteInsightResponse {
}
export declare const DeleteInsightResponse: S.Schema<DeleteInsightResponse>;
export interface DescribeAccountHealthRequest {
}
export declare const DescribeAccountHealthRequest: S.Schema<DescribeAccountHealthRequest>;
export type NumOpenReactiveInsights = number;
export type NumOpenProactiveInsights = number;
export type NumMetricsAnalyzed = number;
export type ResourceHours = number;
export type AnalyzedResourceCount = number;
export interface DescribeAccountHealthResponse {
    OpenReactiveInsights: number;
    OpenProactiveInsights: number;
    MetricsAnalyzed: number;
    ResourceHours: number;
    AnalyzedResourceCount?: number;
}
export declare const DescribeAccountHealthResponse: S.Schema<DescribeAccountHealthResponse>;
export interface DescribeAccountOverviewRequest {
    FromTime: Date;
    ToTime?: Date;
}
export declare const DescribeAccountOverviewRequest: S.Schema<DescribeAccountOverviewRequest>;
export type NumReactiveInsights = number;
export type NumProactiveInsights = number;
export type MeanTimeToRecoverInMilliseconds = number;
export interface DescribeAccountOverviewResponse {
    ReactiveInsights: number;
    ProactiveInsights: number;
    MeanTimeToRecoverInMilliseconds: number;
}
export declare const DescribeAccountOverviewResponse: S.Schema<DescribeAccountOverviewResponse>;
export type AnomalyId = string;
export type AwsAccountId = string;
export interface DescribeAnomalyRequest {
    Id: string;
    AccountId?: string;
}
export declare const DescribeAnomalyRequest: S.Schema<DescribeAnomalyRequest>;
export type AnomalySeverity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export declare const AnomalySeverity: any;
export type AnomalyStatus = "ONGOING" | "CLOSED" | (string & {});
export declare const AnomalyStatus: any;
export interface AnomalyTimeRange {
    StartTime: Date;
    EndTime?: Date;
}
export declare const AnomalyTimeRange: S.Schema<AnomalyTimeRange>;
export interface AnomalyReportedTimeRange {
    OpenTime: Date;
    CloseTime?: Date;
}
export declare const AnomalyReportedTimeRange: S.Schema<AnomalyReportedTimeRange>;
export interface PredictionTimeRange {
    StartTime: Date;
    EndTime?: Date;
}
export declare const PredictionTimeRange: S.Schema<PredictionTimeRange>;
export type CloudWatchMetricsMetricName = string;
export type CloudWatchMetricsNamespace = string;
export type CloudWatchMetricsDimensionName = string;
export type CloudWatchMetricsDimensionValue = string;
export interface CloudWatchMetricsDimension {
    Name?: string;
    Value?: string;
}
export declare const CloudWatchMetricsDimension: S.Schema<CloudWatchMetricsDimension>;
export type CloudWatchMetricsDimensions = CloudWatchMetricsDimension[];
export declare const CloudWatchMetricsDimensions: any;
export type CloudWatchMetricsStat = "Sum" | "Average" | "SampleCount" | "Minimum" | "Maximum" | "p99" | "p90" | "p50" | (string & {});
export declare const CloudWatchMetricsStat: any;
export type CloudWatchMetricsUnit = string;
export type CloudWatchMetricsPeriod = number;
export type MetricValue = number;
export interface TimestampMetricValuePair {
    Timestamp?: Date;
    MetricValue?: number;
}
export declare const TimestampMetricValuePair: S.Schema<TimestampMetricValuePair>;
export type TimestampMetricValuePairList = TimestampMetricValuePair[];
export declare const TimestampMetricValuePairList: any;
export type CloudWatchMetricDataStatusCode = "Complete" | "InternalError" | "PartialData" | (string & {});
export declare const CloudWatchMetricDataStatusCode: any;
export interface CloudWatchMetricsDataSummary {
    TimestampMetricValuePairList?: TimestampMetricValuePair[];
    StatusCode?: CloudWatchMetricDataStatusCode;
}
export declare const CloudWatchMetricsDataSummary: S.Schema<CloudWatchMetricsDataSummary>;
export interface CloudWatchMetricsDetail {
    MetricName?: string;
    Namespace?: string;
    Dimensions?: CloudWatchMetricsDimension[];
    Stat?: CloudWatchMetricsStat;
    Unit?: string;
    Period?: number;
    MetricDataSummary?: CloudWatchMetricsDataSummary;
}
export declare const CloudWatchMetricsDetail: S.Schema<CloudWatchMetricsDetail>;
export type CloudWatchMetricsDetails = CloudWatchMetricsDetail[];
export declare const CloudWatchMetricsDetails: any;
export type PerformanceInsightsMetricDisplayName = string;
export type PerformanceInsightsMetricUnit = string;
export type PerformanceInsightsMetricName = string;
export type PerformanceInsightsMetricGroup = string;
export type PerformanceInsightsMetricDimension = string;
export type PerformanceInsightsMetricDimensions = string[];
export declare const PerformanceInsightsMetricDimensions: any;
export type PerformanceInsightsMetricLimitInteger = number;
export interface PerformanceInsightsMetricDimensionGroup {
    Group?: string;
    Dimensions?: string[];
    Limit?: number;
}
export declare const PerformanceInsightsMetricDimensionGroup: S.Schema<PerformanceInsightsMetricDimensionGroup>;
export type PerformanceInsightsMetricFilterKey = string;
export type PerformanceInsightsMetricFilterValue = string;
export type PerformanceInsightsMetricFilterMap = {
    [key: string]: string | undefined;
};
export declare const PerformanceInsightsMetricFilterMap: any;
export interface PerformanceInsightsMetricQuery {
    Metric?: string;
    GroupBy?: PerformanceInsightsMetricDimensionGroup;
    Filter?: {
        [key: string]: string | undefined;
    };
}
export declare const PerformanceInsightsMetricQuery: S.Schema<PerformanceInsightsMetricQuery>;
export type PerformanceInsightsReferenceName = string;
export type PerformanceInsightsValueDouble = number;
export interface PerformanceInsightsReferenceScalar {
    Value?: number;
}
export declare const PerformanceInsightsReferenceScalar: S.Schema<PerformanceInsightsReferenceScalar>;
export interface PerformanceInsightsReferenceMetric {
    MetricQuery?: PerformanceInsightsMetricQuery;
}
export declare const PerformanceInsightsReferenceMetric: S.Schema<PerformanceInsightsReferenceMetric>;
export interface PerformanceInsightsReferenceComparisonValues {
    ReferenceScalar?: PerformanceInsightsReferenceScalar;
    ReferenceMetric?: PerformanceInsightsReferenceMetric;
}
export declare const PerformanceInsightsReferenceComparisonValues: S.Schema<PerformanceInsightsReferenceComparisonValues>;
export interface PerformanceInsightsReferenceData {
    Name?: string;
    ComparisonValues?: PerformanceInsightsReferenceComparisonValues;
}
export declare const PerformanceInsightsReferenceData: S.Schema<PerformanceInsightsReferenceData>;
export type PerformanceInsightsReferenceDataList = PerformanceInsightsReferenceData[];
export declare const PerformanceInsightsReferenceDataList: any;
export type PerformanceInsightsStatType = string;
export interface PerformanceInsightsStat {
    Type?: string;
    Value?: number;
}
export declare const PerformanceInsightsStat: S.Schema<PerformanceInsightsStat>;
export type PerformanceInsightsStats = PerformanceInsightsStat[];
export declare const PerformanceInsightsStats: any;
export interface PerformanceInsightsMetricsDetail {
    MetricDisplayName?: string;
    Unit?: string;
    MetricQuery?: PerformanceInsightsMetricQuery;
    ReferenceData?: PerformanceInsightsReferenceData[];
    StatsAtAnomaly?: PerformanceInsightsStat[];
    StatsAtBaseline?: PerformanceInsightsStat[];
}
export declare const PerformanceInsightsMetricsDetail: S.Schema<PerformanceInsightsMetricsDetail>;
export type PerformanceInsightsMetricsDetails = PerformanceInsightsMetricsDetail[];
export declare const PerformanceInsightsMetricsDetails: any;
export interface AnomalySourceDetails {
    CloudWatchMetrics?: CloudWatchMetricsDetail[];
    PerformanceInsightsMetrics?: PerformanceInsightsMetricsDetail[];
}
export declare const AnomalySourceDetails: S.Schema<AnomalySourceDetails>;
export type StackName = string;
export type StackNames = string[];
export declare const StackNames: any;
export interface CloudFormationCollection {
    StackNames?: string[];
}
export declare const CloudFormationCollection: S.Schema<CloudFormationCollection>;
export type AppBoundaryKey = string;
export type TagValue = string;
export type TagValues = string[];
export declare const TagValues: any;
export interface TagCollection {
    AppBoundaryKey: string;
    TagValues: string[];
}
export declare const TagCollection: S.Schema<TagCollection>;
export type TagCollections = TagCollection[];
export declare const TagCollections: any;
export interface ResourceCollection {
    CloudFormation?: CloudFormationCollection;
    Tags?: TagCollection[];
}
export declare const ResourceCollection: S.Schema<ResourceCollection>;
export type AnomalyLimit = number;
export type AnomalySource = string;
export type ResourceName = string;
export type ResourceType = string;
export interface AnomalySourceMetadata {
    Source?: string;
    SourceResourceName?: string;
    SourceResourceType?: string;
}
export declare const AnomalySourceMetadata: S.Schema<AnomalySourceMetadata>;
export interface AnomalyResource {
    Name?: string;
    Type?: string;
}
export declare const AnomalyResource: S.Schema<AnomalyResource>;
export type AnomalyResources = AnomalyResource[];
export declare const AnomalyResources: any;
export type AnomalyDescription = string;
export interface ProactiveAnomaly {
    Id?: string;
    Severity?: AnomalySeverity;
    Status?: AnomalyStatus;
    UpdateTime?: Date;
    AnomalyTimeRange?: AnomalyTimeRange;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange;
    PredictionTimeRange?: PredictionTimeRange;
    SourceDetails?: AnomalySourceDetails;
    AssociatedInsightId?: string;
    ResourceCollection?: ResourceCollection;
    Limit?: number;
    SourceMetadata?: AnomalySourceMetadata;
    AnomalyResources?: AnomalyResource[];
    Description?: string;
}
export declare const ProactiveAnomaly: S.Schema<ProactiveAnomaly>;
export type AnomalyType = "CAUSAL" | "CONTEXTUAL" | (string & {});
export declare const AnomalyType: any;
export type AnomalyName = string;
export interface ReactiveAnomaly {
    Id?: string;
    Severity?: AnomalySeverity;
    Status?: AnomalyStatus;
    AnomalyTimeRange?: AnomalyTimeRange;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange;
    SourceDetails?: AnomalySourceDetails;
    AssociatedInsightId?: string;
    ResourceCollection?: ResourceCollection;
    Type?: AnomalyType;
    Name?: string;
    Description?: string;
    CausalAnomalyId?: string;
    AnomalyResources?: AnomalyResource[];
}
export declare const ReactiveAnomaly: S.Schema<ReactiveAnomaly>;
export interface DescribeAnomalyResponse {
    ProactiveAnomaly?: ProactiveAnomaly;
    ReactiveAnomaly?: ReactiveAnomaly;
}
export declare const DescribeAnomalyResponse: S.Schema<DescribeAnomalyResponse>;
export interface DescribeEventSourcesConfigRequest {
}
export declare const DescribeEventSourcesConfigRequest: S.Schema<DescribeEventSourcesConfigRequest>;
export type EventSourceOptInStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const EventSourceOptInStatus: any;
export interface AmazonCodeGuruProfilerIntegration {
    Status?: EventSourceOptInStatus;
}
export declare const AmazonCodeGuruProfilerIntegration: S.Schema<AmazonCodeGuruProfilerIntegration>;
export interface EventSourcesConfig {
    AmazonCodeGuruProfiler?: AmazonCodeGuruProfilerIntegration;
}
export declare const EventSourcesConfig: S.Schema<EventSourcesConfig>;
export interface DescribeEventSourcesConfigResponse {
    EventSources?: EventSourcesConfig;
}
export declare const DescribeEventSourcesConfigResponse: S.Schema<DescribeEventSourcesConfigResponse>;
export interface DescribeFeedbackRequest {
    InsightId?: string;
}
export declare const DescribeFeedbackRequest: S.Schema<DescribeFeedbackRequest>;
export type InsightFeedbackOption = "VALID_COLLECTION" | "RECOMMENDATION_USEFUL" | "ALERT_TOO_SENSITIVE" | "DATA_NOISY_ANOMALY" | "DATA_INCORRECT" | (string & {});
export declare const InsightFeedbackOption: any;
export interface InsightFeedback {
    Id?: string;
    Feedback?: InsightFeedbackOption;
}
export declare const InsightFeedback: S.Schema<InsightFeedback>;
export interface DescribeFeedbackResponse {
    InsightFeedback?: InsightFeedback;
}
export declare const DescribeFeedbackResponse: S.Schema<DescribeFeedbackResponse>;
export interface DescribeInsightRequest {
    Id: string;
    AccountId?: string;
}
export declare const DescribeInsightRequest: S.Schema<DescribeInsightRequest>;
export type InsightName = string;
export type InsightStatus = "ONGOING" | "CLOSED" | (string & {});
export declare const InsightStatus: any;
export interface InsightTimeRange {
    StartTime: Date;
    EndTime?: Date;
}
export declare const InsightTimeRange: S.Schema<InsightTimeRange>;
export type SsmOpsItemId = string;
export type InsightDescription = string;
export interface ProactiveInsight {
    Id?: string;
    Name?: string;
    Severity?: InsightSeverity;
    Status?: InsightStatus;
    InsightTimeRange?: InsightTimeRange;
    PredictionTimeRange?: PredictionTimeRange;
    ResourceCollection?: ResourceCollection;
    SsmOpsItemId?: string;
    Description?: string;
}
export declare const ProactiveInsight: S.Schema<ProactiveInsight>;
export interface ReactiveInsight {
    Id?: string;
    Name?: string;
    Severity?: InsightSeverity;
    Status?: InsightStatus;
    InsightTimeRange?: InsightTimeRange;
    ResourceCollection?: ResourceCollection;
    SsmOpsItemId?: string;
    Description?: string;
}
export declare const ReactiveInsight: S.Schema<ReactiveInsight>;
export interface DescribeInsightResponse {
    ProactiveInsight?: ProactiveInsight;
    ReactiveInsight?: ReactiveInsight;
}
export declare const DescribeInsightResponse: S.Schema<DescribeInsightResponse>;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export type OrganizationalUnitId = string;
export type OrganizationalUnitIdList = string[];
export declare const OrganizationalUnitIdList: any;
export interface DescribeOrganizationHealthRequest {
    AccountIds?: string[];
    OrganizationalUnitIds?: string[];
}
export declare const DescribeOrganizationHealthRequest: S.Schema<DescribeOrganizationHealthRequest>;
export interface DescribeOrganizationHealthResponse {
    OpenReactiveInsights: number;
    OpenProactiveInsights: number;
    MetricsAnalyzed: number;
    ResourceHours: number;
}
export declare const DescribeOrganizationHealthResponse: S.Schema<DescribeOrganizationHealthResponse>;
export interface DescribeOrganizationOverviewRequest {
    FromTime: Date;
    ToTime?: Date;
    AccountIds?: string[];
    OrganizationalUnitIds?: string[];
}
export declare const DescribeOrganizationOverviewRequest: S.Schema<DescribeOrganizationOverviewRequest>;
export interface DescribeOrganizationOverviewResponse {
    ReactiveInsights: number;
    ProactiveInsights: number;
}
export declare const DescribeOrganizationOverviewResponse: S.Schema<DescribeOrganizationOverviewResponse>;
export type OrganizationResourceCollectionType = "AWS_CLOUD_FORMATION" | "AWS_SERVICE" | "AWS_ACCOUNT" | "AWS_TAGS" | (string & {});
export declare const OrganizationResourceCollectionType: any;
export type UuidNextToken = string;
export type OrganizationResourceCollectionMaxResults = number;
export interface DescribeOrganizationResourceCollectionHealthRequest {
    OrganizationResourceCollectionType: OrganizationResourceCollectionType;
    AccountIds?: string[];
    OrganizationalUnitIds?: string[];
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeOrganizationResourceCollectionHealthRequest: S.Schema<DescribeOrganizationResourceCollectionHealthRequest>;
export interface InsightHealth {
    OpenProactiveInsights?: number;
    OpenReactiveInsights?: number;
    MeanTimeToRecoverInMilliseconds?: number;
}
export declare const InsightHealth: S.Schema<InsightHealth>;
export interface CloudFormationHealth {
    StackName?: string;
    Insight?: InsightHealth;
    AnalyzedResourceCount?: number;
}
export declare const CloudFormationHealth: S.Schema<CloudFormationHealth>;
export type CloudFormationHealths = CloudFormationHealth[];
export declare const CloudFormationHealths: any;
export type ServiceName = "API_GATEWAY" | "APPLICATION_ELB" | "AUTO_SCALING_GROUP" | "CLOUD_FRONT" | "DYNAMO_DB" | "EC2" | "ECS" | "EKS" | "ELASTIC_BEANSTALK" | "ELASTI_CACHE" | "ELB" | "ES" | "KINESIS" | "LAMBDA" | "NAT_GATEWAY" | "NETWORK_ELB" | "RDS" | "REDSHIFT" | "ROUTE_53" | "S3" | "SAGE_MAKER" | "SNS" | "SQS" | "STEP_FUNCTIONS" | "SWF" | (string & {});
export declare const ServiceName: any;
export interface ServiceInsightHealth {
    OpenProactiveInsights?: number;
    OpenReactiveInsights?: number;
}
export declare const ServiceInsightHealth: S.Schema<ServiceInsightHealth>;
export interface ServiceHealth {
    ServiceName?: ServiceName;
    Insight?: ServiceInsightHealth;
    AnalyzedResourceCount?: number;
}
export declare const ServiceHealth: S.Schema<ServiceHealth>;
export type ServiceHealths = ServiceHealth[];
export declare const ServiceHealths: any;
export interface AccountInsightHealth {
    OpenProactiveInsights?: number;
    OpenReactiveInsights?: number;
}
export declare const AccountInsightHealth: S.Schema<AccountInsightHealth>;
export interface AccountHealth {
    AccountId?: string;
    Insight?: AccountInsightHealth;
}
export declare const AccountHealth: S.Schema<AccountHealth>;
export type AccountHealths = AccountHealth[];
export declare const AccountHealths: any;
export interface TagHealth {
    AppBoundaryKey?: string;
    TagValue?: string;
    Insight?: InsightHealth;
    AnalyzedResourceCount?: number;
}
export declare const TagHealth: S.Schema<TagHealth>;
export type TagHealths = TagHealth[];
export declare const TagHealths: any;
export interface DescribeOrganizationResourceCollectionHealthResponse {
    CloudFormation?: CloudFormationHealth[];
    Service?: ServiceHealth[];
    Account?: AccountHealth[];
    NextToken?: string;
    Tags?: TagHealth[];
}
export declare const DescribeOrganizationResourceCollectionHealthResponse: S.Schema<DescribeOrganizationResourceCollectionHealthResponse>;
export type ResourceCollectionType = "AWS_CLOUD_FORMATION" | "AWS_SERVICE" | "AWS_TAGS" | (string & {});
export declare const ResourceCollectionType: any;
export interface DescribeResourceCollectionHealthRequest {
    ResourceCollectionType: ResourceCollectionType;
    NextToken?: string;
}
export declare const DescribeResourceCollectionHealthRequest: S.Schema<DescribeResourceCollectionHealthRequest>;
export interface DescribeResourceCollectionHealthResponse {
    CloudFormation?: CloudFormationHealth[];
    Service?: ServiceHealth[];
    NextToken?: string;
    Tags?: TagHealth[];
}
export declare const DescribeResourceCollectionHealthResponse: S.Schema<DescribeResourceCollectionHealthResponse>;
export interface DescribeServiceIntegrationRequest {
}
export declare const DescribeServiceIntegrationRequest: S.Schema<DescribeServiceIntegrationRequest>;
export type OptInStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const OptInStatus: any;
export interface OpsCenterIntegration {
    OptInStatus?: OptInStatus;
}
export declare const OpsCenterIntegration: S.Schema<OpsCenterIntegration>;
export interface LogsAnomalyDetectionIntegration {
    OptInStatus?: OptInStatus;
}
export declare const LogsAnomalyDetectionIntegration: S.Schema<LogsAnomalyDetectionIntegration>;
export type KMSKeyId = string;
export type ServerSideEncryptionType = "CUSTOMER_MANAGED_KEY" | "AWS_OWNED_KMS_KEY" | (string & {});
export declare const ServerSideEncryptionType: any;
export interface KMSServerSideEncryptionIntegration {
    KMSKeyId?: string;
    OptInStatus?: OptInStatus;
    Type?: ServerSideEncryptionType;
}
export declare const KMSServerSideEncryptionIntegration: S.Schema<KMSServerSideEncryptionIntegration>;
export interface ServiceIntegrationConfig {
    OpsCenter?: OpsCenterIntegration;
    LogsAnomalyDetection?: LogsAnomalyDetectionIntegration;
    KMSServerSideEncryption?: KMSServerSideEncryptionIntegration;
}
export declare const ServiceIntegrationConfig: S.Schema<ServiceIntegrationConfig>;
export interface DescribeServiceIntegrationResponse {
    ServiceIntegration?: ServiceIntegrationConfig;
}
export declare const DescribeServiceIntegrationResponse: S.Schema<DescribeServiceIntegrationResponse>;
export interface GetCostEstimationRequest {
    NextToken?: string;
}
export declare const GetCostEstimationRequest: S.Schema<GetCostEstimationRequest>;
export type CostEstimationStackNames = string[];
export declare const CostEstimationStackNames: any;
export interface CloudFormationCostEstimationResourceCollectionFilter {
    StackNames?: string[];
}
export declare const CloudFormationCostEstimationResourceCollectionFilter: S.Schema<CloudFormationCostEstimationResourceCollectionFilter>;
export type CostEstimationTagValues = string[];
export declare const CostEstimationTagValues: any;
export interface TagCostEstimationResourceCollectionFilter {
    AppBoundaryKey: string;
    TagValues: string[];
}
export declare const TagCostEstimationResourceCollectionFilter: S.Schema<TagCostEstimationResourceCollectionFilter>;
export type TagCostEstimationResourceCollectionFilters = TagCostEstimationResourceCollectionFilter[];
export declare const TagCostEstimationResourceCollectionFilters: any;
export interface CostEstimationResourceCollectionFilter {
    CloudFormation?: CloudFormationCostEstimationResourceCollectionFilter;
    Tags?: TagCostEstimationResourceCollectionFilter[];
}
export declare const CostEstimationResourceCollectionFilter: S.Schema<CostEstimationResourceCollectionFilter>;
export type CostEstimationStatus = "ONGOING" | "COMPLETED" | (string & {});
export declare const CostEstimationStatus: any;
export type CostEstimationServiceResourceState = "ACTIVE" | "INACTIVE" | (string & {});
export declare const CostEstimationServiceResourceState: any;
export type CostEstimationServiceResourceCount = number;
export type Cost = number;
export interface ServiceResourceCost {
    Type?: string;
    State?: CostEstimationServiceResourceState;
    Count?: number;
    UnitCost?: number;
    Cost?: number;
}
export declare const ServiceResourceCost: S.Schema<ServiceResourceCost>;
export type ServiceResourceCosts = ServiceResourceCost[];
export declare const ServiceResourceCosts: any;
export interface CostEstimationTimeRange {
    StartTime?: Date;
    EndTime?: Date;
}
export declare const CostEstimationTimeRange: S.Schema<CostEstimationTimeRange>;
export interface GetCostEstimationResponse {
    ResourceCollection?: CostEstimationResourceCollectionFilter;
    Status?: CostEstimationStatus;
    Costs?: ServiceResourceCost[];
    TimeRange?: CostEstimationTimeRange;
    TotalCost?: number;
    NextToken?: string;
}
export declare const GetCostEstimationResponse: S.Schema<GetCostEstimationResponse>;
export interface GetResourceCollectionRequest {
    ResourceCollectionType: ResourceCollectionType;
    NextToken?: string;
}
export declare const GetResourceCollectionRequest: S.Schema<GetResourceCollectionRequest>;
export interface CloudFormationCollectionFilter {
    StackNames?: string[];
}
export declare const CloudFormationCollectionFilter: S.Schema<CloudFormationCollectionFilter>;
export interface TagCollectionFilter {
    AppBoundaryKey: string;
    TagValues: string[];
}
export declare const TagCollectionFilter: S.Schema<TagCollectionFilter>;
export type TagCollectionFilters = TagCollectionFilter[];
export declare const TagCollectionFilters: any;
export interface ResourceCollectionFilter {
    CloudFormation?: CloudFormationCollectionFilter;
    Tags?: TagCollectionFilter[];
}
export declare const ResourceCollectionFilter: S.Schema<ResourceCollectionFilter>;
export interface GetResourceCollectionResponse {
    ResourceCollection?: ResourceCollectionFilter;
    NextToken?: string;
}
export declare const GetResourceCollectionResponse: S.Schema<GetResourceCollectionResponse>;
export interface StartTimeRange {
    FromTime?: Date;
    ToTime?: Date;
}
export declare const StartTimeRange: S.Schema<StartTimeRange>;
export type ListAnomaliesForInsightMaxResults = number;
export type ServiceNames = ServiceName[];
export declare const ServiceNames: any;
export interface ServiceCollection {
    ServiceNames?: ServiceName[];
}
export declare const ServiceCollection: S.Schema<ServiceCollection>;
export interface ListAnomaliesForInsightFilters {
    ServiceCollection?: ServiceCollection;
}
export declare const ListAnomaliesForInsightFilters: S.Schema<ListAnomaliesForInsightFilters>;
export interface ListAnomaliesForInsightRequest {
    InsightId: string;
    StartTimeRange?: StartTimeRange;
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
    Filters?: ListAnomaliesForInsightFilters;
}
export declare const ListAnomaliesForInsightRequest: S.Schema<ListAnomaliesForInsightRequest>;
export interface ProactiveAnomalySummary {
    Id?: string;
    Severity?: AnomalySeverity;
    Status?: AnomalyStatus;
    UpdateTime?: Date;
    AnomalyTimeRange?: AnomalyTimeRange;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange;
    PredictionTimeRange?: PredictionTimeRange;
    SourceDetails?: AnomalySourceDetails;
    AssociatedInsightId?: string;
    ResourceCollection?: ResourceCollection;
    Limit?: number;
    SourceMetadata?: AnomalySourceMetadata;
    AnomalyResources?: AnomalyResource[];
    Description?: string;
}
export declare const ProactiveAnomalySummary: S.Schema<ProactiveAnomalySummary>;
export type ProactiveAnomalies = ProactiveAnomalySummary[];
export declare const ProactiveAnomalies: any;
export interface ReactiveAnomalySummary {
    Id?: string;
    Severity?: AnomalySeverity;
    Status?: AnomalyStatus;
    AnomalyTimeRange?: AnomalyTimeRange;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange;
    SourceDetails?: AnomalySourceDetails;
    AssociatedInsightId?: string;
    ResourceCollection?: ResourceCollection;
    Type?: AnomalyType;
    Name?: string;
    Description?: string;
    CausalAnomalyId?: string;
    AnomalyResources?: AnomalyResource[];
}
export declare const ReactiveAnomalySummary: S.Schema<ReactiveAnomalySummary>;
export type ReactiveAnomalies = ReactiveAnomalySummary[];
export declare const ReactiveAnomalies: any;
export interface ListAnomaliesForInsightResponse {
    ProactiveAnomalies?: ProactiveAnomalySummary[];
    ReactiveAnomalies?: ReactiveAnomalySummary[];
    NextToken?: string;
}
export declare const ListAnomaliesForInsightResponse: S.Schema<ListAnomaliesForInsightResponse>;
export type ListAnomalousLogGroupsMaxResults = number;
export interface ListAnomalousLogGroupsRequest {
    InsightId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAnomalousLogGroupsRequest: S.Schema<ListAnomalousLogGroupsRequest>;
export type LogGroupName = string;
export type NumberOfLogLinesScanned = number;
export type LogStreamName = string;
export type LogAnomalyType = "KEYWORD" | "KEYWORD_TOKEN" | "FORMAT" | "HTTP_CODE" | "BLOCK_FORMAT" | "NUMERICAL_POINT" | "NUMERICAL_NAN" | "NEW_FIELD_NAME" | (string & {});
export declare const LogAnomalyType: any;
export type LogAnomalyToken = string;
export type LogEventId = string;
export type Explanation = string;
export type NumberOfLogLinesOccurrences = number;
export interface LogAnomalyClass {
    LogStreamName?: string;
    LogAnomalyType?: LogAnomalyType;
    LogAnomalyToken?: string;
    LogEventId?: string;
    Explanation?: string;
    NumberOfLogLinesOccurrences?: number;
    LogEventTimestamp?: Date;
}
export declare const LogAnomalyClass: S.Schema<LogAnomalyClass>;
export type LogAnomalyClasses = LogAnomalyClass[];
export declare const LogAnomalyClasses: any;
export interface LogAnomalyShowcase {
    LogAnomalyClasses?: LogAnomalyClass[];
}
export declare const LogAnomalyShowcase: S.Schema<LogAnomalyShowcase>;
export type LogAnomalyShowcases = LogAnomalyShowcase[];
export declare const LogAnomalyShowcases: any;
export interface AnomalousLogGroup {
    LogGroupName?: string;
    ImpactStartTime?: Date;
    ImpactEndTime?: Date;
    NumberOfLogLinesScanned?: number;
    LogAnomalyShowcases?: LogAnomalyShowcase[];
}
export declare const AnomalousLogGroup: S.Schema<AnomalousLogGroup>;
export type AnomalousLogGroups = AnomalousLogGroup[];
export declare const AnomalousLogGroups: any;
export interface ListAnomalousLogGroupsResponse {
    InsightId: string;
    AnomalousLogGroups: AnomalousLogGroup[];
    NextToken?: string;
}
export declare const ListAnomalousLogGroupsResponse: S.Schema<ListAnomalousLogGroupsResponse>;
export interface EventTimeRange {
    FromTime: Date;
    ToTime: Date;
}
export declare const EventTimeRange: S.Schema<EventTimeRange>;
export type EventClass = "INFRASTRUCTURE" | "DEPLOYMENT" | "SECURITY_CHANGE" | "CONFIG_CHANGE" | "SCHEMA_CHANGE" | (string & {});
export declare const EventClass: any;
export type EventSource = string;
export type EventDataSource = "AWS_CLOUD_TRAIL" | "AWS_CODE_DEPLOY" | (string & {});
export declare const EventDataSource: any;
export interface ListEventsFilters {
    InsightId?: string;
    EventTimeRange?: EventTimeRange;
    EventClass?: EventClass;
    EventSource?: string;
    DataSource?: EventDataSource;
    ResourceCollection?: ResourceCollection;
}
export declare const ListEventsFilters: S.Schema<ListEventsFilters>;
export type ListEventsMaxResults = number;
export interface ListEventsRequest {
    Filters: ListEventsFilters;
    MaxResults?: number;
    NextToken?: string;
    AccountId?: string;
}
export declare const ListEventsRequest: S.Schema<ListEventsRequest>;
export type EventId = string;
export type EventName = string;
export type EventResourceType = string;
export type EventResourceName = string;
export type EventResourceArn = string;
export interface EventResource {
    Type?: string;
    Name?: string;
    Arn?: string;
}
export declare const EventResource: S.Schema<EventResource>;
export type EventResources = EventResource[];
export declare const EventResources: any;
export interface Event {
    ResourceCollection?: ResourceCollection;
    Id?: string;
    Time?: Date;
    EventSource?: string;
    Name?: string;
    DataSource?: EventDataSource;
    EventClass?: EventClass;
    Resources?: EventResource[];
}
export declare const Event: S.Schema<Event>;
export type Events = Event[];
export declare const Events: any;
export interface ListEventsResponse {
    Events: Event[];
    NextToken?: string;
}
export declare const ListEventsResponse: S.Schema<ListEventsResponse>;
export type InsightType = "REACTIVE" | "PROACTIVE" | (string & {});
export declare const InsightType: any;
export interface ListInsightsOngoingStatusFilter {
    Type: InsightType;
}
export declare const ListInsightsOngoingStatusFilter: S.Schema<ListInsightsOngoingStatusFilter>;
export interface EndTimeRange {
    FromTime?: Date;
    ToTime?: Date;
}
export declare const EndTimeRange: S.Schema<EndTimeRange>;
export interface ListInsightsClosedStatusFilter {
    Type: InsightType;
    EndTimeRange: EndTimeRange;
}
export declare const ListInsightsClosedStatusFilter: S.Schema<ListInsightsClosedStatusFilter>;
export interface ListInsightsAnyStatusFilter {
    Type: InsightType;
    StartTimeRange: StartTimeRange;
}
export declare const ListInsightsAnyStatusFilter: S.Schema<ListInsightsAnyStatusFilter>;
export interface ListInsightsStatusFilter {
    Ongoing?: ListInsightsOngoingStatusFilter;
    Closed?: ListInsightsClosedStatusFilter;
    Any?: ListInsightsAnyStatusFilter;
}
export declare const ListInsightsStatusFilter: S.Schema<ListInsightsStatusFilter>;
export type ListInsightsMaxResults = number;
export interface ListInsightsRequest {
    StatusFilter: ListInsightsStatusFilter;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListInsightsRequest: S.Schema<ListInsightsRequest>;
export type ResourceArn = string;
export type AssociatedResourceArns = string[];
export declare const AssociatedResourceArns: any;
export interface ProactiveInsightSummary {
    Id?: string;
    Name?: string;
    Severity?: InsightSeverity;
    Status?: InsightStatus;
    InsightTimeRange?: InsightTimeRange;
    PredictionTimeRange?: PredictionTimeRange;
    ResourceCollection?: ResourceCollection;
    ServiceCollection?: ServiceCollection;
    AssociatedResourceArns?: string[];
}
export declare const ProactiveInsightSummary: S.Schema<ProactiveInsightSummary>;
export type ProactiveInsights = ProactiveInsightSummary[];
export declare const ProactiveInsights: any;
export interface ReactiveInsightSummary {
    Id?: string;
    Name?: string;
    Severity?: InsightSeverity;
    Status?: InsightStatus;
    InsightTimeRange?: InsightTimeRange;
    ResourceCollection?: ResourceCollection;
    ServiceCollection?: ServiceCollection;
    AssociatedResourceArns?: string[];
}
export declare const ReactiveInsightSummary: S.Schema<ReactiveInsightSummary>;
export type ReactiveInsights = ReactiveInsightSummary[];
export declare const ReactiveInsights: any;
export interface ListInsightsResponse {
    ProactiveInsights?: ProactiveInsightSummary[];
    ReactiveInsights?: ReactiveInsightSummary[];
    NextToken?: string;
}
export declare const ListInsightsResponse: S.Schema<ListInsightsResponse>;
export type ResourcePermission = "FULL_PERMISSION" | "MISSING_PERMISSION" | (string & {});
export declare const ResourcePermission: any;
export type ResourceTypeFilter = "LOG_GROUPS" | "CLOUDFRONT_DISTRIBUTION" | "DYNAMODB_TABLE" | "EC2_NAT_GATEWAY" | "ECS_CLUSTER" | "ECS_SERVICE" | "EKS_CLUSTER" | "ELASTIC_BEANSTALK_ENVIRONMENT" | "ELASTIC_LOAD_BALANCER_LOAD_BALANCER" | "ELASTIC_LOAD_BALANCING_V2_LOAD_BALANCER" | "ELASTIC_LOAD_BALANCING_V2_TARGET_GROUP" | "ELASTICACHE_CACHE_CLUSTER" | "ELASTICSEARCH_DOMAIN" | "KINESIS_STREAM" | "LAMBDA_FUNCTION" | "OPEN_SEARCH_SERVICE_DOMAIN" | "RDS_DB_INSTANCE" | "RDS_DB_CLUSTER" | "REDSHIFT_CLUSTER" | "ROUTE53_HOSTED_ZONE" | "ROUTE53_HEALTH_CHECK" | "S3_BUCKET" | "SAGEMAKER_ENDPOINT" | "SNS_TOPIC" | "SQS_QUEUE" | "STEP_FUNCTIONS_ACTIVITY" | "STEP_FUNCTIONS_STATE_MACHINE" | (string & {});
export declare const ResourceTypeFilter: any;
export type ResourceTypeFilters = ResourceTypeFilter[];
export declare const ResourceTypeFilters: any;
export interface ListMonitoredResourcesFilters {
    ResourcePermission: ResourcePermission;
    ResourceTypeFilters: ResourceTypeFilter[];
}
export declare const ListMonitoredResourcesFilters: S.Schema<ListMonitoredResourcesFilters>;
export type ListMonitoredResourcesMaxResults = number;
export interface ListMonitoredResourcesRequest {
    Filters?: ListMonitoredResourcesFilters;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListMonitoredResourcesRequest: S.Schema<ListMonitoredResourcesRequest>;
export type MonitoredResourceName = string;
export interface MonitoredResourceIdentifier {
    MonitoredResourceName?: string;
    Type?: string;
    ResourcePermission?: ResourcePermission;
    LastUpdated?: Date;
    ResourceCollection?: ResourceCollection;
}
export declare const MonitoredResourceIdentifier: S.Schema<MonitoredResourceIdentifier>;
export type MonitoredResourceIdentifiers = MonitoredResourceIdentifier[];
export declare const MonitoredResourceIdentifiers: any;
export interface ListMonitoredResourcesResponse {
    MonitoredResourceIdentifiers: MonitoredResourceIdentifier[];
    NextToken?: string;
}
export declare const ListMonitoredResourcesResponse: S.Schema<ListMonitoredResourcesResponse>;
export interface ListNotificationChannelsRequest {
    NextToken?: string;
}
export declare const ListNotificationChannelsRequest: S.Schema<ListNotificationChannelsRequest>;
export interface NotificationChannel {
    Id?: string;
    Config?: NotificationChannelConfig;
}
export declare const NotificationChannel: S.Schema<NotificationChannel>;
export type Channels = NotificationChannel[];
export declare const Channels: any;
export interface ListNotificationChannelsResponse {
    Channels?: NotificationChannel[];
    NextToken?: string;
}
export declare const ListNotificationChannelsResponse: S.Schema<ListNotificationChannelsResponse>;
export type ListInsightsAccountIdList = string[];
export declare const ListInsightsAccountIdList: any;
export type ListInsightsOrganizationalUnitIdList = string[];
export declare const ListInsightsOrganizationalUnitIdList: any;
export interface ListOrganizationInsightsRequest {
    StatusFilter: ListInsightsStatusFilter;
    MaxResults?: number;
    AccountIds?: string[];
    OrganizationalUnitIds?: string[];
    NextToken?: string;
}
export declare const ListOrganizationInsightsRequest: S.Schema<ListOrganizationInsightsRequest>;
export interface ProactiveOrganizationInsightSummary {
    Id?: string;
    AccountId?: string;
    OrganizationalUnitId?: string;
    Name?: string;
    Severity?: InsightSeverity;
    Status?: InsightStatus;
    InsightTimeRange?: InsightTimeRange;
    PredictionTimeRange?: PredictionTimeRange;
    ResourceCollection?: ResourceCollection;
    ServiceCollection?: ServiceCollection;
}
export declare const ProactiveOrganizationInsightSummary: S.Schema<ProactiveOrganizationInsightSummary>;
export type ProactiveOrganizationInsights = ProactiveOrganizationInsightSummary[];
export declare const ProactiveOrganizationInsights: any;
export interface ReactiveOrganizationInsightSummary {
    Id?: string;
    AccountId?: string;
    OrganizationalUnitId?: string;
    Name?: string;
    Severity?: InsightSeverity;
    Status?: InsightStatus;
    InsightTimeRange?: InsightTimeRange;
    ResourceCollection?: ResourceCollection;
    ServiceCollection?: ServiceCollection;
}
export declare const ReactiveOrganizationInsightSummary: S.Schema<ReactiveOrganizationInsightSummary>;
export type ReactiveOrganizationInsights = ReactiveOrganizationInsightSummary[];
export declare const ReactiveOrganizationInsights: any;
export interface ListOrganizationInsightsResponse {
    ProactiveInsights?: ProactiveOrganizationInsightSummary[];
    ReactiveInsights?: ReactiveOrganizationInsightSummary[];
    NextToken?: string;
}
export declare const ListOrganizationInsightsResponse: S.Schema<ListOrganizationInsightsResponse>;
export type Locale = "DE_DE" | "EN_US" | "EN_GB" | "ES_ES" | "FR_FR" | "IT_IT" | "JA_JP" | "KO_KR" | "PT_BR" | "ZH_CN" | "ZH_TW" | (string & {});
export declare const Locale: any;
export interface ListRecommendationsRequest {
    InsightId: string;
    NextToken?: string;
    Locale?: Locale;
    AccountId?: string;
}
export declare const ListRecommendationsRequest: S.Schema<ListRecommendationsRequest>;
export type RecommendationDescription = string;
export type RecommendationLink = string;
export type RecommendationName = string;
export type RecommendationReason = string;
export type RecommendationRelatedEventName = string;
export type RecommendationRelatedEventResourceName = string;
export type RecommendationRelatedEventResourceType = string;
export interface RecommendationRelatedEventResource {
    Name?: string;
    Type?: string;
}
export declare const RecommendationRelatedEventResource: S.Schema<RecommendationRelatedEventResource>;
export type RecommendationRelatedEventResources = RecommendationRelatedEventResource[];
export declare const RecommendationRelatedEventResources: any;
export interface RecommendationRelatedEvent {
    Name?: string;
    Resources?: RecommendationRelatedEventResource[];
}
export declare const RecommendationRelatedEvent: S.Schema<RecommendationRelatedEvent>;
export type RecommendationRelatedEvents = RecommendationRelatedEvent[];
export declare const RecommendationRelatedEvents: any;
export type RecommendationRelatedAnomalyResourceName = string;
export type RecommendationRelatedAnomalyResourceType = string;
export interface RecommendationRelatedAnomalyResource {
    Name?: string;
    Type?: string;
}
export declare const RecommendationRelatedAnomalyResource: S.Schema<RecommendationRelatedAnomalyResource>;
export type RecommendationRelatedAnomalyResources = RecommendationRelatedAnomalyResource[];
export declare const RecommendationRelatedAnomalyResources: any;
export type RecommendationRelatedCloudWatchMetricsSourceMetricName = string;
export type RecommendationRelatedCloudWatchMetricsSourceNamespace = string;
export interface RecommendationRelatedCloudWatchMetricsSourceDetail {
    MetricName?: string;
    Namespace?: string;
}
export declare const RecommendationRelatedCloudWatchMetricsSourceDetail: S.Schema<RecommendationRelatedCloudWatchMetricsSourceDetail>;
export type RecommendationRelatedCloudWatchMetricsSourceDetails = RecommendationRelatedCloudWatchMetricsSourceDetail[];
export declare const RecommendationRelatedCloudWatchMetricsSourceDetails: any;
export interface RecommendationRelatedAnomalySourceDetail {
    CloudWatchMetrics?: RecommendationRelatedCloudWatchMetricsSourceDetail[];
}
export declare const RecommendationRelatedAnomalySourceDetail: S.Schema<RecommendationRelatedAnomalySourceDetail>;
export type RelatedAnomalySourceDetails = RecommendationRelatedAnomalySourceDetail[];
export declare const RelatedAnomalySourceDetails: any;
export interface RecommendationRelatedAnomaly {
    Resources?: RecommendationRelatedAnomalyResource[];
    SourceDetails?: RecommendationRelatedAnomalySourceDetail[];
    AnomalyId?: string;
}
export declare const RecommendationRelatedAnomaly: S.Schema<RecommendationRelatedAnomaly>;
export type RecommendationRelatedAnomalies = RecommendationRelatedAnomaly[];
export declare const RecommendationRelatedAnomalies: any;
export type RecommendationCategory = string;
export interface Recommendation {
    Description?: string;
    Link?: string;
    Name?: string;
    Reason?: string;
    RelatedEvents?: RecommendationRelatedEvent[];
    RelatedAnomalies?: RecommendationRelatedAnomaly[];
    Category?: string;
}
export declare const Recommendation: S.Schema<Recommendation>;
export type Recommendations = Recommendation[];
export declare const Recommendations: any;
export interface ListRecommendationsResponse {
    Recommendations?: Recommendation[];
    NextToken?: string;
}
export declare const ListRecommendationsResponse: S.Schema<ListRecommendationsResponse>;
export interface PutFeedbackRequest {
    InsightFeedback?: InsightFeedback;
}
export declare const PutFeedbackRequest: S.Schema<PutFeedbackRequest>;
export interface PutFeedbackResponse {
}
export declare const PutFeedbackResponse: S.Schema<PutFeedbackResponse>;
export interface RemoveNotificationChannelRequest {
    Id: string;
}
export declare const RemoveNotificationChannelRequest: S.Schema<RemoveNotificationChannelRequest>;
export interface RemoveNotificationChannelResponse {
}
export declare const RemoveNotificationChannelResponse: S.Schema<RemoveNotificationChannelResponse>;
export type InsightStatuses = InsightStatus[];
export declare const InsightStatuses: any;
export interface SearchInsightsFilters {
    Severities?: InsightSeverity[];
    Statuses?: InsightStatus[];
    ResourceCollection?: ResourceCollection;
    ServiceCollection?: ServiceCollection;
}
export declare const SearchInsightsFilters: S.Schema<SearchInsightsFilters>;
export type SearchInsightsMaxResults = number;
export interface SearchInsightsRequest {
    StartTimeRange: StartTimeRange;
    Filters?: SearchInsightsFilters;
    MaxResults?: number;
    NextToken?: string;
    Type: InsightType;
}
export declare const SearchInsightsRequest: S.Schema<SearchInsightsRequest>;
export interface SearchInsightsResponse {
    ProactiveInsights?: ProactiveInsightSummary[];
    ReactiveInsights?: ReactiveInsightSummary[];
    NextToken?: string;
}
export declare const SearchInsightsResponse: S.Schema<SearchInsightsResponse>;
export type SearchInsightsAccountIdList = string[];
export declare const SearchInsightsAccountIdList: any;
export interface SearchOrganizationInsightsFilters {
    Severities?: InsightSeverity[];
    Statuses?: InsightStatus[];
    ResourceCollection?: ResourceCollection;
    ServiceCollection?: ServiceCollection;
}
export declare const SearchOrganizationInsightsFilters: S.Schema<SearchOrganizationInsightsFilters>;
export type SearchOrganizationInsightsMaxResults = number;
export interface SearchOrganizationInsightsRequest {
    AccountIds: string[];
    StartTimeRange: StartTimeRange;
    Filters?: SearchOrganizationInsightsFilters;
    MaxResults?: number;
    NextToken?: string;
    Type: InsightType;
}
export declare const SearchOrganizationInsightsRequest: S.Schema<SearchOrganizationInsightsRequest>;
export interface SearchOrganizationInsightsResponse {
    ProactiveInsights?: ProactiveInsightSummary[];
    ReactiveInsights?: ReactiveInsightSummary[];
    NextToken?: string;
}
export declare const SearchOrganizationInsightsResponse: S.Schema<SearchOrganizationInsightsResponse>;
export type ClientToken = string;
export interface StartCostEstimationRequest {
    ResourceCollection: CostEstimationResourceCollectionFilter;
    ClientToken?: string;
}
export declare const StartCostEstimationRequest: S.Schema<StartCostEstimationRequest>;
export interface StartCostEstimationResponse {
}
export declare const StartCostEstimationResponse: S.Schema<StartCostEstimationResponse>;
export interface UpdateEventSourcesConfigRequest {
    EventSources?: EventSourcesConfig;
}
export declare const UpdateEventSourcesConfigRequest: S.Schema<UpdateEventSourcesConfigRequest>;
export interface UpdateEventSourcesConfigResponse {
}
export declare const UpdateEventSourcesConfigResponse: S.Schema<UpdateEventSourcesConfigResponse>;
export type UpdateResourceCollectionAction = "ADD" | "REMOVE" | (string & {});
export declare const UpdateResourceCollectionAction: any;
export type UpdateStackNames = string[];
export declare const UpdateStackNames: any;
export interface UpdateCloudFormationCollectionFilter {
    StackNames?: string[];
}
export declare const UpdateCloudFormationCollectionFilter: S.Schema<UpdateCloudFormationCollectionFilter>;
export type UpdateTagValues = string[];
export declare const UpdateTagValues: any;
export interface UpdateTagCollectionFilter {
    AppBoundaryKey: string;
    TagValues: string[];
}
export declare const UpdateTagCollectionFilter: S.Schema<UpdateTagCollectionFilter>;
export type UpdateTagCollectionFilters = UpdateTagCollectionFilter[];
export declare const UpdateTagCollectionFilters: any;
export interface UpdateResourceCollectionFilter {
    CloudFormation?: UpdateCloudFormationCollectionFilter;
    Tags?: UpdateTagCollectionFilter[];
}
export declare const UpdateResourceCollectionFilter: S.Schema<UpdateResourceCollectionFilter>;
export interface UpdateResourceCollectionRequest {
    Action: UpdateResourceCollectionAction;
    ResourceCollection: UpdateResourceCollectionFilter;
}
export declare const UpdateResourceCollectionRequest: S.Schema<UpdateResourceCollectionRequest>;
export interface UpdateResourceCollectionResponse {
}
export declare const UpdateResourceCollectionResponse: S.Schema<UpdateResourceCollectionResponse>;
export interface OpsCenterIntegrationConfig {
    OptInStatus?: OptInStatus;
}
export declare const OpsCenterIntegrationConfig: S.Schema<OpsCenterIntegrationConfig>;
export interface LogsAnomalyDetectionIntegrationConfig {
    OptInStatus?: OptInStatus;
}
export declare const LogsAnomalyDetectionIntegrationConfig: S.Schema<LogsAnomalyDetectionIntegrationConfig>;
export interface KMSServerSideEncryptionIntegrationConfig {
    KMSKeyId?: string;
    OptInStatus?: OptInStatus;
    Type?: ServerSideEncryptionType;
}
export declare const KMSServerSideEncryptionIntegrationConfig: S.Schema<KMSServerSideEncryptionIntegrationConfig>;
export interface UpdateServiceIntegrationConfig {
    OpsCenter?: OpsCenterIntegrationConfig;
    LogsAnomalyDetection?: LogsAnomalyDetectionIntegrationConfig;
    KMSServerSideEncryption?: KMSServerSideEncryptionIntegrationConfig;
}
export declare const UpdateServiceIntegrationConfig: S.Schema<UpdateServiceIntegrationConfig>;
export interface UpdateServiceIntegrationRequest {
    ServiceIntegration: UpdateServiceIntegrationConfig;
}
export declare const UpdateServiceIntegrationRequest: S.Schema<UpdateServiceIntegrationRequest>;
export interface UpdateServiceIntegrationResponse {
}
export declare const UpdateServiceIntegrationResponse: S.Schema<UpdateServiceIntegrationResponse>;
export type ErrorMessageString = string;
export type ResourceIdString = string;
export type ResourceIdType = string;
export type RetryAfterSeconds = number;
export type ErrorQuotaCodeString = string;
export type ErrorServiceCodeString = string;
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | "INVALID_PARAMETER_COMBINATION" | "PARAMETER_INCONSISTENT_WITH_SERVICE_STATE" | (string & {});
export declare const ValidationExceptionReason: any;
export type ErrorNameString = string;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFields = ValidationExceptionField[];
export declare const ValidationExceptionFields: any;
export type AddNotificationChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a notification channel to DevOps Guru. A notification channel is used to notify you
 * about important DevOps Guru events, such as when an insight is generated.
 *
 * If you use an Amazon SNS topic in another account, you must attach a policy to it that grants DevOps Guru permission
 * to send it notifications. DevOps Guru adds the required policy on your behalf to send notifications using Amazon SNS in your account. DevOps Guru only supports standard SNS topics.
 * For more information, see Permissions
 * for Amazon SNS topics.
 *
 * If you use an Amazon SNS topic that is encrypted by an Amazon Web Services Key Management Service customer-managed key (CMK), then you must add permissions
 * to the CMK. For more information, see Permissions for
 * Amazon Web Services KMS–encrypted Amazon SNS topics.
 */
export declare const addNotificationChannel: API.OperationMethod<AddNotificationChannelRequest, AddNotificationChannelResponse, AddNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteInsightError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the insight along with the associated anomalies, events and recommendations.
 */
export declare const deleteInsight: API.OperationMethod<DeleteInsightRequest, DeleteInsightResponse, DeleteInsightError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the number of open reactive insights, the number of open proactive insights,
 * and the number of metrics analyzed in your Amazon Web Services account. Use these numbers to gauge the
 * health of operations in your Amazon Web Services account.
 */
export declare const describeAccountHealth: API.OperationMethod<DescribeAccountHealthRequest, DescribeAccountHealthResponse, DescribeAccountHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountOverviewError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * For the time range passed in, returns the number of open reactive insight that were
 * created, the number of open proactive insights that were created, and the Mean Time to Recover (MTTR) for all
 * closed reactive insights.
 */
export declare const describeAccountOverview: API.OperationMethod<DescribeAccountOverviewRequest, DescribeAccountOverviewResponse, DescribeAccountOverviewError, Credentials | HttpClient.HttpClient>;
export type DescribeAnomalyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about an anomaly that you specify using its ID.
 */
export declare const describeAnomaly: API.OperationMethod<DescribeAnomalyRequest, DescribeAnomalyResponse, DescribeAnomalyError, Credentials | HttpClient.HttpClient>;
export type DescribeEventSourcesConfigError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the integration status of services that are integrated with DevOps Guru as Consumer
 * via EventBridge. The one service that can be integrated with DevOps Guru is Amazon CodeGuru
 * Profiler, which can produce proactive recommendations which can be stored and viewed in
 * DevOps Guru.
 */
export declare const describeEventSourcesConfig: API.OperationMethod<DescribeEventSourcesConfigRequest, DescribeEventSourcesConfigResponse, DescribeEventSourcesConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the most recent feedback submitted in the current Amazon Web Services account and Region.
 */
export declare const describeFeedback: API.OperationMethod<DescribeFeedbackRequest, DescribeFeedbackResponse, DescribeFeedbackError, Credentials | HttpClient.HttpClient>;
export type DescribeInsightError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about an insight that you specify using its ID.
 */
export declare const describeInsight: API.OperationMethod<DescribeInsightRequest, DescribeInsightResponse, DescribeInsightError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns active insights, predictive insights, and resource hours analyzed in last
 * hour.
 */
export declare const describeOrganizationHealth: API.OperationMethod<DescribeOrganizationHealthRequest, DescribeOrganizationHealthResponse, DescribeOrganizationHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationOverviewError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an overview of your organization's history based on the specified time range.
 * The overview includes the total reactive and proactive insights.
 */
export declare const describeOrganizationOverview: API.OperationMethod<DescribeOrganizationOverviewRequest, DescribeOrganizationOverviewResponse, DescribeOrganizationOverviewError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationResourceCollectionHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides an overview of your system's health. If additional member accounts are part
 * of your organization, you can filter those accounts using the `AccountIds`
 * field.
 */
export declare const describeOrganizationResourceCollectionHealth: API.PaginatedOperationMethod<DescribeOrganizationResourceCollectionHealthRequest, DescribeOrganizationResourceCollectionHealthResponse, DescribeOrganizationResourceCollectionHealthError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeResourceCollectionHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the number of open proactive insights, open reactive insights, and the Mean Time to Recover (MTTR)
 * for all closed insights in resource collections in your account. You specify the type of
 * Amazon Web Services resources collection. The two types of Amazon Web Services resource collections supported are Amazon Web Services CloudFormation stacks and
 * Amazon Web Services resources that contain the same Amazon Web Services tag. DevOps Guru can be configured to analyze
 * the Amazon Web Services resources that are defined in the stacks or that are tagged using the same tag *key*. You can specify up to 500 Amazon Web Services CloudFormation stacks.
 */
export declare const describeResourceCollectionHealth: API.PaginatedOperationMethod<DescribeResourceCollectionHealthRequest, DescribeResourceCollectionHealthResponse, DescribeResourceCollectionHealthError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeServiceIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the integration status of services that are integrated with DevOps Guru.
 * The one service that can be integrated with DevOps Guru
 * is Amazon Web Services Systems Manager, which can be used to create an OpsItem for each generated insight.
 */
export declare const describeServiceIntegration: API.OperationMethod<DescribeServiceIntegrationRequest, DescribeServiceIntegrationResponse, DescribeServiceIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetCostEstimationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an estimate of the monthly cost for DevOps Guru to analyze your Amazon Web Services resources.
 * For more information,
 * see Estimate your
 * Amazon DevOps Guru costs and
 * Amazon DevOps Guru pricing.
 */
export declare const getCostEstimation: API.PaginatedOperationMethod<GetCostEstimationRequest, GetCostEstimationResponse, GetCostEstimationError, Credentials | HttpClient.HttpClient, unknown>;
export type GetResourceCollectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns lists Amazon Web Services resources that are of the specified resource collection type.
 * The two types of Amazon Web Services resource collections supported are Amazon Web Services CloudFormation stacks and
 * Amazon Web Services resources that contain the same Amazon Web Services tag. DevOps Guru can be configured to analyze
 * the Amazon Web Services resources that are defined in the stacks or that are tagged using the same tag *key*. You can specify up to 500 Amazon Web Services CloudFormation stacks.
 */
export declare const getResourceCollection: API.PaginatedOperationMethod<GetResourceCollectionRequest, GetResourceCollectionResponse, GetResourceCollectionError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAnomaliesForInsightError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the anomalies that belong to an insight that you specify using its
 * ID.
 */
export declare const listAnomaliesForInsight: API.PaginatedOperationMethod<ListAnomaliesForInsightRequest, ListAnomaliesForInsightResponse, ListAnomaliesForInsightError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAnomalousLogGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of log groups that contain log anomalies.
 */
export declare const listAnomalousLogGroups: API.PaginatedOperationMethod<ListAnomalousLogGroupsRequest, ListAnomalousLogGroupsResponse, ListAnomalousLogGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the events emitted by the resources that are evaluated by DevOps Guru.
 * You can use filters to specify which events are returned.
 */
export declare const listEvents: API.PaginatedOperationMethod<ListEventsRequest, ListEventsResponse, ListEventsError, Credentials | HttpClient.HttpClient, Event>;
export type ListInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights in your Amazon Web Services account. You can specify which insights are
 * returned by their start time and status (`ONGOING`, `CLOSED`, or
 * `ANY`).
 */
export declare const listInsights: API.PaginatedOperationMethod<ListInsightsRequest, ListInsightsResponse, ListInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMonitoredResourcesError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of all log groups that are being monitored and tagged by DevOps Guru.
 */
export declare const listMonitoredResources: API.PaginatedOperationMethod<ListMonitoredResourcesRequest, ListMonitoredResourcesResponse, ListMonitoredResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNotificationChannelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of notification channels configured for DevOps Guru. Each notification
 * channel is used to notify you when DevOps Guru generates an insight that contains information
 * about how to improve your operations. The one
 * supported notification channel is Amazon Simple Notification Service (Amazon SNS).
 */
export declare const listNotificationChannels: API.PaginatedOperationMethod<ListNotificationChannelsRequest, ListNotificationChannelsResponse, ListNotificationChannelsError, Credentials | HttpClient.HttpClient, NotificationChannel>;
export type ListOrganizationInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights associated with the account or OU Id.
 */
export declare const listOrganizationInsights: API.PaginatedOperationMethod<ListOrganizationInsightsRequest, ListOrganizationInsightsResponse, ListOrganizationInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of a specified insight's recommendations. Each recommendation includes
 * a list of related metrics and a list of related events.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, Recommendation>;
export type PutFeedbackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Collects customer feedback about the specified insight.
 */
export declare const putFeedback: API.OperationMethod<PutFeedbackRequest, PutFeedbackResponse, PutFeedbackError, Credentials | HttpClient.HttpClient>;
export type RemoveNotificationChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a notification channel from DevOps Guru. A notification channel is used to notify
 * you when DevOps Guru generates an insight that contains information about how to improve your
 * operations.
 */
export declare const removeNotificationChannel: API.OperationMethod<RemoveNotificationChannelRequest, RemoveNotificationChannelResponse, RemoveNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type SearchInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights in your Amazon Web Services account. You can specify which insights are
 * returned by their start time, one or more statuses (`ONGOING` or `CLOSED`), one or more severities
 * (`LOW`, `MEDIUM`, and `HIGH`), and type
 * (`REACTIVE` or `PROACTIVE`).
 *
 * Use the `Filters` parameter to specify status and severity search
 * parameters. Use the `Type` parameter to specify `REACTIVE` or
 * `PROACTIVE` in your search.
 */
export declare const searchInsights: API.PaginatedOperationMethod<SearchInsightsRequest, SearchInsightsResponse, SearchInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type SearchOrganizationInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights in your organization. You can specify which insights are
 * returned by their start time, one or more statuses (`ONGOING`,
 * `CLOSED`, and `CLOSED`), one or more severities
 * (`LOW`, `MEDIUM`, and `HIGH`), and type
 * (`REACTIVE` or `PROACTIVE`).
 *
 * Use the `Filters` parameter to specify status and severity search
 * parameters. Use the `Type` parameter to specify `REACTIVE` or
 * `PROACTIVE` in your search.
 */
export declare const searchOrganizationInsights: API.PaginatedOperationMethod<SearchOrganizationInsightsRequest, SearchOrganizationInsightsResponse, SearchOrganizationInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type StartCostEstimationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the creation of an estimate of the monthly cost to analyze your Amazon Web Services
 * resources.
 */
export declare const startCostEstimation: API.OperationMethod<StartCostEstimationRequest, StartCostEstimationResponse, StartCostEstimationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventSourcesConfigError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables or disables integration with a service that can be integrated with DevOps Guru. The
 * one service that can be integrated with DevOps Guru is Amazon CodeGuru Profiler, which
 * can produce proactive recommendations which can be stored and viewed in DevOps Guru.
 */
export declare const updateEventSourcesConfig: API.OperationMethod<UpdateEventSourcesConfigRequest, UpdateEventSourcesConfigResponse, UpdateEventSourcesConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceCollectionError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the collection of resources that DevOps Guru analyzes.
 * The two types of Amazon Web Services resource collections supported are Amazon Web Services CloudFormation stacks and
 * Amazon Web Services resources that contain the same Amazon Web Services tag. DevOps Guru can be configured to analyze
 * the Amazon Web Services resources that are defined in the stacks or that are tagged using the same tag *key*. You can specify up to 500 Amazon Web Services CloudFormation stacks. This method also creates the IAM role required for
 * you to use DevOps Guru.
 */
export declare const updateResourceCollection: API.OperationMethod<UpdateResourceCollectionRequest, UpdateResourceCollectionResponse, UpdateResourceCollectionError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables or disables integration with a service that can be integrated with DevOps Guru. The
 * one service that can be integrated with DevOps Guru is Amazon Web Services Systems Manager, which can be used to create
 * an OpsItem for each generated insight.
 */
export declare const updateServiceIntegration: API.OperationMethod<UpdateServiceIntegrationRequest, UpdateServiceIntegrationResponse, UpdateServiceIntegrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=devops-guru.d.ts.map