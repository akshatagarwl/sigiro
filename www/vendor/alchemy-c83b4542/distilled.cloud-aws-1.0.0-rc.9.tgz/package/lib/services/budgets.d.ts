import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BillingViewHealthStatusException_base: S.Class<BillingViewHealthStatusException, S.TaggedStruct<"BillingViewHealthStatusException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BillingViewHealthStatusException extends /*@__PURE__*/ BillingViewHealthStatusException_base {
}
declare const CreationLimitExceededException_base: S.Class<CreationLimitExceededException, S.TaggedStruct<"CreationLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CreationLimitExceededException extends /*@__PURE__*/ CreationLimitExceededException_base {
}
declare const DuplicateRecordException_base: S.Class<DuplicateRecordException, S.TaggedStruct<"DuplicateRecordException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateRecordException extends /*@__PURE__*/ DuplicateRecordException_base {
}
declare const ExpiredNextTokenException_base: S.Class<ExpiredNextTokenException, S.TaggedStruct<"ExpiredNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ExpiredNextTokenException extends /*@__PURE__*/ ExpiredNextTokenException_base {
}
declare const InternalErrorException_base: S.Class<InternalErrorException, S.TaggedStruct<"InternalErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalErrorException extends /*@__PURE__*/ InternalErrorException_base {
}
declare const InvalidNextTokenException_base: S.Class<InvalidNextTokenException, S.TaggedStruct<"InvalidNextTokenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceLockedException_base: S.Class<ResourceLockedException, S.TaggedStruct<"ResourceLockedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceLockedException extends /*@__PURE__*/ ResourceLockedException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type AccountId = string;
export type BudgetName = string;
export type NumericValue = string;
export type UnitValue = string;
export interface Spend {
    Amount: string;
    Unit: string;
}
export declare const Spend: S.Schema<Spend>;
export type PlannedBudgetLimits = {
    [key: string]: Spend | undefined;
};
export declare const PlannedBudgetLimits: any;
export type DimensionValue = string;
export type DimensionValues = string[];
export declare const DimensionValues: any;
export type CostFilters = {
    [key: string]: string[] | undefined;
};
export declare const CostFilters: any;
export interface CostTypes {
    IncludeTax?: boolean;
    IncludeSubscription?: boolean;
    UseBlended?: boolean;
    IncludeRefund?: boolean;
    IncludeCredit?: boolean;
    IncludeUpfront?: boolean;
    IncludeRecurring?: boolean;
    IncludeOtherSubscription?: boolean;
    IncludeSupport?: boolean;
    IncludeDiscount?: boolean;
    UseAmortized?: boolean;
}
export declare const CostTypes: S.Schema<CostTypes>;
export type TimeUnit = "DAILY" | "MONTHLY" | "QUARTERLY" | "ANNUALLY" | "CUSTOM" | (string & {});
export declare const TimeUnit: any;
export interface TimePeriod {
    Start?: Date;
    End?: Date;
}
export declare const TimePeriod: S.Schema<TimePeriod>;
export interface CalculatedSpend {
    ActualSpend: Spend;
    ForecastedSpend?: Spend;
}
export declare const CalculatedSpend: S.Schema<CalculatedSpend>;
export type BudgetType = "USAGE" | "COST" | "RI_UTILIZATION" | "RI_COVERAGE" | "SAVINGS_PLANS_UTILIZATION" | "SAVINGS_PLANS_COVERAGE" | (string & {});
export declare const BudgetType: any;
export type AutoAdjustType = "HISTORICAL" | "FORECAST" | (string & {});
export declare const AutoAdjustType: any;
export type AdjustmentPeriod = number;
export interface HistoricalOptions {
    BudgetAdjustmentPeriod: number;
    LookBackAvailablePeriods?: number;
}
export declare const HistoricalOptions: S.Schema<HistoricalOptions>;
export interface AutoAdjustData {
    AutoAdjustType: AutoAdjustType;
    HistoricalOptions?: HistoricalOptions;
    LastAutoAdjustTime?: Date;
}
export declare const AutoAdjustData: S.Schema<AutoAdjustData>;
export type Expressions = Expression[];
export declare const Expressions: S.Schema<Expressions>;
export type Dimension = "AZ" | "INSTANCE_TYPE" | "LINKED_ACCOUNT" | "LINKED_ACCOUNT_NAME" | "OPERATION" | "PURCHASE_TYPE" | "REGION" | "SERVICE" | "SERVICE_CODE" | "USAGE_TYPE" | "USAGE_TYPE_GROUP" | "RECORD_TYPE" | "OPERATING_SYSTEM" | "TENANCY" | "SCOPE" | "PLATFORM" | "SUBSCRIPTION_ID" | "LEGAL_ENTITY_NAME" | "INVOICING_ENTITY" | "DEPLOYMENT_OPTION" | "DATABASE_ENGINE" | "CACHE_ENGINE" | "INSTANCE_TYPE_FAMILY" | "BILLING_ENTITY" | "RESERVATION_ID" | "RESOURCE_ID" | "RIGHTSIZING_TYPE" | "SAVINGS_PLANS_TYPE" | "SAVINGS_PLAN_ARN" | "PAYMENT_OPTION" | "RESERVATION_MODIFIED" | "TAG_KEY" | "COST_CATEGORY_NAME" | (string & {});
export declare const Dimension: any;
export type Value = string;
export type Values = string[];
export declare const Values: any;
export type MatchOption = "EQUALS" | "ABSENT" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "GREATER_THAN_OR_EQUAL" | "CASE_SENSITIVE" | "CASE_INSENSITIVE" | (string & {});
export declare const MatchOption: any;
export type MatchOptions = MatchOption[];
export declare const MatchOptions: any;
export interface ExpressionDimensionValues {
    Key: Dimension;
    Values: string[];
    MatchOptions?: MatchOption[];
}
export declare const ExpressionDimensionValues: S.Schema<ExpressionDimensionValues>;
export type TagKey = string;
export interface TagValues {
    Key?: string;
    Values?: string[];
    MatchOptions?: MatchOption[];
}
export declare const TagValues: S.Schema<TagValues>;
export type CostCategoryName = string;
export interface CostCategoryValues {
    Key?: string;
    Values?: string[];
    MatchOptions?: MatchOption[];
}
export declare const CostCategoryValues: S.Schema<CostCategoryValues>;
export interface Expression {
    Or?: Expression[];
    And?: Expression[];
    Not?: Expression;
    Dimensions?: ExpressionDimensionValues;
    Tags?: TagValues;
    CostCategories?: CostCategoryValues;
}
export declare const Expression: S.Schema<Expression>;
export type Metric = "BlendedCost" | "UnblendedCost" | "AmortizedCost" | "NetUnblendedCost" | "NetAmortizedCost" | "UsageQuantity" | "NormalizedUsageAmount" | "Hours" | (string & {});
export declare const Metric: any;
export type Metrics = Metric[];
export declare const Metrics: any;
export type BillingViewArn = string;
export type HealthStatusValue = "HEALTHY" | "UNHEALTHY" | (string & {});
export declare const HealthStatusValue: any;
export type HealthStatusReason = "BILLING_VIEW_NO_ACCESS" | "BILLING_VIEW_UNHEALTHY" | "FILTER_INVALID" | "MULTI_YEAR_HISTORICAL_DATA_DISABLED" | (string & {});
export declare const HealthStatusReason: any;
export interface HealthStatus {
    Status?: HealthStatusValue;
    StatusReason?: HealthStatusReason;
    LastUpdatedTime?: Date;
}
export declare const HealthStatus: S.Schema<HealthStatus>;
export interface Budget {
    BudgetName: string;
    BudgetLimit?: Spend;
    PlannedBudgetLimits?: {
        [key: string]: Spend | undefined;
    };
    CostFilters?: {
        [key: string]: string[] | undefined;
    };
    CostTypes?: CostTypes;
    TimeUnit: TimeUnit;
    TimePeriod?: TimePeriod;
    CalculatedSpend?: CalculatedSpend;
    BudgetType: BudgetType;
    LastUpdatedTime?: Date;
    AutoAdjustData?: AutoAdjustData;
    FilterExpression?: Expression;
    Metrics?: Metric[];
    BillingViewArn?: string;
    HealthStatus?: HealthStatus;
}
export declare const Budget: S.Schema<Budget>;
export type NotificationType = "ACTUAL" | "FORECASTED" | (string & {});
export declare const NotificationType: any;
export type ComparisonOperator = "GREATER_THAN" | "LESS_THAN" | "EQUAL_TO" | (string & {});
export declare const ComparisonOperator: any;
export type NotificationThreshold = number;
export type ThresholdType = "PERCENTAGE" | "ABSOLUTE_VALUE" | (string & {});
export declare const ThresholdType: any;
export type NotificationState = "OK" | "ALARM" | (string & {});
export declare const NotificationState: any;
export interface Notification {
    NotificationType: NotificationType;
    ComparisonOperator: ComparisonOperator;
    Threshold: number;
    ThresholdType?: ThresholdType;
    NotificationState?: NotificationState;
}
export declare const Notification: S.Schema<Notification>;
export type SubscriptionType = "SNS" | "EMAIL" | (string & {});
export declare const SubscriptionType: any;
export type SubscriberAddress = string | redacted.Redacted<string>;
export interface Subscriber {
    SubscriptionType: SubscriptionType;
    Address: string | redacted.Redacted<string>;
}
export declare const Subscriber: S.Schema<Subscriber>;
export type Subscribers = Subscriber[];
export declare const Subscribers: any;
export interface NotificationWithSubscribers {
    Notification: Notification;
    Subscribers: Subscriber[];
}
export declare const NotificationWithSubscribers: S.Schema<NotificationWithSubscribers>;
export type NotificationWithSubscribersList = NotificationWithSubscribers[];
export declare const NotificationWithSubscribersList: any;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    Key: string;
    Value: string;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface CreateBudgetRequest {
    AccountId: string;
    Budget: Budget;
    NotificationsWithSubscribers?: NotificationWithSubscribers[];
    ResourceTags?: ResourceTag[];
}
export declare const CreateBudgetRequest: S.Schema<CreateBudgetRequest>;
export interface CreateBudgetResponse {
}
export declare const CreateBudgetResponse: S.Schema<CreateBudgetResponse>;
export type ActionType = "APPLY_IAM_POLICY" | "APPLY_SCP_POLICY" | "RUN_SSM_DOCUMENTS" | (string & {});
export declare const ActionType: any;
export interface ActionThreshold {
    ActionThresholdValue: number;
    ActionThresholdType: ThresholdType;
}
export declare const ActionThreshold: S.Schema<ActionThreshold>;
export type PolicyArn = string;
export type Role = string;
export type Roles = string[];
export declare const Roles: any;
export type Group = string;
export type Groups = string[];
export declare const Groups: any;
export type User = string;
export type Users = string[];
export declare const Users: any;
export interface IamActionDefinition {
    PolicyArn: string;
    Roles?: string[];
    Groups?: string[];
    Users?: string[];
}
export declare const IamActionDefinition: S.Schema<IamActionDefinition>;
export type PolicyId = string;
export type TargetId = string;
export type TargetIds = string[];
export declare const TargetIds: any;
export interface ScpActionDefinition {
    PolicyId: string;
    TargetIds: string[];
}
export declare const ScpActionDefinition: S.Schema<ScpActionDefinition>;
export type ActionSubType = "STOP_EC2_INSTANCES" | "STOP_RDS_INSTANCES" | (string & {});
export declare const ActionSubType: any;
export type Region = string;
export type InstanceId = string;
export type InstanceIds = string[];
export declare const InstanceIds: any;
export interface SsmActionDefinition {
    ActionSubType: ActionSubType;
    Region: string;
    InstanceIds: string[];
}
export declare const SsmActionDefinition: S.Schema<SsmActionDefinition>;
export interface Definition {
    IamActionDefinition?: IamActionDefinition;
    ScpActionDefinition?: ScpActionDefinition;
    SsmActionDefinition?: SsmActionDefinition;
}
export declare const Definition: S.Schema<Definition>;
export type RoleArn = string;
export type ApprovalModel = "AUTOMATIC" | "MANUAL" | (string & {});
export declare const ApprovalModel: any;
export interface CreateBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    NotificationType: NotificationType;
    ActionType: ActionType;
    ActionThreshold: ActionThreshold;
    Definition: Definition;
    ExecutionRoleArn: string;
    ApprovalModel: ApprovalModel;
    Subscribers: Subscriber[];
    ResourceTags?: ResourceTag[];
}
export declare const CreateBudgetActionRequest: S.Schema<CreateBudgetActionRequest>;
export type ActionId = string;
export interface CreateBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
}
export declare const CreateBudgetActionResponse: S.Schema<CreateBudgetActionResponse>;
export interface CreateNotificationRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    Subscribers: Subscriber[];
}
export declare const CreateNotificationRequest: S.Schema<CreateNotificationRequest>;
export interface CreateNotificationResponse {
}
export declare const CreateNotificationResponse: S.Schema<CreateNotificationResponse>;
export interface CreateSubscriberRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    Subscriber: Subscriber;
}
export declare const CreateSubscriberRequest: S.Schema<CreateSubscriberRequest>;
export interface CreateSubscriberResponse {
}
export declare const CreateSubscriberResponse: S.Schema<CreateSubscriberResponse>;
export interface DeleteBudgetRequest {
    AccountId: string;
    BudgetName: string;
}
export declare const DeleteBudgetRequest: S.Schema<DeleteBudgetRequest>;
export interface DeleteBudgetResponse {
}
export declare const DeleteBudgetResponse: S.Schema<DeleteBudgetResponse>;
export interface DeleteBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
}
export declare const DeleteBudgetActionRequest: S.Schema<DeleteBudgetActionRequest>;
export type ActionStatus = "STANDBY" | "PENDING" | "EXECUTION_IN_PROGRESS" | "EXECUTION_SUCCESS" | "EXECUTION_FAILURE" | "REVERSE_IN_PROGRESS" | "REVERSE_SUCCESS" | "REVERSE_FAILURE" | "RESET_IN_PROGRESS" | "RESET_FAILURE" | (string & {});
export declare const ActionStatus: any;
export interface Action {
    ActionId: string;
    BudgetName: string;
    NotificationType: NotificationType;
    ActionType: ActionType;
    ActionThreshold: ActionThreshold;
    Definition: Definition;
    ExecutionRoleArn: string;
    ApprovalModel: ApprovalModel;
    Status: ActionStatus;
    Subscribers: Subscriber[];
}
export declare const Action: S.Schema<Action>;
export interface DeleteBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    Action: Action;
}
export declare const DeleteBudgetActionResponse: S.Schema<DeleteBudgetActionResponse>;
export interface DeleteNotificationRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
}
export declare const DeleteNotificationRequest: S.Schema<DeleteNotificationRequest>;
export interface DeleteNotificationResponse {
}
export declare const DeleteNotificationResponse: S.Schema<DeleteNotificationResponse>;
export interface DeleteSubscriberRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    Subscriber: Subscriber;
}
export declare const DeleteSubscriberRequest: S.Schema<DeleteSubscriberRequest>;
export interface DeleteSubscriberResponse {
}
export declare const DeleteSubscriberResponse: S.Schema<DeleteSubscriberResponse>;
export interface DescribeBudgetRequest {
    AccountId: string;
    BudgetName: string;
    ShowFilterExpression?: boolean;
}
export declare const DescribeBudgetRequest: S.Schema<DescribeBudgetRequest>;
export interface DescribeBudgetResponse {
    Budget?: Budget;
}
export declare const DescribeBudgetResponse: S.Schema<DescribeBudgetResponse>;
export interface DescribeBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
}
export declare const DescribeBudgetActionRequest: S.Schema<DescribeBudgetActionRequest>;
export interface DescribeBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    Action: Action;
}
export declare const DescribeBudgetActionResponse: S.Schema<DescribeBudgetActionResponse>;
export type MaxResults = number;
export interface DescribeBudgetActionHistoriesRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    TimePeriod?: TimePeriod;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeBudgetActionHistoriesRequest: S.Schema<DescribeBudgetActionHistoriesRequest>;
export type EventType = "SYSTEM" | "CREATE_ACTION" | "DELETE_ACTION" | "UPDATE_ACTION" | "EXECUTE_ACTION" | (string & {});
export declare const EventType: any;
export interface ActionHistoryDetails {
    Message: string;
    Action: Action;
}
export declare const ActionHistoryDetails: S.Schema<ActionHistoryDetails>;
export interface ActionHistory {
    Timestamp: Date;
    Status: ActionStatus;
    EventType: EventType;
    ActionHistoryDetails: ActionHistoryDetails;
}
export declare const ActionHistory: S.Schema<ActionHistory>;
export type ActionHistories = ActionHistory[];
export declare const ActionHistories: any;
export interface DescribeBudgetActionHistoriesResponse {
    ActionHistories: ActionHistory[];
    NextToken?: string;
}
export declare const DescribeBudgetActionHistoriesResponse: S.Schema<DescribeBudgetActionHistoriesResponse>;
export interface DescribeBudgetActionsForAccountRequest {
    AccountId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeBudgetActionsForAccountRequest: S.Schema<DescribeBudgetActionsForAccountRequest>;
export type Actions = Action[];
export declare const Actions: any;
export interface DescribeBudgetActionsForAccountResponse {
    Actions: Action[];
    NextToken?: string;
}
export declare const DescribeBudgetActionsForAccountResponse: S.Schema<DescribeBudgetActionsForAccountResponse>;
export interface DescribeBudgetActionsForBudgetRequest {
    AccountId: string;
    BudgetName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeBudgetActionsForBudgetRequest: S.Schema<DescribeBudgetActionsForBudgetRequest>;
export interface DescribeBudgetActionsForBudgetResponse {
    Actions: Action[];
    NextToken?: string;
}
export declare const DescribeBudgetActionsForBudgetResponse: S.Schema<DescribeBudgetActionsForBudgetResponse>;
export type MaxResultsBudgetNotifications = number;
export interface DescribeBudgetNotificationsForAccountRequest {
    AccountId: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeBudgetNotificationsForAccountRequest: S.Schema<DescribeBudgetNotificationsForAccountRequest>;
export type Notifications = Notification[];
export declare const Notifications: any;
export interface BudgetNotificationsForAccount {
    Notifications?: Notification[];
    BudgetName?: string;
}
export declare const BudgetNotificationsForAccount: S.Schema<BudgetNotificationsForAccount>;
export type BudgetNotificationsForAccountList = BudgetNotificationsForAccount[];
export declare const BudgetNotificationsForAccountList: any;
export interface DescribeBudgetNotificationsForAccountResponse {
    BudgetNotificationsForAccount?: BudgetNotificationsForAccount[];
    NextToken?: string;
}
export declare const DescribeBudgetNotificationsForAccountResponse: S.Schema<DescribeBudgetNotificationsForAccountResponse>;
export interface DescribeBudgetPerformanceHistoryRequest {
    AccountId: string;
    BudgetName: string;
    TimePeriod?: TimePeriod;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeBudgetPerformanceHistoryRequest: S.Schema<DescribeBudgetPerformanceHistoryRequest>;
export interface BudgetedAndActualAmounts {
    BudgetedAmount?: Spend;
    ActualAmount?: Spend;
    TimePeriod?: TimePeriod;
}
export declare const BudgetedAndActualAmounts: S.Schema<BudgetedAndActualAmounts>;
export type BudgetedAndActualAmountsList = BudgetedAndActualAmounts[];
export declare const BudgetedAndActualAmountsList: any;
export interface BudgetPerformanceHistory {
    BudgetName?: string;
    BudgetType?: BudgetType;
    CostFilters?: {
        [key: string]: string[] | undefined;
    };
    CostTypes?: CostTypes;
    TimeUnit?: TimeUnit;
    BillingViewArn?: string;
    BudgetedAndActualAmountsList?: BudgetedAndActualAmounts[];
    FilterExpression?: Expression;
    Metrics?: Metric[];
}
export declare const BudgetPerformanceHistory: S.Schema<BudgetPerformanceHistory>;
export interface DescribeBudgetPerformanceHistoryResponse {
    BudgetPerformanceHistory?: BudgetPerformanceHistory;
    NextToken?: string;
}
export declare const DescribeBudgetPerformanceHistoryResponse: S.Schema<DescribeBudgetPerformanceHistoryResponse>;
export type MaxResultsDescribeBudgets = number;
export interface DescribeBudgetsRequest {
    AccountId: string;
    MaxResults?: number;
    NextToken?: string;
    ShowFilterExpression?: boolean;
}
export declare const DescribeBudgetsRequest: S.Schema<DescribeBudgetsRequest>;
export type Budgets = Budget[];
export declare const Budgets: any;
export interface DescribeBudgetsResponse {
    Budgets?: Budget[];
    NextToken?: string;
}
export declare const DescribeBudgetsResponse: S.Schema<DescribeBudgetsResponse>;
export interface DescribeNotificationsForBudgetRequest {
    AccountId: string;
    BudgetName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeNotificationsForBudgetRequest: S.Schema<DescribeNotificationsForBudgetRequest>;
export interface DescribeNotificationsForBudgetResponse {
    Notifications?: Notification[];
    NextToken?: string;
}
export declare const DescribeNotificationsForBudgetResponse: S.Schema<DescribeNotificationsForBudgetResponse>;
export interface DescribeSubscribersForNotificationRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeSubscribersForNotificationRequest: S.Schema<DescribeSubscribersForNotificationRequest>;
export interface DescribeSubscribersForNotificationResponse {
    Subscribers?: Subscriber[];
    NextToken?: string;
}
export declare const DescribeSubscribersForNotificationResponse: S.Schema<DescribeSubscribersForNotificationResponse>;
export type ExecutionType = "APPROVE_BUDGET_ACTION" | "RETRY_BUDGET_ACTION" | "REVERSE_BUDGET_ACTION" | "RESET_BUDGET_ACTION" | (string & {});
export declare const ExecutionType: any;
export interface ExecuteBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    ExecutionType: ExecutionType;
}
export declare const ExecuteBudgetActionRequest: S.Schema<ExecuteBudgetActionRequest>;
export interface ExecuteBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    ExecutionType: ExecutionType;
}
export declare const ExecuteBudgetActionResponse: S.Schema<ExecuteBudgetActionResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    ResourceARN: string;
    ResourceTags: ResourceTag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ResourceTagKeyList = string[];
export declare const ResourceTagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    ResourceTagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateBudgetRequest {
    AccountId: string;
    NewBudget: Budget;
}
export declare const UpdateBudgetRequest: S.Schema<UpdateBudgetRequest>;
export interface UpdateBudgetResponse {
}
export declare const UpdateBudgetResponse: S.Schema<UpdateBudgetResponse>;
export interface UpdateBudgetActionRequest {
    AccountId: string;
    BudgetName: string;
    ActionId: string;
    NotificationType?: NotificationType;
    ActionThreshold?: ActionThreshold;
    Definition?: Definition;
    ExecutionRoleArn?: string;
    ApprovalModel?: ApprovalModel;
    Subscribers?: Subscriber[];
}
export declare const UpdateBudgetActionRequest: S.Schema<UpdateBudgetActionRequest>;
export interface UpdateBudgetActionResponse {
    AccountId: string;
    BudgetName: string;
    OldAction: Action;
    NewAction: Action;
}
export declare const UpdateBudgetActionResponse: S.Schema<UpdateBudgetActionResponse>;
export interface UpdateNotificationRequest {
    AccountId: string;
    BudgetName: string;
    OldNotification: Notification;
    NewNotification: Notification;
}
export declare const UpdateNotificationRequest: S.Schema<UpdateNotificationRequest>;
export interface UpdateNotificationResponse {
}
export declare const UpdateNotificationResponse: S.Schema<UpdateNotificationResponse>;
export interface UpdateSubscriberRequest {
    AccountId: string;
    BudgetName: string;
    Notification: Notification;
    OldSubscriber: Subscriber;
    NewSubscriber: Subscriber;
}
export declare const UpdateSubscriberRequest: S.Schema<UpdateSubscriberRequest>;
export interface UpdateSubscriberResponse {
}
export declare const UpdateSubscriberResponse: S.Schema<UpdateSubscriberResponse>;
export type ErrorMessage = string;
export type CreateBudgetError = AccessDeniedException | BillingViewHealthStatusException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a budget and, if included, notifications and subscribers.
 *
 * Only one of `BudgetLimit` or `PlannedBudgetLimits` can be present in
 * the syntax at one time. Use the syntax that matches your use case. The Request Syntax
 * section shows the `BudgetLimit` syntax. For `PlannedBudgetLimits`,
 * see the Examples section.
 *
 * Similarly, only one set of filter and metric selections can be present in the syntax
 * at one time. Either `FilterExpression` and `Metrics` or
 * `CostFilters` and `CostTypes`, not both or a different
 * combination. We recommend using `FilterExpression` and `Metrics`
 * as they provide more flexible and powerful filtering capabilities. The Request Syntax
 * section shows the `FilterExpression`/`Metrics` syntax.
 */
export declare const createBudget: API.OperationMethod<CreateBudgetRequest, CreateBudgetResponse, CreateBudgetError, Credentials | HttpClient.HttpClient>;
export type CreateBudgetActionError = AccessDeniedException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a budget action.
 */
export declare const createBudgetAction: API.OperationMethod<CreateBudgetActionRequest, CreateBudgetActionResponse, CreateBudgetActionError, Credentials | HttpClient.HttpClient>;
export type CreateNotificationError = AccessDeniedException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a notification. You must create the budget before you create the associated notification.
 */
export declare const createNotification: API.OperationMethod<CreateNotificationRequest, CreateNotificationResponse, CreateNotificationError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriberError = AccessDeniedException | CreationLimitExceededException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a subscriber. You must create the associated budget and notification before you create the subscriber.
 */
export declare const createSubscriber: API.OperationMethod<CreateSubscriberRequest, CreateSubscriberResponse, CreateSubscriberError, Credentials | HttpClient.HttpClient>;
export type DeleteBudgetError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a budget. You can delete your budget at any time.
 *
 * Deleting a budget also deletes the notifications and subscribers that are associated with that budget.
 */
export declare const deleteBudget: API.OperationMethod<DeleteBudgetRequest, DeleteBudgetResponse, DeleteBudgetError, Credentials | HttpClient.HttpClient>;
export type DeleteBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ResourceLockedException | ThrottlingException | CommonErrors;
/**
 * Deletes a budget action.
 */
export declare const deleteBudgetAction: API.OperationMethod<DeleteBudgetActionRequest, DeleteBudgetActionResponse, DeleteBudgetActionError, Credentials | HttpClient.HttpClient>;
export type DeleteNotificationError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a notification.
 *
 * Deleting a notification also deletes the subscribers that are associated with the notification.
 */
export declare const deleteNotification: API.OperationMethod<DeleteNotificationRequest, DeleteNotificationResponse, DeleteNotificationError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriberError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a subscriber.
 *
 * Deleting the last subscriber to a notification also deletes the notification.
 */
export declare const deleteSubscriber: API.OperationMethod<DeleteSubscriberRequest, DeleteSubscriberResponse, DeleteSubscriberError, Credentials | HttpClient.HttpClient>;
export type DescribeBudgetError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a budget.
 *
 * The Request Syntax section shows the `BudgetLimit` syntax. For
 * `PlannedBudgetLimits`, see the Examples section.
 */
export declare const describeBudget: API.OperationMethod<DescribeBudgetRequest, DescribeBudgetResponse, DescribeBudgetError, Credentials | HttpClient.HttpClient>;
export type DescribeBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a budget action detail.
 */
export declare const describeBudgetAction: API.OperationMethod<DescribeBudgetActionRequest, DescribeBudgetActionResponse, DescribeBudgetActionError, Credentials | HttpClient.HttpClient>;
export type DescribeBudgetActionHistoriesError = AccessDeniedException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a budget action history detail.
 */
export declare const describeBudgetActionHistories: API.PaginatedOperationMethod<DescribeBudgetActionHistoriesRequest, DescribeBudgetActionHistoriesResponse, DescribeBudgetActionHistoriesError, Credentials | HttpClient.HttpClient, ActionHistory>;
export type DescribeBudgetActionsForAccountError = AccessDeniedException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Describes all of the budget actions for an account.
 */
export declare const describeBudgetActionsForAccount: API.PaginatedOperationMethod<DescribeBudgetActionsForAccountRequest, DescribeBudgetActionsForAccountResponse, DescribeBudgetActionsForAccountError, Credentials | HttpClient.HttpClient, Action>;
export type DescribeBudgetActionsForBudgetError = AccessDeniedException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes all of the budget actions for a budget.
 */
export declare const describeBudgetActionsForBudget: API.PaginatedOperationMethod<DescribeBudgetActionsForBudgetRequest, DescribeBudgetActionsForBudgetResponse, DescribeBudgetActionsForBudgetError, Credentials | HttpClient.HttpClient, Action>;
export type DescribeBudgetNotificationsForAccountError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the budget names and notifications that are associated with an account.
 */
export declare const describeBudgetNotificationsForAccount: API.PaginatedOperationMethod<DescribeBudgetNotificationsForAccountRequest, DescribeBudgetNotificationsForAccountResponse, DescribeBudgetNotificationsForAccountError, Credentials | HttpClient.HttpClient, BudgetNotificationsForAccount>;
export type DescribeBudgetPerformanceHistoryError = AccessDeniedException | BillingViewHealthStatusException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the history for `DAILY`, `MONTHLY`, and `QUARTERLY` budgets. Budget history isn't available for `ANNUAL` budgets.
 */
export declare const describeBudgetPerformanceHistory: API.PaginatedOperationMethod<DescribeBudgetPerformanceHistoryRequest, DescribeBudgetPerformanceHistoryResponse, DescribeBudgetPerformanceHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeBudgetsError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the budgets that are associated with an account.
 *
 * The Request Syntax section shows the `BudgetLimit` syntax. For
 * `PlannedBudgetLimits`, see the Examples section.
 */
export declare const describeBudgets: API.PaginatedOperationMethod<DescribeBudgetsRequest, DescribeBudgetsResponse, DescribeBudgetsError, Credentials | HttpClient.HttpClient, Budget>;
export type DescribeNotificationsForBudgetError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the notifications that are associated with a budget.
 */
export declare const describeNotificationsForBudget: API.PaginatedOperationMethod<DescribeNotificationsForBudgetRequest, DescribeNotificationsForBudgetResponse, DescribeNotificationsForBudgetError, Credentials | HttpClient.HttpClient, Notification>;
export type DescribeSubscribersForNotificationError = AccessDeniedException | ExpiredNextTokenException | InternalErrorException | InvalidNextTokenException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the subscribers that are associated with a notification.
 */
export declare const describeSubscribersForNotification: API.PaginatedOperationMethod<DescribeSubscribersForNotificationRequest, DescribeSubscribersForNotificationResponse, DescribeSubscribersForNotificationError, Credentials | HttpClient.HttpClient, Subscriber>;
export type ExecuteBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ResourceLockedException | ThrottlingException | CommonErrors;
/**
 * Executes a budget action.
 */
export declare const executeBudgetAction: API.OperationMethod<ExecuteBudgetActionRequest, ExecuteBudgetActionResponse, ExecuteBudgetActionError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists tags associated with a budget or budget action resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Creates tags for a budget or budget action resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes tags associated with a budget or budget action resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBudgetError = AccessDeniedException | BillingViewHealthStatusException | InternalErrorException | InvalidParameterException | NotFoundException | ServiceQuotaExceededException | ThrottlingException | CommonErrors;
/**
 * Updates a budget. You can change every part of a budget except for the `budgetName` and the `calculatedSpend`. When you modify a budget, the `calculatedSpend` drops to zero until Amazon Web Services has new usage data to use for forecasting.
 *
 * Only one of `BudgetLimit` or `PlannedBudgetLimits` can be present in
 * the syntax at one time. Use the syntax that matches your case. The Request Syntax
 * section shows the `BudgetLimit` syntax. For `PlannedBudgetLimits`,
 * see the Examples section.
 *
 * Similarly, only one set of filter and metric selections can be present in the syntax
 * at one time. Either `FilterExpression` and `Metrics` or
 * `CostFilters` and `CostTypes`, not both or a different
 * combination. We recommend using `FilterExpression` and `Metrics`
 * as they provide more flexible and powerful filtering capabilities. The Request Syntax
 * section shows the `FilterExpression`/`Metrics` syntax.
 */
export declare const updateBudget: API.OperationMethod<UpdateBudgetRequest, UpdateBudgetResponse, UpdateBudgetError, Credentials | HttpClient.HttpClient>;
export type UpdateBudgetActionError = AccessDeniedException | InternalErrorException | InvalidParameterException | NotFoundException | ResourceLockedException | ThrottlingException | CommonErrors;
/**
 * Updates a budget action.
 */
export declare const updateBudgetAction: API.OperationMethod<UpdateBudgetActionRequest, UpdateBudgetActionResponse, UpdateBudgetActionError, Credentials | HttpClient.HttpClient>;
export type UpdateNotificationError = AccessDeniedException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a notification.
 */
export declare const updateNotification: API.OperationMethod<UpdateNotificationRequest, UpdateNotificationResponse, UpdateNotificationError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriberError = AccessDeniedException | DuplicateRecordException | InternalErrorException | InvalidParameterException | NotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a subscriber.
 */
export declare const updateSubscriber: API.OperationMethod<UpdateSubscriberRequest, UpdateSubscriberResponse, UpdateSubscriberError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=budgets.d.ts.map