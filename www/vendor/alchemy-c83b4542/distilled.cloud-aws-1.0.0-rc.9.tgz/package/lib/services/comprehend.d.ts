import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BatchSizeLimitExceededException_base: S.Class<BatchSizeLimitExceededException, S.TaggedStruct<"BatchSizeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BatchSizeLimitExceededException extends /*@__PURE__*/ BatchSizeLimitExceededException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidFilterException_base: S.Class<InvalidFilterException, S.TaggedStruct<"InvalidFilterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFilterException extends /*@__PURE__*/ InvalidFilterException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
    readonly Reason: any;
    readonly Detail: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const JobNotFoundException_base: S.Class<JobNotFoundException, S.TaggedStruct<"JobNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class JobNotFoundException extends /*@__PURE__*/ JobNotFoundException_base {
}
declare const KmsKeyValidationException_base: S.Class<KmsKeyValidationException, S.TaggedStruct<"KmsKeyValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KmsKeyValidationException extends /*@__PURE__*/ KmsKeyValidationException_base {
}
declare const NotAuthorizedException_base: S.Class<NotAuthorizedException, S.TaggedStruct<"NotAuthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class NotAuthorizedException extends /*@__PURE__*/ NotAuthorizedException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceLimitExceededException_base: S.Class<ResourceLimitExceededException, S.TaggedStruct<"ResourceLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.Class<ResourceUnavailableException, S.TaggedStruct<"ResourceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const TextSizeLimitExceededException_base: S.Class<TextSizeLimitExceededException, S.TaggedStruct<"TextSizeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TextSizeLimitExceededException extends /*@__PURE__*/ TextSizeLimitExceededException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TooManyTagKeysException_base: S.Class<TooManyTagKeysException, S.TaggedStruct<"TooManyTagKeysException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagKeysException extends /*@__PURE__*/ TooManyTagKeysException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnsupportedLanguageException_base: S.Class<UnsupportedLanguageException, S.TaggedStruct<"UnsupportedLanguageException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedLanguageException extends /*@__PURE__*/ UnsupportedLanguageException_base {
}
export type CustomerInputString = string | redacted.Redacted<string>;
export type CustomerInputStringList = (string | redacted.Redacted<string>)[];
export declare const CustomerInputStringList: any;
export interface BatchDetectDominantLanguageRequest {
    TextList: (string | redacted.Redacted<string>)[];
}
export declare const BatchDetectDominantLanguageRequest: S.Schema<BatchDetectDominantLanguageRequest>;
export interface DominantLanguage {
    LanguageCode?: string;
    Score?: number;
}
export declare const DominantLanguage: S.Schema<DominantLanguage>;
export type ListOfDominantLanguages = DominantLanguage[];
export declare const ListOfDominantLanguages: any;
export interface BatchDetectDominantLanguageItemResult {
    Index?: number;
    Languages?: DominantLanguage[];
}
export declare const BatchDetectDominantLanguageItemResult: S.Schema<BatchDetectDominantLanguageItemResult>;
export type ListOfDetectDominantLanguageResult = BatchDetectDominantLanguageItemResult[];
export declare const ListOfDetectDominantLanguageResult: any;
export interface BatchItemError {
    Index?: number;
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const BatchItemError: S.Schema<BatchItemError>;
export type BatchItemErrorList = BatchItemError[];
export declare const BatchItemErrorList: any;
export interface BatchDetectDominantLanguageResponse {
    ResultList: BatchDetectDominantLanguageItemResult[];
    ErrorList: BatchItemError[];
}
export declare const BatchDetectDominantLanguageResponse: S.Schema<BatchDetectDominantLanguageResponse>;
export type LanguageCode = "en" | "es" | "fr" | "de" | "it" | "pt" | "ar" | "hi" | "ja" | "ko" | "zh" | "zh-TW" | (string & {});
export declare const LanguageCode: any;
export interface BatchDetectEntitiesRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export declare const BatchDetectEntitiesRequest: S.Schema<BatchDetectEntitiesRequest>;
export type EntityType = "PERSON" | "LOCATION" | "ORGANIZATION" | "COMMERCIAL_ITEM" | "EVENT" | "DATE" | "QUANTITY" | "TITLE" | "OTHER" | (string & {});
export declare const EntityType: any;
export interface ChildBlock {
    ChildBlockId?: string;
    BeginOffset?: number;
    EndOffset?: number;
}
export declare const ChildBlock: S.Schema<ChildBlock>;
export type ListOfChildBlocks = ChildBlock[];
export declare const ListOfChildBlocks: any;
export interface BlockReference {
    BlockId?: string;
    BeginOffset?: number;
    EndOffset?: number;
    ChildBlocks?: ChildBlock[];
}
export declare const BlockReference: S.Schema<BlockReference>;
export type ListOfBlockReferences = BlockReference[];
export declare const ListOfBlockReferences: any;
export interface Entity {
    Score?: number;
    Type?: EntityType;
    Text?: string;
    BeginOffset?: number;
    EndOffset?: number;
    BlockReferences?: BlockReference[];
}
export declare const Entity: S.Schema<Entity>;
export type ListOfEntities = Entity[];
export declare const ListOfEntities: any;
export interface BatchDetectEntitiesItemResult {
    Index?: number;
    Entities?: Entity[];
}
export declare const BatchDetectEntitiesItemResult: S.Schema<BatchDetectEntitiesItemResult>;
export type ListOfDetectEntitiesResult = BatchDetectEntitiesItemResult[];
export declare const ListOfDetectEntitiesResult: any;
export interface BatchDetectEntitiesResponse {
    ResultList: BatchDetectEntitiesItemResult[];
    ErrorList: BatchItemError[];
}
export declare const BatchDetectEntitiesResponse: S.Schema<BatchDetectEntitiesResponse>;
export interface BatchDetectKeyPhrasesRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export declare const BatchDetectKeyPhrasesRequest: S.Schema<BatchDetectKeyPhrasesRequest>;
export interface KeyPhrase {
    Score?: number;
    Text?: string;
    BeginOffset?: number;
    EndOffset?: number;
}
export declare const KeyPhrase: S.Schema<KeyPhrase>;
export type ListOfKeyPhrases = KeyPhrase[];
export declare const ListOfKeyPhrases: any;
export interface BatchDetectKeyPhrasesItemResult {
    Index?: number;
    KeyPhrases?: KeyPhrase[];
}
export declare const BatchDetectKeyPhrasesItemResult: S.Schema<BatchDetectKeyPhrasesItemResult>;
export type ListOfDetectKeyPhrasesResult = BatchDetectKeyPhrasesItemResult[];
export declare const ListOfDetectKeyPhrasesResult: any;
export interface BatchDetectKeyPhrasesResponse {
    ResultList: BatchDetectKeyPhrasesItemResult[];
    ErrorList: BatchItemError[];
}
export declare const BatchDetectKeyPhrasesResponse: S.Schema<BatchDetectKeyPhrasesResponse>;
export interface BatchDetectSentimentRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export declare const BatchDetectSentimentRequest: S.Schema<BatchDetectSentimentRequest>;
export type SentimentType = "POSITIVE" | "NEGATIVE" | "NEUTRAL" | "MIXED" | (string & {});
export declare const SentimentType: any;
export interface SentimentScore {
    Positive?: number;
    Negative?: number;
    Neutral?: number;
    Mixed?: number;
}
export declare const SentimentScore: S.Schema<SentimentScore>;
export interface BatchDetectSentimentItemResult {
    Index?: number;
    Sentiment?: SentimentType;
    SentimentScore?: SentimentScore;
}
export declare const BatchDetectSentimentItemResult: S.Schema<BatchDetectSentimentItemResult>;
export type ListOfDetectSentimentResult = BatchDetectSentimentItemResult[];
export declare const ListOfDetectSentimentResult: any;
export interface BatchDetectSentimentResponse {
    ResultList: BatchDetectSentimentItemResult[];
    ErrorList: BatchItemError[];
}
export declare const BatchDetectSentimentResponse: S.Schema<BatchDetectSentimentResponse>;
export type SyntaxLanguageCode = "en" | "es" | "fr" | "de" | "it" | "pt" | (string & {});
export declare const SyntaxLanguageCode: any;
export interface BatchDetectSyntaxRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: SyntaxLanguageCode;
}
export declare const BatchDetectSyntaxRequest: S.Schema<BatchDetectSyntaxRequest>;
export type PartOfSpeechTagType = "ADJ" | "ADP" | "ADV" | "AUX" | "CONJ" | "CCONJ" | "DET" | "INTJ" | "NOUN" | "NUM" | "O" | "PART" | "PRON" | "PROPN" | "PUNCT" | "SCONJ" | "SYM" | "VERB" | (string & {});
export declare const PartOfSpeechTagType: any;
export interface PartOfSpeechTag {
    Tag?: PartOfSpeechTagType;
    Score?: number;
}
export declare const PartOfSpeechTag: S.Schema<PartOfSpeechTag>;
export interface SyntaxToken {
    TokenId?: number;
    Text?: string;
    BeginOffset?: number;
    EndOffset?: number;
    PartOfSpeech?: PartOfSpeechTag;
}
export declare const SyntaxToken: S.Schema<SyntaxToken>;
export type ListOfSyntaxTokens = SyntaxToken[];
export declare const ListOfSyntaxTokens: any;
export interface BatchDetectSyntaxItemResult {
    Index?: number;
    SyntaxTokens?: SyntaxToken[];
}
export declare const BatchDetectSyntaxItemResult: S.Schema<BatchDetectSyntaxItemResult>;
export type ListOfDetectSyntaxResult = BatchDetectSyntaxItemResult[];
export declare const ListOfDetectSyntaxResult: any;
export interface BatchDetectSyntaxResponse {
    ResultList: BatchDetectSyntaxItemResult[];
    ErrorList: BatchItemError[];
}
export declare const BatchDetectSyntaxResponse: S.Schema<BatchDetectSyntaxResponse>;
export interface BatchDetectTargetedSentimentRequest {
    TextList: (string | redacted.Redacted<string>)[];
    LanguageCode: LanguageCode;
}
export declare const BatchDetectTargetedSentimentRequest: S.Schema<BatchDetectTargetedSentimentRequest>;
export type ListOfDescriptiveMentionIndices = number[];
export declare const ListOfDescriptiveMentionIndices: any;
export type TargetedSentimentEntityType = "PERSON" | "LOCATION" | "ORGANIZATION" | "FACILITY" | "BRAND" | "COMMERCIAL_ITEM" | "MOVIE" | "MUSIC" | "BOOK" | "SOFTWARE" | "GAME" | "PERSONAL_TITLE" | "EVENT" | "DATE" | "QUANTITY" | "ATTRIBUTE" | "OTHER" | (string & {});
export declare const TargetedSentimentEntityType: any;
export interface MentionSentiment {
    Sentiment?: SentimentType;
    SentimentScore?: SentimentScore;
}
export declare const MentionSentiment: S.Schema<MentionSentiment>;
export interface TargetedSentimentMention {
    Score?: number;
    GroupScore?: number;
    Text?: string;
    Type?: TargetedSentimentEntityType;
    MentionSentiment?: MentionSentiment;
    BeginOffset?: number;
    EndOffset?: number;
}
export declare const TargetedSentimentMention: S.Schema<TargetedSentimentMention>;
export type ListOfMentions = TargetedSentimentMention[];
export declare const ListOfMentions: any;
export interface TargetedSentimentEntity {
    DescriptiveMentionIndex?: number[];
    Mentions?: TargetedSentimentMention[];
}
export declare const TargetedSentimentEntity: S.Schema<TargetedSentimentEntity>;
export type ListOfTargetedSentimentEntities = TargetedSentimentEntity[];
export declare const ListOfTargetedSentimentEntities: any;
export interface BatchDetectTargetedSentimentItemResult {
    Index?: number;
    Entities?: TargetedSentimentEntity[];
}
export declare const BatchDetectTargetedSentimentItemResult: S.Schema<BatchDetectTargetedSentimentItemResult>;
export type ListOfDetectTargetedSentimentResult = BatchDetectTargetedSentimentItemResult[];
export declare const ListOfDetectTargetedSentimentResult: any;
export interface BatchDetectTargetedSentimentResponse {
    ResultList: BatchDetectTargetedSentimentItemResult[];
    ErrorList: BatchItemError[];
}
export declare const BatchDetectTargetedSentimentResponse: S.Schema<BatchDetectTargetedSentimentResponse>;
export type DocumentClassifierEndpointArn = string;
export type SemiStructuredDocumentBlob = Uint8Array;
export type DocumentReadAction = "TEXTRACT_DETECT_DOCUMENT_TEXT" | "TEXTRACT_ANALYZE_DOCUMENT" | (string & {});
export declare const DocumentReadAction: any;
export type DocumentReadMode = "SERVICE_DEFAULT" | "FORCE_DOCUMENT_READ_ACTION" | (string & {});
export declare const DocumentReadMode: any;
export type DocumentReadFeatureTypes = "TABLES" | "FORMS" | (string & {});
export declare const DocumentReadFeatureTypes: any;
export type ListOfDocumentReadFeatureTypes = DocumentReadFeatureTypes[];
export declare const ListOfDocumentReadFeatureTypes: any;
export interface DocumentReaderConfig {
    DocumentReadAction: DocumentReadAction;
    DocumentReadMode?: DocumentReadMode;
    FeatureTypes?: DocumentReadFeatureTypes[];
}
export declare const DocumentReaderConfig: S.Schema<DocumentReaderConfig>;
export interface ClassifyDocumentRequest {
    Text?: string | redacted.Redacted<string>;
    EndpointArn: string;
    Bytes?: Uint8Array;
    DocumentReaderConfig?: DocumentReaderConfig;
}
export declare const ClassifyDocumentRequest: S.Schema<ClassifyDocumentRequest>;
export interface DocumentClass {
    Name?: string;
    Score?: number;
    Page?: number;
}
export declare const DocumentClass: S.Schema<DocumentClass>;
export type ListOfClasses = DocumentClass[];
export declare const ListOfClasses: any;
export interface DocumentLabel {
    Name?: string;
    Score?: number;
    Page?: number;
}
export declare const DocumentLabel: S.Schema<DocumentLabel>;
export type ListOfLabels = DocumentLabel[];
export declare const ListOfLabels: any;
export interface ExtractedCharactersListItem {
    Page?: number;
    Count?: number;
}
export declare const ExtractedCharactersListItem: S.Schema<ExtractedCharactersListItem>;
export type ListOfExtractedCharacters = ExtractedCharactersListItem[];
export declare const ListOfExtractedCharacters: any;
export interface DocumentMetadata {
    Pages?: number;
    ExtractedCharacters?: ExtractedCharactersListItem[];
}
export declare const DocumentMetadata: S.Schema<DocumentMetadata>;
export type DocumentType = "NATIVE_PDF" | "SCANNED_PDF" | "MS_WORD" | "IMAGE" | "PLAIN_TEXT" | "TEXTRACT_DETECT_DOCUMENT_TEXT_JSON" | "TEXTRACT_ANALYZE_DOCUMENT_JSON" | (string & {});
export declare const DocumentType: any;
export interface DocumentTypeListItem {
    Page?: number;
    Type?: DocumentType;
}
export declare const DocumentTypeListItem: S.Schema<DocumentTypeListItem>;
export type ListOfDocumentType = DocumentTypeListItem[];
export declare const ListOfDocumentType: any;
export type PageBasedErrorCode = "TEXTRACT_BAD_PAGE" | "TEXTRACT_PROVISIONED_THROUGHPUT_EXCEEDED" | "PAGE_CHARACTERS_EXCEEDED" | "PAGE_SIZE_EXCEEDED" | "INTERNAL_SERVER_ERROR" | (string & {});
export declare const PageBasedErrorCode: any;
export interface ErrorsListItem {
    Page?: number;
    ErrorCode?: PageBasedErrorCode;
    ErrorMessage?: string;
}
export declare const ErrorsListItem: S.Schema<ErrorsListItem>;
export type ListOfErrors = ErrorsListItem[];
export declare const ListOfErrors: any;
export type PageBasedWarningCode = "INFERENCING_PLAINTEXT_WITH_NATIVE_TRAINED_MODEL" | "INFERENCING_NATIVE_DOCUMENT_WITH_PLAINTEXT_TRAINED_MODEL" | (string & {});
export declare const PageBasedWarningCode: any;
export interface WarningsListItem {
    Page?: number;
    WarnCode?: PageBasedWarningCode;
    WarnMessage?: string;
}
export declare const WarningsListItem: S.Schema<WarningsListItem>;
export type ListOfWarnings = WarningsListItem[];
export declare const ListOfWarnings: any;
export interface ClassifyDocumentResponse {
    Classes?: DocumentClass[];
    Labels?: DocumentLabel[];
    DocumentMetadata?: DocumentMetadata;
    DocumentType?: DocumentTypeListItem[];
    Errors?: ErrorsListItem[];
    Warnings?: WarningsListItem[];
}
export declare const ClassifyDocumentResponse: S.Schema<ClassifyDocumentResponse>;
export interface ContainsPiiEntitiesRequest {
    Text: string;
    LanguageCode: LanguageCode;
}
export declare const ContainsPiiEntitiesRequest: S.Schema<ContainsPiiEntitiesRequest>;
export type PiiEntityType = "BANK_ACCOUNT_NUMBER" | "BANK_ROUTING" | "CREDIT_DEBIT_NUMBER" | "CREDIT_DEBIT_CVV" | "CREDIT_DEBIT_EXPIRY" | "PIN" | "EMAIL" | "ADDRESS" | "NAME" | "PHONE" | "SSN" | "DATE_TIME" | "PASSPORT_NUMBER" | "DRIVER_ID" | "URL" | "AGE" | "USERNAME" | "PASSWORD" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "IP_ADDRESS" | "MAC_ADDRESS" | "ALL" | "LICENSE_PLATE" | "VEHICLE_IDENTIFICATION_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "IN_PERMANENT_ACCOUNT_NUMBER" | "IN_NREGA" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "CA_HEALTH_NUMBER" | "IN_AADHAAR" | "IN_VOTER_NUMBER" | (string & {});
export declare const PiiEntityType: any;
export interface EntityLabel {
    Name?: PiiEntityType;
    Score?: number;
}
export declare const EntityLabel: S.Schema<EntityLabel>;
export type ListOfEntityLabels = EntityLabel[];
export declare const ListOfEntityLabels: any;
export interface ContainsPiiEntitiesResponse {
    Labels?: EntityLabel[];
}
export declare const ContainsPiiEntitiesResponse: S.Schema<ContainsPiiEntitiesResponse>;
export type ComprehendFlywheelArn = string;
export type ComprehendArnName = string;
export type DatasetType = "TRAIN" | "TEST" | (string & {});
export declare const DatasetType: any;
export type Description = string;
export type AttributeNamesListItem = string;
export type AttributeNamesList = string[];
export declare const AttributeNamesList: any;
export type S3Uri = string;
export type AugmentedManifestsDocumentTypeFormat = "PLAIN_TEXT_DOCUMENT" | "SEMI_STRUCTURED_DOCUMENT" | (string & {});
export declare const AugmentedManifestsDocumentTypeFormat: any;
export interface DatasetAugmentedManifestsListItem {
    AttributeNames: string[];
    S3Uri: string;
    AnnotationDataS3Uri?: string;
    SourceDocumentsS3Uri?: string;
    DocumentType?: AugmentedManifestsDocumentTypeFormat;
}
export declare const DatasetAugmentedManifestsListItem: S.Schema<DatasetAugmentedManifestsListItem>;
export type DatasetAugmentedManifestsList = DatasetAugmentedManifestsListItem[];
export declare const DatasetAugmentedManifestsList: any;
export type DatasetDataFormat = "COMPREHEND_CSV" | "AUGMENTED_MANIFEST" | (string & {});
export declare const DatasetDataFormat: any;
export type LabelDelimiter = string;
export interface DatasetDocumentClassifierInputDataConfig {
    S3Uri: string;
    LabelDelimiter?: string;
}
export declare const DatasetDocumentClassifierInputDataConfig: S.Schema<DatasetDocumentClassifierInputDataConfig>;
export interface DatasetEntityRecognizerAnnotations {
    S3Uri: string;
}
export declare const DatasetEntityRecognizerAnnotations: S.Schema<DatasetEntityRecognizerAnnotations>;
export type InputFormat = "ONE_DOC_PER_FILE" | "ONE_DOC_PER_LINE" | (string & {});
export declare const InputFormat: any;
export interface DatasetEntityRecognizerDocuments {
    S3Uri: string;
    InputFormat?: InputFormat;
}
export declare const DatasetEntityRecognizerDocuments: S.Schema<DatasetEntityRecognizerDocuments>;
export interface DatasetEntityRecognizerEntityList {
    S3Uri: string;
}
export declare const DatasetEntityRecognizerEntityList: S.Schema<DatasetEntityRecognizerEntityList>;
export interface DatasetEntityRecognizerInputDataConfig {
    Annotations?: DatasetEntityRecognizerAnnotations;
    Documents: DatasetEntityRecognizerDocuments;
    EntityList?: DatasetEntityRecognizerEntityList;
}
export declare const DatasetEntityRecognizerInputDataConfig: S.Schema<DatasetEntityRecognizerInputDataConfig>;
export interface DatasetInputDataConfig {
    AugmentedManifests?: DatasetAugmentedManifestsListItem[];
    DataFormat?: DatasetDataFormat;
    DocumentClassifierInputDataConfig?: DatasetDocumentClassifierInputDataConfig;
    EntityRecognizerInputDataConfig?: DatasetEntityRecognizerInputDataConfig;
}
export declare const DatasetInputDataConfig: S.Schema<DatasetInputDataConfig>;
export type ClientRequestTokenString = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateDatasetRequest {
    FlywheelArn: string;
    DatasetName: string;
    DatasetType?: DatasetType;
    Description?: string;
    InputDataConfig: DatasetInputDataConfig;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const CreateDatasetRequest: S.Schema<CreateDatasetRequest>;
export type ComprehendDatasetArn = string;
export interface CreateDatasetResponse {
    DatasetArn?: string;
}
export declare const CreateDatasetResponse: S.Schema<CreateDatasetResponse>;
export type VersionName = string;
export type IamRoleArn = string;
export type DocumentClassifierDataFormat = "COMPREHEND_CSV" | "AUGMENTED_MANIFEST" | (string & {});
export declare const DocumentClassifierDataFormat: any;
export type Split = "TRAIN" | "TEST" | (string & {});
export declare const Split: any;
export interface AugmentedManifestsListItem {
    S3Uri: string;
    Split?: Split;
    AttributeNames: string[];
    AnnotationDataS3Uri?: string;
    SourceDocumentsS3Uri?: string;
    DocumentType?: AugmentedManifestsDocumentTypeFormat;
}
export declare const AugmentedManifestsListItem: S.Schema<AugmentedManifestsListItem>;
export type DocumentClassifierAugmentedManifestsList = AugmentedManifestsListItem[];
export declare const DocumentClassifierAugmentedManifestsList: any;
export type DocumentClassifierDocumentTypeFormat = "PLAIN_TEXT_DOCUMENT" | "SEMI_STRUCTURED_DOCUMENT" | (string & {});
export declare const DocumentClassifierDocumentTypeFormat: any;
export interface DocumentClassifierDocuments {
    S3Uri: string;
    TestS3Uri?: string;
}
export declare const DocumentClassifierDocuments: S.Schema<DocumentClassifierDocuments>;
export interface DocumentClassifierInputDataConfig {
    DataFormat?: DocumentClassifierDataFormat;
    S3Uri?: string;
    TestS3Uri?: string;
    LabelDelimiter?: string;
    AugmentedManifests?: AugmentedManifestsListItem[];
    DocumentType?: DocumentClassifierDocumentTypeFormat;
    Documents?: DocumentClassifierDocuments;
    DocumentReaderConfig?: DocumentReaderConfig;
}
export declare const DocumentClassifierInputDataConfig: S.Schema<DocumentClassifierInputDataConfig>;
export type KmsKeyId = string;
export interface DocumentClassifierOutputDataConfig {
    S3Uri?: string;
    KmsKeyId?: string;
    FlywheelStatsS3Prefix?: string;
}
export declare const DocumentClassifierOutputDataConfig: S.Schema<DocumentClassifierOutputDataConfig>;
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export type SubnetId = string;
export type Subnets = string[];
export declare const Subnets: any;
export interface VpcConfig {
    SecurityGroupIds: string[];
    Subnets: string[];
}
export declare const VpcConfig: S.Schema<VpcConfig>;
export type DocumentClassifierMode = "MULTI_CLASS" | "MULTI_LABEL" | (string & {});
export declare const DocumentClassifierMode: any;
export type Policy = string;
export interface CreateDocumentClassifierRequest {
    DocumentClassifierName: string;
    VersionName?: string;
    DataAccessRoleArn: string;
    Tags?: Tag[];
    InputDataConfig: DocumentClassifierInputDataConfig;
    OutputDataConfig?: DocumentClassifierOutputDataConfig;
    ClientRequestToken?: string;
    LanguageCode: LanguageCode;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Mode?: DocumentClassifierMode;
    ModelKmsKeyId?: string;
    ModelPolicy?: string;
}
export declare const CreateDocumentClassifierRequest: S.Schema<CreateDocumentClassifierRequest>;
export type DocumentClassifierArn = string;
export interface CreateDocumentClassifierResponse {
    DocumentClassifierArn?: string;
}
export declare const CreateDocumentClassifierResponse: S.Schema<CreateDocumentClassifierResponse>;
export type ComprehendEndpointName = string;
export type ComprehendModelArn = string;
export type InferenceUnitsInteger = number;
export interface CreateEndpointRequest {
    EndpointName: string;
    ModelArn?: string;
    DesiredInferenceUnits: number;
    ClientRequestToken?: string;
    Tags?: Tag[];
    DataAccessRoleArn?: string;
    FlywheelArn?: string;
}
export declare const CreateEndpointRequest: S.Schema<CreateEndpointRequest>;
export type ComprehendEndpointArn = string;
export interface CreateEndpointResponse {
    EndpointArn?: string;
    ModelArn?: string;
}
export declare const CreateEndpointResponse: S.Schema<CreateEndpointResponse>;
export type EntityRecognizerDataFormat = "COMPREHEND_CSV" | "AUGMENTED_MANIFEST" | (string & {});
export declare const EntityRecognizerDataFormat: any;
export type EntityTypeName = string;
export interface EntityTypesListItem {
    Type: string;
}
export declare const EntityTypesListItem: S.Schema<EntityTypesListItem>;
export type EntityTypesList = EntityTypesListItem[];
export declare const EntityTypesList: any;
export interface EntityRecognizerDocuments {
    S3Uri: string;
    TestS3Uri?: string;
    InputFormat?: InputFormat;
}
export declare const EntityRecognizerDocuments: S.Schema<EntityRecognizerDocuments>;
export interface EntityRecognizerAnnotations {
    S3Uri: string;
    TestS3Uri?: string;
}
export declare const EntityRecognizerAnnotations: S.Schema<EntityRecognizerAnnotations>;
export interface EntityRecognizerEntityList {
    S3Uri: string;
}
export declare const EntityRecognizerEntityList: S.Schema<EntityRecognizerEntityList>;
export type EntityRecognizerAugmentedManifestsList = AugmentedManifestsListItem[];
export declare const EntityRecognizerAugmentedManifestsList: any;
export interface EntityRecognizerInputDataConfig {
    DataFormat?: EntityRecognizerDataFormat;
    EntityTypes: EntityTypesListItem[];
    Documents?: EntityRecognizerDocuments;
    Annotations?: EntityRecognizerAnnotations;
    EntityList?: EntityRecognizerEntityList;
    AugmentedManifests?: AugmentedManifestsListItem[];
}
export declare const EntityRecognizerInputDataConfig: S.Schema<EntityRecognizerInputDataConfig>;
export interface CreateEntityRecognizerRequest {
    RecognizerName: string;
    VersionName?: string;
    DataAccessRoleArn: string;
    Tags?: Tag[];
    InputDataConfig: EntityRecognizerInputDataConfig;
    ClientRequestToken?: string;
    LanguageCode: LanguageCode;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    ModelKmsKeyId?: string;
    ModelPolicy?: string;
}
export declare const CreateEntityRecognizerRequest: S.Schema<CreateEntityRecognizerRequest>;
export type EntityRecognizerArn = string;
export interface CreateEntityRecognizerResponse {
    EntityRecognizerArn?: string;
}
export declare const CreateEntityRecognizerResponse: S.Schema<CreateEntityRecognizerResponse>;
export type LabelListItem = string;
export type LabelsList = string[];
export declare const LabelsList: any;
export interface DocumentClassificationConfig {
    Mode: DocumentClassifierMode;
    Labels?: string[];
}
export declare const DocumentClassificationConfig: S.Schema<DocumentClassificationConfig>;
export interface EntityRecognitionConfig {
    EntityTypes: EntityTypesListItem[];
}
export declare const EntityRecognitionConfig: S.Schema<EntityRecognitionConfig>;
export interface TaskConfig {
    LanguageCode: LanguageCode;
    DocumentClassificationConfig?: DocumentClassificationConfig;
    EntityRecognitionConfig?: EntityRecognitionConfig;
}
export declare const TaskConfig: S.Schema<TaskConfig>;
export type ModelType = "DOCUMENT_CLASSIFIER" | "ENTITY_RECOGNIZER" | (string & {});
export declare const ModelType: any;
export type FlywheelS3Uri = string;
export interface DataSecurityConfig {
    ModelKmsKeyId?: string;
    VolumeKmsKeyId?: string;
    DataLakeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
}
export declare const DataSecurityConfig: S.Schema<DataSecurityConfig>;
export interface CreateFlywheelRequest {
    FlywheelName: string;
    ActiveModelArn?: string;
    DataAccessRoleArn: string;
    TaskConfig?: TaskConfig;
    ModelType?: ModelType;
    DataLakeS3Uri: string;
    DataSecurityConfig?: DataSecurityConfig;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const CreateFlywheelRequest: S.Schema<CreateFlywheelRequest>;
export interface CreateFlywheelResponse {
    FlywheelArn?: string;
    ActiveModelArn?: string;
}
export declare const CreateFlywheelResponse: S.Schema<CreateFlywheelResponse>;
export interface DeleteDocumentClassifierRequest {
    DocumentClassifierArn: string;
}
export declare const DeleteDocumentClassifierRequest: S.Schema<DeleteDocumentClassifierRequest>;
export interface DeleteDocumentClassifierResponse {
}
export declare const DeleteDocumentClassifierResponse: S.Schema<DeleteDocumentClassifierResponse>;
export interface DeleteEndpointRequest {
    EndpointArn: string;
}
export declare const DeleteEndpointRequest: S.Schema<DeleteEndpointRequest>;
export interface DeleteEndpointResponse {
}
export declare const DeleteEndpointResponse: S.Schema<DeleteEndpointResponse>;
export interface DeleteEntityRecognizerRequest {
    EntityRecognizerArn: string;
}
export declare const DeleteEntityRecognizerRequest: S.Schema<DeleteEntityRecognizerRequest>;
export interface DeleteEntityRecognizerResponse {
}
export declare const DeleteEntityRecognizerResponse: S.Schema<DeleteEntityRecognizerResponse>;
export interface DeleteFlywheelRequest {
    FlywheelArn: string;
}
export declare const DeleteFlywheelRequest: S.Schema<DeleteFlywheelRequest>;
export interface DeleteFlywheelResponse {
}
export declare const DeleteFlywheelResponse: S.Schema<DeleteFlywheelResponse>;
export type PolicyRevisionId = string;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
    PolicyRevisionId?: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DescribeDatasetRequest {
    DatasetArn: string;
}
export declare const DescribeDatasetRequest: S.Schema<DescribeDatasetRequest>;
export type DatasetStatus = "CREATING" | "COMPLETED" | "FAILED" | (string & {});
export declare const DatasetStatus: any;
export type AnyLengthString = string;
export type NumberOfDocuments = number;
export interface DatasetProperties {
    DatasetArn?: string;
    DatasetName?: string;
    DatasetType?: DatasetType;
    DatasetS3Uri?: string;
    Description?: string;
    Status?: DatasetStatus;
    Message?: string;
    NumberOfDocuments?: number;
    CreationTime?: Date;
    EndTime?: Date;
}
export declare const DatasetProperties: S.Schema<DatasetProperties>;
export interface DescribeDatasetResponse {
    DatasetProperties?: DatasetProperties;
}
export declare const DescribeDatasetResponse: S.Schema<DescribeDatasetResponse>;
export type JobId = string;
export interface DescribeDocumentClassificationJobRequest {
    JobId: string;
}
export declare const DescribeDocumentClassificationJobRequest: S.Schema<DescribeDocumentClassificationJobRequest>;
export type ComprehendArn = string;
export type JobName = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "STOP_REQUESTED" | "STOPPED" | (string & {});
export declare const JobStatus: any;
export interface InputDataConfig {
    S3Uri: string;
    InputFormat?: InputFormat;
    DocumentReaderConfig?: DocumentReaderConfig;
}
export declare const InputDataConfig: S.Schema<InputDataConfig>;
export interface OutputDataConfig {
    S3Uri: string;
    KmsKeyId?: string;
}
export declare const OutputDataConfig: S.Schema<OutputDataConfig>;
export interface DocumentClassificationJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    DocumentClassifierArn?: string;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    FlywheelArn?: string;
}
export declare const DocumentClassificationJobProperties: S.Schema<DocumentClassificationJobProperties>;
export interface DescribeDocumentClassificationJobResponse {
    DocumentClassificationJobProperties?: DocumentClassificationJobProperties;
}
export declare const DescribeDocumentClassificationJobResponse: S.Schema<DescribeDocumentClassificationJobResponse>;
export interface DescribeDocumentClassifierRequest {
    DocumentClassifierArn: string;
}
export declare const DescribeDocumentClassifierRequest: S.Schema<DescribeDocumentClassifierRequest>;
export type ModelStatus = "SUBMITTED" | "TRAINING" | "DELETING" | "STOP_REQUESTED" | "STOPPED" | "IN_ERROR" | "TRAINED" | "TRAINED_WITH_WARNING" | (string & {});
export declare const ModelStatus: any;
export interface ClassifierEvaluationMetrics {
    Accuracy?: number;
    Precision?: number;
    Recall?: number;
    F1Score?: number;
    MicroPrecision?: number;
    MicroRecall?: number;
    MicroF1Score?: number;
    HammingLoss?: number;
}
export declare const ClassifierEvaluationMetrics: S.Schema<ClassifierEvaluationMetrics>;
export interface ClassifierMetadata {
    NumberOfLabels?: number;
    NumberOfTrainedDocuments?: number;
    NumberOfTestDocuments?: number;
    EvaluationMetrics?: ClassifierEvaluationMetrics;
}
export declare const ClassifierMetadata: S.Schema<ClassifierMetadata>;
export interface DocumentClassifierProperties {
    DocumentClassifierArn?: string;
    LanguageCode?: LanguageCode;
    Status?: ModelStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    TrainingStartTime?: Date;
    TrainingEndTime?: Date;
    InputDataConfig?: DocumentClassifierInputDataConfig;
    OutputDataConfig?: DocumentClassifierOutputDataConfig;
    ClassifierMetadata?: ClassifierMetadata;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Mode?: DocumentClassifierMode;
    ModelKmsKeyId?: string;
    VersionName?: string;
    SourceModelArn?: string;
    FlywheelArn?: string;
}
export declare const DocumentClassifierProperties: S.Schema<DocumentClassifierProperties>;
export interface DescribeDocumentClassifierResponse {
    DocumentClassifierProperties?: DocumentClassifierProperties;
}
export declare const DescribeDocumentClassifierResponse: S.Schema<DescribeDocumentClassifierResponse>;
export interface DescribeDominantLanguageDetectionJobRequest {
    JobId: string;
}
export declare const DescribeDominantLanguageDetectionJobRequest: S.Schema<DescribeDominantLanguageDetectionJobRequest>;
export interface DominantLanguageDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
}
export declare const DominantLanguageDetectionJobProperties: S.Schema<DominantLanguageDetectionJobProperties>;
export interface DescribeDominantLanguageDetectionJobResponse {
    DominantLanguageDetectionJobProperties?: DominantLanguageDetectionJobProperties;
}
export declare const DescribeDominantLanguageDetectionJobResponse: S.Schema<DescribeDominantLanguageDetectionJobResponse>;
export interface DescribeEndpointRequest {
    EndpointArn: string;
}
export declare const DescribeEndpointRequest: S.Schema<DescribeEndpointRequest>;
export type EndpointStatus = "CREATING" | "DELETING" | "FAILED" | "IN_SERVICE" | "UPDATING" | (string & {});
export declare const EndpointStatus: any;
export interface EndpointProperties {
    EndpointArn?: string;
    Status?: EndpointStatus;
    Message?: string;
    ModelArn?: string;
    DesiredModelArn?: string;
    DesiredInferenceUnits?: number;
    CurrentInferenceUnits?: number;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    DataAccessRoleArn?: string;
    DesiredDataAccessRoleArn?: string;
    FlywheelArn?: string;
}
export declare const EndpointProperties: S.Schema<EndpointProperties>;
export interface DescribeEndpointResponse {
    EndpointProperties?: EndpointProperties;
}
export declare const DescribeEndpointResponse: S.Schema<DescribeEndpointResponse>;
export interface DescribeEntitiesDetectionJobRequest {
    JobId: string;
}
export declare const DescribeEntitiesDetectionJobRequest: S.Schema<DescribeEntitiesDetectionJobRequest>;
export interface EntitiesDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    EntityRecognizerArn?: string;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    LanguageCode?: LanguageCode;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    FlywheelArn?: string;
}
export declare const EntitiesDetectionJobProperties: S.Schema<EntitiesDetectionJobProperties>;
export interface DescribeEntitiesDetectionJobResponse {
    EntitiesDetectionJobProperties?: EntitiesDetectionJobProperties;
}
export declare const DescribeEntitiesDetectionJobResponse: S.Schema<DescribeEntitiesDetectionJobResponse>;
export interface DescribeEntityRecognizerRequest {
    EntityRecognizerArn: string;
}
export declare const DescribeEntityRecognizerRequest: S.Schema<DescribeEntityRecognizerRequest>;
export interface EntityRecognizerEvaluationMetrics {
    Precision?: number;
    Recall?: number;
    F1Score?: number;
}
export declare const EntityRecognizerEvaluationMetrics: S.Schema<EntityRecognizerEvaluationMetrics>;
export interface EntityTypesEvaluationMetrics {
    Precision?: number;
    Recall?: number;
    F1Score?: number;
}
export declare const EntityTypesEvaluationMetrics: S.Schema<EntityTypesEvaluationMetrics>;
export interface EntityRecognizerMetadataEntityTypesListItem {
    Type?: string;
    EvaluationMetrics?: EntityTypesEvaluationMetrics;
    NumberOfTrainMentions?: number;
}
export declare const EntityRecognizerMetadataEntityTypesListItem: S.Schema<EntityRecognizerMetadataEntityTypesListItem>;
export type EntityRecognizerMetadataEntityTypesList = EntityRecognizerMetadataEntityTypesListItem[];
export declare const EntityRecognizerMetadataEntityTypesList: any;
export interface EntityRecognizerMetadata {
    NumberOfTrainedDocuments?: number;
    NumberOfTestDocuments?: number;
    EvaluationMetrics?: EntityRecognizerEvaluationMetrics;
    EntityTypes?: EntityRecognizerMetadataEntityTypesListItem[];
}
export declare const EntityRecognizerMetadata: S.Schema<EntityRecognizerMetadata>;
export interface EntityRecognizerOutputDataConfig {
    FlywheelStatsS3Prefix?: string;
}
export declare const EntityRecognizerOutputDataConfig: S.Schema<EntityRecognizerOutputDataConfig>;
export interface EntityRecognizerProperties {
    EntityRecognizerArn?: string;
    LanguageCode?: LanguageCode;
    Status?: ModelStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    TrainingStartTime?: Date;
    TrainingEndTime?: Date;
    InputDataConfig?: EntityRecognizerInputDataConfig;
    RecognizerMetadata?: EntityRecognizerMetadata;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    ModelKmsKeyId?: string;
    VersionName?: string;
    SourceModelArn?: string;
    FlywheelArn?: string;
    OutputDataConfig?: EntityRecognizerOutputDataConfig;
}
export declare const EntityRecognizerProperties: S.Schema<EntityRecognizerProperties>;
export interface DescribeEntityRecognizerResponse {
    EntityRecognizerProperties?: EntityRecognizerProperties;
}
export declare const DescribeEntityRecognizerResponse: S.Schema<DescribeEntityRecognizerResponse>;
export interface DescribeEventsDetectionJobRequest {
    JobId: string;
}
export declare const DescribeEventsDetectionJobRequest: S.Schema<DescribeEventsDetectionJobRequest>;
export type EventTypeString = string;
export type TargetEventTypes = string[];
export declare const TargetEventTypes: any;
export interface EventsDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    LanguageCode?: LanguageCode;
    DataAccessRoleArn?: string;
    TargetEventTypes?: string[];
}
export declare const EventsDetectionJobProperties: S.Schema<EventsDetectionJobProperties>;
export interface DescribeEventsDetectionJobResponse {
    EventsDetectionJobProperties?: EventsDetectionJobProperties;
}
export declare const DescribeEventsDetectionJobResponse: S.Schema<DescribeEventsDetectionJobResponse>;
export interface DescribeFlywheelRequest {
    FlywheelArn: string;
}
export declare const DescribeFlywheelRequest: S.Schema<DescribeFlywheelRequest>;
export type FlywheelStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export declare const FlywheelStatus: any;
export type FlywheelIterationId = string;
export interface FlywheelProperties {
    FlywheelArn?: string;
    ActiveModelArn?: string;
    DataAccessRoleArn?: string;
    TaskConfig?: TaskConfig;
    DataLakeS3Uri?: string;
    DataSecurityConfig?: DataSecurityConfig;
    Status?: FlywheelStatus;
    ModelType?: ModelType;
    Message?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LatestFlywheelIteration?: string;
}
export declare const FlywheelProperties: S.Schema<FlywheelProperties>;
export interface DescribeFlywheelResponse {
    FlywheelProperties?: FlywheelProperties;
}
export declare const DescribeFlywheelResponse: S.Schema<DescribeFlywheelResponse>;
export interface DescribeFlywheelIterationRequest {
    FlywheelArn: string;
    FlywheelIterationId: string;
}
export declare const DescribeFlywheelIterationRequest: S.Schema<DescribeFlywheelIterationRequest>;
export type FlywheelIterationStatus = "TRAINING" | "EVALUATING" | "COMPLETED" | "FAILED" | "STOP_REQUESTED" | "STOPPED" | (string & {});
export declare const FlywheelIterationStatus: any;
export interface FlywheelModelEvaluationMetrics {
    AverageF1Score?: number;
    AveragePrecision?: number;
    AverageRecall?: number;
    AverageAccuracy?: number;
}
export declare const FlywheelModelEvaluationMetrics: S.Schema<FlywheelModelEvaluationMetrics>;
export interface FlywheelIterationProperties {
    FlywheelArn?: string;
    FlywheelIterationId?: string;
    CreationTime?: Date;
    EndTime?: Date;
    Status?: FlywheelIterationStatus;
    Message?: string;
    EvaluatedModelArn?: string;
    EvaluatedModelMetrics?: FlywheelModelEvaluationMetrics;
    TrainedModelArn?: string;
    TrainedModelMetrics?: FlywheelModelEvaluationMetrics;
    EvaluationManifestS3Prefix?: string;
}
export declare const FlywheelIterationProperties: S.Schema<FlywheelIterationProperties>;
export interface DescribeFlywheelIterationResponse {
    FlywheelIterationProperties?: FlywheelIterationProperties;
}
export declare const DescribeFlywheelIterationResponse: S.Schema<DescribeFlywheelIterationResponse>;
export interface DescribeKeyPhrasesDetectionJobRequest {
    JobId: string;
}
export declare const DescribeKeyPhrasesDetectionJobRequest: S.Schema<DescribeKeyPhrasesDetectionJobRequest>;
export interface KeyPhrasesDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    LanguageCode?: LanguageCode;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
}
export declare const KeyPhrasesDetectionJobProperties: S.Schema<KeyPhrasesDetectionJobProperties>;
export interface DescribeKeyPhrasesDetectionJobResponse {
    KeyPhrasesDetectionJobProperties?: KeyPhrasesDetectionJobProperties;
}
export declare const DescribeKeyPhrasesDetectionJobResponse: S.Schema<DescribeKeyPhrasesDetectionJobResponse>;
export interface DescribePiiEntitiesDetectionJobRequest {
    JobId: string;
}
export declare const DescribePiiEntitiesDetectionJobRequest: S.Schema<DescribePiiEntitiesDetectionJobRequest>;
export interface PiiOutputDataConfig {
    S3Uri: string;
    KmsKeyId?: string;
}
export declare const PiiOutputDataConfig: S.Schema<PiiOutputDataConfig>;
export type ListOfPiiEntityTypes = PiiEntityType[];
export declare const ListOfPiiEntityTypes: any;
export type PiiEntitiesDetectionMaskMode = "MASK" | "REPLACE_WITH_PII_ENTITY_TYPE" | (string & {});
export declare const PiiEntitiesDetectionMaskMode: any;
export type MaskCharacter = string;
export interface RedactionConfig {
    PiiEntityTypes?: PiiEntityType[];
    MaskMode?: PiiEntitiesDetectionMaskMode;
    MaskCharacter?: string;
}
export declare const RedactionConfig: S.Schema<RedactionConfig>;
export type PiiEntitiesDetectionMode = "ONLY_REDACTION" | "ONLY_OFFSETS" | (string & {});
export declare const PiiEntitiesDetectionMode: any;
export interface PiiEntitiesDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: PiiOutputDataConfig;
    RedactionConfig?: RedactionConfig;
    LanguageCode?: LanguageCode;
    DataAccessRoleArn?: string;
    Mode?: PiiEntitiesDetectionMode;
}
export declare const PiiEntitiesDetectionJobProperties: S.Schema<PiiEntitiesDetectionJobProperties>;
export interface DescribePiiEntitiesDetectionJobResponse {
    PiiEntitiesDetectionJobProperties?: PiiEntitiesDetectionJobProperties;
}
export declare const DescribePiiEntitiesDetectionJobResponse: S.Schema<DescribePiiEntitiesDetectionJobResponse>;
export interface DescribeResourcePolicyRequest {
    ResourceArn: string;
}
export declare const DescribeResourcePolicyRequest: S.Schema<DescribeResourcePolicyRequest>;
export interface DescribeResourcePolicyResponse {
    ResourcePolicy?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    PolicyRevisionId?: string;
}
export declare const DescribeResourcePolicyResponse: S.Schema<DescribeResourcePolicyResponse>;
export interface DescribeSentimentDetectionJobRequest {
    JobId: string;
}
export declare const DescribeSentimentDetectionJobRequest: S.Schema<DescribeSentimentDetectionJobRequest>;
export interface SentimentDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    LanguageCode?: LanguageCode;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
}
export declare const SentimentDetectionJobProperties: S.Schema<SentimentDetectionJobProperties>;
export interface DescribeSentimentDetectionJobResponse {
    SentimentDetectionJobProperties?: SentimentDetectionJobProperties;
}
export declare const DescribeSentimentDetectionJobResponse: S.Schema<DescribeSentimentDetectionJobResponse>;
export interface DescribeTargetedSentimentDetectionJobRequest {
    JobId: string;
}
export declare const DescribeTargetedSentimentDetectionJobRequest: S.Schema<DescribeTargetedSentimentDetectionJobRequest>;
export interface TargetedSentimentDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    LanguageCode?: LanguageCode;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
}
export declare const TargetedSentimentDetectionJobProperties: S.Schema<TargetedSentimentDetectionJobProperties>;
export interface DescribeTargetedSentimentDetectionJobResponse {
    TargetedSentimentDetectionJobProperties?: TargetedSentimentDetectionJobProperties;
}
export declare const DescribeTargetedSentimentDetectionJobResponse: S.Schema<DescribeTargetedSentimentDetectionJobResponse>;
export interface DescribeTopicsDetectionJobRequest {
    JobId: string;
}
export declare const DescribeTopicsDetectionJobRequest: S.Schema<DescribeTopicsDetectionJobRequest>;
export interface TopicsDetectionJobProperties {
    JobId?: string;
    JobArn?: string;
    JobName?: string;
    JobStatus?: JobStatus;
    Message?: string;
    SubmitTime?: Date;
    EndTime?: Date;
    InputDataConfig?: InputDataConfig;
    OutputDataConfig?: OutputDataConfig;
    NumberOfTopics?: number;
    DataAccessRoleArn?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
}
export declare const TopicsDetectionJobProperties: S.Schema<TopicsDetectionJobProperties>;
export interface DescribeTopicsDetectionJobResponse {
    TopicsDetectionJobProperties?: TopicsDetectionJobProperties;
}
export declare const DescribeTopicsDetectionJobResponse: S.Schema<DescribeTopicsDetectionJobResponse>;
export interface DetectDominantLanguageRequest {
    Text: string | redacted.Redacted<string>;
}
export declare const DetectDominantLanguageRequest: S.Schema<DetectDominantLanguageRequest>;
export interface DetectDominantLanguageResponse {
    Languages?: DominantLanguage[];
}
export declare const DetectDominantLanguageResponse: S.Schema<DetectDominantLanguageResponse>;
export type EntityRecognizerEndpointArn = string;
export interface DetectEntitiesRequest {
    Text?: string | redacted.Redacted<string>;
    LanguageCode?: LanguageCode;
    EndpointArn?: string;
    Bytes?: Uint8Array;
    DocumentReaderConfig?: DocumentReaderConfig;
}
export declare const DetectEntitiesRequest: S.Schema<DetectEntitiesRequest>;
export type BlockType = "LINE" | "WORD" | (string & {});
export declare const BlockType: any;
export interface BoundingBox {
    Height?: number;
    Left?: number;
    Top?: number;
    Width?: number;
}
export declare const BoundingBox: S.Schema<BoundingBox>;
export interface Point {
    X?: number;
    Y?: number;
}
export declare const Point: S.Schema<Point>;
export type Polygon = Point[];
export declare const Polygon: any;
export interface Geometry {
    BoundingBox?: BoundingBox;
    Polygon?: Point[];
}
export declare const Geometry: S.Schema<Geometry>;
export type StringList = string[];
export declare const StringList: any;
export type RelationshipType = "CHILD" | (string & {});
export declare const RelationshipType: any;
export interface RelationshipsListItem {
    Ids?: string[];
    Type?: RelationshipType;
}
export declare const RelationshipsListItem: S.Schema<RelationshipsListItem>;
export type ListOfRelationships = RelationshipsListItem[];
export declare const ListOfRelationships: any;
export interface Block {
    Id?: string;
    BlockType?: BlockType;
    Text?: string;
    Page?: number;
    Geometry?: Geometry;
    Relationships?: RelationshipsListItem[];
}
export declare const Block: S.Schema<Block>;
export type ListOfBlocks = Block[];
export declare const ListOfBlocks: any;
export interface DetectEntitiesResponse {
    Entities?: Entity[];
    DocumentMetadata?: DocumentMetadata;
    DocumentType?: DocumentTypeListItem[];
    Blocks?: Block[];
    Errors?: ErrorsListItem[];
}
export declare const DetectEntitiesResponse: S.Schema<DetectEntitiesResponse>;
export interface DetectKeyPhrasesRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: LanguageCode;
}
export declare const DetectKeyPhrasesRequest: S.Schema<DetectKeyPhrasesRequest>;
export interface DetectKeyPhrasesResponse {
    KeyPhrases?: KeyPhrase[];
}
export declare const DetectKeyPhrasesResponse: S.Schema<DetectKeyPhrasesResponse>;
export interface DetectPiiEntitiesRequest {
    Text: string;
    LanguageCode: LanguageCode;
}
export declare const DetectPiiEntitiesRequest: S.Schema<DetectPiiEntitiesRequest>;
export interface PiiEntity {
    Score?: number;
    Type?: PiiEntityType;
    BeginOffset?: number;
    EndOffset?: number;
}
export declare const PiiEntity: S.Schema<PiiEntity>;
export type ListOfPiiEntities = PiiEntity[];
export declare const ListOfPiiEntities: any;
export interface DetectPiiEntitiesResponse {
    Entities?: PiiEntity[];
}
export declare const DetectPiiEntitiesResponse: S.Schema<DetectPiiEntitiesResponse>;
export interface DetectSentimentRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: LanguageCode;
}
export declare const DetectSentimentRequest: S.Schema<DetectSentimentRequest>;
export interface DetectSentimentResponse {
    Sentiment?: SentimentType;
    SentimentScore?: SentimentScore;
}
export declare const DetectSentimentResponse: S.Schema<DetectSentimentResponse>;
export interface DetectSyntaxRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: SyntaxLanguageCode;
}
export declare const DetectSyntaxRequest: S.Schema<DetectSyntaxRequest>;
export interface DetectSyntaxResponse {
    SyntaxTokens?: SyntaxToken[];
}
export declare const DetectSyntaxResponse: S.Schema<DetectSyntaxResponse>;
export interface DetectTargetedSentimentRequest {
    Text: string | redacted.Redacted<string>;
    LanguageCode: LanguageCode;
}
export declare const DetectTargetedSentimentRequest: S.Schema<DetectTargetedSentimentRequest>;
export interface DetectTargetedSentimentResponse {
    Entities?: TargetedSentimentEntity[];
}
export declare const DetectTargetedSentimentResponse: S.Schema<DetectTargetedSentimentResponse>;
export interface TextSegment {
    Text: string | redacted.Redacted<string>;
}
export declare const TextSegment: S.Schema<TextSegment>;
export type ListOfTextSegments = TextSegment[];
export declare const ListOfTextSegments: any;
export interface DetectToxicContentRequest {
    TextSegments: TextSegment[];
    LanguageCode: LanguageCode;
}
export declare const DetectToxicContentRequest: S.Schema<DetectToxicContentRequest>;
export type ToxicContentType = "GRAPHIC" | "HARASSMENT_OR_ABUSE" | "HATE_SPEECH" | "INSULT" | "PROFANITY" | "SEXUAL" | "VIOLENCE_OR_THREAT" | (string & {});
export declare const ToxicContentType: any;
export interface ToxicContent {
    Name?: ToxicContentType;
    Score?: number;
}
export declare const ToxicContent: S.Schema<ToxicContent>;
export type ListOfToxicContent = ToxicContent[];
export declare const ListOfToxicContent: any;
export interface ToxicLabels {
    Labels?: ToxicContent[];
    Toxicity?: number;
}
export declare const ToxicLabels: S.Schema<ToxicLabels>;
export type ListOfToxicLabels = ToxicLabels[];
export declare const ListOfToxicLabels: any;
export interface DetectToxicContentResponse {
    ResultList?: ToxicLabels[];
}
export declare const DetectToxicContentResponse: S.Schema<DetectToxicContentResponse>;
export interface ImportModelRequest {
    SourceModelArn: string;
    ModelName?: string;
    VersionName?: string;
    ModelKmsKeyId?: string;
    DataAccessRoleArn?: string;
    Tags?: Tag[];
}
export declare const ImportModelRequest: S.Schema<ImportModelRequest>;
export interface ImportModelResponse {
    ModelArn?: string;
}
export declare const ImportModelResponse: S.Schema<ImportModelResponse>;
export interface DatasetFilter {
    Status?: DatasetStatus;
    DatasetType?: DatasetType;
    CreationTimeAfter?: Date;
    CreationTimeBefore?: Date;
}
export declare const DatasetFilter: S.Schema<DatasetFilter>;
export type MaxResultsInteger = number;
export interface ListDatasetsRequest {
    FlywheelArn?: string;
    Filter?: DatasetFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDatasetsRequest: S.Schema<ListDatasetsRequest>;
export type DatasetPropertiesList = DatasetProperties[];
export declare const DatasetPropertiesList: any;
export interface ListDatasetsResponse {
    DatasetPropertiesList?: DatasetProperties[];
    NextToken?: string;
}
export declare const ListDatasetsResponse: S.Schema<ListDatasetsResponse>;
export interface DocumentClassificationJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const DocumentClassificationJobFilter: S.Schema<DocumentClassificationJobFilter>;
export interface ListDocumentClassificationJobsRequest {
    Filter?: DocumentClassificationJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDocumentClassificationJobsRequest: S.Schema<ListDocumentClassificationJobsRequest>;
export type DocumentClassificationJobPropertiesList = DocumentClassificationJobProperties[];
export declare const DocumentClassificationJobPropertiesList: any;
export interface ListDocumentClassificationJobsResponse {
    DocumentClassificationJobPropertiesList?: DocumentClassificationJobProperties[];
    NextToken?: string;
}
export declare const ListDocumentClassificationJobsResponse: S.Schema<ListDocumentClassificationJobsResponse>;
export interface DocumentClassifierFilter {
    Status?: ModelStatus;
    DocumentClassifierName?: string;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const DocumentClassifierFilter: S.Schema<DocumentClassifierFilter>;
export interface ListDocumentClassifiersRequest {
    Filter?: DocumentClassifierFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDocumentClassifiersRequest: S.Schema<ListDocumentClassifiersRequest>;
export type DocumentClassifierPropertiesList = DocumentClassifierProperties[];
export declare const DocumentClassifierPropertiesList: any;
export interface ListDocumentClassifiersResponse {
    DocumentClassifierPropertiesList?: DocumentClassifierProperties[];
    NextToken?: string;
}
export declare const ListDocumentClassifiersResponse: S.Schema<ListDocumentClassifiersResponse>;
export interface ListDocumentClassifierSummariesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDocumentClassifierSummariesRequest: S.Schema<ListDocumentClassifierSummariesRequest>;
export interface DocumentClassifierSummary {
    DocumentClassifierName?: string;
    NumberOfVersions?: number;
    LatestVersionCreatedAt?: Date;
    LatestVersionName?: string;
    LatestVersionStatus?: ModelStatus;
}
export declare const DocumentClassifierSummary: S.Schema<DocumentClassifierSummary>;
export type DocumentClassifierSummariesList = DocumentClassifierSummary[];
export declare const DocumentClassifierSummariesList: any;
export interface ListDocumentClassifierSummariesResponse {
    DocumentClassifierSummariesList?: DocumentClassifierSummary[];
    NextToken?: string;
}
export declare const ListDocumentClassifierSummariesResponse: S.Schema<ListDocumentClassifierSummariesResponse>;
export interface DominantLanguageDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const DominantLanguageDetectionJobFilter: S.Schema<DominantLanguageDetectionJobFilter>;
export interface ListDominantLanguageDetectionJobsRequest {
    Filter?: DominantLanguageDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDominantLanguageDetectionJobsRequest: S.Schema<ListDominantLanguageDetectionJobsRequest>;
export type DominantLanguageDetectionJobPropertiesList = DominantLanguageDetectionJobProperties[];
export declare const DominantLanguageDetectionJobPropertiesList: any;
export interface ListDominantLanguageDetectionJobsResponse {
    DominantLanguageDetectionJobPropertiesList?: DominantLanguageDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListDominantLanguageDetectionJobsResponse: S.Schema<ListDominantLanguageDetectionJobsResponse>;
export interface EndpointFilter {
    ModelArn?: string;
    Status?: EndpointStatus;
    CreationTimeBefore?: Date;
    CreationTimeAfter?: Date;
}
export declare const EndpointFilter: S.Schema<EndpointFilter>;
export interface ListEndpointsRequest {
    Filter?: EndpointFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEndpointsRequest: S.Schema<ListEndpointsRequest>;
export type EndpointPropertiesList = EndpointProperties[];
export declare const EndpointPropertiesList: any;
export interface ListEndpointsResponse {
    EndpointPropertiesList?: EndpointProperties[];
    NextToken?: string;
}
export declare const ListEndpointsResponse: S.Schema<ListEndpointsResponse>;
export interface EntitiesDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const EntitiesDetectionJobFilter: S.Schema<EntitiesDetectionJobFilter>;
export interface ListEntitiesDetectionJobsRequest {
    Filter?: EntitiesDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEntitiesDetectionJobsRequest: S.Schema<ListEntitiesDetectionJobsRequest>;
export type EntitiesDetectionJobPropertiesList = EntitiesDetectionJobProperties[];
export declare const EntitiesDetectionJobPropertiesList: any;
export interface ListEntitiesDetectionJobsResponse {
    EntitiesDetectionJobPropertiesList?: EntitiesDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListEntitiesDetectionJobsResponse: S.Schema<ListEntitiesDetectionJobsResponse>;
export interface EntityRecognizerFilter {
    Status?: ModelStatus;
    RecognizerName?: string;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const EntityRecognizerFilter: S.Schema<EntityRecognizerFilter>;
export interface ListEntityRecognizersRequest {
    Filter?: EntityRecognizerFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEntityRecognizersRequest: S.Schema<ListEntityRecognizersRequest>;
export type EntityRecognizerPropertiesList = EntityRecognizerProperties[];
export declare const EntityRecognizerPropertiesList: any;
export interface ListEntityRecognizersResponse {
    EntityRecognizerPropertiesList?: EntityRecognizerProperties[];
    NextToken?: string;
}
export declare const ListEntityRecognizersResponse: S.Schema<ListEntityRecognizersResponse>;
export interface ListEntityRecognizerSummariesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEntityRecognizerSummariesRequest: S.Schema<ListEntityRecognizerSummariesRequest>;
export interface EntityRecognizerSummary {
    RecognizerName?: string;
    NumberOfVersions?: number;
    LatestVersionCreatedAt?: Date;
    LatestVersionName?: string;
    LatestVersionStatus?: ModelStatus;
}
export declare const EntityRecognizerSummary: S.Schema<EntityRecognizerSummary>;
export type EntityRecognizerSummariesList = EntityRecognizerSummary[];
export declare const EntityRecognizerSummariesList: any;
export interface ListEntityRecognizerSummariesResponse {
    EntityRecognizerSummariesList?: EntityRecognizerSummary[];
    NextToken?: string;
}
export declare const ListEntityRecognizerSummariesResponse: S.Schema<ListEntityRecognizerSummariesResponse>;
export interface EventsDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const EventsDetectionJobFilter: S.Schema<EventsDetectionJobFilter>;
export interface ListEventsDetectionJobsRequest {
    Filter?: EventsDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListEventsDetectionJobsRequest: S.Schema<ListEventsDetectionJobsRequest>;
export type EventsDetectionJobPropertiesList = EventsDetectionJobProperties[];
export declare const EventsDetectionJobPropertiesList: any;
export interface ListEventsDetectionJobsResponse {
    EventsDetectionJobPropertiesList?: EventsDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListEventsDetectionJobsResponse: S.Schema<ListEventsDetectionJobsResponse>;
export interface FlywheelIterationFilter {
    CreationTimeAfter?: Date;
    CreationTimeBefore?: Date;
}
export declare const FlywheelIterationFilter: S.Schema<FlywheelIterationFilter>;
export interface ListFlywheelIterationHistoryRequest {
    FlywheelArn: string;
    Filter?: FlywheelIterationFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFlywheelIterationHistoryRequest: S.Schema<ListFlywheelIterationHistoryRequest>;
export type FlywheelIterationPropertiesList = FlywheelIterationProperties[];
export declare const FlywheelIterationPropertiesList: any;
export interface ListFlywheelIterationHistoryResponse {
    FlywheelIterationPropertiesList?: FlywheelIterationProperties[];
    NextToken?: string;
}
export declare const ListFlywheelIterationHistoryResponse: S.Schema<ListFlywheelIterationHistoryResponse>;
export interface FlywheelFilter {
    Status?: FlywheelStatus;
    CreationTimeAfter?: Date;
    CreationTimeBefore?: Date;
}
export declare const FlywheelFilter: S.Schema<FlywheelFilter>;
export interface ListFlywheelsRequest {
    Filter?: FlywheelFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListFlywheelsRequest: S.Schema<ListFlywheelsRequest>;
export interface FlywheelSummary {
    FlywheelArn?: string;
    ActiveModelArn?: string;
    DataLakeS3Uri?: string;
    Status?: FlywheelStatus;
    ModelType?: ModelType;
    Message?: string;
    CreationTime?: Date;
    LastModifiedTime?: Date;
    LatestFlywheelIteration?: string;
}
export declare const FlywheelSummary: S.Schema<FlywheelSummary>;
export type FlywheelSummaryList = FlywheelSummary[];
export declare const FlywheelSummaryList: any;
export interface ListFlywheelsResponse {
    FlywheelSummaryList?: FlywheelSummary[];
    NextToken?: string;
}
export declare const ListFlywheelsResponse: S.Schema<ListFlywheelsResponse>;
export interface KeyPhrasesDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const KeyPhrasesDetectionJobFilter: S.Schema<KeyPhrasesDetectionJobFilter>;
export interface ListKeyPhrasesDetectionJobsRequest {
    Filter?: KeyPhrasesDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListKeyPhrasesDetectionJobsRequest: S.Schema<ListKeyPhrasesDetectionJobsRequest>;
export type KeyPhrasesDetectionJobPropertiesList = KeyPhrasesDetectionJobProperties[];
export declare const KeyPhrasesDetectionJobPropertiesList: any;
export interface ListKeyPhrasesDetectionJobsResponse {
    KeyPhrasesDetectionJobPropertiesList?: KeyPhrasesDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListKeyPhrasesDetectionJobsResponse: S.Schema<ListKeyPhrasesDetectionJobsResponse>;
export interface PiiEntitiesDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const PiiEntitiesDetectionJobFilter: S.Schema<PiiEntitiesDetectionJobFilter>;
export interface ListPiiEntitiesDetectionJobsRequest {
    Filter?: PiiEntitiesDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListPiiEntitiesDetectionJobsRequest: S.Schema<ListPiiEntitiesDetectionJobsRequest>;
export type PiiEntitiesDetectionJobPropertiesList = PiiEntitiesDetectionJobProperties[];
export declare const PiiEntitiesDetectionJobPropertiesList: any;
export interface ListPiiEntitiesDetectionJobsResponse {
    PiiEntitiesDetectionJobPropertiesList?: PiiEntitiesDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListPiiEntitiesDetectionJobsResponse: S.Schema<ListPiiEntitiesDetectionJobsResponse>;
export interface SentimentDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const SentimentDetectionJobFilter: S.Schema<SentimentDetectionJobFilter>;
export interface ListSentimentDetectionJobsRequest {
    Filter?: SentimentDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListSentimentDetectionJobsRequest: S.Schema<ListSentimentDetectionJobsRequest>;
export type SentimentDetectionJobPropertiesList = SentimentDetectionJobProperties[];
export declare const SentimentDetectionJobPropertiesList: any;
export interface ListSentimentDetectionJobsResponse {
    SentimentDetectionJobPropertiesList?: SentimentDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListSentimentDetectionJobsResponse: S.Schema<ListSentimentDetectionJobsResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    ResourceArn?: string;
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TargetedSentimentDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const TargetedSentimentDetectionJobFilter: S.Schema<TargetedSentimentDetectionJobFilter>;
export interface ListTargetedSentimentDetectionJobsRequest {
    Filter?: TargetedSentimentDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTargetedSentimentDetectionJobsRequest: S.Schema<ListTargetedSentimentDetectionJobsRequest>;
export type TargetedSentimentDetectionJobPropertiesList = TargetedSentimentDetectionJobProperties[];
export declare const TargetedSentimentDetectionJobPropertiesList: any;
export interface ListTargetedSentimentDetectionJobsResponse {
    TargetedSentimentDetectionJobPropertiesList?: TargetedSentimentDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListTargetedSentimentDetectionJobsResponse: S.Schema<ListTargetedSentimentDetectionJobsResponse>;
export interface TopicsDetectionJobFilter {
    JobName?: string;
    JobStatus?: JobStatus;
    SubmitTimeBefore?: Date;
    SubmitTimeAfter?: Date;
}
export declare const TopicsDetectionJobFilter: S.Schema<TopicsDetectionJobFilter>;
export interface ListTopicsDetectionJobsRequest {
    Filter?: TopicsDetectionJobFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListTopicsDetectionJobsRequest: S.Schema<ListTopicsDetectionJobsRequest>;
export type TopicsDetectionJobPropertiesList = TopicsDetectionJobProperties[];
export declare const TopicsDetectionJobPropertiesList: any;
export interface ListTopicsDetectionJobsResponse {
    TopicsDetectionJobPropertiesList?: TopicsDetectionJobProperties[];
    NextToken?: string;
}
export declare const ListTopicsDetectionJobsResponse: S.Schema<ListTopicsDetectionJobsResponse>;
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    ResourcePolicy: string;
    PolicyRevisionId?: string;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResponse {
    PolicyRevisionId?: string;
}
export declare const PutResourcePolicyResponse: S.Schema<PutResourcePolicyResponse>;
export interface StartDocumentClassificationJobRequest {
    JobName?: string;
    DocumentClassifierArn?: string;
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    ClientRequestToken?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
    FlywheelArn?: string;
}
export declare const StartDocumentClassificationJobRequest: S.Schema<StartDocumentClassificationJobRequest>;
export interface StartDocumentClassificationJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
    DocumentClassifierArn?: string;
}
export declare const StartDocumentClassificationJobResponse: S.Schema<StartDocumentClassificationJobResponse>;
export interface StartDominantLanguageDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    ClientRequestToken?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
}
export declare const StartDominantLanguageDetectionJobRequest: S.Schema<StartDominantLanguageDetectionJobRequest>;
export interface StartDominantLanguageDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
}
export declare const StartDominantLanguageDetectionJobResponse: S.Schema<StartDominantLanguageDetectionJobResponse>;
export interface StartEntitiesDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    EntityRecognizerArn?: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
    FlywheelArn?: string;
}
export declare const StartEntitiesDetectionJobRequest: S.Schema<StartEntitiesDetectionJobRequest>;
export interface StartEntitiesDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
    EntityRecognizerArn?: string;
}
export declare const StartEntitiesDetectionJobResponse: S.Schema<StartEntitiesDetectionJobResponse>;
export interface StartEventsDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
    TargetEventTypes: string[];
    Tags?: Tag[];
}
export declare const StartEventsDetectionJobRequest: S.Schema<StartEventsDetectionJobRequest>;
export interface StartEventsDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
}
export declare const StartEventsDetectionJobResponse: S.Schema<StartEventsDetectionJobResponse>;
export interface StartFlywheelIterationRequest {
    FlywheelArn: string;
    ClientRequestToken?: string;
}
export declare const StartFlywheelIterationRequest: S.Schema<StartFlywheelIterationRequest>;
export interface StartFlywheelIterationResponse {
    FlywheelArn?: string;
    FlywheelIterationId?: string;
}
export declare const StartFlywheelIterationResponse: S.Schema<StartFlywheelIterationResponse>;
export interface StartKeyPhrasesDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
}
export declare const StartKeyPhrasesDetectionJobRequest: S.Schema<StartKeyPhrasesDetectionJobRequest>;
export interface StartKeyPhrasesDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
}
export declare const StartKeyPhrasesDetectionJobResponse: S.Schema<StartKeyPhrasesDetectionJobResponse>;
export interface StartPiiEntitiesDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    Mode: PiiEntitiesDetectionMode;
    RedactionConfig?: RedactionConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
    Tags?: Tag[];
}
export declare const StartPiiEntitiesDetectionJobRequest: S.Schema<StartPiiEntitiesDetectionJobRequest>;
export interface StartPiiEntitiesDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
}
export declare const StartPiiEntitiesDetectionJobResponse: S.Schema<StartPiiEntitiesDetectionJobResponse>;
export interface StartSentimentDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
}
export declare const StartSentimentDetectionJobRequest: S.Schema<StartSentimentDetectionJobRequest>;
export interface StartSentimentDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
}
export declare const StartSentimentDetectionJobResponse: S.Schema<StartSentimentDetectionJobResponse>;
export interface StartTargetedSentimentDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    LanguageCode: LanguageCode;
    ClientRequestToken?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
}
export declare const StartTargetedSentimentDetectionJobRequest: S.Schema<StartTargetedSentimentDetectionJobRequest>;
export interface StartTargetedSentimentDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
}
export declare const StartTargetedSentimentDetectionJobResponse: S.Schema<StartTargetedSentimentDetectionJobResponse>;
export type NumberOfTopicsInteger = number;
export interface StartTopicsDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string;
    NumberOfTopics?: number;
    ClientRequestToken?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
    Tags?: Tag[];
}
export declare const StartTopicsDetectionJobRequest: S.Schema<StartTopicsDetectionJobRequest>;
export interface StartTopicsDetectionJobResponse {
    JobId?: string;
    JobArn?: string;
    JobStatus?: JobStatus;
}
export declare const StartTopicsDetectionJobResponse: S.Schema<StartTopicsDetectionJobResponse>;
export interface StopDominantLanguageDetectionJobRequest {
    JobId: string;
}
export declare const StopDominantLanguageDetectionJobRequest: S.Schema<StopDominantLanguageDetectionJobRequest>;
export interface StopDominantLanguageDetectionJobResponse {
    JobId?: string;
    JobStatus?: JobStatus;
}
export declare const StopDominantLanguageDetectionJobResponse: S.Schema<StopDominantLanguageDetectionJobResponse>;
export interface StopEntitiesDetectionJobRequest {
    JobId: string;
}
export declare const StopEntitiesDetectionJobRequest: S.Schema<StopEntitiesDetectionJobRequest>;
export interface StopEntitiesDetectionJobResponse {
    JobId?: string;
    JobStatus?: JobStatus;
}
export declare const StopEntitiesDetectionJobResponse: S.Schema<StopEntitiesDetectionJobResponse>;
export interface StopEventsDetectionJobRequest {
    JobId: string;
}
export declare const StopEventsDetectionJobRequest: S.Schema<StopEventsDetectionJobRequest>;
export interface StopEventsDetectionJobResponse {
    JobId?: string;
    JobStatus?: JobStatus;
}
export declare const StopEventsDetectionJobResponse: S.Schema<StopEventsDetectionJobResponse>;
export interface StopKeyPhrasesDetectionJobRequest {
    JobId: string;
}
export declare const StopKeyPhrasesDetectionJobRequest: S.Schema<StopKeyPhrasesDetectionJobRequest>;
export interface StopKeyPhrasesDetectionJobResponse {
    JobId?: string;
    JobStatus?: JobStatus;
}
export declare const StopKeyPhrasesDetectionJobResponse: S.Schema<StopKeyPhrasesDetectionJobResponse>;
export interface StopPiiEntitiesDetectionJobRequest {
    JobId: string;
}
export declare const StopPiiEntitiesDetectionJobRequest: S.Schema<StopPiiEntitiesDetectionJobRequest>;
export interface StopPiiEntitiesDetectionJobResponse {
    JobId?: string;
    JobStatus?: JobStatus;
}
export declare const StopPiiEntitiesDetectionJobResponse: S.Schema<StopPiiEntitiesDetectionJobResponse>;
export interface StopSentimentDetectionJobRequest {
    JobId: string;
}
export declare const StopSentimentDetectionJobRequest: S.Schema<StopSentimentDetectionJobRequest>;
export interface StopSentimentDetectionJobResponse {
    JobId?: string;
    JobStatus?: JobStatus;
}
export declare const StopSentimentDetectionJobResponse: S.Schema<StopSentimentDetectionJobResponse>;
export interface StopTargetedSentimentDetectionJobRequest {
    JobId: string;
}
export declare const StopTargetedSentimentDetectionJobRequest: S.Schema<StopTargetedSentimentDetectionJobRequest>;
export interface StopTargetedSentimentDetectionJobResponse {
    JobId?: string;
    JobStatus?: JobStatus;
}
export declare const StopTargetedSentimentDetectionJobResponse: S.Schema<StopTargetedSentimentDetectionJobResponse>;
export interface StopTrainingDocumentClassifierRequest {
    DocumentClassifierArn: string;
}
export declare const StopTrainingDocumentClassifierRequest: S.Schema<StopTrainingDocumentClassifierRequest>;
export interface StopTrainingDocumentClassifierResponse {
}
export declare const StopTrainingDocumentClassifierResponse: S.Schema<StopTrainingDocumentClassifierResponse>;
export interface StopTrainingEntityRecognizerRequest {
    EntityRecognizerArn: string;
}
export declare const StopTrainingEntityRecognizerRequest: S.Schema<StopTrainingEntityRecognizerRequest>;
export interface StopTrainingEntityRecognizerResponse {
}
export declare const StopTrainingEntityRecognizerResponse: S.Schema<StopTrainingEntityRecognizerResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateEndpointRequest {
    EndpointArn: string;
    DesiredModelArn?: string;
    DesiredInferenceUnits?: number;
    DesiredDataAccessRoleArn?: string;
    FlywheelArn?: string;
}
export declare const UpdateEndpointRequest: S.Schema<UpdateEndpointRequest>;
export interface UpdateEndpointResponse {
    DesiredModelArn?: string;
}
export declare const UpdateEndpointResponse: S.Schema<UpdateEndpointResponse>;
export interface UpdateDataSecurityConfig {
    ModelKmsKeyId?: string;
    VolumeKmsKeyId?: string;
    VpcConfig?: VpcConfig;
}
export declare const UpdateDataSecurityConfig: S.Schema<UpdateDataSecurityConfig>;
export interface UpdateFlywheelRequest {
    FlywheelArn: string;
    ActiveModelArn?: string;
    DataAccessRoleArn?: string;
    DataSecurityConfig?: UpdateDataSecurityConfig;
}
export declare const UpdateFlywheelRequest: S.Schema<UpdateFlywheelRequest>;
export interface UpdateFlywheelResponse {
    FlywheelProperties?: FlywheelProperties;
}
export declare const UpdateFlywheelResponse: S.Schema<UpdateFlywheelResponse>;
export type InvalidRequestReason = "INVALID_DOCUMENT" | (string & {});
export declare const InvalidRequestReason: any;
export type InvalidRequestDetailReason = "DOCUMENT_SIZE_EXCEEDED" | "UNSUPPORTED_DOC_TYPE" | "PAGE_LIMIT_EXCEEDED" | "TEXTRACT_ACCESS_DENIED" | (string & {});
export declare const InvalidRequestDetailReason: any;
export interface InvalidRequestDetail {
    Reason?: InvalidRequestDetailReason;
}
export declare const InvalidRequestDetail: S.Schema<InvalidRequestDetail>;
export type BatchDetectDominantLanguageError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | CommonErrors;
/**
 * Determines the dominant language of the input text for a batch of documents. For a list
 * of languages that Amazon Comprehend can detect, see Amazon Comprehend Supported Languages.
 */
export declare const batchDetectDominantLanguage: API.OperationMethod<BatchDetectDominantLanguageRequest, BatchDetectDominantLanguageResponse, BatchDetectDominantLanguageError, Credentials | HttpClient.HttpClient>;
export type BatchDetectEntitiesError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the text of a batch of documents for named entities and returns information
 * about them. For more information about named entities, see
 * Entities in the Comprehend Developer Guide.
 */
export declare const batchDetectEntities: API.OperationMethod<BatchDetectEntitiesRequest, BatchDetectEntitiesResponse, BatchDetectEntitiesError, Credentials | HttpClient.HttpClient>;
export type BatchDetectKeyPhrasesError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Detects the key noun phrases found in a batch of documents.
 */
export declare const batchDetectKeyPhrases: API.OperationMethod<BatchDetectKeyPhrasesRequest, BatchDetectKeyPhrasesResponse, BatchDetectKeyPhrasesError, Credentials | HttpClient.HttpClient>;
export type BatchDetectSentimentError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects a batch of documents and returns an inference of the prevailing sentiment,
 * `POSITIVE`, `NEUTRAL`, `MIXED`, or `NEGATIVE`,
 * in each one.
 */
export declare const batchDetectSentiment: API.OperationMethod<BatchDetectSentimentRequest, BatchDetectSentimentResponse, BatchDetectSentimentError, Credentials | HttpClient.HttpClient>;
export type BatchDetectSyntaxError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the text of a batch of documents for the syntax and part of speech of the words
 * in the document and returns information about them. For more information, see
 * Syntax in the Comprehend Developer Guide.
 */
export declare const batchDetectSyntax: API.OperationMethod<BatchDetectSyntaxRequest, BatchDetectSyntaxResponse, BatchDetectSyntaxError, Credentials | HttpClient.HttpClient>;
export type BatchDetectTargetedSentimentError = BatchSizeLimitExceededException | InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects a batch of documents and returns a sentiment analysis
 * for each entity identified in the documents.
 *
 * For more information about targeted sentiment, see Targeted sentiment in the *Amazon Comprehend Developer Guide*.
 */
export declare const batchDetectTargetedSentiment: API.OperationMethod<BatchDetectTargetedSentimentRequest, BatchDetectTargetedSentimentResponse, BatchDetectTargetedSentimentError, Credentials | HttpClient.HttpClient>;
export type ClassifyDocumentError = InternalServerException | InvalidRequestException | ResourceUnavailableException | TextSizeLimitExceededException | NotAuthorizedException | CommonErrors;
/**
 * Creates a classification request to analyze a single document in real-time. `ClassifyDocument`
 * supports the following model types:
 *
 * - Custom classifier - a custom model that you have created and trained.
 * For input, you can provide plain text, a single-page document (PDF, Word, or image), or
 * Amazon Textract API output. For more information, see Custom classification in the *Amazon Comprehend Developer Guide*.
 *
 * - Prompt safety classifier - Amazon Comprehend provides a pre-trained model for classifying
 * input prompts for generative AI applications.
 * For input, you provide English plain text input.
 * For prompt safety classification, the response includes only the `Classes` field.
 * For more information about prompt safety classifiers, see Prompt safety classification in the *Amazon Comprehend Developer Guide*.
 *
 * If the system detects errors while processing a page in the input document,
 * the API response includes an `Errors` field that describes the errors.
 *
 * If the system detects a document-level error in your input document, the API returns an
 * `InvalidRequestException` error response.
 * For details about this exception, see
 *
 * Errors in semi-structured documents in the Comprehend Developer Guide.
 */
export declare const classifyDocument: API.OperationMethod<ClassifyDocumentRequest, ClassifyDocumentResponse, ClassifyDocumentError, Credentials | HttpClient.HttpClient>;
export type ContainsPiiEntitiesError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Analyzes input text for the presence of personally identifiable information (PII) and
 * returns the labels of identified PII entity types such as name, address, bank account number,
 * or phone number.
 */
export declare const containsPiiEntities: API.OperationMethod<ContainsPiiEntitiesRequest, ContainsPiiEntitiesResponse, ContainsPiiEntitiesError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates a dataset to upload training or test data for a model associated with a flywheel.
 * For more information about datasets, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDocumentClassifierError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | TooManyRequestsException | TooManyTagsException | UnsupportedLanguageException | CommonErrors;
/**
 * Creates a new document classifier that you can use to categorize documents. To create a
 * classifier, you provide a set of training documents that are labeled with the categories that you
 * want to use. For more information, see
 * Training classifier models
 * in the Comprehend Developer Guide.
 */
export declare const createDocumentClassifier: API.OperationMethod<CreateDocumentClassifierRequest, CreateDocumentClassifierResponse, CreateDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates a model-specific endpoint for synchronous inference for a previously trained
 * custom model
 * For information about endpoints, see Managing endpoints.
 */
export declare const createEndpoint: API.OperationMethod<CreateEndpointRequest, CreateEndpointResponse, CreateEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateEntityRecognizerError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | TooManyRequestsException | TooManyTagsException | UnsupportedLanguageException | CommonErrors;
/**
 * Creates an entity recognizer using submitted files. After your
 * `CreateEntityRecognizer` request is submitted, you can check job status using the
 * `DescribeEntityRecognizer` API.
 */
export declare const createEntityRecognizer: API.OperationMethod<CreateEntityRecognizerRequest, CreateEntityRecognizerResponse, CreateEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type CreateFlywheelError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | UnsupportedLanguageException | CommonErrors;
/**
 * A flywheel is an Amazon Web Services resource that orchestrates the ongoing training of a model for custom classification
 * or custom entity recognition. You can create a flywheel to start with an existing trained model, or
 * Comprehend can create and train a new model.
 *
 * When you create the flywheel, Comprehend creates a data lake in your account. The data lake holds the training
 * data and test data for all versions of the model.
 *
 * To use a flywheel with an existing trained model, you specify the active model version. Comprehend copies the model's
 * training data and test data into the flywheel's data lake.
 *
 * To use the flywheel with a new model, you need to provide a dataset for training data (and optional test data)
 * when you create the flywheel.
 *
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const createFlywheel: API.OperationMethod<CreateFlywheelRequest, CreateFlywheelResponse, CreateFlywheelError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentClassifierError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a previously created document classifier
 *
 * Only those classifiers that are in terminated states (IN_ERROR, TRAINED) will be deleted.
 * If an active inference job is using the model, a `ResourceInUseException` will be
 * returned.
 *
 * This is an asynchronous action that puts the classifier into a DELETING state, and it is
 * then removed by a background job. Once removed, the classifier disappears from your account
 * and is no longer available for use.
 */
export declare const deleteDocumentClassifier: API.OperationMethod<DeleteDocumentClassifierRequest, DeleteDocumentClassifierResponse, DeleteDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a model-specific endpoint for a previously-trained custom model. All endpoints
 * must be deleted in order for the model to be deleted.
 * For information about endpoints, see Managing endpoints.
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointRequest, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEntityRecognizerError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an entity recognizer.
 *
 * Only those recognizers that are in terminated states (IN_ERROR, TRAINED) will be deleted.
 * If an active inference job is using the model, a `ResourceInUseException` will be
 * returned.
 *
 * This is an asynchronous action that puts the recognizer into a DELETING state, and it is
 * then removed by a background job. Once removed, the recognizer disappears from your account
 * and is no longer available for use.
 */
export declare const deleteEntityRecognizer: API.OperationMethod<DeleteEntityRecognizerRequest, DeleteEntityRecognizerResponse, DeleteEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type DeleteFlywheelError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a flywheel. When you delete the flywheel, Amazon Comprehend
 * does not delete the data lake or the model associated with the flywheel.
 *
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const deleteFlywheel: API.OperationMethod<DeleteFlywheelRequest, DeleteFlywheelResponse, DeleteFlywheelError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a resource-based policy that is attached to a custom model.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about the dataset that you specify.
 * For more information about datasets, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDocumentClassificationJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a document classification job. Use this operation to
 * get the status of a classification job.
 */
export declare const describeDocumentClassificationJob: API.OperationMethod<DescribeDocumentClassificationJobRequest, DescribeDocumentClassificationJobResponse, DescribeDocumentClassificationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDocumentClassifierError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a document classifier.
 */
export declare const describeDocumentClassifier: API.OperationMethod<DescribeDocumentClassifierRequest, DescribeDocumentClassifierResponse, DescribeDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type DescribeDominantLanguageDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a dominant language detection job. Use this operation
 * to get the status of a detection job.
 */
export declare const describeDominantLanguageDetectionJob: API.OperationMethod<DescribeDominantLanguageDetectionJobRequest, DescribeDominantLanguageDetectionJobResponse, DescribeDominantLanguageDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a specific endpoint. Use this operation to get the
 * status of an endpoint.
 * For information about endpoints, see Managing endpoints.
 */
export declare const describeEndpoint: API.OperationMethod<DescribeEndpointRequest, DescribeEndpointResponse, DescribeEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an entities detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeEntitiesDetectionJob: API.OperationMethod<DescribeEntitiesDetectionJobRequest, DescribeEntitiesDetectionJobResponse, DescribeEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeEntityRecognizerError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides details about an entity recognizer including status, S3 buckets containing
 * training data, recognizer metadata, metrics, and so on.
 */
export declare const describeEntityRecognizer: API.OperationMethod<DescribeEntityRecognizerRequest, DescribeEntityRecognizerResponse, DescribeEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | NotAuthorizedException | CommonErrors;
/**
 * Gets the status and details of an events detection job.
 */
export declare const describeEventsDetectionJob: API.OperationMethod<DescribeEventsDetectionJobRequest, DescribeEventsDetectionJobResponse, DescribeEventsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeFlywheelError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides configuration information about the flywheel. For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const describeFlywheel: API.OperationMethod<DescribeFlywheelRequest, DescribeFlywheelResponse, DescribeFlywheelError, Credentials | HttpClient.HttpClient>;
export type DescribeFlywheelIterationError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the configuration properties of a flywheel iteration.
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const describeFlywheelIteration: API.OperationMethod<DescribeFlywheelIterationRequest, DescribeFlywheelIterationResponse, DescribeFlywheelIterationError, Credentials | HttpClient.HttpClient>;
export type DescribeKeyPhrasesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a key phrases detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeKeyPhrasesDetectionJob: API.OperationMethod<DescribeKeyPhrasesDetectionJobRequest, DescribeKeyPhrasesDetectionJobResponse, DescribeKeyPhrasesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribePiiEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a PII entities detection job. For example, you can use
 * this operation to get the job status.
 */
export declare const describePiiEntitiesDetectionJob: API.OperationMethod<DescribePiiEntitiesDetectionJobRequest, DescribePiiEntitiesDetectionJobResponse, DescribePiiEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePolicyError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the details of a resource-based policy that is attached to a custom model, including
 * the JSON body of the policy.
 */
export declare const describeResourcePolicy: API.OperationMethod<DescribeResourcePolicyRequest, DescribeResourcePolicyResponse, DescribeResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a sentiment detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeSentimentDetectionJob: API.OperationMethod<DescribeSentimentDetectionJobRequest, DescribeSentimentDetectionJobResponse, DescribeSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeTargetedSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a targeted sentiment detection job. Use this operation
 * to get the status of the job.
 */
export declare const describeTargetedSentimentDetectionJob: API.OperationMethod<DescribeTargetedSentimentDetectionJobRequest, DescribeTargetedSentimentDetectionJobResponse, DescribeTargetedSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicsDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a topic detection job. Use this operation to get
 * the status of a detection job.
 */
export declare const describeTopicsDetectionJob: API.OperationMethod<DescribeTopicsDetectionJobRequest, DescribeTopicsDetectionJobResponse, DescribeTopicsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DetectDominantLanguageError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | CommonErrors;
/**
 * Determines the dominant language of the input text. For a list of languages that Amazon
 * Comprehend can detect, see Amazon Comprehend Supported Languages.
 */
export declare const detectDominantLanguage: API.OperationMethod<DetectDominantLanguageRequest, DetectDominantLanguageResponse, DetectDominantLanguageError, Credentials | HttpClient.HttpClient>;
export type DetectEntitiesError = InternalServerException | InvalidRequestException | ResourceUnavailableException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Detects named entities in input text when you use the pre-trained model.
 * Detects custom entities if you have a custom entity recognition model.
 *
 * When detecting named entities using the pre-trained model, use plain text as the input.
 * For more information about named entities, see
 * Entities in the Comprehend Developer Guide.
 *
 * When you use a custom entity recognition model,
 * you can input plain text or you can upload a single-page input document (text, PDF, Word, or image).
 *
 * If the system detects errors while processing a page in the input document, the API response
 * includes an entry in `Errors` for each error.
 *
 * If the system detects a document-level error in your input document, the API returns an
 * `InvalidRequestException` error response.
 * For details about this exception, see
 *
 * Errors in semi-structured documents in the Comprehend Developer Guide.
 */
export declare const detectEntities: API.OperationMethod<DetectEntitiesRequest, DetectEntitiesResponse, DetectEntitiesError, Credentials | HttpClient.HttpClient>;
export type DetectKeyPhrasesError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Detects the key noun phrases found in the text.
 */
export declare const detectKeyPhrases: API.OperationMethod<DetectKeyPhrasesRequest, DetectKeyPhrasesResponse, DetectKeyPhrasesError, Credentials | HttpClient.HttpClient>;
export type DetectPiiEntitiesError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the input text for entities that contain personally identifiable information
 * (PII) and returns information about them.
 */
export declare const detectPiiEntities: API.OperationMethod<DetectPiiEntitiesRequest, DetectPiiEntitiesResponse, DetectPiiEntitiesError, Credentials | HttpClient.HttpClient>;
export type DetectSentimentError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects text and returns an inference of the prevailing sentiment
 * (`POSITIVE`, `NEUTRAL`, `MIXED`, or `NEGATIVE`).
 */
export declare const detectSentiment: API.OperationMethod<DetectSentimentRequest, DetectSentimentResponse, DetectSentimentError, Credentials | HttpClient.HttpClient>;
export type DetectSyntaxError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects text for syntax and the part of speech of words in the document. For more
 * information, see
 * Syntax in the Comprehend Developer Guide.
 */
export declare const detectSyntax: API.OperationMethod<DetectSyntaxRequest, DetectSyntaxResponse, DetectSyntaxError, Credentials | HttpClient.HttpClient>;
export type DetectTargetedSentimentError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Inspects the input text and returns a sentiment analysis for each entity identified in the text.
 *
 * For more information about targeted sentiment, see Targeted sentiment in the *Amazon Comprehend Developer Guide*.
 */
export declare const detectTargetedSentiment: API.OperationMethod<DetectTargetedSentimentRequest, DetectTargetedSentimentResponse, DetectTargetedSentimentError, Credentials | HttpClient.HttpClient>;
export type DetectToxicContentError = InternalServerException | InvalidRequestException | TextSizeLimitExceededException | UnsupportedLanguageException | CommonErrors;
/**
 * Performs toxicity analysis on the list of text strings that you provide as input.
 * The API response contains a results list that matches the size of the input list.
 * For more information about toxicity detection, see Toxicity detection in the *Amazon Comprehend Developer Guide*.
 */
export declare const detectToxicContent: API.OperationMethod<DetectToxicContentRequest, DetectToxicContentResponse, DetectToxicContentError, Credentials | HttpClient.HttpClient>;
export type ImportModelError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Creates a new custom model that replicates a source custom model that you import. The
 * source model can be in your Amazon Web Services account or another one.
 *
 * If the source model is in another Amazon Web Services account, then it must have a resource-based policy
 * that authorizes you to import it.
 *
 * The source model must be in the same Amazon Web Services Region that you're using when you import. You
 * can't import a model that's in a different Region.
 */
export declare const importModel: API.OperationMethod<ImportModelRequest, ImportModelResponse, ImportModelError, Credentials | HttpClient.HttpClient>;
export type ListDatasetsError = InternalServerException | InvalidFilterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the datasets that you have configured in this Region. For more information about datasets, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDocumentClassificationJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the documentation classification jobs that you have submitted.
 */
export declare const listDocumentClassificationJobs: API.PaginatedOperationMethod<ListDocumentClassificationJobsRequest, ListDocumentClassificationJobsResponse, ListDocumentClassificationJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDocumentClassifiersError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the document classifiers that you have created.
 */
export declare const listDocumentClassifiers: API.PaginatedOperationMethod<ListDocumentClassifiersRequest, ListDocumentClassifiersResponse, ListDocumentClassifiersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDocumentClassifierSummariesError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of summaries of the document classifiers that you have created
 */
export declare const listDocumentClassifierSummaries: API.PaginatedOperationMethod<ListDocumentClassifierSummariesRequest, ListDocumentClassifierSummariesResponse, ListDocumentClassifierSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDominantLanguageDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the dominant language detection jobs that you have submitted.
 */
export declare const listDominantLanguageDetectionJobs: API.PaginatedOperationMethod<ListDominantLanguageDetectionJobsRequest, ListDominantLanguageDetectionJobsResponse, ListDominantLanguageDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEndpointsError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of all existing endpoints that you've created.
 * For information about endpoints, see Managing endpoints.
 */
export declare const listEndpoints: API.PaginatedOperationMethod<ListEndpointsRequest, ListEndpointsResponse, ListEndpointsError, Credentials | HttpClient.HttpClient, EndpointProperties>;
export type ListEntitiesDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the entity detection jobs that you have submitted.
 */
export declare const listEntitiesDetectionJobs: API.PaginatedOperationMethod<ListEntitiesDetectionJobsRequest, ListEntitiesDetectionJobsResponse, ListEntitiesDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntityRecognizersError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the properties of all entity recognizers that you created, including
 * recognizers currently in training. Allows you to filter the list of recognizers based on
 * criteria such as status and submission time. This call returns up to 500 entity recognizers in
 * the list, with a default number of 100 recognizers in the list.
 *
 * The results of this list are not in any particular order. Please get the list and sort
 * locally if needed.
 */
export declare const listEntityRecognizers: API.PaginatedOperationMethod<ListEntityRecognizersRequest, ListEntityRecognizersResponse, ListEntityRecognizersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntityRecognizerSummariesError = InternalServerException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of summaries for the entity recognizers that you have created.
 */
export declare const listEntityRecognizerSummaries: API.PaginatedOperationMethod<ListEntityRecognizerSummariesRequest, ListEntityRecognizerSummariesResponse, ListEntityRecognizerSummariesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventsDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | NotAuthorizedException | CommonErrors;
/**
 * Gets a list of the events detection jobs that you have submitted.
 */
export declare const listEventsDetectionJobs: API.PaginatedOperationMethod<ListEventsDetectionJobsRequest, ListEventsDetectionJobsResponse, ListEventsDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFlywheelIterationHistoryError = InternalServerException | InvalidFilterException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Information about the history of a flywheel iteration.
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const listFlywheelIterationHistory: API.PaginatedOperationMethod<ListFlywheelIterationHistoryRequest, ListFlywheelIterationHistoryResponse, ListFlywheelIterationHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFlywheelsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the flywheels that you have created.
 */
export declare const listFlywheels: API.PaginatedOperationMethod<ListFlywheelsRequest, ListFlywheelsResponse, ListFlywheelsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKeyPhrasesDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Get a list of key phrase detection jobs that you have submitted.
 */
export declare const listKeyPhrasesDetectionJobs: API.PaginatedOperationMethod<ListKeyPhrasesDetectionJobsRequest, ListKeyPhrasesDetectionJobsResponse, ListKeyPhrasesDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPiiEntitiesDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the PII entity detection jobs that you have submitted.
 */
export declare const listPiiEntitiesDetectionJobs: API.PaginatedOperationMethod<ListPiiEntitiesDetectionJobsRequest, ListPiiEntitiesDetectionJobsResponse, ListPiiEntitiesDetectionJobsError, Credentials | HttpClient.HttpClient, PiiEntitiesDetectionJobProperties>;
export type ListSentimentDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of sentiment detection jobs that you have submitted.
 */
export declare const listSentimentDetectionJobs: API.PaginatedOperationMethod<ListSentimentDetectionJobsRequest, ListSentimentDetectionJobsResponse, ListSentimentDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists all tags associated with a given Amazon Comprehend resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetedSentimentDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of targeted sentiment detection jobs that you have submitted.
 */
export declare const listTargetedSentimentDetectionJobs: API.PaginatedOperationMethod<ListTargetedSentimentDetectionJobsRequest, ListTargetedSentimentDetectionJobsResponse, ListTargetedSentimentDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTopicsDetectionJobsError = InternalServerException | InvalidFilterException | InvalidRequestException | TooManyRequestsException | CommonErrors;
/**
 * Gets a list of the topic detection jobs that you have submitted.
 */
export declare const listTopicsDetectionJobs: API.PaginatedOperationMethod<ListTopicsDetectionJobsRequest, ListTopicsDetectionJobsResponse, ListTopicsDetectionJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type PutResourcePolicyError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Attaches a resource-based policy to a custom model. You can use this policy to authorize
 * an entity in another Amazon Web Services account to import the custom model, which replicates it in Amazon
 * Comprehend in their account.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartDocumentClassificationJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous document classification job using a custom classification model. Use the
 * `DescribeDocumentClassificationJob`
 * operation to track the progress of the job.
 */
export declare const startDocumentClassificationJob: API.OperationMethod<StartDocumentClassificationJobRequest, StartDocumentClassificationJobResponse, StartDocumentClassificationJobError, Credentials | HttpClient.HttpClient>;
export type StartDominantLanguageDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous dominant language detection job for a collection of documents. Use
 * the operation to track the status
 * of a job.
 */
export declare const startDominantLanguageDetectionJob: API.OperationMethod<StartDominantLanguageDetectionJobRequest, StartDominantLanguageDetectionJobResponse, StartDominantLanguageDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartEntitiesDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous entity detection job for a collection of documents. Use the operation to track the status of a job.
 *
 * This API can be used for either standard entity detection or custom entity recognition. In
 * order to be used for custom entity recognition, the optional `EntityRecognizerArn`
 * must be used in order to provide access to the recognizer being used to detect the custom
 * entity.
 */
export declare const startEntitiesDetectionJob: API.OperationMethod<StartEntitiesDetectionJobRequest, StartEntitiesDetectionJobResponse, StartEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartEventsDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | NotAuthorizedException | CommonErrors;
/**
 * Starts an asynchronous event detection job for a collection of documents.
 */
export declare const startEventsDetectionJob: API.OperationMethod<StartEventsDetectionJobRequest, StartEventsDetectionJobResponse, StartEventsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartFlywheelIterationError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Start the flywheel iteration.This operation uses any new datasets to train a new model version.
 * For more information about flywheels, see
 * Flywheel overview in the *Amazon Comprehend Developer Guide*.
 */
export declare const startFlywheelIteration: API.OperationMethod<StartFlywheelIterationRequest, StartFlywheelIterationResponse, StartFlywheelIterationError, Credentials | HttpClient.HttpClient>;
export type StartKeyPhrasesDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous key phrase detection job for a collection of documents. Use the
 * operation to track the status of a
 * job.
 */
export declare const startKeyPhrasesDetectionJob: API.OperationMethod<StartKeyPhrasesDetectionJobRequest, StartKeyPhrasesDetectionJobResponse, StartKeyPhrasesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartPiiEntitiesDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous PII entity detection job for a collection of documents.
 */
export declare const startPiiEntitiesDetectionJob: API.OperationMethod<StartPiiEntitiesDetectionJobRequest, StartPiiEntitiesDetectionJobResponse, StartPiiEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartSentimentDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous sentiment detection job for a collection of documents. Use the
 * operation to track the status of a
 * job.
 */
export declare const startSentimentDetectionJob: API.OperationMethod<StartSentimentDetectionJobRequest, StartSentimentDetectionJobResponse, StartSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartTargetedSentimentDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous targeted sentiment detection job for a collection of documents. Use the
 * `DescribeTargetedSentimentDetectionJob` operation to track the status of a
 * job.
 */
export declare const startTargetedSentimentDetectionJob: API.OperationMethod<StartTargetedSentimentDetectionJobRequest, StartTargetedSentimentDetectionJobResponse, StartTargetedSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartTopicsDetectionJobError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceInUseException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Starts an asynchronous topic detection job. Use the
 * `DescribeTopicDetectionJob` operation to track the status of a job.
 */
export declare const startTopicsDetectionJob: API.OperationMethod<StartTopicsDetectionJobRequest, StartTopicsDetectionJobResponse, StartTopicsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopDominantLanguageDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a dominant language detection job in progress.
 *
 * If the job state is `IN_PROGRESS` the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopDominantLanguageDetectionJob: API.OperationMethod<StopDominantLanguageDetectionJobRequest, StopDominantLanguageDetectionJobResponse, StopDominantLanguageDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops an entities detection job in progress.
 *
 * If the job state is `IN_PROGRESS` the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopEntitiesDetectionJob: API.OperationMethod<StopEntitiesDetectionJobRequest, StopEntitiesDetectionJobResponse, StopEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopEventsDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | NotAuthorizedException | CommonErrors;
/**
 * Stops an events detection job in progress.
 */
export declare const stopEventsDetectionJob: API.OperationMethod<StopEventsDetectionJobRequest, StopEventsDetectionJobResponse, StopEventsDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopKeyPhrasesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a key phrases detection job in progress.
 *
 * If the job state is `IN_PROGRESS` the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopKeyPhrasesDetectionJob: API.OperationMethod<StopKeyPhrasesDetectionJobRequest, StopKeyPhrasesDetectionJobResponse, StopKeyPhrasesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopPiiEntitiesDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a PII entities detection job in progress.
 */
export declare const stopPiiEntitiesDetectionJob: API.OperationMethod<StopPiiEntitiesDetectionJobRequest, StopPiiEntitiesDetectionJobResponse, StopPiiEntitiesDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a sentiment detection job in progress.
 *
 * If the job state is `IN_PROGRESS`, the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is be stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopSentimentDetectionJob: API.OperationMethod<StopSentimentDetectionJobRequest, StopSentimentDetectionJobResponse, StopSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopTargetedSentimentDetectionJobError = InternalServerException | InvalidRequestException | JobNotFoundException | CommonErrors;
/**
 * Stops a targeted sentiment detection job in progress.
 *
 * If the job state is `IN_PROGRESS`, the job is marked for termination and put
 * into the `STOP_REQUESTED` state. If the job completes before it can be stopped, it
 * is put into the `COMPLETED` state; otherwise the job is be stopped and put into the
 * `STOPPED` state.
 *
 * If the job is in the `COMPLETED` or `FAILED` state when you call the
 * `StopDominantLanguageDetectionJob` operation, the operation returns a 400
 * Internal Request Exception.
 *
 * When a job is stopped, any documents already processed are written to the output
 * location.
 */
export declare const stopTargetedSentimentDetectionJob: API.OperationMethod<StopTargetedSentimentDetectionJobRequest, StopTargetedSentimentDetectionJobResponse, StopTargetedSentimentDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopTrainingDocumentClassifierError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops a document classifier training job while in progress.
 *
 * If the training job state is `TRAINING`, the job is marked for termination and
 * put into the `STOP_REQUESTED` state. If the training job completes before it can be
 * stopped, it is put into the `TRAINED`; otherwise the training job is stopped and
 * put into the `STOPPED` state and the service sends back an HTTP 200 response with
 * an empty HTTP body.
 */
export declare const stopTrainingDocumentClassifier: API.OperationMethod<StopTrainingDocumentClassifierRequest, StopTrainingDocumentClassifierResponse, StopTrainingDocumentClassifierError, Credentials | HttpClient.HttpClient>;
export type StopTrainingEntityRecognizerError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops an entity recognizer training job while in progress.
 *
 * If the training job state is `TRAINING`, the job is marked for termination and
 * put into the `STOP_REQUESTED` state. If the training job completes before it can be
 * stopped, it is put into the `TRAINED`; otherwise the training job is stopped and
 * putted into the `STOPPED` state and the service sends back an HTTP 200 response
 * with an empty HTTP body.
 */
export declare const stopTrainingEntityRecognizer: API.OperationMethod<StopTrainingEntityRecognizerRequest, StopTrainingEntityRecognizerResponse, StopTrainingEntityRecognizerError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Associates a specific tag with an Amazon Comprehend resource. A tag is a key-value pair
 * that adds as a metadata to a resource used by Amazon Comprehend. For example, a tag with
 * "Sales" as the key might be added to a resource to indicate its use by the sales department.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyTagKeysException | CommonErrors;
/**
 * Removes a specific tag associated with an Amazon Comprehend resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEndpointError = InternalServerException | InvalidRequestException | ResourceInUseException | ResourceLimitExceededException | ResourceNotFoundException | ResourceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates information about the specified endpoint.
 * For information about endpoints, see Managing endpoints.
 */
export declare const updateEndpoint: API.OperationMethod<UpdateEndpointRequest, UpdateEndpointResponse, UpdateEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateFlywheelError = InternalServerException | InvalidRequestException | KmsKeyValidationException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update the configuration information for an existing flywheel.
 */
export declare const updateFlywheel: API.OperationMethod<UpdateFlywheelRequest, UpdateFlywheelResponse, UpdateFlywheelError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=comprehend.d.ts.map