import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const PendingVerification_base: S.Class<PendingVerification, S.TaggedStruct<"PendingVerification", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class PendingVerification extends /*@__PURE__*/ PendingVerification_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly limit: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly limit: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RoomIdentifier = string;
export type UserID = string | redacted.Redacted<string>;
export type ChatTokenCapability = string;
export type ChatTokenCapabilities = string[];
export declare const ChatTokenCapabilities: any;
export type SessionDurationInMinutes = number;
export type ChatTokenAttributes = {
    [key: string]: string | undefined;
};
export declare const ChatTokenAttributes: any;
export interface CreateChatTokenRequest {
    roomIdentifier: string;
    userId: string | redacted.Redacted<string>;
    capabilities?: string[];
    sessionDurationInMinutes?: number;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateChatTokenRequest: S.Schema<CreateChatTokenRequest>;
export type ChatToken = string | redacted.Redacted<string>;
export interface CreateChatTokenResponse {
    token?: string | redacted.Redacted<string>;
    tokenExpirationTime?: Date;
    sessionExpirationTime?: Date;
}
export declare const CreateChatTokenResponse: S.Schema<CreateChatTokenResponse>;
export type LoggingConfigurationName = string;
export type BucketName = string;
export interface S3DestinationConfiguration {
    bucketName: string;
}
export declare const S3DestinationConfiguration: S.Schema<S3DestinationConfiguration>;
export type LogGroupName = string;
export interface CloudWatchLogsDestinationConfiguration {
    logGroupName: string;
}
export declare const CloudWatchLogsDestinationConfiguration: S.Schema<CloudWatchLogsDestinationConfiguration>;
export type DeliveryStreamName = string;
export interface FirehoseDestinationConfiguration {
    deliveryStreamName: string;
}
export declare const FirehoseDestinationConfiguration: S.Schema<FirehoseDestinationConfiguration>;
export type DestinationConfiguration = {
    s3: S3DestinationConfiguration;
    cloudWatchLogs?: never;
    firehose?: never;
} | {
    s3?: never;
    cloudWatchLogs: CloudWatchLogsDestinationConfiguration;
    firehose?: never;
} | {
    s3?: never;
    cloudWatchLogs?: never;
    firehose: FirehoseDestinationConfiguration;
};
export declare const DestinationConfiguration: any;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CreateLoggingConfigurationRequest {
    name?: string;
    destinationConfiguration: DestinationConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateLoggingConfigurationRequest: S.Schema<CreateLoggingConfigurationRequest>;
export type LoggingConfigurationArn = string;
export type LoggingConfigurationID = string;
export type CreateLoggingConfigurationState = string;
export interface CreateLoggingConfigurationResponse {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateLoggingConfigurationResponse: S.Schema<CreateLoggingConfigurationResponse>;
export type RoomName = string;
export type RoomMaxMessageRatePerSecond = number;
export type RoomMaxMessageLength = number;
export type LambdaArn = string;
export type FallbackResult = string;
export interface MessageReviewHandler {
    uri?: string;
    fallbackResult?: string;
}
export declare const MessageReviewHandler: S.Schema<MessageReviewHandler>;
export type LoggingConfigurationIdentifier = string;
export type LoggingConfigurationIdentifierList = string[];
export declare const LoggingConfigurationIdentifierList: any;
export interface CreateRoomRequest {
    name?: string;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export declare const CreateRoomRequest: S.Schema<CreateRoomRequest>;
export type RoomArn = string;
export type RoomID = string;
export interface CreateRoomResponse {
    arn?: string;
    id?: string;
    name?: string;
    createTime?: Date;
    updateTime?: Date;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export declare const CreateRoomResponse: S.Schema<CreateRoomResponse>;
export interface DeleteLoggingConfigurationRequest {
    identifier: string;
}
export declare const DeleteLoggingConfigurationRequest: S.Schema<DeleteLoggingConfigurationRequest>;
export interface DeleteLoggingConfigurationResponse {
}
export declare const DeleteLoggingConfigurationResponse: S.Schema<DeleteLoggingConfigurationResponse>;
export type MessageID = string;
export type Reason = string;
export interface DeleteMessageRequest {
    roomIdentifier: string;
    id: string;
    reason?: string;
}
export declare const DeleteMessageRequest: S.Schema<DeleteMessageRequest>;
export type ID = string;
export interface DeleteMessageResponse {
    id?: string;
}
export declare const DeleteMessageResponse: S.Schema<DeleteMessageResponse>;
export interface DeleteRoomRequest {
    identifier: string;
}
export declare const DeleteRoomRequest: S.Schema<DeleteRoomRequest>;
export interface DeleteRoomResponse {
}
export declare const DeleteRoomResponse: S.Schema<DeleteRoomResponse>;
export interface DisconnectUserRequest {
    roomIdentifier: string;
    userId: string | redacted.Redacted<string>;
    reason?: string;
}
export declare const DisconnectUserRequest: S.Schema<DisconnectUserRequest>;
export interface DisconnectUserResponse {
}
export declare const DisconnectUserResponse: S.Schema<DisconnectUserResponse>;
export interface GetLoggingConfigurationRequest {
    identifier: string;
}
export declare const GetLoggingConfigurationRequest: S.Schema<GetLoggingConfigurationRequest>;
export type LoggingConfigurationState = string;
export interface GetLoggingConfigurationResponse {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetLoggingConfigurationResponse: S.Schema<GetLoggingConfigurationResponse>;
export interface GetRoomRequest {
    identifier: string;
}
export declare const GetRoomRequest: S.Schema<GetRoomRequest>;
export interface GetRoomResponse {
    arn?: string;
    id?: string;
    name?: string;
    createTime?: Date;
    updateTime?: Date;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export declare const GetRoomResponse: S.Schema<GetRoomResponse>;
export type PaginationToken = string;
export type MaxLoggingConfigurationResults = number;
export interface ListLoggingConfigurationsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListLoggingConfigurationsRequest: S.Schema<ListLoggingConfigurationsRequest>;
export interface LoggingConfigurationSummary {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const LoggingConfigurationSummary: S.Schema<LoggingConfigurationSummary>;
export type LoggingConfigurationList = LoggingConfigurationSummary[];
export declare const LoggingConfigurationList: any;
export interface ListLoggingConfigurationsResponse {
    loggingConfigurations: LoggingConfigurationSummary[];
    nextToken?: string;
}
export declare const ListLoggingConfigurationsResponse: S.Schema<ListLoggingConfigurationsResponse>;
export type MaxRoomResults = number;
export interface ListRoomsRequest {
    name?: string;
    nextToken?: string;
    maxResults?: number;
    messageReviewHandlerUri?: string;
    loggingConfigurationIdentifier?: string;
}
export declare const ListRoomsRequest: S.Schema<ListRoomsRequest>;
export interface RoomSummary {
    arn?: string;
    id?: string;
    name?: string;
    messageReviewHandler?: MessageReviewHandler;
    createTime?: Date;
    updateTime?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export declare const RoomSummary: S.Schema<RoomSummary>;
export type RoomList = RoomSummary[];
export declare const RoomList: any;
export interface ListRoomsResponse {
    rooms: RoomSummary[];
    nextToken?: string;
}
export declare const ListRoomsResponse: S.Schema<ListRoomsResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type EventName = string;
export type EventAttributes = {
    [key: string]: string | undefined;
};
export declare const EventAttributes: any;
export interface SendEventRequest {
    roomIdentifier: string;
    eventName: string;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export declare const SendEventRequest: S.Schema<SendEventRequest>;
export interface SendEventResponse {
    id?: string;
}
export declare const SendEventResponse: S.Schema<SendEventResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateLoggingConfigurationRequest {
    identifier: string;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
}
export declare const UpdateLoggingConfigurationRequest: S.Schema<UpdateLoggingConfigurationRequest>;
export type UpdateLoggingConfigurationState = string;
export interface UpdateLoggingConfigurationResponse {
    arn?: string;
    id?: string;
    createTime?: Date;
    updateTime?: Date;
    name?: string;
    destinationConfiguration?: DestinationConfiguration;
    state?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateLoggingConfigurationResponse: S.Schema<UpdateLoggingConfigurationResponse>;
export interface UpdateRoomRequest {
    identifier: string;
    name?: string;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    loggingConfigurationIdentifiers?: string[];
}
export declare const UpdateRoomRequest: S.Schema<UpdateRoomRequest>;
export interface UpdateRoomResponse {
    arn?: string;
    id?: string;
    name?: string;
    createTime?: Date;
    updateTime?: Date;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
    messageReviewHandler?: MessageReviewHandler;
    tags?: {
        [key: string]: string | undefined;
    };
    loggingConfigurationIdentifiers?: string[];
}
export declare const UpdateRoomResponse: S.Schema<UpdateRoomResponse>;
export type ErrorMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type ValidationExceptionReason = string;
export type FieldName = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type Limit = number;
export type CreateChatTokenError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an encrypted token that is used by a chat participant to establish an individual
 * WebSocket chat connection to a room. When the token is used to connect to chat, the
 * connection is valid for the session duration specified in the request. The token becomes
 * invalid at the token-expiration timestamp included in the response.
 *
 * Use the `capabilities` field to permit an end user to send messages or
 * moderate a room.
 *
 * The `attributes` field securely attaches structured data to the chat session; the data is
 * included within each message sent by the end user and received by other participants in the
 * room. Common use cases for attributes include passing end-user profile data like an icon,
 * display name, colors, badges, and other display features.
 *
 * Encryption keys are owned by Amazon IVS Chat and never used directly by your
 * application.
 */
export declare const createChatToken: API.OperationMethod<CreateChatTokenRequest, CreateChatTokenResponse, CreateChatTokenError, Credentials | HttpClient.HttpClient>;
export type CreateLoggingConfigurationError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a logging configuration that allows clients to store and record sent
 * messages.
 */
export declare const createLoggingConfiguration: API.OperationMethod<CreateLoggingConfigurationRequest, CreateLoggingConfigurationResponse, CreateLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateRoomError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a room that allows clients to connect and pass messages.
 */
export declare const createRoom: API.OperationMethod<CreateRoomRequest, CreateRoomResponse, CreateRoomError, Credentials | HttpClient.HttpClient>;
export type DeleteLoggingConfigurationError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified logging configuration.
 */
export declare const deleteLoggingConfiguration: API.OperationMethod<DeleteLoggingConfigurationRequest, DeleteLoggingConfigurationResponse, DeleteLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteMessageError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an event to a specific room which directs clients to delete a specific message;
 * that is, unrender it from view and delete it from the client’s chat history. This event’s
 * `EventName` is `aws:DELETE_MESSAGE`. This replicates the
 * DeleteMessage WebSocket operation in the Amazon IVS Chat Messaging API.
 */
export declare const deleteMessage: API.OperationMethod<DeleteMessageRequest, DeleteMessageResponse, DeleteMessageError, Credentials | HttpClient.HttpClient>;
export type DeleteRoomError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified room.
 */
export declare const deleteRoom: API.OperationMethod<DeleteRoomRequest, DeleteRoomResponse, DeleteRoomError, Credentials | HttpClient.HttpClient>;
export type DisconnectUserError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disconnects all connections using a specified user ID from a room. This replicates the
 *
 * DisconnectUser WebSocket operation in the Amazon IVS Chat Messaging API.
 */
export declare const disconnectUser: API.OperationMethod<DisconnectUserRequest, DisconnectUserResponse, DisconnectUserError, Credentials | HttpClient.HttpClient>;
export type GetLoggingConfigurationError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the specified logging configuration.
 */
export declare const getLoggingConfiguration: API.OperationMethod<GetLoggingConfigurationRequest, GetLoggingConfigurationResponse, GetLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetRoomError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets the specified room.
 */
export declare const getRoom: API.OperationMethod<GetRoomRequest, GetRoomResponse, GetRoomError, Credentials | HttpClient.HttpClient>;
export type ListLoggingConfigurationsError = AccessDeniedException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all your logging configurations in the AWS region where
 * the API request is processed.
 */
export declare const listLoggingConfigurations: API.PaginatedOperationMethod<ListLoggingConfigurationsRequest, ListLoggingConfigurationsResponse, ListLoggingConfigurationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRoomsError = AccessDeniedException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets summary information about all your rooms in the AWS region where the API request is
 * processed. Results are sorted in descending order of `updateTime`.
 */
export declare const listRooms: API.PaginatedOperationMethod<ListRoomsRequest, ListRoomsResponse, ListRoomsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Gets information about AWS tags for the specified ARN.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type SendEventError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an event to a room. Use this within your application’s business logic to send
 * events to clients of a room; e.g., to notify clients to change the way the chat UI is
 * rendered.
 */
export declare const sendEvent: API.OperationMethod<SendEventRequest, SendEventResponse, SendEventError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Adds or updates tags for the AWS resource with the specified ARN.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Removes tags from the resource with the specified ARN.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLoggingConfigurationError = AccessDeniedException | ConflictException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Updates a specified logging configuration.
 */
export declare const updateLoggingConfiguration: API.OperationMethod<UpdateLoggingConfigurationRequest, UpdateLoggingConfigurationResponse, UpdateLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateRoomError = AccessDeniedException | PendingVerification | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Updates a room’s configuration.
 */
export declare const updateRoom: API.OperationMethod<UpdateRoomRequest, UpdateRoomResponse, UpdateRoomError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=ivschat.d.ts.map