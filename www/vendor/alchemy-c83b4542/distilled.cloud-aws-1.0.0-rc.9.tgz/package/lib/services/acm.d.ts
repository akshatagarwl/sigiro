import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidArgsException_base: S.Class<InvalidArgsException, S.TaggedStruct<"InvalidArgsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidArgsException extends /*@__PURE__*/ InvalidArgsException_base {
}
declare const InvalidArnException_base: S.Class<InvalidArnException, S.TaggedStruct<"InvalidArnException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidDomainValidationOptionsException_base: S.Class<InvalidDomainValidationOptionsException, S.TaggedStruct<"InvalidDomainValidationOptionsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidDomainValidationOptionsException extends /*@__PURE__*/ InvalidDomainValidationOptionsException_base {
}
declare const InvalidParameterException_base: S.Class<InvalidParameterException, S.TaggedStruct<"InvalidParameterException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const InvalidTagException_base: S.Class<InvalidTagException, S.TaggedStruct<"InvalidTagException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const RequestInProgressException_base: S.Class<RequestInProgressException, S.TaggedStruct<"RequestInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestInProgressException extends /*@__PURE__*/ RequestInProgressException_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TagPolicyException_base: S.Class<TagPolicyException, S.TaggedStruct<"TagPolicyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TagPolicyException extends /*@__PURE__*/ TagPolicyException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly throttlingReasons: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.Class<TooManyTagsException, S.TaggedStruct<"TooManyTagsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface AddTagsToCertificateRequest {
    CertificateArn: string;
    Tags: Tag[];
}
export declare const AddTagsToCertificateRequest: S.Schema<AddTagsToCertificateRequest>;
export interface AddTagsToCertificateResponse {
}
export declare const AddTagsToCertificateResponse: S.Schema<AddTagsToCertificateResponse>;
export type AcmeEndpointArn = string;
export type DomainName = string;
export type DomainScopeOption = "ENABLED" | "DISABLED" | (string & {});
export declare const DomainScopeOption: any;
export interface DomainScope {
    ExactDomain?: DomainScopeOption;
    Subdomains?: DomainScopeOption;
    Wildcards?: DomainScopeOption;
}
export declare const DomainScope: S.Schema<DomainScope>;
export type HostedZoneId = string;
export interface DnsPrevalidationOptions {
    DomainScope?: DomainScope;
    HostedZoneId?: string;
}
export declare const DnsPrevalidationOptions: S.Schema<DnsPrevalidationOptions>;
export type PrevalidationOptions = {
    DnsPrevalidation: DnsPrevalidationOptions;
};
export declare const PrevalidationOptions: any;
export interface CreateAcmeDomainValidationRequest {
    IdempotencyToken?: string;
    AcmeEndpointArn: string;
    DomainName: string;
    PrevalidationOptions: PrevalidationOptions;
    Tags?: Tag[];
}
export declare const CreateAcmeDomainValidationRequest: S.Schema<CreateAcmeDomainValidationRequest>;
export type AcmeDomainValidationArn = string;
export interface CreateAcmeDomainValidationResponse {
    AcmeDomainValidationArn: string;
}
export declare const CreateAcmeDomainValidationResponse: S.Schema<CreateAcmeDomainValidationResponse>;
export type AcmeAuthorizationBehavior = "PRE_APPROVED" | (string & {});
export declare const AcmeAuthorizationBehavior: any;
export type AcmeContact = "REQUIRED" | "NOT_REQUIRED" | (string & {});
export declare const AcmeContact: any;
export type PublicKeyAlgorithm = "RSA_2048" | "EC_prime256v1" | "EC_secp384r1" | (string & {});
export declare const PublicKeyAlgorithm: any;
export type PublicKeyAlgorithmList = PublicKeyAlgorithm[];
export declare const PublicKeyAlgorithmList: any;
export interface PublicCertificateAuthority {
    AllowedKeyAlgorithms?: PublicKeyAlgorithm[];
}
export declare const PublicCertificateAuthority: S.Schema<PublicCertificateAuthority>;
export type CertificateAuthority = {
    PublicCertificateAuthority: PublicCertificateAuthority;
};
export declare const CertificateAuthority: any;
export interface CreateAcmeEndpointRequest {
    IdempotencyToken?: string;
    AuthorizationBehavior: AcmeAuthorizationBehavior;
    Contact?: AcmeContact;
    CertificateAuthority: CertificateAuthority;
    Tags?: Tag[];
    CertificateTags?: Tag[];
}
export declare const CreateAcmeEndpointRequest: S.Schema<CreateAcmeEndpointRequest>;
export interface CreateAcmeEndpointResponse {
    AcmeEndpointArn?: string;
}
export declare const CreateAcmeEndpointResponse: S.Schema<CreateAcmeEndpointResponse>;
export type RoleArn = string;
export type TimeType = "MINUTES" | "HOURS" | "DAYS" | (string & {});
export declare const TimeType: any;
export interface Expiration {
    Value: number;
    Type: TimeType;
}
export declare const Expiration: S.Schema<Expiration>;
export interface CreateAcmeExternalAccountBindingRequest {
    IdempotencyToken?: string;
    AcmeEndpointArn: string;
    RoleArn: string;
    Expiration?: Expiration;
    Tags?: Tag[];
}
export declare const CreateAcmeExternalAccountBindingRequest: S.Schema<CreateAcmeExternalAccountBindingRequest>;
export type AcmeExternalAccountBindingArn = string;
export interface AcmeExternalAccountBinding {
    AcmeExternalAccountBindingArn?: string;
    AcmeEndpointArn?: string;
    RoleArn?: string;
    ExpiresAt?: Date;
    RevokedAt?: Date;
    LastUsedAt?: Date;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const AcmeExternalAccountBinding: S.Schema<AcmeExternalAccountBinding>;
export interface CreateAcmeExternalAccountBindingResponse {
    ExternalAccountBinding?: AcmeExternalAccountBinding;
}
export declare const CreateAcmeExternalAccountBindingResponse: S.Schema<CreateAcmeExternalAccountBindingResponse>;
export interface DeleteAcmeDomainValidationRequest {
    AcmeDomainValidationArn: string;
}
export declare const DeleteAcmeDomainValidationRequest: S.Schema<DeleteAcmeDomainValidationRequest>;
export interface DeleteAcmeDomainValidationResponse {
}
export declare const DeleteAcmeDomainValidationResponse: S.Schema<DeleteAcmeDomainValidationResponse>;
export interface DeleteAcmeEndpointRequest {
    AcmeEndpointArn: string;
}
export declare const DeleteAcmeEndpointRequest: S.Schema<DeleteAcmeEndpointRequest>;
export interface DeleteAcmeEndpointResponse {
}
export declare const DeleteAcmeEndpointResponse: S.Schema<DeleteAcmeEndpointResponse>;
export interface DeleteAcmeExternalAccountBindingRequest {
    AcmeExternalAccountBindingArn: string;
}
export declare const DeleteAcmeExternalAccountBindingRequest: S.Schema<DeleteAcmeExternalAccountBindingRequest>;
export interface DeleteAcmeExternalAccountBindingResponse {
}
export declare const DeleteAcmeExternalAccountBindingResponse: S.Schema<DeleteAcmeExternalAccountBindingResponse>;
export interface DeleteCertificateRequest {
    CertificateArn: string;
}
export declare const DeleteCertificateRequest: S.Schema<DeleteCertificateRequest>;
export interface DeleteCertificateResponse {
}
export declare const DeleteCertificateResponse: S.Schema<DeleteCertificateResponse>;
export interface DescribeAcmeAccountRequest {
    AcmeEndpointArn: string;
    AccountUrl: string;
}
export declare const DescribeAcmeAccountRequest: S.Schema<DescribeAcmeAccountRequest>;
export type AcmeAccountStatus = "VALID" | "DEACTIVATED" | "REVOKED" | (string & {});
export declare const AcmeAccountStatus: any;
export type ContactList = string[];
export declare const ContactList: any;
export interface AcmeAccount {
    AccountUrl?: string;
    PublicKeyThumbprint?: string;
    Status?: AcmeAccountStatus;
    CreatedAt?: Date;
    AcmeExternalAccountBindingArn?: string;
    Contacts?: string[];
}
export declare const AcmeAccount: S.Schema<AcmeAccount>;
export interface DescribeAcmeAccountResponse {
    AcmeAccount?: AcmeAccount;
}
export declare const DescribeAcmeAccountResponse: S.Schema<DescribeAcmeAccountResponse>;
export interface DescribeAcmeDomainValidationRequest {
    AcmeDomainValidationArn: string;
}
export declare const DescribeAcmeDomainValidationRequest: S.Schema<DescribeAcmeDomainValidationRequest>;
export type PrevalidationType = "DNS_PREVALIDATION" | (string & {});
export declare const PrevalidationType: any;
export type RecordType = "CNAME" | (string & {});
export declare const RecordType: any;
export interface ResourceRecord {
    Name: string;
    Type: RecordType;
    Value: string;
}
export declare const ResourceRecord: S.Schema<ResourceRecord>;
export interface DnsPrevalidationDetails {
    DomainScope?: DomainScope;
    HostedZoneId?: string;
    ResourceRecord?: ResourceRecord;
}
export declare const DnsPrevalidationDetails: S.Schema<DnsPrevalidationDetails>;
export type PrevalidationDetails = {
    DnsPrevalidation: DnsPrevalidationDetails;
};
export declare const PrevalidationDetails: any;
export type AcmeDomainValidationStatus = "VALIDATING" | "VALID" | "INVALID" | "DELETING" | (string & {});
export declare const AcmeDomainValidationStatus: any;
export type AcmeDomainValidationFailureReason = "ACCESS_DENIED" | "DOMAIN_MISMATCH" | "DOMAIN_NOT_ALLOWED" | "ENDPOINT_NOT_ACTIVE" | "HOSTED_ZONE_NOT_FOUND" | "INTERNAL_FAILURE" | "INVALID_CHANGE_BATCH" | "INVALID_PUBLIC_DOMAIN" | "TIMED_OUT" | (string & {});
export declare const AcmeDomainValidationFailureReason: any;
export interface FailureDetails {
    Reason?: AcmeDomainValidationFailureReason;
    Message?: string;
}
export declare const FailureDetails: S.Schema<FailureDetails>;
export interface AcmeDomainValidation {
    AcmeDomainValidationArn?: string;
    AcmeEndpointArn?: string;
    DomainName?: string;
    PrevalidationType?: PrevalidationType;
    PrevalidationDetails?: PrevalidationDetails;
    Status?: AcmeDomainValidationStatus;
    FailureDetails?: FailureDetails;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const AcmeDomainValidation: S.Schema<AcmeDomainValidation>;
export interface DescribeAcmeDomainValidationResponse {
    AcmeDomainValidation?: AcmeDomainValidation;
}
export declare const DescribeAcmeDomainValidationResponse: S.Schema<DescribeAcmeDomainValidationResponse>;
export interface DescribeAcmeEndpointRequest {
    AcmeEndpointArn: string;
}
export declare const DescribeAcmeEndpointRequest: S.Schema<DescribeAcmeEndpointRequest>;
export type AcmeEndpointStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export declare const AcmeEndpointStatus: any;
export interface AcmeEndpoint {
    AcmeEndpointArn?: string;
    EndpointUrl?: string;
    Status?: AcmeEndpointStatus;
    FailureReason?: string;
    AuthorizationBehavior?: AcmeAuthorizationBehavior;
    Contact?: AcmeContact;
    CertificateAuthority?: CertificateAuthority;
    CertificateTags?: Tag[];
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const AcmeEndpoint: S.Schema<AcmeEndpoint>;
export interface DescribeAcmeEndpointResponse {
    AcmeEndpoint?: AcmeEndpoint;
}
export declare const DescribeAcmeEndpointResponse: S.Schema<DescribeAcmeEndpointResponse>;
export interface DescribeAcmeExternalAccountBindingRequest {
    AcmeExternalAccountBindingArn: string;
}
export declare const DescribeAcmeExternalAccountBindingRequest: S.Schema<DescribeAcmeExternalAccountBindingRequest>;
export interface DescribeAcmeExternalAccountBindingResponse {
    ExternalAccountBinding?: AcmeExternalAccountBinding;
}
export declare const DescribeAcmeExternalAccountBindingResponse: S.Schema<DescribeAcmeExternalAccountBindingResponse>;
export interface DescribeCertificateRequest {
    CertificateArn: string;
}
export declare const DescribeCertificateRequest: S.Schema<DescribeCertificateRequest>;
export type DomainNameString = string;
export type DomainList = string[];
export declare const DomainList: any;
export type CertificateManagedBy = "CLOUDFRONT" | (string & {});
export declare const CertificateManagedBy: any;
export type ValidationEmailList = string[];
export declare const ValidationEmailList: any;
export type DomainStatus = "PENDING_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export declare const DomainStatus: any;
export interface HttpRedirect {
    RedirectFrom?: string;
    RedirectTo?: string;
}
export declare const HttpRedirect: S.Schema<HttpRedirect>;
export type ValidationMethod = "EMAIL" | "DNS" | "HTTP" | (string & {});
export declare const ValidationMethod: any;
export interface DomainValidation {
    DomainName: string;
    ValidationEmails?: string[];
    ValidationDomain?: string;
    ValidationStatus?: DomainStatus;
    ResourceRecord?: ResourceRecord;
    HttpRedirect?: HttpRedirect;
    ValidationMethod?: ValidationMethod;
}
export declare const DomainValidation: S.Schema<DomainValidation>;
export type DomainValidationList = DomainValidation[];
export declare const DomainValidationList: any;
export type CertificateStatus = "PENDING_VALIDATION" | "ISSUED" | "INACTIVE" | "EXPIRED" | "VALIDATION_TIMED_OUT" | "REVOKED" | "FAILED" | (string & {});
export declare const CertificateStatus: any;
export type RevocationReason = "UNSPECIFIED" | "KEY_COMPROMISE" | "CA_COMPROMISE" | "AFFILIATION_CHANGED" | "SUPERCEDED" | "SUPERSEDED" | "CESSATION_OF_OPERATION" | "CERTIFICATE_HOLD" | "REMOVE_FROM_CRL" | "PRIVILEGE_WITHDRAWN" | "A_A_COMPROMISE" | (string & {});
export declare const RevocationReason: any;
export type KeyAlgorithm = "RSA_1024" | "RSA_2048" | "RSA_3072" | "RSA_4096" | "EC_prime256v1" | "EC_secp384r1" | "EC_secp521r1" | (string & {});
export declare const KeyAlgorithm: any;
export type InUseList = string[];
export declare const InUseList: any;
export type FailureReason = "NO_AVAILABLE_CONTACTS" | "ADDITIONAL_VERIFICATION_REQUIRED" | "DOMAIN_NOT_ALLOWED" | "INVALID_PUBLIC_DOMAIN" | "DOMAIN_VALIDATION_DENIED" | "CAA_ERROR" | "PCA_LIMIT_EXCEEDED" | "PCA_INVALID_ARN" | "PCA_INVALID_STATE" | "PCA_REQUEST_FAILED" | "PCA_NAME_CONSTRAINTS_VALIDATION" | "PCA_RESOURCE_NOT_FOUND" | "PCA_INVALID_ARGS" | "PCA_INVALID_DURATION" | "PCA_ACCESS_DENIED" | "SLR_NOT_FOUND" | "OTHER" | (string & {});
export declare const FailureReason: any;
export type CertificateType = "IMPORTED" | "AMAZON_ISSUED" | "PRIVATE" | (string & {});
export declare const CertificateType: any;
export type RenewalStatus = "PENDING_AUTO_RENEWAL" | "PENDING_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export declare const RenewalStatus: any;
export interface RenewalSummary {
    RenewalStatus: RenewalStatus;
    DomainValidationOptions: DomainValidation[];
    RenewalStatusReason?: FailureReason;
    UpdatedAt: Date;
}
export declare const RenewalSummary: S.Schema<RenewalSummary>;
export type KeyUsageName = "DIGITAL_SIGNATURE" | "NON_REPUDIATION" | "KEY_ENCIPHERMENT" | "DATA_ENCIPHERMENT" | "KEY_AGREEMENT" | "CERTIFICATE_SIGNING" | "CRL_SIGNING" | "ENCIPHER_ONLY" | "DECIPHER_ONLY" | "ANY" | "CUSTOM" | (string & {});
export declare const KeyUsageName: any;
export interface KeyUsage {
    Name?: KeyUsageName;
}
export declare const KeyUsage: S.Schema<KeyUsage>;
export type KeyUsageList = KeyUsage[];
export declare const KeyUsageList: any;
export type ExtendedKeyUsageName = "TLS_WEB_SERVER_AUTHENTICATION" | "TLS_WEB_CLIENT_AUTHENTICATION" | "CODE_SIGNING" | "EMAIL_PROTECTION" | "TIME_STAMPING" | "OCSP_SIGNING" | "IPSEC_END_SYSTEM" | "IPSEC_TUNNEL" | "IPSEC_USER" | "ANY" | "NONE" | "CUSTOM" | (string & {});
export declare const ExtendedKeyUsageName: any;
export interface ExtendedKeyUsage {
    Name?: ExtendedKeyUsageName;
    OID?: string;
}
export declare const ExtendedKeyUsage: S.Schema<ExtendedKeyUsage>;
export type ExtendedKeyUsageList = ExtendedKeyUsage[];
export declare const ExtendedKeyUsageList: any;
export type RenewalEligibility = "ELIGIBLE" | "INELIGIBLE" | (string & {});
export declare const RenewalEligibility: any;
export type CertificateTransparencyLoggingPreference = "ENABLED" | "DISABLED" | (string & {});
export declare const CertificateTransparencyLoggingPreference: any;
export type CertificateExport = "ENABLED" | "DISABLED" | (string & {});
export declare const CertificateExport: any;
export interface CertificateOptions {
    CertificateTransparencyLoggingPreference?: CertificateTransparencyLoggingPreference;
    Export?: CertificateExport;
    ValidationMethod?: ValidationMethod;
}
export declare const CertificateOptions: S.Schema<CertificateOptions>;
export type UpdateStatus = "PENDING_DOMAIN_VALIDATION" | "SUCCESS" | "FAILED" | (string & {});
export declare const UpdateStatus: any;
export type UpdateType = "DOMAIN_VALIDATION_METHOD" | (string & {});
export declare const UpdateType: any;
export interface DomainValidationMethodUpdateSummary {
    From?: ValidationMethod;
    To?: ValidationMethod;
}
export declare const DomainValidationMethodUpdateSummary: S.Schema<DomainValidationMethodUpdateSummary>;
export interface UpdateSummary {
    Status?: UpdateStatus;
    Type?: UpdateType;
    DomainValidationMethodUpdateSummary?: DomainValidationMethodUpdateSummary;
    RequestedAt?: Date;
    UpdatedAt?: Date;
}
export declare const UpdateSummary: S.Schema<UpdateSummary>;
export type CertificateKeyPairOrigin = "AWS_MANAGED" | "ACME" | "CUSTOMER_PROVIDED" | (string & {});
export declare const CertificateKeyPairOrigin: any;
export type AcmeAccountId = string;
export interface CertificateDetail {
    CertificateArn?: string;
    DomainName?: string;
    SubjectAlternativeNames?: string[];
    ManagedBy?: CertificateManagedBy;
    DomainValidationOptions?: DomainValidation[];
    Serial?: string;
    Subject?: string;
    Issuer?: string;
    CreatedAt?: Date;
    IssuedAt?: Date;
    ImportedAt?: Date;
    Status?: CertificateStatus;
    RevokedAt?: Date;
    RevocationReason?: RevocationReason;
    NotBefore?: Date;
    NotAfter?: Date;
    KeyAlgorithm?: KeyAlgorithm;
    SignatureAlgorithm?: string;
    InUseBy?: string[];
    FailureReason?: FailureReason;
    Type?: CertificateType;
    RenewalSummary?: RenewalSummary;
    KeyUsages?: KeyUsage[];
    ExtendedKeyUsages?: ExtendedKeyUsage[];
    CertificateAuthorityArn?: string;
    RenewalEligibility?: RenewalEligibility;
    Options?: CertificateOptions;
    UpdateSummary?: UpdateSummary;
    CertificateKeyPairOrigin?: CertificateKeyPairOrigin;
    AcmeEndpointArn?: string;
    AcmeAccountId?: string;
}
export declare const CertificateDetail: S.Schema<CertificateDetail>;
export interface DescribeCertificateResponse {
    Certificate?: CertificateDetail;
}
export declare const DescribeCertificateResponse: S.Schema<DescribeCertificateResponse>;
export type PassphraseBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ExportCertificateRequest {
    CertificateArn: string;
    Passphrase: Uint8Array | redacted.Redacted<Uint8Array>;
}
export declare const ExportCertificateRequest: S.Schema<ExportCertificateRequest>;
export type CertificateBody = string;
export type CertificateChain = string;
export type PrivateKey = string | redacted.Redacted<string>;
export interface ExportCertificateResponse {
    Certificate?: string;
    CertificateChain?: string;
    PrivateKey?: string | redacted.Redacted<string>;
}
export declare const ExportCertificateResponse: S.Schema<ExportCertificateResponse>;
export interface GetAccountConfigurationRequest {
}
export declare const GetAccountConfigurationRequest: S.Schema<GetAccountConfigurationRequest>;
export type PositiveInteger = number;
export interface ExpiryEventsConfiguration {
    DaysBeforeExpiry?: number;
}
export declare const ExpiryEventsConfiguration: S.Schema<ExpiryEventsConfiguration>;
export interface GetAccountConfigurationResponse {
    ExpiryEvents?: ExpiryEventsConfiguration;
}
export declare const GetAccountConfigurationResponse: S.Schema<GetAccountConfigurationResponse>;
export interface GetAcmeExternalAccountBindingCredentialsRequest {
    AcmeExternalAccountBindingArn: string;
}
export declare const GetAcmeExternalAccountBindingCredentialsRequest: S.Schema<GetAcmeExternalAccountBindingCredentialsRequest>;
export type MacKey = string | redacted.Redacted<string>;
export interface GetAcmeExternalAccountBindingCredentialsResponse {
    KeyId?: string;
    MacKey?: string | redacted.Redacted<string>;
}
export declare const GetAcmeExternalAccountBindingCredentialsResponse: S.Schema<GetAcmeExternalAccountBindingCredentialsResponse>;
export interface GetCertificateRequest {
    CertificateArn: string;
}
export declare const GetCertificateRequest: S.Schema<GetCertificateRequest>;
export interface GetCertificateResponse {
    Certificate?: string;
    CertificateChain?: string;
}
export declare const GetCertificateResponse: S.Schema<GetCertificateResponse>;
export type CertificateBodyBlob = Uint8Array;
export type PrivateKeyBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export type CertificateChainBlob = Uint8Array;
export interface ImportCertificateRequest {
    CertificateArn?: string;
    Certificate: Uint8Array;
    PrivateKey: Uint8Array | redacted.Redacted<Uint8Array>;
    CertificateChain?: Uint8Array;
    Tags?: Tag[];
}
export declare const ImportCertificateRequest: S.Schema<ImportCertificateRequest>;
export interface ImportCertificateResponse {
    CertificateArn?: string;
}
export declare const ImportCertificateResponse: S.Schema<ImportCertificateResponse>;
export interface ListAcmeAccountsRequest {
    NextToken?: string;
    MaxResults?: number;
    AcmeEndpointArn: string;
}
export declare const ListAcmeAccountsRequest: S.Schema<ListAcmeAccountsRequest>;
export interface AcmeAccountSummary {
    AccountUrl?: string;
    PublicKeyThumbprint?: string;
    Status?: AcmeAccountStatus;
    CreatedAt?: Date;
    AcmeExternalAccountBindingArn?: string;
    Contacts?: string[];
}
export declare const AcmeAccountSummary: S.Schema<AcmeAccountSummary>;
export type AcmeAccountList = AcmeAccountSummary[];
export declare const AcmeAccountList: any;
export interface ListAcmeAccountsResponse {
    AcmeAccounts?: AcmeAccountSummary[];
    NextToken?: string;
}
export declare const ListAcmeAccountsResponse: S.Schema<ListAcmeAccountsResponse>;
export interface ListAcmeDomainValidationsRequest {
    NextToken?: string;
    MaxResults?: number;
    AcmeEndpointArn: string;
}
export declare const ListAcmeDomainValidationsRequest: S.Schema<ListAcmeDomainValidationsRequest>;
export interface AcmeDomainValidationSummary {
    AcmeDomainValidationArn?: string;
    AcmeEndpointArn?: string;
    DomainName?: string;
    PrevalidationType?: PrevalidationType;
    PrevalidationDetails?: PrevalidationDetails;
    Status?: AcmeDomainValidationStatus;
    FailureDetails?: FailureDetails;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const AcmeDomainValidationSummary: S.Schema<AcmeDomainValidationSummary>;
export type AcmeDomainValidationList = AcmeDomainValidationSummary[];
export declare const AcmeDomainValidationList: any;
export interface ListAcmeDomainValidationsResponse {
    AcmeDomainValidations?: AcmeDomainValidationSummary[];
    NextToken?: string;
}
export declare const ListAcmeDomainValidationsResponse: S.Schema<ListAcmeDomainValidationsResponse>;
export interface ListAcmeEndpointsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListAcmeEndpointsRequest: S.Schema<ListAcmeEndpointsRequest>;
export interface AcmeEndpointSummary {
    AcmeEndpointArn?: string;
    EndpointUrl?: string;
    Status?: AcmeEndpointStatus;
    FailureReason?: string;
    AuthorizationBehavior?: AcmeAuthorizationBehavior;
    Contact?: AcmeContact;
    CertificateAuthority?: CertificateAuthority;
    CertificateTags?: Tag[];
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const AcmeEndpointSummary: S.Schema<AcmeEndpointSummary>;
export type AcmeEndpointList = AcmeEndpointSummary[];
export declare const AcmeEndpointList: any;
export interface ListAcmeEndpointsResponse {
    AcmeEndpoints?: AcmeEndpointSummary[];
    NextToken?: string;
}
export declare const ListAcmeEndpointsResponse: S.Schema<ListAcmeEndpointsResponse>;
export interface ListAcmeExternalAccountBindingsRequest {
    NextToken?: string;
    MaxResults?: number;
    AcmeEndpointArn: string;
}
export declare const ListAcmeExternalAccountBindingsRequest: S.Schema<ListAcmeExternalAccountBindingsRequest>;
export interface AcmeExternalAccountBindingSummary {
    AcmeExternalAccountBindingArn?: string;
    AcmeEndpointArn?: string;
    RoleArn?: string;
    ExpiresAt?: Date;
    RevokedAt?: Date;
    LastUsedAt?: Date;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const AcmeExternalAccountBindingSummary: S.Schema<AcmeExternalAccountBindingSummary>;
export type AcmeExternalAccountBindingList = AcmeExternalAccountBindingSummary[];
export declare const AcmeExternalAccountBindingList: any;
export interface ListAcmeExternalAccountBindingsResponse {
    ExternalAccountBindings?: AcmeExternalAccountBindingSummary[];
    NextToken?: string;
}
export declare const ListAcmeExternalAccountBindingsResponse: S.Schema<ListAcmeExternalAccountBindingsResponse>;
export type CertificateArn = string;
export type NextToken = string;
export type MaxItems = number;
export interface ListCertificateDomainValidationsRequest {
    CertificateArn: string;
    NextToken?: string;
    MaxItems?: number;
}
export declare const ListCertificateDomainValidationsRequest: S.Schema<ListCertificateDomainValidationsRequest>;
export interface EmailValidationChallenge {
    ValidationEmails?: string[];
    ValidationDomain?: string;
}
export declare const EmailValidationChallenge: S.Schema<EmailValidationChallenge>;
export interface DnsValidationChallenge {
    ResourceRecord?: ResourceRecord;
}
export declare const DnsValidationChallenge: S.Schema<DnsValidationChallenge>;
export type ValidationChallenge = {
    EmailValidationChallenge: EmailValidationChallenge;
    DnsValidationChallenge?: never;
} | {
    EmailValidationChallenge?: never;
    DnsValidationChallenge: DnsValidationChallenge;
};
export declare const ValidationChallenge: any;
export interface ValidationConfiguration {
    ValidationMethod?: ValidationMethod;
    ValidationChallenge?: ValidationChallenge;
    ValidationStatus?: DomainStatus;
}
export declare const ValidationConfiguration: S.Schema<ValidationConfiguration>;
export interface DomainValidationSummary {
    DomainName: string;
    ActiveValidationConfiguration?: ValidationConfiguration;
    RequestedValidationConfiguration?: ValidationConfiguration;
}
export declare const DomainValidationSummary: S.Schema<DomainValidationSummary>;
export type DomainValidationSummaryList = DomainValidationSummary[];
export declare const DomainValidationSummaryList: any;
export interface ListCertificateDomainValidationsResponse {
    DomainValidationSummaryList?: DomainValidationSummary[];
    NextToken?: string;
}
export declare const ListCertificateDomainValidationsResponse: S.Schema<ListCertificateDomainValidationsResponse>;
export type CertificateStatuses = CertificateStatus[];
export declare const CertificateStatuses: any;
export type CertificateKeyPairOrigins = CertificateKeyPairOrigin[];
export declare const CertificateKeyPairOrigins: any;
export type ExtendedKeyUsageFilterList = ExtendedKeyUsageName[];
export declare const ExtendedKeyUsageFilterList: any;
export type KeyUsageFilterList = KeyUsageName[];
export declare const KeyUsageFilterList: any;
export type KeyAlgorithmList = KeyAlgorithm[];
export declare const KeyAlgorithmList: any;
export interface Filters {
    extendedKeyUsage?: ExtendedKeyUsageName[];
    keyUsage?: KeyUsageName[];
    keyTypes?: KeyAlgorithm[];
    exportOption?: CertificateExport;
    managedBy?: CertificateManagedBy;
}
export declare const Filters: S.Schema<Filters>;
export type SortBy = "CREATED_AT" | (string & {});
export declare const SortBy: any;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SortOrder: any;
export interface ListCertificatesRequest {
    CertificateStatuses?: CertificateStatus[];
    CertificateKeyPairOrigins?: CertificateKeyPairOrigin[];
    Includes?: Filters;
    NextToken?: string;
    MaxItems?: number;
    SortBy?: SortBy;
    SortOrder?: SortOrder;
}
export declare const ListCertificatesRequest: S.Schema<ListCertificatesRequest>;
export type KeyUsageNames = KeyUsageName[];
export declare const KeyUsageNames: any;
export type ExtendedKeyUsageNames = ExtendedKeyUsageName[];
export declare const ExtendedKeyUsageNames: any;
export interface CertificateSummary {
    CertificateArn?: string;
    DomainName?: string;
    SubjectAlternativeNameSummaries?: string[];
    HasAdditionalSubjectAlternativeNames?: boolean;
    Status?: CertificateStatus;
    Type?: CertificateType;
    KeyAlgorithm?: KeyAlgorithm;
    KeyUsages?: KeyUsageName[];
    ExtendedKeyUsages?: ExtendedKeyUsageName[];
    ExportOption?: CertificateExport;
    InUse?: boolean;
    Exported?: boolean;
    RenewalEligibility?: RenewalEligibility;
    NotBefore?: Date;
    NotAfter?: Date;
    CreatedAt?: Date;
    IssuedAt?: Date;
    ImportedAt?: Date;
    RevokedAt?: Date;
    ManagedBy?: CertificateManagedBy;
    CertificateKeyPairOrigin?: CertificateKeyPairOrigin;
}
export declare const CertificateSummary: S.Schema<CertificateSummary>;
export type CertificateSummaryList = CertificateSummary[];
export declare const CertificateSummaryList: any;
export interface ListCertificatesResponse {
    NextToken?: string;
    CertificateSummaryList?: CertificateSummary[];
}
export declare const ListCertificatesResponse: S.Schema<ListCertificatesResponse>;
export interface ListTagsForCertificateRequest {
    CertificateArn: string;
}
export declare const ListTagsForCertificateRequest: S.Schema<ListTagsForCertificateRequest>;
export interface ListTagsForCertificateResponse {
    Tags?: Tag[];
}
export declare const ListTagsForCertificateResponse: S.Schema<ListTagsForCertificateResponse>;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type IdempotencyToken = string;
export interface PutAccountConfigurationRequest {
    ExpiryEvents?: ExpiryEventsConfiguration;
    IdempotencyToken: string;
}
export declare const PutAccountConfigurationRequest: S.Schema<PutAccountConfigurationRequest>;
export interface PutAccountConfigurationResponse {
}
export declare const PutAccountConfigurationResponse: S.Schema<PutAccountConfigurationResponse>;
export interface RemoveTagsFromCertificateRequest {
    CertificateArn: string;
    Tags: Tag[];
}
export declare const RemoveTagsFromCertificateRequest: S.Schema<RemoveTagsFromCertificateRequest>;
export interface RemoveTagsFromCertificateResponse {
}
export declare const RemoveTagsFromCertificateResponse: S.Schema<RemoveTagsFromCertificateResponse>;
export interface RenewCertificateRequest {
    CertificateArn: string;
}
export declare const RenewCertificateRequest: S.Schema<RenewCertificateRequest>;
export interface RenewCertificateResponse {
}
export declare const RenewCertificateResponse: S.Schema<RenewCertificateResponse>;
export interface DomainValidationOption {
    DomainName: string;
    ValidationDomain: string;
}
export declare const DomainValidationOption: S.Schema<DomainValidationOption>;
export type DomainValidationOptionList = DomainValidationOption[];
export declare const DomainValidationOptionList: any;
export type PcaArn = string;
export interface RequestCertificateRequest {
    DomainName: string;
    ValidationMethod?: ValidationMethod;
    SubjectAlternativeNames?: string[];
    IdempotencyToken?: string;
    DomainValidationOptions?: DomainValidationOption[];
    Options?: CertificateOptions;
    CertificateAuthorityArn?: string;
    Tags?: Tag[];
    KeyAlgorithm?: KeyAlgorithm;
    ManagedBy?: CertificateManagedBy;
}
export declare const RequestCertificateRequest: S.Schema<RequestCertificateRequest>;
export interface RequestCertificateResponse {
    CertificateArn?: string;
}
export declare const RequestCertificateResponse: S.Schema<RequestCertificateResponse>;
export interface ResendValidationEmailRequest {
    CertificateArn: string;
    Domain: string;
    ValidationDomain: string;
}
export declare const ResendValidationEmailRequest: S.Schema<ResendValidationEmailRequest>;
export interface ResendValidationEmailResponse {
}
export declare const ResendValidationEmailResponse: S.Schema<ResendValidationEmailResponse>;
export interface RevokeAcmeAccountRequest {
    AcmeEndpointArn: string;
    AccountUrl: string;
}
export declare const RevokeAcmeAccountRequest: S.Schema<RevokeAcmeAccountRequest>;
export interface RevokeAcmeAccountResponse {
}
export declare const RevokeAcmeAccountResponse: S.Schema<RevokeAcmeAccountResponse>;
export interface RevokeAcmeExternalAccountBindingRequest {
    AcmeExternalAccountBindingArn: string;
}
export declare const RevokeAcmeExternalAccountBindingRequest: S.Schema<RevokeAcmeExternalAccountBindingRequest>;
export interface RevokeAcmeExternalAccountBindingResponse {
}
export declare const RevokeAcmeExternalAccountBindingResponse: S.Schema<RevokeAcmeExternalAccountBindingResponse>;
export interface RevokeCertificateRequest {
    CertificateArn: string;
    RevocationReason: RevocationReason;
}
export declare const RevokeCertificateRequest: S.Schema<RevokeCertificateRequest>;
export interface RevokeCertificateResponse {
    CertificateArn?: string;
}
export declare const RevokeCertificateResponse: S.Schema<RevokeCertificateResponse>;
export type CertificateFilterStatementList = CertificateFilterStatement[];
export declare const CertificateFilterStatementList: S.Schema<CertificateFilterStatementList>;
export type FilterString = string;
export type ComparisonOperator = "CONTAINS" | "EQUALS" | (string & {});
export declare const ComparisonOperator: any;
export interface CommonNameFilter {
    Value: string;
    ComparisonOperator: ComparisonOperator;
}
export declare const CommonNameFilter: S.Schema<CommonNameFilter>;
export type SubjectFilter = {
    CommonName: CommonNameFilter;
};
export declare const SubjectFilter: any;
export interface DnsNameFilter {
    Value: string;
    ComparisonOperator: ComparisonOperator;
}
export declare const DnsNameFilter: S.Schema<DnsNameFilter>;
export type SubjectAlternativeNameFilter = {
    DnsName: DnsNameFilter;
};
export declare const SubjectAlternativeNameFilter: any;
export type SerialNumber = string;
export interface TimestampRange {
    Start?: Date;
    End?: Date;
}
export declare const TimestampRange: S.Schema<TimestampRange>;
export type X509AttributeFilter = {
    Subject: SubjectFilter;
    SubjectAlternativeName?: never;
    ExtendedKeyUsage?: never;
    KeyUsage?: never;
    KeyAlgorithm?: never;
    SerialNumber?: never;
    NotAfter?: never;
    NotBefore?: never;
} | {
    Subject?: never;
    SubjectAlternativeName: SubjectAlternativeNameFilter;
    ExtendedKeyUsage?: never;
    KeyUsage?: never;
    KeyAlgorithm?: never;
    SerialNumber?: never;
    NotAfter?: never;
    NotBefore?: never;
} | {
    Subject?: never;
    SubjectAlternativeName?: never;
    ExtendedKeyUsage: ExtendedKeyUsageName;
    KeyUsage?: never;
    KeyAlgorithm?: never;
    SerialNumber?: never;
    NotAfter?: never;
    NotBefore?: never;
} | {
    Subject?: never;
    SubjectAlternativeName?: never;
    ExtendedKeyUsage?: never;
    KeyUsage: KeyUsageName;
    KeyAlgorithm?: never;
    SerialNumber?: never;
    NotAfter?: never;
    NotBefore?: never;
} | {
    Subject?: never;
    SubjectAlternativeName?: never;
    ExtendedKeyUsage?: never;
    KeyUsage?: never;
    KeyAlgorithm: KeyAlgorithm;
    SerialNumber?: never;
    NotAfter?: never;
    NotBefore?: never;
} | {
    Subject?: never;
    SubjectAlternativeName?: never;
    ExtendedKeyUsage?: never;
    KeyUsage?: never;
    KeyAlgorithm?: never;
    SerialNumber: string;
    NotAfter?: never;
    NotBefore?: never;
} | {
    Subject?: never;
    SubjectAlternativeName?: never;
    ExtendedKeyUsage?: never;
    KeyUsage?: never;
    KeyAlgorithm?: never;
    SerialNumber?: never;
    NotAfter: TimestampRange;
    NotBefore?: never;
} | {
    Subject?: never;
    SubjectAlternativeName?: never;
    ExtendedKeyUsage?: never;
    KeyUsage?: never;
    KeyAlgorithm?: never;
    SerialNumber?: never;
    NotAfter?: never;
    NotBefore: TimestampRange;
};
export declare const X509AttributeFilter: any;
export type AcmCertificateMetadataFilter = {
    Status: CertificateStatus;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus: RenewalStatus;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type: CertificateType;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse: boolean;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported: boolean;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption: CertificateExport;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy: CertificateManagedBy;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod: ValidationMethod;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin: CertificateKeyPairOrigin;
    AcmeEndpointArn?: never;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn: string;
    AcmeAccountId?: never;
} | {
    Status?: never;
    RenewalStatus?: never;
    Type?: never;
    InUse?: never;
    Exported?: never;
    ExportOption?: never;
    ManagedBy?: never;
    ValidationMethod?: never;
    CertificateKeyPairOrigin?: never;
    AcmeEndpointArn?: never;
    AcmeAccountId: string;
};
export declare const AcmCertificateMetadataFilter: any;
export type CertificateFilter = {
    CertificateArn: string;
    X509AttributeFilter?: never;
    AcmCertificateMetadataFilter?: never;
} | {
    CertificateArn?: never;
    X509AttributeFilter: X509AttributeFilter;
    AcmCertificateMetadataFilter?: never;
} | {
    CertificateArn?: never;
    X509AttributeFilter?: never;
    AcmCertificateMetadataFilter: AcmCertificateMetadataFilter;
};
export declare const CertificateFilter: any;
export type CertificateFilterStatement = {
    And: CertificateFilterStatement[];
    Or?: never;
    Not?: never;
    Filter?: never;
} | {
    And?: never;
    Or: CertificateFilterStatement[];
    Not?: never;
    Filter?: never;
} | {
    And?: never;
    Or?: never;
    Not: CertificateFilterStatement;
    Filter?: never;
} | {
    And?: never;
    Or?: never;
    Not?: never;
    Filter: CertificateFilter;
};
export declare const CertificateFilterStatement: S.Schema<CertificateFilterStatement>;
export type SearchMaxResults = number;
export type SearchCertificatesSortBy = "CREATED_AT" | "NOT_AFTER" | "STATUS" | "RENEWAL_STATUS" | "EXPORTED" | "IN_USE" | "NOT_BEFORE" | "KEY_ALGORITHM" | "TYPE" | "CERTIFICATE_ARN" | "COMMON_NAME" | "REVOKED_AT" | "RENEWAL_ELIGIBILITY" | "ISSUED_AT" | "MANAGED_BY" | "EXPORT_OPTION" | "VALIDATION_METHOD" | "IMPORTED_AT" | "ACME_ENDPOINT_ARN" | "ACME_ACCOUNT_ID" | "CERTIFICATE_KEY_PAIR_ORIGIN" | (string & {});
export declare const SearchCertificatesSortBy: any;
export type SearchCertificatesSortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SearchCertificatesSortOrder: any;
export interface SearchCertificatesRequest {
    FilterStatement?: CertificateFilterStatement;
    MaxResults?: number;
    NextToken?: string;
    SortBy?: SearchCertificatesSortBy;
    SortOrder?: SearchCertificatesSortOrder;
}
export declare const SearchCertificatesRequest: S.Schema<SearchCertificatesRequest>;
export type DomainComponentList = string[];
export declare const DomainComponentList: any;
export interface CustomAttribute {
    ObjectIdentifier?: string;
    Value?: string;
}
export declare const CustomAttribute: S.Schema<CustomAttribute>;
export type CustomAttributeList = CustomAttribute[];
export declare const CustomAttributeList: any;
export interface DistinguishedName {
    CommonName?: string;
    DomainComponents?: string[];
    Country?: string;
    CustomAttributes?: CustomAttribute[];
    DistinguishedNameQualifier?: string;
    GenerationQualifier?: string;
    GivenName?: string;
    Initials?: string;
    Locality?: string;
    Organization?: string;
    OrganizationalUnit?: string;
    Pseudonym?: string;
    SerialNumber?: string;
    State?: string;
    Surname?: string;
    Title?: string;
}
export declare const DistinguishedName: S.Schema<DistinguishedName>;
export interface OtherName {
    ObjectIdentifier?: string;
    Value?: string;
}
export declare const OtherName: S.Schema<OtherName>;
export type GeneralName = {
    DirectoryName: DistinguishedName;
    DnsName?: never;
    IpAddress?: never;
    OtherName?: never;
    RegisteredId?: never;
    Rfc822Name?: never;
    UniformResourceIdentifier?: never;
} | {
    DirectoryName?: never;
    DnsName: string;
    IpAddress?: never;
    OtherName?: never;
    RegisteredId?: never;
    Rfc822Name?: never;
    UniformResourceIdentifier?: never;
} | {
    DirectoryName?: never;
    DnsName?: never;
    IpAddress: string;
    OtherName?: never;
    RegisteredId?: never;
    Rfc822Name?: never;
    UniformResourceIdentifier?: never;
} | {
    DirectoryName?: never;
    DnsName?: never;
    IpAddress?: never;
    OtherName: OtherName;
    RegisteredId?: never;
    Rfc822Name?: never;
    UniformResourceIdentifier?: never;
} | {
    DirectoryName?: never;
    DnsName?: never;
    IpAddress?: never;
    OtherName?: never;
    RegisteredId: string;
    Rfc822Name?: never;
    UniformResourceIdentifier?: never;
} | {
    DirectoryName?: never;
    DnsName?: never;
    IpAddress?: never;
    OtherName?: never;
    RegisteredId?: never;
    Rfc822Name: string;
    UniformResourceIdentifier?: never;
} | {
    DirectoryName?: never;
    DnsName?: never;
    IpAddress?: never;
    OtherName?: never;
    RegisteredId?: never;
    Rfc822Name?: never;
    UniformResourceIdentifier: string;
};
export declare const GeneralName: any;
export type GeneralNameList = GeneralName[];
export declare const GeneralNameList: any;
export interface X509Attributes {
    Issuer?: DistinguishedName;
    Subject?: DistinguishedName;
    SubjectAlternativeNames?: GeneralName[];
    ExtendedKeyUsages?: ExtendedKeyUsageName[];
    KeyAlgorithm?: KeyAlgorithm;
    KeyUsages?: KeyUsageName[];
    SerialNumber?: string;
    NotAfter?: Date;
    NotBefore?: Date;
}
export declare const X509Attributes: S.Schema<X509Attributes>;
export interface AcmCertificateMetadata {
    CreatedAt?: Date;
    Exported?: boolean;
    ImportedAt?: Date;
    InUse?: boolean;
    IssuedAt?: Date;
    RenewalEligibility?: RenewalEligibility;
    RevokedAt?: Date;
    Status?: CertificateStatus;
    RenewalStatus?: RenewalStatus;
    Type?: CertificateType;
    ExportOption?: CertificateExport;
    ManagedBy?: CertificateManagedBy;
    ValidationMethod?: ValidationMethod;
    CertificateKeyPairOrigin?: CertificateKeyPairOrigin;
    AcmeEndpointArn?: string;
    AcmeAccountId?: string;
}
export declare const AcmCertificateMetadata: S.Schema<AcmCertificateMetadata>;
export type CertificateMetadata = {
    AcmCertificateMetadata: AcmCertificateMetadata;
};
export declare const CertificateMetadata: any;
export interface CertificateSearchResult {
    CertificateArn?: string;
    X509Attributes?: X509Attributes;
    CertificateMetadata?: CertificateMetadata;
}
export declare const CertificateSearchResult: S.Schema<CertificateSearchResult>;
export type CertificateSearchResultList = CertificateSearchResult[];
export declare const CertificateSearchResultList: any;
export interface SearchCertificatesResponse {
    Results?: CertificateSearchResult[];
    NextToken?: string;
}
export declare const SearchCertificatesResponse: S.Schema<SearchCertificatesResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAcmeDomainValidationRequest {
    AcmeDomainValidationArn: string;
    PrevalidationOptions?: PrevalidationOptions;
}
export declare const UpdateAcmeDomainValidationRequest: S.Schema<UpdateAcmeDomainValidationRequest>;
export interface UpdateAcmeDomainValidationResponse {
}
export declare const UpdateAcmeDomainValidationResponse: S.Schema<UpdateAcmeDomainValidationResponse>;
export interface UpdateAcmeEndpointRequest {
    AcmeEndpointArn: string;
    AuthorizationBehavior?: AcmeAuthorizationBehavior;
    Contact?: AcmeContact;
    CertificateAuthority?: CertificateAuthority;
}
export declare const UpdateAcmeEndpointRequest: S.Schema<UpdateAcmeEndpointRequest>;
export interface UpdateAcmeEndpointResponse {
}
export declare const UpdateAcmeEndpointResponse: S.Schema<UpdateAcmeEndpointResponse>;
export interface UpdateCertificateOptionsRequest {
    CertificateArn: string;
    Options: CertificateOptions;
}
export declare const UpdateCertificateOptionsRequest: S.Schema<UpdateCertificateOptionsRequest>;
export interface UpdateCertificateOptionsResponse {
}
export declare const UpdateCertificateOptionsResponse: S.Schema<UpdateCertificateOptionsResponse>;
export type AvailabilityErrorMessage = string;
export type CoralAvailabilityThrottlingReason = string;
export type CoralAvailabilityThrottledResource = string;
export interface ThrottlingReason {
    reason?: string;
    resource?: string;
}
export declare const ThrottlingReason: S.Schema<ThrottlingReason>;
export type ThrottlingReasonList = ThrottlingReason[];
export declare const ThrottlingReasonList: any;
export type ValidationExceptionMessage = string;
export type ServiceErrorMessage = string;
export type AddTagsToCertificateError = InvalidArnException | InvalidParameterException | InvalidTagException | ResourceNotFoundException | TagPolicyException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to an ACM certificate. Tags are labels that you can use to identify and organize your Amazon Web Services resources. Each tag consists of a `key` and an optional `value`. You specify the certificate on input by its Amazon Resource Name (ARN). You specify the tag by using a key-value pair.
 *
 * This action applies only to the `certificate` resource type. For all other ACM resource types, use TagResource instead.
 *
 * You can apply a tag to just one certificate if you want to identify a specific characteristic of that certificate, or you can apply the same tag to multiple certificates if you want to filter for a common relationship among those certificates. Similarly, you can apply the same tag to multiple resources if you want to specify a relationship among those resources. For example, you can add the same tag to an ACM certificate and an Elastic Load Balancing load balancer to indicate that they are both used by the same website. For more information, see Tagging ACM certificates.
 *
 * To remove one or more tags, use the RemoveTagsFromCertificate action. To view all of the tags that have been applied to the certificate, use the ListTagsForCertificate action.
 */
export declare const addTagsToCertificate: API.OperationMethod<AddTagsToCertificateRequest, AddTagsToCertificateResponse, AddTagsToCertificateError, Credentials | HttpClient.HttpClient>;
export type CreateAcmeDomainValidationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain validation for an ACME endpoint. Domain validations authorize the endpoint to issue certificates for specified domain names. You configure prevalidation to prove domain ownership.
 */
export declare const createAcmeDomainValidation: API.OperationMethod<CreateAcmeDomainValidationRequest, CreateAcmeDomainValidationResponse, CreateAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type CreateAcmeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ACME endpoint, which is a managed ACME server with a unique endpoint URL. After creation, ACME clients can use the endpoint URL to automate certificate issuance using the ACME protocol.
 */
export declare const createAcmeEndpoint: API.OperationMethod<CreateAcmeEndpointRequest, CreateAcmeEndpointResponse, CreateAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateAcmeExternalAccountBindingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an external account binding (EAB) for an ACME endpoint. An EAB provides credentials that authorize an ACME client to register an account with the endpoint. Each EAB is associated with an IAM role that controls what certificate operations the ACME client can perform.
 */
export declare const createAcmeExternalAccountBinding: API.OperationMethod<CreateAcmeExternalAccountBindingRequest, CreateAcmeExternalAccountBindingResponse, CreateAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type DeleteAcmeDomainValidationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a domain validation. After deletion, the ACME endpoint can no longer issue certificates for the associated domain.
 */
export declare const deleteAcmeDomainValidation: API.OperationMethod<DeleteAcmeDomainValidationRequest, DeleteAcmeDomainValidationResponse, DeleteAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type DeleteAcmeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ACME endpoint. After deletion, the endpoint URL is no longer accessible and ACME clients cannot issue certificates through it. Any existing external account bindings and domain validations associated with the endpoint are also deleted.
 */
export declare const deleteAcmeEndpoint: API.OperationMethod<DeleteAcmeEndpointRequest, DeleteAcmeEndpointResponse, DeleteAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteAcmeExternalAccountBindingError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an external account binding. Previously fetched credentials for this binding will no longer be usable for account registration. A deleted binding cannot be recovered.
 */
export declare const deleteAcmeExternalAccountBinding: API.OperationMethod<DeleteAcmeExternalAccountBindingRequest, DeleteAcmeExternalAccountBindingResponse, DeleteAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateError = AccessDeniedException | ConflictException | InvalidArnException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a certificate and its associated private key. If this action succeeds, the certificate is not available for use by Amazon Web Services services integrated with ACM. Deleting a certificate is eventually consistent. The may be a short delay before the certificate no longer appears in the list that can be displayed by calling the ListCertificates action or be retrieved by calling the GetCertificate action.
 *
 * You cannot delete an ACM certificate that is being used by another Amazon Web Services service. To delete a certificate that is in use, you must first remove the certificate association using the console or the CLI for the associated service.
 *
 * Deleting a certificate issued by a private certificate authority (CA) has no effect on the CA. You will continue to be charged for the CA until it is deleted. For more information, see Deleting Your Private CA in the *Private Certificate Authority User Guide*.
 *
 * You cannot delete a certificate with a `CertificateKeyPairOrigin` of `ACME`. ACM automatically deletes these certificates 1 year after they expire.
 *
 * Deleting a certificate issued by a private certificate authority (CA) has no effect on the CA. You will continue to be charged for the CA until it is deleted. For more information, see Deleting your private CA in the *Amazon Web Services Private Certificate Authority User Guide*.
 */
export declare const deleteCertificate: API.OperationMethod<DeleteCertificateRequest, DeleteCertificateResponse, DeleteCertificateError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeAccountError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified ACME account, including its status, public key thumbprint, and associated external account binding.
 */
export declare const describeAcmeAccount: API.OperationMethod<DescribeAcmeAccountRequest, DescribeAcmeAccountResponse, DescribeAcmeAccountError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeDomainValidationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified domain validation, including its status, domain scope, and DNS resource records required for validation.
 */
export declare const describeAcmeDomainValidation: API.OperationMethod<DescribeAcmeDomainValidationRequest, DescribeAcmeDomainValidationResponse, DescribeAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified ACME endpoint, including its status, URL, authorization behavior, and certificate authority configuration.
 */
export declare const describeAcmeEndpoint: API.OperationMethod<DescribeAcmeEndpointRequest, DescribeAcmeEndpointResponse, DescribeAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeAcmeExternalAccountBindingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified external account binding, including the associated IAM role, expiration time, and usage history.
 */
export declare const describeAcmeExternalAccountBinding: API.OperationMethod<DescribeAcmeExternalAccountBindingRequest, DescribeAcmeExternalAccountBindingResponse, DescribeAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificateError = InvalidArnException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns detailed metadata about the specified ACM certificate.
 *
 * If you have just created a certificate using the `RequestCertificate` action, there is a delay of several seconds before you can retrieve information about it.
 */
export declare const describeCertificate: API.OperationMethod<DescribeCertificateRequest, DescribeCertificateResponse, DescribeCertificateError, Credentials | HttpClient.HttpClient>;
export type ExportCertificateError = InvalidArnException | RequestInProgressException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Exports a private certificate issued by a private certificate authority (CA) or a public certificate for use anywhere. The exported file contains the certificate, the certificate chain, and the encrypted private key associated with the public key that is embedded in the certificate. For security, you must assign a passphrase for the private key when exporting it.
 *
 * For information about exporting and formatting a certificate using the ACM console or CLI, see Export a private certificate and Export a public certificate.
 *
 * ACM public certificates created prior to June 17, 2025 cannot be exported.
 */
export declare const exportCertificate: API.OperationMethod<ExportCertificateRequest, ExportCertificateResponse, ExportCertificateError, Credentials | HttpClient.HttpClient>;
export type GetAccountConfigurationError = AccessDeniedException | ThrottlingException | CommonErrors;
/**
 * Returns the account configuration options associated with an Amazon Web Services account.
 */
export declare const getAccountConfiguration: API.OperationMethod<GetAccountConfigurationRequest, GetAccountConfigurationResponse, GetAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAcmeExternalAccountBindingCredentialsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the key ID and MAC key credentials for an external account binding. These credentials are used by ACME clients during account registration to bind to the endpoint.
 */
export declare const getAcmeExternalAccountBindingCredentials: API.OperationMethod<GetAcmeExternalAccountBindingCredentialsRequest, GetAcmeExternalAccountBindingCredentialsResponse, GetAcmeExternalAccountBindingCredentialsError, Credentials | HttpClient.HttpClient>;
export type GetCertificateError = InvalidArnException | RequestInProgressException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a certificate and its certificate chain. The certificate may be either a public or private certificate issued using the ACM `RequestCertificate` action, or a certificate imported into ACM using the `ImportCertificate` action. The chain consists of the certificate of the issuing CA and the intermediate certificates of any other subordinate CAs. All of the certificates are base64 encoded. You can use OpenSSL to decode the certificates and inspect individual fields.
 */
export declare const getCertificate: API.OperationMethod<GetCertificateRequest, GetCertificateResponse, GetCertificateError, Credentials | HttpClient.HttpClient>;
export type ImportCertificateError = ConflictException | InvalidArnException | InvalidParameterException | InvalidTagException | LimitExceededException | ResourceNotFoundException | TagPolicyException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Imports a certificate into Certificate Manager (ACM) to use with services that are integrated with ACM. Note that integrated services allow only certificate types and keys they support to be associated with their resources. Further, their support differs depending on whether the certificate is imported into IAM or into ACM. For more information, see the documentation for each service. For more information about importing certificates into ACM, see Importing Certificates in the *Certificate Manager User Guide*.
 *
 * ACM does not provide managed renewal for certificates that you import.
 *
 * Note the following guidelines when importing third party certificates:
 *
 * - You must enter the private key that matches the certificate you are importing.
 *
 * - The private key must be unencrypted. You cannot import a private key that is protected by a password or a passphrase.
 *
 * - The private key must be no larger than 5 KB (5,120 bytes).
 *
 * - The certificate, private key, and certificate chain must be PEM-encoded.
 *
 * - The current time must be between the `Not Before` and `Not After` certificate fields.
 *
 * - The `Issuer` field must not be empty.
 *
 * - The OCSP authority URL, if present, must not exceed 1000 characters.
 *
 * - To import a new certificate, omit the `CertificateArn` argument. Include this argument only when you want to replace a previously imported certificate.
 *
 * - When you import a certificate by using the CLI, you must specify the certificate, the certificate chain, and the private key by their file names preceded by `fileb://`. For example, you can specify a certificate saved in the `C:\temp` folder as `fileb://C:\temp\certificate_to_import.pem`. If you are making an HTTP or HTTPS Query request, include these arguments as BLOBs.
 *
 * - When you import a certificate by using an SDK, you must specify the certificate, the certificate chain, and the private key files in the manner required by the programming language you're using.
 *
 * - The cryptographic algorithm of an imported certificate must match the algorithm of the signing CA. For example, if the signing CA key type is RSA, then the certificate key type must also be RSA.
 *
 * This operation returns the Amazon Resource Name (ARN) of the imported certificate.
 */
export declare const importCertificate: API.OperationMethod<ImportCertificateRequest, ImportCertificateResponse, ImportCertificateError, Credentials | HttpClient.HttpClient>;
export type ListAcmeAccountsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of ACME accounts registered with the specified ACME endpoint. ACME accounts are created when clients use external account binding credentials to register.
 */
export declare const listAcmeAccounts: API.PaginatedOperationMethod<ListAcmeAccountsRequest, ListAcmeAccountsResponse, ListAcmeAccountsError, Credentials | HttpClient.HttpClient, AcmeAccountSummary>;
export type ListAcmeDomainValidationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of domain validations for the specified ACME endpoint.
 */
export declare const listAcmeDomainValidations: API.PaginatedOperationMethod<ListAcmeDomainValidationsRequest, ListAcmeDomainValidationsResponse, ListAcmeDomainValidationsError, Credentials | HttpClient.HttpClient, AcmeDomainValidationSummary>;
export type ListAcmeEndpointsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of ACME endpoints in your account. Use this operation to view all configured ACME endpoints and their current status.
 */
export declare const listAcmeEndpoints: API.PaginatedOperationMethod<ListAcmeEndpointsRequest, ListAcmeEndpointsResponse, ListAcmeEndpointsError, Credentials | HttpClient.HttpClient, AcmeEndpointSummary>;
export type ListAcmeExternalAccountBindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of external account bindings for the specified ACME endpoint.
 */
export declare const listAcmeExternalAccountBindings: API.PaginatedOperationMethod<ListAcmeExternalAccountBindingsRequest, ListAcmeExternalAccountBindingsResponse, ListAcmeExternalAccountBindingsError, Credentials | HttpClient.HttpClient, AcmeExternalAccountBindingSummary>;
export type ListCertificateDomainValidationsError = AccessDeniedException | InvalidArgsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns per-domain validation summaries for an ACM certificate. Each summary includes the domain name, the active validation configuration, and the requested validation configuration when a validation method migration is in progress. You can use the results to monitor the progress of an email-to-DNS validation migration and to retrieve the CNAME records required for DNS validation.
 */
export declare const listCertificateDomainValidations: API.PaginatedOperationMethod<ListCertificateDomainValidationsRequest, ListCertificateDomainValidationsResponse, ListCertificateDomainValidationsError, Credentials | HttpClient.HttpClient, DomainValidationSummary>;
export type ListCertificatesError = InvalidArgsException | ValidationException | CommonErrors;
/**
 * Retrieves a list of certificate ARNs and domain names. You can request that only certificates that match a specific status be listed. You can also filter by specific attributes of the certificate. Default filtering returns only `RSA_2048` certificates. For more information, see Filters.
 *
 * By default, this action does not return certificates with a `CertificateKeyPairOrigin` of `ACME`. To include ACME certificates, specify `ACME` in the `CertificateKeyPairOrigins` filter.
 */
export declare const listCertificates: API.PaginatedOperationMethod<ListCertificatesRequest, ListCertificatesResponse, ListCertificatesError, Credentials | HttpClient.HttpClient, CertificateSummary>;
export type ListTagsForCertificateError = InvalidArnException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags that have been applied to the ACM certificate. Use the certificate's Amazon Resource Name (ARN) to specify the certificate. To add a tag to an ACM certificate, use the AddTagsToCertificate action. To delete a tag, use the RemoveTagsFromCertificate action.
 *
 * This action applies only to the `certificate` resource type. For all other ACM resource types, use ListTagsForResource instead.
 */
export declare const listTagsForCertificate: API.OperationMethod<ListTagsForCertificateRequest, ListTagsForCertificateResponse, ListTagsForCertificateError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with an ACM resource.
 *
 * Use this action for all ACM resource types except the `certificate` resource type. For certificate resources, use ListTagsForCertificate instead.
 *
 * To add one or more tags, use the TagResource action. To remove one or more tags, use the UntagResource action.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountConfigurationError = AccessDeniedException | ConflictException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or modifies account-level configurations in ACM.
 *
 * The supported configuration option is `DaysBeforeExpiry`. This option specifies the number of days prior to certificate expiration when ACM starts generating `EventBridge` events. ACM sends one event per day per certificate until the certificate expires. By default, accounts receive events starting 45 days before certificate expiration.
 */
export declare const putAccountConfiguration: API.OperationMethod<PutAccountConfigurationRequest, PutAccountConfigurationResponse, PutAccountConfigurationError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromCertificateError = InvalidArnException | InvalidParameterException | InvalidTagException | ResourceNotFoundException | TagPolicyException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove one or more tags from an ACM certificate. A tag consists of a key-value pair. If you do not specify the value portion of the tag when calling this function, the tag will be removed regardless of value. If you specify a value, the tag is removed only if it is associated with the specified value.
 *
 * This action applies only to the `certificate` resource type. For all other ACM resource types, use UntagResource instead.
 *
 * To add tags to a certificate, use the AddTagsToCertificate action. To view all of the tags that have been applied to a specific ACM certificate, use the ListTagsForCertificate action.
 */
export declare const removeTagsFromCertificate: API.OperationMethod<RemoveTagsFromCertificateRequest, RemoveTagsFromCertificateResponse, RemoveTagsFromCertificateError, Credentials | HttpClient.HttpClient>;
export type RenewCertificateError = InvalidArnException | RequestInProgressException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Renews an eligible ACM certificate. In order to renew your Amazon Web Services Private CA certificates with ACM, you must first grant the ACM service principal permission to do so. For more information, see Testing Managed Renewal in the ACM User Guide.
 */
export declare const renewCertificate: API.OperationMethod<RenewCertificateRequest, RenewCertificateResponse, RenewCertificateError, Credentials | HttpClient.HttpClient>;
export type RequestCertificateError = InvalidArnException | InvalidDomainValidationOptionsException | InvalidParameterException | InvalidTagException | LimitExceededException | TagPolicyException | TooManyTagsException | CommonErrors;
/**
 * Requests an ACM certificate for use with other Amazon Web Services services. To request an ACM certificate, you must specify a fully qualified domain name (FQDN) in the `DomainName` parameter. You can also specify additional FQDNs in the `SubjectAlternativeNames` parameter.
 *
 * If you are requesting a private certificate, domain validation is not required. If you are requesting a public certificate, each domain name that you specify must be validated to verify that you own or control the domain. You can use DNS validation or email validation. We recommend that you use DNS validation.
 *
 * ACM behavior differs from the RFC 6125 specification of the certificate validation process. ACM first checks for a Subject Alternative Name, and, if it finds one, ignores the common name (CN).
 *
 * After successful completion of the `RequestCertificate` action, there is a delay of several seconds before you can retrieve information about the new certificate.
 */
export declare const requestCertificate: API.OperationMethod<RequestCertificateRequest, RequestCertificateResponse, RequestCertificateError, Credentials | HttpClient.HttpClient>;
export type ResendValidationEmailError = InvalidArnException | InvalidDomainValidationOptionsException | InvalidStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Resends the email that requests domain ownership validation. The domain owner or an authorized representative must approve the ACM certificate before it can be issued. The certificate can be approved by clicking a link in the mail to navigate to the Amazon certificate approval website and then clicking **I Approve**. However, the validation email can be blocked by spam filters. Therefore, if you do not receive the original mail, you can request that the mail be resent within 72 hours of requesting the ACM certificate. If more than 72 hours have elapsed since your original request or since your last attempt to resend validation mail, you must request a new certificate. For more information about setting up your contact email addresses, see Configure Email for your Domain.
 */
export declare const resendValidationEmail: API.OperationMethod<ResendValidationEmailRequest, ResendValidationEmailResponse, ResendValidationEmailError, Credentials | HttpClient.HttpClient>;
export type RevokeAcmeAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revokes an ACME account, preventing it from requesting or revoking certificates. This operation is irreversible.
 */
export declare const revokeAcmeAccount: API.OperationMethod<RevokeAcmeAccountRequest, RevokeAcmeAccountResponse, RevokeAcmeAccountError, Credentials | HttpClient.HttpClient>;
export type RevokeAcmeExternalAccountBindingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revokes an external account binding, preventing new ACME accounts from being registered using this binding. Existing ACME accounts that were previously registered using the binding are not affected and must be revoked separately.
 */
export declare const revokeAcmeExternalAccountBinding: API.OperationMethod<RevokeAcmeExternalAccountBindingRequest, RevokeAcmeExternalAccountBindingResponse, RevokeAcmeExternalAccountBindingError, Credentials | HttpClient.HttpClient>;
export type RevokeCertificateError = AccessDeniedException | ConflictException | InvalidArnException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Revokes a public ACM certificate. You can only revoke certificates that have been previously exported.
 *
 * Once a certificate is revoked, you cannot reuse the certificate. Revoking a certificate is permanent.
 */
export declare const revokeCertificate: API.OperationMethod<RevokeCertificateRequest, RevokeCertificateResponse, RevokeCertificateError, Credentials | HttpClient.HttpClient>;
export type SearchCertificatesError = AccessDeniedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of certificates matching search criteria. You can filter certificates by X.509 attributes and ACM specific properties like certificate status, type and renewal eligibility. This operation provides more flexible filtering than ListCertificates by supporting complex filter statements.
 */
export declare const searchCertificates: API.PaginatedOperationMethod<SearchCertificatesRequest, SearchCertificatesResponse, SearchCertificatesError, Credentials | HttpClient.HttpClient, CertificateSearchResult>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds one or more tags to an ACM resource. Tags are labels that you can use to identify and organize your Amazon Web Services resources. Each tag consists of a `key` and an optional `value`.
 *
 * Use this action for all ACM resource types except the `certificate` resource type. For certificate resources, use AddTagsToCertificate instead.
 *
 * To remove one or more tags, use the UntagResource action. To view all of the tags that have been applied to a resource, use the ListTagsForResource action.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from an ACM resource.
 *
 * Use this action for all ACM resource types except the `certificate` resource type. For certificate resources, use RemoveTagsFromCertificate instead.
 *
 * To add one or more tags, use the TagResource action. To view all of the tags that have been applied to a resource, use the ListTagsForResource action.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAcmeDomainValidationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the prevalidation configuration of an existing domain validation.
 */
export declare const updateAcmeDomainValidation: API.OperationMethod<UpdateAcmeDomainValidationRequest, UpdateAcmeDomainValidationResponse, UpdateAcmeDomainValidationError, Credentials | HttpClient.HttpClient>;
export type UpdateAcmeEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing ACME endpoint. You can change the authorization behavior, contact requirement, or certificate authority settings.
 */
export declare const updateAcmeEndpoint: API.OperationMethod<UpdateAcmeEndpointRequest, UpdateAcmeEndpointResponse, UpdateAcmeEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateCertificateOptionsError = ConflictException | InvalidArnException | InvalidStateException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates certificate options. You can use this operation to change the domain validation method or specify whether to export your certificate. For more information, see Migrate from email to DNS validation and Certificate Manager Exportable Managed Certificates.
 */
export declare const updateCertificateOptions: API.OperationMethod<UpdateCertificateOptionsRequest, UpdateCertificateOptionsResponse, UpdateCertificateOptionsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=acm.d.ts.map