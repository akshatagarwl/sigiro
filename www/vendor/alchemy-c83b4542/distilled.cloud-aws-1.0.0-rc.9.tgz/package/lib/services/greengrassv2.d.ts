import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const RequestAlreadyInProgressException_base: S.Class<RequestAlreadyInProgressException, S.TaggedStruct<"RequestAlreadyInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestAlreadyInProgressException extends /*@__PURE__*/ RequestAlreadyInProgressException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AssociateServiceRoleToAccountRequest {
    roleArn: string;
}
export declare const AssociateServiceRoleToAccountRequest: S.Schema<AssociateServiceRoleToAccountRequest>;
export interface AssociateServiceRoleToAccountResponse {
    associatedAt?: string;
}
export declare const AssociateServiceRoleToAccountResponse: S.Schema<AssociateServiceRoleToAccountResponse>;
export type IoTThingName = string;
export interface AssociateClientDeviceWithCoreDeviceEntry {
    thingName: string;
}
export declare const AssociateClientDeviceWithCoreDeviceEntry: S.Schema<AssociateClientDeviceWithCoreDeviceEntry>;
export type AssociateClientDeviceWithCoreDeviceEntryList = AssociateClientDeviceWithCoreDeviceEntry[];
export declare const AssociateClientDeviceWithCoreDeviceEntryList: any;
export interface BatchAssociateClientDeviceWithCoreDeviceRequest {
    entries?: AssociateClientDeviceWithCoreDeviceEntry[];
    coreDeviceThingName: string;
}
export declare const BatchAssociateClientDeviceWithCoreDeviceRequest: S.Schema<BatchAssociateClientDeviceWithCoreDeviceRequest>;
export type NonEmptyString = string;
export interface AssociateClientDeviceWithCoreDeviceErrorEntry {
    thingName?: string;
    code?: string;
    message?: string;
}
export declare const AssociateClientDeviceWithCoreDeviceErrorEntry: S.Schema<AssociateClientDeviceWithCoreDeviceErrorEntry>;
export type AssociateClientDeviceWithCoreDeviceErrorList = AssociateClientDeviceWithCoreDeviceErrorEntry[];
export declare const AssociateClientDeviceWithCoreDeviceErrorList: any;
export interface BatchAssociateClientDeviceWithCoreDeviceResponse {
    errorEntries?: AssociateClientDeviceWithCoreDeviceErrorEntry[];
}
export declare const BatchAssociateClientDeviceWithCoreDeviceResponse: S.Schema<BatchAssociateClientDeviceWithCoreDeviceResponse>;
export interface DisassociateClientDeviceFromCoreDeviceEntry {
    thingName: string;
}
export declare const DisassociateClientDeviceFromCoreDeviceEntry: S.Schema<DisassociateClientDeviceFromCoreDeviceEntry>;
export type DisassociateClientDeviceFromCoreDeviceEntryList = DisassociateClientDeviceFromCoreDeviceEntry[];
export declare const DisassociateClientDeviceFromCoreDeviceEntryList: any;
export interface BatchDisassociateClientDeviceFromCoreDeviceRequest {
    entries?: DisassociateClientDeviceFromCoreDeviceEntry[];
    coreDeviceThingName: string;
}
export declare const BatchDisassociateClientDeviceFromCoreDeviceRequest: S.Schema<BatchDisassociateClientDeviceFromCoreDeviceRequest>;
export interface DisassociateClientDeviceFromCoreDeviceErrorEntry {
    thingName?: string;
    code?: string;
    message?: string;
}
export declare const DisassociateClientDeviceFromCoreDeviceErrorEntry: S.Schema<DisassociateClientDeviceFromCoreDeviceErrorEntry>;
export type DisassociateClientDeviceFromCoreDeviceErrorList = DisassociateClientDeviceFromCoreDeviceErrorEntry[];
export declare const DisassociateClientDeviceFromCoreDeviceErrorList: any;
export interface BatchDisassociateClientDeviceFromCoreDeviceResponse {
    errorEntries?: DisassociateClientDeviceFromCoreDeviceErrorEntry[];
}
export declare const BatchDisassociateClientDeviceFromCoreDeviceResponse: S.Schema<BatchDisassociateClientDeviceFromCoreDeviceResponse>;
export interface CancelDeploymentRequest {
    deploymentId: string;
}
export declare const CancelDeploymentRequest: S.Schema<CancelDeploymentRequest>;
export interface CancelDeploymentResponse {
    message?: string;
}
export declare const CancelDeploymentResponse: S.Schema<CancelDeploymentResponse>;
export type RecipeBlob = Uint8Array;
export type ComponentNameString = string;
export type ComponentVersionString = string;
export type PlatformAttributesMap = {
    [key: string]: string | undefined;
};
export declare const PlatformAttributesMap: any;
export interface ComponentPlatform {
    name?: string;
    attributes?: {
        [key: string]: string | undefined;
    };
}
export declare const ComponentPlatform: S.Schema<ComponentPlatform>;
export type ComponentPlatformList = ComponentPlatform[];
export declare const ComponentPlatformList: any;
export type ComponentDependencyType = "HARD" | "SOFT" | (string & {});
export declare const ComponentDependencyType: any;
export interface ComponentDependencyRequirement {
    versionRequirement?: string;
    dependencyType?: ComponentDependencyType;
}
export declare const ComponentDependencyRequirement: S.Schema<ComponentDependencyRequirement>;
export type ComponentDependencyMap = {
    [key: string]: ComponentDependencyRequirement | undefined;
};
export declare const ComponentDependencyMap: any;
export type TopicString = string;
export type LambdaEventSourceType = "PUB_SUB" | "IOT_CORE" | (string & {});
export declare const LambdaEventSourceType: any;
export interface LambdaEventSource {
    topic: string;
    type: LambdaEventSourceType;
}
export declare const LambdaEventSource: S.Schema<LambdaEventSource>;
export type LambdaEventSourceList = LambdaEventSource[];
export declare const LambdaEventSourceList: any;
export type OptionalInteger = number;
export type OptionalBoolean = boolean;
export type LambdaInputPayloadEncodingType = "json" | "binary" | (string & {});
export declare const LambdaInputPayloadEncodingType: any;
export type LambdaExecArg = string;
export type LambdaExecArgsList = string[];
export declare const LambdaExecArgsList: any;
export type LambdaEnvironmentVariables = {
    [key: string]: string | undefined;
};
export declare const LambdaEnvironmentVariables: any;
export type LambdaIsolationMode = "GreengrassContainer" | "NoContainer" | (string & {});
export declare const LambdaIsolationMode: any;
export type FileSystemPath = string;
export type LambdaFilesystemPermission = "ro" | "rw" | (string & {});
export declare const LambdaFilesystemPermission: any;
export interface LambdaVolumeMount {
    sourcePath: string;
    destinationPath: string;
    permission?: LambdaFilesystemPermission;
    addGroupOwner?: boolean;
}
export declare const LambdaVolumeMount: S.Schema<LambdaVolumeMount>;
export type LambdaVolumeList = LambdaVolumeMount[];
export declare const LambdaVolumeList: any;
export interface LambdaDeviceMount {
    path: string;
    permission?: LambdaFilesystemPermission;
    addGroupOwner?: boolean;
}
export declare const LambdaDeviceMount: S.Schema<LambdaDeviceMount>;
export type LambdaDeviceList = LambdaDeviceMount[];
export declare const LambdaDeviceList: any;
export interface LambdaContainerParams {
    memorySizeInKB?: number;
    mountROSysfs?: boolean;
    volumes?: LambdaVolumeMount[];
    devices?: LambdaDeviceMount[];
}
export declare const LambdaContainerParams: S.Schema<LambdaContainerParams>;
export interface LambdaLinuxProcessParams {
    isolationMode?: LambdaIsolationMode;
    containerParams?: LambdaContainerParams;
}
export declare const LambdaLinuxProcessParams: S.Schema<LambdaLinuxProcessParams>;
export interface LambdaExecutionParameters {
    eventSources?: LambdaEventSource[];
    maxQueueSize?: number;
    maxInstancesCount?: number;
    maxIdleTimeInSeconds?: number;
    timeoutInSeconds?: number;
    statusTimeoutInSeconds?: number;
    pinned?: boolean;
    inputPayloadEncodingType?: LambdaInputPayloadEncodingType;
    execArgs?: string[];
    environmentVariables?: {
        [key: string]: string | undefined;
    };
    linuxProcessParams?: LambdaLinuxProcessParams;
}
export declare const LambdaExecutionParameters: S.Schema<LambdaExecutionParameters>;
export interface LambdaFunctionRecipeSource {
    lambdaArn: string;
    componentName?: string;
    componentVersion?: string;
    componentPlatforms?: ComponentPlatform[];
    componentDependencies?: {
        [key: string]: ComponentDependencyRequirement | undefined;
    };
    componentLambdaParameters?: LambdaExecutionParameters;
}
export declare const LambdaFunctionRecipeSource: S.Schema<LambdaFunctionRecipeSource>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type ClientTokenString = string;
export interface CreateComponentVersionRequest {
    inlineRecipe?: Uint8Array;
    lambdaFunction?: LambdaFunctionRecipeSource;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateComponentVersionRequest: S.Schema<CreateComponentVersionRequest>;
export type ComponentVersionARN = string;
export type CloudComponentState = "REQUESTED" | "INITIATED" | "DEPLOYABLE" | "FAILED" | "DEPRECATED" | (string & {});
export declare const CloudComponentState: any;
export type StringMap = {
    [key: string]: string | undefined;
};
export declare const StringMap: any;
export type VendorGuidance = "ACTIVE" | "DISCONTINUED" | "DELETED" | (string & {});
export declare const VendorGuidance: any;
export interface CloudComponentStatus {
    componentState?: CloudComponentState;
    message?: string;
    errors?: {
        [key: string]: string | undefined;
    };
    vendorGuidance?: VendorGuidance;
    vendorGuidanceMessage?: string;
}
export declare const CloudComponentStatus: S.Schema<CloudComponentStatus>;
export interface CreateComponentVersionResponse {
    arn?: string;
    componentName: string;
    componentVersion: string;
    creationTimestamp: Date;
    status: CloudComponentStatus;
}
export declare const CreateComponentVersionResponse: S.Schema<CreateComponentVersionResponse>;
export type TargetARN = string;
export type DeploymentNameString = string;
export type ComponentConfigurationString = string;
export type ComponentConfigurationPath = string;
export type ComponentConfigurationPathList = string[];
export declare const ComponentConfigurationPathList: any;
export interface ComponentConfigurationUpdate {
    merge?: string;
    reset?: string[];
}
export declare const ComponentConfigurationUpdate: S.Schema<ComponentConfigurationUpdate>;
export type Memory = number;
export type CPU = number;
export interface SystemResourceLimits {
    memory?: number;
    cpus?: number;
}
export declare const SystemResourceLimits: S.Schema<SystemResourceLimits>;
export interface ComponentRunWith {
    posixUser?: string;
    systemResourceLimits?: SystemResourceLimits;
    windowsUser?: string;
}
export declare const ComponentRunWith: S.Schema<ComponentRunWith>;
export interface ComponentDeploymentSpecification {
    componentVersion: string;
    configurationUpdate?: ComponentConfigurationUpdate;
    runWith?: ComponentRunWith;
}
export declare const ComponentDeploymentSpecification: S.Schema<ComponentDeploymentSpecification>;
export type ComponentDeploymentSpecifications = {
    [key: string]: ComponentDeploymentSpecification | undefined;
};
export declare const ComponentDeploymentSpecifications: any;
export type IoTJobRolloutBaseRatePerMinute = number;
export type IoTJobRolloutIncrementFactor = number;
export type IoTJobNumberOfThings = number;
export interface IoTJobRateIncreaseCriteria {
    numberOfNotifiedThings?: number;
    numberOfSucceededThings?: number;
}
export declare const IoTJobRateIncreaseCriteria: S.Schema<IoTJobRateIncreaseCriteria>;
export interface IoTJobExponentialRolloutRate {
    baseRatePerMinute: number;
    incrementFactor: number;
    rateIncreaseCriteria: IoTJobRateIncreaseCriteria;
}
export declare const IoTJobExponentialRolloutRate: S.Schema<IoTJobExponentialRolloutRate>;
export type IoTJobMaxExecutionsPerMin = number;
export interface IoTJobExecutionsRolloutConfig {
    exponentialRate?: IoTJobExponentialRolloutRate;
    maximumPerMinute?: number;
}
export declare const IoTJobExecutionsRolloutConfig: S.Schema<IoTJobExecutionsRolloutConfig>;
export type IoTJobExecutionFailureType = "FAILED" | "REJECTED" | "TIMED_OUT" | "ALL" | (string & {});
export declare const IoTJobExecutionFailureType: any;
export type IoTJobAbortAction = "CANCEL" | (string & {});
export declare const IoTJobAbortAction: any;
export type IoTJobAbortThresholdPercentage = number;
export type IoTJobMinimumNumberOfExecutedThings = number;
export interface IoTJobAbortCriteria {
    failureType: IoTJobExecutionFailureType;
    action: IoTJobAbortAction;
    thresholdPercentage: number;
    minNumberOfExecutedThings: number;
}
export declare const IoTJobAbortCriteria: S.Schema<IoTJobAbortCriteria>;
export type IoTJobAbortCriteriaList = IoTJobAbortCriteria[];
export declare const IoTJobAbortCriteriaList: any;
export interface IoTJobAbortConfig {
    criteriaList: IoTJobAbortCriteria[];
}
export declare const IoTJobAbortConfig: S.Schema<IoTJobAbortConfig>;
export type IoTJobInProgressTimeoutInMinutes = number;
export interface IoTJobTimeoutConfig {
    inProgressTimeoutInMinutes?: number;
}
export declare const IoTJobTimeoutConfig: S.Schema<IoTJobTimeoutConfig>;
export interface DeploymentIoTJobConfiguration {
    jobExecutionsRolloutConfig?: IoTJobExecutionsRolloutConfig;
    abortConfig?: IoTJobAbortConfig;
    timeoutConfig?: IoTJobTimeoutConfig;
}
export declare const DeploymentIoTJobConfiguration: S.Schema<DeploymentIoTJobConfiguration>;
export type DeploymentFailureHandlingPolicy = "ROLLBACK" | "DO_NOTHING" | (string & {});
export declare const DeploymentFailureHandlingPolicy: any;
export type DeploymentComponentUpdatePolicyAction = "NOTIFY_COMPONENTS" | "SKIP_NOTIFY_COMPONENTS" | (string & {});
export declare const DeploymentComponentUpdatePolicyAction: any;
export interface DeploymentComponentUpdatePolicy {
    timeoutInSeconds?: number;
    action?: DeploymentComponentUpdatePolicyAction;
}
export declare const DeploymentComponentUpdatePolicy: S.Schema<DeploymentComponentUpdatePolicy>;
export interface DeploymentConfigurationValidationPolicy {
    timeoutInSeconds?: number;
}
export declare const DeploymentConfigurationValidationPolicy: S.Schema<DeploymentConfigurationValidationPolicy>;
export interface DeploymentPolicies {
    failureHandlingPolicy?: DeploymentFailureHandlingPolicy;
    componentUpdatePolicy?: DeploymentComponentUpdatePolicy;
    configurationValidationPolicy?: DeploymentConfigurationValidationPolicy;
}
export declare const DeploymentPolicies: S.Schema<DeploymentPolicies>;
export type ThingGroupARN = string;
export interface CreateDeploymentRequest {
    targetArn: string;
    deploymentName?: string;
    components?: {
        [key: string]: ComponentDeploymentSpecification | undefined;
    };
    iotJobConfiguration?: DeploymentIoTJobConfiguration;
    deploymentPolicies?: DeploymentPolicies;
    parentTargetArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateDeploymentRequest: S.Schema<CreateDeploymentRequest>;
export type IoTJobARN = string;
export interface CreateDeploymentResponse {
    deploymentId?: string;
    iotJobId?: string;
    iotJobArn?: string;
}
export declare const CreateDeploymentResponse: S.Schema<CreateDeploymentResponse>;
export interface DeleteComponentRequest {
    arn: string;
}
export declare const DeleteComponentRequest: S.Schema<DeleteComponentRequest>;
export interface DeleteComponentResponse {
}
export declare const DeleteComponentResponse: S.Schema<DeleteComponentResponse>;
export type CoreDeviceThingName = string;
export interface DeleteCoreDeviceRequest {
    coreDeviceThingName: string;
}
export declare const DeleteCoreDeviceRequest: S.Schema<DeleteCoreDeviceRequest>;
export interface DeleteCoreDeviceResponse {
}
export declare const DeleteCoreDeviceResponse: S.Schema<DeleteCoreDeviceResponse>;
export interface DeleteDeploymentRequest {
    deploymentId: string;
}
export declare const DeleteDeploymentRequest: S.Schema<DeleteDeploymentRequest>;
export interface DeleteDeploymentResponse {
}
export declare const DeleteDeploymentResponse: S.Schema<DeleteDeploymentResponse>;
export interface DescribeComponentRequest {
    arn: string;
}
export declare const DescribeComponentRequest: S.Schema<DescribeComponentRequest>;
export type PublisherString = string;
export type DescriptionString = string;
export interface DescribeComponentResponse {
    arn?: string;
    componentName?: string;
    componentVersion?: string;
    creationTimestamp?: Date;
    publisher?: string;
    description?: string;
    status?: CloudComponentStatus;
    platforms?: ComponentPlatform[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const DescribeComponentResponse: S.Schema<DescribeComponentResponse>;
export interface DisassociateServiceRoleFromAccountRequest {
}
export declare const DisassociateServiceRoleFromAccountRequest: S.Schema<DisassociateServiceRoleFromAccountRequest>;
export interface DisassociateServiceRoleFromAccountResponse {
    disassociatedAt?: string;
}
export declare const DisassociateServiceRoleFromAccountResponse: S.Schema<DisassociateServiceRoleFromAccountResponse>;
export type RecipeOutputFormat = "JSON" | "YAML" | (string & {});
export declare const RecipeOutputFormat: any;
export interface GetComponentRequest {
    recipeOutputFormat?: RecipeOutputFormat;
    arn: string;
}
export declare const GetComponentRequest: S.Schema<GetComponentRequest>;
export interface GetComponentResponse {
    recipeOutputFormat: RecipeOutputFormat;
    recipe: Uint8Array;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetComponentResponse: S.Schema<GetComponentResponse>;
export type S3EndpointType = "REGIONAL" | "GLOBAL" | (string & {});
export declare const S3EndpointType: any;
export type IotEndpointType = "fips" | "standard" | (string & {});
export declare const IotEndpointType: any;
export interface GetComponentVersionArtifactRequest {
    arn: string;
    artifactName: string;
    s3EndpointType?: S3EndpointType;
    iotEndpointType?: IotEndpointType;
}
export declare const GetComponentVersionArtifactRequest: S.Schema<GetComponentVersionArtifactRequest>;
export interface GetComponentVersionArtifactResponse {
    preSignedUrl: string;
}
export declare const GetComponentVersionArtifactResponse: S.Schema<GetComponentVersionArtifactResponse>;
export interface GetConnectivityInfoRequest {
    thingName: string;
}
export declare const GetConnectivityInfoRequest: S.Schema<GetConnectivityInfoRequest>;
export type PortNumberInt = number;
export interface ConnectivityInfo {
    id?: string;
    hostAddress?: string;
    portNumber?: number;
    metadata?: string;
}
export declare const ConnectivityInfo: S.Schema<ConnectivityInfo>;
export type ConnectivityInfoList = ConnectivityInfo[];
export declare const ConnectivityInfoList: any;
export interface GetConnectivityInfoResponse {
    connectivityInfo?: ConnectivityInfo[];
    message?: string;
}
export declare const GetConnectivityInfoResponse: S.Schema<GetConnectivityInfoResponse>;
export interface GetCoreDeviceRequest {
    coreDeviceThingName: string;
}
export declare const GetCoreDeviceRequest: S.Schema<GetCoreDeviceRequest>;
export type GGCVersion = string;
export type CoreDevicePlatformString = string;
export type CoreDeviceArchitectureString = string;
export type CoreDeviceRuntimeString = string;
export type CoreDeviceStatus = "HEALTHY" | "UNHEALTHY" | (string & {});
export declare const CoreDeviceStatus: any;
export interface GetCoreDeviceResponse {
    coreDeviceThingName?: string;
    coreVersion?: string;
    platform?: string;
    architecture?: string;
    runtime?: string;
    status?: CoreDeviceStatus;
    lastStatusUpdateTimestamp?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetCoreDeviceResponse: S.Schema<GetCoreDeviceResponse>;
export interface GetDeploymentRequest {
    deploymentId: string;
}
export declare const GetDeploymentRequest: S.Schema<GetDeploymentRequest>;
export type NullableString = string;
export type DeploymentStatus = "ACTIVE" | "COMPLETED" | "CANCELED" | "FAILED" | "INACTIVE" | (string & {});
export declare const DeploymentStatus: any;
export type IsLatestForTarget = boolean;
export interface GetDeploymentResponse {
    targetArn?: string;
    revisionId?: string;
    deploymentId?: string;
    deploymentName?: string;
    deploymentStatus?: DeploymentStatus;
    iotJobId?: string;
    iotJobArn?: string;
    components?: {
        [key: string]: ComponentDeploymentSpecification | undefined;
    };
    deploymentPolicies?: DeploymentPolicies;
    iotJobConfiguration?: DeploymentIoTJobConfiguration;
    creationTimestamp?: Date;
    isLatestForTarget?: boolean;
    parentTargetArn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetDeploymentResponse: S.Schema<GetDeploymentResponse>;
export interface GetServiceRoleForAccountRequest {
}
export declare const GetServiceRoleForAccountRequest: S.Schema<GetServiceRoleForAccountRequest>;
export interface GetServiceRoleForAccountResponse {
    associatedAt?: string;
    roleArn?: string;
}
export declare const GetServiceRoleForAccountResponse: S.Schema<GetServiceRoleForAccountResponse>;
export type DefaultMaxResults = number;
export type NextTokenString = string;
export interface ListClientDevicesAssociatedWithCoreDeviceRequest {
    coreDeviceThingName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListClientDevicesAssociatedWithCoreDeviceRequest: S.Schema<ListClientDevicesAssociatedWithCoreDeviceRequest>;
export interface AssociatedClientDevice {
    thingName?: string;
    associationTimestamp?: Date;
}
export declare const AssociatedClientDevice: S.Schema<AssociatedClientDevice>;
export type AssociatedClientDeviceList = AssociatedClientDevice[];
export declare const AssociatedClientDeviceList: any;
export interface ListClientDevicesAssociatedWithCoreDeviceResponse {
    associatedClientDevices?: AssociatedClientDevice[];
    nextToken?: string;
}
export declare const ListClientDevicesAssociatedWithCoreDeviceResponse: S.Schema<ListClientDevicesAssociatedWithCoreDeviceResponse>;
export type ComponentVisibilityScope = "PRIVATE" | "PUBLIC" | (string & {});
export declare const ComponentVisibilityScope: any;
export interface ListComponentsRequest {
    scope?: ComponentVisibilityScope;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListComponentsRequest: S.Schema<ListComponentsRequest>;
export type ComponentARN = string;
export interface ComponentLatestVersion {
    arn?: string;
    componentVersion?: string;
    creationTimestamp?: Date;
    description?: string;
    publisher?: string;
    platforms?: ComponentPlatform[];
}
export declare const ComponentLatestVersion: S.Schema<ComponentLatestVersion>;
export interface Component {
    arn?: string;
    componentName?: string;
    latestVersion?: ComponentLatestVersion;
}
export declare const Component: S.Schema<Component>;
export type ComponentList = Component[];
export declare const ComponentList: any;
export interface ListComponentsResponse {
    components?: Component[];
    nextToken?: string;
}
export declare const ListComponentsResponse: S.Schema<ListComponentsResponse>;
export interface ListComponentVersionsRequest {
    arn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListComponentVersionsRequest: S.Schema<ListComponentVersionsRequest>;
export interface ComponentVersionListItem {
    componentName?: string;
    componentVersion?: string;
    arn?: string;
}
export declare const ComponentVersionListItem: S.Schema<ComponentVersionListItem>;
export type ComponentVersionList = ComponentVersionListItem[];
export declare const ComponentVersionList: any;
export interface ListComponentVersionsResponse {
    componentVersions?: ComponentVersionListItem[];
    nextToken?: string;
}
export declare const ListComponentVersionsResponse: S.Schema<ListComponentVersionsResponse>;
export interface ListCoreDevicesRequest {
    thingGroupArn?: string;
    status?: CoreDeviceStatus;
    maxResults?: number;
    nextToken?: string;
    runtime?: string;
}
export declare const ListCoreDevicesRequest: S.Schema<ListCoreDevicesRequest>;
export interface CoreDevice {
    coreDeviceThingName?: string;
    status?: CoreDeviceStatus;
    lastStatusUpdateTimestamp?: Date;
    platform?: string;
    architecture?: string;
    runtime?: string;
}
export declare const CoreDevice: S.Schema<CoreDevice>;
export type CoreDevicesList = CoreDevice[];
export declare const CoreDevicesList: any;
export interface ListCoreDevicesResponse {
    coreDevices?: CoreDevice[];
    nextToken?: string;
}
export declare const ListCoreDevicesResponse: S.Schema<ListCoreDevicesResponse>;
export type DeploymentHistoryFilter = "ALL" | "LATEST_ONLY" | (string & {});
export declare const DeploymentHistoryFilter: any;
export interface ListDeploymentsRequest {
    targetArn?: string;
    historyFilter?: DeploymentHistoryFilter;
    parentTargetArn?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDeploymentsRequest: S.Schema<ListDeploymentsRequest>;
export interface Deployment {
    targetArn?: string;
    revisionId?: string;
    deploymentId?: string;
    deploymentName?: string;
    creationTimestamp?: Date;
    deploymentStatus?: DeploymentStatus;
    isLatestForTarget?: boolean;
    parentTargetArn?: string;
}
export declare const Deployment: S.Schema<Deployment>;
export type DeploymentList = Deployment[];
export declare const DeploymentList: any;
export interface ListDeploymentsResponse {
    deployments?: Deployment[];
    nextToken?: string;
}
export declare const ListDeploymentsResponse: S.Schema<ListDeploymentsResponse>;
export interface ListEffectiveDeploymentsRequest {
    coreDeviceThingName: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListEffectiveDeploymentsRequest: S.Schema<ListEffectiveDeploymentsRequest>;
export type DeploymentID = string;
export type DeploymentName = string;
export type IoTJobId = string;
export type Description = string;
export type EffectiveDeploymentExecutionStatus = "IN_PROGRESS" | "QUEUED" | "FAILED" | "COMPLETED" | "TIMED_OUT" | "CANCELED" | "REJECTED" | "SUCCEEDED" | (string & {});
export declare const EffectiveDeploymentExecutionStatus: any;
export type Reason = string;
export type EffectiveDeploymentErrorCode = string;
export type EffectiveDeploymentErrorStack = string[];
export declare const EffectiveDeploymentErrorStack: any;
export type EffectiveDeploymentErrorType = string;
export type EffectiveDeploymentErrorTypeList = string[];
export declare const EffectiveDeploymentErrorTypeList: any;
export interface EffectiveDeploymentStatusDetails {
    errorStack?: string[];
    errorTypes?: string[];
}
export declare const EffectiveDeploymentStatusDetails: S.Schema<EffectiveDeploymentStatusDetails>;
export interface EffectiveDeployment {
    deploymentId: string;
    deploymentName: string;
    iotJobId?: string;
    iotJobArn?: string;
    description?: string;
    targetArn: string;
    coreDeviceExecutionStatus: EffectiveDeploymentExecutionStatus;
    reason?: string;
    creationTimestamp: Date;
    modifiedTimestamp: Date;
    statusDetails?: EffectiveDeploymentStatusDetails;
}
export declare const EffectiveDeployment: S.Schema<EffectiveDeployment>;
export type EffectiveDeploymentsList = EffectiveDeployment[];
export declare const EffectiveDeploymentsList: any;
export interface ListEffectiveDeploymentsResponse {
    effectiveDeployments?: EffectiveDeployment[];
    nextToken?: string;
}
export declare const ListEffectiveDeploymentsResponse: S.Schema<ListEffectiveDeploymentsResponse>;
export type InstalledComponentTopologyFilter = "ALL" | "ROOT" | (string & {});
export declare const InstalledComponentTopologyFilter: any;
export interface ListInstalledComponentsRequest {
    coreDeviceThingName: string;
    maxResults?: number;
    nextToken?: string;
    topologyFilter?: InstalledComponentTopologyFilter;
}
export declare const ListInstalledComponentsRequest: S.Schema<ListInstalledComponentsRequest>;
export type InstalledComponentLifecycleState = "NEW" | "INSTALLED" | "STARTING" | "RUNNING" | "STOPPING" | "ERRORED" | "BROKEN" | "FINISHED" | (string & {});
export declare const InstalledComponentLifecycleState: any;
export type LifecycleStateDetails = string;
export type IsRoot = boolean;
export type InstalledComponentLifecycleStatusCode = string;
export type InstalledComponentLifecycleStatusCodeList = string[];
export declare const InstalledComponentLifecycleStatusCodeList: any;
export interface InstalledComponent {
    componentName?: string;
    componentVersion?: string;
    lifecycleState?: InstalledComponentLifecycleState;
    lifecycleStateDetails?: string;
    isRoot?: boolean;
    lastStatusChangeTimestamp?: Date;
    lastReportedTimestamp?: Date;
    lastInstallationSource?: string;
    lifecycleStatusCodes?: string[];
}
export declare const InstalledComponent: S.Schema<InstalledComponent>;
export type InstalledComponentList = InstalledComponent[];
export declare const InstalledComponentList: any;
export interface ListInstalledComponentsResponse {
    installedComponents?: InstalledComponent[];
    nextToken?: string;
}
export declare const ListInstalledComponentsResponse: S.Schema<ListInstalledComponentsResponse>;
export type GenericV2ARN = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type ComponentVersionRequirementMap = {
    [key: string]: string | undefined;
};
export declare const ComponentVersionRequirementMap: any;
export interface ComponentCandidate {
    componentName?: string;
    componentVersion?: string;
    versionRequirements?: {
        [key: string]: string | undefined;
    };
}
export declare const ComponentCandidate: S.Schema<ComponentCandidate>;
export type ComponentCandidateList = ComponentCandidate[];
export declare const ComponentCandidateList: any;
export interface ResolveComponentCandidatesRequest {
    platform?: ComponentPlatform;
    componentCandidates?: ComponentCandidate[];
}
export declare const ResolveComponentCandidatesRequest: S.Schema<ResolveComponentCandidatesRequest>;
export interface ResolvedComponentVersion {
    arn?: string;
    componentName?: string;
    componentVersion?: string;
    recipe?: Uint8Array;
    vendorGuidance?: VendorGuidance;
    message?: string;
}
export declare const ResolvedComponentVersion: S.Schema<ResolvedComponentVersion>;
export type ResolvedComponentVersionsList = ResolvedComponentVersion[];
export declare const ResolvedComponentVersionsList: any;
export interface ResolveComponentCandidatesResponse {
    resolvedComponentVersions?: ResolvedComponentVersion[];
}
export declare const ResolveComponentCandidatesResponse: S.Schema<ResolveComponentCandidatesResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateConnectivityInfoRequest {
    thingName: string;
    connectivityInfo: ConnectivityInfo[];
}
export declare const UpdateConnectivityInfoRequest: S.Schema<UpdateConnectivityInfoRequest>;
export interface UpdateConnectivityInfoResponse {
    version?: string;
    message?: string;
}
export declare const UpdateConnectivityInfoResponse: S.Schema<UpdateConnectivityInfoResponse>;
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AssociateServiceRoleToAccountError = InternalServerException | ValidationException | CommonErrors;
/**
 * Associates a Greengrass service role with IoT Greengrass for your Amazon Web Services account in this Amazon Web Services Region. IoT Greengrass
 * uses this role to verify the identity of client devices and manage core device connectivity
 * information. The role must include the AWSGreengrassResourceAccessRolePolicy managed policy or a custom policy that
 * defines equivalent permissions for the IoT Greengrass features that you use. For more information, see
 * Greengrass service role in the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const associateServiceRoleToAccount: API.OperationMethod<AssociateServiceRoleToAccountRequest, AssociateServiceRoleToAccountResponse, AssociateServiceRoleToAccountError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateClientDeviceWithCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a list of client devices with a core device. Use this API operation to specify
 * which client devices can discover a core device through cloud discovery. With cloud discovery,
 * client devices connect to IoT Greengrass to retrieve associated core devices' connectivity information
 * and certificates. For more information, see Configure cloud
 * discovery in the *IoT Greengrass V2 Developer Guide*.
 *
 * Client devices are local IoT devices that connect to and communicate with an IoT Greengrass core
 * device over MQTT. You can connect client devices to a core device to sync MQTT messages and
 * data to Amazon Web Services IoT Core and interact with client devices in Greengrass components. For more information,
 * see Interact with
 * local IoT devices in the *IoT Greengrass V2 Developer Guide*.
 */
export declare const batchAssociateClientDeviceWithCoreDevice: API.OperationMethod<BatchAssociateClientDeviceWithCoreDeviceRequest, BatchAssociateClientDeviceWithCoreDeviceResponse, BatchAssociateClientDeviceWithCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateClientDeviceFromCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a list of client devices from a core device. After you disassociate a client
 * device from a core device, the client device won't be able to use cloud discovery to retrieve
 * the core device's connectivity information and certificates.
 */
export declare const batchDisassociateClientDeviceFromCoreDevice: API.OperationMethod<BatchDisassociateClientDeviceFromCoreDeviceRequest, BatchDisassociateClientDeviceFromCoreDeviceResponse, BatchDisassociateClientDeviceFromCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type CancelDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a deployment. This operation cancels the deployment for devices that haven't yet
 * received it. If a device already received the deployment, this operation doesn't change
 * anything for that device.
 */
export declare const cancelDeployment: API.OperationMethod<CancelDeploymentRequest, CancelDeploymentResponse, CancelDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateComponentVersionError = AccessDeniedException | ConflictException | InternalServerException | RequestAlreadyInProgressException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a component. Components are software that run on Greengrass core devices. After you
 * develop and test a component on your core device, you can use this operation to upload your
 * component to IoT Greengrass. Then, you can deploy the component to other core devices.
 *
 * You can use this operation to do the following:
 *
 * - **Create components from recipes**
 *
 * Create a component from a recipe, which is a file that defines the component's
 * metadata, parameters, dependencies, lifecycle, artifacts, and platform capability. For
 * more information, see IoT Greengrass component recipe
 * reference in the *IoT Greengrass V2 Developer Guide*.
 *
 * To create a component from a recipe, specify `inlineRecipe` when you call
 * this operation.
 *
 * - **Create components from Lambda functions**
 *
 * Create a component from an Lambda function that runs on IoT Greengrass. This creates a recipe
 * and artifacts from the Lambda function's deployment package. You can use this operation to
 * migrate Lambda functions from IoT Greengrass V1 to IoT Greengrass V2.
 *
 * This function accepts Lambda functions in all supported versions of Python, Node.js,
 * and Java runtimes. IoT Greengrass doesn't apply any additional restrictions on deprecated Lambda
 * runtime versions.
 *
 * To create a component from a Lambda function, specify `lambdaFunction` when
 * you call this operation.
 *
 * IoT Greengrass currently supports Lambda functions on only Linux core devices.
 */
export declare const createComponentVersion: API.OperationMethod<CreateComponentVersionRequest, CreateComponentVersionResponse, CreateComponentVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = AccessDeniedException | ConflictException | InternalServerException | RequestAlreadyInProgressException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a continuous deployment for a target, which is a Greengrass core device or group of core
 * devices. When you add a new core device to a group of core devices that has a deployment, IoT Greengrass
 * deploys that group's deployment to the new device.
 *
 * You can define one deployment for each target. When you create a new deployment for a
 * target that has an existing deployment, you replace the previous deployment. IoT Greengrass applies the
 * new deployment to the target devices.
 *
 * Every deployment has a revision number that indicates how many deployment revisions you
 * define for a target. Use this operation to create a new revision of an existing
 * deployment.
 *
 * For more information, see the Create deployments in the
 * *IoT Greengrass V2 Developer Guide*.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a version of a component from IoT Greengrass.
 *
 * This operation deletes the component's recipe and artifacts. As a result, deployments
 * that refer to this component version will fail. If you have deployments that use this
 * component version, you can remove the component from the deployment or update the deployment
 * to use a valid version.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteCoreDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Greengrass core device, which is an IoT thing. This operation removes the core
 * device from the list of core devices. This operation doesn't delete the IoT thing. For more
 * information about how to delete the IoT thing, see DeleteThing in the
 * *IoT API Reference*.
 */
export declare const deleteCoreDevice: API.OperationMethod<DeleteCoreDeviceRequest, DeleteCoreDeviceResponse, DeleteCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a deployment. To delete an active deployment, you must first cancel it. For more
 * information, see CancelDeployment.
 *
 * Deleting a deployment doesn't affect core devices that run that deployment, because core
 * devices store the deployment's configuration on the device. Additionally, core devices can
 * roll back to a previous deployment that has been deleted.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for a version of a component.
 */
export declare const describeComponent: API.OperationMethod<DescribeComponentRequest, DescribeComponentResponse, DescribeComponentError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceRoleFromAccountError = InternalServerException | CommonErrors;
/**
 * Disassociates the Greengrass service role from IoT Greengrass for your Amazon Web Services account in this Amazon Web Services Region.
 * Without a service role, IoT Greengrass can't verify the identity of client devices or manage core device
 * connectivity information. For more information, see Greengrass service role in
 * the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const disassociateServiceRoleFromAccount: API.OperationMethod<DisassociateServiceRoleFromAccountRequest, DisassociateServiceRoleFromAccountResponse, DisassociateServiceRoleFromAccountError, Credentials | HttpClient.HttpClient>;
export type GetComponentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the recipe for a version of a component.
 */
export declare const getComponent: API.OperationMethod<GetComponentRequest, GetComponentResponse, GetComponentError, Credentials | HttpClient.HttpClient>;
export type GetComponentVersionArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the pre-signed URL to download a public or a Lambda component artifact. Core devices
 * call this operation to identify the URL that they can use to download an artifact to
 * install.
 */
export declare const getComponentVersionArtifact: API.OperationMethod<GetComponentVersionArtifactRequest, GetComponentVersionArtifactResponse, GetComponentVersionArtifactError, Credentials | HttpClient.HttpClient>;
export type GetConnectivityInfoError = InternalServerException | ValidationException | CommonErrors;
/**
 * Retrieves connectivity information for a Greengrass core device.
 *
 * Connectivity information includes endpoints and ports where client devices
 * can connect to an MQTT broker on the core device. When a client device
 * calls the IoT Greengrass discovery API,
 * IoT Greengrass returns connectivity information for all of the core devices where the client device can
 * connect. For more information, see Connect client devices to
 * core devices in the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const getConnectivityInfo: API.OperationMethod<GetConnectivityInfoRequest, GetConnectivityInfoResponse, GetConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export type GetCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves metadata for a Greengrass core device.
 *
 * IoT Greengrass relies on individual devices to send status updates to the Amazon Web Services Cloud. If the
 * IoT Greengrass Core software isn't running on the device, or if device isn't connected to the Amazon Web Services Cloud,
 * then the reported status of that device might not reflect its current status. The status
 * timestamp indicates when the device status was last updated.
 *
 * Core devices send status updates at the following times:
 *
 * - When the IoT Greengrass Core software starts
 *
 * - When the core device receives a deployment from the Amazon Web Services Cloud
 *
 * - When the status of any component on the core device becomes
 * `BROKEN`
 *
 * - At a regular interval that you can configure, which defaults to 24 hours
 *
 * - For IoT Greengrass Core v2.7.0, the core device sends status updates upon local deployment and
 * cloud deployment
 */
export declare const getCoreDevice: API.OperationMethod<GetCoreDeviceRequest, GetCoreDeviceResponse, GetCoreDeviceError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a deployment. Deployments define the components that run on Greengrass core devices.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, GetDeploymentResponse, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetServiceRoleForAccountError = InternalServerException | CommonErrors;
/**
 * Gets the service role associated with IoT Greengrass for your Amazon Web Services account in this Amazon Web Services Region.
 * IoT Greengrass uses this role to verify the identity of client devices and manage core device
 * connectivity information. For more information, see Greengrass service role in
 * the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const getServiceRoleForAccount: API.OperationMethod<GetServiceRoleForAccountRequest, GetServiceRoleForAccountResponse, GetServiceRoleForAccountError, Credentials | HttpClient.HttpClient>;
export type ListClientDevicesAssociatedWithCoreDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of client devices that are associated with a core
 * device.
 */
export declare const listClientDevicesAssociatedWithCoreDevice: API.PaginatedOperationMethod<ListClientDevicesAssociatedWithCoreDeviceRequest, ListClientDevicesAssociatedWithCoreDeviceResponse, ListClientDevicesAssociatedWithCoreDeviceError, Credentials | HttpClient.HttpClient, AssociatedClientDevice>;
export type ListComponentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of component summaries. This list includes components that you
 * have permission to view.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, Component>;
export type ListComponentVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of all versions for a component. Greater versions are listed
 * first.
 */
export declare const listComponentVersions: API.PaginatedOperationMethod<ListComponentVersionsRequest, ListComponentVersionsResponse, ListComponentVersionsError, Credentials | HttpClient.HttpClient, ComponentVersionListItem>;
export type ListCoreDevicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of Greengrass core devices.
 *
 * IoT Greengrass relies on individual devices to send status updates to the Amazon Web Services Cloud. If the
 * IoT Greengrass Core software isn't running on the device, or if device isn't connected to the Amazon Web Services Cloud,
 * then the reported status of that device might not reflect its current status. The status
 * timestamp indicates when the device status was last updated.
 *
 * Core devices send status updates at the following times:
 *
 * - When the IoT Greengrass Core software starts
 *
 * - When the core device receives a deployment from the Amazon Web Services Cloud
 *
 * - For Greengrass nucleus 2.12.2 and earlier, the core device sends status updates when the
 * status of any component on the core device becomes `ERRORED` or
 * `BROKEN`.
 *
 * - For Greengrass nucleus 2.12.3 and later, the core device sends status updates when the
 * status of any component on the core device becomes `ERRORED`,
 * `BROKEN`, `RUNNING`, or `FINISHED`.
 *
 * - At a regular interval that you can configure, which defaults to 24 hours
 *
 * - For IoT Greengrass Core v2.7.0, the core device sends status updates upon local deployment and
 * cloud deployment
 */
export declare const listCoreDevices: API.PaginatedOperationMethod<ListCoreDevicesRequest, ListCoreDevicesResponse, ListCoreDevicesError, Credentials | HttpClient.HttpClient, CoreDevice>;
export type ListDeploymentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of deployments.
 */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsRequest, ListDeploymentsResponse, ListDeploymentsError, Credentials | HttpClient.HttpClient, Deployment>;
export type ListEffectiveDeploymentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of deployment jobs that IoT Greengrass sends to Greengrass core devices.
 */
export declare const listEffectiveDeployments: API.PaginatedOperationMethod<ListEffectiveDeploymentsRequest, ListEffectiveDeploymentsResponse, ListEffectiveDeploymentsError, Credentials | HttpClient.HttpClient, EffectiveDeployment>;
export type ListInstalledComponentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a paginated list of the components that a Greengrass core device runs. By default,
 * this list doesn't include components that are deployed as dependencies of other components. To
 * include dependencies in the response, set the `topologyFilter` parameter to
 * `ALL`.
 *
 * IoT Greengrass relies on individual devices to send status updates to the Amazon Web Services Cloud. If the
 * IoT Greengrass Core software isn't running on the device, or if device isn't connected to the Amazon Web Services Cloud,
 * then the reported status of that device might not reflect its current status. The status
 * timestamp indicates when the device status was last updated.
 *
 * Core devices send status updates at the following times:
 *
 * - When the IoT Greengrass Core software starts
 *
 * - When the core device receives a deployment from the Amazon Web Services Cloud
 *
 * - When the status of any component on the core device becomes
 * `BROKEN`
 *
 * - At a regular interval that you can configure, which defaults to 24 hours
 *
 * - For IoT Greengrass Core v2.7.0, the core device sends status updates upon local deployment and
 * cloud deployment
 */
export declare const listInstalledComponents: API.PaginatedOperationMethod<ListInstalledComponentsRequest, ListInstalledComponentsResponse, ListInstalledComponentsError, Credentials | HttpClient.HttpClient, InstalledComponent>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the list of tags for an IoT Greengrass resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResolveComponentCandidatesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of components that meet the component, version, and platform requirements
 * of a deployment. Greengrass core devices call this operation when they receive a deployment to
 * identify the components to install.
 *
 * This operation identifies components that meet all dependency requirements for a
 * deployment. If the requirements conflict, then this operation returns an error and the
 * deployment fails. For example, this occurs if component `A` requires version
 * `>2.0.0` and component `B` requires version `<2.0.0`
 * of a component dependency.
 *
 * When you specify the component candidates to resolve, IoT Greengrass compares each component's
 * digest from the core device with the component's digest in the Amazon Web Services Cloud. If the digests
 * don't match, then IoT Greengrass specifies to use the version from the Amazon Web Services Cloud.
 *
 * To use this operation, you must use the data plane API endpoint and authenticate with an
 * IoT device certificate. For more information, see IoT Greengrass endpoints and quotas.
 */
export declare const resolveComponentCandidates: API.OperationMethod<ResolveComponentCandidatesRequest, ResolveComponentCandidatesResponse, ResolveComponentCandidatesError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds tags to an IoT Greengrass resource. If a tag already exists for the resource, this operation
 * updates the tag's value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from an IoT Greengrass resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectivityInfoError = InternalServerException | ValidationException | CommonErrors;
/**
 * Updates connectivity information for a Greengrass core device.
 *
 * Connectivity information includes endpoints and ports where client devices
 * can connect to an MQTT broker on the core device. When a client device
 * calls the IoT Greengrass discovery API,
 * IoT Greengrass returns connectivity information for all of the core devices where the client device can
 * connect. For more information, see Connect client devices to
 * core devices in the *IoT Greengrass Version 2 Developer Guide*.
 */
export declare const updateConnectivityInfo: API.OperationMethod<UpdateConnectivityInfoRequest, UpdateConnectivityInfoResponse, UpdateConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=greengrassv2.d.ts.map