import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.Class<ResourceUnavailableException, S.TaggedStruct<"ResourceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type RescoreExecutionPlanName = string;
export type Description = string;
export type RescoreCapacityUnit = number;
export interface CapacityUnitsConfiguration {
    RescoreCapacityUnits: number;
}
export declare const CapacityUnitsConfiguration: S.Schema<CapacityUnitsConfiguration>;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type ClientTokenName = string;
export interface CreateRescoreExecutionPlanRequest {
    Name: string;
    Description?: string;
    CapacityUnits?: CapacityUnitsConfiguration;
    Tags?: Tag[];
    ClientToken?: string;
}
export declare const CreateRescoreExecutionPlanRequest: S.Schema<CreateRescoreExecutionPlanRequest>;
export type RescoreExecutionPlanId = string;
export type RescoreExecutionPlanArn = string;
export interface CreateRescoreExecutionPlanResponse {
    Id: string;
    Arn: string;
}
export declare const CreateRescoreExecutionPlanResponse: S.Schema<CreateRescoreExecutionPlanResponse>;
export interface DeleteRescoreExecutionPlanRequest {
    Id: string;
}
export declare const DeleteRescoreExecutionPlanRequest: S.Schema<DeleteRescoreExecutionPlanRequest>;
export interface DeleteRescoreExecutionPlanResponse {
}
export declare const DeleteRescoreExecutionPlanResponse: S.Schema<DeleteRescoreExecutionPlanResponse>;
export interface DescribeRescoreExecutionPlanRequest {
    Id: string;
}
export declare const DescribeRescoreExecutionPlanRequest: S.Schema<DescribeRescoreExecutionPlanRequest>;
export type RescoreExecutionPlanStatus = "CREATING" | "UPDATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export declare const RescoreExecutionPlanStatus: any;
export type ErrorMessage = string;
export interface DescribeRescoreExecutionPlanResponse {
    Id?: string;
    Arn?: string;
    Name?: string;
    Description?: string;
    CapacityUnits?: CapacityUnitsConfiguration;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Status?: RescoreExecutionPlanStatus;
    ErrorMessage?: string;
}
export declare const DescribeRescoreExecutionPlanResponse: S.Schema<DescribeRescoreExecutionPlanResponse>;
export type NextToken = string;
export type MaxResultsIntegerForListRescoreExecutionPlansRequest = number;
export interface ListRescoreExecutionPlansRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListRescoreExecutionPlansRequest: S.Schema<ListRescoreExecutionPlansRequest>;
export interface RescoreExecutionPlanSummary {
    Name?: string;
    Id?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    Status?: RescoreExecutionPlanStatus;
}
export declare const RescoreExecutionPlanSummary: S.Schema<RescoreExecutionPlanSummary>;
export type RescoreExecutionPlanSummaryList = RescoreExecutionPlanSummary[];
export declare const RescoreExecutionPlanSummaryList: any;
export interface ListRescoreExecutionPlansResponse {
    SummaryItems?: RescoreExecutionPlanSummary[];
    NextToken?: string;
}
export declare const ListRescoreExecutionPlansResponse: S.Schema<ListRescoreExecutionPlansResponse>;
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    Tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type SearchQuery = string;
export type DocumentId = string;
export type GroupId = string;
export type DocumentTitle = string;
export type DocumentBody = string;
export type Tokens = string;
export type TitleTokensList = string[];
export declare const TitleTokensList: any;
export type BodyTokensList = string[];
export declare const BodyTokensList: any;
export interface Document {
    Id: string;
    GroupId?: string;
    Title?: string;
    Body?: string;
    TokenizedTitle?: string[];
    TokenizedBody?: string[];
    OriginalScore: number;
}
export declare const Document: S.Schema<Document>;
export type DocumentList = Document[];
export declare const DocumentList: any;
export interface RescoreRequest {
    RescoreExecutionPlanId: string;
    SearchQuery: string;
    Documents: Document[];
}
export declare const RescoreRequest: S.Schema<RescoreRequest>;
export type RescoreId = string;
export interface RescoreResultItem {
    DocumentId?: string;
    Score?: number;
}
export declare const RescoreResultItem: S.Schema<RescoreResultItem>;
export type RescoreResultItemList = RescoreResultItem[];
export declare const RescoreResultItemList: any;
export interface RescoreResult {
    RescoreId?: string;
    ResultItems?: RescoreResultItem[];
}
export declare const RescoreResult: S.Schema<RescoreResult>;
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateRescoreExecutionPlanRequest {
    Id: string;
    Name?: string;
    Description?: string;
    CapacityUnits?: CapacityUnitsConfiguration;
}
export declare const UpdateRescoreExecutionPlanRequest: S.Schema<UpdateRescoreExecutionPlanRequest>;
export interface UpdateRescoreExecutionPlanResponse {
}
export declare const UpdateRescoreExecutionPlanResponse: S.Schema<UpdateRescoreExecutionPlanResponse>;
export type CreateRescoreExecutionPlanError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a rescore execution plan. A rescore execution
 * plan is an Amazon Kendra Intelligent Ranking resource
 * used for provisioning the `Rescore` API. You set
 * the number of capacity units that you require for
 * Amazon Kendra Intelligent Ranking to rescore or re-rank
 * a search service's results.
 *
 * For an example of using the
 * `CreateRescoreExecutionPlan` API, including using
 * the Python and Java SDKs, see Semantically
 * ranking a search service's results.
 */
export declare const createRescoreExecutionPlan: API.OperationMethod<CreateRescoreExecutionPlanRequest, CreateRescoreExecutionPlanResponse, CreateRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteRescoreExecutionPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a rescore execution plan. A rescore execution
 * plan is an Amazon Kendra Intelligent Ranking resource
 * used for provisioning the `Rescore` API.
 */
export declare const deleteRescoreExecutionPlan: API.OperationMethod<DeleteRescoreExecutionPlanRequest, DeleteRescoreExecutionPlanResponse, DeleteRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeRescoreExecutionPlanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a rescore execution plan. A rescore
 * execution plan is an Amazon Kendra Intelligent Ranking
 * resource used for provisioning the `Rescore` API.
 */
export declare const describeRescoreExecutionPlan: API.OperationMethod<DescribeRescoreExecutionPlanRequest, DescribeRescoreExecutionPlanResponse, DescribeRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export type ListRescoreExecutionPlansError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists your rescore execution plans. A rescore execution plan
 * is an Amazon Kendra Intelligent Ranking resource used for
 * provisioning the `Rescore` API.
 */
export declare const listRescoreExecutionPlans: API.PaginatedOperationMethod<ListRescoreExecutionPlansRequest, ListRescoreExecutionPlansResponse, ListRescoreExecutionPlansError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of tags associated with a specified resource.
 * A rescore execution plan is an example of a resource that
 * can have tags associated with it.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RescoreError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rescores or re-ranks search results from a search service
 * such as OpenSearch (self managed). You use the semantic search
 * capabilities of Amazon Kendra Intelligent Ranking to
 * improve the search service's results.
 */
export declare const rescore: API.OperationMethod<RescoreRequest, RescoreResult, RescoreError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a specified tag to a specified rescore execution
 * plan. A rescore execution plan is an Amazon Kendra
 * Intelligent Ranking resource used for provisioning the
 * `Rescore` API. If the tag already exists,
 * the existing value is replaced with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from a rescore execution plan. A rescore
 * execution plan is an Amazon Kendra Intelligent
 * Ranking resource used for provisioning the
 * `Rescore` operation.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRescoreExecutionPlanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a rescore execution plan. A rescore execution plan
 * is an Amazon Kendra Intelligent Ranking resource used for
 * provisioning the `Rescore` API. You can update the
 * number of capacity units you require for Amazon Kendra
 * Intelligent Ranking to rescore or re-rank a search service's
 * results.
 */
export declare const updateRescoreExecutionPlan: API.OperationMethod<UpdateRescoreExecutionPlanRequest, UpdateRescoreExecutionPlanResponse, UpdateRescoreExecutionPlanError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kendra-ranking.d.ts.map