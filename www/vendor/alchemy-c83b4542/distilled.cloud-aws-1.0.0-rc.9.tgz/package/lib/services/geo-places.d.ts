import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SensitiveString = string | redacted.Redacted<string>;
export type Position = number[];
export declare const Position: any;
export type BoundingBox = number[];
export declare const BoundingBox: any;
export type DistanceMeters = number;
export interface FilterCircle {
    Center: number[];
    Radius: number;
}
export declare const FilterCircle: S.Schema<FilterCircle>;
export type CountryCode = string | redacted.Redacted<string>;
export type CountryCodeList = (string | redacted.Redacted<string>)[];
export declare const CountryCodeList: any;
export type AutocompleteFilterPlaceType = "Locality" | "PostalCode" | "Street" | "Intersection" | "PointAddress" | "InterpolatedAddress" | "Country" | "Region" | (string & {});
export declare const AutocompleteFilterPlaceType: any;
export type AutocompleteFilterPlaceTypeList = AutocompleteFilterPlaceType[];
export declare const AutocompleteFilterPlaceTypeList: any;
export interface AutocompleteFilter {
    BoundingBox?: number[];
    Circle?: FilterCircle;
    IncludeCountries?: (string | redacted.Redacted<string>)[];
    IncludePlaceTypes?: AutocompleteFilterPlaceType[];
}
export declare const AutocompleteFilter: S.Schema<AutocompleteFilter>;
export type PostalCodeMode = "MergeAllSpannedLocalities" | "EnumerateSpannedLocalities" | "EnumerateSpannedDistricts" | (string & {});
export declare const PostalCodeMode: any;
export type AutocompleteAdditionalFeature = "Core" | (string & {});
export declare const AutocompleteAdditionalFeature: any;
export type AutocompleteAdditionalFeatureList = AutocompleteAdditionalFeature[];
export declare const AutocompleteAdditionalFeatureList: any;
export type LanguageTag = string;
export type AutocompleteIntendedUse = "SingleUse" | (string & {});
export declare const AutocompleteIntendedUse: any;
export type ApiKey = string | redacted.Redacted<string>;
export interface AutocompleteRequest {
    QueryText: string | redacted.Redacted<string>;
    MaxResults?: number;
    BiasPosition?: number[];
    Filter?: AutocompleteFilter;
    PostalCodeMode?: PostalCodeMode;
    AdditionalFeatures?: AutocompleteAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: AutocompleteIntendedUse;
    Key?: string | redacted.Redacted<string>;
}
export declare const AutocompleteRequest: S.Schema<AutocompleteRequest>;
export type PlaceType = "Country" | "Region" | "SubRegion" | "Locality" | "District" | "SubDistrict" | "PostalCode" | "Block" | "SubBlock" | "Intersection" | "Street" | "PointOfInterest" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "InferredSecondaryAddress" | (string & {});
export declare const PlaceType: any;
export type CountryCode2 = string | redacted.Redacted<string>;
export type CountryCode3 = string | redacted.Redacted<string>;
export interface Country {
    Code2?: string | redacted.Redacted<string>;
    Code3?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export declare const Country: S.Schema<Country>;
export interface Region {
    Code?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export declare const Region: S.Schema<Region>;
export interface SubRegion {
    Code?: string | redacted.Redacted<string>;
    Name?: string | redacted.Redacted<string>;
}
export declare const SubRegion: S.Schema<SubRegion>;
export type IntersectionStreet = string;
export type IntersectionStreetList = string[];
export declare const IntersectionStreetList: any;
export type TypePlacement = "BeforeBaseName" | "AfterBaseName" | (string & {});
export declare const TypePlacement: any;
export type TypeSeparator = string;
export interface StreetComponents {
    BaseName?: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string>;
    TypePlacement?: TypePlacement;
    TypeSeparator?: string;
    Prefix?: string | redacted.Redacted<string>;
    Suffix?: string | redacted.Redacted<string>;
    Direction?: string | redacted.Redacted<string>;
    Language?: string;
}
export declare const StreetComponents: S.Schema<StreetComponents>;
export type StreetComponentsList = StreetComponents[];
export declare const StreetComponentsList: any;
export interface SecondaryAddressComponent {
    Number: string | redacted.Redacted<string>;
    Designator?: string | redacted.Redacted<string>;
}
export declare const SecondaryAddressComponent: S.Schema<SecondaryAddressComponent>;
export type SecondaryAddressComponentList = SecondaryAddressComponent[];
export declare const SecondaryAddressComponentList: any;
export interface Address {
    Label?: string | redacted.Redacted<string>;
    Country?: Country;
    Region?: Region;
    SubRegion?: SubRegion;
    Locality?: string | redacted.Redacted<string>;
    District?: string | redacted.Redacted<string>;
    SubDistrict?: string | redacted.Redacted<string>;
    PostalCode?: string | redacted.Redacted<string>;
    Block?: string | redacted.Redacted<string>;
    SubBlock?: string | redacted.Redacted<string>;
    Intersection?: string[];
    Street?: string | redacted.Redacted<string>;
    StreetComponents?: StreetComponents[];
    AddressNumber?: string | redacted.Redacted<string>;
    Building?: string | redacted.Redacted<string>;
    SecondaryAddressComponents?: SecondaryAddressComponent[];
}
export declare const Address: S.Schema<Address>;
export interface Highlight {
    StartIndex?: number;
    EndIndex?: number;
    Value?: string | redacted.Redacted<string>;
}
export declare const Highlight: S.Schema<Highlight>;
export type HighlightList = Highlight[];
export declare const HighlightList: any;
export interface CountryHighlights {
    Code?: Highlight[];
    Name?: Highlight[];
}
export declare const CountryHighlights: S.Schema<CountryHighlights>;
export interface RegionHighlights {
    Code?: Highlight[];
    Name?: Highlight[];
}
export declare const RegionHighlights: S.Schema<RegionHighlights>;
export interface SubRegionHighlights {
    Code?: Highlight[];
    Name?: Highlight[];
}
export declare const SubRegionHighlights: S.Schema<SubRegionHighlights>;
export type IntersectionHighlightsList = Highlight[][];
export declare const IntersectionHighlightsList: any;
export interface AutocompleteAddressHighlights {
    Label?: Highlight[];
    Country?: CountryHighlights;
    Region?: RegionHighlights;
    SubRegion?: SubRegionHighlights;
    Locality?: Highlight[];
    District?: Highlight[];
    SubDistrict?: Highlight[];
    Street?: Highlight[];
    Block?: Highlight[];
    SubBlock?: Highlight[];
    Intersection?: Highlight[][];
    PostalCode?: Highlight[];
    AddressNumber?: Highlight[];
    Building?: Highlight[];
}
export declare const AutocompleteAddressHighlights: S.Schema<AutocompleteAddressHighlights>;
export interface AutocompleteHighlights {
    Title?: Highlight[];
    Address?: AutocompleteAddressHighlights;
}
export declare const AutocompleteHighlights: S.Schema<AutocompleteHighlights>;
export type SensitiveBoolean = boolean;
export interface AutocompleteResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    Distance?: number;
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    Highlights?: AutocompleteHighlights;
    EstimatedPointAddress?: boolean;
}
export declare const AutocompleteResultItem: S.Schema<AutocompleteResultItem>;
export type AutocompleteResultItemList = AutocompleteResultItem[];
export declare const AutocompleteResultItemList: any;
export interface AutocompleteResponse {
    PricingBucket: string;
    ResultItems?: AutocompleteResultItem[];
}
export declare const AutocompleteResponse: S.Schema<AutocompleteResponse>;
export interface GeocodeQueryComponents {
    Country?: string | redacted.Redacted<string>;
    Region?: string | redacted.Redacted<string>;
    SubRegion?: string | redacted.Redacted<string>;
    Locality?: string | redacted.Redacted<string>;
    District?: string | redacted.Redacted<string>;
    Street?: string | redacted.Redacted<string>;
    AddressNumber?: string | redacted.Redacted<string>;
    PostalCode?: string | redacted.Redacted<string>;
}
export declare const GeocodeQueryComponents: S.Schema<GeocodeQueryComponents>;
export type GeocodeFilterPlaceType = "Locality" | "PostalCode" | "Intersection" | "Street" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "PointOfInterest" | "Country" | "Region" | (string & {});
export declare const GeocodeFilterPlaceType: any;
export type GeocodeFilterPlaceTypeList = GeocodeFilterPlaceType[];
export declare const GeocodeFilterPlaceTypeList: any;
export interface GeocodeFilter {
    IncludeCountries?: (string | redacted.Redacted<string>)[];
    IncludePlaceTypes?: GeocodeFilterPlaceType[];
}
export declare const GeocodeFilter: S.Schema<GeocodeFilter>;
export type GeocodeAdditionalFeature = "TimeZone" | "Access" | "SecondaryAddresses" | "Intersections" | (string & {});
export declare const GeocodeAdditionalFeature: any;
export type GeocodeAdditionalFeatureList = GeocodeAdditionalFeature[];
export declare const GeocodeAdditionalFeatureList: any;
export type GeocodeIntendedUse = "SingleUse" | "Storage" | (string & {});
export declare const GeocodeIntendedUse: any;
export type AddressTranslationComponent = "District" | "Locality" | "Region" | "SubRegion" | (string & {});
export declare const AddressTranslationComponent: any;
export type AddressTranslationComponentList = AddressTranslationComponent[];
export declare const AddressTranslationComponentList: any;
export type GeocodeAddressNamesMode = "Matched" | "Administrative" | (string & {});
export declare const GeocodeAddressNamesMode: any;
export interface GeocodeRequest {
    QueryText?: string | redacted.Redacted<string>;
    QueryComponents?: GeocodeQueryComponents;
    MaxResults?: number;
    BiasPosition?: number[];
    Filter?: GeocodeFilter;
    AdditionalFeatures?: GeocodeAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: GeocodeIntendedUse;
    Key?: string | redacted.Redacted<string>;
    PostalCodeMode?: PostalCodeMode;
    AddressTranslations?: AddressTranslationComponent[];
    AddressNamesMode?: GeocodeAddressNamesMode;
}
export declare const GeocodeRequest: S.Schema<GeocodeRequest>;
export type PostalAuthority = "Usps" | (string & {});
export declare const PostalAuthority: any;
export type PostalCodeType = "UspsZip" | "UspsZipPlus4" | (string & {});
export declare const PostalCodeType: any;
export type ZipClassificationCode = "Military" | "PostOfficeBoxes" | "Unique" | (string & {});
export declare const ZipClassificationCode: any;
export interface UspsZip {
    ZipClassificationCode?: ZipClassificationCode;
}
export declare const UspsZip: S.Schema<UspsZip>;
export type RecordTypeCode = "Firm" | "General" | "HighRise" | "PostOfficeBox" | "Rural" | "Street" | (string & {});
export declare const RecordTypeCode: any;
export interface UspsZipPlus4 {
    RecordTypeCode?: RecordTypeCode;
}
export declare const UspsZipPlus4: S.Schema<UspsZipPlus4>;
export interface PostalCodeDetails {
    PostalCode?: string | redacted.Redacted<string>;
    PostalAuthority?: PostalAuthority;
    PostalCodeType?: PostalCodeType;
    UspsZip?: UspsZip;
    UspsZipPlus4?: UspsZipPlus4;
}
export declare const PostalCodeDetails: S.Schema<PostalCodeDetails>;
export type PostalCodeDetailsList = PostalCodeDetails[];
export declare const PostalCodeDetailsList: any;
export interface Category {
    Id: string | redacted.Redacted<string>;
    Name: string | redacted.Redacted<string>;
    LocalizedName?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export declare const Category: S.Schema<Category>;
export type CategoryList = Category[];
export declare const CategoryList: any;
export interface FoodType {
    LocalizedName: string | redacted.Redacted<string>;
    Id?: string | redacted.Redacted<string>;
    Primary?: boolean;
}
export declare const FoodType: S.Schema<FoodType>;
export type FoodTypeList = FoodType[];
export declare const FoodTypeList: any;
export type AccessPointType = "Delivery" | "Emergency" | "Entrance" | "Loading" | "Other" | "Parking" | "Taxi" | (string & {});
export declare const AccessPointType: any;
export interface AccessPoint {
    Position?: number[];
    Type?: AccessPointType;
    Primary?: boolean;
    Label?: string | redacted.Redacted<string>;
}
export declare const AccessPoint: S.Schema<AccessPoint>;
export type AccessPointList = AccessPoint[];
export declare const AccessPointList: any;
export type DurationSeconds = number;
export interface TimeZone {
    Name: string | redacted.Redacted<string>;
    Offset?: string | redacted.Redacted<string>;
    OffsetSeconds?: number;
}
export declare const TimeZone: S.Schema<TimeZone>;
export type MatchScore = number;
export type MatchScoreList = number[];
export declare const MatchScoreList: any;
export interface SecondaryAddressComponentMatchScore {
    Number?: number;
}
export declare const SecondaryAddressComponentMatchScore: S.Schema<SecondaryAddressComponentMatchScore>;
export type SecondaryAddressComponentMatchScoreList = SecondaryAddressComponentMatchScore[];
export declare const SecondaryAddressComponentMatchScoreList: any;
export interface AddressComponentMatchScores {
    Country?: number;
    Region?: number;
    SubRegion?: number;
    Locality?: number;
    District?: number;
    SubDistrict?: number;
    PostalCode?: number;
    Block?: number;
    SubBlock?: number;
    Intersection?: number[];
    AddressNumber?: number;
    Building?: number;
    SecondaryAddressComponents?: SecondaryAddressComponentMatchScore[];
}
export declare const AddressComponentMatchScores: S.Schema<AddressComponentMatchScores>;
export interface ComponentMatchScores {
    Title?: number;
    Address?: AddressComponentMatchScores;
}
export declare const ComponentMatchScores: S.Schema<ComponentMatchScores>;
export interface MatchScoreDetails {
    Overall?: number;
    Components?: ComponentMatchScores;
}
export declare const MatchScoreDetails: S.Schema<MatchScoreDetails>;
export interface ParsedQueryComponent {
    StartIndex?: number;
    EndIndex?: number;
    Value?: string | redacted.Redacted<string>;
    QueryComponent?: string | redacted.Redacted<string>;
}
export declare const ParsedQueryComponent: S.Schema<ParsedQueryComponent>;
export type ParsedQueryComponentList = ParsedQueryComponent[];
export declare const ParsedQueryComponentList: any;
export interface ParsedQuerySecondaryAddressComponent {
    StartIndex: number;
    EndIndex: number;
    Value: string | redacted.Redacted<string>;
    Number: string | redacted.Redacted<string>;
    Designator: string | redacted.Redacted<string>;
}
export declare const ParsedQuerySecondaryAddressComponent: S.Schema<ParsedQuerySecondaryAddressComponent>;
export type ParsedQuerySecondaryAddressComponentList = ParsedQuerySecondaryAddressComponent[];
export declare const ParsedQuerySecondaryAddressComponentList: any;
export interface GeocodeParsedQueryAddressComponents {
    Country?: ParsedQueryComponent[];
    Region?: ParsedQueryComponent[];
    SubRegion?: ParsedQueryComponent[];
    Locality?: ParsedQueryComponent[];
    District?: ParsedQueryComponent[];
    SubDistrict?: ParsedQueryComponent[];
    PostalCode?: ParsedQueryComponent[];
    Block?: ParsedQueryComponent[];
    SubBlock?: ParsedQueryComponent[];
    Street?: ParsedQueryComponent[];
    AddressNumber?: ParsedQueryComponent[];
    Building?: ParsedQueryComponent[];
    SecondaryAddressComponents?: ParsedQuerySecondaryAddressComponent[];
    OtherComponents?: ParsedQueryComponent[];
}
export declare const GeocodeParsedQueryAddressComponents: S.Schema<GeocodeParsedQueryAddressComponents>;
export interface GeocodeParsedQuery {
    Title?: ParsedQueryComponent[];
    Address?: GeocodeParsedQueryAddressComponents;
}
export declare const GeocodeParsedQuery: S.Schema<GeocodeParsedQuery>;
export interface Intersection {
    PlaceId: string | redacted.Redacted<string>;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    Position?: number[];
    Distance?: number;
    RouteDistance?: number;
    MapView?: number[];
    AccessPoints?: AccessPoint[];
}
export declare const Intersection: S.Schema<Intersection>;
export type IntersectionList = Intersection[];
export declare const IntersectionList: any;
export interface RelatedPlace {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    Position?: number[];
    AccessPoints?: AccessPoint[];
}
export declare const RelatedPlace: S.Schema<RelatedPlace>;
export type RelatedPlaceList = RelatedPlace[];
export declare const RelatedPlaceList: any;
export type TranslationNameType = "Abbreviation" | "AreaCode" | "BaseName" | "Exonym" | "Shortened" | "Synonym" | (string & {});
export declare const TranslationNameType: any;
export interface TranslationName {
    Value: string | redacted.Redacted<string>;
    Language?: string;
    Type: TranslationNameType;
    Primary?: boolean;
    Transliterated?: boolean;
}
export declare const TranslationName: S.Schema<TranslationName>;
export type TranslationNameList = TranslationName[];
export declare const TranslationNameList: any;
export type AdminNamesPreference = "Alternative" | "Primary" | (string & {});
export declare const AdminNamesPreference: any;
export interface AdminNames {
    Names: TranslationName[];
    Preference?: AdminNamesPreference;
}
export declare const AdminNames: S.Schema<AdminNames>;
export type AdminNamesList = AdminNames[];
export declare const AdminNamesList: any;
export interface TranslationDetails {
    Locality?: AdminNames[];
    Region?: AdminNames[];
    District?: AdminNames[];
    SubRegion?: AdminNames[];
}
export declare const TranslationDetails: S.Schema<TranslationDetails>;
export interface GeocodeResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: PostalCodeDetails[];
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    AccessPoints?: AccessPoint[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    MatchScores?: MatchScoreDetails;
    ParsedQuery?: GeocodeParsedQuery;
    Intersections?: Intersection[];
    MainAddress?: RelatedPlace;
    SecondaryAddresses?: RelatedPlace[];
    Translations?: TranslationDetails;
    EstimatedPointAddress?: boolean;
}
export declare const GeocodeResultItem: S.Schema<GeocodeResultItem>;
export type GeocodeResultItemList = GeocodeResultItem[];
export declare const GeocodeResultItemList: any;
export interface GeocodeResponse {
    PricingBucket: string;
    ResultItems?: GeocodeResultItem[];
}
export declare const GeocodeResponse: S.Schema<GeocodeResponse>;
export type GetPlaceAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "SecondaryAddresses" | "CrossReferences" | (string & {});
export declare const GetPlaceAdditionalFeature: any;
export type GetPlaceAdditionalFeatureList = GetPlaceAdditionalFeature[];
export declare const GetPlaceAdditionalFeatureList: any;
export type GetPlaceIntendedUse = "SingleUse" | "Storage" | (string & {});
export declare const GetPlaceIntendedUse: any;
export type GetPlaceAddressNamesMode = "Administrative" | (string & {});
export declare const GetPlaceAddressNamesMode: any;
export interface GetPlaceRequest {
    PlaceId: string | redacted.Redacted<string>;
    AdditionalFeatures?: GetPlaceAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: GetPlaceIntendedUse;
    Key?: string | redacted.Redacted<string>;
    AddressNamesMode?: GetPlaceAddressNamesMode;
}
export declare const GetPlaceRequest: S.Schema<GetPlaceRequest>;
export interface BusinessChain {
    Name?: string | redacted.Redacted<string>;
    Id?: string | redacted.Redacted<string>;
}
export declare const BusinessChain: S.Schema<BusinessChain>;
export type BusinessChainList = BusinessChain[];
export declare const BusinessChainList: any;
export interface ContactDetails {
    Label?: string | redacted.Redacted<string>;
    Value?: string | redacted.Redacted<string>;
    Categories?: Category[];
}
export declare const ContactDetails: S.Schema<ContactDetails>;
export type ContactDetailsList = ContactDetails[];
export declare const ContactDetailsList: any;
export interface Contacts {
    Phones?: ContactDetails[];
    Faxes?: ContactDetails[];
    Websites?: ContactDetails[];
    Emails?: ContactDetails[];
}
export declare const Contacts: S.Schema<Contacts>;
export type OpeningHoursDisplay = string | redacted.Redacted<string>;
export type OpeningHoursDisplayList = (string | redacted.Redacted<string>)[];
export declare const OpeningHoursDisplayList: any;
export interface OpeningHoursComponents {
    OpenTime?: string | redacted.Redacted<string>;
    OpenDuration?: string | redacted.Redacted<string>;
    Recurrence?: string | redacted.Redacted<string>;
}
export declare const OpeningHoursComponents: S.Schema<OpeningHoursComponents>;
export type OpeningHoursComponentsList = OpeningHoursComponents[];
export declare const OpeningHoursComponentsList: any;
export interface OpeningHours {
    Display?: (string | redacted.Redacted<string>)[];
    OpenNow?: boolean;
    Components?: OpeningHoursComponents[];
    Categories?: Category[];
}
export declare const OpeningHours: S.Schema<OpeningHours>;
export type OpeningHoursList = OpeningHours[];
export declare const OpeningHoursList: any;
export interface AccessRestriction {
    Restricted?: boolean;
    Categories?: Category[];
}
export declare const AccessRestriction: S.Schema<AccessRestriction>;
export type AccessRestrictionList = AccessRestriction[];
export declare const AccessRestrictionList: any;
export interface PhonemeTranscription {
    Value?: string | redacted.Redacted<string>;
    Language?: string;
    Preferred?: boolean;
}
export declare const PhonemeTranscription: S.Schema<PhonemeTranscription>;
export type PhonemeTranscriptionList = PhonemeTranscription[];
export declare const PhonemeTranscriptionList: any;
export interface AddressComponentPhonemes {
    Country?: PhonemeTranscription[];
    Region?: PhonemeTranscription[];
    SubRegion?: PhonemeTranscription[];
    Locality?: PhonemeTranscription[];
    District?: PhonemeTranscription[];
    SubDistrict?: PhonemeTranscription[];
    Block?: PhonemeTranscription[];
    SubBlock?: PhonemeTranscription[];
    Street?: PhonemeTranscription[];
}
export declare const AddressComponentPhonemes: S.Schema<AddressComponentPhonemes>;
export interface PhonemeDetails {
    Title?: PhonemeTranscription[];
    Address?: AddressComponentPhonemes;
}
export declare const PhonemeDetails: S.Schema<PhonemeDetails>;
export type PlaceAttribute = "DriveThrough" | (string & {});
export declare const PlaceAttribute: any;
export type PlaceAttributeList = PlaceAttribute[];
export declare const PlaceAttributeList: any;
export interface CrossReference {
    Source: string | redacted.Redacted<string>;
    SourcePlaceId: string | redacted.Redacted<string>;
    SourceCategories?: Category[];
}
export declare const CrossReference: S.Schema<CrossReference>;
export type CrossReferenceList = CrossReference[];
export declare const CrossReferenceList: any;
export interface GetPlaceResponse {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    PricingBucket: string;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: PostalCodeDetails[];
    Position?: number[];
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    Contacts?: Contacts;
    OpeningHours?: OpeningHours[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    MainAddress?: RelatedPlace;
    SecondaryAddresses?: RelatedPlace[];
    PlaceAttributes?: PlaceAttribute[];
    EstimatedPointAddress?: boolean;
    CrossReferences?: CrossReference[];
}
export declare const GetPlaceResponse: S.Schema<GetPlaceResponse>;
export type ReverseGeocodeFilterPlaceType = "Locality" | "Intersection" | "Street" | "PointAddress" | "InterpolatedAddress" | "SecondaryAddress" | "PointOfInterest" | (string & {});
export declare const ReverseGeocodeFilterPlaceType: any;
export type ReverseGeocodeFilterPlaceTypeList = ReverseGeocodeFilterPlaceType[];
export declare const ReverseGeocodeFilterPlaceTypeList: any;
export interface ReverseGeocodeFilter {
    IncludePlaceTypes?: ReverseGeocodeFilterPlaceType[];
}
export declare const ReverseGeocodeFilter: S.Schema<ReverseGeocodeFilter>;
export type ReverseGeocodeAdditionalFeature = "TimeZone" | "Access" | "Intersections" | (string & {});
export declare const ReverseGeocodeAdditionalFeature: any;
export type ReverseGeocodeAdditionalFeatureList = ReverseGeocodeAdditionalFeature[];
export declare const ReverseGeocodeAdditionalFeatureList: any;
export type ReverseGeocodeIntendedUse = "SingleUse" | "Storage" | (string & {});
export declare const ReverseGeocodeIntendedUse: any;
export type Heading = number;
export type ReverseGeocodeAddressNamesMode = "Administrative" | (string & {});
export declare const ReverseGeocodeAddressNamesMode: any;
export interface ReverseGeocodeRequest {
    QueryPosition: number[];
    QueryRadius?: number;
    MaxResults?: number;
    Filter?: ReverseGeocodeFilter;
    AdditionalFeatures?: ReverseGeocodeAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: ReverseGeocodeIntendedUse;
    Key?: string | redacted.Redacted<string>;
    Heading?: number;
    AddressNamesMode?: ReverseGeocodeAddressNamesMode;
}
export declare const ReverseGeocodeRequest: S.Schema<ReverseGeocodeRequest>;
export interface ReverseGeocodeResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: PostalCodeDetails[];
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    AccessPoints?: AccessPoint[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Intersections?: Intersection[];
    MainAddress?: RelatedPlace;
    EstimatedPointAddress?: boolean;
}
export declare const ReverseGeocodeResultItem: S.Schema<ReverseGeocodeResultItem>;
export type ReverseGeocodeResultItemList = ReverseGeocodeResultItem[];
export declare const ReverseGeocodeResultItemList: any;
export interface ReverseGeocodeResponse {
    PricingBucket: string;
    ResultItems?: ReverseGeocodeResultItem[];
}
export declare const ReverseGeocodeResponse: S.Schema<ReverseGeocodeResponse>;
export type FilterCategoryList = (string | redacted.Redacted<string>)[];
export declare const FilterCategoryList: any;
export type FilterBusinessChainList = (string | redacted.Redacted<string>)[];
export declare const FilterBusinessChainList: any;
export type FilterFoodTypeList = (string | redacted.Redacted<string>)[];
export declare const FilterFoodTypeList: any;
export interface SearchNearbyFilter {
    BoundingBox?: number[];
    IncludeCountries?: (string | redacted.Redacted<string>)[];
    IncludeCategories?: (string | redacted.Redacted<string>)[];
    ExcludeCategories?: (string | redacted.Redacted<string>)[];
    IncludeBusinessChains?: (string | redacted.Redacted<string>)[];
    ExcludeBusinessChains?: (string | redacted.Redacted<string>)[];
    IncludeFoodTypes?: (string | redacted.Redacted<string>)[];
    ExcludeFoodTypes?: (string | redacted.Redacted<string>)[];
}
export declare const SearchNearbyFilter: S.Schema<SearchNearbyFilter>;
export type SearchNearbyAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "CrossReferences" | (string & {});
export declare const SearchNearbyAdditionalFeature: any;
export type SearchNearbyAdditionalFeatureList = SearchNearbyAdditionalFeature[];
export declare const SearchNearbyAdditionalFeatureList: any;
export type SearchNearbyIntendedUse = "SingleUse" | "Storage" | (string & {});
export declare const SearchNearbyIntendedUse: any;
export type Token = string;
export interface SearchNearbyRequest {
    QueryPosition: number[];
    QueryRadius?: number;
    MaxResults?: number;
    Filter?: SearchNearbyFilter;
    AdditionalFeatures?: SearchNearbyAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: SearchNearbyIntendedUse;
    NextToken?: string;
    Key?: string | redacted.Redacted<string>;
}
export declare const SearchNearbyRequest: S.Schema<SearchNearbyRequest>;
export interface SearchNearbyResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    Contacts?: Contacts;
    OpeningHours?: OpeningHours[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    PlaceAttributes?: PlaceAttribute[];
    CrossReferences?: CrossReference[];
}
export declare const SearchNearbyResultItem: S.Schema<SearchNearbyResultItem>;
export type SearchNearbyResultItemList = SearchNearbyResultItem[];
export declare const SearchNearbyResultItemList: any;
export interface SearchNearbyResponse {
    PricingBucket: string;
    ResultItems?: SearchNearbyResultItem[];
    NextToken?: string;
}
export declare const SearchNearbyResponse: S.Schema<SearchNearbyResponse>;
export interface SearchTextFilter {
    BoundingBox?: number[];
    Circle?: FilterCircle;
    IncludeCountries?: (string | redacted.Redacted<string>)[];
}
export declare const SearchTextFilter: S.Schema<SearchTextFilter>;
export type SearchTextAdditionalFeature = "TimeZone" | "Phonemes" | "Access" | "Contact" | "CrossReferences" | (string & {});
export declare const SearchTextAdditionalFeature: any;
export type SearchTextAdditionalFeatureList = SearchTextAdditionalFeature[];
export declare const SearchTextAdditionalFeatureList: any;
export type SearchTextIntendedUse = "SingleUse" | "Storage" | (string & {});
export declare const SearchTextIntendedUse: any;
export type SearchTextTravelMode = "Car" | "Scooter" | "Truck" | (string & {});
export declare const SearchTextTravelMode: any;
export interface SearchTextRequest {
    QueryText?: string | redacted.Redacted<string>;
    QueryId?: string | redacted.Redacted<string>;
    MaxResults?: number;
    BiasPosition?: number[];
    Filter?: SearchTextFilter;
    AdditionalFeatures?: SearchTextAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: SearchTextIntendedUse;
    NextToken?: string;
    TravelMode?: SearchTextTravelMode;
    Key?: string | redacted.Redacted<string>;
}
export declare const SearchTextRequest: S.Schema<SearchTextRequest>;
export interface SearchTextResultItem {
    PlaceId: string | redacted.Redacted<string>;
    PlaceType: PlaceType;
    Title: string | redacted.Redacted<string>;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    Contacts?: Contacts;
    OpeningHours?: OpeningHours[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    PlaceAttributes?: PlaceAttribute[];
    CrossReferences?: CrossReference[];
}
export declare const SearchTextResultItem: S.Schema<SearchTextResultItem>;
export type SearchTextResultItemList = SearchTextResultItem[];
export declare const SearchTextResultItemList: any;
export interface SearchTextResponse {
    PricingBucket: string;
    ResultItems?: SearchTextResultItem[];
    NextToken?: string;
}
export declare const SearchTextResponse: S.Schema<SearchTextResponse>;
export interface SuggestFilter {
    BoundingBox?: number[];
    Circle?: FilterCircle;
    IncludeCountries?: (string | redacted.Redacted<string>)[];
}
export declare const SuggestFilter: S.Schema<SuggestFilter>;
export type SuggestAdditionalFeature = "Core" | "TimeZone" | "Phonemes" | "Access" | "CrossReferences" | (string & {});
export declare const SuggestAdditionalFeature: any;
export type SuggestAdditionalFeatureList = SuggestAdditionalFeature[];
export declare const SuggestAdditionalFeatureList: any;
export type SuggestIntendedUse = "SingleUse" | (string & {});
export declare const SuggestIntendedUse: any;
export type SuggestTravelMode = "Car" | "Scooter" | "Truck" | (string & {});
export declare const SuggestTravelMode: any;
export interface SuggestRequest {
    QueryText: string | redacted.Redacted<string>;
    MaxResults?: number;
    MaxQueryRefinements?: number;
    BiasPosition?: number[];
    Filter?: SuggestFilter;
    AdditionalFeatures?: SuggestAdditionalFeature[];
    Language?: string;
    PoliticalView?: string | redacted.Redacted<string>;
    IntendedUse?: SuggestIntendedUse;
    TravelMode?: SuggestTravelMode;
    Key?: string | redacted.Redacted<string>;
}
export declare const SuggestRequest: S.Schema<SuggestRequest>;
export type SuggestResultItemType = "Place" | "Query" | (string & {});
export declare const SuggestResultItemType: any;
export interface SuggestPlaceResult {
    PlaceId?: string | redacted.Redacted<string>;
    PlaceType?: PlaceType;
    Address?: Address;
    Position?: number[];
    Distance?: number;
    MapView?: number[];
    Categories?: Category[];
    FoodTypes?: FoodType[];
    BusinessChains?: BusinessChain[];
    AccessPoints?: AccessPoint[];
    AccessRestrictions?: AccessRestriction[];
    TimeZone?: TimeZone;
    PoliticalView?: string | redacted.Redacted<string>;
    Phonemes?: PhonemeDetails;
    PlaceAttributes?: PlaceAttribute[];
    CrossReferences?: CrossReference[];
}
export declare const SuggestPlaceResult: S.Schema<SuggestPlaceResult>;
export type QueryType = "Category" | "BusinessChain" | (string & {});
export declare const QueryType: any;
export interface SuggestQueryResult {
    QueryId?: string | redacted.Redacted<string>;
    QueryType?: QueryType;
}
export declare const SuggestQueryResult: S.Schema<SuggestQueryResult>;
export interface SuggestAddressHighlights {
    Label?: Highlight[];
}
export declare const SuggestAddressHighlights: S.Schema<SuggestAddressHighlights>;
export interface SuggestHighlights {
    Title?: Highlight[];
    Address?: SuggestAddressHighlights;
}
export declare const SuggestHighlights: S.Schema<SuggestHighlights>;
export interface SuggestResultItem {
    Title: string | redacted.Redacted<string>;
    SuggestResultItemType: SuggestResultItemType;
    Place?: SuggestPlaceResult;
    Query?: SuggestQueryResult;
    Highlights?: SuggestHighlights;
}
export declare const SuggestResultItem: S.Schema<SuggestResultItem>;
export type SuggestResultItemList = SuggestResultItem[];
export declare const SuggestResultItemList: any;
export interface QueryRefinement {
    RefinedTerm: string | redacted.Redacted<string>;
    OriginalTerm: string | redacted.Redacted<string>;
    StartIndex: number;
    EndIndex: number;
}
export declare const QueryRefinement: S.Schema<QueryRefinement>;
export type QueryRefinementList = QueryRefinement[];
export declare const QueryRefinementList: any;
export interface SuggestResponse {
    PricingBucket: string;
    ResultItems?: SuggestResultItem[];
    QueryRefinements?: QueryRefinement[];
}
export declare const SuggestResponse: S.Schema<SuggestResponse>;
export type ValidationExceptionReason = "UnknownOperation" | "Missing" | "CannotParse" | "FieldValidationFailed" | "Other" | "UnknownField" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type AutocompleteError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Autocomplete` completes potential places and addresses as the user types, based on the partial input. The API enhances the efficiency and accuracy of address by completing query based on a few entered keystrokes. It helps you by completing partial queries with valid address completion. Also, the API supports the filtering of results based on geographic location, country, or specific place types, and can be tailored using optional parameters like language and political views. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Autocomplete in the *Amazon Location Service Developer Guide*.
 */
export declare const autocomplete: API.OperationMethod<AutocompleteRequest, AutocompleteResponse, AutocompleteError, Credentials | HttpClient.HttpClient>;
export type GeocodeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Geocode` converts a textual address or place into geographic coordinates. You can obtain geographic coordinates, address component, and other related information. It supports flexible queries, including free-form text or structured queries with components like street names, postal codes, and regions. The Geocode API can also provide additional features such as time zone information and the inclusion of political views. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Geocode in the *Amazon Location Service Developer Guide*.
 */
export declare const geocode: API.OperationMethod<GeocodeRequest, GeocodeResponse, GeocodeError, Credentials | HttpClient.HttpClient>;
export type GetPlaceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetPlace` finds a place by its unique ID. A `PlaceId` is returned by other place operations.
 *
 * For more information, see GetPlace in the *Amazon Location Service Developer Guide*.
 */
export declare const getPlace: API.OperationMethod<GetPlaceRequest, GetPlaceResponse, GetPlaceError, Credentials | HttpClient.HttpClient>;
export type ReverseGeocodeError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `ReverseGeocode` converts geographic coordinates into a human-readable address or place. You can obtain address component, and other related information such as place type, category, street information. The Reverse Geocode API supports filtering to on place type so that you can refine result based on your need. Also, The Reverse Geocode API can also provide additional features such as time zone information and the inclusion of political views.
 *
 * For more information, see Reverse Geocode in the *Amazon Location Service Developer Guide*.
 */
export declare const reverseGeocode: API.OperationMethod<ReverseGeocodeRequest, ReverseGeocodeResponse, ReverseGeocodeError, Credentials | HttpClient.HttpClient>;
export type SearchNearbyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SearchNearby` queries for points of interest within a radius from a central coordinates, returning place results with optional filters such as categories, business chains, food types and more. The API returns details such as a place name, address, phone, category, food type, contact, opening hours. Also, the API can return phonemes, time zones and more based on requested parameters. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see Search Nearby in the *Amazon Location Service Developer Guide*.
 */
export declare const searchNearby: API.OperationMethod<SearchNearbyRequest, SearchNearbyResponse, SearchNearbyError, Credentials | HttpClient.HttpClient>;
export type SearchTextError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SearchText` searches for geocode and place information. You can then complete a follow-up query suggested from the `Suggest` API via a query id.
 *
 * For more information, see Search Text in the *Amazon Location Service Developer Guide*.
 */
export declare const searchText: API.OperationMethod<SearchTextRequest, SearchTextResponse, SearchTextError, Credentials | HttpClient.HttpClient>;
export type SuggestError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `Suggest` provides intelligent predictions or recommendations based on the user's input or context, such as relevant places, points of interest, query terms or search category. It is designed to help users find places or point of interests candidates or identify a follow on query based on incomplete or misspelled queries. It returns a list of possible matches or refinements that can be used to formulate a more accurate query. Users can select the most appropriate suggestion and use it for further searching. The API provides options for filtering results by location and other attributes, and allows for additional features like phonemes and timezones. The response includes refined query terms and detailed place information.
 *
 * For more information, see Suggest in the *Amazon Location Service Developer Guide*.
 */
export declare const suggest: API.OperationMethod<SuggestRequest, SuggestResponse, SuggestError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=geo-places.d.ts.map