import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const APICallRateForCustomerExceededFault_base: S.Class<APICallRateForCustomerExceededFault, S.TaggedStruct<"APICallRateForCustomerExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class APICallRateForCustomerExceededFault extends /*@__PURE__*/ APICallRateForCustomerExceededFault_base {
}
declare const AuthorizationAlreadyExistsFault_base: S.Class<AuthorizationAlreadyExistsFault, S.TaggedStruct<"AuthorizationAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AuthorizationAlreadyExistsFault extends /*@__PURE__*/ AuthorizationAlreadyExistsFault_base {
}
declare const AuthorizationNotFoundFault_base: S.Class<AuthorizationNotFoundFault, S.TaggedStruct<"AuthorizationNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const CacheClusterAlreadyExistsFault_base: S.Class<CacheClusterAlreadyExistsFault, S.TaggedStruct<"CacheClusterAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheClusterAlreadyExistsFault extends /*@__PURE__*/ CacheClusterAlreadyExistsFault_base {
}
declare const CacheClusterNotFoundFault_base: S.Class<CacheClusterNotFoundFault, S.TaggedStruct<"CacheClusterNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheClusterNotFoundFault extends /*@__PURE__*/ CacheClusterNotFoundFault_base {
}
declare const CacheParameterGroupAlreadyExistsFault_base: S.Class<CacheParameterGroupAlreadyExistsFault, S.TaggedStruct<"CacheParameterGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheParameterGroupAlreadyExistsFault extends /*@__PURE__*/ CacheParameterGroupAlreadyExistsFault_base {
}
declare const CacheParameterGroupNotFoundFault_base: S.Class<CacheParameterGroupNotFoundFault, S.TaggedStruct<"CacheParameterGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheParameterGroupNotFoundFault extends /*@__PURE__*/ CacheParameterGroupNotFoundFault_base {
}
declare const CacheParameterGroupQuotaExceededFault_base: S.Class<CacheParameterGroupQuotaExceededFault, S.TaggedStruct<"CacheParameterGroupQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheParameterGroupQuotaExceededFault extends /*@__PURE__*/ CacheParameterGroupQuotaExceededFault_base {
}
declare const CacheSecurityGroupAlreadyExistsFault_base: S.Class<CacheSecurityGroupAlreadyExistsFault, S.TaggedStruct<"CacheSecurityGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheSecurityGroupAlreadyExistsFault extends /*@__PURE__*/ CacheSecurityGroupAlreadyExistsFault_base {
}
declare const CacheSecurityGroupNotFoundFault_base: S.Class<CacheSecurityGroupNotFoundFault, S.TaggedStruct<"CacheSecurityGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSecurityGroupNotFoundFault extends /*@__PURE__*/ CacheSecurityGroupNotFoundFault_base {
}
declare const CacheSecurityGroupQuotaExceededFault_base: S.Class<CacheSecurityGroupQuotaExceededFault, S.TaggedStruct<"CacheSecurityGroupQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSecurityGroupQuotaExceededFault extends /*@__PURE__*/ CacheSecurityGroupQuotaExceededFault_base {
}
declare const CacheSubnetGroupAlreadyExistsFault_base: S.Class<CacheSubnetGroupAlreadyExistsFault, S.TaggedStruct<"CacheSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class CacheSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ CacheSubnetGroupAlreadyExistsFault_base {
}
declare const CacheSubnetGroupInUse_base: S.Class<CacheSubnetGroupInUse, S.TaggedStruct<"CacheSubnetGroupInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class CacheSubnetGroupInUse extends /*@__PURE__*/ CacheSubnetGroupInUse_base {
}
declare const CacheSubnetGroupNotFoundFault_base: S.Class<CacheSubnetGroupNotFoundFault, S.TaggedStruct<"CacheSubnetGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetGroupNotFoundFault extends /*@__PURE__*/ CacheSubnetGroupNotFoundFault_base {
}
declare const CacheSubnetGroupQuotaExceededFault_base: S.Class<CacheSubnetGroupQuotaExceededFault, S.TaggedStruct<"CacheSubnetGroupQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetGroupQuotaExceededFault extends /*@__PURE__*/ CacheSubnetGroupQuotaExceededFault_base {
}
declare const CacheSubnetQuotaExceededFault_base: S.Class<CacheSubnetQuotaExceededFault, S.TaggedStruct<"CacheSubnetQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CacheSubnetQuotaExceededFault extends /*@__PURE__*/ CacheSubnetQuotaExceededFault_base {
}
declare const ClusterQuotaForCustomerExceededFault_base: S.Class<ClusterQuotaForCustomerExceededFault, S.TaggedStruct<"ClusterQuotaForCustomerExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClusterQuotaForCustomerExceededFault extends /*@__PURE__*/ ClusterQuotaForCustomerExceededFault_base {
}
declare const DefaultUserAssociatedToUserGroupFault_base: S.Class<DefaultUserAssociatedToUserGroupFault, S.TaggedStruct<"DefaultUserAssociatedToUserGroupFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DefaultUserAssociatedToUserGroupFault extends /*@__PURE__*/ DefaultUserAssociatedToUserGroupFault_base {
}
declare const DefaultUserRequired_base: S.Class<DefaultUserRequired, S.TaggedStruct<"DefaultUserRequired", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DefaultUserRequired extends /*@__PURE__*/ DefaultUserRequired_base {
}
declare const DuplicateUserNameFault_base: S.Class<DuplicateUserNameFault, S.TaggedStruct<"DuplicateUserNameFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DuplicateUserNameFault extends /*@__PURE__*/ DuplicateUserNameFault_base {
}
declare const GlobalReplicationGroupAlreadyExistsFault_base: S.Class<GlobalReplicationGroupAlreadyExistsFault, S.TaggedStruct<"GlobalReplicationGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalReplicationGroupAlreadyExistsFault extends /*@__PURE__*/ GlobalReplicationGroupAlreadyExistsFault_base {
}
declare const GlobalReplicationGroupNotFoundFault_base: S.Class<GlobalReplicationGroupNotFoundFault, S.TaggedStruct<"GlobalReplicationGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalReplicationGroupNotFoundFault extends /*@__PURE__*/ GlobalReplicationGroupNotFoundFault_base {
}
declare const InsufficientCacheClusterCapacityFault_base: S.Class<InsufficientCacheClusterCapacityFault, S.TaggedStruct<"InsufficientCacheClusterCapacityFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientCacheClusterCapacityFault extends /*@__PURE__*/ InsufficientCacheClusterCapacityFault_base {
}
declare const InvalidARNFault_base: S.Class<InvalidARNFault, S.TaggedStruct<"InvalidARNFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidARNFault extends /*@__PURE__*/ InvalidARNFault_base {
}
declare const InvalidCacheClusterStateFault_base: S.Class<InvalidCacheClusterStateFault, S.TaggedStruct<"InvalidCacheClusterStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheClusterStateFault extends /*@__PURE__*/ InvalidCacheClusterStateFault_base {
}
declare const InvalidCacheParameterGroupStateFault_base: S.Class<InvalidCacheParameterGroupStateFault, S.TaggedStruct<"InvalidCacheParameterGroupStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheParameterGroupStateFault extends /*@__PURE__*/ InvalidCacheParameterGroupStateFault_base {
}
declare const InvalidCacheSecurityGroupStateFault_base: S.Class<InvalidCacheSecurityGroupStateFault, S.TaggedStruct<"InvalidCacheSecurityGroupStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCacheSecurityGroupStateFault extends /*@__PURE__*/ InvalidCacheSecurityGroupStateFault_base {
}
declare const InvalidCredentialsException_base: S.Class<InvalidCredentialsException, S.TaggedStruct<"InvalidCredentialsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class InvalidCredentialsException extends /*@__PURE__*/ InvalidCredentialsException_base {
}
declare const InvalidGlobalReplicationGroupStateFault_base: S.Class<InvalidGlobalReplicationGroupStateFault, S.TaggedStruct<"InvalidGlobalReplicationGroupStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGlobalReplicationGroupStateFault extends /*@__PURE__*/ InvalidGlobalReplicationGroupStateFault_base {
}
declare const InvalidKMSKeyFault_base: S.Class<InvalidKMSKeyFault, S.TaggedStruct<"InvalidKMSKeyFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidKMSKeyFault extends /*@__PURE__*/ InvalidKMSKeyFault_base {
}
declare const InvalidParameterCombinationException_base: S.Class<InvalidParameterCombinationException, S.TaggedStruct<"InvalidParameterCombinationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidReplicationGroupStateFault_base: S.Class<InvalidReplicationGroupStateFault, S.TaggedStruct<"InvalidReplicationGroupStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidReplicationGroupStateFault extends /*@__PURE__*/ InvalidReplicationGroupStateFault_base {
}
declare const InvalidServerlessCacheSnapshotStateFault_base: S.Class<InvalidServerlessCacheSnapshotStateFault, S.TaggedStruct<"InvalidServerlessCacheSnapshotStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidServerlessCacheSnapshotStateFault extends /*@__PURE__*/ InvalidServerlessCacheSnapshotStateFault_base {
}
declare const InvalidServerlessCacheStateFault_base: S.Class<InvalidServerlessCacheStateFault, S.TaggedStruct<"InvalidServerlessCacheStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidServerlessCacheStateFault extends /*@__PURE__*/ InvalidServerlessCacheStateFault_base {
}
declare const InvalidSnapshotStateFault_base: S.Class<InvalidSnapshotStateFault, S.TaggedStruct<"InvalidSnapshotStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSnapshotStateFault extends /*@__PURE__*/ InvalidSnapshotStateFault_base {
}
declare const InvalidSubnet_base: S.Class<InvalidSubnet, S.TaggedStruct<"InvalidSubnet", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidUserGroupStateFault_base: S.Class<InvalidUserGroupStateFault, S.TaggedStruct<"InvalidUserGroupStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserGroupStateFault extends /*@__PURE__*/ InvalidUserGroupStateFault_base {
}
declare const InvalidUserStateFault_base: S.Class<InvalidUserStateFault, S.TaggedStruct<"InvalidUserStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidUserStateFault extends /*@__PURE__*/ InvalidUserStateFault_base {
}
declare const InvalidVPCNetworkStateFault_base: S.Class<InvalidVPCNetworkStateFault, S.TaggedStruct<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const NodeGroupNotFoundFault_base: S.Class<NodeGroupNotFoundFault, S.TaggedStruct<"NodeGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeGroupNotFoundFault extends /*@__PURE__*/ NodeGroupNotFoundFault_base {
}
declare const NodeGroupsPerReplicationGroupQuotaExceededFault_base: S.Class<NodeGroupsPerReplicationGroupQuotaExceededFault, S.TaggedStruct<"NodeGroupsPerReplicationGroupQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeGroupsPerReplicationGroupQuotaExceededFault extends /*@__PURE__*/ NodeGroupsPerReplicationGroupQuotaExceededFault_base {
}
declare const NodeQuotaForClusterExceededFault_base: S.Class<NodeQuotaForClusterExceededFault, S.TaggedStruct<"NodeQuotaForClusterExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForClusterExceededFault extends /*@__PURE__*/ NodeQuotaForClusterExceededFault_base {
}
declare const NodeQuotaForCustomerExceededFault_base: S.Class<NodeQuotaForCustomerExceededFault, S.TaggedStruct<"NodeQuotaForCustomerExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NodeQuotaForCustomerExceededFault extends /*@__PURE__*/ NodeQuotaForCustomerExceededFault_base {
}
declare const NoOperationFault_base: S.Class<NoOperationFault, S.TaggedStruct<"NoOperationFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoOperationFault extends /*@__PURE__*/ NoOperationFault_base {
}
declare const ReplicationGroupAlreadyExistsFault_base: S.Class<ReplicationGroupAlreadyExistsFault, S.TaggedStruct<"ReplicationGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReplicationGroupAlreadyExistsFault extends /*@__PURE__*/ ReplicationGroupAlreadyExistsFault_base {
}
declare const ReplicationGroupAlreadyUnderMigrationFault_base: S.Class<ReplicationGroupAlreadyUnderMigrationFault, S.TaggedStruct<"ReplicationGroupAlreadyUnderMigrationFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupAlreadyUnderMigrationFault extends /*@__PURE__*/ ReplicationGroupAlreadyUnderMigrationFault_base {
}
declare const ReplicationGroupNotFoundFault_base: S.Class<ReplicationGroupNotFoundFault, S.TaggedStruct<"ReplicationGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupNotFoundFault extends /*@__PURE__*/ ReplicationGroupNotFoundFault_base {
}
declare const ReplicationGroupNotUnderMigrationFault_base: S.Class<ReplicationGroupNotUnderMigrationFault, S.TaggedStruct<"ReplicationGroupNotUnderMigrationFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReplicationGroupNotUnderMigrationFault extends /*@__PURE__*/ ReplicationGroupNotUnderMigrationFault_base {
}
declare const ReservedCacheNodeAlreadyExistsFault_base: S.Class<ReservedCacheNodeAlreadyExistsFault, S.TaggedStruct<"ReservedCacheNodeAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReservedCacheNodeAlreadyExistsFault extends /*@__PURE__*/ ReservedCacheNodeAlreadyExistsFault_base {
}
declare const ReservedCacheNodeNotFoundFault_base: S.Class<ReservedCacheNodeNotFoundFault, S.TaggedStruct<"ReservedCacheNodeNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodeNotFoundFault extends /*@__PURE__*/ ReservedCacheNodeNotFoundFault_base {
}
declare const ReservedCacheNodeQuotaExceededFault_base: S.Class<ReservedCacheNodeQuotaExceededFault, S.TaggedStruct<"ReservedCacheNodeQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodeQuotaExceededFault extends /*@__PURE__*/ ReservedCacheNodeQuotaExceededFault_base {
}
declare const ReservedCacheNodesOfferingNotFoundFault_base: S.Class<ReservedCacheNodesOfferingNotFoundFault, S.TaggedStruct<"ReservedCacheNodesOfferingNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ReservedCacheNodesOfferingNotFoundFault extends /*@__PURE__*/ ReservedCacheNodesOfferingNotFoundFault_base {
}
declare const ServerlessCacheAlreadyExistsFault_base: S.Class<ServerlessCacheAlreadyExistsFault, S.TaggedStruct<"ServerlessCacheAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ServerlessCacheAlreadyExistsFault extends /*@__PURE__*/ ServerlessCacheAlreadyExistsFault_base {
}
declare const ServerlessCacheNotFoundFault_base: S.Class<ServerlessCacheNotFoundFault, S.TaggedStruct<"ServerlessCacheNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheNotFoundFault extends /*@__PURE__*/ ServerlessCacheNotFoundFault_base {
}
declare const ServerlessCacheQuotaForCustomerExceededFault_base: S.Class<ServerlessCacheQuotaForCustomerExceededFault, S.TaggedStruct<"ServerlessCacheQuotaForCustomerExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheQuotaForCustomerExceededFault extends /*@__PURE__*/ ServerlessCacheQuotaForCustomerExceededFault_base {
}
declare const ServerlessCacheSnapshotAlreadyExistsFault_base: S.Class<ServerlessCacheSnapshotAlreadyExistsFault, S.TaggedStruct<"ServerlessCacheSnapshotAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ServerlessCacheSnapshotAlreadyExistsFault extends /*@__PURE__*/ ServerlessCacheSnapshotAlreadyExistsFault_base {
}
declare const ServerlessCacheSnapshotNotFoundFault_base: S.Class<ServerlessCacheSnapshotNotFoundFault, S.TaggedStruct<"ServerlessCacheSnapshotNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheSnapshotNotFoundFault extends /*@__PURE__*/ ServerlessCacheSnapshotNotFoundFault_base {
}
declare const ServerlessCacheSnapshotQuotaExceededFault_base: S.Class<ServerlessCacheSnapshotQuotaExceededFault, S.TaggedStruct<"ServerlessCacheSnapshotQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessCacheSnapshotQuotaExceededFault extends /*@__PURE__*/ ServerlessCacheSnapshotQuotaExceededFault_base {
}
declare const ServiceLinkedRoleNotFoundFault_base: S.Class<ServiceLinkedRoleNotFoundFault, S.TaggedStruct<"ServiceLinkedRoleNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceLinkedRoleNotFoundFault extends /*@__PURE__*/ ServiceLinkedRoleNotFoundFault_base {
}
declare const ServiceUpdateNotFoundFault_base: S.Class<ServiceUpdateNotFoundFault, S.TaggedStruct<"ServiceUpdateNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceUpdateNotFoundFault extends /*@__PURE__*/ ServiceUpdateNotFoundFault_base {
}
declare const SnapshotAlreadyExistsFault_base: S.Class<SnapshotAlreadyExistsFault, S.TaggedStruct<"SnapshotAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SnapshotAlreadyExistsFault extends /*@__PURE__*/ SnapshotAlreadyExistsFault_base {
}
declare const SnapshotFeatureNotSupportedFault_base: S.Class<SnapshotFeatureNotSupportedFault, S.TaggedStruct<"SnapshotFeatureNotSupportedFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotFeatureNotSupportedFault extends /*@__PURE__*/ SnapshotFeatureNotSupportedFault_base {
}
declare const SnapshotNotFoundFault_base: S.Class<SnapshotNotFoundFault, S.TaggedStruct<"SnapshotNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotNotFoundFault extends /*@__PURE__*/ SnapshotNotFoundFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.Class<SnapshotQuotaExceededFault, S.TaggedStruct<"SnapshotQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SubnetInUse_base: S.Class<SubnetInUse, S.TaggedStruct<"SubnetInUse", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetInUse extends /*@__PURE__*/ SubnetInUse_base {
}
declare const SubnetNotAllowedFault_base: S.Class<SubnetNotAllowedFault, S.TaggedStruct<"SubnetNotAllowedFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubnetNotAllowedFault extends /*@__PURE__*/ SubnetNotAllowedFault_base {
}
declare const TagNotFoundFault_base: S.Class<TagNotFoundFault, S.TaggedStruct<"TagNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagNotFoundFault extends /*@__PURE__*/ TagNotFoundFault_base {
}
declare const TagQuotaPerResourceExceeded_base: S.Class<TagQuotaPerResourceExceeded, S.TaggedStruct<"TagQuotaPerResourceExceeded", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagQuotaPerResourceExceeded extends /*@__PURE__*/ TagQuotaPerResourceExceeded_base {
}
declare const TestFailoverNotAvailableFault_base: S.Class<TestFailoverNotAvailableFault, S.TaggedStruct<"TestFailoverNotAvailableFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TestFailoverNotAvailableFault extends /*@__PURE__*/ TestFailoverNotAvailableFault_base {
}
declare const UserAlreadyExistsFault_base: S.Class<UserAlreadyExistsFault, S.TaggedStruct<"UserAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UserAlreadyExistsFault extends /*@__PURE__*/ UserAlreadyExistsFault_base {
}
declare const UserGroupAlreadyExistsFault_base: S.Class<UserGroupAlreadyExistsFault, S.TaggedStruct<"UserGroupAlreadyExistsFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class UserGroupAlreadyExistsFault extends /*@__PURE__*/ UserGroupAlreadyExistsFault_base {
}
declare const UserGroupNotFoundFault_base: S.Class<UserGroupNotFoundFault, S.TaggedStruct<"UserGroupNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserGroupNotFoundFault extends /*@__PURE__*/ UserGroupNotFoundFault_base {
}
declare const UserGroupQuotaExceededFault_base: S.Class<UserGroupQuotaExceededFault, S.TaggedStruct<"UserGroupQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserGroupQuotaExceededFault extends /*@__PURE__*/ UserGroupQuotaExceededFault_base {
}
declare const UserNotFoundFault_base: S.Class<UserNotFoundFault, S.TaggedStruct<"UserNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserNotFoundFault extends /*@__PURE__*/ UserNotFoundFault_base {
}
declare const UserQuotaExceededFault_base: S.Class<UserQuotaExceededFault, S.TaggedStruct<"UserQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UserQuotaExceededFault extends /*@__PURE__*/ UserQuotaExceededFault_base {
}
export interface Tag {
    Key?: string;
    Value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface AddTagsToResourceMessage {
    ResourceName?: string;
    Tags?: Tag[];
}
export declare const AddTagsToResourceMessage: S.Schema<AddTagsToResourceMessage>;
export interface TagListMessage {
    TagList?: Tag[];
}
export declare const TagListMessage: S.Schema<TagListMessage>;
export interface AuthorizeCacheSecurityGroupIngressMessage {
    CacheSecurityGroupName?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export declare const AuthorizeCacheSecurityGroupIngressMessage: S.Schema<AuthorizeCacheSecurityGroupIngressMessage>;
export interface EC2SecurityGroup {
    Status?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export declare const EC2SecurityGroup: S.Schema<EC2SecurityGroup>;
export type EC2SecurityGroupList = EC2SecurityGroup[];
export declare const EC2SecurityGroupList: any;
export interface CacheSecurityGroup {
    OwnerId?: string;
    CacheSecurityGroupName?: string;
    Description?: string;
    EC2SecurityGroups?: EC2SecurityGroup[];
    ARN?: string;
}
export declare const CacheSecurityGroup: S.Schema<CacheSecurityGroup>;
export interface AuthorizeCacheSecurityGroupIngressResult {
    CacheSecurityGroup?: CacheSecurityGroup;
}
export declare const AuthorizeCacheSecurityGroupIngressResult: S.Schema<AuthorizeCacheSecurityGroupIngressResult>;
export type ReplicationGroupIdList = string[];
export declare const ReplicationGroupIdList: any;
export type CacheClusterIdList = string[];
export declare const CacheClusterIdList: any;
export interface BatchApplyUpdateActionMessage {
    ReplicationGroupIds?: string[];
    CacheClusterIds?: string[];
    ServiceUpdateName?: string;
}
export declare const BatchApplyUpdateActionMessage: S.Schema<BatchApplyUpdateActionMessage>;
export type UpdateActionStatus = "not-applied" | "waiting-to-start" | "in-progress" | "stopping" | "stopped" | "complete" | "scheduling" | "scheduled" | "not-applicable" | (string & {});
export declare const UpdateActionStatus: any;
export interface ProcessedUpdateAction {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    ServiceUpdateName?: string;
    UpdateActionStatus?: UpdateActionStatus;
}
export declare const ProcessedUpdateAction: S.Schema<ProcessedUpdateAction>;
export type ProcessedUpdateActionList = ProcessedUpdateAction[];
export declare const ProcessedUpdateActionList: any;
export interface UnprocessedUpdateAction {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    ServiceUpdateName?: string;
    ErrorType?: string;
    ErrorMessage?: string;
}
export declare const UnprocessedUpdateAction: S.Schema<UnprocessedUpdateAction>;
export type UnprocessedUpdateActionList = UnprocessedUpdateAction[];
export declare const UnprocessedUpdateActionList: any;
export interface UpdateActionResultsMessage {
    ProcessedUpdateActions?: ProcessedUpdateAction[];
    UnprocessedUpdateActions?: UnprocessedUpdateAction[];
}
export declare const UpdateActionResultsMessage: S.Schema<UpdateActionResultsMessage>;
export interface BatchStopUpdateActionMessage {
    ReplicationGroupIds?: string[];
    CacheClusterIds?: string[];
    ServiceUpdateName?: string;
}
export declare const BatchStopUpdateActionMessage: S.Schema<BatchStopUpdateActionMessage>;
export interface CompleteMigrationMessage {
    ReplicationGroupId?: string;
    Force?: boolean;
}
export declare const CompleteMigrationMessage: S.Schema<CompleteMigrationMessage>;
export interface GlobalReplicationGroupInfo {
    GlobalReplicationGroupId?: string;
    GlobalReplicationGroupMemberRole?: string;
}
export declare const GlobalReplicationGroupInfo: S.Schema<GlobalReplicationGroupInfo>;
export type PendingAutomaticFailoverStatus = "enabled" | "disabled" | (string & {});
export declare const PendingAutomaticFailoverStatus: any;
export interface SlotMigration {
    ProgressPercentage?: number;
}
export declare const SlotMigration: S.Schema<SlotMigration>;
export interface ReshardingStatus {
    SlotMigration?: SlotMigration;
}
export declare const ReshardingStatus: S.Schema<ReshardingStatus>;
export type AuthTokenUpdateStatus = "SETTING" | "ROTATING" | (string & {});
export declare const AuthTokenUpdateStatus: any;
export type UserGroupId = string;
export type UserGroupIdList = string[];
export declare const UserGroupIdList: any;
export interface UserGroupsUpdateStatus {
    UserGroupIdsToAdd?: string[];
    UserGroupIdsToRemove?: string[];
}
export declare const UserGroupsUpdateStatus: S.Schema<UserGroupsUpdateStatus>;
export type LogType = "slow-log" | "engine-log" | (string & {});
export declare const LogType: any;
export type DestinationType = "cloudwatch-logs" | "kinesis-firehose" | (string & {});
export declare const DestinationType: any;
export interface CloudWatchLogsDestinationDetails {
    LogGroup?: string;
}
export declare const CloudWatchLogsDestinationDetails: S.Schema<CloudWatchLogsDestinationDetails>;
export interface KinesisFirehoseDestinationDetails {
    DeliveryStream?: string;
}
export declare const KinesisFirehoseDestinationDetails: S.Schema<KinesisFirehoseDestinationDetails>;
export interface DestinationDetails {
    CloudWatchLogsDetails?: CloudWatchLogsDestinationDetails;
    KinesisFirehoseDetails?: KinesisFirehoseDestinationDetails;
}
export declare const DestinationDetails: S.Schema<DestinationDetails>;
export type LogFormat = "text" | "json" | (string & {});
export declare const LogFormat: any;
export interface PendingLogDeliveryConfiguration {
    LogType?: LogType;
    DestinationType?: DestinationType;
    DestinationDetails?: DestinationDetails;
    LogFormat?: LogFormat;
}
export declare const PendingLogDeliveryConfiguration: S.Schema<PendingLogDeliveryConfiguration>;
export type PendingLogDeliveryConfigurationList = PendingLogDeliveryConfiguration[];
export declare const PendingLogDeliveryConfigurationList: any;
export type TransitEncryptionMode = "preferred" | "required" | (string & {});
export declare const TransitEncryptionMode: any;
export type ClusterMode = "enabled" | "disabled" | "compatible" | (string & {});
export declare const ClusterMode: any;
export interface ReplicationGroupPendingModifiedValues {
    PrimaryClusterId?: string;
    AutomaticFailoverStatus?: PendingAutomaticFailoverStatus;
    Resharding?: ReshardingStatus;
    AuthTokenStatus?: AuthTokenUpdateStatus;
    UserGroups?: UserGroupsUpdateStatus;
    LogDeliveryConfigurations?: PendingLogDeliveryConfiguration[];
    TransitEncryptionEnabled?: boolean;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
}
export declare const ReplicationGroupPendingModifiedValues: S.Schema<ReplicationGroupPendingModifiedValues>;
export type ClusterIdList = string[];
export declare const ClusterIdList: any;
export interface Endpoint {
    Address?: string;
    Port?: number;
}
export declare const Endpoint: S.Schema<Endpoint>;
export interface NodeGroupMember {
    CacheClusterId?: string;
    CacheNodeId?: string;
    ReadEndpoint?: Endpoint;
    PreferredAvailabilityZone?: string;
    PreferredOutpostArn?: string;
    CurrentRole?: string;
}
export declare const NodeGroupMember: S.Schema<NodeGroupMember>;
export type NodeGroupMemberList = NodeGroupMember[];
export declare const NodeGroupMemberList: any;
export interface NodeGroup {
    NodeGroupId?: string;
    Status?: string;
    PrimaryEndpoint?: Endpoint;
    ReaderEndpoint?: Endpoint;
    Slots?: string;
    NodeGroupMembers?: NodeGroupMember[];
}
export declare const NodeGroup: S.Schema<NodeGroup>;
export type NodeGroupList = NodeGroup[];
export declare const NodeGroupList: any;
export type AutomaticFailoverStatus = "enabled" | "disabled" | "enabling" | "disabling" | (string & {});
export declare const AutomaticFailoverStatus: any;
export type MultiAZStatus = "enabled" | "disabled" | (string & {});
export declare const MultiAZStatus: any;
export type ReplicationGroupOutpostArnList = string[];
export declare const ReplicationGroupOutpostArnList: any;
export type StorageEncryptionType = "none" | "sse-elasticache" | "sse-kms" | (string & {});
export declare const StorageEncryptionType: any;
export type LogDeliveryConfigurationStatus = "active" | "enabling" | "modifying" | "disabling" | "error" | (string & {});
export declare const LogDeliveryConfigurationStatus: any;
export interface LogDeliveryConfiguration {
    LogType?: LogType;
    DestinationType?: DestinationType;
    DestinationDetails?: DestinationDetails;
    LogFormat?: LogFormat;
    Status?: LogDeliveryConfigurationStatus;
    Message?: string;
}
export declare const LogDeliveryConfiguration: S.Schema<LogDeliveryConfiguration>;
export type LogDeliveryConfigurationList = LogDeliveryConfiguration[];
export declare const LogDeliveryConfigurationList: any;
export type DataTieringStatus = "enabled" | "disabled" | (string & {});
export declare const DataTieringStatus: any;
export type NetworkType = "ipv4" | "ipv6" | "dual_stack" | (string & {});
export declare const NetworkType: any;
export type IpDiscovery = "ipv4" | "ipv6" | (string & {});
export declare const IpDiscovery: any;
export type Durability = "default" | "async" | "sync" | "disabled" | (string & {});
export declare const Durability: any;
export type EffectiveDurability = "async" | "sync" | "disabled" | (string & {});
export declare const EffectiveDurability: any;
export interface ReplicationGroup {
    ReplicationGroupId?: string;
    Description?: string;
    GlobalReplicationGroupInfo?: GlobalReplicationGroupInfo;
    Status?: string;
    PendingModifiedValues?: ReplicationGroupPendingModifiedValues;
    MemberClusters?: string[];
    NodeGroups?: NodeGroup[];
    SnapshottingClusterId?: string;
    AutomaticFailover?: AutomaticFailoverStatus;
    MultiAZ?: MultiAZStatus;
    ConfigurationEndpoint?: Endpoint;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    ClusterEnabled?: boolean;
    CacheNodeType?: string;
    AuthTokenEnabled?: boolean;
    AuthTokenLastModifiedDate?: Date;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    MemberClustersOutpostArns?: string[];
    KmsKeyId?: string;
    StorageEncryptionType?: StorageEncryptionType;
    ARN?: string;
    UserGroupIds?: string[];
    LogDeliveryConfigurations?: LogDeliveryConfiguration[];
    ReplicationGroupCreateTime?: Date;
    DataTiering?: DataTieringStatus;
    AutoMinorVersionUpgrade?: boolean;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
    Engine?: string;
    Durability?: Durability;
    EffectiveDurability?: EffectiveDurability;
}
export declare const ReplicationGroup: S.Schema<ReplicationGroup>;
export interface CompleteMigrationResponse {
    ReplicationGroup?: ReplicationGroup;
}
export declare const CompleteMigrationResponse: S.Schema<CompleteMigrationResponse>;
export interface CopyServerlessCacheSnapshotRequest {
    SourceServerlessCacheSnapshotName?: string;
    TargetServerlessCacheSnapshotName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export declare const CopyServerlessCacheSnapshotRequest: S.Schema<CopyServerlessCacheSnapshotRequest>;
export interface ServerlessCacheConfiguration {
    ServerlessCacheName?: string;
    Engine?: string;
    MajorEngineVersion?: string;
}
export declare const ServerlessCacheConfiguration: S.Schema<ServerlessCacheConfiguration>;
export interface ServerlessCacheSnapshot {
    ServerlessCacheSnapshotName?: string;
    ARN?: string;
    KmsKeyId?: string;
    SnapshotType?: string;
    Status?: string;
    CreateTime?: Date;
    ExpiryTime?: Date;
    BytesUsedForCache?: string;
    ServerlessCacheConfiguration?: ServerlessCacheConfiguration;
}
export declare const ServerlessCacheSnapshot: S.Schema<ServerlessCacheSnapshot>;
export interface CopyServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export declare const CopyServerlessCacheSnapshotResponse: S.Schema<CopyServerlessCacheSnapshotResponse>;
export interface CopySnapshotMessage {
    SourceSnapshotName?: string;
    TargetSnapshotName?: string;
    TargetBucket?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export declare const CopySnapshotMessage: S.Schema<CopySnapshotMessage>;
export type AllowedNodeGroupId = string;
export type AvailabilityZonesList = string[];
export declare const AvailabilityZonesList: any;
export type OutpostArnsList = string[];
export declare const OutpostArnsList: any;
export interface NodeGroupConfiguration {
    NodeGroupId?: string;
    Slots?: string;
    ReplicaCount?: number;
    PrimaryAvailabilityZone?: string;
    ReplicaAvailabilityZones?: string[];
    PrimaryOutpostArn?: string;
    ReplicaOutpostArns?: string[];
}
export declare const NodeGroupConfiguration: S.Schema<NodeGroupConfiguration>;
export interface NodeSnapshot {
    CacheClusterId?: string;
    NodeGroupId?: string;
    CacheNodeId?: string;
    NodeGroupConfiguration?: NodeGroupConfiguration;
    CacheSize?: string;
    CacheNodeCreateTime?: Date;
    SnapshotCreateTime?: Date;
}
export declare const NodeSnapshot: S.Schema<NodeSnapshot>;
export type NodeSnapshotList = NodeSnapshot[];
export declare const NodeSnapshotList: any;
export interface Snapshot {
    SnapshotName?: string;
    ReplicationGroupId?: string;
    ReplicationGroupDescription?: string;
    CacheClusterId?: string;
    SnapshotStatus?: string;
    SnapshotSource?: string;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    NumCacheNodes?: number;
    PreferredAvailabilityZone?: string;
    PreferredOutpostArn?: string;
    CacheClusterCreateTime?: Date;
    PreferredMaintenanceWindow?: string;
    TopicArn?: string;
    Port?: number;
    CacheParameterGroupName?: string;
    CacheSubnetGroupName?: string;
    VpcId?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    NumNodeGroups?: number;
    AutomaticFailover?: AutomaticFailoverStatus;
    NodeSnapshots?: NodeSnapshot[];
    KmsKeyId?: string;
    ARN?: string;
    DataTiering?: DataTieringStatus;
    Durability?: Durability;
}
export declare const Snapshot: S.Schema<Snapshot>;
export interface CopySnapshotResult {
    Snapshot?: Snapshot;
}
export declare const CopySnapshotResult: S.Schema<CopySnapshotResult>;
export type AZMode = "single-az" | "cross-az" | (string & {});
export declare const AZMode: any;
export type PreferredAvailabilityZoneList = string[];
export declare const PreferredAvailabilityZoneList: any;
export type CacheSecurityGroupNameList = string[];
export declare const CacheSecurityGroupNameList: any;
export type SecurityGroupIdsList = string[];
export declare const SecurityGroupIdsList: any;
export type SnapshotArnsList = string[];
export declare const SnapshotArnsList: any;
export type OutpostMode = "single-outpost" | "cross-outpost" | (string & {});
export declare const OutpostMode: any;
export type PreferredOutpostArnList = string[];
export declare const PreferredOutpostArnList: any;
export interface LogDeliveryConfigurationRequest {
    LogType?: LogType;
    DestinationType?: DestinationType;
    DestinationDetails?: DestinationDetails;
    LogFormat?: LogFormat;
    Enabled?: boolean;
}
export declare const LogDeliveryConfigurationRequest: S.Schema<LogDeliveryConfigurationRequest>;
export type LogDeliveryConfigurationRequestList = LogDeliveryConfigurationRequest[];
export declare const LogDeliveryConfigurationRequestList: any;
export interface CreateCacheClusterMessage {
    CacheClusterId?: string;
    ReplicationGroupId?: string;
    AZMode?: AZMode;
    PreferredAvailabilityZone?: string;
    PreferredAvailabilityZones?: string[];
    NumCacheNodes?: number;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupName?: string;
    CacheSubnetGroupName?: string;
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    Tags?: Tag[];
    SnapshotArns?: string[];
    SnapshotName?: string;
    PreferredMaintenanceWindow?: string;
    Port?: number;
    NotificationTopicArn?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    AuthToken?: string | redacted.Redacted<string>;
    OutpostMode?: OutpostMode;
    PreferredOutpostArn?: string;
    PreferredOutpostArns?: string[];
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    TransitEncryptionEnabled?: boolean;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
}
export declare const CreateCacheClusterMessage: S.Schema<CreateCacheClusterMessage>;
export type CacheNodeIdsList = string[];
export declare const CacheNodeIdsList: any;
export interface ScaleConfig {
    ScalePercentage?: number;
    ScaleIntervalMinutes?: number;
}
export declare const ScaleConfig: S.Schema<ScaleConfig>;
export interface PendingModifiedValues {
    NumCacheNodes?: number;
    CacheNodeIdsToRemove?: string[];
    EngineVersion?: string;
    CacheNodeType?: string;
    AuthTokenStatus?: AuthTokenUpdateStatus;
    LogDeliveryConfigurations?: PendingLogDeliveryConfiguration[];
    TransitEncryptionEnabled?: boolean;
    TransitEncryptionMode?: TransitEncryptionMode;
    ScaleConfig?: ScaleConfig;
}
export declare const PendingModifiedValues: S.Schema<PendingModifiedValues>;
export interface NotificationConfiguration {
    TopicArn?: string;
    TopicStatus?: string;
}
export declare const NotificationConfiguration: S.Schema<NotificationConfiguration>;
export interface CacheSecurityGroupMembership {
    CacheSecurityGroupName?: string;
    Status?: string;
}
export declare const CacheSecurityGroupMembership: S.Schema<CacheSecurityGroupMembership>;
export type CacheSecurityGroupMembershipList = CacheSecurityGroupMembership[];
export declare const CacheSecurityGroupMembershipList: any;
export interface CacheParameterGroupStatus {
    CacheParameterGroupName?: string;
    ParameterApplyStatus?: string;
    CacheNodeIdsToReboot?: string[];
}
export declare const CacheParameterGroupStatus: S.Schema<CacheParameterGroupStatus>;
export interface CacheNode {
    CacheNodeId?: string;
    CacheNodeStatus?: string;
    CacheNodeCreateTime?: Date;
    Endpoint?: Endpoint;
    ParameterGroupStatus?: string;
    SourceCacheNodeId?: string;
    CustomerAvailabilityZone?: string;
    CustomerOutpostArn?: string;
}
export declare const CacheNode: S.Schema<CacheNode>;
export type CacheNodeList = CacheNode[];
export declare const CacheNodeList: any;
export interface SecurityGroupMembership {
    SecurityGroupId?: string;
    Status?: string;
}
export declare const SecurityGroupMembership: S.Schema<SecurityGroupMembership>;
export type SecurityGroupMembershipList = SecurityGroupMembership[];
export declare const SecurityGroupMembershipList: any;
export interface CacheCluster {
    CacheClusterId?: string;
    ConfigurationEndpoint?: Endpoint;
    ClientDownloadLandingPage?: string;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheClusterStatus?: string;
    NumCacheNodes?: number;
    PreferredAvailabilityZone?: string;
    PreferredOutpostArn?: string;
    CacheClusterCreateTime?: Date;
    PreferredMaintenanceWindow?: string;
    PendingModifiedValues?: PendingModifiedValues;
    NotificationConfiguration?: NotificationConfiguration;
    CacheSecurityGroups?: CacheSecurityGroupMembership[];
    CacheParameterGroup?: CacheParameterGroupStatus;
    CacheSubnetGroupName?: string;
    CacheNodes?: CacheNode[];
    AutoMinorVersionUpgrade?: boolean;
    SecurityGroups?: SecurityGroupMembership[];
    ReplicationGroupId?: string;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    AuthTokenEnabled?: boolean;
    AuthTokenLastModifiedDate?: Date;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    ARN?: string;
    ReplicationGroupLogDeliveryEnabled?: boolean;
    LogDeliveryConfigurations?: LogDeliveryConfiguration[];
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
    TransitEncryptionMode?: TransitEncryptionMode;
}
export declare const CacheCluster: S.Schema<CacheCluster>;
export interface CreateCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export declare const CreateCacheClusterResult: S.Schema<CreateCacheClusterResult>;
export interface CreateCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
    CacheParameterGroupFamily?: string;
    Description?: string;
    Tags?: Tag[];
}
export declare const CreateCacheParameterGroupMessage: S.Schema<CreateCacheParameterGroupMessage>;
export interface CacheParameterGroup {
    CacheParameterGroupName?: string;
    CacheParameterGroupFamily?: string;
    Description?: string;
    IsGlobal?: boolean;
    ARN?: string;
}
export declare const CacheParameterGroup: S.Schema<CacheParameterGroup>;
export interface CreateCacheParameterGroupResult {
    CacheParameterGroup?: CacheParameterGroup;
}
export declare const CreateCacheParameterGroupResult: S.Schema<CreateCacheParameterGroupResult>;
export interface CreateCacheSecurityGroupMessage {
    CacheSecurityGroupName?: string;
    Description?: string;
    Tags?: Tag[];
}
export declare const CreateCacheSecurityGroupMessage: S.Schema<CreateCacheSecurityGroupMessage>;
export interface CreateCacheSecurityGroupResult {
    CacheSecurityGroup?: CacheSecurityGroup;
}
export declare const CreateCacheSecurityGroupResult: S.Schema<CreateCacheSecurityGroupResult>;
export type SubnetIdentifierList = string[];
export declare const SubnetIdentifierList: any;
export interface CreateCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string;
    CacheSubnetGroupDescription?: string;
    SubnetIds?: string[];
    Tags?: Tag[];
}
export declare const CreateCacheSubnetGroupMessage: S.Schema<CreateCacheSubnetGroupMessage>;
export interface AvailabilityZone {
    Name?: string;
}
export declare const AvailabilityZone: S.Schema<AvailabilityZone>;
export interface SubnetOutpost {
    SubnetOutpostArn?: string;
}
export declare const SubnetOutpost: S.Schema<SubnetOutpost>;
export type NetworkTypeList = NetworkType[];
export declare const NetworkTypeList: any;
export interface Subnet {
    SubnetIdentifier?: string;
    SubnetAvailabilityZone?: AvailabilityZone;
    SubnetOutpost?: SubnetOutpost;
    SupportedNetworkTypes?: NetworkType[];
}
export declare const Subnet: S.Schema<Subnet>;
export type SubnetList = Subnet[];
export declare const SubnetList: any;
export interface CacheSubnetGroup {
    CacheSubnetGroupName?: string;
    CacheSubnetGroupDescription?: string;
    VpcId?: string;
    Subnets?: Subnet[];
    ARN?: string;
    SupportedNetworkTypes?: NetworkType[];
}
export declare const CacheSubnetGroup: S.Schema<CacheSubnetGroup>;
export interface CreateCacheSubnetGroupResult {
    CacheSubnetGroup?: CacheSubnetGroup;
}
export declare const CreateCacheSubnetGroupResult: S.Schema<CreateCacheSubnetGroupResult>;
export interface CreateGlobalReplicationGroupMessage {
    GlobalReplicationGroupIdSuffix?: string;
    GlobalReplicationGroupDescription?: string;
    PrimaryReplicationGroupId?: string;
}
export declare const CreateGlobalReplicationGroupMessage: S.Schema<CreateGlobalReplicationGroupMessage>;
export interface GlobalReplicationGroupMember {
    ReplicationGroupId?: string;
    ReplicationGroupRegion?: string;
    Role?: string;
    AutomaticFailover?: AutomaticFailoverStatus;
    Status?: string;
}
export declare const GlobalReplicationGroupMember: S.Schema<GlobalReplicationGroupMember>;
export type GlobalReplicationGroupMemberList = GlobalReplicationGroupMember[];
export declare const GlobalReplicationGroupMemberList: any;
export interface GlobalNodeGroup {
    GlobalNodeGroupId?: string;
    Slots?: string;
}
export declare const GlobalNodeGroup: S.Schema<GlobalNodeGroup>;
export type GlobalNodeGroupList = GlobalNodeGroup[];
export declare const GlobalNodeGroupList: any;
export interface GlobalReplicationGroup {
    GlobalReplicationGroupId?: string;
    GlobalReplicationGroupDescription?: string;
    Status?: string;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    Members?: GlobalReplicationGroupMember[];
    ClusterEnabled?: boolean;
    GlobalNodeGroups?: GlobalNodeGroup[];
    AuthTokenEnabled?: boolean;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    ARN?: string;
}
export declare const GlobalReplicationGroup: S.Schema<GlobalReplicationGroup>;
export interface CreateGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const CreateGlobalReplicationGroupResult: S.Schema<CreateGlobalReplicationGroupResult>;
export type NodeGroupConfigurationList = NodeGroupConfiguration[];
export declare const NodeGroupConfigurationList: any;
export type UserGroupIdListInput = string[];
export declare const UserGroupIdListInput: any;
export interface CreateReplicationGroupMessage {
    ReplicationGroupId?: string;
    ReplicationGroupDescription?: string;
    GlobalReplicationGroupId?: string;
    PrimaryClusterId?: string;
    AutomaticFailoverEnabled?: boolean;
    MultiAZEnabled?: boolean;
    NumCacheClusters?: number;
    PreferredCacheClusterAZs?: string[];
    NumNodeGroups?: number;
    ReplicasPerNodeGroup?: number;
    NodeGroupConfiguration?: NodeGroupConfiguration[];
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupName?: string;
    CacheSubnetGroupName?: string;
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    Tags?: Tag[];
    SnapshotArns?: string[];
    SnapshotName?: string;
    PreferredMaintenanceWindow?: string;
    Port?: number;
    NotificationTopicArn?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    AuthToken?: string | redacted.Redacted<string>;
    TransitEncryptionEnabled?: boolean;
    AtRestEncryptionEnabled?: boolean;
    KmsKeyId?: string;
    UserGroupIds?: string[];
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    DataTieringEnabled?: boolean;
    NetworkType?: NetworkType;
    IpDiscovery?: IpDiscovery;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
    ServerlessCacheSnapshotName?: string;
    Durability?: Durability;
}
export declare const CreateReplicationGroupMessage: S.Schema<CreateReplicationGroupMessage>;
export interface CreateReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup;
}
export declare const CreateReplicationGroupResult: S.Schema<CreateReplicationGroupResult>;
export type DataStorageUnit = "GB" | (string & {});
export declare const DataStorageUnit: any;
export interface DataStorage {
    Maximum?: number;
    Minimum?: number;
    Unit?: DataStorageUnit;
}
export declare const DataStorage: S.Schema<DataStorage>;
export interface ECPUPerSecond {
    Maximum?: number;
    Minimum?: number;
}
export declare const ECPUPerSecond: S.Schema<ECPUPerSecond>;
export interface CacheUsageLimits {
    DataStorage?: DataStorage;
    ECPUPerSecond?: ECPUPerSecond;
}
export declare const CacheUsageLimits: S.Schema<CacheUsageLimits>;
export type SubnetIdsList = string[];
export declare const SubnetIdsList: any;
export interface CreateServerlessCacheRequest {
    ServerlessCacheName?: string;
    Description?: string;
    Engine?: string;
    MajorEngineVersion?: string;
    CacheUsageLimits?: CacheUsageLimits;
    KmsKeyId?: string;
    SecurityGroupIds?: string[];
    SnapshotArnsToRestore?: string[];
    Tags?: Tag[];
    UserGroupId?: string;
    SubnetIds?: string[];
    SnapshotRetentionLimit?: number;
    DailySnapshotTime?: string;
    NetworkType?: NetworkType;
}
export declare const CreateServerlessCacheRequest: S.Schema<CreateServerlessCacheRequest>;
export interface ServerlessCache {
    ServerlessCacheName?: string;
    Description?: string;
    CreateTime?: Date;
    Status?: string;
    Engine?: string;
    MajorEngineVersion?: string;
    FullEngineVersion?: string;
    CacheUsageLimits?: CacheUsageLimits;
    KmsKeyId?: string;
    StorageEncryptionType?: StorageEncryptionType;
    SecurityGroupIds?: string[];
    Endpoint?: Endpoint;
    ReaderEndpoint?: Endpoint;
    ARN?: string;
    UserGroupId?: string;
    SubnetIds?: string[];
    SnapshotRetentionLimit?: number;
    DailySnapshotTime?: string;
    NetworkType?: NetworkType;
}
export declare const ServerlessCache: S.Schema<ServerlessCache>;
export interface CreateServerlessCacheResponse {
    ServerlessCache?: ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    };
}
export declare const CreateServerlessCacheResponse: S.Schema<CreateServerlessCacheResponse>;
export interface CreateServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string;
    ServerlessCacheName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export declare const CreateServerlessCacheSnapshotRequest: S.Schema<CreateServerlessCacheSnapshotRequest>;
export interface CreateServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export declare const CreateServerlessCacheSnapshotResponse: S.Schema<CreateServerlessCacheSnapshotResponse>;
export interface CreateSnapshotMessage {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    SnapshotName?: string;
    KmsKeyId?: string;
    Tags?: Tag[];
}
export declare const CreateSnapshotMessage: S.Schema<CreateSnapshotMessage>;
export interface CreateSnapshotResult {
    Snapshot?: Snapshot;
}
export declare const CreateSnapshotResult: S.Schema<CreateSnapshotResult>;
export type UserId = string;
export type UserName = string;
export type EngineType = string;
export type PasswordListInput = string[];
export declare const PasswordListInput: any;
export type AccessString = string;
export type InputAuthenticationType = "password" | "no-password-required" | "iam" | (string & {});
export declare const InputAuthenticationType: any;
export interface AuthenticationMode {
    Type?: InputAuthenticationType;
    Passwords?: Array<string | redacted.Redacted<string>>;
}
export declare const AuthenticationMode: S.Schema<AuthenticationMode>;
export interface CreateUserMessage {
    UserId?: string;
    UserName?: string;
    Engine?: string;
    Passwords?: Array<string | redacted.Redacted<string>>;
    AccessString?: string;
    NoPasswordRequired?: boolean;
    Tags?: Tag[];
    AuthenticationMode?: AuthenticationMode;
}
export declare const CreateUserMessage: S.Schema<CreateUserMessage>;
export type AuthenticationType = "password" | "no-password" | "iam" | (string & {});
export declare const AuthenticationType: any;
export interface Authentication {
    Type?: AuthenticationType;
    PasswordCount?: number;
}
export declare const Authentication: S.Schema<Authentication>;
export interface User {
    UserId?: string;
    UserName?: string;
    Status?: string;
    Engine?: string;
    MinimumEngineVersion?: string;
    AccessString?: string;
    UserGroupIds?: string[];
    Authentication?: Authentication;
    ARN?: string;
}
export declare const User: S.Schema<User>;
export type UserIdListInput = string[];
export declare const UserIdListInput: any;
export interface CreateUserGroupMessage {
    UserGroupId?: string;
    Engine?: string;
    UserIds?: string[];
    Tags?: Tag[];
}
export declare const CreateUserGroupMessage: S.Schema<CreateUserGroupMessage>;
export type UserIdList = string[];
export declare const UserIdList: any;
export interface UserGroupPendingChanges {
    UserIdsToRemove?: string[];
    UserIdsToAdd?: string[];
}
export declare const UserGroupPendingChanges: S.Schema<UserGroupPendingChanges>;
export type UGReplicationGroupIdList = string[];
export declare const UGReplicationGroupIdList: any;
export type UGServerlessCacheIdList = string[];
export declare const UGServerlessCacheIdList: any;
export interface UserGroup {
    UserGroupId?: string;
    Status?: string;
    Engine?: string;
    UserIds?: string[];
    MinimumEngineVersion?: string;
    PendingChanges?: UserGroupPendingChanges;
    ReplicationGroups?: string[];
    ServerlessCaches?: string[];
    ARN?: string;
}
export declare const UserGroup: S.Schema<UserGroup>;
export type GlobalNodeGroupIdList = string[];
export declare const GlobalNodeGroupIdList: any;
export interface DecreaseNodeGroupsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    NodeGroupCount?: number;
    GlobalNodeGroupsToRemove?: string[];
    GlobalNodeGroupsToRetain?: string[];
    ApplyImmediately?: boolean;
}
export declare const DecreaseNodeGroupsInGlobalReplicationGroupMessage: S.Schema<DecreaseNodeGroupsInGlobalReplicationGroupMessage>;
export interface DecreaseNodeGroupsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const DecreaseNodeGroupsInGlobalReplicationGroupResult: S.Schema<DecreaseNodeGroupsInGlobalReplicationGroupResult>;
export interface ConfigureShard {
    NodeGroupId?: string;
    NewReplicaCount?: number;
    PreferredAvailabilityZones?: string[];
    PreferredOutpostArns?: string[];
}
export declare const ConfigureShard: S.Schema<ConfigureShard>;
export type ReplicaConfigurationList = ConfigureShard[];
export declare const ReplicaConfigurationList: any;
export type RemoveReplicasList = string[];
export declare const RemoveReplicasList: any;
export interface DecreaseReplicaCountMessage {
    ReplicationGroupId?: string;
    NewReplicaCount?: number;
    ReplicaConfiguration?: ConfigureShard[];
    ReplicasToRemove?: string[];
    ApplyImmediately?: boolean;
}
export declare const DecreaseReplicaCountMessage: S.Schema<DecreaseReplicaCountMessage>;
export interface DecreaseReplicaCountResult {
    ReplicationGroup?: ReplicationGroup;
}
export declare const DecreaseReplicaCountResult: S.Schema<DecreaseReplicaCountResult>;
export interface DeleteCacheClusterMessage {
    CacheClusterId?: string;
    FinalSnapshotIdentifier?: string;
}
export declare const DeleteCacheClusterMessage: S.Schema<DeleteCacheClusterMessage>;
export interface DeleteCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export declare const DeleteCacheClusterResult: S.Schema<DeleteCacheClusterResult>;
export interface DeleteCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
}
export declare const DeleteCacheParameterGroupMessage: S.Schema<DeleteCacheParameterGroupMessage>;
export interface DeleteCacheParameterGroupResponse {
}
export declare const DeleteCacheParameterGroupResponse: S.Schema<DeleteCacheParameterGroupResponse>;
export interface DeleteCacheSecurityGroupMessage {
    CacheSecurityGroupName?: string;
}
export declare const DeleteCacheSecurityGroupMessage: S.Schema<DeleteCacheSecurityGroupMessage>;
export interface DeleteCacheSecurityGroupResponse {
}
export declare const DeleteCacheSecurityGroupResponse: S.Schema<DeleteCacheSecurityGroupResponse>;
export interface DeleteCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string;
}
export declare const DeleteCacheSubnetGroupMessage: S.Schema<DeleteCacheSubnetGroupMessage>;
export interface DeleteCacheSubnetGroupResponse {
}
export declare const DeleteCacheSubnetGroupResponse: S.Schema<DeleteCacheSubnetGroupResponse>;
export interface DeleteGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    RetainPrimaryReplicationGroup?: boolean;
}
export declare const DeleteGlobalReplicationGroupMessage: S.Schema<DeleteGlobalReplicationGroupMessage>;
export interface DeleteGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const DeleteGlobalReplicationGroupResult: S.Schema<DeleteGlobalReplicationGroupResult>;
export interface DeleteReplicationGroupMessage {
    ReplicationGroupId?: string;
    RetainPrimaryCluster?: boolean;
    FinalSnapshotIdentifier?: string;
}
export declare const DeleteReplicationGroupMessage: S.Schema<DeleteReplicationGroupMessage>;
export interface DeleteReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup;
}
export declare const DeleteReplicationGroupResult: S.Schema<DeleteReplicationGroupResult>;
export interface DeleteServerlessCacheRequest {
    ServerlessCacheName?: string;
    FinalSnapshotName?: string;
}
export declare const DeleteServerlessCacheRequest: S.Schema<DeleteServerlessCacheRequest>;
export interface DeleteServerlessCacheResponse {
    ServerlessCache?: ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    };
}
export declare const DeleteServerlessCacheResponse: S.Schema<DeleteServerlessCacheResponse>;
export interface DeleteServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string;
}
export declare const DeleteServerlessCacheSnapshotRequest: S.Schema<DeleteServerlessCacheSnapshotRequest>;
export interface DeleteServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export declare const DeleteServerlessCacheSnapshotResponse: S.Schema<DeleteServerlessCacheSnapshotResponse>;
export interface DeleteSnapshotMessage {
    SnapshotName?: string;
}
export declare const DeleteSnapshotMessage: S.Schema<DeleteSnapshotMessage>;
export interface DeleteSnapshotResult {
    Snapshot?: Snapshot;
}
export declare const DeleteSnapshotResult: S.Schema<DeleteSnapshotResult>;
export interface DeleteUserMessage {
    UserId?: string;
}
export declare const DeleteUserMessage: S.Schema<DeleteUserMessage>;
export interface DeleteUserGroupMessage {
    UserGroupId?: string;
}
export declare const DeleteUserGroupMessage: S.Schema<DeleteUserGroupMessage>;
export interface DescribeCacheClustersMessage {
    CacheClusterId?: string;
    MaxRecords?: number;
    Marker?: string;
    ShowCacheNodeInfo?: boolean;
    ShowCacheClustersNotInReplicationGroups?: boolean;
}
export declare const DescribeCacheClustersMessage: S.Schema<DescribeCacheClustersMessage>;
export type CacheClusterList = CacheCluster[];
export declare const CacheClusterList: any;
export interface CacheClusterMessage {
    Marker?: string;
    CacheClusters?: CacheCluster[];
}
export declare const CacheClusterMessage: S.Schema<CacheClusterMessage>;
export interface DescribeCacheEngineVersionsMessage {
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupFamily?: string;
    MaxRecords?: number;
    Marker?: string;
    DefaultOnly?: boolean;
}
export declare const DescribeCacheEngineVersionsMessage: S.Schema<DescribeCacheEngineVersionsMessage>;
export interface CacheEngineVersion {
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupFamily?: string;
    CacheEngineDescription?: string;
    CacheEngineVersionDescription?: string;
}
export declare const CacheEngineVersion: S.Schema<CacheEngineVersion>;
export type CacheEngineVersionList = CacheEngineVersion[];
export declare const CacheEngineVersionList: any;
export interface CacheEngineVersionMessage {
    Marker?: string;
    CacheEngineVersions?: CacheEngineVersion[];
}
export declare const CacheEngineVersionMessage: S.Schema<CacheEngineVersionMessage>;
export interface DescribeCacheParameterGroupsMessage {
    CacheParameterGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeCacheParameterGroupsMessage: S.Schema<DescribeCacheParameterGroupsMessage>;
export type CacheParameterGroupList = CacheParameterGroup[];
export declare const CacheParameterGroupList: any;
export interface CacheParameterGroupsMessage {
    Marker?: string;
    CacheParameterGroups?: CacheParameterGroup[];
}
export declare const CacheParameterGroupsMessage: S.Schema<CacheParameterGroupsMessage>;
export interface DescribeCacheParametersMessage {
    CacheParameterGroupName?: string;
    Source?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeCacheParametersMessage: S.Schema<DescribeCacheParametersMessage>;
export type ChangeType = "immediate" | "requires-reboot" | (string & {});
export declare const ChangeType: any;
export interface Parameter {
    ParameterName?: string;
    ParameterValue?: string;
    Description?: string;
    Source?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    MinimumEngineVersion?: string;
    ChangeType?: ChangeType;
}
export declare const Parameter: S.Schema<Parameter>;
export type ParametersList = Parameter[];
export declare const ParametersList: any;
export interface CacheNodeTypeSpecificValue {
    CacheNodeType?: string;
    Value?: string;
}
export declare const CacheNodeTypeSpecificValue: S.Schema<CacheNodeTypeSpecificValue>;
export type CacheNodeTypeSpecificValueList = CacheNodeTypeSpecificValue[];
export declare const CacheNodeTypeSpecificValueList: any;
export interface CacheNodeTypeSpecificParameter {
    ParameterName?: string;
    Description?: string;
    Source?: string;
    DataType?: string;
    AllowedValues?: string;
    IsModifiable?: boolean;
    MinimumEngineVersion?: string;
    CacheNodeTypeSpecificValues?: CacheNodeTypeSpecificValue[];
    ChangeType?: ChangeType;
}
export declare const CacheNodeTypeSpecificParameter: S.Schema<CacheNodeTypeSpecificParameter>;
export type CacheNodeTypeSpecificParametersList = CacheNodeTypeSpecificParameter[];
export declare const CacheNodeTypeSpecificParametersList: any;
export interface CacheParameterGroupDetails {
    Marker?: string;
    Parameters?: Parameter[];
    CacheNodeTypeSpecificParameters?: CacheNodeTypeSpecificParameter[];
}
export declare const CacheParameterGroupDetails: S.Schema<CacheParameterGroupDetails>;
export interface DescribeCacheSecurityGroupsMessage {
    CacheSecurityGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeCacheSecurityGroupsMessage: S.Schema<DescribeCacheSecurityGroupsMessage>;
export type CacheSecurityGroups = CacheSecurityGroup[];
export declare const CacheSecurityGroups: any;
export interface CacheSecurityGroupMessage {
    Marker?: string;
    CacheSecurityGroups?: CacheSecurityGroup[];
}
export declare const CacheSecurityGroupMessage: S.Schema<CacheSecurityGroupMessage>;
export interface DescribeCacheSubnetGroupsMessage {
    CacheSubnetGroupName?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeCacheSubnetGroupsMessage: S.Schema<DescribeCacheSubnetGroupsMessage>;
export type CacheSubnetGroups = CacheSubnetGroup[];
export declare const CacheSubnetGroups: any;
export interface CacheSubnetGroupMessage {
    Marker?: string;
    CacheSubnetGroups?: CacheSubnetGroup[];
}
export declare const CacheSubnetGroupMessage: S.Schema<CacheSubnetGroupMessage>;
export interface DescribeEngineDefaultParametersMessage {
    CacheParameterGroupFamily?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEngineDefaultParametersMessage: S.Schema<DescribeEngineDefaultParametersMessage>;
export interface EngineDefaults {
    CacheParameterGroupFamily?: string;
    Marker?: string;
    Parameters?: Parameter[];
    CacheNodeTypeSpecificParameters?: CacheNodeTypeSpecificParameter[];
}
export declare const EngineDefaults: S.Schema<EngineDefaults>;
export interface DescribeEngineDefaultParametersResult {
    EngineDefaults?: EngineDefaults;
}
export declare const DescribeEngineDefaultParametersResult: S.Schema<DescribeEngineDefaultParametersResult>;
export type SourceType = "cache-cluster" | "cache-parameter-group" | "cache-security-group" | "cache-subnet-group" | "replication-group" | "serverless-cache" | "serverless-cache-snapshot" | "user" | "user-group" | (string & {});
export declare const SourceType: any;
export interface DescribeEventsMessage {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    StartTime?: Date;
    EndTime?: Date;
    Duration?: number;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeEventsMessage: S.Schema<DescribeEventsMessage>;
export interface Event {
    SourceIdentifier?: string;
    SourceType?: SourceType;
    Message?: string;
    Date?: Date;
}
export declare const Event: S.Schema<Event>;
export type EventList = Event[];
export declare const EventList: any;
export interface EventsMessage {
    Marker?: string;
    Events?: Event[];
}
export declare const EventsMessage: S.Schema<EventsMessage>;
export interface DescribeGlobalReplicationGroupsMessage {
    GlobalReplicationGroupId?: string;
    MaxRecords?: number;
    Marker?: string;
    ShowMemberInfo?: boolean;
}
export declare const DescribeGlobalReplicationGroupsMessage: S.Schema<DescribeGlobalReplicationGroupsMessage>;
export type GlobalReplicationGroupList = GlobalReplicationGroup[];
export declare const GlobalReplicationGroupList: any;
export interface DescribeGlobalReplicationGroupsResult {
    Marker?: string;
    GlobalReplicationGroups?: GlobalReplicationGroup[];
}
export declare const DescribeGlobalReplicationGroupsResult: S.Schema<DescribeGlobalReplicationGroupsResult>;
export interface DescribeReplicationGroupsMessage {
    ReplicationGroupId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReplicationGroupsMessage: S.Schema<DescribeReplicationGroupsMessage>;
export type ReplicationGroupList = ReplicationGroup[];
export declare const ReplicationGroupList: any;
export interface ReplicationGroupMessage {
    Marker?: string;
    ReplicationGroups?: ReplicationGroup[];
}
export declare const ReplicationGroupMessage: S.Schema<ReplicationGroupMessage>;
export interface DescribeReservedCacheNodesMessage {
    ReservedCacheNodeId?: string;
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    Duration?: string;
    ProductDescription?: string;
    OfferingType?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReservedCacheNodesMessage: S.Schema<DescribeReservedCacheNodesMessage>;
export interface RecurringCharge {
    RecurringChargeAmount?: number;
    RecurringChargeFrequency?: string;
}
export declare const RecurringCharge: S.Schema<RecurringCharge>;
export type RecurringChargeList = RecurringCharge[];
export declare const RecurringChargeList: any;
export interface ReservedCacheNode {
    ReservedCacheNodeId?: string;
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    StartTime?: Date;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    CacheNodeCount?: number;
    ProductDescription?: string;
    OfferingType?: string;
    State?: string;
    RecurringCharges?: RecurringCharge[];
    ReservationARN?: string;
}
export declare const ReservedCacheNode: S.Schema<ReservedCacheNode>;
export type ReservedCacheNodeList = ReservedCacheNode[];
export declare const ReservedCacheNodeList: any;
export interface ReservedCacheNodeMessage {
    Marker?: string;
    ReservedCacheNodes?: ReservedCacheNode[];
}
export declare const ReservedCacheNodeMessage: S.Schema<ReservedCacheNodeMessage>;
export interface DescribeReservedCacheNodesOfferingsMessage {
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    Duration?: string;
    ProductDescription?: string;
    OfferingType?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeReservedCacheNodesOfferingsMessage: S.Schema<DescribeReservedCacheNodesOfferingsMessage>;
export interface ReservedCacheNodesOffering {
    ReservedCacheNodesOfferingId?: string;
    CacheNodeType?: string;
    Duration?: number;
    FixedPrice?: number;
    UsagePrice?: number;
    ProductDescription?: string;
    OfferingType?: string;
    RecurringCharges?: RecurringCharge[];
}
export declare const ReservedCacheNodesOffering: S.Schema<ReservedCacheNodesOffering>;
export type ReservedCacheNodesOfferingList = ReservedCacheNodesOffering[];
export declare const ReservedCacheNodesOfferingList: any;
export interface ReservedCacheNodesOfferingMessage {
    Marker?: string;
    ReservedCacheNodesOfferings?: ReservedCacheNodesOffering[];
}
export declare const ReservedCacheNodesOfferingMessage: S.Schema<ReservedCacheNodesOfferingMessage>;
export interface DescribeServerlessCachesRequest {
    ServerlessCacheName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const DescribeServerlessCachesRequest: S.Schema<DescribeServerlessCachesRequest>;
export type ServerlessCacheList = ServerlessCache[];
export declare const ServerlessCacheList: any;
export interface DescribeServerlessCachesResponse {
    NextToken?: string;
    ServerlessCaches?: (ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    })[];
}
export declare const DescribeServerlessCachesResponse: S.Schema<DescribeServerlessCachesResponse>;
export interface DescribeServerlessCacheSnapshotsRequest {
    ServerlessCacheName?: string;
    ServerlessCacheSnapshotName?: string;
    SnapshotType?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const DescribeServerlessCacheSnapshotsRequest: S.Schema<DescribeServerlessCacheSnapshotsRequest>;
export type ServerlessCacheSnapshotList = ServerlessCacheSnapshot[];
export declare const ServerlessCacheSnapshotList: any;
export interface DescribeServerlessCacheSnapshotsResponse {
    NextToken?: string;
    ServerlessCacheSnapshots?: ServerlessCacheSnapshot[];
}
export declare const DescribeServerlessCacheSnapshotsResponse: S.Schema<DescribeServerlessCacheSnapshotsResponse>;
export type ServiceUpdateStatus = "available" | "cancelled" | "expired" | (string & {});
export declare const ServiceUpdateStatus: any;
export type ServiceUpdateStatusList = ServiceUpdateStatus[];
export declare const ServiceUpdateStatusList: any;
export interface DescribeServiceUpdatesMessage {
    ServiceUpdateName?: string;
    ServiceUpdateStatus?: ServiceUpdateStatus[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeServiceUpdatesMessage: S.Schema<DescribeServiceUpdatesMessage>;
export type ServiceUpdateSeverity = "critical" | "important" | "medium" | "low" | (string & {});
export declare const ServiceUpdateSeverity: any;
export type ServiceUpdateType = "security-update" | (string & {});
export declare const ServiceUpdateType: any;
export interface ServiceUpdate {
    ServiceUpdateName?: string;
    ServiceUpdateReleaseDate?: Date;
    ServiceUpdateEndDate?: Date;
    ServiceUpdateSeverity?: ServiceUpdateSeverity;
    ServiceUpdateRecommendedApplyByDate?: Date;
    ServiceUpdateStatus?: ServiceUpdateStatus;
    ServiceUpdateDescription?: string;
    ServiceUpdateType?: ServiceUpdateType;
    Engine?: string;
    EngineVersion?: string;
    AutoUpdateAfterRecommendedApplyByDate?: boolean;
    EstimatedUpdateTime?: string;
}
export declare const ServiceUpdate: S.Schema<ServiceUpdate>;
export type ServiceUpdateList = ServiceUpdate[];
export declare const ServiceUpdateList: any;
export interface ServiceUpdatesMessage {
    Marker?: string;
    ServiceUpdates?: ServiceUpdate[];
}
export declare const ServiceUpdatesMessage: S.Schema<ServiceUpdatesMessage>;
export interface DescribeSnapshotsMessage {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    SnapshotName?: string;
    SnapshotSource?: string;
    Marker?: string;
    MaxRecords?: number;
    ShowNodeGroupConfig?: boolean;
}
export declare const DescribeSnapshotsMessage: S.Schema<DescribeSnapshotsMessage>;
export type SnapshotList = Snapshot[];
export declare const SnapshotList: any;
export interface DescribeSnapshotsListMessage {
    Marker?: string;
    Snapshots?: Snapshot[];
}
export declare const DescribeSnapshotsListMessage: S.Schema<DescribeSnapshotsListMessage>;
export interface TimeRangeFilter {
    StartTime?: Date;
    EndTime?: Date;
}
export declare const TimeRangeFilter: S.Schema<TimeRangeFilter>;
export type UpdateActionStatusList = UpdateActionStatus[];
export declare const UpdateActionStatusList: any;
export interface DescribeUpdateActionsMessage {
    ServiceUpdateName?: string;
    ReplicationGroupIds?: string[];
    CacheClusterIds?: string[];
    Engine?: string;
    ServiceUpdateStatus?: ServiceUpdateStatus[];
    ServiceUpdateTimeRange?: TimeRangeFilter;
    UpdateActionStatus?: UpdateActionStatus[];
    ShowNodeLevelUpdateStatus?: boolean;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeUpdateActionsMessage: S.Schema<DescribeUpdateActionsMessage>;
export type SlaMet = "yes" | "no" | "n/a" | (string & {});
export declare const SlaMet: any;
export type NodeUpdateStatus = "not-applied" | "waiting-to-start" | "in-progress" | "stopping" | "stopped" | "complete" | (string & {});
export declare const NodeUpdateStatus: any;
export type NodeUpdateInitiatedBy = "system" | "customer" | (string & {});
export declare const NodeUpdateInitiatedBy: any;
export interface NodeGroupMemberUpdateStatus {
    CacheClusterId?: string;
    CacheNodeId?: string;
    NodeUpdateStatus?: NodeUpdateStatus;
    NodeDeletionDate?: Date;
    NodeUpdateStartDate?: Date;
    NodeUpdateEndDate?: Date;
    NodeUpdateInitiatedBy?: NodeUpdateInitiatedBy;
    NodeUpdateInitiatedDate?: Date;
    NodeUpdateStatusModifiedDate?: Date;
}
export declare const NodeGroupMemberUpdateStatus: S.Schema<NodeGroupMemberUpdateStatus>;
export type NodeGroupMemberUpdateStatusList = NodeGroupMemberUpdateStatus[];
export declare const NodeGroupMemberUpdateStatusList: any;
export interface NodeGroupUpdateStatus {
    NodeGroupId?: string;
    NodeGroupMemberUpdateStatus?: NodeGroupMemberUpdateStatus[];
}
export declare const NodeGroupUpdateStatus: S.Schema<NodeGroupUpdateStatus>;
export type NodeGroupUpdateStatusList = NodeGroupUpdateStatus[];
export declare const NodeGroupUpdateStatusList: any;
export interface CacheNodeUpdateStatus {
    CacheNodeId?: string;
    NodeUpdateStatus?: NodeUpdateStatus;
    NodeDeletionDate?: Date;
    NodeUpdateStartDate?: Date;
    NodeUpdateEndDate?: Date;
    NodeUpdateInitiatedBy?: NodeUpdateInitiatedBy;
    NodeUpdateInitiatedDate?: Date;
    NodeUpdateStatusModifiedDate?: Date;
}
export declare const CacheNodeUpdateStatus: S.Schema<CacheNodeUpdateStatus>;
export type CacheNodeUpdateStatusList = CacheNodeUpdateStatus[];
export declare const CacheNodeUpdateStatusList: any;
export interface UpdateAction {
    ReplicationGroupId?: string;
    CacheClusterId?: string;
    ServiceUpdateName?: string;
    ServiceUpdateReleaseDate?: Date;
    ServiceUpdateSeverity?: ServiceUpdateSeverity;
    ServiceUpdateStatus?: ServiceUpdateStatus;
    ServiceUpdateRecommendedApplyByDate?: Date;
    ServiceUpdateType?: ServiceUpdateType;
    UpdateActionAvailableDate?: Date;
    UpdateActionStatus?: UpdateActionStatus;
    NodesUpdated?: string;
    UpdateActionStatusModifiedDate?: Date;
    SlaMet?: SlaMet;
    NodeGroupUpdateStatus?: NodeGroupUpdateStatus[];
    CacheNodeUpdateStatus?: CacheNodeUpdateStatus[];
    EstimatedUpdateTime?: string;
    Engine?: string;
}
export declare const UpdateAction: S.Schema<UpdateAction>;
export type UpdateActionList = UpdateAction[];
export declare const UpdateActionList: any;
export interface UpdateActionsMessage {
    Marker?: string;
    UpdateActions?: UpdateAction[];
}
export declare const UpdateActionsMessage: S.Schema<UpdateActionsMessage>;
export interface DescribeUserGroupsMessage {
    UserGroupId?: string;
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeUserGroupsMessage: S.Schema<DescribeUserGroupsMessage>;
export type UserGroupList = UserGroup[];
export declare const UserGroupList: any;
export interface DescribeUserGroupsResult {
    UserGroups?: UserGroup[];
    Marker?: string;
}
export declare const DescribeUserGroupsResult: S.Schema<DescribeUserGroupsResult>;
export type FilterName = string;
export type FilterValue = string;
export type FilterValueList = string[];
export declare const FilterValueList: any;
export interface Filter {
    Name?: string;
    Values?: string[];
}
export declare const Filter: S.Schema<Filter>;
export type FilterList = Filter[];
export declare const FilterList: any;
export interface DescribeUsersMessage {
    Engine?: string;
    UserId?: string;
    Filters?: Filter[];
    MaxRecords?: number;
    Marker?: string;
}
export declare const DescribeUsersMessage: S.Schema<DescribeUsersMessage>;
export type UserList = User[];
export declare const UserList: any;
export interface DescribeUsersResult {
    Users?: User[];
    Marker?: string;
}
export declare const DescribeUsersResult: S.Schema<DescribeUsersResult>;
export interface DisassociateGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    ReplicationGroupId?: string;
    ReplicationGroupRegion?: string;
}
export declare const DisassociateGlobalReplicationGroupMessage: S.Schema<DisassociateGlobalReplicationGroupMessage>;
export interface DisassociateGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const DisassociateGlobalReplicationGroupResult: S.Schema<DisassociateGlobalReplicationGroupResult>;
export interface ExportServerlessCacheSnapshotRequest {
    ServerlessCacheSnapshotName?: string;
    S3BucketName?: string;
}
export declare const ExportServerlessCacheSnapshotRequest: S.Schema<ExportServerlessCacheSnapshotRequest>;
export interface ExportServerlessCacheSnapshotResponse {
    ServerlessCacheSnapshot?: ServerlessCacheSnapshot;
}
export declare const ExportServerlessCacheSnapshotResponse: S.Schema<ExportServerlessCacheSnapshotResponse>;
export interface FailoverGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    PrimaryRegion?: string;
    PrimaryReplicationGroupId?: string;
}
export declare const FailoverGlobalReplicationGroupMessage: S.Schema<FailoverGlobalReplicationGroupMessage>;
export interface FailoverGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const FailoverGlobalReplicationGroupResult: S.Schema<FailoverGlobalReplicationGroupResult>;
export interface ReshardingConfiguration {
    NodeGroupId?: string;
    PreferredAvailabilityZones?: string[];
}
export declare const ReshardingConfiguration: S.Schema<ReshardingConfiguration>;
export type ReshardingConfigurationList = ReshardingConfiguration[];
export declare const ReshardingConfigurationList: any;
export interface RegionalConfiguration {
    ReplicationGroupId?: string;
    ReplicationGroupRegion?: string;
    ReshardingConfiguration?: ReshardingConfiguration[];
}
export declare const RegionalConfiguration: S.Schema<RegionalConfiguration>;
export type RegionalConfigurationList = RegionalConfiguration[];
export declare const RegionalConfigurationList: any;
export interface IncreaseNodeGroupsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    NodeGroupCount?: number;
    RegionalConfigurations?: RegionalConfiguration[];
    ApplyImmediately?: boolean;
}
export declare const IncreaseNodeGroupsInGlobalReplicationGroupMessage: S.Schema<IncreaseNodeGroupsInGlobalReplicationGroupMessage>;
export interface IncreaseNodeGroupsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const IncreaseNodeGroupsInGlobalReplicationGroupResult: S.Schema<IncreaseNodeGroupsInGlobalReplicationGroupResult>;
export interface IncreaseReplicaCountMessage {
    ReplicationGroupId?: string;
    NewReplicaCount?: number;
    ReplicaConfiguration?: ConfigureShard[];
    ApplyImmediately?: boolean;
}
export declare const IncreaseReplicaCountMessage: S.Schema<IncreaseReplicaCountMessage>;
export interface IncreaseReplicaCountResult {
    ReplicationGroup?: ReplicationGroup;
}
export declare const IncreaseReplicaCountResult: S.Schema<IncreaseReplicaCountResult>;
export interface ListAllowedNodeTypeModificationsMessage {
    CacheClusterId?: string;
    ReplicationGroupId?: string;
}
export declare const ListAllowedNodeTypeModificationsMessage: S.Schema<ListAllowedNodeTypeModificationsMessage>;
export type NodeTypeList = string[];
export declare const NodeTypeList: any;
export interface AllowedNodeTypeModificationsMessage {
    ScaleUpModifications?: string[];
    ScaleDownModifications?: string[];
}
export declare const AllowedNodeTypeModificationsMessage: S.Schema<AllowedNodeTypeModificationsMessage>;
export interface ListTagsForResourceMessage {
    ResourceName?: string;
}
export declare const ListTagsForResourceMessage: S.Schema<ListTagsForResourceMessage>;
export type AuthTokenUpdateStrategyType = "SET" | "ROTATE" | "DELETE" | (string & {});
export declare const AuthTokenUpdateStrategyType: any;
export interface ModifyCacheClusterMessage {
    CacheClusterId?: string;
    NumCacheNodes?: number;
    CacheNodeIdsToRemove?: string[];
    AZMode?: AZMode;
    NewAvailabilityZones?: string[];
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    PreferredMaintenanceWindow?: string;
    NotificationTopicArn?: string;
    CacheParameterGroupName?: string;
    NotificationTopicStatus?: string;
    ApplyImmediately?: boolean;
    Engine?: string;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    CacheNodeType?: string;
    AuthToken?: string | redacted.Redacted<string>;
    AuthTokenUpdateStrategy?: AuthTokenUpdateStrategyType;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    IpDiscovery?: IpDiscovery;
    ScaleConfig?: ScaleConfig;
}
export declare const ModifyCacheClusterMessage: S.Schema<ModifyCacheClusterMessage>;
export interface ModifyCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export declare const ModifyCacheClusterResult: S.Schema<ModifyCacheClusterResult>;
export interface ParameterNameValue {
    ParameterName?: string;
    ParameterValue?: string;
}
export declare const ParameterNameValue: S.Schema<ParameterNameValue>;
export type ParameterNameValueList = ParameterNameValue[];
export declare const ParameterNameValueList: any;
export interface ModifyCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
    ParameterNameValues?: ParameterNameValue[];
}
export declare const ModifyCacheParameterGroupMessage: S.Schema<ModifyCacheParameterGroupMessage>;
export interface CacheParameterGroupNameMessage {
    CacheParameterGroupName?: string;
}
export declare const CacheParameterGroupNameMessage: S.Schema<CacheParameterGroupNameMessage>;
export interface ModifyCacheSubnetGroupMessage {
    CacheSubnetGroupName?: string;
    CacheSubnetGroupDescription?: string;
    SubnetIds?: string[];
}
export declare const ModifyCacheSubnetGroupMessage: S.Schema<ModifyCacheSubnetGroupMessage>;
export interface ModifyCacheSubnetGroupResult {
    CacheSubnetGroup?: CacheSubnetGroup;
}
export declare const ModifyCacheSubnetGroupResult: S.Schema<ModifyCacheSubnetGroupResult>;
export interface ModifyGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    ApplyImmediately?: boolean;
    CacheNodeType?: string;
    Engine?: string;
    EngineVersion?: string;
    CacheParameterGroupName?: string;
    GlobalReplicationGroupDescription?: string;
    AutomaticFailoverEnabled?: boolean;
}
export declare const ModifyGlobalReplicationGroupMessage: S.Schema<ModifyGlobalReplicationGroupMessage>;
export interface ModifyGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const ModifyGlobalReplicationGroupResult: S.Schema<ModifyGlobalReplicationGroupResult>;
export interface ModifyReplicationGroupMessage {
    ReplicationGroupId?: string;
    ReplicationGroupDescription?: string;
    PrimaryClusterId?: string;
    SnapshottingClusterId?: string;
    AutomaticFailoverEnabled?: boolean;
    MultiAZEnabled?: boolean;
    NodeGroupId?: string;
    CacheSecurityGroupNames?: string[];
    SecurityGroupIds?: string[];
    PreferredMaintenanceWindow?: string;
    NotificationTopicArn?: string;
    CacheParameterGroupName?: string;
    NotificationTopicStatus?: string;
    ApplyImmediately?: boolean;
    Engine?: string;
    EngineVersion?: string;
    AutoMinorVersionUpgrade?: boolean;
    SnapshotRetentionLimit?: number;
    SnapshotWindow?: string;
    CacheNodeType?: string;
    AuthToken?: string | redacted.Redacted<string>;
    AuthTokenUpdateStrategy?: AuthTokenUpdateStrategyType;
    UserGroupIdsToAdd?: string[];
    UserGroupIdsToRemove?: string[];
    RemoveUserGroups?: boolean;
    LogDeliveryConfigurations?: LogDeliveryConfigurationRequest[];
    IpDiscovery?: IpDiscovery;
    TransitEncryptionEnabled?: boolean;
    TransitEncryptionMode?: TransitEncryptionMode;
    ClusterMode?: ClusterMode;
    Durability?: Durability;
}
export declare const ModifyReplicationGroupMessage: S.Schema<ModifyReplicationGroupMessage>;
export interface ModifyReplicationGroupResult {
    ReplicationGroup?: ReplicationGroup;
}
export declare const ModifyReplicationGroupResult: S.Schema<ModifyReplicationGroupResult>;
export type NodeGroupsToRemoveList = string[];
export declare const NodeGroupsToRemoveList: any;
export type NodeGroupsToRetainList = string[];
export declare const NodeGroupsToRetainList: any;
export interface ModifyReplicationGroupShardConfigurationMessage {
    ReplicationGroupId?: string;
    NodeGroupCount?: number;
    ApplyImmediately?: boolean;
    ReshardingConfiguration?: ReshardingConfiguration[];
    NodeGroupsToRemove?: string[];
    NodeGroupsToRetain?: string[];
}
export declare const ModifyReplicationGroupShardConfigurationMessage: S.Schema<ModifyReplicationGroupShardConfigurationMessage>;
export interface ModifyReplicationGroupShardConfigurationResult {
    ReplicationGroup?: ReplicationGroup;
}
export declare const ModifyReplicationGroupShardConfigurationResult: S.Schema<ModifyReplicationGroupShardConfigurationResult>;
export interface ModifyServerlessCacheRequest {
    ServerlessCacheName?: string;
    Description?: string;
    CacheUsageLimits?: CacheUsageLimits;
    RemoveUserGroup?: boolean;
    UserGroupId?: string;
    SecurityGroupIds?: string[];
    SnapshotRetentionLimit?: number;
    DailySnapshotTime?: string;
    Engine?: string;
    MajorEngineVersion?: string;
}
export declare const ModifyServerlessCacheRequest: S.Schema<ModifyServerlessCacheRequest>;
export interface ModifyServerlessCacheResponse {
    ServerlessCache?: ServerlessCache & {
        CacheUsageLimits: CacheUsageLimits & {
            DataStorage: DataStorage & {
                Unit: DataStorageUnit;
            };
        };
    };
}
export declare const ModifyServerlessCacheResponse: S.Schema<ModifyServerlessCacheResponse>;
export interface ModifyUserMessage {
    UserId?: string;
    AccessString?: string;
    AppendAccessString?: string;
    Passwords?: Array<string | redacted.Redacted<string>>;
    NoPasswordRequired?: boolean;
    AuthenticationMode?: AuthenticationMode;
    Engine?: string;
}
export declare const ModifyUserMessage: S.Schema<ModifyUserMessage>;
export interface ModifyUserGroupMessage {
    UserGroupId?: string;
    UserIdsToAdd?: string[];
    UserIdsToRemove?: string[];
    Engine?: string;
}
export declare const ModifyUserGroupMessage: S.Schema<ModifyUserGroupMessage>;
export interface PurchaseReservedCacheNodesOfferingMessage {
    ReservedCacheNodesOfferingId?: string;
    ReservedCacheNodeId?: string;
    CacheNodeCount?: number;
    Tags?: Tag[];
}
export declare const PurchaseReservedCacheNodesOfferingMessage: S.Schema<PurchaseReservedCacheNodesOfferingMessage>;
export interface PurchaseReservedCacheNodesOfferingResult {
    ReservedCacheNode?: ReservedCacheNode;
}
export declare const PurchaseReservedCacheNodesOfferingResult: S.Schema<PurchaseReservedCacheNodesOfferingResult>;
export interface RebalanceSlotsInGlobalReplicationGroupMessage {
    GlobalReplicationGroupId?: string;
    ApplyImmediately?: boolean;
}
export declare const RebalanceSlotsInGlobalReplicationGroupMessage: S.Schema<RebalanceSlotsInGlobalReplicationGroupMessage>;
export interface RebalanceSlotsInGlobalReplicationGroupResult {
    GlobalReplicationGroup?: GlobalReplicationGroup;
}
export declare const RebalanceSlotsInGlobalReplicationGroupResult: S.Schema<RebalanceSlotsInGlobalReplicationGroupResult>;
export interface RebootCacheClusterMessage {
    CacheClusterId?: string;
    CacheNodeIdsToReboot?: string[];
}
export declare const RebootCacheClusterMessage: S.Schema<RebootCacheClusterMessage>;
export interface RebootCacheClusterResult {
    CacheCluster?: CacheCluster;
}
export declare const RebootCacheClusterResult: S.Schema<RebootCacheClusterResult>;
export type KeyList = string[];
export declare const KeyList: any;
export interface RemoveTagsFromResourceMessage {
    ResourceName?: string;
    TagKeys?: string[];
}
export declare const RemoveTagsFromResourceMessage: S.Schema<RemoveTagsFromResourceMessage>;
export interface ResetCacheParameterGroupMessage {
    CacheParameterGroupName?: string;
    ResetAllParameters?: boolean;
    ParameterNameValues?: ParameterNameValue[];
}
export declare const ResetCacheParameterGroupMessage: S.Schema<ResetCacheParameterGroupMessage>;
export interface RevokeCacheSecurityGroupIngressMessage {
    CacheSecurityGroupName?: string;
    EC2SecurityGroupName?: string;
    EC2SecurityGroupOwnerId?: string;
}
export declare const RevokeCacheSecurityGroupIngressMessage: S.Schema<RevokeCacheSecurityGroupIngressMessage>;
export interface RevokeCacheSecurityGroupIngressResult {
    CacheSecurityGroup?: CacheSecurityGroup;
}
export declare const RevokeCacheSecurityGroupIngressResult: S.Schema<RevokeCacheSecurityGroupIngressResult>;
export interface CustomerNodeEndpoint {
    Address?: string;
    Port?: number;
}
export declare const CustomerNodeEndpoint: S.Schema<CustomerNodeEndpoint>;
export type CustomerNodeEndpointList = CustomerNodeEndpoint[];
export declare const CustomerNodeEndpointList: any;
export interface StartMigrationMessage {
    ReplicationGroupId?: string;
    CustomerNodeEndpointList?: CustomerNodeEndpoint[];
}
export declare const StartMigrationMessage: S.Schema<StartMigrationMessage>;
export interface StartMigrationResponse {
    ReplicationGroup?: ReplicationGroup;
}
export declare const StartMigrationResponse: S.Schema<StartMigrationResponse>;
export interface TestFailoverMessage {
    ReplicationGroupId?: string;
    NodeGroupId?: string;
}
export declare const TestFailoverMessage: S.Schema<TestFailoverMessage>;
export interface TestFailoverResult {
    ReplicationGroup?: ReplicationGroup;
}
export declare const TestFailoverResult: S.Schema<TestFailoverResult>;
export interface TestMigrationMessage {
    ReplicationGroupId?: string;
    CustomerNodeEndpointList?: CustomerNodeEndpoint[];
}
export declare const TestMigrationMessage: S.Schema<TestMigrationMessage>;
export interface TestMigrationResponse {
    ReplicationGroup?: ReplicationGroup;
}
export declare const TestMigrationResponse: S.Schema<TestMigrationResponse>;
export type ExceptionMessage = string;
export type AwsQueryErrorMessage = string;
export type AddTagsToResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | InvalidARNFault | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * A tag is a key-value pair where the key and value are case-sensitive. You can use tags
 * to categorize and track all your ElastiCache resources, with the exception of global
 * replication group. When you add or remove tags on replication groups, those actions will
 * be replicated to all nodes in the replication group. For more information, see Resource-level permissions.
 *
 * For example, you can use cost-allocation tags to your ElastiCache resources, Amazon
 * generates a cost allocation report as a comma-separated value (CSV) file with your usage
 * and costs aggregated by your tags. You can apply tags that represent business categories
 * (such as cost centers, application names, or owners) to organize your costs across
 * multiple services.
 *
 * For more information, see Using Cost Allocation Tags in
 * Amazon ElastiCache in the ElastiCache User
 * Guide.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage, TagListMessage, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type AuthorizeCacheSecurityGroupIngressError = AuthorizationAlreadyExistsFault | CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Allows network ingress to a cache security group. Applications using ElastiCache must
 * be running on Amazon EC2, and Amazon EC2 security groups are used as the authorization
 * mechanism.
 *
 * You cannot authorize ingress from an Amazon EC2 security group in one region to an
 * ElastiCache cluster in another region.
 */
export declare const authorizeCacheSecurityGroupIngress: API.OperationMethod<AuthorizeCacheSecurityGroupIngressMessage, AuthorizeCacheSecurityGroupIngressResult, AuthorizeCacheSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type BatchApplyUpdateActionError = InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Apply the service update. For more information on service updates and applying them,
 * see Applying Service
 * Updates.
 */
export declare const batchApplyUpdateAction: API.OperationMethod<BatchApplyUpdateActionMessage, UpdateActionResultsMessage, BatchApplyUpdateActionError, Credentials | HttpClient.HttpClient>;
export type BatchStopUpdateActionError = InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Stop the service update. For more information on service updates and stopping them,
 * see Stopping
 * Service Updates.
 */
export declare const batchStopUpdateAction: API.OperationMethod<BatchStopUpdateActionMessage, UpdateActionResultsMessage, BatchStopUpdateActionError, Credentials | HttpClient.HttpClient>;
export type CompleteMigrationError = InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | ReplicationGroupNotUnderMigrationFault | CommonErrors;
/**
 * Complete the migration of data.
 */
export declare const completeMigration: API.OperationMethod<CompleteMigrationMessage, CompleteMigrationResponse, CompleteMigrationError, Credentials | HttpClient.HttpClient>;
export type CopyServerlessCacheSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotAlreadyExistsFault | ServerlessCacheSnapshotNotFoundFault | ServerlessCacheSnapshotQuotaExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a copy of an existing serverless cache’s snapshot. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const copyServerlessCacheSnapshot: API.OperationMethod<CopyServerlessCacheSnapshotRequest, CopyServerlessCacheSnapshotResponse, CopyServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type CopySnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | SnapshotAlreadyExistsFault | SnapshotNotFoundFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Makes a copy of an existing snapshot.
 *
 * This operation is valid for Valkey or Redis OSS only.
 *
 * Users or groups that have permissions to use the `CopySnapshot`
 * operation can create their own Amazon S3 buckets and copy snapshots to it. To
 * control access to your snapshots, use an IAM policy to control who has the ability
 * to use the `CopySnapshot` operation. For more information about using IAM
 * to control the use of ElastiCache operations, see Exporting
 * Snapshots and Authentication & Access
 * Control.
 *
 * You could receive the following error messages.
 *
 * **Error Messages**
 *
 * - **Error Message:** The S3 bucket %s is outside of
 * the region.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The S3 bucket %s does not
 * exist.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The S3 bucket %s is not owned
 * by the authenticated user.
 *
 * **Solution:** Create an Amazon S3 bucket in the
 * same region as your snapshot. For more information, see Step 1: Create an Amazon S3 Bucket in the ElastiCache User
 * Guide.
 *
 * - **Error Message:** The authenticated user does
 * not have sufficient permissions to perform the desired activity.
 *
 * **Solution:** Contact your system administrator
 * to get the needed permissions.
 *
 * - **Error Message:** The S3 bucket %s already
 * contains an object with key %s.
 *
 * **Solution:** Give the
 * `TargetSnapshotName` a new and unique value. If exporting a
 * snapshot, you could alternatively create a new Amazon S3 bucket and use this
 * same value for `TargetSnapshotName`.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted READ permissions %s on the S3 Bucket.
 *
 * **Solution:** Add List and Read permissions on
 * the bucket. For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted WRITE permissions %s on the S3 Bucket.
 *
 * **Solution:** Add Upload/Delete permissions on
 * the bucket. For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 *
 * - **Error Message: ** ElastiCache has not been
 * granted READ_ACP permissions %s on the S3 Bucket.
 *
 * **Solution:** Add View Permissions on the bucket.
 * For more information, see Step 2: Grant ElastiCache Access to Your Amazon S3 Bucket in the
 * ElastiCache User Guide.
 */
export declare const copySnapshot: API.OperationMethod<CopySnapshotMessage, CopySnapshotResult, CopySnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateCacheClusterError = CacheClusterAlreadyExistsFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a cluster. All nodes in the cluster run the same protocol-compliant cache
 * engine software, either Memcached, Valkey or Redis OSS.
 *
 * This operation is not supported for Valkey or Redis OSS (cluster mode enabled) clusters.
 */
export declare const createCacheCluster: API.OperationMethod<CreateCacheClusterMessage, CreateCacheClusterResult, CreateCacheClusterError, Credentials | HttpClient.HttpClient>;
export type CreateCacheParameterGroupError = CacheParameterGroupAlreadyExistsFault | CacheParameterGroupQuotaExceededFault | InvalidCacheParameterGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new Amazon ElastiCache cache parameter group. An ElastiCache cache parameter
 * group is a collection of parameters and their values that are applied to all of the
 * nodes in any cluster or replication group using the CacheParameterGroup.
 *
 * A newly created CacheParameterGroup is an exact duplicate of the default parameter
 * group for the CacheParameterGroupFamily. To customize the newly created
 * CacheParameterGroup you can change the values of specific parameters. For more
 * information, see:
 *
 * - ModifyCacheParameterGroup in the ElastiCache API Reference.
 *
 * - Parameters and
 * Parameter Groups in the ElastiCache User Guide.
 */
export declare const createCacheParameterGroup: API.OperationMethod<CreateCacheParameterGroupMessage, CreateCacheParameterGroupResult, CreateCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCacheSecurityGroupError = CacheSecurityGroupAlreadyExistsFault | CacheSecurityGroupQuotaExceededFault | InvalidParameterCombinationException | InvalidParameterValueException | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new cache security group. Use a cache security group to control access to
 * one or more clusters.
 *
 * Cache security groups are only used when you are creating a cluster outside of an
 * Amazon Virtual Private Cloud (Amazon VPC). If you are creating a cluster inside of a
 * VPC, use a cache subnet group instead. For more information, see CreateCacheSubnetGroup.
 */
export declare const createCacheSecurityGroup: API.OperationMethod<CreateCacheSecurityGroupMessage, CreateCacheSecurityGroupResult, CreateCacheSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type CreateCacheSubnetGroupError = CacheSubnetGroupAlreadyExistsFault | CacheSubnetGroupQuotaExceededFault | CacheSubnetQuotaExceededFault | InvalidSubnet | SubnetNotAllowedFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a new cache subnet group.
 *
 * Use this parameter only when you are creating a cluster in an Amazon Virtual Private
 * Cloud (Amazon VPC).
 */
export declare const createCacheSubnetGroup: API.OperationMethod<CreateCacheSubnetGroupMessage, CreateCacheSubnetGroupResult, CreateCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalReplicationGroupError = GlobalReplicationGroupAlreadyExistsFault | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Global Datastore offers fully managed, fast, reliable and secure
 * cross-region replication. Using Global Datastore with Valkey or Redis OSS, you can create cross-region
 * read replica clusters for ElastiCache to enable low-latency reads and disaster
 * recovery across regions. For more information, see Replication
 * Across Regions Using Global Datastore.
 *
 * - The **GlobalReplicationGroupIdSuffix** is the
 * name of the Global datastore.
 *
 * - The **PrimaryReplicationGroupId** represents the
 * name of the primary cluster that accepts writes and will replicate updates to
 * the secondary cluster.
 */
export declare const createGlobalReplicationGroup: API.OperationMethod<CreateGlobalReplicationGroupMessage, CreateGlobalReplicationGroupResult, CreateGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationGroupError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | ClusterQuotaForCustomerExceededFault | GlobalReplicationGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupAlreadyExistsFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | CommonErrors;
/**
 * Creates a Valkey or Redis OSS (cluster mode disabled) or a Valkey or Redis OSS (cluster mode enabled) replication
 * group.
 *
 * This API can be used to create a standalone regional replication group or a secondary
 * replication group associated with a Global datastore.
 *
 * A Valkey or Redis OSS (cluster mode disabled) replication group is a collection of nodes, where
 * one of the nodes is a read/write primary and the others are read-only replicas.
 * Writes to the primary are asynchronously propagated to the replicas.
 *
 * A Valkey or Redis OSS cluster-mode enabled cluster is comprised of from 1 to 90 shards (API/CLI:
 * node groups). Each shard has a primary node and up to 5 read-only replica nodes. The
 * configuration can range from 90 shards and 0 replicas to 15 shards and 5 replicas, which
 * is the maximum number or replicas allowed.
 *
 * The node or shard limit can be increased to a maximum of 500 per cluster if the Valkey or Redis OSS
 * engine version is 5.0.6 or higher. For example, you can choose to configure a 500 node
 * cluster that ranges between 83 shards (one primary and 5 replicas per shard) and 500
 * shards (single primary and no replicas). Make sure there are enough available IP
 * addresses to accommodate the increase. Common pitfalls include the subnets in the subnet
 * group have too small a CIDR range or the subnets are shared and heavily used by other
 * clusters. For more information, see Creating a Subnet
 * Group. For versions below 5.0.6, the limit is 250 per cluster.
 *
 * To request a limit increase, see Amazon Service Limits and
 * choose the limit type Nodes per cluster per instance
 * type.
 *
 * When a Valkey or Redis OSS (cluster mode disabled) replication group has been successfully created,
 * you can add one or more read replicas to it, up to a total of 5 read replicas. If you
 * need to increase or decrease the number of node groups (console: shards), you can use scaling.
 * For more information, see Scaling self-designed clusters in the ElastiCache User
 * Guide.
 *
 * This operation is valid for Valkey and Redis OSS only.
 */
export declare const createReplicationGroup: API.OperationMethod<CreateReplicationGroupMessage, CreateReplicationGroupResult, CreateReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type CreateServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | InvalidUserGroupStateFault | ServerlessCacheAlreadyExistsFault | ServerlessCacheNotFoundFault | ServerlessCacheQuotaForCustomerExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserGroupNotFoundFault | CommonErrors;
/**
 * Creates a serverless cache.
 */
export declare const createServerlessCache: API.OperationMethod<CreateServerlessCacheRequest, CreateServerlessCacheResponse, CreateServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type CreateServerlessCacheSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotAlreadyExistsFault | ServerlessCacheSnapshotQuotaExceededFault | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * This API creates a copy of an entire ServerlessCache at a specific moment in time. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const createServerlessCacheSnapshot: API.OperationMethod<CreateServerlessCacheSnapshotRequest, CreateServerlessCacheSnapshotResponse, CreateServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateSnapshotError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Creates a copy of an entire cluster or replication group at a specific moment in
 * time.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const createSnapshot: API.OperationMethod<CreateSnapshotMessage, CreateSnapshotResult, CreateSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = DuplicateUserNameFault | InvalidParameterCombinationException | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserAlreadyExistsFault | UserQuotaExceededFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 to 7.1: Creates a user. For more information, see
 * Using Role Based Access Control (RBAC).
 */
export declare const createUser: API.OperationMethod<CreateUserMessage, User, CreateUserError, Credentials | HttpClient.HttpClient>;
export type CreateUserGroupError = DefaultUserRequired | DuplicateUserNameFault | InvalidParameterValueException | ServiceLinkedRoleNotFoundFault | TagQuotaPerResourceExceeded | UserGroupAlreadyExistsFault | UserGroupQuotaExceededFault | UserNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 to 7.1: Creates a user group. For more
 * information, see Using Role Based Access Control (RBAC)
 */
export declare const createUserGroup: API.OperationMethod<CreateUserGroupMessage, UserGroup, CreateUserGroupError, Credentials | HttpClient.HttpClient>;
export type DecreaseNodeGroupsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Decreases the number of node groups in a Global datastore
 */
export declare const decreaseNodeGroupsInGlobalReplicationGroup: API.OperationMethod<DecreaseNodeGroupsInGlobalReplicationGroupMessage, DecreaseNodeGroupsInGlobalReplicationGroupResult, DecreaseNodeGroupsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DecreaseReplicaCountError = ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | NoOperationFault | ReplicationGroupNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Dynamically decreases the number of replicas in a Valkey or Redis OSS (cluster mode disabled)
 * replication group or the number of replica nodes in one or more node groups (shards) of
 * a Valkey or Redis OSS (cluster mode enabled) replication group. This operation is performed with no
 * cluster down time.
 */
export declare const decreaseReplicaCount: API.OperationMethod<DecreaseReplicaCountMessage, DecreaseReplicaCountResult, DecreaseReplicaCountError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheClusterError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | InvalidParameterCombinationException | InvalidParameterValueException | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes a previously provisioned cluster. `DeleteCacheCluster` deletes all
 * associated cache nodes, node endpoints and the cluster itself. When you receive a
 * successful response from this operation, Amazon ElastiCache immediately begins deleting
 * the cluster; you cannot cancel or revert this operation.
 *
 * This operation is not valid for:
 *
 * - Valkey or Redis OSS (cluster mode enabled) clusters
 *
 * - Valkey or Redis OSS (cluster mode disabled) clusters
 *
 * - A cluster that is the last read replica of a replication group
 *
 * - A cluster that is the primary node of a replication group
 *
 * - A node group (shard) that has Multi-AZ mode enabled
 *
 * - A cluster from a Valkey or Redis OSS (cluster mode enabled) replication group
 *
 * - A cluster that is not in the `available` state
 */
export declare const deleteCacheCluster: API.OperationMethod<DeleteCacheClusterMessage, DeleteCacheClusterResult, DeleteCacheClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Deletes the specified cache parameter group. You cannot delete a cache parameter group
 * if it is associated with any cache clusters. You cannot delete the default cache
 * parameter groups in your account.
 */
export declare const deleteCacheParameterGroup: API.OperationMethod<DeleteCacheParameterGroupMessage, DeleteCacheParameterGroupResponse, DeleteCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheSecurityGroupError = CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Deletes a cache security group.
 *
 * You cannot delete a cache security group if it is associated with any
 * clusters.
 */
export declare const deleteCacheSecurityGroup: API.OperationMethod<DeleteCacheSecurityGroupMessage, DeleteCacheSecurityGroupResponse, DeleteCacheSecurityGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCacheSubnetGroupError = CacheSubnetGroupInUse | CacheSubnetGroupNotFoundFault | CommonErrors;
/**
 * Deletes a cache subnet group.
 *
 * You cannot delete a default cache subnet group or one that is associated with any
 * clusters.
 */
export declare const deleteCacheSubnetGroup: API.OperationMethod<DeleteCacheSubnetGroupMessage, DeleteCacheSubnetGroupResponse, DeleteCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Deleting a Global datastore is a two-step process:
 *
 * - First, you must DisassociateGlobalReplicationGroup to remove
 * the secondary clusters in the Global datastore.
 *
 * - Once the Global datastore contains only the primary cluster, you can use the
 * `DeleteGlobalReplicationGroup` API to delete the Global datastore
 * while retainining the primary cluster using
 * `RetainPrimaryReplicationGroup=true`.
 *
 * Since the Global Datastore has only a primary cluster, you can delete the Global
 * Datastore while retaining the primary by setting
 * `RetainPrimaryReplicationGroup=true`. The primary cluster is never
 * deleted when deleting a Global Datastore. It can only be deleted when it no longer is
 * associated with any Global Datastore.
 *
 * When you receive a successful response from this operation, Amazon ElastiCache
 * immediately begins deleting the selected resources; you cannot cancel or revert this
 * operation.
 */
export declare const deleteGlobalReplicationGroup: API.OperationMethod<DeleteGlobalReplicationGroupMessage, DeleteGlobalReplicationGroupResult, DeleteGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationGroupError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupNotFoundFault | SnapshotAlreadyExistsFault | SnapshotFeatureNotSupportedFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes an existing replication group. By default, this operation deletes the entire
 * replication group, including the primary/primaries and all of the read replicas. If the
 * replication group has only one primary, you can optionally delete only the read
 * replicas, while retaining the primary by setting
 * `RetainPrimaryCluster=true`.
 *
 * When you receive a successful response from this operation, Amazon ElastiCache
 * immediately begins deleting the selected resources; you cannot cancel or revert this
 * operation.
 *
 * - `CreateSnapshot` permission is required to create a final snapshot.
 * Without this permission, the API call will fail with an `Access Denied` exception.
 *
 * - This operation is valid for Redis OSS only.
 */
export declare const deleteReplicationGroup: API.OperationMethod<DeleteReplicationGroupMessage, DeleteReplicationGroupResult, DeleteReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotAlreadyExistsFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes a specified existing serverless cache.
 *
 * `CreateServerlessCacheSnapshot` permission is required to create a final snapshot.
 * Without this permission, the API call will fail with an `Access Denied` exception.
 */
export declare const deleteServerlessCache: API.OperationMethod<DeleteServerlessCacheRequest, DeleteServerlessCacheResponse, DeleteServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteServerlessCacheSnapshotError = InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Deletes an existing serverless cache snapshot. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const deleteServerlessCacheSnapshot: API.OperationMethod<DeleteServerlessCacheSnapshotRequest, DeleteServerlessCacheSnapshotResponse, DeleteServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteSnapshotError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidSnapshotStateFault | SnapshotNotFoundFault | CommonErrors;
/**
 * Deletes an existing snapshot. When you receive a successful response from this
 * operation, ElastiCache immediately begins deleting the snapshot; you cannot cancel or
 * revert this operation.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const deleteSnapshot: API.OperationMethod<DeleteSnapshotMessage, DeleteSnapshotResult, DeleteSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = DefaultUserAssociatedToUserGroupFault | InvalidParameterValueException | InvalidUserStateFault | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 onwards: Deletes a user. The user will be removed from
 * all user groups and in turn removed from all replication groups. For more information,
 * see Using Role Based Access Control (RBAC).
 */
export declare const deleteUser: API.OperationMethod<DeleteUserMessage, User, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteUserGroupError = InvalidParameterValueException | InvalidUserGroupStateFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * For Valkey engine version 7.2 onwards and Redis OSS 6.0 onwards: Deletes a user group. The user group must first
 * be disassociated from the replication group before it can be deleted. For more
 * information, see Using Role Based Access Control (RBAC).
 */
export declare const deleteUserGroup: API.OperationMethod<DeleteUserGroupMessage, UserGroup, DeleteUserGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeCacheClustersError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns information about all provisioned clusters if no cluster identifier is
 * specified, or about a specific cache cluster if a cluster identifier is supplied.
 *
 * By default, abbreviated information about the clusters is returned. You can use the
 * optional *ShowCacheNodeInfo* flag to retrieve detailed information
 * about the cache nodes associated with the clusters. These details include the DNS
 * address and port for the cache node endpoint.
 *
 * If the cluster is in the *creating* state, only cluster-level
 * information is displayed until all of the nodes are successfully provisioned.
 *
 * If the cluster is in the *deleting* state, only cluster-level
 * information is displayed.
 *
 * If cache nodes are currently being added to the cluster, node endpoint information and
 * creation time for the additional nodes are not displayed until they are completely
 * provisioned. When the cluster state is *available*, the cluster is
 * ready for use.
 *
 * If cache nodes are currently being removed from the cluster, no endpoint information
 * for the removed nodes is displayed.
 */
export declare const describeCacheClusters: API.PaginatedOperationMethod<DescribeCacheClustersMessage, CacheClusterMessage, DescribeCacheClustersError, Credentials | HttpClient.HttpClient, CacheCluster>;
export type DescribeCacheEngineVersionsError = CommonErrors;
/**
 * Returns a list of the available cache engines and their versions.
 */
export declare const describeCacheEngineVersions: API.PaginatedOperationMethod<DescribeCacheEngineVersionsMessage, CacheEngineVersionMessage, DescribeCacheEngineVersionsError, Credentials | HttpClient.HttpClient, CacheEngineVersion>;
export type DescribeCacheParameterGroupsError = CacheParameterGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of cache parameter group descriptions. If a cache parameter group name
 * is specified, the list contains only the descriptions for that group.
 */
export declare const describeCacheParameterGroups: API.PaginatedOperationMethod<DescribeCacheParameterGroupsMessage, CacheParameterGroupsMessage, DescribeCacheParameterGroupsError, Credentials | HttpClient.HttpClient, CacheParameterGroup>;
export type DescribeCacheParametersError = CacheParameterGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns the detailed parameter list for a particular cache parameter group.
 */
export declare const describeCacheParameters: API.PaginatedOperationMethod<DescribeCacheParametersMessage, CacheParameterGroupDetails, DescribeCacheParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeCacheSecurityGroupsError = CacheSecurityGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns a list of cache security group descriptions. If a cache security group name is
 * specified, the list contains only the description of that group. This applicable only
 * when you have ElastiCache in Classic setup
 */
export declare const describeCacheSecurityGroups: API.PaginatedOperationMethod<DescribeCacheSecurityGroupsMessage, CacheSecurityGroupMessage, DescribeCacheSecurityGroupsError, Credentials | HttpClient.HttpClient, CacheSecurityGroup>;
export type DescribeCacheSubnetGroupsError = CacheSubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of cache subnet group descriptions. If a subnet group name is
 * specified, the list contains only the description of that group. This is applicable only
 * when you have ElastiCache in VPC setup. All ElastiCache clusters now launch in VPC by
 * default.
 */
export declare const describeCacheSubnetGroups: API.PaginatedOperationMethod<DescribeCacheSubnetGroupsMessage, CacheSubnetGroupMessage, DescribeCacheSubnetGroupsError, Credentials | HttpClient.HttpClient, CacheSubnetGroup>;
export type DescribeEngineDefaultParametersError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns the default engine and system parameter information for the specified cache
 * engine.
 */
export declare const describeEngineDefaultParameters: API.PaginatedOperationMethod<DescribeEngineDefaultParametersMessage, DescribeEngineDefaultParametersResult, DescribeEngineDefaultParametersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventsError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns events related to clusters, cache security groups, and cache parameter groups.
 * You can obtain events specific to a particular cluster, cache security group, or cache
 * parameter group by providing the name as a parameter.
 *
 * By default, only the events occurring within the last hour are returned; however, you
 * can retrieve up to 14 days' worth of events if necessary.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeGlobalReplicationGroupsError = GlobalReplicationGroupNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns information about a particular global replication group. If no identifier is
 * specified, returns information about all Global datastores.
 */
export declare const describeGlobalReplicationGroups: API.PaginatedOperationMethod<DescribeGlobalReplicationGroupsMessage, DescribeGlobalReplicationGroupsResult, DescribeGlobalReplicationGroupsError, Credentials | HttpClient.HttpClient, GlobalReplicationGroup>;
export type DescribeReplicationGroupsError = InvalidParameterCombinationException | InvalidParameterValueException | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Returns information about a particular replication group. If no identifier is
 * specified, `DescribeReplicationGroups` returns information about all
 * replication groups.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const describeReplicationGroups: API.PaginatedOperationMethod<DescribeReplicationGroupsMessage, ReplicationGroupMessage, DescribeReplicationGroupsError, Credentials | HttpClient.HttpClient, ReplicationGroup>;
export type DescribeReservedCacheNodesError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodeNotFoundFault | CommonErrors;
/**
 * Returns information about reserved cache nodes for this account, or about a specified
 * reserved cache node.
 */
export declare const describeReservedCacheNodes: API.PaginatedOperationMethod<DescribeReservedCacheNodesMessage, ReservedCacheNodeMessage, DescribeReservedCacheNodesError, Credentials | HttpClient.HttpClient, ReservedCacheNode>;
export type DescribeReservedCacheNodesOfferingsError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodesOfferingNotFoundFault | CommonErrors;
/**
 * Lists available reserved cache node offerings.
 */
export declare const describeReservedCacheNodesOfferings: API.PaginatedOperationMethod<DescribeReservedCacheNodesOfferingsMessage, ReservedCacheNodesOfferingMessage, DescribeReservedCacheNodesOfferingsError, Credentials | HttpClient.HttpClient, ReservedCacheNodesOffering>;
export type DescribeServerlessCachesError = InvalidParameterCombinationException | InvalidParameterValueException | ServerlessCacheNotFoundFault | CommonErrors;
/**
 * Returns information about a specific serverless cache.
 * If no identifier is specified, then the API returns information on all the serverless caches belonging to
 * this Amazon Web Services account.
 */
export declare const describeServerlessCaches: API.PaginatedOperationMethod<DescribeServerlessCachesRequest, DescribeServerlessCachesResponse, DescribeServerlessCachesError, Credentials | HttpClient.HttpClient, ServerlessCache>;
export type DescribeServerlessCacheSnapshotsError = InvalidParameterCombinationException | InvalidParameterValueException | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about serverless cache snapshots.
 * By default, this API lists all of the customer’s serverless cache snapshots.
 * It can also describe a single serverless cache snapshot, or the snapshots associated with
 * a particular serverless cache. Available for Valkey, Redis OSS and Serverless Memcached only.
 */
export declare const describeServerlessCacheSnapshots: API.PaginatedOperationMethod<DescribeServerlessCacheSnapshotsRequest, DescribeServerlessCacheSnapshotsResponse, DescribeServerlessCacheSnapshotsError, Credentials | HttpClient.HttpClient, ServerlessCacheSnapshot>;
export type DescribeServiceUpdatesError = InvalidParameterCombinationException | InvalidParameterValueException | ServiceUpdateNotFoundFault | CommonErrors;
/**
 * Returns details of the service updates
 */
export declare const describeServiceUpdates: API.PaginatedOperationMethod<DescribeServiceUpdatesMessage, ServiceUpdatesMessage, DescribeServiceUpdatesError, Credentials | HttpClient.HttpClient, ServiceUpdate>;
export type DescribeSnapshotsError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | SnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about cluster or replication group snapshots. By default,
 * `DescribeSnapshots` lists all of your snapshots; it can optionally
 * describe a single snapshot, or just the snapshots associated with a particular cache
 * cluster.
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const describeSnapshots: API.PaginatedOperationMethod<DescribeSnapshotsMessage, DescribeSnapshotsListMessage, DescribeSnapshotsError, Credentials | HttpClient.HttpClient, Snapshot>;
export type DescribeUpdateActionsError = InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Returns details of the update actions
 */
export declare const describeUpdateActions: API.PaginatedOperationMethod<DescribeUpdateActionsMessage, UpdateActionsMessage, DescribeUpdateActionsError, Credentials | HttpClient.HttpClient, UpdateAction>;
export type DescribeUserGroupsError = InvalidParameterCombinationException | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of user groups.
 */
export declare const describeUserGroups: API.PaginatedOperationMethod<DescribeUserGroupsMessage, DescribeUserGroupsResult, DescribeUserGroupsError, Credentials | HttpClient.HttpClient, UserGroup>;
export type DescribeUsersError = InvalidParameterCombinationException | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Returns a list of users.
 */
export declare const describeUsers: API.PaginatedOperationMethod<DescribeUsersMessage, DescribeUsersResult, DescribeUsersError, Credentials | HttpClient.HttpClient, User>;
export type DisassociateGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Remove a secondary cluster from the Global datastore using the Global datastore name.
 * The secondary cluster will no longer receive updates from the primary cluster, but will
 * remain as a standalone cluster in that Amazon region.
 */
export declare const disassociateGlobalReplicationGroup: API.OperationMethod<DisassociateGlobalReplicationGroupMessage, DisassociateGlobalReplicationGroupResult, DisassociateGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ExportServerlessCacheSnapshotError = InvalidParameterValueException | InvalidServerlessCacheSnapshotStateFault | ServerlessCacheSnapshotNotFoundFault | ServiceLinkedRoleNotFoundFault | CommonErrors;
/**
 * Provides the functionality to export the serverless cache snapshot data to Amazon S3. Available for Valkey and Redis OSS only.
 */
export declare const exportServerlessCacheSnapshot: API.OperationMethod<ExportServerlessCacheSnapshotRequest, ExportServerlessCacheSnapshotResponse, ExportServerlessCacheSnapshotError, Credentials | HttpClient.HttpClient>;
export type FailoverGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Used to failover the primary region to a secondary region. The secondary region will
 * become primary, and all other clusters will become secondary.
 */
export declare const failoverGlobalReplicationGroup: API.OperationMethod<FailoverGlobalReplicationGroupMessage, FailoverGlobalReplicationGroupResult, FailoverGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type IncreaseNodeGroupsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Increase the number of node groups in the Global datastore
 */
export declare const increaseNodeGroupsInGlobalReplicationGroup: API.OperationMethod<IncreaseNodeGroupsInGlobalReplicationGroupMessage, IncreaseNodeGroupsInGlobalReplicationGroupResult, IncreaseNodeGroupsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type IncreaseReplicaCountError = ClusterQuotaForCustomerExceededFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | NoOperationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Dynamically increases the number of replicas in a Valkey or Redis OSS (cluster mode disabled)
 * replication group or the number of replica nodes in one or more node groups (shards) of
 * a Valkey or Redis OSS (cluster mode enabled) replication group. This operation is performed with no
 * cluster down time.
 */
export declare const increaseReplicaCount: API.OperationMethod<IncreaseReplicaCountMessage, IncreaseReplicaCountResult, IncreaseReplicaCountError, Credentials | HttpClient.HttpClient>;
export type ListAllowedNodeTypeModificationsError = CacheClusterNotFoundFault | InvalidParameterCombinationException | InvalidParameterValueException | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Lists all available node types that you can scale with your cluster's replication
 * group's current node type.
 *
 * When you use the `ModifyCacheCluster` or
 * `ModifyReplicationGroup` operations to scale your cluster or replication
 * group, the value of the `CacheNodeType` parameter must be one of the node
 * types returned by this operation.
 */
export declare const listAllowedNodeTypeModifications: API.OperationMethod<ListAllowedNodeTypeModificationsMessage, AllowedNodeTypeModificationsMessage, ListAllowedNodeTypeModificationsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | InvalidARNFault | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Lists all tags currently on a named resource.
 *
 * A tag is a key-value pair where the key and value are case-sensitive. You can use
 * tags to categorize and track all your ElastiCache resources, with the exception of
 * global replication group. When you add or remove tags on replication groups, those
 * actions will be replicated to all nodes in the replication group. For more information,
 * see Resource-level permissions.
 *
 * If the cluster is not in the *available* state,
 * `ListTagsForResource` returns an error.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage, TagListMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheClusterError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | CommonErrors;
/**
 * Modifies the settings for a cluster. You can use this operation to change one or more
 * cluster configuration parameters by specifying the parameters and the new values.
 */
export declare const modifyCacheCluster: API.OperationMethod<ModifyCacheClusterMessage, ModifyCacheClusterResult, ModifyCacheClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the parameters of a cache parameter group. You can modify up to 20 parameters
 * in a single request by submitting a list parameter name and value pairs.
 */
export declare const modifyCacheParameterGroup: API.OperationMethod<ModifyCacheParameterGroupMessage, CacheParameterGroupNameMessage, ModifyCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyCacheSubnetGroupError = CacheSubnetGroupNotFoundFault | CacheSubnetQuotaExceededFault | InvalidSubnet | SubnetInUse | SubnetNotAllowedFault | CommonErrors;
/**
 * Modifies an existing cache subnet group.
 */
export declare const modifyCacheSubnetGroup: API.OperationMethod<ModifyCacheSubnetGroupMessage, ModifyCacheSubnetGroupResult, ModifyCacheSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the settings for a Global datastore.
 */
export declare const modifyGlobalReplicationGroup: API.OperationMethod<ModifyGlobalReplicationGroupMessage, ModifyGlobalReplicationGroupResult, ModifyGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationGroupError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidCacheSecurityGroupStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidUserGroupStateFault | InvalidVPCNetworkStateFault | NodeQuotaForClusterExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * Modifies the settings for a replication group. This is limited to Valkey and Redis OSS 7 and above.
 *
 * - Scaling for Valkey or Redis OSS (cluster mode enabled) in
 * the ElastiCache User Guide
 *
 * - ModifyReplicationGroupShardConfiguration in the ElastiCache API
 * Reference
 *
 * This operation is valid for Valkey or Redis OSS only.
 */
export declare const modifyReplicationGroup: API.OperationMethod<ModifyReplicationGroupMessage, ModifyReplicationGroupResult, ModifyReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationGroupShardConfigurationError = InsufficientCacheClusterCapacityFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | InvalidVPCNetworkStateFault | NodeGroupsPerReplicationGroupQuotaExceededFault | NodeQuotaForCustomerExceededFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Modifies a replication group's shards (node groups) by allowing you to add shards,
 * remove shards, or rebalance the keyspaces among existing shards.
 */
export declare const modifyReplicationGroupShardConfiguration: API.OperationMethod<ModifyReplicationGroupShardConfigurationMessage, ModifyReplicationGroupShardConfigurationResult, ModifyReplicationGroupShardConfigurationError, Credentials | HttpClient.HttpClient>;
export type ModifyServerlessCacheError = InvalidCredentialsException | InvalidParameterCombinationException | InvalidParameterValueException | InvalidServerlessCacheStateFault | InvalidUserGroupStateFault | ServerlessCacheNotFoundFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | CommonErrors;
/**
 * This API modifies the attributes of a serverless cache.
 */
export declare const modifyServerlessCache: API.OperationMethod<ModifyServerlessCacheRequest, ModifyServerlessCacheResponse, ModifyServerlessCacheError, Credentials | HttpClient.HttpClient>;
export type ModifyUserError = InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserStateFault | ServiceLinkedRoleNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Changes user password(s) and/or access string.
 */
export declare const modifyUser: API.OperationMethod<ModifyUserMessage, User, ModifyUserError, Credentials | HttpClient.HttpClient>;
export type ModifyUserGroupError = DefaultUserRequired | DuplicateUserNameFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidUserGroupStateFault | ServiceLinkedRoleNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Changes the list of users that belong to the user group.
 */
export declare const modifyUserGroup: API.OperationMethod<ModifyUserGroupMessage, UserGroup, ModifyUserGroupError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedCacheNodesOfferingError = InvalidParameterCombinationException | InvalidParameterValueException | ReservedCacheNodeAlreadyExistsFault | ReservedCacheNodeQuotaExceededFault | ReservedCacheNodesOfferingNotFoundFault | TagQuotaPerResourceExceeded | CommonErrors;
/**
 * Allows you to purchase a reserved cache node offering. Reserved nodes are not eligible
 * for cancellation and are non-refundable. For more information, see Managing Costs with Reserved Nodes.
 */
export declare const purchaseReservedCacheNodesOffering: API.OperationMethod<PurchaseReservedCacheNodesOfferingMessage, PurchaseReservedCacheNodesOfferingResult, PurchaseReservedCacheNodesOfferingError, Credentials | HttpClient.HttpClient>;
export type RebalanceSlotsInGlobalReplicationGroupError = GlobalReplicationGroupNotFoundFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterValueException | CommonErrors;
/**
 * Redistribute slots to ensure uniform distribution across existing shards in the
 * cluster.
 */
export declare const rebalanceSlotsInGlobalReplicationGroup: API.OperationMethod<RebalanceSlotsInGlobalReplicationGroupMessage, RebalanceSlotsInGlobalReplicationGroupResult, RebalanceSlotsInGlobalReplicationGroupError, Credentials | HttpClient.HttpClient>;
export type RebootCacheClusterError = CacheClusterNotFoundFault | InvalidCacheClusterStateFault | CommonErrors;
/**
 * Reboots some, or all, of the cache nodes within a provisioned cluster. This operation
 * applies any modified cache parameter groups to the cluster. The reboot operation takes
 * place as soon as possible, and results in a momentary outage to the cluster. During the
 * reboot, the cluster status is set to REBOOTING.
 *
 * The reboot causes the contents of the cache (for each cache node being rebooted) to be
 * lost.
 *
 * When the reboot is complete, a cluster event is created.
 *
 * Rebooting a cluster is currently supported on Memcached, Valkey and Redis OSS (cluster mode
 * disabled) clusters. Rebooting is not supported on Valkey or Redis OSS (cluster mode enabled)
 * clusters.
 *
 * If you make changes to parameters that require a Valkey or Redis OSS (cluster mode enabled) cluster
 * reboot for the changes to be applied, see Rebooting a Cluster for an alternate process.
 */
export declare const rebootCacheCluster: API.OperationMethod<RebootCacheClusterMessage, RebootCacheClusterResult, RebootCacheClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = CacheClusterNotFoundFault | CacheParameterGroupNotFoundFault | CacheSecurityGroupNotFoundFault | CacheSubnetGroupNotFoundFault | InvalidARNFault | InvalidReplicationGroupStateFault | InvalidServerlessCacheSnapshotStateFault | InvalidServerlessCacheStateFault | ReplicationGroupNotFoundFault | ReservedCacheNodeNotFoundFault | ServerlessCacheNotFoundFault | ServerlessCacheSnapshotNotFoundFault | SnapshotNotFoundFault | TagNotFoundFault | UserGroupNotFoundFault | UserNotFoundFault | CommonErrors;
/**
 * Removes the tags identified by the `TagKeys` list from the named resource.
 * A tag is a key-value pair where the key and value are case-sensitive. You can use tags
 * to categorize and track all your ElastiCache resources, with the exception of global
 * replication group. When you add or remove tags on replication groups, those actions will
 * be replicated to all nodes in the replication group. For more information, see Resource-level permissions.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage, TagListMessage, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetCacheParameterGroupError = CacheParameterGroupNotFoundFault | InvalidCacheParameterGroupStateFault | InvalidGlobalReplicationGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Modifies the parameters of a cache parameter group to the engine or system default
 * value. You can reset specific parameters by submitting a list of parameter names. To
 * reset the entire cache parameter group, specify the `ResetAllParameters` and
 * `CacheParameterGroupName` parameters.
 */
export declare const resetCacheParameterGroup: API.OperationMethod<ResetCacheParameterGroupMessage, CacheParameterGroupNameMessage, ResetCacheParameterGroupError, Credentials | HttpClient.HttpClient>;
export type RevokeCacheSecurityGroupIngressError = AuthorizationNotFoundFault | CacheSecurityGroupNotFoundFault | InvalidCacheSecurityGroupStateFault | InvalidParameterCombinationException | InvalidParameterValueException | CommonErrors;
/**
 * Revokes ingress from a cache security group. Use this operation to disallow access
 * from an Amazon EC2 security group that had been previously authorized.
 */
export declare const revokeCacheSecurityGroupIngress: API.OperationMethod<RevokeCacheSecurityGroupIngressMessage, RevokeCacheSecurityGroupIngressResult, RevokeCacheSecurityGroupIngressError, Credentials | HttpClient.HttpClient>;
export type StartMigrationError = InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupAlreadyUnderMigrationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Start the migration of data.
 */
export declare const startMigration: API.OperationMethod<StartMigrationMessage, StartMigrationResponse, StartMigrationError, Credentials | HttpClient.HttpClient>;
export type TestFailoverError = APICallRateForCustomerExceededFault | InvalidCacheClusterStateFault | InvalidKMSKeyFault | InvalidParameterCombinationException | InvalidParameterValueException | InvalidReplicationGroupStateFault | NodeGroupNotFoundFault | ReplicationGroupNotFoundFault | TestFailoverNotAvailableFault | CommonErrors;
/**
 * Represents the input of a `TestFailover` operation which tests automatic
 * failover on a specified node group (called shard in the console) in a replication group
 * (called cluster in the console).
 *
 * This API is designed for testing the behavior of your application in case of
 * ElastiCache failover. It is not designed to be an operational tool for initiating a
 * failover to overcome a problem you may have with the cluster. Moreover, in certain
 * conditions such as large-scale operational events, Amazon may block this API.
 *
 * **Note the following**
 *
 * - A customer can use this operation to test automatic failover on up to 15 shards
 * (called node groups in the ElastiCache API and Amazon CLI) in any rolling
 * 24-hour period.
 *
 * - If calling this operation on shards in different clusters (called replication
 * groups in the API and CLI), the calls can be made concurrently.
 *
 * - If calling this operation multiple times on different shards in the same Valkey or Redis OSS (cluster mode enabled) replication group, the first node replacement must
 * complete before a subsequent call can be made.
 *
 * - To determine whether the node replacement is complete you can check Events
 * using the Amazon ElastiCache console, the Amazon CLI, or the ElastiCache API.
 * Look for the following automatic failover related events, listed here in order
 * of occurrance:
 *
 * - Replication group message: Test Failover API called for node
 * group
 *
 * - Cache cluster message: Failover from primary node
 * to replica node
 * completed
 *
 * - Replication group message: Failover from primary node
 * to replica node
 * completed
 *
 * - Cache cluster message: Recovering cache nodes
 *
 * - Cache cluster message: Finished recovery for cache nodes
 *
 * For more information see:
 *
 * - Viewing
 * ElastiCache Events in the ElastiCache User
 * Guide
 *
 * - DescribeEvents in the ElastiCache API Reference
 *
 * Also see, Testing
 * Multi-AZ in the *ElastiCache User Guide*.
 */
export declare const testFailover: API.OperationMethod<TestFailoverMessage, TestFailoverResult, TestFailoverError, Credentials | HttpClient.HttpClient>;
export type TestMigrationError = InvalidParameterValueException | InvalidReplicationGroupStateFault | ReplicationGroupAlreadyUnderMigrationFault | ReplicationGroupNotFoundFault | CommonErrors;
/**
 * Async API to test connection between source and target replication group.
 */
export declare const testMigration: API.OperationMethod<TestMigrationMessage, TestMigrationResponse, TestMigrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elasticache.d.ts.map