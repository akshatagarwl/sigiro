import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GatewayTimeoutException_base: S.Class<GatewayTimeoutException, S.TaggedStruct<"GatewayTimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class GatewayTimeoutException extends /*@__PURE__*/ GatewayTimeoutException_base {
}
declare const InternalFailureException_base: S.Class<InternalFailureException, S.TaggedStruct<"InternalFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const MethodNotAllowedException_base: S.Class<MethodNotAllowedException, S.TaggedStruct<"MethodNotAllowedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MethodNotAllowedException extends /*@__PURE__*/ MethodNotAllowedException_base {
}
declare const RequestEntityTooLargeException_base: S.Class<RequestEntityTooLargeException, S.TaggedStruct<"RequestEntityTooLargeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestEntityTooLargeException extends /*@__PURE__*/ RequestEntityTooLargeException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnsupportedDocumentEncodingException_base: S.Class<UnsupportedDocumentEncodingException, S.TaggedStruct<"UnsupportedDocumentEncodingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedDocumentEncodingException extends /*@__PURE__*/ UnsupportedDocumentEncodingException_base {
}
export type ClientId = string;
export type CleanSession = boolean;
export type PreventWillMessage = boolean;
export interface DeleteConnectionRequest {
    clientId: string;
    cleanSession?: boolean;
    preventWillMessage?: boolean;
}
export declare const DeleteConnectionRequest: S.Schema<DeleteConnectionRequest>;
export interface DeleteConnectionResponse {
}
export declare const DeleteConnectionResponse: S.Schema<DeleteConnectionResponse>;
export type ThingName = string;
export type ShadowName = string;
export interface DeleteThingShadowRequest {
    thingName: string;
    shadowName?: string;
}
export declare const DeleteThingShadowRequest: S.Schema<DeleteThingShadowRequest>;
export interface DeleteThingShadowResponse {
    payload: T.StreamingOutputBody;
}
export declare const DeleteThingShadowResponse: S.Schema<DeleteThingShadowResponse>;
export type IncludeSocketInformation = boolean;
export interface GetConnectionRequest {
    clientId: string;
    includeSocketInformation?: boolean;
}
export declare const GetConnectionRequest: S.Schema<GetConnectionRequest>;
export type Connected = boolean;
export type SourceIp = string;
export type SourcePort = number;
export type TargetIp = string;
export type TargetPort = number;
export type KeepAliveDuration = number;
export type DisconnectReason = string;
export type SessionExpiry = number;
export type VpcEndpointId = string;
export interface GetConnectionResponse {
    connected?: boolean;
    thingName?: string;
    cleanSession?: boolean;
    sourceIp?: string;
    sourcePort?: number;
    targetIp?: string;
    targetPort?: number;
    keepAliveDuration?: number;
    connectedSince?: number;
    disconnectedSince?: number;
    disconnectReason?: string;
    sessionExpiry?: number;
    clientId?: string;
    vpcEndpointId?: string;
}
export declare const GetConnectionResponse: S.Schema<GetConnectionResponse>;
export type Topic = string;
export interface GetRetainedMessageRequest {
    topic: string;
}
export declare const GetRetainedMessageRequest: S.Schema<GetRetainedMessageRequest>;
export type Payload = Uint8Array;
export type Qos = number;
export type UserPropertiesBlob = Uint8Array;
export interface GetRetainedMessageResponse {
    topic?: string;
    payload?: Uint8Array;
    qos?: number;
    lastModifiedTime?: number;
    userProperties?: Uint8Array;
}
export declare const GetRetainedMessageResponse: S.Schema<GetRetainedMessageResponse>;
export interface GetThingShadowRequest {
    thingName: string;
    shadowName?: string;
}
export declare const GetThingShadowRequest: S.Schema<GetThingShadowRequest>;
export interface GetThingShadowResponse {
    payload?: T.StreamingOutputBody;
}
export declare const GetThingShadowResponse: S.Schema<GetThingShadowResponse>;
export type NextToken = string;
export type PageSize = number;
export interface ListNamedShadowsForThingRequest {
    thingName: string;
    nextToken?: string;
    pageSize?: number;
}
export declare const ListNamedShadowsForThingRequest: S.Schema<ListNamedShadowsForThingRequest>;
export type NamedShadowList = string[];
export declare const NamedShadowList: any;
export interface ListNamedShadowsForThingResponse {
    results?: string[];
    nextToken?: string;
    timestamp?: number;
}
export declare const ListNamedShadowsForThingResponse: S.Schema<ListNamedShadowsForThingResponse>;
export type MaxResults = number;
export interface ListRetainedMessagesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListRetainedMessagesRequest: S.Schema<ListRetainedMessagesRequest>;
export type PayloadSize = number;
export interface RetainedMessageSummary {
    topic?: string;
    payloadSize?: number;
    qos?: number;
    lastModifiedTime?: number;
}
export declare const RetainedMessageSummary: S.Schema<RetainedMessageSummary>;
export type RetainedMessageList = RetainedMessageSummary[];
export declare const RetainedMessageList: any;
export interface ListRetainedMessagesResponse {
    retainedTopics?: RetainedMessageSummary[];
    nextToken?: string;
}
export declare const ListRetainedMessagesResponse: S.Schema<ListRetainedMessagesResponse>;
export interface ListSubscriptionsRequest {
    clientId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListSubscriptionsRequest: S.Schema<ListSubscriptionsRequest>;
export type TopicFilter = string;
export interface SubscriptionSummary {
    topicFilter: string;
    qos: number;
}
export declare const SubscriptionSummary: S.Schema<SubscriptionSummary>;
export type SubscriptionList = SubscriptionSummary[];
export declare const SubscriptionList: any;
export interface ListSubscriptionsResponse {
    subscriptions?: SubscriptionSummary[];
    nextToken?: string;
}
export declare const ListSubscriptionsResponse: S.Schema<ListSubscriptionsResponse>;
export type Retain = boolean;
export type SynthesizedJsonUserProperties = string;
export type PayloadFormatIndicator = "UNSPECIFIED_BYTES" | "UTF8_DATA" | (string & {});
export declare const PayloadFormatIndicator: any;
export type ContentType = string;
export type ResponseTopic = string;
export type CorrelationData = string;
export type MessageExpiry = number;
export interface PublishRequest {
    topic: string;
    qos?: number;
    retain?: boolean;
    payload?: T.StreamingInputBody;
    userProperties?: string;
    payloadFormatIndicator?: PayloadFormatIndicator;
    contentType?: string;
    responseTopic?: string;
    correlationData?: string;
    messageExpiry?: number;
}
export declare const PublishRequest: S.Schema<PublishRequest>;
export interface PublishResponse {
}
export declare const PublishResponse: S.Schema<PublishResponse>;
export type Confirmation = boolean;
export type TimeoutInSeconds = number;
export interface SendDirectMessageRequest {
    clientId: string;
    topic: string;
    contentType?: string;
    responseTopic?: string;
    confirmation?: boolean;
    timeout?: number;
    payload?: T.StreamingInputBody;
    userProperties?: string;
    payloadFormatIndicator?: PayloadFormatIndicator;
    correlationData?: string;
}
export declare const SendDirectMessageRequest: S.Schema<SendDirectMessageRequest>;
export type ResponseMessage = string;
export type TraceId = string;
export interface SendDirectMessageResponse {
    message?: string;
    traceId?: string;
}
export declare const SendDirectMessageResponse: S.Schema<SendDirectMessageResponse>;
export interface UpdateThingShadowRequest {
    thingName: string;
    shadowName?: string;
    payload: T.StreamingInputBody;
}
export declare const UpdateThingShadowRequest: S.Schema<UpdateThingShadowRequest>;
export interface UpdateThingShadowResponse {
    payload?: T.StreamingOutputBody;
}
export declare const UpdateThingShadowResponse: S.Schema<UpdateThingShadowResponse>;
export type ErrorMessage = string;
export type DeleteConnectionError = ForbiddenException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Disconnects a connected MQTT client from Amazon Web Services IoT Core. When you disconnect a client, Amazon Web Services IoT Core closes the client's network connection and optionally cleans the session state.
 *
 * Requires permission to access the DeleteConnection action.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteThingShadowError = InternalFailureException | InvalidRequestException | MethodNotAllowedException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | UnsupportedDocumentEncodingException | ForbiddenException | CommonErrors;
/**
 * Deletes the shadow for the specified thing.
 *
 * Requires permission to access the DeleteThingShadow action.
 *
 * For more information, see DeleteThingShadow in the IoT Developer Guide.
 */
export declare const deleteThingShadow: API.OperationMethod<DeleteThingShadowRequest, DeleteThingShadowResponse, DeleteThingShadowError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = ForbiddenException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves connection information for the specified MQTT client.
 *
 * Requires permission to access the GetConnection action.
 */
export declare const getConnection: API.OperationMethod<GetConnectionRequest, GetConnectionResponse, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetRetainedMessageError = InternalFailureException | InvalidRequestException | MethodNotAllowedException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ForbiddenException | CommonErrors;
/**
 * Gets the details of a single retained message for the specified topic.
 *
 * This action returns the message payload of the retained message, which can
 * incur messaging costs. To list only the topic names of the retained messages, call
 * ListRetainedMessages.
 *
 * Requires permission to access the GetRetainedMessage action.
 *
 * For more information about messaging costs, see Amazon Web Services IoT Core
 * pricing - Messaging.
 */
export declare const getRetainedMessage: API.OperationMethod<GetRetainedMessageRequest, GetRetainedMessageResponse, GetRetainedMessageError, Credentials | HttpClient.HttpClient>;
export type GetThingShadowError = InternalFailureException | InvalidRequestException | MethodNotAllowedException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | UnsupportedDocumentEncodingException | ForbiddenException | CommonErrors;
/**
 * Gets the shadow for the specified thing.
 *
 * Requires permission to access the GetThingShadow action.
 *
 * For more information, see GetThingShadow in the
 * IoT Developer Guide.
 */
export declare const getThingShadow: API.OperationMethod<GetThingShadowRequest, GetThingShadowResponse, GetThingShadowError, Credentials | HttpClient.HttpClient>;
export type ListNamedShadowsForThingError = InternalFailureException | InvalidRequestException | MethodNotAllowedException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ForbiddenException | CommonErrors;
/**
 * Lists the shadows for the specified thing.
 *
 * Requires permission to access the ListNamedShadowsForThing action.
 */
export declare const listNamedShadowsForThing: API.OperationMethod<ListNamedShadowsForThingRequest, ListNamedShadowsForThingResponse, ListNamedShadowsForThingError, Credentials | HttpClient.HttpClient>;
export type ListRetainedMessagesError = InternalFailureException | InvalidRequestException | MethodNotAllowedException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | ForbiddenException | CommonErrors;
/**
 * Lists summary information about the retained messages stored for the account.
 *
 * This action returns only the topic names of the retained messages. It doesn't
 * return any message payloads. Although this action doesn't return a message payload,
 * it can still incur messaging costs.
 *
 * To get the message payload of a retained message, call
 * GetRetainedMessage
 * with the topic name of the retained message.
 *
 * Requires permission to access the ListRetainedMessages action.
 *
 * For more information about messaging costs, see Amazon Web Services IoT Core
 * pricing - Messaging.
 */
export declare const listRetainedMessages: API.PaginatedOperationMethod<ListRetainedMessagesRequest, ListRetainedMessagesResponse, ListRetainedMessagesError, Credentials | HttpClient.HttpClient, RetainedMessageSummary>;
export type ListSubscriptionsError = ForbiddenException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all subscriptions for MQTT clients with active sessions, including offline clients with persistent sessions.
 *
 * Requires permission to access the ListSubscriptions action.
 */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsRequest, ListSubscriptionsResponse, ListSubscriptionsError, Credentials | HttpClient.HttpClient, SubscriptionSummary>;
export type PublishError = InternalFailureException | InvalidRequestException | MethodNotAllowedException | ThrottlingException | UnauthorizedException | ForbiddenException | CommonErrors;
/**
 * Publishes an MQTT message.
 *
 * Requires permission to access the Publish action.
 *
 * For more information about MQTT messages, see
 * MQTT Protocol in the
 * IoT Developer Guide.
 *
 * For more information about messaging costs, see Amazon Web Services IoT Core
 * pricing - Messaging.
 */
export declare const publish: API.OperationMethod<PublishRequest, PublishResponse, PublishError, Credentials | HttpClient.HttpClient>;
export type SendDirectMessageError = ForbiddenException | GatewayTimeoutException | InternalFailureException | InvalidRequestException | RequestEntityTooLargeException | ResourceNotFoundException | ThrottlingException | UnauthorizedException | CommonErrors;
/**
 * Sends an MQTT message directly to a specific client identified by its client ID.
 *
 * `SendDirectMessage` targets a single client ID. The receiving client does not
 * need to subscribe to the topic, but the receiver's policy must allow `iot:Receive` on the specified topic.
 *
 * Requires permission to access the SendDirectMessage action.
 *
 * For more information about messaging costs, see Amazon Web Services IoT Core
 * pricing.
 */
export declare const sendDirectMessage: API.OperationMethod<SendDirectMessageRequest, SendDirectMessageResponse, SendDirectMessageError, Credentials | HttpClient.HttpClient>;
export type UpdateThingShadowError = ConflictException | InternalFailureException | InvalidRequestException | MethodNotAllowedException | RequestEntityTooLargeException | ServiceUnavailableException | ThrottlingException | UnauthorizedException | UnsupportedDocumentEncodingException | ForbiddenException | CommonErrors;
/**
 * Updates the shadow for the specified thing.
 *
 * Requires permission to access the UpdateThingShadow action.
 *
 * For more information, see UpdateThingShadow in the
 * IoT Developer Guide.
 */
export declare const updateThingShadow: API.OperationMethod<UpdateThingShadowRequest, UpdateThingShadowResponse, UpdateThingShadowError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iot-data-plane.d.ts.map