import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface GetGlyphsRequest {
    FontStack: string;
    FontUnicodeRange: string;
}
export declare const GetGlyphsRequest: S.Schema<GetGlyphsRequest>;
export interface GetGlyphsResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
    ETag?: string;
}
export declare const GetGlyphsResponse: S.Schema<GetGlyphsResponse>;
export type MapStyle = "Standard" | "Monochrome" | "Hybrid" | "Satellite" | (string & {});
export declare const MapStyle: any;
export type ColorScheme = "Light" | "Dark" | (string & {});
export declare const ColorScheme: any;
export type Variant = "Default" | (string & {});
export declare const Variant: any;
export interface GetSpritesRequest {
    FileName: string;
    Style: MapStyle;
    ColorScheme: ColorScheme;
    Variant: Variant;
}
export declare const GetSpritesRequest: S.Schema<GetSpritesRequest>;
export interface GetSpritesResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
    ETag?: string;
}
export declare const GetSpritesResponse: S.Schema<GetSpritesResponse>;
export type PositionListString = string | redacted.Redacted<string>;
export type PositionString = string | redacted.Redacted<string>;
export type CompactOverlay = string | redacted.Redacted<string>;
export type GeoJsonOverlay = string | redacted.Redacted<string>;
export type SensitiveInteger = number;
export type ApiKey = string | redacted.Redacted<string>;
export type LabelSize = "Small" | "Large" | (string & {});
export declare const LabelSize: any;
export type LanguageTag = string;
export type CountryCode = string | redacted.Redacted<string>;
export type MapFeatureMode = "Enabled" | "Disabled" | (string & {});
export declare const MapFeatureMode: any;
export type DistanceMeters = number;
export type ScaleBarUnit = "Kilometers" | "KilometersMiles" | "Miles" | "MilesKilometers" | (string & {});
export declare const ScaleBarUnit: any;
export type StaticMapStyle = "Satellite" | "Standard" | (string & {});
export declare const StaticMapStyle: any;
export type SensitiveFloat = number;
export interface GetStaticMapRequest {
    BoundingBox?: string | redacted.Redacted<string>;
    BoundedPositions?: string | redacted.Redacted<string>;
    Center?: string | redacted.Redacted<string>;
    ColorScheme?: ColorScheme;
    CompactOverlay?: string | redacted.Redacted<string>;
    CropLabels?: boolean;
    GeoJsonOverlay?: string | redacted.Redacted<string>;
    Height: number;
    Key?: string | redacted.Redacted<string>;
    LabelSize?: LabelSize;
    Language?: string;
    Padding?: number;
    PoliticalView?: string | redacted.Redacted<string>;
    PointsOfInterests?: MapFeatureMode;
    Radius?: number;
    FileName: string;
    ScaleBarUnit?: ScaleBarUnit;
    Style?: StaticMapStyle;
    Width: number;
    Zoom?: number;
}
export declare const GetStaticMapRequest: S.Schema<GetStaticMapRequest>;
export interface GetStaticMapResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
    ETag?: string;
    PricingBucket: string;
}
export declare const GetStaticMapResponse: S.Schema<GetStaticMapResponse>;
export type Terrain = "Hillshade" | "Terrain3D" | (string & {});
export declare const Terrain: any;
export type ContourDensity = "Low" | "Medium" | "High" | (string & {});
export declare const ContourDensity: any;
export type Traffic = "All" | "Congestion" | (string & {});
export declare const Traffic: any;
export type TravelMode = "Transit" | "Truck" | (string & {});
export declare const TravelMode: any;
export type TravelModeList = TravelMode[];
export declare const TravelModeList: any;
export type Buildings = "Buildings3D" | (string & {});
export declare const Buildings: any;
export type PoiDensity = "Off" | "VerySparse" | "Sparse" | "Default" | "Dense" | "VeryDense" | (string & {});
export declare const PoiDensity: any;
export type PoiCategory = "FoodAndDrink" | "Entertainment" | "SightsAndMuseums" | "Transportation" | "Accommodations" | "LeisureAndOutdoor" | "Shopping" | "BusinessAndServices" | "FacilitiesAndBuildings" | (string & {});
export declare const PoiCategory: any;
export type PoiCategoryList = PoiCategory[];
export declare const PoiCategoryList: any;
export interface GetStyleDescriptorRequest {
    Style: MapStyle;
    ColorScheme?: ColorScheme;
    PoliticalView?: string | redacted.Redacted<string>;
    Terrain?: Terrain;
    ContourDensity?: ContourDensity;
    Traffic?: Traffic;
    TravelModes?: TravelMode[];
    Buildings?: Buildings;
    PoiDensity?: PoiDensity;
    PoiCategories?: PoiCategory[];
    Key?: string | redacted.Redacted<string>;
}
export declare const GetStyleDescriptorRequest: S.Schema<GetStyleDescriptorRequest>;
export interface GetStyleDescriptorResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
    ETag?: string;
}
export declare const GetStyleDescriptorResponse: S.Schema<GetStyleDescriptorResponse>;
export type TileAdditionalFeature = "ContourLines" | "Hillshade" | "Logistics" | "Transit" | (string & {});
export declare const TileAdditionalFeature: any;
export type TileAdditionalFeatureList = TileAdditionalFeature[];
export declare const TileAdditionalFeatureList: any;
export type Tileset = string;
export type SensitiveString = string | redacted.Redacted<string>;
export interface GetTileRequest {
    AdditionalFeatures?: TileAdditionalFeature[];
    Tileset: string;
    Z: string | redacted.Redacted<string>;
    X: string | redacted.Redacted<string>;
    Y: string | redacted.Redacted<string>;
    Key?: string | redacted.Redacted<string>;
}
export declare const GetTileRequest: S.Schema<GetTileRequest>;
export interface GetTileResponse {
    Blob?: Uint8Array;
    ContentType?: string;
    CacheControl?: string;
    ETag?: string;
    PricingBucket: string;
}
export declare const GetTileResponse: S.Schema<GetTileResponse>;
export type ValidationExceptionReason = "UnknownOperation" | "Missing" | "CannotParse" | "FieldValidationFailed" | "Other" | "UnknownField" | (string & {});
export declare const ValidationExceptionReason: any;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type GetGlyphsError = CommonErrors;
/**
 * `GetGlyphs` returns the map's glyphs.
 *
 * For more information, see Style labels with glyphs in the *Amazon Location Service Developer Guide*.
 */
export declare const getGlyphs: API.OperationMethod<GetGlyphsRequest, GetGlyphsResponse, GetGlyphsError, Credentials | HttpClient.HttpClient>;
export type GetSpritesError = CommonErrors;
/**
 * `GetSprites` returns the map's sprites.
 *
 * For more information, see Style iconography with sprites in the *Amazon Location Service Developer Guide*.
 */
export declare const getSprites: API.OperationMethod<GetSpritesRequest, GetSpritesResponse, GetSpritesError, Credentials | HttpClient.HttpClient>;
export type GetStaticMapError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetStaticMap` provides high-quality static map images with customizable options. You can modify the map's appearance and overlay additional information. It's an ideal solution for applications requiring tailored static map snapshots. Not supported in `ap-southeast-1` and `ap-southeast-5` regions for GrabMaps customers.
 *
 * For more information, see the following topics in the *Amazon Location Service Developer Guide*:
 *
 * - Static maps
 *
 * - Customize static maps
 *
 * - Overlay on the static map
 */
export declare const getStaticMap: API.OperationMethod<GetStaticMapRequest, GetStaticMapResponse, GetStaticMapError, Credentials | HttpClient.HttpClient>;
export type GetStyleDescriptorError = CommonErrors;
/**
 * `GetStyleDescriptor` returns information about the style.
 *
 * For more information, see Style dynamic maps in the *Amazon Location Service Developer Guide*.
 */
export declare const getStyleDescriptor: API.OperationMethod<GetStyleDescriptorRequest, GetStyleDescriptorResponse, GetStyleDescriptorError, Credentials | HttpClient.HttpClient>;
export type GetTileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `GetTile` returns a tile. Map tiles are used by clients to render a map. They're addressed using a grid arrangement with an X coordinate, Y coordinate, and Z (zoom) level.
 *
 * For more information, see Tiles in the *Amazon Location Service Developer Guide*.
 */
export declare const getTile: API.OperationMethod<GetTileRequest, GetTileResponse, GetTileError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=geo-maps.d.ts.map