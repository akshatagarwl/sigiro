import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BadRequestException_base: S.Class<BadRequestException, S.TaggedStruct<"BadRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.Class<InternalServerErrorException, S.TaggedStruct<"InternalServerErrorException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.Class<NotFoundException, S.TaggedStruct<"NotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.Class<UnauthorizedException, S.TaggedStruct<"UnauthorizedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type __integerMin1Max8 = number;
export type __integerMin1Max100 = number;
export interface ScaleInPolicy {
    cpuUtilizationPercentage: number;
}
export declare const ScaleInPolicy: S.Schema<ScaleInPolicy>;
export interface ScaleOutPolicy {
    cpuUtilizationPercentage: number;
}
export declare const ScaleOutPolicy: S.Schema<ScaleOutPolicy>;
export interface AutoScaling {
    maxWorkerCount: number;
    mcuCount: number;
    minWorkerCount: number;
    scaleInPolicy?: ScaleInPolicy;
    scaleOutPolicy?: ScaleOutPolicy;
    maxAutoscalingTaskCount?: number;
}
export declare const AutoScaling: S.Schema<AutoScaling>;
export interface ProvisionedCapacity {
    mcuCount: number;
    workerCount: number;
}
export declare const ProvisionedCapacity: S.Schema<ProvisionedCapacity>;
export interface Capacity {
    autoScaling?: AutoScaling;
    provisionedCapacity?: ProvisionedCapacity;
}
export declare const Capacity: S.Schema<Capacity>;
export type ConnectorConfiguration = {
    [key: string]: string | undefined;
};
export declare const ConnectorConfiguration: any;
export type __stringMax1024 = string;
export type __stringMin1Max128 = string;
export type __listOf__string = string[];
export declare const __listOf__string: any;
export interface Vpc {
    securityGroups?: string[];
    subnets: string[];
}
export declare const Vpc: S.Schema<Vpc>;
export interface ApacheKafkaCluster {
    bootstrapServers: string;
    vpc: Vpc;
}
export declare const ApacheKafkaCluster: S.Schema<ApacheKafkaCluster>;
export interface KafkaCluster {
    apacheKafkaCluster: ApacheKafkaCluster;
}
export declare const KafkaCluster: S.Schema<KafkaCluster>;
export type KafkaClusterClientAuthenticationType = string;
export interface KafkaClusterClientAuthentication {
    authenticationType: string;
}
export declare const KafkaClusterClientAuthentication: S.Schema<KafkaClusterClientAuthentication>;
export type KafkaClusterEncryptionInTransitType = string;
export interface KafkaClusterEncryptionInTransit {
    encryptionType: string;
}
export declare const KafkaClusterEncryptionInTransit: S.Schema<KafkaClusterEncryptionInTransit>;
export interface CloudWatchLogsLogDelivery {
    enabled: boolean;
    logGroup?: string;
}
export declare const CloudWatchLogsLogDelivery: S.Schema<CloudWatchLogsLogDelivery>;
export interface FirehoseLogDelivery {
    deliveryStream?: string;
    enabled: boolean;
}
export declare const FirehoseLogDelivery: S.Schema<FirehoseLogDelivery>;
export interface S3LogDelivery {
    bucket?: string;
    enabled: boolean;
    prefix?: string;
}
export declare const S3LogDelivery: S.Schema<S3LogDelivery>;
export interface WorkerLogDelivery {
    cloudWatchLogs?: CloudWatchLogsLogDelivery;
    firehose?: FirehoseLogDelivery;
    s3?: S3LogDelivery;
}
export declare const WorkerLogDelivery: S.Schema<WorkerLogDelivery>;
export interface LogDelivery {
    workerLogDelivery: WorkerLogDelivery;
}
export declare const LogDelivery: S.Schema<LogDelivery>;
export type NetworkType = string;
export type __longMin1 = number;
export interface CustomPlugin {
    customPluginArn: string;
    revision: number;
}
export declare const CustomPlugin: S.Schema<CustomPlugin>;
export interface Plugin {
    customPlugin: CustomPlugin;
}
export declare const Plugin: S.Schema<Plugin>;
export type __listOfPlugin = Plugin[];
export declare const __listOfPlugin: any;
export interface WorkerConfiguration {
    revision: number;
    workerConfigurationArn: string;
}
export declare const WorkerConfiguration: S.Schema<WorkerConfiguration>;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export declare const Tags: any;
export interface CreateConnectorRequest {
    capacity: Capacity;
    connectorConfiguration: {
        [key: string]: string | undefined;
    };
    connectorDescription?: string;
    connectorName: string;
    kafkaCluster: KafkaCluster;
    kafkaClusterClientAuthentication: KafkaClusterClientAuthentication;
    kafkaClusterEncryptionInTransit: KafkaClusterEncryptionInTransit;
    kafkaConnectVersion: string;
    logDelivery?: LogDelivery;
    networkType?: string;
    plugins: Plugin[];
    serviceExecutionRoleArn: string;
    workerConfiguration?: WorkerConfiguration;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConnectorRequest: S.Schema<CreateConnectorRequest>;
export type ConnectorState = string;
export interface CreateConnectorResponse {
    connectorArn?: string;
    connectorName?: string;
    connectorState?: string;
}
export declare const CreateConnectorResponse: S.Schema<CreateConnectorResponse>;
export type CustomPluginContentType = string;
export interface S3Location {
    bucketArn: string;
    fileKey: string;
    objectVersion?: string;
}
export declare const S3Location: S.Schema<S3Location>;
export interface CustomPluginLocation {
    s3Location: S3Location;
}
export declare const CustomPluginLocation: S.Schema<CustomPluginLocation>;
export interface CreateCustomPluginRequest {
    contentType: string;
    description?: string;
    location: CustomPluginLocation;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCustomPluginRequest: S.Schema<CreateCustomPluginRequest>;
export type CustomPluginState = string;
export interface CreateCustomPluginResponse {
    customPluginArn?: string;
    customPluginState?: string;
    name?: string;
    revision?: number;
}
export declare const CreateCustomPluginResponse: S.Schema<CreateCustomPluginResponse>;
export type __sensitiveString = string | redacted.Redacted<string>;
export interface CreateWorkerConfigurationRequest {
    description?: string;
    name: string;
    propertiesFileContent: string | redacted.Redacted<string>;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateWorkerConfigurationRequest: S.Schema<CreateWorkerConfigurationRequest>;
export type __timestampIso8601 = Date;
export interface WorkerConfigurationRevisionSummary {
    creationTime?: Date;
    description?: string;
    revision?: number;
}
export declare const WorkerConfigurationRevisionSummary: S.Schema<WorkerConfigurationRevisionSummary>;
export type WorkerConfigurationState = string;
export interface CreateWorkerConfigurationResponse {
    creationTime?: Date;
    latestRevision?: WorkerConfigurationRevisionSummary;
    name?: string;
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export declare const CreateWorkerConfigurationResponse: S.Schema<CreateWorkerConfigurationResponse>;
export interface DeleteConnectorRequest {
    connectorArn: string;
    currentVersion?: string;
}
export declare const DeleteConnectorRequest: S.Schema<DeleteConnectorRequest>;
export interface DeleteConnectorResponse {
    connectorArn?: string;
    connectorState?: string;
}
export declare const DeleteConnectorResponse: S.Schema<DeleteConnectorResponse>;
export interface DeleteCustomPluginRequest {
    customPluginArn: string;
}
export declare const DeleteCustomPluginRequest: S.Schema<DeleteCustomPluginRequest>;
export interface DeleteCustomPluginResponse {
    customPluginArn?: string;
    customPluginState?: string;
}
export declare const DeleteCustomPluginResponse: S.Schema<DeleteCustomPluginResponse>;
export interface DeleteWorkerConfigurationRequest {
    workerConfigurationArn: string;
}
export declare const DeleteWorkerConfigurationRequest: S.Schema<DeleteWorkerConfigurationRequest>;
export interface DeleteWorkerConfigurationResponse {
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export declare const DeleteWorkerConfigurationResponse: S.Schema<DeleteWorkerConfigurationResponse>;
export interface DescribeConnectorRequest {
    connectorArn: string;
}
export declare const DescribeConnectorRequest: S.Schema<DescribeConnectorRequest>;
export interface ScaleInPolicyDescription {
    cpuUtilizationPercentage?: number;
}
export declare const ScaleInPolicyDescription: S.Schema<ScaleInPolicyDescription>;
export interface ScaleOutPolicyDescription {
    cpuUtilizationPercentage?: number;
}
export declare const ScaleOutPolicyDescription: S.Schema<ScaleOutPolicyDescription>;
export interface AutoScalingDescription {
    maxWorkerCount?: number;
    mcuCount?: number;
    minWorkerCount?: number;
    scaleInPolicy?: ScaleInPolicyDescription;
    scaleOutPolicy?: ScaleOutPolicyDescription;
    maxAutoscalingTaskCount?: number;
}
export declare const AutoScalingDescription: S.Schema<AutoScalingDescription>;
export interface ProvisionedCapacityDescription {
    mcuCount?: number;
    workerCount?: number;
}
export declare const ProvisionedCapacityDescription: S.Schema<ProvisionedCapacityDescription>;
export interface CapacityDescription {
    autoScaling?: AutoScalingDescription;
    provisionedCapacity?: ProvisionedCapacityDescription;
}
export declare const CapacityDescription: S.Schema<CapacityDescription>;
export interface VpcDescription {
    securityGroups?: string[];
    subnets?: string[];
}
export declare const VpcDescription: S.Schema<VpcDescription>;
export interface ApacheKafkaClusterDescription {
    bootstrapServers?: string;
    vpc?: VpcDescription;
}
export declare const ApacheKafkaClusterDescription: S.Schema<ApacheKafkaClusterDescription>;
export interface KafkaClusterDescription {
    apacheKafkaCluster?: ApacheKafkaClusterDescription;
}
export declare const KafkaClusterDescription: S.Schema<KafkaClusterDescription>;
export interface KafkaClusterClientAuthenticationDescription {
    authenticationType?: string;
}
export declare const KafkaClusterClientAuthenticationDescription: S.Schema<KafkaClusterClientAuthenticationDescription>;
export interface KafkaClusterEncryptionInTransitDescription {
    encryptionType?: string;
}
export declare const KafkaClusterEncryptionInTransitDescription: S.Schema<KafkaClusterEncryptionInTransitDescription>;
export interface CloudWatchLogsLogDeliveryDescription {
    enabled?: boolean;
    logGroup?: string;
}
export declare const CloudWatchLogsLogDeliveryDescription: S.Schema<CloudWatchLogsLogDeliveryDescription>;
export interface FirehoseLogDeliveryDescription {
    deliveryStream?: string;
    enabled?: boolean;
}
export declare const FirehoseLogDeliveryDescription: S.Schema<FirehoseLogDeliveryDescription>;
export interface S3LogDeliveryDescription {
    bucket?: string;
    enabled?: boolean;
    prefix?: string;
}
export declare const S3LogDeliveryDescription: S.Schema<S3LogDeliveryDescription>;
export interface WorkerLogDeliveryDescription {
    cloudWatchLogs?: CloudWatchLogsLogDeliveryDescription;
    firehose?: FirehoseLogDeliveryDescription;
    s3?: S3LogDeliveryDescription;
}
export declare const WorkerLogDeliveryDescription: S.Schema<WorkerLogDeliveryDescription>;
export interface LogDeliveryDescription {
    workerLogDelivery?: WorkerLogDeliveryDescription;
}
export declare const LogDeliveryDescription: S.Schema<LogDeliveryDescription>;
export interface CustomPluginDescription {
    customPluginArn?: string;
    revision?: number;
}
export declare const CustomPluginDescription: S.Schema<CustomPluginDescription>;
export interface PluginDescription {
    customPlugin?: CustomPluginDescription;
}
export declare const PluginDescription: S.Schema<PluginDescription>;
export type __listOfPluginDescription = PluginDescription[];
export declare const __listOfPluginDescription: any;
export interface WorkerConfigurationDescription {
    revision?: number;
    workerConfigurationArn?: string;
}
export declare const WorkerConfigurationDescription: S.Schema<WorkerConfigurationDescription>;
export interface StateDescription {
    code?: string;
    message?: string;
}
export declare const StateDescription: S.Schema<StateDescription>;
export interface DescribeConnectorResponse {
    capacity?: CapacityDescription;
    connectorArn?: string;
    connectorConfiguration?: {
        [key: string]: string | undefined;
    };
    connectorDescription?: string;
    connectorName?: string;
    connectorState?: string;
    creationTime?: Date;
    currentVersion?: string;
    kafkaCluster?: KafkaClusterDescription;
    kafkaClusterClientAuthentication?: KafkaClusterClientAuthenticationDescription;
    kafkaClusterEncryptionInTransit?: KafkaClusterEncryptionInTransitDescription;
    kafkaConnectVersion?: string;
    logDelivery?: LogDeliveryDescription;
    networkType?: string;
    plugins?: PluginDescription[];
    serviceExecutionRoleArn?: string;
    workerConfiguration?: WorkerConfigurationDescription;
    stateDescription?: StateDescription;
}
export declare const DescribeConnectorResponse: S.Schema<DescribeConnectorResponse>;
export interface DescribeConnectorOperationRequest {
    connectorOperationArn: string;
}
export declare const DescribeConnectorOperationRequest: S.Schema<DescribeConnectorOperationRequest>;
export type ConnectorOperationState = string;
export type ConnectorOperationType = string;
export type ConnectorOperationStepType = string;
export type ConnectorOperationStepState = string;
export interface ConnectorOperationStep {
    stepType?: string;
    stepState?: string;
}
export declare const ConnectorOperationStep: S.Schema<ConnectorOperationStep>;
export type __listOfConnectorOperationStep = ConnectorOperationStep[];
export declare const __listOfConnectorOperationStep: any;
export interface WorkerSetting {
    capacity?: CapacityDescription;
}
export declare const WorkerSetting: S.Schema<WorkerSetting>;
export interface DescribeConnectorOperationResponse {
    connectorArn?: string;
    connectorOperationArn?: string;
    connectorOperationState?: string;
    connectorOperationType?: string;
    operationSteps?: ConnectorOperationStep[];
    originWorkerSetting?: WorkerSetting;
    originConnectorConfiguration?: {
        [key: string]: string | undefined;
    };
    targetWorkerSetting?: WorkerSetting;
    targetConnectorConfiguration?: {
        [key: string]: string | undefined;
    };
    errorInfo?: StateDescription;
    creationTime?: Date;
    endTime?: Date;
}
export declare const DescribeConnectorOperationResponse: S.Schema<DescribeConnectorOperationResponse>;
export interface DescribeCustomPluginRequest {
    customPluginArn: string;
}
export declare const DescribeCustomPluginRequest: S.Schema<DescribeCustomPluginRequest>;
export interface CustomPluginFileDescription {
    fileMd5?: string;
    fileSize?: number;
}
export declare const CustomPluginFileDescription: S.Schema<CustomPluginFileDescription>;
export interface S3LocationDescription {
    bucketArn?: string;
    fileKey?: string;
    objectVersion?: string;
}
export declare const S3LocationDescription: S.Schema<S3LocationDescription>;
export interface CustomPluginLocationDescription {
    s3Location?: S3LocationDescription;
}
export declare const CustomPluginLocationDescription: S.Schema<CustomPluginLocationDescription>;
export interface CustomPluginRevisionSummary {
    contentType?: string;
    creationTime?: Date;
    description?: string;
    fileDescription?: CustomPluginFileDescription;
    location?: CustomPluginLocationDescription;
    revision?: number;
}
export declare const CustomPluginRevisionSummary: S.Schema<CustomPluginRevisionSummary>;
export interface DescribeCustomPluginResponse {
    creationTime?: Date;
    customPluginArn?: string;
    customPluginState?: string;
    description?: string;
    latestRevision?: CustomPluginRevisionSummary;
    name?: string;
    stateDescription?: StateDescription;
}
export declare const DescribeCustomPluginResponse: S.Schema<DescribeCustomPluginResponse>;
export interface DescribeWorkerConfigurationRequest {
    workerConfigurationArn: string;
}
export declare const DescribeWorkerConfigurationRequest: S.Schema<DescribeWorkerConfigurationRequest>;
export interface WorkerConfigurationRevisionDescription {
    creationTime?: Date;
    description?: string;
    propertiesFileContent?: string | redacted.Redacted<string>;
    revision?: number;
}
export declare const WorkerConfigurationRevisionDescription: S.Schema<WorkerConfigurationRevisionDescription>;
export interface DescribeWorkerConfigurationResponse {
    creationTime?: Date;
    description?: string;
    latestRevision?: WorkerConfigurationRevisionDescription;
    name?: string;
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export declare const DescribeWorkerConfigurationResponse: S.Schema<DescribeWorkerConfigurationResponse>;
export type MaxResults = number;
export interface ListConnectorOperationsRequest {
    connectorArn: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListConnectorOperationsRequest: S.Schema<ListConnectorOperationsRequest>;
export interface ConnectorOperationSummary {
    connectorOperationArn?: string;
    connectorOperationType?: string;
    connectorOperationState?: string;
    creationTime?: Date;
    endTime?: Date;
}
export declare const ConnectorOperationSummary: S.Schema<ConnectorOperationSummary>;
export type __listOfConnectorOperationSummary = ConnectorOperationSummary[];
export declare const __listOfConnectorOperationSummary: any;
export interface ListConnectorOperationsResponse {
    connectorOperations?: ConnectorOperationSummary[];
    nextToken?: string;
}
export declare const ListConnectorOperationsResponse: S.Schema<ListConnectorOperationsResponse>;
export interface ListConnectorsRequest {
    connectorNamePrefix?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListConnectorsRequest: S.Schema<ListConnectorsRequest>;
export interface ConnectorSummary {
    capacity?: CapacityDescription;
    connectorArn?: string;
    connectorDescription?: string;
    connectorName?: string;
    connectorState?: string;
    creationTime?: Date;
    currentVersion?: string;
    kafkaCluster?: KafkaClusterDescription;
    kafkaClusterClientAuthentication?: KafkaClusterClientAuthenticationDescription;
    kafkaClusterEncryptionInTransit?: KafkaClusterEncryptionInTransitDescription;
    kafkaConnectVersion?: string;
    logDelivery?: LogDeliveryDescription;
    networkType?: string;
    plugins?: PluginDescription[];
    serviceExecutionRoleArn?: string;
    workerConfiguration?: WorkerConfigurationDescription;
}
export declare const ConnectorSummary: S.Schema<ConnectorSummary>;
export type __listOfConnectorSummary = ConnectorSummary[];
export declare const __listOfConnectorSummary: any;
export interface ListConnectorsResponse {
    connectors?: ConnectorSummary[];
    nextToken?: string;
}
export declare const ListConnectorsResponse: S.Schema<ListConnectorsResponse>;
export interface ListCustomPluginsRequest {
    maxResults?: number;
    nextToken?: string;
    namePrefix?: string;
}
export declare const ListCustomPluginsRequest: S.Schema<ListCustomPluginsRequest>;
export interface CustomPluginSummary {
    creationTime?: Date;
    customPluginArn?: string;
    customPluginState?: string;
    description?: string;
    latestRevision?: CustomPluginRevisionSummary;
    name?: string;
}
export declare const CustomPluginSummary: S.Schema<CustomPluginSummary>;
export type __listOfCustomPluginSummary = CustomPluginSummary[];
export declare const __listOfCustomPluginSummary: any;
export interface ListCustomPluginsResponse {
    customPlugins?: CustomPluginSummary[];
    nextToken?: string;
}
export declare const ListCustomPluginsResponse: S.Schema<ListCustomPluginsResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface ListWorkerConfigurationsRequest {
    maxResults?: number;
    nextToken?: string;
    namePrefix?: string;
}
export declare const ListWorkerConfigurationsRequest: S.Schema<ListWorkerConfigurationsRequest>;
export interface WorkerConfigurationSummary {
    creationTime?: Date;
    description?: string;
    latestRevision?: WorkerConfigurationRevisionSummary;
    name?: string;
    workerConfigurationArn?: string;
    workerConfigurationState?: string;
}
export declare const WorkerConfigurationSummary: S.Schema<WorkerConfigurationSummary>;
export type __listOfWorkerConfigurationSummary = WorkerConfigurationSummary[];
export declare const __listOfWorkerConfigurationSummary: any;
export interface ListWorkerConfigurationsResponse {
    nextToken?: string;
    workerConfigurations?: WorkerConfigurationSummary[];
}
export declare const ListWorkerConfigurationsResponse: S.Schema<ListWorkerConfigurationsResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface ScaleInPolicyUpdate {
    cpuUtilizationPercentage: number;
}
export declare const ScaleInPolicyUpdate: S.Schema<ScaleInPolicyUpdate>;
export interface ScaleOutPolicyUpdate {
    cpuUtilizationPercentage: number;
}
export declare const ScaleOutPolicyUpdate: S.Schema<ScaleOutPolicyUpdate>;
export interface AutoScalingUpdate {
    maxWorkerCount: number;
    mcuCount: number;
    minWorkerCount: number;
    scaleInPolicy: ScaleInPolicyUpdate;
    scaleOutPolicy: ScaleOutPolicyUpdate;
    maxAutoscalingTaskCount?: number;
}
export declare const AutoScalingUpdate: S.Schema<AutoScalingUpdate>;
export interface ProvisionedCapacityUpdate {
    mcuCount: number;
    workerCount: number;
}
export declare const ProvisionedCapacityUpdate: S.Schema<ProvisionedCapacityUpdate>;
export interface CapacityUpdate {
    autoScaling?: AutoScalingUpdate;
    provisionedCapacity?: ProvisionedCapacityUpdate;
}
export declare const CapacityUpdate: S.Schema<CapacityUpdate>;
export type ConnectorConfigurationUpdate = {
    [key: string]: string | undefined;
};
export declare const ConnectorConfigurationUpdate: any;
export interface UpdateConnectorRequest {
    capacity?: CapacityUpdate;
    connectorConfiguration?: {
        [key: string]: string | undefined;
    };
    connectorArn: string;
    currentVersion: string;
}
export declare const UpdateConnectorRequest: S.Schema<UpdateConnectorRequest>;
export interface UpdateConnectorResponse {
    connectorArn?: string;
    connectorState?: string;
    connectorOperationArn?: string;
}
export declare const UpdateConnectorResponse: S.Schema<UpdateConnectorResponse>;
export type CreateConnectorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a connector using the specified properties.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateCustomPluginError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a custom plugin using the specified properties.
 */
export declare const createCustomPlugin: API.OperationMethod<CreateCustomPluginRequest, CreateCustomPluginResponse, CreateCustomPluginError, Credentials | HttpClient.HttpClient>;
export type CreateWorkerConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a worker configuration using the specified properties.
 */
export declare const createWorkerConfiguration: API.OperationMethod<CreateWorkerConfigurationRequest, CreateWorkerConfigurationResponse, CreateWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified connector.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomPluginError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a custom plugin.
 */
export declare const deleteCustomPlugin: API.OperationMethod<DeleteCustomPluginRequest, DeleteCustomPluginResponse, DeleteCustomPluginError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkerConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified worker configuration.
 */
export declare const deleteWorkerConfiguration: API.OperationMethod<DeleteWorkerConfigurationRequest, DeleteWorkerConfigurationResponse, DeleteWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns summary information about the connector.
 */
export declare const describeConnector: API.OperationMethod<DescribeConnectorRequest, DescribeConnectorResponse, DescribeConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorOperationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns information about the specified connector's operations.
 */
export declare const describeConnectorOperation: API.OperationMethod<DescribeConnectorOperationRequest, DescribeConnectorOperationResponse, DescribeConnectorOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomPluginError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * A summary description of the custom plugin.
 */
export declare const describeCustomPlugin: API.OperationMethod<DescribeCustomPluginRequest, DescribeCustomPluginResponse, DescribeCustomPluginError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkerConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns information about a worker configuration.
 */
export declare const describeWorkerConfiguration: API.OperationMethod<DescribeWorkerConfigurationRequest, DescribeWorkerConfigurationResponse, DescribeWorkerConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListConnectorOperationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists information about a connector's operation(s).
 */
export declare const listConnectorOperations: API.PaginatedOperationMethod<ListConnectorOperationsRequest, ListConnectorOperationsResponse, ListConnectorOperationsError, Credentials | HttpClient.HttpClient, ConnectorOperationSummary>;
export type ListConnectorsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the connectors in this account and Region. The list is limited to connectors whose name starts with the specified prefix. The response also includes a description of each of the listed connectors.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, ConnectorSummary>;
export type ListCustomPluginsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all of the custom plugins in this account and Region.
 */
export declare const listCustomPlugins: API.PaginatedOperationMethod<ListCustomPluginsRequest, ListCustomPluginsResponse, ListCustomPluginsError, Credentials | HttpClient.HttpClient, CustomPluginSummary>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists all the tags attached to the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkerConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all of the worker configurations in this account and Region.
 */
export declare const listWorkerConfigurations: API.PaginatedOperationMethod<ListWorkerConfigurationsRequest, ListWorkerConfigurationsResponse, ListWorkerConfigurationsError, Credentials | HttpClient.HttpClient, WorkerConfigurationSummary>;
export type TagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Attaches tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the specified connector. For request body, specify only one parameter: either `capacity` or `connectorConfiguration`.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest, UpdateConnectorResponse, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kafkaconnect.d.ts.map