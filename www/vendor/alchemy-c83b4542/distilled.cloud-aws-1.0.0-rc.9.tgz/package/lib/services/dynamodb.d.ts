import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const BackupInUseException_base: S.Class<BackupInUseException, S.TaggedStruct<"BackupInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class BackupInUseException extends /*@__PURE__*/ BackupInUseException_base {
}
declare const BackupNotFoundException_base: S.Class<BackupNotFoundException, S.TaggedStruct<"BackupNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class BackupNotFoundException extends /*@__PURE__*/ BackupNotFoundException_base {
}
declare const ConditionalCheckFailedException_base: S.Class<ConditionalCheckFailedException, S.TaggedStruct<"ConditionalCheckFailedException", {
    readonly message: any;
    readonly Item: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConditionalCheckFailedException extends /*@__PURE__*/ ConditionalCheckFailedException_base {
}
declare const ContinuousBackupsUnavailableException_base: S.Class<ContinuousBackupsUnavailableException, S.TaggedStruct<"ContinuousBackupsUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ContinuousBackupsUnavailableException extends /*@__PURE__*/ ContinuousBackupsUnavailableException_base {
}
declare const DuplicateItemException_base: S.Class<DuplicateItemException, S.TaggedStruct<"DuplicateItemException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateItemException extends /*@__PURE__*/ DuplicateItemException_base {
}
declare const ExportConflictException_base: S.Class<ExportConflictException, S.TaggedStruct<"ExportConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ExportConflictException extends /*@__PURE__*/ ExportConflictException_base {
}
declare const ExportNotFoundException_base: S.Class<ExportNotFoundException, S.TaggedStruct<"ExportNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ExportNotFoundException extends /*@__PURE__*/ ExportNotFoundException_base {
}
declare const GlobalTableAlreadyExistsException_base: S.Class<GlobalTableAlreadyExistsException, S.TaggedStruct<"GlobalTableAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalTableAlreadyExistsException extends /*@__PURE__*/ GlobalTableAlreadyExistsException_base {
}
declare const GlobalTableNotFoundException_base: S.Class<GlobalTableNotFoundException, S.TaggedStruct<"GlobalTableNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class GlobalTableNotFoundException extends /*@__PURE__*/ GlobalTableNotFoundException_base {
}
declare const IdempotentParameterMismatchException_base: S.Class<IdempotentParameterMismatchException, S.TaggedStruct<"IdempotentParameterMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const ImportConflictException_base: S.Class<ImportConflictException, S.TaggedStruct<"ImportConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ImportConflictException extends /*@__PURE__*/ ImportConflictException_base {
}
declare const ImportNotFoundException_base: S.Class<ImportNotFoundException, S.TaggedStruct<"ImportNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ImportNotFoundException extends /*@__PURE__*/ ImportNotFoundException_base {
}
declare const IndexNotFoundException_base: S.Class<IndexNotFoundException, S.TaggedStruct<"IndexNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class IndexNotFoundException extends /*@__PURE__*/ IndexNotFoundException_base {
}
declare const InternalServerError_base: S.Class<InternalServerError, S.TaggedStruct<"InternalServerError", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InvalidEndpointException_base: S.Class<InvalidEndpointException, S.TaggedStruct<"InvalidEndpointException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEndpointException extends /*@__PURE__*/ InvalidEndpointException_base {
}
declare const InvalidExportTimeException_base: S.Class<InvalidExportTimeException, S.TaggedStruct<"InvalidExportTimeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidExportTimeException extends /*@__PURE__*/ InvalidExportTimeException_base {
}
declare const InvalidRestoreTimeException_base: S.Class<InvalidRestoreTimeException, S.TaggedStruct<"InvalidRestoreTimeException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRestoreTimeException extends /*@__PURE__*/ InvalidRestoreTimeException_base {
}
declare const ItemCollectionSizeLimitExceededException_base: S.Class<ItemCollectionSizeLimitExceededException, S.TaggedStruct<"ItemCollectionSizeLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ItemCollectionSizeLimitExceededException extends /*@__PURE__*/ ItemCollectionSizeLimitExceededException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PointInTimeRecoveryUnavailableException_base: S.Class<PointInTimeRecoveryUnavailableException, S.TaggedStruct<"PointInTimeRecoveryUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PointInTimeRecoveryUnavailableException extends /*@__PURE__*/ PointInTimeRecoveryUnavailableException_base {
}
declare const PolicyNotFoundException_base: S.Class<PolicyNotFoundException, S.TaggedStruct<"PolicyNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class PolicyNotFoundException extends /*@__PURE__*/ PolicyNotFoundException_base {
}
declare const ProvisionedThroughputExceededException_base: S.Class<ProvisionedThroughputExceededException, S.TaggedStruct<"ProvisionedThroughputExceededException", {
    readonly message: any;
    readonly ThrottlingReasons: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ProvisionedThroughputExceededException extends /*@__PURE__*/ ProvisionedThroughputExceededException_base {
}
declare const ReplicaAlreadyExistsException_base: S.Class<ReplicaAlreadyExistsException, S.TaggedStruct<"ReplicaAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ReplicaAlreadyExistsException extends /*@__PURE__*/ ReplicaAlreadyExistsException_base {
}
declare const ReplicaNotFoundException_base: S.Class<ReplicaNotFoundException, S.TaggedStruct<"ReplicaNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ReplicaNotFoundException extends /*@__PURE__*/ ReplicaNotFoundException_base {
}
declare const ReplicatedWriteConflictException_base: S.Class<ReplicatedWriteConflictException, S.TaggedStruct<"ReplicatedWriteConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ReplicatedWriteConflictException extends /*@__PURE__*/ ReplicatedWriteConflictException_base {
}
declare const RequestLimitExceeded_base: S.Class<RequestLimitExceeded, S.TaggedStruct<"RequestLimitExceeded", {
    readonly message: any;
    readonly ThrottlingReasons: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestLimitExceeded extends /*@__PURE__*/ RequestLimitExceeded_base {
}
declare const ResourceInUseException_base: S.Class<ResourceInUseException, S.TaggedStruct<"ResourceInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TableAlreadyExistsException_base: S.Class<TableAlreadyExistsException, S.TaggedStruct<"TableAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TableAlreadyExistsException extends /*@__PURE__*/ TableAlreadyExistsException_base {
}
declare const TableInUseException_base: S.Class<TableInUseException, S.TaggedStruct<"TableInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TableInUseException extends /*@__PURE__*/ TableInUseException_base {
}
declare const TableNotFoundException_base: S.Class<TableNotFoundException, S.TaggedStruct<"TableNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TableNotFoundException extends /*@__PURE__*/ TableNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly throttlingReasons: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TransactionCanceledException_base: S.Class<TransactionCanceledException, S.TaggedStruct<"TransactionCanceledException", {
    readonly message: any;
    readonly CancellationReasons: any;
}>, import("effect/Cause").YieldableError>;
export declare class TransactionCanceledException extends /*@__PURE__*/ TransactionCanceledException_base {
}
declare const TransactionConflictException_base: S.Class<TransactionConflictException, S.TaggedStruct<"TransactionConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TransactionConflictException extends /*@__PURE__*/ TransactionConflictException_base {
}
declare const TransactionInProgressException_base: S.Class<TransactionInProgressException, S.TaggedStruct<"TransactionInProgressException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TransactionInProgressException extends /*@__PURE__*/ TransactionInProgressException_base {
}
export type PartiQLStatement = string;
export type StringAttributeValue = string;
export type NumberAttributeValue = string;
export type BinaryAttributeValue = Uint8Array;
export type StringSetAttributeValue = string[];
export declare const StringSetAttributeValue: any;
export type NumberSetAttributeValue = string[];
export declare const NumberSetAttributeValue: any;
export type BinarySetAttributeValue = Uint8Array[];
export declare const BinarySetAttributeValue: any;
export type AttributeName = string;
export type MapAttributeValue = {
    [key: string]: AttributeValue | undefined;
};
export declare const MapAttributeValue: S.Schema<MapAttributeValue>;
export type ListAttributeValue = AttributeValue[];
export declare const ListAttributeValue: S.Schema<ListAttributeValue>;
export type NullAttributeValue = boolean;
export type BooleanAttributeValue = boolean;
export type AttributeValue = {
    S: string;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N: string;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B: Uint8Array;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS: string[];
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS: string[];
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS: Uint8Array[];
    M?: never;
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M: {
        [key: string]: AttributeValue | undefined;
    };
    L?: never;
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L: AttributeValue[];
    NULL?: never;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL: boolean;
    BOOL?: never;
} | {
    S?: never;
    N?: never;
    B?: never;
    SS?: never;
    NS?: never;
    BS?: never;
    M?: never;
    L?: never;
    NULL?: never;
    BOOL: boolean;
};
export declare const AttributeValue: S.Schema<AttributeValue>;
export type PreparedStatementParameters = AttributeValue[];
export declare const PreparedStatementParameters: any;
export type ConsistentRead = boolean;
export type ReturnValuesOnConditionCheckFailure = "ALL_OLD" | "NONE" | (string & {});
export declare const ReturnValuesOnConditionCheckFailure: any;
export interface BatchStatementRequest {
    Statement: string;
    Parameters?: AttributeValue[];
    ConsistentRead?: boolean;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const BatchStatementRequest: S.Schema<BatchStatementRequest>;
export type PartiQLBatchRequest = BatchStatementRequest[];
export declare const PartiQLBatchRequest: any;
export type ReturnConsumedCapacity = "INDEXES" | "TOTAL" | "NONE" | (string & {});
export declare const ReturnConsumedCapacity: any;
export interface BatchExecuteStatementInput {
    Statements: BatchStatementRequest[];
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
}
export declare const BatchExecuteStatementInput: S.Schema<BatchExecuteStatementInput>;
export type BatchStatementErrorCodeEnum = "ConditionalCheckFailed" | "ItemCollectionSizeLimitExceeded" | "RequestLimitExceeded" | "ValidationError" | "ProvisionedThroughputExceeded" | "TransactionConflict" | "ThrottlingError" | "InternalServerError" | "ResourceNotFound" | "AccessDenied" | "DuplicateItem" | (string & {});
export declare const BatchStatementErrorCodeEnum: any;
export type AttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export declare const AttributeMap: any;
export interface BatchStatementError {
    Code?: BatchStatementErrorCodeEnum;
    Message?: string;
    Item?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const BatchStatementError: S.Schema<BatchStatementError>;
export type TableName = string;
export interface BatchStatementResponse {
    Error?: BatchStatementError;
    TableName?: string;
    Item?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const BatchStatementResponse: S.Schema<BatchStatementResponse>;
export type PartiQLBatchResponse = BatchStatementResponse[];
export declare const PartiQLBatchResponse: any;
export type TableArn = string;
export type ConsumedCapacityUnits = number;
export interface Capacity {
    ReadCapacityUnits?: number;
    WriteCapacityUnits?: number;
    CapacityUnits?: number;
}
export declare const Capacity: S.Schema<Capacity>;
export type IndexName = string;
export type SecondaryIndexesCapacityMap = {
    [key: string]: Capacity | undefined;
};
export declare const SecondaryIndexesCapacityMap: any;
export interface VectorCapacity {
    VectorSearchRequestBytes?: number;
    VectorWriteRequestBytes?: number;
}
export declare const VectorCapacity: S.Schema<VectorCapacity>;
export type VectorIndexesCapacityMap = {
    [key: string]: VectorCapacity | undefined;
};
export declare const VectorIndexesCapacityMap: any;
export interface ConsumedCapacity {
    TableName?: string;
    CapacityUnits?: number;
    ReadCapacityUnits?: number;
    WriteCapacityUnits?: number;
    Table?: Capacity;
    LocalSecondaryIndexes?: {
        [key: string]: Capacity | undefined;
    };
    GlobalSecondaryIndexes?: {
        [key: string]: Capacity | undefined;
    };
    VectorIndexes?: {
        [key: string]: VectorCapacity | undefined;
    };
}
export declare const ConsumedCapacity: S.Schema<ConsumedCapacity>;
export type ConsumedCapacityMultiple = ConsumedCapacity[];
export declare const ConsumedCapacityMultiple: any;
export interface BatchExecuteStatementOutput {
    Responses?: BatchStatementResponse[];
    ConsumedCapacity?: ConsumedCapacity[];
}
export declare const BatchExecuteStatementOutput: S.Schema<BatchExecuteStatementOutput>;
export type Key = {
    [key: string]: AttributeValue | undefined;
};
export declare const Key: any;
export type KeyList = {
    [key: string]: AttributeValue | undefined;
}[];
export declare const KeyList: any;
export type AttributeNameList = string[];
export declare const AttributeNameList: any;
export type ProjectionExpression = string;
export type ExpressionAttributeNameVariable = string;
export type ExpressionAttributeNameMap = {
    [key: string]: string | undefined;
};
export declare const ExpressionAttributeNameMap: any;
export interface KeysAndAttributes {
    Keys: {
        [key: string]: AttributeValue | undefined;
    }[];
    AttributesToGet?: string[];
    ConsistentRead?: boolean;
    ProjectionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
}
export declare const KeysAndAttributes: S.Schema<KeysAndAttributes>;
export type BatchGetRequestMap = {
    [key: string]: KeysAndAttributes | undefined;
};
export declare const BatchGetRequestMap: any;
export interface BatchGetItemInput {
    RequestItems: {
        [key: string]: KeysAndAttributes | undefined;
    };
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
}
export declare const BatchGetItemInput: S.Schema<BatchGetItemInput>;
export type ItemList = {
    [key: string]: AttributeValue | undefined;
}[];
export declare const ItemList: any;
export type BatchGetResponseMap = {
    [key: string]: {
        [key: string]: AttributeValue | undefined;
    }[] | undefined;
};
export declare const BatchGetResponseMap: any;
export interface BatchGetItemOutput {
    Responses?: {
        [key: string]: {
            [key: string]: AttributeValue | undefined;
        }[] | undefined;
    };
    UnprocessedKeys?: {
        [key: string]: KeysAndAttributes | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity[];
}
export declare const BatchGetItemOutput: S.Schema<BatchGetItemOutput>;
export type PutItemInputAttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export declare const PutItemInputAttributeMap: any;
export interface PutRequest {
    Item: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const PutRequest: S.Schema<PutRequest>;
export interface DeleteRequest {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const DeleteRequest: S.Schema<DeleteRequest>;
export interface WriteRequest {
    PutRequest?: PutRequest;
    DeleteRequest?: DeleteRequest;
}
export declare const WriteRequest: S.Schema<WriteRequest>;
export type WriteRequests = WriteRequest[];
export declare const WriteRequests: any;
export type BatchWriteItemRequestMap = {
    [key: string]: WriteRequest[] | undefined;
};
export declare const BatchWriteItemRequestMap: any;
export type ReturnItemCollectionMetrics = "SIZE" | "NONE" | (string & {});
export declare const ReturnItemCollectionMetrics: any;
export interface BatchWriteItemInput {
    RequestItems: {
        [key: string]: WriteRequest[] | undefined;
    };
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics;
}
export declare const BatchWriteItemInput: S.Schema<BatchWriteItemInput>;
export type ItemCollectionKeyAttributeMap = {
    [key: string]: AttributeValue | undefined;
};
export declare const ItemCollectionKeyAttributeMap: any;
export type ItemCollectionSizeEstimateBound = number;
export type ItemCollectionSizeEstimateRange = number[];
export declare const ItemCollectionSizeEstimateRange: any;
export interface ItemCollectionMetrics {
    ItemCollectionKey?: {
        [key: string]: AttributeValue | undefined;
    };
    SizeEstimateRangeGB?: number[];
}
export declare const ItemCollectionMetrics: S.Schema<ItemCollectionMetrics>;
export type ItemCollectionMetricsMultiple = ItemCollectionMetrics[];
export declare const ItemCollectionMetricsMultiple: any;
export type ItemCollectionMetricsPerTable = {
    [key: string]: ItemCollectionMetrics[] | undefined;
};
export declare const ItemCollectionMetricsPerTable: any;
export interface BatchWriteItemOutput {
    UnprocessedItems?: {
        [key: string]: WriteRequest[] | undefined;
    };
    ItemCollectionMetrics?: {
        [key: string]: ItemCollectionMetrics[] | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity[];
}
export declare const BatchWriteItemOutput: S.Schema<BatchWriteItemOutput>;
export type BackupName = string;
export interface CreateBackupInput {
    TableName: string;
    BackupName: string;
}
export declare const CreateBackupInput: S.Schema<CreateBackupInput>;
export type BackupArn = string;
export type BackupSizeBytes = number;
export type BackupStatus = "CREATING" | "DELETED" | "AVAILABLE" | (string & {});
export declare const BackupStatus: any;
export type BackupType = "USER" | "SYSTEM" | "AWS_BACKUP" | (string & {});
export declare const BackupType: any;
export type BackupCreationDateTime = Date;
export interface BackupDetails {
    BackupArn: string;
    BackupName: string;
    BackupSizeBytes?: number;
    BackupStatus: BackupStatus;
    BackupType: BackupType;
    BackupCreationDateTime: Date;
    BackupExpiryDateTime?: Date;
}
export declare const BackupDetails: S.Schema<BackupDetails>;
export interface CreateBackupOutput {
    BackupDetails?: BackupDetails;
}
export declare const CreateBackupOutput: S.Schema<CreateBackupOutput>;
export type RegionName = string;
export interface Replica {
    RegionName?: string;
}
export declare const Replica: S.Schema<Replica>;
export type ReplicaList = Replica[];
export declare const ReplicaList: any;
export interface CreateGlobalTableInput {
    GlobalTableName: string;
    ReplicationGroup: Replica[];
}
export declare const CreateGlobalTableInput: S.Schema<CreateGlobalTableInput>;
export type ReplicaStatus = "CREATING" | "CREATION_FAILED" | "UPDATING" | "DELETING" | "ACTIVE" | "REGION_DISABLED" | "INACCESSIBLE_ENCRYPTION_CREDENTIALS" | "ARCHIVING" | "ARCHIVED" | "REPLICATION_NOT_AUTHORIZED" | (string & {});
export declare const ReplicaStatus: any;
export type ReplicaStatusDescription = string;
export type ReplicaStatusPercentProgress = string;
export type KMSMasterKeyId = string;
export type PositiveLongObject = number;
export interface ProvisionedThroughputOverride {
    ReadCapacityUnits?: number;
}
export declare const ProvisionedThroughputOverride: S.Schema<ProvisionedThroughputOverride>;
export type LongObject = number;
export interface OnDemandThroughputOverride {
    MaxReadRequestUnits?: number;
}
export declare const OnDemandThroughputOverride: S.Schema<OnDemandThroughputOverride>;
export type TableStatus = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | "INACCESSIBLE_ENCRYPTION_CREDENTIALS" | "ARCHIVING" | "ARCHIVED" | "REPLICATION_NOT_AUTHORIZED" | (string & {});
export declare const TableStatus: any;
export interface TableWarmThroughputDescription {
    ReadUnitsPerSecond?: number;
    WriteUnitsPerSecond?: number;
    Status?: TableStatus;
}
export declare const TableWarmThroughputDescription: S.Schema<TableWarmThroughputDescription>;
export type IndexStatus = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | (string & {});
export declare const IndexStatus: any;
export interface GlobalSecondaryIndexWarmThroughputDescription {
    ReadUnitsPerSecond?: number;
    WriteUnitsPerSecond?: number;
    Status?: IndexStatus;
}
export declare const GlobalSecondaryIndexWarmThroughputDescription: S.Schema<GlobalSecondaryIndexWarmThroughputDescription>;
export interface ReplicaGlobalSecondaryIndexDescription {
    IndexName?: string;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride;
    OnDemandThroughputOverride?: OnDemandThroughputOverride;
    WarmThroughput?: GlobalSecondaryIndexWarmThroughputDescription;
}
export declare const ReplicaGlobalSecondaryIndexDescription: S.Schema<ReplicaGlobalSecondaryIndexDescription>;
export type ReplicaGlobalSecondaryIndexDescriptionList = ReplicaGlobalSecondaryIndexDescription[];
export declare const ReplicaGlobalSecondaryIndexDescriptionList: any;
export type TableClass = "STANDARD" | "STANDARD_INFREQUENT_ACCESS" | (string & {});
export declare const TableClass: any;
export interface TableClassSummary {
    TableClass?: TableClass;
    LastUpdateDateTime?: Date;
}
export declare const TableClassSummary: S.Schema<TableClassSummary>;
export type GlobalTableSettingsReplicationMode = "ENABLED" | "DISABLED" | "ENABLED_WITH_OVERRIDES" | (string & {});
export declare const GlobalTableSettingsReplicationMode: any;
export interface ReplicaDescription {
    RegionName?: string;
    ReplicaStatus?: ReplicaStatus;
    ReplicaArn?: string;
    ReplicaStatusDescription?: string;
    ReplicaStatusPercentProgress?: string;
    KMSMasterKeyId?: string;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride;
    OnDemandThroughputOverride?: OnDemandThroughputOverride;
    WarmThroughput?: TableWarmThroughputDescription;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndexDescription[];
    ReplicaInaccessibleDateTime?: Date;
    ReplicaTableClassSummary?: TableClassSummary;
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode;
}
export declare const ReplicaDescription: S.Schema<ReplicaDescription>;
export type ReplicaDescriptionList = ReplicaDescription[];
export declare const ReplicaDescriptionList: any;
export type GlobalTableArnString = string;
export type GlobalTableStatus = "CREATING" | "ACTIVE" | "DELETING" | "UPDATING" | (string & {});
export declare const GlobalTableStatus: any;
export interface GlobalTableDescription {
    ReplicationGroup?: ReplicaDescription[];
    GlobalTableArn?: string;
    CreationDateTime?: Date;
    GlobalTableStatus?: GlobalTableStatus;
    GlobalTableName?: string;
}
export declare const GlobalTableDescription: S.Schema<GlobalTableDescription>;
export interface CreateGlobalTableOutput {
    GlobalTableDescription?: GlobalTableDescription;
}
export declare const CreateGlobalTableOutput: S.Schema<CreateGlobalTableOutput>;
export type KeySchemaAttributeName = string;
export type ScalarAttributeType = "S" | "N" | "B" | (string & {});
export declare const ScalarAttributeType: any;
export interface AttributeDefinition {
    AttributeName: string;
    AttributeType: ScalarAttributeType;
}
export declare const AttributeDefinition: S.Schema<AttributeDefinition>;
export type AttributeDefinitions = AttributeDefinition[];
export declare const AttributeDefinitions: any;
export type KeyType = "HASH" | "RANGE" | (string & {});
export declare const KeyType: any;
export interface KeySchemaElement {
    AttributeName: string;
    KeyType: KeyType;
}
export declare const KeySchemaElement: S.Schema<KeySchemaElement>;
export type KeySchema = KeySchemaElement[];
export declare const KeySchema: any;
export type ProjectionType = "ALL" | "KEYS_ONLY" | "INCLUDE" | (string & {});
export declare const ProjectionType: any;
export type NonKeyAttributeName = string;
export type NonKeyAttributeNameList = string[];
export declare const NonKeyAttributeNameList: any;
export interface Projection {
    ProjectionType?: ProjectionType;
    NonKeyAttributes?: string[];
}
export declare const Projection: S.Schema<Projection>;
export interface LocalSecondaryIndex {
    IndexName: string;
    KeySchema: KeySchemaElement[];
    Projection: Projection;
}
export declare const LocalSecondaryIndex: S.Schema<LocalSecondaryIndex>;
export type LocalSecondaryIndexList = LocalSecondaryIndex[];
export declare const LocalSecondaryIndexList: any;
export interface ProvisionedThroughput {
    ReadCapacityUnits: number;
    WriteCapacityUnits: number;
}
export declare const ProvisionedThroughput: S.Schema<ProvisionedThroughput>;
export interface OnDemandThroughput {
    MaxReadRequestUnits?: number;
    MaxWriteRequestUnits?: number;
}
export declare const OnDemandThroughput: S.Schema<OnDemandThroughput>;
export interface WarmThroughput {
    ReadUnitsPerSecond?: number;
    WriteUnitsPerSecond?: number;
}
export declare const WarmThroughput: S.Schema<WarmThroughput>;
export interface GlobalSecondaryIndex {
    IndexName: string;
    KeySchema: KeySchemaElement[];
    Projection: Projection;
    ProvisionedThroughput?: ProvisionedThroughput;
    OnDemandThroughput?: OnDemandThroughput;
    WarmThroughput?: WarmThroughput;
}
export declare const GlobalSecondaryIndex: S.Schema<GlobalSecondaryIndex>;
export type GlobalSecondaryIndexList = GlobalSecondaryIndex[];
export declare const GlobalSecondaryIndexList: any;
export type BillingMode = "PROVISIONED" | "PAY_PER_REQUEST" | (string & {});
export declare const BillingMode: any;
export type StreamEnabled = boolean;
export type StreamViewType = "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY" | (string & {});
export declare const StreamViewType: any;
export interface StreamSpecification {
    StreamEnabled: boolean;
    StreamViewType?: StreamViewType;
}
export declare const StreamSpecification: S.Schema<StreamSpecification>;
export type SSEEnabled = boolean;
export type SSEType = "AES256" | "KMS" | (string & {});
export declare const SSEType: any;
export interface SSESpecification {
    Enabled?: boolean;
    SSEType?: SSEType;
    KMSMasterKeyId?: string;
}
export declare const SSESpecification: S.Schema<SSESpecification>;
export type TagKeyString = string;
export type TagValueString = string;
export interface Tag {
    Key: string;
    Value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export type DeletionProtectionEnabled = boolean;
export type ResourcePolicy = string;
export type VectorAttributeName = string;
export interface VectorAttributeDefinition {
    AttributeName: string;
}
export declare const VectorAttributeDefinition: S.Schema<VectorAttributeDefinition>;
export type SearchSchemaElementType = "HASH" | "INLINE_FILTER" | (string & {});
export declare const SearchSchemaElementType: any;
export interface SearchSchemaElement {
    AttributeName: string;
    SearchSchemaElementType: SearchSchemaElementType;
}
export declare const SearchSchemaElement: S.Schema<SearchSchemaElement>;
export type SearchSchema = SearchSchemaElement[];
export declare const SearchSchema: any;
export type VectorDistanceFunction = "COSINE" | "DOT_PRODUCT" | "EUCLIDEAN" | (string & {});
export declare const VectorDistanceFunction: any;
export interface VectorIndex {
    IndexName: string;
    VectorAttribute: VectorAttributeDefinition;
    SearchSchema?: SearchSchemaElement[];
    Projection: Projection;
    Dimensions: number;
    DistanceFunction: VectorDistanceFunction;
}
export declare const VectorIndex: S.Schema<VectorIndex>;
export type VectorIndexList = VectorIndex[];
export declare const VectorIndexList: any;
export interface CreateTableInput {
    AttributeDefinitions?: AttributeDefinition[];
    TableName: string;
    KeySchema?: KeySchemaElement[];
    LocalSecondaryIndexes?: LocalSecondaryIndex[];
    GlobalSecondaryIndexes?: GlobalSecondaryIndex[];
    BillingMode?: BillingMode;
    ProvisionedThroughput?: ProvisionedThroughput;
    StreamSpecification?: StreamSpecification;
    SSESpecification?: SSESpecification;
    Tags?: Tag[];
    TableClass?: TableClass;
    DeletionProtectionEnabled?: boolean;
    WarmThroughput?: WarmThroughput;
    ResourcePolicy?: string;
    OnDemandThroughput?: OnDemandThroughput;
    GlobalTableSourceArn?: string;
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode;
    VectorIndexes?: VectorIndex[];
}
export declare const CreateTableInput: S.Schema<CreateTableInput>;
export type NonNegativeLongObject = number;
export interface ProvisionedThroughputDescription {
    LastIncreaseDateTime?: Date;
    LastDecreaseDateTime?: Date;
    NumberOfDecreasesToday?: number;
    ReadCapacityUnits?: number;
    WriteCapacityUnits?: number;
}
export declare const ProvisionedThroughputDescription: S.Schema<ProvisionedThroughputDescription>;
export type TableId = string;
export interface BillingModeSummary {
    BillingMode?: BillingMode;
    LastUpdateToPayPerRequestDateTime?: Date;
}
export declare const BillingModeSummary: S.Schema<BillingModeSummary>;
export interface LocalSecondaryIndexDescription {
    IndexName?: string;
    KeySchema?: KeySchemaElement[];
    Projection?: Projection;
    IndexSizeBytes?: number;
    ItemCount?: number;
    IndexArn?: string;
}
export declare const LocalSecondaryIndexDescription: S.Schema<LocalSecondaryIndexDescription>;
export type LocalSecondaryIndexDescriptionList = LocalSecondaryIndexDescription[];
export declare const LocalSecondaryIndexDescriptionList: any;
export type Backfilling = boolean;
export interface GlobalSecondaryIndexDescription {
    IndexName?: string;
    KeySchema?: KeySchemaElement[];
    Projection?: Projection;
    IndexStatus?: IndexStatus;
    Backfilling?: boolean;
    ProvisionedThroughput?: ProvisionedThroughputDescription;
    IndexSizeBytes?: number;
    ItemCount?: number;
    IndexArn?: string;
    OnDemandThroughput?: OnDemandThroughput;
    WarmThroughput?: GlobalSecondaryIndexWarmThroughputDescription;
}
export declare const GlobalSecondaryIndexDescription: S.Schema<GlobalSecondaryIndexDescription>;
export type GlobalSecondaryIndexDescriptionList = GlobalSecondaryIndexDescription[];
export declare const GlobalSecondaryIndexDescriptionList: any;
export type StreamArn = string;
export type WitnessStatus = "CREATING" | "DELETING" | "ACTIVE" | (string & {});
export declare const WitnessStatus: any;
export interface GlobalTableWitnessDescription {
    RegionName?: string;
    WitnessStatus?: WitnessStatus;
}
export declare const GlobalTableWitnessDescription: S.Schema<GlobalTableWitnessDescription>;
export type GlobalTableWitnessDescriptionList = GlobalTableWitnessDescription[];
export declare const GlobalTableWitnessDescriptionList: any;
export type RestoreInProgress = boolean;
export interface RestoreSummary {
    SourceBackupArn?: string;
    SourceTableArn?: string;
    RestoreDateTime: Date;
    RestoreInProgress: boolean;
}
export declare const RestoreSummary: S.Schema<RestoreSummary>;
export type SSEStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "UPDATING" | (string & {});
export declare const SSEStatus: any;
export type KMSMasterKeyArn = string;
export interface SSEDescription {
    Status?: SSEStatus;
    SSEType?: SSEType;
    KMSMasterKeyArn?: string;
    InaccessibleEncryptionDateTime?: Date;
}
export declare const SSEDescription: S.Schema<SSEDescription>;
export type ArchivalReason = string;
export interface ArchivalSummary {
    ArchivalDateTime?: Date;
    ArchivalReason?: string;
    ArchivalBackupArn?: string;
}
export declare const ArchivalSummary: S.Schema<ArchivalSummary>;
export type MultiRegionConsistency = "EVENTUAL" | "STRONG" | (string & {});
export declare const MultiRegionConsistency: any;
export interface VectorIndexDescription {
    IndexName?: string;
    SearchSchema?: SearchSchemaElement[];
    Projection?: Projection;
    VectorAttribute?: VectorAttributeDefinition;
    Dimensions?: number;
    DistanceFunction?: VectorDistanceFunction;
    IndexStatus?: IndexStatus;
    Backfilling?: boolean;
    IndexSizeBytes?: number;
    ItemCount?: number;
    IndexArn?: string;
}
export declare const VectorIndexDescription: S.Schema<VectorIndexDescription>;
export type VectorIndexDescriptionList = VectorIndexDescription[];
export declare const VectorIndexDescriptionList: any;
export interface TableDescription {
    AttributeDefinitions?: AttributeDefinition[];
    TableName?: string;
    KeySchema?: KeySchemaElement[];
    TableStatus?: TableStatus;
    CreationDateTime?: Date;
    ProvisionedThroughput?: ProvisionedThroughputDescription;
    TableSizeBytes?: number;
    ItemCount?: number;
    TableArn?: string;
    TableId?: string;
    BillingModeSummary?: BillingModeSummary;
    LocalSecondaryIndexes?: LocalSecondaryIndexDescription[];
    GlobalSecondaryIndexes?: GlobalSecondaryIndexDescription[];
    StreamSpecification?: StreamSpecification;
    LatestStreamLabel?: string;
    LatestStreamArn?: string;
    GlobalTableVersion?: string;
    Replicas?: ReplicaDescription[];
    GlobalTableWitnesses?: GlobalTableWitnessDescription[];
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode;
    RestoreSummary?: RestoreSummary;
    SSEDescription?: SSEDescription;
    ArchivalSummary?: ArchivalSummary;
    TableClassSummary?: TableClassSummary;
    DeletionProtectionEnabled?: boolean;
    OnDemandThroughput?: OnDemandThroughput;
    WarmThroughput?: TableWarmThroughputDescription;
    MultiRegionConsistency?: MultiRegionConsistency;
    VectorIndexes?: VectorIndexDescription[];
}
export declare const TableDescription: S.Schema<TableDescription>;
export interface CreateTableOutput {
    TableDescription?: TableDescription;
}
export declare const CreateTableOutput: S.Schema<CreateTableOutput>;
export interface DeleteBackupInput {
    BackupArn: string;
}
export declare const DeleteBackupInput: S.Schema<DeleteBackupInput>;
export type TableCreationDateTime = Date;
export type ItemCount = number;
export interface SourceTableDetails {
    TableName: string;
    TableId: string;
    TableArn?: string;
    TableSizeBytes?: number;
    KeySchema: KeySchemaElement[];
    TableCreationDateTime: Date;
    ProvisionedThroughput: ProvisionedThroughput;
    OnDemandThroughput?: OnDemandThroughput;
    ItemCount?: number;
    BillingMode?: BillingMode;
}
export declare const SourceTableDetails: S.Schema<SourceTableDetails>;
export interface LocalSecondaryIndexInfo {
    IndexName?: string;
    KeySchema?: KeySchemaElement[];
    Projection?: Projection;
}
export declare const LocalSecondaryIndexInfo: S.Schema<LocalSecondaryIndexInfo>;
export type LocalSecondaryIndexes = LocalSecondaryIndexInfo[];
export declare const LocalSecondaryIndexes: any;
export interface GlobalSecondaryIndexInfo {
    IndexName?: string;
    KeySchema?: KeySchemaElement[];
    Projection?: Projection;
    ProvisionedThroughput?: ProvisionedThroughput;
    OnDemandThroughput?: OnDemandThroughput;
}
export declare const GlobalSecondaryIndexInfo: S.Schema<GlobalSecondaryIndexInfo>;
export type GlobalSecondaryIndexes = GlobalSecondaryIndexInfo[];
export declare const GlobalSecondaryIndexes: any;
export type TimeToLiveStatus = "ENABLING" | "DISABLING" | "ENABLED" | "DISABLED" | (string & {});
export declare const TimeToLiveStatus: any;
export type TimeToLiveAttributeName = string;
export interface TimeToLiveDescription {
    TimeToLiveStatus?: TimeToLiveStatus;
    AttributeName?: string;
}
export declare const TimeToLiveDescription: S.Schema<TimeToLiveDescription>;
export interface VectorIndexInfo {
    IndexName?: string;
    VectorAttribute?: VectorAttributeDefinition;
    SearchSchema?: SearchSchemaElement[];
    Projection?: Projection;
    Dimensions?: number;
    DistanceFunction?: VectorDistanceFunction;
}
export declare const VectorIndexInfo: S.Schema<VectorIndexInfo>;
export type VectorIndexes = VectorIndexInfo[];
export declare const VectorIndexes: any;
export interface SourceTableFeatureDetails {
    LocalSecondaryIndexes?: LocalSecondaryIndexInfo[];
    GlobalSecondaryIndexes?: GlobalSecondaryIndexInfo[];
    StreamDescription?: StreamSpecification;
    TimeToLiveDescription?: TimeToLiveDescription;
    SSEDescription?: SSEDescription;
    VectorIndexes?: VectorIndexInfo[];
}
export declare const SourceTableFeatureDetails: S.Schema<SourceTableFeatureDetails>;
export interface BackupDescription {
    BackupDetails?: BackupDetails;
    SourceTableDetails?: SourceTableDetails;
    SourceTableFeatureDetails?: SourceTableFeatureDetails;
}
export declare const BackupDescription: S.Schema<BackupDescription>;
export interface DeleteBackupOutput {
    BackupDescription?: BackupDescription;
}
export declare const DeleteBackupOutput: S.Schema<DeleteBackupOutput>;
export type ComparisonOperator = "EQ" | "NE" | "IN" | "LE" | "LT" | "GE" | "GT" | "BETWEEN" | "NOT_NULL" | "NULL" | "CONTAINS" | "NOT_CONTAINS" | "BEGINS_WITH" | (string & {});
export declare const ComparisonOperator: any;
export type AttributeValueList = AttributeValue[];
export declare const AttributeValueList: any;
export interface ExpectedAttributeValue {
    Value?: AttributeValue;
    Exists?: boolean;
    ComparisonOperator?: ComparisonOperator;
    AttributeValueList?: AttributeValue[];
}
export declare const ExpectedAttributeValue: S.Schema<ExpectedAttributeValue>;
export type ExpectedAttributeMap = {
    [key: string]: ExpectedAttributeValue | undefined;
};
export declare const ExpectedAttributeMap: any;
export type ConditionalOperator = "AND" | "OR" | (string & {});
export declare const ConditionalOperator: any;
export type ReturnValue = "NONE" | "ALL_OLD" | "UPDATED_OLD" | "ALL_NEW" | "UPDATED_NEW" | (string & {});
export declare const ReturnValue: any;
export type ConditionExpression = string;
export type ExpressionAttributeValueVariable = string;
export type ExpressionAttributeValueMap = {
    [key: string]: AttributeValue | undefined;
};
export declare const ExpressionAttributeValueMap: any;
export interface DeleteItemInput {
    TableName: string;
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    Expected?: {
        [key: string]: ExpectedAttributeValue | undefined;
    };
    ConditionalOperator?: ConditionalOperator;
    ReturnValues?: ReturnValue;
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics;
    ConditionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const DeleteItemInput: S.Schema<DeleteItemInput>;
export interface DeleteItemOutput {
    Attributes?: {
        [key: string]: AttributeValue | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity;
    ItemCollectionMetrics?: ItemCollectionMetrics;
}
export declare const DeleteItemOutput: S.Schema<DeleteItemOutput>;
export type ResourceArnString = string;
export type PolicyRevisionId = string;
export interface DeleteResourcePolicyInput {
    ResourceArn: string;
    ExpectedRevisionId?: string;
}
export declare const DeleteResourcePolicyInput: S.Schema<DeleteResourcePolicyInput>;
export interface DeleteResourcePolicyOutput {
    RevisionId?: string;
}
export declare const DeleteResourcePolicyOutput: S.Schema<DeleteResourcePolicyOutput>;
export interface DeleteTableInput {
    TableName: string;
}
export declare const DeleteTableInput: S.Schema<DeleteTableInput>;
export interface DeleteTableOutput {
    TableDescription?: TableDescription;
}
export declare const DeleteTableOutput: S.Schema<DeleteTableOutput>;
export interface DescribeBackupInput {
    BackupArn: string;
}
export declare const DescribeBackupInput: S.Schema<DescribeBackupInput>;
export interface DescribeBackupOutput {
    BackupDescription?: BackupDescription;
}
export declare const DescribeBackupOutput: S.Schema<DescribeBackupOutput>;
export interface DescribeContinuousBackupsInput {
    TableName: string;
}
export declare const DescribeContinuousBackupsInput: S.Schema<DescribeContinuousBackupsInput>;
export type ContinuousBackupsStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const ContinuousBackupsStatus: any;
export type PointInTimeRecoveryStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const PointInTimeRecoveryStatus: any;
export type RecoveryPeriodInDays = number;
export interface PointInTimeRecoveryDescription {
    PointInTimeRecoveryStatus?: PointInTimeRecoveryStatus;
    RecoveryPeriodInDays?: number;
    EarliestRestorableDateTime?: Date;
    LatestRestorableDateTime?: Date;
}
export declare const PointInTimeRecoveryDescription: S.Schema<PointInTimeRecoveryDescription>;
export interface ContinuousBackupsDescription {
    ContinuousBackupsStatus: ContinuousBackupsStatus;
    PointInTimeRecoveryDescription?: PointInTimeRecoveryDescription;
}
export declare const ContinuousBackupsDescription: S.Schema<ContinuousBackupsDescription>;
export interface DescribeContinuousBackupsOutput {
    ContinuousBackupsDescription?: ContinuousBackupsDescription;
}
export declare const DescribeContinuousBackupsOutput: S.Schema<DescribeContinuousBackupsOutput>;
export interface DescribeContributorInsightsInput {
    TableName: string;
    IndexName?: string;
}
export declare const DescribeContributorInsightsInput: S.Schema<DescribeContributorInsightsInput>;
export type ContributorInsightsRule = string;
export type ContributorInsightsRuleList = string[];
export declare const ContributorInsightsRuleList: any;
export type ContributorInsightsStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "FAILED" | (string & {});
export declare const ContributorInsightsStatus: any;
export type LastUpdateDateTime = Date;
export type ExceptionName = string;
export type ExceptionDescription = string;
export interface FailureException {
    ExceptionName?: string;
    ExceptionDescription?: string;
}
export declare const FailureException: S.Schema<FailureException>;
export type ContributorInsightsMode = "ACCESSED_AND_THROTTLED_KEYS" | "THROTTLED_KEYS" | (string & {});
export declare const ContributorInsightsMode: any;
export interface DescribeContributorInsightsOutput {
    TableName?: string;
    IndexName?: string;
    ContributorInsightsRuleList?: string[];
    ContributorInsightsStatus?: ContributorInsightsStatus;
    LastUpdateDateTime?: Date;
    FailureException?: FailureException;
    ContributorInsightsMode?: ContributorInsightsMode;
}
export declare const DescribeContributorInsightsOutput: S.Schema<DescribeContributorInsightsOutput>;
export interface DescribeEndpointsRequest {
}
export declare const DescribeEndpointsRequest: S.Schema<DescribeEndpointsRequest>;
export interface Endpoint {
    Address: string;
    CachePeriodInMinutes: number;
}
export declare const Endpoint: S.Schema<Endpoint>;
export type Endpoints = Endpoint[];
export declare const Endpoints: any;
export interface DescribeEndpointsResponse {
    Endpoints: Endpoint[];
}
export declare const DescribeEndpointsResponse: S.Schema<DescribeEndpointsResponse>;
export type ExportArn = string;
export interface DescribeExportInput {
    ExportArn: string;
}
export declare const DescribeExportInput: S.Schema<DescribeExportInput>;
export type ExportStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export declare const ExportStatus: any;
export type ExportStartTime = Date;
export type ExportEndTime = Date;
export type ExportManifest = string;
export type ExportTime = Date;
export type ClientToken = string;
export type S3Bucket = string;
export type S3BucketOwner = string;
export type S3Prefix = string;
export type S3SseAlgorithm = "AES256" | "KMS" | (string & {});
export declare const S3SseAlgorithm: any;
export type S3SseKmsKeyId = string;
export type FailureCode = string;
export type FailureMessage = string;
export type ExportFormat = "DYNAMODB_JSON" | "ION" | (string & {});
export declare const ExportFormat: any;
export type BilledSizeBytes = number;
export type ExportType = "FULL_EXPORT" | "INCREMENTAL_EXPORT" | (string & {});
export declare const ExportType: any;
export type ExportFromTime = Date;
export type ExportToTime = Date;
export type ExportViewType = "NEW_IMAGE" | "NEW_AND_OLD_IMAGES" | (string & {});
export declare const ExportViewType: any;
export interface IncrementalExportSpecification {
    ExportFromTime?: Date;
    ExportToTime?: Date;
    ExportViewType?: ExportViewType;
}
export declare const IncrementalExportSpecification: S.Schema<IncrementalExportSpecification>;
export interface ExportDescription {
    ExportArn?: string;
    ExportStatus?: ExportStatus;
    StartTime?: Date;
    EndTime?: Date;
    ExportManifest?: string;
    TableArn?: string;
    TableId?: string;
    ExportTime?: Date;
    ClientToken?: string;
    S3Bucket?: string;
    S3BucketOwner?: string;
    S3Prefix?: string;
    S3SseAlgorithm?: S3SseAlgorithm;
    S3SseKmsKeyId?: string;
    FailureCode?: string;
    FailureMessage?: string;
    ExportFormat?: ExportFormat;
    BilledSizeBytes?: number;
    ItemCount?: number;
    ExportType?: ExportType;
    IncrementalExportSpecification?: IncrementalExportSpecification;
}
export declare const ExportDescription: S.Schema<ExportDescription>;
export interface DescribeExportOutput {
    ExportDescription?: ExportDescription;
}
export declare const DescribeExportOutput: S.Schema<DescribeExportOutput>;
export interface DescribeGlobalTableInput {
    GlobalTableName: string;
}
export declare const DescribeGlobalTableInput: S.Schema<DescribeGlobalTableInput>;
export interface DescribeGlobalTableOutput {
    GlobalTableDescription?: GlobalTableDescription;
}
export declare const DescribeGlobalTableOutput: S.Schema<DescribeGlobalTableOutput>;
export interface DescribeGlobalTableSettingsInput {
    GlobalTableName: string;
}
export declare const DescribeGlobalTableSettingsInput: S.Schema<DescribeGlobalTableSettingsInput>;
export type AutoScalingPolicyName = string;
export type IntegerObject = number;
export type DoubleObject = number;
export interface AutoScalingTargetTrackingScalingPolicyConfigurationDescription {
    DisableScaleIn?: boolean;
    ScaleInCooldown?: number;
    ScaleOutCooldown?: number;
    TargetValue: number;
}
export declare const AutoScalingTargetTrackingScalingPolicyConfigurationDescription: S.Schema<AutoScalingTargetTrackingScalingPolicyConfigurationDescription>;
export interface AutoScalingPolicyDescription {
    PolicyName?: string;
    TargetTrackingScalingPolicyConfiguration?: AutoScalingTargetTrackingScalingPolicyConfigurationDescription;
}
export declare const AutoScalingPolicyDescription: S.Schema<AutoScalingPolicyDescription>;
export type AutoScalingPolicyDescriptionList = AutoScalingPolicyDescription[];
export declare const AutoScalingPolicyDescriptionList: any;
export interface AutoScalingSettingsDescription {
    MinimumUnits?: number;
    MaximumUnits?: number;
    AutoScalingDisabled?: boolean;
    AutoScalingRoleArn?: string;
    ScalingPolicies?: AutoScalingPolicyDescription[];
}
export declare const AutoScalingSettingsDescription: S.Schema<AutoScalingSettingsDescription>;
export interface ReplicaGlobalSecondaryIndexSettingsDescription {
    IndexName: string;
    IndexStatus?: IndexStatus;
    ProvisionedReadCapacityUnits?: number;
    ProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
    ProvisionedWriteCapacityUnits?: number;
    ProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
}
export declare const ReplicaGlobalSecondaryIndexSettingsDescription: S.Schema<ReplicaGlobalSecondaryIndexSettingsDescription>;
export type ReplicaGlobalSecondaryIndexSettingsDescriptionList = ReplicaGlobalSecondaryIndexSettingsDescription[];
export declare const ReplicaGlobalSecondaryIndexSettingsDescriptionList: any;
export interface ReplicaSettingsDescription {
    RegionName: string;
    ReplicaStatus?: ReplicaStatus;
    ReplicaBillingModeSummary?: BillingModeSummary;
    ReplicaProvisionedReadCapacityUnits?: number;
    ReplicaProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
    ReplicaProvisionedWriteCapacityUnits?: number;
    ReplicaProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
    ReplicaGlobalSecondaryIndexSettings?: ReplicaGlobalSecondaryIndexSettingsDescription[];
    ReplicaTableClassSummary?: TableClassSummary;
}
export declare const ReplicaSettingsDescription: S.Schema<ReplicaSettingsDescription>;
export type ReplicaSettingsDescriptionList = ReplicaSettingsDescription[];
export declare const ReplicaSettingsDescriptionList: any;
export interface DescribeGlobalTableSettingsOutput {
    GlobalTableName?: string;
    ReplicaSettings?: ReplicaSettingsDescription[];
}
export declare const DescribeGlobalTableSettingsOutput: S.Schema<DescribeGlobalTableSettingsOutput>;
export type ImportArn = string;
export interface DescribeImportInput {
    ImportArn: string;
}
export declare const DescribeImportInput: S.Schema<DescribeImportInput>;
export type ImportStatus = "IN_PROGRESS" | "COMPLETED" | "CANCELLING" | "CANCELLED" | "FAILED" | (string & {});
export declare const ImportStatus: any;
export interface S3BucketSource {
    S3BucketOwner?: string;
    S3Bucket: string;
    S3KeyPrefix?: string;
}
export declare const S3BucketSource: S.Schema<S3BucketSource>;
export type ErrorCount = number;
export type CloudWatchLogGroupArn = string;
export type InputFormat = "DYNAMODB_JSON" | "ION" | "CSV" | (string & {});
export declare const InputFormat: any;
export type CsvDelimiter = string;
export type CsvHeader = string;
export type CsvHeaderList = string[];
export declare const CsvHeaderList: any;
export interface CsvOptions {
    Delimiter?: string;
    HeaderList?: string[];
}
export declare const CsvOptions: S.Schema<CsvOptions>;
export interface InputFormatOptions {
    Csv?: CsvOptions;
}
export declare const InputFormatOptions: S.Schema<InputFormatOptions>;
export type InputCompressionType = "GZIP" | "ZSTD" | "NONE" | (string & {});
export declare const InputCompressionType: any;
export interface TableCreationParameters {
    TableName: string;
    AttributeDefinitions: AttributeDefinition[];
    KeySchema: KeySchemaElement[];
    BillingMode?: BillingMode;
    ProvisionedThroughput?: ProvisionedThroughput;
    OnDemandThroughput?: OnDemandThroughput;
    SSESpecification?: SSESpecification;
    GlobalSecondaryIndexes?: GlobalSecondaryIndex[];
    VectorIndexes?: VectorIndex[];
}
export declare const TableCreationParameters: S.Schema<TableCreationParameters>;
export type ImportStartTime = Date;
export type ImportEndTime = Date;
export type ProcessedItemCount = number;
export type ImportedItemCount = number;
export interface ImportTableDescription {
    ImportArn?: string;
    ImportStatus?: ImportStatus;
    TableArn?: string;
    TableId?: string;
    ClientToken?: string;
    S3BucketSource?: S3BucketSource;
    ErrorCount?: number;
    CloudWatchLogGroupArn?: string;
    InputFormat?: InputFormat;
    InputFormatOptions?: InputFormatOptions;
    InputCompressionType?: InputCompressionType;
    TableCreationParameters?: TableCreationParameters;
    StartTime?: Date;
    EndTime?: Date;
    ProcessedSizeBytes?: number;
    ProcessedItemCount?: number;
    ImportedItemCount?: number;
    FailureCode?: string;
    FailureMessage?: string;
}
export declare const ImportTableDescription: S.Schema<ImportTableDescription>;
export interface DescribeImportOutput {
    ImportTableDescription: ImportTableDescription;
}
export declare const DescribeImportOutput: S.Schema<DescribeImportOutput>;
export interface DescribeKinesisStreamingDestinationInput {
    TableName: string;
}
export declare const DescribeKinesisStreamingDestinationInput: S.Schema<DescribeKinesisStreamingDestinationInput>;
export type DestinationStatus = "ENABLING" | "ACTIVE" | "DISABLING" | "DISABLED" | "ENABLE_FAILED" | "UPDATING" | (string & {});
export declare const DestinationStatus: any;
export type ApproximateCreationDateTimePrecision = "MILLISECOND" | "MICROSECOND" | (string & {});
export declare const ApproximateCreationDateTimePrecision: any;
export interface KinesisDataStreamDestination {
    StreamArn?: string;
    DestinationStatus?: DestinationStatus;
    DestinationStatusDescription?: string;
    ApproximateCreationDateTimePrecision?: ApproximateCreationDateTimePrecision;
}
export declare const KinesisDataStreamDestination: S.Schema<KinesisDataStreamDestination>;
export type KinesisDataStreamDestinations = KinesisDataStreamDestination[];
export declare const KinesisDataStreamDestinations: any;
export interface DescribeKinesisStreamingDestinationOutput {
    TableName?: string;
    KinesisDataStreamDestinations?: KinesisDataStreamDestination[];
}
export declare const DescribeKinesisStreamingDestinationOutput: S.Schema<DescribeKinesisStreamingDestinationOutput>;
export interface DescribeLimitsInput {
}
export declare const DescribeLimitsInput: S.Schema<DescribeLimitsInput>;
export interface DescribeLimitsOutput {
    AccountMaxReadCapacityUnits?: number;
    AccountMaxWriteCapacityUnits?: number;
    TableMaxReadCapacityUnits?: number;
    TableMaxWriteCapacityUnits?: number;
}
export declare const DescribeLimitsOutput: S.Schema<DescribeLimitsOutput>;
export interface DescribeTableInput {
    TableName: string;
}
export declare const DescribeTableInput: S.Schema<DescribeTableInput>;
export interface DescribeTableOutput {
    Table?: TableDescription;
}
export declare const DescribeTableOutput: S.Schema<DescribeTableOutput>;
export interface DescribeTableReplicaAutoScalingInput {
    TableName: string;
}
export declare const DescribeTableReplicaAutoScalingInput: S.Schema<DescribeTableReplicaAutoScalingInput>;
export interface ReplicaGlobalSecondaryIndexAutoScalingDescription {
    IndexName?: string;
    IndexStatus?: IndexStatus;
    ProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
    ProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
}
export declare const ReplicaGlobalSecondaryIndexAutoScalingDescription: S.Schema<ReplicaGlobalSecondaryIndexAutoScalingDescription>;
export type ReplicaGlobalSecondaryIndexAutoScalingDescriptionList = ReplicaGlobalSecondaryIndexAutoScalingDescription[];
export declare const ReplicaGlobalSecondaryIndexAutoScalingDescriptionList: any;
export interface ReplicaAutoScalingDescription {
    RegionName?: string;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndexAutoScalingDescription[];
    ReplicaProvisionedReadCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
    ReplicaProvisionedWriteCapacityAutoScalingSettings?: AutoScalingSettingsDescription;
    ReplicaStatus?: ReplicaStatus;
}
export declare const ReplicaAutoScalingDescription: S.Schema<ReplicaAutoScalingDescription>;
export type ReplicaAutoScalingDescriptionList = ReplicaAutoScalingDescription[];
export declare const ReplicaAutoScalingDescriptionList: any;
export interface TableAutoScalingDescription {
    TableName?: string;
    TableStatus?: TableStatus;
    Replicas?: ReplicaAutoScalingDescription[];
}
export declare const TableAutoScalingDescription: S.Schema<TableAutoScalingDescription>;
export interface DescribeTableReplicaAutoScalingOutput {
    TableAutoScalingDescription?: TableAutoScalingDescription;
}
export declare const DescribeTableReplicaAutoScalingOutput: S.Schema<DescribeTableReplicaAutoScalingOutput>;
export interface DescribeTimeToLiveInput {
    TableName: string;
}
export declare const DescribeTimeToLiveInput: S.Schema<DescribeTimeToLiveInput>;
export interface DescribeTimeToLiveOutput {
    TimeToLiveDescription?: TimeToLiveDescription;
}
export declare const DescribeTimeToLiveOutput: S.Schema<DescribeTimeToLiveOutput>;
export interface EnableKinesisStreamingConfiguration {
    ApproximateCreationDateTimePrecision?: ApproximateCreationDateTimePrecision;
}
export declare const EnableKinesisStreamingConfiguration: S.Schema<EnableKinesisStreamingConfiguration>;
export interface KinesisStreamingDestinationInput {
    TableName: string;
    StreamArn: string;
    EnableKinesisStreamingConfiguration?: EnableKinesisStreamingConfiguration;
}
export declare const KinesisStreamingDestinationInput: S.Schema<KinesisStreamingDestinationInput>;
export interface KinesisStreamingDestinationOutput {
    TableName?: string;
    StreamArn?: string;
    DestinationStatus?: DestinationStatus;
    EnableKinesisStreamingConfiguration?: EnableKinesisStreamingConfiguration;
}
export declare const KinesisStreamingDestinationOutput: S.Schema<KinesisStreamingDestinationOutput>;
export type PartiQLNextToken = string;
export type PositiveIntegerObject = number;
export interface ExecuteStatementInput {
    Statement: string;
    Parameters?: AttributeValue[];
    ConsistentRead?: boolean;
    NextToken?: string;
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    Limit?: number;
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const ExecuteStatementInput: S.Schema<ExecuteStatementInput>;
export interface ExecuteStatementOutput {
    Items?: {
        [key: string]: AttributeValue | undefined;
    }[];
    NextToken?: string;
    ConsumedCapacity?: ConsumedCapacity;
    LastEvaluatedKey?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const ExecuteStatementOutput: S.Schema<ExecuteStatementOutput>;
export interface ParameterizedStatement {
    Statement: string;
    Parameters?: AttributeValue[];
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const ParameterizedStatement: S.Schema<ParameterizedStatement>;
export type ParameterizedStatements = ParameterizedStatement[];
export declare const ParameterizedStatements: any;
export type ClientRequestToken = string;
export interface ExecuteTransactionInput {
    TransactStatements: ParameterizedStatement[];
    ClientRequestToken?: string;
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
}
export declare const ExecuteTransactionInput: S.Schema<ExecuteTransactionInput>;
export interface ItemResponse {
    Item?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const ItemResponse: S.Schema<ItemResponse>;
export type ItemResponseList = ItemResponse[];
export declare const ItemResponseList: any;
export interface ExecuteTransactionOutput {
    Responses?: ItemResponse[];
    ConsumedCapacity?: ConsumedCapacity[];
}
export declare const ExecuteTransactionOutput: S.Schema<ExecuteTransactionOutput>;
export interface ExportTableToPointInTimeInput {
    TableArn: string;
    ExportTime?: Date;
    ClientToken?: string;
    S3Bucket: string;
    S3BucketOwner?: string;
    S3Prefix?: string;
    S3SseAlgorithm?: S3SseAlgorithm;
    S3SseKmsKeyId?: string;
    ExportFormat?: ExportFormat;
    ExportType?: ExportType;
    IncrementalExportSpecification?: IncrementalExportSpecification;
}
export declare const ExportTableToPointInTimeInput: S.Schema<ExportTableToPointInTimeInput>;
export interface ExportTableToPointInTimeOutput {
    ExportDescription?: ExportDescription;
}
export declare const ExportTableToPointInTimeOutput: S.Schema<ExportTableToPointInTimeOutput>;
export interface GetItemInput {
    TableName: string;
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    AttributesToGet?: string[];
    ConsistentRead?: boolean;
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ProjectionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
}
export declare const GetItemInput: S.Schema<GetItemInput>;
export interface GetItemOutput {
    Item?: {
        [key: string]: AttributeValue | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity;
}
export declare const GetItemOutput: S.Schema<GetItemOutput>;
export interface GetResourcePolicyInput {
    ResourceArn: string;
}
export declare const GetResourcePolicyInput: S.Schema<GetResourcePolicyInput>;
export interface GetResourcePolicyOutput {
    Policy?: string;
    RevisionId?: string;
}
export declare const GetResourcePolicyOutput: S.Schema<GetResourcePolicyOutput>;
export interface ImportTableInput {
    ClientToken?: string;
    S3BucketSource: S3BucketSource;
    InputFormat: InputFormat;
    InputFormatOptions?: InputFormatOptions;
    InputCompressionType?: InputCompressionType;
    TableCreationParameters: TableCreationParameters;
}
export declare const ImportTableInput: S.Schema<ImportTableInput>;
export interface ImportTableOutput {
    ImportTableDescription: ImportTableDescription;
}
export declare const ImportTableOutput: S.Schema<ImportTableOutput>;
export type BackupsInputLimit = number;
export type TimeRangeLowerBound = Date;
export type TimeRangeUpperBound = Date;
export type BackupTypeFilter = "USER" | "SYSTEM" | "AWS_BACKUP" | "ALL" | (string & {});
export declare const BackupTypeFilter: any;
export interface ListBackupsInput {
    TableName?: string;
    Limit?: number;
    TimeRangeLowerBound?: Date;
    TimeRangeUpperBound?: Date;
    ExclusiveStartBackupArn?: string;
    BackupType?: BackupTypeFilter;
}
export declare const ListBackupsInput: S.Schema<ListBackupsInput>;
export interface BackupSummary {
    TableName?: string;
    TableId?: string;
    TableArn?: string;
    BackupArn?: string;
    BackupName?: string;
    BackupCreationDateTime?: Date;
    BackupExpiryDateTime?: Date;
    BackupStatus?: BackupStatus;
    BackupType?: BackupType;
    BackupSizeBytes?: number;
}
export declare const BackupSummary: S.Schema<BackupSummary>;
export type BackupSummaries = BackupSummary[];
export declare const BackupSummaries: any;
export interface ListBackupsOutput {
    BackupSummaries?: BackupSummary[];
    LastEvaluatedBackupArn?: string;
}
export declare const ListBackupsOutput: S.Schema<ListBackupsOutput>;
export type NextTokenString = string;
export type ListContributorInsightsLimit = number;
export interface ListContributorInsightsInput {
    TableName?: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListContributorInsightsInput: S.Schema<ListContributorInsightsInput>;
export interface ContributorInsightsSummary {
    TableName?: string;
    IndexName?: string;
    ContributorInsightsStatus?: ContributorInsightsStatus;
    ContributorInsightsMode?: ContributorInsightsMode;
}
export declare const ContributorInsightsSummary: S.Schema<ContributorInsightsSummary>;
export type ContributorInsightsSummaries = ContributorInsightsSummary[];
export declare const ContributorInsightsSummaries: any;
export interface ListContributorInsightsOutput {
    ContributorInsightsSummaries?: ContributorInsightsSummary[];
    NextToken?: string;
}
export declare const ListContributorInsightsOutput: S.Schema<ListContributorInsightsOutput>;
export type ListExportsMaxLimit = number;
export type ExportNextToken = string;
export interface ListExportsInput {
    TableArn?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListExportsInput: S.Schema<ListExportsInput>;
export interface ExportSummary {
    ExportArn?: string;
    ExportStatus?: ExportStatus;
    ExportType?: ExportType;
}
export declare const ExportSummary: S.Schema<ExportSummary>;
export type ExportSummaries = ExportSummary[];
export declare const ExportSummaries: any;
export interface ListExportsOutput {
    ExportSummaries?: ExportSummary[];
    NextToken?: string;
}
export declare const ListExportsOutput: S.Schema<ListExportsOutput>;
export interface ListGlobalTablesInput {
    ExclusiveStartGlobalTableName?: string;
    Limit?: number;
    RegionName?: string;
}
export declare const ListGlobalTablesInput: S.Schema<ListGlobalTablesInput>;
export interface GlobalTable {
    GlobalTableName?: string;
    ReplicationGroup?: Replica[];
}
export declare const GlobalTable: S.Schema<GlobalTable>;
export type GlobalTableList = GlobalTable[];
export declare const GlobalTableList: any;
export interface ListGlobalTablesOutput {
    GlobalTables?: GlobalTable[];
    LastEvaluatedGlobalTableName?: string;
}
export declare const ListGlobalTablesOutput: S.Schema<ListGlobalTablesOutput>;
export type ListImportsMaxLimit = number;
export type ImportNextToken = string;
export interface ListImportsInput {
    TableArn?: string;
    PageSize?: number;
    NextToken?: string;
}
export declare const ListImportsInput: S.Schema<ListImportsInput>;
export interface ImportSummary {
    ImportArn?: string;
    ImportStatus?: ImportStatus;
    TableArn?: string;
    S3BucketSource?: S3BucketSource;
    CloudWatchLogGroupArn?: string;
    InputFormat?: InputFormat;
    StartTime?: Date;
    EndTime?: Date;
}
export declare const ImportSummary: S.Schema<ImportSummary>;
export type ImportSummaryList = ImportSummary[];
export declare const ImportSummaryList: any;
export interface ListImportsOutput {
    ImportSummaryList?: ImportSummary[];
    NextToken?: string;
}
export declare const ListImportsOutput: S.Schema<ListImportsOutput>;
export type ListTablesInputLimit = number;
export interface ListTablesInput {
    ExclusiveStartTableName?: string;
    Limit?: number;
}
export declare const ListTablesInput: S.Schema<ListTablesInput>;
export type TableNameList = string[];
export declare const TableNameList: any;
export interface ListTablesOutput {
    TableNames?: string[];
    LastEvaluatedTableName?: string;
}
export declare const ListTablesOutput: S.Schema<ListTablesOutput>;
export interface ListTagsOfResourceInput {
    ResourceArn: string;
    NextToken?: string;
}
export declare const ListTagsOfResourceInput: S.Schema<ListTagsOfResourceInput>;
export interface ListTagsOfResourceOutput {
    Tags?: Tag[];
    NextToken?: string;
}
export declare const ListTagsOfResourceOutput: S.Schema<ListTagsOfResourceOutput>;
export interface PutItemInput {
    TableName: string;
    Item: {
        [key: string]: AttributeValue | undefined;
    };
    Expected?: {
        [key: string]: ExpectedAttributeValue | undefined;
    };
    ReturnValues?: ReturnValue;
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics;
    ConditionalOperator?: ConditionalOperator;
    ConditionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const PutItemInput: S.Schema<PutItemInput>;
export interface PutItemOutput {
    Attributes?: {
        [key: string]: AttributeValue | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity;
    ItemCollectionMetrics?: ItemCollectionMetrics;
}
export declare const PutItemOutput: S.Schema<PutItemOutput>;
export type ConfirmRemoveSelfResourceAccess = boolean;
export interface PutResourcePolicyInput {
    ResourceArn: string;
    Policy: string;
    ExpectedRevisionId?: string;
    ConfirmRemoveSelfResourceAccess?: boolean;
}
export declare const PutResourcePolicyInput: S.Schema<PutResourcePolicyInput>;
export interface PutResourcePolicyOutput {
    RevisionId?: string;
}
export declare const PutResourcePolicyOutput: S.Schema<PutResourcePolicyOutput>;
export type Select = "ALL_ATTRIBUTES" | "ALL_PROJECTED_ATTRIBUTES" | "SPECIFIC_ATTRIBUTES" | "COUNT" | (string & {});
export declare const Select: any;
export interface Condition {
    AttributeValueList?: AttributeValue[];
    ComparisonOperator: ComparisonOperator;
}
export declare const Condition: S.Schema<Condition>;
export type KeyConditions = {
    [key: string]: Condition | undefined;
};
export declare const KeyConditions: any;
export type FilterConditionMap = {
    [key: string]: Condition | undefined;
};
export declare const FilterConditionMap: any;
export type KeyExpression = string;
export interface QueryInput {
    TableName: string;
    IndexName?: string;
    Select?: Select;
    AttributesToGet?: string[];
    Limit?: number;
    ConsistentRead?: boolean;
    KeyConditions?: {
        [key: string]: Condition | undefined;
    };
    QueryFilter?: {
        [key: string]: Condition | undefined;
    };
    ConditionalOperator?: ConditionalOperator;
    ScanIndexForward?: boolean;
    ExclusiveStartKey?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ProjectionExpression?: string;
    FilterExpression?: string;
    KeyConditionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
}
export declare const QueryInput: S.Schema<QueryInput>;
export interface QueryOutput {
    Items?: {
        [key: string]: AttributeValue | undefined;
    }[];
    Count?: number;
    ScannedCount?: number;
    LastEvaluatedKey?: {
        [key: string]: AttributeValue | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity;
}
export declare const QueryOutput: S.Schema<QueryOutput>;
export interface RestoreTableFromBackupInput {
    TargetTableName: string;
    BackupArn: string;
    BillingModeOverride?: BillingMode;
    GlobalSecondaryIndexOverride?: GlobalSecondaryIndex[];
    LocalSecondaryIndexOverride?: LocalSecondaryIndex[];
    ProvisionedThroughputOverride?: ProvisionedThroughput;
    OnDemandThroughputOverride?: OnDemandThroughput;
    SSESpecificationOverride?: SSESpecification;
    VectorIndexOverride?: VectorIndex[];
}
export declare const RestoreTableFromBackupInput: S.Schema<RestoreTableFromBackupInput>;
export interface RestoreTableFromBackupOutput {
    TableDescription?: TableDescription;
}
export declare const RestoreTableFromBackupOutput: S.Schema<RestoreTableFromBackupOutput>;
export interface RestoreTableToPointInTimeInput {
    SourceTableArn?: string;
    SourceTableName?: string;
    TargetTableName: string;
    UseLatestRestorableTime?: boolean;
    RestoreDateTime?: Date;
    BillingModeOverride?: BillingMode;
    GlobalSecondaryIndexOverride?: GlobalSecondaryIndex[];
    LocalSecondaryIndexOverride?: LocalSecondaryIndex[];
    ProvisionedThroughputOverride?: ProvisionedThroughput;
    OnDemandThroughputOverride?: OnDemandThroughput;
    SSESpecificationOverride?: SSESpecification;
    VectorIndexOverride?: VectorIndex[];
}
export declare const RestoreTableToPointInTimeInput: S.Schema<RestoreTableToPointInTimeInput>;
export interface RestoreTableToPointInTimeOutput {
    TableDescription?: TableDescription;
}
export declare const RestoreTableToPointInTimeOutput: S.Schema<RestoreTableToPointInTimeOutput>;
export type ScanTotalSegments = number;
export type ScanSegment = number;
export interface ScanInput {
    TableName: string;
    IndexName?: string;
    AttributesToGet?: string[];
    Limit?: number;
    Select?: Select;
    ScanFilter?: {
        [key: string]: Condition | undefined;
    };
    ConditionalOperator?: ConditionalOperator;
    ExclusiveStartKey?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    TotalSegments?: number;
    Segment?: number;
    ProjectionExpression?: string;
    FilterExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ConsistentRead?: boolean;
}
export declare const ScanInput: S.Schema<ScanInput>;
export interface ScanOutput {
    Items?: {
        [key: string]: AttributeValue | undefined;
    }[];
    Count?: number;
    ScannedCount?: number;
    LastEvaluatedKey?: {
        [key: string]: AttributeValue | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity;
}
export declare const ScanOutput: S.Schema<ScanOutput>;
export type SearchVectorList = AttributeValue[];
export declare const SearchVectorList: any;
export type TopKInteger = number;
export interface SearchVectorsInput {
    TableName: string;
    IndexName: string;
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ProjectionExpression?: string;
    SearchVector: AttributeValue[];
    SearchConditionExpression?: string;
    TopK: number;
}
export declare const SearchVectorsInput: S.Schema<SearchVectorsInput>;
export type ScoreNumber = number;
export interface SearchResultItem {
    Item?: {
        [key: string]: AttributeValue | undefined;
    };
    Score?: number;
}
export declare const SearchResultItem: S.Schema<SearchResultItem>;
export type SearchResultList = SearchResultItem[];
export declare const SearchResultList: any;
export interface SearchVectorsOutput {
    ConsumedCapacity?: VectorCapacity;
    SearchResults?: SearchResultItem[];
}
export declare const SearchVectorsOutput: S.Schema<SearchVectorsOutput>;
export interface TagResourceInput {
    ResourceArn: string;
    Tags: Tag[];
}
export declare const TagResourceInput: S.Schema<TagResourceInput>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface Get {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ProjectionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
}
export declare const Get: S.Schema<Get>;
export interface TransactGetItem {
    Get: Get;
}
export declare const TransactGetItem: S.Schema<TransactGetItem>;
export type TransactGetItemList = TransactGetItem[];
export declare const TransactGetItemList: any;
export interface TransactGetItemsInput {
    TransactItems: TransactGetItem[];
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
}
export declare const TransactGetItemsInput: S.Schema<TransactGetItemsInput>;
export interface TransactGetItemsOutput {
    ConsumedCapacity?: ConsumedCapacity[];
    Responses?: ItemResponse[];
}
export declare const TransactGetItemsOutput: S.Schema<TransactGetItemsOutput>;
export interface ConditionCheck {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ConditionExpression: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const ConditionCheck: S.Schema<ConditionCheck>;
export interface Put {
    Item: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ConditionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const Put: S.Schema<Put>;
export interface Delete {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    TableName: string;
    ConditionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const Delete: S.Schema<Delete>;
export type UpdateExpression = string;
export interface Update {
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    UpdateExpression: string;
    TableName: string;
    ConditionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const Update: S.Schema<Update>;
export interface TransactWriteItem {
    ConditionCheck?: ConditionCheck;
    Put?: Put;
    Delete?: Delete;
    Update?: Update;
}
export declare const TransactWriteItem: S.Schema<TransactWriteItem>;
export type TransactWriteItemList = TransactWriteItem[];
export declare const TransactWriteItemList: any;
export interface TransactWriteItemsInput {
    TransactItems: TransactWriteItem[];
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics;
    ClientRequestToken?: string;
}
export declare const TransactWriteItemsInput: S.Schema<TransactWriteItemsInput>;
export interface TransactWriteItemsOutput {
    ConsumedCapacity?: ConsumedCapacity[];
    ItemCollectionMetrics?: {
        [key: string]: ItemCollectionMetrics[] | undefined;
    };
}
export declare const TransactWriteItemsOutput: S.Schema<TransactWriteItemsOutput>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export declare const UntagResourceInput: S.Schema<UntagResourceInput>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface PointInTimeRecoverySpecification {
    PointInTimeRecoveryEnabled: boolean;
    RecoveryPeriodInDays?: number;
}
export declare const PointInTimeRecoverySpecification: S.Schema<PointInTimeRecoverySpecification>;
export interface UpdateContinuousBackupsInput {
    TableName: string;
    PointInTimeRecoverySpecification: PointInTimeRecoverySpecification;
}
export declare const UpdateContinuousBackupsInput: S.Schema<UpdateContinuousBackupsInput>;
export interface UpdateContinuousBackupsOutput {
    ContinuousBackupsDescription?: ContinuousBackupsDescription;
}
export declare const UpdateContinuousBackupsOutput: S.Schema<UpdateContinuousBackupsOutput>;
export type ContributorInsightsAction = "ENABLE" | "DISABLE" | (string & {});
export declare const ContributorInsightsAction: any;
export interface UpdateContributorInsightsInput {
    TableName: string;
    IndexName?: string;
    ContributorInsightsAction: ContributorInsightsAction;
    ContributorInsightsMode?: ContributorInsightsMode;
}
export declare const UpdateContributorInsightsInput: S.Schema<UpdateContributorInsightsInput>;
export interface UpdateContributorInsightsOutput {
    TableName?: string;
    IndexName?: string;
    ContributorInsightsStatus?: ContributorInsightsStatus;
    ContributorInsightsMode?: ContributorInsightsMode;
}
export declare const UpdateContributorInsightsOutput: S.Schema<UpdateContributorInsightsOutput>;
export interface CreateReplicaAction {
    RegionName: string;
}
export declare const CreateReplicaAction: S.Schema<CreateReplicaAction>;
export interface DeleteReplicaAction {
    RegionName: string;
}
export declare const DeleteReplicaAction: S.Schema<DeleteReplicaAction>;
export interface ReplicaUpdate {
    Create?: CreateReplicaAction;
    Delete?: DeleteReplicaAction;
}
export declare const ReplicaUpdate: S.Schema<ReplicaUpdate>;
export type ReplicaUpdateList = ReplicaUpdate[];
export declare const ReplicaUpdateList: any;
export interface UpdateGlobalTableInput {
    GlobalTableName: string;
    ReplicaUpdates: ReplicaUpdate[];
}
export declare const UpdateGlobalTableInput: S.Schema<UpdateGlobalTableInput>;
export interface UpdateGlobalTableOutput {
    GlobalTableDescription?: GlobalTableDescription;
}
export declare const UpdateGlobalTableOutput: S.Schema<UpdateGlobalTableOutput>;
export type AutoScalingRoleArn = string;
export interface AutoScalingTargetTrackingScalingPolicyConfigurationUpdate {
    DisableScaleIn?: boolean;
    ScaleInCooldown?: number;
    ScaleOutCooldown?: number;
    TargetValue: number;
}
export declare const AutoScalingTargetTrackingScalingPolicyConfigurationUpdate: S.Schema<AutoScalingTargetTrackingScalingPolicyConfigurationUpdate>;
export interface AutoScalingPolicyUpdate {
    PolicyName?: string;
    TargetTrackingScalingPolicyConfiguration: AutoScalingTargetTrackingScalingPolicyConfigurationUpdate;
}
export declare const AutoScalingPolicyUpdate: S.Schema<AutoScalingPolicyUpdate>;
export interface AutoScalingSettingsUpdate {
    MinimumUnits?: number;
    MaximumUnits?: number;
    AutoScalingDisabled?: boolean;
    AutoScalingRoleArn?: string;
    ScalingPolicyUpdate?: AutoScalingPolicyUpdate;
}
export declare const AutoScalingSettingsUpdate: S.Schema<AutoScalingSettingsUpdate>;
export interface GlobalTableGlobalSecondaryIndexSettingsUpdate {
    IndexName: string;
    ProvisionedWriteCapacityUnits?: number;
    ProvisionedWriteCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate;
}
export declare const GlobalTableGlobalSecondaryIndexSettingsUpdate: S.Schema<GlobalTableGlobalSecondaryIndexSettingsUpdate>;
export type GlobalTableGlobalSecondaryIndexSettingsUpdateList = GlobalTableGlobalSecondaryIndexSettingsUpdate[];
export declare const GlobalTableGlobalSecondaryIndexSettingsUpdateList: any;
export interface ReplicaGlobalSecondaryIndexSettingsUpdate {
    IndexName: string;
    ProvisionedReadCapacityUnits?: number;
    ProvisionedReadCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate;
}
export declare const ReplicaGlobalSecondaryIndexSettingsUpdate: S.Schema<ReplicaGlobalSecondaryIndexSettingsUpdate>;
export type ReplicaGlobalSecondaryIndexSettingsUpdateList = ReplicaGlobalSecondaryIndexSettingsUpdate[];
export declare const ReplicaGlobalSecondaryIndexSettingsUpdateList: any;
export interface ReplicaSettingsUpdate {
    RegionName: string;
    ReplicaProvisionedReadCapacityUnits?: number;
    ReplicaProvisionedReadCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate;
    ReplicaGlobalSecondaryIndexSettingsUpdate?: ReplicaGlobalSecondaryIndexSettingsUpdate[];
    ReplicaTableClass?: TableClass;
}
export declare const ReplicaSettingsUpdate: S.Schema<ReplicaSettingsUpdate>;
export type ReplicaSettingsUpdateList = ReplicaSettingsUpdate[];
export declare const ReplicaSettingsUpdateList: any;
export interface UpdateGlobalTableSettingsInput {
    GlobalTableName: string;
    GlobalTableBillingMode?: BillingMode;
    GlobalTableProvisionedWriteCapacityUnits?: number;
    GlobalTableProvisionedWriteCapacityAutoScalingSettingsUpdate?: AutoScalingSettingsUpdate;
    GlobalTableGlobalSecondaryIndexSettingsUpdate?: GlobalTableGlobalSecondaryIndexSettingsUpdate[];
    ReplicaSettingsUpdate?: ReplicaSettingsUpdate[];
}
export declare const UpdateGlobalTableSettingsInput: S.Schema<UpdateGlobalTableSettingsInput>;
export interface UpdateGlobalTableSettingsOutput {
    GlobalTableName?: string;
    ReplicaSettings?: ReplicaSettingsDescription[];
}
export declare const UpdateGlobalTableSettingsOutput: S.Schema<UpdateGlobalTableSettingsOutput>;
export type AttributeAction = "ADD" | "PUT" | "DELETE" | (string & {});
export declare const AttributeAction: any;
export interface AttributeValueUpdate {
    Value?: AttributeValue;
    Action?: AttributeAction;
}
export declare const AttributeValueUpdate: S.Schema<AttributeValueUpdate>;
export type AttributeUpdates = {
    [key: string]: AttributeValueUpdate | undefined;
};
export declare const AttributeUpdates: any;
export interface UpdateItemInput {
    TableName: string;
    Key: {
        [key: string]: AttributeValue | undefined;
    };
    AttributeUpdates?: {
        [key: string]: AttributeValueUpdate | undefined;
    };
    Expected?: {
        [key: string]: ExpectedAttributeValue | undefined;
    };
    ConditionalOperator?: ConditionalOperator;
    ReturnValues?: ReturnValue;
    ReturnConsumedCapacity?: ReturnConsumedCapacity;
    ReturnItemCollectionMetrics?: ReturnItemCollectionMetrics;
    UpdateExpression?: string;
    ConditionExpression?: string;
    ExpressionAttributeNames?: {
        [key: string]: string | undefined;
    };
    ExpressionAttributeValues?: {
        [key: string]: AttributeValue | undefined;
    };
    ReturnValuesOnConditionCheckFailure?: ReturnValuesOnConditionCheckFailure;
}
export declare const UpdateItemInput: S.Schema<UpdateItemInput>;
export interface UpdateItemOutput {
    Attributes?: {
        [key: string]: AttributeValue | undefined;
    };
    ConsumedCapacity?: ConsumedCapacity;
    ItemCollectionMetrics?: ItemCollectionMetrics;
}
export declare const UpdateItemOutput: S.Schema<UpdateItemOutput>;
export interface UpdateKinesisStreamingConfiguration {
    ApproximateCreationDateTimePrecision?: ApproximateCreationDateTimePrecision;
}
export declare const UpdateKinesisStreamingConfiguration: S.Schema<UpdateKinesisStreamingConfiguration>;
export interface UpdateKinesisStreamingDestinationInput {
    TableName: string;
    StreamArn: string;
    UpdateKinesisStreamingConfiguration?: UpdateKinesisStreamingConfiguration;
}
export declare const UpdateKinesisStreamingDestinationInput: S.Schema<UpdateKinesisStreamingDestinationInput>;
export interface UpdateKinesisStreamingDestinationOutput {
    TableName?: string;
    StreamArn?: string;
    DestinationStatus?: DestinationStatus;
    UpdateKinesisStreamingConfiguration?: UpdateKinesisStreamingConfiguration;
}
export declare const UpdateKinesisStreamingDestinationOutput: S.Schema<UpdateKinesisStreamingDestinationOutput>;
export interface UpdateGlobalSecondaryIndexAction {
    IndexName: string;
    ProvisionedThroughput?: ProvisionedThroughput;
    OnDemandThroughput?: OnDemandThroughput;
    WarmThroughput?: WarmThroughput;
}
export declare const UpdateGlobalSecondaryIndexAction: S.Schema<UpdateGlobalSecondaryIndexAction>;
export interface CreateGlobalSecondaryIndexAction {
    IndexName: string;
    KeySchema: KeySchemaElement[];
    Projection: Projection;
    ProvisionedThroughput?: ProvisionedThroughput;
    OnDemandThroughput?: OnDemandThroughput;
    WarmThroughput?: WarmThroughput;
}
export declare const CreateGlobalSecondaryIndexAction: S.Schema<CreateGlobalSecondaryIndexAction>;
export interface DeleteGlobalSecondaryIndexAction {
    IndexName: string;
}
export declare const DeleteGlobalSecondaryIndexAction: S.Schema<DeleteGlobalSecondaryIndexAction>;
export interface GlobalSecondaryIndexUpdate {
    Update?: UpdateGlobalSecondaryIndexAction;
    Create?: CreateGlobalSecondaryIndexAction;
    Delete?: DeleteGlobalSecondaryIndexAction;
}
export declare const GlobalSecondaryIndexUpdate: S.Schema<GlobalSecondaryIndexUpdate>;
export type GlobalSecondaryIndexUpdateList = GlobalSecondaryIndexUpdate[];
export declare const GlobalSecondaryIndexUpdateList: any;
export interface ReplicaGlobalSecondaryIndex {
    IndexName: string;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride;
    OnDemandThroughputOverride?: OnDemandThroughputOverride;
}
export declare const ReplicaGlobalSecondaryIndex: S.Schema<ReplicaGlobalSecondaryIndex>;
export type ReplicaGlobalSecondaryIndexList = ReplicaGlobalSecondaryIndex[];
export declare const ReplicaGlobalSecondaryIndexList: any;
export interface CreateReplicationGroupMemberAction {
    RegionName: string;
    KMSMasterKeyId?: string;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride;
    OnDemandThroughputOverride?: OnDemandThroughputOverride;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndex[];
    TableClassOverride?: TableClass;
}
export declare const CreateReplicationGroupMemberAction: S.Schema<CreateReplicationGroupMemberAction>;
export interface UpdateReplicationGroupMemberAction {
    RegionName: string;
    KMSMasterKeyId?: string;
    ProvisionedThroughputOverride?: ProvisionedThroughputOverride;
    OnDemandThroughputOverride?: OnDemandThroughputOverride;
    GlobalSecondaryIndexes?: ReplicaGlobalSecondaryIndex[];
    TableClassOverride?: TableClass;
}
export declare const UpdateReplicationGroupMemberAction: S.Schema<UpdateReplicationGroupMemberAction>;
export interface DeleteReplicationGroupMemberAction {
    RegionName: string;
}
export declare const DeleteReplicationGroupMemberAction: S.Schema<DeleteReplicationGroupMemberAction>;
export interface ReplicationGroupUpdate {
    Create?: CreateReplicationGroupMemberAction;
    Update?: UpdateReplicationGroupMemberAction;
    Delete?: DeleteReplicationGroupMemberAction;
}
export declare const ReplicationGroupUpdate: S.Schema<ReplicationGroupUpdate>;
export type ReplicationGroupUpdateList = ReplicationGroupUpdate[];
export declare const ReplicationGroupUpdateList: any;
export interface CreateGlobalTableWitnessGroupMemberAction {
    RegionName: string;
}
export declare const CreateGlobalTableWitnessGroupMemberAction: S.Schema<CreateGlobalTableWitnessGroupMemberAction>;
export interface DeleteGlobalTableWitnessGroupMemberAction {
    RegionName: string;
}
export declare const DeleteGlobalTableWitnessGroupMemberAction: S.Schema<DeleteGlobalTableWitnessGroupMemberAction>;
export interface GlobalTableWitnessGroupUpdate {
    Create?: CreateGlobalTableWitnessGroupMemberAction;
    Delete?: DeleteGlobalTableWitnessGroupMemberAction;
}
export declare const GlobalTableWitnessGroupUpdate: S.Schema<GlobalTableWitnessGroupUpdate>;
export type GlobalTableWitnessGroupUpdateList = GlobalTableWitnessGroupUpdate[];
export declare const GlobalTableWitnessGroupUpdateList: any;
export interface CreateVectorIndexAction {
    IndexName: string;
    VectorAttribute: VectorAttributeDefinition;
    SearchSchema?: SearchSchemaElement[];
    Projection: Projection;
    Dimensions: number;
    DistanceFunction: VectorDistanceFunction;
}
export declare const CreateVectorIndexAction: S.Schema<CreateVectorIndexAction>;
export interface DeleteVectorIndexAction {
    IndexName: string;
}
export declare const DeleteVectorIndexAction: S.Schema<DeleteVectorIndexAction>;
export interface VectorIndexUpdate {
    Create?: CreateVectorIndexAction;
    Delete?: DeleteVectorIndexAction;
}
export declare const VectorIndexUpdate: S.Schema<VectorIndexUpdate>;
export type VectorIndexUpdateList = VectorIndexUpdate[];
export declare const VectorIndexUpdateList: any;
export interface UpdateTableInput {
    AttributeDefinitions?: AttributeDefinition[];
    TableName: string;
    BillingMode?: BillingMode;
    ProvisionedThroughput?: ProvisionedThroughput;
    GlobalSecondaryIndexUpdates?: GlobalSecondaryIndexUpdate[];
    StreamSpecification?: StreamSpecification;
    SSESpecification?: SSESpecification;
    ReplicaUpdates?: ReplicationGroupUpdate[];
    TableClass?: TableClass;
    DeletionProtectionEnabled?: boolean;
    MultiRegionConsistency?: MultiRegionConsistency;
    GlobalTableWitnessUpdates?: GlobalTableWitnessGroupUpdate[];
    OnDemandThroughput?: OnDemandThroughput;
    WarmThroughput?: WarmThroughput;
    GlobalTableSettingsReplicationMode?: GlobalTableSettingsReplicationMode;
    VectorIndexUpdates?: VectorIndexUpdate[];
}
export declare const UpdateTableInput: S.Schema<UpdateTableInput>;
export interface UpdateTableOutput {
    TableDescription?: TableDescription;
}
export declare const UpdateTableOutput: S.Schema<UpdateTableOutput>;
export interface GlobalSecondaryIndexAutoScalingUpdate {
    IndexName?: string;
    ProvisionedWriteCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate;
}
export declare const GlobalSecondaryIndexAutoScalingUpdate: S.Schema<GlobalSecondaryIndexAutoScalingUpdate>;
export type GlobalSecondaryIndexAutoScalingUpdateList = GlobalSecondaryIndexAutoScalingUpdate[];
export declare const GlobalSecondaryIndexAutoScalingUpdateList: any;
export interface ReplicaGlobalSecondaryIndexAutoScalingUpdate {
    IndexName?: string;
    ProvisionedReadCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate;
}
export declare const ReplicaGlobalSecondaryIndexAutoScalingUpdate: S.Schema<ReplicaGlobalSecondaryIndexAutoScalingUpdate>;
export type ReplicaGlobalSecondaryIndexAutoScalingUpdateList = ReplicaGlobalSecondaryIndexAutoScalingUpdate[];
export declare const ReplicaGlobalSecondaryIndexAutoScalingUpdateList: any;
export interface ReplicaAutoScalingUpdate {
    RegionName: string;
    ReplicaGlobalSecondaryIndexUpdates?: ReplicaGlobalSecondaryIndexAutoScalingUpdate[];
    ReplicaProvisionedReadCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate;
}
export declare const ReplicaAutoScalingUpdate: S.Schema<ReplicaAutoScalingUpdate>;
export type ReplicaAutoScalingUpdateList = ReplicaAutoScalingUpdate[];
export declare const ReplicaAutoScalingUpdateList: any;
export interface UpdateTableReplicaAutoScalingInput {
    GlobalSecondaryIndexUpdates?: GlobalSecondaryIndexAutoScalingUpdate[];
    TableName: string;
    ProvisionedWriteCapacityAutoScalingUpdate?: AutoScalingSettingsUpdate;
    ReplicaUpdates?: ReplicaAutoScalingUpdate[];
}
export declare const UpdateTableReplicaAutoScalingInput: S.Schema<UpdateTableReplicaAutoScalingInput>;
export interface UpdateTableReplicaAutoScalingOutput {
    TableAutoScalingDescription?: TableAutoScalingDescription;
}
export declare const UpdateTableReplicaAutoScalingOutput: S.Schema<UpdateTableReplicaAutoScalingOutput>;
export type TimeToLiveEnabled = boolean;
export interface TimeToLiveSpecification {
    Enabled: boolean;
    AttributeName: string;
}
export declare const TimeToLiveSpecification: S.Schema<TimeToLiveSpecification>;
export interface UpdateTimeToLiveInput {
    TableName: string;
    TimeToLiveSpecification: TimeToLiveSpecification;
}
export declare const UpdateTimeToLiveInput: S.Schema<UpdateTimeToLiveInput>;
export interface UpdateTimeToLiveOutput {
    TimeToLiveSpecification?: TimeToLiveSpecification;
}
export declare const UpdateTimeToLiveOutput: S.Schema<UpdateTimeToLiveOutput>;
export type ErrorMessage = string;
export type Reason = string;
export type Resource = string;
export interface ThrottlingReason {
    reason?: string;
    resource?: string;
}
export declare const ThrottlingReason: S.Schema<ThrottlingReason>;
export type ThrottlingReasonList = ThrottlingReason[];
export declare const ThrottlingReasonList: any;
export type AvailabilityErrorMessage = string;
export type Code = string;
export interface CancellationReason {
    Item?: {
        [key: string]: AttributeValue | undefined;
    };
    Code?: string;
    Message?: string;
}
export declare const CancellationReason: S.Schema<CancellationReason>;
export type CancellationReasonList = CancellationReason[];
export declare const CancellationReasonList: any;
export type BatchExecuteStatementError = InternalServerError | RequestLimitExceeded | ThrottlingException | CommonErrors;
/**
 * This operation allows you to perform batch reads or writes on data stored in DynamoDB,
 * using PartiQL. Each read statement in a `BatchExecuteStatement` must specify
 * an equality condition on all key attributes. This enforces that each `SELECT`
 * statement in a batch returns at most a single item. For more information, see Running batch operations with PartiQL for DynamoDB .
 *
 * The entire batch must consist of either read statements or write statements, you
 * cannot mix both in one batch.
 *
 * A HTTP 200 response does not mean that all statements in the BatchExecuteStatement
 * succeeded. Error details for individual statements can be found under the Error field of the `BatchStatementResponse` for each
 * statement.
 */
export declare const batchExecuteStatement: API.OperationMethod<BatchExecuteStatementInput, BatchExecuteStatementOutput, BatchExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type BatchGetItemError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `BatchGetItem` operation returns the attributes of one or more items
 * from one or more tables. You identify requested items by primary key.
 *
 * A single operation can retrieve up to 16 MB of data, which can contain as many as 100
 * items. `BatchGetItem` returns a partial result if the response size limit is
 * exceeded, the table's provisioned throughput is exceeded, more than 1MB per partition is
 * requested, or an internal processing failure occurs. If a partial result is returned,
 * the operation returns a value for `UnprocessedKeys`. You can use this value
 * to retry the operation starting with the next item to get.
 *
 * If you request more than 100 items, `BatchGetItem` returns a
 * `ValidationException` with the message "Too many items requested for
 * the BatchGetItem call."
 *
 * For example, if you ask to retrieve 100 items, but each individual item is 300 KB in
 * size, the system returns 52 items (so as not to exceed the 16 MB limit). It also returns
 * an appropriate `UnprocessedKeys` value so you can get the next page of
 * results. If desired, your application can include its own logic to assemble the pages of
 * results into one dataset.
 *
 * If *none* of the items can be processed due to insufficient
 * provisioned throughput on all of the tables in the request, then
 * `BatchGetItem` returns a
 * `ProvisionedThroughputExceededException`. If at least
 * one of the items is successfully processed, then
 * `BatchGetItem` completes successfully, while returning the keys of the
 * unread items in `UnprocessedKeys`.
 *
 * If DynamoDB returns any unprocessed items, you should retry the batch operation on
 * those items. However, we strongly recommend that you use an exponential
 * backoff algorithm. If you retry the batch operation immediately, the
 * underlying read or write requests can still fail due to throttling on the individual
 * tables. If you delay the batch operation using exponential backoff, the individual
 * requests in the batch are much more likely to succeed.
 *
 * For more information, see Batch Operations and Error Handling in the Amazon DynamoDB
 * Developer Guide.
 *
 * By default, `BatchGetItem` performs eventually consistent reads on every
 * table in the request. If you want strongly consistent reads instead, you can set
 * `ConsistentRead` to `true` for any or all tables.
 *
 * In order to minimize response latency, `BatchGetItem` may retrieve items in
 * parallel.
 *
 * When designing your application, keep in mind that DynamoDB does not return items in
 * any particular order. To help parse the response by item, include the primary key values
 * for the items in your request in the `ProjectionExpression` parameter.
 *
 * If a requested item does not exist, it is not returned in the result. Requests for
 * nonexistent items consume the minimum read capacity units according to the type of read.
 * For more information, see Working with Tables in the Amazon DynamoDB Developer
 * Guide.
 *
 * `BatchGetItem` will result in a `ValidationException` if the
 * same key is specified multiple times.
 */
export declare const batchGetItem: API.OperationMethod<BatchGetItemInput, BatchGetItemOutput, BatchGetItemError, Credentials | HttpClient.HttpClient>;
export type BatchWriteItemError = InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `BatchWriteItem` operation puts or deletes multiple items in one or
 * more tables. A single call to `BatchWriteItem` can transmit up to 16MB of
 * data over the network, consisting of up to 25 item put or delete operations. While
 * individual items can be up to 400 KB once stored, it's important to note that an item's
 * representation might be greater than 400KB while being sent in DynamoDB's JSON format
 * for the API call. For more details on this distinction, see Naming Rules and Data Types.
 *
 * `BatchWriteItem` cannot update items. If you perform a
 * `BatchWriteItem` operation on an existing item, that item's values
 * will be overwritten by the operation and it will appear like it was updated. To
 * update items, we recommend you use the `UpdateItem` action.
 *
 * The individual `PutItem` and `DeleteItem` operations specified
 * in `BatchWriteItem` are atomic; however `BatchWriteItem` as a
 * whole is not. If any requested operations fail because the table's provisioned
 * throughput is exceeded or an internal processing failure occurs, the failed operations
 * are returned in the `UnprocessedItems` response parameter. You can
 * investigate and optionally resend the requests. Typically, you would call
 * `BatchWriteItem` in a loop. Each iteration would check for unprocessed
 * items and submit a new `BatchWriteItem` request with those unprocessed items
 * until all items have been processed.
 *
 * If `BatchWriteItem` cannot process any items due to throttling (for
 * example, insufficient provisioned throughput on the tables in the request, or
 * partition-level or account-level limits), it returns a
 * `ProvisionedThroughputExceededException` or a
 * `ThrottlingException`. Both indicate that the request was throttled;
 * check the `ThrottlingReason` field in the returned exception for details.
 *
 * If DynamoDB returns any unprocessed items, you should retry the batch operation on
 * those items. However, we strongly recommend that you use an exponential
 * backoff algorithm. If you retry the batch operation immediately, the
 * underlying read or write requests can still fail due to throttling on the individual
 * tables. If you delay the batch operation using exponential backoff, the individual
 * requests in the batch are much more likely to succeed.
 *
 * For more information, see Batch Operations and Error Handling in the Amazon DynamoDB
 * Developer Guide.
 *
 * With `BatchWriteItem`, you can efficiently write or delete large amounts of
 * data, such as from Amazon EMR, or copy data from another database into DynamoDB. In
 * order to improve performance with these large-scale operations,
 * `BatchWriteItem` does not behave in the same way as individual
 * `PutItem` and `DeleteItem` calls would. For example, you
 * cannot specify conditions on individual put and delete requests, and
 * `BatchWriteItem` does not return deleted items in the response.
 *
 * If you use a programming language that supports concurrency, you can use threads to
 * write items in parallel. Your application must include the necessary logic to manage the
 * threads. With languages that don't support threading, you must update or delete the
 * specified items one at a time. In both situations, `BatchWriteItem` performs
 * the specified put and delete operations in parallel, giving you the power of the thread
 * pool approach without having to introduce complexity into your application.
 *
 * Parallel processing reduces latency, but each specified put and delete request
 * consumes the same number of write capacity units whether it is processed in parallel or
 * not. Delete operations on nonexistent items consume one write capacity unit.
 *
 * If one or more of the following is true, DynamoDB rejects the entire batch write
 * operation:
 *
 * - One or more tables specified in the `BatchWriteItem` request does
 * not exist.
 *
 * - Primary key attributes specified on an item in the request do not match those
 * in the corresponding table's primary key schema.
 *
 * - You try to perform multiple operations on the same item in the same
 * `BatchWriteItem` request. For example, you cannot put and delete
 * the same item in the same `BatchWriteItem` request.
 *
 * - Your request contains at least two items with identical hash and range keys
 * (which essentially is two put operations).
 *
 * - There are more than 25 requests in the batch.
 *
 * - Any individual item in a batch exceeds 400 KB.
 *
 * - The total request size exceeds 16 MB.
 *
 * - Any individual items with keys exceeding the key length limits. For a
 * partition key, the limit is 2048 bytes and for a sort key, the limit is 1024
 * bytes.
 */
export declare const batchWriteItem: API.OperationMethod<BatchWriteItemInput, BatchWriteItemOutput, BatchWriteItemError, Credentials | HttpClient.HttpClient>;
export type CreateBackupError = BackupInUseException | ContinuousBackupsUnavailableException | InternalServerError | InvalidEndpointException | LimitExceededException | TableInUseException | TableNotFoundException | CommonErrors;
/**
 * Creates a backup for an existing table.
 *
 * Each time you create an on-demand backup, the entire table data is backed up. There
 * is no limit to the number of on-demand backups that can be taken.
 *
 * When you create an on-demand backup, a time marker of the request is cataloged, and
 * the backup is created asynchronously, by applying all changes until the time of the
 * request to the last full table snapshot. Backup requests are processed instantaneously
 * and become available for restore within minutes.
 *
 * You can call `CreateBackup` at a maximum rate of 50 times per
 * second.
 *
 * All backups in DynamoDB work without consuming any provisioned throughput on the
 * table.
 *
 * If you submit a backup request on 2018-12-14 at 14:25:00, the backup is guaranteed to
 * contain all data committed to the table up to 14:24:00, and data committed after
 * 14:26:00 will not be. The backup might contain data modifications made between 14:24:00
 * and 14:26:00. On-demand backup does not support causal consistency.
 *
 * Along with data, the following are also included on the backups:
 *
 * - Global secondary indexes (GSIs)
 *
 * - Local secondary indexes (LSIs)
 *
 * - Streams
 *
 * - Provisioned read and write capacity
 */
export declare const createBackup: API.OperationMethod<CreateBackupInput, CreateBackupOutput, CreateBackupError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalTableError = GlobalTableAlreadyExistsException | InternalServerError | InvalidEndpointException | LimitExceededException | TableNotFoundException | CommonErrors;
/**
 * Creates a global table from an existing table. A global table creates a replication
 * relationship between two or more DynamoDB tables with the same table name in the
 * provided Regions.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 *
 * If you want to add a new replica table to a global table, each of the following
 * conditions must be true:
 *
 * - The table must have the same primary key as all of the other replicas.
 *
 * - The table must have the same name as all of the other replicas.
 *
 * - The table must have DynamoDB Streams enabled, with the stream containing both
 * the new and the old images of the item.
 *
 * - None of the replica tables in the global table can contain any data.
 *
 * If global secondary indexes are specified, then the following conditions must also be
 * met:
 *
 * - The global secondary indexes must have the same name.
 *
 * - The global secondary indexes must have the same hash key and sort key (if
 * present).
 *
 * If local secondary indexes are specified, then the following conditions must also be
 * met:
 *
 * - The local secondary indexes must have the same name.
 *
 * - The local secondary indexes must have the same hash key and sort key (if
 * present).
 *
 * Write capacity settings should be set consistently across your replica tables and
 * secondary indexes. DynamoDB strongly recommends enabling auto scaling to manage the
 * write capacity settings for all of your global tables replicas and indexes.
 *
 * If you prefer to manage write capacity settings manually, you should provision
 * equal replicated write capacity units to your replica tables. You should also
 * provision equal replicated write capacity units to matching secondary indexes across
 * your global table.
 */
export declare const createGlobalTable: API.OperationMethod<CreateGlobalTableInput, CreateGlobalTableOutput, CreateGlobalTableError, Credentials | HttpClient.HttpClient>;
export type CreateTableError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | CommonErrors;
/**
 * The `CreateTable` operation adds a new table to your account. In an Amazon Web Services account, table names must be unique within each Region. That is, you can
 * have two tables with same name if you create the tables in different Regions.
 *
 * `CreateTable` is an asynchronous operation. Upon receiving a
 * `CreateTable` request, DynamoDB immediately returns a response with a
 * `TableStatus` of `CREATING`. After the table is created,
 * DynamoDB sets the `TableStatus` to `ACTIVE`. You can perform read
 * and write operations only on an `ACTIVE` table.
 *
 * You can optionally define secondary indexes on the new table, as part of the
 * `CreateTable` operation. If you want to create multiple tables with
 * secondary indexes on them, you must create the tables sequentially. Only one table with
 * secondary indexes can be in the `CREATING` state at any given time.
 *
 * You can use the `DescribeTable` action to check the table status.
 */
export declare const createTable: API.OperationMethod<CreateTableInput, CreateTableOutput, CreateTableError, Credentials | HttpClient.HttpClient>;
export type DeleteBackupError = BackupInUseException | BackupNotFoundException | InternalServerError | InvalidEndpointException | LimitExceededException | CommonErrors;
/**
 * Deletes an existing backup of a table.
 *
 * You can call `DeleteBackup` at a maximum rate of 10 times per
 * second.
 */
export declare const deleteBackup: API.OperationMethod<DeleteBackupInput, DeleteBackupOutput, DeleteBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteItemError = ConditionalCheckFailedException | InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * Deletes a single item in a table by primary key. You can perform a conditional delete
 * operation that deletes the item if it exists, or if it has an expected attribute
 * value.
 *
 * In addition to deleting an item, you can also return the item's attribute values in
 * the same operation, using the `ReturnValues` parameter.
 *
 * Unless you specify conditions, the `DeleteItem` is an idempotent operation;
 * running it multiple times on the same item or attribute does *not*
 * result in an error response.
 *
 * Conditional deletes are useful for deleting items only if specific conditions are met.
 * If those conditions are met, DynamoDB performs the delete. Otherwise, the item is not
 * deleted.
 */
export declare const deleteItem: API.OperationMethod<DeleteItemInput, DeleteItemOutput, DeleteItemError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InternalServerError | InvalidEndpointException | LimitExceededException | PolicyNotFoundException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the resource-based policy attached to the resource, which can be a table or
 * stream.
 *
 * `DeleteResourcePolicy` is an idempotent operation; running it multiple
 * times on the same resource *doesn't* result in an error response,
 * unless you specify an `ExpectedRevisionId`, which will then return a
 * `PolicyNotFoundException`.
 *
 * To make sure that you don't inadvertently lock yourself out of your own resources,
 * the root principal in your Amazon Web Services account can perform
 * `DeleteResourcePolicy` requests, even if your resource-based policy
 * explicitly denies the root principal's access.
 *
 * `DeleteResourcePolicy` is an asynchronous operation. If you issue a
 * `GetResourcePolicy` request immediately after running the
 * `DeleteResourcePolicy` request, DynamoDB might still return
 * the deleted policy. This is because the policy for your resource might not have been
 * deleted yet. Wait for a few seconds, and then try the `GetResourcePolicy`
 * request again.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyInput, DeleteResourcePolicyOutput, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteTableError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * The `DeleteTable` operation deletes a table and all of its items. After a
 * `DeleteTable` request, the specified table is in the
 * `DELETING` state until DynamoDB completes the deletion. If the table is
 * in the `ACTIVE` state, you can delete it. If a table is in
 * `CREATING` or `UPDATING` states, then DynamoDB returns a
 * `ResourceInUseException`. If the specified table does not exist, DynamoDB
 * returns a `ResourceNotFoundException`. If table is already in the
 * `DELETING` state, no error is returned.
 *
 * DynamoDB might continue to accept data read and write operations, such as
 * `GetItem` and `PutItem`, on a table in the
 * `DELETING` state until the table deletion is complete. For the full
 * list of table states, see TableStatus.
 *
 * When you delete a table, any indexes on that table are also deleted.
 *
 * If you have DynamoDB Streams enabled on the table, then the corresponding stream on
 * that table goes into the `DISABLED` state, and the stream is automatically
 * deleted after 24 hours.
 *
 * Use the `DescribeTable` action to check the status of the table.
 */
export declare const deleteTable: API.OperationMethod<DeleteTableInput, DeleteTableOutput, DeleteTableError, Credentials | HttpClient.HttpClient>;
export type DescribeBackupError = BackupNotFoundException | InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Describes an existing backup of a table.
 *
 * You can call `DescribeBackup` at a maximum rate of 10 times per
 * second.
 */
export declare const describeBackup: API.OperationMethod<DescribeBackupInput, DescribeBackupOutput, DescribeBackupError, Credentials | HttpClient.HttpClient>;
export type DescribeContinuousBackupsError = InternalServerError | InvalidEndpointException | TableNotFoundException | CommonErrors;
/**
 * Checks the status of continuous backups and point in time recovery on the specified
 * table. Continuous backups are `ENABLED` on all tables at table creation. If
 * point in time recovery is enabled, `PointInTimeRecoveryStatus` will be set to
 * ENABLED.
 *
 * After continuous backups and point in time recovery are enabled, you can restore to
 * any point in time within `EarliestRestorableDateTime` and
 * `LatestRestorableDateTime`.
 *
 * `LatestRestorableDateTime` is typically 5 minutes before the current time.
 * You can restore your table to any point in time in the last 35 days. You can set the
 * recovery period to any value between 1 and 35 days.
 *
 * You can call `DescribeContinuousBackups` at a maximum rate of 10 times per
 * second.
 */
export declare const describeContinuousBackups: API.OperationMethod<DescribeContinuousBackupsInput, DescribeContinuousBackupsOutput, DescribeContinuousBackupsError, Credentials | HttpClient.HttpClient>;
export type DescribeContributorInsightsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about contributor insights for a given table or global secondary
 * index.
 */
export declare const describeContributorInsights: API.OperationMethod<DescribeContributorInsightsInput, DescribeContributorInsightsOutput, DescribeContributorInsightsError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointsError = CommonErrors;
/**
 * Returns the regional endpoint information. For more information on policy permissions,
 * please see Internetwork traffic privacy.
 */
export declare const describeEndpoints: API.OperationMethod<DescribeEndpointsRequest, DescribeEndpointsResponse, DescribeEndpointsError, Credentials | HttpClient.HttpClient>;
export type DescribeExportError = ExportNotFoundException | InternalServerError | LimitExceededException | CommonErrors;
/**
 * Describes an existing table export.
 */
export declare const describeExport: API.OperationMethod<DescribeExportInput, DescribeExportOutput, DescribeExportError, Credentials | HttpClient.HttpClient>;
export type DescribeGlobalTableError = GlobalTableNotFoundException | InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Returns information about the specified global table.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const describeGlobalTable: API.OperationMethod<DescribeGlobalTableInput, DescribeGlobalTableOutput, DescribeGlobalTableError, Credentials | HttpClient.HttpClient>;
export type DescribeGlobalTableSettingsError = GlobalTableNotFoundException | InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Describes Region-specific settings for a global table.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const describeGlobalTableSettings: API.OperationMethod<DescribeGlobalTableSettingsInput, DescribeGlobalTableSettingsOutput, DescribeGlobalTableSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeImportError = ImportNotFoundException | CommonErrors;
/**
 * Represents the properties of the import.
 */
export declare const describeImport: API.OperationMethod<DescribeImportInput, DescribeImportOutput, DescribeImportError, Credentials | HttpClient.HttpClient>;
export type DescribeKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the status of Kinesis streaming.
 */
export declare const describeKinesisStreamingDestination: API.OperationMethod<DescribeKinesisStreamingDestinationInput, DescribeKinesisStreamingDestinationOutput, DescribeKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type DescribeLimitsError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Returns the current provisioned-capacity quotas for your Amazon Web Services account in
 * a Region, both for the Region as a whole and for any one DynamoDB table that you create
 * there.
 *
 * When you establish an Amazon Web Services account, the account has initial quotas on
 * the maximum read capacity units and write capacity units that you can provision across
 * all of your DynamoDB tables in a given Region. Also, there are per-table
 * quotas that apply when you create a table there. For more information, see Service,
 * Account, and Table Quotas page in the Amazon DynamoDB
 * Developer Guide.
 *
 * Although you can increase these quotas by filing a case at Amazon Web Services Support Center, obtaining the
 * increase is not instantaneous. The `DescribeLimits` action lets you write
 * code to compare the capacity you are currently using to those quotas imposed by your
 * account so that you have enough time to apply for an increase before you hit a
 * quota.
 *
 * For example, you could use one of the Amazon Web Services SDKs to do the
 * following:
 *
 * - Call `DescribeLimits` for a particular Region to obtain your
 * current account quotas on provisioned capacity there.
 *
 * - Create a variable to hold the aggregate read capacity units provisioned for
 * all your tables in that Region, and one to hold the aggregate write capacity
 * units. Zero them both.
 *
 * - Call `ListTables` to obtain a list of all your DynamoDB
 * tables.
 *
 * - For each table name listed by `ListTables`, do the
 * following:
 *
 * - Call `DescribeTable` with the table name.
 *
 * - Use the data returned by `DescribeTable` to add the read
 * capacity units and write capacity units provisioned for the table itself
 * to your variables.
 *
 * - If the table has one or more global secondary indexes (GSIs), loop
 * over these GSIs and add their provisioned capacity values to your
 * variables as well.
 *
 * - Report the account quotas for that Region returned by
 * `DescribeLimits`, along with the total current provisioned
 * capacity levels you have calculated.
 *
 * This will let you see whether you are getting close to your account-level
 * quotas.
 *
 * The per-table quotas apply only when you are creating a new table. They restrict the
 * sum of the provisioned capacity of the new table itself and all its global secondary
 * indexes.
 *
 * For existing tables and their GSIs, DynamoDB doesn't let you increase provisioned
 * capacity extremely rapidly, but the only quota that applies is that the aggregate
 * provisioned capacity over all your tables and GSIs cannot exceed either of the
 * per-account quotas.
 *
 * `DescribeLimits` should only be called periodically. You can expect
 * throttling errors if you call it more than once in a minute.
 *
 * The `DescribeLimits` Request element has no content.
 */
export declare const describeLimits: API.OperationMethod<DescribeLimitsInput, DescribeLimitsOutput, DescribeLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeTableError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the table, including the current status of the table, when
 * it was created, the primary key schema, and any indexes on the table.
 *
 * If you issue a `DescribeTable` request immediately after a
 * `CreateTable` request, DynamoDB might return a
 * `ResourceNotFoundException`. This is because
 * `DescribeTable` uses an eventually consistent query, and the metadata
 * for your table might not be available at that moment. Wait for a few seconds, and
 * then try the `DescribeTable` request again.
 */
export declare const describeTable: API.OperationMethod<DescribeTableInput, DescribeTableOutput, DescribeTableError, Credentials | HttpClient.HttpClient>;
export type DescribeTableReplicaAutoScalingError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Describes auto scaling settings across replicas of the global table at once.
 */
export declare const describeTableReplicaAutoScaling: API.OperationMethod<DescribeTableReplicaAutoScalingInput, DescribeTableReplicaAutoScalingOutput, DescribeTableReplicaAutoScalingError, Credentials | HttpClient.HttpClient>;
export type DescribeTimeToLiveError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * Gives a description of the Time to Live (TTL) status on the specified table.
 */
export declare const describeTimeToLive: API.OperationMethod<DescribeTimeToLiveInput, DescribeTimeToLiveOutput, DescribeTimeToLiveError, Credentials | HttpClient.HttpClient>;
export type DisableKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Stops replication from the DynamoDB table to the Kinesis data stream. This
 * is done without deleting either of the resources.
 */
export declare const disableKinesisStreamingDestination: API.OperationMethod<KinesisStreamingDestinationInput, KinesisStreamingDestinationOutput, DisableKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type EnableKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Starts table data replication to the specified Kinesis data stream at a timestamp
 * chosen during the enable workflow. If this operation doesn't return results immediately,
 * use DescribeKinesisStreamingDestination to check if streaming to the Kinesis data stream
 * is ACTIVE.
 */
export declare const enableKinesisStreamingDestination: API.OperationMethod<KinesisStreamingDestinationInput, KinesisStreamingDestinationOutput, EnableKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type ExecuteStatementError = ConditionalCheckFailedException | DuplicateItemException | InternalServerError | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * This operation allows you to perform reads and singleton writes on data stored in
 * DynamoDB, using PartiQL.
 *
 * For PartiQL reads (`SELECT` statement), if the total number of processed
 * items exceeds the maximum dataset size limit of 1 MB, the read stops and results are
 * returned to the user as a `LastEvaluatedKey` value to continue the read in a
 * subsequent operation. If the filter criteria in `WHERE` clause does not match
 * any data, the read will return an empty result set.
 *
 * A single `SELECT` statement response can return up to the maximum number of
 * items (if using the Limit parameter) or a maximum of 1 MB of data (and then apply any
 * filtering to the results using `WHERE` clause). If
 * `LastEvaluatedKey` is present in the response, you need to paginate the
 * result set. If `NextToken` is present, you need to paginate the result set
 * and include `NextToken`.
 */
export declare const executeStatement: API.OperationMethod<ExecuteStatementInput, ExecuteStatementOutput, ExecuteStatementError, Credentials | HttpClient.HttpClient>;
export type ExecuteTransactionError = IdempotentParameterMismatchException | InternalServerError | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionCanceledException | TransactionInProgressException | CommonErrors;
/**
 * This operation allows you to perform transactional reads or writes on data stored in
 * DynamoDB, using PartiQL.
 *
 * The entire transaction must consist of either read statements or write statements,
 * you cannot mix both in one transaction. The EXISTS function is an exception and can
 * be used to check the condition of specific attributes of the item in a similar
 * manner to `ConditionCheck` in the TransactWriteItems API.
 */
export declare const executeTransaction: API.OperationMethod<ExecuteTransactionInput, ExecuteTransactionOutput, ExecuteTransactionError, Credentials | HttpClient.HttpClient>;
export type ExportTableToPointInTimeError = ExportConflictException | InternalServerError | InvalidExportTimeException | LimitExceededException | PointInTimeRecoveryUnavailableException | TableNotFoundException | CommonErrors;
/**
 * Exports table data to an S3 bucket. The table must have point in time recovery
 * enabled, and you can export data from any time within the point in time recovery
 * window.
 */
export declare const exportTableToPointInTime: API.OperationMethod<ExportTableToPointInTimeInput, ExportTableToPointInTimeOutput, ExportTableToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type GetItemError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `GetItem` operation returns a set of attributes for the item with the
 * given primary key. If there is no matching item, `GetItem` does not return
 * any data and there will be no `Item` element in the response.
 *
 * `GetItem` provides an eventually consistent read by default. If your
 * application requires a strongly consistent read, set `ConsistentRead` to
 * `true`. Although a strongly consistent read might take more time than an
 * eventually consistent read, it always returns the last updated value.
 */
export declare const getItem: API.OperationMethod<GetItemInput, GetItemOutput, GetItemError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InternalServerError | InvalidEndpointException | PolicyNotFoundException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the resource-based policy document attached to the resource, which can be a
 * table or stream, in JSON format.
 *
 * `GetResourcePolicy` follows an
 * *eventually consistent*
 * model. The following list
 * describes the outcomes when you issue the `GetResourcePolicy` request
 * immediately after issuing another request:
 *
 * - If you issue a `GetResourcePolicy` request immediately after a
 * `PutResourcePolicy` request, DynamoDB might return a
 * `PolicyNotFoundException`.
 *
 * - If you issue a `GetResourcePolicy`request immediately after a
 * `DeleteResourcePolicy` request, DynamoDB might return
 * the policy that was present before the deletion request.
 *
 * - If you issue a `GetResourcePolicy` request immediately after a
 * `CreateTable` request, which includes a resource-based policy,
 * DynamoDB might return a `ResourceNotFoundException` or
 * a `PolicyNotFoundException`.
 *
 * Because `GetResourcePolicy` uses an eventually
 * consistent query, the metadata for your policy or table might not be
 * available at that moment. Wait for a few seconds, and then retry the
 * `GetResourcePolicy` request.
 *
 * After a `GetResourcePolicy` request returns a policy created using the
 * `PutResourcePolicy` request, the policy will be applied in the
 * authorization of requests to the resource. Because this process is eventually
 * consistent, it will take some time to apply the policy to all requests to a resource.
 * Policies that you attach while creating a table using the `CreateTable`
 * request will always be applied to all requests for that table.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyInput, GetResourcePolicyOutput, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ImportTableError = ImportConflictException | LimitExceededException | ResourceInUseException | CommonErrors;
/**
 * Imports table data from an S3 bucket.
 */
export declare const importTable: API.OperationMethod<ImportTableInput, ImportTableOutput, ImportTableError, Credentials | HttpClient.HttpClient>;
export type ListBackupsError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * List DynamoDB backups that are associated with an Amazon Web Services account and
 * weren't made with Amazon Web Services Backup. To list these backups for a given table,
 * specify `TableName`. `ListBackups` returns a paginated list of
 * results with at most 1 MB worth of items in a page. You can also specify a maximum
 * number of entries to be returned in a page.
 *
 * In the request, start time is inclusive, but end time is exclusive. Note that these
 * boundaries are for the time at which the original backup was requested.
 *
 * You can call `ListBackups` a maximum of five times per second.
 *
 * If you want to retrieve the complete list of backups made with Amazon Web Services
 * Backup, use the Amazon Web Services Backup
 * list API.
 */
export declare const listBackups: API.OperationMethod<ListBackupsInput, ListBackupsOutput, ListBackupsError, Credentials | HttpClient.HttpClient>;
export type ListContributorInsightsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of ContributorInsightsSummary for a table and all its global secondary
 * indexes.
 */
export declare const listContributorInsights: API.PaginatedOperationMethod<ListContributorInsightsInput, ListContributorInsightsOutput, ListContributorInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListExportsError = InternalServerError | LimitExceededException | CommonErrors;
/**
 * Lists completed exports within the past 90 days, in reverse alphanumeric order of `ExportArn`.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsInput, ListExportsOutput, ListExportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGlobalTablesError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Lists all global tables that have a replica in the specified Region.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const listGlobalTables: API.OperationMethod<ListGlobalTablesInput, ListGlobalTablesOutput, ListGlobalTablesError, Credentials | HttpClient.HttpClient>;
export type ListImportsError = LimitExceededException | CommonErrors;
/**
 * Lists completed imports within the past 90 days.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsInput, ListImportsOutput, ListImportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTablesError = InternalServerError | InvalidEndpointException | CommonErrors;
/**
 * Returns an array of table names associated with the current account and endpoint. The
 * output from `ListTables` is paginated, with each page returning a maximum of
 * 100 table names.
 */
export declare const listTables: API.PaginatedOperationMethod<ListTablesInput, ListTablesOutput, ListTablesError, Credentials | HttpClient.HttpClient, TableName>;
export type ListTagsOfResourceError = InternalServerError | InvalidEndpointException | ResourceNotFoundException | CommonErrors;
/**
 * List all tags on an Amazon DynamoDB resource. You can call ListTagsOfResource up to 10
 * times per second, per account.
 *
 * For an overview on tagging DynamoDB resources, see Tagging for DynamoDB
 * in the *Amazon DynamoDB Developer Guide*.
 */
export declare const listTagsOfResource: API.OperationMethod<ListTagsOfResourceInput, ListTagsOfResourceOutput, ListTagsOfResourceError, Credentials | HttpClient.HttpClient>;
export type PutItemError = ConditionalCheckFailedException | InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * Creates a new item, or replaces an old item with a new item. If an item that has the
 * same primary key as the new item already exists in the specified table, the new item
 * completely replaces the existing item. You can perform a conditional put operation (add
 * a new item if one with the specified primary key doesn't exist), or replace an existing
 * item if it has certain attribute values. You can return the item's attribute values in
 * the same operation, using the `ReturnValues` parameter.
 *
 * When you add an item, the primary key attributes are the only required attributes.
 *
 * Empty String and Binary attribute values are allowed. Attribute values of type String
 * and Binary must have a length greater than zero if the attribute is used as a key
 * attribute for a table or index. Set type attributes cannot be empty.
 *
 * Invalid Requests with empty values will be rejected with a
 * `ValidationException` exception.
 *
 * To prevent a new item from replacing an existing item, use a conditional
 * expression that contains the `attribute_not_exists` function with the
 * name of the attribute being used as the partition key for the table. Since every
 * record must contain that attribute, the `attribute_not_exists` function
 * will only succeed if no matching item exists.
 *
 * To determine whether `PutItem` overwrote an existing item, use
 * `ReturnValues` set to `ALL_OLD`. If the response includes
 * the `Attributes` element, an existing item was overwritten.
 *
 * For more information about `PutItem`, see Working with
 * Items in the *Amazon DynamoDB Developer Guide*.
 */
export declare const putItem: API.OperationMethod<PutItemInput, PutItemOutput, PutItemError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = InternalServerError | InvalidEndpointException | LimitExceededException | PolicyNotFoundException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Attaches a resource-based policy document to the resource, which can be a table or
 * stream. When you attach a resource-based policy using this API, the policy application
 * is
 * *eventually consistent*
 * .
 *
 * `PutResourcePolicy` is an idempotent operation; running it multiple times
 * on the same resource using the same policy document will return the same revision ID. If
 * you specify an `ExpectedRevisionId` that doesn't match the current policy's
 * `RevisionId`, the `PolicyNotFoundException` will be
 * returned.
 *
 * `PutResourcePolicy` is an asynchronous operation. If you issue a
 * `GetResourcePolicy` request immediately after a
 * `PutResourcePolicy` request, DynamoDB might return your
 * previous policy, if there was one, or return the
 * `PolicyNotFoundException`. This is because
 * `GetResourcePolicy` uses an eventually consistent query, and the
 * metadata for your policy or table might not be available at that moment. Wait for a
 * few seconds, and then try the `GetResourcePolicy` request again.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyInput, PutResourcePolicyOutput, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type QueryError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * You must provide the name of the partition key attribute and a single value for that
 * attribute. `Query` returns all items with that partition key value.
 * Optionally, you can provide a sort key attribute and use a comparison operator to refine
 * the search results.
 *
 * Use the `KeyConditionExpression` parameter to provide a specific value for
 * the partition key. The `Query` operation will return all of the items from
 * the table or index with that partition key value. You can optionally narrow the scope of
 * the `Query` operation by specifying a sort key value and a comparison
 * operator in `KeyConditionExpression`. To further refine the
 * `Query` results, you can optionally provide a
 * `FilterExpression`. A `FilterExpression` determines which
 * items within the results should be returned to you. All of the other results are
 * discarded.
 *
 * A `Query` operation always returns a result set. If no matching items are
 * found, the result set will be empty. Queries that do not return results consume the
 * minimum number of read capacity units for that type of read operation.
 *
 * DynamoDB calculates the number of read capacity units consumed based on item
 * size, not on the amount of data that is returned to an application. The number of
 * capacity units consumed will be the same whether you request all of the attributes
 * (the default behavior) or just some of them (using a projection expression). The
 * number will also be the same whether or not you use a `FilterExpression`.
 *
 * `Query` results are always sorted by the sort key value. If the data type of
 * the sort key is Number, the results are returned in numeric order; otherwise, the
 * results are returned in order of UTF-8 bytes. By default, the sort order is ascending.
 * To reverse the order, set the `ScanIndexForward` parameter to false.
 *
 * A single `Query` operation will read up to the maximum number of items set
 * (if using the `Limit` parameter) or a maximum of 1 MB of data and then apply
 * any filtering to the results using `FilterExpression`. If
 * `LastEvaluatedKey` is present in the response, you will need to paginate
 * the result set. For more information, see Paginating
 * the Results in the *Amazon DynamoDB Developer Guide*.
 *
 * `FilterExpression` is applied after a `Query` finishes, but before
 * the results are returned. A `FilterExpression` cannot contain partition key
 * or sort key attributes. You need to specify those attributes in the
 * `KeyConditionExpression`.
 *
 * A `Query` operation can return an empty result set and a
 * `LastEvaluatedKey` if all the items read for the page of results are
 * filtered out.
 *
 * You can query a table, a local secondary index, or a global secondary index. For a
 * query on a table or on a local secondary index, you can set the
 * `ConsistentRead` parameter to `true` and obtain a strongly
 * consistent result. Global secondary indexes support eventually consistent reads only, so
 * do not specify `ConsistentRead` when querying a global secondary
 * index.
 */
export declare const query: API.PaginatedOperationMethod<QueryInput, QueryOutput, QueryError, Credentials | HttpClient.HttpClient, {
    [key: string]: AttributeValue | undefined;
}>;
export type RestoreTableFromBackupError = BackupInUseException | BackupNotFoundException | InternalServerError | InvalidEndpointException | LimitExceededException | TableAlreadyExistsException | TableInUseException | CommonErrors;
/**
 * Creates a new table from an existing backup. Any number of users can execute up to 50
 * concurrent restores (any type of restore) in a given account.
 *
 * You can call `RestoreTableFromBackup` at a maximum rate of 10 times per
 * second.
 *
 * You must manually set up the following on the restored table:
 *
 * - Auto scaling policies
 *
 * - IAM policies
 *
 * - Amazon CloudWatch metrics and alarms
 *
 * - Tags
 *
 * - Stream settings
 *
 * - Time to Live (TTL) settings
 */
export declare const restoreTableFromBackup: API.OperationMethod<RestoreTableFromBackupInput, RestoreTableFromBackupOutput, RestoreTableFromBackupError, Credentials | HttpClient.HttpClient>;
export type RestoreTableToPointInTimeError = InternalServerError | InvalidEndpointException | InvalidRestoreTimeException | LimitExceededException | PointInTimeRecoveryUnavailableException | TableAlreadyExistsException | TableInUseException | TableNotFoundException | CommonErrors;
/**
 * Restores the specified table to the specified point in time within
 * `EarliestRestorableDateTime` and `LatestRestorableDateTime`.
 * You can restore your table to any point in time in the last 35 days. You can set the
 * recovery period to any value between 1 and 35 days. Any number of users can execute up
 * to 50 concurrent restores (any type of restore) in a given account.
 *
 * When you restore using point in time recovery, DynamoDB restores your table data to
 * the state based on the selected date and time (day:hour:minute:second) to a new table.
 *
 * Along with data, the following are also included on the new restored table using point
 * in time recovery:
 *
 * - Global secondary indexes (GSIs)
 *
 * - Local secondary indexes (LSIs)
 *
 * - Provisioned read and write capacity
 *
 * - Encryption settings
 *
 * All these settings come from the current settings of the source table at
 * the time of restore.
 *
 * You must manually set up the following on the restored table:
 *
 * - Auto scaling policies
 *
 * - IAM policies
 *
 * - Amazon CloudWatch metrics and alarms
 *
 * - Tags
 *
 * - Stream settings
 *
 * - Time to Live (TTL) settings
 *
 * - Point in time recovery settings
 */
export declare const restoreTableToPointInTime: API.OperationMethod<RestoreTableToPointInTimeInput, RestoreTableToPointInTimeOutput, RestoreTableToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type ScanError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * The `Scan` operation returns one or more items and item attributes by
 * accessing every item in a table or a secondary index. To have DynamoDB return fewer
 * items, you can provide a `FilterExpression` operation.
 *
 * If the total size of scanned items exceeds the maximum dataset size limit of 1 MB, the
 * scan completes and results are returned to the user. The `LastEvaluatedKey`
 * value is also returned and the requestor can use the `LastEvaluatedKey` to
 * continue the scan in a subsequent operation. Each scan response also includes number of
 * items that were scanned (ScannedCount) as part of the request. If using a
 * `FilterExpression`, a scan result can result in no items meeting the
 * criteria and the `Count` will result in zero. If you did not use a
 * `FilterExpression` in the scan request, then `Count` is the
 * same as `ScannedCount`.
 *
 * `Count` and `ScannedCount` only return the count of items
 * specific to a single scan request and, unless the table is less than 1MB, do not
 * represent the total number of items in the table.
 *
 * A single `Scan` operation first reads up to the maximum number of items set
 * (if using the `Limit` parameter) or a maximum of 1 MB of data and then
 * applies any filtering to the results if a `FilterExpression` is provided. If
 * `LastEvaluatedKey` is present in the response, pagination is required to
 * complete the full table scan. For more information, see Paginating the
 * Results in the *Amazon DynamoDB Developer Guide*.
 *
 * `Scan` operations proceed sequentially; however, for faster performance on
 * a large table or secondary index, applications can request a parallel `Scan`
 * operation by providing the `Segment` and `TotalSegments`
 * parameters. For more information, see Parallel
 * Scan in the *Amazon DynamoDB Developer Guide*.
 *
 * By default, a `Scan` uses eventually consistent reads when accessing the
 * items in a table. Therefore, the results from an eventually consistent `Scan`
 * may not include the latest item changes at the time the scan iterates through each item
 * in the table. If you require a strongly consistent read of each item as the scan
 * iterates through the items in the table, you can set the `ConsistentRead`
 * parameter to true. Strong consistency only relates to the consistency of the read at the
 * item level.
 *
 * DynamoDB does not provide snapshot isolation for a scan operation when the
 * `ConsistentRead` parameter is set to true. Thus, a DynamoDB scan
 * operation does not guarantee that all reads in a scan see a consistent snapshot of
 * the table when the scan operation was requested.
 */
export declare const scan: API.PaginatedOperationMethod<ScanInput, ScanOutput, ScanError, Credentials | HttpClient.HttpClient, {
    [key: string]: AttributeValue | undefined;
}>;
export type SearchVectorsError = InternalServerError | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Performs a vector similarity search on a vector index associated with an Amazon
 * DynamoDB table, and returns the most similar items sorted by similarity score
 * based on the distance function configured for the index.
 *
 * Score interpretation depends on the distance function:
 *
 * - `COSINE` - Returns the items with the k
 * smallest scores. Scores range from 0 (identical) to 2 (opposite).
 * Lower scores indicate higher similarity.
 *
 * - `EUCLIDEAN` - Returns the items with the k
 * smallest scores. Scores represent the Euclidean distance between
 * vectors. Lower scores indicate higher similarity.
 *
 * - `DOT_PRODUCT` - Returns the items with the k
 * highest scores. Higher scores indicate higher similarity.
 */
export declare const searchVectors: API.OperationMethod<SearchVectorsInput, SearchVectorsOutput, SearchVectorsError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Associate a set of tags with an Amazon DynamoDB resource. You can then activate these
 * user-defined tags so that they appear on the Billing and Cost Management console for
 * cost allocation tracking. You can call TagResource up to five times per second, per
 * account.
 *
 * - `TagResource` is an asynchronous operation. If you issue a ListTagsOfResource request immediately after a
 * `TagResource` request, DynamoDB might return your
 * previous tag set, if there was one, or an empty tag set. This is because
 * `ListTagsOfResource` uses an eventually consistent query, and the
 * metadata for your tags or table might not be available at that moment. Wait for
 * a few seconds, and then try the `ListTagsOfResource` request
 * again.
 *
 * - The application or removal of tags using `TagResource` and
 * `UntagResource` APIs is eventually consistent.
 * `ListTagsOfResource` API will only reflect the changes after a
 * few seconds.
 *
 * For an overview on tagging DynamoDB resources, see Tagging for DynamoDB
 * in the *Amazon DynamoDB Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TransactGetItemsError = InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionCanceledException | CommonErrors;
/**
 * `TransactGetItems` is a synchronous operation that atomically retrieves
 * multiple items from one or more tables (but not from indexes) in a single account and
 * Region. A `TransactGetItems` call can contain up to 100
 * `TransactGetItem` objects, each of which contains a `Get`
 * structure that specifies an item to retrieve from a table in the account and Region. A
 * call to `TransactGetItems` cannot retrieve items from tables in more than one
 * Amazon Web Services account or Region. The aggregate size of the items in the
 * transaction cannot exceed 4 MB.
 *
 * DynamoDB rejects the entire `TransactGetItems` request if any of
 * the following is true:
 *
 * - A conflicting operation is in the process of updating an item to be
 * read.
 *
 * - There is insufficient provisioned capacity for the transaction to be
 * completed.
 *
 * - There is a user error, such as an invalid data format.
 *
 * - The aggregate size of the items in the transaction exceeded 4 MB.
 */
export declare const transactGetItems: API.OperationMethod<TransactGetItemsInput, TransactGetItemsOutput, TransactGetItemsError, Credentials | HttpClient.HttpClient>;
export type TransactWriteItemsError = IdempotentParameterMismatchException | InternalServerError | InvalidEndpointException | ProvisionedThroughputExceededException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionCanceledException | TransactionInProgressException | CommonErrors;
/**
 * `TransactWriteItems` is a synchronous write operation that groups up to 100
 * action requests. These actions can target items in different tables, but not in
 * different Amazon Web Services accounts or Regions, and no two actions can target the same
 * item. For example, you cannot both `ConditionCheck` and `Update`
 * the same item. The aggregate size of the items in the transaction cannot exceed 4
 * MB.
 *
 * The actions are completed atomically so that either all of them succeed, or all of
 * them fail. They are defined by the following objects:
 *
 * - `Put`  —   Initiates a `PutItem`
 * operation to write a new item. This structure specifies the primary key of the
 * item to be written, the name of the table to write it in, an optional condition
 * expression that must be satisfied for the write to succeed, a list of the item's
 * attributes, and a field indicating whether to retrieve the item's attributes if
 * the condition is not met.
 *
 * - `Update`  —   Initiates an `UpdateItem`
 * operation to update an existing item. This structure specifies the primary key
 * of the item to be updated, the name of the table where it resides, an optional
 * condition expression that must be satisfied for the update to succeed, an
 * expression that defines one or more attributes to be updated, and a field
 * indicating whether to retrieve the item's attributes if the condition is not
 * met.
 *
 * - `Delete`  —   Initiates a `DeleteItem`
 * operation to delete an existing item. This structure specifies the primary key
 * of the item to be deleted, the name of the table where it resides, an optional
 * condition expression that must be satisfied for the deletion to succeed, and a
 * field indicating whether to retrieve the item's attributes if the condition is
 * not met.
 *
 * - `ConditionCheck`  —   Applies a condition to an item
 * that is not being modified by the transaction. This structure specifies the
 * primary key of the item to be checked, the name of the table where it resides, a
 * condition expression that must be satisfied for the transaction to succeed, and
 * a field indicating whether to retrieve the item's attributes if the condition is
 * not met.
 *
 * DynamoDB rejects the entire `TransactWriteItems` request if any of the
 * following is true:
 *
 * - A condition in one of the condition expressions is not met.
 *
 * - An ongoing operation is in the process of updating the same item.
 *
 * - There is insufficient provisioned capacity for the transaction to be
 * completed.
 *
 * - An item size becomes too large (bigger than 400 KB), a local secondary index
 * (LSI) becomes too large, or a similar validation error occurs because of changes
 * made by the transaction.
 *
 * - The aggregate size of the items in the transaction exceeds 4 MB.
 *
 * - There is a user error, such as an invalid data format.
 */
export declare const transactWriteItems: API.OperationMethod<TransactWriteItemsInput, TransactWriteItemsOutput, TransactWriteItemsError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the association of tags from an Amazon DynamoDB resource. You can call
 * `UntagResource` up to five times per second, per account.
 *
 * - `UntagResource` is an asynchronous operation. If you issue a ListTagsOfResource request immediately after an
 * `UntagResource` request, DynamoDB might return your
 * previous tag set, if there was one, or an empty tag set. This is because
 * `ListTagsOfResource` uses an eventually consistent query, and the
 * metadata for your tags or table might not be available at that moment. Wait for
 * a few seconds, and then try the `ListTagsOfResource` request
 * again.
 *
 * - The application or removal of tags using `TagResource` and
 * `UntagResource` APIs is eventually consistent.
 * `ListTagsOfResource` API will only reflect the changes after a
 * few seconds.
 *
 * For an overview on tagging DynamoDB resources, see Tagging for DynamoDB
 * in the *Amazon DynamoDB Developer Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateContinuousBackupsError = ContinuousBackupsUnavailableException | InternalServerError | InvalidEndpointException | TableNotFoundException | CommonErrors;
/**
 * `UpdateContinuousBackups` enables or disables point in time recovery for
 * the specified table. A successful `UpdateContinuousBackups` call returns the
 * current `ContinuousBackupsDescription`. Continuous backups are
 * `ENABLED` on all tables at table creation. If point in time recovery is
 * enabled, `PointInTimeRecoveryStatus` will be set to ENABLED.
 *
 * Once continuous backups and point in time recovery are enabled, you can restore to
 * any point in time within `EarliestRestorableDateTime` and
 * `LatestRestorableDateTime`.
 *
 * `LatestRestorableDateTime` is typically 5 minutes before the current time.
 * You can restore your table to any point in time in the last 35 days. You can set the
 * `RecoveryPeriodInDays` to any value between 1 and 35 days.
 */
export declare const updateContinuousBackups: API.OperationMethod<UpdateContinuousBackupsInput, UpdateContinuousBackupsOutput, UpdateContinuousBackupsError, Credentials | HttpClient.HttpClient>;
export type UpdateContributorInsightsError = InternalServerError | ResourceNotFoundException | CommonErrors;
/**
 * Updates the status for contributor insights for a specific table or index. CloudWatch
 * Contributor Insights for DynamoDB graphs display the partition key and (if applicable)
 * sort key of frequently accessed items and frequently throttled items in plaintext. If
 * you require the use of Amazon Web Services Key Management Service (KMS) to encrypt this
 * table’s partition key and sort key data with an Amazon Web Services managed key or
 * customer managed key, you should not enable CloudWatch Contributor Insights for DynamoDB
 * for this table.
 */
export declare const updateContributorInsights: API.OperationMethod<UpdateContributorInsightsInput, UpdateContributorInsightsOutput, UpdateContributorInsightsError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalTableError = GlobalTableNotFoundException | InternalServerError | InvalidEndpointException | ReplicaAlreadyExistsException | ReplicaNotFoundException | TableNotFoundException | CommonErrors;
/**
 * Adds or removes replicas in the specified global table. The global table must already
 * exist to be able to use this operation. Any replica to be added must be empty, have the
 * same name as the global table, have the same key schema, have DynamoDB Streams enabled,
 * and have the same provisioned and maximum write capacity units.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 *
 * If you are using global tables Version
 * 2019.11.21 (Current) you can use UpdateTable instead.
 *
 * Although you can use `UpdateGlobalTable` to add replicas and remove
 * replicas in a single request, for simplicity we recommend that you issue separate
 * requests for adding or removing replicas.
 *
 * If global secondary indexes are specified, then the following conditions must also be
 * met:
 *
 * - The global secondary indexes must have the same name.
 *
 * - The global secondary indexes must have the same hash key and sort key (if
 * present).
 *
 * - The global secondary indexes must have the same provisioned and maximum write
 * capacity units.
 */
export declare const updateGlobalTable: API.OperationMethod<UpdateGlobalTableInput, UpdateGlobalTableOutput, UpdateGlobalTableError, Credentials | HttpClient.HttpClient>;
export type UpdateGlobalTableSettingsError = GlobalTableNotFoundException | IndexNotFoundException | InternalServerError | InvalidEndpointException | LimitExceededException | ReplicaNotFoundException | ResourceInUseException | CommonErrors;
/**
 * Updates settings for a global table.
 *
 * This documentation is for version 2017.11.29 (Legacy) of global tables, which should be avoided for new global tables. Customers should use Global Tables version 2019.11.21 (Current) when possible, because it provides greater flexibility, higher efficiency, and consumes less write capacity than 2017.11.29 (Legacy).
 *
 * To determine which version you're using, see Determining the global table version you are using. To update existing global tables from version 2017.11.29 (Legacy) to version 2019.11.21 (Current), see Upgrading global tables.
 */
export declare const updateGlobalTableSettings: API.OperationMethod<UpdateGlobalTableSettingsInput, UpdateGlobalTableSettingsOutput, UpdateGlobalTableSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateItemError = ConditionalCheckFailedException | InternalServerError | InvalidEndpointException | ItemCollectionSizeLimitExceededException | ProvisionedThroughputExceededException | ReplicatedWriteConflictException | RequestLimitExceeded | ResourceNotFoundException | ThrottlingException | TransactionConflictException | CommonErrors;
/**
 * Edits an existing item's attributes, or adds a new item to the table if it does not
 * already exist. You can put, delete, or add attribute values. You can also perform a
 * conditional update on an existing item (insert a new attribute name-value pair if it
 * doesn't exist, or replace an existing name-value pair if it has certain expected
 * attribute values).
 *
 * You can also return the item's attribute values in the same `UpdateItem`
 * operation using the `ReturnValues` parameter.
 */
export declare const updateItem: API.OperationMethod<UpdateItemInput, UpdateItemOutput, UpdateItemError, Credentials | HttpClient.HttpClient>;
export type UpdateKinesisStreamingDestinationError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * The command to update the Kinesis stream destination.
 */
export declare const updateKinesisStreamingDestination: API.OperationMethod<UpdateKinesisStreamingDestinationInput, UpdateKinesisStreamingDestinationOutput, UpdateKinesisStreamingDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateTableError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Modifies the provisioned throughput settings, global secondary indexes, or DynamoDB
 * Streams settings for a given table.
 *
 * You can only perform one of the following operations at once:
 *
 * - Modify the provisioned throughput settings of the table.
 *
 * - Remove a global secondary index from the table.
 *
 * - Create a new global secondary index on the table. After the index begins
 * backfilling, you can use `UpdateTable` to perform other
 * operations.
 *
 * `UpdateTable` is an asynchronous operation; while it's executing, the table
 * status changes from `ACTIVE` to `UPDATING`. While it's
 * `UPDATING`, you can't issue another `UpdateTable` request.
 * When the table returns to the `ACTIVE` state, the `UpdateTable`
 * operation is complete.
 */
export declare const updateTable: API.OperationMethod<UpdateTableInput, UpdateTableOutput, UpdateTableError, Credentials | HttpClient.HttpClient>;
export type UpdateTableReplicaAutoScalingError = InternalServerError | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates auto scaling settings on your global tables at once.
 */
export declare const updateTableReplicaAutoScaling: API.OperationMethod<UpdateTableReplicaAutoScalingInput, UpdateTableReplicaAutoScalingOutput, UpdateTableReplicaAutoScalingError, Credentials | HttpClient.HttpClient>;
export type UpdateTimeToLiveError = InternalServerError | InvalidEndpointException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * The `UpdateTimeToLive` method enables or disables Time to Live (TTL) for
 * the specified table. A successful `UpdateTimeToLive` call returns the current
 * `TimeToLiveSpecification`. It can take up to one hour for the change to
 * fully process. Any additional `UpdateTimeToLive` calls for the same table
 * during this one hour duration result in a `ValidationException`.
 *
 * TTL compares the current time in epoch time format to the time stored in the TTL
 * attribute of an item. If the epoch time value stored in the attribute is less than the
 * current time, the item is marked as expired and subsequently deleted.
 *
 * The epoch time format is the number of seconds elapsed since 12:00:00 AM January
 * 1, 1970 UTC.
 *
 * DynamoDB deletes expired items on a best-effort basis to ensure availability of
 * throughput for other data operations.
 *
 * DynamoDB typically deletes expired items within two days of expiration. The exact
 * duration within which an item gets deleted after expiration is specific to the
 * nature of the workload. Items that have expired and not been deleted will still show
 * up in reads, queries, and scans.
 *
 * As items are deleted, they are removed from any local secondary index and global
 * secondary index immediately in the same eventually consistent way as a standard delete
 * operation.
 *
 * For more information, see Time To Live in the
 * Amazon DynamoDB Developer Guide.
 */
export declare const updateTimeToLive: API.OperationMethod<UpdateTimeToLiveInput, UpdateTimeToLiveOutput, UpdateTimeToLiveError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dynamodb.d.ts.map