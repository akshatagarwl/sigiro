import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.Class<InvalidRequestException, S.TaggedStruct<"InvalidRequestException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.Class<LimitExceededException, S.TaggedStruct<"LimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.Class<ResourceAlreadyExistsException, S.TaggedStruct<"ResourceAlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type EnvironmentName = string;
export type Description = string;
export type KmsKeyId = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export type FederationMode = "FEDERATED" | "LOCAL" | (string & {});
export declare const FederationMode: any;
export type SamlMetadataDocument = string;
export type Url = string;
export type Urn = string;
export type FederationProviderName = string;
export type FederationAttributeKey = string;
export type FederationAttributeValue = string;
export type AttributeMap = {
    [key: string]: string | undefined;
};
export declare const AttributeMap: any;
export interface FederationParameters {
    samlMetadataDocument?: string;
    samlMetadataURL?: string;
    applicationCallBackURL?: string;
    federationURN?: string;
    federationProviderName?: string;
    attributeMap?: {
        [key: string]: string | undefined;
    };
}
export declare const FederationParameters: S.Schema<FederationParameters>;
export type EmailId = string | redacted.Redacted<string>;
export type NameString = string;
export interface SuperuserParameters {
    emailAddress: string | redacted.Redacted<string>;
    firstName: string;
    lastName: string;
}
export declare const SuperuserParameters: S.Schema<SuperuserParameters>;
export type DataBundleArn = string;
export type DataBundleArns = string[];
export declare const DataBundleArns: any;
export interface CreateEnvironmentRequest {
    name: string;
    description?: string;
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    federationMode?: FederationMode;
    federationParameters?: FederationParameters;
    superuserParameters?: SuperuserParameters;
    dataBundles?: string[];
}
export declare const CreateEnvironmentRequest: S.Schema<CreateEnvironmentRequest>;
export type IdType = string;
export type EnvironmentArn = string;
export interface CreateEnvironmentResponse {
    environmentId?: string;
    environmentArn?: string;
    environmentUrl?: string;
}
export declare const CreateEnvironmentResponse: S.Schema<CreateEnvironmentResponse>;
export type EnvironmentId = string;
export type DatabaseName = string;
export type ChangeType = "PUT" | "DELETE" | (string & {});
export declare const ChangeType: any;
export type S3Path = string;
export type DbPath = string;
export interface ChangeRequest {
    changeType: ChangeType;
    s3Path?: string;
    dbPath: string;
}
export declare const ChangeRequest: S.Schema<ChangeRequest>;
export type ChangeRequests = ChangeRequest[];
export declare const ChangeRequests: any;
export type ClientTokenString = string;
export interface CreateKxChangesetRequest {
    environmentId: string;
    databaseName: string;
    changeRequests: ChangeRequest[];
    clientToken: string;
}
export declare const CreateKxChangesetRequest: S.Schema<CreateKxChangesetRequest>;
export type ChangesetId = string;
export type ChangesetStatus = "PENDING" | "PROCESSING" | "FAILED" | "COMPLETED" | (string & {});
export declare const ChangesetStatus: any;
export type ErrorMessage = string;
export type ErrorDetails = "The inputs to this request are invalid." | "Service limits have been exceeded." | "Missing required permission to perform this request." | "One or more inputs to this request were not found." | "The system temporarily lacks sufficient resources to process the request." | "An internal error has occurred." | "Cancelled" | "A user recoverable error has occurred" | (string & {});
export declare const ErrorDetails: any;
export interface ErrorInfo {
    errorMessage?: string;
    errorType?: ErrorDetails;
}
export declare const ErrorInfo: S.Schema<ErrorInfo>;
export interface CreateKxChangesetResponse {
    changesetId?: string;
    databaseName?: string;
    environmentId?: string;
    changeRequests?: ChangeRequest[];
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
    status?: ChangesetStatus;
    errorInfo?: ErrorInfo;
}
export declare const CreateKxChangesetResponse: S.Schema<CreateKxChangesetResponse>;
export type ClientToken = string;
export type KxEnvironmentId = string;
export type KxClusterName = string;
export type KxClusterType = "HDB" | "RDB" | "GATEWAY" | "GP" | "TICKERPLANT" | (string & {});
export declare const KxClusterType: any;
export type VolumeName = string;
export type TickerplantLogVolumes = string[];
export declare const TickerplantLogVolumes: any;
export interface TickerplantLogConfiguration {
    tickerplantLogVolumes?: string[];
}
export declare const TickerplantLogConfiguration: S.Schema<TickerplantLogConfiguration>;
export type KxCacheStorageType = string;
export type DbPaths = string[];
export declare const DbPaths: any;
export type KxDataviewName = string;
export interface KxDatabaseCacheConfiguration {
    cacheType: string;
    dbPaths: string[];
    dataviewName?: string;
}
export declare const KxDatabaseCacheConfiguration: S.Schema<KxDatabaseCacheConfiguration>;
export type KxDatabaseCacheConfigurations = KxDatabaseCacheConfiguration[];
export declare const KxDatabaseCacheConfigurations: any;
export type VersionId = string;
export type SegmentConfigurationDbPathList = string[];
export declare const SegmentConfigurationDbPathList: any;
export type KxVolumeName = string;
export interface KxDataviewSegmentConfiguration {
    dbPaths: string[];
    volumeName: string;
    onDemand?: boolean;
}
export declare const KxDataviewSegmentConfiguration: S.Schema<KxDataviewSegmentConfiguration>;
export type KxDataviewSegmentConfigurationList = KxDataviewSegmentConfiguration[];
export declare const KxDataviewSegmentConfigurationList: any;
export interface KxDataviewConfiguration {
    dataviewName?: string;
    dataviewVersionId?: string;
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
}
export declare const KxDataviewConfiguration: S.Schema<KxDataviewConfiguration>;
export interface KxDatabaseConfiguration {
    databaseName: string;
    cacheConfigurations?: KxDatabaseCacheConfiguration[];
    changesetId?: string;
    dataviewName?: string;
    dataviewConfiguration?: KxDataviewConfiguration;
}
export declare const KxDatabaseConfiguration: S.Schema<KxDatabaseConfiguration>;
export type KxDatabaseConfigurations = KxDatabaseConfiguration[];
export declare const KxDatabaseConfigurations: any;
export type KxCacheStorageSize = number;
export interface KxCacheStorageConfiguration {
    type: string;
    size: number;
}
export declare const KxCacheStorageConfiguration: S.Schema<KxCacheStorageConfiguration>;
export type KxCacheStorageConfigurations = KxCacheStorageConfiguration[];
export declare const KxCacheStorageConfigurations: any;
export type NodeCount = number;
export type AutoScalingMetric = "CPU_UTILIZATION_PERCENTAGE" | (string & {});
export declare const AutoScalingMetric: any;
export type AutoScalingMetricTarget = number;
export type CooldownTime = number;
export interface AutoScalingConfiguration {
    minNodeCount?: number;
    maxNodeCount?: number;
    autoScalingMetric?: AutoScalingMetric;
    metricTarget?: number;
    scaleInCooldownSeconds?: number;
    scaleOutCooldownSeconds?: number;
}
export declare const AutoScalingConfiguration: S.Schema<AutoScalingConfiguration>;
export type KxClusterDescription = string;
export type NodeType = string;
export interface CapacityConfiguration {
    nodeType?: string;
    nodeCount?: number;
}
export declare const CapacityConfiguration: S.Schema<CapacityConfiguration>;
export type ReleaseLabel = string;
export type VpcIdString = string;
export type SecurityGroupIdString = string;
export type SecurityGroupIdList = string[];
export declare const SecurityGroupIdList: any;
export type SubnetIdString = string;
export type SubnetIdList = string[];
export declare const SubnetIdList: any;
export type IPAddressType = "IP_V4" | (string & {});
export declare const IPAddressType: any;
export interface VpcConfiguration {
    vpcId?: string;
    securityGroupIds?: string[];
    subnetIds?: string[];
    ipAddressType?: IPAddressType;
}
export declare const VpcConfiguration: S.Schema<VpcConfiguration>;
export type InitializationScriptFilePath = string;
export type KxCommandLineArgumentKey = string;
export type KxCommandLineArgumentValue = string;
export interface KxCommandLineArgument {
    key?: string;
    value?: string;
}
export declare const KxCommandLineArgument: S.Schema<KxCommandLineArgument>;
export type KxCommandLineArguments = KxCommandLineArgument[];
export declare const KxCommandLineArguments: any;
export type S3Bucket = string;
export type S3Key = string;
export type S3ObjectVersion = string;
export interface CodeConfiguration {
    s3Bucket?: string;
    s3Key?: string;
    s3ObjectVersion?: string;
}
export declare const CodeConfiguration: S.Schema<CodeConfiguration>;
export type ExecutionRoleArn = string;
export type KxSavedownStorageType = "SDS01" | (string & {});
export declare const KxSavedownStorageType: any;
export type KxSavedownStorageSize = number;
export interface KxSavedownStorageConfiguration {
    type?: KxSavedownStorageType;
    size?: number;
    volumeName?: string;
}
export declare const KxSavedownStorageConfiguration: S.Schema<KxSavedownStorageConfiguration>;
export type KxAzMode = "SINGLE" | "MULTI" | (string & {});
export declare const KxAzMode: any;
export type AvailabilityZoneId = string;
export type KxScalingGroupName = string;
export type MemoryMib = number;
export type ClusterNodeCount = number;
export type CpuCount = number;
export interface KxScalingGroupConfiguration {
    scalingGroupName: string;
    memoryLimit?: number;
    memoryReservation: number;
    nodeCount: number;
    cpu?: number;
}
export declare const KxScalingGroupConfiguration: S.Schema<KxScalingGroupConfiguration>;
export interface CreateKxClusterRequest {
    clientToken?: string;
    environmentId: string;
    clusterName: string;
    clusterType: KxClusterType;
    tickerplantLogConfiguration?: TickerplantLogConfiguration;
    databases?: KxDatabaseConfiguration[];
    cacheStorageConfigurations?: KxCacheStorageConfiguration[];
    autoScalingConfiguration?: AutoScalingConfiguration;
    clusterDescription?: string;
    capacityConfiguration?: CapacityConfiguration;
    releaseLabel: string;
    vpcConfiguration: VpcConfiguration;
    initializationScript?: string;
    commandLineArguments?: KxCommandLineArgument[];
    code?: CodeConfiguration;
    executionRole?: string;
    savedownStorageConfiguration?: KxSavedownStorageConfiguration;
    azMode: KxAzMode;
    availabilityZoneId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    scalingGroupConfiguration?: KxScalingGroupConfiguration;
}
export declare const CreateKxClusterRequest: S.Schema<CreateKxClusterRequest>;
export type KxClusterStatus = "PENDING" | "CREATING" | "CREATE_FAILED" | "RUNNING" | "UPDATING" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export declare const KxClusterStatus: any;
export type KxClusterStatusReason = string;
export type VolumeType = "NAS_1" | (string & {});
export declare const VolumeType: any;
export interface Volume {
    volumeName?: string;
    volumeType?: VolumeType;
}
export declare const Volume: S.Schema<Volume>;
export type Volumes = Volume[];
export declare const Volumes: any;
export interface CreateKxClusterResponse {
    environmentId?: string;
    status?: KxClusterStatus;
    statusReason?: string;
    clusterName?: string;
    clusterType?: KxClusterType;
    tickerplantLogConfiguration?: TickerplantLogConfiguration;
    volumes?: Volume[];
    databases?: KxDatabaseConfiguration[];
    cacheStorageConfigurations?: KxCacheStorageConfiguration[];
    autoScalingConfiguration?: AutoScalingConfiguration;
    clusterDescription?: string;
    capacityConfiguration?: CapacityConfiguration;
    releaseLabel?: string;
    vpcConfiguration?: VpcConfiguration;
    initializationScript?: string;
    commandLineArguments?: KxCommandLineArgument[];
    code?: CodeConfiguration;
    executionRole?: string;
    lastModifiedTimestamp?: Date;
    savedownStorageConfiguration?: KxSavedownStorageConfiguration;
    azMode?: KxAzMode;
    availabilityZoneId?: string;
    createdTimestamp?: Date;
    scalingGroupConfiguration?: KxScalingGroupConfiguration;
}
export declare const CreateKxClusterResponse: S.Schema<CreateKxClusterResponse>;
export interface CreateKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export declare const CreateKxDatabaseRequest: S.Schema<CreateKxDatabaseRequest>;
export type DatabaseArn = string;
export interface CreateKxDatabaseResponse {
    databaseName?: string;
    databaseArn?: string;
    environmentId?: string;
    description?: string;
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
}
export declare const CreateKxDatabaseResponse: S.Schema<CreateKxDatabaseResponse>;
export interface CreateKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
    azMode: KxAzMode;
    availabilityZoneId?: string;
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
    autoUpdate?: boolean;
    readWrite?: boolean;
    description?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken: string;
}
export declare const CreateKxDataviewRequest: S.Schema<CreateKxDataviewRequest>;
export type KxDataviewStatus = "CREATING" | "ACTIVE" | "UPDATING" | "FAILED" | "DELETING" | (string & {});
export declare const KxDataviewStatus: any;
export interface CreateKxDataviewResponse {
    dataviewName?: string;
    databaseName?: string;
    environmentId?: string;
    azMode?: KxAzMode;
    availabilityZoneId?: string;
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
    description?: string;
    autoUpdate?: boolean;
    readWrite?: boolean;
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
    status?: KxDataviewStatus;
}
export declare const CreateKxDataviewResponse: S.Schema<CreateKxDataviewResponse>;
export type KxEnvironmentName = string;
export type KmsKeyARN = string;
export interface CreateKxEnvironmentRequest {
    name: string;
    description?: string;
    kmsKeyId: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateKxEnvironmentRequest: S.Schema<CreateKxEnvironmentRequest>;
export type EnvironmentStatus = "CREATE_REQUESTED" | "CREATING" | "CREATED" | "DELETE_REQUESTED" | "DELETING" | "DELETED" | "FAILED_CREATION" | "RETRY_DELETION" | "FAILED_DELETION" | "UPDATE_NETWORK_REQUESTED" | "UPDATING_NETWORK" | "FAILED_UPDATING_NETWORK" | "SUSPENDED" | (string & {});
export declare const EnvironmentStatus: any;
export interface CreateKxEnvironmentResponse {
    name?: string;
    status?: EnvironmentStatus;
    environmentId?: string;
    description?: string;
    environmentArn?: string;
    kmsKeyId?: string;
    creationTimestamp?: Date;
}
export declare const CreateKxEnvironmentResponse: S.Schema<CreateKxEnvironmentResponse>;
export type KxHostType = string;
export interface CreateKxScalingGroupRequest {
    clientToken: string;
    environmentId: string;
    scalingGroupName: string;
    hostType: string;
    availabilityZoneId: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateKxScalingGroupRequest: S.Schema<CreateKxScalingGroupRequest>;
export type KxScalingGroupStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export declare const KxScalingGroupStatus: any;
export interface CreateKxScalingGroupResponse {
    environmentId?: string;
    scalingGroupName?: string;
    hostType?: string;
    availabilityZoneId?: string;
    status?: KxScalingGroupStatus;
    lastModifiedTimestamp?: Date;
    createdTimestamp?: Date;
}
export declare const CreateKxScalingGroupResponse: S.Schema<CreateKxScalingGroupResponse>;
export type KxUserNameString = string;
export type RoleArn = string;
export interface CreateKxUserRequest {
    environmentId: string;
    userName: string;
    iamRole: string;
    tags?: {
        [key: string]: string | undefined;
    };
    clientToken?: string;
}
export declare const CreateKxUserRequest: S.Schema<CreateKxUserRequest>;
export type KxUserArn = string;
export interface CreateKxUserResponse {
    userName?: string;
    userArn?: string;
    environmentId?: string;
    iamRole?: string;
}
export declare const CreateKxUserResponse: S.Schema<CreateKxUserResponse>;
export type KxVolumeType = "NAS_1" | (string & {});
export declare const KxVolumeType: any;
export type KxNAS1Type = "SSD_1000" | "SSD_250" | "HDD_12" | (string & {});
export declare const KxNAS1Type: any;
export type KxNAS1Size = number;
export interface KxNAS1Configuration {
    type?: KxNAS1Type;
    size?: number;
}
export declare const KxNAS1Configuration: S.Schema<KxNAS1Configuration>;
export type AvailabilityZoneIds = string[];
export declare const AvailabilityZoneIds: any;
export interface CreateKxVolumeRequest {
    clientToken?: string;
    environmentId: string;
    volumeType: KxVolumeType;
    volumeName: string;
    description?: string;
    nas1Configuration?: KxNAS1Configuration;
    azMode: KxAzMode;
    availabilityZoneIds: string[];
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateKxVolumeRequest: S.Schema<CreateKxVolumeRequest>;
export type KxVolumeArn = string;
export type KxVolumeStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATED" | "UPDATE_FAILED" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export declare const KxVolumeStatus: any;
export type KxVolumeStatusReason = string;
export interface CreateKxVolumeResponse {
    environmentId?: string;
    volumeName?: string;
    volumeType?: KxVolumeType;
    volumeArn?: string;
    nas1Configuration?: KxNAS1Configuration;
    status?: KxVolumeStatus;
    statusReason?: string;
    azMode?: KxAzMode;
    description?: string;
    availabilityZoneIds?: string[];
    createdTimestamp?: Date;
}
export declare const CreateKxVolumeResponse: S.Schema<CreateKxVolumeResponse>;
export interface DeleteEnvironmentRequest {
    environmentId: string;
}
export declare const DeleteEnvironmentRequest: S.Schema<DeleteEnvironmentRequest>;
export interface DeleteEnvironmentResponse {
}
export declare const DeleteEnvironmentResponse: S.Schema<DeleteEnvironmentResponse>;
export interface DeleteKxClusterRequest {
    environmentId: string;
    clusterName: string;
    clientToken?: string;
}
export declare const DeleteKxClusterRequest: S.Schema<DeleteKxClusterRequest>;
export interface DeleteKxClusterResponse {
}
export declare const DeleteKxClusterResponse: S.Schema<DeleteKxClusterResponse>;
export type KxClusterNodeIdString = string;
export interface DeleteKxClusterNodeRequest {
    environmentId: string;
    clusterName: string;
    nodeId: string;
}
export declare const DeleteKxClusterNodeRequest: S.Schema<DeleteKxClusterNodeRequest>;
export interface DeleteKxClusterNodeResponse {
}
export declare const DeleteKxClusterNodeResponse: S.Schema<DeleteKxClusterNodeResponse>;
export interface DeleteKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
    clientToken: string;
}
export declare const DeleteKxDatabaseRequest: S.Schema<DeleteKxDatabaseRequest>;
export interface DeleteKxDatabaseResponse {
}
export declare const DeleteKxDatabaseResponse: S.Schema<DeleteKxDatabaseResponse>;
export interface DeleteKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
    clientToken: string;
}
export declare const DeleteKxDataviewRequest: S.Schema<DeleteKxDataviewRequest>;
export interface DeleteKxDataviewResponse {
}
export declare const DeleteKxDataviewResponse: S.Schema<DeleteKxDataviewResponse>;
export interface DeleteKxEnvironmentRequest {
    environmentId: string;
    clientToken?: string;
}
export declare const DeleteKxEnvironmentRequest: S.Schema<DeleteKxEnvironmentRequest>;
export interface DeleteKxEnvironmentResponse {
}
export declare const DeleteKxEnvironmentResponse: S.Schema<DeleteKxEnvironmentResponse>;
export interface DeleteKxScalingGroupRequest {
    environmentId: string;
    scalingGroupName: string;
    clientToken?: string;
}
export declare const DeleteKxScalingGroupRequest: S.Schema<DeleteKxScalingGroupRequest>;
export interface DeleteKxScalingGroupResponse {
}
export declare const DeleteKxScalingGroupResponse: S.Schema<DeleteKxScalingGroupResponse>;
export interface DeleteKxUserRequest {
    userName: string;
    environmentId: string;
    clientToken?: string;
}
export declare const DeleteKxUserRequest: S.Schema<DeleteKxUserRequest>;
export interface DeleteKxUserResponse {
}
export declare const DeleteKxUserResponse: S.Schema<DeleteKxUserResponse>;
export interface DeleteKxVolumeRequest {
    environmentId: string;
    volumeName: string;
    clientToken?: string;
}
export declare const DeleteKxVolumeRequest: S.Schema<DeleteKxVolumeRequest>;
export interface DeleteKxVolumeResponse {
}
export declare const DeleteKxVolumeResponse: S.Schema<DeleteKxVolumeResponse>;
export interface GetEnvironmentRequest {
    environmentId: string;
}
export declare const GetEnvironmentRequest: S.Schema<GetEnvironmentRequest>;
export type SmsDomainUrl = string;
export interface Environment {
    name?: string;
    environmentId?: string;
    awsAccountId?: string;
    status?: EnvironmentStatus;
    environmentUrl?: string;
    description?: string;
    environmentArn?: string;
    sageMakerStudioDomainUrl?: string;
    kmsKeyId?: string;
    dedicatedServiceAccountId?: string;
    federationMode?: FederationMode;
    federationParameters?: FederationParameters;
}
export declare const Environment: S.Schema<Environment>;
export interface GetEnvironmentResponse {
    environment?: Environment;
}
export declare const GetEnvironmentResponse: S.Schema<GetEnvironmentResponse>;
export interface GetKxChangesetRequest {
    environmentId: string;
    databaseName: string;
    changesetId: string;
}
export declare const GetKxChangesetRequest: S.Schema<GetKxChangesetRequest>;
export interface GetKxChangesetResponse {
    changesetId?: string;
    databaseName?: string;
    environmentId?: string;
    changeRequests?: ChangeRequest[];
    createdTimestamp?: Date;
    activeFromTimestamp?: Date;
    lastModifiedTimestamp?: Date;
    status?: ChangesetStatus;
    errorInfo?: ErrorInfo;
}
export declare const GetKxChangesetResponse: S.Schema<GetKxChangesetResponse>;
export interface GetKxClusterRequest {
    environmentId: string;
    clusterName: string;
}
export declare const GetKxClusterRequest: S.Schema<GetKxClusterRequest>;
export interface GetKxClusterResponse {
    status?: KxClusterStatus;
    statusReason?: string;
    clusterName?: string;
    clusterType?: KxClusterType;
    tickerplantLogConfiguration?: TickerplantLogConfiguration;
    volumes?: Volume[];
    databases?: KxDatabaseConfiguration[];
    cacheStorageConfigurations?: KxCacheStorageConfiguration[];
    autoScalingConfiguration?: AutoScalingConfiguration;
    clusterDescription?: string;
    capacityConfiguration?: CapacityConfiguration;
    releaseLabel?: string;
    vpcConfiguration?: VpcConfiguration;
    initializationScript?: string;
    commandLineArguments?: KxCommandLineArgument[];
    code?: CodeConfiguration;
    executionRole?: string;
    lastModifiedTimestamp?: Date;
    savedownStorageConfiguration?: KxSavedownStorageConfiguration;
    azMode?: KxAzMode;
    availabilityZoneId?: string;
    createdTimestamp?: Date;
    scalingGroupConfiguration?: KxScalingGroupConfiguration;
}
export declare const GetKxClusterResponse: S.Schema<GetKxClusterResponse>;
export interface GetKxConnectionStringRequest {
    userArn: string;
    environmentId: string;
    clusterName: string;
}
export declare const GetKxConnectionStringRequest: S.Schema<GetKxConnectionStringRequest>;
export type SignedKxConnectionString = string | redacted.Redacted<string>;
export interface GetKxConnectionStringResponse {
    signedConnectionString?: string | redacted.Redacted<string>;
}
export declare const GetKxConnectionStringResponse: S.Schema<GetKxConnectionStringResponse>;
export interface GetKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
}
export declare const GetKxDatabaseRequest: S.Schema<GetKxDatabaseRequest>;
export type NumBytes = number;
export type NumChangesets = number;
export type NumFiles = number;
export interface GetKxDatabaseResponse {
    databaseName?: string;
    databaseArn?: string;
    environmentId?: string;
    description?: string;
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
    lastCompletedChangesetId?: string;
    numBytes?: number;
    numChangesets?: number;
    numFiles?: number;
}
export declare const GetKxDatabaseResponse: S.Schema<GetKxDatabaseResponse>;
export interface GetKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
}
export declare const GetKxDataviewRequest: S.Schema<GetKxDataviewRequest>;
export type AttachedClusterList = string[];
export declare const AttachedClusterList: any;
export interface KxDataviewActiveVersion {
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
    attachedClusters?: string[];
    createdTimestamp?: Date;
    versionId?: string;
}
export declare const KxDataviewActiveVersion: S.Schema<KxDataviewActiveVersion>;
export type KxDataviewActiveVersionList = KxDataviewActiveVersion[];
export declare const KxDataviewActiveVersionList: any;
export type KxDataviewStatusReason = string;
export interface GetKxDataviewResponse {
    databaseName?: string;
    dataviewName?: string;
    azMode?: KxAzMode;
    availabilityZoneId?: string;
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
    activeVersions?: KxDataviewActiveVersion[];
    description?: string;
    autoUpdate?: boolean;
    readWrite?: boolean;
    environmentId?: string;
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
    status?: KxDataviewStatus;
    statusReason?: string;
}
export declare const GetKxDataviewResponse: S.Schema<GetKxDataviewResponse>;
export interface GetKxEnvironmentRequest {
    environmentId: string;
}
export declare const GetKxEnvironmentRequest: S.Schema<GetKxEnvironmentRequest>;
export type TgwStatus = "NONE" | "UPDATE_REQUESTED" | "UPDATING" | "FAILED_UPDATE" | "SUCCESSFULLY_UPDATED" | (string & {});
export declare const TgwStatus: any;
export type DnsStatus = "NONE" | "UPDATE_REQUESTED" | "UPDATING" | "FAILED_UPDATE" | "SUCCESSFULLY_UPDATED" | (string & {});
export declare const DnsStatus: any;
export type EnvironmentErrorMessage = string;
export type TransitGatewayID = string;
export type ValidCIDRSpace = string;
export type RuleNumber = number;
export type Protocol = string;
export type RuleAction = "allow" | "deny" | (string & {});
export declare const RuleAction: any;
export type Port = number;
export interface PortRange {
    from: number;
    to: number;
}
export declare const PortRange: S.Schema<PortRange>;
export type IcmpTypeOrCode = number;
export interface IcmpTypeCode {
    type: number;
    code: number;
}
export declare const IcmpTypeCode: S.Schema<IcmpTypeCode>;
export type ValidCIDRBlock = string;
export interface NetworkACLEntry {
    ruleNumber: number;
    protocol: string;
    ruleAction: RuleAction;
    portRange?: PortRange;
    icmpTypeCode?: IcmpTypeCode;
    cidrBlock: string;
}
export declare const NetworkACLEntry: S.Schema<NetworkACLEntry>;
export type NetworkACLConfiguration = NetworkACLEntry[];
export declare const NetworkACLConfiguration: any;
export interface TransitGatewayConfiguration {
    transitGatewayID: string;
    routableCIDRSpace: string;
    attachmentNetworkAclConfiguration?: NetworkACLEntry[];
}
export declare const TransitGatewayConfiguration: S.Schema<TransitGatewayConfiguration>;
export type ValidHostname = string;
export type ValidIPAddress = string;
export interface CustomDNSServer {
    customDNSServerName: string;
    customDNSServerIP: string;
}
export declare const CustomDNSServer: S.Schema<CustomDNSServer>;
export type CustomDNSConfiguration = CustomDNSServer[];
export declare const CustomDNSConfiguration: any;
export type StringValueLength1to255 = string;
export interface GetKxEnvironmentResponse {
    name?: string;
    environmentId?: string;
    awsAccountId?: string;
    status?: EnvironmentStatus;
    tgwStatus?: TgwStatus;
    dnsStatus?: DnsStatus;
    errorMessage?: string;
    description?: string;
    environmentArn?: string;
    kmsKeyId?: string;
    dedicatedServiceAccountId?: string;
    transitGatewayConfiguration?: TransitGatewayConfiguration;
    customDNSConfiguration?: CustomDNSServer[];
    creationTimestamp?: Date;
    updateTimestamp?: Date;
    availabilityZoneIds?: string[];
    certificateAuthorityArn?: string;
}
export declare const GetKxEnvironmentResponse: S.Schema<GetKxEnvironmentResponse>;
export interface GetKxScalingGroupRequest {
    environmentId: string;
    scalingGroupName: string;
}
export declare const GetKxScalingGroupRequest: S.Schema<GetKxScalingGroupRequest>;
export type Arn = string;
export type KxClusterNameList = string[];
export declare const KxClusterNameList: any;
export interface GetKxScalingGroupResponse {
    scalingGroupName?: string;
    scalingGroupArn?: string;
    hostType?: string;
    clusters?: string[];
    availabilityZoneId?: string;
    status?: KxScalingGroupStatus;
    statusReason?: string;
    lastModifiedTimestamp?: Date;
    createdTimestamp?: Date;
}
export declare const GetKxScalingGroupResponse: S.Schema<GetKxScalingGroupResponse>;
export interface GetKxUserRequest {
    userName: string;
    environmentId: string;
}
export declare const GetKxUserRequest: S.Schema<GetKxUserRequest>;
export interface GetKxUserResponse {
    userName?: string;
    userArn?: string;
    environmentId?: string;
    iamRole?: string;
}
export declare const GetKxUserResponse: S.Schema<GetKxUserResponse>;
export interface GetKxVolumeRequest {
    environmentId: string;
    volumeName: string;
}
export declare const GetKxVolumeRequest: S.Schema<GetKxVolumeRequest>;
export interface KxAttachedCluster {
    clusterName?: string;
    clusterType?: KxClusterType;
    clusterStatus?: KxClusterStatus;
}
export declare const KxAttachedCluster: S.Schema<KxAttachedCluster>;
export type KxAttachedClusters = KxAttachedCluster[];
export declare const KxAttachedClusters: any;
export interface GetKxVolumeResponse {
    environmentId?: string;
    volumeName?: string;
    volumeType?: KxVolumeType;
    volumeArn?: string;
    nas1Configuration?: KxNAS1Configuration;
    status?: KxVolumeStatus;
    statusReason?: string;
    createdTimestamp?: Date;
    description?: string;
    azMode?: KxAzMode;
    availabilityZoneIds?: string[];
    lastModifiedTimestamp?: Date;
    attachedClusters?: KxAttachedCluster[];
}
export declare const GetKxVolumeResponse: S.Schema<GetKxVolumeResponse>;
export type PaginationToken = string;
export type ResultLimit = number;
export interface ListEnvironmentsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListEnvironmentsRequest: S.Schema<ListEnvironmentsRequest>;
export type EnvironmentList = Environment[];
export declare const EnvironmentList: any;
export interface ListEnvironmentsResponse {
    environments?: Environment[];
    nextToken?: string;
}
export declare const ListEnvironmentsResponse: S.Schema<ListEnvironmentsResponse>;
export type MaxResults = number;
export interface ListKxChangesetsRequest {
    environmentId: string;
    databaseName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListKxChangesetsRequest: S.Schema<ListKxChangesetsRequest>;
export interface KxChangesetListEntry {
    changesetId?: string;
    createdTimestamp?: Date;
    activeFromTimestamp?: Date;
    lastModifiedTimestamp?: Date;
    status?: ChangesetStatus;
}
export declare const KxChangesetListEntry: S.Schema<KxChangesetListEntry>;
export type KxChangesets = KxChangesetListEntry[];
export declare const KxChangesets: any;
export interface ListKxChangesetsResponse {
    kxChangesets?: KxChangesetListEntry[];
    nextToken?: string;
}
export declare const ListKxChangesetsResponse: S.Schema<ListKxChangesetsResponse>;
export interface ListKxClusterNodesRequest {
    environmentId: string;
    clusterName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListKxClusterNodesRequest: S.Schema<ListKxClusterNodesRequest>;
export type KxNodeStatus = "RUNNING" | "PROVISIONING" | (string & {});
export declare const KxNodeStatus: any;
export interface KxNode {
    nodeId?: string;
    availabilityZoneId?: string;
    launchTime?: Date;
    status?: KxNodeStatus;
}
export declare const KxNode: S.Schema<KxNode>;
export type KxNodeSummaries = KxNode[];
export declare const KxNodeSummaries: any;
export interface ListKxClusterNodesResponse {
    nodes?: KxNode[];
    nextToken?: string;
}
export declare const ListKxClusterNodesResponse: S.Schema<ListKxClusterNodesResponse>;
export interface ListKxClustersRequest {
    environmentId: string;
    clusterType?: KxClusterType;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListKxClustersRequest: S.Schema<ListKxClustersRequest>;
export interface KxCluster {
    status?: KxClusterStatus;
    statusReason?: string;
    clusterName?: string;
    clusterType?: KxClusterType;
    clusterDescription?: string;
    releaseLabel?: string;
    volumes?: Volume[];
    initializationScript?: string;
    executionRole?: string;
    azMode?: KxAzMode;
    availabilityZoneId?: string;
    lastModifiedTimestamp?: Date;
    createdTimestamp?: Date;
}
export declare const KxCluster: S.Schema<KxCluster>;
export type KxClusters = KxCluster[];
export declare const KxClusters: any;
export interface ListKxClustersResponse {
    kxClusterSummaries?: KxCluster[];
    nextToken?: string;
}
export declare const ListKxClustersResponse: S.Schema<ListKxClustersResponse>;
export interface ListKxDatabasesRequest {
    environmentId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListKxDatabasesRequest: S.Schema<ListKxDatabasesRequest>;
export interface KxDatabaseListEntry {
    databaseName?: string;
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
}
export declare const KxDatabaseListEntry: S.Schema<KxDatabaseListEntry>;
export type KxDatabases = KxDatabaseListEntry[];
export declare const KxDatabases: any;
export interface ListKxDatabasesResponse {
    kxDatabases?: KxDatabaseListEntry[];
    nextToken?: string;
}
export declare const ListKxDatabasesResponse: S.Schema<ListKxDatabasesResponse>;
export interface ListKxDataviewsRequest {
    environmentId: string;
    databaseName: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListKxDataviewsRequest: S.Schema<ListKxDataviewsRequest>;
export interface KxDataviewListEntry {
    environmentId?: string;
    databaseName?: string;
    dataviewName?: string;
    azMode?: KxAzMode;
    availabilityZoneId?: string;
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
    activeVersions?: KxDataviewActiveVersion[];
    status?: KxDataviewStatus;
    description?: string;
    autoUpdate?: boolean;
    readWrite?: boolean;
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
    statusReason?: string;
}
export declare const KxDataviewListEntry: S.Schema<KxDataviewListEntry>;
export type KxDataviews = KxDataviewListEntry[];
export declare const KxDataviews: any;
export interface ListKxDataviewsResponse {
    kxDataviews?: KxDataviewListEntry[];
    nextToken?: string;
}
export declare const ListKxDataviewsResponse: S.Schema<ListKxDataviewsResponse>;
export type BoxedInteger = number;
export interface ListKxEnvironmentsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListKxEnvironmentsRequest: S.Schema<ListKxEnvironmentsRequest>;
export interface KxEnvironment {
    name?: string;
    environmentId?: string;
    awsAccountId?: string;
    status?: EnvironmentStatus;
    tgwStatus?: TgwStatus;
    dnsStatus?: DnsStatus;
    errorMessage?: string;
    description?: string;
    environmentArn?: string;
    kmsKeyId?: string;
    dedicatedServiceAccountId?: string;
    transitGatewayConfiguration?: TransitGatewayConfiguration;
    customDNSConfiguration?: CustomDNSServer[];
    creationTimestamp?: Date;
    updateTimestamp?: Date;
    availabilityZoneIds?: string[];
    certificateAuthorityArn?: string;
}
export declare const KxEnvironment: S.Schema<KxEnvironment>;
export type KxEnvironmentList = KxEnvironment[];
export declare const KxEnvironmentList: any;
export interface ListKxEnvironmentsResponse {
    environments?: KxEnvironment[];
    nextToken?: string;
}
export declare const ListKxEnvironmentsResponse: S.Schema<ListKxEnvironmentsResponse>;
export interface ListKxScalingGroupsRequest {
    environmentId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListKxScalingGroupsRequest: S.Schema<ListKxScalingGroupsRequest>;
export interface KxScalingGroup {
    scalingGroupName?: string;
    hostType?: string;
    clusters?: string[];
    availabilityZoneId?: string;
    status?: KxScalingGroupStatus;
    statusReason?: string;
    lastModifiedTimestamp?: Date;
    createdTimestamp?: Date;
}
export declare const KxScalingGroup: S.Schema<KxScalingGroup>;
export type KxScalingGroupList = KxScalingGroup[];
export declare const KxScalingGroupList: any;
export interface ListKxScalingGroupsResponse {
    scalingGroups?: KxScalingGroup[];
    nextToken?: string;
}
export declare const ListKxScalingGroupsResponse: S.Schema<ListKxScalingGroupsResponse>;
export interface ListKxUsersRequest {
    environmentId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListKxUsersRequest: S.Schema<ListKxUsersRequest>;
export interface KxUser {
    userArn?: string;
    userName?: string;
    iamRole?: string;
    createTimestamp?: Date;
    updateTimestamp?: Date;
}
export declare const KxUser: S.Schema<KxUser>;
export type KxUserList = KxUser[];
export declare const KxUserList: any;
export interface ListKxUsersResponse {
    users?: KxUser[];
    nextToken?: string;
}
export declare const ListKxUsersResponse: S.Schema<ListKxUsersResponse>;
export interface ListKxVolumesRequest {
    environmentId: string;
    maxResults?: number;
    nextToken?: string;
    volumeType?: KxVolumeType;
}
export declare const ListKxVolumesRequest: S.Schema<ListKxVolumesRequest>;
export interface KxVolume {
    volumeName?: string;
    volumeType?: KxVolumeType;
    status?: KxVolumeStatus;
    description?: string;
    statusReason?: string;
    azMode?: KxAzMode;
    availabilityZoneIds?: string[];
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
}
export declare const KxVolume: S.Schema<KxVolume>;
export type KxVolumes = KxVolume[];
export declare const KxVolumes: any;
export interface ListKxVolumesResponse {
    kxVolumeSummaries?: KxVolume[];
    nextToken?: string;
}
export declare const ListKxVolumesResponse: S.Schema<ListKxVolumesResponse>;
export type FinSpaceTaggableArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateEnvironmentRequest {
    environmentId: string;
    name?: string;
    description?: string;
    federationMode?: FederationMode;
    federationParameters?: FederationParameters;
}
export declare const UpdateEnvironmentRequest: S.Schema<UpdateEnvironmentRequest>;
export interface UpdateEnvironmentResponse {
    environment?: Environment;
}
export declare const UpdateEnvironmentResponse: S.Schema<UpdateEnvironmentResponse>;
export type KxClusterCodeDeploymentStrategy = "NO_RESTART" | "ROLLING" | "FORCE" | (string & {});
export declare const KxClusterCodeDeploymentStrategy: any;
export interface KxClusterCodeDeploymentConfiguration {
    deploymentStrategy: KxClusterCodeDeploymentStrategy;
}
export declare const KxClusterCodeDeploymentConfiguration: S.Schema<KxClusterCodeDeploymentConfiguration>;
export interface UpdateKxClusterCodeConfigurationRequest {
    environmentId: string;
    clusterName: string;
    clientToken?: string;
    code: CodeConfiguration;
    initializationScript?: string;
    commandLineArguments?: KxCommandLineArgument[];
    deploymentConfiguration?: KxClusterCodeDeploymentConfiguration;
}
export declare const UpdateKxClusterCodeConfigurationRequest: S.Schema<UpdateKxClusterCodeConfigurationRequest>;
export interface UpdateKxClusterCodeConfigurationResponse {
}
export declare const UpdateKxClusterCodeConfigurationResponse: S.Schema<UpdateKxClusterCodeConfigurationResponse>;
export type KxDeploymentStrategy = "NO_RESTART" | "ROLLING" | (string & {});
export declare const KxDeploymentStrategy: any;
export interface KxDeploymentConfiguration {
    deploymentStrategy: KxDeploymentStrategy;
}
export declare const KxDeploymentConfiguration: S.Schema<KxDeploymentConfiguration>;
export interface UpdateKxClusterDatabasesRequest {
    environmentId: string;
    clusterName: string;
    clientToken?: string;
    databases: KxDatabaseConfiguration[];
    deploymentConfiguration?: KxDeploymentConfiguration;
}
export declare const UpdateKxClusterDatabasesRequest: S.Schema<UpdateKxClusterDatabasesRequest>;
export interface UpdateKxClusterDatabasesResponse {
}
export declare const UpdateKxClusterDatabasesResponse: S.Schema<UpdateKxClusterDatabasesResponse>;
export interface UpdateKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
    description?: string;
    clientToken: string;
}
export declare const UpdateKxDatabaseRequest: S.Schema<UpdateKxDatabaseRequest>;
export interface UpdateKxDatabaseResponse {
    databaseName?: string;
    environmentId?: string;
    description?: string;
    lastModifiedTimestamp?: Date;
}
export declare const UpdateKxDatabaseResponse: S.Schema<UpdateKxDatabaseResponse>;
export interface UpdateKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
    description?: string;
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
    clientToken: string;
}
export declare const UpdateKxDataviewRequest: S.Schema<UpdateKxDataviewRequest>;
export interface UpdateKxDataviewResponse {
    environmentId?: string;
    databaseName?: string;
    dataviewName?: string;
    azMode?: KxAzMode;
    availabilityZoneId?: string;
    changesetId?: string;
    segmentConfigurations?: KxDataviewSegmentConfiguration[];
    activeVersions?: KxDataviewActiveVersion[];
    status?: KxDataviewStatus;
    autoUpdate?: boolean;
    readWrite?: boolean;
    description?: string;
    createdTimestamp?: Date;
    lastModifiedTimestamp?: Date;
}
export declare const UpdateKxDataviewResponse: S.Schema<UpdateKxDataviewResponse>;
export interface UpdateKxEnvironmentRequest {
    environmentId: string;
    name?: string;
    description?: string;
    clientToken?: string;
}
export declare const UpdateKxEnvironmentRequest: S.Schema<UpdateKxEnvironmentRequest>;
export interface UpdateKxEnvironmentResponse {
    name?: string;
    environmentId?: string;
    awsAccountId?: string;
    status?: EnvironmentStatus;
    tgwStatus?: TgwStatus;
    dnsStatus?: DnsStatus;
    errorMessage?: string;
    description?: string;
    environmentArn?: string;
    kmsKeyId?: string;
    dedicatedServiceAccountId?: string;
    transitGatewayConfiguration?: TransitGatewayConfiguration;
    customDNSConfiguration?: CustomDNSServer[];
    creationTimestamp?: Date;
    updateTimestamp?: Date;
    availabilityZoneIds?: string[];
}
export declare const UpdateKxEnvironmentResponse: S.Schema<UpdateKxEnvironmentResponse>;
export interface UpdateKxEnvironmentNetworkRequest {
    environmentId: string;
    transitGatewayConfiguration?: TransitGatewayConfiguration;
    customDNSConfiguration?: CustomDNSServer[];
    clientToken?: string;
}
export declare const UpdateKxEnvironmentNetworkRequest: S.Schema<UpdateKxEnvironmentNetworkRequest>;
export interface UpdateKxEnvironmentNetworkResponse {
    name?: string;
    environmentId?: string;
    awsAccountId?: string;
    status?: EnvironmentStatus;
    tgwStatus?: TgwStatus;
    dnsStatus?: DnsStatus;
    errorMessage?: string;
    description?: string;
    environmentArn?: string;
    kmsKeyId?: string;
    dedicatedServiceAccountId?: string;
    transitGatewayConfiguration?: TransitGatewayConfiguration;
    customDNSConfiguration?: CustomDNSServer[];
    creationTimestamp?: Date;
    updateTimestamp?: Date;
    availabilityZoneIds?: string[];
}
export declare const UpdateKxEnvironmentNetworkResponse: S.Schema<UpdateKxEnvironmentNetworkResponse>;
export interface UpdateKxUserRequest {
    environmentId: string;
    userName: string;
    iamRole: string;
    clientToken?: string;
}
export declare const UpdateKxUserRequest: S.Schema<UpdateKxUserRequest>;
export interface UpdateKxUserResponse {
    userName?: string;
    userArn?: string;
    environmentId?: string;
    iamRole?: string;
}
export declare const UpdateKxUserResponse: S.Schema<UpdateKxUserResponse>;
export interface UpdateKxVolumeRequest {
    environmentId: string;
    volumeName: string;
    description?: string;
    clientToken?: string;
    nas1Configuration?: KxNAS1Configuration;
}
export declare const UpdateKxVolumeRequest: S.Schema<UpdateKxVolumeRequest>;
export interface UpdateKxVolumeResponse {
    environmentId?: string;
    volumeName?: string;
    volumeType?: KxVolumeType;
    volumeArn?: string;
    nas1Configuration?: KxNAS1Configuration;
    status?: KxVolumeStatus;
    description?: string;
    statusReason?: string;
    createdTimestamp?: Date;
    azMode?: KxAzMode;
    availabilityZoneIds?: string[];
    lastModifiedTimestamp?: Date;
    attachedClusters?: KxAttachedCluster[];
}
export declare const UpdateKxVolumeResponse: S.Schema<UpdateKxVolumeResponse>;
export type ErrorMessage2 = string;
export type CreateEnvironmentError = AccessDeniedException | InternalServerException | LimitExceededException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new FinSpace environment.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateKxChangesetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a changeset for a kdb database. A changeset allows you to add and delete existing files by using an ordered list of change requests.
 */
export declare const createKxChangeset: API.OperationMethod<CreateKxChangesetRequest, CreateKxChangesetResponse, CreateKxChangesetError, Credentials | HttpClient.HttpClient>;
export type CreateKxClusterError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new kdb cluster.
 */
export declare const createKxCluster: API.OperationMethod<CreateKxClusterRequest, CreateKxClusterResponse, CreateKxClusterError, Credentials | HttpClient.HttpClient>;
export type CreateKxDatabaseError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new kdb database in the environment.
 */
export declare const createKxDatabase: API.OperationMethod<CreateKxDatabaseRequest, CreateKxDatabaseResponse, CreateKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type CreateKxDataviewError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of kdb database with tiered storage capabilities and a pre-warmed cache, ready for mounting on kdb clusters. Dataviews are only available for clusters running on a scaling group. They are not supported on dedicated clusters.
 */
export declare const createKxDataview: API.OperationMethod<CreateKxDataviewRequest, CreateKxDataviewResponse, CreateKxDataviewError, Credentials | HttpClient.HttpClient>;
export type CreateKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a managed kdb environment for the account.
 */
export declare const createKxEnvironment: API.OperationMethod<CreateKxEnvironmentRequest, CreateKxEnvironmentResponse, CreateKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateKxScalingGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new scaling group.
 */
export declare const createKxScalingGroup: API.OperationMethod<CreateKxScalingGroupRequest, CreateKxScalingGroupResponse, CreateKxScalingGroupError, Credentials | HttpClient.HttpClient>;
export type CreateKxUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a user in FinSpace kdb environment with an associated IAM role.
 */
export declare const createKxUser: API.OperationMethod<CreateKxUserRequest, CreateKxUserResponse, CreateKxUserError, Credentials | HttpClient.HttpClient>;
export type CreateKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new volume with a specific amount of throughput and storage capacity.
 */
export declare const createKxVolume: API.OperationMethod<CreateKxVolumeRequest, CreateKxVolumeResponse, CreateKxVolumeError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an FinSpace environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteKxClusterError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a kdb cluster.
 */
export declare const deleteKxCluster: API.OperationMethod<DeleteKxClusterRequest, DeleteKxClusterResponse, DeleteKxClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteKxClusterNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified nodes from a cluster.
 */
export declare const deleteKxClusterNode: API.OperationMethod<DeleteKxClusterNodeRequest, DeleteKxClusterNodeResponse, DeleteKxClusterNodeError, Credentials | HttpClient.HttpClient>;
export type DeleteKxDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified database and all of its associated data. This action is irreversible. You must copy any data out of the database before deleting it if the data is to be retained.
 */
export declare const deleteKxDatabase: API.OperationMethod<DeleteKxDatabaseRequest, DeleteKxDatabaseResponse, DeleteKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteKxDataviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified dataview. Before deleting a dataview, make sure that it is not in use by any cluster.
 */
export declare const deleteKxDataview: API.OperationMethod<DeleteKxDataviewRequest, DeleteKxDataviewResponse, DeleteKxDataviewError, Credentials | HttpClient.HttpClient>;
export type DeleteKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the kdb environment. This action is irreversible. Deleting a kdb environment will remove all the associated data and any services running in it.
 */
export declare const deleteKxEnvironment: API.OperationMethod<DeleteKxEnvironmentRequest, DeleteKxEnvironmentResponse, DeleteKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteKxScalingGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified scaling group. This action is irreversible. You cannot delete a scaling group until all the clusters running on it have been deleted.
 */
export declare const deleteKxScalingGroup: API.OperationMethod<DeleteKxScalingGroupRequest, DeleteKxScalingGroupResponse, DeleteKxScalingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteKxUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a user in the specified kdb environment.
 */
export declare const deleteKxUser: API.OperationMethod<DeleteKxUserRequest, DeleteKxUserResponse, DeleteKxUserError, Credentials | HttpClient.HttpClient>;
export type DeleteKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a volume. You can only delete a volume if it's not attached to a cluster or a dataview. When a volume is deleted, any data on the volume is lost. This action is irreversible.
 */
export declare const deleteKxVolume: API.OperationMethod<DeleteKxVolumeRequest, DeleteKxVolumeResponse, DeleteKxVolumeError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the FinSpace environment object.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetKxChangesetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a kdb changeset.
 */
export declare const getKxChangeset: API.OperationMethod<GetKxChangesetRequest, GetKxChangesetResponse, GetKxChangesetError, Credentials | HttpClient.HttpClient>;
export type GetKxClusterError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a kdb cluster.
 */
export declare const getKxCluster: API.OperationMethod<GetKxClusterRequest, GetKxClusterResponse, GetKxClusterError, Credentials | HttpClient.HttpClient>;
export type GetKxConnectionStringError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a connection string for a user to connect to a kdb cluster. You must call this API using the same role that you have defined while creating a user.
 */
export declare const getKxConnectionString: API.OperationMethod<GetKxConnectionStringRequest, GetKxConnectionStringResponse, GetKxConnectionStringError, Credentials | HttpClient.HttpClient>;
export type GetKxDatabaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns database information for the specified environment ID.
 */
export declare const getKxDatabase: API.OperationMethod<GetKxDatabaseRequest, GetKxDatabaseResponse, GetKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetKxDataviewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of the dataview.
 */
export declare const getKxDataview: API.OperationMethod<GetKxDataviewRequest, GetKxDataviewResponse, GetKxDataviewError, Credentials | HttpClient.HttpClient>;
export type GetKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves all the information for the specified kdb environment.
 */
export declare const getKxEnvironment: API.OperationMethod<GetKxEnvironmentRequest, GetKxEnvironmentResponse, GetKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetKxScalingGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of a scaling group.
 */
export declare const getKxScalingGroup: API.OperationMethod<GetKxScalingGroupRequest, GetKxScalingGroupResponse, GetKxScalingGroupError, Credentials | HttpClient.HttpClient>;
export type GetKxUserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified kdb user.
 */
export declare const getKxUser: API.OperationMethod<GetKxUserRequest, GetKxUserResponse, GetKxUserError, Credentials | HttpClient.HttpClient>;
export type GetKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the information about the volume.
 */
export declare const getKxVolume: API.OperationMethod<GetKxVolumeRequest, GetKxVolumeResponse, GetKxVolumeError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * A list of all of your FinSpace environments.
 */
export declare const listEnvironments: API.OperationMethod<ListEnvironmentsRequest, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type ListKxChangesetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the changesets for a database.
 */
export declare const listKxChangesets: API.PaginatedOperationMethod<ListKxChangesetsRequest, ListKxChangesetsResponse, ListKxChangesetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxClusterNodesError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the nodes in a kdb cluster.
 */
export declare const listKxClusterNodes: API.PaginatedOperationMethod<ListKxClusterNodesRequest, ListKxClusterNodesResponse, ListKxClusterNodesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxClustersError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of clusters.
 */
export declare const listKxClusters: API.OperationMethod<ListKxClustersRequest, ListKxClustersResponse, ListKxClustersError, Credentials | HttpClient.HttpClient>;
export type ListKxDatabasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the databases in the kdb environment.
 */
export declare const listKxDatabases: API.PaginatedOperationMethod<ListKxDatabasesRequest, ListKxDatabasesResponse, ListKxDatabasesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxDataviewsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the dataviews in the database.
 */
export declare const listKxDataviews: API.PaginatedOperationMethod<ListKxDataviewsRequest, ListKxDataviewsResponse, ListKxDataviewsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxEnvironmentsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of kdb environments created in an account.
 */
export declare const listKxEnvironments: API.PaginatedOperationMethod<ListKxEnvironmentsRequest, ListKxEnvironmentsResponse, ListKxEnvironmentsError, Credentials | HttpClient.HttpClient, KxEnvironment>;
export type ListKxScalingGroupsError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of scaling groups in a kdb environment.
 */
export declare const listKxScalingGroups: API.PaginatedOperationMethod<ListKxScalingGroupsRequest, ListKxScalingGroupsResponse, ListKxScalingGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxUsersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the users in a kdb environment.
 */
export declare const listKxUsers: API.OperationMethod<ListKxUsersRequest, ListKxUsersResponse, ListKxUsersError, Credentials | HttpClient.HttpClient>;
export type ListKxVolumesError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the volumes in a kdb environment.
 */
export declare const listKxVolumes: API.OperationMethod<ListKxVolumesRequest, ListKxVolumesResponse, ListKxVolumesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * A list of all tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Adds metadata tags to a FinSpace resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes metadata tags from a FinSpace resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update your FinSpace environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest, UpdateEnvironmentResponse, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateKxClusterCodeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows you to update code configuration on a running cluster. By using this API you can update the code, the initialization script path, and the command line arguments for a specific cluster.
 * The configuration that you want to update will override any existing configurations on the cluster.
 */
export declare const updateKxClusterCodeConfiguration: API.OperationMethod<UpdateKxClusterCodeConfigurationRequest, UpdateKxClusterCodeConfigurationResponse, UpdateKxClusterCodeConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateKxClusterDatabasesError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the databases mounted on a kdb cluster, which includes the `changesetId` and all the dbPaths to be cached. This API does not allow you to change a database name or add a database if you created a cluster without one.
 *
 * Using this API you can point a cluster to a different changeset and modify a list of partitions being cached.
 */
export declare const updateKxClusterDatabases: API.OperationMethod<UpdateKxClusterDatabasesRequest, UpdateKxClusterDatabasesResponse, UpdateKxClusterDatabasesError, Credentials | HttpClient.HttpClient>;
export type UpdateKxDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information for the given kdb database.
 */
export declare const updateKxDatabase: API.OperationMethod<UpdateKxDatabaseRequest, UpdateKxDatabaseResponse, UpdateKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type UpdateKxDataviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified dataview. The dataviews get automatically updated when any new changesets are ingested. Each update of the dataview creates a new version, including changeset details and cache configurations
 */
export declare const updateKxDataview: API.OperationMethod<UpdateKxDataviewRequest, UpdateKxDataviewResponse, UpdateKxDataviewError, Credentials | HttpClient.HttpClient>;
export type UpdateKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information for the given kdb environment.
 */
export declare const updateKxEnvironment: API.OperationMethod<UpdateKxEnvironmentRequest, UpdateKxEnvironmentResponse, UpdateKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateKxEnvironmentNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates environment network to connect to your internal network by using a transit gateway. This API supports request to create a transit gateway attachment from FinSpace VPC to your transit gateway ID and create a custom Route-53 outbound resolvers.
 *
 * Once you send a request to update a network, you cannot change it again. Network update might require termination of any clusters that are running in the existing network.
 */
export declare const updateKxEnvironmentNetwork: API.OperationMethod<UpdateKxEnvironmentNetworkRequest, UpdateKxEnvironmentNetworkResponse, UpdateKxEnvironmentNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateKxUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the user details. You can only update the IAM role associated with a user.
 */
export declare const updateKxUser: API.OperationMethod<UpdateKxUserRequest, UpdateKxUserResponse, UpdateKxUserError, Credentials | HttpClient.HttpClient>;
export type UpdateKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the throughput or capacity of a volume. During the update process, the filesystem
 * might be unavailable for a few minutes. You can retry any operations after the update is complete.
 */
export declare const updateKxVolume: API.OperationMethod<UpdateKxVolumeRequest, UpdateKxVolumeResponse, UpdateKxVolumeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=finspace.d.ts.map