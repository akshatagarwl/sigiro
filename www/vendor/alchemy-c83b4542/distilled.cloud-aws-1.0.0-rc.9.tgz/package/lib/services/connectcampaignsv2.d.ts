import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidCampaignStateException_base: S.Class<InvalidCampaignStateException, S.TaggedStruct<"InvalidCampaignStateException", {
    readonly state: any;
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidCampaignStateException extends /*@__PURE__*/ InvalidCampaignStateException_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CampaignName = string;
export type InstanceId = string;
export type Capacity = number;
export type QueueId = string;
export type BandwidthAllocation = number;
export interface ProgressiveConfig {
    bandwidthAllocation: number;
}
export declare const ProgressiveConfig: S.Schema<ProgressiveConfig>;
export type TargetRate = number;
export type ConnectionStartPoint = string;
export type EvaluationWindow = string;
export interface AbandonmentRatePacingConfig {
    targetRate: number;
    connectionStartPoint: string;
    connectionThresholdSeconds: number;
    evaluationWindow: string;
}
export declare const AbandonmentRatePacingConfig: S.Schema<AbandonmentRatePacingConfig>;
export type PacingStrategy = {
    abandonmentRate: AbandonmentRatePacingConfig;
};
export declare const PacingStrategy: any;
export type PacingStrategyList = PacingStrategy[];
export declare const PacingStrategyList: any;
export interface PredictiveConfig {
    bandwidthAllocation: number;
    pacingStrategies?: PacingStrategy[];
}
export declare const PredictiveConfig: S.Schema<PredictiveConfig>;
export interface AgentlessConfig {
}
export declare const AgentlessConfig: S.Schema<AgentlessConfig>;
export type TimeoutDuration = number;
export interface TimeoutConfig {
    durationInSeconds: number;
}
export declare const TimeoutConfig: S.Schema<TimeoutConfig>;
export type AgentAction = string;
export type AgentActions = string[];
export declare const AgentActions: any;
export interface PreviewConfig {
    bandwidthAllocation: number;
    timeoutConfig: TimeoutConfig;
    agentActions?: string[];
}
export declare const PreviewConfig: S.Schema<PreviewConfig>;
export type TelephonyOutboundMode = {
    progressive: ProgressiveConfig;
    predictive?: never;
    agentless?: never;
    preview?: never;
} | {
    progressive?: never;
    predictive: PredictiveConfig;
    agentless?: never;
    preview?: never;
} | {
    progressive?: never;
    predictive?: never;
    agentless: AgentlessConfig;
    preview?: never;
} | {
    progressive?: never;
    predictive?: never;
    agentless?: never;
    preview: PreviewConfig;
};
export declare const TelephonyOutboundMode: any;
export type ContactFlowId = string;
export type SourcePhoneNumber = string;
export interface AnswerMachineDetectionConfig {
    enableAnswerMachineDetection: boolean;
    awaitAnswerMachinePrompt?: boolean;
}
export declare const AnswerMachineDetectionConfig: S.Schema<AnswerMachineDetectionConfig>;
export type RingTimeout = number;
export interface TelephonyOutboundConfig {
    connectContactFlowId: string;
    connectSourcePhoneNumber?: string;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig;
    ringTimeout?: number;
}
export declare const TelephonyOutboundConfig: S.Schema<TelephonyOutboundConfig>;
export interface TelephonyChannelSubtypeConfig {
    capacity?: number;
    connectQueueId?: string;
    outboundMode: TelephonyOutboundMode;
    defaultOutboundConfig: TelephonyOutboundConfig;
}
export declare const TelephonyChannelSubtypeConfig: S.Schema<TelephonyChannelSubtypeConfig>;
export type SmsOutboundMode = {
    agentless: AgentlessConfig;
};
export declare const SmsOutboundMode: any;
export type Arn = string;
export interface SmsOutboundConfig {
    connectSourcePhoneNumberArn: string;
    wisdomTemplateArn: string;
}
export declare const SmsOutboundConfig: S.Schema<SmsOutboundConfig>;
export interface SmsChannelSubtypeConfig {
    capacity?: number;
    outboundMode: SmsOutboundMode;
    defaultOutboundConfig: SmsOutboundConfig;
}
export declare const SmsChannelSubtypeConfig: S.Schema<SmsChannelSubtypeConfig>;
export type EmailOutboundMode = {
    agentless: AgentlessConfig;
};
export declare const EmailOutboundMode: any;
export type EmailAddress = string | redacted.Redacted<string>;
export type EmailDisplayName = string | redacted.Redacted<string>;
export interface EmailOutboundConfig {
    connectSourceEmailAddress: string | redacted.Redacted<string>;
    sourceEmailAddressDisplayName?: string | redacted.Redacted<string>;
    wisdomTemplateArn: string;
}
export declare const EmailOutboundConfig: S.Schema<EmailOutboundConfig>;
export interface EmailChannelSubtypeConfig {
    capacity?: number;
    outboundMode: EmailOutboundMode;
    defaultOutboundConfig: EmailOutboundConfig;
}
export declare const EmailChannelSubtypeConfig: S.Schema<EmailChannelSubtypeConfig>;
export type WhatsAppOutboundMode = {
    agentless: AgentlessConfig;
};
export declare const WhatsAppOutboundMode: any;
export interface WhatsAppOutboundConfig {
    connectSourcePhoneNumberArn: string;
    wisdomTemplateArn: string;
}
export declare const WhatsAppOutboundConfig: S.Schema<WhatsAppOutboundConfig>;
export interface WhatsAppChannelSubtypeConfig {
    capacity?: number;
    outboundMode: WhatsAppOutboundMode;
    defaultOutboundConfig: WhatsAppOutboundConfig;
}
export declare const WhatsAppChannelSubtypeConfig: S.Schema<WhatsAppChannelSubtypeConfig>;
export interface ChannelSubtypeConfig {
    telephony?: TelephonyChannelSubtypeConfig;
    sms?: SmsChannelSubtypeConfig;
    email?: EmailChannelSubtypeConfig;
    whatsApp?: WhatsAppChannelSubtypeConfig;
}
export declare const ChannelSubtypeConfig: S.Schema<ChannelSubtypeConfig>;
export type ExternalCampaignType = string;
export interface EventTrigger {
    customerProfilesDomainArn?: string;
}
export declare const EventTrigger: S.Schema<EventTrigger>;
export type Source = {
    customerProfilesSegmentArn: string;
    eventTrigger?: never;
} | {
    customerProfilesSegmentArn?: never;
    eventTrigger: EventTrigger;
};
export declare const Source: any;
export type Iso8601Duration = string;
export interface Schedule {
    startTime: Date;
    endTime: Date;
    refreshFrequency?: string;
}
export declare const Schedule: S.Schema<Schedule>;
export interface EntryLimitsConfig {
    maxEntryCount: number;
    minEntryInterval: string;
}
export declare const EntryLimitsConfig: S.Schema<EntryLimitsConfig>;
export type TimeZone = string;
export type LocalTimeZoneDetectionType = string;
export type LocalTimeZoneDetection = string[];
export declare const LocalTimeZoneDetection: any;
export type LocalTimeZoneDetectionScope = string;
export interface LocalTimeZoneConfig {
    defaultTimeZone?: string;
    localTimeZoneDetection?: string[];
    localTimeZoneDetectionScope?: string;
}
export declare const LocalTimeZoneConfig: S.Schema<LocalTimeZoneConfig>;
export type DayOfWeek = string;
export type Iso8601Time = string;
export interface TimeRange {
    startTime: string;
    endTime: string;
}
export declare const TimeRange: S.Schema<TimeRange>;
export type TimeRangeList = TimeRange[];
export declare const TimeRangeList: any;
export type DailyHours = {
    [key: string]: TimeRange[] | undefined;
};
export declare const DailyHours: any;
export type OpenHours = {
    dailyHours: {
        [key: string]: TimeRange[] | undefined;
    };
};
export declare const OpenHours: any;
export type RestrictedPeriodName = string;
export type Iso8601Date = string;
export interface RestrictedPeriod {
    name?: string;
    startDate: string;
    endDate: string;
}
export declare const RestrictedPeriod: S.Schema<RestrictedPeriod>;
export type RestrictedPeriodList = RestrictedPeriod[];
export declare const RestrictedPeriodList: any;
export type RestrictedPeriods = {
    restrictedPeriodList: RestrictedPeriod[];
};
export declare const RestrictedPeriods: any;
export interface TimeWindow {
    openHours: OpenHours;
    restrictedPeriods?: RestrictedPeriods;
}
export declare const TimeWindow: S.Schema<TimeWindow>;
export interface CommunicationTimeConfig {
    localTimeZoneConfig: LocalTimeZoneConfig;
    telephony?: TimeWindow;
    sms?: TimeWindow;
    email?: TimeWindow;
    whatsApp?: TimeWindow;
}
export declare const CommunicationTimeConfig: S.Schema<CommunicationTimeConfig>;
export type CommunicationLimitTimeUnit = string;
export interface CommunicationLimit {
    maxCountPerRecipient: number;
    frequency: number;
    unit: string;
}
export declare const CommunicationLimit: S.Schema<CommunicationLimit>;
export type CommunicationLimitList = CommunicationLimit[];
export declare const CommunicationLimitList: any;
export type CommunicationLimits = {
    communicationLimitsList: CommunicationLimit[];
};
export declare const CommunicationLimits: any;
export type InstanceLimitsHandling = string;
export interface CommunicationLimitsConfig {
    allChannelSubtypes?: CommunicationLimits;
    instanceLimitsHandling?: string;
}
export declare const CommunicationLimitsConfig: S.Schema<CommunicationLimitsConfig>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CreateCampaignRequest {
    name: string;
    connectInstanceId: string;
    channelSubtypeConfig?: ChannelSubtypeConfig;
    type?: string;
    source?: Source;
    connectCampaignFlowArn?: string;
    schedule?: Schedule;
    entryLimitsConfig?: EntryLimitsConfig;
    communicationTimeConfig?: CommunicationTimeConfig;
    communicationLimitsOverride?: CommunicationLimitsConfig;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCampaignRequest: S.Schema<CreateCampaignRequest>;
export type CampaignId = string;
export type CampaignArn = string;
export interface CreateCampaignResponse {
    id?: string;
    arn?: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCampaignResponse: S.Schema<CreateCampaignResponse>;
export interface DeleteCampaignRequest {
    id: string;
}
export declare const DeleteCampaignRequest: S.Schema<DeleteCampaignRequest>;
export interface DeleteCampaignResponse {
}
export declare const DeleteCampaignResponse: S.Schema<DeleteCampaignResponse>;
export type ChannelSubtype = string;
export interface DeleteCampaignChannelSubtypeConfigRequest {
    id: string;
    channelSubtype: string;
}
export declare const DeleteCampaignChannelSubtypeConfigRequest: S.Schema<DeleteCampaignChannelSubtypeConfigRequest>;
export interface DeleteCampaignChannelSubtypeConfigResponse {
}
export declare const DeleteCampaignChannelSubtypeConfigResponse: S.Schema<DeleteCampaignChannelSubtypeConfigResponse>;
export type CommunicationLimitsConfigType = string;
export interface DeleteCampaignCommunicationLimitsRequest {
    id: string;
    config: string;
}
export declare const DeleteCampaignCommunicationLimitsRequest: S.Schema<DeleteCampaignCommunicationLimitsRequest>;
export interface DeleteCampaignCommunicationLimitsResponse {
}
export declare const DeleteCampaignCommunicationLimitsResponse: S.Schema<DeleteCampaignCommunicationLimitsResponse>;
export type CommunicationTimeConfigType = string;
export interface DeleteCampaignCommunicationTimeRequest {
    id: string;
    config: string;
}
export declare const DeleteCampaignCommunicationTimeRequest: S.Schema<DeleteCampaignCommunicationTimeRequest>;
export interface DeleteCampaignCommunicationTimeResponse {
}
export declare const DeleteCampaignCommunicationTimeResponse: S.Schema<DeleteCampaignCommunicationTimeResponse>;
export interface DeleteCampaignEntryLimitsRequest {
    id: string;
}
export declare const DeleteCampaignEntryLimitsRequest: S.Schema<DeleteCampaignEntryLimitsRequest>;
export interface DeleteCampaignEntryLimitsResponse {
}
export declare const DeleteCampaignEntryLimitsResponse: S.Schema<DeleteCampaignEntryLimitsResponse>;
export type CampaignDeletionPolicy = string;
export interface DeleteConnectInstanceConfigRequest {
    connectInstanceId: string;
    campaignDeletionPolicy?: string;
}
export declare const DeleteConnectInstanceConfigRequest: S.Schema<DeleteConnectInstanceConfigRequest>;
export interface DeleteConnectInstanceConfigResponse {
}
export declare const DeleteConnectInstanceConfigResponse: S.Schema<DeleteConnectInstanceConfigResponse>;
export interface CustomerProfilesIntegrationIdentifier {
    domainArn: string;
}
export declare const CustomerProfilesIntegrationIdentifier: S.Schema<CustomerProfilesIntegrationIdentifier>;
export interface QConnectIntegrationIdentifier {
    knowledgeBaseArn: string;
}
export declare const QConnectIntegrationIdentifier: S.Schema<QConnectIntegrationIdentifier>;
export type LambdaArn = string;
export interface LambdaIntegrationIdentifier {
    functionArn: string;
}
export declare const LambdaIntegrationIdentifier: S.Schema<LambdaIntegrationIdentifier>;
export type IntegrationIdentifier = {
    customerProfiles: CustomerProfilesIntegrationIdentifier;
    qConnect?: never;
    lambda?: never;
} | {
    customerProfiles?: never;
    qConnect: QConnectIntegrationIdentifier;
    lambda?: never;
} | {
    customerProfiles?: never;
    qConnect?: never;
    lambda: LambdaIntegrationIdentifier;
};
export declare const IntegrationIdentifier: any;
export interface DeleteConnectInstanceIntegrationRequest {
    connectInstanceId: string;
    integrationIdentifier: IntegrationIdentifier;
}
export declare const DeleteConnectInstanceIntegrationRequest: S.Schema<DeleteConnectInstanceIntegrationRequest>;
export interface DeleteConnectInstanceIntegrationResponse {
}
export declare const DeleteConnectInstanceIntegrationResponse: S.Schema<DeleteConnectInstanceIntegrationResponse>;
export interface DeleteInstanceOnboardingJobRequest {
    connectInstanceId: string;
}
export declare const DeleteInstanceOnboardingJobRequest: S.Schema<DeleteInstanceOnboardingJobRequest>;
export interface DeleteInstanceOnboardingJobResponse {
}
export declare const DeleteInstanceOnboardingJobResponse: S.Schema<DeleteInstanceOnboardingJobResponse>;
export interface DescribeCampaignRequest {
    id: string;
}
export declare const DescribeCampaignRequest: S.Schema<DescribeCampaignRequest>;
export interface Campaign {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
    channelSubtypeConfig?: ChannelSubtypeConfig;
    type?: string;
    source?: Source;
    connectCampaignFlowArn?: string;
    schedule?: Schedule;
    entryLimitsConfig?: EntryLimitsConfig;
    communicationTimeConfig?: CommunicationTimeConfig;
    communicationLimitsOverride?: CommunicationLimitsConfig;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Campaign: S.Schema<Campaign>;
export interface DescribeCampaignResponse {
    campaign?: Campaign;
}
export declare const DescribeCampaignResponse: S.Schema<DescribeCampaignResponse>;
export interface GetCampaignStateRequest {
    id: string;
}
export declare const GetCampaignStateRequest: S.Schema<GetCampaignStateRequest>;
export type CampaignState = string;
export interface GetCampaignStateResponse {
    state?: string;
}
export declare const GetCampaignStateResponse: S.Schema<GetCampaignStateResponse>;
export type CampaignIdList = string[];
export declare const CampaignIdList: any;
export interface GetCampaignStateBatchRequest {
    campaignIds: string[];
}
export declare const GetCampaignStateBatchRequest: S.Schema<GetCampaignStateBatchRequest>;
export interface SuccessfulCampaignStateResponse {
    campaignId?: string;
    state?: string;
}
export declare const SuccessfulCampaignStateResponse: S.Schema<SuccessfulCampaignStateResponse>;
export type SuccessfulCampaignStateResponseList = SuccessfulCampaignStateResponse[];
export declare const SuccessfulCampaignStateResponseList: any;
export type GetCampaignStateBatchFailureCode = string;
export interface FailedCampaignStateResponse {
    campaignId?: string;
    failureCode?: string;
}
export declare const FailedCampaignStateResponse: S.Schema<FailedCampaignStateResponse>;
export type FailedCampaignStateResponseList = FailedCampaignStateResponse[];
export declare const FailedCampaignStateResponseList: any;
export interface GetCampaignStateBatchResponse {
    successfulRequests?: SuccessfulCampaignStateResponse[];
    failedRequests?: FailedCampaignStateResponse[];
}
export declare const GetCampaignStateBatchResponse: S.Schema<GetCampaignStateBatchResponse>;
export interface GetConnectInstanceConfigRequest {
    connectInstanceId: string;
}
export declare const GetConnectInstanceConfigRequest: S.Schema<GetConnectInstanceConfigRequest>;
export type ServiceLinkedRoleArn = string;
export type Enabled = boolean;
export type EncryptionType = string;
export type EncryptionKey = string;
export interface EncryptionConfig {
    enabled: boolean;
    encryptionType?: string;
    keyArn?: string;
}
export declare const EncryptionConfig: S.Schema<EncryptionConfig>;
export interface InstanceConfig {
    connectInstanceId: string;
    serviceLinkedRoleArn: string;
    encryptionConfig: EncryptionConfig;
}
export declare const InstanceConfig: S.Schema<InstanceConfig>;
export interface GetConnectInstanceConfigResponse {
    connectInstanceConfig?: InstanceConfig;
}
export declare const GetConnectInstanceConfigResponse: S.Schema<GetConnectInstanceConfigResponse>;
export interface GetInstanceCommunicationLimitsRequest {
    connectInstanceId: string;
}
export declare const GetInstanceCommunicationLimitsRequest: S.Schema<GetInstanceCommunicationLimitsRequest>;
export interface InstanceCommunicationLimitsConfig {
    allChannelSubtypes?: CommunicationLimits;
}
export declare const InstanceCommunicationLimitsConfig: S.Schema<InstanceCommunicationLimitsConfig>;
export interface GetInstanceCommunicationLimitsResponse {
    communicationLimitsConfig?: InstanceCommunicationLimitsConfig;
}
export declare const GetInstanceCommunicationLimitsResponse: S.Schema<GetInstanceCommunicationLimitsResponse>;
export interface GetInstanceOnboardingJobStatusRequest {
    connectInstanceId: string;
}
export declare const GetInstanceOnboardingJobStatusRequest: S.Schema<GetInstanceOnboardingJobStatusRequest>;
export type InstanceOnboardingJobStatusCode = string;
export type InstanceOnboardingJobFailureCode = string;
export interface InstanceOnboardingJobStatus {
    connectInstanceId: string;
    status: string;
    failureCode?: string;
}
export declare const InstanceOnboardingJobStatus: S.Schema<InstanceOnboardingJobStatus>;
export interface GetInstanceOnboardingJobStatusResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus;
}
export declare const GetInstanceOnboardingJobStatusResponse: S.Schema<GetInstanceOnboardingJobStatusResponse>;
export type MaxResults = number;
export type NextToken = string;
export type InstanceIdFilterOperator = string;
export interface InstanceIdFilter {
    value: string;
    operator: string;
}
export declare const InstanceIdFilter: S.Schema<InstanceIdFilter>;
export interface CampaignFilters {
    instanceIdFilter?: InstanceIdFilter;
}
export declare const CampaignFilters: S.Schema<CampaignFilters>;
export interface ListCampaignsRequest {
    maxResults?: number;
    nextToken?: string;
    filters?: CampaignFilters;
}
export declare const ListCampaignsRequest: S.Schema<ListCampaignsRequest>;
export type ChannelSubtypeList = string[];
export declare const ChannelSubtypeList: any;
export interface CampaignSummary {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
    channelSubtypes: string[];
    type?: string;
    schedule?: Schedule;
    entryLimitsConfig?: EntryLimitsConfig;
    connectCampaignFlowArn?: string;
}
export declare const CampaignSummary: S.Schema<CampaignSummary>;
export type CampaignSummaryList = CampaignSummary[];
export declare const CampaignSummaryList: any;
export interface ListCampaignsResponse {
    nextToken?: string;
    campaignSummaryList?: CampaignSummary[];
}
export declare const ListCampaignsResponse: S.Schema<ListCampaignsResponse>;
export interface ListConnectInstanceIntegrationsRequest {
    connectInstanceId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListConnectInstanceIntegrationsRequest: S.Schema<ListConnectInstanceIntegrationsRequest>;
export type EventType = string;
export type ObjectTypeName = string;
export type ObjectTypeNamesMap = {
    [key: string]: string | undefined;
};
export declare const ObjectTypeNamesMap: any;
export interface CustomerProfilesIntegrationSummary {
    domainArn: string;
    objectTypeNames: {
        [key: string]: string | undefined;
    };
}
export declare const CustomerProfilesIntegrationSummary: S.Schema<CustomerProfilesIntegrationSummary>;
export interface QConnectIntegrationSummary {
    knowledgeBaseArn: string;
}
export declare const QConnectIntegrationSummary: S.Schema<QConnectIntegrationSummary>;
export interface LambdaIntegrationSummary {
    functionArn: string;
}
export declare const LambdaIntegrationSummary: S.Schema<LambdaIntegrationSummary>;
export type IntegrationSummary = {
    customerProfiles: CustomerProfilesIntegrationSummary;
    qConnect?: never;
    lambda?: never;
} | {
    customerProfiles?: never;
    qConnect: QConnectIntegrationSummary;
    lambda?: never;
} | {
    customerProfiles?: never;
    qConnect?: never;
    lambda: LambdaIntegrationSummary;
};
export declare const IntegrationSummary: any;
export type IntegrationSummaryList = IntegrationSummary[];
export declare const IntegrationSummaryList: any;
export interface ListConnectInstanceIntegrationsResponse {
    nextToken?: string;
    integrationSummaryList?: IntegrationSummary[];
}
export declare const ListConnectInstanceIntegrationsResponse: S.Schema<ListConnectInstanceIntegrationsResponse>;
export interface ListTagsForResourceRequest {
    arn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface PauseCampaignRequest {
    id: string;
}
export declare const PauseCampaignRequest: S.Schema<PauseCampaignRequest>;
export interface PauseCampaignResponse {
}
export declare const PauseCampaignResponse: S.Schema<PauseCampaignResponse>;
export interface CustomerProfilesIntegrationConfig {
    domainArn: string;
    objectTypeNames: {
        [key: string]: string | undefined;
    };
}
export declare const CustomerProfilesIntegrationConfig: S.Schema<CustomerProfilesIntegrationConfig>;
export interface QConnectIntegrationConfig {
    knowledgeBaseArn: string;
}
export declare const QConnectIntegrationConfig: S.Schema<QConnectIntegrationConfig>;
export interface LambdaIntegrationConfig {
    functionArn: string;
}
export declare const LambdaIntegrationConfig: S.Schema<LambdaIntegrationConfig>;
export type IntegrationConfig = {
    customerProfiles: CustomerProfilesIntegrationConfig;
    qConnect?: never;
    lambda?: never;
} | {
    customerProfiles?: never;
    qConnect: QConnectIntegrationConfig;
    lambda?: never;
} | {
    customerProfiles?: never;
    qConnect?: never;
    lambda: LambdaIntegrationConfig;
};
export declare const IntegrationConfig: any;
export interface PutConnectInstanceIntegrationRequest {
    connectInstanceId: string;
    integrationConfig: IntegrationConfig;
}
export declare const PutConnectInstanceIntegrationRequest: S.Schema<PutConnectInstanceIntegrationRequest>;
export interface PutConnectInstanceIntegrationResponse {
}
export declare const PutConnectInstanceIntegrationResponse: S.Schema<PutConnectInstanceIntegrationResponse>;
export interface PutInstanceCommunicationLimitsRequest {
    connectInstanceId: string;
    communicationLimitsConfig: InstanceCommunicationLimitsConfig;
}
export declare const PutInstanceCommunicationLimitsRequest: S.Schema<PutInstanceCommunicationLimitsRequest>;
export interface PutInstanceCommunicationLimitsResponse {
}
export declare const PutInstanceCommunicationLimitsResponse: S.Schema<PutInstanceCommunicationLimitsResponse>;
export type ClientToken = string;
export type DestinationPhoneNumber = string | redacted.Redacted<string>;
export type AttributeName = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export declare const Attributes: any;
export interface TelephonyChannelSubtypeParameters {
    destinationPhoneNumber: string | redacted.Redacted<string>;
    attributes: {
        [key: string]: string | undefined;
    };
    connectSourcePhoneNumber?: string;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig;
    ringTimeout?: number;
}
export declare const TelephonyChannelSubtypeParameters: S.Schema<TelephonyChannelSubtypeParameters>;
export interface SmsChannelSubtypeParameters {
    destinationPhoneNumber: string | redacted.Redacted<string>;
    connectSourcePhoneNumberArn?: string;
    templateArn?: string;
    templateParameters: {
        [key: string]: string | undefined;
    };
}
export declare const SmsChannelSubtypeParameters: S.Schema<SmsChannelSubtypeParameters>;
export interface EmailChannelSubtypeParameters {
    destinationEmailAddress: string | redacted.Redacted<string>;
    connectSourceEmailAddress?: string | redacted.Redacted<string>;
    templateArn?: string;
    templateParameters: {
        [key: string]: string | undefined;
    };
}
export declare const EmailChannelSubtypeParameters: S.Schema<EmailChannelSubtypeParameters>;
export interface WhatsAppChannelSubtypeParameters {
    destinationPhoneNumber: string | redacted.Redacted<string>;
    connectSourcePhoneNumberArn?: string;
    templateArn?: string;
    templateParameters: {
        [key: string]: string | undefined;
    };
}
export declare const WhatsAppChannelSubtypeParameters: S.Schema<WhatsAppChannelSubtypeParameters>;
export type ChannelSubtypeParameters = {
    telephony: TelephonyChannelSubtypeParameters;
    sms?: never;
    email?: never;
    whatsApp?: never;
} | {
    telephony?: never;
    sms: SmsChannelSubtypeParameters;
    email?: never;
    whatsApp?: never;
} | {
    telephony?: never;
    sms?: never;
    email: EmailChannelSubtypeParameters;
    whatsApp?: never;
} | {
    telephony?: never;
    sms?: never;
    email?: never;
    whatsApp: WhatsAppChannelSubtypeParameters;
};
export declare const ChannelSubtypeParameters: any;
export interface OutboundRequest {
    clientToken: string;
    expirationTime: Date;
    channelSubtypeParameters: ChannelSubtypeParameters;
}
export declare const OutboundRequest: S.Schema<OutboundRequest>;
export type OutboundRequestList = OutboundRequest[];
export declare const OutboundRequestList: any;
export interface PutOutboundRequestBatchRequest {
    id: string;
    outboundRequests: OutboundRequest[];
}
export declare const PutOutboundRequestBatchRequest: S.Schema<PutOutboundRequestBatchRequest>;
export type DialRequestId = string;
export interface SuccessfulRequest {
    clientToken?: string;
    id?: string;
}
export declare const SuccessfulRequest: S.Schema<SuccessfulRequest>;
export type SuccessfulRequestList = SuccessfulRequest[];
export declare const SuccessfulRequestList: any;
export type FailureCode = string;
export interface FailedRequest {
    clientToken?: string;
    id?: string;
    failureCode?: string;
}
export declare const FailedRequest: S.Schema<FailedRequest>;
export type FailedRequestList = FailedRequest[];
export declare const FailedRequestList: any;
export interface PutOutboundRequestBatchResponse {
    successfulRequests?: SuccessfulRequest[];
    failedRequests?: FailedRequest[];
}
export declare const PutOutboundRequestBatchResponse: S.Schema<PutOutboundRequestBatchResponse>;
export type ProfileId = string;
export type SourceEvent = string;
export type SessionId = string;
export type BrowserId = string;
export interface WebNotificationContext {
    sessionId?: string;
    browserId?: string;
}
export declare const WebNotificationContext: S.Schema<WebNotificationContext>;
export interface ChannelContext {
    webNotificationContext?: WebNotificationContext;
}
export declare const ChannelContext: S.Schema<ChannelContext>;
export interface EventTriggerContext {
    sourceEvent?: string;
    channelContext?: ChannelContext;
}
export declare const EventTriggerContext: S.Schema<EventTriggerContext>;
export interface ProfileOutboundRequest {
    clientToken: string;
    profileId: string;
    expirationTime?: Date;
    eventTriggerContext?: EventTriggerContext;
}
export declare const ProfileOutboundRequest: S.Schema<ProfileOutboundRequest>;
export type ProfileOutboundRequestList = ProfileOutboundRequest[];
export declare const ProfileOutboundRequestList: any;
export interface PutProfileOutboundRequestBatchRequest {
    id: string;
    profileOutboundRequests: ProfileOutboundRequest[];
}
export declare const PutProfileOutboundRequestBatchRequest: S.Schema<PutProfileOutboundRequestBatchRequest>;
export type ProfileOutboundRequestId = string;
export interface SuccessfulProfileOutboundRequest {
    clientToken?: string;
    id?: string;
}
export declare const SuccessfulProfileOutboundRequest: S.Schema<SuccessfulProfileOutboundRequest>;
export type SuccessfulProfileOutboundRequestList = SuccessfulProfileOutboundRequest[];
export declare const SuccessfulProfileOutboundRequestList: any;
export type ProfileOutboundRequestFailureCode = string;
export interface FailedProfileOutboundRequest {
    clientToken?: string;
    id?: string;
    failureCode?: string;
}
export declare const FailedProfileOutboundRequest: S.Schema<FailedProfileOutboundRequest>;
export type FailedProfileOutboundRequestList = FailedProfileOutboundRequest[];
export declare const FailedProfileOutboundRequestList: any;
export interface PutProfileOutboundRequestBatchResponse {
    successfulRequests?: SuccessfulProfileOutboundRequest[];
    failedRequests?: FailedProfileOutboundRequest[];
}
export declare const PutProfileOutboundRequestBatchResponse: S.Schema<PutProfileOutboundRequestBatchResponse>;
export interface ResumeCampaignRequest {
    id: string;
}
export declare const ResumeCampaignRequest: S.Schema<ResumeCampaignRequest>;
export interface ResumeCampaignResponse {
}
export declare const ResumeCampaignResponse: S.Schema<ResumeCampaignResponse>;
export interface StartCampaignRequest {
    id: string;
}
export declare const StartCampaignRequest: S.Schema<StartCampaignRequest>;
export interface StartCampaignResponse {
}
export declare const StartCampaignResponse: S.Schema<StartCampaignResponse>;
export interface StartInstanceOnboardingJobRequest {
    connectInstanceId: string;
    encryptionConfig: EncryptionConfig;
}
export declare const StartInstanceOnboardingJobRequest: S.Schema<StartInstanceOnboardingJobRequest>;
export interface StartInstanceOnboardingJobResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus;
}
export declare const StartInstanceOnboardingJobResponse: S.Schema<StartInstanceOnboardingJobResponse>;
export interface StopCampaignRequest {
    id: string;
}
export declare const StopCampaignRequest: S.Schema<StopCampaignRequest>;
export interface StopCampaignResponse {
}
export declare const StopCampaignResponse: S.Schema<StopCampaignResponse>;
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateCampaignChannelSubtypeConfigRequest {
    id: string;
    channelSubtypeConfig: ChannelSubtypeConfig;
}
export declare const UpdateCampaignChannelSubtypeConfigRequest: S.Schema<UpdateCampaignChannelSubtypeConfigRequest>;
export interface UpdateCampaignChannelSubtypeConfigResponse {
}
export declare const UpdateCampaignChannelSubtypeConfigResponse: S.Schema<UpdateCampaignChannelSubtypeConfigResponse>;
export interface UpdateCampaignCommunicationLimitsRequest {
    id: string;
    communicationLimitsOverride: CommunicationLimitsConfig;
}
export declare const UpdateCampaignCommunicationLimitsRequest: S.Schema<UpdateCampaignCommunicationLimitsRequest>;
export interface UpdateCampaignCommunicationLimitsResponse {
}
export declare const UpdateCampaignCommunicationLimitsResponse: S.Schema<UpdateCampaignCommunicationLimitsResponse>;
export interface UpdateCampaignCommunicationTimeRequest {
    id: string;
    communicationTimeConfig: CommunicationTimeConfig;
}
export declare const UpdateCampaignCommunicationTimeRequest: S.Schema<UpdateCampaignCommunicationTimeRequest>;
export interface UpdateCampaignCommunicationTimeResponse {
}
export declare const UpdateCampaignCommunicationTimeResponse: S.Schema<UpdateCampaignCommunicationTimeResponse>;
export interface UpdateCampaignEntryLimitsRequest {
    id: string;
    entryLimitsConfig: EntryLimitsConfig;
}
export declare const UpdateCampaignEntryLimitsRequest: S.Schema<UpdateCampaignEntryLimitsRequest>;
export interface UpdateCampaignEntryLimitsResponse {
}
export declare const UpdateCampaignEntryLimitsResponse: S.Schema<UpdateCampaignEntryLimitsResponse>;
export interface UpdateCampaignFlowAssociationRequest {
    id: string;
    connectCampaignFlowArn: string;
}
export declare const UpdateCampaignFlowAssociationRequest: S.Schema<UpdateCampaignFlowAssociationRequest>;
export interface UpdateCampaignFlowAssociationResponse {
}
export declare const UpdateCampaignFlowAssociationResponse: S.Schema<UpdateCampaignFlowAssociationResponse>;
export interface UpdateCampaignNameRequest {
    id: string;
    name: string;
}
export declare const UpdateCampaignNameRequest: S.Schema<UpdateCampaignNameRequest>;
export interface UpdateCampaignNameResponse {
}
export declare const UpdateCampaignNameResponse: S.Schema<UpdateCampaignNameResponse>;
export interface UpdateCampaignScheduleRequest {
    id: string;
    schedule: Schedule;
}
export declare const UpdateCampaignScheduleRequest: S.Schema<UpdateCampaignScheduleRequest>;
export interface UpdateCampaignScheduleResponse {
}
export declare const UpdateCampaignScheduleResponse: S.Schema<UpdateCampaignScheduleResponse>;
export interface UpdateCampaignSourceRequest {
    id: string;
    source: Source;
}
export declare const UpdateCampaignSourceRequest: S.Schema<UpdateCampaignSourceRequest>;
export interface UpdateCampaignSourceResponse {
}
export declare const UpdateCampaignSourceResponse: S.Schema<UpdateCampaignSourceResponse>;
export type XAmazonErrorType = string;
export type CreateCampaignError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a campaign for the specified Amazon Connect account. This API is idempotent.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a campaign from the specified Amazon Connect account.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignChannelSubtypeConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the channel subtype config of a campaign. This API is idempotent.
 */
export declare const deleteCampaignChannelSubtypeConfig: API.OperationMethod<DeleteCampaignChannelSubtypeConfigRequest, DeleteCampaignChannelSubtypeConfigResponse, DeleteCampaignChannelSubtypeConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignCommunicationLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the communication limits config for a campaign. This API is idempotent.
 */
export declare const deleteCampaignCommunicationLimits: API.OperationMethod<DeleteCampaignCommunicationLimitsRequest, DeleteCampaignCommunicationLimitsResponse, DeleteCampaignCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignCommunicationTimeError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the communication time config for a campaign. This API is idempotent.
 */
export declare const deleteCampaignCommunicationTime: API.OperationMethod<DeleteCampaignCommunicationTimeRequest, DeleteCampaignCommunicationTimeResponse, DeleteCampaignCommunicationTimeError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignEntryLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the entry limits config for a campaign. This API is idempotent.
 */
export declare const deleteCampaignEntryLimits: API.OperationMethod<DeleteCampaignEntryLimitsRequest, DeleteCampaignEntryLimitsResponse, DeleteCampaignEntryLimitsError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectInstanceConfigError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connect instance config from the specified AWS account.
 */
export declare const deleteConnectInstanceConfig: API.OperationMethod<DeleteConnectInstanceConfigRequest, DeleteConnectInstanceConfigResponse, DeleteConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectInstanceIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the integration for the specified Amazon Connect instance.
 */
export declare const deleteConnectInstanceIntegration: API.OperationMethod<DeleteConnectInstanceIntegrationRequest, DeleteConnectInstanceIntegrationResponse, DeleteConnectInstanceIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceOnboardingJobError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the Connect Campaigns onboarding job for the specified Amazon Connect instance.
 */
export declare const deleteInstanceOnboardingJob: API.OperationMethod<DeleteInstanceOnboardingJobRequest, DeleteInstanceOnboardingJobResponse, DeleteInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the specific campaign.
 */
export declare const describeCampaign: API.OperationMethod<DescribeCampaignRequest, DescribeCampaignResponse, DescribeCampaignError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of a campaign for the specified Amazon Connect account.
 */
export declare const getCampaignState: API.OperationMethod<GetCampaignStateRequest, GetCampaignStateResponse, GetCampaignStateError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateBatchError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of campaigns for the specified Amazon Connect account.
 */
export declare const getCampaignStateBatch: API.OperationMethod<GetCampaignStateBatchRequest, GetCampaignStateBatchResponse, GetCampaignStateBatchError, Credentials | HttpClient.HttpClient>;
export type GetConnectInstanceConfigError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific Connect instance config.
 */
export declare const getConnectInstanceConfig: API.OperationMethod<GetConnectInstanceConfigRequest, GetConnectInstanceConfigResponse, GetConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type GetInstanceCommunicationLimitsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the instance communication limits.
 */
export declare const getInstanceCommunicationLimits: API.OperationMethod<GetInstanceCommunicationLimitsRequest, GetInstanceCommunicationLimitsResponse, GetInstanceCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type GetInstanceOnboardingJobStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific instance onboarding job status.
 */
export declare const getInstanceOnboardingJobStatus: API.OperationMethod<GetInstanceOnboardingJobStatusRequest, GetInstanceOnboardingJobStatusResponse, GetInstanceOnboardingJobStatusError, Credentials | HttpClient.HttpClient>;
export type ListCampaignsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Provides summary information about the campaigns under the specified Amazon Connect account.
 */
export declare const listCampaigns: API.PaginatedOperationMethod<ListCampaignsRequest, ListCampaignsResponse, ListCampaignsError, Credentials | HttpClient.HttpClient, CampaignSummary>;
export type ListConnectInstanceIntegrationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides summary information about the integration under the specified Connect instance.
 */
export declare const listConnectInstanceIntegrations: API.PaginatedOperationMethod<ListConnectInstanceIntegrationsRequest, ListConnectInstanceIntegrationsResponse, ListConnectInstanceIntegrationsError, Credentials | HttpClient.HttpClient, IntegrationSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PauseCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Pauses a campaign for the specified Amazon Connect account.
 */
export declare const pauseCampaign: API.OperationMethod<PauseCampaignRequest, PauseCampaignResponse, PauseCampaignError, Credentials | HttpClient.HttpClient>;
export type PutConnectInstanceIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Put or update the integration for the specified Amazon Connect instance.
 */
export declare const putConnectInstanceIntegration: API.OperationMethod<PutConnectInstanceIntegrationRequest, PutConnectInstanceIntegrationResponse, PutConnectInstanceIntegrationError, Credentials | HttpClient.HttpClient>;
export type PutInstanceCommunicationLimitsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Put the instance communication limits. This API is idempotent.
 */
export declare const putInstanceCommunicationLimits: API.OperationMethod<PutInstanceCommunicationLimitsRequest, PutInstanceCommunicationLimitsResponse, PutInstanceCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type PutOutboundRequestBatchError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates outbound requests for the specified campaign Amazon Connect account. This API is idempotent.
 */
export declare const putOutboundRequestBatch: API.OperationMethod<PutOutboundRequestBatchRequest, PutOutboundRequestBatchResponse, PutOutboundRequestBatchError, Credentials | HttpClient.HttpClient>;
export type PutProfileOutboundRequestBatchError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Takes in a list of profile outbound requests to be placed as part of an outbound campaign. This API is idempotent.
 */
export declare const putProfileOutboundRequestBatch: API.OperationMethod<PutProfileOutboundRequestBatchRequest, PutProfileOutboundRequestBatchResponse, PutProfileOutboundRequestBatchError, Credentials | HttpClient.HttpClient>;
export type ResumeCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const resumeCampaign: API.OperationMethod<ResumeCampaignRequest, ResumeCampaignResponse, ResumeCampaignError, Credentials | HttpClient.HttpClient>;
export type StartCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a campaign for the specified Amazon Connect account.
 */
export declare const startCampaign: API.OperationMethod<StartCampaignRequest, StartCampaignResponse, StartCampaignError, Credentials | HttpClient.HttpClient>;
export type StartInstanceOnboardingJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Onboard the specific Amazon Connect instance to Connect Campaigns.
 */
export declare const startInstanceOnboardingJob: API.OperationMethod<StartInstanceOnboardingJobRequest, StartInstanceOnboardingJobResponse, StartInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type StopCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const stopCampaign: API.OperationMethod<StopCampaignRequest, StopCampaignResponse, StopCampaignError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignChannelSubtypeConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the channel subtype config of a campaign. This API is idempotent.
 */
export declare const updateCampaignChannelSubtypeConfig: API.OperationMethod<UpdateCampaignChannelSubtypeConfigRequest, UpdateCampaignChannelSubtypeConfigResponse, UpdateCampaignChannelSubtypeConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignCommunicationLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the communication limits config for a campaign. This API is idempotent.
 */
export declare const updateCampaignCommunicationLimits: API.OperationMethod<UpdateCampaignCommunicationLimitsRequest, UpdateCampaignCommunicationLimitsResponse, UpdateCampaignCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignCommunicationTimeError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the communication time config for a campaign. This API is idempotent.
 */
export declare const updateCampaignCommunicationTime: API.OperationMethod<UpdateCampaignCommunicationTimeRequest, UpdateCampaignCommunicationTimeResponse, UpdateCampaignCommunicationTimeError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignEntryLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the entry limits config for a campaign. This API is idempotent.
 */
export declare const updateCampaignEntryLimits: API.OperationMethod<UpdateCampaignEntryLimitsRequest, UpdateCampaignEntryLimitsResponse, UpdateCampaignEntryLimitsError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignFlowAssociationError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the campaign flow associated with a campaign. This API is idempotent.
 */
export declare const updateCampaignFlowAssociation: API.OperationMethod<UpdateCampaignFlowAssociationRequest, UpdateCampaignFlowAssociationResponse, UpdateCampaignFlowAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignNameError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the name of a campaign. This API is idempotent.
 */
export declare const updateCampaignName: API.OperationMethod<UpdateCampaignNameRequest, UpdateCampaignNameResponse, UpdateCampaignNameError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignScheduleError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the schedule for a campaign. This API is idempotent.
 */
export declare const updateCampaignSchedule: API.OperationMethod<UpdateCampaignScheduleRequest, UpdateCampaignScheduleResponse, UpdateCampaignScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignSourceError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the campaign source with a campaign. This API is idempotent.
 */
export declare const updateCampaignSource: API.OperationMethod<UpdateCampaignSourceRequest, UpdateCampaignSourceResponse, UpdateCampaignSourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connectcampaignsv2.d.ts.map