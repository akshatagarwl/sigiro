import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const AlreadyExistsException_base: S.Class<AlreadyExistsException, S.TaggedStruct<"AlreadyExistsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const ColumnStatisticsTaskNotRunningException_base: S.Class<ColumnStatisticsTaskNotRunningException, S.TaggedStruct<"ColumnStatisticsTaskNotRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ColumnStatisticsTaskNotRunningException extends /*@__PURE__*/ ColumnStatisticsTaskNotRunningException_base {
}
declare const ColumnStatisticsTaskRunningException_base: S.Class<ColumnStatisticsTaskRunningException, S.TaggedStruct<"ColumnStatisticsTaskRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ColumnStatisticsTaskRunningException extends /*@__PURE__*/ ColumnStatisticsTaskRunningException_base {
}
declare const ColumnStatisticsTaskStoppingException_base: S.Class<ColumnStatisticsTaskStoppingException, S.TaggedStruct<"ColumnStatisticsTaskStoppingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ColumnStatisticsTaskStoppingException extends /*@__PURE__*/ ColumnStatisticsTaskStoppingException_base {
}
declare const ConcurrentModificationException_base: S.Class<ConcurrentModificationException, S.TaggedStruct<"ConcurrentModificationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConcurrentRunsExceededException_base: S.Class<ConcurrentRunsExceededException, S.TaggedStruct<"ConcurrentRunsExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConcurrentRunsExceededException extends /*@__PURE__*/ ConcurrentRunsExceededException_base {
}
declare const ConditionCheckFailureException_base: S.Class<ConditionCheckFailureException, S.TaggedStruct<"ConditionCheckFailureException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConditionCheckFailureException extends /*@__PURE__*/ ConditionCheckFailureException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CrawlerNotRunningException_base: S.Class<CrawlerNotRunningException, S.TaggedStruct<"CrawlerNotRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CrawlerNotRunningException extends /*@__PURE__*/ CrawlerNotRunningException_base {
}
declare const CrawlerRunningException_base: S.Class<CrawlerRunningException, S.TaggedStruct<"CrawlerRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CrawlerRunningException extends /*@__PURE__*/ CrawlerRunningException_base {
}
declare const CrawlerStoppingException_base: S.Class<CrawlerStoppingException, S.TaggedStruct<"CrawlerStoppingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CrawlerStoppingException extends /*@__PURE__*/ CrawlerStoppingException_base {
}
declare const EntityNotFoundException_base: S.Class<EntityNotFoundException, S.TaggedStruct<"EntityNotFoundException", {
    readonly message: any;
    readonly FromFederationSource: any;
}>, import("effect/Cause").YieldableError>;
export declare class EntityNotFoundException extends /*@__PURE__*/ EntityNotFoundException_base {
}
declare const FederatedResourceAlreadyExistsException_base: S.Class<FederatedResourceAlreadyExistsException, S.TaggedStruct<"FederatedResourceAlreadyExistsException", {
    readonly message: any;
    readonly AssociatedGlueResource: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FederatedResourceAlreadyExistsException extends /*@__PURE__*/ FederatedResourceAlreadyExistsException_base {
}
declare const FederationSourceException_base: S.Class<FederationSourceException, S.TaggedStruct<"FederationSourceException", {
    readonly FederationSourceErrorCode: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FederationSourceException extends /*@__PURE__*/ FederationSourceException_base {
}
declare const FederationSourceRetryableException_base: S.Class<FederationSourceRetryableException, S.TaggedStruct<"FederationSourceRetryableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FederationSourceRetryableException extends /*@__PURE__*/ FederationSourceRetryableException_base {
}
declare const GlueEncryptionException_base: S.Class<GlueEncryptionException, S.TaggedStruct<"GlueEncryptionException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class GlueEncryptionException extends /*@__PURE__*/ GlueEncryptionException_base {
}
declare const GlueRoleNotAssumable_base: S.Class<GlueRoleNotAssumable, S.TaggedStruct<"GlueRoleNotAssumable", {
    readonly message: any;
    readonly FromFederationSource: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GlueRoleNotAssumable extends /*@__PURE__*/ GlueRoleNotAssumable_base {
}
declare const GlueS3TargetNotReady_base: S.Class<GlueS3TargetNotReady, S.TaggedStruct<"GlueS3TargetNotReady", {
    readonly message: any;
    readonly FromFederationSource: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class GlueS3TargetNotReady extends /*@__PURE__*/ GlueS3TargetNotReady_base {
}
declare const IdempotentParameterMismatchException_base: S.Class<IdempotentParameterMismatchException, S.TaggedStruct<"IdempotentParameterMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const IllegalBlueprintStateException_base: S.Class<IllegalBlueprintStateException, S.TaggedStruct<"IllegalBlueprintStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IllegalBlueprintStateException extends /*@__PURE__*/ IllegalBlueprintStateException_base {
}
declare const IllegalSessionStateException_base: S.Class<IllegalSessionStateException, S.TaggedStruct<"IllegalSessionStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IllegalSessionStateException extends /*@__PURE__*/ IllegalSessionStateException_base {
}
declare const IllegalWorkflowStateException_base: S.Class<IllegalWorkflowStateException, S.TaggedStruct<"IllegalWorkflowStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IllegalWorkflowStateException extends /*@__PURE__*/ IllegalWorkflowStateException_base {
}
declare const IntegrationConflictOperationFault_base: S.Class<IntegrationConflictOperationFault, S.TaggedStruct<"IntegrationConflictOperationFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IntegrationConflictOperationFault extends /*@__PURE__*/ IntegrationConflictOperationFault_base {
}
declare const IntegrationNotFoundFault_base: S.Class<IntegrationNotFoundFault, S.TaggedStruct<"IntegrationNotFoundFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IntegrationNotFoundFault extends /*@__PURE__*/ IntegrationNotFoundFault_base {
}
declare const IntegrationQuotaExceededFault_base: S.Class<IntegrationQuotaExceededFault, S.TaggedStruct<"IntegrationQuotaExceededFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class IntegrationQuotaExceededFault extends /*@__PURE__*/ IntegrationQuotaExceededFault_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InternalServiceException_base: S.Class<InternalServiceException, S.TaggedStruct<"InternalServiceException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidInputException_base: S.Class<InvalidInputException, S.TaggedStruct<"InvalidInputException", {
    readonly message: any;
    readonly FromFederationSource: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidIntegrationStateFault_base: S.Class<InvalidIntegrationStateFault, S.TaggedStruct<"InvalidIntegrationStateFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidIntegrationStateFault extends /*@__PURE__*/ InvalidIntegrationStateFault_base {
}
declare const InvalidStateException_base: S.Class<InvalidStateException, S.TaggedStruct<"InvalidStateException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const KMSKeyNotAccessibleFault_base: S.Class<KMSKeyNotAccessibleFault, S.TaggedStruct<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const MaterializedViewRefreshTaskNotRunningException_base: S.Class<MaterializedViewRefreshTaskNotRunningException, S.TaggedStruct<"MaterializedViewRefreshTaskNotRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaterializedViewRefreshTaskNotRunningException extends /*@__PURE__*/ MaterializedViewRefreshTaskNotRunningException_base {
}
declare const MaterializedViewRefreshTaskRunningException_base: S.Class<MaterializedViewRefreshTaskRunningException, S.TaggedStruct<"MaterializedViewRefreshTaskRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaterializedViewRefreshTaskRunningException extends /*@__PURE__*/ MaterializedViewRefreshTaskRunningException_base {
}
declare const MaterializedViewRefreshTaskStoppingException_base: S.Class<MaterializedViewRefreshTaskStoppingException, S.TaggedStruct<"MaterializedViewRefreshTaskStoppingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaterializedViewRefreshTaskStoppingException extends /*@__PURE__*/ MaterializedViewRefreshTaskStoppingException_base {
}
declare const MLTransformNotReadyException_base: S.Class<MLTransformNotReadyException, S.TaggedStruct<"MLTransformNotReadyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MLTransformNotReadyException extends /*@__PURE__*/ MLTransformNotReadyException_base {
}
declare const NoScheduleException_base: S.Class<NoScheduleException, S.TaggedStruct<"NoScheduleException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoScheduleException extends /*@__PURE__*/ NoScheduleException_base {
}
declare const OperationNotSupportedException_base: S.Class<OperationNotSupportedException, S.TaggedStruct<"OperationNotSupportedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OperationNotSupportedException extends /*@__PURE__*/ OperationNotSupportedException_base {
}
declare const OperationTimeoutException_base: S.Class<OperationTimeoutException, S.TaggedStruct<"OperationTimeoutException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OperationTimeoutException extends /*@__PURE__*/ OperationTimeoutException_base {
}
declare const PermissionTypeMismatchException_base: S.Class<PermissionTypeMismatchException, S.TaggedStruct<"PermissionTypeMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PermissionTypeMismatchException extends /*@__PURE__*/ PermissionTypeMismatchException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotReadyException_base: S.Class<ResourceNotReadyException, S.TaggedStruct<"ResourceNotReadyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const ResourceNumberLimitExceededException_base: S.Class<ResourceNumberLimitExceededException, S.TaggedStruct<"ResourceNumberLimitExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ResourceNumberLimitExceededException extends /*@__PURE__*/ ResourceNumberLimitExceededException_base {
}
declare const SchedulerNotRunningException_base: S.Class<SchedulerNotRunningException, S.TaggedStruct<"SchedulerNotRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SchedulerNotRunningException extends /*@__PURE__*/ SchedulerNotRunningException_base {
}
declare const SchedulerRunningException_base: S.Class<SchedulerRunningException, S.TaggedStruct<"SchedulerRunningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SchedulerRunningException extends /*@__PURE__*/ SchedulerRunningException_base {
}
declare const SchedulerTransitioningException_base: S.Class<SchedulerTransitioningException, S.TaggedStruct<"SchedulerTransitioningException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SchedulerTransitioningException extends /*@__PURE__*/ SchedulerTransitioningException_base {
}
declare const SessionBusyException_base: S.Class<SessionBusyException, S.TaggedStruct<"SessionBusyException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SessionBusyException extends /*@__PURE__*/ SessionBusyException_base {
}
declare const TargetResourceNotFound_base: S.Class<TargetResourceNotFound, S.TaggedStruct<"TargetResourceNotFound", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TargetResourceNotFound extends /*@__PURE__*/ TargetResourceNotFound_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const VersionMismatchException_base: S.Class<VersionMismatchException, S.TaggedStruct<"VersionMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VersionMismatchException extends /*@__PURE__*/ VersionMismatchException_base {
}
export type AssetId = string;
export type IterableFormName = string;
export type ItemIdentifier = string;
export type GlossaryTermId = string;
export type GlossaryTermIdList = string[];
export declare const GlossaryTermIdList: any;
export type HashString = string;
export interface AssociateGlossaryTermsRequest {
    AssetIdentifier: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
    GlossaryTermIdentifiers: string[];
    ClientToken?: string;
}
export declare const AssociateGlossaryTermsRequest: S.Schema<AssociateGlossaryTermsRequest>;
export interface AssociateGlossaryTermsResponse {
    AssetIdentifier?: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
    GlossaryTerms?: string[];
}
export declare const AssociateGlossaryTermsResponse: S.Schema<AssociateGlossaryTermsResponse>;
export type CatalogIdString = string;
export type NameString = string;
export type ValueString = string;
export type ValueStringList = string[];
export declare const ValueStringList: any;
export type ColumnTypeString = string;
export type CommentString = string;
export type KeyString = string;
export type ParametersMapValue = string;
export type ParametersMap = {
    [key: string]: string | undefined;
};
export declare const ParametersMap: any;
export interface Column {
    Name: string;
    Type?: string;
    Comment?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const Column: S.Schema<Column>;
export type ColumnList = Column[];
export declare const ColumnList: any;
export type LocationString = string;
export type LocationStringList = string[];
export declare const LocationStringList: any;
export type FormatString = string;
export interface SerDeInfo {
    Name?: string;
    SerializationLibrary?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const SerDeInfo: S.Schema<SerDeInfo>;
export type NameStringList = string[];
export declare const NameStringList: any;
export type IntegerFlag = number;
export interface Order {
    Column: string;
    SortOrder: number;
}
export declare const Order: S.Schema<Order>;
export type OrderList = Order[];
export declare const OrderList: any;
export type ColumnValuesString = string;
export type ColumnValueStringList = string[];
export declare const ColumnValueStringList: any;
export type LocationMap = {
    [key: string]: string | undefined;
};
export declare const LocationMap: any;
export interface SkewedInfo {
    SkewedColumnNames?: string[];
    SkewedColumnValues?: string[];
    SkewedColumnValueLocationMaps?: {
        [key: string]: string | undefined;
    };
}
export declare const SkewedInfo: S.Schema<SkewedInfo>;
export type GlueResourceArn = string;
export type SchemaRegistryNameString = string;
export interface SchemaId {
    SchemaArn?: string;
    SchemaName?: string;
    RegistryName?: string;
}
export declare const SchemaId: S.Schema<SchemaId>;
export type SchemaVersionIdString = string;
export type VersionLongNumber = number;
export interface SchemaReference {
    SchemaId?: SchemaId;
    SchemaVersionId?: string;
    SchemaVersionNumber?: number;
}
export declare const SchemaReference: S.Schema<SchemaReference>;
export interface StorageDescriptor {
    Columns?: Column[];
    Location?: string;
    AdditionalLocations?: string[];
    InputFormat?: string;
    OutputFormat?: string;
    Compressed?: boolean;
    NumberOfBuckets?: number;
    SerdeInfo?: SerDeInfo;
    BucketColumns?: string[];
    SortColumns?: Order[];
    Parameters?: {
        [key: string]: string | undefined;
    };
    SkewedInfo?: SkewedInfo;
    StoredAsSubDirectories?: boolean;
    SchemaReference?: SchemaReference;
}
export declare const StorageDescriptor: S.Schema<StorageDescriptor>;
export interface PartitionInput {
    Values?: string[];
    LastAccessTime?: Date;
    StorageDescriptor?: StorageDescriptor;
    Parameters?: {
        [key: string]: string | undefined;
    };
    LastAnalyzedTime?: Date;
}
export declare const PartitionInput: S.Schema<PartitionInput>;
export type PartitionInputList = PartitionInput[];
export declare const PartitionInputList: any;
export interface BatchCreatePartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionInputList: PartitionInput[];
}
export declare const BatchCreatePartitionRequest: S.Schema<BatchCreatePartitionRequest>;
export type DescriptionString = string;
export interface ErrorDetail {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const ErrorDetail: S.Schema<ErrorDetail>;
export interface PartitionError {
    PartitionValues?: string[];
    ErrorDetail?: ErrorDetail;
}
export declare const PartitionError: S.Schema<PartitionError>;
export type PartitionErrors = PartitionError[];
export declare const PartitionErrors: any;
export interface BatchCreatePartitionResponse {
    Errors?: PartitionError[];
}
export declare const BatchCreatePartitionResponse: S.Schema<BatchCreatePartitionResponse>;
export type DeleteConnectionNameList = string[];
export declare const DeleteConnectionNameList: any;
export interface BatchDeleteConnectionRequest {
    CatalogId?: string;
    ConnectionNameList: string[];
}
export declare const BatchDeleteConnectionRequest: S.Schema<BatchDeleteConnectionRequest>;
export type ErrorByName = {
    [key: string]: ErrorDetail | undefined;
};
export declare const ErrorByName: any;
export interface BatchDeleteConnectionResponse {
    Succeeded?: string[];
    Errors?: {
        [key: string]: ErrorDetail | undefined;
    };
}
export declare const BatchDeleteConnectionResponse: S.Schema<BatchDeleteConnectionResponse>;
export interface PartitionValueList {
    Values: string[];
}
export declare const PartitionValueList: S.Schema<PartitionValueList>;
export type BatchDeletePartitionValueList = PartitionValueList[];
export declare const BatchDeletePartitionValueList: any;
export interface BatchDeletePartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionsToDelete: PartitionValueList[];
}
export declare const BatchDeletePartitionRequest: S.Schema<BatchDeletePartitionRequest>;
export interface BatchDeletePartitionResponse {
    Errors?: PartitionError[];
}
export declare const BatchDeletePartitionResponse: S.Schema<BatchDeletePartitionResponse>;
export type BatchDeleteTableNameList = string[];
export declare const BatchDeleteTableNameList: any;
export type TransactionIdString = string;
export interface BatchDeleteTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    TablesToDelete: string[];
    TransactionId?: string;
}
export declare const BatchDeleteTableRequest: S.Schema<BatchDeleteTableRequest>;
export interface TableError {
    TableName?: string;
    ErrorDetail?: ErrorDetail;
}
export declare const TableError: S.Schema<TableError>;
export type TableErrors = TableError[];
export declare const TableErrors: any;
export interface BatchDeleteTableResponse {
    Errors?: TableError[];
}
export declare const BatchDeleteTableResponse: S.Schema<BatchDeleteTableResponse>;
export type VersionString = string;
export type BatchDeleteTableVersionList = string[];
export declare const BatchDeleteTableVersionList: any;
export interface BatchDeleteTableVersionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    VersionIds: string[];
}
export declare const BatchDeleteTableVersionRequest: S.Schema<BatchDeleteTableVersionRequest>;
export interface TableVersionError {
    TableName?: string;
    VersionId?: string;
    ErrorDetail?: ErrorDetail;
}
export declare const TableVersionError: S.Schema<TableVersionError>;
export type TableVersionErrors = TableVersionError[];
export declare const TableVersionErrors: any;
export interface BatchDeleteTableVersionResponse {
    Errors?: TableVersionError[];
}
export declare const BatchDeleteTableVersionResponse: S.Schema<BatchDeleteTableVersionResponse>;
export type OrchestrationNameString = string;
export type BatchGetBlueprintNames = string[];
export declare const BatchGetBlueprintNames: any;
export interface BatchGetBlueprintsRequest {
    Names: string[];
    IncludeBlueprint?: boolean;
    IncludeParameterSpec?: boolean;
}
export declare const BatchGetBlueprintsRequest: S.Schema<BatchGetBlueprintsRequest>;
export type Generic512CharString = string;
export type TimestampValue = Date;
export type BlueprintParameterSpec = string;
export type BlueprintStatus = "CREATING" | "ACTIVE" | "UPDATING" | "FAILED" | (string & {});
export declare const BlueprintStatus: any;
export type ErrorString = string;
export interface LastActiveDefinition {
    Description?: string;
    LastModifiedOn?: Date;
    ParameterSpec?: string;
    BlueprintLocation?: string;
    BlueprintServiceLocation?: string;
}
export declare const LastActiveDefinition: S.Schema<LastActiveDefinition>;
export interface Blueprint {
    Name?: string;
    Description?: string;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
    ParameterSpec?: string;
    BlueprintLocation?: string;
    BlueprintServiceLocation?: string;
    Status?: BlueprintStatus;
    ErrorMessage?: string;
    LastActiveDefinition?: LastActiveDefinition;
}
export declare const Blueprint: S.Schema<Blueprint>;
export type Blueprints = Blueprint[];
export declare const Blueprints: any;
export type BlueprintNames = string[];
export declare const BlueprintNames: any;
export interface BatchGetBlueprintsResponse {
    Blueprints?: Blueprint[];
    MissingBlueprints?: string[];
}
export declare const BatchGetBlueprintsResponse: S.Schema<BatchGetBlueprintsResponse>;
export type CrawlerNameList = string[];
export declare const CrawlerNameList: any;
export interface BatchGetCrawlersRequest {
    CrawlerNames: string[];
}
export declare const BatchGetCrawlersRequest: S.Schema<BatchGetCrawlersRequest>;
export type Role = string;
export type Path = string;
export type PathList = string[];
export declare const PathList: any;
export type ConnectionName = string;
export type EventQueueArn = string;
export interface S3Target {
    Path?: string;
    Exclusions?: string[];
    ConnectionName?: string;
    SampleSize?: number;
    EventQueueArn?: string;
    DlqEventQueueArn?: string;
}
export declare const S3Target: S.Schema<S3Target>;
export type S3TargetList = S3Target[];
export declare const S3TargetList: any;
export type JdbcMetadataEntry = "COMMENTS" | "RAWTYPES" | (string & {});
export declare const JdbcMetadataEntry: any;
export type EnableAdditionalMetadata = JdbcMetadataEntry[];
export declare const EnableAdditionalMetadata: any;
export interface JdbcTarget {
    ConnectionName?: string;
    Path?: string;
    Exclusions?: string[];
    EnableAdditionalMetadata?: JdbcMetadataEntry[];
}
export declare const JdbcTarget: S.Schema<JdbcTarget>;
export type JdbcTargetList = JdbcTarget[];
export declare const JdbcTargetList: any;
export interface MongoDBTarget {
    ConnectionName?: string;
    Path?: string;
    ScanAll?: boolean;
}
export declare const MongoDBTarget: S.Schema<MongoDBTarget>;
export type MongoDBTargetList = MongoDBTarget[];
export declare const MongoDBTargetList: any;
export interface DynamoDBTarget {
    Path?: string;
    scanAll?: boolean;
    scanRate?: number;
}
export declare const DynamoDBTarget: S.Schema<DynamoDBTarget>;
export type DynamoDBTargetList = DynamoDBTarget[];
export declare const DynamoDBTargetList: any;
export type CatalogTablesList = string[];
export declare const CatalogTablesList: any;
export interface CatalogTarget {
    DatabaseName: string;
    Tables: string[];
    ConnectionName?: string;
    EventQueueArn?: string;
    DlqEventQueueArn?: string;
}
export declare const CatalogTarget: S.Schema<CatalogTarget>;
export type CatalogTargetList = CatalogTarget[];
export declare const CatalogTargetList: any;
export interface DeltaTarget {
    DeltaTables?: string[];
    ConnectionName?: string;
    WriteManifest?: boolean;
    CreateNativeDeltaTable?: boolean;
}
export declare const DeltaTarget: S.Schema<DeltaTarget>;
export type DeltaTargetList = DeltaTarget[];
export declare const DeltaTargetList: any;
export interface IcebergTarget {
    Paths?: string[];
    ConnectionName?: string;
    Exclusions?: string[];
    MaximumTraversalDepth?: number;
}
export declare const IcebergTarget: S.Schema<IcebergTarget>;
export type IcebergTargetList = IcebergTarget[];
export declare const IcebergTargetList: any;
export interface HudiTarget {
    Paths?: string[];
    ConnectionName?: string;
    Exclusions?: string[];
    MaximumTraversalDepth?: number;
}
export declare const HudiTarget: S.Schema<HudiTarget>;
export type HudiTargetList = HudiTarget[];
export declare const HudiTargetList: any;
export interface CrawlerTargets {
    S3Targets?: S3Target[];
    JdbcTargets?: JdbcTarget[];
    MongoDBTargets?: MongoDBTarget[];
    DynamoDBTargets?: DynamoDBTarget[];
    CatalogTargets?: CatalogTarget[];
    DeltaTargets?: DeltaTarget[];
    IcebergTargets?: IcebergTarget[];
    HudiTargets?: HudiTarget[];
}
export declare const CrawlerTargets: S.Schema<CrawlerTargets>;
export type DatabaseName = string;
export type ClassifierNameList = string[];
export declare const ClassifierNameList: any;
export type RecrawlBehavior = "CRAWL_EVERYTHING" | "CRAWL_NEW_FOLDERS_ONLY" | "CRAWL_EVENT_MODE" | (string & {});
export declare const RecrawlBehavior: any;
export interface RecrawlPolicy {
    RecrawlBehavior?: RecrawlBehavior;
}
export declare const RecrawlPolicy: S.Schema<RecrawlPolicy>;
export type UpdateBehavior = "LOG" | "UPDATE_IN_DATABASE" | (string & {});
export declare const UpdateBehavior: any;
export type DeleteBehavior = "LOG" | "DELETE_FROM_DATABASE" | "DEPRECATE_IN_DATABASE" | (string & {});
export declare const DeleteBehavior: any;
export interface SchemaChangePolicy {
    UpdateBehavior?: UpdateBehavior;
    DeleteBehavior?: DeleteBehavior;
}
export declare const SchemaChangePolicy: S.Schema<SchemaChangePolicy>;
export type CrawlerLineageSettings = "ENABLE" | "DISABLE" | (string & {});
export declare const CrawlerLineageSettings: any;
export interface LineageConfiguration {
    CrawlerLineageSettings?: CrawlerLineageSettings;
}
export declare const LineageConfiguration: S.Schema<LineageConfiguration>;
export type CrawlerState = "READY" | "RUNNING" | "STOPPING" | (string & {});
export declare const CrawlerState: any;
export type TablePrefix = string;
export type CronExpression = string;
export type ScheduleState = "SCHEDULED" | "NOT_SCHEDULED" | "TRANSITIONING" | (string & {});
export declare const ScheduleState: any;
export interface Schedule {
    ScheduleExpression?: string;
    State?: ScheduleState;
}
export declare const Schedule: S.Schema<Schedule>;
export type MillisecondsCount = number;
export type LastCrawlStatus = "SUCCEEDED" | "CANCELLED" | "FAILED" | (string & {});
export declare const LastCrawlStatus: any;
export type LogGroup = string;
export type LogStream = string;
export type MessagePrefix = string;
export interface LastCrawlInfo {
    Status?: LastCrawlStatus;
    ErrorMessage?: string;
    LogGroup?: string;
    LogStream?: string;
    MessagePrefix?: string;
    StartTime?: Date;
}
export declare const LastCrawlInfo: S.Schema<LastCrawlInfo>;
export type VersionId = number;
export type CrawlerConfiguration = string;
export type CrawlerSecurityConfiguration = string;
export type AccountId = string;
export interface LakeFormationConfiguration {
    UseLakeFormationCredentials?: boolean;
    AccountId?: string;
}
export declare const LakeFormationConfiguration: S.Schema<LakeFormationConfiguration>;
export interface Crawler {
    Name?: string;
    Role?: string;
    Targets?: CrawlerTargets;
    DatabaseName?: string;
    Description?: string;
    Classifiers?: string[];
    RecrawlPolicy?: RecrawlPolicy;
    SchemaChangePolicy?: SchemaChangePolicy;
    LineageConfiguration?: LineageConfiguration;
    State?: CrawlerState;
    TablePrefix?: string;
    Schedule?: Schedule;
    CrawlElapsedTime?: number;
    CreationTime?: Date;
    LastUpdated?: Date;
    LastCrawl?: LastCrawlInfo;
    Version?: number;
    Configuration?: string;
    CrawlerSecurityConfiguration?: string;
    LakeFormationConfiguration?: LakeFormationConfiguration;
}
export declare const Crawler: S.Schema<Crawler>;
export type CrawlerList = Crawler[];
export declare const CrawlerList: any;
export interface BatchGetCrawlersResponse {
    Crawlers?: Crawler[];
    CrawlersNotFound?: string[];
}
export declare const BatchGetCrawlersResponse: S.Schema<BatchGetCrawlersResponse>;
export type CustomEntityTypeNames = string[];
export declare const CustomEntityTypeNames: any;
export interface BatchGetCustomEntityTypesRequest {
    Names: string[];
}
export declare const BatchGetCustomEntityTypesRequest: S.Schema<BatchGetCustomEntityTypesRequest>;
export type ContextWords = string[];
export declare const ContextWords: any;
export interface CustomEntityType {
    Name: string;
    RegexString: string;
    ContextWords?: string[];
}
export declare const CustomEntityType: S.Schema<CustomEntityType>;
export type CustomEntityTypes = CustomEntityType[];
export declare const CustomEntityTypes: any;
export interface BatchGetCustomEntityTypesResponse {
    CustomEntityTypes?: CustomEntityType[];
    CustomEntityTypesNotFound?: string[];
}
export declare const BatchGetCustomEntityTypesResponse: S.Schema<BatchGetCustomEntityTypesResponse>;
export type DataQualityResultIds = string[];
export declare const DataQualityResultIds: any;
export interface BatchGetDataQualityResultRequest {
    ResultIds: string[];
}
export declare const BatchGetDataQualityResultRequest: S.Schema<BatchGetDataQualityResultRequest>;
export type GenericBoundedDouble = number;
export type GlueTableAdditionalOptions = {
    [key: string]: string | undefined;
};
export declare const GlueTableAdditionalOptions: any;
export interface GlueTable {
    DatabaseName: string;
    TableName: string;
    CatalogId?: string;
    ConnectionName?: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
}
export declare const GlueTable: S.Schema<GlueTable>;
export type PreProcessingQueryString = string;
export interface DataQualityGlueTable {
    DatabaseName: string;
    TableName: string;
    CatalogId?: string;
    ConnectionName?: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    PreProcessingQuery?: string;
}
export declare const DataQualityGlueTable: S.Schema<DataQualityGlueTable>;
export interface DataSource {
    GlueTable?: GlueTable;
    DataQualityGlueTable?: DataQualityGlueTable;
}
export declare const DataSource: S.Schema<DataSource>;
export type DataQualityRuleResultDescription = string | redacted.Redacted<string>;
export type DataQualityRuleResultStatus = "PASS" | "FAIL" | "ERROR" | (string & {});
export declare const DataQualityRuleResultStatus: any;
export type EvaluatedMetricsMap = {
    [key: string]: number | undefined;
};
export declare const EvaluatedMetricsMap: any;
export type RuleMetricsMap = {
    [key: string]: number | undefined;
};
export declare const RuleMetricsMap: any;
export type Labels = {
    [key: string]: string | undefined;
};
export declare const Labels: any;
export interface DataQualityRuleResult {
    Name?: string;
    Description?: string | redacted.Redacted<string>;
    EvaluationMessage?: string | redacted.Redacted<string>;
    Result?: DataQualityRuleResultStatus;
    EvaluatedMetrics?: {
        [key: string]: number | undefined;
    };
    EvaluatedRule?: string | redacted.Redacted<string>;
    RuleMetrics?: {
        [key: string]: number | undefined;
    };
    Labels?: {
        [key: string]: string | undefined;
    };
}
export declare const DataQualityRuleResult: S.Schema<DataQualityRuleResult>;
export type DataQualityRuleResults = DataQualityRuleResult[];
export declare const DataQualityRuleResults: any;
export type BinEdges = string[];
export declare const BinEdges: any;
export type Count = number[];
export declare const Count: any;
export interface DistributionData {
    BinEdges?: string[];
    Count?: number[];
    DataType?: string;
}
export declare const DistributionData: S.Schema<DistributionData>;
export type EvaluatedDistributionsMap = {
    [key: string]: DistributionData | undefined;
};
export declare const EvaluatedDistributionsMap: any;
export interface DataQualityAnalyzerResult {
    Name?: string;
    Description?: string | redacted.Redacted<string>;
    EvaluationMessage?: string | redacted.Redacted<string>;
    EvaluatedMetrics?: {
        [key: string]: number | undefined;
    };
    EvaluatedDistributions?: {
        [key: string]: DistributionData | undefined;
    };
}
export declare const DataQualityAnalyzerResult: S.Schema<DataQualityAnalyzerResult>;
export type DataQualityAnalyzerResults = DataQualityAnalyzerResult[];
export declare const DataQualityAnalyzerResults: any;
export type DataQualityObservationDescription = string | redacted.Redacted<string>;
export interface DataQualityMetricValues {
    ActualValue?: number;
    ExpectedValue?: number;
    LowerLimit?: number;
    UpperLimit?: number;
}
export declare const DataQualityMetricValues: S.Schema<DataQualityMetricValues>;
export type NewRules = string[];
export declare const NewRules: any;
export interface MetricBasedObservation {
    MetricName?: string;
    StatisticId?: string;
    MetricValues?: DataQualityMetricValues;
    NewRules?: string[];
}
export declare const MetricBasedObservation: S.Schema<MetricBasedObservation>;
export interface DataQualityObservation {
    Description?: string | redacted.Redacted<string>;
    MetricBasedObservation?: MetricBasedObservation;
}
export declare const DataQualityObservation: S.Schema<DataQualityObservation>;
export type DataQualityObservations = DataQualityObservation[];
export declare const DataQualityObservations: any;
export interface DataQualityAggregatedMetrics {
    TotalRowsProcessed?: number;
    TotalRowsPassed?: number;
    TotalRowsFailed?: number;
    TotalRulesProcessed?: number;
    TotalRulesPassed?: number;
    TotalRulesFailed?: number;
}
export declare const DataQualityAggregatedMetrics: S.Schema<DataQualityAggregatedMetrics>;
export interface DataQualityResult {
    ResultId?: string;
    ProfileId?: string;
    Score?: number;
    DataSource?: DataSource;
    RulesetName?: string;
    EvaluationContext?: string;
    StartedOn?: Date;
    CompletedOn?: Date;
    JobName?: string;
    JobRunId?: string;
    RulesetEvaluationRunId?: string;
    RuleResults?: DataQualityRuleResult[];
    AnalyzerResults?: DataQualityAnalyzerResult[];
    Observations?: DataQualityObservation[];
    AggregatedMetrics?: DataQualityAggregatedMetrics;
}
export declare const DataQualityResult: S.Schema<DataQualityResult>;
export type DataQualityResultsList = DataQualityResult[];
export declare const DataQualityResultsList: any;
export interface BatchGetDataQualityResultResponse {
    Results: DataQualityResult[];
    ResultsNotFound?: string[];
}
export declare const BatchGetDataQualityResultResponse: S.Schema<BatchGetDataQualityResultResponse>;
export type DataQualityRulesetEvaluationRunIdList = string[];
export declare const DataQualityRulesetEvaluationRunIdList: any;
export interface BatchGetDataQualityRulesetEvaluationRunRequest {
    RunIds: string[];
}
export declare const BatchGetDataQualityRulesetEvaluationRunRequest: S.Schema<BatchGetDataQualityRulesetEvaluationRunRequest>;
export type RoleString = string;
export type Timeout = number;
export type UriString = string;
export type DQCompositeRuleEvaluationMethod = "COLUMN" | "ROW" | (string & {});
export declare const DQCompositeRuleEvaluationMethod: any;
export type ResultTypeEnum = "ALL" | "PASSED_ONLY" | "FAILED_ONLY" | (string & {});
export declare const ResultTypeEnum: any;
export interface CatalogTableConfigOptions {
    DatabaseName?: string;
    TableName?: string;
    S3Location?: string;
    CatalogId?: string;
}
export declare const CatalogTableConfigOptions: S.Schema<CatalogTableConfigOptions>;
export interface RowLevelResultsOptions {
    MaxRowsToWrite?: number;
    ResultType?: ResultTypeEnum;
    CatalogTableConfig?: CatalogTableConfigOptions;
}
export declare const RowLevelResultsOptions: S.Schema<RowLevelResultsOptions>;
export interface DistributionResultsOptions {
    WriteDistributionResultsEnabled?: boolean;
    CatalogTableConfig?: CatalogTableConfigOptions;
}
export declare const DistributionResultsOptions: S.Schema<DistributionResultsOptions>;
export interface ProfilingResultsOptions {
    WriteProfilingResultsEnabled?: boolean;
    CatalogTableConfig?: CatalogTableConfigOptions;
    DistributionResults?: DistributionResultsOptions;
}
export declare const ProfilingResultsOptions: S.Schema<ProfilingResultsOptions>;
export type ObservationConfiguration = "ALL" | "NONE" | (string & {});
export declare const ObservationConfiguration: any;
export type ObservationMode = "SCHEDULED" | "FIXED" | (string & {});
export declare const ObservationMode: any;
export interface DataQualityRuleResultsOptions {
    WriteDataQualityRuleResultsEnabled?: boolean;
    CatalogTableConfig?: CatalogTableConfigOptions;
}
export declare const DataQualityRuleResultsOptions: S.Schema<DataQualityRuleResultsOptions>;
export interface ObservationResultsOptions {
    WriteObservationResultsEnabled?: boolean;
    CatalogTableConfig?: CatalogTableConfigOptions;
}
export declare const ObservationResultsOptions: S.Schema<ObservationResultsOptions>;
export interface DataQualityEvaluationRunAdditionalRunOptions {
    CloudWatchMetricsEnabled?: boolean;
    ResultsS3Prefix?: string;
    CompositeRuleEvaluationMethod?: DQCompositeRuleEvaluationMethod;
    CustomLogGroupPrefix?: string;
    RowLevelResults?: RowLevelResultsOptions;
    ProfilingResults?: ProfilingResultsOptions;
    ObservationScope?: ObservationConfiguration;
    ObservationMode?: ObservationMode;
    DataQualityRuleResults?: DataQualityRuleResultsOptions;
    ObservationResults?: ObservationResultsOptions;
}
export declare const DataQualityEvaluationRunAdditionalRunOptions: S.Schema<DataQualityEvaluationRunAdditionalRunOptions>;
export type TaskStatusType = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | "SUCCEEDED" | "FAILED" | "TIMEOUT" | (string & {});
export declare const TaskStatusType: any;
export type ExecutionTime = number;
export type RulesetNames = string[];
export declare const RulesetNames: any;
export type DataQualityResultIdList = string[];
export declare const DataQualityResultIdList: any;
export type DataSourceMap = {
    [key: string]: DataSource | undefined;
};
export declare const DataSourceMap: any;
export interface DataQualityRulesetEvaluationRun {
    RunId?: string;
    DataSource?: DataSource;
    Role?: string;
    NumberOfWorkers?: number;
    Timeout?: number;
    AdditionalRunOptions?: DataQualityEvaluationRunAdditionalRunOptions;
    Status?: TaskStatusType;
    ErrorString?: string;
    StartedOn?: Date;
    LastModifiedOn?: Date;
    CompletedOn?: Date;
    ExecutionTime?: number;
    RulesetNames?: string[];
    ResultIds?: string[];
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    };
}
export declare const DataQualityRulesetEvaluationRun: S.Schema<DataQualityRulesetEvaluationRun>;
export type DataQualityRulesetEvaluationRunsList = DataQualityRulesetEvaluationRun[];
export declare const DataQualityRulesetEvaluationRunsList: any;
export interface BatchGetDataQualityRulesetEvaluationRunResponse {
    Runs?: DataQualityRulesetEvaluationRun[];
    RunsNotFound?: string[];
}
export declare const BatchGetDataQualityRulesetEvaluationRunResponse: S.Schema<BatchGetDataQualityRulesetEvaluationRunResponse>;
export type DevEndpointNames = string[];
export declare const DevEndpointNames: any;
export interface BatchGetDevEndpointsRequest {
    DevEndpointNames: string[];
}
export declare const BatchGetDevEndpointsRequest: S.Schema<BatchGetDevEndpointsRequest>;
export type RoleArn = string;
export type StringList = string[];
export declare const StringList: any;
export type IntegerValue = number;
export type WorkerType = "Standard" | "G.1X" | "G.2X" | "G.025X" | "G.4X" | "G.8X" | "Z.2X" | (string & {});
export declare const WorkerType: any;
export type GlueVersionString = string;
export type PublicKeysList = string[];
export declare const PublicKeysList: any;
export type MapValue = {
    [key: string]: string | undefined;
};
export declare const MapValue: any;
export interface DevEndpoint {
    EndpointName?: string;
    RoleArn?: string;
    SecurityGroupIds?: string[];
    SubnetId?: string;
    YarnEndpointAddress?: string;
    PrivateAddress?: string;
    ZeppelinRemoteSparkInterpreterPort?: number;
    PublicAddress?: string;
    Status?: string;
    WorkerType?: WorkerType;
    GlueVersion?: string;
    NumberOfWorkers?: number;
    NumberOfNodes?: number;
    AvailabilityZone?: string;
    VpcId?: string;
    ExtraPythonLibsS3Path?: string;
    ExtraJarsS3Path?: string;
    FailureReason?: string;
    LastUpdateStatus?: string;
    CreatedTimestamp?: Date;
    LastModifiedTimestamp?: Date;
    PublicKey?: string;
    PublicKeys?: string[];
    SecurityConfiguration?: string;
    Arguments?: {
        [key: string]: string | undefined;
    };
}
export declare const DevEndpoint: S.Schema<DevEndpoint>;
export type DevEndpointList = DevEndpoint[];
export declare const DevEndpointList: any;
export interface BatchGetDevEndpointsResponse {
    DevEndpoints?: DevEndpoint[];
    DevEndpointsNotFound?: string[];
}
export declare const BatchGetDevEndpointsResponse: S.Schema<BatchGetDevEndpointsResponse>;
export type ItemIdentifierList = string[];
export declare const ItemIdentifierList: any;
export interface BatchGetIterableFormsRequest {
    AssetIdentifier: string;
    IterableFormName: string;
    ItemIdentifiers: string[];
}
export declare const BatchGetIterableFormsRequest: S.Schema<BatchGetIterableFormsRequest>;
export type ItemId = string;
export type ItemName = string;
export type AssetFormKey = string;
export type FormTypeId = string;
export type FormContent = string;
export interface AssetFormEntry {
    FormTypeId?: string;
    Content?: string;
}
export declare const AssetFormEntry: S.Schema<AssetFormEntry>;
export type AssetFormMap = {
    [key: string]: AssetFormEntry | undefined;
};
export declare const AssetFormMap: any;
export interface IterableFormItem {
    ItemId?: string;
    ItemName?: string;
    GlossaryTerms?: string[];
    Forms?: {
        [key: string]: AssetFormEntry | undefined;
    };
    Attachments?: {
        [key: string]: AssetFormEntry | undefined;
    };
}
export declare const IterableFormItem: S.Schema<IterableFormItem>;
export type IterableFormItemList = IterableFormItem[];
export declare const IterableFormItemList: any;
export type ItemErrorCode = string;
export type ItemErrorMessage = string;
export interface ItemError {
    ItemIdentifier?: string;
    Code?: string;
    Message?: string;
}
export declare const ItemError: S.Schema<ItemError>;
export type ItemErrorList = ItemError[];
export declare const ItemErrorList: any;
export interface BatchGetIterableFormsResponse {
    Items?: IterableFormItem[];
    Errors?: ItemError[];
}
export declare const BatchGetIterableFormsResponse: S.Schema<BatchGetIterableFormsResponse>;
export type JobNameList = string[];
export declare const JobNameList: any;
export interface BatchGetJobsRequest {
    JobNames: string[];
}
export declare const BatchGetJobsRequest: S.Schema<BatchGetJobsRequest>;
export type JobMode = "SCRIPT" | "VISUAL" | "NOTEBOOK" | (string & {});
export declare const JobMode: any;
export type MaxConcurrentRuns = number;
export interface ExecutionProperty {
    MaxConcurrentRuns?: number;
}
export declare const ExecutionProperty: S.Schema<ExecutionProperty>;
export type ScriptLocationString = string;
export type PythonVersionString = string;
export type RuntimeNameString = string;
export interface JobCommand {
    Name?: string;
    ScriptLocation?: string;
    PythonVersion?: string;
    Runtime?: string;
}
export declare const JobCommand: S.Schema<JobCommand>;
export type GenericMap = {
    [key: string]: string | undefined;
};
export declare const GenericMap: any;
export type ConnectionString = string;
export type ConnectionStringList = string[];
export declare const ConnectionStringList: any;
export interface ConnectionsList {
    Connections?: string[];
}
export declare const ConnectionsList: S.Schema<ConnectionsList>;
export type MaxRetries = number;
export type NotifyDelayAfter = number;
export interface NotificationProperty {
    NotifyDelayAfter?: number;
}
export declare const NotificationProperty: S.Schema<NotificationProperty>;
export type NodeId = string;
export type NodeName = string;
export type EnclosedInStringProperty = string;
export type EnclosedInStringPropertyWithQuote = string;
export type GlueStudioColumnNameString = string;
export interface GlueStudioSchemaColumn {
    Name: string;
    Type?: string;
    GlueStudioType?: string;
}
export declare const GlueStudioSchemaColumn: S.Schema<GlueStudioSchemaColumn>;
export type GlueStudioSchemaColumnList = GlueStudioSchemaColumn[];
export declare const GlueStudioSchemaColumnList: any;
export interface GlueSchema {
    Columns?: GlueStudioSchemaColumn[];
}
export declare const GlueSchema: S.Schema<GlueSchema>;
export type GlueSchemas = GlueSchema[];
export declare const GlueSchemas: any;
export interface AthenaConnectorSource {
    Name: string;
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    ConnectionTable?: string;
    SchemaName: string;
    OutputSchemas?: GlueSchema[];
}
export declare const AthenaConnectorSource: S.Schema<AthenaConnectorSource>;
export type BoxedNonNegativeLong = number;
export type EnclosedInStringProperties = string[];
export declare const EnclosedInStringProperties: any;
export type JDBCDataType = "ARRAY" | "BIGINT" | "BINARY" | "BIT" | "BLOB" | "BOOLEAN" | "CHAR" | "CLOB" | "DATALINK" | "DATE" | "DECIMAL" | "DISTINCT" | "DOUBLE" | "FLOAT" | "INTEGER" | "JAVA_OBJECT" | "LONGNVARCHAR" | "LONGVARBINARY" | "LONGVARCHAR" | "NCHAR" | "NCLOB" | "NULL" | "NUMERIC" | "NVARCHAR" | "OTHER" | "REAL" | "REF" | "REF_CURSOR" | "ROWID" | "SMALLINT" | "SQLXML" | "STRUCT" | "TIME" | "TIME_WITH_TIMEZONE" | "TIMESTAMP" | "TIMESTAMP_WITH_TIMEZONE" | "TINYINT" | "VARBINARY" | "VARCHAR" | (string & {});
export declare const JDBCDataType: any;
export type GlueRecordType = "DATE" | "STRING" | "TIMESTAMP" | "INT" | "FLOAT" | "LONG" | "BIGDECIMAL" | "BYTE" | "SHORT" | "DOUBLE" | (string & {});
export declare const GlueRecordType: any;
export type JDBCDataTypeMapping = {
    [key in JDBCDataType]?: GlueRecordType;
};
export declare const JDBCDataTypeMapping: any;
export interface JDBCConnectorOptions {
    FilterPredicate?: string;
    PartitionColumn?: string;
    LowerBound?: number;
    UpperBound?: number;
    NumPartitions?: number;
    JobBookmarkKeys?: string[];
    JobBookmarkKeysSortOrder?: string;
    DataTypeMapping?: {
        [key: string]: GlueRecordType | undefined;
    };
}
export declare const JDBCConnectorOptions: S.Schema<JDBCConnectorOptions>;
export type SqlQuery = string;
export interface JDBCConnectorSource {
    Name: string;
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: JDBCConnectorOptions;
    ConnectionTable?: string;
    Query?: string;
    OutputSchemas?: GlueSchema[];
}
export declare const JDBCConnectorSource: S.Schema<JDBCConnectorSource>;
export type AdditionalOptions = {
    [key: string]: string | undefined;
};
export declare const AdditionalOptions: any;
export interface SparkConnectorSource {
    Name: string;
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const SparkConnectorSource: S.Schema<SparkConnectorSource>;
export interface CatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PartitionPredicate?: string;
    OutputSchemas?: GlueSchema[];
}
export declare const CatalogSource: S.Schema<CatalogSource>;
export interface RedshiftSource {
    Name: string;
    Database: string;
    Table: string;
    RedshiftTmpDir?: string;
    TmpDirIAMRole?: string;
}
export declare const RedshiftSource: S.Schema<RedshiftSource>;
export type BoxedLong = number;
export interface S3SourceAdditionalOptions {
    BoundedSize?: number;
    BoundedFiles?: number;
}
export declare const S3SourceAdditionalOptions: S.Schema<S3SourceAdditionalOptions>;
export interface S3CatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PartitionPredicate?: string;
    AdditionalOptions?: S3SourceAdditionalOptions;
}
export declare const S3CatalogSource: S.Schema<S3CatalogSource>;
export type CompressionType = "gzip" | "bzip2" | (string & {});
export declare const CompressionType: any;
export type BoxedBoolean = boolean;
export type BoxedNonNegativeInt = number;
export interface S3DirectSourceAdditionalOptions {
    BoundedSize?: number;
    BoundedFiles?: number;
    EnableSamplePath?: boolean;
    SamplePath?: string;
}
export declare const S3DirectSourceAdditionalOptions: S.Schema<S3DirectSourceAdditionalOptions>;
export type Separator = "comma" | "ctrla" | "pipe" | "semicolon" | "tab" | (string & {});
export declare const Separator: any;
export type QuoteChar = "quote" | "quillemet" | "single_quote" | "disabled" | (string & {});
export declare const QuoteChar: any;
export interface S3CsvSource {
    Name: string;
    Paths: string[];
    CompressionType?: CompressionType;
    Exclusions?: string[];
    GroupSize?: string;
    GroupFiles?: string;
    Recurse?: boolean;
    MaxBand?: number;
    MaxFilesInBand?: number;
    AdditionalOptions?: S3DirectSourceAdditionalOptions;
    Separator: Separator;
    Escaper?: string;
    QuoteChar: QuoteChar;
    Multiline?: boolean;
    WithHeader?: boolean;
    WriteHeader?: boolean;
    SkipFirst?: boolean;
    OptimizePerformance?: boolean;
    OutputSchemas?: GlueSchema[];
}
export declare const S3CsvSource: S.Schema<S3CsvSource>;
export interface S3JsonSource {
    Name: string;
    Paths: string[];
    CompressionType?: CompressionType;
    Exclusions?: string[];
    GroupSize?: string;
    GroupFiles?: string;
    Recurse?: boolean;
    MaxBand?: number;
    MaxFilesInBand?: number;
    AdditionalOptions?: S3DirectSourceAdditionalOptions;
    JsonPath?: string;
    Multiline?: boolean;
    OutputSchemas?: GlueSchema[];
}
export declare const S3JsonSource: S.Schema<S3JsonSource>;
export type ParquetCompressionType = "snappy" | "lzo" | "gzip" | "brotli" | "lz4" | "uncompressed" | "none" | (string & {});
export declare const ParquetCompressionType: any;
export interface S3ParquetSource {
    Name: string;
    Paths: string[];
    CompressionType?: ParquetCompressionType;
    Exclusions?: string[];
    GroupSize?: string;
    GroupFiles?: string;
    Recurse?: boolean;
    MaxBand?: number;
    MaxFilesInBand?: number;
    AdditionalOptions?: S3DirectSourceAdditionalOptions;
    OutputSchemas?: GlueSchema[];
}
export declare const S3ParquetSource: S.Schema<S3ParquetSource>;
export interface RelationalCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export declare const RelationalCatalogSource: S.Schema<RelationalCatalogSource>;
export interface DDBELTCatalogAdditionalOptions {
    DynamodbExport?: string;
    DynamodbUnnestDDBJson?: boolean;
}
export declare const DDBELTCatalogAdditionalOptions: S.Schema<DDBELTCatalogAdditionalOptions>;
export interface DynamoDBCatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PitrEnabled?: boolean;
    AdditionalOptions?: DDBELTCatalogAdditionalOptions;
}
export declare const DynamoDBCatalogSource: S.Schema<DynamoDBCatalogSource>;
export type OneInput = string[];
export declare const OneInput: any;
export interface JDBCConnectorTarget {
    Name: string;
    Inputs: string[];
    ConnectionName: string;
    ConnectionTable: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const JDBCConnectorTarget: S.Schema<JDBCConnectorTarget>;
export interface SparkConnectorTarget {
    Name: string;
    Inputs: string[];
    ConnectionName: string;
    ConnectorName: string;
    ConnectionType: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const SparkConnectorTarget: S.Schema<SparkConnectorTarget>;
export type GlueStudioPathList = string[][];
export declare const GlueStudioPathList: any;
export interface BasicCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Database: string;
    Table: string;
}
export declare const BasicCatalogTarget: S.Schema<BasicCatalogTarget>;
export type EnclosedInStringPropertiesMinOne = string[];
export declare const EnclosedInStringPropertiesMinOne: any;
export interface UpsertRedshiftTargetOptions {
    TableLocation?: string;
    ConnectionName?: string;
    UpsertKeys?: string[];
}
export declare const UpsertRedshiftTargetOptions: S.Schema<UpsertRedshiftTargetOptions>;
export interface RedshiftTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
    RedshiftTmpDir?: string;
    TmpDirIAMRole?: string;
    UpsertRedshiftOptions?: UpsertRedshiftTargetOptions;
}
export declare const RedshiftTarget: S.Schema<RedshiftTarget>;
export type UpdateCatalogBehavior = "UPDATE_IN_DATABASE" | "LOG" | (string & {});
export declare const UpdateCatalogBehavior: any;
export interface CatalogSchemaChangePolicy {
    EnableUpdateCatalog?: boolean;
    UpdateBehavior?: UpdateCatalogBehavior;
}
export declare const CatalogSchemaChangePolicy: S.Schema<CatalogSchemaChangePolicy>;
export interface AutoDataQuality {
    IsEnabled?: boolean;
    EvaluationContext?: string;
}
export declare const AutoDataQuality: S.Schema<AutoDataQuality>;
export interface S3CatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Table: string;
    Database: string;
    SchemaChangePolicy?: CatalogSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
}
export declare const S3CatalogTarget: S.Schema<S3CatalogTarget>;
export type NumberTargetPartitionsString = string;
export interface DirectSchemaChangePolicy {
    EnableUpdateCatalog?: boolean;
    UpdateBehavior?: UpdateCatalogBehavior;
    Table?: string;
    Database?: string;
}
export declare const DirectSchemaChangePolicy: S.Schema<DirectSchemaChangePolicy>;
export interface S3GlueParquetTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Path: string;
    Compression?: ParquetCompressionType;
    NumberTargetPartitions?: string;
    SchemaChangePolicy?: DirectSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
}
export declare const S3GlueParquetTarget: S.Schema<S3GlueParquetTarget>;
export type TargetFormat = "json" | "csv" | "avro" | "orc" | "parquet" | "hudi" | "delta" | "iceberg" | "hyper" | "xml" | (string & {});
export declare const TargetFormat: any;
export interface S3DirectTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Path: string;
    Compression?: string;
    NumberTargetPartitions?: string;
    Format: TargetFormat;
    SchemaChangePolicy?: DirectSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
    OutputSchemas?: GlueSchema[];
}
export declare const S3DirectTarget: S.Schema<S3DirectTarget>;
export interface Mapping {
    ToKey?: string;
    FromPath?: string[];
    FromType?: string;
    ToType?: string;
    Dropped?: boolean;
    Children?: Mapping[];
}
export declare const Mapping: S.Schema<Mapping>;
export type Mappings = Mapping[];
export declare const Mappings: S.Schema<Mappings>;
export interface ApplyMapping {
    Name: string;
    Inputs: string[];
    Mapping: Mapping[];
}
export declare const ApplyMapping: S.Schema<ApplyMapping>;
export interface SelectFields {
    Name: string;
    Inputs: string[];
    Paths: string[][];
}
export declare const SelectFields: S.Schema<SelectFields>;
export interface DropFields {
    Name: string;
    Inputs: string[];
    Paths: string[][];
}
export declare const DropFields: S.Schema<DropFields>;
export interface RenameField {
    Name: string;
    Inputs: string[];
    SourcePath: string[];
    TargetPath: string[];
}
export declare const RenameField: S.Schema<RenameField>;
export type Topk = number;
export type Prob = number;
export interface Spigot {
    Name: string;
    Inputs: string[];
    Path: string;
    Topk?: number;
    Prob?: number;
}
export declare const Spigot: S.Schema<Spigot>;
export type TwoInputs = string[];
export declare const TwoInputs: any;
export type JoinType = "equijoin" | "left" | "right" | "outer" | "leftsemi" | "leftanti" | (string & {});
export declare const JoinType: any;
export interface JoinColumn {
    From: string;
    Keys: string[][];
}
export declare const JoinColumn: S.Schema<JoinColumn>;
export type JoinColumns = JoinColumn[];
export declare const JoinColumns: any;
export interface Join {
    Name: string;
    Inputs: string[];
    JoinType: JoinType;
    Columns: JoinColumn[];
}
export declare const Join: S.Schema<Join>;
export interface SplitFields {
    Name: string;
    Inputs: string[];
    Paths: string[][];
}
export declare const SplitFields: S.Schema<SplitFields>;
export type NonNegativeInt = number;
export interface SelectFromCollection {
    Name: string;
    Inputs: string[];
    Index: number;
}
export declare const SelectFromCollection: S.Schema<SelectFromCollection>;
export interface FillMissingValues {
    Name: string;
    Inputs: string[];
    ImputedPath: string;
    FilledPath?: string;
}
export declare const FillMissingValues: S.Schema<FillMissingValues>;
export type FilterLogicalOperator = "AND" | "OR" | (string & {});
export declare const FilterLogicalOperator: any;
export type FilterOperation = "EQ" | "LT" | "GT" | "LTE" | "GTE" | "REGEX" | "ISNULL" | (string & {});
export declare const FilterOperation: any;
export type FilterValueType = "COLUMNEXTRACTED" | "CONSTANT" | (string & {});
export declare const FilterValueType: any;
export interface FilterValue {
    Type: FilterValueType;
    Value: string[];
}
export declare const FilterValue: S.Schema<FilterValue>;
export type FilterValues = FilterValue[];
export declare const FilterValues: any;
export interface FilterExpression {
    Operation: FilterOperation;
    Negated?: boolean;
    Values: FilterValue[];
}
export declare const FilterExpression: S.Schema<FilterExpression>;
export type FilterExpressions = FilterExpression[];
export declare const FilterExpressions: any;
export interface Filter {
    Name: string;
    Inputs: string[];
    LogicalOperator: FilterLogicalOperator;
    Filters: FilterExpression[];
}
export declare const Filter: S.Schema<Filter>;
export type ManyInputs = string[];
export declare const ManyInputs: any;
export type ExtendedString = string;
export interface CustomCode {
    Name: string;
    Inputs: string[];
    Code: string;
    ClassName: string;
    OutputSchemas?: GlueSchema[];
}
export declare const CustomCode: S.Schema<CustomCode>;
export interface SqlAlias {
    From: string;
    Alias: string;
}
export declare const SqlAlias: S.Schema<SqlAlias>;
export type SqlAliases = SqlAlias[];
export declare const SqlAliases: any;
export interface SparkSQL {
    Name: string;
    Inputs: string[];
    SqlQuery: string;
    SqlAliases: SqlAlias[];
    OutputSchemas?: GlueSchema[];
}
export declare const SparkSQL: S.Schema<SparkSQL>;
export type BoxedPositiveInt = number;
export type StartingPosition = "latest" | "trim_horizon" | "earliest" | "timestamp" | (string & {});
export declare const StartingPosition: any;
export type Iso8601DateTime = Date;
export interface KinesisStreamingSourceOptions {
    EndpointUrl?: string;
    StreamName?: string;
    Classification?: string;
    Delimiter?: string;
    StartingPosition?: StartingPosition;
    MaxFetchTimeInMs?: number;
    MaxFetchRecordsPerShard?: number;
    MaxRecordPerRead?: number;
    AddIdleTimeBetweenReads?: boolean;
    IdleTimeBetweenReadsInMs?: number;
    DescribeShardInterval?: number;
    NumRetries?: number;
    RetryIntervalMs?: number;
    MaxRetryIntervalMs?: number;
    AvoidEmptyBatches?: boolean;
    StreamArn?: string;
    RoleArn?: string;
    RoleSessionName?: string;
    AddRecordTimestamp?: string;
    EmitConsumerLagMetrics?: string;
    StartingTimestamp?: Date;
    FanoutConsumerARN?: string;
}
export declare const KinesisStreamingSourceOptions: S.Schema<KinesisStreamingSourceOptions>;
export type PollingTime = number;
export type PositiveLong = number;
export interface StreamingDataPreviewOptions {
    PollingTime?: number;
    RecordPollingLimit?: number;
}
export declare const StreamingDataPreviewOptions: S.Schema<StreamingDataPreviewOptions>;
export interface DirectKinesisSource {
    Name: string;
    WindowSize?: number;
    DetectSchema?: boolean;
    StreamingOptions?: KinesisStreamingSourceOptions;
    DataPreviewOptions?: StreamingDataPreviewOptions;
}
export declare const DirectKinesisSource: S.Schema<DirectKinesisSource>;
export interface KafkaStreamingSourceOptions {
    BootstrapServers?: string;
    SecurityProtocol?: string;
    ConnectionName?: string;
    TopicName?: string;
    Assign?: string;
    SubscribePattern?: string;
    Classification?: string;
    Delimiter?: string;
    StartingOffsets?: string;
    EndingOffsets?: string;
    PollTimeoutMs?: number;
    NumRetries?: number;
    RetryIntervalMs?: number;
    MaxOffsetsPerTrigger?: number;
    MinPartitions?: number;
    IncludeHeaders?: boolean;
    AddRecordTimestamp?: string;
    EmitConsumerLagMetrics?: string;
    StartingTimestamp?: Date;
}
export declare const KafkaStreamingSourceOptions: S.Schema<KafkaStreamingSourceOptions>;
export interface DirectKafkaSource {
    Name: string;
    StreamingOptions?: KafkaStreamingSourceOptions;
    WindowSize?: number;
    DetectSchema?: boolean;
    DataPreviewOptions?: StreamingDataPreviewOptions;
}
export declare const DirectKafkaSource: S.Schema<DirectKafkaSource>;
export interface CatalogKinesisSource {
    Name: string;
    WindowSize?: number;
    DetectSchema?: boolean;
    Table: string;
    Database: string;
    StreamingOptions?: KinesisStreamingSourceOptions;
    DataPreviewOptions?: StreamingDataPreviewOptions;
}
export declare const CatalogKinesisSource: S.Schema<CatalogKinesisSource>;
export interface CatalogKafkaSource {
    Name: string;
    WindowSize?: number;
    DetectSchema?: boolean;
    Table: string;
    Database: string;
    StreamingOptions?: KafkaStreamingSourceOptions;
    DataPreviewOptions?: StreamingDataPreviewOptions;
}
export declare const CatalogKafkaSource: S.Schema<CatalogKafkaSource>;
export interface NullCheckBoxList {
    IsEmpty?: boolean;
    IsNullString?: boolean;
    IsNegOne?: boolean;
}
export declare const NullCheckBoxList: S.Schema<NullCheckBoxList>;
export type GenericLimitedString = string;
export interface Datatype {
    Id: string;
    Label: string;
}
export declare const Datatype: S.Schema<Datatype>;
export interface NullValueField {
    Value: string;
    Datatype: Datatype;
}
export declare const NullValueField: S.Schema<NullValueField>;
export type NullValueFields = NullValueField[];
export declare const NullValueFields: any;
export interface DropNullFields {
    Name: string;
    Inputs: string[];
    NullCheckBoxList?: NullCheckBoxList;
    NullTextList?: NullValueField[];
}
export declare const DropNullFields: S.Schema<DropNullFields>;
export interface Merge {
    Name: string;
    Inputs: string[];
    Source: string;
    PrimaryKeys: string[][];
}
export declare const Merge: S.Schema<Merge>;
export type UnionType = "ALL" | "DISTINCT" | (string & {});
export declare const UnionType: any;
export interface Union {
    Name: string;
    Inputs: string[];
    UnionType: UnionType;
}
export declare const Union: S.Schema<Union>;
export type PiiType = "RowAudit" | "RowHashing" | "RowMasking" | "RowPartialMasking" | "ColumnAudit" | "ColumnHashing" | "ColumnMasking" | (string & {});
export declare const PiiType: any;
export type BoxedDoubleFraction = number;
export type MaskValue = string;
export interface PIIDetection {
    Name: string;
    Inputs: string[];
    PiiType: PiiType;
    EntityTypesToDetect: string[];
    OutputColumnName?: string;
    SampleFraction?: number;
    ThresholdFraction?: number;
    MaskValue?: string;
    RedactText?: string;
    RedactChar?: string;
    MatchPattern?: string;
    NumLeftCharsToExclude?: number;
    NumRightCharsToExclude?: number;
    DetectionParameters?: string;
    DetectionSensitivity?: string;
}
export declare const PIIDetection: S.Schema<PIIDetection>;
export type AggFunction = "avg" | "countDistinct" | "count" | "first" | "last" | "kurtosis" | "max" | "min" | "skewness" | "stddev_samp" | "stddev_pop" | "sum" | "sumDistinct" | "var_samp" | "var_pop" | (string & {});
export declare const AggFunction: any;
export interface AggregateOperation {
    Column: string[];
    AggFunc: AggFunction;
}
export declare const AggregateOperation: S.Schema<AggregateOperation>;
export type AggregateOperations = AggregateOperation[];
export declare const AggregateOperations: any;
export interface Aggregate {
    Name: string;
    Inputs: string[];
    Groups: string[][];
    Aggs: AggregateOperation[];
}
export declare const Aggregate: S.Schema<Aggregate>;
export type LimitedStringList = string[];
export declare const LimitedStringList: any;
export type LimitedPathList = string[][];
export declare const LimitedPathList: any;
export interface DropDuplicates {
    Name: string;
    Inputs: string[];
    Columns?: string[][];
}
export declare const DropDuplicates: S.Schema<DropDuplicates>;
export interface GovernedCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Table: string;
    Database: string;
    SchemaChangePolicy?: CatalogSchemaChangePolicy;
}
export declare const GovernedCatalogTarget: S.Schema<GovernedCatalogTarget>;
export interface GovernedCatalogSource {
    Name: string;
    Database: string;
    Table: string;
    PartitionPredicate?: string;
    AdditionalOptions?: S3SourceAdditionalOptions;
}
export declare const GovernedCatalogSource: S.Schema<GovernedCatalogSource>;
export interface MicrosoftSQLServerCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export declare const MicrosoftSQLServerCatalogSource: S.Schema<MicrosoftSQLServerCatalogSource>;
export interface MySQLCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export declare const MySQLCatalogSource: S.Schema<MySQLCatalogSource>;
export interface OracleSQLCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export declare const OracleSQLCatalogSource: S.Schema<OracleSQLCatalogSource>;
export interface PostgreSQLCatalogSource {
    Name: string;
    Database: string;
    Table: string;
}
export declare const PostgreSQLCatalogSource: S.Schema<PostgreSQLCatalogSource>;
export interface MicrosoftSQLServerCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export declare const MicrosoftSQLServerCatalogTarget: S.Schema<MicrosoftSQLServerCatalogTarget>;
export interface MySQLCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export declare const MySQLCatalogTarget: S.Schema<MySQLCatalogTarget>;
export interface OracleSQLCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export declare const OracleSQLCatalogTarget: S.Schema<OracleSQLCatalogTarget>;
export interface PostgreSQLCatalogTarget {
    Name: string;
    Inputs: string[];
    Database: string;
    Table: string;
}
export declare const PostgreSQLCatalogTarget: S.Schema<PostgreSQLCatalogTarget>;
export interface GroupFilters {
    GroupName: string;
    Filters: FilterExpression[];
    LogicalOperator: FilterLogicalOperator;
}
export declare const GroupFilters: S.Schema<GroupFilters>;
export type GroupFiltersList = GroupFilters[];
export declare const GroupFiltersList: any;
export interface Route {
    Name: string;
    Inputs: string[];
    GroupFiltersList: GroupFilters[];
}
export declare const Route: S.Schema<Route>;
export type ParamType = "str" | "int" | "float" | "complex" | "bool" | "list" | "null" | (string & {});
export declare const ParamType: any;
export interface TransformConfigParameter {
    Name: string;
    Type: ParamType;
    ValidationRule?: string;
    ValidationMessage?: string;
    Value?: string[];
    ListType?: ParamType;
    IsOptional?: boolean;
}
export declare const TransformConfigParameter: S.Schema<TransformConfigParameter>;
export type TransformConfigParameterList = TransformConfigParameter[];
export declare const TransformConfigParameterList: any;
export interface DynamicTransform {
    Name: string;
    TransformName: string;
    Inputs: string[];
    Parameters?: TransformConfigParameter[];
    FunctionName: string;
    Path: string;
    Version?: string;
    OutputSchemas?: GlueSchema[];
}
export declare const DynamicTransform: S.Schema<DynamicTransform>;
export type DQDLString = string;
export type DQTransformOutput = "PrimaryInput" | "EvaluationResults" | (string & {});
export declare const DQTransformOutput: any;
export interface DQResultsPublishingOptions {
    EvaluationContext?: string;
    ResultsS3Prefix?: string;
    CloudWatchMetricsEnabled?: boolean;
    ResultsPublishingEnabled?: boolean;
}
export declare const DQResultsPublishingOptions: S.Schema<DQResultsPublishingOptions>;
export type DQStopJobOnFailureTiming = "Immediate" | "AfterDataLoad" | (string & {});
export declare const DQStopJobOnFailureTiming: any;
export interface DQStopJobOnFailureOptions {
    StopJobOnFailureTiming?: DQStopJobOnFailureTiming;
}
export declare const DQStopJobOnFailureOptions: S.Schema<DQStopJobOnFailureOptions>;
export interface EvaluateDataQuality {
    Name: string;
    Inputs: string[];
    Ruleset: string;
    Output?: DQTransformOutput;
    PublishingOptions?: DQResultsPublishingOptions;
    StopJobOnFailureOptions?: DQStopJobOnFailureOptions;
}
export declare const EvaluateDataQuality: S.Schema<EvaluateDataQuality>;
export interface S3CatalogHudiSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalHudiOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const S3CatalogHudiSource: S.Schema<S3CatalogHudiSource>;
export interface CatalogHudiSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalHudiOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const CatalogHudiSource: S.Schema<CatalogHudiSource>;
export interface S3HudiSource {
    Name: string;
    Paths: string[];
    AdditionalHudiOptions?: {
        [key: string]: string | undefined;
    };
    AdditionalOptions?: S3DirectSourceAdditionalOptions;
    OutputSchemas?: GlueSchema[];
}
export declare const S3HudiSource: S.Schema<S3HudiSource>;
export interface S3HudiCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Table: string;
    Database: string;
    AdditionalOptions: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: CatalogSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
    OutputSchemas?: GlueSchema[];
}
export declare const S3HudiCatalogTarget: S.Schema<S3HudiCatalogTarget>;
export type HudiTargetCompressionType = "gzip" | "lzo" | "uncompressed" | "snappy" | (string & {});
export declare const HudiTargetCompressionType: any;
export interface S3HudiDirectTarget {
    Name: string;
    Inputs: string[];
    Path: string;
    Compression: HudiTargetCompressionType;
    NumberTargetPartitions?: string;
    PartitionKeys?: string[][];
    Format: TargetFormat;
    AdditionalOptions: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: DirectSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
}
export declare const S3HudiDirectTarget: S.Schema<S3HudiDirectTarget>;
export type JDBCConnectionType = "sqlserver" | "mysql" | "oracle" | "postgresql" | "redshift" | (string & {});
export declare const JDBCConnectionType: any;
export interface DirectJDBCSource {
    Name: string;
    Database: string;
    Table: string;
    ConnectionName: string;
    ConnectionType: JDBCConnectionType;
    RedshiftTmpDir?: string;
    OutputSchemas?: GlueSchema[];
}
export declare const DirectJDBCSource: S.Schema<DirectJDBCSource>;
export interface S3CatalogDeltaSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalDeltaOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const S3CatalogDeltaSource: S.Schema<S3CatalogDeltaSource>;
export interface CatalogDeltaSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalDeltaOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const CatalogDeltaSource: S.Schema<CatalogDeltaSource>;
export interface S3DeltaSource {
    Name: string;
    Paths: string[];
    AdditionalDeltaOptions?: {
        [key: string]: string | undefined;
    };
    AdditionalOptions?: S3DirectSourceAdditionalOptions;
    OutputSchemas?: GlueSchema[];
}
export declare const S3DeltaSource: S.Schema<S3DeltaSource>;
export interface S3DeltaCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Table: string;
    Database: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: CatalogSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
    OutputSchemas?: GlueSchema[];
}
export declare const S3DeltaCatalogTarget: S.Schema<S3DeltaCatalogTarget>;
export type DeltaTargetCompressionType = "uncompressed" | "snappy" | (string & {});
export declare const DeltaTargetCompressionType: any;
export interface S3DeltaDirectTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Path: string;
    Compression: DeltaTargetCompressionType;
    NumberTargetPartitions?: string;
    Format: TargetFormat;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: DirectSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
}
export declare const S3DeltaDirectTarget: S.Schema<S3DeltaDirectTarget>;
export interface Option {
    Value?: string;
    Label?: string;
    Description?: string;
}
export declare const Option: S.Schema<Option>;
export interface AmazonRedshiftAdvancedOption {
    Key?: string;
    Value?: string;
}
export declare const AmazonRedshiftAdvancedOption: S.Schema<AmazonRedshiftAdvancedOption>;
export type AmazonRedshiftAdvancedOptions = AmazonRedshiftAdvancedOption[];
export declare const AmazonRedshiftAdvancedOptions: any;
export type OptionList = Option[];
export declare const OptionList: any;
export interface AmazonRedshiftNodeData {
    AccessType?: string;
    SourceType?: string;
    Connection?: Option;
    Schema?: Option;
    Table?: Option;
    CatalogDatabase?: Option;
    CatalogTable?: Option;
    CatalogRedshiftSchema?: string;
    CatalogRedshiftTable?: string;
    TempDir?: string;
    IamRole?: Option;
    AdvancedOptions?: AmazonRedshiftAdvancedOption[];
    SampleQuery?: string;
    PreAction?: string;
    PostAction?: string;
    Action?: string;
    TablePrefix?: string;
    Upsert?: boolean;
    MergeAction?: string;
    MergeWhenMatched?: string;
    MergeWhenNotMatched?: string;
    MergeClause?: string;
    CrawlerConnection?: string;
    TableSchema?: Option[];
    StagingTable?: string;
    SelectedColumns?: Option[];
}
export declare const AmazonRedshiftNodeData: S.Schema<AmazonRedshiftNodeData>;
export interface AmazonRedshiftSource {
    Name?: string;
    Data?: AmazonRedshiftNodeData;
}
export declare const AmazonRedshiftSource: S.Schema<AmazonRedshiftSource>;
export interface AmazonRedshiftTarget {
    Name?: string;
    Data?: AmazonRedshiftNodeData;
    Inputs?: string[];
}
export declare const AmazonRedshiftTarget: S.Schema<AmazonRedshiftTarget>;
export type DQDLAliases = {
    [key: string]: string | undefined;
};
export declare const DQDLAliases: any;
export type AdditionalOptionKeys = "performanceTuning.caching" | "observations.scope" | "compositeRuleEvaluation.method" | (string & {});
export declare const AdditionalOptionKeys: any;
export type DQAdditionalOptions = {
    [key in AdditionalOptionKeys]?: string;
};
export declare const DQAdditionalOptions: any;
export interface EvaluateDataQualityMultiFrame {
    Name: string;
    Inputs: string[];
    AdditionalDataSources?: {
        [key: string]: string | undefined;
    };
    Ruleset: string;
    PublishingOptions?: DQResultsPublishingOptions;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    StopJobOnFailureOptions?: DQStopJobOnFailureOptions;
}
export declare const EvaluateDataQualityMultiFrame: S.Schema<EvaluateDataQualityMultiFrame>;
export type RecipeVersion = string;
export interface RecipeReference {
    RecipeArn: string;
    RecipeVersion: string;
}
export declare const RecipeReference: S.Schema<RecipeReference>;
export type Operation = string;
export type ParameterName = string;
export type ParameterValue = string;
export type ParameterMap = {
    [key: string]: string | undefined;
};
export declare const ParameterMap: any;
export interface RecipeAction {
    Operation: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
}
export declare const RecipeAction: S.Schema<RecipeAction>;
export type DatabrewCondition = string;
export type DatabrewConditionValue = string;
export type TargetColumn = string;
export interface ConditionExpression {
    Condition: string;
    Value?: string;
    TargetColumn: string;
}
export declare const ConditionExpression: S.Schema<ConditionExpression>;
export type ConditionExpressionList = ConditionExpression[];
export declare const ConditionExpressionList: any;
export interface RecipeStep {
    Action: RecipeAction;
    ConditionExpressions?: ConditionExpression[];
}
export declare const RecipeStep: S.Schema<RecipeStep>;
export type RecipeSteps = RecipeStep[];
export declare const RecipeSteps: any;
export interface Recipe {
    Name: string;
    Inputs: string[];
    RecipeReference?: RecipeReference;
    RecipeSteps?: RecipeStep[];
}
export declare const Recipe: S.Schema<Recipe>;
export interface SnowflakeNodeData {
    SourceType?: string;
    Connection?: Option;
    Schema?: string;
    Table?: string;
    Database?: string;
    TempDir?: string;
    IamRole?: Option;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    SampleQuery?: string;
    PreAction?: string;
    PostAction?: string;
    Action?: string;
    Upsert?: boolean;
    MergeAction?: string;
    MergeWhenMatched?: string;
    MergeWhenNotMatched?: string;
    MergeClause?: string;
    StagingTable?: string;
    SelectedColumns?: Option[];
    AutoPushdown?: boolean;
    TableSchema?: Option[];
}
export declare const SnowflakeNodeData: S.Schema<SnowflakeNodeData>;
export interface SnowflakeSource {
    Name: string;
    Data: SnowflakeNodeData;
    OutputSchemas?: GlueSchema[];
}
export declare const SnowflakeSource: S.Schema<SnowflakeSource>;
export interface SnowflakeTarget {
    Name: string;
    Data: SnowflakeNodeData;
    Inputs?: string[];
}
export declare const SnowflakeTarget: S.Schema<SnowflakeTarget>;
export type ConnectorOptions = {
    [key: string]: string | undefined;
};
export declare const ConnectorOptions: any;
export interface ConnectorDataSource {
    Name: string;
    ConnectionType: string;
    Data: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const ConnectorDataSource: S.Schema<ConnectorDataSource>;
export interface ConnectorDataTarget {
    Name: string;
    ConnectionType: string;
    Data: {
        [key: string]: string | undefined;
    };
    Inputs?: string[];
}
export declare const ConnectorDataTarget: S.Schema<ConnectorDataTarget>;
export interface S3CatalogIcebergSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalIcebergOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const S3CatalogIcebergSource: S.Schema<S3CatalogIcebergSource>;
export interface CatalogIcebergSource {
    Name: string;
    Database: string;
    Table: string;
    AdditionalIcebergOptions?: {
        [key: string]: string | undefined;
    };
    OutputSchemas?: GlueSchema[];
}
export declare const CatalogIcebergSource: S.Schema<CatalogIcebergSource>;
export interface S3IcebergCatalogTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Table: string;
    Database: string;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: CatalogSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
}
export declare const S3IcebergCatalogTarget: S.Schema<S3IcebergCatalogTarget>;
export type IcebergTargetCompressionType = "gzip" | "lzo" | "uncompressed" | "snappy" | (string & {});
export declare const IcebergTargetCompressionType: any;
export interface S3IcebergDirectTarget {
    Name: string;
    Inputs: string[];
    PartitionKeys?: string[][];
    Path: string;
    Format: TargetFormat;
    AdditionalOptions?: {
        [key: string]: string | undefined;
    };
    SchemaChangePolicy?: DirectSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
    Compression: IcebergTargetCompressionType;
    NumberTargetPartitions?: string;
    OutputSchemas?: GlueSchema[];
}
export declare const S3IcebergDirectTarget: S.Schema<S3IcebergDirectTarget>;
export interface S3ExcelSource {
    Name: string;
    Paths: string[];
    CompressionType?: ParquetCompressionType;
    Exclusions?: string[];
    GroupSize?: string;
    GroupFiles?: string;
    Recurse?: boolean;
    MaxBand?: number;
    MaxFilesInBand?: number;
    AdditionalOptions?: S3DirectSourceAdditionalOptions;
    NumberRows?: number;
    SkipFooter?: number;
    OutputSchemas?: GlueSchema[];
}
export declare const S3ExcelSource: S.Schema<S3ExcelSource>;
export type HyperTargetCompressionType = "uncompressed" | (string & {});
export declare const HyperTargetCompressionType: any;
export interface S3HyperDirectTarget {
    Name: string;
    Inputs: string[];
    Format?: TargetFormat;
    PartitionKeys?: string[][];
    Path: string;
    Compression?: HyperTargetCompressionType;
    SchemaChangePolicy?: DirectSchemaChangePolicy;
    AutoDataQuality?: AutoDataQuality;
    OutputSchemas?: GlueSchema[];
}
export declare const S3HyperDirectTarget: S.Schema<S3HyperDirectTarget>;
export type DdbExportType = "ddb" | "s3" | (string & {});
export declare const DdbExportType: any;
export interface DDBELTConnectionOptions {
    DynamodbExport?: DdbExportType;
    DynamodbUnnestDDBJson?: boolean;
    DynamodbTableArn: string;
    DynamodbS3Bucket?: string;
    DynamodbS3Prefix?: string;
    DynamodbS3BucketOwner?: string;
    DynamodbStsRoleArn?: string;
}
export declare const DDBELTConnectionOptions: S.Schema<DDBELTConnectionOptions>;
export interface DynamoDBELTConnectorSource {
    Name: string;
    ConnectionOptions?: DDBELTConnectionOptions;
    OutputSchemas?: GlueSchema[];
}
export declare const DynamoDBELTConnectorSource: S.Schema<DynamoDBELTConnectorSource>;
export interface CodeGenConfigurationNode {
    AthenaConnectorSource?: AthenaConnectorSource;
    JDBCConnectorSource?: JDBCConnectorSource;
    SparkConnectorSource?: SparkConnectorSource;
    CatalogSource?: CatalogSource;
    RedshiftSource?: RedshiftSource;
    S3CatalogSource?: S3CatalogSource;
    S3CsvSource?: S3CsvSource;
    S3JsonSource?: S3JsonSource;
    S3ParquetSource?: S3ParquetSource;
    RelationalCatalogSource?: RelationalCatalogSource;
    DynamoDBCatalogSource?: DynamoDBCatalogSource;
    JDBCConnectorTarget?: JDBCConnectorTarget;
    SparkConnectorTarget?: SparkConnectorTarget;
    CatalogTarget?: BasicCatalogTarget;
    RedshiftTarget?: RedshiftTarget;
    S3CatalogTarget?: S3CatalogTarget;
    S3GlueParquetTarget?: S3GlueParquetTarget;
    S3DirectTarget?: S3DirectTarget;
    ApplyMapping?: ApplyMapping;
    SelectFields?: SelectFields;
    DropFields?: DropFields;
    RenameField?: RenameField;
    Spigot?: Spigot;
    Join?: Join;
    SplitFields?: SplitFields;
    SelectFromCollection?: SelectFromCollection;
    FillMissingValues?: FillMissingValues;
    Filter?: Filter;
    CustomCode?: CustomCode;
    SparkSQL?: SparkSQL;
    DirectKinesisSource?: DirectKinesisSource;
    DirectKafkaSource?: DirectKafkaSource;
    CatalogKinesisSource?: CatalogKinesisSource;
    CatalogKafkaSource?: CatalogKafkaSource;
    DropNullFields?: DropNullFields;
    Merge?: Merge;
    Union?: Union;
    PIIDetection?: PIIDetection;
    Aggregate?: Aggregate;
    DropDuplicates?: DropDuplicates;
    GovernedCatalogTarget?: GovernedCatalogTarget;
    GovernedCatalogSource?: GovernedCatalogSource;
    MicrosoftSQLServerCatalogSource?: MicrosoftSQLServerCatalogSource;
    MySQLCatalogSource?: MySQLCatalogSource;
    OracleSQLCatalogSource?: OracleSQLCatalogSource;
    PostgreSQLCatalogSource?: PostgreSQLCatalogSource;
    MicrosoftSQLServerCatalogTarget?: MicrosoftSQLServerCatalogTarget;
    MySQLCatalogTarget?: MySQLCatalogTarget;
    OracleSQLCatalogTarget?: OracleSQLCatalogTarget;
    PostgreSQLCatalogTarget?: PostgreSQLCatalogTarget;
    Route?: Route;
    DynamicTransform?: DynamicTransform;
    EvaluateDataQuality?: EvaluateDataQuality;
    S3CatalogHudiSource?: S3CatalogHudiSource;
    CatalogHudiSource?: CatalogHudiSource;
    S3HudiSource?: S3HudiSource;
    S3HudiCatalogTarget?: S3HudiCatalogTarget;
    S3HudiDirectTarget?: S3HudiDirectTarget;
    DirectJDBCSource?: DirectJDBCSource;
    S3CatalogDeltaSource?: S3CatalogDeltaSource;
    CatalogDeltaSource?: CatalogDeltaSource;
    S3DeltaSource?: S3DeltaSource;
    S3DeltaCatalogTarget?: S3DeltaCatalogTarget;
    S3DeltaDirectTarget?: S3DeltaDirectTarget;
    AmazonRedshiftSource?: AmazonRedshiftSource;
    AmazonRedshiftTarget?: AmazonRedshiftTarget;
    EvaluateDataQualityMultiFrame?: EvaluateDataQualityMultiFrame;
    Recipe?: Recipe;
    SnowflakeSource?: SnowflakeSource;
    SnowflakeTarget?: SnowflakeTarget;
    ConnectorDataSource?: ConnectorDataSource;
    ConnectorDataTarget?: ConnectorDataTarget;
    S3CatalogIcebergSource?: S3CatalogIcebergSource;
    CatalogIcebergSource?: CatalogIcebergSource;
    S3IcebergCatalogTarget?: S3IcebergCatalogTarget;
    S3IcebergDirectTarget?: S3IcebergDirectTarget;
    S3ExcelSource?: S3ExcelSource;
    S3HyperDirectTarget?: S3HyperDirectTarget;
    DynamoDBELTConnectorSource?: DynamoDBELTConnectorSource;
}
export declare const CodeGenConfigurationNode: S.Schema<CodeGenConfigurationNode>;
export type CodeGenConfigurationNodes = {
    [key: string]: CodeGenConfigurationNode | undefined;
};
export declare const CodeGenConfigurationNodes: any;
export type ExecutionClass = "FLEX" | "STANDARD" | (string & {});
export declare const ExecutionClass: any;
export type SourceControlProvider = "GITHUB" | "GITLAB" | "BITBUCKET" | "AWS_CODE_COMMIT" | (string & {});
export declare const SourceControlProvider: any;
export type SourceControlAuthStrategy = "PERSONAL_ACCESS_TOKEN" | "AWS_SECRETS_MANAGER" | (string & {});
export declare const SourceControlAuthStrategy: any;
export interface SourceControlDetails {
    Provider?: SourceControlProvider;
    Repository?: string;
    Owner?: string;
    Branch?: string;
    Folder?: string;
    LastCommitId?: string;
    AuthStrategy?: SourceControlAuthStrategy;
    AuthToken?: string;
}
export declare const SourceControlDetails: S.Schema<SourceControlDetails>;
export type MaintenanceWindow = string;
export interface Job {
    Name?: string;
    JobMode?: JobMode;
    JobRunQueuingEnabled?: boolean;
    Description?: string;
    LogUri?: string;
    Role?: string;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
    ExecutionProperty?: ExecutionProperty;
    Command?: JobCommand;
    DefaultArguments?: {
        [key: string]: string | undefined;
    };
    NonOverridableArguments?: {
        [key: string]: string | undefined;
    };
    Connections?: ConnectionsList;
    MaxRetries?: number;
    AllocatedCapacity?: number;
    Timeout?: number;
    MaxCapacity?: number;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    SecurityConfiguration?: string;
    NotificationProperty?: NotificationProperty;
    GlueVersion?: string;
    CodeGenConfigurationNodes?: {
        [key: string]: CodeGenConfigurationNode | undefined;
    };
    ExecutionClass?: ExecutionClass;
    SourceControlDetails?: SourceControlDetails;
    MaintenanceWindow?: string;
    ProfileName?: string;
}
export declare const Job: S.Schema<Job>;
export type JobList = Job[];
export declare const JobList: any;
export interface BatchGetJobsResponse {
    Jobs?: Job[];
    JobsNotFound?: string[];
}
export declare const BatchGetJobsResponse: S.Schema<BatchGetJobsResponse>;
export type BatchGetPartitionValueList = PartitionValueList[];
export declare const BatchGetPartitionValueList: any;
export type AuditContextString = string;
export type ColumnNameString = string;
export type AuditColumnNamesList = string[];
export declare const AuditColumnNamesList: any;
export interface AuditContext {
    AdditionalAuditContext?: string;
    RequestedColumns?: string[];
    AllColumnsRequested?: boolean;
}
export declare const AuditContext: S.Schema<AuditContext>;
export type NullableString = string;
export type ContextKey = string;
export type ContextValue = string;
export type AdditionalContextMap = {
    [key: string]: string | undefined;
};
export declare const AdditionalContextMap: any;
export interface QuerySessionContext {
    QueryId?: string;
    QueryStartTime?: Date;
    ClusterId?: string;
    QueryAuthorizationId?: string;
    AdditionalContext?: {
        [key: string]: string | undefined;
    };
}
export declare const QuerySessionContext: S.Schema<QuerySessionContext>;
export interface BatchGetPartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionsToGet: PartitionValueList[];
    AuditContext?: AuditContext;
    QuerySessionContext?: QuerySessionContext;
}
export declare const BatchGetPartitionRequest: S.Schema<BatchGetPartitionRequest>;
export interface Partition {
    Values?: string[];
    DatabaseName?: string;
    TableName?: string;
    CreationTime?: Date;
    LastAccessTime?: Date;
    StorageDescriptor?: StorageDescriptor;
    Parameters?: {
        [key: string]: string | undefined;
    };
    LastAnalyzedTime?: Date;
    CatalogId?: string;
}
export declare const Partition: S.Schema<Partition>;
export type PartitionList = Partition[];
export declare const PartitionList: any;
export interface BatchGetPartitionResponse {
    Partitions?: Partition[];
    UnprocessedKeys?: PartitionValueList[];
}
export declare const BatchGetPartitionResponse: S.Schema<BatchGetPartitionResponse>;
export type DatabaseNameString = string;
export type TableNameString = string;
export type TableOptimizerType = "compaction" | "retention" | "orphan_file_deletion" | (string & {});
export declare const TableOptimizerType: any;
export interface BatchGetTableOptimizerEntry {
    catalogId?: string;
    databaseName?: string;
    tableName?: string;
    type?: TableOptimizerType;
}
export declare const BatchGetTableOptimizerEntry: S.Schema<BatchGetTableOptimizerEntry>;
export type BatchGetTableOptimizerEntries = BatchGetTableOptimizerEntry[];
export declare const BatchGetTableOptimizerEntries: any;
export interface BatchGetTableOptimizerRequest {
    Entries: BatchGetTableOptimizerEntry[];
}
export declare const BatchGetTableOptimizerRequest: S.Schema<BatchGetTableOptimizerRequest>;
export type ArnString = string;
export type GlueConnectionNameString = string;
export type TableOptimizerVpcConfiguration = {
    glueConnectionName: string;
};
export declare const TableOptimizerVpcConfiguration: any;
export type CompactionStrategy = "binpack" | "sort" | "z-order" | (string & {});
export declare const CompactionStrategy: any;
export interface IcebergCompactionConfiguration {
    strategy?: CompactionStrategy;
    minInputFiles?: number;
    deleteFileThreshold?: number;
}
export declare const IcebergCompactionConfiguration: S.Schema<IcebergCompactionConfiguration>;
export interface CompactionConfiguration {
    icebergConfiguration?: IcebergCompactionConfiguration;
}
export declare const CompactionConfiguration: S.Schema<CompactionConfiguration>;
export interface IcebergRetentionConfiguration {
    snapshotRetentionPeriodInDays?: number;
    numberOfSnapshotsToRetain?: number;
    cleanExpiredFiles?: boolean;
    runRateInHours?: number;
}
export declare const IcebergRetentionConfiguration: S.Schema<IcebergRetentionConfiguration>;
export interface RetentionConfiguration {
    icebergConfiguration?: IcebergRetentionConfiguration;
}
export declare const RetentionConfiguration: S.Schema<RetentionConfiguration>;
export type MessageString = string;
export interface IcebergOrphanFileDeletionConfiguration {
    orphanFileRetentionPeriodInDays?: number;
    location?: string;
    runRateInHours?: number;
}
export declare const IcebergOrphanFileDeletionConfiguration: S.Schema<IcebergOrphanFileDeletionConfiguration>;
export interface OrphanFileDeletionConfiguration {
    icebergConfiguration?: IcebergOrphanFileDeletionConfiguration;
}
export declare const OrphanFileDeletionConfiguration: S.Schema<OrphanFileDeletionConfiguration>;
export interface TableOptimizerConfiguration {
    roleArn?: string;
    enabled?: boolean;
    vpcConfiguration?: TableOptimizerVpcConfiguration;
    compactionConfiguration?: CompactionConfiguration;
    retentionConfiguration?: RetentionConfiguration;
    orphanFileDeletionConfiguration?: OrphanFileDeletionConfiguration;
}
export declare const TableOptimizerConfiguration: S.Schema<TableOptimizerConfiguration>;
export type TableOptimizerEventType = "starting" | "completed" | "failed" | "in_progress" | (string & {});
export declare const TableOptimizerEventType: any;
export type TableOptimizerRunTimestamp = Date;
export interface RunMetrics {
    NumberOfBytesCompacted?: string;
    NumberOfFilesCompacted?: string;
    NumberOfDpus?: string;
    JobDurationInHour?: string;
}
export declare const RunMetrics: S.Schema<RunMetrics>;
export type MetricCounts = number;
export type DpuHours = number;
export type DpuCounts = number;
export type DpuDurationInHour = number;
export interface IcebergCompactionMetrics {
    NumberOfBytesCompacted?: number;
    NumberOfFilesCompacted?: number;
    DpuHours?: number;
    NumberOfDpus?: number;
    JobDurationInHour?: number;
}
export declare const IcebergCompactionMetrics: S.Schema<IcebergCompactionMetrics>;
export interface CompactionMetrics {
    IcebergMetrics?: IcebergCompactionMetrics;
}
export declare const CompactionMetrics: S.Schema<CompactionMetrics>;
export interface IcebergRetentionMetrics {
    NumberOfDataFilesDeleted?: number;
    NumberOfManifestFilesDeleted?: number;
    NumberOfManifestListsDeleted?: number;
    DpuHours?: number;
    NumberOfDpus?: number;
    JobDurationInHour?: number;
}
export declare const IcebergRetentionMetrics: S.Schema<IcebergRetentionMetrics>;
export interface RetentionMetrics {
    IcebergMetrics?: IcebergRetentionMetrics;
}
export declare const RetentionMetrics: S.Schema<RetentionMetrics>;
export interface IcebergOrphanFileDeletionMetrics {
    NumberOfOrphanFilesDeleted?: number;
    DpuHours?: number;
    NumberOfDpus?: number;
    JobDurationInHour?: number;
}
export declare const IcebergOrphanFileDeletionMetrics: S.Schema<IcebergOrphanFileDeletionMetrics>;
export interface OrphanFileDeletionMetrics {
    IcebergMetrics?: IcebergOrphanFileDeletionMetrics;
}
export declare const OrphanFileDeletionMetrics: S.Schema<OrphanFileDeletionMetrics>;
export interface TableOptimizerRun {
    eventType?: TableOptimizerEventType;
    startTimestamp?: Date;
    endTimestamp?: Date;
    metrics?: RunMetrics;
    error?: string;
    compactionMetrics?: CompactionMetrics;
    compactionStrategy?: CompactionStrategy;
    retentionMetrics?: RetentionMetrics;
    orphanFileDeletionMetrics?: OrphanFileDeletionMetrics;
}
export declare const TableOptimizerRun: S.Schema<TableOptimizerRun>;
export type ConfigurationSource = "catalog" | "table" | (string & {});
export declare const ConfigurationSource: any;
export interface TableOptimizer {
    type?: TableOptimizerType;
    configuration?: TableOptimizerConfiguration;
    lastRun?: TableOptimizerRun;
    configurationSource?: ConfigurationSource;
}
export declare const TableOptimizer: S.Schema<TableOptimizer>;
export interface BatchTableOptimizer {
    catalogId?: string;
    databaseName?: string;
    tableName?: string;
    tableOptimizer?: TableOptimizer;
}
export declare const BatchTableOptimizer: S.Schema<BatchTableOptimizer>;
export type BatchTableOptimizers = BatchTableOptimizer[];
export declare const BatchTableOptimizers: any;
export interface BatchGetTableOptimizerError_ {
    error?: ErrorDetail;
    catalogId?: string;
    databaseName?: string;
    tableName?: string;
    type?: TableOptimizerType;
}
export declare const BatchGetTableOptimizerError_: S.Schema<BatchGetTableOptimizerError_>;
export type BatchGetTableOptimizerErrors = BatchGetTableOptimizerError_[];
export declare const BatchGetTableOptimizerErrors: any;
export interface BatchGetTableOptimizerResponse {
    TableOptimizers?: BatchTableOptimizer[];
    Failures?: BatchGetTableOptimizerError_[];
}
export declare const BatchGetTableOptimizerResponse: S.Schema<BatchGetTableOptimizerResponse>;
export type TriggerNameList = string[];
export declare const TriggerNameList: any;
export interface BatchGetTriggersRequest {
    TriggerNames: string[];
}
export declare const BatchGetTriggersRequest: S.Schema<BatchGetTriggersRequest>;
export type IdString = string;
export type TriggerType = "SCHEDULED" | "CONDITIONAL" | "ON_DEMAND" | "EVENT" | (string & {});
export declare const TriggerType: any;
export type TriggerState = "CREATING" | "CREATED" | "ACTIVATING" | "ACTIVATED" | "DEACTIVATING" | "DEACTIVATED" | "DELETING" | "UPDATING" | (string & {});
export declare const TriggerState: any;
export interface Action {
    JobName?: string;
    Arguments?: {
        [key: string]: string | undefined;
    };
    Timeout?: number;
    SecurityConfiguration?: string;
    NotificationProperty?: NotificationProperty;
    CrawlerName?: string;
}
export declare const Action: S.Schema<Action>;
export type ActionList = Action[];
export declare const ActionList: any;
export type Logical = "AND" | "ANY" | (string & {});
export declare const Logical: any;
export type LogicalOperator = "EQUALS" | (string & {});
export declare const LogicalOperator: any;
export type JobRunState = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | "SUCCEEDED" | "FAILED" | "TIMEOUT" | "ERROR" | "WAITING" | "EXPIRED" | (string & {});
export declare const JobRunState: any;
export type CrawlState = "RUNNING" | "CANCELLING" | "CANCELLED" | "SUCCEEDED" | "FAILED" | "ERROR" | (string & {});
export declare const CrawlState: any;
export interface Condition {
    LogicalOperator?: LogicalOperator;
    JobName?: string;
    State?: JobRunState;
    CrawlerName?: string;
    CrawlState?: CrawlState;
}
export declare const Condition: S.Schema<Condition>;
export type ConditionList = Condition[];
export declare const ConditionList: any;
export interface Predicate {
    Logical?: Logical;
    Conditions?: Condition[];
}
export declare const Predicate: S.Schema<Predicate>;
export type BatchSize = number;
export type BatchWindow = number;
export interface EventBatchingCondition {
    BatchSize: number;
    BatchWindow?: number;
}
export declare const EventBatchingCondition: S.Schema<EventBatchingCondition>;
export interface Trigger {
    Name?: string;
    WorkflowName?: string;
    Id?: string;
    Type?: TriggerType;
    State?: TriggerState;
    Description?: string;
    Schedule?: string;
    Actions?: Action[];
    Predicate?: Predicate;
    EventBatchingCondition?: EventBatchingCondition;
}
export declare const Trigger: S.Schema<Trigger>;
export type TriggerList = Trigger[];
export declare const TriggerList: any;
export interface BatchGetTriggersResponse {
    Triggers?: Trigger[];
    TriggersNotFound?: string[];
}
export declare const BatchGetTriggersResponse: S.Schema<BatchGetTriggersResponse>;
export type WorkflowNames = string[];
export declare const WorkflowNames: any;
export interface BatchGetWorkflowsRequest {
    Names: string[];
    IncludeGraph?: boolean;
}
export declare const BatchGetWorkflowsRequest: S.Schema<BatchGetWorkflowsRequest>;
export type WorkflowRunProperties = {
    [key: string]: string | undefined;
};
export declare const WorkflowRunProperties: any;
export type WorkflowRunStatus = "RUNNING" | "COMPLETED" | "STOPPING" | "STOPPED" | "ERROR" | (string & {});
export declare const WorkflowRunStatus: any;
export interface WorkflowRunStatistics {
    TotalActions?: number;
    TimeoutActions?: number;
    FailedActions?: number;
    StoppedActions?: number;
    SucceededActions?: number;
    RunningActions?: number;
    ErroredActions?: number;
    WaitingActions?: number;
}
export declare const WorkflowRunStatistics: S.Schema<WorkflowRunStatistics>;
export type NodeType = "CRAWLER" | "JOB" | "TRIGGER" | (string & {});
export declare const NodeType: any;
export interface TriggerNodeDetails {
    Trigger?: Trigger;
}
export declare const TriggerNodeDetails: S.Schema<TriggerNodeDetails>;
export type AttemptCount = number;
export interface Predecessor {
    JobName?: string;
    RunId?: string;
}
export declare const Predecessor: S.Schema<Predecessor>;
export type PredecessorList = Predecessor[];
export declare const PredecessorList: any;
export type OrchestrationMessageString = string;
export type OrchestrationPolicyJsonString = string;
export interface JobRun {
    Id?: string;
    Attempt?: number;
    PreviousRunId?: string;
    TriggerName?: string;
    JobName?: string;
    JobMode?: JobMode;
    JobRunQueuingEnabled?: boolean;
    StartedOn?: Date;
    LastModifiedOn?: Date;
    CompletedOn?: Date;
    JobRunState?: JobRunState;
    Arguments?: {
        [key: string]: string | undefined;
    };
    ErrorMessage?: string;
    PredecessorRuns?: Predecessor[];
    AllocatedCapacity?: number;
    ExecutionTime?: number;
    Timeout?: number;
    MaxCapacity?: number;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    SecurityConfiguration?: string;
    LogGroupName?: string;
    NotificationProperty?: NotificationProperty;
    GlueVersion?: string;
    DPUSeconds?: number;
    ExecutionClass?: ExecutionClass;
    MaintenanceWindow?: string;
    ProfileName?: string;
    StateDetail?: string;
    ExecutionRoleSessionPolicy?: string;
}
export declare const JobRun: S.Schema<JobRun>;
export type JobRunList = JobRun[];
export declare const JobRunList: any;
export interface JobNodeDetails {
    JobRuns?: JobRun[];
}
export declare const JobNodeDetails: S.Schema<JobNodeDetails>;
export interface Crawl {
    State?: CrawlState;
    StartedOn?: Date;
    CompletedOn?: Date;
    ErrorMessage?: string;
    LogGroup?: string;
    LogStream?: string;
}
export declare const Crawl: S.Schema<Crawl>;
export type CrawlList = Crawl[];
export declare const CrawlList: any;
export interface CrawlerNodeDetails {
    Crawls?: Crawl[];
}
export declare const CrawlerNodeDetails: S.Schema<CrawlerNodeDetails>;
export interface Node {
    Type?: NodeType;
    Name?: string;
    UniqueId?: string;
    TriggerDetails?: TriggerNodeDetails;
    JobDetails?: JobNodeDetails;
    CrawlerDetails?: CrawlerNodeDetails;
}
export declare const Node: S.Schema<Node>;
export type NodeList = Node[];
export declare const NodeList: any;
export interface Edge {
    SourceId?: string;
    DestinationId?: string;
}
export declare const Edge: S.Schema<Edge>;
export type EdgeList = Edge[];
export declare const EdgeList: any;
export interface WorkflowGraph {
    Nodes?: Node[];
    Edges?: Edge[];
}
export declare const WorkflowGraph: S.Schema<WorkflowGraph>;
export interface StartingEventBatchCondition {
    BatchSize?: number;
    BatchWindow?: number;
}
export declare const StartingEventBatchCondition: S.Schema<StartingEventBatchCondition>;
export interface WorkflowRun {
    Name?: string;
    WorkflowRunId?: string;
    PreviousRunId?: string;
    WorkflowRunProperties?: {
        [key: string]: string | undefined;
    };
    StartedOn?: Date;
    CompletedOn?: Date;
    Status?: WorkflowRunStatus;
    ErrorMessage?: string;
    Statistics?: WorkflowRunStatistics;
    Graph?: WorkflowGraph;
    StartingEventBatchCondition?: StartingEventBatchCondition;
}
export declare const WorkflowRun: S.Schema<WorkflowRun>;
export interface BlueprintDetails {
    BlueprintName?: string;
    RunId?: string;
}
export declare const BlueprintDetails: S.Schema<BlueprintDetails>;
export interface Workflow {
    Name?: string;
    Description?: string;
    DefaultRunProperties?: {
        [key: string]: string | undefined;
    };
    CreatedOn?: Date;
    LastModifiedOn?: Date;
    LastRun?: WorkflowRun;
    Graph?: WorkflowGraph;
    MaxConcurrentRuns?: number;
    BlueprintDetails?: BlueprintDetails;
}
export declare const Workflow: S.Schema<Workflow>;
export type Workflows = Workflow[];
export declare const Workflows: any;
export interface BatchGetWorkflowsResponse {
    Workflows?: Workflow[];
    MissingWorkflows?: string[];
}
export declare const BatchGetWorkflowsResponse: S.Schema<BatchGetWorkflowsResponse>;
export type InclusionAnnotationValue = "INCLUDE" | "EXCLUDE" | (string & {});
export declare const InclusionAnnotationValue: any;
export interface DatapointInclusionAnnotation {
    ProfileId?: string;
    StatisticId?: string;
    InclusionAnnotation?: InclusionAnnotationValue;
}
export declare const DatapointInclusionAnnotation: S.Schema<DatapointInclusionAnnotation>;
export type InclusionAnnotationList = DatapointInclusionAnnotation[];
export declare const InclusionAnnotationList: any;
export interface BatchPutDataQualityStatisticAnnotationRequest {
    InclusionAnnotations: DatapointInclusionAnnotation[];
    ClientToken?: string;
}
export declare const BatchPutDataQualityStatisticAnnotationRequest: S.Schema<BatchPutDataQualityStatisticAnnotationRequest>;
export interface AnnotationError {
    ProfileId?: string;
    StatisticId?: string;
    FailureReason?: string;
}
export declare const AnnotationError: S.Schema<AnnotationError>;
export type AnnotationErrorList = AnnotationError[];
export declare const AnnotationErrorList: any;
export interface BatchPutDataQualityStatisticAnnotationResponse {
    FailedInclusionAnnotations?: AnnotationError[];
}
export declare const BatchPutDataQualityStatisticAnnotationResponse: S.Schema<BatchPutDataQualityStatisticAnnotationResponse>;
export type BatchStopJobRunJobRunIdList = string[];
export declare const BatchStopJobRunJobRunIdList: any;
export interface BatchStopJobRunRequest {
    JobName: string;
    JobRunIds: string[];
}
export declare const BatchStopJobRunRequest: S.Schema<BatchStopJobRunRequest>;
export interface BatchStopJobRunSuccessfulSubmission {
    JobName?: string;
    JobRunId?: string;
}
export declare const BatchStopJobRunSuccessfulSubmission: S.Schema<BatchStopJobRunSuccessfulSubmission>;
export type BatchStopJobRunSuccessfulSubmissionList = BatchStopJobRunSuccessfulSubmission[];
export declare const BatchStopJobRunSuccessfulSubmissionList: any;
export interface BatchStopJobRunError_ {
    JobName?: string;
    JobRunId?: string;
    ErrorDetail?: ErrorDetail;
}
export declare const BatchStopJobRunError_: S.Schema<BatchStopJobRunError_>;
export type BatchStopJobRunErrorList = BatchStopJobRunError_[];
export declare const BatchStopJobRunErrorList: any;
export interface BatchStopJobRunResponse {
    SuccessfulSubmissions?: BatchStopJobRunSuccessfulSubmission[];
    Errors?: BatchStopJobRunError_[];
}
export declare const BatchStopJobRunResponse: S.Schema<BatchStopJobRunResponse>;
export type BoundedPartitionValueList = string[];
export declare const BoundedPartitionValueList: any;
export interface BatchUpdatePartitionRequestEntry {
    PartitionValueList: string[];
    PartitionInput: PartitionInput;
}
export declare const BatchUpdatePartitionRequestEntry: S.Schema<BatchUpdatePartitionRequestEntry>;
export type BatchUpdatePartitionRequestEntryList = BatchUpdatePartitionRequestEntry[];
export declare const BatchUpdatePartitionRequestEntryList: any;
export interface BatchUpdatePartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    Entries: BatchUpdatePartitionRequestEntry[];
}
export declare const BatchUpdatePartitionRequest: S.Schema<BatchUpdatePartitionRequest>;
export interface BatchUpdatePartitionFailureEntry {
    PartitionValueList?: string[];
    ErrorDetail?: ErrorDetail;
}
export declare const BatchUpdatePartitionFailureEntry: S.Schema<BatchUpdatePartitionFailureEntry>;
export type BatchUpdatePartitionFailureList = BatchUpdatePartitionFailureEntry[];
export declare const BatchUpdatePartitionFailureList: any;
export interface BatchUpdatePartitionResponse {
    Errors?: BatchUpdatePartitionFailureEntry[];
}
export declare const BatchUpdatePartitionResponse: S.Schema<BatchUpdatePartitionResponse>;
export interface CancelDataQualityRuleRecommendationRunRequest {
    RunId: string;
}
export declare const CancelDataQualityRuleRecommendationRunRequest: S.Schema<CancelDataQualityRuleRecommendationRunRequest>;
export interface CancelDataQualityRuleRecommendationRunResponse {
}
export declare const CancelDataQualityRuleRecommendationRunResponse: S.Schema<CancelDataQualityRuleRecommendationRunResponse>;
export interface CancelDataQualityRulesetEvaluationRunRequest {
    RunId: string;
}
export declare const CancelDataQualityRulesetEvaluationRunRequest: S.Schema<CancelDataQualityRulesetEvaluationRunRequest>;
export interface CancelDataQualityRulesetEvaluationRunResponse {
}
export declare const CancelDataQualityRulesetEvaluationRunResponse: S.Schema<CancelDataQualityRulesetEvaluationRunResponse>;
export interface CancelMLTaskRunRequest {
    TransformId: string;
    TaskRunId: string;
}
export declare const CancelMLTaskRunRequest: S.Schema<CancelMLTaskRunRequest>;
export interface CancelMLTaskRunResponse {
    TransformId?: string;
    TaskRunId?: string;
    Status?: TaskStatusType;
}
export declare const CancelMLTaskRunResponse: S.Schema<CancelMLTaskRunResponse>;
export interface CancelStatementRequest {
    SessionId: string;
    Id: number;
    RequestOrigin?: string;
}
export declare const CancelStatementRequest: S.Schema<CancelStatementRequest>;
export interface CancelStatementResponse {
}
export declare const CancelStatementResponse: S.Schema<CancelStatementResponse>;
export type DataFormat = "AVRO" | "JSON" | "PROTOBUF" | (string & {});
export declare const DataFormat: any;
export type SchemaDefinitionString = string;
export interface CheckSchemaVersionValidityInput {
    DataFormat: DataFormat;
    SchemaDefinition: string;
}
export declare const CheckSchemaVersionValidityInput: S.Schema<CheckSchemaVersionValidityInput>;
export type IsVersionValid = boolean;
export type SchemaValidationError = string;
export interface CheckSchemaVersionValidityResponse {
    Valid?: boolean;
    Error?: string;
}
export declare const CheckSchemaVersionValidityResponse: S.Schema<CheckSchemaVersionValidityResponse>;
export type OrchestrationS3Location = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export declare const TagsMap: any;
export interface CreateBlueprintRequest {
    Name: string;
    Description?: string;
    BlueprintLocation: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateBlueprintRequest: S.Schema<CreateBlueprintRequest>;
export interface CreateBlueprintResponse {
    Name?: string;
}
export declare const CreateBlueprintResponse: S.Schema<CreateBlueprintResponse>;
export type CatalogNameString = string;
export type FederationIdentifier = string;
export interface FederatedCatalog {
    Identifier?: string;
    ConnectionName?: string;
    ConnectionType?: string;
}
export declare const FederatedCatalog: S.Schema<FederatedCatalog>;
export type ResourceArnString = string;
export interface TargetRedshiftCatalog {
    CatalogArn: string;
}
export declare const TargetRedshiftCatalog: S.Schema<TargetRedshiftCatalog>;
export type IAMRoleArn = string;
export interface DataLakeAccessProperties {
    DataLakeAccess?: boolean;
    DataTransferRole?: string;
    KmsKey?: string;
    CatalogType?: string;
}
export declare const DataLakeAccessProperties: S.Schema<DataLakeAccessProperties>;
export interface IcebergOptimizationProperties {
    RoleArn?: string;
    Compaction?: {
        [key: string]: string | undefined;
    };
    Retention?: {
        [key: string]: string | undefined;
    };
    OrphanFileDeletion?: {
        [key: string]: string | undefined;
    };
}
export declare const IcebergOptimizationProperties: S.Schema<IcebergOptimizationProperties>;
export interface CatalogProperties {
    DataLakeAccessProperties?: DataLakeAccessProperties;
    IcebergOptimizationProperties?: IcebergOptimizationProperties;
    CustomProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const CatalogProperties: S.Schema<CatalogProperties>;
export type DataLakePrincipalString = string;
export interface DataLakePrincipal {
    DataLakePrincipalIdentifier?: string;
}
export declare const DataLakePrincipal: S.Schema<DataLakePrincipal>;
export type Permission = "ALL" | "SELECT" | "ALTER" | "DROP" | "DELETE" | "INSERT" | "CREATE_DATABASE" | "CREATE_TABLE" | "DATA_LOCATION_ACCESS" | (string & {});
export declare const Permission: any;
export type PermissionList = Permission[];
export declare const PermissionList: any;
export interface PrincipalPermissions {
    Principal?: DataLakePrincipal;
    Permissions?: Permission[];
}
export declare const PrincipalPermissions: S.Schema<PrincipalPermissions>;
export type PrincipalPermissionsList = PrincipalPermissions[];
export declare const PrincipalPermissionsList: any;
export type AllowFullTableExternalDataAccessEnum = "True" | "False" | (string & {});
export declare const AllowFullTableExternalDataAccessEnum: any;
export type OverwriteChildResourcePermissionsWithDefaultEnum = "Accept" | "Deny" | (string & {});
export declare const OverwriteChildResourcePermissionsWithDefaultEnum: any;
export interface CatalogInput {
    Description?: string;
    FederatedCatalog?: FederatedCatalog;
    Parameters?: {
        [key: string]: string | undefined;
    };
    TargetRedshiftCatalog?: TargetRedshiftCatalog;
    CatalogProperties?: CatalogProperties;
    CreateTableDefaultPermissions?: PrincipalPermissions[];
    CreateDatabaseDefaultPermissions?: PrincipalPermissions[];
    AllowFullTableExternalDataAccess?: AllowFullTableExternalDataAccessEnum;
    OverwriteChildResourcePermissionsWithDefault?: OverwriteChildResourcePermissionsWithDefaultEnum;
}
export declare const CatalogInput: S.Schema<CatalogInput>;
export interface CreateCatalogRequest {
    Name: string;
    CatalogInput: CatalogInput;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCatalogRequest: S.Schema<CreateCatalogRequest>;
export interface CreateCatalogResponse {
}
export declare const CreateCatalogResponse: S.Schema<CreateCatalogResponse>;
export type Classification = string;
export type GrokPattern = string;
export type CustomPatterns = string;
export interface CreateGrokClassifierRequest {
    Classification: string;
    Name: string;
    GrokPattern: string;
    CustomPatterns?: string;
}
export declare const CreateGrokClassifierRequest: S.Schema<CreateGrokClassifierRequest>;
export type RowTag = string;
export interface CreateXMLClassifierRequest {
    Classification: string;
    Name: string;
    RowTag?: string;
}
export declare const CreateXMLClassifierRequest: S.Schema<CreateXMLClassifierRequest>;
export type JsonPath = string;
export interface CreateJsonClassifierRequest {
    Name: string;
    JsonPath: string;
}
export declare const CreateJsonClassifierRequest: S.Schema<CreateJsonClassifierRequest>;
export type CsvColumnDelimiter = string;
export type CsvQuoteSymbol = string;
export type CsvHeaderOption = "UNKNOWN" | "PRESENT" | "ABSENT" | (string & {});
export declare const CsvHeaderOption: any;
export type CsvHeader = string[];
export declare const CsvHeader: any;
export type CustomDatatypes = string[];
export declare const CustomDatatypes: any;
export type CsvSerdeOption = "OpenCSVSerDe" | "LazySimpleSerDe" | "None" | (string & {});
export declare const CsvSerdeOption: any;
export interface CreateCsvClassifierRequest {
    Name: string;
    Delimiter?: string;
    QuoteSymbol?: string;
    ContainsHeader?: CsvHeaderOption;
    Header?: string[];
    DisableValueTrimming?: boolean;
    AllowSingleColumn?: boolean;
    CustomDatatypeConfigured?: boolean;
    CustomDatatypes?: string[];
    Serde?: CsvSerdeOption;
}
export declare const CreateCsvClassifierRequest: S.Schema<CreateCsvClassifierRequest>;
export interface CreateClassifierRequest {
    GrokClassifier?: CreateGrokClassifierRequest;
    XMLClassifier?: CreateXMLClassifierRequest;
    JsonClassifier?: CreateJsonClassifierRequest;
    CsvClassifier?: CreateCsvClassifierRequest;
}
export declare const CreateClassifierRequest: S.Schema<CreateClassifierRequest>;
export interface CreateClassifierResponse {
}
export declare const CreateClassifierResponse: S.Schema<CreateClassifierResponse>;
export type ColumnNameList = string[];
export declare const ColumnNameList: any;
export type SampleSizePercentage = number;
export interface CreateColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
    Role: string;
    Schedule?: string;
    ColumnNameList?: string[];
    SampleSize?: number;
    CatalogID?: string;
    SecurityConfiguration?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateColumnStatisticsTaskSettingsRequest: S.Schema<CreateColumnStatisticsTaskSettingsRequest>;
export interface CreateColumnStatisticsTaskSettingsResponse {
}
export declare const CreateColumnStatisticsTaskSettingsResponse: S.Schema<CreateColumnStatisticsTaskSettingsResponse>;
export type ConnectionType = "JDBC" | "SFTP" | "MONGODB" | "KAFKA" | "NETWORK" | "MARKETPLACE" | "CUSTOM" | "SALESFORCE" | "VIEW_VALIDATION_REDSHIFT" | "VIEW_VALIDATION_ATHENA" | "GOOGLEADS" | "GOOGLESHEETS" | "GOOGLEANALYTICS4" | "SERVICENOW" | "MARKETO" | "SAPODATA" | "ZENDESK" | "JIRACLOUD" | "NETSUITEERP" | "HUBSPOT" | "FACEBOOKADS" | "INSTAGRAMADS" | "ZOHOCRM" | "SALESFORCEPARDOT" | "SALESFORCEMARKETINGCLOUD" | "ADOBEANALYTICS" | "SLACK" | "LINKEDIN" | "MIXPANEL" | "ASANA" | "STRIPE" | "SMARTSHEET" | "DATADOG" | "WOOCOMMERCE" | "INTERCOM" | "SNAPCHATADS" | "PAYPAL" | "QUICKBOOKS" | "FACEBOOKPAGEINSIGHTS" | "FRESHDESK" | "TWILIO" | "DOCUSIGNMONITOR" | "FRESHSALES" | "ZOOM" | "GOOGLESEARCHCONSOLE" | "SALESFORCECOMMERCECLOUD" | "SAPCONCUR" | "DYNATRACE" | "MICROSOFTDYNAMIC365FINANCEANDOPS" | "MICROSOFTTEAMS" | "BLACKBAUDRAISEREDGENXT" | "MAILCHIMP" | "GITLAB" | "PENDO" | "PRODUCTBOARD" | "CIRCLECI" | "PIPEDIVE" | "SENDGRID" | "AZURECOSMOS" | "AZURESQL" | "BIGQUERY" | "BLACKBAUD" | "CLOUDERAHIVE" | "CLOUDERAIMPALA" | "CLOUDWATCH" | "CLOUDWATCHMETRICS" | "CMDB" | "DATALAKEGEN2" | "DB2" | "DB2AS400" | "DOCUMENTDB" | "DOMO" | "DYNAMODB" | "GOOGLECLOUDSTORAGE" | "HBASE" | "KUSTOMER" | "MICROSOFTDYNAMICS365CRM" | "MONDAY" | "MYSQL" | "OKTA" | "OPENSEARCH" | "ORACLE" | "PIPEDRIVE" | "POSTGRESQL" | "SAPHANA" | "SQLSERVER" | "SYNAPSE" | "TERADATA" | "TERADATANOS" | "TIMESTREAM" | "TPCDS" | "VERTICA" | (string & {});
export declare const ConnectionType: any;
export type MatchCriteria = string[];
export declare const MatchCriteria: any;
export type ConnectionPropertyKey = "HOST" | "PORT" | "USERNAME" | "PASSWORD" | "ENCRYPTED_PASSWORD" | "JDBC_DRIVER_JAR_URI" | "JDBC_DRIVER_CLASS_NAME" | "JDBC_ENGINE" | "JDBC_ENGINE_VERSION" | "CONFIG_FILES" | "INSTANCE_ID" | "JDBC_CONNECTION_URL" | "JDBC_ENFORCE_SSL" | "CUSTOM_JDBC_CERT" | "SKIP_CUSTOM_JDBC_CERT_VALIDATION" | "CUSTOM_JDBC_CERT_STRING" | "CONNECTION_URL" | "KAFKA_BOOTSTRAP_SERVERS" | "KAFKA_SSL_ENABLED" | "KAFKA_CUSTOM_CERT" | "KAFKA_SKIP_CUSTOM_CERT_VALIDATION" | "KAFKA_CLIENT_KEYSTORE" | "KAFKA_CLIENT_KEYSTORE_PASSWORD" | "KAFKA_CLIENT_KEY_PASSWORD" | "ENCRYPTED_KAFKA_CLIENT_KEYSTORE_PASSWORD" | "ENCRYPTED_KAFKA_CLIENT_KEY_PASSWORD" | "KAFKA_SASL_MECHANISM" | "KAFKA_SASL_PLAIN_USERNAME" | "KAFKA_SASL_PLAIN_PASSWORD" | "ENCRYPTED_KAFKA_SASL_PLAIN_PASSWORD" | "KAFKA_SASL_SCRAM_USERNAME" | "KAFKA_SASL_SCRAM_PASSWORD" | "KAFKA_SASL_SCRAM_SECRETS_ARN" | "ENCRYPTED_KAFKA_SASL_SCRAM_PASSWORD" | "KAFKA_SASL_GSSAPI_KEYTAB" | "KAFKA_SASL_GSSAPI_KRB5_CONF" | "KAFKA_SASL_GSSAPI_SERVICE" | "KAFKA_SASL_GSSAPI_PRINCIPAL" | "SECRET_ID" | "CONNECTOR_URL" | "CONNECTOR_TYPE" | "CONNECTOR_CLASS_NAME" | "ENDPOINT" | "ENDPOINT_TYPE" | "ROLE_ARN" | "REGION" | "WORKGROUP_NAME" | "CLUSTER_IDENTIFIER" | "DATABASE" | (string & {});
export declare const ConnectionPropertyKey: any;
export type ConnectionProperties = {
    [key in ConnectionPropertyKey]?: string;
};
export declare const ConnectionProperties: any;
export type PropertyKey = string;
export type PropertyValue = string;
export type PropertyMap = {
    [key: string]: string | undefined;
};
export declare const PropertyMap: any;
export type SecurityGroupIdList = string[];
export declare const SecurityGroupIdList: any;
export interface PhysicalConnectionRequirements {
    SubnetId?: string;
    SecurityGroupIdList?: string[];
    AvailabilityZone?: string;
}
export declare const PhysicalConnectionRequirements: S.Schema<PhysicalConnectionRequirements>;
export type AuthenticationType = "BASIC" | "OAUTH2" | "CUSTOM" | "IAM" | (string & {});
export declare const AuthenticationType: any;
export type OAuth2GrantType = "AUTHORIZATION_CODE" | "CLIENT_CREDENTIALS" | "JWT_BEARER" | (string & {});
export declare const OAuth2GrantType: any;
export type UserManagedClientApplicationClientId = string;
export type AWSManagedClientApplicationReference = string;
export interface OAuth2ClientApplication {
    UserManagedClientApplicationClientId?: string;
    AWSManagedClientApplicationReference?: string;
}
export declare const OAuth2ClientApplication: S.Schema<OAuth2ClientApplication>;
export type TokenUrl = string;
export type TokenUrlParameterKey = string;
export type TokenUrlParameterValue = string;
export type TokenUrlParametersMap = {
    [key: string]: string | undefined;
};
export declare const TokenUrlParametersMap: any;
export type AuthorizationCode = string | redacted.Redacted<string>;
export type RedirectUri = string;
export interface AuthorizationCodeProperties {
    AuthorizationCode?: string | redacted.Redacted<string>;
    RedirectUri?: string;
}
export declare const AuthorizationCodeProperties: S.Schema<AuthorizationCodeProperties>;
export type UserManagedClientApplicationClientSecret = string | redacted.Redacted<string>;
export type AccessToken = string | redacted.Redacted<string>;
export type RefreshToken = string | redacted.Redacted<string>;
export type JwtToken = string | redacted.Redacted<string>;
export interface OAuth2Credentials {
    UserManagedClientApplicationClientSecret?: string | redacted.Redacted<string>;
    AccessToken?: string | redacted.Redacted<string>;
    RefreshToken?: string | redacted.Redacted<string>;
    JwtToken?: string | redacted.Redacted<string>;
}
export declare const OAuth2Credentials: S.Schema<OAuth2Credentials>;
export interface OAuth2PropertiesInput {
    OAuth2GrantType?: OAuth2GrantType;
    OAuth2ClientApplication?: OAuth2ClientApplication;
    TokenUrl?: string;
    TokenUrlParametersMap?: {
        [key: string]: string | undefined;
    };
    AuthorizationCodeProperties?: AuthorizationCodeProperties;
    OAuth2Credentials?: OAuth2Credentials;
}
export declare const OAuth2PropertiesInput: S.Schema<OAuth2PropertiesInput>;
export type SecretArn = string;
export type KmsKeyArn = string;
export type Username = string;
export type Password = string | redacted.Redacted<string>;
export interface BasicAuthenticationCredentials {
    Username?: string;
    Password?: string | redacted.Redacted<string>;
}
export declare const BasicAuthenticationCredentials: S.Schema<BasicAuthenticationCredentials>;
export type CredentialKey = string;
export type CredentialValue = string;
export type CredentialMap = {
    [key: string]: string | undefined;
};
export declare const CredentialMap: any;
export interface AuthenticationConfigurationInput {
    AuthenticationType?: AuthenticationType;
    OAuth2Properties?: OAuth2PropertiesInput;
    SecretArn?: string;
    KmsKeyArn?: string;
    BasicAuthenticationCredentials?: BasicAuthenticationCredentials;
    CustomAuthenticationCredentials?: {
        [key: string]: string | undefined;
    };
}
export declare const AuthenticationConfigurationInput: S.Schema<AuthenticationConfigurationInput>;
export type ComputeEnvironment = "SPARK" | "ATHENA" | "PYTHON" | (string & {});
export declare const ComputeEnvironment: any;
export type ComputeEnvironmentList = ComputeEnvironment[];
export declare const ComputeEnvironmentList: any;
export interface ConnectionInput {
    Name: string;
    Description?: string;
    ConnectionType: ConnectionType;
    MatchCriteria?: string[];
    ConnectionProperties: {
        [key: string]: string | undefined;
    };
    SparkProperties?: {
        [key: string]: string | undefined;
    };
    AthenaProperties?: {
        [key: string]: string | undefined;
    };
    PythonProperties?: {
        [key: string]: string | undefined;
    };
    PhysicalConnectionRequirements?: PhysicalConnectionRequirements;
    AuthenticationConfiguration?: AuthenticationConfigurationInput;
    ValidateCredentials?: boolean;
    ValidateForComputeEnvironments?: ComputeEnvironment[];
}
export declare const ConnectionInput: S.Schema<ConnectionInput>;
export interface CreateConnectionRequest {
    CatalogId?: string;
    ConnectionInput: ConnectionInput;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateConnectionRequest: S.Schema<CreateConnectionRequest>;
export type ConnectionStatus = "READY" | "IN_PROGRESS" | "FAILED" | (string & {});
export declare const ConnectionStatus: any;
export interface CreateConnectionResponse {
    CreateConnectionStatus?: ConnectionStatus;
}
export declare const CreateConnectionResponse: S.Schema<CreateConnectionResponse>;
export interface CreateCrawlerRequest {
    Name: string;
    Role: string;
    DatabaseName?: string;
    Description?: string;
    Targets: CrawlerTargets;
    Schedule?: string;
    Classifiers?: string[];
    TablePrefix?: string;
    SchemaChangePolicy?: SchemaChangePolicy;
    RecrawlPolicy?: RecrawlPolicy;
    LineageConfiguration?: LineageConfiguration;
    LakeFormationConfiguration?: LakeFormationConfiguration;
    Configuration?: string;
    CrawlerSecurityConfiguration?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCrawlerRequest: S.Schema<CreateCrawlerRequest>;
export interface CreateCrawlerResponse {
}
export declare const CreateCrawlerResponse: S.Schema<CreateCrawlerResponse>;
export interface CreateCustomEntityTypeRequest {
    Name: string;
    RegexString: string;
    ContextWords?: string[];
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateCustomEntityTypeRequest: S.Schema<CreateCustomEntityTypeRequest>;
export interface CreateCustomEntityTypeResponse {
    Name?: string;
}
export declare const CreateCustomEntityTypeResponse: S.Schema<CreateCustomEntityTypeResponse>;
export type URI = string;
export interface DatabaseIdentifier {
    CatalogId?: string;
    DatabaseName?: string;
    Region?: string;
}
export declare const DatabaseIdentifier: S.Schema<DatabaseIdentifier>;
export interface FederatedDatabase {
    Identifier?: string;
    ConnectionName?: string;
    ConnectionType?: string;
}
export declare const FederatedDatabase: S.Schema<FederatedDatabase>;
export interface DatabaseInput {
    Name: string;
    Description?: string;
    LocationUri?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    CreateTableDefaultPermissions?: PrincipalPermissions[];
    TargetDatabase?: DatabaseIdentifier;
    FederatedDatabase?: FederatedDatabase;
}
export declare const DatabaseInput: S.Schema<DatabaseInput>;
export interface CreateDatabaseRequest {
    CatalogId?: string;
    DatabaseInput: DatabaseInput;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDatabaseRequest: S.Schema<CreateDatabaseRequest>;
export interface CreateDatabaseResponse {
}
export declare const CreateDatabaseResponse: S.Schema<CreateDatabaseResponse>;
export type DataQualityRulesetString = string;
export interface DataQualityTargetTable {
    TableName: string;
    DatabaseName: string;
    CatalogId?: string;
}
export declare const DataQualityTargetTable: S.Schema<DataQualityTargetTable>;
export interface CreateDataQualityRulesetRequest {
    Name: string;
    Description?: string;
    Ruleset: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    TargetTable?: DataQualityTargetTable;
    DataQualitySecurityConfiguration?: string;
    ClientToken?: string;
}
export declare const CreateDataQualityRulesetRequest: S.Schema<CreateDataQualityRulesetRequest>;
export interface CreateDataQualityRulesetResponse {
    Name?: string;
}
export declare const CreateDataQualityRulesetResponse: S.Schema<CreateDataQualityRulesetResponse>;
export interface CreateDevEndpointRequest {
    EndpointName: string;
    RoleArn: string;
    SecurityGroupIds?: string[];
    SubnetId?: string;
    PublicKey?: string;
    PublicKeys?: string[];
    NumberOfNodes?: number;
    WorkerType?: WorkerType;
    GlueVersion?: string;
    NumberOfWorkers?: number;
    ExtraPythonLibsS3Path?: string;
    ExtraJarsS3Path?: string;
    SecurityConfiguration?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    Arguments?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDevEndpointRequest: S.Schema<CreateDevEndpointRequest>;
export interface CreateDevEndpointResponse {
    EndpointName?: string;
    Status?: string;
    SecurityGroupIds?: string[];
    SubnetId?: string;
    RoleArn?: string;
    YarnEndpointAddress?: string;
    ZeppelinRemoteSparkInterpreterPort?: number;
    NumberOfNodes?: number;
    WorkerType?: WorkerType;
    GlueVersion?: string;
    NumberOfWorkers?: number;
    AvailabilityZone?: string;
    VpcId?: string;
    ExtraPythonLibsS3Path?: string;
    ExtraJarsS3Path?: string;
    FailureReason?: string;
    SecurityConfiguration?: string;
    CreatedTimestamp?: Date;
    Arguments?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateDevEndpointResponse: S.Schema<CreateDevEndpointResponse>;
export type GlossaryName = string;
export type MetadataDescription = string;
export interface CreateGlossaryRequest {
    Name: string;
    Description?: string;
    ClientToken?: string;
}
export declare const CreateGlossaryRequest: S.Schema<CreateGlossaryRequest>;
export type GlossaryId = string;
export interface CreateGlossaryResponse {
    Id?: string;
    Name?: string;
    Description?: string;
}
export declare const CreateGlossaryResponse: S.Schema<CreateGlossaryResponse>;
export type GlossaryTermName = string;
export type GlossaryShortDescription = string;
export type GlossaryLongDescription = string;
export interface CreateGlossaryTermRequest {
    GlossaryIdentifier: string;
    Name: string;
    ShortDescription?: string;
    LongDescription?: string;
    ClientToken?: string;
}
export declare const CreateGlossaryTermRequest: S.Schema<CreateGlossaryTermRequest>;
export interface CreateGlossaryTermResponse {
    Id?: string;
    GlossaryId?: string;
    Name?: string;
    ShortDescription?: string;
    LongDescription?: string;
}
export declare const CreateGlossaryTermResponse: S.Schema<CreateGlossaryTermResponse>;
export type IdentityCenterInstanceArn = string;
export type IdentityCenterScope = string;
export type IdentityCenterScopesList = string[];
export declare const IdentityCenterScopesList: any;
export interface CreateGlueIdentityCenterConfigurationRequest {
    InstanceArn: string;
    Scopes?: string[];
    UserBackgroundSessionsEnabled?: boolean;
}
export declare const CreateGlueIdentityCenterConfigurationRequest: S.Schema<CreateGlueIdentityCenterConfigurationRequest>;
export type ApplicationArn = string;
export interface CreateGlueIdentityCenterConfigurationResponse {
    ApplicationArn?: string;
}
export declare const CreateGlueIdentityCenterConfigurationResponse: S.Schema<CreateGlueIdentityCenterConfigurationResponse>;
export type String128 = string;
export type String512 = string;
export type IntegrationDescription = string;
export type String2048 = string;
export type IntegrationString = string;
export type IntegrationAdditionalEncryptionContextMap = {
    [key: string]: string | undefined;
};
export declare const IntegrationAdditionalEncryptionContextMap: any;
export interface Tag {
    key?: string;
    value?: string;
}
export declare const Tag: S.Schema<Tag>;
export type IntegrationTagsList = Tag[];
export declare const IntegrationTagsList: any;
export type IntegrationSourcePropertiesMap = {
    [key: string]: string | undefined;
};
export declare const IntegrationSourcePropertiesMap: any;
export type ContinuousSync = boolean;
export interface IntegrationConfig {
    RefreshInterval?: string;
    SourceProperties?: {
        [key: string]: string | undefined;
    };
    ContinuousSync?: boolean;
}
export declare const IntegrationConfig: S.Schema<IntegrationConfig>;
export interface CreateIntegrationRequest {
    IntegrationName: string;
    SourceArn: string;
    TargetArn: string;
    Description?: string;
    DataFilter?: string;
    KmsKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
    IntegrationConfig?: IntegrationConfig;
}
export declare const CreateIntegrationRequest: S.Schema<CreateIntegrationRequest>;
export type IntegrationStatus = "CREATING" | "ACTIVE" | "MODIFYING" | "FAILED" | "DELETING" | "SYNCING" | "NEEDS_ATTENTION" | (string & {});
export declare const IntegrationStatus: any;
export type IntegrationTimestamp = Date;
export interface IntegrationError {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const IntegrationError: S.Schema<IntegrationError>;
export type IntegrationErrorList = IntegrationError[];
export declare const IntegrationErrorList: any;
export interface CreateIntegrationResponse {
    SourceArn: string;
    TargetArn: string;
    IntegrationName: string;
    Description?: string;
    IntegrationArn: string;
    KmsKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
    Status: IntegrationStatus;
    CreateTime: Date;
    Errors?: IntegrationError[];
    DataFilter?: string;
    IntegrationConfig?: IntegrationConfig;
}
export declare const CreateIntegrationResponse: S.Schema<CreateIntegrationResponse>;
export interface SourceProcessingProperties {
    RoleArn?: string;
}
export declare const SourceProcessingProperties: S.Schema<SourceProcessingProperties>;
export interface TargetProcessingProperties {
    RoleArn?: string;
    KmsArn?: string;
    ConnectionName?: string;
    EventBusArn?: string;
}
export declare const TargetProcessingProperties: S.Schema<TargetProcessingProperties>;
export interface CreateIntegrationResourcePropertyRequest {
    ResourceArn: string;
    SourceProcessingProperties?: SourceProcessingProperties;
    TargetProcessingProperties?: TargetProcessingProperties;
    Tags?: Tag[];
}
export declare const CreateIntegrationResourcePropertyRequest: S.Schema<CreateIntegrationResourcePropertyRequest>;
export interface CreateIntegrationResourcePropertyResponse {
    ResourceArn: string;
    ResourcePropertyArn?: string;
    SourceProcessingProperties?: SourceProcessingProperties;
    TargetProcessingProperties?: TargetProcessingProperties;
}
export declare const CreateIntegrationResourcePropertyResponse: S.Schema<CreateIntegrationResourcePropertyResponse>;
export type SourceTableFieldsList = string[];
export declare const SourceTableFieldsList: any;
export type PrimaryKeyList = string[];
export declare const PrimaryKeyList: any;
export interface SourceTableConfig {
    Fields?: string[];
    FilterPredicate?: string;
    PrimaryKey?: string[];
    RecordUpdateField?: string;
}
export declare const SourceTableConfig: S.Schema<SourceTableConfig>;
export type UnnestSpec = "TOPLEVEL" | "FULL" | "NOUNNEST" | (string & {});
export declare const UnnestSpec: any;
export interface IntegrationPartition {
    FieldName?: string;
    FunctionSpec?: string;
    ConversionSpec?: string;
}
export declare const IntegrationPartition: S.Schema<IntegrationPartition>;
export type IntegrationPartitionSpecList = IntegrationPartition[];
export declare const IntegrationPartitionSpecList: any;
export interface TargetTableConfig {
    UnnestSpec?: UnnestSpec;
    PartitionSpec?: IntegrationPartition[];
    TargetTableName?: string;
}
export declare const TargetTableConfig: S.Schema<TargetTableConfig>;
export interface CreateIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
    SourceTableConfig?: SourceTableConfig;
    TargetTableConfig?: TargetTableConfig;
}
export declare const CreateIntegrationTablePropertiesRequest: S.Schema<CreateIntegrationTablePropertiesRequest>;
export interface CreateIntegrationTablePropertiesResponse {
}
export declare const CreateIntegrationTablePropertiesResponse: S.Schema<CreateIntegrationTablePropertiesResponse>;
export interface CreateJobRequest {
    Name: string;
    JobMode?: JobMode;
    JobRunQueuingEnabled?: boolean;
    Description?: string;
    LogUri?: string;
    Role: string;
    ExecutionProperty?: ExecutionProperty;
    Command: JobCommand;
    DefaultArguments?: {
        [key: string]: string | undefined;
    };
    NonOverridableArguments?: {
        [key: string]: string | undefined;
    };
    Connections?: ConnectionsList;
    MaxRetries?: number;
    AllocatedCapacity?: number;
    Timeout?: number;
    MaxCapacity?: number;
    SecurityConfiguration?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    NotificationProperty?: NotificationProperty;
    GlueVersion?: string;
    NumberOfWorkers?: number;
    WorkerType?: WorkerType;
    CodeGenConfigurationNodes?: {
        [key: string]: CodeGenConfigurationNode | undefined;
    };
    ExecutionClass?: ExecutionClass;
    SourceControlDetails?: SourceControlDetails;
    MaintenanceWindow?: string;
}
export declare const CreateJobRequest: S.Schema<CreateJobRequest>;
export interface CreateJobResponse {
    Name?: string;
}
export declare const CreateJobResponse: S.Schema<CreateJobResponse>;
export type GlueTables = GlueTable[];
export declare const GlueTables: any;
export type TransformType = "FIND_MATCHES" | (string & {});
export declare const TransformType: any;
export interface FindMatchesParameters {
    PrimaryKeyColumnName?: string;
    PrecisionRecallTradeoff?: number;
    AccuracyCostTradeoff?: number;
    EnforceProvidedLabels?: boolean;
}
export declare const FindMatchesParameters: S.Schema<FindMatchesParameters>;
export interface TransformParameters {
    TransformType: TransformType;
    FindMatchesParameters?: FindMatchesParameters;
}
export declare const TransformParameters: S.Schema<TransformParameters>;
export type MLUserDataEncryptionModeString = "DISABLED" | "SSE-KMS" | (string & {});
export declare const MLUserDataEncryptionModeString: any;
export interface MLUserDataEncryption {
    MlUserDataEncryptionMode: MLUserDataEncryptionModeString;
    KmsKeyId?: string;
}
export declare const MLUserDataEncryption: S.Schema<MLUserDataEncryption>;
export interface TransformEncryption {
    MlUserDataEncryption?: MLUserDataEncryption;
    TaskRunSecurityConfigurationName?: string;
}
export declare const TransformEncryption: S.Schema<TransformEncryption>;
export interface CreateMLTransformRequest {
    Name: string;
    Description?: string;
    InputRecordTables: GlueTable[];
    Parameters: TransformParameters;
    Role: string;
    GlueVersion?: string;
    MaxCapacity?: number;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    Timeout?: number;
    MaxRetries?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    TransformEncryption?: TransformEncryption;
}
export declare const CreateMLTransformRequest: S.Schema<CreateMLTransformRequest>;
export interface CreateMLTransformResponse {
    TransformId?: string;
}
export declare const CreateMLTransformResponse: S.Schema<CreateMLTransformResponse>;
export interface CreatePartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionInput: PartitionInput;
}
export declare const CreatePartitionRequest: S.Schema<CreatePartitionRequest>;
export interface CreatePartitionResponse {
}
export declare const CreatePartitionResponse: S.Schema<CreatePartitionResponse>;
export type KeyList = string[];
export declare const KeyList: any;
export interface PartitionIndex {
    Keys: string[];
    IndexName: string;
}
export declare const PartitionIndex: S.Schema<PartitionIndex>;
export interface CreatePartitionIndexRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionIndex: PartitionIndex;
}
export declare const CreatePartitionIndexRequest: S.Schema<CreatePartitionIndexRequest>;
export interface CreatePartitionIndexResponse {
}
export declare const CreatePartitionIndexResponse: S.Schema<CreatePartitionIndexResponse>;
export interface CreateRegistryInput {
    RegistryName: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRegistryInput: S.Schema<CreateRegistryInput>;
export interface CreateRegistryResponse {
    RegistryArn?: string;
    RegistryName?: string;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateRegistryResponse: S.Schema<CreateRegistryResponse>;
export interface RegistryId {
    RegistryName?: string;
    RegistryArn?: string;
}
export declare const RegistryId: S.Schema<RegistryId>;
export type Compatibility = "NONE" | "DISABLED" | "BACKWARD" | "BACKWARD_ALL" | "FORWARD" | "FORWARD_ALL" | "FULL" | "FULL_ALL" | (string & {});
export declare const Compatibility: any;
export interface CreateSchemaInput {
    RegistryId?: RegistryId;
    SchemaName: string;
    DataFormat: DataFormat;
    Compatibility?: Compatibility;
    Description?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    SchemaDefinition?: string;
}
export declare const CreateSchemaInput: S.Schema<CreateSchemaInput>;
export type SchemaCheckpointNumber = number;
export type SchemaStatus = "AVAILABLE" | "PENDING" | "DELETING" | (string & {});
export declare const SchemaStatus: any;
export type SchemaVersionStatus = "AVAILABLE" | "PENDING" | "FAILURE" | "DELETING" | (string & {});
export declare const SchemaVersionStatus: any;
export interface CreateSchemaResponse {
    RegistryName?: string;
    RegistryArn?: string;
    SchemaName?: string;
    SchemaArn?: string;
    Description?: string;
    DataFormat?: DataFormat;
    Compatibility?: Compatibility;
    SchemaCheckpoint?: number;
    LatestSchemaVersion?: number;
    NextSchemaVersion?: number;
    SchemaStatus?: SchemaStatus;
    Tags?: {
        [key: string]: string | undefined;
    };
    SchemaVersionId?: string;
    SchemaVersionStatus?: SchemaVersionStatus;
}
export declare const CreateSchemaResponse: S.Schema<CreateSchemaResponse>;
export type CodeGenIdentifier = string;
export type CodeGenNodeType = string;
export type CodeGenArgName = string;
export type CodeGenArgValue = string;
export interface CodeGenNodeArg {
    Name: string;
    Value: string;
    Param?: boolean;
}
export declare const CodeGenNodeArg: S.Schema<CodeGenNodeArg>;
export type CodeGenNodeArgs = CodeGenNodeArg[];
export declare const CodeGenNodeArgs: any;
export interface CodeGenNode {
    Id: string;
    NodeType: string;
    Args: CodeGenNodeArg[];
    LineNumber?: number;
}
export declare const CodeGenNode: S.Schema<CodeGenNode>;
export type DagNodes = CodeGenNode[];
export declare const DagNodes: any;
export interface CodeGenEdge {
    Source: string;
    Target: string;
    TargetParameter?: string;
}
export declare const CodeGenEdge: S.Schema<CodeGenEdge>;
export type DagEdges = CodeGenEdge[];
export declare const DagEdges: any;
export type Language = "PYTHON" | "SCALA" | (string & {});
export declare const Language: any;
export interface CreateScriptRequest {
    DagNodes?: CodeGenNode[];
    DagEdges?: CodeGenEdge[];
    Language?: Language;
}
export declare const CreateScriptRequest: S.Schema<CreateScriptRequest>;
export type PythonScript = string;
export type ScalaCode = string;
export interface CreateScriptResponse {
    PythonScript?: string;
    ScalaCode?: string;
}
export declare const CreateScriptResponse: S.Schema<CreateScriptResponse>;
export type S3EncryptionMode = "DISABLED" | "SSE-KMS" | "SSE-S3" | (string & {});
export declare const S3EncryptionMode: any;
export interface S3Encryption {
    S3EncryptionMode?: S3EncryptionMode;
    KmsKeyArn?: string;
}
export declare const S3Encryption: S.Schema<S3Encryption>;
export type S3EncryptionList = S3Encryption[];
export declare const S3EncryptionList: any;
export type CloudWatchEncryptionMode = "DISABLED" | "SSE-KMS" | (string & {});
export declare const CloudWatchEncryptionMode: any;
export interface CloudWatchEncryption {
    CloudWatchEncryptionMode?: CloudWatchEncryptionMode;
    KmsKeyArn?: string;
}
export declare const CloudWatchEncryption: S.Schema<CloudWatchEncryption>;
export type JobBookmarksEncryptionMode = "DISABLED" | "CSE-KMS" | (string & {});
export declare const JobBookmarksEncryptionMode: any;
export interface JobBookmarksEncryption {
    JobBookmarksEncryptionMode?: JobBookmarksEncryptionMode;
    KmsKeyArn?: string;
}
export declare const JobBookmarksEncryption: S.Schema<JobBookmarksEncryption>;
export type DataQualityEncryptionMode = "DISABLED" | "SSE-KMS" | (string & {});
export declare const DataQualityEncryptionMode: any;
export interface DataQualityEncryption {
    DataQualityEncryptionMode?: DataQualityEncryptionMode;
    KmsKeyArn?: string;
}
export declare const DataQualityEncryption: S.Schema<DataQualityEncryption>;
export interface EncryptionConfiguration {
    S3Encryption?: S3Encryption[];
    CloudWatchEncryption?: CloudWatchEncryption;
    JobBookmarksEncryption?: JobBookmarksEncryption;
    DataQualityEncryption?: DataQualityEncryption;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export interface CreateSecurityConfigurationRequest {
    Name: string;
    EncryptionConfiguration: EncryptionConfiguration;
}
export declare const CreateSecurityConfigurationRequest: S.Schema<CreateSecurityConfigurationRequest>;
export interface CreateSecurityConfigurationResponse {
    Name?: string;
    CreatedTimestamp?: Date;
}
export declare const CreateSecurityConfigurationResponse: S.Schema<CreateSecurityConfigurationResponse>;
export type OrchestrationRoleArn = string;
export interface SessionCommand {
    Name?: string;
    PythonVersion?: string;
}
export declare const SessionCommand: S.Schema<SessionCommand>;
export type OrchestrationArgumentsValue = string;
export type OrchestrationArgumentsMap = {
    [key: string]: string | undefined;
};
export declare const OrchestrationArgumentsMap: any;
export type SessionType = "LIVY" | "SPARK_CONNECT" | (string & {});
export declare const SessionType: any;
export interface CreateSessionRequest {
    Id: string;
    Description?: string;
    Role: string;
    Command: SessionCommand;
    Timeout?: number;
    IdleTimeout?: number;
    DefaultArguments?: {
        [key: string]: string | undefined;
    };
    Connections?: ConnectionsList;
    MaxCapacity?: number;
    NumberOfWorkers?: number;
    WorkerType?: WorkerType;
    SecurityConfiguration?: string;
    GlueVersion?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
    RequestOrigin?: string;
    SessionType?: SessionType;
}
export declare const CreateSessionRequest: S.Schema<CreateSessionRequest>;
export type SessionStatus = "PROVISIONING" | "READY" | "FAILED" | "TIMEOUT" | "STOPPING" | "STOPPED" | (string & {});
export declare const SessionStatus: any;
export type DoubleValue = number;
export type IdleTimeout = number;
export interface Session {
    Id?: string;
    CreatedOn?: Date;
    Status?: SessionStatus;
    ErrorMessage?: string;
    Description?: string;
    Role?: string;
    Command?: SessionCommand;
    DefaultArguments?: {
        [key: string]: string | undefined;
    };
    Connections?: ConnectionsList;
    Progress?: number;
    MaxCapacity?: number;
    SecurityConfiguration?: string;
    GlueVersion?: string;
    NumberOfWorkers?: number;
    WorkerType?: WorkerType;
    CompletedOn?: Date;
    ExecutionTime?: number;
    DPUSeconds?: number;
    IdleTimeout?: number;
    ProfileName?: string;
    SessionType?: SessionType;
}
export declare const Session: S.Schema<Session>;
export interface CreateSessionResponse {
    Session?: Session;
}
export declare const CreateSessionResponse: S.Schema<CreateSessionResponse>;
export type NonNegativeInteger = number;
export type ViewTextString = string;
export type TableTypeString = string;
export interface TableIdentifier {
    CatalogId?: string;
    DatabaseName?: string;
    Name?: string;
    Region?: string;
}
export declare const TableIdentifier: S.Schema<TableIdentifier>;
export type ViewDialect = "REDSHIFT" | "ATHENA" | "SPARK" | (string & {});
export declare const ViewDialect: any;
export type ViewDialectVersionString = string;
export interface ViewRepresentationInput {
    Dialect?: ViewDialect;
    DialectVersion?: string;
    ViewOriginalText?: string;
    ValidationConnection?: string;
    ViewExpandedText?: string;
}
export declare const ViewRepresentationInput: S.Schema<ViewRepresentationInput>;
export type ViewRepresentationInputList = ViewRepresentationInput[];
export declare const ViewRepresentationInputList: any;
export type TableVersionId = number;
export type RefreshSeconds = number;
export type LastRefreshType = "FULL" | "INCREMENTAL" | (string & {});
export declare const LastRefreshType: any;
export type ViewSubObjectsList = string[];
export declare const ViewSubObjectsList: any;
export type ViewSubObjectVersionIdsList = number[];
export declare const ViewSubObjectVersionIdsList: any;
export interface ViewDefinitionInput {
    IsProtected?: boolean;
    Definer?: string;
    Representations?: ViewRepresentationInput[];
    ViewVersionId?: number;
    ViewVersionToken?: string;
    RefreshSeconds?: number;
    LastRefreshType?: LastRefreshType;
    SubObjects?: string[];
    SubObjectVersionIds?: number[];
}
export declare const ViewDefinitionInput: S.Schema<ViewDefinitionInput>;
export interface TableInput {
    Name: string;
    Description?: string;
    Owner?: string;
    LastAccessTime?: Date;
    LastAnalyzedTime?: Date;
    Retention?: number;
    StorageDescriptor?: StorageDescriptor;
    PartitionKeys?: Column[];
    ViewOriginalText?: string;
    ViewExpandedText?: string;
    TableType?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    TargetTable?: TableIdentifier;
    ViewDefinition?: ViewDefinitionInput;
}
export declare const TableInput: S.Schema<TableInput>;
export type PartitionIndexList = PartitionIndex[];
export declare const PartitionIndexList: any;
export type MetadataOperation = "CREATE" | (string & {});
export declare const MetadataOperation: any;
export type IntegerList = number[];
export declare const IntegerList: any;
export type IcebergStructTypeEnum = "struct" | (string & {});
export declare const IcebergStructTypeEnum: any;
export type IcebergDocument = unknown;
export interface IcebergStructField {
    Id: number;
    Name: string;
    Type: any;
    Required: boolean;
    Doc?: string;
    InitialDefault?: any;
    WriteDefault?: any;
}
export declare const IcebergStructField: S.Schema<IcebergStructField>;
export type IcebergStructFieldList = IcebergStructField[];
export declare const IcebergStructFieldList: any;
export interface IcebergSchema {
    SchemaId?: number;
    IdentifierFieldIds?: number[];
    Type?: IcebergStructTypeEnum;
    Fields: IcebergStructField[];
}
export declare const IcebergSchema: S.Schema<IcebergSchema>;
export type IcebergTransformString = string;
export interface IcebergPartitionField {
    SourceId: number;
    Transform: string;
    Name: string;
    FieldId?: number;
}
export declare const IcebergPartitionField: S.Schema<IcebergPartitionField>;
export type IcebergPartitionSpecFieldList = IcebergPartitionField[];
export declare const IcebergPartitionSpecFieldList: any;
export interface IcebergPartitionSpec {
    Fields: IcebergPartitionField[];
    SpecId?: number;
}
export declare const IcebergPartitionSpec: S.Schema<IcebergPartitionSpec>;
export type IcebergSortDirection = "asc" | "desc" | (string & {});
export declare const IcebergSortDirection: any;
export type IcebergNullOrder = "nulls-first" | "nulls-last" | (string & {});
export declare const IcebergNullOrder: any;
export interface IcebergSortField {
    SourceId: number;
    Transform: string;
    Direction: IcebergSortDirection;
    NullOrder: IcebergNullOrder;
}
export declare const IcebergSortField: S.Schema<IcebergSortField>;
export type IcebergSortOrderFieldList = IcebergSortField[];
export declare const IcebergSortOrderFieldList: any;
export interface IcebergSortOrder {
    OrderId: number;
    Fields: IcebergSortField[];
}
export declare const IcebergSortOrder: S.Schema<IcebergSortOrder>;
export type StringToStringMap = {
    [key: string]: string | undefined;
};
export declare const StringToStringMap: any;
export interface CreateIcebergTableInput {
    Location: string;
    Schema: IcebergSchema;
    PartitionSpec?: IcebergPartitionSpec;
    WriteOrder?: IcebergSortOrder;
    Properties?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateIcebergTableInput: S.Schema<CreateIcebergTableInput>;
export interface IcebergInput {
    MetadataOperation: MetadataOperation;
    Version?: string;
    CreateIcebergTableInput?: CreateIcebergTableInput;
}
export declare const IcebergInput: S.Schema<IcebergInput>;
export interface OpenTableFormatInput {
    IcebergInput?: IcebergInput;
}
export declare const OpenTableFormatInput: S.Schema<OpenTableFormatInput>;
export interface CreateTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    Name?: string;
    TableInput?: TableInput;
    PartitionIndexes?: PartitionIndex[];
    TransactionId?: string;
    OpenTableFormatInput?: OpenTableFormatInput;
}
export declare const CreateTableRequest: S.Schema<CreateTableRequest>;
export interface CreateTableResponse {
}
export declare const CreateTableResponse: S.Schema<CreateTableResponse>;
export interface CreateTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
    TableOptimizerConfiguration: TableOptimizerConfiguration;
}
export declare const CreateTableOptimizerRequest: S.Schema<CreateTableOptimizerRequest>;
export interface CreateTableOptimizerResponse {
}
export declare const CreateTableOptimizerResponse: S.Schema<CreateTableOptimizerResponse>;
export interface CreateTriggerRequest {
    Name: string;
    WorkflowName?: string;
    Type: TriggerType;
    Schedule?: string;
    Predicate?: Predicate;
    Actions: Action[];
    Description?: string;
    StartOnCreation?: boolean;
    Tags?: {
        [key: string]: string | undefined;
    };
    EventBatchingCondition?: EventBatchingCondition;
}
export declare const CreateTriggerRequest: S.Schema<CreateTriggerRequest>;
export interface CreateTriggerResponse {
    Name?: string;
}
export declare const CreateTriggerResponse: S.Schema<CreateTriggerResponse>;
export type ConfigValueString = string;
export type AllowedValuesStringList = string[];
export declare const AllowedValuesStringList: any;
export interface ConfigurationObject {
    DefaultValue?: string;
    AllowedValues?: string[];
    MinValue?: string;
    MaxValue?: string;
}
export declare const ConfigurationObject: S.Schema<ConfigurationObject>;
export type ConfigurationMap = {
    [key: string]: ConfigurationObject | undefined;
};
export declare const ConfigurationMap: any;
export interface ProfileConfiguration {
    SessionConfiguration?: {
        [key: string]: ConfigurationObject | undefined;
    };
    JobConfiguration?: {
        [key: string]: ConfigurationObject | undefined;
    };
}
export declare const ProfileConfiguration: S.Schema<ProfileConfiguration>;
export interface CreateUsageProfileRequest {
    Name: string;
    Description?: string;
    Configuration: ProfileConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateUsageProfileRequest: S.Schema<CreateUsageProfileRequest>;
export interface CreateUsageProfileResponse {
    Name?: string;
}
export declare const CreateUsageProfileResponse: S.Schema<CreateUsageProfileResponse>;
export type FunctionType = "REGULAR_FUNCTION" | "AGGREGATE_FUNCTION" | "STORED_PROCEDURE" | (string & {});
export declare const FunctionType: any;
export type PrincipalType = "USER" | "ROLE" | "GROUP" | (string & {});
export declare const PrincipalType: any;
export type ResourceType = "JAR" | "FILE" | "ARCHIVE" | (string & {});
export declare const ResourceType: any;
export interface ResourceUri {
    ResourceType?: ResourceType;
    Uri?: string;
}
export declare const ResourceUri: S.Schema<ResourceUri>;
export type ResourceUriList = ResourceUri[];
export declare const ResourceUriList: any;
export interface UserDefinedFunctionInput {
    FunctionName?: string;
    ClassName?: string;
    OwnerName?: string;
    FunctionType?: FunctionType;
    OwnerType?: PrincipalType;
    ResourceUris?: ResourceUri[];
}
export declare const UserDefinedFunctionInput: S.Schema<UserDefinedFunctionInput>;
export interface CreateUserDefinedFunctionRequest {
    CatalogId?: string;
    DatabaseName: string;
    FunctionInput: UserDefinedFunctionInput;
}
export declare const CreateUserDefinedFunctionRequest: S.Schema<CreateUserDefinedFunctionRequest>;
export interface CreateUserDefinedFunctionResponse {
}
export declare const CreateUserDefinedFunctionResponse: S.Schema<CreateUserDefinedFunctionResponse>;
export type WorkflowDescriptionString = string;
export interface CreateWorkflowRequest {
    Name: string;
    Description?: string;
    DefaultRunProperties?: {
        [key: string]: string | undefined;
    };
    Tags?: {
        [key: string]: string | undefined;
    };
    MaxConcurrentRuns?: number;
}
export declare const CreateWorkflowRequest: S.Schema<CreateWorkflowRequest>;
export interface CreateWorkflowResponse {
    Name?: string;
}
export declare const CreateWorkflowResponse: S.Schema<CreateWorkflowResponse>;
export interface DeleteAssetRequest {
    Identifier: string;
}
export declare const DeleteAssetRequest: S.Schema<DeleteAssetRequest>;
export interface DeleteAssetResponse {
}
export declare const DeleteAssetResponse: S.Schema<DeleteAssetResponse>;
export type AssetTypeId = string;
export interface DeleteAssetTypeRequest {
    Identifier: string;
}
export declare const DeleteAssetTypeRequest: S.Schema<DeleteAssetTypeRequest>;
export interface DeleteAssetTypeResponse {
}
export declare const DeleteAssetTypeResponse: S.Schema<DeleteAssetTypeResponse>;
export type AttachmentName = string;
export interface DeleteAttachmentRequest {
    AssetIdentifier: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
    AttachmentName: string;
}
export declare const DeleteAttachmentRequest: S.Schema<DeleteAttachmentRequest>;
export interface DeleteAttachmentResponse {
    AssetIdentifier?: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
}
export declare const DeleteAttachmentResponse: S.Schema<DeleteAttachmentResponse>;
export interface DeleteBlueprintRequest {
    Name: string;
}
export declare const DeleteBlueprintRequest: S.Schema<DeleteBlueprintRequest>;
export interface DeleteBlueprintResponse {
    Name?: string;
}
export declare const DeleteBlueprintResponse: S.Schema<DeleteBlueprintResponse>;
export interface DeleteCatalogRequest {
    CatalogId: string;
}
export declare const DeleteCatalogRequest: S.Schema<DeleteCatalogRequest>;
export interface DeleteCatalogResponse {
}
export declare const DeleteCatalogResponse: S.Schema<DeleteCatalogResponse>;
export interface DeleteClassifierRequest {
    Name: string;
}
export declare const DeleteClassifierRequest: S.Schema<DeleteClassifierRequest>;
export interface DeleteClassifierResponse {
}
export declare const DeleteClassifierResponse: S.Schema<DeleteClassifierResponse>;
export interface DeleteColumnStatisticsForPartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    ColumnName: string;
}
export declare const DeleteColumnStatisticsForPartitionRequest: S.Schema<DeleteColumnStatisticsForPartitionRequest>;
export interface DeleteColumnStatisticsForPartitionResponse {
}
export declare const DeleteColumnStatisticsForPartitionResponse: S.Schema<DeleteColumnStatisticsForPartitionResponse>;
export interface DeleteColumnStatisticsForTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    ColumnName: string;
}
export declare const DeleteColumnStatisticsForTableRequest: S.Schema<DeleteColumnStatisticsForTableRequest>;
export interface DeleteColumnStatisticsForTableResponse {
}
export declare const DeleteColumnStatisticsForTableResponse: S.Schema<DeleteColumnStatisticsForTableResponse>;
export interface DeleteColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
}
export declare const DeleteColumnStatisticsTaskSettingsRequest: S.Schema<DeleteColumnStatisticsTaskSettingsRequest>;
export interface DeleteColumnStatisticsTaskSettingsResponse {
}
export declare const DeleteColumnStatisticsTaskSettingsResponse: S.Schema<DeleteColumnStatisticsTaskSettingsResponse>;
export interface DeleteConnectionRequest {
    CatalogId?: string;
    ConnectionName: string;
}
export declare const DeleteConnectionRequest: S.Schema<DeleteConnectionRequest>;
export interface DeleteConnectionResponse {
}
export declare const DeleteConnectionResponse: S.Schema<DeleteConnectionResponse>;
export interface DeleteConnectionTypeRequest {
    ConnectionType: string;
}
export declare const DeleteConnectionTypeRequest: S.Schema<DeleteConnectionTypeRequest>;
export interface DeleteConnectionTypeResponse {
}
export declare const DeleteConnectionTypeResponse: S.Schema<DeleteConnectionTypeResponse>;
export interface DeleteCrawlerRequest {
    Name: string;
}
export declare const DeleteCrawlerRequest: S.Schema<DeleteCrawlerRequest>;
export interface DeleteCrawlerResponse {
}
export declare const DeleteCrawlerResponse: S.Schema<DeleteCrawlerResponse>;
export interface DeleteCustomEntityTypeRequest {
    Name: string;
}
export declare const DeleteCustomEntityTypeRequest: S.Schema<DeleteCustomEntityTypeRequest>;
export interface DeleteCustomEntityTypeResponse {
    Name?: string;
}
export declare const DeleteCustomEntityTypeResponse: S.Schema<DeleteCustomEntityTypeResponse>;
export interface DeleteDatabaseRequest {
    CatalogId?: string;
    Name: string;
}
export declare const DeleteDatabaseRequest: S.Schema<DeleteDatabaseRequest>;
export interface DeleteDatabaseResponse {
}
export declare const DeleteDatabaseResponse: S.Schema<DeleteDatabaseResponse>;
export interface DeleteDataQualityRulesetRequest {
    Name: string;
}
export declare const DeleteDataQualityRulesetRequest: S.Schema<DeleteDataQualityRulesetRequest>;
export interface DeleteDataQualityRulesetResponse {
}
export declare const DeleteDataQualityRulesetResponse: S.Schema<DeleteDataQualityRulesetResponse>;
export interface DeleteDevEndpointRequest {
    EndpointName: string;
}
export declare const DeleteDevEndpointRequest: S.Schema<DeleteDevEndpointRequest>;
export interface DeleteDevEndpointResponse {
}
export declare const DeleteDevEndpointResponse: S.Schema<DeleteDevEndpointResponse>;
export interface DeleteFormTypeRequest {
    Identifier: string;
}
export declare const DeleteFormTypeRequest: S.Schema<DeleteFormTypeRequest>;
export interface DeleteFormTypeResponse {
}
export declare const DeleteFormTypeResponse: S.Schema<DeleteFormTypeResponse>;
export interface DeleteGlossaryRequest {
    Identifier: string;
}
export declare const DeleteGlossaryRequest: S.Schema<DeleteGlossaryRequest>;
export interface DeleteGlossaryResponse {
}
export declare const DeleteGlossaryResponse: S.Schema<DeleteGlossaryResponse>;
export interface DeleteGlossaryTermRequest {
    Identifier: string;
}
export declare const DeleteGlossaryTermRequest: S.Schema<DeleteGlossaryTermRequest>;
export interface DeleteGlossaryTermResponse {
}
export declare const DeleteGlossaryTermResponse: S.Schema<DeleteGlossaryTermResponse>;
export interface DeleteGlueIdentityCenterConfigurationRequest {
}
export declare const DeleteGlueIdentityCenterConfigurationRequest: S.Schema<DeleteGlueIdentityCenterConfigurationRequest>;
export interface DeleteGlueIdentityCenterConfigurationResponse {
}
export declare const DeleteGlueIdentityCenterConfigurationResponse: S.Schema<DeleteGlueIdentityCenterConfigurationResponse>;
export interface DeleteIntegrationRequest {
    IntegrationIdentifier: string;
}
export declare const DeleteIntegrationRequest: S.Schema<DeleteIntegrationRequest>;
export interface DeleteIntegrationResponse {
    SourceArn: string;
    TargetArn: string;
    IntegrationName: string;
    Description?: string;
    IntegrationArn: string;
    KmsKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
    Status: IntegrationStatus;
    CreateTime: Date;
    Errors?: IntegrationError[];
    DataFilter?: string;
}
export declare const DeleteIntegrationResponse: S.Schema<DeleteIntegrationResponse>;
export interface DeleteIntegrationResourcePropertyRequest {
    ResourceArn: string;
}
export declare const DeleteIntegrationResourcePropertyRequest: S.Schema<DeleteIntegrationResourcePropertyRequest>;
export interface DeleteIntegrationResourcePropertyResponse {
}
export declare const DeleteIntegrationResourcePropertyResponse: S.Schema<DeleteIntegrationResourcePropertyResponse>;
export interface DeleteIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
}
export declare const DeleteIntegrationTablePropertiesRequest: S.Schema<DeleteIntegrationTablePropertiesRequest>;
export interface DeleteIntegrationTablePropertiesResponse {
}
export declare const DeleteIntegrationTablePropertiesResponse: S.Schema<DeleteIntegrationTablePropertiesResponse>;
export interface DeleteJobRequest {
    JobName: string;
}
export declare const DeleteJobRequest: S.Schema<DeleteJobRequest>;
export interface DeleteJobResponse {
    JobName?: string;
}
export declare const DeleteJobResponse: S.Schema<DeleteJobResponse>;
export interface DeleteMLTransformRequest {
    TransformId: string;
}
export declare const DeleteMLTransformRequest: S.Schema<DeleteMLTransformRequest>;
export interface DeleteMLTransformResponse {
    TransformId?: string;
}
export declare const DeleteMLTransformResponse: S.Schema<DeleteMLTransformResponse>;
export interface DeletePartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
}
export declare const DeletePartitionRequest: S.Schema<DeletePartitionRequest>;
export interface DeletePartitionResponse {
}
export declare const DeletePartitionResponse: S.Schema<DeletePartitionResponse>;
export interface DeletePartitionIndexRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    IndexName: string;
}
export declare const DeletePartitionIndexRequest: S.Schema<DeletePartitionIndexRequest>;
export interface DeletePartitionIndexResponse {
}
export declare const DeletePartitionIndexResponse: S.Schema<DeletePartitionIndexResponse>;
export interface DeleteRegistryInput {
    RegistryId: RegistryId;
}
export declare const DeleteRegistryInput: S.Schema<DeleteRegistryInput>;
export type RegistryStatus = "AVAILABLE" | "DELETING" | (string & {});
export declare const RegistryStatus: any;
export interface DeleteRegistryResponse {
    RegistryName?: string;
    RegistryArn?: string;
    Status?: RegistryStatus;
}
export declare const DeleteRegistryResponse: S.Schema<DeleteRegistryResponse>;
export interface DeleteResourcePolicyRequest {
    PolicyHashCondition?: string;
    ResourceArn?: string;
}
export declare const DeleteResourcePolicyRequest: S.Schema<DeleteResourcePolicyRequest>;
export interface DeleteResourcePolicyResponse {
}
export declare const DeleteResourcePolicyResponse: S.Schema<DeleteResourcePolicyResponse>;
export interface DeleteSchemaInput {
    SchemaId: SchemaId;
}
export declare const DeleteSchemaInput: S.Schema<DeleteSchemaInput>;
export interface DeleteSchemaResponse {
    SchemaArn?: string;
    SchemaName?: string;
    Status?: SchemaStatus;
}
export declare const DeleteSchemaResponse: S.Schema<DeleteSchemaResponse>;
export type VersionsString = string;
export interface DeleteSchemaVersionsInput {
    SchemaId: SchemaId;
    Versions: string;
}
export declare const DeleteSchemaVersionsInput: S.Schema<DeleteSchemaVersionsInput>;
export type ErrorCodeString = string;
export type ErrorMessageString = string;
export interface ErrorDetails {
    ErrorCode?: string;
    ErrorMessage?: string;
}
export declare const ErrorDetails: S.Schema<ErrorDetails>;
export interface SchemaVersionErrorItem {
    VersionNumber?: number;
    ErrorDetails?: ErrorDetails;
}
export declare const SchemaVersionErrorItem: S.Schema<SchemaVersionErrorItem>;
export type SchemaVersionErrorList = SchemaVersionErrorItem[];
export declare const SchemaVersionErrorList: any;
export interface DeleteSchemaVersionsResponse {
    SchemaVersionErrors?: SchemaVersionErrorItem[];
}
export declare const DeleteSchemaVersionsResponse: S.Schema<DeleteSchemaVersionsResponse>;
export interface DeleteSecurityConfigurationRequest {
    Name: string;
}
export declare const DeleteSecurityConfigurationRequest: S.Schema<DeleteSecurityConfigurationRequest>;
export interface DeleteSecurityConfigurationResponse {
}
export declare const DeleteSecurityConfigurationResponse: S.Schema<DeleteSecurityConfigurationResponse>;
export interface DeleteSessionRequest {
    Id: string;
    RequestOrigin?: string;
}
export declare const DeleteSessionRequest: S.Schema<DeleteSessionRequest>;
export interface DeleteSessionResponse {
    Id?: string;
}
export declare const DeleteSessionResponse: S.Schema<DeleteSessionResponse>;
export interface DeleteTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    Name: string;
    TransactionId?: string;
}
export declare const DeleteTableRequest: S.Schema<DeleteTableRequest>;
export interface DeleteTableResponse {
}
export declare const DeleteTableResponse: S.Schema<DeleteTableResponse>;
export interface DeleteTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
}
export declare const DeleteTableOptimizerRequest: S.Schema<DeleteTableOptimizerRequest>;
export interface DeleteTableOptimizerResponse {
}
export declare const DeleteTableOptimizerResponse: S.Schema<DeleteTableOptimizerResponse>;
export interface DeleteTableVersionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    VersionId: string;
}
export declare const DeleteTableVersionRequest: S.Schema<DeleteTableVersionRequest>;
export interface DeleteTableVersionResponse {
}
export declare const DeleteTableVersionResponse: S.Schema<DeleteTableVersionResponse>;
export interface DeleteTriggerRequest {
    Name: string;
}
export declare const DeleteTriggerRequest: S.Schema<DeleteTriggerRequest>;
export interface DeleteTriggerResponse {
    Name?: string;
}
export declare const DeleteTriggerResponse: S.Schema<DeleteTriggerResponse>;
export interface DeleteUsageProfileRequest {
    Name: string;
}
export declare const DeleteUsageProfileRequest: S.Schema<DeleteUsageProfileRequest>;
export interface DeleteUsageProfileResponse {
}
export declare const DeleteUsageProfileResponse: S.Schema<DeleteUsageProfileResponse>;
export interface DeleteUserDefinedFunctionRequest {
    CatalogId?: string;
    DatabaseName: string;
    FunctionName: string;
}
export declare const DeleteUserDefinedFunctionRequest: S.Schema<DeleteUserDefinedFunctionRequest>;
export interface DeleteUserDefinedFunctionResponse {
}
export declare const DeleteUserDefinedFunctionResponse: S.Schema<DeleteUserDefinedFunctionResponse>;
export interface DeleteWorkflowRequest {
    Name: string;
}
export declare const DeleteWorkflowRequest: S.Schema<DeleteWorkflowRequest>;
export interface DeleteWorkflowResponse {
    Name?: string;
}
export declare const DeleteWorkflowResponse: S.Schema<DeleteWorkflowResponse>;
export interface DescribeConnectionTypeRequest {
    ConnectionType: string;
}
export declare const DescribeConnectionTypeRequest: S.Schema<DescribeConnectionTypeRequest>;
export type Description = string;
export type AuthenticationTypes = AuthenticationType[];
export declare const AuthenticationTypes: any;
export type DataOperation = "READ" | "WRITE" | (string & {});
export declare const DataOperation: any;
export type DataOperations = DataOperation[];
export declare const DataOperations: any;
export type ComputeEnvironments = ComputeEnvironment[];
export declare const ComputeEnvironments: any;
export interface Capabilities {
    SupportedAuthenticationTypes: AuthenticationType[];
    SupportedDataOperations: DataOperation[];
    SupportedComputeEnvironments: ComputeEnvironment[];
}
export declare const Capabilities: S.Schema<Capabilities>;
export type PropertyName = string;
export type PropertyDescriptionString = string;
export type PropertyType = "USER_INPUT" | "SECRET" | "READ_ONLY" | "UNUSED" | "SECRET_OR_USER_INPUT" | (string & {});
export declare const PropertyType: any;
export type PropertyTypes = PropertyType[];
export declare const PropertyTypes: any;
export type AllowedValueDescriptionString = string;
export type AllowedValueValueString = string;
export interface AllowedValue {
    Description?: string;
    Value: string;
}
export declare const AllowedValue: S.Schema<AllowedValue>;
export type AllowedValues = AllowedValue[];
export declare const AllowedValues: any;
export type PropertyLocation = "HEADER" | "BODY" | "QUERY_PARAM" | "PATH" | (string & {});
export declare const PropertyLocation: any;
export interface Property {
    Name: string;
    Description: string;
    Required: boolean;
    DefaultValue?: string;
    PropertyTypes: PropertyType[];
    AllowedValues?: AllowedValue[];
    DataOperationScopes?: DataOperation[];
    KeyOverride?: string;
    PropertyLocation?: PropertyLocation;
}
export declare const Property: S.Schema<Property>;
export type PropertiesMap = {
    [key: string]: Property | undefined;
};
export declare const PropertiesMap: any;
export interface AuthConfiguration {
    AuthenticationType: Property;
    SecretArn?: Property;
    OAuth2Properties?: {
        [key: string]: Property | undefined;
    };
    BasicAuthenticationProperties?: {
        [key: string]: Property | undefined;
    };
    CustomAuthenticationProperties?: {
        [key: string]: Property | undefined;
    };
}
export declare const AuthConfiguration: S.Schema<AuthConfiguration>;
export type ComputeEnvironmentName = string;
export type ComputeEnvironmentConfigurationDescriptionString = string;
export type PropertyNameOverrides = {
    [key: string]: string | undefined;
};
export declare const PropertyNameOverrides: any;
export type ListOfString = string[];
export declare const ListOfString: any;
export interface ComputeEnvironmentConfiguration {
    Name: string;
    Description: string;
    ComputeEnvironment: ComputeEnvironment;
    SupportedAuthenticationTypes: AuthenticationType[];
    ConnectionOptions: {
        [key: string]: Property | undefined;
    };
    ConnectionPropertyNameOverrides: {
        [key: string]: string | undefined;
    };
    ConnectionOptionNameOverrides: {
        [key: string]: string | undefined;
    };
    ConnectionPropertiesRequiredOverrides: string[];
    PhysicalConnectionPropertiesRequired?: boolean;
}
export declare const ComputeEnvironmentConfiguration: S.Schema<ComputeEnvironmentConfiguration>;
export type ComputeEnvironmentConfigurationMap = {
    [key: string]: ComputeEnvironmentConfiguration | undefined;
};
export declare const ComputeEnvironmentConfigurationMap: any;
export type HTTPMethod = "GET" | "POST" | (string & {});
export declare const HTTPMethod: any;
export type PathString = string;
export type ConnectorPropertyKey = string;
export interface ConnectorProperty {
    Name: string;
    KeyOverride?: string;
    Required: boolean;
    DefaultValue?: string;
    AllowedValues?: string[];
    PropertyLocation?: PropertyLocation;
    PropertyType: PropertyType;
    Format?: string;
}
export declare const ConnectorProperty: S.Schema<ConnectorProperty>;
export type ConnectorPropertyList = ConnectorProperty[];
export declare const ConnectorPropertyList: any;
export type JsonPathString = string;
export interface ResponseConfiguration {
    ResultPath: string;
    ErrorPath?: string;
}
export declare const ResponseConfiguration: S.Schema<ResponseConfiguration>;
export type DefaultValue = string;
export interface ResponseExtractionMapping {
    ContentPath?: string;
    HeaderKey?: string;
}
export declare const ResponseExtractionMapping: S.Schema<ResponseExtractionMapping>;
export interface ExtractedParameter {
    Key?: string;
    DefaultValue?: string;
    PropertyLocation?: PropertyLocation;
    Value?: ResponseExtractionMapping;
}
export declare const ExtractedParameter: S.Schema<ExtractedParameter>;
export interface CursorConfiguration {
    NextPage: ExtractedParameter;
    LimitParameter?: ExtractedParameter;
}
export declare const CursorConfiguration: S.Schema<CursorConfiguration>;
export interface OffsetConfiguration {
    OffsetParameter: ExtractedParameter;
    LimitParameter: ExtractedParameter;
}
export declare const OffsetConfiguration: S.Schema<OffsetConfiguration>;
export interface PaginationConfiguration {
    CursorConfiguration?: CursorConfiguration;
    OffsetConfiguration?: OffsetConfiguration;
}
export declare const PaginationConfiguration: S.Schema<PaginationConfiguration>;
export type FilterMode = "QUERY_PARAMS" | "FILTER_STRING" | (string & {});
export declare const FilterMode: any;
export type ConnectionStringToStringMap = {
    [key: string]: string | undefined;
};
export declare const ConnectionStringToStringMap: any;
export interface BetweenConfiguration {
    LowBoundKey?: string;
    HighBoundKey?: string;
    Template?: string;
}
export declare const BetweenConfiguration: S.Schema<BetweenConfiguration>;
export interface FilterStringConfiguration {
    QueryParameterName: string;
    QuoteStringValues?: boolean;
    QuoteCharacter?: string;
}
export declare const FilterStringConfiguration: S.Schema<FilterStringConfiguration>;
export interface FilterConfiguration {
    FilterMode: FilterMode;
    OperatorMappings?: {
        [key: string]: string | undefined;
    };
    DateTimeFormat?: string;
    StripQuotes?: boolean;
    BetweenConfiguration?: BetweenConfiguration;
    FilterStringConfiguration?: FilterStringConfiguration;
}
export declare const FilterConfiguration: S.Schema<FilterConfiguration>;
export interface SourceConfiguration {
    RequestMethod?: HTTPMethod;
    RequestPath?: string;
    RequestParameters?: ConnectorProperty[];
    ResponseConfiguration?: ResponseConfiguration;
    PaginationConfiguration?: PaginationConfiguration;
    FilterConfiguration?: FilterConfiguration;
}
export declare const SourceConfiguration: S.Schema<SourceConfiguration>;
export type EntityConfigurationMapKeyString = string;
export type FieldDefinitionMapKeyString = string;
export type FieldDataType = "INT" | "SMALLINT" | "BIGINT" | "FLOAT" | "LONG" | "DATE" | "BOOLEAN" | "MAP" | "ARRAY" | "STRING" | "TIMESTAMP" | "DECIMAL" | "BYTE" | "SHORT" | "DOUBLE" | "STRUCT" | "BINARY" | "UNION" | (string & {});
export declare const FieldDataType: any;
export interface FilterOverrides {
    FieldName?: string;
    OperatorMappings?: {
        [key: string]: string | undefined;
    };
    BetweenConfiguration?: BetweenConfiguration;
    DateTimeFormat?: string;
}
export declare const FilterOverrides: S.Schema<FilterOverrides>;
export interface FieldDefinition {
    Name: string;
    FieldDataType: FieldDataType;
    ResponseDateFormat?: string;
    IsPartitionable?: boolean;
    IsNullable?: boolean;
    IsQueryable?: boolean;
    IsOrderable?: boolean;
    FilterOverrides?: FilterOverrides;
}
export declare const FieldDefinition: S.Schema<FieldDefinition>;
export type FieldDefinitionMap = {
    [key: string]: FieldDefinition | undefined;
};
export declare const FieldDefinitionMap: any;
export interface EntityConfiguration {
    SourceConfiguration?: SourceConfiguration;
    Schema?: {
        [key: string]: FieldDefinition | undefined;
    };
}
export declare const EntityConfiguration: S.Schema<EntityConfiguration>;
export type EntityConfigurationMap = {
    [key: string]: EntityConfiguration | undefined;
};
export declare const EntityConfigurationMap: any;
export interface RestConfiguration {
    GlobalSourceConfiguration?: SourceConfiguration;
    ValidationEndpointConfiguration?: SourceConfiguration;
    EntityConfigurations?: {
        [key: string]: EntityConfiguration | undefined;
    };
}
export declare const RestConfiguration: S.Schema<RestConfiguration>;
export interface DescribeConnectionTypeResponse {
    ConnectionType?: string;
    Description?: string;
    Capabilities?: Capabilities;
    ConnectionProperties?: {
        [key: string]: Property | undefined;
    };
    ConnectionOptions?: {
        [key: string]: Property | undefined;
    };
    AuthenticationConfiguration?: AuthConfiguration;
    ComputeEnvironmentConfigurations?: {
        [key: string]: ComputeEnvironmentConfiguration | undefined;
    };
    PhysicalConnectionRequirements?: {
        [key: string]: Property | undefined;
    };
    AthenaConnectionProperties?: {
        [key: string]: Property | undefined;
    };
    PythonConnectionProperties?: {
        [key: string]: Property | undefined;
    };
    SparkConnectionProperties?: {
        [key: string]: Property | undefined;
    };
    RestConfiguration?: RestConfiguration;
}
export declare const DescribeConnectionTypeResponse: S.Schema<DescribeConnectionTypeResponse>;
export type EntityName = string;
export type NextToken = string;
export type ApiVersion = string;
export interface DescribeEntityRequest {
    ConnectionName: string;
    CatalogId?: string;
    EntityName: string;
    NextToken?: string;
    DataStoreApiVersion?: string;
}
export declare const DescribeEntityRequest: S.Schema<DescribeEntityRequest>;
export type EntityFieldName = string;
export type FieldLabel = string;
export type FieldDescription = string;
export type FieldFilterOperator = "LESS_THAN" | "GREATER_THAN" | "BETWEEN" | "EQUAL_TO" | "NOT_EQUAL_TO" | "GREATER_THAN_OR_EQUAL_TO" | "LESS_THAN_OR_EQUAL_TO" | "CONTAINS" | "ORDER_BY" | (string & {});
export declare const FieldFilterOperator: any;
export type FieldFilterOperatorsList = FieldFilterOperator[];
export declare const FieldFilterOperatorsList: any;
export type CustomProperties = {
    [key: string]: string | undefined;
};
export declare const CustomProperties: any;
export interface Field {
    FieldName?: string;
    Label?: string;
    Description?: string;
    FieldType?: FieldDataType;
    IsPrimaryKey?: boolean;
    IsNullable?: boolean;
    IsRetrievable?: boolean;
    IsFilterable?: boolean;
    IsPartitionable?: boolean;
    IsCreateable?: boolean;
    IsUpdateable?: boolean;
    IsUpsertable?: boolean;
    IsDefaultOnCreate?: boolean;
    SupportedValues?: string[];
    SupportedFilterOperators?: FieldFilterOperator[];
    ParentField?: string;
    NativeDataType?: string;
    CustomProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const Field: S.Schema<Field>;
export type FieldsList = Field[];
export declare const FieldsList: any;
export interface DescribeEntityResponse {
    Fields?: Field[];
    NextToken?: string;
}
export declare const DescribeEntityResponse: S.Schema<DescribeEntityResponse>;
export type IntegrationInteger = number;
export interface DescribeInboundIntegrationsRequest {
    IntegrationArn?: string;
    Marker?: string;
    MaxRecords?: number;
    TargetArn?: string;
}
export declare const DescribeInboundIntegrationsRequest: S.Schema<DescribeInboundIntegrationsRequest>;
export interface InboundIntegration {
    SourceArn: string;
    TargetArn: string;
    IntegrationArn: string;
    Status: IntegrationStatus;
    CreateTime: Date;
    IntegrationConfig?: IntegrationConfig;
    Errors?: IntegrationError[];
}
export declare const InboundIntegration: S.Schema<InboundIntegration>;
export type InboundIntegrationsList = InboundIntegration[];
export declare const InboundIntegrationsList: any;
export interface DescribeInboundIntegrationsResponse {
    InboundIntegrations?: InboundIntegration[];
    Marker?: string;
}
export declare const DescribeInboundIntegrationsResponse: S.Schema<DescribeInboundIntegrationsResponse>;
export type IntegrationFilterValues = string[];
export declare const IntegrationFilterValues: any;
export interface IntegrationFilter {
    Name?: string;
    Values?: string[];
}
export declare const IntegrationFilter: S.Schema<IntegrationFilter>;
export type IntegrationFilterList = IntegrationFilter[];
export declare const IntegrationFilterList: any;
export interface DescribeIntegrationsRequest {
    IntegrationIdentifier?: string;
    Marker?: string;
    MaxRecords?: number;
    Filters?: IntegrationFilter[];
}
export declare const DescribeIntegrationsRequest: S.Schema<DescribeIntegrationsRequest>;
export interface Integration {
    SourceArn: string;
    TargetArn: string;
    Description?: string;
    IntegrationName: string;
    IntegrationArn: string;
    KmsKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
    Status: IntegrationStatus;
    CreateTime: Date;
    IntegrationConfig?: IntegrationConfig;
    Errors?: IntegrationError[];
    DataFilter?: string;
}
export declare const Integration: S.Schema<Integration>;
export type IntegrationsList = Integration[];
export declare const IntegrationsList: any;
export interface DescribeIntegrationsResponse {
    Integrations?: Integration[];
    Marker?: string;
}
export declare const DescribeIntegrationsResponse: S.Schema<DescribeIntegrationsResponse>;
export interface DisassociateGlossaryTermsRequest {
    AssetIdentifier: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
    GlossaryTermIdentifiers: string[];
    ClientToken?: string;
}
export declare const DisassociateGlossaryTermsRequest: S.Schema<DisassociateGlossaryTermsRequest>;
export interface DisassociateGlossaryTermsResponse {
    AssetIdentifier?: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
    GlossaryTerms?: string[];
}
export declare const DisassociateGlossaryTermsResponse: S.Schema<DisassociateGlossaryTermsResponse>;
export interface GetAssetInput {
    Identifier: string;
}
export declare const GetAssetInput: S.Schema<GetAssetInput>;
export type AssetName = string;
export type AssetDescription = string;
export type CreatedAt = Date;
export type UpdatedAt = Date;
export type IterableFormKey = string;
export interface IterableFormEntry {
    FormTypeId?: string;
}
export declare const IterableFormEntry: S.Schema<IterableFormEntry>;
export type IterableFormMap = {
    [key: string]: IterableFormEntry | undefined;
};
export declare const IterableFormMap: any;
export interface GetAssetOutput {
    Id: string;
    Name?: string;
    Description?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
    AssetTypeId: string;
    GlossaryTerms?: string[];
    Forms?: {
        [key: string]: AssetFormEntry | undefined;
    };
    Attachments?: {
        [key: string]: AssetFormEntry | undefined;
    };
    IterableForms?: {
        [key: string]: IterableFormEntry | undefined;
    };
}
export declare const GetAssetOutput: S.Schema<GetAssetOutput>;
export interface GetAssetTypeRequest {
    Identifier: string;
}
export declare const GetAssetTypeRequest: S.Schema<GetAssetTypeRequest>;
export type AssetTypeName = string;
export type AssetTypeFormKey = string;
export interface AssetTypeFormReference {
    FormTypeIdentifier: string;
}
export declare const AssetTypeFormReference: S.Schema<AssetTypeFormReference>;
export type AssetTypeFormsMap = {
    [key: string]: AssetTypeFormReference | undefined;
};
export declare const AssetTypeFormsMap: any;
export interface GetAssetTypeResponse {
    Id?: string;
    Name?: string;
    Forms?: {
        [key: string]: AssetTypeFormReference | undefined;
    };
}
export declare const GetAssetTypeResponse: S.Schema<GetAssetTypeResponse>;
export interface GetBlueprintRequest {
    Name: string;
    IncludeBlueprint?: boolean;
    IncludeParameterSpec?: boolean;
}
export declare const GetBlueprintRequest: S.Schema<GetBlueprintRequest>;
export interface GetBlueprintResponse {
    Blueprint?: Blueprint;
}
export declare const GetBlueprintResponse: S.Schema<GetBlueprintResponse>;
export interface GetBlueprintRunRequest {
    BlueprintName: string;
    RunId: string;
}
export declare const GetBlueprintRunRequest: S.Schema<GetBlueprintRunRequest>;
export type BlueprintRunState = "RUNNING" | "SUCCEEDED" | "FAILED" | "ROLLING_BACK" | (string & {});
export declare const BlueprintRunState: any;
export type BlueprintParameters = string;
export type OrchestrationIAMRoleArn = string;
export interface BlueprintRun {
    BlueprintName?: string;
    RunId?: string;
    WorkflowName?: string;
    State?: BlueprintRunState;
    StartedOn?: Date;
    CompletedOn?: Date;
    ErrorMessage?: string;
    RollbackErrorMessage?: string;
    Parameters?: string;
    RoleArn?: string;
}
export declare const BlueprintRun: S.Schema<BlueprintRun>;
export interface GetBlueprintRunResponse {
    BlueprintRun?: BlueprintRun;
}
export declare const GetBlueprintRunResponse: S.Schema<GetBlueprintRunResponse>;
export type PageSize = number;
export interface GetBlueprintRunsRequest {
    BlueprintName: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetBlueprintRunsRequest: S.Schema<GetBlueprintRunsRequest>;
export type BlueprintRuns = BlueprintRun[];
export declare const BlueprintRuns: any;
export interface GetBlueprintRunsResponse {
    BlueprintRuns?: BlueprintRun[];
    NextToken?: string;
}
export declare const GetBlueprintRunsResponse: S.Schema<GetBlueprintRunsResponse>;
export interface GetCatalogRequest {
    CatalogId: string;
}
export declare const GetCatalogRequest: S.Schema<GetCatalogRequest>;
export interface DataLakeAccessPropertiesOutput {
    DataLakeAccess?: boolean;
    DataTransferRole?: string;
    KmsKey?: string;
    ManagedWorkgroupName?: string;
    ManagedWorkgroupStatus?: string;
    RedshiftDatabaseName?: string;
    StatusMessage?: string;
    CatalogType?: string;
}
export declare const DataLakeAccessPropertiesOutput: S.Schema<DataLakeAccessPropertiesOutput>;
export interface IcebergOptimizationPropertiesOutput {
    RoleArn?: string;
    Compaction?: {
        [key: string]: string | undefined;
    };
    Retention?: {
        [key: string]: string | undefined;
    };
    OrphanFileDeletion?: {
        [key: string]: string | undefined;
    };
    LastUpdatedTime?: Date;
}
export declare const IcebergOptimizationPropertiesOutput: S.Schema<IcebergOptimizationPropertiesOutput>;
export interface CatalogPropertiesOutput {
    DataLakeAccessProperties?: DataLakeAccessPropertiesOutput;
    IcebergOptimizationProperties?: IcebergOptimizationPropertiesOutput;
    CustomProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const CatalogPropertiesOutput: S.Schema<CatalogPropertiesOutput>;
export interface Catalog {
    CatalogId?: string;
    Name: string;
    ResourceArn?: string;
    Description?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    CreateTime?: Date;
    UpdateTime?: Date;
    TargetRedshiftCatalog?: TargetRedshiftCatalog;
    FederatedCatalog?: FederatedCatalog;
    CatalogProperties?: CatalogPropertiesOutput;
    CreateTableDefaultPermissions?: PrincipalPermissions[];
    CreateDatabaseDefaultPermissions?: PrincipalPermissions[];
    AllowFullTableExternalDataAccess?: AllowFullTableExternalDataAccessEnum;
}
export declare const Catalog: S.Schema<Catalog>;
export interface GetCatalogResponse {
    Catalog?: Catalog;
}
export declare const GetCatalogResponse: S.Schema<GetCatalogResponse>;
export interface GetCatalogImportStatusRequest {
    CatalogId?: string;
}
export declare const GetCatalogImportStatusRequest: S.Schema<GetCatalogImportStatusRequest>;
export interface CatalogImportStatus {
    ImportCompleted?: boolean;
    ImportTime?: Date;
    ImportedBy?: string;
}
export declare const CatalogImportStatus: S.Schema<CatalogImportStatus>;
export interface GetCatalogImportStatusResponse {
    ImportStatus?: CatalogImportStatus;
}
export declare const GetCatalogImportStatusResponse: S.Schema<GetCatalogImportStatusResponse>;
export type Token = string;
export interface GetCatalogsRequest {
    ParentCatalogId?: string;
    NextToken?: string;
    MaxResults?: number;
    Recursive?: boolean;
    IncludeRoot?: boolean;
    HasDatabases?: boolean;
}
export declare const GetCatalogsRequest: S.Schema<GetCatalogsRequest>;
export type CatalogList = Catalog[];
export declare const CatalogList: any;
export interface GetCatalogsResponse {
    CatalogList: Catalog[];
    NextToken?: string;
}
export declare const GetCatalogsResponse: S.Schema<GetCatalogsResponse>;
export interface GetClassifierRequest {
    Name: string;
}
export declare const GetClassifierRequest: S.Schema<GetClassifierRequest>;
export interface GrokClassifier {
    Name: string;
    Classification: string;
    CreationTime?: Date;
    LastUpdated?: Date;
    Version?: number;
    GrokPattern: string;
    CustomPatterns?: string;
}
export declare const GrokClassifier: S.Schema<GrokClassifier>;
export interface XMLClassifier {
    Name: string;
    Classification: string;
    CreationTime?: Date;
    LastUpdated?: Date;
    Version?: number;
    RowTag?: string;
}
export declare const XMLClassifier: S.Schema<XMLClassifier>;
export interface JsonClassifier {
    Name: string;
    CreationTime?: Date;
    LastUpdated?: Date;
    Version?: number;
    JsonPath: string;
}
export declare const JsonClassifier: S.Schema<JsonClassifier>;
export interface CsvClassifier {
    Name: string;
    CreationTime?: Date;
    LastUpdated?: Date;
    Version?: number;
    Delimiter?: string;
    QuoteSymbol?: string;
    ContainsHeader?: CsvHeaderOption;
    Header?: string[];
    DisableValueTrimming?: boolean;
    AllowSingleColumn?: boolean;
    CustomDatatypeConfigured?: boolean;
    CustomDatatypes?: string[];
    Serde?: CsvSerdeOption;
}
export declare const CsvClassifier: S.Schema<CsvClassifier>;
export interface Classifier {
    GrokClassifier?: GrokClassifier;
    XMLClassifier?: XMLClassifier;
    JsonClassifier?: JsonClassifier;
    CsvClassifier?: CsvClassifier;
}
export declare const Classifier: S.Schema<Classifier>;
export interface GetClassifierResponse {
    Classifier?: Classifier;
}
export declare const GetClassifierResponse: S.Schema<GetClassifierResponse>;
export interface GetClassifiersRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetClassifiersRequest: S.Schema<GetClassifiersRequest>;
export type ClassifierList = Classifier[];
export declare const ClassifierList: any;
export interface GetClassifiersResponse {
    Classifiers?: Classifier[];
    NextToken?: string;
}
export declare const GetClassifiersResponse: S.Schema<GetClassifiersResponse>;
export type GetColumnNamesList = string[];
export declare const GetColumnNamesList: any;
export interface GetColumnStatisticsForPartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    ColumnNames: string[];
}
export declare const GetColumnStatisticsForPartitionRequest: S.Schema<GetColumnStatisticsForPartitionRequest>;
export type TypeString = string;
export type ColumnStatisticsType = "BOOLEAN" | "DATE" | "DECIMAL" | "DOUBLE" | "LONG" | "STRING" | "BINARY" | (string & {});
export declare const ColumnStatisticsType: any;
export type NonNegativeLong = number;
export interface BooleanColumnStatisticsData {
    NumberOfTrues: number;
    NumberOfFalses: number;
    NumberOfNulls: number;
}
export declare const BooleanColumnStatisticsData: S.Schema<BooleanColumnStatisticsData>;
export interface DateColumnStatisticsData {
    MinimumValue?: Date;
    MaximumValue?: Date;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export declare const DateColumnStatisticsData: S.Schema<DateColumnStatisticsData>;
export interface DecimalNumber {
    UnscaledValue: Uint8Array;
    Scale: number;
}
export declare const DecimalNumber: S.Schema<DecimalNumber>;
export interface DecimalColumnStatisticsData {
    MinimumValue?: DecimalNumber;
    MaximumValue?: DecimalNumber;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export declare const DecimalColumnStatisticsData: S.Schema<DecimalColumnStatisticsData>;
export interface DoubleColumnStatisticsData {
    MinimumValue?: number;
    MaximumValue?: number;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export declare const DoubleColumnStatisticsData: S.Schema<DoubleColumnStatisticsData>;
export interface LongColumnStatisticsData {
    MinimumValue?: number;
    MaximumValue?: number;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export declare const LongColumnStatisticsData: S.Schema<LongColumnStatisticsData>;
export type NonNegativeDouble = number;
export interface StringColumnStatisticsData {
    MaximumLength: number;
    AverageLength: number;
    NumberOfNulls: number;
    NumberOfDistinctValues: number;
}
export declare const StringColumnStatisticsData: S.Schema<StringColumnStatisticsData>;
export interface BinaryColumnStatisticsData {
    MaximumLength: number;
    AverageLength: number;
    NumberOfNulls: number;
}
export declare const BinaryColumnStatisticsData: S.Schema<BinaryColumnStatisticsData>;
export interface ColumnStatisticsData {
    Type: ColumnStatisticsType;
    BooleanColumnStatisticsData?: BooleanColumnStatisticsData;
    DateColumnStatisticsData?: DateColumnStatisticsData;
    DecimalColumnStatisticsData?: DecimalColumnStatisticsData;
    DoubleColumnStatisticsData?: DoubleColumnStatisticsData;
    LongColumnStatisticsData?: LongColumnStatisticsData;
    StringColumnStatisticsData?: StringColumnStatisticsData;
    BinaryColumnStatisticsData?: BinaryColumnStatisticsData;
}
export declare const ColumnStatisticsData: S.Schema<ColumnStatisticsData>;
export interface ColumnStatistics {
    ColumnName: string;
    ColumnType: string;
    AnalyzedTime: Date;
    StatisticsData: ColumnStatisticsData;
}
export declare const ColumnStatistics: S.Schema<ColumnStatistics>;
export type ColumnStatisticsList = ColumnStatistics[];
export declare const ColumnStatisticsList: any;
export interface ColumnError {
    ColumnName?: string;
    Error?: ErrorDetail;
}
export declare const ColumnError: S.Schema<ColumnError>;
export type ColumnErrors = ColumnError[];
export declare const ColumnErrors: any;
export interface GetColumnStatisticsForPartitionResponse {
    ColumnStatisticsList?: ColumnStatistics[];
    Errors?: ColumnError[];
}
export declare const GetColumnStatisticsForPartitionResponse: S.Schema<GetColumnStatisticsForPartitionResponse>;
export interface GetColumnStatisticsForTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    ColumnNames: string[];
}
export declare const GetColumnStatisticsForTableRequest: S.Schema<GetColumnStatisticsForTableRequest>;
export interface GetColumnStatisticsForTableResponse {
    ColumnStatisticsList?: ColumnStatistics[];
    Errors?: ColumnError[];
}
export declare const GetColumnStatisticsForTableResponse: S.Schema<GetColumnStatisticsForTableResponse>;
export interface GetColumnStatisticsTaskRunRequest {
    ColumnStatisticsTaskRunId: string;
}
export declare const GetColumnStatisticsTaskRunRequest: S.Schema<GetColumnStatisticsTaskRunRequest>;
export type TableName = string;
export type PositiveInteger = number;
export type ComputationType = "FULL" | "INCREMENTAL" | (string & {});
export declare const ComputationType: any;
export type ColumnStatisticsState = "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "STOPPED" | (string & {});
export declare const ColumnStatisticsState: any;
export interface ColumnStatisticsTaskRun {
    CustomerId?: string;
    ColumnStatisticsTaskRunId?: string;
    DatabaseName?: string;
    TableName?: string;
    ColumnNameList?: string[];
    CatalogID?: string;
    Role?: string;
    SampleSize?: number;
    SecurityConfiguration?: string;
    NumberOfWorkers?: number;
    WorkerType?: string;
    ComputationType?: ComputationType;
    Status?: ColumnStatisticsState;
    CreationTime?: Date;
    LastUpdated?: Date;
    StartTime?: Date;
    EndTime?: Date;
    ErrorMessage?: string;
    DPUSeconds?: number;
}
export declare const ColumnStatisticsTaskRun: S.Schema<ColumnStatisticsTaskRun>;
export interface GetColumnStatisticsTaskRunResponse {
    ColumnStatisticsTaskRun?: ColumnStatisticsTaskRun;
}
export declare const GetColumnStatisticsTaskRunResponse: S.Schema<GetColumnStatisticsTaskRunResponse>;
export interface GetColumnStatisticsTaskRunsRequest {
    DatabaseName: string;
    TableName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetColumnStatisticsTaskRunsRequest: S.Schema<GetColumnStatisticsTaskRunsRequest>;
export type ColumnStatisticsTaskRunsList = ColumnStatisticsTaskRun[];
export declare const ColumnStatisticsTaskRunsList: any;
export interface GetColumnStatisticsTaskRunsResponse {
    ColumnStatisticsTaskRuns?: ColumnStatisticsTaskRun[];
    NextToken?: string;
}
export declare const GetColumnStatisticsTaskRunsResponse: S.Schema<GetColumnStatisticsTaskRunsResponse>;
export interface GetColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
}
export declare const GetColumnStatisticsTaskSettingsRequest: S.Schema<GetColumnStatisticsTaskSettingsRequest>;
export type ScheduleType = "CRON" | "AUTO" | (string & {});
export declare const ScheduleType: any;
export type SettingSource = "CATALOG" | "TABLE" | (string & {});
export declare const SettingSource: any;
export type ExecutionStatus = "FAILED" | "STARTED" | (string & {});
export declare const ExecutionStatus: any;
export interface ExecutionAttempt {
    Status?: ExecutionStatus;
    ColumnStatisticsTaskRunId?: string;
    ExecutionTimestamp?: Date;
    ErrorMessage?: string;
}
export declare const ExecutionAttempt: S.Schema<ExecutionAttempt>;
export interface ColumnStatisticsTaskSettings {
    DatabaseName?: string;
    TableName?: string;
    Schedule?: Schedule;
    ColumnNameList?: string[];
    CatalogID?: string;
    Role?: string;
    SampleSize?: number;
    SecurityConfiguration?: string;
    ScheduleType?: ScheduleType;
    SettingSource?: SettingSource;
    LastExecutionAttempt?: ExecutionAttempt;
}
export declare const ColumnStatisticsTaskSettings: S.Schema<ColumnStatisticsTaskSettings>;
export interface GetColumnStatisticsTaskSettingsResponse {
    ColumnStatisticsTaskSettings?: ColumnStatisticsTaskSettings;
}
export declare const GetColumnStatisticsTaskSettingsResponse: S.Schema<GetColumnStatisticsTaskSettingsResponse>;
export interface GetConnectionRequest {
    CatalogId?: string;
    Name: string;
    HidePassword?: boolean;
    ApplyOverrideForComputeEnvironment?: ComputeEnvironment;
}
export declare const GetConnectionRequest: S.Schema<GetConnectionRequest>;
export type LongValueString = string;
export interface OAuth2Properties {
    OAuth2GrantType?: OAuth2GrantType;
    OAuth2ClientApplication?: OAuth2ClientApplication;
    TokenUrl?: string;
    TokenUrlParametersMap?: {
        [key: string]: string | undefined;
    };
}
export declare const OAuth2Properties: S.Schema<OAuth2Properties>;
export interface AuthenticationConfiguration {
    AuthenticationType?: AuthenticationType;
    SecretArn?: string;
    KmsKeyArn?: string;
    OAuth2Properties?: OAuth2Properties;
}
export declare const AuthenticationConfiguration: S.Schema<AuthenticationConfiguration>;
export type ConnectionSchemaVersion = number;
export interface Connection {
    Name?: string;
    Description?: string;
    ConnectionType?: ConnectionType;
    MatchCriteria?: string[];
    ConnectionProperties?: {
        [key: string]: string | undefined;
    };
    SparkProperties?: {
        [key: string]: string | undefined;
    };
    AthenaProperties?: {
        [key: string]: string | undefined;
    };
    PythonProperties?: {
        [key: string]: string | undefined;
    };
    PhysicalConnectionRequirements?: PhysicalConnectionRequirements;
    CreationTime?: Date;
    LastUpdatedTime?: Date;
    LastUpdatedBy?: string;
    Status?: ConnectionStatus;
    StatusReason?: string;
    LastConnectionValidationTime?: Date;
    AuthenticationConfiguration?: AuthenticationConfiguration;
    ConnectionSchemaVersion?: number;
    CompatibleComputeEnvironments?: ComputeEnvironment[];
}
export declare const Connection: S.Schema<Connection>;
export interface GetConnectionResponse {
    Connection?: Connection;
}
export declare const GetConnectionResponse: S.Schema<GetConnectionResponse>;
export interface GetConnectionsFilter {
    MatchCriteria?: string[];
    ConnectionType?: ConnectionType;
    ConnectionSchemaVersion?: number;
}
export declare const GetConnectionsFilter: S.Schema<GetConnectionsFilter>;
export interface GetConnectionsRequest {
    CatalogId?: string;
    Filter?: GetConnectionsFilter;
    HidePassword?: boolean;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetConnectionsRequest: S.Schema<GetConnectionsRequest>;
export type ConnectionList = Connection[];
export declare const ConnectionList: any;
export interface GetConnectionsResponse {
    ConnectionList?: Connection[];
    NextToken?: string;
}
export declare const GetConnectionsResponse: S.Schema<GetConnectionsResponse>;
export interface GetCrawlerRequest {
    Name: string;
}
export declare const GetCrawlerRequest: S.Schema<GetCrawlerRequest>;
export interface GetCrawlerResponse {
    Crawler?: Crawler;
}
export declare const GetCrawlerResponse: S.Schema<GetCrawlerResponse>;
export interface GetCrawlerMetricsRequest {
    CrawlerNameList?: string[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetCrawlerMetricsRequest: S.Schema<GetCrawlerMetricsRequest>;
export interface CrawlerMetrics {
    CrawlerName?: string;
    TimeLeftSeconds?: number;
    StillEstimating?: boolean;
    LastRuntimeSeconds?: number;
    MedianRuntimeSeconds?: number;
    TablesCreated?: number;
    TablesUpdated?: number;
    TablesDeleted?: number;
}
export declare const CrawlerMetrics: S.Schema<CrawlerMetrics>;
export type CrawlerMetricsList = CrawlerMetrics[];
export declare const CrawlerMetricsList: any;
export interface GetCrawlerMetricsResponse {
    CrawlerMetricsList?: CrawlerMetrics[];
    NextToken?: string;
}
export declare const GetCrawlerMetricsResponse: S.Schema<GetCrawlerMetricsResponse>;
export interface GetCrawlersRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetCrawlersRequest: S.Schema<GetCrawlersRequest>;
export interface GetCrawlersResponse {
    Crawlers?: Crawler[];
    NextToken?: string;
}
export declare const GetCrawlersResponse: S.Schema<GetCrawlersResponse>;
export interface GetCustomEntityTypeRequest {
    Name: string;
}
export declare const GetCustomEntityTypeRequest: S.Schema<GetCustomEntityTypeRequest>;
export interface GetCustomEntityTypeResponse {
    Name?: string;
    RegexString?: string;
    ContextWords?: string[];
}
export declare const GetCustomEntityTypeResponse: S.Schema<GetCustomEntityTypeResponse>;
export type GlueResourceType = "JOB" | "SESSION" | (string & {});
export declare const GlueResourceType: any;
export interface GetDashboardUrlRequest {
    ResourceId: string;
    ResourceType: GlueResourceType;
    RequestOrigin?: string;
}
export declare const GetDashboardUrlRequest: S.Schema<GetDashboardUrlRequest>;
export type SensitiveUrl = string | redacted.Redacted<string>;
export interface GetDashboardUrlResponse {
    Url: string | redacted.Redacted<string>;
}
export declare const GetDashboardUrlResponse: S.Schema<GetDashboardUrlResponse>;
export interface GetDatabaseRequest {
    CatalogId?: string;
    Name: string;
}
export declare const GetDatabaseRequest: S.Schema<GetDatabaseRequest>;
export interface Database {
    Name: string;
    Description?: string;
    LocationUri?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    CreateTime?: Date;
    CreateTableDefaultPermissions?: PrincipalPermissions[];
    TargetDatabase?: DatabaseIdentifier;
    CatalogId?: string;
    FederatedDatabase?: FederatedDatabase;
}
export declare const Database: S.Schema<Database>;
export interface GetDatabaseResponse {
    Database?: Database;
}
export declare const GetDatabaseResponse: S.Schema<GetDatabaseResponse>;
export type CatalogGetterPageSize = number;
export type ResourceShareType = "FOREIGN" | "ALL" | "FEDERATED" | (string & {});
export declare const ResourceShareType: any;
export type DatabaseAttributes = "NAME" | "TARGET_DATABASE" | (string & {});
export declare const DatabaseAttributes: any;
export type DatabaseAttributesList = DatabaseAttributes[];
export declare const DatabaseAttributesList: any;
export interface GetDatabasesRequest {
    CatalogId?: string;
    NextToken?: string;
    MaxResults?: number;
    ResourceShareType?: ResourceShareType;
    AttributesToGet?: DatabaseAttributes[];
}
export declare const GetDatabasesRequest: S.Schema<GetDatabasesRequest>;
export type DatabaseList = Database[];
export declare const DatabaseList: any;
export interface GetDatabasesResponse {
    DatabaseList: Database[];
    NextToken?: string;
}
export declare const GetDatabasesResponse: S.Schema<GetDatabasesResponse>;
export interface GetDataCatalogEncryptionSettingsRequest {
    CatalogId?: string;
}
export declare const GetDataCatalogEncryptionSettingsRequest: S.Schema<GetDataCatalogEncryptionSettingsRequest>;
export type CatalogEncryptionMode = "DISABLED" | "SSE-KMS" | "SSE-KMS-WITH-SERVICE-ROLE" | (string & {});
export declare const CatalogEncryptionMode: any;
export interface EncryptionAtRest {
    CatalogEncryptionMode: CatalogEncryptionMode;
    SseAwsKmsKeyId?: string;
    CatalogEncryptionServiceRole?: string;
}
export declare const EncryptionAtRest: S.Schema<EncryptionAtRest>;
export interface ConnectionPasswordEncryption {
    ReturnConnectionPasswordEncrypted: boolean;
    AwsKmsKeyId?: string;
}
export declare const ConnectionPasswordEncryption: S.Schema<ConnectionPasswordEncryption>;
export interface DataCatalogEncryptionSettings {
    EncryptionAtRest?: EncryptionAtRest;
    ConnectionPasswordEncryption?: ConnectionPasswordEncryption;
}
export declare const DataCatalogEncryptionSettings: S.Schema<DataCatalogEncryptionSettings>;
export interface GetDataCatalogEncryptionSettingsResponse {
    DataCatalogEncryptionSettings?: DataCatalogEncryptionSettings;
}
export declare const GetDataCatalogEncryptionSettingsResponse: S.Schema<GetDataCatalogEncryptionSettingsResponse>;
export interface GetDataCatalogExportConfigurationInput {
}
export declare const GetDataCatalogExportConfigurationInput: S.Schema<GetDataCatalogExportConfigurationInput>;
export type ExportSetting = "ENABLED" | "DISABLED" | (string & {});
export declare const ExportSetting: any;
export type ExportStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | "FAILED" | (string & {});
export declare const ExportStatus: any;
export type SseAlgorithm = string;
export type KmsKeyArnString = string;
export interface ExportEncryptionConfiguration {
    SseAlgorithm?: string;
    KmsKeyArn?: string;
}
export declare const ExportEncryptionConfiguration: S.Schema<ExportEncryptionConfiguration>;
export type S3TableBucketArn = string;
export interface GetDataCatalogExportConfigurationOutput {
    ExportSetting?: ExportSetting;
    Status?: ExportStatus;
    EncryptionConfiguration?: ExportEncryptionConfiguration;
    S3TableBucketArn?: string;
    CreatedAt?: Date;
    UpdatedAt?: Date;
}
export declare const GetDataCatalogExportConfigurationOutput: S.Schema<GetDataCatalogExportConfigurationOutput>;
export interface GetDataflowGraphRequest {
    PythonScript?: string;
}
export declare const GetDataflowGraphRequest: S.Schema<GetDataflowGraphRequest>;
export interface GetDataflowGraphResponse {
    DagNodes?: CodeGenNode[];
    DagEdges?: CodeGenEdge[];
}
export declare const GetDataflowGraphResponse: S.Schema<GetDataflowGraphResponse>;
export interface GetDataQualityModelRequest {
    StatisticId?: string;
    ProfileId: string;
}
export declare const GetDataQualityModelRequest: S.Schema<GetDataQualityModelRequest>;
export type DataQualityModelStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export declare const DataQualityModelStatus: any;
export interface GetDataQualityModelResponse {
    Status?: DataQualityModelStatus;
    StartedOn?: Date;
    CompletedOn?: Date;
    FailureReason?: string;
}
export declare const GetDataQualityModelResponse: S.Schema<GetDataQualityModelResponse>;
export interface GetDataQualityModelResultRequest {
    StatisticId: string;
    ProfileId: string;
}
export declare const GetDataQualityModelResultRequest: S.Schema<GetDataQualityModelResultRequest>;
export interface StatisticModelResult {
    LowerBound?: number;
    UpperBound?: number;
    PredictedValue?: number;
    ActualValue?: number;
    Date?: Date;
    InclusionAnnotation?: InclusionAnnotationValue;
}
export declare const StatisticModelResult: S.Schema<StatisticModelResult>;
export type StatisticModelResults = StatisticModelResult[];
export declare const StatisticModelResults: any;
export interface GetDataQualityModelResultResponse {
    CompletedOn?: Date;
    Model?: StatisticModelResult[];
}
export declare const GetDataQualityModelResultResponse: S.Schema<GetDataQualityModelResultResponse>;
export interface GetDataQualityResultRequest {
    ResultId: string;
}
export declare const GetDataQualityResultRequest: S.Schema<GetDataQualityResultRequest>;
export interface GetDataQualityResultResponse {
    ResultId?: string;
    ProfileId?: string;
    Score?: number;
    DataSource?: DataSource;
    RulesetName?: string;
    EvaluationContext?: string;
    StartedOn?: Date;
    CompletedOn?: Date;
    JobName?: string;
    JobRunId?: string;
    RulesetEvaluationRunId?: string;
    RuleResults?: DataQualityRuleResult[];
    AnalyzerResults?: DataQualityAnalyzerResult[];
    Observations?: DataQualityObservation[];
    AggregatedMetrics?: DataQualityAggregatedMetrics;
}
export declare const GetDataQualityResultResponse: S.Schema<GetDataQualityResultResponse>;
export interface GetDataQualityRuleRecommendationRunRequest {
    RunId: string;
}
export declare const GetDataQualityRuleRecommendationRunRequest: S.Schema<GetDataQualityRuleRecommendationRunRequest>;
export interface DataQualityRuleRecommendationRunAdditionalRunOptions {
    CustomLogGroupPrefix?: string;
}
export declare const DataQualityRuleRecommendationRunAdditionalRunOptions: S.Schema<DataQualityRuleRecommendationRunAdditionalRunOptions>;
export interface GetDataQualityRuleRecommendationRunResponse {
    RunId?: string;
    DataSource?: DataSource;
    Role?: string;
    NumberOfWorkers?: number;
    Timeout?: number;
    Status?: TaskStatusType;
    ErrorString?: string;
    StartedOn?: Date;
    LastModifiedOn?: Date;
    CompletedOn?: Date;
    ExecutionTime?: number;
    RecommendedRuleset?: string;
    CreatedRulesetName?: string;
    DataQualitySecurityConfiguration?: string;
    AdditionalRunOptions?: DataQualityRuleRecommendationRunAdditionalRunOptions;
}
export declare const GetDataQualityRuleRecommendationRunResponse: S.Schema<GetDataQualityRuleRecommendationRunResponse>;
export interface GetDataQualityRulesetRequest {
    Name: string;
}
export declare const GetDataQualityRulesetRequest: S.Schema<GetDataQualityRulesetRequest>;
export interface GetDataQualityRulesetResponse {
    Name?: string;
    Description?: string;
    Ruleset?: string;
    TargetTable?: DataQualityTargetTable;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
    RecommendationRunId?: string;
    DataQualitySecurityConfiguration?: string;
}
export declare const GetDataQualityRulesetResponse: S.Schema<GetDataQualityRulesetResponse>;
export interface GetDataQualityRulesetEvaluationRunRequest {
    RunId: string;
}
export declare const GetDataQualityRulesetEvaluationRunRequest: S.Schema<GetDataQualityRulesetEvaluationRunRequest>;
export interface GetDataQualityRulesetEvaluationRunResponse {
    RunId?: string;
    DataSource?: DataSource;
    Role?: string;
    NumberOfWorkers?: number;
    Timeout?: number;
    AdditionalRunOptions?: DataQualityEvaluationRunAdditionalRunOptions;
    Status?: TaskStatusType;
    ErrorString?: string;
    StartedOn?: Date;
    LastModifiedOn?: Date;
    CompletedOn?: Date;
    ExecutionTime?: number;
    RulesetNames?: string[];
    ResultIds?: string[];
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    };
}
export declare const GetDataQualityRulesetEvaluationRunResponse: S.Schema<GetDataQualityRulesetEvaluationRunResponse>;
export interface GetDevEndpointRequest {
    EndpointName: string;
}
export declare const GetDevEndpointRequest: S.Schema<GetDevEndpointRequest>;
export interface GetDevEndpointResponse {
    DevEndpoint?: DevEndpoint;
}
export declare const GetDevEndpointResponse: S.Schema<GetDevEndpointResponse>;
export interface GetDevEndpointsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetDevEndpointsRequest: S.Schema<GetDevEndpointsRequest>;
export interface GetDevEndpointsResponse {
    DevEndpoints?: DevEndpoint[];
    NextToken?: string;
}
export declare const GetDevEndpointsResponse: S.Schema<GetDevEndpointsResponse>;
export type OptionKey = string;
export type OptionValue = string;
export type ConnectionOptions = {
    [key: string]: string | undefined;
};
export declare const ConnectionOptions: any;
export type FilterPredicate = string;
export type Limit = number;
export type SelectedFields = string[];
export declare const SelectedFields: any;
export interface GetEntityRecordsRequest {
    ConnectionName?: string;
    CatalogId?: string;
    EntityName: string;
    NextToken?: string;
    DataStoreApiVersion?: string;
    ConnectionOptions?: {
        [key: string]: string | undefined;
    };
    FilterPredicate?: string;
    Limit: number;
    OrderBy?: string;
    SelectedFields?: string[];
}
export declare const GetEntityRecordsRequest: S.Schema<GetEntityRecordsRequest>;
export type Record = unknown;
export type Records = any[];
export declare const Records: any;
export interface GetEntityRecordsResponse {
    Records?: any[];
    NextToken?: string;
}
export declare const GetEntityRecordsResponse: S.Schema<GetEntityRecordsResponse>;
export interface GetFormTypeRequest {
    Identifier: string;
}
export declare const GetFormTypeRequest: S.Schema<GetFormTypeRequest>;
export type FormTypeName = string;
export type FormTypeSchema = string;
export interface GetFormTypeResponse {
    Id?: string;
    Name?: string;
    Schema?: string;
}
export declare const GetFormTypeResponse: S.Schema<GetFormTypeResponse>;
export interface GetGlossaryRequest {
    Identifier: string;
}
export declare const GetGlossaryRequest: S.Schema<GetGlossaryRequest>;
export interface GetGlossaryResponse {
    Id?: string;
    Name?: string;
    Description?: string;
}
export declare const GetGlossaryResponse: S.Schema<GetGlossaryResponse>;
export interface GetGlossaryTermRequest {
    Identifier: string;
}
export declare const GetGlossaryTermRequest: S.Schema<GetGlossaryTermRequest>;
export interface GetGlossaryTermResponse {
    Id?: string;
    GlossaryId?: string;
    Name?: string;
    ShortDescription?: string;
    LongDescription?: string;
}
export declare const GetGlossaryTermResponse: S.Schema<GetGlossaryTermResponse>;
export interface GetGlueIdentityCenterConfigurationRequest {
}
export declare const GetGlueIdentityCenterConfigurationRequest: S.Schema<GetGlueIdentityCenterConfigurationRequest>;
export type OrchestrationStringList = string[];
export declare const OrchestrationStringList: any;
export interface GetGlueIdentityCenterConfigurationResponse {
    ApplicationArn?: string;
    InstanceArn?: string;
    Scopes?: string[];
    UserBackgroundSessionsEnabled?: boolean;
}
export declare const GetGlueIdentityCenterConfigurationResponse: S.Schema<GetGlueIdentityCenterConfigurationResponse>;
export interface GetIntegrationResourcePropertyRequest {
    ResourceArn: string;
}
export declare const GetIntegrationResourcePropertyRequest: S.Schema<GetIntegrationResourcePropertyRequest>;
export interface GetIntegrationResourcePropertyResponse {
    ResourceArn?: string;
    ResourcePropertyArn?: string;
    SourceProcessingProperties?: SourceProcessingProperties;
    TargetProcessingProperties?: TargetProcessingProperties;
}
export declare const GetIntegrationResourcePropertyResponse: S.Schema<GetIntegrationResourcePropertyResponse>;
export interface GetIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
}
export declare const GetIntegrationTablePropertiesRequest: S.Schema<GetIntegrationTablePropertiesRequest>;
export interface GetIntegrationTablePropertiesResponse {
    ResourceArn?: string;
    TableName?: string;
    SourceTableConfig?: SourceTableConfig;
    TargetTableConfig?: TargetTableConfig;
}
export declare const GetIntegrationTablePropertiesResponse: S.Schema<GetIntegrationTablePropertiesResponse>;
export interface GetJobRequest {
    JobName: string;
}
export declare const GetJobRequest: S.Schema<GetJobRequest>;
export interface GetJobResponse {
    Job?: Job;
}
export declare const GetJobResponse: S.Schema<GetJobResponse>;
export type JobName = string;
export type RunId = string;
export interface GetJobBookmarkRequest {
    JobName: string;
    RunId?: string;
}
export declare const GetJobBookmarkRequest: S.Schema<GetJobBookmarkRequest>;
export type JsonValue = string;
export interface JobBookmarkEntry {
    JobName?: string;
    Version?: number;
    Run?: number;
    Attempt?: number;
    PreviousRunId?: string;
    RunId?: string;
    JobBookmark?: string;
}
export declare const JobBookmarkEntry: S.Schema<JobBookmarkEntry>;
export interface GetJobBookmarkResponse {
    JobBookmarkEntry?: JobBookmarkEntry;
}
export declare const GetJobBookmarkResponse: S.Schema<GetJobBookmarkResponse>;
export interface GetJobRunRequest {
    JobName: string;
    RunId: string;
    PredecessorsIncluded?: boolean;
}
export declare const GetJobRunRequest: S.Schema<GetJobRunRequest>;
export interface GetJobRunResponse {
    JobRun?: JobRun;
}
export declare const GetJobRunResponse: S.Schema<GetJobRunResponse>;
export type OrchestrationPageSize200 = number;
export interface GetJobRunsRequest {
    JobName: string;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetJobRunsRequest: S.Schema<GetJobRunsRequest>;
export interface GetJobRunsResponse {
    JobRuns?: JobRun[];
    NextToken?: string;
}
export declare const GetJobRunsResponse: S.Schema<GetJobRunsResponse>;
export interface GetJobsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetJobsRequest: S.Schema<GetJobsRequest>;
export interface GetJobsResponse {
    Jobs?: Job[];
    NextToken?: string;
}
export declare const GetJobsResponse: S.Schema<GetJobsResponse>;
export interface CatalogEntry {
    DatabaseName: string;
    TableName: string;
}
export declare const CatalogEntry: S.Schema<CatalogEntry>;
export type CatalogEntries = CatalogEntry[];
export declare const CatalogEntries: any;
export interface Location {
    Jdbc?: CodeGenNodeArg[];
    S3?: CodeGenNodeArg[];
    DynamoDB?: CodeGenNodeArg[];
}
export declare const Location: S.Schema<Location>;
export interface GetMappingRequest {
    Source: CatalogEntry;
    Sinks?: CatalogEntry[];
    Location?: Location;
}
export declare const GetMappingRequest: S.Schema<GetMappingRequest>;
export type SchemaPathString = string;
export type FieldType = string;
export interface MappingEntry {
    SourceTable?: string;
    SourcePath?: string;
    SourceType?: string;
    TargetTable?: string;
    TargetPath?: string;
    TargetType?: string;
}
export declare const MappingEntry: S.Schema<MappingEntry>;
export type MappingList = MappingEntry[];
export declare const MappingList: any;
export interface GetMappingResponse {
    Mapping: MappingEntry[];
}
export declare const GetMappingResponse: S.Schema<GetMappingResponse>;
export type UUIDv4 = string;
export interface GetMaterializedViewRefreshTaskRunRequest {
    CatalogId: string;
    MaterializedViewRefreshTaskRunId: string;
}
export declare const GetMaterializedViewRefreshTaskRunRequest: S.Schema<GetMaterializedViewRefreshTaskRunRequest>;
export type MaterializedViewRefreshState = "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "STOPPED" | (string & {});
export declare const MaterializedViewRefreshState: any;
export type MaterializedViewRefreshType = "FULL" | "INCREMENTAL" | (string & {});
export declare const MaterializedViewRefreshType: any;
export type ByteCount = number;
export interface MaterializedViewRefreshTaskRun {
    CustomerId?: string;
    MaterializedViewRefreshTaskRunId?: string;
    DatabaseName?: string;
    TableName?: string;
    CatalogId?: string;
    Role?: string;
    Status?: MaterializedViewRefreshState;
    CreationTime?: Date;
    LastUpdated?: Date;
    StartTime?: Date;
    EndTime?: Date;
    ErrorMessage?: string;
    DPUSeconds?: number;
    RefreshType?: MaterializedViewRefreshType;
    ProcessedBytes?: number;
}
export declare const MaterializedViewRefreshTaskRun: S.Schema<MaterializedViewRefreshTaskRun>;
export interface GetMaterializedViewRefreshTaskRunResponse {
    MaterializedViewRefreshTaskRun?: MaterializedViewRefreshTaskRun;
}
export declare const GetMaterializedViewRefreshTaskRunResponse: S.Schema<GetMaterializedViewRefreshTaskRunResponse>;
export interface GetMLTaskRunRequest {
    TransformId: string;
    TaskRunId: string;
}
export declare const GetMLTaskRunRequest: S.Schema<GetMLTaskRunRequest>;
export type TaskType = "EVALUATION" | "LABELING_SET_GENERATION" | "IMPORT_LABELS" | "EXPORT_LABELS" | "FIND_MATCHES" | (string & {});
export declare const TaskType: any;
export type ReplaceBoolean = boolean;
export interface ImportLabelsTaskRunProperties {
    InputS3Path?: string;
    Replace?: boolean;
}
export declare const ImportLabelsTaskRunProperties: S.Schema<ImportLabelsTaskRunProperties>;
export interface ExportLabelsTaskRunProperties {
    OutputS3Path?: string;
}
export declare const ExportLabelsTaskRunProperties: S.Schema<ExportLabelsTaskRunProperties>;
export interface LabelingSetGenerationTaskRunProperties {
    OutputS3Path?: string;
}
export declare const LabelingSetGenerationTaskRunProperties: S.Schema<LabelingSetGenerationTaskRunProperties>;
export interface FindMatchesTaskRunProperties {
    JobId?: string;
    JobName?: string;
    JobRunId?: string;
}
export declare const FindMatchesTaskRunProperties: S.Schema<FindMatchesTaskRunProperties>;
export interface TaskRunProperties {
    TaskType?: TaskType;
    ImportLabelsTaskRunProperties?: ImportLabelsTaskRunProperties;
    ExportLabelsTaskRunProperties?: ExportLabelsTaskRunProperties;
    LabelingSetGenerationTaskRunProperties?: LabelingSetGenerationTaskRunProperties;
    FindMatchesTaskRunProperties?: FindMatchesTaskRunProperties;
}
export declare const TaskRunProperties: S.Schema<TaskRunProperties>;
export interface GetMLTaskRunResponse {
    TransformId?: string;
    TaskRunId?: string;
    Status?: TaskStatusType;
    LogGroupName?: string;
    Properties?: TaskRunProperties;
    ErrorString?: string;
    StartedOn?: Date;
    LastModifiedOn?: Date;
    CompletedOn?: Date;
    ExecutionTime?: number;
}
export declare const GetMLTaskRunResponse: S.Schema<GetMLTaskRunResponse>;
export type PaginationToken = string;
export interface TaskRunFilterCriteria {
    TaskRunType?: TaskType;
    Status?: TaskStatusType;
    StartedBefore?: Date;
    StartedAfter?: Date;
}
export declare const TaskRunFilterCriteria: S.Schema<TaskRunFilterCriteria>;
export type TaskRunSortColumnType = "TASK_RUN_TYPE" | "STATUS" | "STARTED" | (string & {});
export declare const TaskRunSortColumnType: any;
export type SortDirectionType = "DESCENDING" | "ASCENDING" | (string & {});
export declare const SortDirectionType: any;
export interface TaskRunSortCriteria {
    Column: TaskRunSortColumnType;
    SortDirection: SortDirectionType;
}
export declare const TaskRunSortCriteria: S.Schema<TaskRunSortCriteria>;
export interface GetMLTaskRunsRequest {
    TransformId: string;
    NextToken?: string;
    MaxResults?: number;
    Filter?: TaskRunFilterCriteria;
    Sort?: TaskRunSortCriteria;
}
export declare const GetMLTaskRunsRequest: S.Schema<GetMLTaskRunsRequest>;
export interface TaskRun {
    TransformId?: string;
    TaskRunId?: string;
    Status?: TaskStatusType;
    LogGroupName?: string;
    Properties?: TaskRunProperties;
    ErrorString?: string;
    StartedOn?: Date;
    LastModifiedOn?: Date;
    CompletedOn?: Date;
    ExecutionTime?: number;
}
export declare const TaskRun: S.Schema<TaskRun>;
export type TaskRunList = TaskRun[];
export declare const TaskRunList: any;
export interface GetMLTaskRunsResponse {
    TaskRuns?: TaskRun[];
    NextToken?: string;
}
export declare const GetMLTaskRunsResponse: S.Schema<GetMLTaskRunsResponse>;
export interface GetMLTransformRequest {
    TransformId: string;
}
export declare const GetMLTransformRequest: S.Schema<GetMLTransformRequest>;
export type TransformStatusType = "NOT_READY" | "READY" | "DELETING" | (string & {});
export declare const TransformStatusType: any;
export type RecordsCount = number;
export interface ConfusionMatrix {
    NumTruePositives?: number;
    NumFalsePositives?: number;
    NumTrueNegatives?: number;
    NumFalseNegatives?: number;
}
export declare const ConfusionMatrix: S.Schema<ConfusionMatrix>;
export interface ColumnImportance {
    ColumnName?: string;
    Importance?: number;
}
export declare const ColumnImportance: S.Schema<ColumnImportance>;
export type ColumnImportanceList = ColumnImportance[];
export declare const ColumnImportanceList: any;
export interface FindMatchesMetrics {
    AreaUnderPRCurve?: number;
    Precision?: number;
    Recall?: number;
    F1?: number;
    ConfusionMatrix?: ConfusionMatrix;
    ColumnImportances?: ColumnImportance[];
}
export declare const FindMatchesMetrics: S.Schema<FindMatchesMetrics>;
export interface EvaluationMetrics {
    TransformType: TransformType;
    FindMatchesMetrics?: FindMatchesMetrics;
}
export declare const EvaluationMetrics: S.Schema<EvaluationMetrics>;
export type LabelCount = number;
export interface SchemaColumn {
    Name?: string;
    DataType?: string;
}
export declare const SchemaColumn: S.Schema<SchemaColumn>;
export type TransformSchema = SchemaColumn[];
export declare const TransformSchema: any;
export interface GetMLTransformResponse {
    TransformId?: string;
    Name?: string;
    Description?: string;
    Status?: TransformStatusType;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
    InputRecordTables?: GlueTable[];
    Parameters?: TransformParameters;
    EvaluationMetrics?: EvaluationMetrics;
    LabelCount?: number;
    Schema?: SchemaColumn[];
    Role?: string;
    GlueVersion?: string;
    MaxCapacity?: number;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    Timeout?: number;
    MaxRetries?: number;
    TransformEncryption?: TransformEncryption;
}
export declare const GetMLTransformResponse: S.Schema<GetMLTransformResponse>;
export interface TransformFilterCriteria {
    Name?: string;
    TransformType?: TransformType;
    Status?: TransformStatusType;
    GlueVersion?: string;
    CreatedBefore?: Date;
    CreatedAfter?: Date;
    LastModifiedBefore?: Date;
    LastModifiedAfter?: Date;
    Schema?: SchemaColumn[];
}
export declare const TransformFilterCriteria: S.Schema<TransformFilterCriteria>;
export type TransformSortColumnType = "NAME" | "TRANSFORM_TYPE" | "STATUS" | "CREATED" | "LAST_MODIFIED" | (string & {});
export declare const TransformSortColumnType: any;
export interface TransformSortCriteria {
    Column: TransformSortColumnType;
    SortDirection: SortDirectionType;
}
export declare const TransformSortCriteria: S.Schema<TransformSortCriteria>;
export interface GetMLTransformsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filter?: TransformFilterCriteria;
    Sort?: TransformSortCriteria;
}
export declare const GetMLTransformsRequest: S.Schema<GetMLTransformsRequest>;
export interface MLTransform {
    TransformId?: string;
    Name?: string;
    Description?: string;
    Status?: TransformStatusType;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
    InputRecordTables?: GlueTable[];
    Parameters?: TransformParameters;
    EvaluationMetrics?: EvaluationMetrics;
    LabelCount?: number;
    Schema?: SchemaColumn[];
    Role?: string;
    GlueVersion?: string;
    MaxCapacity?: number;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    Timeout?: number;
    MaxRetries?: number;
    TransformEncryption?: TransformEncryption;
}
export declare const MLTransform: S.Schema<MLTransform>;
export type TransformList = MLTransform[];
export declare const TransformList: any;
export interface GetMLTransformsResponse {
    Transforms: MLTransform[];
    NextToken?: string;
}
export declare const GetMLTransformsResponse: S.Schema<GetMLTransformsResponse>;
export interface GetPartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    AuditContext?: AuditContext;
}
export declare const GetPartitionRequest: S.Schema<GetPartitionRequest>;
export interface GetPartitionResponse {
    Partition?: Partition;
}
export declare const GetPartitionResponse: S.Schema<GetPartitionResponse>;
export interface GetPartitionIndexesRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    NextToken?: string;
}
export declare const GetPartitionIndexesRequest: S.Schema<GetPartitionIndexesRequest>;
export interface KeySchemaElement {
    Name: string;
    Type: string;
}
export declare const KeySchemaElement: S.Schema<KeySchemaElement>;
export type KeySchemaElementList = KeySchemaElement[];
export declare const KeySchemaElementList: any;
export type PartitionIndexStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | (string & {});
export declare const PartitionIndexStatus: any;
export type BackfillErrorCode = "ENCRYPTED_PARTITION_ERROR" | "INTERNAL_ERROR" | "INVALID_PARTITION_TYPE_DATA_ERROR" | "MISSING_PARTITION_VALUE_ERROR" | "UNSUPPORTED_PARTITION_CHARACTER_ERROR" | (string & {});
export declare const BackfillErrorCode: any;
export type BackfillErroredPartitionsList = PartitionValueList[];
export declare const BackfillErroredPartitionsList: any;
export interface BackfillError {
    Code?: BackfillErrorCode;
    Partitions?: PartitionValueList[];
}
export declare const BackfillError: S.Schema<BackfillError>;
export type BackfillErrors = BackfillError[];
export declare const BackfillErrors: any;
export interface PartitionIndexDescriptor {
    IndexName: string;
    Keys: KeySchemaElement[];
    IndexStatus: PartitionIndexStatus;
    BackfillErrors?: BackfillError[];
}
export declare const PartitionIndexDescriptor: S.Schema<PartitionIndexDescriptor>;
export type PartitionIndexDescriptorList = PartitionIndexDescriptor[];
export declare const PartitionIndexDescriptorList: any;
export interface GetPartitionIndexesResponse {
    PartitionIndexDescriptorList?: PartitionIndexDescriptor[];
    NextToken?: string;
}
export declare const GetPartitionIndexesResponse: S.Schema<GetPartitionIndexesResponse>;
export type PredicateString = string;
export type TotalSegmentsInteger = number;
export interface Segment {
    SegmentNumber: number;
    TotalSegments: number;
}
export declare const Segment: S.Schema<Segment>;
export type BooleanNullable = boolean;
export interface GetPartitionsRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    Expression?: string;
    NextToken?: string;
    Segment?: Segment;
    MaxResults?: number;
    ExcludeColumnSchema?: boolean;
    TransactionId?: string;
    QueryAsOfTime?: Date;
    AuditContext?: AuditContext;
}
export declare const GetPartitionsRequest: S.Schema<GetPartitionsRequest>;
export interface GetPartitionsResponse {
    Partitions?: Partition[];
    NextToken?: string;
}
export declare const GetPartitionsResponse: S.Schema<GetPartitionsResponse>;
export type AdditionalPlanOptionsMap = {
    [key: string]: string | undefined;
};
export declare const AdditionalPlanOptionsMap: any;
export interface GetPlanRequest {
    Mapping: MappingEntry[];
    Source: CatalogEntry;
    Sinks?: CatalogEntry[];
    Location?: Location;
    Language?: Language;
    AdditionalPlanOptionsMap?: {
        [key: string]: string | undefined;
    };
}
export declare const GetPlanRequest: S.Schema<GetPlanRequest>;
export interface GetPlanResponse {
    PythonScript?: string;
    ScalaCode?: string;
}
export declare const GetPlanResponse: S.Schema<GetPlanResponse>;
export interface GetRegistryInput {
    RegistryId: RegistryId;
}
export declare const GetRegistryInput: S.Schema<GetRegistryInput>;
export type CreatedTimestamp = string;
export type UpdatedTimestamp = string;
export interface GetRegistryResponse {
    RegistryName?: string;
    RegistryArn?: string;
    Description?: string;
    Status?: RegistryStatus;
    CreatedTime?: string;
    UpdatedTime?: string;
}
export declare const GetRegistryResponse: S.Schema<GetRegistryResponse>;
export interface GetResourcePoliciesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetResourcePoliciesRequest: S.Schema<GetResourcePoliciesRequest>;
export type PolicyJsonString = string;
export interface GluePolicy {
    PolicyInJson?: string;
    PolicyHash?: string;
    CreateTime?: Date;
    UpdateTime?: Date;
}
export declare const GluePolicy: S.Schema<GluePolicy>;
export type GetResourcePoliciesResponseList = GluePolicy[];
export declare const GetResourcePoliciesResponseList: any;
export interface GetResourcePoliciesResponse {
    GetResourcePoliciesResponseList?: GluePolicy[];
    NextToken?: string;
}
export declare const GetResourcePoliciesResponse: S.Schema<GetResourcePoliciesResponse>;
export interface GetResourcePolicyRequest {
    ResourceArn?: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export interface GetResourcePolicyResponse {
    PolicyInJson?: string;
    PolicyHash?: string;
    CreateTime?: Date;
    UpdateTime?: Date;
}
export declare const GetResourcePolicyResponse: S.Schema<GetResourcePolicyResponse>;
export interface GetSchemaInput {
    SchemaId: SchemaId;
}
export declare const GetSchemaInput: S.Schema<GetSchemaInput>;
export interface GetSchemaResponse {
    RegistryName?: string;
    RegistryArn?: string;
    SchemaName?: string;
    SchemaArn?: string;
    Description?: string;
    DataFormat?: DataFormat;
    Compatibility?: Compatibility;
    SchemaCheckpoint?: number;
    LatestSchemaVersion?: number;
    NextSchemaVersion?: number;
    SchemaStatus?: SchemaStatus;
    CreatedTime?: string;
    UpdatedTime?: string;
}
export declare const GetSchemaResponse: S.Schema<GetSchemaResponse>;
export interface GetSchemaByDefinitionInput {
    SchemaId: SchemaId;
    SchemaDefinition: string;
}
export declare const GetSchemaByDefinitionInput: S.Schema<GetSchemaByDefinitionInput>;
export interface GetSchemaByDefinitionResponse {
    SchemaVersionId?: string;
    SchemaArn?: string;
    DataFormat?: DataFormat;
    Status?: SchemaVersionStatus;
    CreatedTime?: string;
}
export declare const GetSchemaByDefinitionResponse: S.Schema<GetSchemaByDefinitionResponse>;
export type LatestSchemaVersionBoolean = boolean;
export interface SchemaVersionNumber {
    LatestVersion?: boolean;
    VersionNumber?: number;
}
export declare const SchemaVersionNumber: S.Schema<SchemaVersionNumber>;
export interface GetSchemaVersionInput {
    SchemaId?: SchemaId;
    SchemaVersionId?: string;
    SchemaVersionNumber?: SchemaVersionNumber;
}
export declare const GetSchemaVersionInput: S.Schema<GetSchemaVersionInput>;
export interface GetSchemaVersionResponse {
    SchemaVersionId?: string;
    SchemaDefinition?: string;
    DataFormat?: DataFormat;
    SchemaArn?: string;
    VersionNumber?: number;
    Status?: SchemaVersionStatus;
    CreatedTime?: string;
}
export declare const GetSchemaVersionResponse: S.Schema<GetSchemaVersionResponse>;
export type SchemaDiffType = "SYNTAX_DIFF" | (string & {});
export declare const SchemaDiffType: any;
export interface GetSchemaVersionsDiffInput {
    SchemaId: SchemaId;
    FirstSchemaVersionNumber: SchemaVersionNumber;
    SecondSchemaVersionNumber: SchemaVersionNumber;
    SchemaDiffType: SchemaDiffType;
}
export declare const GetSchemaVersionsDiffInput: S.Schema<GetSchemaVersionsDiffInput>;
export type SchemaDefinitionDiff = string;
export interface GetSchemaVersionsDiffResponse {
    Diff?: string;
}
export declare const GetSchemaVersionsDiffResponse: S.Schema<GetSchemaVersionsDiffResponse>;
export interface GetSecurityConfigurationRequest {
    Name: string;
}
export declare const GetSecurityConfigurationRequest: S.Schema<GetSecurityConfigurationRequest>;
export interface SecurityConfiguration {
    Name?: string;
    CreatedTimeStamp?: Date;
    EncryptionConfiguration?: EncryptionConfiguration;
}
export declare const SecurityConfiguration: S.Schema<SecurityConfiguration>;
export interface GetSecurityConfigurationResponse {
    SecurityConfiguration?: SecurityConfiguration;
}
export declare const GetSecurityConfigurationResponse: S.Schema<GetSecurityConfigurationResponse>;
export interface GetSecurityConfigurationsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const GetSecurityConfigurationsRequest: S.Schema<GetSecurityConfigurationsRequest>;
export type SecurityConfigurationList = SecurityConfiguration[];
export declare const SecurityConfigurationList: any;
export interface GetSecurityConfigurationsResponse {
    SecurityConfigurations?: SecurityConfiguration[];
    NextToken?: string;
}
export declare const GetSecurityConfigurationsResponse: S.Schema<GetSecurityConfigurationsResponse>;
export interface GetSessionRequest {
    Id: string;
    RequestOrigin?: string;
}
export declare const GetSessionRequest: S.Schema<GetSessionRequest>;
export interface GetSessionResponse {
    Session?: Session;
}
export declare const GetSessionResponse: S.Schema<GetSessionResponse>;
export interface GetSessionEndpointRequest {
    SessionId: string;
}
export declare const GetSessionEndpointRequest: S.Schema<GetSessionEndpointRequest>;
export type SparkConnectEndpointUrl = string;
export type SensitiveString = string | redacted.Redacted<string>;
export interface SessionEndpoint {
    Url: string;
    AuthToken: string | redacted.Redacted<string>;
    AuthTokenExpirationTime: Date;
}
export declare const SessionEndpoint: S.Schema<SessionEndpoint>;
export interface GetSessionEndpointResponse {
    SparkConnect: SessionEndpoint;
}
export declare const GetSessionEndpointResponse: S.Schema<GetSessionEndpointResponse>;
export interface GetStatementRequest {
    SessionId: string;
    Id: number;
    RequestOrigin?: string;
}
export declare const GetStatementRequest: S.Schema<GetStatementRequest>;
export type StatementState = "WAITING" | "RUNNING" | "AVAILABLE" | "CANCELLING" | "CANCELLED" | "ERROR" | (string & {});
export declare const StatementState: any;
export interface StatementOutputData {
    TextPlain?: string;
}
export declare const StatementOutputData: S.Schema<StatementOutputData>;
export interface StatementOutput {
    Data?: StatementOutputData;
    ExecutionCount?: number;
    Status?: StatementState;
    ErrorName?: string;
    ErrorValue?: string;
    Traceback?: string[];
}
export declare const StatementOutput: S.Schema<StatementOutput>;
export type LongValue = number;
export interface Statement {
    Id?: number;
    Code?: string;
    State?: StatementState;
    Output?: StatementOutput;
    Progress?: number;
    StartedOn?: number;
    CompletedOn?: number;
}
export declare const Statement: S.Schema<Statement>;
export interface GetStatementResponse {
    Statement?: Statement;
}
export declare const GetStatementResponse: S.Schema<GetStatementResponse>;
export type TableAttributes = "NAME" | "TABLE_TYPE" | "DEFAULT" | "LATEST_ICEBERG_METADATA" | (string & {});
export declare const TableAttributes: any;
export type TableAttributesList = TableAttributes[];
export declare const TableAttributesList: any;
export interface GetTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    Name: string;
    TransactionId?: string;
    QueryAsOfTime?: Date;
    AuditContext?: AuditContext;
    IncludeStatusDetails?: boolean;
    AttributesToGet?: TableAttributes[];
}
export declare const GetTableRequest: S.Schema<GetTableRequest>;
export interface FederatedTable {
    Identifier?: string;
    DatabaseIdentifier?: string;
    ConnectionName?: string;
    ConnectionType?: string;
}
export declare const FederatedTable: S.Schema<FederatedTable>;
export interface ViewRepresentation {
    Dialect?: ViewDialect;
    DialectVersion?: string;
    ViewOriginalText?: string;
    ViewExpandedText?: string;
    ValidationConnection?: string;
    IsStale?: boolean;
}
export declare const ViewRepresentation: S.Schema<ViewRepresentation>;
export type ViewRepresentationList = ViewRepresentation[];
export declare const ViewRepresentationList: any;
export interface ViewDefinition {
    IsProtected?: boolean;
    Definer?: string;
    ViewVersionId?: number;
    ViewVersionToken?: string;
    RefreshSeconds?: number;
    LastRefreshType?: LastRefreshType;
    SubObjects?: string[];
    SubObjectVersionIds?: number[];
    Representations?: ViewRepresentation[];
}
export declare const ViewDefinition: S.Schema<ViewDefinition>;
export type TableIdString = string;
export type IcebergSchemaList = IcebergSchema[];
export declare const IcebergSchemaList: any;
export type IcebergPartitionSpecList = IcebergPartitionSpec[];
export declare const IcebergPartitionSpecList: any;
export type IcebergSortOrderList = IcebergSortOrder[];
export declare const IcebergSortOrderList: any;
export interface IcebergTableMetadata {
    FormatVersion?: string;
    TableUuid?: string;
    Location?: string;
    Properties?: {
        [key: string]: string | undefined;
    };
    Schemas?: IcebergSchema[];
    CurrentSchemaId?: number;
    LastColumnId?: number;
    PartitionSpecs?: IcebergPartitionSpec[];
    DefaultSpecId?: number;
    LastPartitionId?: number;
    SortOrders?: IcebergSortOrder[];
    DefaultSortOrderId?: number;
}
export declare const IcebergTableMetadata: S.Schema<IcebergTableMetadata>;
export type ResourceAction = "UPDATE" | "CREATE" | (string & {});
export declare const ResourceAction: any;
export type ResourceState = "QUEUED" | "IN_PROGRESS" | "SUCCESS" | "STOPPED" | "FAILED" | (string & {});
export declare const ResourceState: any;
export interface ViewValidation {
    Dialect?: ViewDialect;
    DialectVersion?: string;
    ViewValidationText?: string;
    UpdateTime?: Date;
    State?: ResourceState;
    Error?: ErrorDetail;
}
export declare const ViewValidation: S.Schema<ViewValidation>;
export type ViewValidationList = ViewValidation[];
export declare const ViewValidationList: any;
export interface StatusDetails {
    RequestedChange?: Table;
    ViewValidations?: ViewValidation[];
}
export declare const StatusDetails: S.Schema<StatusDetails>;
export interface TableStatus {
    RequestedBy?: string;
    UpdatedBy?: string;
    RequestTime?: Date;
    UpdateTime?: Date;
    Action?: ResourceAction;
    State?: ResourceState;
    Error?: ErrorDetail;
    Details?: StatusDetails;
}
export declare const TableStatus: S.Schema<TableStatus>;
export interface Table {
    Name: string;
    DatabaseName?: string;
    Description?: string;
    Owner?: string;
    CreateTime?: Date;
    UpdateTime?: Date;
    LastAccessTime?: Date;
    LastAnalyzedTime?: Date;
    Retention?: number;
    StorageDescriptor?: StorageDescriptor;
    PartitionKeys?: Column[];
    ViewOriginalText?: string;
    ViewExpandedText?: string;
    TableType?: string;
    Parameters?: {
        [key: string]: string | undefined;
    };
    CreatedBy?: string;
    IsRegisteredWithLakeFormation?: boolean;
    TargetTable?: TableIdentifier;
    CatalogId?: string;
    VersionId?: string;
    FederatedTable?: FederatedTable;
    ViewDefinition?: ViewDefinition;
    IsMultiDialectView?: boolean;
    IsMaterializedView?: boolean;
    IcebergTableMetadata?: IcebergTableMetadata;
    Status?: TableStatus;
}
export declare const Table: S.Schema<Table>;
export interface GetTableResponse {
    Table?: Table;
}
export declare const GetTableResponse: S.Schema<GetTableResponse>;
export interface GetTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
}
export declare const GetTableOptimizerRequest: S.Schema<GetTableOptimizerRequest>;
export interface GetTableOptimizerResponse {
    CatalogId?: string;
    DatabaseName?: string;
    TableName?: string;
    TableOptimizer?: TableOptimizer;
}
export declare const GetTableOptimizerResponse: S.Schema<GetTableOptimizerResponse>;
export type FilterString = string;
export interface GetTablesRequest {
    CatalogId?: string;
    DatabaseName: string;
    Expression?: string;
    NextToken?: string;
    MaxResults?: number;
    TransactionId?: string;
    QueryAsOfTime?: Date;
    AuditContext?: AuditContext;
    IncludeStatusDetails?: boolean;
    AttributesToGet?: TableAttributes[];
}
export declare const GetTablesRequest: S.Schema<GetTablesRequest>;
export type TableList = Table[];
export declare const TableList: any;
export interface GetTablesResponse {
    TableList?: Table[];
    NextToken?: string;
}
export declare const GetTablesResponse: S.Schema<GetTablesResponse>;
export interface GetTableVersionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    VersionId?: string;
    AuditContext?: AuditContext;
}
export declare const GetTableVersionRequest: S.Schema<GetTableVersionRequest>;
export interface TableVersion {
    Table?: Table;
    VersionId?: string;
}
export declare const TableVersion: S.Schema<TableVersion>;
export interface GetTableVersionResponse {
    TableVersion?: TableVersion;
}
export declare const GetTableVersionResponse: S.Schema<GetTableVersionResponse>;
export interface GetTableVersionsRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    NextToken?: string;
    MaxResults?: number;
    AuditContext?: AuditContext;
}
export declare const GetTableVersionsRequest: S.Schema<GetTableVersionsRequest>;
export type GetTableVersionsList = TableVersion[];
export declare const GetTableVersionsList: any;
export interface GetTableVersionsResponse {
    TableVersions?: TableVersion[];
    NextToken?: string;
}
export declare const GetTableVersionsResponse: S.Schema<GetTableVersionsResponse>;
export interface GetTagsRequest {
    ResourceArn: string;
}
export declare const GetTagsRequest: S.Schema<GetTagsRequest>;
export interface GetTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const GetTagsResponse: S.Schema<GetTagsResponse>;
export interface GetTriggerRequest {
    Name: string;
}
export declare const GetTriggerRequest: S.Schema<GetTriggerRequest>;
export interface GetTriggerResponse {
    Trigger?: Trigger;
}
export declare const GetTriggerResponse: S.Schema<GetTriggerResponse>;
export interface GetTriggersRequest {
    NextToken?: string;
    DependentJobName?: string;
    MaxResults?: number;
}
export declare const GetTriggersRequest: S.Schema<GetTriggersRequest>;
export interface GetTriggersResponse {
    Triggers?: Trigger[];
    NextToken?: string;
}
export declare const GetTriggersResponse: S.Schema<GetTriggersResponse>;
export type PermissionType = "COLUMN_PERMISSION" | "CELL_FILTER_PERMISSION" | "NESTED_PERMISSION" | "NESTED_CELL_PERMISSION" | (string & {});
export declare const PermissionType: any;
export type PermissionTypeList = PermissionType[];
export declare const PermissionTypeList: any;
export interface GetUnfilteredPartitionMetadataRequest {
    Region?: string;
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    AuditContext?: AuditContext;
    SupportedPermissionTypes: PermissionType[];
    QuerySessionContext?: QuerySessionContext;
}
export declare const GetUnfilteredPartitionMetadataRequest: S.Schema<GetUnfilteredPartitionMetadataRequest>;
export interface GetUnfilteredPartitionMetadataResponse {
    Partition?: Partition;
    AuthorizedColumns?: string[];
    IsRegisteredWithLakeFormation?: boolean;
}
export declare const GetUnfilteredPartitionMetadataResponse: S.Schema<GetUnfilteredPartitionMetadataResponse>;
export interface GetUnfilteredPartitionsMetadataRequest {
    Region?: string;
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Expression?: string;
    AuditContext?: AuditContext;
    SupportedPermissionTypes: PermissionType[];
    NextToken?: string;
    Segment?: Segment;
    MaxResults?: number;
    QuerySessionContext?: QuerySessionContext;
}
export declare const GetUnfilteredPartitionsMetadataRequest: S.Schema<GetUnfilteredPartitionsMetadataRequest>;
export interface UnfilteredPartition {
    Partition?: Partition;
    AuthorizedColumns?: string[];
    IsRegisteredWithLakeFormation?: boolean;
}
export declare const UnfilteredPartition: S.Schema<UnfilteredPartition>;
export type UnfilteredPartitionList = UnfilteredPartition[];
export declare const UnfilteredPartitionList: any;
export interface GetUnfilteredPartitionsMetadataResponse {
    UnfilteredPartitions?: UnfilteredPartition[];
    NextToken?: string;
}
export declare const GetUnfilteredPartitionsMetadataResponse: S.Schema<GetUnfilteredPartitionsMetadataResponse>;
export interface SupportedDialect {
    Dialect?: ViewDialect;
    DialectVersion?: string;
}
export declare const SupportedDialect: S.Schema<SupportedDialect>;
export interface GetUnfilteredTableMetadataRequest {
    Region?: string;
    CatalogId: string;
    DatabaseName: string;
    Name: string;
    AuditContext?: AuditContext;
    SupportedPermissionTypes: PermissionType[];
    ParentResourceArn?: string;
    RootResourceArn?: string;
    SupportedDialect?: SupportedDialect;
    Permissions?: Permission[];
    QuerySessionContext?: QuerySessionContext;
}
export declare const GetUnfilteredTableMetadataRequest: S.Schema<GetUnfilteredTableMetadataRequest>;
export interface ColumnRowFilter {
    ColumnName?: string;
    RowFilterExpression?: string;
}
export declare const ColumnRowFilter: S.Schema<ColumnRowFilter>;
export type ColumnRowFilterList = ColumnRowFilter[];
export declare const ColumnRowFilterList: any;
export interface GetUnfilteredTableMetadataResponse {
    Table?: Table;
    AuthorizedColumns?: string[];
    IsRegisteredWithLakeFormation?: boolean;
    CellFilters?: ColumnRowFilter[];
    QueryAuthorizationId?: string;
    IsMultiDialectView?: boolean;
    IsMaterializedView?: boolean;
    ResourceArn?: string;
    IsProtected?: boolean;
    Permissions?: Permission[];
    RowFilter?: string;
}
export declare const GetUnfilteredTableMetadataResponse: S.Schema<GetUnfilteredTableMetadataResponse>;
export interface GetUsageProfileRequest {
    Name: string;
}
export declare const GetUsageProfileRequest: S.Schema<GetUsageProfileRequest>;
export interface GetUsageProfileResponse {
    Name?: string;
    Description?: string;
    Configuration?: ProfileConfiguration;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
}
export declare const GetUsageProfileResponse: S.Schema<GetUsageProfileResponse>;
export interface GetUserDefinedFunctionRequest {
    CatalogId?: string;
    DatabaseName: string;
    FunctionName: string;
}
export declare const GetUserDefinedFunctionRequest: S.Schema<GetUserDefinedFunctionRequest>;
export interface UserDefinedFunction {
    FunctionName?: string;
    DatabaseName?: string;
    ClassName?: string;
    OwnerName?: string;
    FunctionType?: FunctionType;
    OwnerType?: PrincipalType;
    CreateTime?: Date;
    ResourceUris?: ResourceUri[];
    CatalogId?: string;
}
export declare const UserDefinedFunction: S.Schema<UserDefinedFunction>;
export interface GetUserDefinedFunctionResponse {
    UserDefinedFunction?: UserDefinedFunction;
}
export declare const GetUserDefinedFunctionResponse: S.Schema<GetUserDefinedFunctionResponse>;
export interface GetUserDefinedFunctionsRequest {
    CatalogId?: string;
    DatabaseName?: string;
    Pattern: string;
    FunctionType?: FunctionType;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetUserDefinedFunctionsRequest: S.Schema<GetUserDefinedFunctionsRequest>;
export type UserDefinedFunctionList = UserDefinedFunction[];
export declare const UserDefinedFunctionList: any;
export interface GetUserDefinedFunctionsResponse {
    UserDefinedFunctions?: UserDefinedFunction[];
    NextToken?: string;
}
export declare const GetUserDefinedFunctionsResponse: S.Schema<GetUserDefinedFunctionsResponse>;
export interface GetWorkflowRequest {
    Name: string;
    IncludeGraph?: boolean;
}
export declare const GetWorkflowRequest: S.Schema<GetWorkflowRequest>;
export interface GetWorkflowResponse {
    Workflow?: Workflow;
}
export declare const GetWorkflowResponse: S.Schema<GetWorkflowResponse>;
export interface GetWorkflowRunRequest {
    Name: string;
    RunId: string;
    IncludeGraph?: boolean;
}
export declare const GetWorkflowRunRequest: S.Schema<GetWorkflowRunRequest>;
export interface GetWorkflowRunResponse {
    Run?: WorkflowRun;
}
export declare const GetWorkflowRunResponse: S.Schema<GetWorkflowRunResponse>;
export interface GetWorkflowRunPropertiesRequest {
    Name: string;
    RunId: string;
}
export declare const GetWorkflowRunPropertiesRequest: S.Schema<GetWorkflowRunPropertiesRequest>;
export interface GetWorkflowRunPropertiesResponse {
    RunProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const GetWorkflowRunPropertiesResponse: S.Schema<GetWorkflowRunPropertiesResponse>;
export interface GetWorkflowRunsRequest {
    Name: string;
    IncludeGraph?: boolean;
    NextToken?: string;
    MaxResults?: number;
}
export declare const GetWorkflowRunsRequest: S.Schema<GetWorkflowRunsRequest>;
export type WorkflowRuns = WorkflowRun[];
export declare const WorkflowRuns: any;
export interface GetWorkflowRunsResponse {
    Runs?: WorkflowRun[];
    NextToken?: string;
}
export declare const GetWorkflowRunsResponse: S.Schema<GetWorkflowRunsResponse>;
export interface ImportCatalogToGlueRequest {
    CatalogId?: string;
}
export declare const ImportCatalogToGlueRequest: S.Schema<ImportCatalogToGlueRequest>;
export interface ImportCatalogToGlueResponse {
}
export declare const ImportCatalogToGlueResponse: S.Schema<ImportCatalogToGlueResponse>;
export interface ListAssetTypesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListAssetTypesRequest: S.Schema<ListAssetTypesRequest>;
export interface AssetTypeItem {
    Id?: string;
    Name?: string;
}
export declare const AssetTypeItem: S.Schema<AssetTypeItem>;
export type AssetTypeItemList = AssetTypeItem[];
export declare const AssetTypeItemList: any;
export interface ListAssetTypesResponse {
    Items?: AssetTypeItem[];
    NextToken?: string;
}
export declare const ListAssetTypesResponse: S.Schema<ListAssetTypesResponse>;
export type OrchestrationPageSize25 = number;
export interface ListBlueprintsRequest {
    NextToken?: string;
    MaxResults?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListBlueprintsRequest: S.Schema<ListBlueprintsRequest>;
export interface ListBlueprintsResponse {
    Blueprints?: string[];
    NextToken?: string;
}
export declare const ListBlueprintsResponse: S.Schema<ListBlueprintsResponse>;
export interface ListColumnStatisticsTaskRunsRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListColumnStatisticsTaskRunsRequest: S.Schema<ListColumnStatisticsTaskRunsRequest>;
export type ColumnStatisticsTaskRunIdList = string[];
export declare const ColumnStatisticsTaskRunIdList: any;
export interface ListColumnStatisticsTaskRunsResponse {
    ColumnStatisticsTaskRunIds?: string[];
    NextToken?: string;
}
export declare const ListColumnStatisticsTaskRunsResponse: S.Schema<ListColumnStatisticsTaskRunsResponse>;
export type MaxResults = number;
export interface ListConnectionTypesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListConnectionTypesRequest: S.Schema<ListConnectionTypesRequest>;
export type DisplayName = string;
export type Vendor = string;
export type UrlString = string;
export interface ConnectionTypeVariant {
    ConnectionTypeVariantName?: string;
    DisplayName?: string;
    Description?: string;
    LogoUrl?: string;
}
export declare const ConnectionTypeVariant: S.Schema<ConnectionTypeVariant>;
export type ConnectionTypeVariantList = ConnectionTypeVariant[];
export declare const ConnectionTypeVariantList: any;
export interface ConnectionTypeBrief {
    ConnectionType?: ConnectionType;
    DisplayName?: string;
    Vendor?: string;
    Description?: string;
    Categories?: string[];
    Capabilities?: Capabilities;
    LogoUrl?: string;
    ConnectionTypeVariants?: ConnectionTypeVariant[];
}
export declare const ConnectionTypeBrief: S.Schema<ConnectionTypeBrief>;
export type ConnectionTypeList = ConnectionTypeBrief[];
export declare const ConnectionTypeList: any;
export interface ListConnectionTypesResponse {
    ConnectionTypes?: ConnectionTypeBrief[];
    NextToken?: string;
}
export declare const ListConnectionTypesResponse: S.Schema<ListConnectionTypesResponse>;
export interface ListCrawlersRequest {
    MaxResults?: number;
    NextToken?: string;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListCrawlersRequest: S.Schema<ListCrawlersRequest>;
export interface ListCrawlersResponse {
    CrawlerNames?: string[];
    NextToken?: string;
}
export declare const ListCrawlersResponse: S.Schema<ListCrawlersResponse>;
export type FieldName = "CRAWL_ID" | "STATE" | "START_TIME" | "END_TIME" | "DPU_HOUR" | (string & {});
export declare const FieldName: any;
export type FilterOperator = "GT" | "GE" | "LT" | "LE" | "EQ" | "NE" | (string & {});
export declare const FilterOperator: any;
export interface CrawlsFilter {
    FieldName?: FieldName;
    FilterOperator?: FilterOperator;
    FieldValue?: string;
}
export declare const CrawlsFilter: S.Schema<CrawlsFilter>;
export type CrawlsFilterList = CrawlsFilter[];
export declare const CrawlsFilterList: any;
export interface ListCrawlsRequest {
    CrawlerName: string;
    MaxResults?: number;
    Filters?: CrawlsFilter[];
    NextToken?: string;
}
export declare const ListCrawlsRequest: S.Schema<ListCrawlsRequest>;
export type CrawlId = string;
export type CrawlerHistoryState = "RUNNING" | "COMPLETED" | "FAILED" | "STOPPED" | (string & {});
export declare const CrawlerHistoryState: any;
export interface CrawlerHistory {
    CrawlId?: string;
    State?: CrawlerHistoryState;
    StartTime?: Date;
    EndTime?: Date;
    Summary?: string;
    ErrorMessage?: string;
    LogGroup?: string;
    LogStream?: string;
    MessagePrefix?: string;
    DPUHour?: number;
}
export declare const CrawlerHistory: S.Schema<CrawlerHistory>;
export type CrawlerHistoryList = CrawlerHistory[];
export declare const CrawlerHistoryList: any;
export interface ListCrawlsResponse {
    Crawls?: CrawlerHistory[];
    NextToken?: string;
}
export declare const ListCrawlsResponse: S.Schema<ListCrawlsResponse>;
export interface ListCustomEntityTypesRequest {
    NextToken?: string;
    MaxResults?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListCustomEntityTypesRequest: S.Schema<ListCustomEntityTypesRequest>;
export interface ListCustomEntityTypesResponse {
    CustomEntityTypes?: CustomEntityType[];
    NextToken?: string;
}
export declare const ListCustomEntityTypesResponse: S.Schema<ListCustomEntityTypesResponse>;
export interface DataQualityResultFilterCriteria {
    DataSource?: DataSource;
    JobName?: string;
    JobRunId?: string;
    StartedAfter?: Date;
    StartedBefore?: Date;
}
export declare const DataQualityResultFilterCriteria: S.Schema<DataQualityResultFilterCriteria>;
export interface ListDataQualityResultsRequest {
    Filter?: DataQualityResultFilterCriteria;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataQualityResultsRequest: S.Schema<ListDataQualityResultsRequest>;
export interface DataQualityResultDescription {
    ResultId?: string;
    DataSource?: DataSource;
    JobName?: string;
    JobRunId?: string;
    StartedOn?: Date;
}
export declare const DataQualityResultDescription: S.Schema<DataQualityResultDescription>;
export type DataQualityResultDescriptionList = DataQualityResultDescription[];
export declare const DataQualityResultDescriptionList: any;
export interface ListDataQualityResultsResponse {
    Results: DataQualityResultDescription[];
    NextToken?: string;
}
export declare const ListDataQualityResultsResponse: S.Schema<ListDataQualityResultsResponse>;
export interface DataQualityRuleRecommendationRunFilter {
    DataSource: DataSource;
    StartedBefore?: Date;
    StartedAfter?: Date;
}
export declare const DataQualityRuleRecommendationRunFilter: S.Schema<DataQualityRuleRecommendationRunFilter>;
export interface ListDataQualityRuleRecommendationRunsRequest {
    Filter?: DataQualityRuleRecommendationRunFilter;
    NextToken?: string;
    MaxResults?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListDataQualityRuleRecommendationRunsRequest: S.Schema<ListDataQualityRuleRecommendationRunsRequest>;
export interface DataQualityRuleRecommendationRunDescription {
    RunId?: string;
    Status?: TaskStatusType;
    StartedOn?: Date;
    DataSource?: DataSource;
    CreatedRulesetName?: string;
}
export declare const DataQualityRuleRecommendationRunDescription: S.Schema<DataQualityRuleRecommendationRunDescription>;
export type DataQualityRuleRecommendationRunList = DataQualityRuleRecommendationRunDescription[];
export declare const DataQualityRuleRecommendationRunList: any;
export interface ListDataQualityRuleRecommendationRunsResponse {
    Runs?: DataQualityRuleRecommendationRunDescription[];
    NextToken?: string;
}
export declare const ListDataQualityRuleRecommendationRunsResponse: S.Schema<ListDataQualityRuleRecommendationRunsResponse>;
export interface DataQualityRulesetEvaluationRunFilter {
    DataSource: DataSource;
    StartedBefore?: Date;
    StartedAfter?: Date;
    RulesetName?: string;
}
export declare const DataQualityRulesetEvaluationRunFilter: S.Schema<DataQualityRulesetEvaluationRunFilter>;
export interface ListDataQualityRulesetEvaluationRunsRequest {
    Filter?: DataQualityRulesetEvaluationRunFilter;
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListDataQualityRulesetEvaluationRunsRequest: S.Schema<ListDataQualityRulesetEvaluationRunsRequest>;
export interface DataQualityRulesetEvaluationRunDescription {
    RunId?: string;
    Status?: TaskStatusType;
    StartedOn?: Date;
    DataSource?: DataSource;
}
export declare const DataQualityRulesetEvaluationRunDescription: S.Schema<DataQualityRulesetEvaluationRunDescription>;
export type DataQualityRulesetEvaluationRunList = DataQualityRulesetEvaluationRunDescription[];
export declare const DataQualityRulesetEvaluationRunList: any;
export interface ListDataQualityRulesetEvaluationRunsResponse {
    Runs?: DataQualityRulesetEvaluationRunDescription[];
    NextToken?: string;
}
export declare const ListDataQualityRulesetEvaluationRunsResponse: S.Schema<ListDataQualityRulesetEvaluationRunsResponse>;
export interface DataQualityRulesetFilterCriteria {
    Name?: string;
    Description?: string;
    CreatedBefore?: Date;
    CreatedAfter?: Date;
    LastModifiedBefore?: Date;
    LastModifiedAfter?: Date;
    TargetTable?: DataQualityTargetTable;
}
export declare const DataQualityRulesetFilterCriteria: S.Schema<DataQualityRulesetFilterCriteria>;
export interface ListDataQualityRulesetsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filter?: DataQualityRulesetFilterCriteria;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListDataQualityRulesetsRequest: S.Schema<ListDataQualityRulesetsRequest>;
export interface DataQualityRulesetListDetails {
    Name?: string;
    Description?: string;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
    TargetTable?: DataQualityTargetTable;
    RecommendationRunId?: string;
    RuleCount?: number;
}
export declare const DataQualityRulesetListDetails: S.Schema<DataQualityRulesetListDetails>;
export type DataQualityRulesetList = DataQualityRulesetListDetails[];
export declare const DataQualityRulesetList: any;
export interface ListDataQualityRulesetsResponse {
    Rulesets?: DataQualityRulesetListDetails[];
    NextToken?: string;
}
export declare const ListDataQualityRulesetsResponse: S.Schema<ListDataQualityRulesetsResponse>;
export interface TimestampFilter {
    RecordedBefore?: Date;
    RecordedAfter?: Date;
}
export declare const TimestampFilter: S.Schema<TimestampFilter>;
export interface ListDataQualityStatisticAnnotationsRequest {
    StatisticId?: string;
    ProfileId?: string;
    TimestampFilter?: TimestampFilter;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDataQualityStatisticAnnotationsRequest: S.Schema<ListDataQualityStatisticAnnotationsRequest>;
export interface TimestampedInclusionAnnotation {
    Value?: InclusionAnnotationValue;
    LastModifiedOn?: Date;
}
export declare const TimestampedInclusionAnnotation: S.Schema<TimestampedInclusionAnnotation>;
export interface StatisticAnnotation {
    ProfileId?: string;
    StatisticId?: string;
    StatisticRecordedOn?: Date;
    InclusionAnnotation?: TimestampedInclusionAnnotation;
}
export declare const StatisticAnnotation: S.Schema<StatisticAnnotation>;
export type AnnotationList = StatisticAnnotation[];
export declare const AnnotationList: any;
export interface ListDataQualityStatisticAnnotationsResponse {
    Annotations?: StatisticAnnotation[];
    NextToken?: string;
}
export declare const ListDataQualityStatisticAnnotationsResponse: S.Schema<ListDataQualityStatisticAnnotationsResponse>;
export interface ListDataQualityStatisticsRequest {
    StatisticId?: string;
    ProfileId?: string;
    TimestampFilter?: TimestampFilter;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListDataQualityStatisticsRequest: S.Schema<ListDataQualityStatisticsRequest>;
export interface RunIdentifier {
    RunId?: string;
    JobRunId?: string;
}
export declare const RunIdentifier: S.Schema<RunIdentifier>;
export type StatisticNameString = string;
export type StatisticEvaluationLevel = "Dataset" | "Column" | "Multicolumn" | (string & {});
export declare const StatisticEvaluationLevel: any;
export type ReferenceDatasetsList = string[];
export declare const ReferenceDatasetsList: any;
export type StatisticPropertiesMap = {
    [key: string]: string | undefined;
};
export declare const StatisticPropertiesMap: any;
export interface StatisticSummary {
    StatisticId?: string;
    ProfileId?: string;
    RunIdentifier?: RunIdentifier;
    StatisticName?: string;
    DoubleValue?: number;
    DistributionValue?: DistributionData;
    EvaluationLevel?: StatisticEvaluationLevel;
    ColumnsReferenced?: string[];
    ReferencedDatasets?: string[];
    StatisticProperties?: {
        [key: string]: string | undefined;
    };
    RecordedOn?: Date;
    InclusionAnnotation?: TimestampedInclusionAnnotation;
}
export declare const StatisticSummary: S.Schema<StatisticSummary>;
export type StatisticSummaryList = StatisticSummary[];
export declare const StatisticSummaryList: any;
export interface ListDataQualityStatisticsResponse {
    Statistics?: StatisticSummary[];
    NextToken?: string;
}
export declare const ListDataQualityStatisticsResponse: S.Schema<ListDataQualityStatisticsResponse>;
export interface ListDevEndpointsRequest {
    NextToken?: string;
    MaxResults?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListDevEndpointsRequest: S.Schema<ListDevEndpointsRequest>;
export type DevEndpointNameList = string[];
export declare const DevEndpointNameList: any;
export interface ListDevEndpointsResponse {
    DevEndpointNames?: string[];
    NextToken?: string;
}
export declare const ListDevEndpointsResponse: S.Schema<ListDevEndpointsResponse>;
export interface ListEntitiesRequest {
    ConnectionName?: string;
    CatalogId?: string;
    ParentEntityName?: string;
    NextToken?: string;
    DataStoreApiVersion?: string;
}
export declare const ListEntitiesRequest: S.Schema<ListEntitiesRequest>;
export type EntityLabel = string;
export type IsParentEntity = boolean;
export type EntityDescription = string;
export type Category = string;
export interface Entity {
    EntityName?: string;
    Label?: string;
    IsParentEntity?: boolean;
    Description?: string;
    Category?: string;
    CustomProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const Entity: S.Schema<Entity>;
export type EntityList = Entity[];
export declare const EntityList: any;
export interface ListEntitiesResponse {
    Entities?: Entity[];
    NextToken?: string;
}
export declare const ListEntitiesResponse: S.Schema<ListEntitiesResponse>;
export interface ListFormTypesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListFormTypesRequest: S.Schema<ListFormTypesRequest>;
export interface FormTypeItem {
    Id?: string;
    Name?: string;
}
export declare const FormTypeItem: S.Schema<FormTypeItem>;
export type FormTypeItemList = FormTypeItem[];
export declare const FormTypeItemList: any;
export interface ListFormTypesResponse {
    Items: FormTypeItem[];
    NextToken?: string;
}
export declare const ListFormTypesResponse: S.Schema<ListFormTypesResponse>;
export interface ListGlossariesRequest {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListGlossariesRequest: S.Schema<ListGlossariesRequest>;
export interface GlossaryItem {
    Id?: string;
    Name?: string;
    Description?: string;
}
export declare const GlossaryItem: S.Schema<GlossaryItem>;
export type GlossaryItemList = GlossaryItem[];
export declare const GlossaryItemList: any;
export interface ListGlossariesResponse {
    Items?: GlossaryItem[];
    NextToken?: string;
}
export declare const ListGlossariesResponse: S.Schema<ListGlossariesResponse>;
export interface ListGlossaryTermsRequest {
    GlossaryIdentifier: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListGlossaryTermsRequest: S.Schema<ListGlossaryTermsRequest>;
export interface GlossaryTermItem {
    Id?: string;
    Name?: string;
    ShortDescription?: string;
}
export declare const GlossaryTermItem: S.Schema<GlossaryTermItem>;
export type GlossaryTermItemList = GlossaryTermItem[];
export declare const GlossaryTermItemList: any;
export interface ListGlossaryTermsResponse {
    Items?: GlossaryTermItem[];
    NextToken?: string;
}
export declare const ListGlossaryTermsResponse: S.Schema<ListGlossaryTermsResponse>;
export type String1024 = string;
export type IntegrationResourcePropertyFilterValues = string[];
export declare const IntegrationResourcePropertyFilterValues: any;
export interface IntegrationResourcePropertyFilter {
    Name?: string;
    Values?: string[];
}
export declare const IntegrationResourcePropertyFilter: S.Schema<IntegrationResourcePropertyFilter>;
export type IntegrationResourcePropertyFilterList = IntegrationResourcePropertyFilter[];
export declare const IntegrationResourcePropertyFilterList: any;
export interface ListIntegrationResourcePropertiesRequest {
    Marker?: string;
    Filters?: IntegrationResourcePropertyFilter[];
    MaxRecords?: number;
}
export declare const ListIntegrationResourcePropertiesRequest: S.Schema<ListIntegrationResourcePropertiesRequest>;
export interface IntegrationResourceProperty {
    ResourceArn: string;
    ResourcePropertyArn?: string;
    SourceProcessingProperties?: SourceProcessingProperties;
    TargetProcessingProperties?: TargetProcessingProperties;
}
export declare const IntegrationResourceProperty: S.Schema<IntegrationResourceProperty>;
export type IntegrationResourcePropertyList = IntegrationResourceProperty[];
export declare const IntegrationResourcePropertyList: any;
export interface ListIntegrationResourcePropertiesResponse {
    IntegrationResourcePropertyList?: IntegrationResourceProperty[];
    Marker?: string;
}
export declare const ListIntegrationResourcePropertiesResponse: S.Schema<ListIntegrationResourcePropertiesResponse>;
export interface ListIterableFormsRequest {
    AssetIdentifier: string;
    IterableFormName: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListIterableFormsRequest: S.Schema<ListIterableFormsRequest>;
export type ItemDescription = string;
export interface IterableFormListItem {
    ItemId?: string;
    ItemName?: string;
    Description?: string;
    GlossaryTerms?: string[];
}
export declare const IterableFormListItem: S.Schema<IterableFormListItem>;
export type IterableFormListItemList = IterableFormListItem[];
export declare const IterableFormListItemList: any;
export interface ListIterableFormsResponse {
    Items?: IterableFormListItem[];
    NextToken?: string;
}
export declare const ListIterableFormsResponse: S.Schema<ListIterableFormsResponse>;
export interface ListJobsRequest {
    NextToken?: string;
    MaxResults?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListJobsRequest: S.Schema<ListJobsRequest>;
export interface ListJobsResponse {
    JobNames?: string[];
    NextToken?: string;
}
export declare const ListJobsResponse: S.Schema<ListJobsResponse>;
export interface ListMaterializedViewRefreshTaskRunsRequest {
    CatalogId: string;
    DatabaseName?: string;
    TableName?: string;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListMaterializedViewRefreshTaskRunsRequest: S.Schema<ListMaterializedViewRefreshTaskRunsRequest>;
export type MaterializedViewRefreshTaskRunsList = MaterializedViewRefreshTaskRun[];
export declare const MaterializedViewRefreshTaskRunsList: any;
export interface ListMaterializedViewRefreshTaskRunsResponse {
    MaterializedViewRefreshTaskRuns?: MaterializedViewRefreshTaskRun[];
    NextToken?: string;
}
export declare const ListMaterializedViewRefreshTaskRunsResponse: S.Schema<ListMaterializedViewRefreshTaskRunsResponse>;
export interface ListMLTransformsRequest {
    NextToken?: string;
    MaxResults?: number;
    Filter?: TransformFilterCriteria;
    Sort?: TransformSortCriteria;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListMLTransformsRequest: S.Schema<ListMLTransformsRequest>;
export type TransformIdList = string[];
export declare const TransformIdList: any;
export interface ListMLTransformsResponse {
    TransformIds: string[];
    NextToken?: string;
}
export declare const ListMLTransformsResponse: S.Schema<ListMLTransformsResponse>;
export type MaxResultsNumber = number;
export type SchemaRegistryTokenString = string;
export interface ListRegistriesInput {
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListRegistriesInput: S.Schema<ListRegistriesInput>;
export interface RegistryListItem {
    RegistryName?: string;
    RegistryArn?: string;
    Description?: string;
    Status?: RegistryStatus;
    CreatedTime?: string;
    UpdatedTime?: string;
}
export declare const RegistryListItem: S.Schema<RegistryListItem>;
export type RegistryListDefinition = RegistryListItem[];
export declare const RegistryListDefinition: any;
export interface ListRegistriesResponse {
    Registries?: RegistryListItem[];
    NextToken?: string;
}
export declare const ListRegistriesResponse: S.Schema<ListRegistriesResponse>;
export interface ListSchemasInput {
    RegistryId?: RegistryId;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListSchemasInput: S.Schema<ListSchemasInput>;
export interface SchemaListItem {
    RegistryName?: string;
    SchemaName?: string;
    SchemaArn?: string;
    Description?: string;
    SchemaStatus?: SchemaStatus;
    CreatedTime?: string;
    UpdatedTime?: string;
}
export declare const SchemaListItem: S.Schema<SchemaListItem>;
export type SchemaListDefinition = SchemaListItem[];
export declare const SchemaListDefinition: any;
export interface ListSchemasResponse {
    Schemas?: SchemaListItem[];
    NextToken?: string;
}
export declare const ListSchemasResponse: S.Schema<ListSchemasResponse>;
export interface ListSchemaVersionsInput {
    SchemaId: SchemaId;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListSchemaVersionsInput: S.Schema<ListSchemaVersionsInput>;
export interface SchemaVersionListItem {
    SchemaArn?: string;
    SchemaVersionId?: string;
    VersionNumber?: number;
    Status?: SchemaVersionStatus;
    CreatedTime?: string;
}
export declare const SchemaVersionListItem: S.Schema<SchemaVersionListItem>;
export type SchemaVersionList = SchemaVersionListItem[];
export declare const SchemaVersionList: any;
export interface ListSchemaVersionsResponse {
    Schemas?: SchemaVersionListItem[];
    NextToken?: string;
}
export declare const ListSchemaVersionsResponse: S.Schema<ListSchemaVersionsResponse>;
export type OrchestrationToken = string;
export interface ListSessionsRequest {
    NextToken?: string;
    MaxResults?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
    RequestOrigin?: string;
}
export declare const ListSessionsRequest: S.Schema<ListSessionsRequest>;
export type SessionIdList = string[];
export declare const SessionIdList: any;
export type SessionList = Session[];
export declare const SessionList: any;
export interface ListSessionsResponse {
    Ids?: string[];
    Sessions?: Session[];
    NextToken?: string;
}
export declare const ListSessionsResponse: S.Schema<ListSessionsResponse>;
export interface ListStatementsRequest {
    SessionId: string;
    RequestOrigin?: string;
    NextToken?: string;
}
export declare const ListStatementsRequest: S.Schema<ListStatementsRequest>;
export type StatementList = Statement[];
export declare const StatementList: any;
export interface ListStatementsResponse {
    Statements?: Statement[];
    NextToken?: string;
}
export declare const ListStatementsResponse: S.Schema<ListStatementsResponse>;
export type MaxListTableOptimizerRunsTokenResults = number;
export type ListTableOptimizerRunsToken = string;
export interface ListTableOptimizerRunsRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
    MaxResults?: number;
    NextToken?: string;
}
export declare const ListTableOptimizerRunsRequest: S.Schema<ListTableOptimizerRunsRequest>;
export type TableOptimizerRuns = TableOptimizerRun[];
export declare const TableOptimizerRuns: any;
export interface ListTableOptimizerRunsResponse {
    CatalogId?: string;
    DatabaseName?: string;
    TableName?: string;
    NextToken?: string;
    TableOptimizerRuns?: TableOptimizerRun[];
}
export declare const ListTableOptimizerRunsResponse: S.Schema<ListTableOptimizerRunsResponse>;
export interface ListTriggersRequest {
    NextToken?: string;
    DependentJobName?: string;
    MaxResults?: number;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTriggersRequest: S.Schema<ListTriggersRequest>;
export interface ListTriggersResponse {
    TriggerNames?: string[];
    NextToken?: string;
}
export declare const ListTriggersResponse: S.Schema<ListTriggersResponse>;
export interface ListUsageProfilesRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListUsageProfilesRequest: S.Schema<ListUsageProfilesRequest>;
export interface UsageProfileDefinition {
    Name?: string;
    Description?: string;
    CreatedOn?: Date;
    LastModifiedOn?: Date;
}
export declare const UsageProfileDefinition: S.Schema<UsageProfileDefinition>;
export type UsageProfileDefinitionList = UsageProfileDefinition[];
export declare const UsageProfileDefinitionList: any;
export interface ListUsageProfilesResponse {
    Profiles?: UsageProfileDefinition[];
    NextToken?: string;
}
export declare const ListUsageProfilesResponse: S.Schema<ListUsageProfilesResponse>;
export interface ListWorkflowsRequest {
    NextToken?: string;
    MaxResults?: number;
}
export declare const ListWorkflowsRequest: S.Schema<ListWorkflowsRequest>;
export interface ListWorkflowsResponse {
    Workflows?: string[];
    NextToken?: string;
}
export declare const ListWorkflowsResponse: S.Schema<ListWorkflowsResponse>;
export interface ModifyIntegrationRequest {
    IntegrationIdentifier: string;
    Description?: string;
    DataFilter?: string;
    IntegrationConfig?: IntegrationConfig;
    IntegrationName?: string;
}
export declare const ModifyIntegrationRequest: S.Schema<ModifyIntegrationRequest>;
export interface ModifyIntegrationResponse {
    SourceArn: string;
    TargetArn: string;
    IntegrationName: string;
    Description?: string;
    IntegrationArn: string;
    KmsKeyId?: string;
    AdditionalEncryptionContext?: {
        [key: string]: string | undefined;
    };
    Tags?: Tag[];
    Status: IntegrationStatus;
    CreateTime: Date;
    Errors?: IntegrationError[];
    DataFilter?: string;
    IntegrationConfig?: IntegrationConfig;
}
export declare const ModifyIntegrationResponse: S.Schema<ModifyIntegrationResponse>;
export interface PutAssetRequest {
    AssetTypeId: string;
    Identifier: string;
    Name: string;
    Description?: string;
    Forms: {
        [key: string]: AssetFormEntry | undefined;
    };
    ClientToken?: string;
}
export declare const PutAssetRequest: S.Schema<PutAssetRequest>;
export interface PutAssetResponse {
    Id: string;
    Name: string;
    Description?: string;
    CreatedAt?: Date;
    Forms?: {
        [key: string]: AssetFormEntry | undefined;
    };
}
export declare const PutAssetResponse: S.Schema<PutAssetResponse>;
export interface PutAssetTypeRequest {
    Name: string;
    Forms: {
        [key: string]: AssetTypeFormReference | undefined;
    };
    ClientToken?: string;
}
export declare const PutAssetTypeRequest: S.Schema<PutAssetTypeRequest>;
export interface PutAssetTypeResponse {
    Id?: string;
    Name?: string;
    Forms?: {
        [key: string]: AssetTypeFormReference | undefined;
    };
}
export declare const PutAssetTypeResponse: S.Schema<PutAssetTypeResponse>;
export interface PutAttachmentRequest {
    AssetIdentifier: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
    AttachmentName: string;
    Content: string;
    FormTypeId: string;
    ClientToken?: string;
}
export declare const PutAttachmentRequest: S.Schema<PutAttachmentRequest>;
export interface PutAttachmentResponse {
    AssetIdentifier?: string;
    IterableFormName?: string;
    ItemIdentifier?: string;
    AttachmentName?: string;
    FormTypeId?: string;
}
export declare const PutAttachmentResponse: S.Schema<PutAttachmentResponse>;
export interface PutDataCatalogEncryptionSettingsRequest {
    CatalogId?: string;
    DataCatalogEncryptionSettings: DataCatalogEncryptionSettings;
}
export declare const PutDataCatalogEncryptionSettingsRequest: S.Schema<PutDataCatalogEncryptionSettingsRequest>;
export interface PutDataCatalogEncryptionSettingsResponse {
}
export declare const PutDataCatalogEncryptionSettingsResponse: S.Schema<PutDataCatalogEncryptionSettingsResponse>;
export interface PutDataCatalogExportConfigurationInput {
    ExportSetting: ExportSetting;
    EncryptionConfiguration?: ExportEncryptionConfiguration;
    ClientToken?: string;
}
export declare const PutDataCatalogExportConfigurationInput: S.Schema<PutDataCatalogExportConfigurationInput>;
export interface PutDataCatalogExportConfigurationOutput {
    ExportSetting?: ExportSetting;
    EncryptionConfiguration?: ExportEncryptionConfiguration;
}
export declare const PutDataCatalogExportConfigurationOutput: S.Schema<PutDataCatalogExportConfigurationOutput>;
export interface PutDataQualityProfileAnnotationRequest {
    ProfileId: string;
    InclusionAnnotation: InclusionAnnotationValue;
}
export declare const PutDataQualityProfileAnnotationRequest: S.Schema<PutDataQualityProfileAnnotationRequest>;
export interface PutDataQualityProfileAnnotationResponse {
}
export declare const PutDataQualityProfileAnnotationResponse: S.Schema<PutDataQualityProfileAnnotationResponse>;
export interface PutFormTypeRequest {
    Name: string;
    Schema: string;
    ClientToken?: string;
}
export declare const PutFormTypeRequest: S.Schema<PutFormTypeRequest>;
export interface PutFormTypeResponse {
    Id?: string;
    Name?: string;
    Schema?: string;
}
export declare const PutFormTypeResponse: S.Schema<PutFormTypeResponse>;
export type ExistCondition = "MUST_EXIST" | "NOT_EXIST" | "NONE" | (string & {});
export declare const ExistCondition: any;
export type EnableHybridValues = "TRUE" | "FALSE" | (string & {});
export declare const EnableHybridValues: any;
export interface PutResourcePolicyRequest {
    PolicyInJson: string;
    ResourceArn?: string;
    PolicyHashCondition?: string;
    PolicyExistsCondition?: ExistCondition;
    EnableHybrid?: EnableHybridValues;
}
export declare const PutResourcePolicyRequest: S.Schema<PutResourcePolicyRequest>;
export interface PutResourcePolicyResponse {
    PolicyHash?: string;
}
export declare const PutResourcePolicyResponse: S.Schema<PutResourcePolicyResponse>;
export type MetadataKeyString = string;
export type MetadataValueString = string;
export interface MetadataKeyValuePair {
    MetadataKey?: string;
    MetadataValue?: string;
}
export declare const MetadataKeyValuePair: S.Schema<MetadataKeyValuePair>;
export interface PutSchemaVersionMetadataInput {
    SchemaId?: SchemaId;
    SchemaVersionNumber?: SchemaVersionNumber;
    SchemaVersionId?: string;
    MetadataKeyValue: MetadataKeyValuePair;
}
export declare const PutSchemaVersionMetadataInput: S.Schema<PutSchemaVersionMetadataInput>;
export interface PutSchemaVersionMetadataResponse {
    SchemaArn?: string;
    SchemaName?: string;
    RegistryName?: string;
    LatestVersion?: boolean;
    VersionNumber?: number;
    SchemaVersionId?: string;
    MetadataKey?: string;
    MetadataValue?: string;
}
export declare const PutSchemaVersionMetadataResponse: S.Schema<PutSchemaVersionMetadataResponse>;
export interface PutWorkflowRunPropertiesRequest {
    Name: string;
    RunId: string;
    RunProperties: {
        [key: string]: string | undefined;
    };
}
export declare const PutWorkflowRunPropertiesRequest: S.Schema<PutWorkflowRunPropertiesRequest>;
export interface PutWorkflowRunPropertiesResponse {
}
export declare const PutWorkflowRunPropertiesResponse: S.Schema<PutWorkflowRunPropertiesResponse>;
export type MetadataList = MetadataKeyValuePair[];
export declare const MetadataList: any;
export type QuerySchemaVersionMetadataMaxResults = number;
export interface QuerySchemaVersionMetadataInput {
    SchemaId?: SchemaId;
    SchemaVersionNumber?: SchemaVersionNumber;
    SchemaVersionId?: string;
    MetadataList?: MetadataKeyValuePair[];
    MaxResults?: number;
    NextToken?: string;
}
export declare const QuerySchemaVersionMetadataInput: S.Schema<QuerySchemaVersionMetadataInput>;
export interface OtherMetadataValueListItem {
    MetadataValue?: string;
    CreatedTime?: string;
}
export declare const OtherMetadataValueListItem: S.Schema<OtherMetadataValueListItem>;
export type OtherMetadataValueList = OtherMetadataValueListItem[];
export declare const OtherMetadataValueList: any;
export interface MetadataInfo {
    MetadataValue?: string;
    CreatedTime?: string;
    OtherMetadataValueList?: OtherMetadataValueListItem[];
}
export declare const MetadataInfo: S.Schema<MetadataInfo>;
export type MetadataInfoMap = {
    [key: string]: MetadataInfo | undefined;
};
export declare const MetadataInfoMap: any;
export interface QuerySchemaVersionMetadataResponse {
    MetadataInfoMap?: {
        [key: string]: MetadataInfo | undefined;
    };
    SchemaVersionId?: string;
    NextToken?: string;
}
export declare const QuerySchemaVersionMetadataResponse: S.Schema<QuerySchemaVersionMetadataResponse>;
export type IntegrationType = "REST" | (string & {});
export declare const IntegrationType: any;
export interface ConnectionPropertiesConfiguration {
    Url?: ConnectorProperty;
    AdditionalRequestParameters?: ConnectorProperty[];
}
export declare const ConnectionPropertiesConfiguration: S.Schema<ConnectionPropertiesConfiguration>;
export type ConnectorOAuth2GrantType = "CLIENT_CREDENTIALS" | "JWT_BEARER" | "AUTHORIZATION_CODE" | (string & {});
export declare const ConnectorOAuth2GrantType: any;
export type ContentType = "APPLICATION_JSON" | "URL_ENCODED" | (string & {});
export declare const ContentType: any;
export interface ClientCredentialsProperties {
    TokenUrl?: ConnectorProperty;
    RequestMethod?: HTTPMethod;
    ContentType?: ContentType;
    ClientId?: ConnectorProperty;
    ClientSecret?: ConnectorProperty;
    Scope?: ConnectorProperty;
    TokenUrlParameters?: ConnectorProperty[];
}
export declare const ClientCredentialsProperties: S.Schema<ClientCredentialsProperties>;
export interface JWTBearerProperties {
    TokenUrl?: ConnectorProperty;
    RequestMethod?: HTTPMethod;
    ContentType?: ContentType;
    JwtToken?: ConnectorProperty;
    TokenUrlParameters?: ConnectorProperty[];
}
export declare const JWTBearerProperties: S.Schema<JWTBearerProperties>;
export interface ConnectorAuthorizationCodeProperties {
    AuthorizationCodeUrl?: ConnectorProperty;
    AuthorizationCode?: ConnectorProperty;
    RedirectUri?: ConnectorProperty;
    TokenUrl?: ConnectorProperty;
    RequestMethod?: HTTPMethod;
    ContentType?: ContentType;
    ClientId?: ConnectorProperty;
    ClientSecret?: ConnectorProperty;
    Scope?: ConnectorProperty;
    Prompt?: ConnectorProperty;
    TokenUrlParameters?: ConnectorProperty[];
}
export declare const ConnectorAuthorizationCodeProperties: S.Schema<ConnectorAuthorizationCodeProperties>;
export interface ConnectorOAuth2Properties {
    OAuth2GrantType: ConnectorOAuth2GrantType;
    ClientCredentialsProperties?: ClientCredentialsProperties;
    JWTBearerProperties?: JWTBearerProperties;
    AuthorizationCodeProperties?: ConnectorAuthorizationCodeProperties;
}
export declare const ConnectorOAuth2Properties: S.Schema<ConnectorOAuth2Properties>;
export interface BasicAuthenticationProperties {
    Username?: ConnectorProperty;
    Password?: ConnectorProperty;
}
export declare const BasicAuthenticationProperties: S.Schema<BasicAuthenticationProperties>;
export interface CustomAuthenticationProperties {
    AuthenticationParameters: ConnectorProperty[];
}
export declare const CustomAuthenticationProperties: S.Schema<CustomAuthenticationProperties>;
export interface ConnectorAuthenticationConfiguration {
    AuthenticationTypes: AuthenticationType[];
    OAuth2Properties?: ConnectorOAuth2Properties;
    BasicAuthenticationProperties?: BasicAuthenticationProperties;
    CustomAuthenticationProperties?: CustomAuthenticationProperties;
}
export declare const ConnectorAuthenticationConfiguration: S.Schema<ConnectorAuthenticationConfiguration>;
export interface RegisterConnectionTypeRequest {
    ConnectionType: string;
    IntegrationType: IntegrationType;
    Description?: string;
    ConnectionProperties: ConnectionPropertiesConfiguration;
    ConnectorAuthenticationConfiguration: ConnectorAuthenticationConfiguration;
    RestConfiguration: RestConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    };
}
export declare const RegisterConnectionTypeRequest: S.Schema<RegisterConnectionTypeRequest>;
export interface RegisterConnectionTypeResponse {
    ConnectionTypeArn?: string;
}
export declare const RegisterConnectionTypeResponse: S.Schema<RegisterConnectionTypeResponse>;
export interface RegisterSchemaVersionInput {
    SchemaId: SchemaId;
    SchemaDefinition: string;
}
export declare const RegisterSchemaVersionInput: S.Schema<RegisterSchemaVersionInput>;
export interface RegisterSchemaVersionResponse {
    SchemaVersionId?: string;
    VersionNumber?: number;
    Status?: SchemaVersionStatus;
}
export declare const RegisterSchemaVersionResponse: S.Schema<RegisterSchemaVersionResponse>;
export interface RemoveSchemaVersionMetadataInput {
    SchemaId?: SchemaId;
    SchemaVersionNumber?: SchemaVersionNumber;
    SchemaVersionId?: string;
    MetadataKeyValue: MetadataKeyValuePair;
}
export declare const RemoveSchemaVersionMetadataInput: S.Schema<RemoveSchemaVersionMetadataInput>;
export interface RemoveSchemaVersionMetadataResponse {
    SchemaArn?: string;
    SchemaName?: string;
    RegistryName?: string;
    LatestVersion?: boolean;
    VersionNumber?: number;
    SchemaVersionId?: string;
    MetadataKey?: string;
    MetadataValue?: string;
}
export declare const RemoveSchemaVersionMetadataResponse: S.Schema<RemoveSchemaVersionMetadataResponse>;
export interface ResetJobBookmarkRequest {
    JobName: string;
    RunId?: string;
}
export declare const ResetJobBookmarkRequest: S.Schema<ResetJobBookmarkRequest>;
export interface ResetJobBookmarkResponse {
    JobBookmarkEntry?: JobBookmarkEntry;
}
export declare const ResetJobBookmarkResponse: S.Schema<ResetJobBookmarkResponse>;
export type NodeIdList = string[];
export declare const NodeIdList: any;
export interface ResumeWorkflowRunRequest {
    Name: string;
    RunId: string;
    NodeIds: string[];
}
export declare const ResumeWorkflowRunRequest: S.Schema<ResumeWorkflowRunRequest>;
export interface ResumeWorkflowRunResponse {
    RunId?: string;
    NodeIds?: string[];
}
export declare const ResumeWorkflowRunResponse: S.Schema<ResumeWorkflowRunResponse>;
export type OrchestrationStatementCodeString = string;
export interface RunStatementRequest {
    SessionId: string;
    Code: string;
    RequestOrigin?: string;
}
export declare const RunStatementRequest: S.Schema<RunStatementRequest>;
export interface RunStatementResponse {
    Id?: number;
}
export declare const RunStatementResponse: S.Schema<RunStatementResponse>;
export type SearchText = string;
export type SearchMaxResults = number;
export type SearchNextToken = string;
export type SearchAttribute = string;
export type SearchSortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export declare const SearchSortOrder: any;
export interface SearchSort {
    Attribute: string;
    Order?: SearchSortOrder;
}
export declare const SearchSort: S.Schema<SearchSort>;
export type SearchFilterClauseList = SearchFilterClause[];
export declare const SearchFilterClauseList: S.Schema<SearchFilterClauseList>;
export type SearchFilterOperator = "equals" | "greaterThan" | "greaterThanOrEquals" | "lessThan" | "lessThanOrEquals" | "notExists" | (string & {});
export declare const SearchFilterOperator: any;
export type SearchFilterStringValue = string;
export type SearchFilterLongValue = number;
export type SearchFilterValue = {
    StringValue: string;
    LongValue?: never;
} | {
    StringValue?: never;
    LongValue: number;
};
export declare const SearchFilterValue: any;
export interface SearchAttributeFilter {
    Attribute: string;
    Operator: SearchFilterOperator;
    Value?: SearchFilterValue;
}
export declare const SearchAttributeFilter: S.Schema<SearchAttributeFilter>;
export type SearchMapKey = string;
export type SearchMapFilterValue = {
    StringValue: string;
};
export declare const SearchMapFilterValue: any;
export interface SearchMapFilter {
    Attribute: string;
    Key: string;
    Value: SearchMapFilterValue;
}
export declare const SearchMapFilter: S.Schema<SearchMapFilter>;
export type SearchFilterClause = {
    AndAllFilters: SearchFilterClause[];
    OrAnyFilters?: never;
    AttributeFilter?: never;
    MapFilter?: never;
} | {
    AndAllFilters?: never;
    OrAnyFilters: SearchFilterClause[];
    AttributeFilter?: never;
    MapFilter?: never;
} | {
    AndAllFilters?: never;
    OrAnyFilters?: never;
    AttributeFilter: SearchAttributeFilter;
    MapFilter?: never;
} | {
    AndAllFilters?: never;
    OrAnyFilters?: never;
    AttributeFilter?: never;
    MapFilter: SearchMapFilter;
};
export declare const SearchFilterClause: S.Schema<SearchFilterClause>;
export interface SearchAssetsInput {
    SearchText?: string;
    MaxResults?: number;
    NextToken?: string;
    Sort?: SearchSort;
    FilterClause?: SearchFilterClause;
}
export declare const SearchAssetsInput: S.Schema<SearchAssetsInput>;
export type SearchResultName = string;
export interface SearchResultItem {
    Id?: string;
    AssetName?: string;
    AssetDescription?: string;
    UpdatedAt?: Date;
    AssetTypeId?: string;
}
export declare const SearchResultItem: S.Schema<SearchResultItem>;
export type SearchResultItemList = SearchResultItem[];
export declare const SearchResultItemList: any;
export interface SearchAssetsOutput {
    Items?: SearchResultItem[];
    NextToken?: string;
}
export declare const SearchAssetsOutput: S.Schema<SearchAssetsOutput>;
export type Comparator = "EQUALS" | "GREATER_THAN" | "LESS_THAN" | "GREATER_THAN_EQUALS" | "LESS_THAN_EQUALS" | (string & {});
export declare const Comparator: any;
export interface PropertyPredicate {
    Key?: string;
    Value?: string;
    Comparator?: Comparator;
}
export declare const PropertyPredicate: S.Schema<PropertyPredicate>;
export type SearchPropertyPredicates = PropertyPredicate[];
export declare const SearchPropertyPredicates: any;
export type Sort = "ASC" | "DESC" | (string & {});
export declare const Sort: any;
export interface SortCriterion {
    FieldName?: string;
    Sort?: Sort;
}
export declare const SortCriterion: S.Schema<SortCriterion>;
export type SortCriteria = SortCriterion[];
export declare const SortCriteria: any;
export interface SearchTablesRequest {
    CatalogId?: string;
    NextToken?: string;
    Filters?: PropertyPredicate[];
    SearchText?: string;
    SortCriteria?: SortCriterion[];
    MaxResults?: number;
    ResourceShareType?: ResourceShareType;
    IncludeStatusDetails?: boolean;
}
export declare const SearchTablesRequest: S.Schema<SearchTablesRequest>;
export interface SearchTablesResponse {
    NextToken?: string;
    TableList?: Table[];
}
export declare const SearchTablesResponse: S.Schema<SearchTablesResponse>;
export interface StartBlueprintRunRequest {
    BlueprintName: string;
    Parameters?: string;
    RoleArn: string;
}
export declare const StartBlueprintRunRequest: S.Schema<StartBlueprintRunRequest>;
export interface StartBlueprintRunResponse {
    RunId?: string;
}
export declare const StartBlueprintRunResponse: S.Schema<StartBlueprintRunResponse>;
export interface StartColumnStatisticsTaskRunRequest {
    DatabaseName: string;
    TableName: string;
    ColumnNameList?: string[];
    Role: string;
    SampleSize?: number;
    CatalogID?: string;
    SecurityConfiguration?: string;
}
export declare const StartColumnStatisticsTaskRunRequest: S.Schema<StartColumnStatisticsTaskRunRequest>;
export interface StartColumnStatisticsTaskRunResponse {
    ColumnStatisticsTaskRunId?: string;
}
export declare const StartColumnStatisticsTaskRunResponse: S.Schema<StartColumnStatisticsTaskRunResponse>;
export interface StartColumnStatisticsTaskRunScheduleRequest {
    DatabaseName: string;
    TableName: string;
}
export declare const StartColumnStatisticsTaskRunScheduleRequest: S.Schema<StartColumnStatisticsTaskRunScheduleRequest>;
export interface StartColumnStatisticsTaskRunScheduleResponse {
}
export declare const StartColumnStatisticsTaskRunScheduleResponse: S.Schema<StartColumnStatisticsTaskRunScheduleResponse>;
export interface StartCrawlerRequest {
    Name: string;
}
export declare const StartCrawlerRequest: S.Schema<StartCrawlerRequest>;
export interface StartCrawlerResponse {
}
export declare const StartCrawlerResponse: S.Schema<StartCrawlerResponse>;
export interface StartCrawlerScheduleRequest {
    CrawlerName: string;
}
export declare const StartCrawlerScheduleRequest: S.Schema<StartCrawlerScheduleRequest>;
export interface StartCrawlerScheduleResponse {
}
export declare const StartCrawlerScheduleResponse: S.Schema<StartCrawlerScheduleResponse>;
export interface StartDataQualityRuleRecommendationRunRequest {
    DataSource: DataSource;
    Role: string;
    NumberOfWorkers?: number;
    Timeout?: number;
    CreatedRulesetName?: string;
    DataQualitySecurityConfiguration?: string;
    ClientToken?: string;
    AdditionalRunOptions?: DataQualityRuleRecommendationRunAdditionalRunOptions;
}
export declare const StartDataQualityRuleRecommendationRunRequest: S.Schema<StartDataQualityRuleRecommendationRunRequest>;
export interface StartDataQualityRuleRecommendationRunResponse {
    RunId?: string;
}
export declare const StartDataQualityRuleRecommendationRunResponse: S.Schema<StartDataQualityRuleRecommendationRunResponse>;
export interface StartDataQualityRulesetEvaluationRunRequest {
    DataSource: DataSource;
    Role: string;
    NumberOfWorkers?: number;
    Timeout?: number;
    ClientToken?: string;
    AdditionalRunOptions?: DataQualityEvaluationRunAdditionalRunOptions;
    RulesetNames: string[];
    AdditionalDataSources?: {
        [key: string]: DataSource | undefined;
    };
}
export declare const StartDataQualityRulesetEvaluationRunRequest: S.Schema<StartDataQualityRulesetEvaluationRunRequest>;
export interface StartDataQualityRulesetEvaluationRunResponse {
    RunId?: string;
}
export declare const StartDataQualityRulesetEvaluationRunResponse: S.Schema<StartDataQualityRulesetEvaluationRunResponse>;
export interface StartExportLabelsTaskRunRequest {
    TransformId: string;
    OutputS3Path: string;
}
export declare const StartExportLabelsTaskRunRequest: S.Schema<StartExportLabelsTaskRunRequest>;
export interface StartExportLabelsTaskRunResponse {
    TaskRunId?: string;
}
export declare const StartExportLabelsTaskRunResponse: S.Schema<StartExportLabelsTaskRunResponse>;
export interface StartImportLabelsTaskRunRequest {
    TransformId: string;
    InputS3Path: string;
    ReplaceAllLabels?: boolean;
}
export declare const StartImportLabelsTaskRunRequest: S.Schema<StartImportLabelsTaskRunRequest>;
export interface StartImportLabelsTaskRunResponse {
    TaskRunId?: string;
}
export declare const StartImportLabelsTaskRunResponse: S.Schema<StartImportLabelsTaskRunResponse>;
export interface StartJobRunRequest {
    JobName: string;
    JobRunQueuingEnabled?: boolean;
    JobRunId?: string;
    Arguments?: {
        [key: string]: string | undefined;
    };
    AllocatedCapacity?: number;
    Timeout?: number;
    MaxCapacity?: number;
    SecurityConfiguration?: string;
    NotificationProperty?: NotificationProperty;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    ExecutionClass?: ExecutionClass;
    ExecutionRoleSessionPolicy?: string;
}
export declare const StartJobRunRequest: S.Schema<StartJobRunRequest>;
export interface StartJobRunResponse {
    JobRunId?: string;
}
export declare const StartJobRunResponse: S.Schema<StartJobRunResponse>;
export interface StartMaterializedViewRefreshTaskRunRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    FullRefresh?: boolean;
}
export declare const StartMaterializedViewRefreshTaskRunRequest: S.Schema<StartMaterializedViewRefreshTaskRunRequest>;
export interface StartMaterializedViewRefreshTaskRunResponse {
    MaterializedViewRefreshTaskRunId?: string;
}
export declare const StartMaterializedViewRefreshTaskRunResponse: S.Schema<StartMaterializedViewRefreshTaskRunResponse>;
export interface StartMLEvaluationTaskRunRequest {
    TransformId: string;
}
export declare const StartMLEvaluationTaskRunRequest: S.Schema<StartMLEvaluationTaskRunRequest>;
export interface StartMLEvaluationTaskRunResponse {
    TaskRunId?: string;
}
export declare const StartMLEvaluationTaskRunResponse: S.Schema<StartMLEvaluationTaskRunResponse>;
export interface StartMLLabelingSetGenerationTaskRunRequest {
    TransformId: string;
    OutputS3Path: string;
}
export declare const StartMLLabelingSetGenerationTaskRunRequest: S.Schema<StartMLLabelingSetGenerationTaskRunRequest>;
export interface StartMLLabelingSetGenerationTaskRunResponse {
    TaskRunId?: string;
}
export declare const StartMLLabelingSetGenerationTaskRunResponse: S.Schema<StartMLLabelingSetGenerationTaskRunResponse>;
export interface StartTriggerRequest {
    Name: string;
}
export declare const StartTriggerRequest: S.Schema<StartTriggerRequest>;
export interface StartTriggerResponse {
    Name?: string;
}
export declare const StartTriggerResponse: S.Schema<StartTriggerResponse>;
export interface StartWorkflowRunRequest {
    Name: string;
    RunProperties?: {
        [key: string]: string | undefined;
    };
}
export declare const StartWorkflowRunRequest: S.Schema<StartWorkflowRunRequest>;
export interface StartWorkflowRunResponse {
    RunId?: string;
}
export declare const StartWorkflowRunResponse: S.Schema<StartWorkflowRunResponse>;
export interface StopColumnStatisticsTaskRunRequest {
    DatabaseName: string;
    TableName: string;
}
export declare const StopColumnStatisticsTaskRunRequest: S.Schema<StopColumnStatisticsTaskRunRequest>;
export interface StopColumnStatisticsTaskRunResponse {
}
export declare const StopColumnStatisticsTaskRunResponse: S.Schema<StopColumnStatisticsTaskRunResponse>;
export interface StopColumnStatisticsTaskRunScheduleRequest {
    DatabaseName: string;
    TableName: string;
}
export declare const StopColumnStatisticsTaskRunScheduleRequest: S.Schema<StopColumnStatisticsTaskRunScheduleRequest>;
export interface StopColumnStatisticsTaskRunScheduleResponse {
}
export declare const StopColumnStatisticsTaskRunScheduleResponse: S.Schema<StopColumnStatisticsTaskRunScheduleResponse>;
export interface StopCrawlerRequest {
    Name: string;
}
export declare const StopCrawlerRequest: S.Schema<StopCrawlerRequest>;
export interface StopCrawlerResponse {
}
export declare const StopCrawlerResponse: S.Schema<StopCrawlerResponse>;
export interface StopCrawlerScheduleRequest {
    CrawlerName: string;
}
export declare const StopCrawlerScheduleRequest: S.Schema<StopCrawlerScheduleRequest>;
export interface StopCrawlerScheduleResponse {
}
export declare const StopCrawlerScheduleResponse: S.Schema<StopCrawlerScheduleResponse>;
export interface StopMaterializedViewRefreshTaskRunRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
}
export declare const StopMaterializedViewRefreshTaskRunRequest: S.Schema<StopMaterializedViewRefreshTaskRunRequest>;
export interface StopMaterializedViewRefreshTaskRunResponse {
}
export declare const StopMaterializedViewRefreshTaskRunResponse: S.Schema<StopMaterializedViewRefreshTaskRunResponse>;
export interface StopSessionRequest {
    Id: string;
    RequestOrigin?: string;
}
export declare const StopSessionRequest: S.Schema<StopSessionRequest>;
export interface StopSessionResponse {
    Id?: string;
}
export declare const StopSessionResponse: S.Schema<StopSessionResponse>;
export interface StopTriggerRequest {
    Name: string;
}
export declare const StopTriggerRequest: S.Schema<StopTriggerRequest>;
export interface StopTriggerResponse {
    Name?: string;
}
export declare const StopTriggerResponse: S.Schema<StopTriggerResponse>;
export interface StopWorkflowRunRequest {
    Name: string;
    RunId: string;
}
export declare const StopWorkflowRunRequest: S.Schema<StopWorkflowRunRequest>;
export interface StopWorkflowRunResponse {
}
export declare const StopWorkflowRunResponse: S.Schema<StopWorkflowRunResponse>;
export interface TagResourceRequest {
    ResourceArn: string;
    TagsToAdd: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface TestConnectionInput {
    ConnectionType: ConnectionType;
    ConnectionProperties: {
        [key: string]: string | undefined;
    };
    AuthenticationConfiguration?: AuthenticationConfigurationInput;
}
export declare const TestConnectionInput: S.Schema<TestConnectionInput>;
export interface TestConnectionRequest {
    ConnectionName?: string;
    CatalogId?: string;
    TestConnectionInput?: TestConnectionInput;
}
export declare const TestConnectionRequest: S.Schema<TestConnectionRequest>;
export interface TestConnectionResponse {
}
export declare const TestConnectionResponse: S.Schema<TestConnectionResponse>;
export type TagKeysList = string[];
export declare const TagKeysList: any;
export interface UntagResourceRequest {
    ResourceArn: string;
    TagsToRemove: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAssetRequest {
    Identifier: string;
    Name?: string;
    Description?: string;
    ClientToken?: string;
}
export declare const UpdateAssetRequest: S.Schema<UpdateAssetRequest>;
export interface UpdateAssetResponse {
    Id: string;
    Name?: string;
    Description?: string;
    UpdatedAt?: Date;
}
export declare const UpdateAssetResponse: S.Schema<UpdateAssetResponse>;
export interface UpdateBlueprintRequest {
    Name: string;
    Description?: string;
    BlueprintLocation: string;
}
export declare const UpdateBlueprintRequest: S.Schema<UpdateBlueprintRequest>;
export interface UpdateBlueprintResponse {
    Name?: string;
}
export declare const UpdateBlueprintResponse: S.Schema<UpdateBlueprintResponse>;
export interface UpdateCatalogRequest {
    CatalogId: string;
    CatalogInput: CatalogInput;
}
export declare const UpdateCatalogRequest: S.Schema<UpdateCatalogRequest>;
export interface UpdateCatalogResponse {
}
export declare const UpdateCatalogResponse: S.Schema<UpdateCatalogResponse>;
export interface UpdateGrokClassifierRequest {
    Name: string;
    Classification?: string;
    GrokPattern?: string;
    CustomPatterns?: string;
}
export declare const UpdateGrokClassifierRequest: S.Schema<UpdateGrokClassifierRequest>;
export interface UpdateXMLClassifierRequest {
    Name: string;
    Classification?: string;
    RowTag?: string;
}
export declare const UpdateXMLClassifierRequest: S.Schema<UpdateXMLClassifierRequest>;
export interface UpdateJsonClassifierRequest {
    Name: string;
    JsonPath?: string;
}
export declare const UpdateJsonClassifierRequest: S.Schema<UpdateJsonClassifierRequest>;
export interface UpdateCsvClassifierRequest {
    Name: string;
    Delimiter?: string;
    QuoteSymbol?: string;
    ContainsHeader?: CsvHeaderOption;
    Header?: string[];
    DisableValueTrimming?: boolean;
    AllowSingleColumn?: boolean;
    CustomDatatypeConfigured?: boolean;
    CustomDatatypes?: string[];
    Serde?: CsvSerdeOption;
}
export declare const UpdateCsvClassifierRequest: S.Schema<UpdateCsvClassifierRequest>;
export interface UpdateClassifierRequest {
    GrokClassifier?: UpdateGrokClassifierRequest;
    XMLClassifier?: UpdateXMLClassifierRequest;
    JsonClassifier?: UpdateJsonClassifierRequest;
    CsvClassifier?: UpdateCsvClassifierRequest;
}
export declare const UpdateClassifierRequest: S.Schema<UpdateClassifierRequest>;
export interface UpdateClassifierResponse {
}
export declare const UpdateClassifierResponse: S.Schema<UpdateClassifierResponse>;
export type UpdateColumnStatisticsList = ColumnStatistics[];
export declare const UpdateColumnStatisticsList: any;
export interface UpdateColumnStatisticsForPartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionValues: string[];
    ColumnStatisticsList: ColumnStatistics[];
}
export declare const UpdateColumnStatisticsForPartitionRequest: S.Schema<UpdateColumnStatisticsForPartitionRequest>;
export interface ColumnStatisticsError {
    ColumnStatistics?: ColumnStatistics;
    Error?: ErrorDetail;
}
export declare const ColumnStatisticsError: S.Schema<ColumnStatisticsError>;
export type ColumnStatisticsErrors = ColumnStatisticsError[];
export declare const ColumnStatisticsErrors: any;
export interface UpdateColumnStatisticsForPartitionResponse {
    Errors?: ColumnStatisticsError[];
}
export declare const UpdateColumnStatisticsForPartitionResponse: S.Schema<UpdateColumnStatisticsForPartitionResponse>;
export interface UpdateColumnStatisticsForTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    ColumnStatisticsList: ColumnStatistics[];
}
export declare const UpdateColumnStatisticsForTableRequest: S.Schema<UpdateColumnStatisticsForTableRequest>;
export interface UpdateColumnStatisticsForTableResponse {
    Errors?: ColumnStatisticsError[];
}
export declare const UpdateColumnStatisticsForTableResponse: S.Schema<UpdateColumnStatisticsForTableResponse>;
export interface UpdateColumnStatisticsTaskSettingsRequest {
    DatabaseName: string;
    TableName: string;
    Role?: string;
    Schedule?: string;
    ColumnNameList?: string[];
    SampleSize?: number;
    CatalogID?: string;
    SecurityConfiguration?: string;
}
export declare const UpdateColumnStatisticsTaskSettingsRequest: S.Schema<UpdateColumnStatisticsTaskSettingsRequest>;
export interface UpdateColumnStatisticsTaskSettingsResponse {
}
export declare const UpdateColumnStatisticsTaskSettingsResponse: S.Schema<UpdateColumnStatisticsTaskSettingsResponse>;
export interface UpdateConnectionRequest {
    CatalogId?: string;
    Name: string;
    ConnectionInput: ConnectionInput;
}
export declare const UpdateConnectionRequest: S.Schema<UpdateConnectionRequest>;
export interface UpdateConnectionResponse {
}
export declare const UpdateConnectionResponse: S.Schema<UpdateConnectionResponse>;
export type DescriptionStringRemovable = string;
export interface UpdateCrawlerRequest {
    Name: string;
    Role?: string;
    DatabaseName?: string;
    Description?: string;
    Targets?: CrawlerTargets;
    Schedule?: string;
    Classifiers?: string[];
    TablePrefix?: string;
    SchemaChangePolicy?: SchemaChangePolicy;
    RecrawlPolicy?: RecrawlPolicy;
    LineageConfiguration?: LineageConfiguration;
    LakeFormationConfiguration?: LakeFormationConfiguration;
    Configuration?: string;
    CrawlerSecurityConfiguration?: string;
}
export declare const UpdateCrawlerRequest: S.Schema<UpdateCrawlerRequest>;
export interface UpdateCrawlerResponse {
}
export declare const UpdateCrawlerResponse: S.Schema<UpdateCrawlerResponse>;
export interface UpdateCrawlerScheduleRequest {
    CrawlerName: string;
    Schedule?: string;
}
export declare const UpdateCrawlerScheduleRequest: S.Schema<UpdateCrawlerScheduleRequest>;
export interface UpdateCrawlerScheduleResponse {
}
export declare const UpdateCrawlerScheduleResponse: S.Schema<UpdateCrawlerScheduleResponse>;
export interface UpdateDatabaseRequest {
    CatalogId?: string;
    Name: string;
    DatabaseInput: DatabaseInput;
}
export declare const UpdateDatabaseRequest: S.Schema<UpdateDatabaseRequest>;
export interface UpdateDatabaseResponse {
}
export declare const UpdateDatabaseResponse: S.Schema<UpdateDatabaseResponse>;
export interface UpdateDataQualityRulesetRequest {
    Name: string;
    Description?: string;
    Ruleset?: string;
}
export declare const UpdateDataQualityRulesetRequest: S.Schema<UpdateDataQualityRulesetRequest>;
export interface UpdateDataQualityRulesetResponse {
    Name?: string;
    Description?: string;
    Ruleset?: string;
}
export declare const UpdateDataQualityRulesetResponse: S.Schema<UpdateDataQualityRulesetResponse>;
export interface DevEndpointCustomLibraries {
    ExtraPythonLibsS3Path?: string;
    ExtraJarsS3Path?: string;
}
export declare const DevEndpointCustomLibraries: S.Schema<DevEndpointCustomLibraries>;
export interface UpdateDevEndpointRequest {
    EndpointName: string;
    PublicKey?: string;
    AddPublicKeys?: string[];
    DeletePublicKeys?: string[];
    CustomLibraries?: DevEndpointCustomLibraries;
    UpdateEtlLibraries?: boolean;
    DeleteArguments?: string[];
    AddArguments?: {
        [key: string]: string | undefined;
    };
}
export declare const UpdateDevEndpointRequest: S.Schema<UpdateDevEndpointRequest>;
export interface UpdateDevEndpointResponse {
}
export declare const UpdateDevEndpointResponse: S.Schema<UpdateDevEndpointResponse>;
export interface UpdateGlossaryRequest {
    Identifier: string;
    Name?: string;
    Description?: string;
    ClientToken?: string;
}
export declare const UpdateGlossaryRequest: S.Schema<UpdateGlossaryRequest>;
export interface UpdateGlossaryResponse {
    Id?: string;
    Name?: string;
    Description?: string;
}
export declare const UpdateGlossaryResponse: S.Schema<UpdateGlossaryResponse>;
export interface UpdateGlossaryTermRequest {
    Identifier: string;
    Name?: string;
    ShortDescription?: string;
    LongDescription?: string;
    ClientToken?: string;
}
export declare const UpdateGlossaryTermRequest: S.Schema<UpdateGlossaryTermRequest>;
export interface UpdateGlossaryTermResponse {
    Id?: string;
    GlossaryId?: string;
    Name?: string;
    ShortDescription?: string;
    LongDescription?: string;
}
export declare const UpdateGlossaryTermResponse: S.Schema<UpdateGlossaryTermResponse>;
export interface UpdateGlueIdentityCenterConfigurationRequest {
    Scopes?: string[];
    UserBackgroundSessionsEnabled?: boolean;
}
export declare const UpdateGlueIdentityCenterConfigurationRequest: S.Schema<UpdateGlueIdentityCenterConfigurationRequest>;
export interface UpdateGlueIdentityCenterConfigurationResponse {
}
export declare const UpdateGlueIdentityCenterConfigurationResponse: S.Schema<UpdateGlueIdentityCenterConfigurationResponse>;
export interface UpdateIntegrationResourcePropertyRequest {
    ResourceArn: string;
    SourceProcessingProperties?: SourceProcessingProperties;
    TargetProcessingProperties?: TargetProcessingProperties;
}
export declare const UpdateIntegrationResourcePropertyRequest: S.Schema<UpdateIntegrationResourcePropertyRequest>;
export interface UpdateIntegrationResourcePropertyResponse {
    ResourceArn?: string;
    ResourcePropertyArn?: string;
    SourceProcessingProperties?: SourceProcessingProperties;
    TargetProcessingProperties?: TargetProcessingProperties;
}
export declare const UpdateIntegrationResourcePropertyResponse: S.Schema<UpdateIntegrationResourcePropertyResponse>;
export interface UpdateIntegrationTablePropertiesRequest {
    ResourceArn: string;
    TableName: string;
    SourceTableConfig?: SourceTableConfig;
    TargetTableConfig?: TargetTableConfig;
}
export declare const UpdateIntegrationTablePropertiesRequest: S.Schema<UpdateIntegrationTablePropertiesRequest>;
export interface UpdateIntegrationTablePropertiesResponse {
}
export declare const UpdateIntegrationTablePropertiesResponse: S.Schema<UpdateIntegrationTablePropertiesResponse>;
export interface JobUpdate {
    JobMode?: JobMode;
    JobRunQueuingEnabled?: boolean;
    Description?: string;
    LogUri?: string;
    Role?: string;
    ExecutionProperty?: ExecutionProperty;
    Command?: JobCommand;
    DefaultArguments?: {
        [key: string]: string | undefined;
    };
    NonOverridableArguments?: {
        [key: string]: string | undefined;
    };
    Connections?: ConnectionsList;
    MaxRetries?: number;
    AllocatedCapacity?: number;
    Timeout?: number;
    MaxCapacity?: number;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    SecurityConfiguration?: string;
    NotificationProperty?: NotificationProperty;
    GlueVersion?: string;
    CodeGenConfigurationNodes?: {
        [key: string]: CodeGenConfigurationNode | undefined;
    };
    ExecutionClass?: ExecutionClass;
    SourceControlDetails?: SourceControlDetails;
    MaintenanceWindow?: string;
}
export declare const JobUpdate: S.Schema<JobUpdate>;
export interface UpdateJobRequest {
    JobName: string;
    JobUpdate: JobUpdate;
}
export declare const UpdateJobRequest: S.Schema<UpdateJobRequest>;
export interface UpdateJobResponse {
    JobName?: string;
}
export declare const UpdateJobResponse: S.Schema<UpdateJobResponse>;
export type CommitIdString = string;
export type AuthTokenString = string;
export interface UpdateJobFromSourceControlRequest {
    JobName?: string;
    Provider?: SourceControlProvider;
    RepositoryName?: string;
    RepositoryOwner?: string;
    BranchName?: string;
    Folder?: string;
    CommitId?: string;
    AuthStrategy?: SourceControlAuthStrategy;
    AuthToken?: string;
}
export declare const UpdateJobFromSourceControlRequest: S.Schema<UpdateJobFromSourceControlRequest>;
export interface UpdateJobFromSourceControlResponse {
    JobName?: string;
}
export declare const UpdateJobFromSourceControlResponse: S.Schema<UpdateJobFromSourceControlResponse>;
export interface UpdateMLTransformRequest {
    TransformId: string;
    Name?: string;
    Description?: string;
    Parameters?: TransformParameters;
    Role?: string;
    GlueVersion?: string;
    MaxCapacity?: number;
    WorkerType?: WorkerType;
    NumberOfWorkers?: number;
    Timeout?: number;
    MaxRetries?: number;
}
export declare const UpdateMLTransformRequest: S.Schema<UpdateMLTransformRequest>;
export interface UpdateMLTransformResponse {
    TransformId?: string;
}
export declare const UpdateMLTransformResponse: S.Schema<UpdateMLTransformResponse>;
export interface UpdatePartitionRequest {
    CatalogId?: string;
    DatabaseName: string;
    TableName: string;
    PartitionValueList: string[];
    PartitionInput: PartitionInput;
}
export declare const UpdatePartitionRequest: S.Schema<UpdatePartitionRequest>;
export interface UpdatePartitionResponse {
}
export declare const UpdatePartitionResponse: S.Schema<UpdatePartitionResponse>;
export interface UpdateRegistryInput {
    RegistryId: RegistryId;
    Description: string;
}
export declare const UpdateRegistryInput: S.Schema<UpdateRegistryInput>;
export interface UpdateRegistryResponse {
    RegistryName?: string;
    RegistryArn?: string;
}
export declare const UpdateRegistryResponse: S.Schema<UpdateRegistryResponse>;
export interface UpdateSchemaInput {
    SchemaId: SchemaId;
    SchemaVersionNumber?: SchemaVersionNumber;
    Compatibility?: Compatibility;
    Description?: string;
}
export declare const UpdateSchemaInput: S.Schema<UpdateSchemaInput>;
export interface UpdateSchemaResponse {
    SchemaArn?: string;
    SchemaName?: string;
    RegistryName?: string;
}
export declare const UpdateSchemaResponse: S.Schema<UpdateSchemaResponse>;
export interface UpdateSourceControlFromJobRequest {
    JobName?: string;
    Provider?: SourceControlProvider;
    RepositoryName?: string;
    RepositoryOwner?: string;
    BranchName?: string;
    Folder?: string;
    CommitId?: string;
    AuthStrategy?: SourceControlAuthStrategy;
    AuthToken?: string;
}
export declare const UpdateSourceControlFromJobRequest: S.Schema<UpdateSourceControlFromJobRequest>;
export interface UpdateSourceControlFromJobResponse {
    JobName?: string;
}
export declare const UpdateSourceControlFromJobResponse: S.Schema<UpdateSourceControlFromJobResponse>;
export type ViewUpdateAction = "ADD" | "REPLACE" | "ADD_OR_REPLACE" | "DROP" | (string & {});
export declare const ViewUpdateAction: any;
export type IcebergUpdateAction = "add-schema" | "set-current-schema" | "add-spec" | "set-default-spec" | "add-sort-order" | "set-default-sort-order" | "set-location" | "set-properties" | "remove-properties" | "add-encryption-key" | "remove-encryption-key" | (string & {});
export declare const IcebergUpdateAction: any;
export type EncryptionKeyIdString = string;
export type EncryptedKeyMetadataString = string;
export interface IcebergEncryptedKey {
    KeyId: string;
    EncryptedKeyMetadata: string;
    EncryptedById?: string;
    Properties?: {
        [key: string]: string | undefined;
    };
}
export declare const IcebergEncryptedKey: S.Schema<IcebergEncryptedKey>;
export interface IcebergTableUpdate {
    Schema: IcebergSchema;
    PartitionSpec?: IcebergPartitionSpec;
    SortOrder?: IcebergSortOrder;
    Location: string;
    Properties?: {
        [key: string]: string | undefined;
    };
    Action?: IcebergUpdateAction;
    EncryptionKey?: IcebergEncryptedKey;
    KeyId?: string;
}
export declare const IcebergTableUpdate: S.Schema<IcebergTableUpdate>;
export type IcebergTableUpdateList = IcebergTableUpdate[];
export declare const IcebergTableUpdateList: any;
export interface UpdateIcebergTableInput {
    Updates: IcebergTableUpdate[];
}
export declare const UpdateIcebergTableInput: S.Schema<UpdateIcebergTableInput>;
export interface UpdateIcebergInput {
    UpdateIcebergTableInput: UpdateIcebergTableInput;
}
export declare const UpdateIcebergInput: S.Schema<UpdateIcebergInput>;
export interface UpdateOpenTableFormatInput {
    UpdateIcebergInput?: UpdateIcebergInput;
}
export declare const UpdateOpenTableFormatInput: S.Schema<UpdateOpenTableFormatInput>;
export interface UpdateTableRequest {
    CatalogId?: string;
    DatabaseName: string;
    Name?: string;
    TableInput?: TableInput;
    SkipArchive?: boolean;
    TransactionId?: string;
    VersionId?: string;
    ViewUpdateAction?: ViewUpdateAction;
    Force?: boolean;
    UpdateOpenTableFormatInput?: UpdateOpenTableFormatInput;
}
export declare const UpdateTableRequest: S.Schema<UpdateTableRequest>;
export interface UpdateTableResponse {
}
export declare const UpdateTableResponse: S.Schema<UpdateTableResponse>;
export interface UpdateTableOptimizerRequest {
    CatalogId: string;
    DatabaseName: string;
    TableName: string;
    Type: TableOptimizerType;
    TableOptimizerConfiguration: TableOptimizerConfiguration;
}
export declare const UpdateTableOptimizerRequest: S.Schema<UpdateTableOptimizerRequest>;
export interface UpdateTableOptimizerResponse {
}
export declare const UpdateTableOptimizerResponse: S.Schema<UpdateTableOptimizerResponse>;
export interface TriggerUpdate {
    Name?: string;
    Description?: string;
    Schedule?: string;
    Actions?: Action[];
    Predicate?: Predicate;
    EventBatchingCondition?: EventBatchingCondition;
}
export declare const TriggerUpdate: S.Schema<TriggerUpdate>;
export interface UpdateTriggerRequest {
    Name: string;
    TriggerUpdate: TriggerUpdate;
}
export declare const UpdateTriggerRequest: S.Schema<UpdateTriggerRequest>;
export interface UpdateTriggerResponse {
    Trigger?: Trigger;
}
export declare const UpdateTriggerResponse: S.Schema<UpdateTriggerResponse>;
export interface UpdateUsageProfileRequest {
    Name: string;
    Description?: string;
    Configuration: ProfileConfiguration;
}
export declare const UpdateUsageProfileRequest: S.Schema<UpdateUsageProfileRequest>;
export interface UpdateUsageProfileResponse {
    Name?: string;
}
export declare const UpdateUsageProfileResponse: S.Schema<UpdateUsageProfileResponse>;
export interface UpdateUserDefinedFunctionRequest {
    CatalogId?: string;
    DatabaseName: string;
    FunctionName: string;
    FunctionInput: UserDefinedFunctionInput;
}
export declare const UpdateUserDefinedFunctionRequest: S.Schema<UpdateUserDefinedFunctionRequest>;
export interface UpdateUserDefinedFunctionResponse {
}
export declare const UpdateUserDefinedFunctionResponse: S.Schema<UpdateUserDefinedFunctionResponse>;
export interface UpdateWorkflowRequest {
    Name: string;
    Description?: string;
    DefaultRunProperties?: {
        [key: string]: string | undefined;
    };
    MaxConcurrentRuns?: number;
}
export declare const UpdateWorkflowRequest: S.Schema<UpdateWorkflowRequest>;
export interface UpdateWorkflowResponse {
    Name?: string;
}
export declare const UpdateWorkflowResponse: S.Schema<UpdateWorkflowResponse>;
export type FederationSourceErrorCode = "AccessDeniedException" | "EntityNotFoundException" | "InvalidCredentialsException" | "InvalidInputException" | "InvalidResponseException" | "OperationTimeoutException" | "OperationNotSupportedException" | "InternalServiceException" | "PartialFailureException" | "ThrottlingException" | (string & {});
export declare const FederationSourceErrorCode: any;
export type IntegrationErrorMessage = string;
export type AssociateGlossaryTermsError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Associates one or more glossary terms with an asset in Glue Data Catalog.
 */
export declare const associateGlossaryTerms: API.OperationMethod<AssociateGlossaryTermsRequest, AssociateGlossaryTermsResponse, AssociateGlossaryTermsError, Credentials | HttpClient.HttpClient>;
export type BatchCreatePartitionError = AlreadyExistsException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates one or more partitions in a batch operation.
 */
export declare const batchCreatePartition: API.OperationMethod<BatchCreatePartitionRequest, BatchCreatePartitionResponse, BatchCreatePartitionError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteConnectionError = InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a list of connection definitions from the Data Catalog.
 */
export declare const batchDeleteConnection: API.OperationMethod<BatchDeleteConnectionRequest, BatchDeleteConnectionResponse, BatchDeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type BatchDeletePartitionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes one or more partitions in a batch operation.
 */
export declare const batchDeletePartition: API.OperationMethod<BatchDeletePartitionRequest, BatchDeletePartitionResponse, BatchDeletePartitionError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteTableError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Deletes multiple tables at once.
 *
 * After completing this operation, you no longer have access to the table versions and
 * partitions that belong to the deleted table. Glue deletes these "orphaned" resources
 * asynchronously in a timely manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources, before calling
 * `BatchDeleteTable`, use `DeleteTableVersion` or
 * `BatchDeleteTableVersion`, and `DeletePartition` or
 * `BatchDeletePartition`, to delete any resources that belong to the
 * table.
 */
export declare const batchDeleteTable: API.OperationMethod<BatchDeleteTableRequest, BatchDeleteTableResponse, BatchDeleteTableError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteTableVersionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified batch of versions of a table.
 */
export declare const batchDeleteTableVersion: API.OperationMethod<BatchDeleteTableVersionRequest, BatchDeleteTableVersionResponse, BatchDeleteTableVersionError, Credentials | HttpClient.HttpClient>;
export type BatchGetBlueprintsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about a list of blueprints.
 */
export declare const batchGetBlueprints: API.OperationMethod<BatchGetBlueprintsRequest, BatchGetBlueprintsResponse, BatchGetBlueprintsError, Credentials | HttpClient.HttpClient>;
export type BatchGetCrawlersError = InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of crawler names. After calling the `ListCrawlers` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetCrawlers: API.OperationMethod<BatchGetCrawlersRequest, BatchGetCrawlersResponse, BatchGetCrawlersError, Credentials | HttpClient.HttpClient>;
export type BatchGetCustomEntityTypesError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details for the custom patterns specified by a list of names.
 */
export declare const batchGetCustomEntityTypes: API.OperationMethod<BatchGetCustomEntityTypesRequest, BatchGetCustomEntityTypesResponse, BatchGetCustomEntityTypesError, Credentials | HttpClient.HttpClient>;
export type BatchGetDataQualityResultError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of data quality results for the specified result IDs.
 */
export declare const batchGetDataQualityResult: API.OperationMethod<BatchGetDataQualityResultRequest, BatchGetDataQualityResultResponse, BatchGetDataQualityResultError, Credentials | HttpClient.HttpClient>;
export type BatchGetDataQualityRulesetEvaluationRunError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of multiple evaluation runs in a single request.
 */
export declare const batchGetDataQualityRulesetEvaluationRun: API.OperationMethod<BatchGetDataQualityRulesetEvaluationRunRequest, BatchGetDataQualityRulesetEvaluationRunResponse, BatchGetDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type BatchGetDevEndpointsError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of development endpoint names. After
 * calling the `ListDevEndpoints` operation, you can call this operation to access the
 * data to which you have been granted permissions. This operation supports all IAM permissions,
 * including permission conditions that uses tags.
 */
export declare const batchGetDevEndpoints: API.OperationMethod<BatchGetDevEndpointsRequest, BatchGetDevEndpointsResponse, BatchGetDevEndpointsError, Credentials | HttpClient.HttpClient>;
export type BatchGetIterableFormsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves multiple items from an iterable form on an asset in Glue Data Catalog in a single request.
 */
export declare const batchGetIterableForms: API.OperationMethod<BatchGetIterableFormsRequest, BatchGetIterableFormsResponse, BatchGetIterableFormsError, Credentials | HttpClient.HttpClient>;
export type BatchGetJobsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of job names. After calling the `ListJobs` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetJobs: API.OperationMethod<BatchGetJobsRequest, BatchGetJobsResponse, BatchGetJobsError, Credentials | HttpClient.HttpClient>;
export type BatchGetPartitionError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | InvalidStateException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves partitions in a batch request.
 */
export declare const batchGetPartition: API.OperationMethod<BatchGetPartitionRequest, BatchGetPartitionResponse, BatchGetPartitionError, Credentials | HttpClient.HttpClient>;
export type BatchGetTableOptimizerError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Returns the configuration for the specified table optimizers.
 */
export declare const batchGetTableOptimizer: API.OperationMethod<BatchGetTableOptimizerRequest, BatchGetTableOptimizerResponse, BatchGetTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type BatchGetTriggersError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of trigger names. After calling the `ListTriggers` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetTriggers: API.OperationMethod<BatchGetTriggersRequest, BatchGetTriggersResponse, BatchGetTriggersError, Credentials | HttpClient.HttpClient>;
export type BatchGetWorkflowsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a list of resource metadata for a given list of workflow names. After calling the `ListWorkflows` operation, you can call this operation to access the data to which you have been granted permissions. This operation supports all IAM permissions, including permission conditions that uses tags.
 */
export declare const batchGetWorkflows: API.OperationMethod<BatchGetWorkflowsRequest, BatchGetWorkflowsResponse, BatchGetWorkflowsError, Credentials | HttpClient.HttpClient>;
export type BatchPutDataQualityStatisticAnnotationError = EntityNotFoundException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Annotate datapoints over time for a specific data quality statistic.
 * The API requires both profileID and statisticID as part of the InclusionAnnotation input.
 * The API only works for a single statisticId across multiple profiles.
 */
export declare const batchPutDataQualityStatisticAnnotation: API.OperationMethod<BatchPutDataQualityStatisticAnnotationRequest, BatchPutDataQualityStatisticAnnotationResponse, BatchPutDataQualityStatisticAnnotationError, Credentials | HttpClient.HttpClient>;
export type BatchStopJobRunError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops one or more job runs for a specified job definition.
 */
export declare const batchStopJobRun: API.OperationMethod<BatchStopJobRunRequest, BatchStopJobRunResponse, BatchStopJobRunError, Credentials | HttpClient.HttpClient>;
export type BatchUpdatePartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates one or more partitions in a batch operation.
 */
export declare const batchUpdatePartition: API.OperationMethod<BatchUpdatePartitionRequest, BatchUpdatePartitionResponse, BatchUpdatePartitionError, Credentials | HttpClient.HttpClient>;
export type CancelDataQualityRuleRecommendationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels the specified recommendation run that was being used to generate rules.
 */
export declare const cancelDataQualityRuleRecommendationRun: API.OperationMethod<CancelDataQualityRuleRecommendationRunRequest, CancelDataQualityRuleRecommendationRunResponse, CancelDataQualityRuleRecommendationRunError, Credentials | HttpClient.HttpClient>;
export type CancelDataQualityRulesetEvaluationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels a run where a ruleset is being evaluated against a data source.
 */
export declare const cancelDataQualityRulesetEvaluationRun: API.OperationMethod<CancelDataQualityRulesetEvaluationRunRequest, CancelDataQualityRulesetEvaluationRunResponse, CancelDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type CancelMLTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels (stops) a task run. Machine learning task runs are asynchronous tasks that Glue runs on your behalf as part of various machine learning workflows. You can cancel a
 * machine learning task run at any time by calling `CancelMLTaskRun` with a task
 * run's parent transform's `TransformID` and the task run's `TaskRunId`.
 */
export declare const cancelMLTaskRun: API.OperationMethod<CancelMLTaskRunRequest, CancelMLTaskRunResponse, CancelMLTaskRunError, Credentials | HttpClient.HttpClient>;
export type CancelStatementError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Cancels the statement.
 */
export declare const cancelStatement: API.OperationMethod<CancelStatementRequest, CancelStatementResponse, CancelStatementError, Credentials | HttpClient.HttpClient>;
export type CheckSchemaVersionValidityError = AccessDeniedException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Validates the supplied schema. This call has no side effects, it simply validates using the supplied schema using `DataFormat` as the format. Since it does not take a schema set name, no compatibility checks are performed.
 */
export declare const checkSchemaVersionValidity: API.OperationMethod<CheckSchemaVersionValidityInput, CheckSchemaVersionValidityResponse, CheckSchemaVersionValidityError, Credentials | HttpClient.HttpClient>;
export type CreateBlueprintError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Registers a blueprint with Glue.
 */
export declare const createBlueprint: API.OperationMethod<CreateBlueprintRequest, CreateBlueprintResponse, CreateBlueprintError, Credentials | HttpClient.HttpClient>;
export type CreateCatalogError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederatedResourceAlreadyExistsException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new catalog in the Glue Data Catalog.
 */
export declare const createCatalog: API.OperationMethod<CreateCatalogRequest, CreateCatalogResponse, CreateCatalogError, Credentials | HttpClient.HttpClient>;
export type CreateClassifierError = AlreadyExistsException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates a classifier in the user's account. This can be a `GrokClassifier`, an
 * `XMLClassifier`, a `JsonClassifier`, or a `CsvClassifier`,
 * depending on which field of the request is present.
 */
export declare const createClassifier: API.OperationMethod<CreateClassifierRequest, CreateClassifierResponse, CreateClassifierError, Credentials | HttpClient.HttpClient>;
export type CreateColumnStatisticsTaskSettingsError = AccessDeniedException | AlreadyExistsException | ColumnStatisticsTaskRunningException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates settings for a column statistics task.
 */
export declare const createColumnStatisticsTaskSettings: API.OperationMethod<CreateColumnStatisticsTaskSettingsRequest, CreateColumnStatisticsTaskSettingsResponse, CreateColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = AlreadyExistsException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a connection definition in the Data Catalog.
 *
 * Connections used for creating federated resources require the IAM `glue:PassConnection` permission.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateCrawlerError = AlreadyExistsException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | GlueRoleNotAssumable | GlueS3TargetNotReady | CommonErrors;
/**
 * Creates a new crawler with specified targets, role, configuration, and optional schedule.
 * At least one crawl target must be specified, in the `s3Targets` field, the
 * `jdbcTargets` field, or the `DynamoDBTargets` field.
 */
export declare const createCrawler: API.OperationMethod<CreateCrawlerRequest, CreateCrawlerResponse, CreateCrawlerError, Credentials | HttpClient.HttpClient>;
export type CreateCustomEntityTypeError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a custom pattern that is used to detect sensitive data across the columns and rows of your structured data.
 *
 * Each custom pattern you create specifies a regular expression and an optional list of context words. If no context words are passed only a regular expression is checked.
 */
export declare const createCustomEntityType: API.OperationMethod<CreateCustomEntityTypeRequest, CreateCustomEntityTypeResponse, CreateCustomEntityTypeError, Credentials | HttpClient.HttpClient>;
export type CreateDatabaseError = AlreadyExistsException | ConcurrentModificationException | FederatedResourceAlreadyExistsException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new database in a Data Catalog.
 */
export declare const createDatabase: API.OperationMethod<CreateDatabaseRequest, CreateDatabaseResponse, CreateDatabaseError, Credentials | HttpClient.HttpClient>;
export type CreateDataQualityRulesetError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a data quality ruleset with DQDL rules applied to a specified Glue table.
 *
 * You create the ruleset using the Data Quality Definition Language (DQDL). For more information, see the Glue developer guide.
 */
export declare const createDataQualityRuleset: API.OperationMethod<CreateDataQualityRulesetRequest, CreateDataQualityRulesetResponse, CreateDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type CreateDevEndpointError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a new development endpoint.
 */
export declare const createDevEndpoint: API.OperationMethod<CreateDevEndpointRequest, CreateDevEndpointResponse, CreateDevEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates a business glossary in Glue Data Catalog. A glossary is a container for glossary terms that define business concepts.
 */
export declare const createGlossary: API.OperationMethod<CreateGlossaryRequest, CreateGlossaryResponse, CreateGlossaryError, Credentials | HttpClient.HttpClient>;
export type CreateGlossaryTermError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates a glossary term within a business glossary in Glue Data Catalog.
 */
export declare const createGlossaryTerm: API.OperationMethod<CreateGlossaryTermRequest, CreateGlossaryTermResponse, CreateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type CreateGlueIdentityCenterConfigurationError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates a new Glue Identity Center configuration to enable integration between Glue and Amazon Web Services IAM
 * Identity Center for authentication and authorization.
 */
export declare const createGlueIdentityCenterConfiguration: API.OperationMethod<CreateGlueIdentityCenterConfigurationRequest, CreateGlueIdentityCenterConfigurationResponse, CreateGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = AccessDeniedException | ConflictException | EntityNotFoundException | IntegrationConflictOperationFault | IntegrationQuotaExceededFault | InternalServerException | InternalServiceException | InvalidInputException | KMSKeyNotAccessibleFault | ResourceNotFoundException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a Zero-ETL integration in the caller's account between two resources with Amazon Resource Names (ARNs): the `SourceArn` and `TargetArn`.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationRequest, CreateIntegrationResponse, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationResourcePropertyError = AccessDeniedException | ConflictException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API can be used for setting up the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target). These properties can include the role to access the connection or database. To set both source and target properties the same API needs to be invoked with the Glue connection ARN as `ResourceArn` with `SourceProcessingProperties` and the Glue database ARN as `ResourceArn` with `TargetProcessingProperties` respectively.
 */
export declare const createIntegrationResourceProperty: API.OperationMethod<CreateIntegrationResourcePropertyRequest, CreateIntegrationResourcePropertyResponse, CreateIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used to provide optional override properties for the the tables that need to be replicated. These properties can include properties for filtering and partitioning for the source and target tables. To set both source and target properties the same API need to be invoked with the Glue connection ARN as `ResourceArn` with `SourceTableConfig`, and the Glue database ARN as `ResourceArn` with `TargetTableConfig` respectively.
 */
export declare const createIntegrationTableProperties: API.OperationMethod<CreateIntegrationTablePropertiesRequest, CreateIntegrationTablePropertiesResponse, CreateIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = AlreadyExistsException | ConcurrentModificationException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | GlueRoleNotAssumable | CommonErrors;
/**
 * Creates a new job definition.
 */
export declare const createJob: API.OperationMethod<CreateJobRequest, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateMLTransformError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates an Glue machine learning transform. This operation creates the transform and
 * all the necessary parameters to train it.
 *
 * Call this operation as the first step in the process of using a machine learning transform
 * (such as the `FindMatches` transform) for deduplicating data. You can provide an
 * optional `Description`, in addition to the parameters that you want to use for your
 * algorithm.
 *
 * You must also specify certain parameters for the tasks that Glue runs on your
 * behalf as part of learning from your data and creating a high-quality machine learning
 * transform. These parameters include `Role`, and optionally,
 * `AllocatedCapacity`, `Timeout`, and `MaxRetries`. For more
 * information, see Jobs.
 */
export declare const createMLTransform: API.OperationMethod<CreateMLTransformRequest, CreateMLTransformResponse, CreateMLTransformError, Credentials | HttpClient.HttpClient>;
export type CreatePartitionError = AlreadyExistsException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new partition.
 */
export declare const createPartition: API.OperationMethod<CreatePartitionRequest, CreatePartitionResponse, CreatePartitionError, Credentials | HttpClient.HttpClient>;
export type CreatePartitionIndexError = AlreadyExistsException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a specified partition index in an existing table.
 */
export declare const createPartitionIndex: API.OperationMethod<CreatePartitionIndexRequest, CreatePartitionIndexResponse, CreatePartitionIndexError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new registry which may be used to hold a collection of schemas.
 */
export declare const createRegistry: API.OperationMethod<CreateRegistryInput, CreateRegistryResponse, CreateRegistryError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new schema set and registers the schema definition. Returns an error if the schema set already exists without actually registering the version.
 *
 * When the schema set is created, a version checkpoint will be set to the first version. Compatibility mode "DISABLED" restricts any additional schema versions from being added after the first schema version. For all other compatibility modes, validation of compatibility settings will be applied only from the second version onwards when the `RegisterSchemaVersion` API is used.
 *
 * When this API is called without a `RegistryId`, this will create an entry for a "default-registry" in the registry database tables, if it is not already present.
 */
export declare const createSchema: API.OperationMethod<CreateSchemaInput, CreateSchemaResponse, CreateSchemaError, Credentials | HttpClient.HttpClient>;
export type CreateScriptError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Transforms a directed acyclic graph (DAG) into code.
 */
export declare const createScript: API.OperationMethod<CreateScriptRequest, CreateScriptResponse, CreateScriptError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityConfigurationError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new security configuration. A security configuration is a set of security properties that can be used by Glue. You can use a security configuration to encrypt data at rest. For information about using security configurations in Glue, see Encrypting Data Written by Crawlers, Jobs, and Development Endpoints.
 */
export declare const createSecurityConfiguration: API.OperationMethod<CreateSecurityConfigurationRequest, CreateSecurityConfigurationResponse, CreateSecurityConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateSessionError = AccessDeniedException | AlreadyExistsException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Creates a new session.
 */
export declare const createSession: API.OperationMethod<CreateSessionRequest, CreateSessionResponse, CreateSessionError, Credentials | HttpClient.HttpClient>;
export type CreateTableError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new table definition in the Data Catalog.
 */
export declare const createTable: API.OperationMethod<CreateTableRequest, CreateTableResponse, CreateTableError, Credentials | HttpClient.HttpClient>;
export type CreateTableOptimizerError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new table optimizer for a specific function.
 */
export declare const createTableOptimizer: API.OperationMethod<CreateTableOptimizerRequest, CreateTableOptimizerResponse, CreateTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type CreateTriggerError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new trigger.
 *
 * Job arguments may be logged. Do not pass plaintext secrets as arguments. Retrieve secrets from a Glue Connection, Amazon Web Services Secrets Manager or other secret management mechanism if you intend to keep them within the Job.
 */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest, CreateTriggerResponse, CreateTriggerError, Credentials | HttpClient.HttpClient>;
export type CreateUsageProfileError = AlreadyExistsException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates an Glue usage profile.
 */
export declare const createUsageProfile: API.OperationMethod<CreateUsageProfileRequest, CreateUsageProfileResponse, CreateUsageProfileError, Credentials | HttpClient.HttpClient>;
export type CreateUserDefinedFunctionError = AlreadyExistsException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new function definition in the Data Catalog.
 */
export declare const createUserDefinedFunction: API.OperationMethod<CreateUserDefinedFunctionRequest, CreateUserDefinedFunctionResponse, CreateUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = AlreadyExistsException | ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Creates a new workflow.
 */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest, CreateWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset from Glue Data Catalog.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetTypeError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes an asset type from Glue Data Catalog.
 */
export declare const deleteAssetType: API.OperationMethod<DeleteAssetTypeRequest, DeleteAssetTypeResponse, DeleteAssetTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteAttachmentError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a form attachment from an asset in Glue Data Catalog.
 */
export declare const deleteAttachment: API.OperationMethod<DeleteAttachmentRequest, DeleteAttachmentResponse, DeleteAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteBlueprintError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an existing blueprint.
 */
export declare const deleteBlueprint: API.OperationMethod<DeleteBlueprintRequest, DeleteBlueprintResponse, DeleteBlueprintError, Credentials | HttpClient.HttpClient>;
export type DeleteCatalogError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Removes the specified catalog from the Glue Data Catalog.
 *
 * After completing this operation, you no longer have access to the databases, tables (and all table versions and partitions that might belong to the tables) and the user-defined functions in the deleted catalog. Glue deletes these "orphaned" resources asynchronously in a timely manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources before calling the `DeleteCatalog` operation, use `DeleteTableVersion` (or `BatchDeleteTableVersion`), `DeletePartition` (or `BatchDeletePartition`), `DeleteTable` (or `BatchDeleteTable`), `DeleteUserDefinedFunction` and `DeleteDatabase` to delete any resources that belong to the catalog.
 */
export declare const deleteCatalog: API.OperationMethod<DeleteCatalogRequest, DeleteCatalogResponse, DeleteCatalogError, Credentials | HttpClient.HttpClient>;
export type DeleteClassifierError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Removes a classifier from the Data Catalog.
 */
export declare const deleteClassifier: API.OperationMethod<DeleteClassifierRequest, DeleteClassifierResponse, DeleteClassifierError, Credentials | HttpClient.HttpClient>;
export type DeleteColumnStatisticsForPartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Delete the partition column statistics of a column.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `DeletePartition`.
 */
export declare const deleteColumnStatisticsForPartition: API.OperationMethod<DeleteColumnStatisticsForPartitionRequest, DeleteColumnStatisticsForPartitionResponse, DeleteColumnStatisticsForPartitionError, Credentials | HttpClient.HttpClient>;
export type DeleteColumnStatisticsForTableError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves table statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `DeleteTable`.
 */
export declare const deleteColumnStatisticsForTable: API.OperationMethod<DeleteColumnStatisticsForTableRequest, DeleteColumnStatisticsForTableResponse, DeleteColumnStatisticsForTableError, Credentials | HttpClient.HttpClient>;
export type DeleteColumnStatisticsTaskSettingsError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes settings for a column statistics task.
 */
export declare const deleteColumnStatisticsTaskSettings: API.OperationMethod<DeleteColumnStatisticsTaskSettingsRequest, DeleteColumnStatisticsTaskSettingsResponse, DeleteColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a connection from the Data Catalog.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Deletes a custom connection type in Glue.
 *
 * The connection type must exist and be registered before it can be deleted. This operation supports cleanup of connection type resources and helps maintain proper lifecycle management of custom connection types.
 */
export declare const deleteConnectionType: API.OperationMethod<DeleteConnectionTypeRequest, DeleteConnectionTypeResponse, DeleteConnectionTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteCrawlerError = CrawlerRunningException | EntityNotFoundException | OperationTimeoutException | SchedulerTransitioningException | CommonErrors;
/**
 * Removes a specified crawler from the Glue Data Catalog, unless the crawler state is
 * `RUNNING`.
 */
export declare const deleteCrawler: API.OperationMethod<DeleteCrawlerRequest, DeleteCrawlerResponse, DeleteCrawlerError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomEntityTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a custom pattern by specifying its name.
 */
export declare const deleteCustomEntityType: API.OperationMethod<DeleteCustomEntityTypeRequest, DeleteCustomEntityTypeResponse, DeleteCustomEntityTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteDatabaseError = ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Removes a specified database from a Data Catalog.
 *
 * After completing this operation, you no longer have access to the tables (and all table
 * versions and partitions that might belong to the tables) and the user-defined functions in
 * the deleted database. Glue deletes these "orphaned" resources asynchronously in a timely
 * manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources, before calling
 * `DeleteDatabase`, use `DeleteTableVersion` or
 * `BatchDeleteTableVersion`, `DeletePartition` or
 * `BatchDeletePartition`, `DeleteUserDefinedFunction`, and
 * `DeleteTable` or `BatchDeleteTable`, to delete any resources that
 * belong to the database.
 */
export declare const deleteDatabase: API.OperationMethod<DeleteDatabaseRequest, DeleteDatabaseResponse, DeleteDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteDataQualityRulesetError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a data quality ruleset.
 */
export declare const deleteDataQualityRuleset: API.OperationMethod<DeleteDataQualityRulesetRequest, DeleteDataQualityRulesetResponse, DeleteDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type DeleteDevEndpointError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified development endpoint.
 */
export declare const deleteDevEndpoint: API.OperationMethod<DeleteDevEndpointRequest, DeleteDevEndpointResponse, DeleteDevEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteFormTypeError = AccessDeniedException | ConcurrentModificationException | ConflictException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a form type from Glue Data Catalog. A form type cannot be deleted if it is still referenced by an asset type.
 */
export declare const deleteFormType: API.OperationMethod<DeleteFormTypeRequest, DeleteFormTypeResponse, DeleteFormTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryError = AccessDeniedException | ConcurrentModificationException | ConflictException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a business glossary from Glue Data Catalog. A glossary cannot be deleted if it still contains glossary terms.
 */
export declare const deleteGlossary: API.OperationMethod<DeleteGlossaryRequest, DeleteGlossaryResponse, DeleteGlossaryError, Credentials | HttpClient.HttpClient>;
export type DeleteGlossaryTermError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes a glossary term from Glue Data Catalog.
 */
export declare const deleteGlossaryTerm: API.OperationMethod<DeleteGlossaryTermRequest, DeleteGlossaryTermResponse, DeleteGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type DeleteGlueIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes the existing Glue Identity Center configuration, removing the integration between Glue and
 * Amazon Web Services IAM Identity Center.
 */
export declare const deleteGlueIdentityCenterConfiguration: API.OperationMethod<DeleteGlueIdentityCenterConfigurationRequest, DeleteGlueIdentityCenterConfigurationResponse, DeleteGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = AccessDeniedException | ConflictException | EntityNotFoundException | IntegrationConflictOperationFault | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | InvalidIntegrationStateFault | InvalidStateException | ValidationException | CommonErrors;
/**
 * Deletes the specified Zero-ETL integration.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationResourcePropertyError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used for deleting the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target).
 */
export declare const deleteIntegrationResourceProperty: API.OperationMethod<DeleteIntegrationResourcePropertyRequest, DeleteIntegrationResourcePropertyResponse, DeleteIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the table properties that have been created for the tables that need to be replicated.
 */
export declare const deleteIntegrationTableProperties: API.OperationMethod<DeleteIntegrationTablePropertiesRequest, DeleteIntegrationTablePropertiesResponse, DeleteIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified job definition. If the job definition
 * is not found, no exception is thrown.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest, DeleteJobResponse, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteMLTransformError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an Glue machine learning transform. Machine learning transforms are a special
 * type of transform that use machine learning to learn the details of the transformation to be
 * performed by learning from examples provided by humans. These transformations are then saved
 * by Glue. If you no longer need a transform, you can delete it by calling
 * `DeleteMLTransforms`. However, any Glue jobs that still reference the deleted
 * transform will no longer succeed.
 */
export declare const deleteMLTransform: API.OperationMethod<DeleteMLTransformRequest, DeleteMLTransformResponse, DeleteMLTransformError, Credentials | HttpClient.HttpClient>;
export type DeletePartitionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified partition.
 */
export declare const deletePartition: API.OperationMethod<DeletePartitionRequest, DeletePartitionResponse, DeletePartitionError, Credentials | HttpClient.HttpClient>;
export type DeletePartitionIndexError = ConflictException | EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified partition index from an existing table.
 */
export declare const deletePartitionIndex: API.OperationMethod<DeletePartitionIndexRequest, DeletePartitionIndexResponse, DeletePartitionIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Delete the entire registry including schema and all of its versions. To get the status of the delete operation, you can call the `GetRegistry` API after the asynchronous call. Deleting a registry will deactivate all online operations for the registry such as the `UpdateRegistry`, `CreateSchema`, `UpdateSchema`, and `RegisterSchemaVersion` APIs.
 */
export declare const deleteRegistry: API.OperationMethod<DeleteRegistryInput, DeleteRegistryResponse, DeleteRegistryError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = ConditionCheckFailureException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Deletes the entire schema set, including the schema set and all of its versions. To get the status of the delete operation, you can call `GetSchema` API after the asynchronous call. Deleting a registry will deactivate all online operations for the schema, such as the `GetSchemaByDefinition`, and `RegisterSchemaVersion` APIs.
 */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaInput, DeleteSchemaResponse, DeleteSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaVersionsError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Remove versions from the specified schema. A version number or range may be supplied. If the compatibility mode forbids deleting of a version that is necessary, such as BACKWARDS_FULL, an error is returned. Calling the `GetSchemaVersions` API after this call will list the status of the deleted versions.
 *
 * When the range of version numbers contain check pointed version, the API will return a 409 conflict and will not proceed with the deletion. You have to remove the checkpoint first using the `DeleteSchemaCheckpoint` API before using this API.
 *
 * You cannot use the `DeleteSchemaVersions` API to delete the first schema version in the schema set. The first schema version can only be deleted by the `DeleteSchema` API. This operation will also delete the attached `SchemaVersionMetadata` under the schema versions. Hard deletes will be enforced on the database.
 *
 * If the compatibility mode forbids deleting of a version that is necessary, such as BACKWARDS_FULL, an error is returned.
 */
export declare const deleteSchemaVersions: API.OperationMethod<DeleteSchemaVersionsInput, DeleteSchemaVersionsResponse, DeleteSchemaVersionsError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityConfigurationError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified security configuration.
 */
export declare const deleteSecurityConfiguration: API.OperationMethod<DeleteSecurityConfigurationRequest, DeleteSecurityConfigurationResponse, DeleteSecurityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteSessionError = AccessDeniedException | ConcurrentModificationException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes the session.
 */
export declare const deleteSession: API.OperationMethod<DeleteSessionRequest, DeleteSessionResponse, DeleteSessionError, Credentials | HttpClient.HttpClient>;
export type DeleteTableError = ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Removes a table definition from the Data Catalog.
 *
 * After completing this operation, you no longer have access to the table versions and
 * partitions that belong to the deleted table. Glue deletes these "orphaned" resources
 * asynchronously in a timely manner, at the discretion of the service.
 *
 * To ensure the immediate deletion of all related resources, before calling
 * `DeleteTable`, use `DeleteTableVersion` or
 * `BatchDeleteTableVersion`, and `DeletePartition` or
 * `BatchDeletePartition`, to delete any resources that belong to the
 * table.
 */
export declare const deleteTable: API.OperationMethod<DeleteTableRequest, DeleteTableResponse, DeleteTableError, Credentials | HttpClient.HttpClient>;
export type DeleteTableOptimizerError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Deletes an optimizer and all associated metadata for a table. The optimization will no longer be performed on the table.
 */
export declare const deleteTableOptimizer: API.OperationMethod<DeleteTableOptimizerRequest, DeleteTableOptimizerResponse, DeleteTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type DeleteTableVersionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified version of a table.
 */
export declare const deleteTableVersion: API.OperationMethod<DeleteTableVersionRequest, DeleteTableVersionResponse, DeleteTableVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteTriggerError = ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a specified trigger. If the trigger is not found, no
 * exception is thrown.
 */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest, DeleteTriggerResponse, DeleteTriggerError, Credentials | HttpClient.HttpClient>;
export type DeleteUsageProfileError = InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Deletes the Glue specified usage profile.
 */
export declare const deleteUsageProfile: API.OperationMethod<DeleteUsageProfileRequest, DeleteUsageProfileResponse, DeleteUsageProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteUserDefinedFunctionError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes an existing function definition from the Data Catalog.
 */
export declare const deleteUserDefinedFunction: API.OperationMethod<DeleteUserDefinedFunctionRequest, DeleteUserDefinedFunctionResponse, DeleteUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = ConcurrentModificationException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Deletes a workflow.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionTypeError = AccessDeniedException | InternalServiceException | InvalidInputException | ValidationException | CommonErrors;
/**
 * The `DescribeConnectionType` API provides full details of the supported options for a given connection type in Glue. The response includes authentication configuration details that show supported authentication types and properties, and RestConfiguration for custom REST-based connection types registered via `RegisterConnectionType`.
 *
 * See also: `ListConnectionTypes`, `RegisterConnectionType`, `DeleteConnectionType`
 */
export declare const describeConnectionType: API.OperationMethod<DescribeConnectionTypeRequest, DescribeConnectionTypeResponse, DescribeConnectionTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeEntityError = AccessDeniedException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Provides details regarding the entity used with the connection type, with a description of the data model for each field in the selected entity.
 *
 * The response includes all the fields which make up the entity.
 */
export declare const describeEntity: API.PaginatedOperationMethod<DescribeEntityRequest, DescribeEntityResponse, DescribeEntityError, Credentials | HttpClient.HttpClient, Field>;
export type DescribeInboundIntegrationsError = AccessDeniedException | EntityNotFoundException | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | OperationNotSupportedException | TargetResourceNotFound | ValidationException | CommonErrors;
/**
 * Returns a list of inbound integrations for the specified integration.
 */
export declare const describeInboundIntegrations: API.OperationMethod<DescribeInboundIntegrationsRequest, DescribeInboundIntegrationsResponse, DescribeInboundIntegrationsError, Credentials | HttpClient.HttpClient>;
export type DescribeIntegrationsError = AccessDeniedException | EntityNotFoundException | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | ValidationException | CommonErrors;
/**
 * The API is used to retrieve a list of integrations.
 */
export declare const describeIntegrations: API.OperationMethod<DescribeIntegrationsRequest, DescribeIntegrationsResponse, DescribeIntegrationsError, Credentials | HttpClient.HttpClient>;
export type DisassociateGlossaryTermsError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Removes the association of one or more glossary terms from an asset in Glue Data Catalog.
 */
export declare const disassociateGlossaryTerms: API.OperationMethod<DisassociateGlossaryTermsRequest, DisassociateGlossaryTermsResponse, DisassociateGlossaryTermsError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata for an asset in Glue Data Catalog, including its forms, additional attachments, and associated glossary terms.
 */
export declare const getAsset: API.OperationMethod<GetAssetInput, GetAssetOutput, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetAssetTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves an asset type in Glue Data Catalog by its identifier.
 */
export declare const getAssetType: API.OperationMethod<GetAssetTypeRequest, GetAssetTypeResponse, GetAssetTypeError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of a blueprint.
 */
export declare const getBlueprint: API.OperationMethod<GetBlueprintRequest, GetBlueprintResponse, GetBlueprintError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintRunError = EntityNotFoundException | InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of a blueprint run.
 */
export declare const getBlueprintRun: API.OperationMethod<GetBlueprintRunRequest, GetBlueprintRunResponse, GetBlueprintRunError, Credentials | HttpClient.HttpClient>;
export type GetBlueprintRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of blueprint runs for a specified blueprint.
 */
export declare const getBlueprintRuns: API.PaginatedOperationMethod<GetBlueprintRunsRequest, GetBlueprintRunsResponse, GetBlueprintRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCatalogError = AccessDeniedException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * The name of the Catalog to retrieve. This should be all lowercase.
 */
export declare const getCatalog: API.OperationMethod<GetCatalogRequest, GetCatalogResponse, GetCatalogError, Credentials | HttpClient.HttpClient>;
export type GetCatalogImportStatusError = InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the status of a migration operation.
 */
export declare const getCatalogImportStatus: API.OperationMethod<GetCatalogImportStatusRequest, GetCatalogImportStatusResponse, GetCatalogImportStatusError, Credentials | HttpClient.HttpClient>;
export type GetCatalogsError = AccessDeniedException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all catalogs defined in a catalog in the Glue Data Catalog. For a Redshift-federated catalog use case, this operation returns the list of catalogs mapped to Redshift databases in the Redshift namespace catalog.
 */
export declare const getCatalogs: API.OperationMethod<GetCatalogsRequest, GetCatalogsResponse, GetCatalogsError, Credentials | HttpClient.HttpClient>;
export type GetClassifierError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve a classifier by name.
 */
export declare const getClassifier: API.OperationMethod<GetClassifierRequest, GetClassifierResponse, GetClassifierError, Credentials | HttpClient.HttpClient>;
export type GetClassifiersError = OperationTimeoutException | CommonErrors;
/**
 * Lists all classifier objects in the Data Catalog.
 */
export declare const getClassifiers: API.PaginatedOperationMethod<GetClassifiersRequest, GetClassifiersResponse, GetClassifiersError, Credentials | HttpClient.HttpClient, unknown>;
export type GetColumnStatisticsForPartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves partition statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `GetPartition`.
 */
export declare const getColumnStatisticsForPartition: API.OperationMethod<GetColumnStatisticsForPartitionRequest, GetColumnStatisticsForPartitionResponse, GetColumnStatisticsForPartitionError, Credentials | HttpClient.HttpClient>;
export type GetColumnStatisticsForTableError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves table statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `GetTable`.
 */
export declare const getColumnStatisticsForTable: API.OperationMethod<GetColumnStatisticsForTableRequest, GetColumnStatisticsForTableResponse, GetColumnStatisticsForTableError, Credentials | HttpClient.HttpClient>;
export type GetColumnStatisticsTaskRunError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Get the associated metadata/information for a task run, given a task run ID.
 */
export declare const getColumnStatisticsTaskRun: API.OperationMethod<GetColumnStatisticsTaskRunRequest, GetColumnStatisticsTaskRunResponse, GetColumnStatisticsTaskRunError, Credentials | HttpClient.HttpClient>;
export type GetColumnStatisticsTaskRunsError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about all runs associated with the specified table.
 */
export declare const getColumnStatisticsTaskRuns: API.PaginatedOperationMethod<GetColumnStatisticsTaskRunsRequest, GetColumnStatisticsTaskRunsResponse, GetColumnStatisticsTaskRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetColumnStatisticsTaskSettingsError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets settings for a column statistics task.
 */
export declare const getColumnStatisticsTaskSettings: API.OperationMethod<GetColumnStatisticsTaskSettingsRequest, GetColumnStatisticsTaskSettingsResponse, GetColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = EntityNotFoundException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a connection definition from the Data Catalog.
 */
export declare const getConnection: API.OperationMethod<GetConnectionRequest, GetConnectionResponse, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type GetConnectionsError = EntityNotFoundException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of connection definitions from the Data Catalog.
 */
export declare const getConnections: API.PaginatedOperationMethod<GetConnectionsRequest, GetConnectionsResponse, GetConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCrawlerError = EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for a specified crawler.
 */
export declare const getCrawler: API.OperationMethod<GetCrawlerRequest, GetCrawlerResponse, GetCrawlerError, Credentials | HttpClient.HttpClient>;
export type GetCrawlerMetricsError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves metrics about specified crawlers.
 */
export declare const getCrawlerMetrics: API.PaginatedOperationMethod<GetCrawlerMetricsRequest, GetCrawlerMetricsResponse, GetCrawlerMetricsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCrawlersError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for all crawlers defined in the customer
 * account.
 */
export declare const getCrawlers: API.PaginatedOperationMethod<GetCrawlersRequest, GetCrawlersResponse, GetCrawlersError, Credentials | HttpClient.HttpClient, unknown>;
export type GetCustomEntityTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the details of a custom pattern by specifying its name.
 */
export declare const getCustomEntityType: API.OperationMethod<GetCustomEntityTypeRequest, GetCustomEntityTypeResponse, GetCustomEntityTypeError, Credentials | HttpClient.HttpClient>;
export type GetDashboardUrlError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | CommonErrors;
/**
 * Retrieves the URL for the Spark monitoring dashboard for a Glue resource.
 */
export declare const getDashboardUrl: API.OperationMethod<GetDashboardUrlRequest, GetDashboardUrlResponse, GetDashboardUrlError, Credentials | HttpClient.HttpClient>;
export type GetDatabaseError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the definition of a specified database.
 */
export declare const getDatabase: API.OperationMethod<GetDatabaseRequest, GetDatabaseResponse, GetDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetDatabasesError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all databases defined in a given Data Catalog.
 */
export declare const getDatabases: API.PaginatedOperationMethod<GetDatabasesRequest, GetDatabasesResponse, GetDatabasesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDataCatalogEncryptionSettingsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the security configuration for a specified catalog.
 */
export declare const getDataCatalogEncryptionSettings: API.OperationMethod<GetDataCatalogEncryptionSettingsRequest, GetDataCatalogEncryptionSettingsResponse, GetDataCatalogEncryptionSettingsError, Credentials | HttpClient.HttpClient>;
export type GetDataCatalogExportConfigurationError = EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current export configuration for the Glue Data Catalog. The export configuration controls whether catalog metadata is exported to S3 Tables.
 */
export declare const getDataCatalogExportConfiguration: API.OperationMethod<GetDataCatalogExportConfigurationInput, GetDataCatalogExportConfigurationOutput, GetDataCatalogExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDataflowGraphError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Transforms a Python script into a directed acyclic graph (DAG).
 */
export declare const getDataflowGraph: API.OperationMethod<GetDataflowGraphRequest, GetDataflowGraphResponse, GetDataflowGraphError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityModelError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve the training status of the model along with more information (CompletedOn, StartedOn, FailureReason).
 */
export declare const getDataQualityModel: API.OperationMethod<GetDataQualityModelRequest, GetDataQualityModelResponse, GetDataQualityModelError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityModelResultError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve a statistic's predictions for a given Profile ID.
 */
export declare const getDataQualityModelResult: API.OperationMethod<GetDataQualityModelResultRequest, GetDataQualityModelResultResponse, GetDataQualityModelResultError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityResultError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the result of a data quality rule evaluation.
 */
export declare const getDataQualityResult: API.OperationMethod<GetDataQualityResultRequest, GetDataQualityResultResponse, GetDataQualityResultError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityRuleRecommendationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets the specified recommendation run that was used to generate rules.
 */
export declare const getDataQualityRuleRecommendationRun: API.OperationMethod<GetDataQualityRuleRecommendationRunRequest, GetDataQualityRuleRecommendationRunResponse, GetDataQualityRuleRecommendationRunError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityRulesetError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns an existing ruleset by identifier or name.
 */
export declare const getDataQualityRuleset: API.OperationMethod<GetDataQualityRulesetRequest, GetDataQualityRulesetResponse, GetDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type GetDataQualityRulesetEvaluationRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specific run where a ruleset is evaluated against a data source.
 */
export declare const getDataQualityRulesetEvaluationRun: API.OperationMethod<GetDataQualityRulesetEvaluationRunRequest, GetDataQualityRulesetEvaluationRunResponse, GetDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type GetDevEndpointError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about a specified development endpoint.
 *
 * When you create a development endpoint in a virtual private cloud (VPC), Glue returns only
 * a private IP address, and the public IP address field is not populated. When you create a
 * non-VPC development endpoint, Glue returns only a public IP address.
 */
export declare const getDevEndpoint: API.OperationMethod<GetDevEndpointRequest, GetDevEndpointResponse, GetDevEndpointError, Credentials | HttpClient.HttpClient>;
export type GetDevEndpointsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all the development endpoints in this Amazon Web Services account.
 *
 * When you create a development endpoint in a virtual private cloud (VPC), Glue returns only a private IP address
 * and the public IP address field is not populated. When you create a non-VPC development
 * endpoint, Glue returns only a public IP address.
 */
export declare const getDevEndpoints: API.PaginatedOperationMethod<GetDevEndpointsRequest, GetDevEndpointsResponse, GetDevEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetEntityRecordsError = AccessDeniedException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * This API is used to query preview data from a given connection type or from a native Amazon S3 based Glue Data Catalog.
 *
 * Returns records as an array of JSON blobs. Each record is formatted using Jackson JsonNode based on the field type defined by the `DescribeEntity` API.
 *
 * Spark connectors generate schemas according to the same data type mapping as in the `DescribeEntity` API. Spark connectors convert data to the appropriate data types matching the schema when returning rows.
 */
export declare const getEntityRecords: API.OperationMethod<GetEntityRecordsRequest, GetEntityRecordsResponse, GetEntityRecordsError, Credentials | HttpClient.HttpClient>;
export type GetFormTypeError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Retrieves a form type in Glue Data Catalog by its identifier.
 */
export declare const getFormType: API.OperationMethod<GetFormTypeRequest, GetFormTypeResponse, GetFormTypeError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryError = AccessDeniedException | EntityNotFoundException | InternalServiceException | ThrottlingException | CommonErrors;
/**
 * Retrieves a business glossary in Glue Data Catalog by its identifier.
 */
export declare const getGlossary: API.OperationMethod<GetGlossaryRequest, GetGlossaryResponse, GetGlossaryError, Credentials | HttpClient.HttpClient>;
export type GetGlossaryTermError = AccessDeniedException | EntityNotFoundException | InternalServiceException | ThrottlingException | CommonErrors;
/**
 * Retrieves a glossary term in Glue Data Catalog by its identifier.
 */
export declare const getGlossaryTerm: API.OperationMethod<GetGlossaryTermRequest, GetGlossaryTermResponse, GetGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type GetGlueIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the current Glue Identity Center configuration details, including the associated Identity Center instance and
 * application information.
 */
export declare const getGlueIdentityCenterConfiguration: API.OperationMethod<GetGlueIdentityCenterConfigurationRequest, GetGlueIdentityCenterConfigurationResponse, GetGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResourcePropertyError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used for fetching the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target)
 */
export declare const getIntegrationResourceProperty: API.OperationMethod<GetIntegrationResourcePropertyRequest, GetIntegrationResourcePropertyResponse, GetIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used to retrieve optional override properties for the tables that need to be replicated. These properties can include properties for filtering and partition for source and target tables.
 */
export declare const getIntegrationTableProperties: API.OperationMethod<GetIntegrationTablePropertiesRequest, GetIntegrationTablePropertiesResponse, GetIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type GetJobError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves an existing job definition.
 */
export declare const getJob: API.OperationMethod<GetJobRequest, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetJobBookmarkError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Returns information on a job bookmark entry.
 *
 * For more information about enabling and using job bookmarks, see:
 *
 * - Tracking processed data using job bookmarks
 *
 * - Job parameters used by Glue
 *
 * - Job structure
 */
export declare const getJobBookmark: API.OperationMethod<GetJobBookmarkRequest, GetJobBookmarkResponse, GetJobBookmarkError, Credentials | HttpClient.HttpClient>;
export type GetJobRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the metadata for a given job run. Job run history is accessible for 365 days for your workflow and job run.
 */
export declare const getJobRun: API.OperationMethod<GetJobRunRequest, GetJobRunResponse, GetJobRunError, Credentials | HttpClient.HttpClient>;
export type GetJobRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for all runs of a given job definition.
 *
 * `GetJobRuns` returns the job runs in chronological order, with the newest jobs returned first.
 */
export declare const getJobRuns: API.PaginatedOperationMethod<GetJobRunsRequest, GetJobRunsResponse, GetJobRunsError, Credentials | HttpClient.HttpClient, JobRun>;
export type GetJobsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves all current job definitions.
 */
export declare const getJobs: API.PaginatedOperationMethod<GetJobsRequest, GetJobsResponse, GetJobsError, Credentials | HttpClient.HttpClient, Job>;
export type GetMappingError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates mappings.
 */
export declare const getMapping: API.OperationMethod<GetMappingRequest, GetMappingResponse, GetMappingError, Credentials | HttpClient.HttpClient>;
export type GetMaterializedViewRefreshTaskRunError = AccessDeniedException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Get the associated metadata/information for a task run, given a task run ID.
 */
export declare const getMaterializedViewRefreshTaskRun: API.OperationMethod<GetMaterializedViewRefreshTaskRunRequest, GetMaterializedViewRefreshTaskRunResponse, GetMaterializedViewRefreshTaskRunError, Credentials | HttpClient.HttpClient>;
export type GetMLTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets details for a specific task run on a machine learning transform. Machine learning
 * task runs are asynchronous tasks that Glue runs on your behalf as part of various machine
 * learning workflows. You can check the stats of any task run by calling
 * `GetMLTaskRun` with the `TaskRunID` and its parent transform's
 * `TransformID`.
 */
export declare const getMLTaskRun: API.OperationMethod<GetMLTaskRunRequest, GetMLTaskRunResponse, GetMLTaskRunError, Credentials | HttpClient.HttpClient>;
export type GetMLTaskRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets a list of runs for a machine learning transform. Machine learning task runs are
 * asynchronous tasks that Glue runs on your behalf as part of various machine learning
 * workflows. You can get a sortable, filterable list of machine learning task runs by calling
 * `GetMLTaskRuns` with their parent transform's `TransformID` and other
 * optional parameters as documented in this section.
 *
 * This operation returns a list of historic runs and must be paginated.
 */
export declare const getMLTaskRuns: API.PaginatedOperationMethod<GetMLTaskRunsRequest, GetMLTaskRunsResponse, GetMLTaskRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetMLTransformError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets an Glue machine learning transform artifact and all its corresponding metadata.
 * Machine learning transforms are a special type of transform that use machine learning to learn
 * the details of the transformation to be performed by learning from examples provided by
 * humans. These transformations are then saved by Glue. You can retrieve their metadata by
 * calling `GetMLTransform`.
 */
export declare const getMLTransform: API.OperationMethod<GetMLTransformRequest, GetMLTransformResponse, GetMLTransformError, Credentials | HttpClient.HttpClient>;
export type GetMLTransformsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets a sortable, filterable list of existing Glue machine learning transforms. Machine
 * learning transforms are a special type of transform that use machine learning to learn the
 * details of the transformation to be performed by learning from examples provided by humans.
 * These transformations are then saved by Glue, and you can retrieve their metadata by
 * calling `GetMLTransforms`.
 */
export declare const getMLTransforms: API.PaginatedOperationMethod<GetMLTransformsRequest, GetMLTransformsResponse, GetMLTransformsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetPartitionError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about a specified partition.
 */
export declare const getPartition: API.OperationMethod<GetPartitionRequest, GetPartitionResponse, GetPartitionError, Credentials | HttpClient.HttpClient>;
export type GetPartitionIndexesError = ConflictException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the partition indexes associated with a table.
 */
export declare const getPartitionIndexes: API.PaginatedOperationMethod<GetPartitionIndexesRequest, GetPartitionIndexesResponse, GetPartitionIndexesError, Credentials | HttpClient.HttpClient, PartitionIndexDescriptor>;
export type GetPartitionsError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | InvalidStateException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Retrieves information about the partitions in a table.
 */
export declare const getPartitions: API.PaginatedOperationMethod<GetPartitionsRequest, GetPartitionsResponse, GetPartitionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetPlanError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets code to perform a specified mapping.
 */
export declare const getPlan: API.OperationMethod<GetPlanRequest, GetPlanResponse, GetPlanError, Credentials | HttpClient.HttpClient>;
export type GetRegistryError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Describes the specified registry in detail.
 */
export declare const getRegistry: API.OperationMethod<GetRegistryInput, GetRegistryResponse, GetRegistryError, Credentials | HttpClient.HttpClient>;
export type GetResourcePoliciesError = GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the resource policies set on individual resources by Resource Access Manager
 * during cross-account permission grants. Also retrieves the Data Catalog resource
 * policy.
 *
 * If you enabled metadata encryption in Data Catalog settings, and you do not have
 * permission on the KMS key, the operation can't return the Data Catalog resource
 * policy.
 */
export declare const getResourcePolicies: API.PaginatedOperationMethod<GetResourcePoliciesRequest, GetResourcePoliciesResponse, GetResourcePoliciesError, Credentials | HttpClient.HttpClient, GluePolicy>;
export type GetResourcePolicyError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified resource policy.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetSchemaError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Describes the specified schema in detail.
 */
export declare const getSchema: API.OperationMethod<GetSchemaInput, GetSchemaResponse, GetSchemaError, Credentials | HttpClient.HttpClient>;
export type GetSchemaByDefinitionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieves a schema by the `SchemaDefinition`. The schema definition is sent to the Schema Registry, canonicalized, and hashed. If the hash is matched within the scope of the `SchemaName` or ARN (or the default registry, if none is supplied), that schema’s metadata is returned. Otherwise, a 404 or NotFound error is returned. Schema versions in `Deleted` statuses will not be included in the results.
 */
export declare const getSchemaByDefinition: API.OperationMethod<GetSchemaByDefinitionInput, GetSchemaByDefinitionResponse, GetSchemaByDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSchemaVersionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Get the specified schema by its unique ID assigned when a version of the schema is created or registered. Schema versions in Deleted status will not be included in the results.
 */
export declare const getSchemaVersion: API.OperationMethod<GetSchemaVersionInput, GetSchemaVersionResponse, GetSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type GetSchemaVersionsDiffError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Fetches the schema version difference in the specified difference type between two stored schema versions in the Schema Registry.
 *
 * This API allows you to compare two schema versions between two schema definitions under the same schema.
 */
export declare const getSchemaVersionsDiff: API.OperationMethod<GetSchemaVersionsDiffInput, GetSchemaVersionsDiffResponse, GetSchemaVersionsDiffError, Credentials | HttpClient.HttpClient>;
export type GetSecurityConfigurationError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified security configuration.
 */
export declare const getSecurityConfiguration: API.OperationMethod<GetSecurityConfigurationRequest, GetSecurityConfigurationResponse, GetSecurityConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSecurityConfigurationsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of all security configurations.
 */
export declare const getSecurityConfigurations: API.PaginatedOperationMethod<GetSecurityConfigurationsRequest, GetSecurityConfigurationsResponse, GetSecurityConfigurationsError, Credentials | HttpClient.HttpClient, SecurityConfiguration>;
export type GetSessionError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the session.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionEndpointError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Returns the Spark Connect endpoint URL and authentication token for an interactive session.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointRequest, GetSessionEndpointResponse, GetSessionEndpointError, Credentials | HttpClient.HttpClient>;
export type GetStatementError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the statement.
 */
export declare const getStatement: API.OperationMethod<GetStatementRequest, GetStatementResponse, GetStatementError, Credentials | HttpClient.HttpClient>;
export type GetTableError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | CommonErrors;
/**
 * Retrieves the `Table` definition in a Data Catalog for
 * a specified table.
 */
export declare const getTable: API.OperationMethod<GetTableRequest, GetTableResponse, GetTableError, Credentials | HttpClient.HttpClient>;
export type GetTableOptimizerError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Returns the configuration of all optimizers associated with a specified table.
 */
export declare const getTableOptimizer: API.OperationMethod<GetTableOptimizerRequest, GetTableOptimizerResponse, GetTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type GetTablesError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the definitions of some or all of the tables in a given
 * `Database`.
 */
export declare const getTables: API.PaginatedOperationMethod<GetTablesRequest, GetTablesResponse, GetTablesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTableVersionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified version of a table.
 */
export declare const getTableVersion: API.OperationMethod<GetTableVersionRequest, GetTableVersionResponse, GetTableVersionError, Credentials | HttpClient.HttpClient>;
export type GetTableVersionsError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of strings that identify available versions of
 * a specified table.
 */
export declare const getTableVersions: API.PaginatedOperationMethod<GetTableVersionsRequest, GetTableVersionsResponse, GetTableVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetTagsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a list of tags associated with a resource.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest, GetTagsResponse, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetTriggerError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the definition of a trigger.
 */
export declare const getTrigger: API.OperationMethod<GetTriggerRequest, GetTriggerResponse, GetTriggerError, Credentials | HttpClient.HttpClient>;
export type GetTriggersError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Gets all the triggers associated with a job.
 */
export declare const getTriggers: API.PaginatedOperationMethod<GetTriggersRequest, GetTriggersResponse, GetTriggersError, Credentials | HttpClient.HttpClient, Trigger>;
export type GetUnfilteredPartitionMetadataError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * Retrieves partition metadata from the Data Catalog that contains unfiltered
 * metadata.
 *
 * For IAM authorization, the public IAM action associated with this API is `glue:GetPartition`.
 */
export declare const getUnfilteredPartitionMetadata: API.OperationMethod<GetUnfilteredPartitionMetadataRequest, GetUnfilteredPartitionMetadataResponse, GetUnfilteredPartitionMetadataError, Credentials | HttpClient.HttpClient>;
export type GetUnfilteredPartitionsMetadataError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * Retrieves partition metadata from the Data Catalog that contains unfiltered
 * metadata.
 *
 * For IAM authorization, the public IAM action associated with this API is `glue:GetPartitions`.
 */
export declare const getUnfilteredPartitionsMetadata: API.PaginatedOperationMethod<GetUnfilteredPartitionsMetadataRequest, GetUnfilteredPartitionsMetadataResponse, GetUnfilteredPartitionsMetadataError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUnfilteredTableMetadataError = EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | PermissionTypeMismatchException | CommonErrors;
/**
 * Allows a third-party analytical engine to retrieve unfiltered table metadata from the Data Catalog.
 *
 * For IAM authorization, the public IAM action associated with this API is `glue:GetTable`.
 */
export declare const getUnfilteredTableMetadata: API.OperationMethod<GetUnfilteredTableMetadataRequest, GetUnfilteredTableMetadataResponse, GetUnfilteredTableMetadataError, Credentials | HttpClient.HttpClient>;
export type GetUsageProfileError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves information about the specified Glue usage profile.
 */
export declare const getUsageProfile: API.OperationMethod<GetUsageProfileRequest, GetUsageProfileResponse, GetUsageProfileError, Credentials | HttpClient.HttpClient>;
export type GetUserDefinedFunctionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a specified function definition from the Data Catalog.
 */
export declare const getUserDefinedFunction: API.OperationMethod<GetUserDefinedFunctionRequest, GetUserDefinedFunctionResponse, GetUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type GetUserDefinedFunctionsError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves multiple function definitions from the Data Catalog.
 */
export declare const getUserDefinedFunctions: API.PaginatedOperationMethod<GetUserDefinedFunctionsRequest, GetUserDefinedFunctionsResponse, GetUserDefinedFunctionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetWorkflowError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves resource metadata for a workflow.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the metadata for a given workflow run. Job run history is accessible for 90 days for your workflow and job run.
 */
export declare const getWorkflowRun: API.OperationMethod<GetWorkflowRunRequest, GetWorkflowRunResponse, GetWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunPropertiesError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the workflow run properties which were set during the run.
 */
export declare const getWorkflowRunProperties: API.OperationMethod<GetWorkflowRunPropertiesRequest, GetWorkflowRunPropertiesResponse, GetWorkflowRunPropertiesError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves metadata for all runs of a given workflow.
 */
export declare const getWorkflowRuns: API.PaginatedOperationMethod<GetWorkflowRunsRequest, GetWorkflowRunsResponse, GetWorkflowRunsError, Credentials | HttpClient.HttpClient, WorkflowRun>;
export type ImportCatalogToGlueError = InternalServiceException | OperationTimeoutException | CommonErrors;
/**
 * Imports an existing Amazon Athena Data Catalog to Glue.
 */
export declare const importCatalogToGlue: API.OperationMethod<ImportCatalogToGlueRequest, ImportCatalogToGlueResponse, ImportCatalogToGlueError, Credentials | HttpClient.HttpClient>;
export type ListAssetTypesError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists the asset types defined in Glue Data Catalog.
 */
export declare const listAssetTypes: API.PaginatedOperationMethod<ListAssetTypesRequest, ListAssetTypesResponse, ListAssetTypesError, Credentials | HttpClient.HttpClient, AssetTypeItem>;
export type ListBlueprintsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists all the blueprint names in an account.
 */
export declare const listBlueprints: API.PaginatedOperationMethod<ListBlueprintsRequest, ListBlueprintsResponse, ListBlueprintsError, Credentials | HttpClient.HttpClient, OrchestrationNameString>;
export type ListColumnStatisticsTaskRunsError = OperationTimeoutException | CommonErrors;
/**
 * List all task runs for a particular account.
 */
export declare const listColumnStatisticsTaskRuns: API.PaginatedOperationMethod<ListColumnStatisticsTaskRunsRequest, ListColumnStatisticsTaskRunsResponse, ListColumnStatisticsTaskRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConnectionTypesError = AccessDeniedException | InternalServiceException | CommonErrors;
/**
 * The `ListConnectionTypes` API provides a discovery mechanism to learn available connection types in Glue. The response contains a list of connection types with high-level details of what is supported for each connection type, including both built-in connection types and custom connection types registered via `RegisterConnectionType`. The connection types listed are the set of supported options for the `ConnectionType` value in the `CreateConnection` API.
 *
 * See also: `DescribeConnectionType`, `RegisterConnectionType`, `DeleteConnectionType`
 */
export declare const listConnectionTypes: API.PaginatedOperationMethod<ListConnectionTypesRequest, ListConnectionTypesResponse, ListConnectionTypesError, Credentials | HttpClient.HttpClient, ConnectionTypeBrief>;
export type ListCrawlersError = OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all crawler resources in this Amazon Web Services account, or the
 * resources with the specified tag. This operation allows you to see which
 * resources are available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listCrawlers: API.PaginatedOperationMethod<ListCrawlersRequest, ListCrawlersResponse, ListCrawlersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCrawlsError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns all the crawls of a specified crawler. Returns only the crawls that have occurred since the launch date of the crawler history feature, and only retains up to 12 months of crawls. Older crawls will not be returned.
 *
 * You may use this API to:
 *
 * - Retrive all the crawls of a specified crawler.
 *
 * - Retrieve all the crawls of a specified crawler within a limited count.
 *
 * - Retrieve all the crawls of a specified crawler in a specific time range.
 *
 * - Retrieve all the crawls of a specified crawler with a particular state, crawl ID, or DPU hour value.
 */
export declare const listCrawls: API.OperationMethod<ListCrawlsRequest, ListCrawlsResponse, ListCrawlsError, Credentials | HttpClient.HttpClient>;
export type ListCustomEntityTypesError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists all the custom patterns that have been created.
 */
export declare const listCustomEntityTypes: API.PaginatedOperationMethod<ListCustomEntityTypesRequest, ListCustomEntityTypesResponse, ListCustomEntityTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityResultsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns all data quality execution results for your account.
 */
export declare const listDataQualityResults: API.PaginatedOperationMethod<ListDataQualityResultsRequest, ListDataQualityResultsResponse, ListDataQualityResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityRuleRecommendationRunsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists the recommendation runs meeting the filter criteria.
 */
export declare const listDataQualityRuleRecommendationRuns: API.PaginatedOperationMethod<ListDataQualityRuleRecommendationRunsRequest, ListDataQualityRuleRecommendationRunsResponse, ListDataQualityRuleRecommendationRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityRulesetEvaluationRunsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists all the runs meeting the filter criteria, where a ruleset is evaluated against a data source.
 */
export declare const listDataQualityRulesetEvaluationRuns: API.PaginatedOperationMethod<ListDataQualityRulesetEvaluationRunsRequest, ListDataQualityRulesetEvaluationRunsResponse, ListDataQualityRulesetEvaluationRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityRulesetsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Returns a paginated list of rulesets for the specified list of Glue tables.
 */
export declare const listDataQualityRulesets: API.PaginatedOperationMethod<ListDataQualityRulesetsRequest, ListDataQualityRulesetsResponse, ListDataQualityRulesetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDataQualityStatisticAnnotationsError = InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieve annotations for a data quality statistic.
 */
export declare const listDataQualityStatisticAnnotations: API.OperationMethod<ListDataQualityStatisticAnnotationsRequest, ListDataQualityStatisticAnnotationsResponse, ListDataQualityStatisticAnnotationsError, Credentials | HttpClient.HttpClient>;
export type ListDataQualityStatisticsError = EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Retrieves a list of data quality statistics.
 */
export declare const listDataQualityStatistics: API.OperationMethod<ListDataQualityStatisticsRequest, ListDataQualityStatisticsResponse, ListDataQualityStatisticsError, Credentials | HttpClient.HttpClient>;
export type ListDevEndpointsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all `DevEndpoint` resources in this Amazon Web Services account, or the
 * resources with the specified tag. This operation allows you to see which resources are
 * available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listDevEndpoints: API.PaginatedOperationMethod<ListDevEndpointsRequest, ListDevEndpointsResponse, ListDevEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEntitiesError = AccessDeniedException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Returns the available entities supported by the connection type.
 */
export declare const listEntities: API.PaginatedOperationMethod<ListEntitiesRequest, ListEntitiesResponse, ListEntitiesError, Credentials | HttpClient.HttpClient, Entity>;
export type ListFormTypesError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists the form types defined in Glue Data Catalog.
 */
export declare const listFormTypes: API.PaginatedOperationMethod<ListFormTypesRequest, ListFormTypesResponse, ListFormTypesError, Credentials | HttpClient.HttpClient, FormTypeItem>;
export type ListGlossariesError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists business glossaries in Glue Data Catalog.
 */
export declare const listGlossaries: API.PaginatedOperationMethod<ListGlossariesRequest, ListGlossariesResponse, ListGlossariesError, Credentials | HttpClient.HttpClient, GlossaryItem>;
export type ListGlossaryTermsError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists glossary terms within a business glossary in Glue Data Catalog.
 */
export declare const listGlossaryTerms: API.PaginatedOperationMethod<ListGlossaryTermsRequest, ListGlossaryTermsResponse, ListGlossaryTermsError, Credentials | HttpClient.HttpClient, GlossaryTermItem>;
export type ListIntegrationResourcePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List integration resource properties for a single customer. It supports the filters, maxRecords and markers.
 */
export declare const listIntegrationResourceProperties: API.OperationMethod<ListIntegrationResourcePropertiesRequest, ListIntegrationResourcePropertiesResponse, ListIntegrationResourcePropertiesError, Credentials | HttpClient.HttpClient>;
export type ListIterableFormsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Lists the items in an iterable form on an asset in Glue Data Catalog. For example, lists the columns of a table asset.
 */
export declare const listIterableForms: API.PaginatedOperationMethod<ListIterableFormsRequest, ListIterableFormsResponse, ListIterableFormsError, Credentials | HttpClient.HttpClient, IterableFormListItem>;
export type ListJobsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all job resources in this Amazon Web Services account, or the resources with the specified tag. This operation allows you to see which resources are available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, NameString>;
export type ListMaterializedViewRefreshTaskRunsError = AccessDeniedException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * List all task runs for a particular account.
 */
export declare const listMaterializedViewRefreshTaskRuns: API.PaginatedOperationMethod<ListMaterializedViewRefreshTaskRunsRequest, ListMaterializedViewRefreshTaskRunsResponse, ListMaterializedViewRefreshTaskRunsError, Credentials | HttpClient.HttpClient, MaterializedViewRefreshTaskRun>;
export type ListMLTransformsError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves a sortable, filterable list of existing Glue machine learning transforms in this Amazon Web Services account,
 * or the resources with the specified tag. This operation takes the optional `Tags` field, which you can use as
 * a filter of the responses so that tagged resources can be retrieved as a group. If you choose to use tag
 * filtering, only resources with the tags are retrieved.
 */
export declare const listMLTransforms: API.PaginatedOperationMethod<ListMLTransformsRequest, ListMLTransformsResponse, ListMLTransformsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRegistriesError = AccessDeniedException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns a list of registries that you have created, with minimal registry information. Registries in the `Deleting` status will not be included in the results. Empty results will be returned if there are no registries available.
 */
export declare const listRegistries: API.PaginatedOperationMethod<ListRegistriesInput, ListRegistriesResponse, ListRegistriesError, Credentials | HttpClient.HttpClient, RegistryListItem>;
export type ListSchemasError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns a list of schemas with minimal details. Schemas in Deleting status will not be included in the results. Empty results will be returned if there are no schemas available.
 *
 * When the `RegistryId` is not provided, all the schemas across registries will be part of the API response.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasInput, ListSchemasResponse, ListSchemasError, Credentials | HttpClient.HttpClient, SchemaListItem>;
export type ListSchemaVersionsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Returns a list of schema versions that you have created, with minimal information. Schema versions in Deleted status will not be included in the results. Empty results will be returned if there are no schema versions available.
 */
export declare const listSchemaVersions: API.PaginatedOperationMethod<ListSchemaVersionsInput, ListSchemaVersionsResponse, ListSchemaVersionsError, Credentials | HttpClient.HttpClient, SchemaVersionListItem>;
export type ListSessionsError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieve a list of sessions.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListStatementsError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists statements for the session.
 */
export declare const listStatements: API.OperationMethod<ListStatementsRequest, ListStatementsResponse, ListStatementsError, Credentials | HttpClient.HttpClient>;
export type ListTableOptimizerRunsError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the history of previous optimizer runs for a specific table.
 */
export declare const listTableOptimizerRuns: API.PaginatedOperationMethod<ListTableOptimizerRunsRequest, ListTableOptimizerRunsResponse, ListTableOptimizerRunsError, Credentials | HttpClient.HttpClient, TableOptimizerRun>;
export type ListTriggersError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Retrieves the names of all trigger resources in this Amazon Web Services account, or the resources with the specified tag. This operation allows you to see which resources are available in your account, and their names.
 *
 * This operation takes the optional `Tags` field, which you can use as a filter on
 * the response so that tagged resources can be retrieved as a group. If you choose to use tags
 * filtering, only resources with the tag are retrieved.
 */
export declare const listTriggers: API.PaginatedOperationMethod<ListTriggersRequest, ListTriggersResponse, ListTriggersError, Credentials | HttpClient.HttpClient, NameString>;
export type ListUsageProfilesError = InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * List all the Glue usage profiles.
 */
export declare const listUsageProfiles: API.PaginatedOperationMethod<ListUsageProfilesRequest, ListUsageProfilesResponse, ListUsageProfilesError, Credentials | HttpClient.HttpClient, UsageProfileDefinition>;
export type ListWorkflowsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Lists names of workflows created in the account.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, NameString>;
export type ModifyIntegrationError = AccessDeniedException | ConflictException | EntityNotFoundException | IntegrationConflictOperationFault | IntegrationNotFoundFault | InternalServerException | InternalServiceException | InvalidInputException | InvalidIntegrationStateFault | InvalidStateException | ValidationException | CommonErrors;
/**
 * Modifies a Zero-ETL integration in the caller's account.
 */
export declare const modifyIntegration: API.OperationMethod<ModifyIntegrationRequest, ModifyIntegrationResponse, ModifyIntegrationError, Credentials | HttpClient.HttpClient>;
export type PutAssetError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates an asset in Glue Data Catalog. If the asset already exists, this operation updates it; otherwise, a new asset is created.
 */
export declare const putAsset: API.OperationMethod<PutAssetRequest, PutAssetResponse, PutAssetError, Credentials | HttpClient.HttpClient>;
export type PutAssetTypeError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates an asset type in Glue Data Catalog. An asset type defines the structure of assets by specifying which forms they include. If an asset type with the given name already exists, it is updated.
 */
export declare const putAssetType: API.OperationMethod<PutAssetTypeRequest, PutAssetTypeResponse, PutAssetTypeError, Credentials | HttpClient.HttpClient>;
export type PutAttachmentError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Attaches a form to an asset or an iterable form item in Glue Data Catalog. If an attachment with the same name already exists, it is overwritten.
 */
export declare const putAttachment: API.OperationMethod<PutAttachmentRequest, PutAttachmentResponse, PutAttachmentError, Credentials | HttpClient.HttpClient>;
export type PutDataCatalogEncryptionSettingsError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Sets the security configuration for a specified catalog. After the configuration has been
 * set, the specified encryption is applied to every catalog write thereafter.
 */
export declare const putDataCatalogEncryptionSettings: API.OperationMethod<PutDataCatalogEncryptionSettingsRequest, PutDataCatalogEncryptionSettingsResponse, PutDataCatalogEncryptionSettingsError, Credentials | HttpClient.HttpClient>;
export type PutDataCatalogExportConfigurationError = AccessDeniedException | ConflictException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates the export configuration for the Glue Data Catalog. Use this operation to enable or disable the export of catalog metadata to S3 Tables.
 */
export declare const putDataCatalogExportConfiguration: API.OperationMethod<PutDataCatalogExportConfigurationInput, PutDataCatalogExportConfigurationOutput, PutDataCatalogExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutDataQualityProfileAnnotationError = EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Annotate all datapoints for a Profile.
 */
export declare const putDataQualityProfileAnnotation: API.OperationMethod<PutDataQualityProfileAnnotationRequest, PutDataQualityProfileAnnotationResponse, PutDataQualityProfileAnnotationError, Credentials | HttpClient.HttpClient>;
export type PutFormTypeError = AccessDeniedException | ConcurrentModificationException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Creates or updates a form type in Glue Data Catalog. A form type defines the schema for structured metadata that can be attached to assets.
 */
export declare const putFormType: API.OperationMethod<PutFormTypeRequest, PutFormTypeResponse, PutFormTypeError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = ConditionCheckFailureException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Sets the Data Catalog resource policy for access control.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutSchemaVersionMetadataError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Puts the metadata key value pair for a specified schema version ID. A maximum of 10 key value pairs will be allowed per schema version. They can be added over one or more calls.
 */
export declare const putSchemaVersionMetadata: API.OperationMethod<PutSchemaVersionMetadataInput, PutSchemaVersionMetadataResponse, PutSchemaVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type PutWorkflowRunPropertiesError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Puts the specified workflow run properties for the given workflow run. If a property already exists for the specified run, then it overrides the value otherwise adds the property to existing properties.
 */
export declare const putWorkflowRunProperties: API.OperationMethod<PutWorkflowRunPropertiesRequest, PutWorkflowRunPropertiesResponse, PutWorkflowRunPropertiesError, Credentials | HttpClient.HttpClient>;
export type QuerySchemaVersionMetadataError = AccessDeniedException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Queries for the schema version metadata information.
 */
export declare const querySchemaVersionMetadata: API.OperationMethod<QuerySchemaVersionMetadataInput, QuerySchemaVersionMetadataResponse, QuerySchemaVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type RegisterConnectionTypeError = AccessDeniedException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | ValidationException | CommonErrors;
/**
 * Registers a custom connection type in Glue based on the configuration provided. This operation enables customers to configure custom connectors for any data source with REST-based APIs, eliminating the need for building custom Lambda connectors.
 *
 * The registered connection type stores details about how requests and responses are interpreted by REST sources, including connection properties, authentication configuration, and REST configuration with entity definitions. Once registered, customers can create connections using this connection type and work with them the same way as natively supported Glue connectors.
 *
 * Supports multiple authentication types including Basic, OAuth2 (Client Credentials, JWT Bearer, Authorization Code), and Custom Auth configurations.
 */
export declare const registerConnectionType: API.OperationMethod<RegisterConnectionTypeRequest, RegisterConnectionTypeResponse, RegisterConnectionTypeError, Credentials | HttpClient.HttpClient>;
export type RegisterSchemaVersionError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Adds a new version to the existing schema. Returns an error if new version of schema does not meet the compatibility requirements of the schema set. This API will not create a new schema set and will return a 404 error if the schema set is not already present in the Schema Registry.
 *
 * If this is the first schema definition to be registered in the Schema Registry, this API will store the schema version and return immediately. Otherwise, this call has the potential to run longer than other operations due to compatibility modes. You can call the `GetSchemaVersion` API with the `SchemaVersionId` to check compatibility modes.
 *
 * If the same schema definition is already stored in Schema Registry as a version, the schema ID of the existing schema is returned to the caller.
 */
export declare const registerSchemaVersion: API.OperationMethod<RegisterSchemaVersionInput, RegisterSchemaVersionResponse, RegisterSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type RemoveSchemaVersionMetadataError = AccessDeniedException | EntityNotFoundException | InvalidInputException | CommonErrors;
/**
 * Removes a key value pair from the schema version metadata for the specified schema version ID.
 */
export declare const removeSchemaVersionMetadata: API.OperationMethod<RemoveSchemaVersionMetadataInput, RemoveSchemaVersionMetadataResponse, RemoveSchemaVersionMetadataError, Credentials | HttpClient.HttpClient>;
export type ResetJobBookmarkError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Resets a bookmark entry.
 *
 * For more information about enabling and using job bookmarks, see:
 *
 * - Tracking processed data using job bookmarks
 *
 * - Job parameters used by Glue
 *
 * - Job structure
 */
export declare const resetJobBookmark: API.OperationMethod<ResetJobBookmarkRequest, ResetJobBookmarkResponse, ResetJobBookmarkError, Credentials | HttpClient.HttpClient>;
export type ResumeWorkflowRunError = ConcurrentRunsExceededException | EntityNotFoundException | IllegalWorkflowStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Restarts selected nodes of a previous partially completed workflow run and resumes the workflow run. The selected nodes and all nodes that are downstream from the selected nodes are run.
 */
export declare const resumeWorkflowRun: API.OperationMethod<ResumeWorkflowRunRequest, ResumeWorkflowRunResponse, ResumeWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type RunStatementError = AccessDeniedException | EntityNotFoundException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | ResourceNumberLimitExceededException | SessionBusyException | ValidationException | CommonErrors;
/**
 * Executes the statement.
 */
export declare const runStatement: API.OperationMethod<RunStatementRequest, RunStatementResponse, RunStatementError, Credentials | HttpClient.HttpClient>;
export type SearchAssetsError = AccessDeniedException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Searches for assets in Glue Data Catalog using full-text search, filters, sorting, and aggregations. Returns matching assets with relevance-ranked results.
 */
export declare const searchAssets: API.PaginatedOperationMethod<SearchAssetsInput, SearchAssetsOutput, SearchAssetsError, Credentials | HttpClient.HttpClient, SearchResultItem>;
export type SearchTablesError = InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Searches a set of tables based on properties in the table metadata as well as on the parent database. You can search against text or filter conditions.
 *
 * You can only get tables that you have access to based on the security policies defined in Lake Formation. You need at least a read-only access to the table for it to be returned. If you do not have access to all the columns in the table, these columns will not be searched against when returning the list of tables back to you. If you have access to the columns but not the data in the columns, those columns and the associated metadata for those columns will be included in the search.
 */
export declare const searchTables: API.PaginatedOperationMethod<SearchTablesRequest, SearchTablesResponse, SearchTablesError, Credentials | HttpClient.HttpClient, unknown>;
export type StartBlueprintRunError = EntityNotFoundException | IllegalBlueprintStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a new run of the specified blueprint.
 */
export declare const startBlueprintRun: API.OperationMethod<StartBlueprintRunRequest, StartBlueprintRunResponse, StartBlueprintRunError, Credentials | HttpClient.HttpClient>;
export type StartColumnStatisticsTaskRunError = AccessDeniedException | ColumnStatisticsTaskRunningException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a column statistics task run, for a specified table and columns.
 */
export declare const startColumnStatisticsTaskRun: API.OperationMethod<StartColumnStatisticsTaskRunRequest, StartColumnStatisticsTaskRunResponse, StartColumnStatisticsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartColumnStatisticsTaskRunScheduleError = AccessDeniedException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Starts a column statistics task run schedule.
 */
export declare const startColumnStatisticsTaskRunSchedule: API.OperationMethod<StartColumnStatisticsTaskRunScheduleRequest, StartColumnStatisticsTaskRunScheduleResponse, StartColumnStatisticsTaskRunScheduleError, Credentials | HttpClient.HttpClient>;
export type StartCrawlerError = CrawlerRunningException | EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Starts a crawl using the specified crawler, regardless
 * of what is scheduled. If the crawler is already running, returns a
 * CrawlerRunningException.
 */
export declare const startCrawler: API.OperationMethod<StartCrawlerRequest, StartCrawlerResponse, StartCrawlerError, Credentials | HttpClient.HttpClient>;
export type StartCrawlerScheduleError = EntityNotFoundException | NoScheduleException | OperationTimeoutException | SchedulerRunningException | SchedulerTransitioningException | CommonErrors;
/**
 * Changes the schedule state of the specified crawler to
 * `SCHEDULED`, unless the crawler is already running or the
 * schedule state is already `SCHEDULED`.
 */
export declare const startCrawlerSchedule: API.OperationMethod<StartCrawlerScheduleRequest, StartCrawlerScheduleResponse, StartCrawlerScheduleError, Credentials | HttpClient.HttpClient>;
export type StartDataQualityRuleRecommendationRunError = ConflictException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Starts a recommendation run that is used to generate rules when you don't know what rules to write. Glue Data Quality analyzes the data and comes up with recommendations for a potential ruleset. You can then triage the ruleset and modify the generated ruleset to your liking.
 *
 * Recommendation runs are automatically deleted after 90 days.
 */
export declare const startDataQualityRuleRecommendationRun: API.OperationMethod<StartDataQualityRuleRecommendationRunRequest, StartDataQualityRuleRecommendationRunResponse, StartDataQualityRuleRecommendationRunError, Credentials | HttpClient.HttpClient>;
export type StartDataQualityRulesetEvaluationRunError = ConflictException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Once you have a ruleset definition (either recommended or your own), you call this operation to evaluate the ruleset against a data source (Glue table). The evaluation computes results which you can retrieve with the `GetDataQualityResult` API.
 */
export declare const startDataQualityRulesetEvaluationRun: API.OperationMethod<StartDataQualityRulesetEvaluationRunRequest, StartDataQualityRulesetEvaluationRunResponse, StartDataQualityRulesetEvaluationRunError, Credentials | HttpClient.HttpClient>;
export type StartExportLabelsTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Begins an asynchronous task to export all labeled data for a particular transform. This
 * task is the only label-related API call that is not part of the typical active learning
 * workflow. You typically use `StartExportLabelsTaskRun` when you want to work with
 * all of your existing labels at the same time, such as when you want to remove or change labels
 * that were previously submitted as truth. This API operation accepts the
 * `TransformId` whose labels you want to export and an Amazon Simple Storage
 * Service (Amazon S3) path to export the labels to. The operation returns a
 * `TaskRunId`. You can check on the status of your task run by calling the
 * `GetMLTaskRun` API.
 */
export declare const startExportLabelsTaskRun: API.OperationMethod<StartExportLabelsTaskRunRequest, StartExportLabelsTaskRunResponse, StartExportLabelsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartImportLabelsTaskRunError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Enables you to provide additional labels (examples of truth) to be used to teach the
 * machine learning transform and improve its quality. This API operation is generally used as
 * part of the active learning workflow that starts with the
 * `StartMLLabelingSetGenerationTaskRun` call and that ultimately results in
 * improving the quality of your machine learning transform.
 *
 * After the `StartMLLabelingSetGenerationTaskRun` finishes, Glue machine learning
 * will have generated a series of questions for humans to answer. (Answering these questions is
 * often called 'labeling' in the machine learning workflows). In the case of the
 * `FindMatches` transform, these questions are of the form, “What is the correct
 * way to group these rows together into groups composed entirely of matching records?” After the
 * labeling process is finished, users upload their answers/labels with a call to
 * `StartImportLabelsTaskRun`. After `StartImportLabelsTaskRun` finishes,
 * all future runs of the machine learning transform use the new and improved labels and perform
 * a higher-quality transformation.
 *
 * By default, `StartMLLabelingSetGenerationTaskRun` continually learns from and
 * combines all labels that you upload unless you set `Replace` to true. If you set
 * `Replace` to true, `StartImportLabelsTaskRun` deletes and forgets all
 * previously uploaded labels and learns only from the exact set that you upload. Replacing
 * labels can be helpful if you realize that you previously uploaded incorrect labels, and you
 * believe that they are having a negative effect on your transform quality.
 *
 * You can check on the status of your task run by calling the `GetMLTaskRun`
 * operation.
 */
export declare const startImportLabelsTaskRun: API.OperationMethod<StartImportLabelsTaskRunRequest, StartImportLabelsTaskRunResponse, StartImportLabelsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartJobRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | GlueRoleNotAssumable | CommonErrors;
/**
 * Starts a job run using a job definition.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest, StartJobRunResponse, StartJobRunError, Credentials | HttpClient.HttpClient>;
export type StartMaterializedViewRefreshTaskRunError = AccessDeniedException | EntityNotFoundException | InvalidInputException | MaterializedViewRefreshTaskRunningException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a materialized view refresh task run for a specified materialized view.
 */
export declare const startMaterializedViewRefreshTaskRun: API.OperationMethod<StartMaterializedViewRefreshTaskRunRequest, StartMaterializedViewRefreshTaskRunResponse, StartMaterializedViewRefreshTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartMLEvaluationTaskRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | MLTransformNotReadyException | OperationTimeoutException | CommonErrors;
/**
 * Starts a task to estimate the quality of the transform.
 *
 * When you provide label sets as examples of truth, Glue machine learning uses some of
 * those examples to learn from them. The rest of the labels are used as a test to estimate
 * quality.
 *
 * Returns a unique identifier for the run. You can call `GetMLTaskRun` to get more
 * information about the stats of the `EvaluationTaskRun`.
 */
export declare const startMLEvaluationTaskRun: API.OperationMethod<StartMLEvaluationTaskRunRequest, StartMLEvaluationTaskRunResponse, StartMLEvaluationTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartMLLabelingSetGenerationTaskRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Starts the active learning workflow for your machine learning transform to improve the
 * transform's quality by generating label sets and adding labels.
 *
 * When the `StartMLLabelingSetGenerationTaskRun` finishes, Glue will have
 * generated a "labeling set" or a set of questions for humans to answer.
 *
 * In the case of the `FindMatches` transform, these questions are of the form,
 * “What is the correct way to group these rows together into groups composed entirely of
 * matching records?”
 *
 * After the labeling process is finished, you can upload your labels with a call to
 * `StartImportLabelsTaskRun`. After `StartImportLabelsTaskRun` finishes,
 * all future runs of the machine learning transform will use the new and improved labels and
 * perform a higher-quality transformation.
 *
 * Note: The role used to write the generated labeling set to the `OutputS3Path` is the role
 * associated with the Machine Learning Transform, specified in the `CreateMLTransform` API.
 */
export declare const startMLLabelingSetGenerationTaskRun: API.OperationMethod<StartMLLabelingSetGenerationTaskRunRequest, StartMLLabelingSetGenerationTaskRunResponse, StartMLLabelingSetGenerationTaskRunError, Credentials | HttpClient.HttpClient>;
export type StartTriggerError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts an existing trigger. See Triggering
 * Jobs for information about how different types of trigger are
 * started.
 */
export declare const startTrigger: API.OperationMethod<StartTriggerRequest, StartTriggerResponse, StartTriggerError, Credentials | HttpClient.HttpClient>;
export type StartWorkflowRunError = ConcurrentRunsExceededException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Starts a new run of the specified workflow.
 */
export declare const startWorkflowRun: API.OperationMethod<StartWorkflowRunRequest, StartWorkflowRunResponse, StartWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type StopColumnStatisticsTaskRunError = ColumnStatisticsTaskNotRunningException | ColumnStatisticsTaskStoppingException | EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * Stops a task run for the specified table.
 */
export declare const stopColumnStatisticsTaskRun: API.OperationMethod<StopColumnStatisticsTaskRunRequest, StopColumnStatisticsTaskRunResponse, StopColumnStatisticsTaskRunError, Credentials | HttpClient.HttpClient>;
export type StopColumnStatisticsTaskRunScheduleError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops a column statistics task run schedule.
 */
export declare const stopColumnStatisticsTaskRunSchedule: API.OperationMethod<StopColumnStatisticsTaskRunScheduleRequest, StopColumnStatisticsTaskRunScheduleResponse, StopColumnStatisticsTaskRunScheduleError, Credentials | HttpClient.HttpClient>;
export type StopCrawlerError = CrawlerNotRunningException | CrawlerStoppingException | EntityNotFoundException | OperationTimeoutException | CommonErrors;
/**
 * If the specified crawler is running, stops the crawl.
 */
export declare const stopCrawler: API.OperationMethod<StopCrawlerRequest, StopCrawlerResponse, StopCrawlerError, Credentials | HttpClient.HttpClient>;
export type StopCrawlerScheduleError = EntityNotFoundException | OperationTimeoutException | SchedulerNotRunningException | SchedulerTransitioningException | CommonErrors;
/**
 * Sets the schedule state of the specified crawler to
 * `NOT_SCHEDULED`, but does not stop the crawler if it is
 * already running.
 */
export declare const stopCrawlerSchedule: API.OperationMethod<StopCrawlerScheduleRequest, StopCrawlerScheduleResponse, StopCrawlerScheduleError, Credentials | HttpClient.HttpClient>;
export type StopMaterializedViewRefreshTaskRunError = AccessDeniedException | InvalidInputException | MaterializedViewRefreshTaskNotRunningException | MaterializedViewRefreshTaskStoppingException | OperationTimeoutException | CommonErrors;
/**
 * Stops a materialized view refresh task run for a specified materialized view.
 */
export declare const stopMaterializedViewRefreshTaskRun: API.OperationMethod<StopMaterializedViewRefreshTaskRunRequest, StopMaterializedViewRefreshTaskRunResponse, StopMaterializedViewRefreshTaskRunError, Credentials | HttpClient.HttpClient>;
export type StopSessionError = AccessDeniedException | ConcurrentModificationException | IllegalSessionStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops the session.
 */
export declare const stopSession: API.OperationMethod<StopSessionRequest, StopSessionResponse, StopSessionError, Credentials | HttpClient.HttpClient>;
export type StopTriggerError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops a specified trigger.
 */
export declare const stopTrigger: API.OperationMethod<StopTriggerRequest, StopTriggerResponse, StopTriggerError, Credentials | HttpClient.HttpClient>;
export type StopWorkflowRunError = EntityNotFoundException | IllegalWorkflowStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Stops the execution of the specified workflow run.
 */
export declare const stopWorkflowRun: API.OperationMethod<StopWorkflowRunRequest, StopWorkflowRunResponse, StopWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Adds tags to a resource. A tag is a label you can assign to an Amazon Web Services resource.
 * In Glue, you can tag only certain resources. For information about what
 * resources you can tag, see Amazon Web Services Tags in Glue.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestConnectionError = AccessDeniedException | ConflictException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Tests a connection to a service to validate the service credentials that you provide.
 *
 * You can either provide an existing connection name or a `TestConnectionInput` for testing a non-existing connection input. Providing both at the same time will cause an error.
 *
 * If the action is successful, the service sends back an HTTP 200 response.
 */
export declare const testConnection: API.OperationMethod<TestConnectionRequest, TestConnectionResponse, TestConnectionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Updates the name and description of an existing asset in Glue Data Catalog. Only the fields that you provide are updated.
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateBlueprintError = ConcurrentModificationException | EntityNotFoundException | IllegalBlueprintStateException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a registered blueprint.
 */
export declare const updateBlueprint: API.OperationMethod<UpdateBlueprintRequest, UpdateBlueprintResponse, UpdateBlueprintError, Credentials | HttpClient.HttpClient>;
export type UpdateCatalogError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing catalog's properties in the Glue Data Catalog.
 */
export declare const updateCatalog: API.OperationMethod<UpdateCatalogRequest, UpdateCatalogResponse, UpdateCatalogError, Credentials | HttpClient.HttpClient>;
export type UpdateClassifierError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | VersionMismatchException | CommonErrors;
/**
 * Modifies an existing classifier (a `GrokClassifier`,
 * an `XMLClassifier`, a `JsonClassifier`, or a `CsvClassifier`, depending on
 * which field is present).
 */
export declare const updateClassifier: API.OperationMethod<UpdateClassifierRequest, UpdateClassifierResponse, UpdateClassifierError, Credentials | HttpClient.HttpClient>;
export type UpdateColumnStatisticsForPartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates or updates partition statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `UpdatePartition`.
 */
export declare const updateColumnStatisticsForPartition: API.OperationMethod<UpdateColumnStatisticsForPartitionRequest, UpdateColumnStatisticsForPartitionResponse, UpdateColumnStatisticsForPartitionError, Credentials | HttpClient.HttpClient>;
export type UpdateColumnStatisticsForTableError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Creates or updates table statistics of columns.
 *
 * The Identity and Access Management (IAM) permission required for this operation is `UpdateTable`.
 */
export declare const updateColumnStatisticsForTable: API.OperationMethod<UpdateColumnStatisticsForTableRequest, UpdateColumnStatisticsForTableResponse, UpdateColumnStatisticsForTableError, Credentials | HttpClient.HttpClient>;
export type UpdateColumnStatisticsTaskSettingsError = AccessDeniedException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | VersionMismatchException | CommonErrors;
/**
 * Updates settings for a column statistics task.
 */
export declare const updateColumnStatisticsTaskSettings: API.OperationMethod<UpdateColumnStatisticsTaskSettingsRequest, UpdateColumnStatisticsTaskSettingsResponse, UpdateColumnStatisticsTaskSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = EntityNotFoundException | GlueEncryptionException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a connection definition in the Data Catalog.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest, UpdateConnectionResponse, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateCrawlerError = CrawlerRunningException | EntityNotFoundException | InvalidInputException | OperationTimeoutException | VersionMismatchException | GlueRoleNotAssumable | GlueS3TargetNotReady | CommonErrors;
/**
 * Updates a crawler. If a crawler is
 * running, you must stop it using `StopCrawler` before updating
 * it.
 */
export declare const updateCrawler: API.OperationMethod<UpdateCrawlerRequest, UpdateCrawlerResponse, UpdateCrawlerError, Credentials | HttpClient.HttpClient>;
export type UpdateCrawlerScheduleError = EntityNotFoundException | InvalidInputException | OperationTimeoutException | SchedulerTransitioningException | VersionMismatchException | CommonErrors;
/**
 * Updates the schedule of a crawler using a `cron` expression.
 */
export declare const updateCrawlerSchedule: API.OperationMethod<UpdateCrawlerScheduleRequest, UpdateCrawlerScheduleResponse, UpdateCrawlerScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateDatabaseError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing database definition in a Data Catalog.
 */
export declare const updateDatabase: API.OperationMethod<UpdateDatabaseRequest, UpdateDatabaseResponse, UpdateDatabaseError, Credentials | HttpClient.HttpClient>;
export type UpdateDataQualityRulesetError = AlreadyExistsException | EntityNotFoundException | IdempotentParameterMismatchException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Updates the specified data quality ruleset.
 */
export declare const updateDataQualityRuleset: API.OperationMethod<UpdateDataQualityRulesetRequest, UpdateDataQualityRulesetResponse, UpdateDataQualityRulesetError, Credentials | HttpClient.HttpClient>;
export type UpdateDevEndpointError = EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Updates a specified development endpoint.
 */
export declare const updateDevEndpoint: API.OperationMethod<UpdateDevEndpointRequest, UpdateDevEndpointResponse, UpdateDevEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Updates a business glossary in Glue Data Catalog.
 */
export declare const updateGlossary: API.OperationMethod<UpdateGlossaryRequest, UpdateGlossaryResponse, UpdateGlossaryError, Credentials | HttpClient.HttpClient>;
export type UpdateGlossaryTermError = AccessDeniedException | AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | CommonErrors;
/**
 * Updates a glossary term in Glue Data Catalog.
 */
export declare const updateGlossaryTerm: API.OperationMethod<UpdateGlossaryTermRequest, UpdateGlossaryTermResponse, UpdateGlossaryTermError, Credentials | HttpClient.HttpClient>;
export type UpdateGlueIdentityCenterConfigurationError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates the existing Glue Identity Center configuration, allowing modification of scopes and permissions for the integration.
 */
export declare const updateGlueIdentityCenterConfiguration: API.OperationMethod<UpdateGlueIdentityCenterConfigurationRequest, UpdateGlueIdentityCenterConfigurationResponse, UpdateGlueIdentityCenterConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationResourcePropertyError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API can be used for updating the `ResourceProperty` of the Glue connection (for the source) or Glue database ARN (for the target). These properties can include the role to access the connection or database. Since the same resource can be used across multiple integrations, updating resource properties will impact all the integrations using it.
 */
export declare const updateIntegrationResourceProperty: API.OperationMethod<UpdateIntegrationResourcePropertyRequest, UpdateIntegrationResourcePropertyResponse, UpdateIntegrationResourcePropertyError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationTablePropertiesError = AccessDeniedException | EntityNotFoundException | InternalServerException | InternalServiceException | InvalidInputException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This API is used to provide optional override properties for the tables that need to be replicated. These properties can include properties for filtering and partitioning for the source and target tables. To set both source and target properties the same API need to be invoked with the Glue connection ARN as `ResourceArn` with `SourceTableConfig`, and the Glue database ARN as `ResourceArn` with `TargetTableConfig` respectively.
 *
 * The override will be reflected across all the integrations using same `ResourceArn` and source table.
 */
export declare const updateIntegrationTableProperties: API.OperationMethod<UpdateIntegrationTablePropertiesRequest, UpdateIntegrationTablePropertiesResponse, UpdateIntegrationTablePropertiesError, Credentials | HttpClient.HttpClient>;
export type UpdateJobError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | GlueRoleNotAssumable | CommonErrors;
/**
 * Updates an existing job definition. The previous job definition is completely overwritten by this information.
 */
export declare const updateJob: API.OperationMethod<UpdateJobRequest, UpdateJobResponse, UpdateJobError, Credentials | HttpClient.HttpClient>;
export type UpdateJobFromSourceControlError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Synchronizes a job from the source control repository. This operation takes the job artifacts that are located in the remote repository and updates the Glue internal stores with these artifacts.
 *
 * This API supports optional parameters which take in the repository information.
 */
export declare const updateJobFromSourceControl: API.OperationMethod<UpdateJobFromSourceControlRequest, UpdateJobFromSourceControlResponse, UpdateJobFromSourceControlError, Credentials | HttpClient.HttpClient>;
export type UpdateMLTransformError = AccessDeniedException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing machine learning transform. Call this operation to tune the algorithm parameters to achieve better results.
 *
 * After calling this operation, you can call the `StartMLEvaluationTaskRun`
 * operation to assess how well your new parameters achieved your goals (such as improving the
 * quality of your machine learning transform, or making it more cost-effective).
 */
export declare const updateMLTransform: API.OperationMethod<UpdateMLTransformRequest, UpdateMLTransformResponse, UpdateMLTransformError, Credentials | HttpClient.HttpClient>;
export type UpdatePartitionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a partition.
 */
export declare const updatePartition: API.OperationMethod<UpdatePartitionRequest, UpdatePartitionResponse, UpdatePartitionError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Updates an existing registry which is used to hold a collection of schemas. The updated properties relate to the registry, and do not modify any of the schemas within the registry.
 */
export declare const updateRegistry: API.OperationMethod<UpdateRegistryInput, UpdateRegistryResponse, UpdateRegistryError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | CommonErrors;
/**
 * Updates the description, compatibility setting, or version checkpoint for a schema set.
 *
 * For updating the compatibility setting, the call will not validate compatibility for the entire set of schema versions with the new compatibility setting. If the value for `Compatibility` is provided, the `VersionNumber` (a checkpoint) is also required. The API will validate the checkpoint version number for consistency.
 *
 * If the value for the `VersionNumber` (checkpoint) is provided, `Compatibility` is optional and this can be used to set/reset a checkpoint for the schema.
 *
 * This update will happen only if the schema is in the AVAILABLE state.
 */
export declare const updateSchema: API.OperationMethod<UpdateSchemaInput, UpdateSchemaResponse, UpdateSchemaError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceControlFromJobError = AccessDeniedException | AlreadyExistsException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | ValidationException | CommonErrors;
/**
 * Synchronizes a job to the source control repository. This operation takes the job artifacts from the Glue internal stores and makes a commit to the remote repository that is configured on the job.
 *
 * This API supports optional parameters which take in the repository information.
 */
export declare const updateSourceControlFromJob: API.OperationMethod<UpdateSourceControlFromJobRequest, UpdateSourceControlFromJobResponse, UpdateSourceControlFromJobError, Credentials | HttpClient.HttpClient>;
export type UpdateTableError = AlreadyExistsException | ConcurrentModificationException | EntityNotFoundException | FederationSourceException | FederationSourceRetryableException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | ResourceNotReadyException | ResourceNumberLimitExceededException | CommonErrors;
/**
 * Updates a metadata table in the Data Catalog.
 */
export declare const updateTable: API.OperationMethod<UpdateTableRequest, UpdateTableResponse, UpdateTableError, Credentials | HttpClient.HttpClient>;
export type UpdateTableOptimizerError = AccessDeniedException | ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration for an existing table optimizer.
 */
export declare const updateTableOptimizer: API.OperationMethod<UpdateTableOptimizerRequest, UpdateTableOptimizerResponse, UpdateTableOptimizerError, Credentials | HttpClient.HttpClient>;
export type UpdateTriggerError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates a trigger definition.
 *
 * Job arguments may be logged. Do not pass plaintext secrets as arguments. Retrieve secrets from a Glue Connection, Amazon Web Services Secrets Manager or other secret management mechanism if you intend to keep them within the Job.
 */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest, UpdateTriggerResponse, UpdateTriggerError, Credentials | HttpClient.HttpClient>;
export type UpdateUsageProfileError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationNotSupportedException | OperationTimeoutException | CommonErrors;
/**
 * Update an Glue usage profile.
 */
export declare const updateUsageProfile: API.OperationMethod<UpdateUsageProfileRequest, UpdateUsageProfileResponse, UpdateUsageProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateUserDefinedFunctionError = EntityNotFoundException | GlueEncryptionException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing function definition in the Data Catalog.
 */
export declare const updateUserDefinedFunction: API.OperationMethod<UpdateUserDefinedFunctionRequest, UpdateUserDefinedFunctionResponse, UpdateUserDefinedFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowError = ConcurrentModificationException | EntityNotFoundException | InternalServiceException | InvalidInputException | OperationTimeoutException | CommonErrors;
/**
 * Updates an existing workflow.
 */
export declare const updateWorkflow: API.OperationMethod<UpdateWorkflowRequest, UpdateWorkflowResponse, UpdateWorkflowError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=glue.d.ts.map