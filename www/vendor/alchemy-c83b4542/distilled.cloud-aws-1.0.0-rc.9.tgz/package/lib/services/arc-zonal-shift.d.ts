import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly reason: any;
    readonly zonalShiftId: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ZonalShiftId = string;
export interface CancelPracticeRunRequest {
    zonalShiftId: string;
}
export declare const CancelPracticeRunRequest: S.Schema<CancelPracticeRunRequest>;
export type ResourceIdentifier = string;
export type AvailabilityZone = string;
export type ExpiryTime = Date;
export type StartTime = Date;
export type ZonalShiftStatus = "ACTIVE" | "EXPIRED" | "CANCELED" | (string & {});
export declare const ZonalShiftStatus: any;
export type ZonalShiftComment = string;
export interface CancelPracticeRunResponse {
    zonalShiftId: string;
    resourceIdentifier: string;
    awayFrom: string;
    expiryTime: Date;
    startTime: Date;
    status: ZonalShiftStatus;
    comment: string;
}
export declare const CancelPracticeRunResponse: S.Schema<CancelPracticeRunResponse>;
export interface CancelZonalShiftRequest {
    zonalShiftId: string;
}
export declare const CancelZonalShiftRequest: S.Schema<CancelZonalShiftRequest>;
export interface ZonalShift {
    zonalShiftId: string;
    resourceIdentifier: string;
    awayFrom: string;
    expiryTime: Date;
    startTime: Date;
    status: ZonalShiftStatus;
    comment: string;
}
export declare const ZonalShift: S.Schema<ZonalShift>;
export type BlockedWindow = string;
export type BlockedWindows = string[];
export declare const BlockedWindows: any;
export type BlockedDate = string;
export type BlockedDates = string[];
export declare const BlockedDates: any;
export type ControlConditionType = "CLOUDWATCH" | (string & {});
export declare const ControlConditionType: any;
export type MetricIdentifier = string;
export interface ControlCondition {
    type: ControlConditionType;
    alarmIdentifier: string;
}
export declare const ControlCondition: S.Schema<ControlCondition>;
export type BlockingAlarms = ControlCondition[];
export declare const BlockingAlarms: any;
export type AllowedWindow = string;
export type AllowedWindows = string[];
export declare const AllowedWindows: any;
export type OutcomeAlarms = ControlCondition[];
export declare const OutcomeAlarms: any;
export interface CreatePracticeRunConfigurationRequest {
    resourceIdentifier: string;
    blockedWindows?: string[];
    blockedDates?: string[];
    blockingAlarms?: ControlCondition[];
    allowedWindows?: string[];
    outcomeAlarms: ControlCondition[];
}
export declare const CreatePracticeRunConfigurationRequest: S.Schema<CreatePracticeRunConfigurationRequest>;
export type ResourceArn = string;
export type ResourceName = string;
export type ZonalAutoshiftStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const ZonalAutoshiftStatus: any;
export interface PracticeRunConfiguration {
    blockingAlarms?: ControlCondition[];
    outcomeAlarms: ControlCondition[];
    blockedWindows?: string[];
    allowedWindows?: string[];
    blockedDates?: string[];
}
export declare const PracticeRunConfiguration: S.Schema<PracticeRunConfiguration>;
export interface CreatePracticeRunConfigurationResponse {
    arn: string;
    name: string;
    zonalAutoshiftStatus: ZonalAutoshiftStatus;
    practiceRunConfiguration: PracticeRunConfiguration;
}
export declare const CreatePracticeRunConfigurationResponse: S.Schema<CreatePracticeRunConfigurationResponse>;
export interface DeletePracticeRunConfigurationRequest {
    resourceIdentifier: string;
}
export declare const DeletePracticeRunConfigurationRequest: S.Schema<DeletePracticeRunConfigurationRequest>;
export interface DeletePracticeRunConfigurationResponse {
    arn: string;
    name: string;
    zonalAutoshiftStatus: ZonalAutoshiftStatus;
}
export declare const DeletePracticeRunConfigurationResponse: S.Schema<DeletePracticeRunConfigurationResponse>;
export interface GetAutoshiftObserverNotificationStatusRequest {
}
export declare const GetAutoshiftObserverNotificationStatusRequest: S.Schema<GetAutoshiftObserverNotificationStatusRequest>;
export type AutoshiftObserverNotificationStatus = "ENABLED" | "DISABLED" | (string & {});
export declare const AutoshiftObserverNotificationStatus: any;
export interface GetAutoshiftObserverNotificationStatusResponse {
    status: AutoshiftObserverNotificationStatus;
}
export declare const GetAutoshiftObserverNotificationStatusResponse: S.Schema<GetAutoshiftObserverNotificationStatusResponse>;
export interface GetManagedResourceRequest {
    resourceIdentifier: string;
}
export declare const GetManagedResourceRequest: S.Schema<GetManagedResourceRequest>;
export type Weight = number;
export type AppliedWeights = {
    [key: string]: number | undefined;
};
export declare const AppliedWeights: any;
export type AppliedStatus = "APPLIED" | "NOT_APPLIED" | (string & {});
export declare const AppliedStatus: any;
export type ShiftType = "ZONAL_SHIFT" | "PRACTICE_RUN" | "FIS_EXPERIMENT" | "ZONAL_AUTOSHIFT" | (string & {});
export declare const ShiftType: any;
export type PracticeRunOutcome = "FAILED" | "INTERRUPTED" | "PENDING" | "SUCCEEDED" | "CAPACITY_CHECK_FAILED" | (string & {});
export declare const PracticeRunOutcome: any;
export interface ZonalShiftInResource {
    appliedStatus: AppliedStatus;
    zonalShiftId: string;
    resourceIdentifier: string;
    awayFrom: string;
    expiryTime: Date;
    startTime: Date;
    comment: string;
    shiftType?: ShiftType;
    practiceRunOutcome?: PracticeRunOutcome;
}
export declare const ZonalShiftInResource: S.Schema<ZonalShiftInResource>;
export type ZonalShiftsInResource = ZonalShiftInResource[];
export declare const ZonalShiftsInResource: any;
export type AutoshiftAppliedStatus = "APPLIED" | "NOT_APPLIED" | (string & {});
export declare const AutoshiftAppliedStatus: any;
export interface AutoshiftInResource {
    appliedStatus: AutoshiftAppliedStatus;
    awayFrom: string;
    startTime: Date;
}
export declare const AutoshiftInResource: S.Schema<AutoshiftInResource>;
export type AutoshiftsInResource = AutoshiftInResource[];
export declare const AutoshiftsInResource: any;
export interface GetManagedResourceResponse {
    arn?: string;
    name?: string;
    appliedWeights: {
        [key: string]: number | undefined;
    };
    zonalShifts: ZonalShiftInResource[];
    autoshifts?: AutoshiftInResource[];
    practiceRunConfiguration?: PracticeRunConfiguration;
    zonalAutoshiftStatus?: ZonalAutoshiftStatus;
}
export declare const GetManagedResourceResponse: S.Schema<GetManagedResourceResponse>;
export type AutoshiftExecutionStatus = "ACTIVE" | "COMPLETED" | (string & {});
export declare const AutoshiftExecutionStatus: any;
export type MaxResults = number;
export interface ListAutoshiftsRequest {
    nextToken?: string;
    status?: AutoshiftExecutionStatus;
    maxResults?: number;
}
export declare const ListAutoshiftsRequest: S.Schema<ListAutoshiftsRequest>;
export interface AutoshiftSummary {
    awayFrom: string;
    endTime?: Date;
    startTime: Date;
    status: AutoshiftExecutionStatus;
}
export declare const AutoshiftSummary: S.Schema<AutoshiftSummary>;
export type AutoshiftSummaries = AutoshiftSummary[];
export declare const AutoshiftSummaries: any;
export interface ListAutoshiftsResponse {
    items?: AutoshiftSummary[];
    nextToken?: string;
}
export declare const ListAutoshiftsResponse: S.Schema<ListAutoshiftsResponse>;
export interface ListManagedResourcesRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListManagedResourcesRequest: S.Schema<ListManagedResourcesRequest>;
export type AvailabilityZones = string[];
export declare const AvailabilityZones: any;
export interface ManagedResourceSummary {
    arn?: string;
    name?: string;
    availabilityZones: string[];
    appliedWeights?: {
        [key: string]: number | undefined;
    };
    zonalShifts?: ZonalShiftInResource[];
    autoshifts?: AutoshiftInResource[];
    zonalAutoshiftStatus?: ZonalAutoshiftStatus;
    practiceRunStatus?: ZonalAutoshiftStatus;
}
export declare const ManagedResourceSummary: S.Schema<ManagedResourceSummary>;
export type ManagedResourceSummaries = ManagedResourceSummary[];
export declare const ManagedResourceSummaries: any;
export interface ListManagedResourcesResponse {
    items: ManagedResourceSummary[];
    nextToken?: string;
}
export declare const ListManagedResourcesResponse: S.Schema<ListManagedResourcesResponse>;
export interface ListZonalShiftsRequest {
    nextToken?: string;
    status?: ZonalShiftStatus;
    maxResults?: number;
    resourceIdentifier?: string;
}
export declare const ListZonalShiftsRequest: S.Schema<ListZonalShiftsRequest>;
export interface ZonalShiftSummary {
    zonalShiftId: string;
    resourceIdentifier: string;
    awayFrom: string;
    expiryTime: Date;
    startTime: Date;
    status: ZonalShiftStatus;
    comment: string;
    shiftType?: ShiftType;
    practiceRunOutcome?: PracticeRunOutcome;
}
export declare const ZonalShiftSummary: S.Schema<ZonalShiftSummary>;
export type ZonalShiftSummaries = ZonalShiftSummary[];
export declare const ZonalShiftSummaries: any;
export interface ListZonalShiftsResponse {
    items?: ZonalShiftSummary[];
    nextToken?: string;
}
export declare const ListZonalShiftsResponse: S.Schema<ListZonalShiftsResponse>;
export interface StartPracticeRunRequest {
    resourceIdentifier: string;
    awayFrom: string;
    comment: string;
}
export declare const StartPracticeRunRequest: S.Schema<StartPracticeRunRequest>;
export interface StartPracticeRunResponse {
    zonalShiftId: string;
    resourceIdentifier: string;
    awayFrom: string;
    expiryTime: Date;
    startTime: Date;
    status: ZonalShiftStatus;
    comment: string;
}
export declare const StartPracticeRunResponse: S.Schema<StartPracticeRunResponse>;
export type ExpiresIn = string;
export interface StartZonalShiftRequest {
    resourceIdentifier: string;
    awayFrom: string;
    expiresIn: string;
    comment: string;
}
export declare const StartZonalShiftRequest: S.Schema<StartZonalShiftRequest>;
export interface UpdateAutoshiftObserverNotificationStatusRequest {
    status: AutoshiftObserverNotificationStatus;
}
export declare const UpdateAutoshiftObserverNotificationStatusRequest: S.Schema<UpdateAutoshiftObserverNotificationStatusRequest>;
export interface UpdateAutoshiftObserverNotificationStatusResponse {
    status: AutoshiftObserverNotificationStatus;
}
export declare const UpdateAutoshiftObserverNotificationStatusResponse: S.Schema<UpdateAutoshiftObserverNotificationStatusResponse>;
export interface UpdatePracticeRunConfigurationRequest {
    resourceIdentifier: string;
    blockedWindows?: string[];
    blockedDates?: string[];
    blockingAlarms?: ControlCondition[];
    allowedWindows?: string[];
    outcomeAlarms?: ControlCondition[];
}
export declare const UpdatePracticeRunConfigurationRequest: S.Schema<UpdatePracticeRunConfigurationRequest>;
export interface UpdatePracticeRunConfigurationResponse {
    arn: string;
    name: string;
    zonalAutoshiftStatus: ZonalAutoshiftStatus;
    practiceRunConfiguration: PracticeRunConfiguration;
}
export declare const UpdatePracticeRunConfigurationResponse: S.Schema<UpdatePracticeRunConfigurationResponse>;
export interface UpdateZonalAutoshiftConfigurationRequest {
    resourceIdentifier: string;
    zonalAutoshiftStatus: ZonalAutoshiftStatus;
}
export declare const UpdateZonalAutoshiftConfigurationRequest: S.Schema<UpdateZonalAutoshiftConfigurationRequest>;
export interface UpdateZonalAutoshiftConfigurationResponse {
    resourceIdentifier: string;
    zonalAutoshiftStatus: ZonalAutoshiftStatus;
}
export declare const UpdateZonalAutoshiftConfigurationResponse: S.Schema<UpdateZonalAutoshiftConfigurationResponse>;
export interface UpdateZonalShiftRequest {
    zonalShiftId: string;
    comment?: string;
    expiresIn?: string;
}
export declare const UpdateZonalShiftRequest: S.Schema<UpdateZonalShiftRequest>;
export type ConflictExceptionReason = "ZonalShiftAlreadyExists" | "ZonalShiftStatusNotActive" | "SimultaneousZonalShiftsConflict" | "PracticeConfigurationAlreadyExists" | "AutoShiftEnabled" | "PracticeConfigurationDoesNotExist" | "ZonalAutoshiftActive" | "PracticeOutcomeAlarmsRed" | "PracticeBlockingAlarmsRed" | "PracticeInBlockedDates" | "PracticeInBlockedWindows" | "PracticeOutsideAllowedWindows" | (string & {});
export declare const ConflictExceptionReason: any;
export type ValidationExceptionReason = "InvalidExpiresIn" | "InvalidStatus" | "MissingValue" | "InvalidToken" | "InvalidResourceIdentifier" | "InvalidAz" | "UnsupportedAz" | "InvalidAlarmCondition" | "InvalidConditionType" | "InvalidPracticeBlocker" | "FISExperimentUpdateNotAllowed" | "AutoshiftUpdateNotAllowed" | "UnsupportedPracticeCancelShiftType" | "InvalidPracticeAllowedWindow" | "InvalidPracticeWindows" | (string & {});
export declare const ValidationExceptionReason: any;
export type CancelPracticeRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancel an in-progress practice run zonal shift in Amazon Application Recovery Controller.
 */
export declare const cancelPracticeRun: API.OperationMethod<CancelPracticeRunRequest, CancelPracticeRunResponse, CancelPracticeRunError, Credentials | HttpClient.HttpClient>;
export type CancelZonalShiftError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancel a zonal shift in Amazon Application Recovery Controller. To cancel the zonal shift, specify the zonal shift ID.
 *
 * A zonal shift can be one that you've started for a resource in your Amazon Web Services account in an Amazon Web Services Region, or it can be a zonal shift started by a practice run with zonal autoshift.
 */
export declare const cancelZonalShift: API.OperationMethod<CancelZonalShiftRequest, ZonalShift, CancelZonalShiftError, Credentials | HttpClient.HttpClient>;
export type CreatePracticeRunConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A practice run configuration for zonal autoshift is required when you enable zonal autoshift. A practice run configuration includes specifications for blocked dates and blocked time windows, and for Amazon CloudWatch alarms that you create to use with practice runs. The alarms that you specify are an *outcome alarm*, to monitor application health during practice runs and, optionally, a *blocking alarm*, to block practice runs from starting.
 *
 * When a resource has a practice run configuration, ARC starts zonal shifts for the resource weekly, to shift traffic for practice runs. Practice runs help you to ensure that shifting away traffic from an Availability Zone during an autoshift is safe for your application.
 *
 * For more information, see Considerations when you configure zonal autoshift in the Amazon Application Recovery Controller Developer Guide.
 */
export declare const createPracticeRunConfiguration: API.OperationMethod<CreatePracticeRunConfigurationRequest, CreatePracticeRunConfigurationResponse, CreatePracticeRunConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePracticeRunConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the practice run configuration for a resource. Before you can delete a practice run configuration for a resource., you must disable zonal autoshift for the resource. Practice runs must be configured for zonal autoshift to be enabled.
 */
export declare const deletePracticeRunConfiguration: API.OperationMethod<DeletePracticeRunConfigurationRequest, DeletePracticeRunConfigurationResponse, DeletePracticeRunConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAutoshiftObserverNotificationStatusError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Returns the status of the autoshift observer notification. Autoshift observer notifications notify you through Amazon EventBridge when there is an autoshift event for zonal autoshift. The status can be `ENABLED` or `DISABLED`. When `ENABLED`, a notification is sent when an autoshift is triggered. When `DISABLED`, notifications are not sent.
 */
export declare const getAutoshiftObserverNotificationStatus: API.OperationMethod<GetAutoshiftObserverNotificationStatusRequest, GetAutoshiftObserverNotificationStatusResponse, GetAutoshiftObserverNotificationStatusError, Credentials | HttpClient.HttpClient>;
export type GetManagedResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about a resource that's been registered for zonal shifts with Amazon Application Recovery Controller in this Amazon Web Services Region. Resources that are registered for zonal shifts are managed resources in ARC. You can start zonal shifts and configure zonal autoshift for managed resources.
 */
export declare const getManagedResource: API.OperationMethod<GetManagedResourceRequest, GetManagedResourceResponse, GetManagedResourceError, Credentials | HttpClient.HttpClient>;
export type ListAutoshiftsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the autoshifts for an Amazon Web Services Region. By default, the call returns only `ACTIVE` autoshifts. Optionally, you can specify the `status` parameter to return `COMPLETED` autoshifts.
 */
export declare const listAutoshifts: API.PaginatedOperationMethod<ListAutoshiftsRequest, ListAutoshiftsResponse, ListAutoshiftsError, Credentials | HttpClient.HttpClient, AutoshiftSummary>;
export type ListManagedResourcesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the resources in your Amazon Web Services account in this Amazon Web Services Region that are managed for zonal shifts in Amazon Application Recovery Controller, and information about them. The information includes the zonal autoshift status for the resource, as well as the Amazon Resource Name (ARN), the Availability Zones that each resource is deployed in, and the resource name.
 */
export declare const listManagedResources: API.PaginatedOperationMethod<ListManagedResourcesRequest, ListManagedResourcesResponse, ListManagedResourcesError, Credentials | HttpClient.HttpClient, ManagedResourceSummary>;
export type ListZonalShiftsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all active and completed zonal shifts in Amazon Application Recovery Controller in your Amazon Web Services account in this Amazon Web Services Region. `ListZonalShifts` returns customer-initiated zonal shifts, as well as practice run zonal shifts that ARC started on your behalf for zonal autoshift.
 *
 * For more information about listing autoshifts, see ">ListAutoshifts.
 */
export declare const listZonalShifts: API.PaginatedOperationMethod<ListZonalShiftsRequest, ListZonalShiftsResponse, ListZonalShiftsError, Credentials | HttpClient.HttpClient, ZonalShiftSummary>;
export type StartPracticeRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start an on-demand practice run zonal shift in Amazon Application Recovery Controller. With zonal autoshift enabled, you can start an on-demand practice run to verify preparedness at any time. Amazon Web Services also runs automated practice runs about weekly when you have enabled zonal autoshift.
 *
 * For more information, see Considerations when you configure zonal autoshift in the Amazon Application Recovery Controller Developer Guide.
 */
export declare const startPracticeRun: API.OperationMethod<StartPracticeRunRequest, StartPracticeRunResponse, StartPracticeRunError, Credentials | HttpClient.HttpClient>;
export type StartZonalShiftError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * You start a zonal shift to temporarily move load balancer traffic away from an Availability Zone in an Amazon Web Services Region, to help your application recover immediately, for example, from a developer's bad code deployment or from an Amazon Web Services infrastructure failure in a single Availability Zone. You can start a zonal shift in ARC only for managed resources in your Amazon Web Services account in an Amazon Web Services Region. Resources are automatically registered with ARC by Amazon Web Services services.
 *
 * Amazon Application Recovery Controller currently supports enabling the following resources for zonal shift and zonal autoshift:
 *
 * - Amazon EC2 Auto Scaling groups
 *
 * - Amazon Elastic Kubernetes Service
 *
 * - Application Load Balancer
 *
 * - Network Load Balancer
 *
 * When you start a zonal shift, traffic for the resource is no longer routed to the Availability Zone. The zonal shift is created immediately in ARC. However, it can take a short time, typically up to a few minutes, for existing, in-progress connections in the Availability Zone to complete.
 *
 * For more information, see Zonal shift in the Amazon Application Recovery Controller Developer Guide.
 */
export declare const startZonalShift: API.OperationMethod<StartZonalShiftRequest, ZonalShift, StartZonalShiftError, Credentials | HttpClient.HttpClient>;
export type UpdateAutoshiftObserverNotificationStatusError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the status of autoshift observer notification. Autoshift observer notification enables you to be notified, through Amazon EventBridge, when there is an autoshift event for zonal autoshift.
 *
 * If the status is `ENABLED`, ARC includes all autoshift events when you use the EventBridge pattern `Autoshift In Progress`. When the status is `DISABLED`, ARC includes only autoshift events for autoshifts when one or more of your resources is included in the autoshift.
 *
 * For more information, see Notifications for practice runs and autoshifts in the Amazon Application Recovery Controller Developer Guide.
 */
export declare const updateAutoshiftObserverNotificationStatus: API.OperationMethod<UpdateAutoshiftObserverNotificationStatusRequest, UpdateAutoshiftObserverNotificationStatusResponse, UpdateAutoshiftObserverNotificationStatusError, Credentials | HttpClient.HttpClient>;
export type UpdatePracticeRunConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a practice run configuration to change one or more of the following: add, change, or remove the blocking alarm; change the outcome alarm; or add, change, or remove blocking dates or time windows.
 */
export declare const updatePracticeRunConfiguration: API.OperationMethod<UpdatePracticeRunConfigurationRequest, UpdatePracticeRunConfigurationResponse, UpdatePracticeRunConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateZonalAutoshiftConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The zonal autoshift configuration for a resource includes the practice run configuration and the status for running autoshifts, zonal autoshift status. When a resource has a practice run configuration, ARC starts weekly zonal shifts for the resource, to shift traffic away from an Availability Zone. Weekly practice runs help you to make sure that your application can continue to operate normally with the loss of one Availability Zone.
 *
 * You can update the zonal autoshift status to enable or disable zonal autoshift. When zonal autoshift is `ENABLED`, you authorize Amazon Web Services to shift away resource traffic for an application from an Availability Zone during events, on your behalf, to help reduce time to recovery. Traffic is also shifted away for the required weekly practice runs.
 */
export declare const updateZonalAutoshiftConfiguration: API.OperationMethod<UpdateZonalAutoshiftConfigurationRequest, UpdateZonalAutoshiftConfigurationResponse, UpdateZonalAutoshiftConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateZonalShiftError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update an active zonal shift in Amazon Application Recovery Controller in your Amazon Web Services account. You can update a zonal shift to set a new expiration, or edit or replace the comment for the zonal shift.
 */
export declare const updateZonalShift: API.OperationMethod<UpdateZonalShiftRequest, ZonalShift, UpdateZonalShiftError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=arc-zonal-shift.d.ts.map