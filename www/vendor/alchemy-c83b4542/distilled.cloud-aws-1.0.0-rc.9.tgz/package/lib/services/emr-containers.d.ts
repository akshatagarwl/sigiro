import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const EKSRequestThrottledException_base: S.Class<EKSRequestThrottledException, S.TaggedStruct<"EKSRequestThrottledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class EKSRequestThrottledException extends /*@__PURE__*/ EKSRequestThrottledException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidResourceArn_base: S.Class<InvalidResourceArn, S.TaggedStruct<"InvalidResourceArn", {
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidResourceArn extends /*@__PURE__*/ InvalidResourceArn_base {
}
declare const RequestThrottledException_base: S.Class<RequestThrottledException, S.TaggedStruct<"RequestThrottledException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestThrottledException extends /*@__PURE__*/ RequestThrottledException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyRequestsException_base: S.Class<TooManyRequestsException, S.TaggedStruct<"TooManyRequestsException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceIdString = string;
export interface CancelJobRunRequest {
    id: string;
    virtualClusterId: string;
}
export declare const CancelJobRunRequest: S.Schema<CancelJobRunRequest>;
export interface CancelJobRunResponse {
    id?: string;
    virtualClusterId?: string;
}
export declare const CancelJobRunResponse: S.Schema<CancelJobRunResponse>;
export type ResourceNameString = string;
export type ClientToken = string;
export type ParametricIAMRoleArn = string;
export type ParametricReleaseLabel = string;
export type String1024 = string;
export type SensitivePropertiesMap = {
    [key: string]: string | undefined;
};
export declare const SensitivePropertiesMap: any;
export interface Configuration {
    classification: string;
    properties?: {
        [key: string]: string | undefined;
    };
    configurations?: Configuration[];
}
export declare const Configuration: S.Schema<Configuration>;
export type ConfigurationList = Configuration[];
export declare const ConfigurationList: S.Schema<ConfigurationList>;
export type TemplateParameter = string;
export type String256 = string;
export interface ParametricCloudWatchMonitoringConfiguration {
    logGroupName?: string;
    logStreamNamePrefix?: string;
}
export declare const ParametricCloudWatchMonitoringConfiguration: S.Schema<ParametricCloudWatchMonitoringConfiguration>;
export type UriString = string;
export interface ParametricS3MonitoringConfiguration {
    logUri?: string;
}
export declare const ParametricS3MonitoringConfiguration: S.Schema<ParametricS3MonitoringConfiguration>;
export interface ParametricMonitoringConfiguration {
    persistentAppUI?: string;
    cloudWatchMonitoringConfiguration?: ParametricCloudWatchMonitoringConfiguration;
    s3MonitoringConfiguration?: ParametricS3MonitoringConfiguration;
}
export declare const ParametricMonitoringConfiguration: S.Schema<ParametricMonitoringConfiguration>;
export interface ParametricConfigurationOverrides {
    applicationConfiguration?: Configuration[];
    monitoringConfiguration?: ParametricMonitoringConfiguration;
}
export declare const ParametricConfigurationOverrides: S.Schema<ParametricConfigurationOverrides>;
export type EntryPointPath = string | redacted.Redacted<string>;
export type EntryPointArgument = string | redacted.Redacted<string>;
export type EntryPointArguments = (string | redacted.Redacted<string>)[];
export declare const EntryPointArguments: any;
export type SparkSubmitParameters = string | redacted.Redacted<string>;
export interface SparkSubmitJobDriver {
    entryPoint: string | redacted.Redacted<string>;
    entryPointArguments?: (string | redacted.Redacted<string>)[];
    sparkSubmitParameters?: string | redacted.Redacted<string>;
}
export declare const SparkSubmitJobDriver: S.Schema<SparkSubmitJobDriver>;
export type SparkSqlParameters = string | redacted.Redacted<string>;
export interface SparkSqlJobDriver {
    entryPoint?: string | redacted.Redacted<string>;
    sparkSqlParameters?: string | redacted.Redacted<string>;
}
export declare const SparkSqlJobDriver: S.Schema<SparkSqlJobDriver>;
export interface JobDriver {
    sparkSubmitJobDriver?: SparkSubmitJobDriver;
    sparkSqlJobDriver?: SparkSqlJobDriver;
}
export declare const JobDriver: S.Schema<JobDriver>;
export type TemplateParameterName = string;
export type TemplateParameterDataType = "NUMBER" | "STRING" | (string & {});
export declare const TemplateParameterDataType: any;
export interface TemplateParameterConfiguration {
    type?: TemplateParameterDataType;
    defaultValue?: string;
}
export declare const TemplateParameterConfiguration: S.Schema<TemplateParameterConfiguration>;
export type TemplateParameterConfigurationMap = {
    [key: string]: TemplateParameterConfiguration | undefined;
};
export declare const TemplateParameterConfigurationMap: any;
export type String128 = string;
export type StringEmpty256 = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface JobTemplateData {
    executionRoleArn: string;
    releaseLabel: string;
    configurationOverrides?: ParametricConfigurationOverrides;
    jobDriver: JobDriver;
    parameterConfiguration?: {
        [key: string]: TemplateParameterConfiguration | undefined;
    };
    jobTags?: {
        [key: string]: string | undefined;
    };
}
export declare const JobTemplateData: S.Schema<JobTemplateData>;
export type KmsKeyArn = string;
export interface CreateJobTemplateRequest {
    name: string;
    clientToken: string;
    jobTemplateData: JobTemplateData;
    tags?: {
        [key: string]: string | undefined;
    };
    kmsKeyArn?: string;
}
export declare const CreateJobTemplateRequest: S.Schema<CreateJobTemplateRequest>;
export type JobTemplateArn = string;
export interface CreateJobTemplateResponse {
    id?: string;
    name?: string;
    arn?: string;
    createdAt?: Date;
}
export declare const CreateJobTemplateResponse: S.Schema<CreateJobTemplateResponse>;
export type EndpointType = string;
export type ReleaseLabel = string;
export type IAMRoleArn = string;
export type ACMCertArn = string;
export type AllowAWSToRetainLogs = "ENABLED" | "DISABLED" | (string & {});
export declare const AllowAWSToRetainLogs: any;
export interface ManagedLogs {
    allowAWSToRetainLogs?: AllowAWSToRetainLogs;
    encryptionKeyArn?: string;
}
export declare const ManagedLogs: S.Schema<ManagedLogs>;
export type PersistentAppUI = "ENABLED" | "DISABLED" | (string & {});
export declare const PersistentAppUI: any;
export type LogGroupName = string;
export interface CloudWatchMonitoringConfiguration {
    logGroupName: string;
    logStreamNamePrefix?: string;
}
export declare const CloudWatchMonitoringConfiguration: S.Schema<CloudWatchMonitoringConfiguration>;
export interface S3MonitoringConfiguration {
    logUri: string;
    encryptionKeyArn?: string;
}
export declare const S3MonitoringConfiguration: S.Schema<S3MonitoringConfiguration>;
export type RotationSize = string;
export type MaxFilesToKeep = number;
export interface ContainerLogRotationConfiguration {
    rotationSize: string;
    maxFilesToKeep: number;
}
export declare const ContainerLogRotationConfiguration: S.Schema<ContainerLogRotationConfiguration>;
export interface MonitoringConfiguration {
    managedLogs?: ManagedLogs;
    persistentAppUI?: PersistentAppUI;
    cloudWatchMonitoringConfiguration?: CloudWatchMonitoringConfiguration;
    s3MonitoringConfiguration?: S3MonitoringConfiguration;
    containerLogRotationConfiguration?: ContainerLogRotationConfiguration;
}
export declare const MonitoringConfiguration: S.Schema<MonitoringConfiguration>;
export interface ConfigurationOverrides {
    applicationConfiguration?: Configuration[];
    monitoringConfiguration?: MonitoringConfiguration;
}
export declare const ConfigurationOverrides: S.Schema<ConfigurationOverrides>;
export type SessionIdleTimeoutInMinutes = number;
export interface CreateManagedEndpointRequest {
    name: string;
    virtualClusterId: string;
    type: string;
    releaseLabel: string;
    executionRoleArn: string;
    certificateArn?: string;
    configurationOverrides?: ConfigurationOverrides;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    };
    sessionIdleTimeoutInMinutes?: number;
}
export declare const CreateManagedEndpointRequest: S.Schema<CreateManagedEndpointRequest>;
export type EndpointArn = string;
export interface CreateManagedEndpointResponse {
    id?: string;
    name?: string;
    arn?: string;
    virtualClusterId?: string;
}
export declare const CreateManagedEndpointResponse: S.Schema<CreateManagedEndpointResponse>;
export type ContainerProviderType = "EKS" | (string & {});
export declare const ContainerProviderType: any;
export type ClusterId = string;
export type KubernetesNamespace = string;
export type NodeLabelString = string;
export interface EksInfo {
    namespace?: string;
    nodeLabel?: string;
}
export declare const EksInfo: S.Schema<EksInfo>;
export type ContainerInfo = {
    eksInfo: EksInfo;
};
export declare const ContainerInfo: any;
export interface ContainerProvider {
    type: ContainerProviderType;
    id: string;
    info?: ContainerInfo;
}
export declare const ContainerProvider: S.Schema<ContainerProvider>;
export type SessionTagValue = string;
export interface SecureNamespaceInfo {
    clusterId?: string;
    namespace?: string;
}
export declare const SecureNamespaceInfo: S.Schema<SecureNamespaceInfo>;
export interface LakeFormationConfiguration {
    authorizedSessionTagValue?: string;
    secureNamespaceInfo?: SecureNamespaceInfo;
    queryEngineRoleArn?: string;
}
export declare const LakeFormationConfiguration: S.Schema<LakeFormationConfiguration>;
export type CertificateProviderType = "PEM" | (string & {});
export declare const CertificateProviderType: any;
export type SecretsManagerArn = string;
export interface TLSCertificateConfiguration {
    certificateProviderType?: CertificateProviderType;
    publicCertificateSecretArn?: string;
    privateCertificateSecretArn?: string;
}
export declare const TLSCertificateConfiguration: S.Schema<TLSCertificateConfiguration>;
export interface InTransitEncryptionConfiguration {
    tlsCertificateConfiguration?: TLSCertificateConfiguration;
}
export declare const InTransitEncryptionConfiguration: S.Schema<InTransitEncryptionConfiguration>;
export interface EncryptionConfiguration {
    inTransitEncryptionConfiguration?: InTransitEncryptionConfiguration;
}
export declare const EncryptionConfiguration: S.Schema<EncryptionConfiguration>;
export interface AuthorizationConfiguration {
    lakeFormationConfiguration?: LakeFormationConfiguration;
    encryptionConfiguration?: EncryptionConfiguration;
}
export declare const AuthorizationConfiguration: S.Schema<AuthorizationConfiguration>;
export type IdentityCenterInstanceARN = string;
export type EmrIdentityCenterApplicationARN = string;
export interface IdentityCenterConfiguration {
    enableIdentityCenter?: boolean;
    identityCenterApplicationAssignmentRequired?: boolean;
    identityCenterInstanceARN?: string;
    emrIdentityCenterApplicationARN?: string;
}
export declare const IdentityCenterConfiguration: S.Schema<IdentityCenterConfiguration>;
export interface IAMConfiguration {
    systemRole?: string;
}
export declare const IAMConfiguration: S.Schema<IAMConfiguration>;
export interface AuthenticationConfiguration {
    identityCenterConfiguration?: IdentityCenterConfiguration;
    iamConfiguration?: IAMConfiguration;
}
export declare const AuthenticationConfiguration: S.Schema<AuthenticationConfiguration>;
export interface SecurityConfigurationData {
    authorizationConfiguration?: AuthorizationConfiguration;
    authenticationConfiguration?: AuthenticationConfiguration;
}
export declare const SecurityConfigurationData: S.Schema<SecurityConfigurationData>;
export interface CreateSecurityConfigurationRequest {
    clientToken: string;
    name: string;
    containerProvider?: ContainerProvider;
    securityConfigurationData: SecurityConfigurationData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateSecurityConfigurationRequest: S.Schema<CreateSecurityConfigurationRequest>;
export type SecurityConfigurationArn = string;
export interface CreateSecurityConfigurationResponse {
    id?: string;
    name?: string;
    arn?: string;
}
export declare const CreateSecurityConfigurationResponse: S.Schema<CreateSecurityConfigurationResponse>;
export type InQueueJobLimitInteger = number;
export type JobLimitInteger = number;
export interface SchedulerConfiguration {
    maxInQueueJobRuns?: number;
    maxConcurrentJobRuns?: number;
}
export declare const SchedulerConfiguration: S.Schema<SchedulerConfiguration>;
export interface CreateVirtualClusterRequest {
    name: string;
    containerProvider: ContainerProvider;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    };
    securityConfigurationId?: string;
    sessionEnabled?: boolean;
    schedulerConfiguration?: SchedulerConfiguration;
}
export declare const CreateVirtualClusterRequest: S.Schema<CreateVirtualClusterRequest>;
export type VirtualClusterArn = string;
export interface CreateVirtualClusterResponse {
    id?: string;
    name?: string;
    arn?: string;
}
export declare const CreateVirtualClusterResponse: S.Schema<CreateVirtualClusterResponse>;
export interface DeleteJobTemplateRequest {
    id: string;
}
export declare const DeleteJobTemplateRequest: S.Schema<DeleteJobTemplateRequest>;
export interface DeleteJobTemplateResponse {
    id?: string;
}
export declare const DeleteJobTemplateResponse: S.Schema<DeleteJobTemplateResponse>;
export interface DeleteManagedEndpointRequest {
    id: string;
    virtualClusterId: string;
}
export declare const DeleteManagedEndpointRequest: S.Schema<DeleteManagedEndpointRequest>;
export interface DeleteManagedEndpointResponse {
    id?: string;
    virtualClusterId?: string;
}
export declare const DeleteManagedEndpointResponse: S.Schema<DeleteManagedEndpointResponse>;
export interface DeleteSecurityConfigurationRequest {
    id: string;
}
export declare const DeleteSecurityConfigurationRequest: S.Schema<DeleteSecurityConfigurationRequest>;
export interface DeleteSecurityConfigurationResponse {
    id?: string;
}
export declare const DeleteSecurityConfigurationResponse: S.Schema<DeleteSecurityConfigurationResponse>;
export interface DeleteVirtualClusterRequest {
    id: string;
}
export declare const DeleteVirtualClusterRequest: S.Schema<DeleteVirtualClusterRequest>;
export interface DeleteVirtualClusterResponse {
    id?: string;
}
export declare const DeleteVirtualClusterResponse: S.Schema<DeleteVirtualClusterResponse>;
export interface DescribeJobRunRequest {
    id: string;
    virtualClusterId: string;
}
export declare const DescribeJobRunRequest: S.Schema<DescribeJobRunRequest>;
export type JobArn = string;
export type JobRunState = "PENDING" | "SUBMITTED" | "RUNNING" | "FAILED" | "CANCELLED" | "CANCEL_PENDING" | "COMPLETED" | (string & {});
export declare const JobRunState: any;
export type RequestIdentityUserArn = string;
export type FailureReason = "INTERNAL_ERROR" | "USER_ERROR" | "VALIDATION_ERROR" | "CLUSTER_UNAVAILABLE" | (string & {});
export declare const FailureReason: any;
export type JavaInteger = number;
export interface RetryPolicyConfiguration {
    maxAttempts: number;
}
export declare const RetryPolicyConfiguration: S.Schema<RetryPolicyConfiguration>;
export interface RetryPolicyExecution {
    currentAttemptCount: number;
}
export declare const RetryPolicyExecution: S.Schema<RetryPolicyExecution>;
export interface JobRun {
    id?: string;
    name?: string;
    virtualClusterId?: string;
    arn?: string;
    state?: JobRunState;
    clientToken?: string;
    executionRoleArn?: string;
    releaseLabel?: string;
    configurationOverrides?: ConfigurationOverrides;
    jobDriver?: JobDriver;
    createdAt?: Date;
    createdBy?: string;
    finishedAt?: Date;
    stateDetails?: string;
    failureReason?: FailureReason;
    tags?: {
        [key: string]: string | undefined;
    };
    retryPolicyConfiguration?: RetryPolicyConfiguration;
    retryPolicyExecution?: RetryPolicyExecution;
}
export declare const JobRun: S.Schema<JobRun>;
export interface DescribeJobRunResponse {
    jobRun?: JobRun;
}
export declare const DescribeJobRunResponse: S.Schema<DescribeJobRunResponse>;
export interface DescribeJobTemplateRequest {
    id: string;
}
export declare const DescribeJobTemplateRequest: S.Schema<DescribeJobTemplateRequest>;
export type String2048 = string;
export interface JobTemplate {
    name?: string;
    id?: string;
    arn?: string;
    createdAt?: Date;
    createdBy?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    jobTemplateData: JobTemplateData;
    kmsKeyArn?: string;
    decryptionError?: string;
}
export declare const JobTemplate: S.Schema<JobTemplate>;
export interface DescribeJobTemplateResponse {
    jobTemplate?: JobTemplate;
}
export declare const DescribeJobTemplateResponse: S.Schema<DescribeJobTemplateResponse>;
export interface DescribeManagedEndpointRequest {
    id: string;
    virtualClusterId: string;
}
export declare const DescribeManagedEndpointRequest: S.Schema<DescribeManagedEndpointRequest>;
export type EndpointState = "CREATING" | "ACTIVE" | "TERMINATING" | "TERMINATED" | "TERMINATED_WITH_ERRORS" | (string & {});
export declare const EndpointState: any;
export type Base64Encoded = string;
export interface Certificate {
    certificateArn?: string;
    certificateData?: string;
}
export declare const Certificate: S.Schema<Certificate>;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export interface Endpoint {
    id?: string;
    name?: string;
    arn?: string;
    virtualClusterId?: string;
    type?: string;
    state?: EndpointState;
    releaseLabel?: string;
    executionRoleArn?: string;
    certificateArn?: string;
    certificateAuthority?: Certificate;
    configurationOverrides?: ConfigurationOverrides;
    serverUrl?: string;
    authProxyUrl?: string;
    createdAt?: Date;
    securityGroup?: string;
    subnetIds?: string[];
    stateDetails?: string;
    failureReason?: FailureReason;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const Endpoint: S.Schema<Endpoint>;
export interface DescribeManagedEndpointResponse {
    endpoint?: Endpoint;
}
export declare const DescribeManagedEndpointResponse: S.Schema<DescribeManagedEndpointResponse>;
export interface DescribeSecurityConfigurationRequest {
    id: string;
}
export declare const DescribeSecurityConfigurationRequest: S.Schema<DescribeSecurityConfigurationRequest>;
export interface SecurityConfiguration {
    id?: string;
    name?: string;
    arn?: string;
    createdAt?: Date;
    createdBy?: string;
    securityConfigurationData?: SecurityConfigurationData;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const SecurityConfiguration: S.Schema<SecurityConfiguration>;
export interface DescribeSecurityConfigurationResponse {
    securityConfiguration?: SecurityConfiguration;
}
export declare const DescribeSecurityConfigurationResponse: S.Schema<DescribeSecurityConfigurationResponse>;
export interface DescribeVirtualClusterRequest {
    id: string;
}
export declare const DescribeVirtualClusterRequest: S.Schema<DescribeVirtualClusterRequest>;
export type VirtualClusterState = "RUNNING" | "TERMINATING" | "TERMINATED" | "ARRESTED" | (string & {});
export declare const VirtualClusterState: any;
export type NonNegativeInteger = number;
export interface SchedulerStatus {
    currentInQueueJobRuns?: number;
    currentConcurrentJobRuns?: number;
}
export declare const SchedulerStatus: S.Schema<SchedulerStatus>;
export interface VirtualCluster {
    id?: string;
    name?: string;
    arn?: string;
    state?: VirtualClusterState;
    containerProvider?: ContainerProvider;
    createdAt?: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    securityConfigurationId?: string;
    sessionEnabled?: boolean;
    schedulerConfiguration?: SchedulerConfiguration;
    schedulerStatus?: SchedulerStatus;
}
export declare const VirtualCluster: S.Schema<VirtualCluster>;
export interface DescribeVirtualClusterResponse {
    virtualCluster?: VirtualCluster;
}
export declare const DescribeVirtualClusterResponse: S.Schema<DescribeVirtualClusterResponse>;
export type CredentialType = string;
export type LogContext = string;
export interface GetManagedEndpointSessionCredentialsRequest {
    endpointIdentifier: string;
    virtualClusterIdentifier: string;
    executionRoleArn: string;
    credentialType: string;
    durationInSeconds?: number;
    logContext?: string;
    clientToken?: string;
}
export declare const GetManagedEndpointSessionCredentialsRequest: S.Schema<GetManagedEndpointSessionCredentialsRequest>;
export type Token = string | redacted.Redacted<string>;
export type Credentials = {
    token: string | redacted.Redacted<string>;
};
export declare const Credentials: any;
export interface GetManagedEndpointSessionCredentialsResponse {
    id?: string;
    credentials?: Credentials;
    endpointCredentials?: Credentials;
    expiresAt?: Date;
}
export declare const GetManagedEndpointSessionCredentialsResponse: S.Schema<GetManagedEndpointSessionCredentialsResponse>;
export type JobRunStates = JobRunState[];
export declare const JobRunStates: any;
export type NextToken = string;
export interface ListJobRunsRequest {
    virtualClusterId: string;
    createdBefore?: Date;
    createdAfter?: Date;
    name?: string;
    states?: JobRunState[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListJobRunsRequest: S.Schema<ListJobRunsRequest>;
export type JobRuns = JobRun[];
export declare const JobRuns: any;
export interface ListJobRunsResponse {
    jobRuns?: JobRun[];
    nextToken?: string;
}
export declare const ListJobRunsResponse: S.Schema<ListJobRunsResponse>;
export interface ListJobTemplatesRequest {
    createdAfter?: Date;
    createdBefore?: Date;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListJobTemplatesRequest: S.Schema<ListJobTemplatesRequest>;
export type JobTemplates = JobTemplate[];
export declare const JobTemplates: any;
export interface ListJobTemplatesResponse {
    templates?: JobTemplate[];
    nextToken?: string;
}
export declare const ListJobTemplatesResponse: S.Schema<ListJobTemplatesResponse>;
export type EndpointTypes = string[];
export declare const EndpointTypes: any;
export type EndpointStates = EndpointState[];
export declare const EndpointStates: any;
export interface ListManagedEndpointsRequest {
    virtualClusterId: string;
    createdBefore?: Date;
    createdAfter?: Date;
    types?: string[];
    states?: EndpointState[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListManagedEndpointsRequest: S.Schema<ListManagedEndpointsRequest>;
export type Endpoints = Endpoint[];
export declare const Endpoints: any;
export interface ListManagedEndpointsResponse {
    endpoints?: Endpoint[];
    nextToken?: string;
}
export declare const ListManagedEndpointsResponse: S.Schema<ListManagedEndpointsResponse>;
export interface ListSecurityConfigurationsRequest {
    createdAfter?: Date;
    createdBefore?: Date;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListSecurityConfigurationsRequest: S.Schema<ListSecurityConfigurationsRequest>;
export type SecurityConfigurations = SecurityConfiguration[];
export declare const SecurityConfigurations: any;
export interface ListSecurityConfigurationsResponse {
    securityConfigurations?: SecurityConfiguration[];
    nextToken?: string;
}
export declare const ListSecurityConfigurationsResponse: S.Schema<ListSecurityConfigurationsResponse>;
export type RsiArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export type VirtualClusterStates = VirtualClusterState[];
export declare const VirtualClusterStates: any;
export interface ListVirtualClustersRequest {
    containerProviderId?: string;
    containerProviderType?: ContainerProviderType;
    createdAfter?: Date;
    createdBefore?: Date;
    states?: VirtualClusterState[];
    maxResults?: number;
    nextToken?: string;
    eksAccessEntryIntegrated?: boolean;
}
export declare const ListVirtualClustersRequest: S.Schema<ListVirtualClustersRequest>;
export type VirtualClusters = VirtualCluster[];
export declare const VirtualClusters: any;
export interface ListVirtualClustersResponse {
    virtualClusters?: VirtualCluster[];
    nextToken?: string;
}
export declare const ListVirtualClustersResponse: S.Schema<ListVirtualClustersResponse>;
export type TemplateParameterInputMap = {
    [key: string]: string | undefined;
};
export declare const TemplateParameterInputMap: any;
export interface StartJobRunRequest {
    name?: string;
    virtualClusterId: string;
    clientToken: string;
    executionRoleArn?: string;
    releaseLabel?: string;
    jobDriver?: JobDriver;
    configurationOverrides?: ConfigurationOverrides;
    tags?: {
        [key: string]: string | undefined;
    };
    jobTemplateId?: string;
    jobTemplateParameters?: {
        [key: string]: string | undefined;
    };
    retryPolicyConfiguration?: RetryPolicyConfiguration;
}
export declare const StartJobRunRequest: S.Schema<StartJobRunRequest>;
export interface StartJobRunResponse {
    id?: string;
    name?: string;
    arn?: string;
    virtualClusterId?: string;
}
export declare const StartJobRunResponse: S.Schema<StartJobRunResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateVirtualClusterRequest {
    id: string;
    schedulerConfiguration?: SchedulerConfiguration;
    clientToken: string;
}
export declare const UpdateVirtualClusterRequest: S.Schema<UpdateVirtualClusterRequest>;
export interface UpdateVirtualClusterResponse {
    virtualCluster?: VirtualCluster;
}
export declare const UpdateVirtualClusterResponse: S.Schema<UpdateVirtualClusterResponse>;
export type CancelJobRunError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Cancels a job run. A job run is a unit of work, such as a Spark jar, PySpark script, or
 * SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const cancelJobRun: API.OperationMethod<CancelJobRunRequest, CancelJobRunResponse, CancelJobRunError, Creds | HttpClient.HttpClient>;
export type CreateJobTemplateError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a job template. Job template stores values of StartJobRun API request in a
 * template and can be used to start a job run. Job template allows two use cases: avoid
 * repeating recurring StartJobRun API request values, enforcing certain values in StartJobRun
 * API request.
 */
export declare const createJobTemplate: API.OperationMethod<CreateJobTemplateRequest, CreateJobTemplateResponse, CreateJobTemplateError, Creds | HttpClient.HttpClient>;
export type CreateManagedEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a managed endpoint. A managed endpoint is a gateway that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can
 * communicate with your virtual cluster.
 */
export declare const createManagedEndpoint: API.OperationMethod<CreateManagedEndpointRequest, CreateManagedEndpointResponse, CreateManagedEndpointError, Creds | HttpClient.HttpClient>;
export type CreateSecurityConfigurationError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a security configuration. Security configurations in Amazon EMR on EKS are
 * templates for different security setups. You can use security configurations to configure
 * the Lake Formation integration setup. You can also create a security configuration
 * to re-use a security setup each time you create a virtual cluster.
 */
export declare const createSecurityConfiguration: API.OperationMethod<CreateSecurityConfigurationRequest, CreateSecurityConfigurationResponse, CreateSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type CreateVirtualClusterError = EKSRequestThrottledException | InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const createVirtualCluster: API.OperationMethod<CreateVirtualClusterRequest, CreateVirtualClusterResponse, CreateVirtualClusterError, Creds | HttpClient.HttpClient>;
export type DeleteJobTemplateError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a job template. Job template stores values of StartJobRun API request in a
 * template and can be used to start a job run. Job template allows two use cases: avoid
 * repeating recurring StartJobRun API request values, enforcing certain values in StartJobRun
 * API request.
 */
export declare const deleteJobTemplate: API.OperationMethod<DeleteJobTemplateRequest, DeleteJobTemplateResponse, DeleteJobTemplateError, Creds | HttpClient.HttpClient>;
export type DeleteManagedEndpointError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a managed endpoint. A managed endpoint is a gateway that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can
 * communicate with your virtual cluster.
 */
export declare const deleteManagedEndpoint: API.OperationMethod<DeleteManagedEndpointRequest, DeleteManagedEndpointResponse, DeleteManagedEndpointError, Creds | HttpClient.HttpClient>;
export type DeleteSecurityConfigurationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Deletes a security configuration.
 */
export declare const deleteSecurityConfiguration: API.OperationMethod<DeleteSecurityConfigurationRequest, DeleteSecurityConfigurationResponse, DeleteSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DeleteVirtualClusterError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const deleteVirtualCluster: API.OperationMethod<DeleteVirtualClusterRequest, DeleteVirtualClusterResponse, DeleteVirtualClusterError, Creds | HttpClient.HttpClient>;
export type DescribeJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a job run. A job run is a unit of work, such as a
 * Spark jar, PySpark script, or SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const describeJobRun: API.OperationMethod<DescribeJobRunRequest, DescribeJobRunResponse, DescribeJobRunError, Creds | HttpClient.HttpClient>;
export type DescribeJobTemplateError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified job template. Job template stores values
 * of StartJobRun API request in a template and can be used to start a job run. Job template
 * allows two use cases: avoid repeating recurring StartJobRun API request values, enforcing
 * certain values in StartJobRun API request.
 */
export declare const describeJobTemplate: API.OperationMethod<DescribeJobTemplateRequest, DescribeJobTemplateResponse, DescribeJobTemplateError, Creds | HttpClient.HttpClient>;
export type DescribeManagedEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a managed endpoint. A managed endpoint is a gateway
 * that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can communicate with your virtual cluster.
 */
export declare const describeManagedEndpoint: API.OperationMethod<DescribeManagedEndpointRequest, DescribeManagedEndpointResponse, DescribeManagedEndpointError, Creds | HttpClient.HttpClient>;
export type DescribeSecurityConfigurationError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified security configuration. Security
 * configurations in Amazon EMR on EKS are templates for different security setups. You
 * can use security configurations to configure the Lake Formation integration setup.
 * You can also create a security configuration to re-use a security setup each time you
 * create a virtual cluster.
 */
export declare const describeSecurityConfiguration: API.OperationMethod<DescribeSecurityConfigurationRequest, DescribeSecurityConfigurationResponse, DescribeSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DescribeVirtualClusterError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified virtual cluster. Virtual cluster is a
 * managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual
 * clusters. They do not consume any additional resource in your system. A single virtual
 * cluster maps to a single Kubernetes namespace. Given this relationship, you can model
 * virtual clusters the same way you model Kubernetes namespaces to meet your
 * requirements.
 */
export declare const describeVirtualCluster: API.OperationMethod<DescribeVirtualClusterRequest, DescribeVirtualClusterResponse, DescribeVirtualClusterError, Creds | HttpClient.HttpClient>;
export type GetManagedEndpointSessionCredentialsError = InternalServerException | RequestThrottledException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Generate a session token to connect to a managed endpoint.
 */
export declare const getManagedEndpointSessionCredentials: API.OperationMethod<GetManagedEndpointSessionCredentialsRequest, GetManagedEndpointSessionCredentialsResponse, GetManagedEndpointSessionCredentialsError, Creds | HttpClient.HttpClient>;
export type ListJobRunsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists job runs based on a set of parameters. A job run is a unit of work, such as a
 * Spark jar, PySpark script, or SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsRequest, ListJobRunsResponse, ListJobRunsError, Creds | HttpClient.HttpClient, JobRun>;
export type ListJobTemplatesError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists job templates based on a set of parameters. Job template stores values of
 * StartJobRun API request in a template and can be used to start a job run. Job template
 * allows two use cases: avoid repeating recurring StartJobRun API request values, enforcing
 * certain values in StartJobRun API request.
 */
export declare const listJobTemplates: API.PaginatedOperationMethod<ListJobTemplatesRequest, ListJobTemplatesResponse, ListJobTemplatesError, Creds | HttpClient.HttpClient, JobTemplate>;
export type ListManagedEndpointsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists managed endpoints based on a set of parameters. A managed endpoint is a gateway
 * that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can communicate with your virtual cluster.
 */
export declare const listManagedEndpoints: API.PaginatedOperationMethod<ListManagedEndpointsRequest, ListManagedEndpointsResponse, ListManagedEndpointsError, Creds | HttpClient.HttpClient, Endpoint>;
export type ListSecurityConfigurationsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists security configurations based on a set of parameters. Security configurations in
 * Amazon EMR on EKS are templates for different security setups. You can use security
 * configurations to configure the Lake Formation integration setup. You can also
 * create a security configuration to re-use a security setup each time you create a virtual
 * cluster.
 */
export declare const listSecurityConfigurations: API.PaginatedOperationMethod<ListSecurityConfigurationsRequest, ListSecurityConfigurationsResponse, ListSecurityConfigurationsError, Creds | HttpClient.HttpClient, SecurityConfiguration>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags assigned to the resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Creds | HttpClient.HttpClient>;
export type ListVirtualClustersError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists information about the specified virtual cluster. Virtual cluster is a managed
 * entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual
 * clusters. They do not consume any additional resource in your system. A single virtual
 * cluster maps to a single Kubernetes namespace. Given this relationship, you can model
 * virtual clusters the same way you model Kubernetes namespaces to meet your
 * requirements.
 */
export declare const listVirtualClusters: API.PaginatedOperationMethod<ListVirtualClustersRequest, ListVirtualClustersResponse, ListVirtualClustersError, Creds | HttpClient.HttpClient, VirtualCluster>;
export type StartJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Starts a job run. A job run is a unit of work, such as a Spark jar, PySpark script, or
 * SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest, StartJobRunResponse, StartJobRunError, Creds | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | InvalidResourceArn | CommonErrors;
/**
 * Assigns tags to resources. A tag is a label that you assign to an Amazon Web Services
 * resource. Each tag consists of a key and an optional value, both of which you define. Tags
 * enable you to categorize your Amazon Web Services resources by attributes such as purpose,
 * owner, or environment. When you have many resources of the same type, you can quickly
 * identify a specific resource based on the tags you've assigned to it. For example, you can
 * define a set of tags for your Amazon EMR on EKS clusters to help you track each
 * cluster's owner and stack level. We recommend that you devise a consistent set of tag keys
 * for each resource type. You can then search and filter the resources based on the tags that
 * you add.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Creds | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | InvalidResourceArn | CommonErrors;
/**
 * Removes tags from resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Creds | HttpClient.HttpClient>;
export type UpdateVirtualClusterError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const updateVirtualCluster: API.OperationMethod<UpdateVirtualClusterRequest, UpdateVirtualClusterResponse, UpdateVirtualClusterError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=emr-containers.d.ts.map