import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationId = string;
export type JobRunId = string;
export type ShutdownGracePeriodInSeconds = number;
export interface CancelJobRunRequest {
    applicationId: string;
    jobRunId: string;
    shutdownGracePeriodInSeconds?: number;
}
export declare const CancelJobRunRequest: S.Schema<CancelJobRunRequest>;
export interface CancelJobRunResponse {
    applicationId: string;
    jobRunId: string;
}
export declare const CancelJobRunResponse: S.Schema<CancelJobRunResponse>;
export type ApplicationName = string;
export type ReleaseLabel = string;
export type EngineType = string;
export type ClientToken = string;
export type WorkerTypeString = string;
export type WorkerCounts = number;
export type CpuSize = string;
export type MemorySize = string;
export type DiskSize = string;
export type DiskType = string;
export interface WorkerResourceConfig {
    cpu: string;
    memory: string;
    disk?: string;
    diskType?: string;
}
export declare const WorkerResourceConfig: S.Schema<WorkerResourceConfig>;
export interface InitialCapacityConfig {
    workerCount: number;
    workerConfiguration?: WorkerResourceConfig;
}
export declare const InitialCapacityConfig: S.Schema<InitialCapacityConfig>;
export type InitialCapacityConfigMap = {
    [key: string]: InitialCapacityConfig | undefined;
};
export declare const InitialCapacityConfigMap: any;
export interface MaximumAllowedResources {
    cpu: string;
    memory: string;
    disk?: string;
}
export declare const MaximumAllowedResources: S.Schema<MaximumAllowedResources>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface AutoStartConfig {
    enabled?: boolean;
}
export declare const AutoStartConfig: S.Schema<AutoStartConfig>;
export interface AutoStopConfig {
    enabled?: boolean;
    idleTimeoutMinutes?: number;
}
export declare const AutoStopConfig: S.Schema<AutoStopConfig>;
export type SubnetString = string;
export type SubnetIds = string[];
export declare const SubnetIds: any;
export type SecurityGroupString = string;
export type SecurityGroupIds = string[];
export declare const SecurityGroupIds: any;
export interface NetworkConfiguration {
    subnetIds?: string[];
    securityGroupIds?: string[];
}
export declare const NetworkConfiguration: S.Schema<NetworkConfiguration>;
export type Architecture = string;
export type ImageUri = string;
export interface ImageConfigurationInput {
    imageUri?: string;
    applicationLevelDigestResolution?: boolean;
}
export declare const ImageConfigurationInput: S.Schema<ImageConfigurationInput>;
export interface WorkerTypeSpecificationInput {
    imageConfiguration?: ImageConfigurationInput;
}
export declare const WorkerTypeSpecificationInput: S.Schema<WorkerTypeSpecificationInput>;
export type WorkerTypeSpecificationInputMap = {
    [key: string]: WorkerTypeSpecificationInput | undefined;
};
export declare const WorkerTypeSpecificationInputMap: any;
export type String1024 = string;
export type ConfigurationPropertyKey = string;
export type ConfigurationPropertyValue = string;
export type SensitivePropertiesMap = {
    [key: string]: string | undefined;
};
export declare const SensitivePropertiesMap: any;
export interface Configuration {
    classification: string;
    properties?: {
        [key: string]: string | undefined;
    };
    configurations?: Configuration[];
}
export declare const Configuration: S.Schema<Configuration>;
export type ConfigurationList = Configuration[];
export declare const ConfigurationList: S.Schema<ConfigurationList>;
export type UriString = string;
export type EncryptionKeyArn = string;
export interface S3MonitoringConfiguration {
    logUri?: string;
    encryptionKeyArn?: string;
}
export declare const S3MonitoringConfiguration: S.Schema<S3MonitoringConfiguration>;
export interface ManagedPersistenceMonitoringConfiguration {
    enabled?: boolean;
    encryptionKeyArn?: string;
}
export declare const ManagedPersistenceMonitoringConfiguration: S.Schema<ManagedPersistenceMonitoringConfiguration>;
export type LogGroupName = string;
export type LogStreamNamePrefix = string;
export type LogTypeString = string;
export type LogTypeList = string[];
export declare const LogTypeList: any;
export type LogTypeMap = {
    [key: string]: string[] | undefined;
};
export declare const LogTypeMap: any;
export interface CloudWatchLoggingConfiguration {
    enabled: boolean;
    logGroupName?: string;
    logStreamNamePrefix?: string;
    encryptionKeyArn?: string;
    logTypes?: {
        [key: string]: string[] | undefined;
    };
}
export declare const CloudWatchLoggingConfiguration: S.Schema<CloudWatchLoggingConfiguration>;
export type PrometheusUrlString = string;
export interface PrometheusMonitoringConfiguration {
    remoteWriteUrl?: string;
}
export declare const PrometheusMonitoringConfiguration: S.Schema<PrometheusMonitoringConfiguration>;
export interface MonitoringConfiguration {
    s3MonitoringConfiguration?: S3MonitoringConfiguration;
    managedPersistenceMonitoringConfiguration?: ManagedPersistenceMonitoringConfiguration;
    cloudWatchLoggingConfiguration?: CloudWatchLoggingConfiguration;
    prometheusMonitoringConfiguration?: PrometheusMonitoringConfiguration;
}
export declare const MonitoringConfiguration: S.Schema<MonitoringConfiguration>;
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type EncryptionContext = {
    [key: string]: string | undefined;
};
export declare const EncryptionContext: any;
export interface DiskEncryptionConfiguration {
    encryptionContext?: {
        [key: string]: string | undefined;
    };
    encryptionKeyArn?: string;
}
export declare const DiskEncryptionConfiguration: S.Schema<DiskEncryptionConfiguration>;
export interface InteractiveConfiguration {
    studioEnabled?: boolean;
    livyEndpointEnabled?: boolean;
    sessionEnabled?: boolean;
}
export declare const InteractiveConfiguration: S.Schema<InteractiveConfiguration>;
export interface SchedulerConfiguration {
    queueTimeoutMinutes?: number;
    maxConcurrentRuns?: number;
}
export declare const SchedulerConfiguration: S.Schema<SchedulerConfiguration>;
export type IdentityCenterInstanceArn = string;
export interface IdentityCenterConfigurationInput {
    identityCenterInstanceArn?: string;
    userBackgroundSessionsEnabled?: boolean;
}
export declare const IdentityCenterConfigurationInput: S.Schema<IdentityCenterConfigurationInput>;
export interface JobLevelCostAllocationConfiguration {
    enabled?: boolean;
}
export declare const JobLevelCostAllocationConfiguration: S.Schema<JobLevelCostAllocationConfiguration>;
export interface CreateApplicationRequest {
    name?: string;
    releaseLabel: string;
    type: string;
    clientToken: string;
    initialCapacity?: {
        [key: string]: InitialCapacityConfig | undefined;
    };
    maximumCapacity?: MaximumAllowedResources;
    tags?: {
        [key: string]: string | undefined;
    };
    autoStartConfiguration?: AutoStartConfig;
    autoStopConfiguration?: AutoStopConfig;
    networkConfiguration?: NetworkConfiguration;
    architecture?: string;
    imageConfiguration?: ImageConfigurationInput;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecificationInput | undefined;
    };
    runtimeConfiguration?: Configuration[];
    monitoringConfiguration?: MonitoringConfiguration;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration;
    interactiveConfiguration?: InteractiveConfiguration;
    schedulerConfiguration?: SchedulerConfiguration;
    identityCenterConfiguration?: IdentityCenterConfigurationInput;
    jobLevelCostAllocationConfiguration?: JobLevelCostAllocationConfiguration;
}
export declare const CreateApplicationRequest: S.Schema<CreateApplicationRequest>;
export type ApplicationArn = string;
export interface CreateApplicationResponse {
    applicationId: string;
    name?: string;
    arn: string;
}
export declare const CreateApplicationResponse: S.Schema<CreateApplicationResponse>;
export interface DeleteApplicationRequest {
    applicationId: string;
}
export declare const DeleteApplicationRequest: S.Schema<DeleteApplicationRequest>;
export interface DeleteApplicationResponse {
}
export declare const DeleteApplicationResponse: S.Schema<DeleteApplicationResponse>;
export interface GetApplicationRequest {
    applicationId: string;
}
export declare const GetApplicationRequest: S.Schema<GetApplicationRequest>;
export type ApplicationState = string;
export type String256 = string;
export type ImageDigest = string;
export interface ImageConfiguration {
    imageUri: string;
    resolvedImageDigest?: string;
    applicationLevelDigestResolution?: boolean;
}
export declare const ImageConfiguration: S.Schema<ImageConfiguration>;
export interface WorkerTypeSpecification {
    imageConfiguration?: ImageConfiguration;
}
export declare const WorkerTypeSpecification: S.Schema<WorkerTypeSpecification>;
export type WorkerTypeSpecificationMap = {
    [key: string]: WorkerTypeSpecification | undefined;
};
export declare const WorkerTypeSpecificationMap: any;
export type IdentityCenterApplicationArn = string;
export interface IdentityCenterConfiguration {
    identityCenterInstanceArn?: string;
    identityCenterApplicationArn?: string;
    userBackgroundSessionsEnabled?: boolean;
}
export declare const IdentityCenterConfiguration: S.Schema<IdentityCenterConfiguration>;
export interface Application {
    applicationId: string;
    name?: string;
    arn: string;
    releaseLabel: string;
    type: string;
    state: string;
    stateDetails?: string;
    initialCapacity?: {
        [key: string]: InitialCapacityConfig | undefined;
    };
    maximumCapacity?: MaximumAllowedResources;
    createdAt: Date;
    updatedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    };
    autoStartConfiguration?: AutoStartConfig;
    autoStopConfiguration?: AutoStopConfig;
    networkConfiguration?: NetworkConfiguration;
    architecture?: string;
    imageConfiguration?: ImageConfiguration;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecification | undefined;
    };
    runtimeConfiguration?: Configuration[];
    monitoringConfiguration?: MonitoringConfiguration;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration;
    interactiveConfiguration?: InteractiveConfiguration;
    schedulerConfiguration?: SchedulerConfiguration;
    identityCenterConfiguration?: IdentityCenterConfiguration;
    jobLevelCostAllocationConfiguration?: JobLevelCostAllocationConfiguration;
}
export declare const Application: S.Schema<Application>;
export interface GetApplicationResponse {
    application: Application;
}
export declare const GetApplicationResponse: S.Schema<GetApplicationResponse>;
export type AttemptNumber = number;
export interface GetDashboardForJobRunRequest {
    applicationId: string;
    jobRunId: string;
    attempt?: number;
    accessSystemProfileLogs?: boolean;
}
export declare const GetDashboardForJobRunRequest: S.Schema<GetDashboardForJobRunRequest>;
export type Url = string;
export interface GetDashboardForJobRunResponse {
    url?: string;
}
export declare const GetDashboardForJobRunResponse: S.Schema<GetDashboardForJobRunResponse>;
export interface GetJobRunRequest {
    applicationId: string;
    jobRunId: string;
    attempt?: number;
}
export declare const GetJobRunRequest: S.Schema<GetJobRunRequest>;
export type JobArn = string;
export type RequestIdentityUserArn = string;
export type IAMRoleArn = string;
export type PolicyDocument = string;
export type Arn = string;
export type PolicyArnList = string[];
export declare const PolicyArnList: any;
export interface JobRunExecutionIamPolicy {
    policy?: string;
    policyArns?: string[];
}
export declare const JobRunExecutionIamPolicy: S.Schema<JobRunExecutionIamPolicy>;
export type JobRunState = string;
export interface ConfigurationOverrides {
    applicationConfiguration?: Configuration[];
    monitoringConfiguration?: MonitoringConfiguration;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration;
}
export declare const ConfigurationOverrides: S.Schema<ConfigurationOverrides>;
export type EntryPointPath = string | redacted.Redacted<string>;
export type EntryPointArgument = string | redacted.Redacted<string>;
export type EntryPointArguments = (string | redacted.Redacted<string>)[];
export declare const EntryPointArguments: any;
export type SparkSubmitParameters = string | redacted.Redacted<string>;
export interface SparkSubmit {
    entryPoint: string | redacted.Redacted<string>;
    entryPointArguments?: (string | redacted.Redacted<string>)[];
    sparkSubmitParameters?: string | redacted.Redacted<string>;
}
export declare const SparkSubmit: S.Schema<SparkSubmit>;
export type Query = string | redacted.Redacted<string>;
export type InitScriptPath = string | redacted.Redacted<string>;
export type HiveCliParameters = string | redacted.Redacted<string>;
export interface Hive {
    query: string | redacted.Redacted<string>;
    initQueryFile?: string | redacted.Redacted<string>;
    parameters?: string | redacted.Redacted<string>;
}
export declare const Hive: S.Schema<Hive>;
export type JobDriver = {
    sparkSubmit: SparkSubmit;
    hive?: never;
} | {
    sparkSubmit?: never;
    hive: Hive;
};
export declare const JobDriver: any;
export interface TotalResourceUtilization {
    vCPUHour?: number;
    memoryGBHour?: number;
    storageGBHour?: number;
}
export declare const TotalResourceUtilization: S.Schema<TotalResourceUtilization>;
export type Duration = number;
export interface ResourceUtilization {
    vCPUHour?: number;
    memoryGBHour?: number;
    storageGBHour?: number;
}
export declare const ResourceUtilization: S.Schema<ResourceUtilization>;
export type JobRunMode = string;
export interface RetryPolicy {
    maxAttempts?: number;
    maxFailedAttemptsPerHour?: number;
}
export declare const RetryPolicy: S.Schema<RetryPolicy>;
export interface JobRun {
    applicationId: string;
    jobRunId: string;
    name?: string;
    arn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    executionRole: string;
    executionIamPolicy?: JobRunExecutionIamPolicy;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    configurationOverrides?: ConfigurationOverrides;
    jobDriver: JobDriver;
    tags?: {
        [key: string]: string | undefined;
    };
    totalResourceUtilization?: TotalResourceUtilization;
    networkConfiguration?: NetworkConfiguration;
    totalExecutionDurationSeconds?: number;
    executionTimeoutMinutes?: number;
    billedResourceUtilization?: ResourceUtilization;
    mode?: string;
    retryPolicy?: RetryPolicy;
    attempt?: number;
    attemptCreatedAt?: Date;
    attemptUpdatedAt?: Date;
    startedAt?: Date;
    endedAt?: Date;
    queuedDurationMilliseconds?: number;
    imageConfiguration?: ImageConfiguration;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecification | undefined;
    };
}
export declare const JobRun: S.Schema<JobRun>;
export interface GetJobRunResponse {
    jobRun: JobRun;
}
export declare const GetJobRunResponse: S.Schema<GetJobRunResponse>;
export type ResourceId = string;
export type ResourceType = string;
export interface GetResourceDashboardRequest {
    applicationId: string;
    resourceId: string;
    resourceType: string;
}
export declare const GetResourceDashboardRequest: S.Schema<GetResourceDashboardRequest>;
export interface GetResourceDashboardResponse {
    url?: string;
}
export declare const GetResourceDashboardResponse: S.Schema<GetResourceDashboardResponse>;
export type SessionId = string;
export interface GetSessionRequest {
    applicationId: string;
    sessionId: string;
}
export declare const GetSessionRequest: S.Schema<GetSessionRequest>;
export type SessionArn = string;
export type SessionState = string;
export interface SessionConfigurationOverrides {
    runtimeConfiguration?: Configuration[];
}
export declare const SessionConfigurationOverrides: S.Schema<SessionConfigurationOverrides>;
export interface Session {
    applicationId: string;
    sessionId: string;
    arn: string;
    name?: string;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    executionRoleArn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date;
    endedAt?: Date;
    idleSince?: Date;
    configurationOverrides?: SessionConfigurationOverrides;
    networkConfiguration?: NetworkConfiguration;
    idleTimeoutMinutes?: number;
    tags?: {
        [key: string]: string | undefined;
    };
    totalResourceUtilization?: TotalResourceUtilization;
    billedResourceUtilization?: ResourceUtilization;
    totalExecutionDurationSeconds?: number;
}
export declare const Session: S.Schema<Session>;
export interface GetSessionResponse {
    session: Session;
}
export declare const GetSessionResponse: S.Schema<GetSessionResponse>;
export interface GetSessionEndpointRequest {
    applicationId: string;
    sessionId: string;
}
export declare const GetSessionEndpointRequest: S.Schema<GetSessionEndpointRequest>;
export type EndpointUrl = string;
export type SessionAuthToken = string | redacted.Redacted<string>;
export interface GetSessionEndpointResponse {
    applicationId: string;
    sessionId: string;
    endpoint: string;
    authToken: string | redacted.Redacted<string>;
    authTokenExpiresAt: Date;
}
export declare const GetSessionEndpointResponse: S.Schema<GetSessionEndpointResponse>;
export type NextToken = string;
export type ApplicationStateSet = string[];
export declare const ApplicationStateSet: any;
export interface ListApplicationsRequest {
    nextToken?: string;
    maxResults?: number;
    states?: string[];
}
export declare const ListApplicationsRequest: S.Schema<ListApplicationsRequest>;
export interface ApplicationSummary {
    id: string;
    name?: string;
    arn: string;
    releaseLabel: string;
    type: string;
    state: string;
    stateDetails?: string;
    createdAt: Date;
    updatedAt: Date;
    architecture?: string;
}
export declare const ApplicationSummary: S.Schema<ApplicationSummary>;
export type ApplicationList = ApplicationSummary[];
export declare const ApplicationList: any;
export interface ListApplicationsResponse {
    applications: ApplicationSummary[];
    nextToken?: string;
}
export declare const ListApplicationsResponse: S.Schema<ListApplicationsResponse>;
export interface ListJobRunAttemptsRequest {
    applicationId: string;
    jobRunId: string;
    nextToken?: string;
    maxResults?: number;
}
export declare const ListJobRunAttemptsRequest: S.Schema<ListJobRunAttemptsRequest>;
export type JobRunType = string;
export interface JobRunAttemptSummary {
    applicationId: string;
    id: string;
    name?: string;
    mode?: string;
    arn: string;
    createdBy: string;
    jobCreatedAt: Date;
    createdAt: Date;
    updatedAt: Date;
    executionRole: string;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    type?: string;
    attempt?: number;
}
export declare const JobRunAttemptSummary: S.Schema<JobRunAttemptSummary>;
export type JobRunAttempts = JobRunAttemptSummary[];
export declare const JobRunAttempts: any;
export interface ListJobRunAttemptsResponse {
    jobRunAttempts: JobRunAttemptSummary[];
    nextToken?: string;
}
export declare const ListJobRunAttemptsResponse: S.Schema<ListJobRunAttemptsResponse>;
export type JobRunStateSet = string[];
export declare const JobRunStateSet: any;
export interface ListJobRunsRequest {
    applicationId: string;
    nextToken?: string;
    maxResults?: number;
    createdAtAfter?: Date;
    createdAtBefore?: Date;
    states?: string[];
    mode?: string;
}
export declare const ListJobRunsRequest: S.Schema<ListJobRunsRequest>;
export interface JobRunSummary {
    applicationId: string;
    id: string;
    name?: string;
    mode?: string;
    arn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    executionRole: string;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    type?: string;
    attempt?: number;
    attemptCreatedAt?: Date;
    attemptUpdatedAt?: Date;
}
export declare const JobRunSummary: S.Schema<JobRunSummary>;
export type JobRuns = JobRunSummary[];
export declare const JobRuns: any;
export interface ListJobRunsResponse {
    jobRuns: JobRunSummary[];
    nextToken?: string;
}
export declare const ListJobRunsResponse: S.Schema<ListJobRunsResponse>;
export type SessionStateSet = string[];
export declare const SessionStateSet: any;
export interface ListSessionsRequest {
    applicationId: string;
    nextToken?: string;
    maxResults?: number;
    states?: string[];
    createdAtAfter?: Date;
    createdAtBefore?: Date;
}
export declare const ListSessionsRequest: S.Schema<ListSessionsRequest>;
export interface SessionSummary {
    applicationId: string;
    sessionId: string;
    arn: string;
    name?: string;
    state: string;
    stateDetails: string;
    releaseLabel: string;
    executionRoleArn: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const SessionSummary: S.Schema<SessionSummary>;
export type Sessions = SessionSummary[];
export declare const Sessions: any;
export interface ListSessionsResponse {
    sessions: SessionSummary[];
    nextToken?: string;
}
export declare const ListSessionsResponse: S.Schema<ListSessionsResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface StartApplicationRequest {
    applicationId: string;
}
export declare const StartApplicationRequest: S.Schema<StartApplicationRequest>;
export interface StartApplicationResponse {
}
export declare const StartApplicationResponse: S.Schema<StartApplicationResponse>;
export interface StartJobRunRequest {
    applicationId: string;
    clientToken: string;
    executionRoleArn: string;
    executionIamPolicy?: JobRunExecutionIamPolicy;
    jobDriver?: JobDriver;
    configurationOverrides?: ConfigurationOverrides;
    tags?: {
        [key: string]: string | undefined;
    };
    executionTimeoutMinutes?: number;
    name?: string;
    mode?: string;
    retryPolicy?: RetryPolicy;
}
export declare const StartJobRunRequest: S.Schema<StartJobRunRequest>;
export interface StartJobRunResponse {
    applicationId: string;
    jobRunId: string;
    arn: string;
}
export declare const StartJobRunResponse: S.Schema<StartJobRunResponse>;
export interface StartSessionRequest {
    applicationId: string;
    clientToken: string;
    executionRoleArn: string;
    configurationOverrides?: SessionConfigurationOverrides;
    tags?: {
        [key: string]: string | undefined;
    };
    idleTimeoutMinutes?: number;
    name?: string;
}
export declare const StartSessionRequest: S.Schema<StartSessionRequest>;
export interface StartSessionResponse {
    applicationId: string;
    sessionId: string;
    arn: string;
}
export declare const StartSessionResponse: S.Schema<StartSessionResponse>;
export interface StopApplicationRequest {
    applicationId: string;
}
export declare const StopApplicationRequest: S.Schema<StopApplicationRequest>;
export interface StopApplicationResponse {
}
export declare const StopApplicationResponse: S.Schema<StopApplicationResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export interface TerminateSessionRequest {
    applicationId: string;
    sessionId: string;
}
export declare const TerminateSessionRequest: S.Schema<TerminateSessionRequest>;
export interface TerminateSessionResponse {
    applicationId: string;
    sessionId: string;
}
export declare const TerminateSessionResponse: S.Schema<TerminateSessionResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateApplicationRequest {
    applicationId: string;
    clientToken: string;
    initialCapacity?: {
        [key: string]: InitialCapacityConfig | undefined;
    };
    maximumCapacity?: MaximumAllowedResources;
    autoStartConfiguration?: AutoStartConfig;
    autoStopConfiguration?: AutoStopConfig;
    networkConfiguration?: NetworkConfiguration;
    architecture?: string;
    imageConfiguration?: ImageConfigurationInput;
    workerTypeSpecifications?: {
        [key: string]: WorkerTypeSpecificationInput | undefined;
    };
    interactiveConfiguration?: InteractiveConfiguration;
    releaseLabel?: string;
    runtimeConfiguration?: Configuration[];
    monitoringConfiguration?: MonitoringConfiguration;
    diskEncryptionConfiguration?: DiskEncryptionConfiguration;
    schedulerConfiguration?: SchedulerConfiguration;
    identityCenterConfiguration?: IdentityCenterConfigurationInput;
    jobLevelCostAllocationConfiguration?: JobLevelCostAllocationConfiguration;
}
export declare const UpdateApplicationRequest: S.Schema<UpdateApplicationRequest>;
export interface UpdateApplicationResponse {
    application: Application;
}
export declare const UpdateApplicationResponse: S.Schema<UpdateApplicationResponse>;
export type CancelJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a job run.
 */
export declare const cancelJobRun: API.OperationMethod<CancelJobRunRequest, CancelJobRunResponse, CancelJobRunError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an application.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an application. An application has to be in a stopped or created state in order to be deleted.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays detailed information about a specified application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetDashboardForJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates and returns a URL that you can use to access the application UIs for a job run.
 *
 * For jobs in a running state, the application UI is a live user interface such as the Spark or Tez web UI. For completed jobs, the application UI is a persistent application user interface such as the Spark History Server or persistent Tez UI.
 *
 * The URL is valid for one hour after you generate it. To access the application UI after that hour elapses, you must invoke the API again to generate a new URL.
 */
export declare const getDashboardForJobRun: API.OperationMethod<GetDashboardForJobRunRequest, GetDashboardForJobRunResponse, GetDashboardForJobRunError, Credentials | HttpClient.HttpClient>;
export type GetJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays detailed information about a job run.
 */
export declare const getJobRun: API.OperationMethod<GetJobRunRequest, GetJobRunResponse, GetJobRunError, Credentials | HttpClient.HttpClient>;
export type GetResourceDashboardError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a URL that you can use to access the application UIs for a specified resource, such as a session.
 *
 * For resources in a running state, the application UI is a live user interface such as the Spark web UI. For terminated resources, the application UI is a persistent application user interface such as the Spark History Server.
 *
 * The URL is valid for one hour after you generate it. To access the application UI after that hour elapses, you must invoke the API again to generate a new URL.
 */
export declare const getResourceDashboard: API.OperationMethod<GetResourceDashboardRequest, GetResourceDashboardResponse, GetResourceDashboardError, Credentials | HttpClient.HttpClient>;
export type GetSessionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Displays detailed information about a session.
 */
export declare const getSession: API.OperationMethod<GetSessionRequest, GetSessionResponse, GetSessionError, Credentials | HttpClient.HttpClient>;
export type GetSessionEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the session endpoint URL and a time-limited authentication token for the specified session. Use the endpoint and token to connect a client to the session. Call this operation again when the authentication token expires to obtain a new token.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointRequest, GetSessionEndpointResponse, GetSessionEndpointError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists applications based on a set of parameters.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, ApplicationSummary>;
export type ListJobRunAttemptsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all attempt of a job run.
 */
export declare const listJobRunAttempts: API.PaginatedOperationMethod<ListJobRunAttemptsRequest, ListJobRunAttemptsResponse, ListJobRunAttemptsError, Credentials | HttpClient.HttpClient, JobRunAttemptSummary>;
export type ListJobRunsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists job runs based on a set of parameters.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsRequest, ListJobRunsResponse, ListJobRunsError, Credentials | HttpClient.HttpClient, JobRunSummary>;
export type ListSessionsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists sessions for the specified application. You can filter sessions by state and creation time.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsRequest, ListSessionsResponse, ListSessionsError, Credentials | HttpClient.HttpClient, SessionSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags assigned to the resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Starts a specified application and initializes initial capacity if configured.
 */
export declare const startApplication: API.OperationMethod<StartApplicationRequest, StartApplicationResponse, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StartJobRunError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts a job run.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest, StartJobRunResponse, StartJobRunError, Credentials | HttpClient.HttpClient>;
export type StartSessionError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates and starts a new session on the specified application. The application must be in the `STARTED` state or have `AutoStart` enabled, and have interactive sessions enabled. This operation is supported for EMR release 7.13.0 and later.
 */
export declare const startSession: API.OperationMethod<StartSessionRequest, StartSessionResponse, StartSessionError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops a specified application and releases initial capacity if configured. All scheduled and running jobs must be completed or cancelled before stopping an application.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationRequest, StopApplicationResponse, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Assigns tags to resources. A tag is a label that you assign to an Amazon Web Services resource. Each tag consists of a key and an optional value, both of which you define. Tags enable you to categorize your Amazon Web Services resources by attributes such as purpose, owner, or environment. When you have many resources of the same type, you can quickly identify a specific resource based on the tags you've assigned to it.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateSessionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Terminates the specified session. After you terminate a session, it enters the `TERMINATING` state and then the `TERMINATED` state. You can still access the Spark History Server for a terminated session through the `GetResourceDashboard` operation.
 */
export declare const terminateSession: API.OperationMethod<TerminateSessionRequest, TerminateSessionResponse, TerminateSessionError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a specified application. An application has to be in a stopped or created state in order to be updated.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=emr-serverless.d.ts.map