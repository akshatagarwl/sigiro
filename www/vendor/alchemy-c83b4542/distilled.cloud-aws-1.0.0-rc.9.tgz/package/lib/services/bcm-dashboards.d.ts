import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DashboardName = string;
export type Description = string;
export type WidgetId = string;
export type WidgetTitle = string;
export type WidgetWidth = number;
export type WidgetHeight = number;
export type MetricName = "AmortizedCost" | "BlendedCost" | "NetAmortizedCost" | "NetUnblendedCost" | "NormalizedUsageAmount" | "UnblendedCost" | "UsageQuantity" | "SpendCoveredBySavingsPlans" | "Hour" | "Unit" | "Cost" | (string & {});
export declare const MetricName: any;
export type MetricNames = MetricName[];
export declare const MetricNames: any;
export type DateTimeType = "ABSOLUTE" | "RELATIVE" | (string & {});
export declare const DateTimeType: any;
export interface DateTimeValue {
    type: DateTimeType;
    value: string;
}
export declare const DateTimeValue: S.Schema<DateTimeValue>;
export interface DateTimeRange {
    startTime: DateTimeValue;
    endTime: DateTimeValue;
}
export declare const DateTimeRange: S.Schema<DateTimeRange>;
export type Granularity = "HOURLY" | "DAILY" | "MONTHLY" | (string & {});
export declare const Granularity: any;
export type GroupDefinitionType = "DIMENSION" | "TAG" | "COST_CATEGORY" | (string & {});
export declare const GroupDefinitionType: any;
export interface GroupDefinition {
    key: string;
    type?: GroupDefinitionType;
}
export declare const GroupDefinition: S.Schema<GroupDefinition>;
export type GroupDefinitions = GroupDefinition[];
export declare const GroupDefinitions: any;
export type Expressions = Expression[];
export declare const Expressions: S.Schema<Expressions>;
export type Dimension = "AZ" | "INSTANCE_TYPE" | "LINKED_ACCOUNT" | "OPERATION" | "PURCHASE_TYPE" | "REGION" | "SERVICE" | "USAGE_TYPE" | "USAGE_TYPE_GROUP" | "RECORD_TYPE" | "RESOURCE_ID" | "SUBSCRIPTION_ID" | "TAG_KEY" | "OPERATING_SYSTEM" | "TENANCY" | "BILLING_ENTITY" | "RESERVATION_ID" | "COST_CATEGORY_NAME" | "DATABASE_ENGINE" | "LEGAL_ENTITY_NAME" | "SAVINGS_PLANS_TYPE" | "INSTANCE_TYPE_FAMILY" | "CACHE_ENGINE" | "DEPLOYMENT_OPTION" | "SCOPE" | "PLATFORM" | (string & {});
export declare const Dimension: any;
export type StringList = string[];
export declare const StringList: any;
export type MatchOption = "EQUALS" | "ABSENT" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS" | "GREATER_THAN_OR_EQUAL" | "CASE_SENSITIVE" | "CASE_INSENSITIVE" | (string & {});
export declare const MatchOption: any;
export type MatchOptions = MatchOption[];
export declare const MatchOptions: any;
export interface DimensionValues {
    key: Dimension;
    values: string[];
    matchOptions?: MatchOption[];
}
export declare const DimensionValues: S.Schema<DimensionValues>;
export interface TagValues {
    key?: string;
    values?: string[];
    matchOptions?: MatchOption[];
}
export declare const TagValues: S.Schema<TagValues>;
export interface CostCategoryValues {
    key?: string;
    values?: string[];
    matchOptions?: MatchOption[];
}
export declare const CostCategoryValues: S.Schema<CostCategoryValues>;
export interface Expression {
    or?: Expression[];
    and?: Expression[];
    not?: Expression;
    dimensions?: DimensionValues;
    tags?: TagValues;
    costCategories?: CostCategoryValues;
}
export declare const Expression: S.Schema<Expression>;
export interface CostAndUsageQuery {
    metrics: MetricName[];
    timeRange: DateTimeRange;
    granularity: Granularity;
    groupBy?: GroupDefinition[];
    filter?: Expression;
}
export declare const CostAndUsageQuery: S.Schema<CostAndUsageQuery>;
export interface SavingsPlansCoverageQuery {
    timeRange: DateTimeRange;
    metrics?: MetricName[];
    granularity?: Granularity;
    groupBy?: GroupDefinition[];
    filter?: Expression;
}
export declare const SavingsPlansCoverageQuery: S.Schema<SavingsPlansCoverageQuery>;
export interface SavingsPlansUtilizationQuery {
    timeRange: DateTimeRange;
    granularity?: Granularity;
    filter?: Expression;
}
export declare const SavingsPlansUtilizationQuery: S.Schema<SavingsPlansUtilizationQuery>;
export interface ReservationCoverageQuery {
    timeRange: DateTimeRange;
    groupBy?: GroupDefinition[];
    granularity?: Granularity;
    filter?: Expression;
    metrics?: MetricName[];
}
export declare const ReservationCoverageQuery: S.Schema<ReservationCoverageQuery>;
export interface ReservationUtilizationQuery {
    timeRange: DateTimeRange;
    groupBy?: GroupDefinition[];
    granularity?: Granularity;
    filter?: Expression;
}
export declare const ReservationUtilizationQuery: S.Schema<ReservationUtilizationQuery>;
export type QueryParameters = {
    costAndUsage: CostAndUsageQuery;
    savingsPlansCoverage?: never;
    savingsPlansUtilization?: never;
    reservationCoverage?: never;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage: SavingsPlansCoverageQuery;
    savingsPlansUtilization?: never;
    reservationCoverage?: never;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage?: never;
    savingsPlansUtilization: SavingsPlansUtilizationQuery;
    reservationCoverage?: never;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage?: never;
    savingsPlansUtilization?: never;
    reservationCoverage: ReservationCoverageQuery;
    reservationUtilization?: never;
} | {
    costAndUsage?: never;
    savingsPlansCoverage?: never;
    savingsPlansUtilization?: never;
    reservationCoverage?: never;
    reservationUtilization: ReservationUtilizationQuery;
};
export declare const QueryParameters: any;
export type VisualType = "LINE" | "BAR" | "STACK" | (string & {});
export declare const VisualType: any;
export interface GraphDisplayConfig {
    visualType: VisualType;
}
export declare const GraphDisplayConfig: S.Schema<GraphDisplayConfig>;
export type GraphDisplayConfigMap = {
    [key: string]: GraphDisplayConfig | undefined;
};
export declare const GraphDisplayConfigMap: any;
export interface TableDisplayConfigStruct {
}
export declare const TableDisplayConfigStruct: S.Schema<TableDisplayConfigStruct>;
export type DisplayConfig = {
    graph: {
        [key: string]: GraphDisplayConfig | undefined;
    };
    table?: never;
} | {
    graph?: never;
    table: TableDisplayConfigStruct;
};
export declare const DisplayConfig: any;
export interface WidgetConfig {
    queryParameters: QueryParameters;
    displayConfig: DisplayConfig;
}
export declare const WidgetConfig: S.Schema<WidgetConfig>;
export type WidgetConfigList = WidgetConfig[];
export declare const WidgetConfigList: any;
export interface Widget {
    id?: string;
    title: string;
    description?: string;
    width?: number;
    height?: number;
    horizontalOffset?: number;
    configs: WidgetConfig[];
}
export declare const Widget: S.Schema<Widget>;
export type WidgetList = Widget[];
export declare const WidgetList: any;
export type ResourceTagKey = string;
export type ResourceTagValue = string;
export interface ResourceTag {
    key: string;
    value: string;
}
export declare const ResourceTag: S.Schema<ResourceTag>;
export type ResourceTagList = ResourceTag[];
export declare const ResourceTagList: any;
export interface CreateDashboardRequest {
    name: string;
    description?: string;
    widgets: Widget[];
    resourceTags?: ResourceTag[];
}
export declare const CreateDashboardRequest: S.Schema<CreateDashboardRequest>;
export type DashboardArn = string;
export interface CreateDashboardResponse {
    arn: string;
}
export declare const CreateDashboardResponse: S.Schema<CreateDashboardResponse>;
export type ScheduledReportName = string;
export type ServiceRoleArn = string;
export interface SchedulePeriod {
    startTime?: Date;
    endTime?: Date;
}
export declare const SchedulePeriod: S.Schema<SchedulePeriod>;
export type ScheduleState = "ENABLED" | "DISABLED" | (string & {});
export declare const ScheduleState: any;
export interface ScheduleConfig {
    scheduleExpression?: string;
    scheduleExpressionTimeZone?: string;
    schedulePeriod?: SchedulePeriod;
    state?: ScheduleState;
}
export declare const ScheduleConfig: S.Schema<ScheduleConfig>;
export type WidgetIdList = string[];
export declare const WidgetIdList: any;
export interface ScheduledReportInput {
    name: string;
    dashboardArn: string;
    scheduledReportExecutionRoleArn: string;
    scheduleConfig: ScheduleConfig;
    description?: string;
    widgetIds?: string[];
    widgetDateRangeOverride?: DateTimeRange;
}
export declare const ScheduledReportInput: S.Schema<ScheduledReportInput>;
export type ClientToken = string;
export interface CreateScheduledReportRequest {
    scheduledReport: ScheduledReportInput;
    resourceTags?: ResourceTag[];
    clientToken?: string;
}
export declare const CreateScheduledReportRequest: S.Schema<CreateScheduledReportRequest>;
export type ScheduledReportArn = string;
export interface CreateScheduledReportResponse {
    arn: string;
}
export declare const CreateScheduledReportResponse: S.Schema<CreateScheduledReportResponse>;
export interface DeleteDashboardRequest {
    arn: string;
}
export declare const DeleteDashboardRequest: S.Schema<DeleteDashboardRequest>;
export interface DeleteDashboardResponse {
    arn: string;
}
export declare const DeleteDashboardResponse: S.Schema<DeleteDashboardResponse>;
export interface DeleteScheduledReportRequest {
    arn: string;
}
export declare const DeleteScheduledReportRequest: S.Schema<DeleteScheduledReportRequest>;
export interface DeleteScheduledReportResponse {
    arn: string;
}
export declare const DeleteScheduledReportResponse: S.Schema<DeleteScheduledReportResponse>;
export interface ExecuteScheduledReportRequest {
    arn: string;
    clientToken?: string;
    dryRun?: boolean;
}
export declare const ExecuteScheduledReportRequest: S.Schema<ExecuteScheduledReportRequest>;
export type HealthStatusCode = "HEALTHY" | "UNHEALTHY" | (string & {});
export declare const HealthStatusCode: any;
export type StatusReason = "DATA_SOURCE_ACCESS_DENIED" | "EXECUTION_ROLE_ASSUME_FAILED" | "EXECUTION_ROLE_INSUFFICIENT_PERMISSIONS" | "DASHBOARD_NOT_FOUND" | "DASHBOARD_ACCESS_DENIED" | "INTERNAL_FAILURE" | "WIDGET_ID_NOT_FOUND" | (string & {});
export declare const StatusReason: any;
export type StatusReasonList = StatusReason[];
export declare const StatusReasonList: any;
export interface HealthStatus {
    statusCode: HealthStatusCode;
    lastRefreshedAt?: Date;
    statusReasons?: StatusReason[];
}
export declare const HealthStatus: S.Schema<HealthStatus>;
export interface ExecuteScheduledReportResponse {
    healthStatus?: HealthStatus;
    executionTriggered?: boolean;
}
export declare const ExecuteScheduledReportResponse: S.Schema<ExecuteScheduledReportResponse>;
export interface GetDashboardRequest {
    arn: string;
}
export declare const GetDashboardRequest: S.Schema<GetDashboardRequest>;
export type DashboardType = "CUSTOM" | (string & {});
export declare const DashboardType: any;
export interface GetDashboardResponse {
    arn: string;
    name: string;
    description?: string;
    type: DashboardType;
    widgets: Widget[];
    createdAt: Date;
    updatedAt: Date;
}
export declare const GetDashboardResponse: S.Schema<GetDashboardResponse>;
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export declare const GetResourcePolicyRequest: S.Schema<GetResourcePolicyRequest>;
export interface GetResourcePolicyResponse {
    resourceArn: string;
    policyDocument: string;
}
export declare const GetResourcePolicyResponse: S.Schema<GetResourcePolicyResponse>;
export interface GetScheduledReportRequest {
    arn: string;
}
export declare const GetScheduledReportRequest: S.Schema<GetScheduledReportRequest>;
export interface ScheduledReport {
    arn?: string;
    name: string;
    dashboardArn: string;
    scheduledReportExecutionRoleArn: string;
    scheduleConfig: ScheduleConfig;
    description?: string;
    widgetIds?: string[];
    widgetDateRangeOverride?: DateTimeRange;
    createdAt?: Date;
    updatedAt?: Date;
    lastExecutionAt?: Date;
    healthStatus?: HealthStatus;
}
export declare const ScheduledReport: S.Schema<ScheduledReport>;
export interface GetScheduledReportResponse {
    scheduledReport: ScheduledReport;
}
export declare const GetScheduledReportResponse: S.Schema<GetScheduledReportResponse>;
export type MaxResults = number;
export type NextPageToken = string;
export interface ListDashboardsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListDashboardsRequest: S.Schema<ListDashboardsRequest>;
export interface DashboardReference {
    arn: string;
    name: string;
    description?: string;
    type: DashboardType;
    createdAt: Date;
    updatedAt: Date;
}
export declare const DashboardReference: S.Schema<DashboardReference>;
export type DashboardReferenceList = DashboardReference[];
export declare const DashboardReferenceList: any;
export interface ListDashboardsResponse {
    dashboards: DashboardReference[];
    nextToken?: string;
}
export declare const ListDashboardsResponse: S.Schema<ListDashboardsResponse>;
export interface ListScheduledReportsRequest {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListScheduledReportsRequest: S.Schema<ListScheduledReportsRequest>;
export interface ScheduledReportSummary {
    arn: string;
    name: string;
    dashboardArn: string;
    scheduleExpression: string;
    state: ScheduleState;
    healthStatus: HealthStatus;
    scheduleExpressionTimeZone?: string;
    widgetIds?: string[];
}
export declare const ScheduledReportSummary: S.Schema<ScheduledReportSummary>;
export type ScheduledReportSummaryList = ScheduledReportSummary[];
export declare const ScheduledReportSummaryList: any;
export interface ListScheduledReportsResponse {
    scheduledReports: ScheduledReportSummary[];
    nextToken?: string;
}
export declare const ListScheduledReportsResponse: S.Schema<ListScheduledReportsResponse>;
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    resourceTags?: ResourceTag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    resourceTags: ResourceTag[];
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type ResourceTagKeyList = string[];
export declare const ResourceTagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    resourceTagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateDashboardRequest {
    arn: string;
    name: string;
    description?: string;
    widgets?: Widget[];
}
export declare const UpdateDashboardRequest: S.Schema<UpdateDashboardRequest>;
export interface UpdateDashboardResponse {
    arn: string;
}
export declare const UpdateDashboardResponse: S.Schema<UpdateDashboardResponse>;
export interface UpdateScheduledReportRequest {
    arn: string;
    name?: string;
    description?: string;
    dashboardArn?: string;
    scheduledReportExecutionRoleArn?: string;
    scheduleConfig?: ScheduleConfig;
    widgetIds?: string[];
    widgetDateRangeOverride?: DateTimeRange;
    clearWidgetIds?: boolean;
    clearWidgetDateRangeOverride?: boolean;
}
export declare const UpdateScheduledReportRequest: S.Schema<UpdateScheduledReportRequest>;
export interface UpdateScheduledReportResponse {
    arn: string;
}
export declare const UpdateScheduledReportResponse: S.Schema<UpdateScheduledReportResponse>;
export type CreateDashboardError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new dashboard that can contain multiple widgets displaying cost and usage data. You can add custom widgets or use predefined widgets, arranging them in your preferred layout.
 */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest, CreateDashboardResponse, CreateDashboardError, Credentials | HttpClient.HttpClient>;
export type CreateScheduledReportError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new scheduled report for a dashboard. A scheduled report automatically generates and delivers dashboard snapshots on a recurring schedule. Reports are delivered within 15 minutes of the scheduled delivery time.
 */
export declare const createScheduledReport: API.OperationMethod<CreateScheduledReportRequest, CreateScheduledReportResponse, CreateScheduledReportError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified dashboard. This action cannot be undone.
 */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest, DeleteDashboardResponse, DeleteDashboardError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduledReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified scheduled report. This is an irreversible operation.
 */
export declare const deleteScheduledReport: API.OperationMethod<DeleteScheduledReportRequest, DeleteScheduledReportResponse, DeleteScheduledReportError, Credentials | HttpClient.HttpClient>;
export type ExecuteScheduledReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Triggers an immediate execution of a scheduled report, outside of its regular schedule. The scheduled report must be in `ENABLED` state. Calling this operation on a `DISABLED` scheduled report returns a `ValidationException`.
 *
 * If a `clientToken` is provided, the service uses it for idempotency. Requests with the same client token will not trigger a new execution within the same minute.
 */
export declare const executeScheduledReport: API.OperationMethod<ExecuteScheduledReportRequest, ExecuteScheduledReportResponse, ExecuteScheduledReportError, Credentials | HttpClient.HttpClient>;
export type GetDashboardError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration and metadata of a specified dashboard, including its widgets and layout settings.
 */
export declare const getDashboard: API.OperationMethod<GetDashboardRequest, GetDashboardResponse, GetDashboardError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to a dashboard, showing sharing configurations and permissions.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetScheduledReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration and metadata of a specified scheduled report.
 */
export declare const getScheduledReport: API.OperationMethod<GetScheduledReportRequest, GetScheduledReportResponse, GetScheduledReportError, Credentials | HttpClient.HttpClient>;
export type ListDashboardsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all dashboards in your account.
 */
export declare const listDashboards: API.PaginatedOperationMethod<ListDashboardsRequest, ListDashboardsResponse, ListDashboardsError, Credentials | HttpClient.HttpClient, DashboardReference>;
export type ListScheduledReportsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of scheduled reports in your account.
 */
export declare const listScheduledReports: API.PaginatedOperationMethod<ListScheduledReportsRequest, ListScheduledReportsResponse, ListScheduledReportsError, Credentials | HttpClient.HttpClient, ScheduledReportSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all tags associated with a specified dashboard resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a specified dashboard resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes specified tags from a dashboard resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing dashboard's properties, including its name, description, and widget configurations.
 */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest, UpdateDashboardResponse, UpdateDashboardError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduledReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing scheduled report's properties, including its name, description, schedule configuration, and widget settings. Only the parameters included in the request are updated; all other properties remain unchanged.
 */
export declare const updateScheduledReport: API.OperationMethod<UpdateScheduledReportRequest, UpdateScheduledReportResponse, UpdateScheduledReportError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bcm-dashboards.d.ts.map