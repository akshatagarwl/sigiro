import * as HttpClient from "effect/unstable/http/HttpClient";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ForbiddenException_base: S.Class<ForbiddenException, S.TaggedStruct<"ForbiddenException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const IdempotencyTokenInUseException_base: S.Class<IdempotencyTokenInUseException, S.TaggedStruct<"IdempotencyTokenInUseException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotencyTokenInUseException extends /*@__PURE__*/ IdempotencyTokenInUseException_base {
}
declare const IdempotentParameterMismatchException_base: S.Class<IdempotentParameterMismatchException, S.TaggedStruct<"IdempotentParameterMismatchException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterValueException_base: S.Class<InvalidParameterValueException, S.TaggedStruct<"InvalidParameterValueException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const NotManagementAccountException_base: S.Class<NotManagementAccountException, S.TaggedStruct<"NotManagementAccountException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotManagementAccountException extends /*@__PURE__*/ NotManagementAccountException_base {
}
declare const OptInRequiredException_base: S.Class<OptInRequiredException, S.TaggedStruct<"OptInRequiredException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OptInRequiredException extends /*@__PURE__*/ OptInRequiredException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.Class<ServiceUnavailableException, S.TaggedStruct<"ServiceUnavailableException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type AccountId = string;
export type AccountIdList = string[];
export declare const AccountIdList: any;
export type ClientToken = string;
export interface AssociateAccountsRequest {
    accountIds: string[];
    clientToken?: string;
}
export declare const AssociateAccountsRequest: S.Schema<AssociateAccountsRequest>;
export type StringList = string[];
export declare const StringList: any;
export interface AssociateAccountsResponse {
    accountIds?: string[];
    errors?: string[];
}
export declare const AssociateAccountsResponse: S.Schema<AssociateAccountsResponse>;
export type RuleName = string;
export type RuleDescription = string;
export type RuleType = "OrganizationRule" | "AccountRule" | (string & {});
export declare const RuleType: any;
export type RuleApplyOrder = "BeforeAccountRules" | "AfterAccountRules" | (string & {});
export declare const RuleApplyOrder: any;
export type OrganizationConfigurationAccountIds = string[];
export declare const OrganizationConfigurationAccountIds: any;
export interface OrganizationConfiguration {
    ruleApplyOrder?: RuleApplyOrder;
    accountIds?: string[];
}
export declare const OrganizationConfiguration: S.Schema<OrganizationConfiguration>;
export type RecommendedActionType = "SnapshotAndDeleteUnattachedEbsVolume" | "UpgradeEbsVolumeType" | (string & {});
export declare const RecommendedActionType: any;
export type RecommendedActionTypeList = RecommendedActionType[];
export declare const RecommendedActionTypeList: any;
export type ComparisonOperator = "StringEquals" | "StringNotEquals" | "StringEqualsIgnoreCase" | "StringNotEqualsIgnoreCase" | "StringLike" | "StringNotLike" | "NumericEquals" | "NumericNotEquals" | "NumericLessThan" | "NumericLessThanEquals" | "NumericGreaterThan" | "NumericGreaterThanEquals" | "StringEqualsIfExists" | "StringNotEqualsIfExists" | "StringEqualsIgnoreCaseIfExists" | "StringNotEqualsIgnoreCaseIfExists" | "StringLikeIfExists" | "StringNotLikeIfExists" | "NumericEqualsIfExists" | "NumericNotEqualsIfExists" | "NumericLessThanIfExists" | "NumericLessThanEqualsIfExists" | "NumericGreaterThanIfExists" | "NumericGreaterThanEqualsIfExists" | (string & {});
export declare const ComparisonOperator: any;
export type StringCriteriaValue = string;
export type StringCriteriaValues = string[];
export declare const StringCriteriaValues: any;
export interface StringCriteriaCondition {
    comparison?: ComparisonOperator;
    values?: string[];
}
export declare const StringCriteriaCondition: S.Schema<StringCriteriaCondition>;
export type StringCriteriaConditionList = StringCriteriaCondition[];
export declare const StringCriteriaConditionList: any;
export type IntegerList = number[];
export declare const IntegerList: any;
export interface IntegerCriteriaCondition {
    comparison?: ComparisonOperator;
    values?: number[];
}
export declare const IntegerCriteriaCondition: S.Schema<IntegerCriteriaCondition>;
export type IntegerCriteriaConditionList = IntegerCriteriaCondition[];
export declare const IntegerCriteriaConditionList: any;
export type DoubleList = number[];
export declare const DoubleList: any;
export interface DoubleCriteriaCondition {
    comparison?: ComparisonOperator;
    values?: number[];
}
export declare const DoubleCriteriaCondition: S.Schema<DoubleCriteriaCondition>;
export type DoubleCriteriaConditionList = DoubleCriteriaCondition[];
export declare const DoubleCriteriaConditionList: any;
export interface ResourceTagsCriteriaCondition {
    comparison?: ComparisonOperator;
    key?: string;
    values?: string[];
}
export declare const ResourceTagsCriteriaCondition: S.Schema<ResourceTagsCriteriaCondition>;
export type ResourceTagsCriteriaConditionList = ResourceTagsCriteriaCondition[];
export declare const ResourceTagsCriteriaConditionList: any;
export interface Criteria {
    region?: StringCriteriaCondition[];
    resourceArn?: StringCriteriaCondition[];
    ebsVolumeType?: StringCriteriaCondition[];
    ebsVolumeSizeInGib?: IntegerCriteriaCondition[];
    estimatedMonthlySavings?: DoubleCriteriaCondition[];
    resourceTag?: ResourceTagsCriteriaCondition[];
    lookBackPeriodInDays?: IntegerCriteriaCondition[];
    restartNeeded?: StringCriteriaCondition[];
}
export declare const Criteria: S.Schema<Criteria>;
export interface Schedule {
    scheduleExpression?: string;
    scheduleExpressionTimezone?: string;
    executionWindowInMinutes?: number;
}
export declare const Schedule: S.Schema<Schedule>;
export type RuleStatus = "Active" | "Inactive" | (string & {});
export declare const RuleStatus: any;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export declare const Tag: S.Schema<Tag>;
export type TagList = Tag[];
export declare const TagList: any;
export interface CreateAutomationRuleRequest {
    name: string;
    description?: string;
    ruleType: RuleType;
    organizationConfiguration?: OrganizationConfiguration;
    priority?: string;
    recommendedActionTypes: RecommendedActionType[];
    criteria?: Criteria;
    schedule: Schedule;
    status: RuleStatus;
    tags?: Tag[];
    clientToken?: string;
}
export declare const CreateAutomationRuleRequest: S.Schema<CreateAutomationRuleRequest>;
export type RuleArn = string;
export type RuleId = string;
export interface CreateAutomationRuleResponse {
    ruleArn?: string;
    ruleId?: string;
    name?: string;
    description?: string;
    ruleType?: RuleType;
    ruleRevision?: number;
    organizationConfiguration?: OrganizationConfiguration;
    priority?: string;
    recommendedActionTypes?: RecommendedActionType[];
    criteria?: Criteria;
    schedule?: Schedule;
    status?: RuleStatus;
    tags?: Tag[];
    createdTimestamp?: Date;
}
export declare const CreateAutomationRuleResponse: S.Schema<CreateAutomationRuleResponse>;
export interface DeleteAutomationRuleRequest {
    ruleArn: string;
    ruleRevision: number;
    clientToken?: string;
}
export declare const DeleteAutomationRuleRequest: S.Schema<DeleteAutomationRuleRequest>;
export interface DeleteAutomationRuleResponse {
}
export declare const DeleteAutomationRuleResponse: S.Schema<DeleteAutomationRuleResponse>;
export interface DisassociateAccountsRequest {
    accountIds: string[];
    clientToken?: string;
}
export declare const DisassociateAccountsRequest: S.Schema<DisassociateAccountsRequest>;
export interface DisassociateAccountsResponse {
    accountIds?: string[];
    errors?: string[];
}
export declare const DisassociateAccountsResponse: S.Schema<DisassociateAccountsResponse>;
export type EventId = string;
export interface GetAutomationEventRequest {
    eventId: string;
}
export declare const GetAutomationEventRequest: S.Schema<GetAutomationEventRequest>;
export type EventType = "SnapshotAndDeleteUnattachedEbsVolume" | "UpgradeEbsVolumeType" | (string & {});
export declare const EventType: any;
export type EventStatus = "Ready" | "InProgress" | "Complete" | "Failed" | "Cancelled" | "RollbackReady" | "RollbackInProgress" | "RollbackComplete" | "RollbackFailed" | (string & {});
export declare const EventStatus: any;
export type ResourceArn = string;
export type ResourceId = string;
export type RecommendedActionId = string;
export type ResourceType = "EbsVolume" | (string & {});
export declare const ResourceType: any;
export type SavingsEstimationMode = "BeforeDiscount" | "AfterDiscount" | (string & {});
export declare const SavingsEstimationMode: any;
export interface EstimatedMonthlySavings {
    currency: string;
    beforeDiscountSavings: number;
    afterDiscountSavings: number;
    savingsEstimationMode: SavingsEstimationMode;
}
export declare const EstimatedMonthlySavings: S.Schema<EstimatedMonthlySavings>;
export interface GetAutomationEventResponse {
    eventId?: string;
    eventDescription?: string;
    eventType?: EventType;
    eventStatus?: EventStatus;
    eventStatusReason?: string;
    resourceArn?: string;
    resourceId?: string;
    recommendedActionId?: string;
    accountId?: string;
    region?: string;
    ruleId?: string;
    resourceType?: ResourceType;
    createdTimestamp?: Date;
    completedTimestamp?: Date;
    estimatedMonthlySavings?: EstimatedMonthlySavings;
}
export declare const GetAutomationEventResponse: S.Schema<GetAutomationEventResponse>;
export interface GetAutomationRuleRequest {
    ruleArn: string;
}
export declare const GetAutomationRuleRequest: S.Schema<GetAutomationRuleRequest>;
export interface GetAutomationRuleResponse {
    ruleArn?: string;
    ruleId?: string;
    name?: string;
    description?: string;
    ruleType?: RuleType;
    ruleRevision?: number;
    accountId?: string;
    organizationConfiguration?: OrganizationConfiguration;
    priority?: string;
    recommendedActionTypes?: RecommendedActionType[];
    criteria?: Criteria;
    schedule?: Schedule;
    status?: RuleStatus;
    tags?: Tag[];
    createdTimestamp?: Date;
    lastUpdatedTimestamp?: Date;
}
export declare const GetAutomationRuleResponse: S.Schema<GetAutomationRuleResponse>;
export interface GetEnrollmentConfigurationRequest {
}
export declare const GetEnrollmentConfigurationRequest: S.Schema<GetEnrollmentConfigurationRequest>;
export type EnrollmentStatus = "Active" | "Inactive" | "Pending" | "Failed" | (string & {});
export declare const EnrollmentStatus: any;
export type OrganizationRuleMode = "AnyAllowed" | "NoneAllowed" | (string & {});
export declare const OrganizationRuleMode: any;
export interface GetEnrollmentConfigurationResponse {
    status: EnrollmentStatus;
    statusReason?: string;
    organizationRuleMode?: OrganizationRuleMode;
    lastUpdatedTimestamp?: Date;
}
export declare const GetEnrollmentConfigurationResponse: S.Schema<GetEnrollmentConfigurationResponse>;
export type NextToken = string;
export interface ListAccountsRequest {
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAccountsRequest: S.Schema<ListAccountsRequest>;
export interface AccountInfo {
    accountId: string;
    status: EnrollmentStatus;
    organizationRuleMode: OrganizationRuleMode;
    statusReason?: string;
    lastUpdatedTimestamp: Date;
}
export declare const AccountInfo: S.Schema<AccountInfo>;
export type AccountInfoList = AccountInfo[];
export declare const AccountInfoList: any;
export interface ListAccountsResponse {
    accounts: AccountInfo[];
    nextToken?: string;
}
export declare const ListAccountsResponse: S.Schema<ListAccountsResponse>;
export type AutomationEventFilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export declare const FilterValues: any;
export interface AutomationEventFilter {
    name: string;
    values: string[];
}
export declare const AutomationEventFilter: S.Schema<AutomationEventFilter>;
export type AutomationEventFilterList = AutomationEventFilter[];
export declare const AutomationEventFilterList: any;
export interface ListAutomationEventsRequest {
    filters?: AutomationEventFilter[];
    startTimeInclusive?: Date;
    endTimeExclusive?: Date;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAutomationEventsRequest: S.Schema<ListAutomationEventsRequest>;
export interface AutomationEvent {
    eventId?: string;
    eventDescription?: string;
    eventType?: EventType;
    eventStatus?: EventStatus;
    eventStatusReason?: string;
    resourceArn?: string;
    resourceId?: string;
    recommendedActionId?: string;
    accountId?: string;
    region?: string;
    ruleId?: string;
    resourceType?: ResourceType;
    createdTimestamp?: Date;
    completedTimestamp?: Date;
    estimatedMonthlySavings?: EstimatedMonthlySavings;
}
export declare const AutomationEvent: S.Schema<AutomationEvent>;
export type AutomationEvents = AutomationEvent[];
export declare const AutomationEvents: any;
export interface ListAutomationEventsResponse {
    automationEvents?: AutomationEvent[];
    nextToken?: string;
}
export declare const ListAutomationEventsResponse: S.Schema<ListAutomationEventsResponse>;
export interface ListAutomationEventStepsRequest {
    eventId: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAutomationEventStepsRequest: S.Schema<ListAutomationEventStepsRequest>;
export type StepId = string;
export type StepType = "CreateEbsSnapshot" | "DeleteEbsVolume" | "ModifyEbsVolume" | "CreateEbsVolume" | (string & {});
export declare const StepType: any;
export type StepStatus = "Ready" | "InProgress" | "Complete" | "Failed" | (string & {});
export declare const StepStatus: any;
export interface AutomationEventStep {
    eventId?: string;
    stepId?: string;
    stepType?: StepType;
    stepStatus?: StepStatus;
    resourceId?: string;
    startTimestamp?: Date;
    completedTimestamp?: Date;
    estimatedMonthlySavings?: EstimatedMonthlySavings;
}
export declare const AutomationEventStep: S.Schema<AutomationEventStep>;
export type AutomationEventSteps = AutomationEventStep[];
export declare const AutomationEventSteps: any;
export interface ListAutomationEventStepsResponse {
    automationEventSteps?: AutomationEventStep[];
    nextToken?: string;
}
export declare const ListAutomationEventStepsResponse: S.Schema<ListAutomationEventStepsResponse>;
export interface ListAutomationEventSummariesRequest {
    filters?: AutomationEventFilter[];
    startDateInclusive?: string;
    endDateExclusive?: string;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAutomationEventSummariesRequest: S.Schema<ListAutomationEventSummariesRequest>;
export type SummaryDimensionKey = string;
export interface SummaryDimension {
    key: string;
    value: string;
}
export declare const SummaryDimension: S.Schema<SummaryDimension>;
export type SummaryDimensions = SummaryDimension[];
export declare const SummaryDimensions: any;
export interface TimePeriod {
    startTimeInclusive?: Date;
    endTimeExclusive?: Date;
}
export declare const TimePeriod: S.Schema<TimePeriod>;
export interface SummaryTotals {
    automationEventCount?: number;
    estimatedMonthlySavings?: EstimatedMonthlySavings;
}
export declare const SummaryTotals: S.Schema<SummaryTotals>;
export interface AutomationEventSummary {
    key?: string;
    dimensions?: SummaryDimension[];
    timePeriod?: TimePeriod;
    total?: SummaryTotals;
}
export declare const AutomationEventSummary: S.Schema<AutomationEventSummary>;
export type AutomationEventSummaryList = AutomationEventSummary[];
export declare const AutomationEventSummaryList: any;
export interface ListAutomationEventSummariesResponse {
    automationEventSummaries?: AutomationEventSummary[];
    nextToken?: string;
}
export declare const ListAutomationEventSummariesResponse: S.Schema<ListAutomationEventSummariesResponse>;
export interface OrganizationScope {
    accountIds?: string[];
}
export declare const OrganizationScope: S.Schema<OrganizationScope>;
export interface ListAutomationRulePreviewRequest {
    ruleType: RuleType;
    organizationScope?: OrganizationScope;
    recommendedActionTypes: RecommendedActionType[];
    criteria?: Criteria;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAutomationRulePreviewRequest: S.Schema<ListAutomationRulePreviewRequest>;
export interface EbsVolumeConfiguration {
    type?: string;
    sizeInGib?: number;
    iops?: number;
    throughput?: number;
}
export declare const EbsVolumeConfiguration: S.Schema<EbsVolumeConfiguration>;
export interface EbsVolume {
    configuration?: EbsVolumeConfiguration;
}
export declare const EbsVolume: S.Schema<EbsVolume>;
export type ResourceDetails = {
    ebsVolume: EbsVolume;
};
export declare const ResourceDetails: any;
export interface PreviewResult {
    recommendedActionId?: string;
    resourceArn?: string;
    resourceId?: string;
    accountId?: string;
    region?: string;
    resourceType?: ResourceType;
    lookBackPeriodInDays?: number;
    recommendedActionType?: RecommendedActionType;
    currentResourceSummary?: string;
    currentResourceDetails?: ResourceDetails;
    recommendedResourceSummary?: string;
    recommendedResourceDetails?: ResourceDetails;
    restartNeeded?: boolean;
    estimatedMonthlySavings?: EstimatedMonthlySavings;
    resourceTags?: Tag[];
}
export declare const PreviewResult: S.Schema<PreviewResult>;
export type PreviewResults = PreviewResult[];
export declare const PreviewResults: any;
export interface ListAutomationRulePreviewResponse {
    previewResults?: PreviewResult[];
    nextToken?: string;
}
export declare const ListAutomationRulePreviewResponse: S.Schema<ListAutomationRulePreviewResponse>;
export interface ListAutomationRulePreviewSummariesRequest {
    ruleType: RuleType;
    organizationScope?: OrganizationScope;
    recommendedActionTypes: RecommendedActionType[];
    criteria?: Criteria;
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAutomationRulePreviewSummariesRequest: S.Schema<ListAutomationRulePreviewSummariesRequest>;
export interface RulePreviewTotal {
    recommendedActionCount: number;
    estimatedMonthlySavings: EstimatedMonthlySavings;
}
export declare const RulePreviewTotal: S.Schema<RulePreviewTotal>;
export interface PreviewResultSummary {
    key: string;
    total: RulePreviewTotal;
}
export declare const PreviewResultSummary: S.Schema<PreviewResultSummary>;
export type PreviewResultSummaries = PreviewResultSummary[];
export declare const PreviewResultSummaries: any;
export interface ListAutomationRulePreviewSummariesResponse {
    previewResultSummaries?: PreviewResultSummary[];
    nextToken?: string;
}
export declare const ListAutomationRulePreviewSummariesResponse: S.Schema<ListAutomationRulePreviewSummariesResponse>;
export type AutomationRuleFilterName = string;
export interface Filter {
    name: string;
    values: string[];
}
export declare const Filter: S.Schema<Filter>;
export type FilterList = Filter[];
export declare const FilterList: any;
export interface ListAutomationRulesRequest {
    filters?: Filter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListAutomationRulesRequest: S.Schema<ListAutomationRulesRequest>;
export interface AutomationRule {
    ruleArn?: string;
    ruleId?: string;
    name?: string;
    description?: string;
    ruleType?: RuleType;
    ruleRevision?: number;
    accountId?: string;
    organizationConfiguration?: OrganizationConfiguration;
    priority?: string;
    recommendedActionTypes?: RecommendedActionType[];
    schedule?: Schedule;
    status?: RuleStatus;
    createdTimestamp?: Date;
    lastUpdatedTimestamp?: Date;
}
export declare const AutomationRule: S.Schema<AutomationRule>;
export type AutomationRules = AutomationRule[];
export declare const AutomationRules: any;
export interface ListAutomationRulesResponse {
    automationRules?: AutomationRule[];
    nextToken?: string;
}
export declare const ListAutomationRulesResponse: S.Schema<ListAutomationRulesResponse>;
export type RecommendedActionFilterName = string;
export interface RecommendedActionFilter {
    name: string;
    values: string[];
}
export declare const RecommendedActionFilter: S.Schema<RecommendedActionFilter>;
export type RecommendedActionFilterList = RecommendedActionFilter[];
export declare const RecommendedActionFilterList: any;
export interface ListRecommendedActionsRequest {
    filters?: RecommendedActionFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecommendedActionsRequest: S.Schema<ListRecommendedActionsRequest>;
export interface RecommendedAction {
    recommendedActionId?: string;
    resourceArn?: string;
    resourceId?: string;
    accountId?: string;
    region?: string;
    resourceType?: ResourceType;
    lookBackPeriodInDays?: number;
    recommendedActionType?: RecommendedActionType;
    currentResourceSummary?: string;
    currentResourceDetails?: ResourceDetails;
    recommendedResourceSummary?: string;
    recommendedResourceDetails?: ResourceDetails;
    restartNeeded?: boolean;
    estimatedMonthlySavings?: EstimatedMonthlySavings;
    resourceTags?: Tag[];
}
export declare const RecommendedAction: S.Schema<RecommendedAction>;
export type RecommendedActions = RecommendedAction[];
export declare const RecommendedActions: any;
export interface ListRecommendedActionsResponse {
    recommendedActions?: RecommendedAction[];
    nextToken?: string;
}
export declare const ListRecommendedActionsResponse: S.Schema<ListRecommendedActionsResponse>;
export interface ListRecommendedActionSummariesRequest {
    filters?: RecommendedActionFilter[];
    maxResults?: number;
    nextToken?: string;
}
export declare const ListRecommendedActionSummariesRequest: S.Schema<ListRecommendedActionSummariesRequest>;
export interface RecommendedActionTotal {
    recommendedActionCount: number;
    estimatedMonthlySavings: EstimatedMonthlySavings;
}
export declare const RecommendedActionTotal: S.Schema<RecommendedActionTotal>;
export interface RecommendedActionSummary {
    key: string;
    total: RecommendedActionTotal;
}
export declare const RecommendedActionSummary: S.Schema<RecommendedActionSummary>;
export type RecommendedActionSummaries = RecommendedActionSummary[];
export declare const RecommendedActionSummaries: any;
export interface ListRecommendedActionSummariesResponse {
    recommendedActionSummaries?: RecommendedActionSummary[];
    nextToken?: string;
}
export declare const ListRecommendedActionSummariesResponse: S.Schema<ListRecommendedActionSummariesResponse>;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: Tag[];
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface RollbackAutomationEventRequest {
    eventId: string;
    clientToken?: string;
}
export declare const RollbackAutomationEventRequest: S.Schema<RollbackAutomationEventRequest>;
export interface RollbackAutomationEventResponse {
    eventId?: string;
    eventStatus?: EventStatus;
}
export declare const RollbackAutomationEventResponse: S.Schema<RollbackAutomationEventResponse>;
export interface StartAutomationEventRequest {
    recommendedActionId: string;
    clientToken?: string;
}
export declare const StartAutomationEventRequest: S.Schema<StartAutomationEventRequest>;
export interface StartAutomationEventResponse {
    recommendedActionId?: string;
    eventId?: string;
    eventStatus?: EventStatus;
}
export declare const StartAutomationEventResponse: S.Schema<StartAutomationEventResponse>;
export interface TagResourceRequest {
    resourceArn: string;
    ruleRevision: number;
    tags: Tag[];
    clientToken?: string;
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    ruleRevision: number;
    tagKeys: string[];
    clientToken?: string;
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateAutomationRuleRequest {
    ruleArn: string;
    ruleRevision: number;
    name?: string;
    description?: string;
    ruleType?: RuleType;
    organizationConfiguration?: OrganizationConfiguration;
    priority?: string;
    recommendedActionTypes?: RecommendedActionType[];
    criteria?: Criteria;
    schedule?: Schedule;
    status?: RuleStatus;
    clientToken?: string;
}
export declare const UpdateAutomationRuleRequest: S.Schema<UpdateAutomationRuleRequest>;
export interface UpdateAutomationRuleResponse {
    ruleArn?: string;
    ruleRevision?: number;
    name?: string;
    description?: string;
    ruleType?: RuleType;
    organizationConfiguration?: OrganizationConfiguration;
    priority?: string;
    recommendedActionTypes?: RecommendedActionType[];
    criteria?: Criteria;
    schedule?: Schedule;
    status?: RuleStatus;
    createdTimestamp?: Date;
    lastUpdatedTimestamp?: Date;
}
export declare const UpdateAutomationRuleResponse: S.Schema<UpdateAutomationRuleResponse>;
export interface UpdateEnrollmentConfigurationRequest {
    status: EnrollmentStatus;
    clientToken?: string;
}
export declare const UpdateEnrollmentConfigurationRequest: S.Schema<UpdateEnrollmentConfigurationRequest>;
export interface UpdateEnrollmentConfigurationResponse {
    status: EnrollmentStatus;
    statusReason?: string;
    lastUpdatedTimestamp: Date;
}
export declare const UpdateEnrollmentConfigurationResponse: S.Schema<UpdateEnrollmentConfigurationResponse>;
export type AssociateAccountsError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Associates one or more member accounts with your organization's management account, enabling centralized implementation of optimization actions across those accounts. Once associated, the management account (or a delegated administrator) can apply recommended actions to the member account. When you associate a member account, its organization rule mode is automatically set to "Any allowed," which permits the management account to create Automation rules that automatically apply actions to that account. If the member account has not previously enabled the Automation feature, the association process automatically enables it.
 *
 * Only the management account or a delegated administrator can perform this action.
 */
export declare const associateAccounts: API.OperationMethod<AssociateAccountsRequest, AssociateAccountsResponse, AssociateAccountsError, Credentials | HttpClient.HttpClient>;
export type CreateAutomationRuleError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates a new automation rule to apply recommended actions to resources based on specified criteria.
 */
export declare const createAutomationRule: API.OperationMethod<CreateAutomationRuleRequest, CreateAutomationRuleResponse, CreateAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomationRuleError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing automation rule.
 */
export declare const deleteAutomationRule: API.OperationMethod<DeleteAutomationRuleRequest, DeleteAutomationRuleResponse, DeleteAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type DisassociateAccountsError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Disassociates member accounts from your organization's management account, removing centralized automation capabilities. Once disassociated, organization rules no longer apply to the member account, and the management account (or delegated administrator) cannot create Automation rules for that account.
 *
 * Only the management account or a delegated administrator can perform this action.
 */
export declare const disassociateAccounts: API.OperationMethod<DisassociateAccountsRequest, DisassociateAccountsResponse, DisassociateAccountsError, Credentials | HttpClient.HttpClient>;
export type GetAutomationEventError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about a specific automation event.
 */
export declare const getAutomationEvent: API.OperationMethod<GetAutomationEventRequest, GetAutomationEventResponse, GetAutomationEventError, Credentials | HttpClient.HttpClient>;
export type GetAutomationRuleError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about a specific automation rule.
 */
export declare const getAutomationRule: API.OperationMethod<GetAutomationRuleRequest, GetAutomationRuleResponse, GetAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type GetEnrollmentConfigurationError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current enrollment configuration for Compute Optimizer Automation.
 */
export declare const getEnrollmentConfiguration: API.OperationMethod<GetEnrollmentConfigurationRequest, GetEnrollmentConfigurationResponse, GetEnrollmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListAccountsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the accounts in your organization that are enrolled in Compute Optimizer and whether they have enabled Automation.
 *
 * Only the management account or a delegated administrator can perform this action.
 */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, Credentials | HttpClient.HttpClient, AccountInfo>;
export type ListAutomationEventsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists automation events based on specified filters. You can retrieve events that were created within the past year.
 */
export declare const listAutomationEvents: API.PaginatedOperationMethod<ListAutomationEventsRequest, ListAutomationEventsResponse, ListAutomationEventsError, Credentials | HttpClient.HttpClient, AutomationEvent>;
export type ListAutomationEventStepsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the steps for a specific automation event. You can only list steps for events created within the past year.
 */
export declare const listAutomationEventSteps: API.PaginatedOperationMethod<ListAutomationEventStepsRequest, ListAutomationEventStepsResponse, ListAutomationEventStepsError, Credentials | HttpClient.HttpClient, AutomationEventStep>;
export type ListAutomationEventSummariesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Provides a summary of automation events based on specified filters. Only events created within the past year will be included in the summary.
 */
export declare const listAutomationEventSummaries: API.PaginatedOperationMethod<ListAutomationEventSummariesRequest, ListAutomationEventSummariesResponse, ListAutomationEventSummariesError, Credentials | HttpClient.HttpClient, AutomationEventSummary>;
export type ListAutomationRulePreviewError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns a preview of the recommended actions that match your Automation rule's configuration and criteria.
 */
export declare const listAutomationRulePreview: API.PaginatedOperationMethod<ListAutomationRulePreviewRequest, ListAutomationRulePreviewResponse, ListAutomationRulePreviewError, Credentials | HttpClient.HttpClient, PreviewResult>;
export type ListAutomationRulePreviewSummariesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns a summary of the recommended actions that match your rule preview configuration and criteria.
 */
export declare const listAutomationRulePreviewSummaries: API.PaginatedOperationMethod<ListAutomationRulePreviewSummariesRequest, ListAutomationRulePreviewSummariesResponse, ListAutomationRulePreviewSummariesError, Credentials | HttpClient.HttpClient, PreviewResultSummary>;
export type ListAutomationRulesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the automation rules that match specified filters.
 */
export declare const listAutomationRules: API.PaginatedOperationMethod<ListAutomationRulesRequest, ListAutomationRulesResponse, ListAutomationRulesError, Credentials | HttpClient.HttpClient, AutomationRule>;
export type ListRecommendedActionsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the recommended actions based that match specified filters.
 *
 * Management accounts and delegated administrators can retrieve recommended actions that include associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const listRecommendedActions: API.PaginatedOperationMethod<ListRecommendedActionsRequest, ListRecommendedActionsResponse, ListRecommendedActionsError, Credentials | HttpClient.HttpClient, RecommendedAction>;
export type ListRecommendedActionSummariesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Provides a summary of recommended actions based on specified filters.
 *
 * Management accounts and delegated administrators can retrieve recommended actions that include associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const listRecommendedActionSummaries: API.PaginatedOperationMethod<ListRecommendedActionSummariesRequest, ListRecommendedActionSummariesResponse, ListRecommendedActionSummariesError, Credentials | HttpClient.HttpClient, RecommendedActionSummary>;
export type ListTagsForResourceError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RollbackAutomationEventError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Initiates a rollback for a completed automation event.
 *
 * Management accounts and delegated administrators can only initiate a rollback for events belonging to associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const rollbackAutomationEvent: API.OperationMethod<RollbackAutomationEventRequest, RollbackAutomationEventResponse, RollbackAutomationEventError, Credentials | HttpClient.HttpClient>;
export type StartAutomationEventError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Initiates a one-time, on-demand automation for the specified recommended action.
 *
 * Management accounts and delegated administrators can only initiate recommended actions for associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const startAutomationEvent: API.OperationMethod<StartAutomationEventRequest, StartAutomationEventResponse, StartAutomationEventError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Adds tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomationRuleError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates an existing automation rule.
 */
export declare const updateAutomationRule: API.OperationMethod<UpdateAutomationRuleRequest, UpdateAutomationRuleResponse, UpdateAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateEnrollmentConfigurationError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates your account’s Compute Optimizer Automation enrollment configuration.
 */
export declare const updateEnrollmentConfiguration: API.OperationMethod<UpdateEnrollmentConfigurationRequest, UpdateEnrollmentConfigurationResponse, UpdateEnrollmentConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=compute-optimizer-automation.d.ts.map