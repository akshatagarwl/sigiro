import * as HttpClient from "effect/unstable/http/HttpClient";
import * as redacted from "effect/Redacted";
import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
declare const AccessDeniedException_base: S.Class<AccessDeniedException, S.TaggedStruct<"AccessDeniedException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.Class<ConflictException, S.TaggedStruct<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.Class<InternalServerException, S.TaggedStruct<"InternalServerException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.Class<ResourceNotFoundException, S.TaggedStruct<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.Class<ServiceQuotaExceededException, S.TaggedStruct<"ServiceQuotaExceededException", {
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.Class<ThrottlingException, S.TaggedStruct<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.Class<ValidationException, S.TaggedStruct<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type InputString = string;
export type OptInType = string;
export interface ApplyPendingMaintenanceActionInput {
    resourceArn: string;
    applyAction: string;
    optInType: string;
    applyOn?: string;
}
export declare const ApplyPendingMaintenanceActionInput: S.Schema<ApplyPendingMaintenanceActionInput>;
export interface PendingMaintenanceActionDetails {
    action: string;
    autoAppliedAfterDate?: string;
    forcedApplyDate?: string;
    optInStatus?: string;
    currentApplyDate?: string;
    description?: string;
}
export declare const PendingMaintenanceActionDetails: S.Schema<PendingMaintenanceActionDetails>;
export type PendingMaintenanceActionDetailsList = PendingMaintenanceActionDetails[];
export declare const PendingMaintenanceActionDetailsList: any;
export interface ResourcePendingMaintenanceAction {
    resourceArn?: string;
    pendingMaintenanceActionDetails?: PendingMaintenanceActionDetails[];
}
export declare const ResourcePendingMaintenanceAction: S.Schema<ResourcePendingMaintenanceAction>;
export interface ApplyPendingMaintenanceActionOutput {
    resourcePendingMaintenanceAction: ResourcePendingMaintenanceAction;
}
export declare const ApplyPendingMaintenanceActionOutput: S.Schema<ApplyPendingMaintenanceActionOutput>;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export declare const TagMap: any;
export interface CopyClusterSnapshotInput {
    snapshotArn: string;
    targetSnapshotName: string;
    kmsKeyId?: string;
    copyTags?: boolean;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CopyClusterSnapshotInput: S.Schema<CopyClusterSnapshotInput>;
export type StringList = string[];
export declare const StringList: any;
export type Status = string;
export type SnapshotType = string;
export interface ClusterSnapshot {
    subnetIds: string[];
    snapshotName: string;
    snapshotArn: string;
    snapshotCreationTime: string;
    clusterArn: string;
    clusterCreationTime: string;
    status: string;
    vpcSecurityGroupIds: string[];
    adminUserName: string;
    kmsKeyId: string;
    snapshotType?: string;
}
export declare const ClusterSnapshot: S.Schema<ClusterSnapshot>;
export interface CopyClusterSnapshotOutput {
    snapshot: ClusterSnapshot;
}
export declare const CopyClusterSnapshotOutput: S.Schema<CopyClusterSnapshotOutput>;
export type Auth = string;
export type Password = string | redacted.Redacted<string>;
export interface CreateClusterInput {
    clusterName: string;
    authType: string;
    adminUserName: string;
    adminUserPassword: string | redacted.Redacted<string>;
    shardCapacity: number;
    shardCount: number;
    vpcSecurityGroupIds?: string[];
    subnetIds?: string[];
    kmsKeyId?: string;
    clientToken?: string;
    preferredMaintenanceWindow?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    backupRetentionPeriod?: number;
    preferredBackupWindow?: string;
    shardInstanceCount?: number;
}
export declare const CreateClusterInput: S.Schema<CreateClusterInput>;
export interface Shard {
    shardId: string;
    createTime: string;
    status: string;
}
export declare const Shard: S.Schema<Shard>;
export type ShardList = Shard[];
export declare const ShardList: any;
export interface Cluster {
    clusterName: string;
    clusterArn: string;
    status: string;
    clusterEndpoint?: string;
    createTime: string;
    adminUserName: string;
    authType: string;
    shardCapacity: number;
    shardCount: number;
    vpcSecurityGroupIds: string[];
    subnetIds: string[];
    preferredMaintenanceWindow: string;
    kmsKeyId: string;
    shards?: Shard[];
    backupRetentionPeriod?: number;
    preferredBackupWindow?: string;
    shardInstanceCount?: number;
}
export declare const Cluster: S.Schema<Cluster>;
export interface CreateClusterOutput {
    cluster: Cluster;
}
export declare const CreateClusterOutput: S.Schema<CreateClusterOutput>;
export interface CreateClusterSnapshotInput {
    clusterArn: string;
    snapshotName: string;
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const CreateClusterSnapshotInput: S.Schema<CreateClusterSnapshotInput>;
export interface CreateClusterSnapshotOutput {
    snapshot: ClusterSnapshot;
}
export declare const CreateClusterSnapshotOutput: S.Schema<CreateClusterSnapshotOutput>;
export interface DeleteClusterInput {
    clusterArn: string;
}
export declare const DeleteClusterInput: S.Schema<DeleteClusterInput>;
export interface DeleteClusterOutput {
    cluster: Cluster;
}
export declare const DeleteClusterOutput: S.Schema<DeleteClusterOutput>;
export interface DeleteClusterSnapshotInput {
    snapshotArn: string;
}
export declare const DeleteClusterSnapshotInput: S.Schema<DeleteClusterSnapshotInput>;
export interface DeleteClusterSnapshotOutput {
    snapshot: ClusterSnapshot;
}
export declare const DeleteClusterSnapshotOutput: S.Schema<DeleteClusterSnapshotOutput>;
export interface GetClusterInput {
    clusterArn: string;
}
export declare const GetClusterInput: S.Schema<GetClusterInput>;
export interface GetClusterOutput {
    cluster: Cluster;
}
export declare const GetClusterOutput: S.Schema<GetClusterOutput>;
export interface GetClusterSnapshotInput {
    snapshotArn: string;
}
export declare const GetClusterSnapshotInput: S.Schema<GetClusterSnapshotInput>;
export interface GetClusterSnapshotOutput {
    snapshot: ClusterSnapshot;
}
export declare const GetClusterSnapshotOutput: S.Schema<GetClusterSnapshotOutput>;
export interface GetPendingMaintenanceActionInput {
    resourceArn: string;
}
export declare const GetPendingMaintenanceActionInput: S.Schema<GetPendingMaintenanceActionInput>;
export interface GetPendingMaintenanceActionOutput {
    resourcePendingMaintenanceAction: ResourcePendingMaintenanceAction;
}
export declare const GetPendingMaintenanceActionOutput: S.Schema<GetPendingMaintenanceActionOutput>;
export type PaginationToken = string;
export interface ListClustersInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListClustersInput: S.Schema<ListClustersInput>;
export interface ClusterInList {
    clusterName: string;
    clusterArn: string;
    status: string;
}
export declare const ClusterInList: S.Schema<ClusterInList>;
export type ClusterList = ClusterInList[];
export declare const ClusterList: any;
export interface ListClustersOutput {
    clusters?: ClusterInList[];
    nextToken?: string;
}
export declare const ListClustersOutput: S.Schema<ListClustersOutput>;
export interface ListClusterSnapshotsInput {
    clusterArn?: string;
    nextToken?: string;
    maxResults?: number;
    snapshotType?: string;
}
export declare const ListClusterSnapshotsInput: S.Schema<ListClusterSnapshotsInput>;
export interface ClusterSnapshotInList {
    snapshotName: string;
    snapshotArn: string;
    clusterArn: string;
    status: string;
    snapshotCreationTime: string;
}
export declare const ClusterSnapshotInList: S.Schema<ClusterSnapshotInList>;
export type ClusterSnapshotList = ClusterSnapshotInList[];
export declare const ClusterSnapshotList: any;
export interface ListClusterSnapshotsOutput {
    snapshots?: ClusterSnapshotInList[];
    nextToken?: string;
}
export declare const ListClusterSnapshotsOutput: S.Schema<ListClusterSnapshotsOutput>;
export interface ListPendingMaintenanceActionsInput {
    nextToken?: string;
    maxResults?: number;
}
export declare const ListPendingMaintenanceActionsInput: S.Schema<ListPendingMaintenanceActionsInput>;
export type ResourcePendingMaintenanceActionList = ResourcePendingMaintenanceAction[];
export declare const ResourcePendingMaintenanceActionList: any;
export interface ListPendingMaintenanceActionsOutput {
    resourcePendingMaintenanceActions: ResourcePendingMaintenanceAction[];
    nextToken?: string;
}
export declare const ListPendingMaintenanceActionsOutput: S.Schema<ListPendingMaintenanceActionsOutput>;
export type Arn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export declare const ListTagsForResourceRequest: S.Schema<ListTagsForResourceRequest>;
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    };
}
export declare const ListTagsForResourceResponse: S.Schema<ListTagsForResourceResponse>;
export interface RestoreClusterFromSnapshotInput {
    clusterName: string;
    snapshotArn: string;
    vpcSecurityGroupIds?: string[];
    subnetIds?: string[];
    kmsKeyId?: string;
    tags?: {
        [key: string]: string | undefined;
    };
    shardCapacity?: number;
    shardInstanceCount?: number;
}
export declare const RestoreClusterFromSnapshotInput: S.Schema<RestoreClusterFromSnapshotInput>;
export interface RestoreClusterFromSnapshotOutput {
    cluster: Cluster;
}
export declare const RestoreClusterFromSnapshotOutput: S.Schema<RestoreClusterFromSnapshotOutput>;
export interface StartClusterInput {
    clusterArn: string;
}
export declare const StartClusterInput: S.Schema<StartClusterInput>;
export interface StartClusterOutput {
    cluster: Cluster;
}
export declare const StartClusterOutput: S.Schema<StartClusterOutput>;
export interface StopClusterInput {
    clusterArn: string;
}
export declare const StopClusterInput: S.Schema<StopClusterInput>;
export interface StopClusterOutput {
    cluster: Cluster;
}
export declare const StopClusterOutput: S.Schema<StopClusterOutput>;
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export declare const TagResourceRequest: S.Schema<TagResourceRequest>;
export interface TagResourceResponse {
}
export declare const TagResourceResponse: S.Schema<TagResourceResponse>;
export type TagKeyList = string[];
export declare const TagKeyList: any;
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export declare const UntagResourceRequest: S.Schema<UntagResourceRequest>;
export interface UntagResourceResponse {
}
export declare const UntagResourceResponse: S.Schema<UntagResourceResponse>;
export interface UpdateClusterInput {
    clusterArn: string;
    authType?: string;
    shardCapacity?: number;
    shardCount?: number;
    vpcSecurityGroupIds?: string[];
    subnetIds?: string[];
    adminUserPassword?: string | redacted.Redacted<string>;
    clientToken?: string;
    preferredMaintenanceWindow?: string;
    backupRetentionPeriod?: number;
    preferredBackupWindow?: string;
    shardInstanceCount?: number;
}
export declare const UpdateClusterInput: S.Schema<UpdateClusterInput>;
export interface UpdateClusterOutput {
    cluster: Cluster;
}
export declare const UpdateClusterOutput: S.Schema<UpdateClusterOutput>;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export declare const ValidationExceptionField: S.Schema<ValidationExceptionField>;
export type ValidationExceptionFieldList = ValidationExceptionField[];
export declare const ValidationExceptionFieldList: any;
export type ApplyPendingMaintenanceActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The type of pending maintenance action to be applied to the resource.
 */
export declare const applyPendingMaintenanceAction: API.OperationMethod<ApplyPendingMaintenanceActionInput, ApplyPendingMaintenanceActionOutput, ApplyPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type CopyClusterSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Copies a snapshot of an elastic cluster.
 */
export declare const copyClusterSnapshot: API.OperationMethod<CopyClusterSnapshotInput, CopyClusterSnapshotOutput, CopyClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Amazon DocumentDB elastic cluster and returns its cluster structure.
 */
export declare const createCluster: API.OperationMethod<CreateClusterInput, CreateClusterOutput, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateClusterSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of an elastic cluster.
 */
export declare const createClusterSnapshot: API.OperationMethod<CreateClusterSnapshotInput, CreateClusterSnapshotOutput, CreateClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an elastic cluster.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterInput, DeleteClusterOutput, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an elastic cluster snapshot.
 */
export declare const deleteClusterSnapshot: API.OperationMethod<DeleteClusterSnapshotInput, DeleteClusterSnapshotOutput, DeleteClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific elastic cluster.
 */
export declare const getCluster: API.OperationMethod<GetClusterInput, GetClusterOutput, GetClusterError, Credentials | HttpClient.HttpClient>;
export type GetClusterSnapshotError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific elastic cluster snapshot
 */
export declare const getClusterSnapshot: API.OperationMethod<GetClusterSnapshotInput, GetClusterSnapshotOutput, GetClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetPendingMaintenanceActionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all maintenance actions that are pending.
 */
export declare const getPendingMaintenanceAction: API.OperationMethod<GetPendingMaintenanceActionInput, GetPendingMaintenanceActionOutput, GetPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type ListClustersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about provisioned Amazon DocumentDB elastic clusters.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersInput, ListClustersOutput, ListClustersError, Credentials | HttpClient.HttpClient, ClusterInList>;
export type ListClusterSnapshotsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about snapshots for a specified elastic cluster.
 */
export declare const listClusterSnapshots: API.PaginatedOperationMethod<ListClusterSnapshotsInput, ListClusterSnapshotsOutput, ListClusterSnapshotsError, Credentials | HttpClient.HttpClient, ClusterSnapshotInList>;
export type ListPendingMaintenanceActionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all maintenance actions that are pending.
 */
export declare const listPendingMaintenanceActions: API.PaginatedOperationMethod<ListPendingMaintenanceActionsInput, ListPendingMaintenanceActionsOutput, ListPendingMaintenanceActionsError, Credentials | HttpClient.HttpClient, ResourcePendingMaintenanceAction>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags on a elastic cluster resource
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RestoreClusterFromSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores an elastic cluster from a snapshot.
 */
export declare const restoreClusterFromSnapshot: API.OperationMethod<RestoreClusterFromSnapshotInput, RestoreClusterFromSnapshotOutput, RestoreClusterFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type StartClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restarts the stopped elastic cluster that is specified by `clusterARN`.
 */
export declare const startCluster: API.OperationMethod<StartClusterInput, StartClusterOutput, StartClusterError, Credentials | HttpClient.HttpClient>;
export type StopClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the running elastic cluster that is specified by `clusterArn`.
 * The elastic cluster must be in the *available* state.
 */
export declare const stopCluster: API.OperationMethod<StopClusterInput, StopClusterOutput, StopClusterError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds metadata tags to an elastic cluster resource
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes metadata tags from an elastic cluster resource
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies an elastic cluster. This includes updating admin-username/password,
 * upgrading the API version, and setting up a backup window and maintenance window
 */
export declare const updateCluster: API.OperationMethod<UpdateClusterInput, UpdateClusterOutput, UpdateClusterError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=docdb-elastic.d.ts.map