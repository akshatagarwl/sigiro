import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DestinationNotVerified_base: S.Class<DestinationNotVerified, S.TaggedStruct<"DestinationNotVerified", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DestinationNotVerified extends /*@__PURE__*/ DestinationNotVerified_base {
}
declare const EmailAddressCreatedTooRecently_base: S.Class<EmailAddressCreatedTooRecently, S.TaggedStruct<"EmailAddressCreatedTooRecently", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EmailAddressCreatedTooRecently extends /*@__PURE__*/ EmailAddressCreatedTooRecently_base {
}
declare const EmailAddressNotFound_base: S.Class<EmailAddressNotFound, S.TaggedStruct<"EmailAddressNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EmailAddressNotFound extends /*@__PURE__*/ EmailAddressNotFound_base {
}
declare const EmailRoutingRuleNotFound_base: S.Class<EmailRoutingRuleNotFound, S.TaggedStruct<"EmailRoutingRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EmailRoutingRuleNotFound extends /*@__PURE__*/ EmailRoutingRuleNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const WorkerScriptNotFound_base: S.Class<WorkerScriptNotFound, S.TaggedStruct<"WorkerScriptNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WorkerScriptNotFound extends /*@__PURE__*/ WorkerScriptNotFound_base {
}
export interface CreateAddressRequest {
    /** Identifier. */
    accountId: string;
    /** The contact email address of the user. */
    email: string;
}
export declare const CreateAddressRequest: S.Schema<CreateAddressRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export declare const CreateAddressResponse: S.Schema<CreateAddressResponse>;
export interface CreateDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Domain of your zone. */
    name?: string;
}
export declare const CreateDnsRequest: S.Schema<CreateDnsRequest>;
export type DnsCreateResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
export declare const DnsCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDnsResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: DnsCreateResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export declare const CreateDnsResponse: S.Schema<CreateDnsResponse>;
export type RulesCreateRequestActionsItemType = "drop" | "forward" | "worker";
export declare const RulesCreateRequestActionsItemType: any;
export type RulesCreateRequestActionsItemValueList = Array<string>;
export declare const RulesCreateRequestActionsItemValueList: S.Schema<RulesCreateRequestActionsItemValueList>;
export interface RulesCreateRequestActionsItem {
    /** Type of supported action. */
    type: RulesCreateRequestActionsItemType | (string & {});
    value?: RulesCreateRequestActionsItemValueList;
}
export declare const RulesCreateRequestActionsItem: S.Schema<RulesCreateRequestActionsItem>;
export type RulesCreateRequestActionsList = Array<RulesCreateRequestActionsItem>;
export declare const RulesCreateRequestActionsList: S.Schema<RulesCreateRequestActionsList>;
export type RulesCreateRequestMatchersItemType = "all" | "literal";
export declare const RulesCreateRequestMatchersItemType: any;
export type RulesCreateRequestMatchersItemField = "to";
export declare const RulesCreateRequestMatchersItemField: any;
export interface RulesCreateRequestMatchersItem {
    /** Type of matcher. */
    type: RulesCreateRequestMatchersItemType | (string & {});
    /** Field for type matcher. */
    field?: RulesCreateRequestMatchersItemField | (string & {});
    /** Value for matcher. */
    value?: string;
}
export declare const RulesCreateRequestMatchersItem: S.Schema<RulesCreateRequestMatchersItem>;
export type RulesCreateRequestMatchersList = Array<RulesCreateRequestMatchersItem>;
export declare const RulesCreateRequestMatchersList: S.Schema<RulesCreateRequestMatchersList>;
export type RulesCreateRequestSource = "api" | "wrangler";
export declare const RulesCreateRequestSource: any;
export interface CreateRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** List actions patterns. */
    actions: RulesCreateRequestActionsList;
    /** Matching patterns to forward to your actions. */
    matchers: RulesCreateRequestMatchersList;
    /** Routing rule status. */
    enabled?: boolean;
    /** Routing rule name. */
    name?: string;
    /** Public tag (script_tag) of the Worker that owns this rule. Required when */
    ownerWorkerTag?: string;
    /** Priority of the routing rule. */
    priority?: number;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesCreateRequestSource | (string & {});
}
export declare const CreateRuleRequest: S.Schema<CreateRuleRequest>;
export type RulesCreateResponseActionsItemType = "drop" | "forward" | "worker";
export declare const RulesCreateResponseActionsItemType: any;
export type RulesCreateResponseActionsItemValueList = Array<string>;
export declare const RulesCreateResponseActionsItemValueList: S.Schema<RulesCreateResponseActionsItemValueList>;
export interface RulesCreateResponseActionsItem {
    /** Type of supported action. */
    type: RulesCreateResponseActionsItemType;
    value?: RulesCreateResponseActionsItemValueList | null;
}
export declare const RulesCreateResponseActionsItem: S.Schema<RulesCreateResponseActionsItem>;
export type RulesCreateResponseActionsList = Array<RulesCreateResponseActionsItem>;
export declare const RulesCreateResponseActionsList: S.Schema<RulesCreateResponseActionsList>;
export type RulesCreateResponseMatchersItemType = "all" | "literal";
export declare const RulesCreateResponseMatchersItemType: any;
export type RulesCreateResponseMatchersItemField = "to";
export declare const RulesCreateResponseMatchersItemField: any;
export interface RulesCreateResponseMatchersItem {
    /** Type of matcher. */
    type: RulesCreateResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesCreateResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export declare const RulesCreateResponseMatchersItem: S.Schema<RulesCreateResponseMatchersItem>;
export type RulesCreateResponseMatchersList = Array<RulesCreateResponseMatchersItem>;
export declare const RulesCreateResponseMatchersList: S.Schema<RulesCreateResponseMatchersList>;
export type RulesCreateResponseSource = "api" | "wrangler";
export declare const RulesCreateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesCreateResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesCreateResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesCreateResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export declare const CreateRuleResponse: S.Schema<CreateRuleResponse>;
export interface DeleteAddressRequest {
    /** Identifier. */
    accountId: string;
    /** Destination address identifier. */
    destinationAddressIdentifier: string;
}
export declare const DeleteAddressRequest: S.Schema<DeleteAddressRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export declare const DeleteAddressResponse: S.Schema<DeleteAddressResponse>;
export interface DeleteDnsRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const DeleteDnsRequest: S.Schema<DeleteDnsRequest>;
export interface DeleteDnsResponse {
}
export declare const DeleteDnsResponse: S.Schema<DeleteDnsResponse>;
export interface DeleteRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Routing rule identifier. */
    ruleIdentifier: string;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export type RulesDeleteResponseActionsItemType = "drop" | "forward" | "worker";
export declare const RulesDeleteResponseActionsItemType: any;
export type RulesDeleteResponseActionsItemValueList = Array<string>;
export declare const RulesDeleteResponseActionsItemValueList: S.Schema<RulesDeleteResponseActionsItemValueList>;
export interface RulesDeleteResponseActionsItem {
    /** Type of supported action. */
    type: RulesDeleteResponseActionsItemType;
    value?: RulesDeleteResponseActionsItemValueList | null;
}
export declare const RulesDeleteResponseActionsItem: S.Schema<RulesDeleteResponseActionsItem>;
export type RulesDeleteResponseActionsList = Array<RulesDeleteResponseActionsItem>;
export declare const RulesDeleteResponseActionsList: S.Schema<RulesDeleteResponseActionsList>;
export type RulesDeleteResponseMatchersItemType = "all" | "literal";
export declare const RulesDeleteResponseMatchersItemType: any;
export type RulesDeleteResponseMatchersItemField = "to";
export declare const RulesDeleteResponseMatchersItemField: any;
export interface RulesDeleteResponseMatchersItem {
    /** Type of matcher. */
    type: RulesDeleteResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesDeleteResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export declare const RulesDeleteResponseMatchersItem: S.Schema<RulesDeleteResponseMatchersItem>;
export type RulesDeleteResponseMatchersList = Array<RulesDeleteResponseMatchersItem>;
export declare const RulesDeleteResponseMatchersList: S.Schema<RulesDeleteResponseMatchersList>;
export type RulesDeleteResponseSource = "api" | "wrangler";
export declare const RulesDeleteResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesDeleteResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesDeleteResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesDeleteResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface DisableEmailRoutingRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const DisableEmailRoutingRequest: S.Schema<DisableEmailRoutingRequest>;
export type DisableResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
export declare const DisableResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DisableEmailRoutingResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: DisableResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export declare const DisableEmailRoutingResponse: S.Schema<DisableEmailRoutingResponse>;
export type EditAddressRequestStatus = "unverified" | "verified";
export declare const EditAddressRequestStatus: any;
export interface EditAddressRequest {
    /** Identifier. */
    accountId: string;
    /** Destination address identifier. */
    destinationAddressIdentifier: string;
    /** Destination address status. Non-admin callers may only set verified addresses back to unverified; setting to verified requires admin privileges. */
    status: EditAddressRequestStatus | (string & {});
}
export declare const EditAddressRequest: S.Schema<EditAddressRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export declare const EditAddressResponse: S.Schema<EditAddressResponse>;
export interface EnableEmailRoutingRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const EnableEmailRoutingRequest: S.Schema<EnableEmailRoutingRequest>;
export type EnableResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
export declare const EnableResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EnableEmailRoutingResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: EnableResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export declare const EnableEmailRoutingResponse: S.Schema<EnableEmailRoutingResponse>;
export interface GetAddressRequest {
    /** Identifier. */
    accountId: string;
    /** Destination address identifier. */
    destinationAddressIdentifier: string;
}
export declare const GetAddressRequest: S.Schema<GetAddressRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAddressResponse {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export declare const GetAddressResponse: S.Schema<GetAddressResponse>;
export interface GetDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Domain of your zone. */
    subdomain?: string;
}
export declare const GetDnsRequest: S.Schema<GetDnsRequest>;
export type DnsGetResponseErrorsItemMissingType = "A" | "AAAA" | "CNAME" | "HTTPS" | "TXT" | "SRV" | "LOC" | "MX" | "NS" | "CERT" | "DNSKEY" | "DS" | "NAPTR" | "SMIMEA" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export declare const DnsGetResponseErrorsItemMissingType: any;
export interface DnsGetResponseErrorsItemMissing {
    /** DNS record content. */
    content?: string | null;
    /** DNS record name (or @ for the zone apex). */
    name?: string | null;
    /** Required for MX, SRV and URI records. Unused by other record types. Records with lower priorities are preferred. */
    priority?: number | null;
    /** Time to live, in seconds, of the DNS record. Must be between 60 and 86400, or 1 for 'automatic'. */
    ttl?: number | null;
    /** DNS record type. */
    type?: DnsGetResponseErrorsItemMissingType | null;
}
export declare const DnsGetResponseErrorsItemMissing: S.Schema<DnsGetResponseErrorsItemMissing>;
export interface DnsGetResponseErrorsItem {
    code?: string | null;
    /** List of records needed to enable an Email Routing zone. */
    missing?: DnsGetResponseErrorsItemMissing | null;
}
export declare const DnsGetResponseErrorsItem: S.Schema<DnsGetResponseErrorsItem>;
export type DnsGetResponseErrorsList = Array<DnsGetResponseErrorsItem>;
export declare const DnsGetResponseErrorsList: S.Schema<DnsGetResponseErrorsList>;
export interface DnsGetResponseRecordItem {
    /** DNS record content. */
    content?: string | null;
    /** DNS record name (or @ for the zone apex). */
    name?: string | null;
    /** Required for MX, SRV and URI records. Unused by other record types. Records with lower priorities are preferred. */
    priority?: number | null;
    /** Time to live, in seconds, of the DNS record. Must be between 60 and 86400, or 1 for 'automatic'. */
    ttl?: number | null;
    /** DNS record type. */
    type?: string | null;
}
export declare const DnsGetResponseRecordItem: S.Schema<DnsGetResponseRecordItem>;
export type DnsGetResponseRecordList = Array<DnsGetResponseRecordItem>;
export declare const DnsGetResponseRecordList: S.Schema<DnsGetResponseRecordList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDnsResponse {
    errors?: DnsGetResponseErrorsList | null;
    record?: DnsGetResponseRecordList | null;
}
export declare const GetDnsResponse: S.Schema<GetDnsResponse>;
export interface GetEmailRoutingRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetEmailRoutingRequest: S.Schema<GetEmailRoutingRequest>;
export type GetResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
export declare const GetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEmailRoutingResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: GetResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export declare const GetEmailRoutingResponse: S.Schema<GetEmailRoutingResponse>;
export interface GetRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Routing rule identifier. */
    ruleIdentifier: string;
}
export declare const GetRuleRequest: S.Schema<GetRuleRequest>;
export type RulesGetResponseActionsItemType = "drop" | "forward" | "worker";
export declare const RulesGetResponseActionsItemType: any;
export type RulesGetResponseActionsItemValueList = Array<string>;
export declare const RulesGetResponseActionsItemValueList: S.Schema<RulesGetResponseActionsItemValueList>;
export interface RulesGetResponseActionsItem {
    /** Type of supported action. */
    type: RulesGetResponseActionsItemType;
    value?: RulesGetResponseActionsItemValueList | null;
}
export declare const RulesGetResponseActionsItem: S.Schema<RulesGetResponseActionsItem>;
export type RulesGetResponseActionsList = Array<RulesGetResponseActionsItem>;
export declare const RulesGetResponseActionsList: S.Schema<RulesGetResponseActionsList>;
export type RulesGetResponseMatchersItemType = "all" | "literal";
export declare const RulesGetResponseMatchersItemType: any;
export type RulesGetResponseMatchersItemField = "to";
export declare const RulesGetResponseMatchersItemField: any;
export interface RulesGetResponseMatchersItem {
    /** Type of matcher. */
    type: RulesGetResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesGetResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export declare const RulesGetResponseMatchersItem: S.Schema<RulesGetResponseMatchersItem>;
export type RulesGetResponseMatchersList = Array<RulesGetResponseMatchersItem>;
export declare const RulesGetResponseMatchersList: S.Schema<RulesGetResponseMatchersList>;
export type RulesGetResponseSource = "api" | "wrangler";
export declare const RulesGetResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesGetResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesGetResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesGetResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export declare const GetRuleResponse: S.Schema<GetRuleResponse>;
export interface GetRuleCatchAllRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetRuleCatchAllRequest: S.Schema<GetRuleCatchAllRequest>;
export type RulesCatchAllsGetResponseActionsItemType = "drop" | "forward" | "worker";
export declare const RulesCatchAllsGetResponseActionsItemType: any;
export type RulesCatchAllsGetResponseActionsItemValueList = Array<string>;
export declare const RulesCatchAllsGetResponseActionsItemValueList: S.Schema<RulesCatchAllsGetResponseActionsItemValueList>;
export interface RulesCatchAllsGetResponseActionsItem {
    /** Type of action for catch-all rule. */
    type: RulesCatchAllsGetResponseActionsItemType;
    value?: RulesCatchAllsGetResponseActionsItemValueList | null;
}
export declare const RulesCatchAllsGetResponseActionsItem: S.Schema<RulesCatchAllsGetResponseActionsItem>;
export type RulesCatchAllsGetResponseActionsList = Array<RulesCatchAllsGetResponseActionsItem>;
export declare const RulesCatchAllsGetResponseActionsList: S.Schema<RulesCatchAllsGetResponseActionsList>;
export type RulesCatchAllsGetResponseMatchersItemType = "all";
export declare const RulesCatchAllsGetResponseMatchersItemType: any;
export interface RulesCatchAllsGetResponseMatchersItem {
    /** Type of matcher. Default is 'all'. */
    type: RulesCatchAllsGetResponseMatchersItemType;
}
export declare const RulesCatchAllsGetResponseMatchersItem: S.Schema<RulesCatchAllsGetResponseMatchersItem>;
export type RulesCatchAllsGetResponseMatchersList = Array<RulesCatchAllsGetResponseMatchersItem>;
export declare const RulesCatchAllsGetResponseMatchersList: S.Schema<RulesCatchAllsGetResponseMatchersList>;
export type RulesCatchAllsGetResponseSource = "api" | "wrangler";
export declare const RulesCatchAllsGetResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleCatchAllResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions for the catch-all routing rule. */
    actions?: RulesCatchAllsGetResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** List of matchers for the catch-all routing rule. */
    matchers?: RulesCatchAllsGetResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesCatchAllsGetResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export declare const GetRuleCatchAllResponse: S.Schema<GetRuleCatchAllResponse>;
export type AddressesListRequestDirection = "asc" | "desc";
export declare const AddressesListRequestDirection: any;
export interface ListAddressesRequest {
    /** Identifier. */
    accountId: string;
    /** Sorts results in an ascending or descending order. */
    direction?: AddressesListRequestDirection | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter by verified destination addresses. */
    verified?: string;
}
export declare const ListAddressesRequest: S.Schema<ListAddressesRequest>;
export interface AddressesListResultItem {
    /** Destination address identifier. */
    id?: string | null;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Destination address tag. (Deprecated, replaced by destination address identifier) */
    tag?: string | null;
    /** The date and time the destination address has been verified. Null means not verified yet. */
    verified?: string | null;
}
export declare const AddressesListResultItem: S.Schema<AddressesListResultItem>;
export type AddressesListResultList = Array<AddressesListResultItem>;
export declare const AddressesListResultList: S.Schema<AddressesListResultList>;
export interface ListAddressesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AddressesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAddressesResponse: S.Schema<ListAddressesResponse>;
export interface ListRulesRequest {
    /** Identifier. */
    zoneId: string;
    page?: number;
    perPage?: number;
    /** Filter by enabled routing rules. */
    enabled?: boolean;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export type ListRulesResponseResultList = Array<GetRuleResponse>;
export declare const ListRulesResponseResultList: S.Schema<ListRulesResponseResultList>;
export interface ListRulesResponse {
    /** Routing rules for the zone. */
    result: ListRulesResponseResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export interface PatchDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Domain of your zone. */
    name?: string;
}
export declare const PatchDnsRequest: S.Schema<PatchDnsRequest>;
export type DnsEditResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
export declare const DnsEditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDnsResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: DnsEditResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export declare const PatchDnsResponse: S.Schema<PatchDnsResponse>;
export type RulesCatchAllsUpdateRequestActionsItemType = "drop" | "forward" | "worker";
export declare const RulesCatchAllsUpdateRequestActionsItemType: any;
export type RulesCatchAllsUpdateRequestActionsItemValueList = Array<string>;
export declare const RulesCatchAllsUpdateRequestActionsItemValueList: S.Schema<RulesCatchAllsUpdateRequestActionsItemValueList>;
export interface RulesCatchAllsUpdateRequestActionsItem {
    /** Type of action for catch-all rule. */
    type: RulesCatchAllsUpdateRequestActionsItemType | (string & {});
    value?: RulesCatchAllsUpdateRequestActionsItemValueList;
}
export declare const RulesCatchAllsUpdateRequestActionsItem: S.Schema<RulesCatchAllsUpdateRequestActionsItem>;
export type RulesCatchAllsUpdateRequestActionsList = Array<RulesCatchAllsUpdateRequestActionsItem>;
export declare const RulesCatchAllsUpdateRequestActionsList: S.Schema<RulesCatchAllsUpdateRequestActionsList>;
export type RulesCatchAllsUpdateRequestMatchersItemType = "all";
export declare const RulesCatchAllsUpdateRequestMatchersItemType: any;
export interface RulesCatchAllsUpdateRequestMatchersItem {
    /** Type of matcher. Default is 'all'. */
    type: RulesCatchAllsUpdateRequestMatchersItemType | (string & {});
}
export declare const RulesCatchAllsUpdateRequestMatchersItem: S.Schema<RulesCatchAllsUpdateRequestMatchersItem>;
export type RulesCatchAllsUpdateRequestMatchersList = Array<RulesCatchAllsUpdateRequestMatchersItem>;
export declare const RulesCatchAllsUpdateRequestMatchersList: S.Schema<RulesCatchAllsUpdateRequestMatchersList>;
export type RulesCatchAllsUpdateRequestSource = "api" | "wrangler";
export declare const RulesCatchAllsUpdateRequestSource: any;
export interface PutRuleCatchAllRequest {
    /** Identifier. */
    zoneId: string;
    /** List actions for the catch-all routing rule. */
    actions: RulesCatchAllsUpdateRequestActionsList;
    /** List of matchers for the catch-all routing rule. */
    matchers: RulesCatchAllsUpdateRequestMatchersList;
    /** Routing rule status. */
    enabled?: boolean;
    /** Routing rule name. */
    name?: string;
    /** Public tag (script_tag) of the Worker that owns this rule. Required when */
    ownerWorkerTag?: string;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesCatchAllsUpdateRequestSource | (string & {});
}
export declare const PutRuleCatchAllRequest: S.Schema<PutRuleCatchAllRequest>;
export type RulesCatchAllsUpdateResponseActionsItemType = "drop" | "forward" | "worker";
export declare const RulesCatchAllsUpdateResponseActionsItemType: any;
export type RulesCatchAllsUpdateResponseActionsItemValueList = Array<string>;
export declare const RulesCatchAllsUpdateResponseActionsItemValueList: S.Schema<RulesCatchAllsUpdateResponseActionsItemValueList>;
export interface RulesCatchAllsUpdateResponseActionsItem {
    /** Type of action for catch-all rule. */
    type: RulesCatchAllsUpdateResponseActionsItemType;
    value?: RulesCatchAllsUpdateResponseActionsItemValueList | null;
}
export declare const RulesCatchAllsUpdateResponseActionsItem: S.Schema<RulesCatchAllsUpdateResponseActionsItem>;
export type RulesCatchAllsUpdateResponseActionsList = Array<RulesCatchAllsUpdateResponseActionsItem>;
export declare const RulesCatchAllsUpdateResponseActionsList: S.Schema<RulesCatchAllsUpdateResponseActionsList>;
export type RulesCatchAllsUpdateResponseMatchersItemType = "all";
export declare const RulesCatchAllsUpdateResponseMatchersItemType: any;
export interface RulesCatchAllsUpdateResponseMatchersItem {
    /** Type of matcher. Default is 'all'. */
    type: RulesCatchAllsUpdateResponseMatchersItemType;
}
export declare const RulesCatchAllsUpdateResponseMatchersItem: S.Schema<RulesCatchAllsUpdateResponseMatchersItem>;
export type RulesCatchAllsUpdateResponseMatchersList = Array<RulesCatchAllsUpdateResponseMatchersItem>;
export declare const RulesCatchAllsUpdateResponseMatchersList: S.Schema<RulesCatchAllsUpdateResponseMatchersList>;
export type RulesCatchAllsUpdateResponseSource = "api" | "wrangler";
export declare const RulesCatchAllsUpdateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutRuleCatchAllResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions for the catch-all routing rule. */
    actions?: RulesCatchAllsUpdateResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** List of matchers for the catch-all routing rule. */
    matchers?: RulesCatchAllsUpdateResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesCatchAllsUpdateResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export declare const PutRuleCatchAllResponse: S.Schema<PutRuleCatchAllResponse>;
export interface UnlockRequest {
    /** Identifier. */
    zoneId: string;
    /** Domain of your zone. */
    name?: string;
}
export declare const UnlockRequest: S.Schema<UnlockRequest>;
export type UnlockResponseStatus = "ready" | "unconfigured" | "misconfigured" | "misconfigured/locked" | "unlocked";
export declare const UnlockResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UnlockResponse {
    /** Email Routing settings identifier. */
    id: string;
    /** State of the zone settings for Email Routing. */
    enabled: boolean;
    /** Domain of your zone. */
    name: string;
    /** The date and time the settings have been created. */
    created?: string | null;
    /** The date and time the settings have been modified. */
    modified?: string | null;
    /** Flag to check if the user skipped the configuration wizard. */
    skipWizard?: boolean | null;
    /** Show the state of your account, and the type or configuration error. */
    status?: UnlockResponseStatus | null;
    /** Whether subaddressing (plus-addressing) is honored when matching incoming mail against routing rules. */
    supportSubaddress?: boolean | null;
    /** Email Routing settings tag. (Deprecated, replaced by Email Routing settings identifier) */
    tag?: string | null;
}
export declare const UnlockResponse: S.Schema<UnlockResponse>;
export type RulesUpdateRequestActionsItemType = "drop" | "forward" | "worker";
export declare const RulesUpdateRequestActionsItemType: any;
export type RulesUpdateRequestActionsItemValueList = Array<string>;
export declare const RulesUpdateRequestActionsItemValueList: S.Schema<RulesUpdateRequestActionsItemValueList>;
export interface RulesUpdateRequestActionsItem {
    /** Type of supported action. */
    type: RulesUpdateRequestActionsItemType | (string & {});
    value?: RulesUpdateRequestActionsItemValueList;
}
export declare const RulesUpdateRequestActionsItem: S.Schema<RulesUpdateRequestActionsItem>;
export type RulesUpdateRequestActionsList = Array<RulesUpdateRequestActionsItem>;
export declare const RulesUpdateRequestActionsList: S.Schema<RulesUpdateRequestActionsList>;
export type RulesUpdateRequestMatchersItemType = "all" | "literal";
export declare const RulesUpdateRequestMatchersItemType: any;
export type RulesUpdateRequestMatchersItemField = "to";
export declare const RulesUpdateRequestMatchersItemField: any;
export interface RulesUpdateRequestMatchersItem {
    /** Type of matcher. */
    type: RulesUpdateRequestMatchersItemType | (string & {});
    /** Field for type matcher. */
    field?: RulesUpdateRequestMatchersItemField | (string & {});
    /** Value for matcher. */
    value?: string;
}
export declare const RulesUpdateRequestMatchersItem: S.Schema<RulesUpdateRequestMatchersItem>;
export type RulesUpdateRequestMatchersList = Array<RulesUpdateRequestMatchersItem>;
export declare const RulesUpdateRequestMatchersList: S.Schema<RulesUpdateRequestMatchersList>;
export type RulesUpdateRequestSource = "api" | "wrangler";
export declare const RulesUpdateRequestSource: any;
export interface UpdateRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Routing rule identifier. */
    ruleIdentifier: string;
    /** List actions patterns. */
    actions: RulesUpdateRequestActionsList;
    /** Matching patterns to forward to your actions. */
    matchers: RulesUpdateRequestMatchersList;
    /** Routing rule status. */
    enabled?: boolean;
    /** Routing rule name. */
    name?: string;
    /** Public tag (script_tag) of the Worker that owns this rule. Required when */
    ownerWorkerTag?: string;
    /** Priority of the routing rule. */
    priority?: number;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesUpdateRequestSource | (string & {});
}
export declare const UpdateRuleRequest: S.Schema<UpdateRuleRequest>;
export type RulesUpdateResponseActionsItemType = "drop" | "forward" | "worker";
export declare const RulesUpdateResponseActionsItemType: any;
export type RulesUpdateResponseActionsItemValueList = Array<string>;
export declare const RulesUpdateResponseActionsItemValueList: S.Schema<RulesUpdateResponseActionsItemValueList>;
export interface RulesUpdateResponseActionsItem {
    /** Type of supported action. */
    type: RulesUpdateResponseActionsItemType;
    value?: RulesUpdateResponseActionsItemValueList | null;
}
export declare const RulesUpdateResponseActionsItem: S.Schema<RulesUpdateResponseActionsItem>;
export type RulesUpdateResponseActionsList = Array<RulesUpdateResponseActionsItem>;
export declare const RulesUpdateResponseActionsList: S.Schema<RulesUpdateResponseActionsList>;
export type RulesUpdateResponseMatchersItemType = "all" | "literal";
export declare const RulesUpdateResponseMatchersItemType: any;
export type RulesUpdateResponseMatchersItemField = "to";
export declare const RulesUpdateResponseMatchersItemField: any;
export interface RulesUpdateResponseMatchersItem {
    /** Type of matcher. */
    type: RulesUpdateResponseMatchersItemType;
    /** Field for type matcher. */
    field?: RulesUpdateResponseMatchersItemField | null;
    /** Value for matcher. */
    value?: string | null;
}
export declare const RulesUpdateResponseMatchersItem: S.Schema<RulesUpdateResponseMatchersItem>;
export type RulesUpdateResponseMatchersList = Array<RulesUpdateResponseMatchersItem>;
export declare const RulesUpdateResponseMatchersList: S.Schema<RulesUpdateResponseMatchersList>;
export type RulesUpdateResponseSource = "api" | "wrangler";
export declare const RulesUpdateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** Routing rule identifier. */
    id?: string | null;
    /** List actions patterns. */
    actions?: RulesUpdateResponseActionsList | null;
    /** Routing rule status. */
    enabled?: boolean | null;
    /** Matching patterns to forward to your actions. */
    matchers?: RulesUpdateResponseMatchersList | null;
    /** Routing rule name. */
    name?: string | null;
    /** Priority of the routing rule. */
    priority?: number | null;
    /** Who manages the rule. `api` covers dashboard, generic API, and Terraform; */
    source?: RulesUpdateResponseSource | null;
    /** Routing rule tag. (Deprecated, replaced by routing rule identifier) */
    tag?: string | null;
}
export declare const UpdateRuleResponse: S.Schema<UpdateRuleResponse>;
export type CreateAddressError = CloudflareOpError;
/** Create a destination address to forward your emails to. Destination addresses need to be verified before they can be used. */
export declare const createAddress: API.OperationMethod<CreateAddressRequest, CreateAddressResponse, CreateAddressError, CloudflareOpContext>;
export type CreateDnsError = CloudflareOpError;
/** Enable you Email Routing zone. Add and lock the necessary MX and SPF records. */
export declare const createDns: API.OperationMethod<CreateDnsRequest, CreateDnsResponse, CreateDnsError, CloudflareOpContext>;
export type CreateRuleError = WorkerScriptNotFound | CloudflareOpError;
/** Rules consist of a set of criteria for matching emails (such as an email being sent to a specific custom email address) plus a set of actions to take on the email (like forwarding it to a specific destination address). Forward actions require all destination addresses to be verified. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type DeleteAddressError = EmailAddressNotFound | EmailAddressCreatedTooRecently | CloudflareOpError;
/** Deletes a specific destination address. */
export declare const deleteAddress: API.OperationMethod<DeleteAddressRequest, DeleteAddressResponse, DeleteAddressError, CloudflareOpContext>;
export type DeleteDnsError = CloudflareOpError;
/** Disable your Email Routing zone. Also removes additional MX records previously required for Email Routing to work. */
export declare const deleteDns: API.OperationMethod<DeleteDnsRequest, DeleteDnsResponse, DeleteDnsError, CloudflareOpContext>;
export type DeleteRuleError = EmailRoutingRuleNotFound | CloudflareOpError;
/** Delete a specific routing rule. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DisableEmailRoutingError = Forbidden | CloudflareOpError;
/** Disable your Email Routing zone. Also removes additional MX records previously required for Email Routing to work. */
export declare const disableEmailRouting: API.OperationMethod<DisableEmailRoutingRequest, DisableEmailRoutingResponse, DisableEmailRoutingError, CloudflareOpContext>;
export type EditAddressError = CloudflareOpError;
/** Updates the status of a specific destination address. */
export declare const editAddress: API.OperationMethod<EditAddressRequest, EditAddressResponse, EditAddressError, CloudflareOpContext>;
export type EnableEmailRoutingError = Forbidden | CloudflareOpError;
/** Enable you Email Routing zone. Add and lock the necessary MX and SPF records. */
export declare const enableEmailRouting: API.OperationMethod<EnableEmailRoutingRequest, EnableEmailRoutingResponse, EnableEmailRoutingError, CloudflareOpContext>;
export type GetAddressError = CloudflareOpError;
/** Gets information for a specific destination email already created. */
export declare const getAddress: API.OperationMethod<GetAddressRequest, GetAddressResponse, GetAddressError, CloudflareOpContext>;
export type GetDnsError = CloudflareOpError;
/** Show the DNS records needed to configure your Email Routing zone. */
export declare const getDns: API.OperationMethod<GetDnsRequest, GetDnsResponse, GetDnsError, CloudflareOpContext>;
export type GetEmailRoutingError = Forbidden | CloudflareOpError;
/** Get information about the settings for your Email Routing zone. */
export declare const getEmailRouting: API.OperationMethod<GetEmailRoutingRequest, GetEmailRoutingResponse, GetEmailRoutingError, CloudflareOpContext>;
export type GetRuleError = Forbidden | EmailRoutingRuleNotFound | CloudflareOpError;
/** Get information for a specific routing rule already created. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type GetRuleCatchAllError = Forbidden | CloudflareOpError;
/** Get information on the default catch-all routing rule. */
export declare const getRuleCatchAll: API.OperationMethod<GetRuleCatchAllRequest, GetRuleCatchAllResponse, GetRuleCatchAllError, CloudflareOpContext>;
export type ListAddressesError = CloudflareOpError;
/** Lists existing destination addresses. */
export declare const listAddresses: API.PaginatedOperationMethod<ListAddressesRequest, ListAddressesResponse, ListAddressesError, CloudflareOpContext, AddressesListResultItem>;
export type ListRulesError = CloudflareOpError;
/** List routing rules (docs-absent endpoint). */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, GetRuleResponse>;
export type PatchDnsError = CloudflareOpError;
/** Unlock MX Records previously locked by Email Routing. */
export declare const patchDns: API.OperationMethod<PatchDnsRequest, PatchDnsResponse, PatchDnsError, CloudflareOpContext>;
export type PutRuleCatchAllError = Forbidden | DestinationNotVerified | WorkerScriptNotFound | CloudflareOpError;
/** Enable or disable catch-all routing rule, or change action to forward to specific destination address. Forward actions require all destination addresses to be verified. */
export declare const putRuleCatchAll: API.OperationMethod<PutRuleCatchAllRequest, PutRuleCatchAllResponse, PutRuleCatchAllError, CloudflareOpContext>;
export type UnlockError = CloudflareOpError;
/** Unlock MX records previously locked by Email Routing. Deprecated - use PATCH /zones/{zone_id}/email/routing/dns instead. */
export declare const unlock: API.OperationMethod<UnlockRequest, UnlockResponse, UnlockError, CloudflareOpContext>;
export type UpdateRuleError = WorkerScriptNotFound | CloudflareOpError;
/** Update actions and matches, or enable/disable specific routing rules. Forward actions require all destination addresses to be verified. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
//# sourceMappingURL=email_routing.d.ts.map