import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ContentTypeRequired_base: S.Class<ContentTypeRequired, S.TaggedStruct<"ContentTypeRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ContentTypeRequired extends /*@__PURE__*/ ContentTypeRequired_base {
}
declare const D1DatabaseNotFound_base: S.Class<D1DatabaseNotFound, S.TaggedStruct<"D1DatabaseNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class D1DatabaseNotFound extends /*@__PURE__*/ D1DatabaseNotFound_base {
}
declare const DeploymentNotFound_base: S.Class<DeploymentNotFound, S.TaggedStruct<"DeploymentNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DeploymentNotFound extends /*@__PURE__*/ DeploymentNotFound_base {
}
declare const DispatchNamespaceNotFound_base: S.Class<DispatchNamespaceNotFound, S.TaggedStruct<"DispatchNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DispatchNamespaceNotFound extends /*@__PURE__*/ DispatchNamespaceNotFound_base {
}
declare const DomainNotFound_base: S.Class<DomainNotFound, S.TaggedStruct<"DomainNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DomainNotFound extends /*@__PURE__*/ DomainNotFound_base {
}
declare const DuplicateMigrationTarget_base: S.Class<DuplicateMigrationTarget, S.TaggedStruct<"DuplicateMigrationTarget", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicateMigrationTarget extends /*@__PURE__*/ DuplicateMigrationTarget_base {
}
declare const DurableObjectClassNotFound_base: S.Class<DurableObjectClassNotFound, S.TaggedStruct<"DurableObjectClassNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DurableObjectClassNotFound extends /*@__PURE__*/ DurableObjectClassNotFound_base {
}
declare const DurableObjectMustBeSqlite_base: S.Class<DurableObjectMustBeSqlite, S.TaggedStruct<"DurableObjectMustBeSqlite", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DurableObjectMustBeSqlite extends /*@__PURE__*/ DurableObjectMustBeSqlite_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameAlreadyInUse_base: S.Class<HostnameAlreadyInUse, S.TaggedStruct<"HostnameAlreadyInUse", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HostnameAlreadyInUse extends /*@__PURE__*/ HostnameAlreadyInUse_base {
}
declare const HyperdriveConfigNotFound_base: S.Class<HyperdriveConfigNotFound, S.TaggedStruct<"HyperdriveConfigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HyperdriveConfigNotFound extends /*@__PURE__*/ HyperdriveConfigNotFound_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidRoutePattern_base: S.Class<InvalidRoutePattern, S.TaggedStruct<"InvalidRoutePattern", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoutePattern extends /*@__PURE__*/ InvalidRoutePattern_base {
}
declare const InvalidWorkerScript_base: S.Class<InvalidWorkerScript, S.TaggedStruct<"InvalidWorkerScript", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidWorkerScript extends /*@__PURE__*/ InvalidWorkerScript_base {
}
declare const KVNamespaceNotFound_base: S.Class<KVNamespaceNotFound, S.TaggedStruct<"KVNamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KVNamespaceNotFound extends /*@__PURE__*/ KVNamespaceNotFound_base {
}
declare const MtlsCertificateNotFound_base: S.Class<MtlsCertificateNotFound, S.TaggedStruct<"MtlsCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MtlsCertificateNotFound extends /*@__PURE__*/ MtlsCertificateNotFound_base {
}
declare const ObservabilityDestinationCreateFailed_base: S.Class<ObservabilityDestinationCreateFailed, S.TaggedStruct<"ObservabilityDestinationCreateFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ObservabilityDestinationCreateFailed extends /*@__PURE__*/ ObservabilityDestinationCreateFailed_base {
}
declare const ObservabilityDestinationNotFound_base: S.Class<ObservabilityDestinationNotFound, S.TaggedStruct<"ObservabilityDestinationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ObservabilityDestinationNotFound extends /*@__PURE__*/ ObservabilityDestinationNotFound_base {
}
declare const ObservabilityDestinationPreflightFailed_base: S.Class<ObservabilityDestinationPreflightFailed, S.TaggedStruct<"ObservabilityDestinationPreflightFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ObservabilityDestinationPreflightFailed extends /*@__PURE__*/ ObservabilityDestinationPreflightFailed_base {
}
declare const PreviewDeploymentNotFound_base: S.Class<PreviewDeploymentNotFound, S.TaggedStruct<"PreviewDeploymentNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PreviewDeploymentNotFound extends /*@__PURE__*/ PreviewDeploymentNotFound_base {
}
declare const PreviewNotFound_base: S.Class<PreviewNotFound, S.TaggedStruct<"PreviewNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PreviewNotFound extends /*@__PURE__*/ PreviewNotFound_base {
}
declare const QueueConsumerConflict_base: S.Class<QueueConsumerConflict, S.TaggedStruct<"QueueConsumerConflict", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueConsumerConflict extends /*@__PURE__*/ QueueConsumerConflict_base {
}
declare const QueueNotFound_base: S.Class<QueueNotFound, S.TaggedStruct<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
declare const R2BucketNotFound_base: S.Class<R2BucketNotFound, S.TaggedStruct<"R2BucketNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class R2BucketNotFound extends /*@__PURE__*/ R2BucketNotFound_base {
}
declare const RouteNotFound_base: S.Class<RouteNotFound, S.TaggedStruct<"RouteNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RouteNotFound extends /*@__PURE__*/ RouteNotFound_base {
}
declare const RouteScriptNotFound_base: S.Class<RouteScriptNotFound, S.TaggedStruct<"RouteScriptNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RouteScriptNotFound extends /*@__PURE__*/ RouteScriptNotFound_base {
}
declare const ScriptModuleNotFound_base: S.Class<ScriptModuleNotFound, S.TaggedStruct<"ScriptModuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ScriptModuleNotFound extends /*@__PURE__*/ ScriptModuleNotFound_base {
}
declare const ScriptStartupError_base: S.Class<ScriptStartupError, S.TaggedStruct<"ScriptStartupError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ScriptStartupError extends /*@__PURE__*/ ScriptStartupError_base {
}
declare const SecretNotFound_base: S.Class<SecretNotFound, S.TaggedStruct<"SecretNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretNotFound extends /*@__PURE__*/ SecretNotFound_base {
}
declare const SecretsStoreBindingNotFound_base: S.Class<SecretsStoreBindingNotFound, S.TaggedStruct<"SecretsStoreBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretsStoreBindingNotFound extends /*@__PURE__*/ SecretsStoreBindingNotFound_base {
}
declare const ServiceBindingConflict_base: S.Class<ServiceBindingConflict, S.TaggedStruct<"ServiceBindingConflict", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ServiceBindingConflict extends /*@__PURE__*/ ServiceBindingConflict_base {
}
declare const ServiceBindingNotFound_base: S.Class<ServiceBindingNotFound, S.TaggedStruct<"ServiceBindingNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ServiceBindingNotFound extends /*@__PURE__*/ ServiceBindingNotFound_base {
}
declare const SubdomainAlreadyExists_base: S.Class<SubdomainAlreadyExists, S.TaggedStruct<"SubdomainAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SubdomainAlreadyExists extends /*@__PURE__*/ SubdomainAlreadyExists_base {
}
declare const SubdomainNotFound_base: S.Class<SubdomainNotFound, S.TaggedStruct<"SubdomainNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SubdomainNotFound extends /*@__PURE__*/ SubdomainNotFound_base {
}
declare const VectorizeIndexNotFound_base: S.Class<VectorizeIndexNotFound, S.TaggedStruct<"VectorizeIndexNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VectorizeIndexNotFound extends /*@__PURE__*/ VectorizeIndexNotFound_base {
}
declare const VersionNotFound_base: S.Class<VersionNotFound, S.TaggedStruct<"VersionNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VersionNotFound extends /*@__PURE__*/ VersionNotFound_base {
}
declare const WorkerHasNoVersions_base: S.Class<WorkerHasNoVersions, S.TaggedStruct<"WorkerHasNoVersions", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WorkerHasNoVersions extends /*@__PURE__*/ WorkerHasNoVersions_base {
}
declare const WorkerNotFound_base: S.Class<WorkerNotFound, S.TaggedStruct<"WorkerNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WorkerNotFound extends /*@__PURE__*/ WorkerNotFound_base {
}
declare const WorkerVersionNotFound_base: S.Class<WorkerVersionNotFound, S.TaggedStruct<"WorkerVersionNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WorkerVersionNotFound extends /*@__PURE__*/ WorkerVersionNotFound_base {
}
export type ScriptsSecretsBulkUpdateRequestSecretsSecretTextType = "secret_text";
export declare const ScriptsSecretsBulkUpdateRequestSecretsSecretTextType: any;
export interface ScriptsSecretsBulkUpdateRequestSecretsSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateRequestSecretsSecretTextType;
}
export declare const ScriptsSecretsBulkUpdateRequestSecretsSecretText: S.Schema<ScriptsSecretsBulkUpdateRequestSecretsSecretText>;
export type ScriptsSecretsBulkUpdateRequestSecretsSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsSecretsBulkUpdateRequestSecretsSecretKeyFormat: any;
export type ScriptsSecretsBulkUpdateRequestSecretsSecretKeyType = "secret_key";
export declare const ScriptsSecretsBulkUpdateRequestSecretsSecretKeyType: any;
export type ScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesItem: any;
export type ScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList = Array<ScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesItem | (string & {})>;
export declare const ScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList: S.Schema<ScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList>;
export interface ScriptsSecretsBulkUpdateRequestSecretsSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsBulkUpdateRequestSecretsSecretKeyFormat | (string & {});
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateRequestSecretsSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsBulkUpdateRequestSecretsSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export declare const ScriptsSecretsBulkUpdateRequestSecretsSecretKey: S.Schema<ScriptsSecretsBulkUpdateRequestSecretsSecretKey>;
export type ScriptsSecretsBulkUpdateRequestSecrets = ScriptsSecretsBulkUpdateRequestSecretsSecretText | ScriptsSecretsBulkUpdateRequestSecretsSecretKey;
export declare const ScriptsSecretsBulkUpdateRequestSecrets: any;
export type ScriptsSecretsBulkUpdateRequestVersionTagsMap = {
    [key: string]: unknown | undefined;
};
export declare const ScriptsSecretsBulkUpdateRequestVersionTagsMap: S.Schema<ScriptsSecretsBulkUpdateRequestVersionTagsMap>;
export interface BulkUpdateScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Map of secret names to secret values: */
    secrets?: ScriptsSecretsBulkUpdateRequestSecrets;
    /** Optional version tags to apply to the new script version. */
    versionTags?: ScriptsSecretsBulkUpdateRequestVersionTagsMap;
}
export declare const BulkUpdateScriptSecretsRequest: S.Schema<BulkUpdateScriptSecretsRequest>;
export type ScriptsSecretsBulkUpdateResultSecretTextType = "secret_text";
export declare const ScriptsSecretsBulkUpdateResultSecretTextType: any;
export interface ScriptsSecretsBulkUpdateResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateResultSecretTextType;
}
export declare const ScriptsSecretsBulkUpdateResultSecretText: S.Schema<ScriptsSecretsBulkUpdateResultSecretText>;
export type ScriptsSecretsBulkUpdateResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsSecretsBulkUpdateResultSecretKeyFormat: any;
export type ScriptsSecretsBulkUpdateResultSecretKeyType = "secret_key";
export declare const ScriptsSecretsBulkUpdateResultSecretKeyType: any;
export type ScriptsSecretsBulkUpdateResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsSecretsBulkUpdateResultSecretKeyUsagesItem: any;
export type ScriptsSecretsBulkUpdateResultSecretKeyUsagesList = Array<ScriptsSecretsBulkUpdateResultSecretKeyUsagesItem>;
export declare const ScriptsSecretsBulkUpdateResultSecretKeyUsagesList: S.Schema<ScriptsSecretsBulkUpdateResultSecretKeyUsagesList>;
export interface ScriptsSecretsBulkUpdateResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsBulkUpdateResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsBulkUpdateResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsBulkUpdateResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsSecretsBulkUpdateResultSecretKey: S.Schema<ScriptsSecretsBulkUpdateResultSecretKey>;
export type ScriptsSecretsBulkUpdateResult = ScriptsSecretsBulkUpdateResultSecretText | ScriptsSecretsBulkUpdateResultSecretKey;
export declare const ScriptsSecretsBulkUpdateResult: any;
export type BulkUpdateScriptSecretsResponse = ScriptsSecretsBulkUpdateResult;
export declare const BulkUpdateScriptSecretsResponse: S.Schema<BulkUpdateScriptSecretsResponse>;
export type CreateAssetUploadBodyMap = {
    [key: string]: unknown | undefined;
};
export declare const CreateAssetUploadBodyMap: S.Schema<CreateAssetUploadBodyMap>;
export interface CreateAssetUploadRequest {
    /** Identifier. */
    accountId: string;
    /** Whether the file contents are base64-encoded. Must be `true`. */
    base64: boolean;
    /** Asset-upload session JWT (sent as Bearer Authorization). */
    jwtToken?: string;
    /** Map of asset hash -> base64 file content; each entry is a multipart form part. */
    body?: CreateAssetUploadBodyMap;
}
export declare const CreateAssetUploadRequest: S.Schema<CreateAssetUploadRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAssetUploadResponse {
    /** A "completion" JWT which can be redeemed when creating a Worker version. */
    jwt?: string | null;
}
export declare const CreateAssetUploadResponse: S.Schema<CreateAssetUploadResponse>;
export type BetaWorkersCreateRequestObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersCreateRequestObservabilityLogsDestinationsList: S.Schema<BetaWorkersCreateRequestObservabilityLogsDestinationsList>;
export interface BetaWorkersCreateRequestObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersCreateRequestObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export declare const BetaWorkersCreateRequestObservabilityLogs: S.Schema<BetaWorkersCreateRequestObservabilityLogs>;
export type BetaWorkersCreateRequestObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersCreateRequestObservabilityTracesDestinationsList: S.Schema<BetaWorkersCreateRequestObservabilityTracesDestinationsList>;
export type BetaWorkersCreateRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersCreateRequestObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersCreateRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersCreateRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersCreateRequestObservabilityTracesPropagationPolicy | (string & {});
}
export declare const BetaWorkersCreateRequestObservabilityTraces: S.Schema<BetaWorkersCreateRequestObservabilityTraces>;
export interface BetaWorkersCreateRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Log settings for the Worker. */
    logs?: BetaWorkersCreateRequestObservabilityLogs;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersCreateRequestObservabilityTraces;
}
export declare const BetaWorkersCreateRequestObservability: S.Schema<BetaWorkersCreateRequestObservability>;
export interface BetaWorkersCreateRequestSubdomain {
    /** Whether the *.workers.dev subdomain is enabled for the Worker. */
    enabled?: boolean;
    /** Whether [preview URLs](https://developers.cloudflare.com/workers/configuration/previews/) are enabled for the Worker. */
    previewsEnabled?: boolean;
}
export declare const BetaWorkersCreateRequestSubdomain: S.Schema<BetaWorkersCreateRequestSubdomain>;
export type BetaWorkersCreateRequestTagsList = Array<string>;
export declare const BetaWorkersCreateRequestTagsList: S.Schema<BetaWorkersCreateRequestTagsList>;
export interface BetaWorkersCreateRequestTailConsumersItem {
    /** Name of the consumer Worker. */
    name: string;
}
export declare const BetaWorkersCreateRequestTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersCreateRequestTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersCreateRequestTailConsumersList: S.Schema<BetaWorkersCreateRequestTailConsumersList>;
export interface CreateBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Worker. */
    name: string;
    /** Whether logpush is enabled for the Worker. */
    logpush?: boolean;
    /** Observability settings for the Worker. */
    observability?: BetaWorkersCreateRequestObservability;
    /** Subdomain settings for the Worker. */
    subdomain?: BetaWorkersCreateRequestSubdomain;
    /** Tags associated with the Worker. */
    tags?: BetaWorkersCreateRequestTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers?: BetaWorkersCreateRequestTailConsumersList;
}
export declare const CreateBetaWorkerRequest: S.Schema<CreateBetaWorkerRequest>;
export type BetaWorkersCreateResponseObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersCreateResponseObservabilityLogsDestinationsList: S.Schema<BetaWorkersCreateResponseObservabilityLogsDestinationsList>;
export interface BetaWorkersCreateResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersCreateResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const BetaWorkersCreateResponseObservabilityLogs: S.Schema<BetaWorkersCreateResponseObservabilityLogs>;
export type BetaWorkersCreateResponseObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersCreateResponseObservabilityTracesDestinationsList: S.Schema<BetaWorkersCreateResponseObservabilityTracesDestinationsList>;
export type BetaWorkersCreateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersCreateResponseObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersCreateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersCreateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersCreateResponseObservabilityTracesPropagationPolicy | null;
}
export declare const BetaWorkersCreateResponseObservabilityTraces: S.Schema<BetaWorkersCreateResponseObservabilityTraces>;
export interface BetaWorkersCreateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersCreateResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersCreateResponseObservabilityTraces | null;
}
export declare const BetaWorkersCreateResponseObservability: S.Schema<BetaWorkersCreateResponseObservability>;
export interface BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem {
    /** ID of the dispatch namespace. */
    namespaceId: string;
    /** Name of the dispatch namespace. */
    namespaceName: string;
    /** ID of the Worker using the dispatch namespace. */
    workerId: string;
    /** Name of the Worker using the dispatch namespace. */
    workerName: string;
}
export declare const BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem: S.Schema<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export declare const BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsList: S.Schema<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsList>;
export interface BetaWorkersCreateResponseReferencesDomainsItem {
    /** ID of the custom domain. */
    id: string;
    /** ID of the TLS certificate issued for the custom domain. */
    certificateId: string;
    /** Full hostname of the custom domain, including the zone name. */
    hostname: string;
    /** ID of the zone. */
    zoneId: string;
    /** Name of the zone. */
    zoneName: string;
}
export declare const BetaWorkersCreateResponseReferencesDomainsItem: S.Schema<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersCreateResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export declare const BetaWorkersCreateResponseReferencesDomainsList: S.Schema<BetaWorkersCreateResponseReferencesDomainsList>;
export interface BetaWorkersCreateResponseReferencesDurableObjectsItem {
    /** ID of the Durable Object namespace being used. */
    namespaceId: string;
    /** Name of the Durable Object namespace being used. */
    namespaceName: string;
    /** ID of the Worker using the Durable Object implementation. */
    workerId: string;
    /** Name of the Worker using the Durable Object implementation. */
    workerName: string;
}
export declare const BetaWorkersCreateResponseReferencesDurableObjectsItem: S.Schema<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersCreateResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export declare const BetaWorkersCreateResponseReferencesDurableObjectsList: S.Schema<BetaWorkersCreateResponseReferencesDurableObjectsList>;
export interface BetaWorkersCreateResponseReferencesQueuesItem {
    /** ID of the queue consumer configuration. */
    queueConsumerId: string;
    /** ID of the queue. */
    queueId: string;
    /** Name of the queue. */
    queueName: string;
}
export declare const BetaWorkersCreateResponseReferencesQueuesItem: S.Schema<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersCreateResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export declare const BetaWorkersCreateResponseReferencesQueuesList: S.Schema<BetaWorkersCreateResponseReferencesQueuesList>;
export interface BetaWorkersCreateResponseReferencesWorkersItem {
    /** ID of the referencing Worker. */
    id: string;
    /** Name of the referencing Worker. */
    name: string;
}
export declare const BetaWorkersCreateResponseReferencesWorkersItem: S.Schema<BetaWorkersCreateResponseReferencesWorkersItem>;
export type BetaWorkersCreateResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export declare const BetaWorkersCreateResponseReferencesWorkersList: S.Schema<BetaWorkersCreateResponseReferencesWorkersList>;
export interface BetaWorkersCreateResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersCreateResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersCreateResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersCreateResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersCreateResponseReferencesWorkersList;
}
export declare const BetaWorkersCreateResponseReferences: S.Schema<BetaWorkersCreateResponseReferences>;
export interface BetaWorkersCreateResponseSubdomain {
    /** Whether the *.workers.dev subdomain is enabled for the Worker. */
    enabled?: boolean | null;
    /** Whether [preview URLs](https://developers.cloudflare.com/workers/configuration/previews/) are enabled for the Worker. */
    previewsEnabled?: boolean | null;
}
export declare const BetaWorkersCreateResponseSubdomain: S.Schema<BetaWorkersCreateResponseSubdomain>;
export type BetaWorkersCreateResponseTagsList = Array<string>;
export declare const BetaWorkersCreateResponseTagsList: S.Schema<BetaWorkersCreateResponseTagsList>;
export type BetaWorkersCreateResponseTailConsumersItem = BetaWorkersCreateRequestTailConsumersItem;
export declare const BetaWorkersCreateResponseTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersCreateResponseTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersCreateResponseTailConsumersList: S.Schema<BetaWorkersCreateResponseTailConsumersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersCreateResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersCreateResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersCreateResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersCreateResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
}
export declare const CreateBetaWorkerResponse: S.Schema<CreateBetaWorkerResponse>;
export interface BetaWorkersVersionsCreateRequestAnnotations {
    /** Human-readable message about the version. Truncated to 1000 bytes if longer. */
    workersMessage?: string;
    /** User-provided identifier for the version. Maximum 100 bytes. */
    workersTag?: string;
    /** Operation that triggered the creation of the version. */
    workersTriggeredBy?: string;
}
export declare const BetaWorkersVersionsCreateRequestAnnotations: S.Schema<BetaWorkersVersionsCreateRequestAnnotations>;
export type BetaWorkersVersionsCreateRequestAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export declare const BetaWorkersVersionsCreateRequestAssetsConfigHtmlHandling: any;
export type BetaWorkersVersionsCreateRequestAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export declare const BetaWorkersVersionsCreateRequestAssetsConfigNotFoundHandling: any;
export type BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirstCase0List = Array<string>;
export declare const BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirstCase0List: S.Schema<BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirstCase0List>;
export type BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirstCase0List;
export declare const BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirst: any;
export interface BetaWorkersVersionsCreateRequestAssetsConfig {
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsCreateRequestAssetsConfigHtmlHandling | (string & {});
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsCreateRequestAssetsConfigNotFoundHandling | (string & {});
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsCreateRequestAssetsConfigRunWorkerFirst;
}
export declare const BetaWorkersVersionsCreateRequestAssetsConfig: S.Schema<BetaWorkersVersionsCreateRequestAssetsConfig>;
export interface BetaWorkersVersionsCreateRequestAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsCreateRequestAssetsConfig;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string;
}
export declare const BetaWorkersVersionsCreateRequestAssets: S.Schema<BetaWorkersVersionsCreateRequestAssets>;
export type BetaWorkersVersionsCreateRequestBindingsItemAIType = "ai";
export declare const BetaWorkersVersionsCreateRequestBindingsItemAIType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAIType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemAI: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemAI>;
export type BetaWorkersVersionsCreateRequestBindingsItemAISearchType = "ai_search";
export declare const BetaWorkersVersionsCreateRequestBindingsItemAISearchType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemAISearch: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemAISearch>;
export type BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespaceType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespaceType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespace: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespace>;
export type BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngineType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngineType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngine: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngine>;
export type BetaWorkersVersionsCreateRequestBindingsItemAssetsType = "assets";
export declare const BetaWorkersVersionsCreateRequestBindingsItemAssetsType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemAssetsType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemAssets: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemAssets>;
export type BetaWorkersVersionsCreateRequestBindingsItemBrowserType = "browser";
export declare const BetaWorkersVersionsCreateRequestBindingsItemBrowserType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemBrowserType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemBrowser: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemBrowser>;
export type BetaWorkersVersionsCreateRequestBindingsItemD1Type = "d1";
export declare const BetaWorkersVersionsCreateRequestBindingsItemD1Type: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemD1: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemD1>;
export type BetaWorkersVersionsCreateRequestBindingsItemDataBlobType = "data_blob";
export declare const BetaWorkersVersionsCreateRequestBindingsItemDataBlobType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemDataBlobType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemDataBlob: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDataBlob>;
export type BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem {
    /** Name of the parameter. */
    name: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsList>;
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundWorker {
    /** Entrypoint to invoke on the outbound worker. */
    entrypoint?: string;
    /** Environment of the outbound worker. */
    environment?: string;
    /** Name of the outbound worker. */
    service?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundWorker>;
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsList;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundWorker;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutbound: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutbound>;
export interface BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutbound;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespace: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespace>;
export type BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespaceType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string;
    /** The environment of the script_name to bind to. */
    environment?: string;
    /** Namespace identifier tag. */
    namespaceId?: string;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespace: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespace>;
export type BetaWorkersVersionsCreateRequestBindingsItemHyperdriveType = "hyperdrive";
export declare const BetaWorkersVersionsCreateRequestBindingsItemHyperdriveType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemHyperdriveType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemHyperdrive: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemHyperdrive>;
export type BetaWorkersVersionsCreateRequestBindingsItemInheritType = "inherit";
export declare const BetaWorkersVersionsCreateRequestBindingsItemInheritType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemInherit: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemInherit>;
export type BetaWorkersVersionsCreateRequestBindingsItemImagesType = "images";
export declare const BetaWorkersVersionsCreateRequestBindingsItemImagesType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemImagesType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemImages: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemImages>;
export type BetaWorkersVersionsCreateRequestBindingsItemJsonType = "json";
export declare const BetaWorkersVersionsCreateRequestBindingsItemJsonType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemJsonType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemJson: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemJson>;
export type BetaWorkersVersionsCreateRequestBindingsItemKVNamespaceType = "kv_namespace";
export declare const BetaWorkersVersionsCreateRequestBindingsItemKVNamespaceType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemKVNamespaceType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemKVNamespace: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemKVNamespace>;
export type BetaWorkersVersionsCreateRequestBindingsItemMediaType = "media";
export declare const BetaWorkersVersionsCreateRequestBindingsItemMediaType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemMediaType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemMedia: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemMedia>;
export type BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificateType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificateType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificate: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificate>;
export type BetaWorkersVersionsCreateRequestBindingsItemPlainTextType = "plain_text";
export declare const BetaWorkersVersionsCreateRequestBindingsItemPlainTextType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemPlainTextType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemPlainText: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemPlainText>;
export type BetaWorkersVersionsCreateRequestBindingsItemPipelinesType = "pipelines";
export declare const BetaWorkersVersionsCreateRequestBindingsItemPipelinesType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemPipelinesType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemPipelines: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemPipelines>;
export type BetaWorkersVersionsCreateRequestBindingsItemQueueType = "queue";
export declare const BetaWorkersVersionsCreateRequestBindingsItemQueueType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemQueueType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemQueue: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemQueue>;
export interface BetaWorkersVersionsCreateRequestBindingsItemRatelimitSimple {
    /** The limit (requests per period). */
    limit: number;
    /** The period in seconds. */
    period: number;
    /** Duration in seconds to apply the mitigation action after the rate limit is exceeded. Valid values are 0 (disabled), 10, or multiples of 60 up to 86400. Must be greater than or equal to the period when non-zero. */
    mitigationTimeout?: number;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemRatelimitSimple>;
export type BetaWorkersVersionsCreateRequestBindingsItemRatelimitType = "ratelimit";
export declare const BetaWorkersVersionsCreateRequestBindingsItemRatelimitType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateRequestBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemRatelimitType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemRatelimit: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemRatelimit>;
export type BetaWorkersVersionsCreateRequestBindingsItemR2BucketType = "r2_bucket";
export declare const BetaWorkersVersionsCreateRequestBindingsItemR2BucketType: any;
export type BetaWorkersVersionsCreateRequestBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const BetaWorkersVersionsCreateRequestBindingsItemR2BucketJurisdiction: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsCreateRequestBindingsItemR2BucketJurisdiction | (string & {});
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemR2Bucket: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemR2Bucket>;
export type BetaWorkersVersionsCreateRequestBindingsItemSecretTextType = "secret_text";
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretTextType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSecretTextType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretText: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemSecretText>;
export type BetaWorkersVersionsCreateRequestBindingsItemSendEmailType = "send_email";
export declare const BetaWorkersVersionsCreateRequestBindingsItemSendEmailType: any;
export type BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedDestinationAddressesList>;
export type BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedSenderAddressesList>;
export interface BetaWorkersVersionsCreateRequestBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedDestinationAddressesList;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsCreateRequestBindingsItemSendEmailAllowedSenderAddressesList;
    /** Destination address for the email. */
    destinationAddress?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemSendEmail: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemSendEmail>;
export type BetaWorkersVersionsCreateRequestBindingsItemServiceType = "service";
export declare const BetaWorkersVersionsCreateRequestBindingsItemServiceType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemService: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemService>;
export type BetaWorkersVersionsCreateRequestBindingsItemTextBlobType = "text_blob";
export declare const BetaWorkersVersionsCreateRequestBindingsItemTextBlobType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemTextBlobType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemTextBlob: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemTextBlob>;
export type BetaWorkersVersionsCreateRequestBindingsItemVectorizeType = "vectorize";
export declare const BetaWorkersVersionsCreateRequestBindingsItemVectorizeType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVectorizeType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemVectorize: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemVectorize>;
export type BetaWorkersVersionsCreateRequestBindingsItemVersionMetadataType = "version_metadata";
export declare const BetaWorkersVersionsCreateRequestBindingsItemVersionMetadataType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVersionMetadataType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemVersionMetadata: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemVersionMetadata>;
export type BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecretType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecretType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecret: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecret>;
export type BetaWorkersVersionsCreateRequestBindingsItemFlagshipType = "flagship";
export declare const BetaWorkersVersionsCreateRequestBindingsItemFlagshipType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemFlagshipType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemFlagship: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemFlagship>;
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretKeyFormat: any;
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyType = "secret_key";
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretKeyType: any;
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesItem: any;
export type BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesItem | (string & {})>;
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesList: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesList>;
export interface BetaWorkersVersionsCreateRequestBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsCreateRequestBindingsItemSecretKeyFormat | (string & {});
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsCreateRequestBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemSecretKey: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemSecretKey>;
export type BetaWorkersVersionsCreateRequestBindingsItemWorkflowType = "workflow";
export declare const BetaWorkersVersionsCreateRequestBindingsItemWorkflowType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemWorkflow: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemWorkflow>;
export type BetaWorkersVersionsCreateRequestBindingsItemWasmModuleType = "wasm_module";
export declare const BetaWorkersVersionsCreateRequestBindingsItemWasmModuleType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemWasmModuleType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemWasmModule: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemWasmModule>;
export type BetaWorkersVersionsCreateRequestBindingsItemVPCServiceType = "vpc_service";
export declare const BetaWorkersVersionsCreateRequestBindingsItemVPCServiceType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVPCServiceType;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemVPCService: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemVPCService>;
export type BetaWorkersVersionsCreateRequestBindingsItemVPCNetworkType = "vpc_network";
export declare const BetaWorkersVersionsCreateRequestBindingsItemVPCNetworkType: any;
export interface BetaWorkersVersionsCreateRequestBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateRequestBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string;
}
export declare const BetaWorkersVersionsCreateRequestBindingsItemVPCNetwork: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemVPCNetwork>;
export type BetaWorkersVersionsCreateRequestBindingsItem = BetaWorkersVersionsCreateRequestBindingsItemAI | BetaWorkersVersionsCreateRequestBindingsItemAISearch | BetaWorkersVersionsCreateRequestBindingsItemAISearchNamespace | BetaWorkersVersionsCreateRequestBindingsItemAnalyticsEngine | BetaWorkersVersionsCreateRequestBindingsItemAssets | BetaWorkersVersionsCreateRequestBindingsItemBrowser | BetaWorkersVersionsCreateRequestBindingsItemD1 | BetaWorkersVersionsCreateRequestBindingsItemDataBlob | BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespace | BetaWorkersVersionsCreateRequestBindingsItemDurableObjectNamespace | BetaWorkersVersionsCreateRequestBindingsItemHyperdrive | BetaWorkersVersionsCreateRequestBindingsItemInherit | BetaWorkersVersionsCreateRequestBindingsItemImages | BetaWorkersVersionsCreateRequestBindingsItemJson | BetaWorkersVersionsCreateRequestBindingsItemKVNamespace | BetaWorkersVersionsCreateRequestBindingsItemMedia | BetaWorkersVersionsCreateRequestBindingsItemMTLSCertificate | BetaWorkersVersionsCreateRequestBindingsItemPlainText | BetaWorkersVersionsCreateRequestBindingsItemPipelines | BetaWorkersVersionsCreateRequestBindingsItemQueue | BetaWorkersVersionsCreateRequestBindingsItemRatelimit | BetaWorkersVersionsCreateRequestBindingsItemR2Bucket | BetaWorkersVersionsCreateRequestBindingsItemSecretText | BetaWorkersVersionsCreateRequestBindingsItemSendEmail | BetaWorkersVersionsCreateRequestBindingsItemService | BetaWorkersVersionsCreateRequestBindingsItemTextBlob | BetaWorkersVersionsCreateRequestBindingsItemVectorize | BetaWorkersVersionsCreateRequestBindingsItemVersionMetadata | BetaWorkersVersionsCreateRequestBindingsItemSecretsStoreSecret | BetaWorkersVersionsCreateRequestBindingsItemFlagship | BetaWorkersVersionsCreateRequestBindingsItemSecretKey | BetaWorkersVersionsCreateRequestBindingsItemWorkflow | BetaWorkersVersionsCreateRequestBindingsItemWasmModule | BetaWorkersVersionsCreateRequestBindingsItemVPCService | BetaWorkersVersionsCreateRequestBindingsItemVPCNetwork;
export declare const BetaWorkersVersionsCreateRequestBindingsItem: any;
export type BetaWorkersVersionsCreateRequestBindingsList = Array<BetaWorkersVersionsCreateRequestBindingsItem>;
export declare const BetaWorkersVersionsCreateRequestBindingsList: S.Schema<BetaWorkersVersionsCreateRequestBindingsList>;
export interface BetaWorkersVersionsCreateRequestCacheOptions {
    /** Whether caching is enabled for this Worker. */
    enabled: boolean;
    /** Whether cached responses are shared across Worker version */
    crossVersionCache?: boolean;
}
export declare const BetaWorkersVersionsCreateRequestCacheOptions: S.Schema<BetaWorkersVersionsCreateRequestCacheOptions>;
export type BetaWorkersVersionsCreateRequestCompatibilityFlagsList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestCompatibilityFlagsList: S.Schema<BetaWorkersVersionsCreateRequestCompatibilityFlagsList>;
export interface BetaWorkersVersionsCreateRequestContainersItem {
    /** Select which Durable Object class should get this container attached. */
    className: string;
}
export declare const BetaWorkersVersionsCreateRequestContainersItem: S.Schema<BetaWorkersVersionsCreateRequestContainersItem>;
export type BetaWorkersVersionsCreateRequestContainersList = Array<BetaWorkersVersionsCreateRequestContainersItem>;
export declare const BetaWorkersVersionsCreateRequestContainersList: S.Schema<BetaWorkersVersionsCreateRequestContainersList>;
export interface BetaWorkersVersionsCreateRequestLimits {
    /** CPU time limit in milliseconds. */
    cpuMs?: number;
    /** Subrequest limit per request. */
    subrequests?: number;
}
export declare const BetaWorkersVersionsCreateRequestLimits: S.Schema<BetaWorkersVersionsCreateRequestLimits>;
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationDeletedClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationDeletedClassesList>;
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewClassesList>;
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewSqliteClassesList>;
export interface BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem {
    from?: string;
    to?: string;
}
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesList>;
export interface BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem {
    from?: string;
    fromScript?: string;
    to?: string;
}
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesList>;
export interface BetaWorkersVersionsCreateRequestMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationDeletedClassesList;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewClassesList;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationNewSqliteClassesList;
    /** Tag to set as the latest migration tag. */
    newTag?: string;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesList;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesList;
}
export declare const BetaWorkersVersionsCreateRequestMigrationsSingleStepMigration: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigration>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList;
}
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrationsStepsList;
}
export declare const BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrations: S.Schema<BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrations>;
export type BetaWorkersVersionsCreateRequestMigrations = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigration | BetaWorkersVersionsCreateRequestMigrationsWorkersMultipleStepMigrations;
export declare const BetaWorkersVersionsCreateRequestMigrations: any;
export interface BetaWorkersVersionsCreateRequestModulesItem {
    /** The base64-encoded module content. */
    contentBase64: string;
    /** The content type of the module. */
    contentType: string;
    /** The name of the module. */
    name: string;
}
export declare const BetaWorkersVersionsCreateRequestModulesItem: S.Schema<BetaWorkersVersionsCreateRequestModulesItem>;
export type BetaWorkersVersionsCreateRequestModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export declare const BetaWorkersVersionsCreateRequestModulesList: S.Schema<BetaWorkersVersionsCreateRequestModulesList>;
export interface BetaWorkersVersionsCreateRequestPackageDependenciesItem {
    /** The exact version that was resolved and installed by the package manager. */
    installedVersion: string;
    /** The npm package name. */
    name: string;
    /** The version constraint as written in package.json. */
    packageJsonVersion: string;
}
export declare const BetaWorkersVersionsCreateRequestPackageDependenciesItem: S.Schema<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsCreateRequestPackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export declare const BetaWorkersVersionsCreateRequestPackageDependenciesList: S.Schema<BetaWorkersVersionsCreateRequestPackageDependenciesList>;
export type BetaWorkersVersionsCreateRequestPlacementModeMode = "smart";
export declare const BetaWorkersVersionsCreateRequestPlacementModeMode: any;
export interface BetaWorkersVersionsCreateRequestPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsCreateRequestPlacementModeMode;
}
export declare const BetaWorkersVersionsCreateRequestPlacementMode: S.Schema<BetaWorkersVersionsCreateRequestPlacementMode>;
export interface BetaWorkersVersionsCreateRequestPlacementRegion {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const BetaWorkersVersionsCreateRequestPlacementRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementRegion>;
export interface BetaWorkersVersionsCreateRequestPlacementHostname {
    /** HTTP hostname for targeted placement. */
    hostname: string;
}
export declare const BetaWorkersVersionsCreateRequestPlacementHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export interface BetaWorkersVersionsCreateRequestPlacementHost {
    /** TCP host and port for targeted placement. */
    host: string;
}
export declare const BetaWorkersVersionsCreateRequestPlacementHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementHost>;
export type BetaWorkersVersionsCreateRequestPlacementCase4Mode = "targeted";
export declare const BetaWorkersVersionsCreateRequestPlacementCase4Mode: any;
export interface BetaWorkersVersionsCreateRequestPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const BetaWorkersVersionsCreateRequestPlacementCase4: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase4>;
export type BetaWorkersVersionsCreateRequestPlacementCase5Mode = "targeted";
export declare const BetaWorkersVersionsCreateRequestPlacementCase5Mode: any;
export interface BetaWorkersVersionsCreateRequestPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase5Mode;
}
export declare const BetaWorkersVersionsCreateRequestPlacementCase5: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase5>;
export type BetaWorkersVersionsCreateRequestPlacementCase6Mode = "targeted";
export declare const BetaWorkersVersionsCreateRequestPlacementCase6Mode: any;
export interface BetaWorkersVersionsCreateRequestPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase6Mode;
}
export declare const BetaWorkersVersionsCreateRequestPlacementCase6: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase6>;
export type BetaWorkersVersionsCreateRequestPlacementCase7Mode = "targeted";
export declare const BetaWorkersVersionsCreateRequestPlacementCase7Mode: any;
export interface BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion {
    /** Cloud region in format 'provider:region'. */
    region: string;
}
export declare const BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export interface BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost {
    /** TCP host:port for targeted placement. */
    host: string;
}
export declare const BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const BetaWorkersVersionsCreateRequestPlacementCase7TargetItem: any;
export type BetaWorkersVersionsCreateRequestPlacementCase7TargetList = Array<BetaWorkersVersionsCreateRequestPlacementCase7TargetItem>;
export declare const BetaWorkersVersionsCreateRequestPlacementCase7TargetList: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetList>;
export interface BetaWorkersVersionsCreateRequestPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateRequestPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsCreateRequestPlacementCase7TargetList;
}
export declare const BetaWorkersVersionsCreateRequestPlacementCase7: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7>;
export type BetaWorkersVersionsCreateRequestPlacement = BetaWorkersVersionsCreateRequestPlacementMode | BetaWorkersVersionsCreateRequestPlacementRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementHost | BetaWorkersVersionsCreateRequestPlacementCase4 | BetaWorkersVersionsCreateRequestPlacementCase5 | BetaWorkersVersionsCreateRequestPlacementCase6 | BetaWorkersVersionsCreateRequestPlacementCase7;
export declare const BetaWorkersVersionsCreateRequestPlacement: any;
export type BetaWorkersVersionsCreateRequestUsageModel = "standard" | "bundled" | "unbound";
export declare const BetaWorkersVersionsCreateRequestUsageModel: any;
export interface CreateBetaWorkerVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** If true, a deployment will be created that sends 100% of traffic to the new version. */
    deploy?: boolean;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateRequestAnnotations;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsCreateRequestAssets;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsCreateRequestBindingsList;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateRequestCacheOptions;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsCreateRequestCompatibilityFlagsList;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsCreateRequestContainersList;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateRequestLimits;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsCreateRequestMigrations;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsCreateRequestModulesList;
    /** The list of npm packages that were installed and used when this Worker */
    packageDependencies?: BetaWorkersVersionsCreateRequestPackageDependenciesList;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsCreateRequestPlacement;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsCreateRequestUsageModel | (string & {});
}
export declare const CreateBetaWorkerVersionRequest: S.Schema<CreateBetaWorkerVersionRequest>;
export type BetaWorkersVersionsCreateResponseUrlsList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseUrlsList: S.Schema<BetaWorkersVersionsCreateResponseUrlsList>;
export interface BetaWorkersVersionsCreateResponseAnnotations {
    /** Human-readable message about the version. Truncated to 1000 bytes if longer. */
    workersMessage?: string | null;
    /** User-provided identifier for the version. Maximum 100 bytes. */
    workersTag?: string | null;
    /** Operation that triggered the creation of the version. */
    workersTriggeredBy?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseAnnotations: S.Schema<BetaWorkersVersionsCreateResponseAnnotations>;
export type BetaWorkersVersionsCreateResponseAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export declare const BetaWorkersVersionsCreateResponseAssetsConfigHtmlHandling: any;
export type BetaWorkersVersionsCreateResponseAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export declare const BetaWorkersVersionsCreateResponseAssetsConfigNotFoundHandling: any;
export type BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirstCase0List = Array<string>;
export declare const BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirstCase0List: S.Schema<BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirstCase0List>;
export type BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirstCase0List;
export declare const BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirst: any;
export interface BetaWorkersVersionsCreateResponseAssetsConfig {
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsCreateResponseAssetsConfigHtmlHandling | null;
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsCreateResponseAssetsConfigNotFoundHandling | null;
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsCreateResponseAssetsConfigRunWorkerFirst | null;
}
export declare const BetaWorkersVersionsCreateResponseAssetsConfig: S.Schema<BetaWorkersVersionsCreateResponseAssetsConfig>;
export interface BetaWorkersVersionsCreateResponseAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsCreateResponseAssetsConfig | null;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseAssets: S.Schema<BetaWorkersVersionsCreateResponseAssets>;
export type BetaWorkersVersionsCreateResponseBindingsItemAIType = "ai";
export declare const BetaWorkersVersionsCreateResponseBindingsItemAIType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAIType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemAI: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemAI>;
export type BetaWorkersVersionsCreateResponseBindingsItemAISearchType = "ai_search";
export declare const BetaWorkersVersionsCreateResponseBindingsItemAISearchType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemAISearch: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemAISearch>;
export type BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespaceType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespaceType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespace: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespace>;
export type BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngineType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngineType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngine: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngine>;
export type BetaWorkersVersionsCreateResponseBindingsItemAssetsType = "assets";
export declare const BetaWorkersVersionsCreateResponseBindingsItemAssetsType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemAssetsType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemAssets: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemAssets>;
export type BetaWorkersVersionsCreateResponseBindingsItemBrowserType = "browser";
export declare const BetaWorkersVersionsCreateResponseBindingsItemBrowserType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemBrowserType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemBrowser: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemBrowser>;
export type BetaWorkersVersionsCreateResponseBindingsItemD1Type = "d1";
export declare const BetaWorkersVersionsCreateResponseBindingsItemD1Type: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemD1: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemD1>;
export type BetaWorkersVersionsCreateResponseBindingsItemDataBlobType = "data_blob";
export declare const BetaWorkersVersionsCreateResponseBindingsItemDataBlobType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemDataBlobType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemDataBlob: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDataBlob>;
export type BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceType: any;
export type BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export declare const BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsList>;
export interface BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker {
    /** Entrypoint to invoke on the outbound worker. */
    entrypoint?: string | null;
    /** Environment of the outbound worker. */
    environment?: string | null;
    /** Name of the outbound worker. */
    service?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker>;
export interface BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutbound: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutbound>;
export interface BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutbound | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespace: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespace>;
export type BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespaceType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespace: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespace>;
export type BetaWorkersVersionsCreateResponseBindingsItemHyperdriveType = "hyperdrive";
export declare const BetaWorkersVersionsCreateResponseBindingsItemHyperdriveType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemHyperdriveType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemHyperdrive: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemHyperdrive>;
export type BetaWorkersVersionsCreateResponseBindingsItemInheritType = "inherit";
export declare const BetaWorkersVersionsCreateResponseBindingsItemInheritType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemInherit: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemInherit>;
export type BetaWorkersVersionsCreateResponseBindingsItemImagesType = "images";
export declare const BetaWorkersVersionsCreateResponseBindingsItemImagesType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemImagesType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemImages: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemImages>;
export type BetaWorkersVersionsCreateResponseBindingsItemJsonType = "json";
export declare const BetaWorkersVersionsCreateResponseBindingsItemJsonType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemJsonType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemJson: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemJson>;
export type BetaWorkersVersionsCreateResponseBindingsItemKVNamespaceType = "kv_namespace";
export declare const BetaWorkersVersionsCreateResponseBindingsItemKVNamespaceType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemKVNamespaceType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemKVNamespace: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemKVNamespace>;
export type BetaWorkersVersionsCreateResponseBindingsItemMediaType = "media";
export declare const BetaWorkersVersionsCreateResponseBindingsItemMediaType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemMediaType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemMedia: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemMedia>;
export type BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificateType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificateType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificate: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificate>;
export type BetaWorkersVersionsCreateResponseBindingsItemPlainTextType = "plain_text";
export declare const BetaWorkersVersionsCreateResponseBindingsItemPlainTextType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemPlainTextType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemPlainText: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemPlainText>;
export type BetaWorkersVersionsCreateResponseBindingsItemPipelinesType = "pipelines";
export declare const BetaWorkersVersionsCreateResponseBindingsItemPipelinesType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemPipelinesType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemPipelines: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemPipelines>;
export type BetaWorkersVersionsCreateResponseBindingsItemQueueType = "queue";
export declare const BetaWorkersVersionsCreateResponseBindingsItemQueueType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemQueueType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemQueue: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemQueue>;
export interface BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple {
    /** The limit (requests per period). */
    limit: number;
    /** The period in seconds. */
    period: number;
    /** Duration in seconds to apply the mitigation action after the rate limit is exceeded. Valid values are 0 (disabled), 10, or multiples of 60 up to 86400. Must be greater than or equal to the period when non-zero. */
    mitigationTimeout?: number | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple>;
export type BetaWorkersVersionsCreateResponseBindingsItemRatelimitType = "ratelimit";
export declare const BetaWorkersVersionsCreateResponseBindingsItemRatelimitType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemRatelimitType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemRatelimit: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimit>;
export type BetaWorkersVersionsCreateResponseBindingsItemR2BucketType = "r2_bucket";
export declare const BetaWorkersVersionsCreateResponseBindingsItemR2BucketType: any;
export type BetaWorkersVersionsCreateResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const BetaWorkersVersionsCreateResponseBindingsItemR2BucketJurisdiction: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsCreateResponseBindingsItemR2BucketJurisdiction | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemR2Bucket: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemR2Bucket>;
export type BetaWorkersVersionsCreateResponseBindingsItemSecretTextType = "secret_text";
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretTextType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSecretTextType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretText: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemSecretText>;
export type BetaWorkersVersionsCreateResponseBindingsItemSendEmailType = "send_email";
export declare const BetaWorkersVersionsCreateResponseBindingsItemSendEmailType: any;
export type BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedDestinationAddressesList>;
export type BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedSenderAddressesList>;
export interface BetaWorkersVersionsCreateResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsCreateResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemSendEmail: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemSendEmail>;
export type BetaWorkersVersionsCreateResponseBindingsItemServiceType = "service";
export declare const BetaWorkersVersionsCreateResponseBindingsItemServiceType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemService: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemService>;
export type BetaWorkersVersionsCreateResponseBindingsItemTextBlobType = "text_blob";
export declare const BetaWorkersVersionsCreateResponseBindingsItemTextBlobType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemTextBlobType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemTextBlob: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemTextBlob>;
export type BetaWorkersVersionsCreateResponseBindingsItemVectorizeType = "vectorize";
export declare const BetaWorkersVersionsCreateResponseBindingsItemVectorizeType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVectorizeType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemVectorize: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemVectorize>;
export type BetaWorkersVersionsCreateResponseBindingsItemVersionMetadataType = "version_metadata";
export declare const BetaWorkersVersionsCreateResponseBindingsItemVersionMetadataType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVersionMetadataType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemVersionMetadata: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemVersionMetadata>;
export type BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecretType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecretType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecret: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecret>;
export type BetaWorkersVersionsCreateResponseBindingsItemFlagshipType = "flagship";
export declare const BetaWorkersVersionsCreateResponseBindingsItemFlagshipType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemFlagshipType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemFlagship: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemFlagship>;
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretKeyFormat: any;
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyType = "secret_key";
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretKeyType: any;
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesItem: any;
export type BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesItem>;
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesList: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesList>;
export interface BetaWorkersVersionsCreateResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsCreateResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsCreateResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemSecretKey: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemSecretKey>;
export type BetaWorkersVersionsCreateResponseBindingsItemWorkflowType = "workflow";
export declare const BetaWorkersVersionsCreateResponseBindingsItemWorkflowType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemWorkflow: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemWorkflow>;
export type BetaWorkersVersionsCreateResponseBindingsItemWasmModuleType = "wasm_module";
export declare const BetaWorkersVersionsCreateResponseBindingsItemWasmModuleType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemWasmModuleType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemWasmModule: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemWasmModule>;
export type BetaWorkersVersionsCreateResponseBindingsItemVPCServiceType = "vpc_service";
export declare const BetaWorkersVersionsCreateResponseBindingsItemVPCServiceType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVPCServiceType;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemVPCService: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemVPCService>;
export type BetaWorkersVersionsCreateResponseBindingsItemVPCNetworkType = "vpc_network";
export declare const BetaWorkersVersionsCreateResponseBindingsItemVPCNetworkType: any;
export interface BetaWorkersVersionsCreateResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsCreateResponseBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseBindingsItemVPCNetwork: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemVPCNetwork>;
export type BetaWorkersVersionsCreateResponseBindingsItem = BetaWorkersVersionsCreateResponseBindingsItemAI | BetaWorkersVersionsCreateResponseBindingsItemAISearch | BetaWorkersVersionsCreateResponseBindingsItemAISearchNamespace | BetaWorkersVersionsCreateResponseBindingsItemAnalyticsEngine | BetaWorkersVersionsCreateResponseBindingsItemAssets | BetaWorkersVersionsCreateResponseBindingsItemBrowser | BetaWorkersVersionsCreateResponseBindingsItemD1 | BetaWorkersVersionsCreateResponseBindingsItemDataBlob | BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespace | BetaWorkersVersionsCreateResponseBindingsItemDurableObjectNamespace | BetaWorkersVersionsCreateResponseBindingsItemHyperdrive | BetaWorkersVersionsCreateResponseBindingsItemInherit | BetaWorkersVersionsCreateResponseBindingsItemImages | BetaWorkersVersionsCreateResponseBindingsItemJson | BetaWorkersVersionsCreateResponseBindingsItemKVNamespace | BetaWorkersVersionsCreateResponseBindingsItemMedia | BetaWorkersVersionsCreateResponseBindingsItemMTLSCertificate | BetaWorkersVersionsCreateResponseBindingsItemPlainText | BetaWorkersVersionsCreateResponseBindingsItemPipelines | BetaWorkersVersionsCreateResponseBindingsItemQueue | BetaWorkersVersionsCreateResponseBindingsItemRatelimit | BetaWorkersVersionsCreateResponseBindingsItemR2Bucket | BetaWorkersVersionsCreateResponseBindingsItemSecretText | BetaWorkersVersionsCreateResponseBindingsItemSendEmail | BetaWorkersVersionsCreateResponseBindingsItemService | BetaWorkersVersionsCreateResponseBindingsItemTextBlob | BetaWorkersVersionsCreateResponseBindingsItemVectorize | BetaWorkersVersionsCreateResponseBindingsItemVersionMetadata | BetaWorkersVersionsCreateResponseBindingsItemSecretsStoreSecret | BetaWorkersVersionsCreateResponseBindingsItemFlagship | BetaWorkersVersionsCreateResponseBindingsItemSecretKey | BetaWorkersVersionsCreateResponseBindingsItemWorkflow | BetaWorkersVersionsCreateResponseBindingsItemWasmModule | BetaWorkersVersionsCreateResponseBindingsItemVPCService | BetaWorkersVersionsCreateResponseBindingsItemVPCNetwork;
export declare const BetaWorkersVersionsCreateResponseBindingsItem: any;
export type BetaWorkersVersionsCreateResponseBindingsList = Array<BetaWorkersVersionsCreateResponseBindingsItem>;
export declare const BetaWorkersVersionsCreateResponseBindingsList: S.Schema<BetaWorkersVersionsCreateResponseBindingsList>;
export interface BetaWorkersVersionsCreateResponseCacheOptions {
    /** Whether caching is enabled for this Worker. */
    enabled: boolean;
    /** Whether cached responses are shared across Worker version */
    crossVersionCache?: boolean | null;
}
export declare const BetaWorkersVersionsCreateResponseCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type BetaWorkersVersionsCreateResponseCompatibilityFlagsList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseCompatibilityFlagsList: S.Schema<BetaWorkersVersionsCreateResponseCompatibilityFlagsList>;
export type BetaWorkersVersionsCreateResponseContainersItem = BetaWorkersVersionsCreateRequestContainersItem;
export declare const BetaWorkersVersionsCreateResponseContainersItem: S.Schema<BetaWorkersVersionsCreateRequestContainersItem>;
export type BetaWorkersVersionsCreateResponseContainersList = Array<BetaWorkersVersionsCreateRequestContainersItem>;
export declare const BetaWorkersVersionsCreateResponseContainersList: S.Schema<BetaWorkersVersionsCreateResponseContainersList>;
export interface BetaWorkersVersionsCreateResponseLimits {
    /** CPU time limit in milliseconds. */
    cpuMs?: number | null;
    /** Subrequest limit per request. */
    subrequests?: number | null;
}
export declare const BetaWorkersVersionsCreateResponseLimits: S.Schema<BetaWorkersVersionsCreateResponseLimits>;
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationDeletedClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationDeletedClassesList>;
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewClassesList>;
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewSqliteClassesList>;
export interface BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem {
    from?: string | null;
    to?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesList>;
export interface BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem {
    from?: string | null;
    fromScript?: string | null;
    to?: string | null;
}
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesList>;
export interface BetaWorkersVersionsCreateResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export declare const BetaWorkersVersionsCreateResponseMigrationsSingleStepMigration: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigration>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export declare const BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrations: S.Schema<BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrations>;
export type BetaWorkersVersionsCreateResponseMigrations = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigration | BetaWorkersVersionsCreateResponseMigrationsWorkersMultipleStepMigrations;
export declare const BetaWorkersVersionsCreateResponseMigrations: any;
export type BetaWorkersVersionsCreateResponseModulesItem = BetaWorkersVersionsCreateRequestModulesItem;
export declare const BetaWorkersVersionsCreateResponseModulesItem: S.Schema<BetaWorkersVersionsCreateRequestModulesItem>;
export type BetaWorkersVersionsCreateResponseModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export declare const BetaWorkersVersionsCreateResponseModulesList: S.Schema<BetaWorkersVersionsCreateResponseModulesList>;
export type BetaWorkersVersionsCreateResponsePackageDependenciesItem = BetaWorkersVersionsCreateRequestPackageDependenciesItem;
export declare const BetaWorkersVersionsCreateResponsePackageDependenciesItem: S.Schema<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsCreateResponsePackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export declare const BetaWorkersVersionsCreateResponsePackageDependenciesList: S.Schema<BetaWorkersVersionsCreateResponsePackageDependenciesList>;
export type BetaWorkersVersionsCreateResponsePlacementModeMode = "smart";
export declare const BetaWorkersVersionsCreateResponsePlacementModeMode: any;
export interface BetaWorkersVersionsCreateResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsCreateResponsePlacementModeMode;
}
export declare const BetaWorkersVersionsCreateResponsePlacementMode: S.Schema<BetaWorkersVersionsCreateResponsePlacementMode>;
export type BetaWorkersVersionsCreateResponsePlacementRegion = BetaWorkersVersionsCreateRequestPlacementRegion;
export declare const BetaWorkersVersionsCreateResponsePlacementRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementRegion>;
export type BetaWorkersVersionsCreateResponsePlacementHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const BetaWorkersVersionsCreateResponsePlacementHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type BetaWorkersVersionsCreateResponsePlacementHost = BetaWorkersVersionsCreateRequestPlacementHost;
export declare const BetaWorkersVersionsCreateResponsePlacementHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementHost>;
export type BetaWorkersVersionsCreateResponsePlacementCase4Mode = "targeted";
export declare const BetaWorkersVersionsCreateResponsePlacementCase4Mode: any;
export interface BetaWorkersVersionsCreateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const BetaWorkersVersionsCreateResponsePlacementCase4: S.Schema<BetaWorkersVersionsCreateResponsePlacementCase4>;
export type BetaWorkersVersionsCreateResponsePlacementCase5Mode = "targeted";
export declare const BetaWorkersVersionsCreateResponsePlacementCase5Mode: any;
export interface BetaWorkersVersionsCreateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase5Mode;
}
export declare const BetaWorkersVersionsCreateResponsePlacementCase5: S.Schema<BetaWorkersVersionsCreateResponsePlacementCase5>;
export type BetaWorkersVersionsCreateResponsePlacementCase6Mode = "targeted";
export declare const BetaWorkersVersionsCreateResponsePlacementCase6Mode: any;
export interface BetaWorkersVersionsCreateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase6Mode;
}
export declare const BetaWorkersVersionsCreateResponsePlacementCase6: S.Schema<BetaWorkersVersionsCreateResponsePlacementCase6>;
export type BetaWorkersVersionsCreateResponsePlacementCase7Mode = "targeted";
export declare const BetaWorkersVersionsCreateResponsePlacementCase7Mode: any;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const BetaWorkersVersionsCreateResponsePlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const BetaWorkersVersionsCreateResponsePlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const BetaWorkersVersionsCreateResponsePlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const BetaWorkersVersionsCreateResponsePlacementCase7TargetItem: any;
export type BetaWorkersVersionsCreateResponsePlacementCase7TargetList = Array<BetaWorkersVersionsCreateResponsePlacementCase7TargetItem>;
export declare const BetaWorkersVersionsCreateResponsePlacementCase7TargetList: S.Schema<BetaWorkersVersionsCreateResponsePlacementCase7TargetList>;
export interface BetaWorkersVersionsCreateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsCreateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsCreateResponsePlacementCase7TargetList;
}
export declare const BetaWorkersVersionsCreateResponsePlacementCase7: S.Schema<BetaWorkersVersionsCreateResponsePlacementCase7>;
export type BetaWorkersVersionsCreateResponsePlacement = BetaWorkersVersionsCreateResponsePlacementMode | BetaWorkersVersionsCreateRequestPlacementRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementHost | BetaWorkersVersionsCreateResponsePlacementCase4 | BetaWorkersVersionsCreateResponsePlacementCase5 | BetaWorkersVersionsCreateResponsePlacementCase6 | BetaWorkersVersionsCreateResponsePlacementCase7;
export declare const BetaWorkersVersionsCreateResponsePlacement: any;
export type BetaWorkersVersionsCreateResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const BetaWorkersVersionsCreateResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateBetaWorkerVersionResponse {
    /** Version identifier. */
    id: string;
    /** When the version was created. */
    createdOn: string;
    /** The integer version number, starting from one. */
    number: number;
    /** All routable URLs that always point to this version. Does not include alias URLs, since aliases can be updated to point to a different version. */
    urls: BetaWorkersVersionsCreateResponseUrlsList;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateResponseAnnotations | null;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsCreateResponseAssets | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsCreateResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsCreateResponseCompatibilityFlagsList | null;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsCreateResponseContainersList | null;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateResponseLimits | null;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string | null;
    /** Durable Object migration tag. Set when the version is deployed. Omitted if the version has not been deployed or the Worker does not use Durable Objects. */
    migrationTag?: string | null;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsCreateResponseMigrations | null;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsCreateResponseModulesList | null;
    /** The list of npm packages that were installed and used when this Worker */
    packageDependencies?: BetaWorkersVersionsCreateResponsePackageDependenciesList | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsCreateResponsePlacement | null;
    /** The client used to create the version. */
    source?: string | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsCreateResponseUsageModel | null;
}
export declare const CreateBetaWorkerVersionResponse: S.Schema<CreateBetaWorkerVersionResponse>;
export type ObservabilityDestinationsCreateRequestConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ObservabilityDestinationsCreateRequestConfigurationHeadersMap: S.Schema<ObservabilityDestinationsCreateRequestConfigurationHeadersMap>;
export type ObservabilityDestinationsCreateRequestConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export declare const ObservabilityDestinationsCreateRequestConfigurationLogpushDataset: any;
export type ObservabilityDestinationsCreateRequestConfigurationType = "logpush";
export declare const ObservabilityDestinationsCreateRequestConfigurationType: any;
export interface ObservabilityDestinationsCreateRequestConfiguration {
    headers: ObservabilityDestinationsCreateRequestConfigurationHeadersMap;
    logpushDataset: ObservabilityDestinationsCreateRequestConfigurationLogpushDataset | (string & {});
    type: ObservabilityDestinationsCreateRequestConfigurationType | (string & {});
    url: string;
}
export declare const ObservabilityDestinationsCreateRequestConfiguration: S.Schema<ObservabilityDestinationsCreateRequestConfiguration>;
export interface CreateObservabilityDestinationRequest {
    accountId: string;
    configuration: ObservabilityDestinationsCreateRequestConfiguration;
    enabled: boolean;
    name: string;
    skipPreflightCheck?: boolean;
}
export declare const CreateObservabilityDestinationRequest: S.Schema<CreateObservabilityDestinationRequest>;
export type ObservabilityDestinationsCreateResponseConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export declare const ObservabilityDestinationsCreateResponseConfigurationLogpushDataset: any;
export type ObservabilityDestinationsCreateResponseConfigurationType = "logpush";
export declare const ObservabilityDestinationsCreateResponseConfigurationType: any;
export interface ObservabilityDestinationsCreateResponseConfiguration {
    destinationConf: string;
    logpushDataset: ObservabilityDestinationsCreateResponseConfigurationLogpushDataset;
    logpushJob: number;
    type: ObservabilityDestinationsCreateResponseConfigurationType;
    url: string;
}
export declare const ObservabilityDestinationsCreateResponseConfiguration: S.Schema<ObservabilityDestinationsCreateResponseConfiguration>;
export type ObservabilityDestinationsCreateResponseScriptsList = Array<string>;
export declare const ObservabilityDestinationsCreateResponseScriptsList: S.Schema<ObservabilityDestinationsCreateResponseScriptsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateObservabilityDestinationResponse {
    configuration: ObservabilityDestinationsCreateResponseConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsCreateResponseScriptsList;
    slug: string;
}
export declare const CreateObservabilityDestinationResponse: S.Schema<CreateObservabilityDestinationResponse>;
export type ObservabilityQueriesCreateRequestParametersCalculationsItemOperator = "uniq" | "count" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "COUNT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export declare const ObservabilityQueriesCreateRequestParametersCalculationsItemOperator: any;
export type ObservabilityQueriesCreateRequestParametersCalculationsItemKeyType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesCreateRequestParametersCalculationsItemKeyType: any;
export interface ObservabilityQueriesCreateRequestParametersCalculationsItem {
    operator: ObservabilityQueriesCreateRequestParametersCalculationsItemOperator | (string & {});
    alias?: string;
    key?: string;
    keyType?: ObservabilityQueriesCreateRequestParametersCalculationsItemKeyType | (string & {});
}
export declare const ObservabilityQueriesCreateRequestParametersCalculationsItem: S.Schema<ObservabilityQueriesCreateRequestParametersCalculationsItem>;
export type ObservabilityQueriesCreateRequestParametersCalculationsList = Array<ObservabilityQueriesCreateRequestParametersCalculationsItem>;
export declare const ObservabilityQueriesCreateRequestParametersCalculationsList: S.Schema<ObservabilityQueriesCreateRequestParametersCalculationsList>;
export type ObservabilityQueriesCreateRequestParametersDatasetsList = Array<string>;
export declare const ObservabilityQueriesCreateRequestParametersDatasetsList: S.Schema<ObservabilityQueriesCreateRequestParametersDatasetsList>;
export type ObservabilityQueriesCreateRequestParametersFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityQueriesCreateRequestParametersFilterCombination: any;
export type ObservabilityQueriesCreateRequestParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemCase0FilterCombination: any;
export type ObservabilityQueriesCreateRequestParametersFiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemCase0FiltersList: S.Schema<ObservabilityQueriesCreateRequestParametersFiltersItemCase0FiltersList>;
export type ObservabilityQueriesCreateRequestParametersFiltersItemCase0Kind = "group";
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemCase0Kind: any;
export interface ObservabilityQueriesCreateRequestParametersFiltersItemCase0 {
    filterCombination: ObservabilityQueriesCreateRequestParametersFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityQueriesCreateRequestParametersFiltersItemCase0FiltersList;
    kind: ObservabilityQueriesCreateRequestParametersFiltersItemCase0Kind;
}
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemCase0: S.Schema<ObservabilityQueriesCreateRequestParametersFiltersItemCase0>;
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityQueriesCreateRequestParametersFiltersItem = ObservabilityQueriesCreateRequestParametersFiltersItemCase0 | ObservabilityQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityQueriesCreateRequestParametersFiltersItem: any;
export type ObservabilityQueriesCreateRequestParametersFiltersList = Array<ObservabilityQueriesCreateRequestParametersFiltersItem>;
export declare const ObservabilityQueriesCreateRequestParametersFiltersList: S.Schema<ObservabilityQueriesCreateRequestParametersFiltersList>;
export type ObservabilityQueriesCreateRequestParametersGroupBysItemType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesCreateRequestParametersGroupBysItemType: any;
export interface ObservabilityQueriesCreateRequestParametersGroupBysItem {
    type: ObservabilityQueriesCreateRequestParametersGroupBysItemType | (string & {});
    value: string;
}
export declare const ObservabilityQueriesCreateRequestParametersGroupBysItem: S.Schema<ObservabilityQueriesCreateRequestParametersGroupBysItem>;
export type ObservabilityQueriesCreateRequestParametersGroupBysList = Array<ObservabilityQueriesCreateRequestParametersGroupBysItem>;
export declare const ObservabilityQueriesCreateRequestParametersGroupBysList: S.Schema<ObservabilityQueriesCreateRequestParametersGroupBysList>;
export type ObservabilityQueriesCreateRequestParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export declare const ObservabilityQueriesCreateRequestParametersHavingsItemOperation: any;
export interface ObservabilityQueriesCreateRequestParametersHavingsItem {
    key: string;
    operation: ObservabilityQueriesCreateRequestParametersHavingsItemOperation | (string & {});
    value: number;
}
export declare const ObservabilityQueriesCreateRequestParametersHavingsItem: S.Schema<ObservabilityQueriesCreateRequestParametersHavingsItem>;
export type ObservabilityQueriesCreateRequestParametersHavingsList = Array<ObservabilityQueriesCreateRequestParametersHavingsItem>;
export declare const ObservabilityQueriesCreateRequestParametersHavingsList: S.Schema<ObservabilityQueriesCreateRequestParametersHavingsList>;
export type ObservabilityQueriesCreateRequestParametersNeedleValue = string | number | boolean;
export declare const ObservabilityQueriesCreateRequestParametersNeedleValue: any;
export interface ObservabilityQueriesCreateRequestParametersNeedle {
    value: ObservabilityQueriesCreateRequestParametersNeedleValue;
    isRegex?: boolean;
    matchCase?: boolean;
}
export declare const ObservabilityQueriesCreateRequestParametersNeedle: S.Schema<ObservabilityQueriesCreateRequestParametersNeedle>;
export type ObservabilityQueriesCreateRequestParametersOrderByOrder = "asc" | "desc";
export declare const ObservabilityQueriesCreateRequestParametersOrderByOrder: any;
export interface ObservabilityQueriesCreateRequestParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityQueriesCreateRequestParametersOrderByOrder | (string & {});
}
export declare const ObservabilityQueriesCreateRequestParametersOrderBy: S.Schema<ObservabilityQueriesCreateRequestParametersOrderBy>;
export interface ObservabilityQueriesCreateRequestParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityQueriesCreateRequestParametersCalculationsList;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityQueriesCreateRequestParametersDatasetsList;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityQueriesCreateRequestParametersFilterCombination | (string & {});
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityQueriesCreateRequestParametersFiltersList;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityQueriesCreateRequestParametersGroupBysList;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityQueriesCreateRequestParametersHavingsList;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilityQueriesCreateRequestParametersNeedle;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityQueriesCreateRequestParametersOrderBy;
}
export declare const ObservabilityQueriesCreateRequestParameters: S.Schema<ObservabilityQueriesCreateRequestParameters>;
export interface CreateObservabilityQueryRequest {
    accountId: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityQueriesCreateRequestParameters;
}
export declare const CreateObservabilityQueryRequest: S.Schema<CreateObservabilityQueryRequest>;
export type ObservabilityQueriesCreateResponseParametersCalculationsItemOperator = "uniq" | "count" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "COUNT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export declare const ObservabilityQueriesCreateResponseParametersCalculationsItemOperator: any;
export type ObservabilityQueriesCreateResponseParametersCalculationsItemKeyType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesCreateResponseParametersCalculationsItemKeyType: any;
export interface ObservabilityQueriesCreateResponseParametersCalculationsItem {
    operator: ObservabilityQueriesCreateResponseParametersCalculationsItemOperator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilityQueriesCreateResponseParametersCalculationsItemKeyType | null;
}
export declare const ObservabilityQueriesCreateResponseParametersCalculationsItem: S.Schema<ObservabilityQueriesCreateResponseParametersCalculationsItem>;
export type ObservabilityQueriesCreateResponseParametersCalculationsList = Array<ObservabilityQueriesCreateResponseParametersCalculationsItem>;
export declare const ObservabilityQueriesCreateResponseParametersCalculationsList: S.Schema<ObservabilityQueriesCreateResponseParametersCalculationsList>;
export type ObservabilityQueriesCreateResponseParametersDatasetsList = Array<string>;
export declare const ObservabilityQueriesCreateResponseParametersDatasetsList: S.Schema<ObservabilityQueriesCreateResponseParametersDatasetsList>;
export type ObservabilityQueriesCreateResponseParametersFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityQueriesCreateResponseParametersFilterCombination: any;
export type ObservabilityQueriesCreateResponseParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemCase0FilterCombination: any;
export type ObservabilityQueriesCreateResponseParametersFiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemCase0FiltersList: S.Schema<ObservabilityQueriesCreateResponseParametersFiltersItemCase0FiltersList>;
export type ObservabilityQueriesCreateResponseParametersFiltersItemCase0Kind = "group";
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemCase0Kind: any;
export interface ObservabilityQueriesCreateResponseParametersFiltersItemCase0 {
    filterCombination: ObservabilityQueriesCreateResponseParametersFiltersItemCase0FilterCombination;
    filters: ObservabilityQueriesCreateResponseParametersFiltersItemCase0FiltersList;
    kind: ObservabilityQueriesCreateResponseParametersFiltersItemCase0Kind;
}
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemCase0: S.Schema<ObservabilityQueriesCreateResponseParametersFiltersItemCase0>;
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export declare const ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityQueriesCreateResponseParametersFiltersItem = ObservabilityQueriesCreateResponseParametersFiltersItemCase0 | ObservabilityQueriesCreateResponseParametersFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityQueriesCreateResponseParametersFiltersItem: any;
export type ObservabilityQueriesCreateResponseParametersFiltersList = Array<ObservabilityQueriesCreateResponseParametersFiltersItem>;
export declare const ObservabilityQueriesCreateResponseParametersFiltersList: S.Schema<ObservabilityQueriesCreateResponseParametersFiltersList>;
export type ObservabilityQueriesCreateResponseParametersGroupBysItemType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesCreateResponseParametersGroupBysItemType: any;
export interface ObservabilityQueriesCreateResponseParametersGroupBysItem {
    type: ObservabilityQueriesCreateResponseParametersGroupBysItemType;
    value: string;
}
export declare const ObservabilityQueriesCreateResponseParametersGroupBysItem: S.Schema<ObservabilityQueriesCreateResponseParametersGroupBysItem>;
export type ObservabilityQueriesCreateResponseParametersGroupBysList = Array<ObservabilityQueriesCreateResponseParametersGroupBysItem>;
export declare const ObservabilityQueriesCreateResponseParametersGroupBysList: S.Schema<ObservabilityQueriesCreateResponseParametersGroupBysList>;
export type ObservabilityQueriesCreateResponseParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export declare const ObservabilityQueriesCreateResponseParametersHavingsItemOperation: any;
export interface ObservabilityQueriesCreateResponseParametersHavingsItem {
    key: string;
    operation: ObservabilityQueriesCreateResponseParametersHavingsItemOperation;
    value: number;
}
export declare const ObservabilityQueriesCreateResponseParametersHavingsItem: S.Schema<ObservabilityQueriesCreateResponseParametersHavingsItem>;
export type ObservabilityQueriesCreateResponseParametersHavingsList = Array<ObservabilityQueriesCreateResponseParametersHavingsItem>;
export declare const ObservabilityQueriesCreateResponseParametersHavingsList: S.Schema<ObservabilityQueriesCreateResponseParametersHavingsList>;
export type ObservabilityQueriesCreateResponseParametersNeedleValue = string | number | boolean;
export declare const ObservabilityQueriesCreateResponseParametersNeedleValue: any;
export interface ObservabilityQueriesCreateResponseParametersNeedle {
    value: ObservabilityQueriesCreateResponseParametersNeedleValue;
    isRegex?: boolean | null;
    matchCase?: boolean | null;
}
export declare const ObservabilityQueriesCreateResponseParametersNeedle: S.Schema<ObservabilityQueriesCreateResponseParametersNeedle>;
export type ObservabilityQueriesCreateResponseParametersOrderByOrder = "asc" | "desc";
export declare const ObservabilityQueriesCreateResponseParametersOrderByOrder: any;
export interface ObservabilityQueriesCreateResponseParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityQueriesCreateResponseParametersOrderByOrder | null;
}
export declare const ObservabilityQueriesCreateResponseParametersOrderBy: S.Schema<ObservabilityQueriesCreateResponseParametersOrderBy>;
export interface ObservabilityQueriesCreateResponseParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityQueriesCreateResponseParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityQueriesCreateResponseParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityQueriesCreateResponseParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityQueriesCreateResponseParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityQueriesCreateResponseParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityQueriesCreateResponseParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilityQueriesCreateResponseParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityQueriesCreateResponseParametersOrderBy | null;
}
export declare const ObservabilityQueriesCreateResponseParameters: S.Schema<ObservabilityQueriesCreateResponseParameters>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateObservabilityQueryResponse {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityQueriesCreateResponseParameters;
    updated: string;
    updatedBy: string;
}
export declare const CreateObservabilityQueryResponse: S.Schema<CreateObservabilityQueryResponse>;
export interface ObservabilitySharedQueriesCreateRequestTimeframe {
    /** Start timestamp for the query timeframe (Unix timestamp in milliseconds) */
    from: number;
    /** End timestamp for the query timeframe (Unix timestamp in milliseconds) */
    to: number;
}
export declare const ObservabilitySharedQueriesCreateRequestTimeframe: S.Schema<ObservabilitySharedQueriesCreateRequestTimeframe>;
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsItemOperator = "uniq" | "count" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "COUNT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export declare const ObservabilitySharedQueriesCreateRequestParametersCalculationsItemOperator: any;
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsItemKeyType = "string" | "number" | "boolean";
export declare const ObservabilitySharedQueriesCreateRequestParametersCalculationsItemKeyType: any;
export interface ObservabilitySharedQueriesCreateRequestParametersCalculationsItem {
    /** Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance. */
    operator: ObservabilitySharedQueriesCreateRequestParametersCalculationsItemOperator | (string & {});
    /** Custom label for this calculation in the results. Useful for distinguishing multiple calculations. */
    alias?: string;
    /** Field name to calculate over. Must exist in the data — verify with the keys endpoint. Omit for operators that don't require a key (e.g. count). */
    key?: string;
    /** Data type of the key. Required when key is provided to ensure correct aggregation. */
    keyType?: ObservabilitySharedQueriesCreateRequestParametersCalculationsItemKeyType | (string & {});
}
export declare const ObservabilitySharedQueriesCreateRequestParametersCalculationsItem: S.Schema<ObservabilitySharedQueriesCreateRequestParametersCalculationsItem>;
export type ObservabilitySharedQueriesCreateRequestParametersCalculationsList = Array<ObservabilitySharedQueriesCreateRequestParametersCalculationsItem>;
export declare const ObservabilitySharedQueriesCreateRequestParametersCalculationsList: S.Schema<ObservabilitySharedQueriesCreateRequestParametersCalculationsList>;
export type ObservabilitySharedQueriesCreateRequestParametersDatasetsList = Array<string>;
export declare const ObservabilitySharedQueriesCreateRequestParametersDatasetsList: S.Schema<ObservabilitySharedQueriesCreateRequestParametersDatasetsList>;
export type ObservabilitySharedQueriesCreateRequestParametersFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilitySharedQueriesCreateRequestParametersFilterCombination: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FilterCombination: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FiltersList: S.Schema<ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FiltersList>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0Kind = "group";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0Kind: any;
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0Kind;
}
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0: S.Schema<ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItem = ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemCase0 | ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItem: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersList = Array<ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersItem>;
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersList: S.Schema<ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersList>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0Kind = "group";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0Kind: any;
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0 {
    filterCombination: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0FiltersList;
    kind: ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0Kind;
}
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0: S.Schema<ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersItem = ObservabilitySharedQueriesCreateRequestParametersFiltersItemCase0 | ObservabilitySharedQueriesCreateRequestParametersFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersItem: any;
export type ObservabilitySharedQueriesCreateRequestParametersFiltersList = Array<ObservabilitySharedQueriesCreateRequestParametersFiltersItem>;
export declare const ObservabilitySharedQueriesCreateRequestParametersFiltersList: S.Schema<ObservabilitySharedQueriesCreateRequestParametersFiltersList>;
export type ObservabilitySharedQueriesCreateRequestParametersGroupBysItemType = "string" | "number" | "boolean";
export declare const ObservabilitySharedQueriesCreateRequestParametersGroupBysItemType: any;
export interface ObservabilitySharedQueriesCreateRequestParametersGroupBysItem {
    /** Data type of the group-by field. */
    type: ObservabilitySharedQueriesCreateRequestParametersGroupBysItemType | (string & {});
    /** Field name to group results by (e.g. $metadata.service, $metadata.statusCode). */
    value: string;
}
export declare const ObservabilitySharedQueriesCreateRequestParametersGroupBysItem: S.Schema<ObservabilitySharedQueriesCreateRequestParametersGroupBysItem>;
export type ObservabilitySharedQueriesCreateRequestParametersGroupBysList = Array<ObservabilitySharedQueriesCreateRequestParametersGroupBysItem>;
export declare const ObservabilitySharedQueriesCreateRequestParametersGroupBysList: S.Schema<ObservabilitySharedQueriesCreateRequestParametersGroupBysList>;
export type ObservabilitySharedQueriesCreateRequestParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export declare const ObservabilitySharedQueriesCreateRequestParametersHavingsItemOperation: any;
export interface ObservabilitySharedQueriesCreateRequestParametersHavingsItem {
    /** Calculation alias or operator to filter on after aggregation. */
    key: string;
    /** Numeric comparison operator: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesCreateRequestParametersHavingsItemOperation | (string & {});
    /** Threshold value to compare the calculation result against. */
    value: number;
}
export declare const ObservabilitySharedQueriesCreateRequestParametersHavingsItem: S.Schema<ObservabilitySharedQueriesCreateRequestParametersHavingsItem>;
export type ObservabilitySharedQueriesCreateRequestParametersHavingsList = Array<ObservabilitySharedQueriesCreateRequestParametersHavingsItem>;
export declare const ObservabilitySharedQueriesCreateRequestParametersHavingsList: S.Schema<ObservabilitySharedQueriesCreateRequestParametersHavingsList>;
export type ObservabilitySharedQueriesCreateRequestParametersNeedleValue = string | number | boolean;
export declare const ObservabilitySharedQueriesCreateRequestParametersNeedleValue: any;
export interface ObservabilitySharedQueriesCreateRequestParametersNeedle {
    /** The text or pattern to search for. */
    value: ObservabilitySharedQueriesCreateRequestParametersNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export declare const ObservabilitySharedQueriesCreateRequestParametersNeedle: S.Schema<ObservabilitySharedQueriesCreateRequestParametersNeedle>;
export type ObservabilitySharedQueriesCreateRequestParametersOrderByOrder = "asc" | "desc";
export declare const ObservabilitySharedQueriesCreateRequestParametersOrderByOrder: any;
export interface ObservabilitySharedQueriesCreateRequestParametersOrderBy {
    /** Alias of the calculation to order results by. Must match the alias (or operator) of a calculation in the query. */
    value: string;
    /** Sort direction: 'asc' for ascending, 'desc' for descending. */
    order?: ObservabilitySharedQueriesCreateRequestParametersOrderByOrder | (string & {});
}
export declare const ObservabilitySharedQueriesCreateRequestParametersOrderBy: S.Schema<ObservabilitySharedQueriesCreateRequestParametersOrderBy>;
export interface ObservabilitySharedQueriesCreateRequestParameters {
    /** Aggregation calculations to compute (e.g. count, avg, p99). Each calculation produces aggregate values and optional time-series data. */
    calculations?: ObservabilitySharedQueriesCreateRequestParametersCalculationsList;
    /** Datasets to query. Leave empty to query all available datasets. */
    datasets?: ObservabilitySharedQueriesCreateRequestParametersDatasetsList;
    /** Logical operator for combining top-level filters: 'and' (all must match) or 'or' (any must match). Defaults to 'and'. */
    filterCombination?: ObservabilitySharedQueriesCreateRequestParametersFilterCombination | (string & {});
    /** Filters to narrow query results. Use the keys and values endpoints to discover available fields before building filters. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilitySharedQueriesCreateRequestParametersFiltersList;
    /** Fields to group calculation results by. Only applicable when the query view is 'calculations'. Produces per-group aggregate values. */
    groupBys?: ObservabilitySharedQueriesCreateRequestParametersGroupBysList;
    /** Post-aggregation filters applied to calculation results. Use to filter groups after aggregation (e.g. only groups where count > 100). */
    havings?: ObservabilitySharedQueriesCreateRequestParametersHavingsList;
    /** Maximum number of group-by rows to return in calculation results. A value of 10 is a sensible default for most use cases. */
    limit?: number;
    /** Full-text search expression applied across all event fields. Matches events containing the specified text. */
    needle?: ObservabilitySharedQueriesCreateRequestParametersNeedle;
    /** Ordering for grouped calculation results. Only effective when a group-by is present. */
    orderBy?: ObservabilitySharedQueriesCreateRequestParametersOrderBy;
}
export declare const ObservabilitySharedQueriesCreateRequestParameters: S.Schema<ObservabilitySharedQueriesCreateRequestParameters>;
export type ObservabilitySharedQueriesCreateRequestView = "traces" | "events" | "calculations" | "invocations" | "requests" | "agents";
export declare const ObservabilitySharedQueriesCreateRequestView: any;
export interface CreateObservabilitySharedQueryRequest {
    accountId: string;
    /** Identifier for the query. When parameters are omitted, this ID is used to load a previously saved query's parameters. When providing parameters inline, pass any identifier (e.g. an ad-hoc ID). */
    queryId: string;
    /** Timeframe for the query using Unix timestamps in milliseconds. Narrower timeframes produce faster responses and more specific results. */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** When true, includes time-series data in the response. */
    chart?: boolean;
    /** When true, includes a comparison dataset from the previous time period of equal length. */
    compare?: boolean;
    /** When true, executes the query without persisting the results. Useful for validation or previewing. */
    dry?: boolean;
    /** Number of time-series buckets. Only used when view is 'calculations'. Omit to let the system auto-detect an appropriate granularity. */
    granularity?: number;
    /** When true, omits time-series data from the response and returns only aggregated values. Reduces response size when series are not needed. */
    ignoreSeries?: boolean;
    /** Maximum number of events to return when view is 'events'. Also controls the number of group-by rows when view is 'calculations'. */
    limit?: number;
    /** Cursor for pagination in event, trace, and invocation views. Pass the $metadata.id of the last returned item to fetch the next page. */
    offset?: string;
    /** Numeric offset for paginating grouped/pattern results (top-N lists). Use together with limit. Not used by cursor-based pagination. */
    offsetBy?: number;
    /** Pagination direction: 'next' for forward, 'prev' for backward. */
    offsetDirection?: string;
    /** Query parameters defining what data to retrieve — filters, calculations, group-bys, and ordering. In practice this should always be provided for ad-hoc queries. Only omit when executing a previously saved query by queryId. Use the keys and values endpoints to discover available fields before building filters. */
    parameters?: ObservabilitySharedQueriesCreateRequestParameters;
    /** Controls the shape of the response. 'events': individual log lines matching the query. 'calculations': aggregated metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series. 'invocations': events grouped by request ID. 'traces': distributed trace summaries. 'agents': Durable Object agent summaries. */
    view?: ObservabilitySharedQueriesCreateRequestView | (string & {});
}
export declare const CreateObservabilitySharedQueryRequest: S.Schema<CreateObservabilitySharedQueryRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateObservabilitySharedQueryResponse {
    /** Specify the ID of the shared query. */
    id: string;
}
export declare const CreateObservabilitySharedQueryResponse: S.Schema<CreateObservabilitySharedQueryResponse>;
export interface PreviewTailConsumer {
    name: string;
}
export declare const PreviewTailConsumer: S.Schema<PreviewTailConsumer>;
export type PreviewTailConsumersList = Array<PreviewTailConsumer>;
export declare const PreviewTailConsumersList: S.Schema<PreviewTailConsumersList>;
export interface CreatePreviewRequest {
    accountId: string;
    /** Parent Worker id or script name. */
    workerId: string;
    /** Do not copy the parent's Previews Base configuration onto this Preview. */
    ignoreBaseConfig?: boolean;
    /** Preview name. Defaults to the git branch in wrangler; Alchemy defaults to the stage. */
    name: string;
    logpush?: boolean;
    tailConsumers?: PreviewTailConsumersList;
}
export declare const CreatePreviewRequest: S.Schema<CreatePreviewRequest>;
export type PreviewUrlsList = Array<string>;
export declare const PreviewUrlsList: S.Schema<PreviewUrlsList>;
export interface PreviewResource {
    /** Immutable Preview id. */
    id: string;
    /** Preview name as created (e.g. a git branch). */
    name: string;
    /** DNS-safe slug used in Preview URLs. */
    slug: string;
    /** Parent Worker script name this Preview belongs to. */
    workerName: string;
    /** Stable Preview URLs (always the latest deployment). */
    urls?: PreviewUrlsList | null;
    tags?: PreviewUrlsList | null;
    logpush?: boolean | null;
    tailConsumers?: PreviewTailConsumersList | null;
    createdOn?: string | null;
    updatedOn?: string | null;
}
export declare const PreviewResource: S.Schema<PreviewResource>;
export interface CreatePreviewDeploymentMetadataAssets {
    jwt?: string;
    config?: unknown;
}
export declare const CreatePreviewDeploymentMetadataAssets: S.Schema<CreatePreviewDeploymentMetadataAssets>;
export type CreatePreviewDeploymentMetadataCompatibilityFlagsList = Array<string>;
export declare const CreatePreviewDeploymentMetadataCompatibilityFlagsList: S.Schema<CreatePreviewDeploymentMetadataCompatibilityFlagsList>;
export interface CreatePreviewDeploymentMetadataContainer {
    className: string;
}
export declare const CreatePreviewDeploymentMetadataContainer: S.Schema<CreatePreviewDeploymentMetadataContainer>;
export type CreatePreviewDeploymentMetadataContainersList = Array<CreatePreviewDeploymentMetadataContainer>;
export declare const CreatePreviewDeploymentMetadataContainersList: S.Schema<CreatePreviewDeploymentMetadataContainersList>;
export interface CreatePreviewDeploymentMetadata {
    /** Entrypoint module filename. */
    mainModule?: string;
    assets?: CreatePreviewDeploymentMetadataAssets;
    compatibilityDate?: string;
    compatibilityFlags?: CreatePreviewDeploymentMetadataCompatibilityFlagsList;
    /** Version annotations (workers/message, workers/tag, …). */
    annotations?: unknown;
    /** Durable Object class migrations for this Preview's isolated namespaces. */
    migrations?: unknown;
    limits?: unknown;
    placement?: unknown;
    cacheOptions?: unknown;
    /** Binding map keyed by runtime name (wrangler `env` format). */
    env?: unknown;
    containers?: CreatePreviewDeploymentMetadataContainersList;
}
export declare const CreatePreviewDeploymentMetadata: S.Schema<CreatePreviewDeploymentMetadata>;
export interface CreatePreviewDeploymentRequest {
    accountId: string;
    workerId: string;
    /** Preview id (not name) — wrangler uses the resource id returned by createPreview. */
    previewId: string;
    /** JSON-encoded multipart `metadata` part. */
    metadata: CreatePreviewDeploymentMetadata;
    /** Module files comprising the Worker script, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export declare const CreatePreviewDeploymentRequest: S.Schema<CreatePreviewDeploymentRequest>;
export interface PreviewDeploymentResource {
    id: string;
    previewId?: string | null;
    previewName?: string | null;
    migrationTag?: string | null;
    /** Pinned deployment URLs for this exact deploy. */
    urls?: PreviewUrlsList | null;
    compatibilityDate?: string | null;
    createdOn?: string | null;
}
export declare const PreviewDeploymentResource: S.Schema<PreviewDeploymentResource>;
export interface CreateRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string;
}
export declare const CreateRouteRequest: S.Schema<CreateRouteRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRouteResponse {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export declare const CreateRouteResponse: S.Schema<CreateRouteResponse>;
export interface ScriptsAssetsUploadCreateRequestManifestValue {
    /** The hash of the file. */
    hash: string;
    /** The size of the file in bytes. */
    size: number;
}
export declare const ScriptsAssetsUploadCreateRequestManifestValue: S.Schema<ScriptsAssetsUploadCreateRequestManifestValue>;
export type ScriptsAssetsUploadCreateRequestManifestMap = {
    [key: string]: ScriptsAssetsUploadCreateRequestManifestValue | undefined;
};
export declare const ScriptsAssetsUploadCreateRequestManifestMap: S.Schema<ScriptsAssetsUploadCreateRequestManifestMap>;
export interface CreateScriptAssetUploadRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A manifest ([path]: {hash, size}) map of files to upload. As an example, `/blog/hello-world.html` would be a valid path key. */
    manifest: ScriptsAssetsUploadCreateRequestManifestMap;
}
export declare const CreateScriptAssetUploadRequest: S.Schema<CreateScriptAssetUploadRequest>;
export type ScriptsAssetsUploadCreateResponseBucketsItemList = Array<string>;
export declare const ScriptsAssetsUploadCreateResponseBucketsItemList: S.Schema<ScriptsAssetsUploadCreateResponseBucketsItemList>;
export type ScriptsAssetsUploadCreateResponseBucketsList = Array<ScriptsAssetsUploadCreateResponseBucketsItemList>;
export declare const ScriptsAssetsUploadCreateResponseBucketsList: S.Schema<ScriptsAssetsUploadCreateResponseBucketsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptAssetUploadResponse {
    /** The requests to make to upload assets. */
    buckets?: ScriptsAssetsUploadCreateResponseBucketsList | null;
    /** A JWT to use as authentication for uploading assets. */
    jwt?: string | null;
}
export declare const CreateScriptAssetUploadResponse: S.Schema<CreateScriptAssetUploadResponse>;
export type ScriptsDeploymentsCreateRequestStrategy = "percentage";
export declare const ScriptsDeploymentsCreateRequestStrategy: any;
export interface ScriptsDeploymentsCreateRequestVersionsItem {
    percentage: number;
    versionId: string;
}
export declare const ScriptsDeploymentsCreateRequestVersionsItem: S.Schema<ScriptsDeploymentsCreateRequestVersionsItem>;
export type ScriptsDeploymentsCreateRequestVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export declare const ScriptsDeploymentsCreateRequestVersionsList: S.Schema<ScriptsDeploymentsCreateRequestVersionsList>;
export interface ScriptsDeploymentsCreateRequestAnnotations {
    /** Human-readable message about the deployment. Truncated to 1000 bytes if longer. */
    workersMessage?: string;
    /** Operation that triggered the creation of the deployment. */
    workersTriggeredBy?: string;
}
export declare const ScriptsDeploymentsCreateRequestAnnotations: S.Schema<ScriptsDeploymentsCreateRequestAnnotations>;
export interface CreateScriptDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** If set to true, the deployment will be created even if normally blocked by something such rolling back to an older version when a secret has changed. */
    force?: boolean;
    strategy: ScriptsDeploymentsCreateRequestStrategy | (string & {});
    versions: ScriptsDeploymentsCreateRequestVersionsList;
    annotations?: ScriptsDeploymentsCreateRequestAnnotations;
}
export declare const CreateScriptDeploymentRequest: S.Schema<CreateScriptDeploymentRequest>;
export type ScriptsDeploymentsCreateResponseStrategy = "percentage";
export declare const ScriptsDeploymentsCreateResponseStrategy: any;
export type ScriptsDeploymentsCreateResponseVersionsItem = ScriptsDeploymentsCreateRequestVersionsItem;
export declare const ScriptsDeploymentsCreateResponseVersionsItem: S.Schema<ScriptsDeploymentsCreateRequestVersionsItem>;
export type ScriptsDeploymentsCreateResponseVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export declare const ScriptsDeploymentsCreateResponseVersionsList: S.Schema<ScriptsDeploymentsCreateResponseVersionsList>;
export interface ScriptsDeploymentsCreateResponseAnnotations {
    /** Human-readable message about the deployment. Truncated to 1000 bytes if longer. */
    workersMessage?: string | null;
    /** Operation that triggered the creation of the deployment. */
    workersTriggeredBy?: string | null;
}
export declare const ScriptsDeploymentsCreateResponseAnnotations: S.Schema<ScriptsDeploymentsCreateResponseAnnotations>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptDeploymentResponse {
    id: string;
    createdOn: string;
    source: string;
    strategy: ScriptsDeploymentsCreateResponseStrategy;
    versions: ScriptsDeploymentsCreateResponseVersionsList;
    annotations?: ScriptsDeploymentsCreateResponseAnnotations | null;
    authorEmail?: string | null;
}
export declare const CreateScriptDeploymentResponse: S.Schema<CreateScriptDeploymentResponse>;
export interface CreateScriptEdgePreviewWranglerSessionConfigWorkersDev {
    /** Route the preview through workers.dev. */
    workersDev: boolean;
    minimalMode?: boolean;
}
export declare const CreateScriptEdgePreviewWranglerSessionConfigWorkersDev: S.Schema<CreateScriptEdgePreviewWranglerSessionConfigWorkersDev>;
export type CreateScriptEdgePreviewWranglerSessionConfigRoutesList = Array<string>;
export declare const CreateScriptEdgePreviewWranglerSessionConfigRoutesList: S.Schema<CreateScriptEdgePreviewWranglerSessionConfigRoutesList>;
export interface CreateScriptEdgePreviewWranglerSessionConfigRoutes {
    /** Routes to serve the preview on. */
    routes: CreateScriptEdgePreviewWranglerSessionConfigRoutesList;
    minimalMode?: boolean;
}
export declare const CreateScriptEdgePreviewWranglerSessionConfigRoutes: S.Schema<CreateScriptEdgePreviewWranglerSessionConfigRoutes>;
export type CreateScriptEdgePreviewWranglerSessionConfig = CreateScriptEdgePreviewWranglerSessionConfigWorkersDev | CreateScriptEdgePreviewWranglerSessionConfigRoutes;
export declare const CreateScriptEdgePreviewWranglerSessionConfig: any;
export type CreateScriptEdgePreviewMetadataStringList = Array<string>;
export declare const CreateScriptEdgePreviewMetadataStringList: S.Schema<CreateScriptEdgePreviewMetadataStringList>;
export type CreateScriptEdgePreviewMetadataUsageModel = "bundled" | "unbound" | "standard";
export declare const CreateScriptEdgePreviewMetadataUsageModel: any;
export type CreateScriptEdgePreviewMetadataBindingPlainTextType = "plain_text";
export declare const CreateScriptEdgePreviewMetadataBindingPlainTextType: any;
export interface CreateScriptEdgePreviewMetadataBindingPlainText {
    type: CreateScriptEdgePreviewMetadataBindingPlainTextType;
    name: string;
    text: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingPlainText: S.Schema<CreateScriptEdgePreviewMetadataBindingPlainText>;
export type CreateScriptEdgePreviewMetadataBindingSecretTextType = "secret_text";
export declare const CreateScriptEdgePreviewMetadataBindingSecretTextType: any;
export interface CreateScriptEdgePreviewMetadataBindingSecretText {
    type: CreateScriptEdgePreviewMetadataBindingSecretTextType;
    name: string;
    text: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingSecretText: S.Schema<CreateScriptEdgePreviewMetadataBindingSecretText>;
export type CreateScriptEdgePreviewMetadataBindingJsonType = "json";
export declare const CreateScriptEdgePreviewMetadataBindingJsonType: any;
export interface CreateScriptEdgePreviewMetadataBindingJson {
    type: CreateScriptEdgePreviewMetadataBindingJsonType;
    name: string;
    json: unknown;
}
export declare const CreateScriptEdgePreviewMetadataBindingJson: S.Schema<CreateScriptEdgePreviewMetadataBindingJson>;
export type CreateScriptEdgePreviewMetadataBindingKvNamespaceType = "kv_namespace";
export declare const CreateScriptEdgePreviewMetadataBindingKvNamespaceType: any;
export interface CreateScriptEdgePreviewMetadataBindingKvNamespace {
    type: CreateScriptEdgePreviewMetadataBindingKvNamespaceType;
    name: string;
    namespaceId: string;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingKvNamespace: S.Schema<CreateScriptEdgePreviewMetadataBindingKvNamespace>;
export type CreateScriptEdgePreviewMetadataBindingDurableObjectNamespaceType = "durable_object_namespace";
export declare const CreateScriptEdgePreviewMetadataBindingDurableObjectNamespaceType: any;
export interface CreateScriptEdgePreviewMetadataBindingDurableObjectNamespace {
    type: CreateScriptEdgePreviewMetadataBindingDurableObjectNamespaceType;
    name: string;
    className: string;
    scriptName?: string;
    environment?: string;
    namespaceId?: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingDurableObjectNamespace: S.Schema<CreateScriptEdgePreviewMetadataBindingDurableObjectNamespace>;
export type CreateScriptEdgePreviewMetadataBindingR2BucketType = "r2_bucket";
export declare const CreateScriptEdgePreviewMetadataBindingR2BucketType: any;
export interface CreateScriptEdgePreviewMetadataBindingR2Bucket {
    type: CreateScriptEdgePreviewMetadataBindingR2BucketType;
    name: string;
    bucketName: string;
    jurisdiction?: string;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingR2Bucket: S.Schema<CreateScriptEdgePreviewMetadataBindingR2Bucket>;
export type CreateScriptEdgePreviewMetadataBindingD1Type = "d1";
export declare const CreateScriptEdgePreviewMetadataBindingD1Type: any;
export interface CreateScriptEdgePreviewMetadataBindingD1 {
    type: CreateScriptEdgePreviewMetadataBindingD1Type;
    name: string;
    id: string;
    internalEnv?: string;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingD1: S.Schema<CreateScriptEdgePreviewMetadataBindingD1>;
export type CreateScriptEdgePreviewMetadataBindingQueueType = "queue";
export declare const CreateScriptEdgePreviewMetadataBindingQueueType: any;
export interface CreateScriptEdgePreviewMetadataBindingQueue {
    type: CreateScriptEdgePreviewMetadataBindingQueueType;
    name: string;
    queueName: string;
    deliveryDelay?: number;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingQueue: S.Schema<CreateScriptEdgePreviewMetadataBindingQueue>;
export type CreateScriptEdgePreviewMetadataBindingServiceType = "service";
export declare const CreateScriptEdgePreviewMetadataBindingServiceType: any;
export interface CreateScriptEdgePreviewMetadataBindingService {
    type: CreateScriptEdgePreviewMetadataBindingServiceType;
    name: string;
    service: string;
    environment?: string;
    entrypoint?: string;
    crossAccountGrant?: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingService: S.Schema<CreateScriptEdgePreviewMetadataBindingService>;
export type CreateScriptEdgePreviewMetadataBindingAiType = "ai";
export declare const CreateScriptEdgePreviewMetadataBindingAiType: any;
export interface CreateScriptEdgePreviewMetadataBindingAi {
    type: CreateScriptEdgePreviewMetadataBindingAiType;
    name: string;
    staging?: boolean;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingAi: S.Schema<CreateScriptEdgePreviewMetadataBindingAi>;
export type CreateScriptEdgePreviewMetadataBindingBrowserType = "browser";
export declare const CreateScriptEdgePreviewMetadataBindingBrowserType: any;
export interface CreateScriptEdgePreviewMetadataBindingBrowser {
    type: CreateScriptEdgePreviewMetadataBindingBrowserType;
    name: string;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingBrowser: S.Schema<CreateScriptEdgePreviewMetadataBindingBrowser>;
export type CreateScriptEdgePreviewMetadataBindingImagesType = "images";
export declare const CreateScriptEdgePreviewMetadataBindingImagesType: any;
export interface CreateScriptEdgePreviewMetadataBindingImages {
    type: CreateScriptEdgePreviewMetadataBindingImagesType;
    name: string;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingImages: S.Schema<CreateScriptEdgePreviewMetadataBindingImages>;
export type CreateScriptEdgePreviewMetadataBindingVectorizeType = "vectorize";
export declare const CreateScriptEdgePreviewMetadataBindingVectorizeType: any;
export interface CreateScriptEdgePreviewMetadataBindingVectorize {
    type: CreateScriptEdgePreviewMetadataBindingVectorizeType;
    name: string;
    indexName: string;
    internalEnv?: string;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingVectorize: S.Schema<CreateScriptEdgePreviewMetadataBindingVectorize>;
export type CreateScriptEdgePreviewMetadataBindingWorkflowType = "workflow";
export declare const CreateScriptEdgePreviewMetadataBindingWorkflowType: any;
export interface CreateScriptEdgePreviewMetadataBindingWorkflow {
    type: CreateScriptEdgePreviewMetadataBindingWorkflowType;
    name: string;
    workflowName: string;
    className: string;
    scriptName?: string;
    raw?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingWorkflow: S.Schema<CreateScriptEdgePreviewMetadataBindingWorkflow>;
export type CreateScriptEdgePreviewMetadataBindingHyperdriveType = "hyperdrive";
export declare const CreateScriptEdgePreviewMetadataBindingHyperdriveType: any;
export interface CreateScriptEdgePreviewMetadataBindingHyperdrive {
    type: CreateScriptEdgePreviewMetadataBindingHyperdriveType;
    name: string;
    id: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingHyperdrive: S.Schema<CreateScriptEdgePreviewMetadataBindingHyperdrive>;
export type CreateScriptEdgePreviewMetadataBindingAnalyticsEngineType = "analytics_engine";
export declare const CreateScriptEdgePreviewMetadataBindingAnalyticsEngineType: any;
export interface CreateScriptEdgePreviewMetadataBindingAnalyticsEngine {
    type: CreateScriptEdgePreviewMetadataBindingAnalyticsEngineType;
    name: string;
    dataset?: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingAnalyticsEngine: S.Schema<CreateScriptEdgePreviewMetadataBindingAnalyticsEngine>;
export type CreateScriptEdgePreviewMetadataBindingDispatchNamespaceType = "dispatch_namespace";
export declare const CreateScriptEdgePreviewMetadataBindingDispatchNamespaceType: any;
export interface CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundWorker {
    service?: string;
    environment?: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundWorker: S.Schema<CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundWorker>;
export type CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParam = PreviewTailConsumer;
export declare const CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParam: S.Schema<PreviewTailConsumer>;
export type CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParamsList = Array<PreviewTailConsumer>;
export declare const CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParamsList: S.Schema<CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParamsList>;
export interface CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutbound {
    worker?: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundWorker;
    params?: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutboundParamsList;
}
export declare const CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutbound: S.Schema<CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutbound>;
export interface CreateScriptEdgePreviewMetadataBindingDispatchNamespace {
    type: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceType;
    name: string;
    namespace: string;
    outbound?: CreateScriptEdgePreviewMetadataBindingDispatchNamespaceOutbound;
}
export declare const CreateScriptEdgePreviewMetadataBindingDispatchNamespace: S.Schema<CreateScriptEdgePreviewMetadataBindingDispatchNamespace>;
export type CreateScriptEdgePreviewMetadataBindingSendEmailType = "send_email";
export declare const CreateScriptEdgePreviewMetadataBindingSendEmailType: any;
export interface CreateScriptEdgePreviewMetadataBindingSendEmail {
    type: CreateScriptEdgePreviewMetadataBindingSendEmailType;
    name: string;
    destinationAddress?: string;
    allowedDestinationAddresses?: CreateScriptEdgePreviewMetadataStringList;
    allowedSenderAddresses?: CreateScriptEdgePreviewMetadataStringList;
}
export declare const CreateScriptEdgePreviewMetadataBindingSendEmail: S.Schema<CreateScriptEdgePreviewMetadataBindingSendEmail>;
export type CreateScriptEdgePreviewMetadataBindingMtlsCertificateType = "mtls_certificate";
export declare const CreateScriptEdgePreviewMetadataBindingMtlsCertificateType: any;
export interface CreateScriptEdgePreviewMetadataBindingMtlsCertificate {
    type: CreateScriptEdgePreviewMetadataBindingMtlsCertificateType;
    name: string;
    certificateId: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingMtlsCertificate: S.Schema<CreateScriptEdgePreviewMetadataBindingMtlsCertificate>;
export type CreateScriptEdgePreviewMetadataBindingWasmModuleType = "wasm_module";
export declare const CreateScriptEdgePreviewMetadataBindingWasmModuleType: any;
export interface CreateScriptEdgePreviewMetadataBindingWasmModule {
    type: CreateScriptEdgePreviewMetadataBindingWasmModuleType;
    name: string;
    part: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingWasmModule: S.Schema<CreateScriptEdgePreviewMetadataBindingWasmModule>;
export type CreateScriptEdgePreviewMetadataBindingTextBlobType = "text_blob";
export declare const CreateScriptEdgePreviewMetadataBindingTextBlobType: any;
export interface CreateScriptEdgePreviewMetadataBindingTextBlob {
    type: CreateScriptEdgePreviewMetadataBindingTextBlobType;
    name: string;
    part: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingTextBlob: S.Schema<CreateScriptEdgePreviewMetadataBindingTextBlob>;
export type CreateScriptEdgePreviewMetadataBindingDataBlobType = "data_blob";
export declare const CreateScriptEdgePreviewMetadataBindingDataBlobType: any;
export interface CreateScriptEdgePreviewMetadataBindingDataBlob {
    type: CreateScriptEdgePreviewMetadataBindingDataBlobType;
    name: string;
    part: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingDataBlob: S.Schema<CreateScriptEdgePreviewMetadataBindingDataBlob>;
export type CreateScriptEdgePreviewMetadataBindingPipelinesType = "pipelines";
export declare const CreateScriptEdgePreviewMetadataBindingPipelinesType: any;
export interface CreateScriptEdgePreviewMetadataBindingPipelines {
    type: CreateScriptEdgePreviewMetadataBindingPipelinesType;
    name: string;
    pipeline: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingPipelines: S.Schema<CreateScriptEdgePreviewMetadataBindingPipelines>;
export type CreateScriptEdgePreviewMetadataBindingSecretsStoreSecretType = "secrets_store_secret";
export declare const CreateScriptEdgePreviewMetadataBindingSecretsStoreSecretType: any;
export interface CreateScriptEdgePreviewMetadataBindingSecretsStoreSecret {
    type: CreateScriptEdgePreviewMetadataBindingSecretsStoreSecretType;
    name: string;
    storeId: string;
    secretName: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingSecretsStoreSecret: S.Schema<CreateScriptEdgePreviewMetadataBindingSecretsStoreSecret>;
export type CreateScriptEdgePreviewMetadataBindingStreamType = "stream";
export declare const CreateScriptEdgePreviewMetadataBindingStreamType: any;
export interface CreateScriptEdgePreviewMetadataBindingStream {
    type: CreateScriptEdgePreviewMetadataBindingStreamType;
    name: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingStream: S.Schema<CreateScriptEdgePreviewMetadataBindingStream>;
export type CreateScriptEdgePreviewMetadataBindingMediaType = "media";
export declare const CreateScriptEdgePreviewMetadataBindingMediaType: any;
export interface CreateScriptEdgePreviewMetadataBindingMedia {
    type: CreateScriptEdgePreviewMetadataBindingMediaType;
    name: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingMedia: S.Schema<CreateScriptEdgePreviewMetadataBindingMedia>;
export type CreateScriptEdgePreviewMetadataBindingVersionMetadataType = "version_metadata";
export declare const CreateScriptEdgePreviewMetadataBindingVersionMetadataType: any;
export interface CreateScriptEdgePreviewMetadataBindingVersionMetadata {
    type: CreateScriptEdgePreviewMetadataBindingVersionMetadataType;
    name: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingVersionMetadata: S.Schema<CreateScriptEdgePreviewMetadataBindingVersionMetadata>;
export type CreateScriptEdgePreviewMetadataBindingAssetsType = "assets";
export declare const CreateScriptEdgePreviewMetadataBindingAssetsType: any;
export interface CreateScriptEdgePreviewMetadataBindingAssets {
    type: CreateScriptEdgePreviewMetadataBindingAssetsType;
    name: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingAssets: S.Schema<CreateScriptEdgePreviewMetadataBindingAssets>;
export type CreateScriptEdgePreviewMetadataBindingWorkerLoaderType = "worker_loader";
export declare const CreateScriptEdgePreviewMetadataBindingWorkerLoaderType: any;
export interface CreateScriptEdgePreviewMetadataBindingWorkerLoader {
    type: CreateScriptEdgePreviewMetadataBindingWorkerLoaderType;
    name: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingWorkerLoader: S.Schema<CreateScriptEdgePreviewMetadataBindingWorkerLoader>;
export type CreateScriptEdgePreviewMetadataBindingLogfwdrType = "logfwdr";
export declare const CreateScriptEdgePreviewMetadataBindingLogfwdrType: any;
export interface CreateScriptEdgePreviewMetadataBindingLogfwdr {
    type: CreateScriptEdgePreviewMetadataBindingLogfwdrType;
    name: string;
    destination: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingLogfwdr: S.Schema<CreateScriptEdgePreviewMetadataBindingLogfwdr>;
export type CreateScriptEdgePreviewMetadataBindingAiSearchNamespaceType = "ai_search_namespace";
export declare const CreateScriptEdgePreviewMetadataBindingAiSearchNamespaceType: any;
export interface CreateScriptEdgePreviewMetadataBindingAiSearchNamespace {
    type: CreateScriptEdgePreviewMetadataBindingAiSearchNamespaceType;
    name: string;
    namespace: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingAiSearchNamespace: S.Schema<CreateScriptEdgePreviewMetadataBindingAiSearchNamespace>;
export type CreateScriptEdgePreviewMetadataBindingAiSearchType = "ai_search";
export declare const CreateScriptEdgePreviewMetadataBindingAiSearchType: any;
export interface CreateScriptEdgePreviewMetadataBindingAiSearch {
    type: CreateScriptEdgePreviewMetadataBindingAiSearchType;
    name: string;
    instanceName: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingAiSearch: S.Schema<CreateScriptEdgePreviewMetadataBindingAiSearch>;
export type CreateScriptEdgePreviewMetadataBindingRatelimitType = "ratelimit";
export declare const CreateScriptEdgePreviewMetadataBindingRatelimitType: any;
export type CreateScriptEdgePreviewMetadataBindingRatelimitPeriod = "10" | "60";
export declare const CreateScriptEdgePreviewMetadataBindingRatelimitPeriod: any;
export interface CreateScriptEdgePreviewMetadataBindingRatelimitSimple {
    limit: number;
    period: CreateScriptEdgePreviewMetadataBindingRatelimitPeriod | (string & {});
}
export declare const CreateScriptEdgePreviewMetadataBindingRatelimitSimple: S.Schema<CreateScriptEdgePreviewMetadataBindingRatelimitSimple>;
export interface CreateScriptEdgePreviewMetadataBindingRatelimit {
    type: CreateScriptEdgePreviewMetadataBindingRatelimitType;
    name: string;
    namespaceId: string;
    simple: CreateScriptEdgePreviewMetadataBindingRatelimitSimple;
}
export declare const CreateScriptEdgePreviewMetadataBindingRatelimit: S.Schema<CreateScriptEdgePreviewMetadataBindingRatelimit>;
export type CreateScriptEdgePreviewMetadataBindingArtifactsType = "artifacts";
export declare const CreateScriptEdgePreviewMetadataBindingArtifactsType: any;
export interface CreateScriptEdgePreviewMetadataBindingArtifacts {
    type: CreateScriptEdgePreviewMetadataBindingArtifactsType;
    name: string;
    namespace: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingArtifacts: S.Schema<CreateScriptEdgePreviewMetadataBindingArtifacts>;
export type CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorldType = "unsafe_hello_world";
export declare const CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorldType: any;
export interface CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorld {
    type: CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorldType;
    name: string;
    enableTimer?: boolean;
}
export declare const CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorld: S.Schema<CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorld>;
export type CreateScriptEdgePreviewMetadataBindingFlagshipType = "flagship";
export declare const CreateScriptEdgePreviewMetadataBindingFlagshipType: any;
export interface CreateScriptEdgePreviewMetadataBindingFlagship {
    type: CreateScriptEdgePreviewMetadataBindingFlagshipType;
    name: string;
    appId: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingFlagship: S.Schema<CreateScriptEdgePreviewMetadataBindingFlagship>;
export type CreateScriptEdgePreviewMetadataBindingVpcServiceType = "vpc_service";
export declare const CreateScriptEdgePreviewMetadataBindingVpcServiceType: any;
export interface CreateScriptEdgePreviewMetadataBindingVpcService {
    type: CreateScriptEdgePreviewMetadataBindingVpcServiceType;
    name: string;
    serviceId: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingVpcService: S.Schema<CreateScriptEdgePreviewMetadataBindingVpcService>;
export type CreateScriptEdgePreviewMetadataBindingVpcNetworkType = "vpc_network";
export declare const CreateScriptEdgePreviewMetadataBindingVpcNetworkType: any;
export interface CreateScriptEdgePreviewMetadataBindingVpcNetwork {
    type: CreateScriptEdgePreviewMetadataBindingVpcNetworkType;
    name: string;
    tunnelId?: string;
    networkId?: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingVpcNetwork: S.Schema<CreateScriptEdgePreviewMetadataBindingVpcNetwork>;
export type CreateScriptEdgePreviewMetadataBindingInheritType = "inherit";
export declare const CreateScriptEdgePreviewMetadataBindingInheritType: any;
export interface CreateScriptEdgePreviewMetadataBindingInherit {
    type: CreateScriptEdgePreviewMetadataBindingInheritType;
    name: string;
}
export declare const CreateScriptEdgePreviewMetadataBindingInherit: S.Schema<CreateScriptEdgePreviewMetadataBindingInherit>;
export type CreateScriptEdgePreviewMetadataBinding = CreateScriptEdgePreviewMetadataBindingPlainText | CreateScriptEdgePreviewMetadataBindingSecretText | CreateScriptEdgePreviewMetadataBindingJson | CreateScriptEdgePreviewMetadataBindingKvNamespace | CreateScriptEdgePreviewMetadataBindingDurableObjectNamespace | CreateScriptEdgePreviewMetadataBindingR2Bucket | CreateScriptEdgePreviewMetadataBindingD1 | CreateScriptEdgePreviewMetadataBindingQueue | CreateScriptEdgePreviewMetadataBindingService | CreateScriptEdgePreviewMetadataBindingAi | CreateScriptEdgePreviewMetadataBindingBrowser | CreateScriptEdgePreviewMetadataBindingImages | CreateScriptEdgePreviewMetadataBindingVectorize | CreateScriptEdgePreviewMetadataBindingWorkflow | CreateScriptEdgePreviewMetadataBindingHyperdrive | CreateScriptEdgePreviewMetadataBindingAnalyticsEngine | CreateScriptEdgePreviewMetadataBindingDispatchNamespace | CreateScriptEdgePreviewMetadataBindingSendEmail | CreateScriptEdgePreviewMetadataBindingMtlsCertificate | CreateScriptEdgePreviewMetadataBindingWasmModule | CreateScriptEdgePreviewMetadataBindingTextBlob | CreateScriptEdgePreviewMetadataBindingDataBlob | CreateScriptEdgePreviewMetadataBindingPipelines | CreateScriptEdgePreviewMetadataBindingSecretsStoreSecret | CreateScriptEdgePreviewMetadataBindingStream | CreateScriptEdgePreviewMetadataBindingMedia | CreateScriptEdgePreviewMetadataBindingVersionMetadata | CreateScriptEdgePreviewMetadataBindingAssets | CreateScriptEdgePreviewMetadataBindingWorkerLoader | CreateScriptEdgePreviewMetadataBindingLogfwdr | CreateScriptEdgePreviewMetadataBindingAiSearchNamespace | CreateScriptEdgePreviewMetadataBindingAiSearch | CreateScriptEdgePreviewMetadataBindingRatelimit | CreateScriptEdgePreviewMetadataBindingArtifacts | CreateScriptEdgePreviewMetadataBindingUnsafeHelloWorld | CreateScriptEdgePreviewMetadataBindingFlagship | CreateScriptEdgePreviewMetadataBindingVpcService | CreateScriptEdgePreviewMetadataBindingVpcNetwork | CreateScriptEdgePreviewMetadataBindingInherit;
export declare const CreateScriptEdgePreviewMetadataBinding: any;
export type CreateScriptEdgePreviewMetadataBindingsList = Array<CreateScriptEdgePreviewMetadataBinding>;
export declare const CreateScriptEdgePreviewMetadataBindingsList: S.Schema<CreateScriptEdgePreviewMetadataBindingsList>;
export type CreateScriptEdgePreviewMetadataMigrationRenamedClass = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem;
export declare const CreateScriptEdgePreviewMetadataMigrationRenamedClass: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export type CreateScriptEdgePreviewMetadataMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const CreateScriptEdgePreviewMetadataMigrationRenamedClassesList: S.Schema<CreateScriptEdgePreviewMetadataMigrationRenamedClassesList>;
export interface CreateScriptEdgePreviewMetadataMigrationStep {
    newClasses?: CreateScriptEdgePreviewMetadataStringList;
    newSqliteClasses?: CreateScriptEdgePreviewMetadataStringList;
    renamedClasses?: CreateScriptEdgePreviewMetadataMigrationRenamedClassesList;
    deletedClasses?: CreateScriptEdgePreviewMetadataStringList;
}
export declare const CreateScriptEdgePreviewMetadataMigrationStep: S.Schema<CreateScriptEdgePreviewMetadataMigrationStep>;
export type CreateScriptEdgePreviewMetadataMigrationStepsList = Array<CreateScriptEdgePreviewMetadataMigrationStep>;
export declare const CreateScriptEdgePreviewMetadataMigrationStepsList: S.Schema<CreateScriptEdgePreviewMetadataMigrationStepsList>;
export interface CreateScriptEdgePreviewMetadataMigrations {
    oldTag?: string;
    newTag?: string;
    steps?: CreateScriptEdgePreviewMetadataMigrationStepsList;
}
export declare const CreateScriptEdgePreviewMetadataMigrations: S.Schema<CreateScriptEdgePreviewMetadataMigrations>;
export type CreateScriptEdgePreviewMetadataPlacementSmartMode = "smart";
export declare const CreateScriptEdgePreviewMetadataPlacementSmartMode: any;
export interface CreateScriptEdgePreviewMetadataPlacementSmart {
    mode: CreateScriptEdgePreviewMetadataPlacementSmartMode;
    hint?: string;
}
export declare const CreateScriptEdgePreviewMetadataPlacementSmart: S.Schema<CreateScriptEdgePreviewMetadataPlacementSmart>;
export interface CreateScriptEdgePreviewMetadataPlacementRegion {
    region: string;
}
export declare const CreateScriptEdgePreviewMetadataPlacementRegion: S.Schema<CreateScriptEdgePreviewMetadataPlacementRegion>;
export interface CreateScriptEdgePreviewMetadataPlacementHost {
    host: string;
}
export declare const CreateScriptEdgePreviewMetadataPlacementHost: S.Schema<CreateScriptEdgePreviewMetadataPlacementHost>;
export interface CreateScriptEdgePreviewMetadataPlacementHostname {
    hostname: string;
}
export declare const CreateScriptEdgePreviewMetadataPlacementHostname: S.Schema<CreateScriptEdgePreviewMetadataPlacementHostname>;
export type CreateScriptEdgePreviewMetadataPlacement = CreateScriptEdgePreviewMetadataPlacementSmart | CreateScriptEdgePreviewMetadataPlacementRegion | CreateScriptEdgePreviewMetadataPlacementHost | CreateScriptEdgePreviewMetadataPlacementHostname;
export declare const CreateScriptEdgePreviewMetadataPlacement: any;
export interface CreateScriptEdgePreviewMetadataTailConsumer {
    service: string;
    environment?: string;
}
export declare const CreateScriptEdgePreviewMetadataTailConsumer: S.Schema<CreateScriptEdgePreviewMetadataTailConsumer>;
export type CreateScriptEdgePreviewMetadataTailConsumersList = Array<CreateScriptEdgePreviewMetadataTailConsumer>;
export declare const CreateScriptEdgePreviewMetadataTailConsumersList: S.Schema<CreateScriptEdgePreviewMetadataTailConsumersList>;
export interface CreateScriptEdgePreviewMetadataLimits {
    cpuMs?: number;
    subrequests?: number;
}
export declare const CreateScriptEdgePreviewMetadataLimits: S.Schema<CreateScriptEdgePreviewMetadataLimits>;
export type CreateScriptEdgePreviewMetadataAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export declare const CreateScriptEdgePreviewMetadataAssetsConfigHtmlHandling: any;
export type CreateScriptEdgePreviewMetadataAssetsConfigNotFoundHandling = "single-page-application" | "404-page" | "none";
export declare const CreateScriptEdgePreviewMetadataAssetsConfigNotFoundHandling: any;
export type CreateScriptEdgePreviewMetadataAssetsConfigRunWorkerFirst = boolean | CreateScriptEdgePreviewMetadataStringList;
export declare const CreateScriptEdgePreviewMetadataAssetsConfigRunWorkerFirst: any;
export interface CreateScriptEdgePreviewMetadataAssetsConfig {
    htmlHandling?: CreateScriptEdgePreviewMetadataAssetsConfigHtmlHandling | (string & {});
    notFoundHandling?: CreateScriptEdgePreviewMetadataAssetsConfigNotFoundHandling | (string & {});
    runWorkerFirst?: CreateScriptEdgePreviewMetadataAssetsConfigRunWorkerFirst;
    redirects?: string;
    headers?: string;
}
export declare const CreateScriptEdgePreviewMetadataAssetsConfig: S.Schema<CreateScriptEdgePreviewMetadataAssetsConfig>;
export interface CreateScriptEdgePreviewMetadataAssets {
    jwt?: string;
    config?: CreateScriptEdgePreviewMetadataAssetsConfig;
}
export declare const CreateScriptEdgePreviewMetadataAssets: S.Schema<CreateScriptEdgePreviewMetadataAssets>;
export interface CreateScriptEdgePreviewMetadataObservabilityLogs {
    enabled?: boolean;
    headSamplingRate?: number;
    invocationLogs?: boolean;
    persist?: boolean;
    destinations?: CreateScriptEdgePreviewMetadataStringList;
}
export declare const CreateScriptEdgePreviewMetadataObservabilityLogs: S.Schema<CreateScriptEdgePreviewMetadataObservabilityLogs>;
export interface CreateScriptEdgePreviewMetadataObservabilityTraces {
    enabled?: boolean;
    headSamplingRate?: number;
    persist?: boolean;
    destinations?: CreateScriptEdgePreviewMetadataStringList;
}
export declare const CreateScriptEdgePreviewMetadataObservabilityTraces: S.Schema<CreateScriptEdgePreviewMetadataObservabilityTraces>;
export interface CreateScriptEdgePreviewMetadataObservability {
    enabled?: boolean;
    headSamplingRate?: number;
    logs?: CreateScriptEdgePreviewMetadataObservabilityLogs;
    traces?: CreateScriptEdgePreviewMetadataObservabilityTraces;
}
export declare const CreateScriptEdgePreviewMetadataObservability: S.Schema<CreateScriptEdgePreviewMetadataObservability>;
export type CreateScriptEdgePreviewMetadataContainer = CreatePreviewDeploymentMetadataContainer;
export declare const CreateScriptEdgePreviewMetadataContainer: S.Schema<CreatePreviewDeploymentMetadataContainer>;
export type CreateScriptEdgePreviewMetadataContainersList = Array<CreatePreviewDeploymentMetadataContainer>;
export declare const CreateScriptEdgePreviewMetadataContainersList: S.Schema<CreateScriptEdgePreviewMetadataContainersList>;
export interface CreateScriptEdgePreviewMetadata {
    mainModule?: string;
    bodyPart?: string;
    compatibilityDate?: string;
    compatibilityFlags?: CreateScriptEdgePreviewMetadataStringList;
    usageModel?: CreateScriptEdgePreviewMetadataUsageModel | (string & {});
    bindings?: CreateScriptEdgePreviewMetadataBindingsList;
    keepBindings?: CreateScriptEdgePreviewMetadataStringList;
    migrations?: CreateScriptEdgePreviewMetadataMigrations;
    capnpSchema?: string;
    logpush?: boolean;
    placement?: CreateScriptEdgePreviewMetadataPlacement;
    tailConsumers?: CreateScriptEdgePreviewMetadataTailConsumersList;
    streamingTailConsumers?: CreateScriptEdgePreviewMetadataTailConsumersList;
    limits?: CreateScriptEdgePreviewMetadataLimits;
    assets?: CreateScriptEdgePreviewMetadataAssets;
    observability?: CreateScriptEdgePreviewMetadataObservability;
    containers?: CreateScriptEdgePreviewMetadataContainersList;
    annotations?: unknown;
    keepAssets?: boolean;
    tags?: CreateScriptEdgePreviewMetadataStringList;
}
export declare const CreateScriptEdgePreviewMetadata: S.Schema<CreateScriptEdgePreviewMetadata>;
export interface CreateScriptEdgePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** The session token returned by createSubdomainEdgePreviewSession. */
    cfPreviewUploadConfigToken: string;
    /** Module files comprising the worker script, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
    /** JSON-encoded multipart part selecting how the preview is routed (workers.dev or explicit routes); without it edge previews cannot opt into workers.dev routing. */
    wranglerSessionConfig?: CreateScriptEdgePreviewWranglerSessionConfig;
    /** JSON-encoded multipart `metadata` part: the preview worker's modules, bindings and settings. */
    metadata?: CreateScriptEdgePreviewMetadata;
}
export declare const CreateScriptEdgePreviewRequest: S.Schema<CreateScriptEdgePreviewRequest>;
export interface CreateScriptEdgePreviewResponse {
    /** Token to send as cf-workers-preview-token header when making requests to the preview host. */
    previewToken: string;
    /** URL for tailing live logs from the preview worker. */
    tailUrl?: string | null;
}
export declare const CreateScriptEdgePreviewResponse: S.Schema<CreateScriptEdgePreviewResponse>;
export interface CreateScriptSubdomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Whether the Worker should be available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs should be available on the workers.dev subdomain. */
    previewsEnabled?: boolean;
}
export declare const CreateScriptSubdomainRequest: S.Schema<CreateScriptSubdomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptSubdomainResponse {
    /** Whether the Worker is available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs are available on the workers.dev subdomain. */
    previewsEnabled: boolean;
}
export declare const CreateScriptSubdomainResponse: S.Schema<CreateScriptSubdomainResponse>;
export type CreateScriptTailFiltersList = Array<unknown>;
export declare const CreateScriptTailFiltersList: S.Schema<CreateScriptTailFiltersList>;
export interface CreateScriptTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Tail event filters; an empty list tails everything. */
    filters?: CreateScriptTailFiltersList;
}
export declare const CreateScriptTailRequest: S.Schema<CreateScriptTailRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptTailResponse {
    /** Identifier. */
    id: string;
    expiresAt: string;
    url: string;
}
export declare const CreateScriptTailResponse: S.Schema<CreateScriptTailResponse>;
export type ScriptsVersionsCreateRequestBindingsInherit = "strict";
export declare const ScriptsVersionsCreateRequestBindingsInherit: any;
export interface PutScriptMetadataAnnotations {
    workersMessage?: string;
    workersTag?: string;
    /** Alias to point at this version (e.g. for gradual deployments). */
    workersAlias?: string;
}
export declare const PutScriptMetadataAnnotations: S.Schema<PutScriptMetadataAnnotations>;
export type PutScriptAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export declare const PutScriptAssetsConfigHtmlHandling: any;
export type PutScriptAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export declare const PutScriptAssetsConfigNotFoundHandling: any;
export type PutScriptMetadataStringList = Array<string>;
export declare const PutScriptMetadataStringList: S.Schema<PutScriptMetadataStringList>;
export type PutScriptAssetsConfigRunWorkerFirst = PutScriptMetadataStringList | boolean;
export declare const PutScriptAssetsConfigRunWorkerFirst: any;
export interface PutScriptAssetsConfig {
    htmlHandling?: PutScriptAssetsConfigHtmlHandling | (string & {});
    notFoundHandling?: PutScriptAssetsConfigNotFoundHandling | (string & {});
    runWorkerFirst?: PutScriptAssetsConfigRunWorkerFirst;
    serveDirectly?: boolean;
    headers?: string;
    redirects?: string;
}
export declare const PutScriptAssetsConfig: S.Schema<PutScriptAssetsConfig>;
export interface PutScriptMetadataAssets {
    config?: PutScriptAssetsConfig;
    jwt?: string;
}
export declare const PutScriptMetadataAssets: S.Schema<PutScriptMetadataAssets>;
export type PutScriptBindingAiType = "ai";
export declare const PutScriptBindingAiType: any;
export interface PutScriptBindingAi {
    name: string;
    type: PutScriptBindingAiType;
}
export declare const PutScriptBindingAi: S.Schema<PutScriptBindingAi>;
export type PutScriptBindingAiSearchType = "ai_search";
export declare const PutScriptBindingAiSearchType: any;
export interface PutScriptBindingAiSearch {
    instanceName: string;
    name: string;
    namespace?: string;
    type: PutScriptBindingAiSearchType;
}
export declare const PutScriptBindingAiSearch: S.Schema<PutScriptBindingAiSearch>;
export type PutScriptBindingAiSearchNamespaceType = "ai_search_namespace";
export declare const PutScriptBindingAiSearchNamespaceType: any;
export interface PutScriptBindingAiSearchNamespace {
    name: string;
    namespace: string;
    type: PutScriptBindingAiSearchNamespaceType;
}
export declare const PutScriptBindingAiSearchNamespace: S.Schema<PutScriptBindingAiSearchNamespace>;
export type PutScriptBindingAnalyticsEngineType = "analytics_engine";
export declare const PutScriptBindingAnalyticsEngineType: any;
export interface PutScriptBindingAnalyticsEngine {
    dataset: string;
    name: string;
    type: PutScriptBindingAnalyticsEngineType;
}
export declare const PutScriptBindingAnalyticsEngine: S.Schema<PutScriptBindingAnalyticsEngine>;
export type PutScriptBindingAssetsType = "assets";
export declare const PutScriptBindingAssetsType: any;
export interface PutScriptBindingAssets {
    name: string;
    type: PutScriptBindingAssetsType;
}
export declare const PutScriptBindingAssets: S.Schema<PutScriptBindingAssets>;
export type PutScriptBindingBrowserType = "browser";
export declare const PutScriptBindingBrowserType: any;
export interface PutScriptBindingBrowser {
    name: string;
    type: PutScriptBindingBrowserType;
}
export declare const PutScriptBindingBrowser: S.Schema<PutScriptBindingBrowser>;
export type PutScriptBindingD1Type = "d1";
export declare const PutScriptBindingD1Type: any;
export interface PutScriptBindingD1 {
    databaseId: string;
    name: string;
    id?: string;
    type: PutScriptBindingD1Type;
}
export declare const PutScriptBindingD1: S.Schema<PutScriptBindingD1>;
export type PutScriptBindingDataBlobType = "data_blob";
export declare const PutScriptBindingDataBlobType: any;
export interface PutScriptBindingDataBlob {
    name: string;
    part: string;
    type: PutScriptBindingDataBlobType;
}
export declare const PutScriptBindingDataBlob: S.Schema<PutScriptBindingDataBlob>;
export type PutScriptBindingDispatchNamespaceOutboundParam = PreviewTailConsumer;
export declare const PutScriptBindingDispatchNamespaceOutboundParam: S.Schema<PreviewTailConsumer>;
export type PutScriptBindingDispatchNamespaceOutboundParamsList = Array<PreviewTailConsumer>;
export declare const PutScriptBindingDispatchNamespaceOutboundParamsList: S.Schema<PutScriptBindingDispatchNamespaceOutboundParamsList>;
export interface PutScriptBindingDispatchNamespaceOutboundWorker {
    entrypoint?: string;
    environment?: string;
    service?: string;
}
export declare const PutScriptBindingDispatchNamespaceOutboundWorker: S.Schema<PutScriptBindingDispatchNamespaceOutboundWorker>;
export interface PutScriptBindingDispatchNamespaceOutbound {
    params?: PutScriptBindingDispatchNamespaceOutboundParamsList;
    worker?: PutScriptBindingDispatchNamespaceOutboundWorker;
}
export declare const PutScriptBindingDispatchNamespaceOutbound: S.Schema<PutScriptBindingDispatchNamespaceOutbound>;
export type PutScriptBindingDispatchNamespaceType = "dispatch_namespace";
export declare const PutScriptBindingDispatchNamespaceType: any;
export interface PutScriptBindingDispatchNamespace {
    name: string;
    namespace: string;
    outbound?: PutScriptBindingDispatchNamespaceOutbound;
    type: PutScriptBindingDispatchNamespaceType;
}
export declare const PutScriptBindingDispatchNamespace: S.Schema<PutScriptBindingDispatchNamespace>;
export type PutScriptBindingDurableObjectNamespaceType = "durable_object_namespace";
export declare const PutScriptBindingDurableObjectNamespaceType: any;
export interface PutScriptBindingDurableObjectNamespace {
    name: string;
    className: string;
    dispatchNamespace?: string;
    environment?: string;
    namespaceId?: string;
    scriptName?: string;
    type: PutScriptBindingDurableObjectNamespaceType;
}
export declare const PutScriptBindingDurableObjectNamespace: S.Schema<PutScriptBindingDurableObjectNamespace>;
export type PutScriptBindingHyperdriveType = "hyperdrive";
export declare const PutScriptBindingHyperdriveType: any;
export interface PutScriptBindingHyperdrive {
    id: string;
    name: string;
    type: PutScriptBindingHyperdriveType;
}
export declare const PutScriptBindingHyperdrive: S.Schema<PutScriptBindingHyperdrive>;
export type PutScriptBindingInheritType = "inherit";
export declare const PutScriptBindingInheritType: any;
export interface PutScriptBindingInherit {
    name: string;
    oldName?: string;
    versionId?: string;
    type: PutScriptBindingInheritType;
}
export declare const PutScriptBindingInherit: S.Schema<PutScriptBindingInherit>;
export type PutScriptBindingImagesType = "images";
export declare const PutScriptBindingImagesType: any;
export interface PutScriptBindingImages {
    name: string;
    type: PutScriptBindingImagesType;
}
export declare const PutScriptBindingImages: S.Schema<PutScriptBindingImages>;
export type PutScriptBindingJsonType = "json";
export declare const PutScriptBindingJsonType: any;
export interface PutScriptBindingJson {
    json: unknown;
    name: string;
    type: PutScriptBindingJsonType;
}
export declare const PutScriptBindingJson: S.Schema<PutScriptBindingJson>;
export type PutScriptBindingKvNamespaceType = "kv_namespace";
export declare const PutScriptBindingKvNamespaceType: any;
export interface PutScriptBindingKvNamespace {
    name: string;
    namespaceId: string;
    type: PutScriptBindingKvNamespaceType;
}
export declare const PutScriptBindingKvNamespace: S.Schema<PutScriptBindingKvNamespace>;
export type PutScriptBindingMediaType = "media";
export declare const PutScriptBindingMediaType: any;
export interface PutScriptBindingMedia {
    name: string;
    type: PutScriptBindingMediaType;
}
export declare const PutScriptBindingMedia: S.Schema<PutScriptBindingMedia>;
export type PutScriptBindingMtlsCertificateType = "mtls_certificate";
export declare const PutScriptBindingMtlsCertificateType: any;
export interface PutScriptBindingMtlsCertificate {
    certificateId: string;
    name: string;
    type: PutScriptBindingMtlsCertificateType;
}
export declare const PutScriptBindingMtlsCertificate: S.Schema<PutScriptBindingMtlsCertificate>;
export type PutScriptBindingPlainTextType = "plain_text";
export declare const PutScriptBindingPlainTextType: any;
export interface PutScriptBindingPlainText {
    name: string;
    text: string;
    type: PutScriptBindingPlainTextType;
}
export declare const PutScriptBindingPlainText: S.Schema<PutScriptBindingPlainText>;
export type PutScriptBindingPipelinesType = "pipelines";
export declare const PutScriptBindingPipelinesType: any;
export interface PutScriptBindingPipelines {
    name: string;
    pipeline: string;
    type: PutScriptBindingPipelinesType;
}
export declare const PutScriptBindingPipelines: S.Schema<PutScriptBindingPipelines>;
export type PutScriptBindingQueueType = "queue";
export declare const PutScriptBindingQueueType: any;
export interface PutScriptBindingQueue {
    name: string;
    queueName: string;
    type: PutScriptBindingQueueType;
}
export declare const PutScriptBindingQueue: S.Schema<PutScriptBindingQueue>;
export interface PutScriptBindingRatelimitSimple {
    limit: number;
    period: number;
    mitigationTimeout?: number;
}
export declare const PutScriptBindingRatelimitSimple: S.Schema<PutScriptBindingRatelimitSimple>;
export type PutScriptBindingRatelimitType = "ratelimit";
export declare const PutScriptBindingRatelimitType: any;
export interface PutScriptBindingRatelimit {
    name: string;
    namespaceId: string;
    simple: PutScriptBindingRatelimitSimple;
    type: PutScriptBindingRatelimitType;
}
export declare const PutScriptBindingRatelimit: S.Schema<PutScriptBindingRatelimit>;
export type PutScriptBindingR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const PutScriptBindingR2BucketJurisdiction: any;
export type PutScriptBindingR2BucketType = "r2_bucket";
export declare const PutScriptBindingR2BucketType: any;
export interface PutScriptBindingR2Bucket {
    bucketName: string;
    name: string;
    jurisdiction?: PutScriptBindingR2BucketJurisdiction | (string & {});
    type: PutScriptBindingR2BucketType;
}
export declare const PutScriptBindingR2Bucket: S.Schema<PutScriptBindingR2Bucket>;
export type PutScriptBindingSecretTextType = "secret_text";
export declare const PutScriptBindingSecretTextType: any;
export interface PutScriptBindingSecretText {
    name: string;
    text: string;
    type: PutScriptBindingSecretTextType;
}
export declare const PutScriptBindingSecretText: S.Schema<PutScriptBindingSecretText>;
export type PutScriptBindingSendEmailType = "send_email";
export declare const PutScriptBindingSendEmailType: any;
export interface PutScriptBindingSendEmail {
    name: string;
    allowedDestinationAddresses?: PutScriptMetadataStringList;
    allowedSenderAddresses?: PutScriptMetadataStringList;
    destinationAddress?: string;
    type: PutScriptBindingSendEmailType;
}
export declare const PutScriptBindingSendEmail: S.Schema<PutScriptBindingSendEmail>;
export type PutScriptBindingServiceType = "service";
export declare const PutScriptBindingServiceType: any;
export interface PutScriptBindingService {
    name: string;
    service: string;
    entrypoint?: string;
    environment?: string;
    type: PutScriptBindingServiceType;
}
export declare const PutScriptBindingService: S.Schema<PutScriptBindingService>;
export type PutScriptBindingTextBlobType = "text_blob";
export declare const PutScriptBindingTextBlobType: any;
export interface PutScriptBindingTextBlob {
    name: string;
    part: string;
    type: PutScriptBindingTextBlobType;
}
export declare const PutScriptBindingTextBlob: S.Schema<PutScriptBindingTextBlob>;
export type PutScriptBindingVectorizeType = "vectorize";
export declare const PutScriptBindingVectorizeType: any;
export interface PutScriptBindingVectorize {
    indexName: string;
    name: string;
    type: PutScriptBindingVectorizeType;
}
export declare const PutScriptBindingVectorize: S.Schema<PutScriptBindingVectorize>;
export type PutScriptBindingVersionMetadataType = "version_metadata";
export declare const PutScriptBindingVersionMetadataType: any;
export interface PutScriptBindingVersionMetadata {
    name: string;
    type: PutScriptBindingVersionMetadataType;
}
export declare const PutScriptBindingVersionMetadata: S.Schema<PutScriptBindingVersionMetadata>;
export type PutScriptBindingSecretsStoreSecretType = "secrets_store_secret";
export declare const PutScriptBindingSecretsStoreSecretType: any;
export interface PutScriptBindingSecretsStoreSecret {
    name: string;
    secretName: string;
    storeId: string;
    type: PutScriptBindingSecretsStoreSecretType;
}
export declare const PutScriptBindingSecretsStoreSecret: S.Schema<PutScriptBindingSecretsStoreSecret>;
export type PutScriptBindingFlagshipType = "flagship";
export declare const PutScriptBindingFlagshipType: any;
export interface PutScriptBindingFlagship {
    appId: string;
    name: string;
    type: PutScriptBindingFlagshipType;
}
export declare const PutScriptBindingFlagship: S.Schema<PutScriptBindingFlagship>;
export type PutScriptBindingSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const PutScriptBindingSecretKeyFormat: any;
export type PutScriptBindingSecretKeyUsage = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const PutScriptBindingSecretKeyUsage: any;
export type PutScriptBindingSecretKeyUsagesList = Array<PutScriptBindingSecretKeyUsage | (string & {})>;
export declare const PutScriptBindingSecretKeyUsagesList: S.Schema<PutScriptBindingSecretKeyUsagesList>;
export type PutScriptBindingSecretKeyType = "secret_key";
export declare const PutScriptBindingSecretKeyType: any;
export interface PutScriptBindingSecretKey {
    algorithm: unknown;
    format: PutScriptBindingSecretKeyFormat | (string & {});
    name: string;
    usages: PutScriptBindingSecretKeyUsagesList;
    keyBase64?: string;
    keyJwk?: unknown;
    type: PutScriptBindingSecretKeyType;
}
export declare const PutScriptBindingSecretKey: S.Schema<PutScriptBindingSecretKey>;
export type PutScriptBindingWorkflowType = "workflow";
export declare const PutScriptBindingWorkflowType: any;
export interface PutScriptBindingWorkflow {
    name: string;
    workflowName: string;
    className: string;
    scriptName?: string;
    type: PutScriptBindingWorkflowType;
}
export declare const PutScriptBindingWorkflow: S.Schema<PutScriptBindingWorkflow>;
export type PutScriptBindingWasmModuleType = "wasm_module";
export declare const PutScriptBindingWasmModuleType: any;
export interface PutScriptBindingWasmModule {
    name: string;
    part: string;
    type: PutScriptBindingWasmModuleType;
}
export declare const PutScriptBindingWasmModule: S.Schema<PutScriptBindingWasmModule>;
export type PutScriptBindingVpcServiceType = "vpc_service";
export declare const PutScriptBindingVpcServiceType: any;
export interface PutScriptBindingVpcService {
    name: string;
    serviceId: string;
    type: PutScriptBindingVpcServiceType;
}
export declare const PutScriptBindingVpcService: S.Schema<PutScriptBindingVpcService>;
export type PutScriptBindingVpcNetworkType = "vpc_network";
export declare const PutScriptBindingVpcNetworkType: any;
export interface PutScriptBindingVpcNetwork {
    name: string;
    networkId?: string;
    tunnelId?: string;
    type: PutScriptBindingVpcNetworkType;
}
export declare const PutScriptBindingVpcNetwork: S.Schema<PutScriptBindingVpcNetwork>;
export type PutScriptBindingWorkerLoaderType = "worker_loader";
export declare const PutScriptBindingWorkerLoaderType: any;
export interface PutScriptBindingWorkerLoader {
    name: string;
    type: PutScriptBindingWorkerLoaderType;
}
export declare const PutScriptBindingWorkerLoader: S.Schema<PutScriptBindingWorkerLoader>;
export type PutScriptBindingArtifactsType = "artifacts";
export declare const PutScriptBindingArtifactsType: any;
export interface PutScriptBindingArtifacts {
    name: string;
    namespace: string;
    type: PutScriptBindingArtifactsType;
}
export declare const PutScriptBindingArtifacts: S.Schema<PutScriptBindingArtifacts>;
export type PutScriptBindingStreamType = "stream";
export declare const PutScriptBindingStreamType: any;
export interface PutScriptBindingStream {
    name: string;
    type: PutScriptBindingStreamType;
}
export declare const PutScriptBindingStream: S.Schema<PutScriptBindingStream>;
export type PutScriptBinding = PutScriptBindingAi | PutScriptBindingAiSearch | PutScriptBindingAiSearchNamespace | PutScriptBindingAnalyticsEngine | PutScriptBindingAssets | PutScriptBindingBrowser | PutScriptBindingD1 | PutScriptBindingDataBlob | PutScriptBindingDispatchNamespace | PutScriptBindingDurableObjectNamespace | PutScriptBindingHyperdrive | PutScriptBindingInherit | PutScriptBindingImages | PutScriptBindingJson | PutScriptBindingKvNamespace | PutScriptBindingMedia | PutScriptBindingMtlsCertificate | PutScriptBindingPlainText | PutScriptBindingPipelines | PutScriptBindingQueue | PutScriptBindingRatelimit | PutScriptBindingR2Bucket | PutScriptBindingSecretText | PutScriptBindingSendEmail | PutScriptBindingService | PutScriptBindingTextBlob | PutScriptBindingVectorize | PutScriptBindingVersionMetadata | PutScriptBindingSecretsStoreSecret | PutScriptBindingFlagship | PutScriptBindingSecretKey | PutScriptBindingWorkflow | PutScriptBindingWasmModule | PutScriptBindingVpcService | PutScriptBindingVpcNetwork | PutScriptBindingWorkerLoader | PutScriptBindingArtifacts | PutScriptBindingStream;
export declare const PutScriptBinding: any;
export type PutScriptMetadataBindingsList = Array<PutScriptBinding>;
export declare const PutScriptMetadataBindingsList: S.Schema<PutScriptMetadataBindingsList>;
export type PutScriptContainer = CreatePreviewDeploymentMetadataContainer;
export declare const PutScriptContainer: S.Schema<CreatePreviewDeploymentMetadataContainer>;
export type PutScriptMetadataContainersList = Array<CreatePreviewDeploymentMetadataContainer>;
export declare const PutScriptMetadataContainersList: S.Schema<PutScriptMetadataContainersList>;
export type PutScriptMetadataLimits = CreateScriptEdgePreviewMetadataLimits;
export declare const PutScriptMetadataLimits: S.Schema<CreateScriptEdgePreviewMetadataLimits>;
export type PutScriptMigrationRenamedClass = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem;
export declare const PutScriptMigrationRenamedClass: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export type PutScriptMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const PutScriptMigrationRenamedClassesList: S.Schema<PutScriptMigrationRenamedClassesList>;
export type PutScriptMigrationTransferredClass = BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem;
export declare const PutScriptMigrationTransferredClass: S.Schema<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export type PutScriptMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateRequestMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const PutScriptMigrationTransferredClassesList: S.Schema<PutScriptMigrationTransferredClassesList>;
export interface PutScriptSingleStepMigration {
    deletedClasses?: PutScriptMetadataStringList;
    newClasses?: PutScriptMetadataStringList;
    newSqliteClasses?: PutScriptMetadataStringList;
    newTag?: string;
    oldTag?: string;
    renamedClasses?: PutScriptMigrationRenamedClassesList;
    transferredClasses?: PutScriptMigrationTransferredClassesList;
}
export declare const PutScriptSingleStepMigration: S.Schema<PutScriptSingleStepMigration>;
export interface PutScriptMigrationStep {
    deletedClasses?: PutScriptMetadataStringList;
    newClasses?: PutScriptMetadataStringList;
    newSqliteClasses?: PutScriptMetadataStringList;
    renamedClasses?: PutScriptMigrationRenamedClassesList;
    transferredClasses?: PutScriptMigrationTransferredClassesList;
}
export declare const PutScriptMigrationStep: S.Schema<PutScriptMigrationStep>;
export type PutScriptMigrationStepsList = Array<PutScriptMigrationStep>;
export declare const PutScriptMigrationStepsList: S.Schema<PutScriptMigrationStepsList>;
export interface PutScriptMultipleStepMigrations {
    newTag?: string;
    oldTag?: string;
    steps?: PutScriptMigrationStepsList;
}
export declare const PutScriptMultipleStepMigrations: S.Schema<PutScriptMultipleStepMigrations>;
export type PutScriptMetadataMigrations = PutScriptSingleStepMigration | PutScriptMultipleStepMigrations;
export declare const PutScriptMetadataMigrations: any;
export interface PutScriptObservabilityLogs {
    enabled: boolean;
    invocationLogs: boolean;
    destinations?: PutScriptMetadataStringList;
    headSamplingRate?: number | null;
    persist?: boolean;
}
export declare const PutScriptObservabilityLogs: S.Schema<PutScriptObservabilityLogs>;
export type PutScriptObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const PutScriptObservabilityTracesPropagationPolicy: any;
export interface PutScriptObservabilityTraces {
    destinations?: PutScriptMetadataStringList;
    enabled?: boolean;
    headSamplingRate?: number | null;
    persist?: boolean;
    propagationPolicy?: PutScriptObservabilityTracesPropagationPolicy | (string & {});
}
export declare const PutScriptObservabilityTraces: S.Schema<PutScriptObservabilityTraces>;
export interface PutScriptMetadataObservability {
    enabled: boolean;
    headSamplingRate?: number | null;
    logs?: PutScriptObservabilityLogs | null;
    traces?: PutScriptObservabilityTraces | null;
}
export declare const PutScriptMetadataObservability: S.Schema<PutScriptMetadataObservability>;
export type PutScriptPlacementSmartMode = "smart";
export declare const PutScriptPlacementSmartMode: any;
export interface PutScriptPlacementSmart {
    mode: PutScriptPlacementSmartMode;
}
export declare const PutScriptPlacementSmart: S.Schema<PutScriptPlacementSmart>;
export type PutScriptPlacementRegion = CreateScriptEdgePreviewMetadataPlacementRegion;
export declare const PutScriptPlacementRegion: S.Schema<CreateScriptEdgePreviewMetadataPlacementRegion>;
export type PutScriptPlacementHostname = CreateScriptEdgePreviewMetadataPlacementHostname;
export declare const PutScriptPlacementHostname: S.Schema<CreateScriptEdgePreviewMetadataPlacementHostname>;
export type PutScriptPlacementHost = CreateScriptEdgePreviewMetadataPlacementHost;
export declare const PutScriptPlacementHost: S.Schema<CreateScriptEdgePreviewMetadataPlacementHost>;
export type PutScriptPlacementTargetedMode = "targeted";
export declare const PutScriptPlacementTargetedMode: any;
export interface PutScriptPlacementTargetedRegion {
    mode: PutScriptPlacementTargetedMode;
    region: string;
}
export declare const PutScriptPlacementTargetedRegion: S.Schema<PutScriptPlacementTargetedRegion>;
export interface PutScriptPlacementTargetedHostname {
    hostname: string;
    mode: PutScriptPlacementTargetedMode;
}
export declare const PutScriptPlacementTargetedHostname: S.Schema<PutScriptPlacementTargetedHostname>;
export interface PutScriptPlacementTargetedHost {
    host: string;
    mode: PutScriptPlacementTargetedMode;
}
export declare const PutScriptPlacementTargetedHost: S.Schema<PutScriptPlacementTargetedHost>;
export type PutScriptPlacementTargetRegion = CreateScriptEdgePreviewMetadataPlacementRegion;
export declare const PutScriptPlacementTargetRegion: S.Schema<CreateScriptEdgePreviewMetadataPlacementRegion>;
export type PutScriptPlacementTargetHostname = CreateScriptEdgePreviewMetadataPlacementHostname;
export declare const PutScriptPlacementTargetHostname: S.Schema<CreateScriptEdgePreviewMetadataPlacementHostname>;
export type PutScriptPlacementTargetHost = CreateScriptEdgePreviewMetadataPlacementHost;
export declare const PutScriptPlacementTargetHost: S.Schema<CreateScriptEdgePreviewMetadataPlacementHost>;
export type PutScriptPlacementTarget = CreateScriptEdgePreviewMetadataPlacementRegion | CreateScriptEdgePreviewMetadataPlacementHostname | CreateScriptEdgePreviewMetadataPlacementHost;
export declare const PutScriptPlacementTarget: any;
export type PutScriptPlacementTargetsList = Array<PutScriptPlacementTarget>;
export declare const PutScriptPlacementTargetsList: S.Schema<PutScriptPlacementTargetsList>;
export interface PutScriptPlacementTargetedList {
    mode: PutScriptPlacementTargetedMode;
    target: PutScriptPlacementTargetsList;
}
export declare const PutScriptPlacementTargetedList: S.Schema<PutScriptPlacementTargetedList>;
export type PutScriptMetadataPlacement = PutScriptPlacementSmart | CreateScriptEdgePreviewMetadataPlacementRegion | CreateScriptEdgePreviewMetadataPlacementHostname | CreateScriptEdgePreviewMetadataPlacementHost | PutScriptPlacementTargetedRegion | PutScriptPlacementTargetedHostname | PutScriptPlacementTargetedHost | PutScriptPlacementTargetedList;
export declare const PutScriptMetadataPlacement: any;
export interface PutScriptTailConsumer {
    service: string;
    environment?: string;
    namespace?: string;
}
export declare const PutScriptTailConsumer: S.Schema<PutScriptTailConsumer>;
export type PutScriptMetadataTailConsumersList = Array<PutScriptTailConsumer>;
export declare const PutScriptMetadataTailConsumersList: S.Schema<PutScriptMetadataTailConsumersList>;
export type PutScriptMetadataUsageModel = "standard" | "bundled" | "unbound";
export declare const PutScriptMetadataUsageModel: any;
export interface PutScriptMetadataCache {
    enabled?: boolean;
    crossVersionCache?: boolean;
}
export declare const PutScriptMetadataCache: S.Schema<PutScriptMetadataCache>;
export type PutScriptMetadataStreamingTailConsumersList = Array<PutScriptTailConsumer>;
export declare const PutScriptMetadataStreamingTailConsumersList: S.Schema<PutScriptMetadataStreamingTailConsumersList>;
export interface PutScriptMetadata {
    annotations?: PutScriptMetadataAnnotations;
    assets?: PutScriptMetadataAssets;
    bindings?: PutScriptMetadataBindingsList;
    bodyPart?: string;
    compatibilityDate?: string;
    compatibilityFlags?: PutScriptMetadataStringList;
    containers?: PutScriptMetadataContainersList;
    keepAssets?: boolean;
    keepBindings?: PutScriptMetadataStringList;
    limits?: CreateScriptEdgePreviewMetadataLimits;
    logpush?: boolean;
    mainModule?: string;
    migrations?: PutScriptMetadataMigrations;
    observability?: PutScriptMetadataObservability;
    placement?: PutScriptMetadataPlacement;
    tags?: PutScriptMetadataStringList;
    tailConsumers?: PutScriptMetadataTailConsumersList | null;
    usageModel?: PutScriptMetadataUsageModel | (string & {});
    cacheOptions?: PutScriptMetadataCache;
    streamingTailConsumers?: PutScriptMetadataStreamingTailConsumersList | null;
}
export declare const PutScriptMetadata: S.Schema<PutScriptMetadata>;
export interface CreateScriptVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** When set to "strict", the upload will fail if any `inherit` type bindings cannot be resolved against the previous version of the Worker. Without this, unresolvable inherit bindings are silently dropped. */
    bindingsInherit?: ScriptsVersionsCreateRequestBindingsInherit | (string & {});
    metadata: PutScriptMetadata;
    /** Module / asset file parts, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export declare const CreateScriptVersionRequest: S.Schema<CreateScriptVersionRequest>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemAIType = "ai";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAIType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemAIType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAI: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemAI>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemAISearchType = "ai_search";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAISearchType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAISearch: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemAISearch>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAISearchNamespaceType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemAISearchNamespaceType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAISearchNamespace: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemAISearchNamespace>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAnalyticsEngineType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemAnalyticsEngineType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAnalyticsEngine: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemAnalyticsEngine>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemAssetsType = "assets";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAssetsType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemAssetsType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemAssets: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemAssets>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemBrowserType = "browser";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemBrowserType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemBrowserType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemBrowser: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemBrowser>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemD1Type = "d1";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemD1Type: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemD1: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemD1>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemDataBlobType = "data_blob";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDataBlobType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemDataBlobType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDataBlob: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemDataBlob>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceType: any;
export type ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker>;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutbound: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutbound>;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespaceOutbound | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespace: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespace>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDurableObjectNamespaceType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemDurableObjectNamespace: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemDurableObjectNamespace>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemHyperdriveType = "hyperdrive";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemHyperdriveType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemHyperdriveType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemHyperdrive: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemHyperdrive>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemInheritType = "inherit";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemInheritType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemInherit: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemInherit>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemImagesType = "images";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemImagesType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemImagesType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemImages: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemImages>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemJsonType = "json";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemJsonType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemJsonType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemJson: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemJson>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemKVNamespaceType = "kv_namespace";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemKVNamespaceType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemKVNamespaceType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemKVNamespace: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemKVNamespace>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemMediaType = "media";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemMediaType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemMediaType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemMedia: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemMedia>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemMTLSCertificateType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemMTLSCertificateType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemMTLSCertificate: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemMTLSCertificate>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemPlainTextType = "plain_text";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemPlainTextType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemPlainTextType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemPlainText: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemPlainText>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemPipelinesType = "pipelines";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemPipelinesType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemPipelinesType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemPipelines: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemPipelines>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemQueueType = "queue";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemQueueType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemQueueType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemQueue: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemQueue>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemRatelimitType = "ratelimit";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemRatelimitType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemRatelimitType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemRatelimit: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemRatelimit>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemR2BucketType = "r2_bucket";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemR2BucketType: any;
export type ScriptsVersionsCreateResponseResourcesBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemR2BucketJurisdiction: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: ScriptsVersionsCreateResponseResourcesBindingsItemR2BucketJurisdiction | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemR2Bucket: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemR2Bucket>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSecretTextType = "secret_text";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretTextType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemSecretTextType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretText: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemSecretText>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailType = "send_email";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailType: any;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList>;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: ScriptsVersionsCreateResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSendEmail: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemSendEmail>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemServiceType = "service";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemServiceType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemService: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemService>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemTextBlobType = "text_blob";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemTextBlobType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemTextBlobType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemTextBlob: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemTextBlob>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemVectorizeType = "vectorize";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVectorizeType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemVectorizeType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVectorize: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemVectorize>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemVersionMetadataType = "version_metadata";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVersionMetadataType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemVersionMetadataType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVersionMetadata: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemVersionMetadata>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretsStoreSecretType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemSecretsStoreSecretType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretsStoreSecret: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemSecretsStoreSecret>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemFlagshipType = "flagship";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemFlagshipType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemFlagshipType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemFlagship: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemFlagship>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyFormat: any;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyType = "secret_key";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyType: any;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyUsagesItem: any;
export type ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyUsagesList = Array<ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyUsagesItem>;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyUsagesList: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyUsagesList>;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsVersionsCreateResponseResourcesBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemSecretKey: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemSecretKey>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemWorkflowType = "workflow";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemWorkflowType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemWorkflow: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemWorkflow>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemWasmModuleType = "wasm_module";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemWasmModuleType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemWasmModuleType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemWasmModule: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemWasmModule>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemVPCServiceType = "vpc_service";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVPCServiceType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemVPCServiceType;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVPCService: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemVPCService>;
export type ScriptsVersionsCreateResponseResourcesBindingsItemVPCNetworkType = "vpc_network";
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVPCNetworkType: any;
export interface ScriptsVersionsCreateResponseResourcesBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsCreateResponseResourcesBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesBindingsItemVPCNetwork: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsItemVPCNetwork>;
export type ScriptsVersionsCreateResponseResourcesBindingsItem = ScriptsVersionsCreateResponseResourcesBindingsItemAI | ScriptsVersionsCreateResponseResourcesBindingsItemAISearch | ScriptsVersionsCreateResponseResourcesBindingsItemAISearchNamespace | ScriptsVersionsCreateResponseResourcesBindingsItemAnalyticsEngine | ScriptsVersionsCreateResponseResourcesBindingsItemAssets | ScriptsVersionsCreateResponseResourcesBindingsItemBrowser | ScriptsVersionsCreateResponseResourcesBindingsItemD1 | ScriptsVersionsCreateResponseResourcesBindingsItemDataBlob | ScriptsVersionsCreateResponseResourcesBindingsItemDispatchNamespace | ScriptsVersionsCreateResponseResourcesBindingsItemDurableObjectNamespace | ScriptsVersionsCreateResponseResourcesBindingsItemHyperdrive | ScriptsVersionsCreateResponseResourcesBindingsItemInherit | ScriptsVersionsCreateResponseResourcesBindingsItemImages | ScriptsVersionsCreateResponseResourcesBindingsItemJson | ScriptsVersionsCreateResponseResourcesBindingsItemKVNamespace | ScriptsVersionsCreateResponseResourcesBindingsItemMedia | ScriptsVersionsCreateResponseResourcesBindingsItemMTLSCertificate | ScriptsVersionsCreateResponseResourcesBindingsItemPlainText | ScriptsVersionsCreateResponseResourcesBindingsItemPipelines | ScriptsVersionsCreateResponseResourcesBindingsItemQueue | ScriptsVersionsCreateResponseResourcesBindingsItemRatelimit | ScriptsVersionsCreateResponseResourcesBindingsItemR2Bucket | ScriptsVersionsCreateResponseResourcesBindingsItemSecretText | ScriptsVersionsCreateResponseResourcesBindingsItemSendEmail | ScriptsVersionsCreateResponseResourcesBindingsItemService | ScriptsVersionsCreateResponseResourcesBindingsItemTextBlob | ScriptsVersionsCreateResponseResourcesBindingsItemVectorize | ScriptsVersionsCreateResponseResourcesBindingsItemVersionMetadata | ScriptsVersionsCreateResponseResourcesBindingsItemSecretsStoreSecret | ScriptsVersionsCreateResponseResourcesBindingsItemFlagship | ScriptsVersionsCreateResponseResourcesBindingsItemSecretKey | ScriptsVersionsCreateResponseResourcesBindingsItemWorkflow | ScriptsVersionsCreateResponseResourcesBindingsItemWasmModule | ScriptsVersionsCreateResponseResourcesBindingsItemVPCService | ScriptsVersionsCreateResponseResourcesBindingsItemVPCNetwork;
export declare const ScriptsVersionsCreateResponseResourcesBindingsItem: any;
export type ScriptsVersionsCreateResponseResourcesBindingsList = Array<ScriptsVersionsCreateResponseResourcesBindingsItem>;
export declare const ScriptsVersionsCreateResponseResourcesBindingsList: S.Schema<ScriptsVersionsCreateResponseResourcesBindingsList>;
export type ScriptsVersionsCreateResponseResourcesScriptHandlersList = Array<string>;
export declare const ScriptsVersionsCreateResponseResourcesScriptHandlersList: S.Schema<ScriptsVersionsCreateResponseResourcesScriptHandlersList>;
export type ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItemHandlersList = Array<string>;
export declare const ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItemHandlersList: S.Schema<ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItemHandlersList>;
export interface ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItemHandlersList | null;
    /** The name of the exported class or entrypoint. */
    name?: string | null;
}
export declare const ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItem: S.Schema<ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItem>;
export type ScriptsVersionsCreateResponseResourcesScriptNamedHandlersList = Array<ScriptsVersionsCreateResponseResourcesScriptNamedHandlersItem>;
export declare const ScriptsVersionsCreateResponseResourcesScriptNamedHandlersList: S.Schema<ScriptsVersionsCreateResponseResourcesScriptNamedHandlersList>;
export interface ScriptsVersionsCreateResponseResourcesScript {
    /** Hashed script content */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsVersionsCreateResponseResourcesScriptHandlersList | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsVersionsCreateResponseResourcesScriptNamedHandlersList | null;
}
export declare const ScriptsVersionsCreateResponseResourcesScript: S.Schema<ScriptsVersionsCreateResponseResourcesScript>;
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeCompatibilityFlagsList = Array<string>;
export declare const ScriptsVersionsCreateResponseResourcesScriptRuntimeCompatibilityFlagsList: S.Schema<ScriptsVersionsCreateResponseResourcesScriptRuntimeCompatibilityFlagsList>;
export interface ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number | null;
}
export declare const ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits: S.Schema<ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits>;
export type ScriptsVersionsCreateResponseResourcesScriptRuntimeUsageModel = "bundled" | "unbound" | "standard";
export declare const ScriptsVersionsCreateResponseResourcesScriptRuntimeUsageModel: any;
export interface ScriptsVersionsCreateResponseResourcesScriptRuntime {
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. */
    compatibilityFlags?: ScriptsVersionsCreateResponseResourcesScriptRuntimeCompatibilityFlagsList | null;
    /** Resource limits for the Worker. */
    limits?: ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsVersionsCreateResponseResourcesScriptRuntimeUsageModel | null;
}
export declare const ScriptsVersionsCreateResponseResourcesScriptRuntime: S.Schema<ScriptsVersionsCreateResponseResourcesScriptRuntime>;
export interface ScriptsVersionsCreateResponseResources {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: ScriptsVersionsCreateResponseResourcesBindingsList | null;
    script?: ScriptsVersionsCreateResponseResourcesScript | null;
    /** Runtime configuration for the Worker. */
    scriptRuntime?: ScriptsVersionsCreateResponseResourcesScriptRuntime | null;
}
export declare const ScriptsVersionsCreateResponseResources: S.Schema<ScriptsVersionsCreateResponseResources>;
export type ScriptsVersionsCreateResponseMetadataSource = "unknown" | "api" | "wrangler" | "terraform" | "dash" | "cf_cli" | "dash_template" | "integration" | "quick_editor" | "playground" | "workersci";
export declare const ScriptsVersionsCreateResponseMetadataSource: any;
export interface ScriptsVersionsCreateResponseMetadata {
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** When the version was created. */
    createdOn?: string | null;
    /** Whether the version can be previewed. */
    hasPreview?: boolean | null;
    /** When the version was last modified. */
    modifiedOn?: string | null;
    /** The source of the version upload. */
    source?: ScriptsVersionsCreateResponseMetadataSource | null;
}
export declare const ScriptsVersionsCreateResponseMetadata: S.Schema<ScriptsVersionsCreateResponseMetadata>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScriptVersionResponse {
    resources: ScriptsVersionsCreateResponseResources;
    /** Unique identifier for the version. */
    id?: string | null;
    metadata?: ScriptsVersionsCreateResponseMetadata | null;
    /** Sequential version number. */
    number?: number | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
}
export declare const CreateScriptVersionResponse: S.Schema<CreateScriptVersionResponse>;
export interface CreateServiceEdgePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the Worker service. */
    serviceName: string;
    /** Name of the environment within the service. */
    environmentName: string;
    /** The session token returned by createSubdomainEdgePreviewSession. */
    cfPreviewUploadConfigToken: string;
    /** JSON-encoded multipart `metadata` part: the preview worker's modules, bindings and settings. */
    metadata?: CreateScriptEdgePreviewMetadata;
    /** Module files comprising the worker script, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
    /** JSON-encoded multipart part selecting how the preview is routed (workers.dev or explicit routes); without it edge previews cannot opt into workers.dev routing. */
    wranglerSessionConfig?: CreateScriptEdgePreviewWranglerSessionConfig;
}
export declare const CreateServiceEdgePreviewRequest: S.Schema<CreateServiceEdgePreviewRequest>;
export interface CreateServiceEdgePreviewResponse {
    /** Token to send as cf-workers-preview-token header when making requests to the preview host. */
    previewToken: string;
    /** URL for tailing live logs from the preview worker. */
    tailUrl?: string | null;
}
export declare const CreateServiceEdgePreviewResponse: S.Schema<CreateServiceEdgePreviewResponse>;
export interface CreateSubdomainEdgePreviewSessionRequest {
    /** Identifier. */
    accountId: string;
}
export declare const CreateSubdomainEdgePreviewSessionRequest: S.Schema<CreateSubdomainEdgePreviewSessionRequest>;
export interface CreateSubdomainEdgePreviewSessionResponse {
    /** Session token used as cf-preview-upload-config-token when uploading a preview worker. */
    token: string;
    /** Optional URL to exchange the token for a re-encoded version. */
    exchangeUrl?: string | null;
}
export declare const CreateSubdomainEdgePreviewSessionResponse: S.Schema<CreateSubdomainEdgePreviewSessionResponse>;
export interface CreateZoneEdgePreviewSessionRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const CreateZoneEdgePreviewSessionRequest: S.Schema<CreateZoneEdgePreviewSessionRequest>;
export interface CreateZoneEdgePreviewSessionResponse {
    /** Session token used as cf-preview-upload-config-token when uploading a preview worker. */
    token: string;
    /** Optional URL to exchange the token for a re-encoded version. */
    exchangeUrl?: string | null;
}
export declare const CreateZoneEdgePreviewSessionResponse: S.Schema<CreateZoneEdgePreviewSessionResponse>;
export interface DeleteBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
}
export declare const DeleteBetaWorkerRequest: S.Schema<DeleteBetaWorkerRequest>;
export interface DeleteBetaWorkerResponse {
}
export declare const DeleteBetaWorkerResponse: S.Schema<DeleteBetaWorkerResponse>;
export interface DeleteBetaWorkerVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Identifier for the version, which can be a UUID, a UUID prefix (minimum length 8), or the literal "latest" to operate on the most recently created version. */
    versionId: string;
}
export declare const DeleteBetaWorkerVersionRequest: S.Schema<DeleteBetaWorkerVersionRequest>;
export interface DeleteBetaWorkerVersionResponse {
}
export declare const DeleteBetaWorkerVersionResponse: S.Schema<DeleteBetaWorkerVersionResponse>;
export interface DeleteDomainRequest {
    /** Identifier. */
    accountId: string;
    /** ID of the domain. */
    domainId: string;
}
export declare const DeleteDomainRequest: S.Schema<DeleteDomainRequest>;
export interface DeleteDomainResponse {
}
export declare const DeleteDomainResponse: S.Schema<DeleteDomainResponse>;
export interface DeleteObservabilityDestinationRequest {
    accountId: string;
    slug: string;
}
export declare const DeleteObservabilityDestinationRequest: S.Schema<DeleteObservabilityDestinationRequest>;
export type ObservabilityDestinationsDeleteResponseConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export declare const ObservabilityDestinationsDeleteResponseConfigurationLogpushDataset: any;
export type ObservabilityDestinationsDeleteResponseConfigurationType = "logpush";
export declare const ObservabilityDestinationsDeleteResponseConfigurationType: any;
export interface ObservabilityDestinationsDeleteResponseConfiguration {
    destinationConf: string;
    logpushDataset: ObservabilityDestinationsDeleteResponseConfigurationLogpushDataset;
    logpushJob: number;
    type: ObservabilityDestinationsDeleteResponseConfigurationType;
    url: string;
}
export declare const ObservabilityDestinationsDeleteResponseConfiguration: S.Schema<ObservabilityDestinationsDeleteResponseConfiguration>;
export type ObservabilityDestinationsDeleteResponseScriptsList = Array<string>;
export declare const ObservabilityDestinationsDeleteResponseScriptsList: S.Schema<ObservabilityDestinationsDeleteResponseScriptsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteObservabilityDestinationResponse {
    configuration: ObservabilityDestinationsDeleteResponseConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsDeleteResponseScriptsList;
    slug: string;
}
export declare const DeleteObservabilityDestinationResponse: S.Schema<DeleteObservabilityDestinationResponse>;
export interface DeletePreviewRequest {
    accountId: string;
    workerId: string;
    previewId: string;
}
export declare const DeletePreviewRequest: S.Schema<DeletePreviewRequest>;
export interface DeletePreviewResponse {
}
export declare const DeletePreviewResponse: S.Schema<DeletePreviewResponse>;
export interface DeleteRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    routeId: string;
}
export declare const DeleteRouteRequest: S.Schema<DeleteRouteRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRouteResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const DeleteRouteResponse: S.Schema<DeleteRouteResponse>;
export interface DeleteScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** If set to true, delete will not be stopped by associated service binding, durable object, or other binding. Any of these associated bindings/durable objects will be deleted along with the script. */
    force?: boolean;
}
export declare const DeleteScriptRequest: S.Schema<DeleteScriptRequest>;
export type DeleteScriptResponse = unknown;
export declare const DeleteScriptResponse: S.Schema<DeleteScriptResponse>;
export interface DeleteScriptDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    deploymentId: string;
}
export declare const DeleteScriptDeploymentRequest: S.Schema<DeleteScriptDeploymentRequest>;
export interface DeleteScriptDeploymentResponse {
}
export declare const DeleteScriptDeploymentResponse: S.Schema<DeleteScriptDeploymentResponse>;
export interface DeleteScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export declare const DeleteScriptSecretRequest: S.Schema<DeleteScriptSecretRequest>;
export type DeleteScriptSecretResponse = unknown;
export declare const DeleteScriptSecretResponse: S.Schema<DeleteScriptSecretResponse>;
export interface DeleteScriptSubdomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const DeleteScriptSubdomainRequest: S.Schema<DeleteScriptSubdomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteScriptSubdomainResponse {
    /** Whether the Worker is available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs are available on the workers.dev subdomain. */
    previewsEnabled: boolean;
}
export declare const DeleteScriptSubdomainResponse: S.Schema<DeleteScriptSubdomainResponse>;
export interface DeleteScriptTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Identifier. */
    id: string;
}
export declare const DeleteScriptTailRequest: S.Schema<DeleteScriptTailRequest>;
export interface DeleteScriptTailResponse {
}
export declare const DeleteScriptTailResponse: S.Schema<DeleteScriptTailResponse>;
export interface DeleteSubdomainRequest {
    /** Identifier. */
    accountId: string;
}
export declare const DeleteSubdomainRequest: S.Schema<DeleteSubdomainRequest>;
export interface DeleteSubdomainResponse {
}
export declare const DeleteSubdomainResponse: S.Schema<DeleteSubdomainResponse>;
export interface GetAccountSettingRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetAccountSettingRequest: S.Schema<GetAccountSettingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountSettingResponse {
    defaultUsageModel?: string | null;
    greenCompute?: boolean | null;
}
export declare const GetAccountSettingResponse: S.Schema<GetAccountSettingResponse>;
export interface GetBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
}
export declare const GetBetaWorkerRequest: S.Schema<GetBetaWorkerRequest>;
export type BetaWorkersGetResponseObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersGetResponseObservabilityLogsDestinationsList: S.Schema<BetaWorkersGetResponseObservabilityLogsDestinationsList>;
export interface BetaWorkersGetResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersGetResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const BetaWorkersGetResponseObservabilityLogs: S.Schema<BetaWorkersGetResponseObservabilityLogs>;
export type BetaWorkersGetResponseObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersGetResponseObservabilityTracesDestinationsList: S.Schema<BetaWorkersGetResponseObservabilityTracesDestinationsList>;
export type BetaWorkersGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersGetResponseObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersGetResponseObservabilityTracesPropagationPolicy | null;
}
export declare const BetaWorkersGetResponseObservabilityTraces: S.Schema<BetaWorkersGetResponseObservabilityTraces>;
export interface BetaWorkersGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersGetResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersGetResponseObservabilityTraces | null;
}
export declare const BetaWorkersGetResponseObservability: S.Schema<BetaWorkersGetResponseObservability>;
export type BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export declare const BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsItem: S.Schema<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export declare const BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsList: S.Schema<BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsList>;
export type BetaWorkersGetResponseReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export declare const BetaWorkersGetResponseReferencesDomainsItem: S.Schema<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersGetResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export declare const BetaWorkersGetResponseReferencesDomainsList: S.Schema<BetaWorkersGetResponseReferencesDomainsList>;
export type BetaWorkersGetResponseReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export declare const BetaWorkersGetResponseReferencesDurableObjectsItem: S.Schema<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersGetResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export declare const BetaWorkersGetResponseReferencesDurableObjectsList: S.Schema<BetaWorkersGetResponseReferencesDurableObjectsList>;
export type BetaWorkersGetResponseReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export declare const BetaWorkersGetResponseReferencesQueuesItem: S.Schema<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersGetResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export declare const BetaWorkersGetResponseReferencesQueuesList: S.Schema<BetaWorkersGetResponseReferencesQueuesList>;
export type BetaWorkersGetResponseReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export declare const BetaWorkersGetResponseReferencesWorkersItem: S.Schema<BetaWorkersCreateResponseReferencesWorkersItem>;
export type BetaWorkersGetResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export declare const BetaWorkersGetResponseReferencesWorkersList: S.Schema<BetaWorkersGetResponseReferencesWorkersList>;
export interface BetaWorkersGetResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersGetResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersGetResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersGetResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersGetResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersGetResponseReferencesWorkersList;
}
export declare const BetaWorkersGetResponseReferences: S.Schema<BetaWorkersGetResponseReferences>;
export type BetaWorkersGetResponseSubdomain = BetaWorkersCreateResponseSubdomain;
export declare const BetaWorkersGetResponseSubdomain: S.Schema<BetaWorkersCreateResponseSubdomain>;
export type BetaWorkersGetResponseTagsList = Array<string>;
export declare const BetaWorkersGetResponseTagsList: S.Schema<BetaWorkersGetResponseTagsList>;
export type BetaWorkersGetResponseTailConsumersItem = BetaWorkersCreateRequestTailConsumersItem;
export declare const BetaWorkersGetResponseTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersGetResponseTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersGetResponseTailConsumersList: S.Schema<BetaWorkersGetResponseTailConsumersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersGetResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersGetResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersGetResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersGetResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
}
export declare const GetBetaWorkerResponse: S.Schema<GetBetaWorkerResponse>;
export type BetaWorkersVersionsGetRequestInclude = "modules";
export declare const BetaWorkersVersionsGetRequestInclude: any;
export interface GetBetaWorkerVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Identifier for the version, which can be a UUID, a UUID prefix (minimum length 8), or the literal "latest" to operate on the most recently created version. */
    versionId: string;
    /** Whether to include the `modules` property of the version in the response, which contains code and sourcemap content and may add several megabytes to the response size. */
    include?: BetaWorkersVersionsGetRequestInclude | (string & {});
}
export declare const GetBetaWorkerVersionRequest: S.Schema<GetBetaWorkerVersionRequest>;
export type BetaWorkersVersionsGetResponseUrlsList = Array<string>;
export declare const BetaWorkersVersionsGetResponseUrlsList: S.Schema<BetaWorkersVersionsGetResponseUrlsList>;
export type BetaWorkersVersionsGetResponseAnnotations = BetaWorkersVersionsCreateResponseAnnotations;
export declare const BetaWorkersVersionsGetResponseAnnotations: S.Schema<BetaWorkersVersionsCreateResponseAnnotations>;
export type BetaWorkersVersionsGetResponseAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export declare const BetaWorkersVersionsGetResponseAssetsConfigHtmlHandling: any;
export type BetaWorkersVersionsGetResponseAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export declare const BetaWorkersVersionsGetResponseAssetsConfigNotFoundHandling: any;
export type BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirstCase0List = Array<string>;
export declare const BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirstCase0List: S.Schema<BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirstCase0List>;
export type BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirstCase0List;
export declare const BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirst: any;
export interface BetaWorkersVersionsGetResponseAssetsConfig {
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsGetResponseAssetsConfigHtmlHandling | null;
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsGetResponseAssetsConfigNotFoundHandling | null;
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsGetResponseAssetsConfigRunWorkerFirst | null;
}
export declare const BetaWorkersVersionsGetResponseAssetsConfig: S.Schema<BetaWorkersVersionsGetResponseAssetsConfig>;
export interface BetaWorkersVersionsGetResponseAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsGetResponseAssetsConfig | null;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string | null;
}
export declare const BetaWorkersVersionsGetResponseAssets: S.Schema<BetaWorkersVersionsGetResponseAssets>;
export type BetaWorkersVersionsGetResponseBindingsItemAIType = "ai";
export declare const BetaWorkersVersionsGetResponseBindingsItemAIType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAIType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemAI: S.Schema<BetaWorkersVersionsGetResponseBindingsItemAI>;
export type BetaWorkersVersionsGetResponseBindingsItemAISearchType = "ai_search";
export declare const BetaWorkersVersionsGetResponseBindingsItemAISearchType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemAISearch: S.Schema<BetaWorkersVersionsGetResponseBindingsItemAISearch>;
export type BetaWorkersVersionsGetResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const BetaWorkersVersionsGetResponseBindingsItemAISearchNamespaceType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAISearchNamespaceType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemAISearchNamespace: S.Schema<BetaWorkersVersionsGetResponseBindingsItemAISearchNamespace>;
export type BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngineType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngineType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngine: S.Schema<BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngine>;
export type BetaWorkersVersionsGetResponseBindingsItemAssetsType = "assets";
export declare const BetaWorkersVersionsGetResponseBindingsItemAssetsType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemAssetsType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemAssets: S.Schema<BetaWorkersVersionsGetResponseBindingsItemAssets>;
export type BetaWorkersVersionsGetResponseBindingsItemBrowserType = "browser";
export declare const BetaWorkersVersionsGetResponseBindingsItemBrowserType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemBrowserType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemBrowser: S.Schema<BetaWorkersVersionsGetResponseBindingsItemBrowser>;
export type BetaWorkersVersionsGetResponseBindingsItemD1Type = "d1";
export declare const BetaWorkersVersionsGetResponseBindingsItemD1Type: any;
export interface BetaWorkersVersionsGetResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemD1: S.Schema<BetaWorkersVersionsGetResponseBindingsItemD1>;
export type BetaWorkersVersionsGetResponseBindingsItemDataBlobType = "data_blob";
export declare const BetaWorkersVersionsGetResponseBindingsItemDataBlobType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemDataBlobType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemDataBlob: S.Schema<BetaWorkersVersionsGetResponseBindingsItemDataBlob>;
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceType: any;
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export declare const BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsList>;
export type BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export declare const BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker>;
export interface BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutbound: S.Schema<BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutbound>;
export interface BetaWorkersVersionsGetResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsGetResponseBindingsItemDispatchNamespaceOutbound | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemDispatchNamespace: S.Schema<BetaWorkersVersionsGetResponseBindingsItemDispatchNamespace>;
export type BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespaceType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespace: S.Schema<BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespace>;
export type BetaWorkersVersionsGetResponseBindingsItemHyperdriveType = "hyperdrive";
export declare const BetaWorkersVersionsGetResponseBindingsItemHyperdriveType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemHyperdriveType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemHyperdrive: S.Schema<BetaWorkersVersionsGetResponseBindingsItemHyperdrive>;
export type BetaWorkersVersionsGetResponseBindingsItemInheritType = "inherit";
export declare const BetaWorkersVersionsGetResponseBindingsItemInheritType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemInherit: S.Schema<BetaWorkersVersionsGetResponseBindingsItemInherit>;
export type BetaWorkersVersionsGetResponseBindingsItemImagesType = "images";
export declare const BetaWorkersVersionsGetResponseBindingsItemImagesType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemImagesType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemImages: S.Schema<BetaWorkersVersionsGetResponseBindingsItemImages>;
export type BetaWorkersVersionsGetResponseBindingsItemJsonType = "json";
export declare const BetaWorkersVersionsGetResponseBindingsItemJsonType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemJsonType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemJson: S.Schema<BetaWorkersVersionsGetResponseBindingsItemJson>;
export type BetaWorkersVersionsGetResponseBindingsItemKVNamespaceType = "kv_namespace";
export declare const BetaWorkersVersionsGetResponseBindingsItemKVNamespaceType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemKVNamespaceType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemKVNamespace: S.Schema<BetaWorkersVersionsGetResponseBindingsItemKVNamespace>;
export type BetaWorkersVersionsGetResponseBindingsItemMediaType = "media";
export declare const BetaWorkersVersionsGetResponseBindingsItemMediaType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemMediaType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemMedia: S.Schema<BetaWorkersVersionsGetResponseBindingsItemMedia>;
export type BetaWorkersVersionsGetResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const BetaWorkersVersionsGetResponseBindingsItemMTLSCertificateType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemMTLSCertificateType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemMTLSCertificate: S.Schema<BetaWorkersVersionsGetResponseBindingsItemMTLSCertificate>;
export type BetaWorkersVersionsGetResponseBindingsItemPlainTextType = "plain_text";
export declare const BetaWorkersVersionsGetResponseBindingsItemPlainTextType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemPlainTextType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemPlainText: S.Schema<BetaWorkersVersionsGetResponseBindingsItemPlainText>;
export type BetaWorkersVersionsGetResponseBindingsItemPipelinesType = "pipelines";
export declare const BetaWorkersVersionsGetResponseBindingsItemPipelinesType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemPipelinesType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemPipelines: S.Schema<BetaWorkersVersionsGetResponseBindingsItemPipelines>;
export type BetaWorkersVersionsGetResponseBindingsItemQueueType = "queue";
export declare const BetaWorkersVersionsGetResponseBindingsItemQueueType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemQueueType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemQueue: S.Schema<BetaWorkersVersionsGetResponseBindingsItemQueue>;
export type BetaWorkersVersionsGetResponseBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export declare const BetaWorkersVersionsGetResponseBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple>;
export type BetaWorkersVersionsGetResponseBindingsItemRatelimitType = "ratelimit";
export declare const BetaWorkersVersionsGetResponseBindingsItemRatelimitType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemRatelimitType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemRatelimit: S.Schema<BetaWorkersVersionsGetResponseBindingsItemRatelimit>;
export type BetaWorkersVersionsGetResponseBindingsItemR2BucketType = "r2_bucket";
export declare const BetaWorkersVersionsGetResponseBindingsItemR2BucketType: any;
export type BetaWorkersVersionsGetResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const BetaWorkersVersionsGetResponseBindingsItemR2BucketJurisdiction: any;
export interface BetaWorkersVersionsGetResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsGetResponseBindingsItemR2BucketJurisdiction | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemR2Bucket: S.Schema<BetaWorkersVersionsGetResponseBindingsItemR2Bucket>;
export type BetaWorkersVersionsGetResponseBindingsItemSecretTextType = "secret_text";
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretTextType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSecretTextType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretText: S.Schema<BetaWorkersVersionsGetResponseBindingsItemSecretText>;
export type BetaWorkersVersionsGetResponseBindingsItemSendEmailType = "send_email";
export declare const BetaWorkersVersionsGetResponseBindingsItemSendEmailType: any;
export type BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList>;
export type BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedSenderAddressesList>;
export interface BetaWorkersVersionsGetResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsGetResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemSendEmail: S.Schema<BetaWorkersVersionsGetResponseBindingsItemSendEmail>;
export type BetaWorkersVersionsGetResponseBindingsItemServiceType = "service";
export declare const BetaWorkersVersionsGetResponseBindingsItemServiceType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemService: S.Schema<BetaWorkersVersionsGetResponseBindingsItemService>;
export type BetaWorkersVersionsGetResponseBindingsItemTextBlobType = "text_blob";
export declare const BetaWorkersVersionsGetResponseBindingsItemTextBlobType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemTextBlobType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemTextBlob: S.Schema<BetaWorkersVersionsGetResponseBindingsItemTextBlob>;
export type BetaWorkersVersionsGetResponseBindingsItemVectorizeType = "vectorize";
export declare const BetaWorkersVersionsGetResponseBindingsItemVectorizeType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVectorizeType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemVectorize: S.Schema<BetaWorkersVersionsGetResponseBindingsItemVectorize>;
export type BetaWorkersVersionsGetResponseBindingsItemVersionMetadataType = "version_metadata";
export declare const BetaWorkersVersionsGetResponseBindingsItemVersionMetadataType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVersionMetadataType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemVersionMetadata: S.Schema<BetaWorkersVersionsGetResponseBindingsItemVersionMetadata>;
export type BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecretType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecretType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecret: S.Schema<BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecret>;
export type BetaWorkersVersionsGetResponseBindingsItemFlagshipType = "flagship";
export declare const BetaWorkersVersionsGetResponseBindingsItemFlagshipType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemFlagshipType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemFlagship: S.Schema<BetaWorkersVersionsGetResponseBindingsItemFlagship>;
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretKeyFormat: any;
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyType = "secret_key";
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretKeyType: any;
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesItem: any;
export type BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesItem>;
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesList: S.Schema<BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesList>;
export interface BetaWorkersVersionsGetResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsGetResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsGetResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemSecretKey: S.Schema<BetaWorkersVersionsGetResponseBindingsItemSecretKey>;
export type BetaWorkersVersionsGetResponseBindingsItemWorkflowType = "workflow";
export declare const BetaWorkersVersionsGetResponseBindingsItemWorkflowType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemWorkflow: S.Schema<BetaWorkersVersionsGetResponseBindingsItemWorkflow>;
export type BetaWorkersVersionsGetResponseBindingsItemWasmModuleType = "wasm_module";
export declare const BetaWorkersVersionsGetResponseBindingsItemWasmModuleType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemWasmModuleType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemWasmModule: S.Schema<BetaWorkersVersionsGetResponseBindingsItemWasmModule>;
export type BetaWorkersVersionsGetResponseBindingsItemVPCServiceType = "vpc_service";
export declare const BetaWorkersVersionsGetResponseBindingsItemVPCServiceType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVPCServiceType;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemVPCService: S.Schema<BetaWorkersVersionsGetResponseBindingsItemVPCService>;
export type BetaWorkersVersionsGetResponseBindingsItemVPCNetworkType = "vpc_network";
export declare const BetaWorkersVersionsGetResponseBindingsItemVPCNetworkType: any;
export interface BetaWorkersVersionsGetResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsGetResponseBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const BetaWorkersVersionsGetResponseBindingsItemVPCNetwork: S.Schema<BetaWorkersVersionsGetResponseBindingsItemVPCNetwork>;
export type BetaWorkersVersionsGetResponseBindingsItem = BetaWorkersVersionsGetResponseBindingsItemAI | BetaWorkersVersionsGetResponseBindingsItemAISearch | BetaWorkersVersionsGetResponseBindingsItemAISearchNamespace | BetaWorkersVersionsGetResponseBindingsItemAnalyticsEngine | BetaWorkersVersionsGetResponseBindingsItemAssets | BetaWorkersVersionsGetResponseBindingsItemBrowser | BetaWorkersVersionsGetResponseBindingsItemD1 | BetaWorkersVersionsGetResponseBindingsItemDataBlob | BetaWorkersVersionsGetResponseBindingsItemDispatchNamespace | BetaWorkersVersionsGetResponseBindingsItemDurableObjectNamespace | BetaWorkersVersionsGetResponseBindingsItemHyperdrive | BetaWorkersVersionsGetResponseBindingsItemInherit | BetaWorkersVersionsGetResponseBindingsItemImages | BetaWorkersVersionsGetResponseBindingsItemJson | BetaWorkersVersionsGetResponseBindingsItemKVNamespace | BetaWorkersVersionsGetResponseBindingsItemMedia | BetaWorkersVersionsGetResponseBindingsItemMTLSCertificate | BetaWorkersVersionsGetResponseBindingsItemPlainText | BetaWorkersVersionsGetResponseBindingsItemPipelines | BetaWorkersVersionsGetResponseBindingsItemQueue | BetaWorkersVersionsGetResponseBindingsItemRatelimit | BetaWorkersVersionsGetResponseBindingsItemR2Bucket | BetaWorkersVersionsGetResponseBindingsItemSecretText | BetaWorkersVersionsGetResponseBindingsItemSendEmail | BetaWorkersVersionsGetResponseBindingsItemService | BetaWorkersVersionsGetResponseBindingsItemTextBlob | BetaWorkersVersionsGetResponseBindingsItemVectorize | BetaWorkersVersionsGetResponseBindingsItemVersionMetadata | BetaWorkersVersionsGetResponseBindingsItemSecretsStoreSecret | BetaWorkersVersionsGetResponseBindingsItemFlagship | BetaWorkersVersionsGetResponseBindingsItemSecretKey | BetaWorkersVersionsGetResponseBindingsItemWorkflow | BetaWorkersVersionsGetResponseBindingsItemWasmModule | BetaWorkersVersionsGetResponseBindingsItemVPCService | BetaWorkersVersionsGetResponseBindingsItemVPCNetwork;
export declare const BetaWorkersVersionsGetResponseBindingsItem: any;
export type BetaWorkersVersionsGetResponseBindingsList = Array<BetaWorkersVersionsGetResponseBindingsItem>;
export declare const BetaWorkersVersionsGetResponseBindingsList: S.Schema<BetaWorkersVersionsGetResponseBindingsList>;
export type BetaWorkersVersionsGetResponseCacheOptions = BetaWorkersVersionsCreateResponseCacheOptions;
export declare const BetaWorkersVersionsGetResponseCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type BetaWorkersVersionsGetResponseCompatibilityFlagsList = Array<string>;
export declare const BetaWorkersVersionsGetResponseCompatibilityFlagsList: S.Schema<BetaWorkersVersionsGetResponseCompatibilityFlagsList>;
export type BetaWorkersVersionsGetResponseContainersItem = BetaWorkersVersionsCreateRequestContainersItem;
export declare const BetaWorkersVersionsGetResponseContainersItem: S.Schema<BetaWorkersVersionsCreateRequestContainersItem>;
export type BetaWorkersVersionsGetResponseContainersList = Array<BetaWorkersVersionsCreateRequestContainersItem>;
export declare const BetaWorkersVersionsGetResponseContainersList: S.Schema<BetaWorkersVersionsGetResponseContainersList>;
export type BetaWorkersVersionsGetResponseLimits = BetaWorkersVersionsCreateResponseLimits;
export declare const BetaWorkersVersionsGetResponseLimits: S.Schema<BetaWorkersVersionsCreateResponseLimits>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationDeletedClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationDeletedClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesList>;
export interface BetaWorkersVersionsGetResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsGetResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export declare const BetaWorkersVersionsGetResponseMigrationsSingleStepMigration: S.Schema<BetaWorkersVersionsGetResponseMigrationsSingleStepMigration>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export declare const BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrations: S.Schema<BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrations>;
export type BetaWorkersVersionsGetResponseMigrations = BetaWorkersVersionsGetResponseMigrationsSingleStepMigration | BetaWorkersVersionsGetResponseMigrationsWorkersMultipleStepMigrations;
export declare const BetaWorkersVersionsGetResponseMigrations: any;
export type BetaWorkersVersionsGetResponseModulesItem = BetaWorkersVersionsCreateRequestModulesItem;
export declare const BetaWorkersVersionsGetResponseModulesItem: S.Schema<BetaWorkersVersionsCreateRequestModulesItem>;
export type BetaWorkersVersionsGetResponseModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export declare const BetaWorkersVersionsGetResponseModulesList: S.Schema<BetaWorkersVersionsGetResponseModulesList>;
export type BetaWorkersVersionsGetResponsePackageDependenciesItem = BetaWorkersVersionsCreateRequestPackageDependenciesItem;
export declare const BetaWorkersVersionsGetResponsePackageDependenciesItem: S.Schema<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsGetResponsePackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export declare const BetaWorkersVersionsGetResponsePackageDependenciesList: S.Schema<BetaWorkersVersionsGetResponsePackageDependenciesList>;
export type BetaWorkersVersionsGetResponsePlacementModeMode = "smart";
export declare const BetaWorkersVersionsGetResponsePlacementModeMode: any;
export interface BetaWorkersVersionsGetResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsGetResponsePlacementModeMode;
}
export declare const BetaWorkersVersionsGetResponsePlacementMode: S.Schema<BetaWorkersVersionsGetResponsePlacementMode>;
export type BetaWorkersVersionsGetResponsePlacementRegion = BetaWorkersVersionsCreateRequestPlacementRegion;
export declare const BetaWorkersVersionsGetResponsePlacementRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementRegion>;
export type BetaWorkersVersionsGetResponsePlacementHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const BetaWorkersVersionsGetResponsePlacementHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type BetaWorkersVersionsGetResponsePlacementHost = BetaWorkersVersionsCreateRequestPlacementHost;
export declare const BetaWorkersVersionsGetResponsePlacementHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementHost>;
export type BetaWorkersVersionsGetResponsePlacementCase4Mode = "targeted";
export declare const BetaWorkersVersionsGetResponsePlacementCase4Mode: any;
export interface BetaWorkersVersionsGetResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const BetaWorkersVersionsGetResponsePlacementCase4: S.Schema<BetaWorkersVersionsGetResponsePlacementCase4>;
export type BetaWorkersVersionsGetResponsePlacementCase5Mode = "targeted";
export declare const BetaWorkersVersionsGetResponsePlacementCase5Mode: any;
export interface BetaWorkersVersionsGetResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase5Mode;
}
export declare const BetaWorkersVersionsGetResponsePlacementCase5: S.Schema<BetaWorkersVersionsGetResponsePlacementCase5>;
export type BetaWorkersVersionsGetResponsePlacementCase6Mode = "targeted";
export declare const BetaWorkersVersionsGetResponsePlacementCase6Mode: any;
export interface BetaWorkersVersionsGetResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase6Mode;
}
export declare const BetaWorkersVersionsGetResponsePlacementCase6: S.Schema<BetaWorkersVersionsGetResponsePlacementCase6>;
export type BetaWorkersVersionsGetResponsePlacementCase7Mode = "targeted";
export declare const BetaWorkersVersionsGetResponsePlacementCase7Mode: any;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const BetaWorkersVersionsGetResponsePlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const BetaWorkersVersionsGetResponsePlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const BetaWorkersVersionsGetResponsePlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const BetaWorkersVersionsGetResponsePlacementCase7TargetItem: any;
export type BetaWorkersVersionsGetResponsePlacementCase7TargetList = Array<BetaWorkersVersionsGetResponsePlacementCase7TargetItem>;
export declare const BetaWorkersVersionsGetResponsePlacementCase7TargetList: S.Schema<BetaWorkersVersionsGetResponsePlacementCase7TargetList>;
export interface BetaWorkersVersionsGetResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsGetResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsGetResponsePlacementCase7TargetList;
}
export declare const BetaWorkersVersionsGetResponsePlacementCase7: S.Schema<BetaWorkersVersionsGetResponsePlacementCase7>;
export type BetaWorkersVersionsGetResponsePlacement = BetaWorkersVersionsGetResponsePlacementMode | BetaWorkersVersionsCreateRequestPlacementRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementHost | BetaWorkersVersionsGetResponsePlacementCase4 | BetaWorkersVersionsGetResponsePlacementCase5 | BetaWorkersVersionsGetResponsePlacementCase6 | BetaWorkersVersionsGetResponsePlacementCase7;
export declare const BetaWorkersVersionsGetResponsePlacement: any;
export type BetaWorkersVersionsGetResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const BetaWorkersVersionsGetResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBetaWorkerVersionResponse {
    /** Version identifier. */
    id: string;
    /** When the version was created. */
    createdOn: string;
    /** The integer version number, starting from one. */
    number: number;
    /** All routable URLs that always point to this version. Does not include alias URLs, since aliases can be updated to point to a different version. */
    urls: BetaWorkersVersionsGetResponseUrlsList;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateResponseAnnotations | null;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsGetResponseAssets | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsGetResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsGetResponseCompatibilityFlagsList | null;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsGetResponseContainersList | null;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateResponseLimits | null;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string | null;
    /** Durable Object migration tag. Set when the version is deployed. Omitted if the version has not been deployed or the Worker does not use Durable Objects. */
    migrationTag?: string | null;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsGetResponseMigrations | null;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsGetResponseModulesList | null;
    /** The list of npm packages that were installed and used when this Worker */
    packageDependencies?: BetaWorkersVersionsGetResponsePackageDependenciesList | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsGetResponsePlacement | null;
    /** The client used to create the version. */
    source?: string | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsGetResponseUsageModel | null;
}
export declare const GetBetaWorkerVersionResponse: S.Schema<GetBetaWorkerVersionResponse>;
export interface GetDomainRequest {
    /** Identifier. */
    accountId: string;
    /** ID of the domain. */
    domainId: string;
}
export declare const GetDomainRequest: S.Schema<GetDomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDomainResponse {
    /** Immutable ID of the domain. */
    id: string;
    /** ID of the TLS certificate issued for the domain. */
    certId: string;
    /** Worker environment associated with the domain. */
    environment: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** ID of the zone containing the domain hostname. */
    zoneId: string;
    /** Name of the zone containing the domain hostname. */
    zoneName: string;
    /** Whether Worker Previews are served on this custom domain. */
    previewsEnabled?: boolean | null;
}
export declare const GetDomainResponse: S.Schema<GetDomainResponse>;
export type ObservabilitySharedQueriesGetRequestView = "events" | "invocations" | "calculations";
export declare const ObservabilitySharedQueriesGetRequestView: any;
export interface GetObservabilitySharedQueryRequest {
    accountId: string;
    /** Specify the ID of the shared query. */
    id: string;
    /** Select the view of the query result to return, defaults to events. */
    view?: ObservabilitySharedQueriesGetRequestView | (string & {});
}
export declare const GetObservabilitySharedQueryRequest: S.Schema<GetObservabilitySharedQueryRequest>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemOperator = "uniq" | "count" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "COUNT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemOperator: any;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemKeyType = "string" | "number" | "boolean";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemKeyType: any;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItem {
    operator: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemOperator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItemKeyType | null;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItem: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItem>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsItem>;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsList: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsList>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersDatasetsList = Array<string>;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersDatasetsList: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersDatasetsList>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFilterCombination: any;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FilterCombination: any;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FiltersList: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FiltersList>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0Kind = "group";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0Kind: any;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0 {
    filterCombination: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FilterCombination;
    filters: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0FiltersList;
    kind: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0Kind;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItem = ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemCase0 | ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItem: any;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersItem>;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersList: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersList>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItemType = "string" | "number" | "boolean";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItemType: any;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItem {
    type: ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItemType;
    value: string;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItem: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItem>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysItem>;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysList: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysList>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItemOperation: any;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItem {
    key: string;
    operation: ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItemOperation;
    value: number;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItem: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItem>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsList = Array<ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsItem>;
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsList: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsList>;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle {
    value: unknown;
    isRegex?: boolean | null;
    matchCase?: boolean | null;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle>;
export type ObservabilitySharedQueriesGetResponseRunQueryParametersOrderByOrder = "asc" | "desc";
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersOrderByOrder: any;
export interface ObservabilitySharedQueriesGetResponseRunQueryParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilitySharedQueriesGetResponseRunQueryParametersOrderByOrder | null;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParametersOrderBy: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersOrderBy>;
export interface ObservabilitySharedQueriesGetResponseRunQueryParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilitySharedQueriesGetResponseRunQueryParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilitySharedQueriesGetResponseRunQueryParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilitySharedQueriesGetResponseRunQueryParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilitySharedQueriesGetResponseRunQueryParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilitySharedQueriesGetResponseRunQueryParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilitySharedQueriesGetResponseRunQueryParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilitySharedQueriesGetResponseRunQueryParametersOrderBy | null;
}
export declare const ObservabilitySharedQueriesGetResponseRunQueryParameters: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParameters>;
export interface ObservabilitySharedQueriesGetResponseRunQuery {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilitySharedQueriesGetResponseRunQueryParameters;
    updated: string;
    updatedBy: string;
}
export declare const ObservabilitySharedQueriesGetResponseRunQuery: S.Schema<ObservabilitySharedQueriesGetResponseRunQuery>;
export type ObservabilitySharedQueriesGetResponseRunStatus = "STARTED" | "COMPLETED";
export declare const ObservabilitySharedQueriesGetResponseRunStatus: any;
export type ObservabilitySharedQueriesGetResponseRunTimeframe = ObservabilitySharedQueriesCreateRequestTimeframe;
export declare const ObservabilitySharedQueriesGetResponseRunTimeframe: S.Schema<ObservabilitySharedQueriesCreateRequestTimeframe>;
export interface ObservabilitySharedQueriesGetResponseRunStatistics {
    /** Number of uncompressed bytes read from the table. */
    bytesRead: number;
    /** Time in seconds for the query to run. */
    elapsed: number;
    /** Number of rows scanned from the table. */
    rowsRead: number;
    /** The level of Adaptive Bit Rate (ABR) sampling used for the query. If empty the ABR level is 1 */
    abrLevel?: number | null;
}
export declare const ObservabilitySharedQueriesGetResponseRunStatistics: S.Schema<ObservabilitySharedQueriesGetResponseRunStatistics>;
export interface ObservabilitySharedQueriesGetResponseRun {
    /** Unique identifier for this query run. */
    id: string;
    /** Cloudflare account ID that owns this query run. */
    accountId: string;
    /** Whether this was a dry run (results not persisted). */
    dry: boolean;
    /** Number of time-series buckets used for the query. Higher values produce more detailed series data. */
    granularity: number;
    /** A saved query definition with its parameters, metadata, and ownership information. */
    query: ObservabilitySharedQueriesGetResponseRunQuery;
    /** Current execution status of the query run. */
    status: ObservabilitySharedQueriesGetResponseRunStatus;
    /** Time range for the query execution */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** ID of the user who initiated the query run. */
    userId: string;
    /** ISO-8601 timestamp when the query run was created. */
    created?: string | null;
    /** Query performance statistics from the database (does not include network latency). */
    statistics?: ObservabilitySharedQueriesGetResponseRunStatistics | null;
    /** ISO-8601 timestamp when the query run was last updated. */
    updated?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseRun: S.Schema<ObservabilitySharedQueriesGetResponseRun>;
export type ObservabilitySharedQueriesGetResponseStatistics = ObservabilitySharedQueriesGetResponseRunStatistics;
export declare const ObservabilitySharedQueriesGetResponseStatistics: S.Schema<ObservabilitySharedQueriesGetResponseRunStatistics>;
export type ObservabilitySharedQueriesGetResponseAgentsItemEventTypeCountsMap = {
    [key: string]: number | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseAgentsItemEventTypeCountsMap: S.Schema<ObservabilitySharedQueriesGetResponseAgentsItemEventTypeCountsMap>;
export interface ObservabilitySharedQueriesGetResponseAgentsItem {
    /** Class name of the Durable Object agent. */
    agentClass: string;
    /** Breakdown of event counts by event type. */
    eventTypeCounts: ObservabilitySharedQueriesGetResponseAgentsItemEventTypeCountsMap;
    /** Timestamp of the earliest event from this agent in the queried window (Unix epoch ms). */
    firstEventMs: number;
    /** Whether the agent emitted any error events in the queried window. */
    hasErrors: boolean;
    /** Timestamp of the most recent event from this agent (Unix epoch ms). */
    lastEventMs: number;
    /** Durable Object namespace the agent belongs to. */
    namespace: string;
    /** Worker service name that hosts this agent. */
    service: string;
    /** Total number of events emitted by this agent in the queried window. */
    totalEvents: number;
}
export declare const ObservabilitySharedQueriesGetResponseAgentsItem: S.Schema<ObservabilitySharedQueriesGetResponseAgentsItem>;
export type ObservabilitySharedQueriesGetResponseAgentsList = Array<ObservabilitySharedQueriesGetResponseAgentsItem>;
export declare const ObservabilitySharedQueriesGetResponseAgentsList: S.Schema<ObservabilitySharedQueriesGetResponseAgentsList>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItemValue = string | number | boolean;
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItemValue: any;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItemValue;
}
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItem: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsItem>;
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsList: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsList>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    groups?: ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItemGroupsList | null;
}
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItem: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesItem>;
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesList: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesList>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItemValue: any;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItemValue;
}
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItem: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsItem>;
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsList: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsList>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItem: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataItem>;
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataList: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataList>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItem {
    data: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItemDataList;
    time: string;
}
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItem: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsItemSeriesList = Array<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesItem>;
export declare const ObservabilitySharedQueriesGetResponseCalculationsItemSeriesList: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItemSeriesList>;
export interface ObservabilitySharedQueriesGetResponseCalculationsItem {
    aggregates: ObservabilitySharedQueriesGetResponseCalculationsItemAggregatesList;
    calculation: string;
    series: ObservabilitySharedQueriesGetResponseCalculationsItemSeriesList;
    alias?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseCalculationsItem: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsItem>;
export type ObservabilitySharedQueriesGetResponseCalculationsList = Array<ObservabilitySharedQueriesGetResponseCalculationsItem>;
export declare const ObservabilitySharedQueriesGetResponseCalculationsList: S.Schema<ObservabilitySharedQueriesGetResponseCalculationsList>;
export type ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItemValue = string | number | boolean;
export declare const ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItemValue: any;
export interface ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItemValue;
}
export declare const ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItem: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItem>;
export type ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsItem>;
export declare const ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsList: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsList>;
export interface ObservabilitySharedQueriesGetResponseCompareItemAggregatesItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    groups?: ObservabilitySharedQueriesGetResponseCompareItemAggregatesItemGroupsList | null;
}
export declare const ObservabilitySharedQueriesGetResponseCompareItemAggregatesItem: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemAggregatesItem>;
export type ObservabilitySharedQueriesGetResponseCompareItemAggregatesList = Array<ObservabilitySharedQueriesGetResponseCompareItemAggregatesItem>;
export declare const ObservabilitySharedQueriesGetResponseCompareItemAggregatesList: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemAggregatesList>;
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export declare const ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItemValue: any;
export interface ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItemValue;
}
export declare const ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItem: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItem>;
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsList = Array<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsItem>;
export declare const ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsList: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsList>;
export interface ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItem: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItem>;
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataList = Array<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataItem>;
export declare const ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataList: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataList>;
export interface ObservabilitySharedQueriesGetResponseCompareItemSeriesItem {
    data: ObservabilitySharedQueriesGetResponseCompareItemSeriesItemDataList;
    time: string;
}
export declare const ObservabilitySharedQueriesGetResponseCompareItemSeriesItem: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemSeriesItem>;
export type ObservabilitySharedQueriesGetResponseCompareItemSeriesList = Array<ObservabilitySharedQueriesGetResponseCompareItemSeriesItem>;
export declare const ObservabilitySharedQueriesGetResponseCompareItemSeriesList: S.Schema<ObservabilitySharedQueriesGetResponseCompareItemSeriesList>;
export interface ObservabilitySharedQueriesGetResponseCompareItem {
    aggregates: ObservabilitySharedQueriesGetResponseCompareItemAggregatesList;
    calculation: string;
    series: ObservabilitySharedQueriesGetResponseCompareItemSeriesList;
    alias?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseCompareItem: S.Schema<ObservabilitySharedQueriesGetResponseCompareItem>;
export type ObservabilitySharedQueriesGetResponseCompareList = Array<ObservabilitySharedQueriesGetResponseCompareItem>;
export declare const ObservabilitySharedQueriesGetResponseCompareList: S.Schema<ObservabilitySharedQueriesGetResponseCompareList>;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata {
    /** Unique event ID. Use as the cursor value for offset-based pagination. */
    id: string;
    /** Cloudflare account identifier. */
    account?: string | null;
    /** Cloudflare product that generated this event (e.g. workers, pages). */
    cloudService?: string | null;
    coldStart?: number | null;
    /** Estimated cost units for this invocation. */
    cost?: number | null;
    /** Span duration in milliseconds. */
    duration?: number | null;
    /** Span end time as a Unix epoch in milliseconds. */
    endTime?: number | null;
    /** Error message, present when the log represents an error. */
    error?: string | null;
    /** Templatized version of the error message used for grouping similar errors. */
    errorTemplate?: string | null;
    /** Content-based fingerprint used to group similar events. */
    fingerprint?: string | null;
    /** Log level (e.g. log, debug, info, warn, error). */
    level?: string | null;
    /** Log message text. */
    message?: string | null;
    /** Templatized version of the log message used for grouping similar messages. */
    messageTemplate?: string | null;
    /** Metric name when the event represents a metric data point. */
    metricName?: string | null;
    /** Origin of the event (e.g. fetch, scheduled, queue). */
    origin?: string | null;
    /** Span ID of the parent span in the trace hierarchy. */
    parentSpanId?: string | null;
    /** Infrastructure provider identifier. */
    provider?: string | null;
    /** Cloudflare data center / region that handled the request. */
    region?: string | null;
    /** Cloudflare request ID that ties all logs from a single invocation together. */
    requestId?: string | null;
    /** Worker script name that produced this event. */
    service?: string | null;
    /** Span ID for this individual unit of work within a trace. */
    spanId?: string | null;
    /** Human-readable name for this span. */
    spanName?: string | null;
    /** Stack / deployment identifier. */
    stackId?: string | null;
    /** Span start time as a Unix epoch in milliseconds. */
    startTime?: number | null;
    /** HTTP response status code returned by the Worker. */
    statusCode?: number | null;
    /** Total duration of the entire trace in milliseconds. */
    traceDuration?: number | null;
    /** Distributed trace ID linking spans across services. */
    traceId?: string | null;
    /** Logical transaction name for this request. */
    transactionName?: string | null;
    /** What triggered the invocation (e.g. GET /users, POST /orders, queue message). */
    trigger?: string | null;
    /** Event type classifier (e.g. cf-worker-event, cf-worker-log). */
    type?: string | null;
    /** Request URL that triggered the Worker invocation. */
    url?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemSourceCase1Map: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemSourceCase1Map>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemSource = string | ObservabilitySharedQueriesGetResponseEventsEventsItemSourceCase1Map;
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemSource: any;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemContainersMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemContainersMap: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemContainersMap>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventType: any;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventMap: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventMap>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ExecutionModel: any;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview {
    id?: string | null;
    name?: string | null;
    slug?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion {
    id?: string | null;
    message?: string | null;
    tag?: string | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0 {
    eventType: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventType;
    requestId: string;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventType: any;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem {
    channel: string;
    message: string;
    timestamp: number;
}
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventMap: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventMap>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ExecutionModel: any;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventType;
    outcome: string;
    requestId: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1>;
export type ObservabilitySharedQueriesGetResponseEventsEventsItemWorkers = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0 | ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1;
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItemWorkers: any;
export interface ObservabilitySharedQueriesGetResponseEventsEventsItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilitySharedQueriesGetResponseEventsEventsItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilitySharedQueriesGetResponseEventsEventsItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkers | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsEventsItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItem>;
export type ObservabilitySharedQueriesGetResponseEventsEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItem>;
export declare const ObservabilitySharedQueriesGetResponseEventsEventsList: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsList>;
export interface ObservabilitySharedQueriesGetResponseEventsFieldsItem {
    /** Field name present in the matched events. */
    key: string;
    /** Data type of the field (string, number, or boolean). */
    type: string;
}
export declare const ObservabilitySharedQueriesGetResponseEventsFieldsItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsFieldsItem>;
export type ObservabilitySharedQueriesGetResponseEventsFieldsList = Array<ObservabilitySharedQueriesGetResponseEventsFieldsItem>;
export declare const ObservabilitySharedQueriesGetResponseEventsFieldsList: S.Schema<ObservabilitySharedQueriesGetResponseEventsFieldsList>;
export interface ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates {
    count: number;
    interval: number;
    firstSeen?: string | null;
    lastSeen?: string | null;
    bin?: unknown | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates: S.Schema<ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates>;
export type ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemGroups = string | number | boolean;
export declare const ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemGroups: any;
export interface ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItem {
    aggregates: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates;
    count: number;
    interval: number;
    sampleInterval: number;
    errors?: number | null;
    /** Groups in the query results. */
    groups?: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemGroups | null;
}
export declare const ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItem>;
export type ObservabilitySharedQueriesGetResponseEventsSeriesItemDataList = Array<ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItem>;
export declare const ObservabilitySharedQueriesGetResponseEventsSeriesItemDataList: S.Schema<ObservabilitySharedQueriesGetResponseEventsSeriesItemDataList>;
export interface ObservabilitySharedQueriesGetResponseEventsSeriesItem {
    data: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataList;
    time: string;
}
export declare const ObservabilitySharedQueriesGetResponseEventsSeriesItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsSeriesItem>;
export type ObservabilitySharedQueriesGetResponseEventsSeriesList = Array<ObservabilitySharedQueriesGetResponseEventsSeriesItem>;
export declare const ObservabilitySharedQueriesGetResponseEventsSeriesList: S.Schema<ObservabilitySharedQueriesGetResponseEventsSeriesList>;
export interface ObservabilitySharedQueriesGetResponseEvents {
    /** Total number of events matching the query (may exceed the number returned due to limits). */
    count?: number | null;
    /** List of individual telemetry events matching the query. */
    events?: ObservabilitySharedQueriesGetResponseEventsEventsList | null;
    /** List of fields discovered in the matched events. Useful for building dynamic UIs. */
    fields?: ObservabilitySharedQueriesGetResponseEventsFieldsList | null;
    /** Time-series data for the matched events, bucketed by the query granularity. */
    series?: ObservabilitySharedQueriesGetResponseEventsSeriesList | null;
}
export declare const ObservabilitySharedQueriesGetResponseEvents: S.Schema<ObservabilitySharedQueriesGetResponseEvents>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemMetadata = ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemMetadata: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemSourceCase1Map: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItemSourceCase1Map>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemSource = string | ObservabilitySharedQueriesGetResponseInvocationsValueItemSourceCase1Map;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemSource: any;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemContainersMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemContainersMap: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItemContainersMap>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventType: any;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventMap: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventMap>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ExecutionModel: any;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0 {
    eventType: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventType;
    requestId: string;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventType: any;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsItem = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventMap: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventMap>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ExecutionModel: any;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventType;
    outcome: string;
    requestId: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1EventMap | null;
    executionModel?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkers = ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase0 | ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkersCase1;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkers: any;
export interface ObservabilitySharedQueriesGetResponseInvocationsValueItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilitySharedQueriesGetResponseInvocationsValueItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilitySharedQueriesGetResponseInvocationsValueItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilitySharedQueriesGetResponseInvocationsValueItemWorkers | null;
}
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueItem: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueItem>;
export type ObservabilitySharedQueriesGetResponseInvocationsValueList = Array<ObservabilitySharedQueriesGetResponseInvocationsValueItem>;
export declare const ObservabilitySharedQueriesGetResponseInvocationsValueList: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsValueList>;
export type ObservabilitySharedQueriesGetResponseInvocationsMap = {
    [key: string]: ObservabilitySharedQueriesGetResponseInvocationsValueList | undefined;
};
export declare const ObservabilitySharedQueriesGetResponseInvocationsMap: S.Schema<ObservabilitySharedQueriesGetResponseInvocationsMap>;
export type ObservabilitySharedQueriesGetResponseTracesItemServiceList = Array<string>;
export declare const ObservabilitySharedQueriesGetResponseTracesItemServiceList: S.Schema<ObservabilitySharedQueriesGetResponseTracesItemServiceList>;
export type ObservabilitySharedQueriesGetResponseTracesItemErrorsList = Array<string>;
export declare const ObservabilitySharedQueriesGetResponseTracesItemErrorsList: S.Schema<ObservabilitySharedQueriesGetResponseTracesItemErrorsList>;
export interface ObservabilitySharedQueriesGetResponseTracesItem {
    /** Name of the root span that initiated the trace. */
    rootSpanName: string;
    /** Logical transaction name for the root span. */
    rootTransactionName: string;
    /** List of Worker services involved in the trace. */
    service: ObservabilitySharedQueriesGetResponseTracesItemServiceList;
    /** Total number of spans in the trace. */
    spans: number;
    /** Total duration of the trace in milliseconds. */
    traceDurationMs: number;
    /** Trace end time as a Unix epoch in milliseconds. */
    traceEndMs: number;
    /** Unique identifier for the distributed trace. */
    traceId: string;
    /** Trace start time as a Unix epoch in milliseconds. */
    traceStartMs: number;
    /** Error messages encountered during the trace, if any. */
    errors?: ObservabilitySharedQueriesGetResponseTracesItemErrorsList | null;
}
export declare const ObservabilitySharedQueriesGetResponseTracesItem: S.Schema<ObservabilitySharedQueriesGetResponseTracesItem>;
export type ObservabilitySharedQueriesGetResponseTracesList = Array<ObservabilitySharedQueriesGetResponseTracesItem>;
export declare const ObservabilitySharedQueriesGetResponseTracesList: S.Schema<ObservabilitySharedQueriesGetResponseTracesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetObservabilitySharedQueryResponse {
    /** Represents a single execution of a query against Workers Observability data, including the query definition, execution status, and performance statistics. */
    run: ObservabilitySharedQueriesGetResponseRun;
    /** Query performance statistics from the database. Includes execution time, rows scanned, and bytes read. Does not include network latency. */
    statistics: ObservabilitySharedQueriesGetResponseRunStatistics;
    /** Durable Object agent summaries. Present when the query view is 'agents'. Each entry represents an agent with its event counts and status. */
    agents?: ObservabilitySharedQueriesGetResponseAgentsList | null;
    /** Aggregated calculation results. Present when the query view is 'calculations'. Contains computed metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series data. */
    calculations?: ObservabilitySharedQueriesGetResponseCalculationsList | null;
    /** Comparison calculation results from the previous time period. Present when the compare option is enabled. Same structure as calculations. */
    compare?: ObservabilitySharedQueriesGetResponseCompareList | null;
    /** Individual event results. Present when the query view is 'events'. Contains the matching log lines and their metadata. */
    events?: ObservabilitySharedQueriesGetResponseEvents | null;
    /** Events grouped by invocation (request ID). Present when the query view is 'invocations'. Each key is a request ID mapping to all events from that invocation. */
    invocations?: ObservabilitySharedQueriesGetResponseInvocationsMap | null;
    /** Trace summaries matching the query. Present when the query view is 'traces'. Each entry represents a distributed trace with its spans, duration, and services involved. */
    traces?: ObservabilitySharedQueriesGetResponseTracesList | null;
}
export declare const GetObservabilitySharedQueryResponse: S.Schema<GetObservabilitySharedQueryResponse>;
export interface GetPreviewRequest {
    accountId: string;
    /** Parent Worker id or script name. */
    workerId: string;
    /** Preview id or name. */
    previewId: string;
}
export declare const GetPreviewRequest: S.Schema<GetPreviewRequest>;
export interface GetPreviewDeploymentRequest {
    accountId: string;
    workerId: string;
    previewId: string;
    /** Deployment id, or `latest`. */
    deploymentId: string;
}
export declare const GetPreviewDeploymentRequest: S.Schema<GetPreviewDeploymentRequest>;
export interface GetRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    routeId: string;
}
export declare const GetRouteRequest: S.Schema<GetRouteRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRouteResponse {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export declare const GetRouteResponse: S.Schema<GetRouteResponse>;
export interface GetScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetScriptRequest: S.Schema<GetScriptRequest>;
export interface GetScriptResponse {
}
export declare const GetScriptResponse: S.Schema<GetScriptResponse>;
export interface GetScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetScriptContentRequest: S.Schema<GetScriptContentRequest>;
export interface GetScriptContentResponse {
}
export declare const GetScriptContentResponse: S.Schema<GetScriptContentResponse>;
export interface GetScriptDeploymentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    deploymentId: string;
}
export declare const GetScriptDeploymentRequest: S.Schema<GetScriptDeploymentRequest>;
export type ScriptsDeploymentsGetResponseStrategy = "percentage";
export declare const ScriptsDeploymentsGetResponseStrategy: any;
export type ScriptsDeploymentsGetResponseVersionsItem = ScriptsDeploymentsCreateRequestVersionsItem;
export declare const ScriptsDeploymentsGetResponseVersionsItem: S.Schema<ScriptsDeploymentsCreateRequestVersionsItem>;
export type ScriptsDeploymentsGetResponseVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export declare const ScriptsDeploymentsGetResponseVersionsList: S.Schema<ScriptsDeploymentsGetResponseVersionsList>;
export type ScriptsDeploymentsGetResponseAnnotations = ScriptsDeploymentsCreateResponseAnnotations;
export declare const ScriptsDeploymentsGetResponseAnnotations: S.Schema<ScriptsDeploymentsCreateResponseAnnotations>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptDeploymentResponse {
    id: string;
    createdOn: string;
    source: string;
    strategy: ScriptsDeploymentsGetResponseStrategy;
    versions: ScriptsDeploymentsGetResponseVersionsList;
    annotations?: ScriptsDeploymentsCreateResponseAnnotations | null;
    authorEmail?: string | null;
}
export declare const GetScriptDeploymentResponse: S.Schema<GetScriptDeploymentResponse>;
export interface GetScriptScheduleRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetScriptScheduleRequest: S.Schema<GetScriptScheduleRequest>;
export interface ScriptsSchedulesGetResponseSchedulesItem {
    cron: string;
    createdOn?: string | null;
    modifiedOn?: string | null;
}
export declare const ScriptsSchedulesGetResponseSchedulesItem: S.Schema<ScriptsSchedulesGetResponseSchedulesItem>;
export type ScriptsSchedulesGetResponseSchedulesList = Array<ScriptsSchedulesGetResponseSchedulesItem>;
export declare const ScriptsSchedulesGetResponseSchedulesList: S.Schema<ScriptsSchedulesGetResponseSchedulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptScheduleResponse {
    schedules: ScriptsSchedulesGetResponseSchedulesList;
}
export declare const GetScriptScheduleResponse: S.Schema<GetScriptScheduleResponse>;
export interface GetScriptScriptAndVersionSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetScriptScriptAndVersionSettingRequest: S.Schema<GetScriptScriptAndVersionSettingRequest>;
export interface ScriptsScriptAndVersionSettingsGetResponseAnnotations {
    /** Human-readable message about the version. Truncated to 1000 bytes if longer. */
    workersMessage?: string | null;
    /** User-provided identifier for the version. Maximum 100 bytes. */
    workersTag?: string | null;
    /** Operation that triggered the creation of the version. This is read-only and set by the server. */
    workersTriggeredBy?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseAnnotations: S.Schema<ScriptsScriptAndVersionSettingsGetResponseAnnotations>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAIType = "ai";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAIType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAIType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAI: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemAI>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchType = "ai_search";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearch: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearch>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespaceType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespaceType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespace: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespace>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngineType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngineType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngine: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngine>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssetsType = "assets";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssetsType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssetsType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssets: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssets>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowserType = "browser";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowserType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowserType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowser: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowser>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1Type = "d1";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1Type: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlobType = "data_blob";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlobType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlobType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlob: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlob>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceType: any;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker>;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutbound: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutbound>;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespaceOutbound | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespace: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespace>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespaceType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespace: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespace>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdriveType = "hyperdrive";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdriveType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdriveType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdrive: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdrive>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemInheritType = "inherit";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemInheritType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemInherit: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemInherit>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemImagesType = "images";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemImagesType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemImagesType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemImages: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemImages>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemJsonType = "json";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemJsonType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemJsonType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemJson: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemJson>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespaceType = "kv_namespace";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespaceType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespaceType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespace: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespace>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemMediaType = "media";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemMediaType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemMediaType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemMedia: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemMedia>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificateType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificateType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificate: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificate>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainTextType = "plain_text";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainTextType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainTextType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainText: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainText>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelinesType = "pipelines";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelinesType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelinesType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelines: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelines>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueueType = "queue";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueueType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueueType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueue: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueue>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitType = "ratelimit";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimitType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimit: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimit>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketType = "r2_bucket";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketType: any;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketJurisdiction: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2BucketJurisdiction | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2Bucket: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2Bucket>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretTextType = "secret_text";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretTextType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretTextType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretText: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretText>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailType = "send_email";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailType: any;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList>;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmail: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmail>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemServiceType = "service";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemServiceType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemService: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemService>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlobType = "text_blob";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlobType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlobType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlob: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlob>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorizeType = "vectorize";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorizeType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorizeType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorize: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorize>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadataType = "version_metadata";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadataType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadataType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadata: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadata>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecretType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecretType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecret: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecret>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagshipType = "flagship";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagshipType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagshipType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagship: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagship>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyFormat: any;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyType = "secret_key";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyType: any;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesItem: any;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesList = Array<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesList>;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKey: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKey>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflowType = "workflow";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflowType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflow: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflow>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModuleType = "wasm_module";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModuleType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModuleType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModule: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModule>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCServiceType = "vpc_service";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCServiceType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCServiceType;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCService: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCService>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetworkType = "vpc_network";
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetworkType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetwork: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetwork>;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsItem = ScriptsScriptAndVersionSettingsGetResponseBindingsItemAI | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearch | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAISearchNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAnalyticsEngine | ScriptsScriptAndVersionSettingsGetResponseBindingsItemAssets | ScriptsScriptAndVersionSettingsGetResponseBindingsItemBrowser | ScriptsScriptAndVersionSettingsGetResponseBindingsItemD1 | ScriptsScriptAndVersionSettingsGetResponseBindingsItemDataBlob | ScriptsScriptAndVersionSettingsGetResponseBindingsItemDispatchNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemDurableObjectNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemHyperdrive | ScriptsScriptAndVersionSettingsGetResponseBindingsItemInherit | ScriptsScriptAndVersionSettingsGetResponseBindingsItemImages | ScriptsScriptAndVersionSettingsGetResponseBindingsItemJson | ScriptsScriptAndVersionSettingsGetResponseBindingsItemKVNamespace | ScriptsScriptAndVersionSettingsGetResponseBindingsItemMedia | ScriptsScriptAndVersionSettingsGetResponseBindingsItemMTLSCertificate | ScriptsScriptAndVersionSettingsGetResponseBindingsItemPlainText | ScriptsScriptAndVersionSettingsGetResponseBindingsItemPipelines | ScriptsScriptAndVersionSettingsGetResponseBindingsItemQueue | ScriptsScriptAndVersionSettingsGetResponseBindingsItemRatelimit | ScriptsScriptAndVersionSettingsGetResponseBindingsItemR2Bucket | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretText | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSendEmail | ScriptsScriptAndVersionSettingsGetResponseBindingsItemService | ScriptsScriptAndVersionSettingsGetResponseBindingsItemTextBlob | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVectorize | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVersionMetadata | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretsStoreSecret | ScriptsScriptAndVersionSettingsGetResponseBindingsItemFlagship | ScriptsScriptAndVersionSettingsGetResponseBindingsItemSecretKey | ScriptsScriptAndVersionSettingsGetResponseBindingsItemWorkflow | ScriptsScriptAndVersionSettingsGetResponseBindingsItemWasmModule | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCService | ScriptsScriptAndVersionSettingsGetResponseBindingsItemVPCNetwork;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsItem: any;
export type ScriptsScriptAndVersionSettingsGetResponseBindingsList = Array<ScriptsScriptAndVersionSettingsGetResponseBindingsItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseBindingsList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseBindingsList>;
export type ScriptsScriptAndVersionSettingsGetResponseCacheOptions = BetaWorkersVersionsCreateResponseCacheOptions;
export declare const ScriptsScriptAndVersionSettingsGetResponseCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type ScriptsScriptAndVersionSettingsGetResponseCompatibilityFlagsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseCompatibilityFlagsList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseCompatibilityFlagsList>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsValueType = "worker" | "durable-object";
export declare const ScriptsScriptAndVersionSettingsGetResponseExportsValueType: any;
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValueCache {
    /** Whether caching is enabled for this entrypoint. */
    enabled: boolean;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseExportsValueCache: S.Schema<ScriptsScriptAndVersionSettingsGetResponseExportsValueCache>;
export interface ScriptsScriptAndVersionSettingsGetResponseExportsValue {
    /** The kind of export. */
    type: ScriptsScriptAndVersionSettingsGetResponseExportsValueType;
    /** Cache override for this entrypoint. It applies only to */
    cache?: ScriptsScriptAndVersionSettingsGetResponseExportsValueCache | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseExportsValue: S.Schema<ScriptsScriptAndVersionSettingsGetResponseExportsValue>;
export type ScriptsScriptAndVersionSettingsGetResponseExportsMap = {
    [key: string]: ScriptsScriptAndVersionSettingsGetResponseExportsValue | undefined;
};
export declare const ScriptsScriptAndVersionSettingsGetResponseExportsMap: S.Schema<ScriptsScriptAndVersionSettingsGetResponseExportsMap>;
export interface ScriptsScriptAndVersionSettingsGetResponseLimits {
    /** The amount of CPU time this Worker can use in milliseconds. */
    cpuMs?: number | null;
    /** The number of subrequests this Worker can make per request. */
    subrequests?: number | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseLimits: S.Schema<ScriptsScriptAndVersionSettingsGetResponseLimits>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList>;
export interface ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigration: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigration>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrations: S.Schema<ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrations>;
export type ScriptsScriptAndVersionSettingsGetResponseMigrations = ScriptsScriptAndVersionSettingsGetResponseMigrationsSingleStepMigration | ScriptsScriptAndVersionSettingsGetResponseMigrationsWorkersMultipleStepMigrations;
export declare const ScriptsScriptAndVersionSettingsGetResponseMigrations: any;
export type ScriptsScriptAndVersionSettingsGetResponseObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseObservabilityLogsDestinationsList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseObservabilityLogsDestinationsList>;
export interface ScriptsScriptAndVersionSettingsGetResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsGetResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseObservabilityLogs: S.Schema<ScriptsScriptAndVersionSettingsGetResponseObservabilityLogs>;
export type ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesDestinationsList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesDestinationsList>;
export type ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesPropagationPolicy: any;
export interface ScriptsScriptAndVersionSettingsGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsScriptAndVersionSettingsGetResponseObservabilityTracesPropagationPolicy | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseObservabilityTraces: S.Schema<ScriptsScriptAndVersionSettingsGetResponseObservabilityTraces>;
export interface ScriptsScriptAndVersionSettingsGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: ScriptsScriptAndVersionSettingsGetResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsScriptAndVersionSettingsGetResponseObservabilityTraces | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseObservability: S.Schema<ScriptsScriptAndVersionSettingsGetResponseObservability>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementModeMode = "smart";
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementModeMode: any;
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementModeMode;
}
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementMode: S.Schema<ScriptsScriptAndVersionSettingsGetResponsePlacementMode>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementRegion = BetaWorkersVersionsCreateRequestPlacementRegion;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementRegion>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementHost = BetaWorkersVersionsCreateRequestPlacementHost;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementHost>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase4Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase4Mode: any;
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase4: S.Schema<ScriptsScriptAndVersionSettingsGetResponsePlacementCase4>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase5Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase5Mode: any;
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase5Mode;
}
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase5: S.Schema<ScriptsScriptAndVersionSettingsGetResponsePlacementCase5>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase6Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase6Mode: any;
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase6Mode;
}
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase6: S.Schema<ScriptsScriptAndVersionSettingsGetResponsePlacementCase6>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase7Mode: any;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItem: any;
export type ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetList = Array<ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetList: S.Schema<ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetList>;
export interface ScriptsScriptAndVersionSettingsGetResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsGetResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsScriptAndVersionSettingsGetResponsePlacementCase7TargetList;
}
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacementCase7: S.Schema<ScriptsScriptAndVersionSettingsGetResponsePlacementCase7>;
export type ScriptsScriptAndVersionSettingsGetResponsePlacement = ScriptsScriptAndVersionSettingsGetResponsePlacementMode | BetaWorkersVersionsCreateRequestPlacementRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementHost | ScriptsScriptAndVersionSettingsGetResponsePlacementCase4 | ScriptsScriptAndVersionSettingsGetResponsePlacementCase5 | ScriptsScriptAndVersionSettingsGetResponsePlacementCase6 | ScriptsScriptAndVersionSettingsGetResponsePlacementCase7;
export declare const ScriptsScriptAndVersionSettingsGetResponsePlacement: any;
export type ScriptsScriptAndVersionSettingsGetResponseTagsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsGetResponseTagsList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTagsList>;
export interface ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem {
    /** Name of Worker that is to be the consumer. */
    service: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
    /** Optional dispatch namespace the script belongs to. */
    namespace?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsScriptAndVersionSettingsGetResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export declare const ScriptsScriptAndVersionSettingsGetResponseTailConsumersList: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersList>;
export type ScriptsScriptAndVersionSettingsGetResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const ScriptsScriptAndVersionSettingsGetResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptScriptAndVersionSettingResponse {
    /** Annotations for the Worker version. Annotations are not inherited across settings updates; omitting this field means the new version will have no annotations. */
    annotations?: ScriptsScriptAndVersionSettingsGetResponseAnnotations | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: ScriptsScriptAndVersionSettingsGetResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsScriptAndVersionSettingsGetResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries */
    exports?: ScriptsScriptAndVersionSettingsGetResponseExportsMap | null;
    /** Limits to apply for this Worker. */
    limits?: ScriptsScriptAndVersionSettingsGetResponseLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: ScriptsScriptAndVersionSettingsGetResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsScriptAndVersionSettingsGetResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsScriptAndVersionSettingsGetResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsScriptAndVersionSettingsGetResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsScriptAndVersionSettingsGetResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsScriptAndVersionSettingsGetResponseUsageModel | null;
}
export declare const GetScriptScriptAndVersionSettingResponse: S.Schema<GetScriptScriptAndVersionSettingResponse>;
export interface GetScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A JavaScript variable name for the secret binding. */
    secretName: string;
    /** Flag that indicates whether the secret name is URL encoded. */
    urlEncoded?: boolean;
}
export declare const GetScriptSecretRequest: S.Schema<GetScriptSecretRequest>;
export type ScriptsSecretsGetResultSecretTextType = "secret_text";
export declare const ScriptsSecretsGetResultSecretTextType: any;
export interface ScriptsSecretsGetResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsGetResultSecretTextType;
}
export declare const ScriptsSecretsGetResultSecretText: S.Schema<ScriptsSecretsGetResultSecretText>;
export type ScriptsSecretsGetResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsSecretsGetResultSecretKeyFormat: any;
export type ScriptsSecretsGetResultSecretKeyType = "secret_key";
export declare const ScriptsSecretsGetResultSecretKeyType: any;
export type ScriptsSecretsGetResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsSecretsGetResultSecretKeyUsagesItem: any;
export type ScriptsSecretsGetResultSecretKeyUsagesList = Array<ScriptsSecretsGetResultSecretKeyUsagesItem>;
export declare const ScriptsSecretsGetResultSecretKeyUsagesList: S.Schema<ScriptsSecretsGetResultSecretKeyUsagesList>;
export interface ScriptsSecretsGetResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsGetResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsGetResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsGetResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsSecretsGetResultSecretKey: S.Schema<ScriptsSecretsGetResultSecretKey>;
export type ScriptsSecretsGetResult = ScriptsSecretsGetResultSecretText | ScriptsSecretsGetResultSecretKey;
export declare const ScriptsSecretsGetResult: any;
export type GetScriptSecretResponse = ScriptsSecretsGetResult;
export declare const GetScriptSecretResponse: S.Schema<GetScriptSecretResponse>;
export interface GetScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetScriptSettingRequest: S.Schema<GetScriptSettingRequest>;
export type ScriptsSettingsGetResponseObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsSettingsGetResponseObservabilityLogsDestinationsList: S.Schema<ScriptsSettingsGetResponseObservabilityLogsDestinationsList>;
export interface ScriptsSettingsGetResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsSettingsGetResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const ScriptsSettingsGetResponseObservabilityLogs: S.Schema<ScriptsSettingsGetResponseObservabilityLogs>;
export type ScriptsSettingsGetResponseObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsSettingsGetResponseObservabilityTracesDestinationsList: S.Schema<ScriptsSettingsGetResponseObservabilityTracesDestinationsList>;
export type ScriptsSettingsGetResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsSettingsGetResponseObservabilityTracesPropagationPolicy: any;
export interface ScriptsSettingsGetResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsSettingsGetResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsSettingsGetResponseObservabilityTracesPropagationPolicy | null;
}
export declare const ScriptsSettingsGetResponseObservabilityTraces: S.Schema<ScriptsSettingsGetResponseObservabilityTraces>;
export interface ScriptsSettingsGetResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: ScriptsSettingsGetResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsSettingsGetResponseObservabilityTraces | null;
}
export declare const ScriptsSettingsGetResponseObservability: S.Schema<ScriptsSettingsGetResponseObservability>;
export type ScriptsSettingsGetResponseTagsList = Array<string>;
export declare const ScriptsSettingsGetResponseTagsList: S.Schema<ScriptsSettingsGetResponseTagsList>;
export type ScriptsSettingsGetResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export declare const ScriptsSettingsGetResponseTailConsumersItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsSettingsGetResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export declare const ScriptsSettingsGetResponseTailConsumersList: S.Schema<ScriptsSettingsGetResponseTailConsumersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptSettingResponse {
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsSettingsGetResponseObservability | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsSettingsGetResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsSettingsGetResponseTailConsumersList | null;
}
export declare const GetScriptSettingResponse: S.Schema<GetScriptSettingResponse>;
export interface GetScriptSubdomainRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetScriptSubdomainRequest: S.Schema<GetScriptSubdomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptSubdomainResponse {
    /** Whether the Worker is available on the workers.dev subdomain. */
    enabled: boolean;
    /** Whether the Worker's Preview URLs are available on the workers.dev subdomain. */
    previewsEnabled: boolean;
}
export declare const GetScriptSubdomainResponse: S.Schema<GetScriptSubdomainResponse>;
export interface GetScriptTailRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const GetScriptTailRequest: S.Schema<GetScriptTailRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptTailResponse {
    /** Identifier. */
    id: string;
    expiresAt: string;
    url: string;
}
export declare const GetScriptTailResponse: S.Schema<GetScriptTailResponse>;
export interface GetScriptVersionRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    versionId: string;
}
export declare const GetScriptVersionRequest: S.Schema<GetScriptVersionRequest>;
export type ScriptsVersionsGetResponseResourcesBindingsItemAIType = "ai";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAIType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemAIType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAI: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemAI>;
export type ScriptsVersionsGetResponseResourcesBindingsItemAISearchType = "ai_search";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAISearchType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAISearch: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemAISearch>;
export type ScriptsVersionsGetResponseResourcesBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAISearchNamespaceType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemAISearchNamespaceType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAISearchNamespace: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemAISearchNamespace>;
export type ScriptsVersionsGetResponseResourcesBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAnalyticsEngineType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemAnalyticsEngineType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAnalyticsEngine: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemAnalyticsEngine>;
export type ScriptsVersionsGetResponseResourcesBindingsItemAssetsType = "assets";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAssetsType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemAssetsType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemAssets: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemAssets>;
export type ScriptsVersionsGetResponseResourcesBindingsItemBrowserType = "browser";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemBrowserType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemBrowserType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemBrowser: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemBrowser>;
export type ScriptsVersionsGetResponseResourcesBindingsItemD1Type = "d1";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemD1Type: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemD1: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemD1>;
export type ScriptsVersionsGetResponseResourcesBindingsItemDataBlobType = "data_blob";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDataBlobType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemDataBlobType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDataBlob: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemDataBlob>;
export type ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceType: any;
export type ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList>;
export type ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker>;
export interface ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutbound: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutbound>;
export interface ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespaceOutbound | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespace: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespace>;
export type ScriptsVersionsGetResponseResourcesBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDurableObjectNamespaceType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemDurableObjectNamespace: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemDurableObjectNamespace>;
export type ScriptsVersionsGetResponseResourcesBindingsItemHyperdriveType = "hyperdrive";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemHyperdriveType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemHyperdriveType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemHyperdrive: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemHyperdrive>;
export type ScriptsVersionsGetResponseResourcesBindingsItemInheritType = "inherit";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemInheritType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemInherit: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemInherit>;
export type ScriptsVersionsGetResponseResourcesBindingsItemImagesType = "images";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemImagesType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemImagesType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemImages: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemImages>;
export type ScriptsVersionsGetResponseResourcesBindingsItemJsonType = "json";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemJsonType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemJsonType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemJson: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemJson>;
export type ScriptsVersionsGetResponseResourcesBindingsItemKVNamespaceType = "kv_namespace";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemKVNamespaceType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemKVNamespaceType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemKVNamespace: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemKVNamespace>;
export type ScriptsVersionsGetResponseResourcesBindingsItemMediaType = "media";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemMediaType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemMediaType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemMedia: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemMedia>;
export type ScriptsVersionsGetResponseResourcesBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemMTLSCertificateType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemMTLSCertificateType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemMTLSCertificate: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemMTLSCertificate>;
export type ScriptsVersionsGetResponseResourcesBindingsItemPlainTextType = "plain_text";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemPlainTextType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemPlainTextType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemPlainText: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemPlainText>;
export type ScriptsVersionsGetResponseResourcesBindingsItemPipelinesType = "pipelines";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemPipelinesType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemPipelinesType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemPipelines: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemPipelines>;
export type ScriptsVersionsGetResponseResourcesBindingsItemQueueType = "queue";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemQueueType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemQueueType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemQueue: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemQueue>;
export type ScriptsVersionsGetResponseResourcesBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export declare const ScriptsVersionsGetResponseResourcesBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple>;
export type ScriptsVersionsGetResponseResourcesBindingsItemRatelimitType = "ratelimit";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemRatelimitType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemRatelimitType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemRatelimit: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemRatelimit>;
export type ScriptsVersionsGetResponseResourcesBindingsItemR2BucketType = "r2_bucket";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemR2BucketType: any;
export type ScriptsVersionsGetResponseResourcesBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemR2BucketJurisdiction: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: ScriptsVersionsGetResponseResourcesBindingsItemR2BucketJurisdiction | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemR2Bucket: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemR2Bucket>;
export type ScriptsVersionsGetResponseResourcesBindingsItemSecretTextType = "secret_text";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretTextType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemSecretTextType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretText: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemSecretText>;
export type ScriptsVersionsGetResponseResourcesBindingsItemSendEmailType = "send_email";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSendEmailType: any;
export type ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList>;
export type ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList>;
export interface ScriptsVersionsGetResponseResourcesBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: ScriptsVersionsGetResponseResourcesBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSendEmail: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemSendEmail>;
export type ScriptsVersionsGetResponseResourcesBindingsItemServiceType = "service";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemServiceType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemService: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemService>;
export type ScriptsVersionsGetResponseResourcesBindingsItemTextBlobType = "text_blob";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemTextBlobType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemTextBlobType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemTextBlob: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemTextBlob>;
export type ScriptsVersionsGetResponseResourcesBindingsItemVectorizeType = "vectorize";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVectorizeType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemVectorizeType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVectorize: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemVectorize>;
export type ScriptsVersionsGetResponseResourcesBindingsItemVersionMetadataType = "version_metadata";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVersionMetadataType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemVersionMetadataType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVersionMetadata: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemVersionMetadata>;
export type ScriptsVersionsGetResponseResourcesBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretsStoreSecretType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemSecretsStoreSecretType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretsStoreSecret: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemSecretsStoreSecret>;
export type ScriptsVersionsGetResponseResourcesBindingsItemFlagshipType = "flagship";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemFlagshipType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemFlagshipType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemFlagship: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemFlagship>;
export type ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyFormat: any;
export type ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyType = "secret_key";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyType: any;
export type ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyUsagesItem: any;
export type ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyUsagesList = Array<ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyUsagesItem>;
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyUsagesList: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyUsagesList>;
export interface ScriptsVersionsGetResponseResourcesBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsVersionsGetResponseResourcesBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemSecretKey: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemSecretKey>;
export type ScriptsVersionsGetResponseResourcesBindingsItemWorkflowType = "workflow";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemWorkflowType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemWorkflow: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemWorkflow>;
export type ScriptsVersionsGetResponseResourcesBindingsItemWasmModuleType = "wasm_module";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemWasmModuleType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemWasmModuleType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemWasmModule: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemWasmModule>;
export type ScriptsVersionsGetResponseResourcesBindingsItemVPCServiceType = "vpc_service";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVPCServiceType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemVPCServiceType;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVPCService: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemVPCService>;
export type ScriptsVersionsGetResponseResourcesBindingsItemVPCNetworkType = "vpc_network";
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVPCNetworkType: any;
export interface ScriptsVersionsGetResponseResourcesBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsVersionsGetResponseResourcesBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesBindingsItemVPCNetwork: S.Schema<ScriptsVersionsGetResponseResourcesBindingsItemVPCNetwork>;
export type ScriptsVersionsGetResponseResourcesBindingsItem = ScriptsVersionsGetResponseResourcesBindingsItemAI | ScriptsVersionsGetResponseResourcesBindingsItemAISearch | ScriptsVersionsGetResponseResourcesBindingsItemAISearchNamespace | ScriptsVersionsGetResponseResourcesBindingsItemAnalyticsEngine | ScriptsVersionsGetResponseResourcesBindingsItemAssets | ScriptsVersionsGetResponseResourcesBindingsItemBrowser | ScriptsVersionsGetResponseResourcesBindingsItemD1 | ScriptsVersionsGetResponseResourcesBindingsItemDataBlob | ScriptsVersionsGetResponseResourcesBindingsItemDispatchNamespace | ScriptsVersionsGetResponseResourcesBindingsItemDurableObjectNamespace | ScriptsVersionsGetResponseResourcesBindingsItemHyperdrive | ScriptsVersionsGetResponseResourcesBindingsItemInherit | ScriptsVersionsGetResponseResourcesBindingsItemImages | ScriptsVersionsGetResponseResourcesBindingsItemJson | ScriptsVersionsGetResponseResourcesBindingsItemKVNamespace | ScriptsVersionsGetResponseResourcesBindingsItemMedia | ScriptsVersionsGetResponseResourcesBindingsItemMTLSCertificate | ScriptsVersionsGetResponseResourcesBindingsItemPlainText | ScriptsVersionsGetResponseResourcesBindingsItemPipelines | ScriptsVersionsGetResponseResourcesBindingsItemQueue | ScriptsVersionsGetResponseResourcesBindingsItemRatelimit | ScriptsVersionsGetResponseResourcesBindingsItemR2Bucket | ScriptsVersionsGetResponseResourcesBindingsItemSecretText | ScriptsVersionsGetResponseResourcesBindingsItemSendEmail | ScriptsVersionsGetResponseResourcesBindingsItemService | ScriptsVersionsGetResponseResourcesBindingsItemTextBlob | ScriptsVersionsGetResponseResourcesBindingsItemVectorize | ScriptsVersionsGetResponseResourcesBindingsItemVersionMetadata | ScriptsVersionsGetResponseResourcesBindingsItemSecretsStoreSecret | ScriptsVersionsGetResponseResourcesBindingsItemFlagship | ScriptsVersionsGetResponseResourcesBindingsItemSecretKey | ScriptsVersionsGetResponseResourcesBindingsItemWorkflow | ScriptsVersionsGetResponseResourcesBindingsItemWasmModule | ScriptsVersionsGetResponseResourcesBindingsItemVPCService | ScriptsVersionsGetResponseResourcesBindingsItemVPCNetwork;
export declare const ScriptsVersionsGetResponseResourcesBindingsItem: any;
export type ScriptsVersionsGetResponseResourcesBindingsList = Array<ScriptsVersionsGetResponseResourcesBindingsItem>;
export declare const ScriptsVersionsGetResponseResourcesBindingsList: S.Schema<ScriptsVersionsGetResponseResourcesBindingsList>;
export type ScriptsVersionsGetResponseResourcesScriptHandlersList = Array<string>;
export declare const ScriptsVersionsGetResponseResourcesScriptHandlersList: S.Schema<ScriptsVersionsGetResponseResourcesScriptHandlersList>;
export type ScriptsVersionsGetResponseResourcesScriptNamedHandlersItemHandlersList = Array<string>;
export declare const ScriptsVersionsGetResponseResourcesScriptNamedHandlersItemHandlersList: S.Schema<ScriptsVersionsGetResponseResourcesScriptNamedHandlersItemHandlersList>;
export interface ScriptsVersionsGetResponseResourcesScriptNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsVersionsGetResponseResourcesScriptNamedHandlersItemHandlersList | null;
    /** The name of the exported class or entrypoint. */
    name?: string | null;
}
export declare const ScriptsVersionsGetResponseResourcesScriptNamedHandlersItem: S.Schema<ScriptsVersionsGetResponseResourcesScriptNamedHandlersItem>;
export type ScriptsVersionsGetResponseResourcesScriptNamedHandlersList = Array<ScriptsVersionsGetResponseResourcesScriptNamedHandlersItem>;
export declare const ScriptsVersionsGetResponseResourcesScriptNamedHandlersList: S.Schema<ScriptsVersionsGetResponseResourcesScriptNamedHandlersList>;
export interface ScriptsVersionsGetResponseResourcesScript {
    /** Hashed script content */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsVersionsGetResponseResourcesScriptHandlersList | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsVersionsGetResponseResourcesScriptNamedHandlersList | null;
}
export declare const ScriptsVersionsGetResponseResourcesScript: S.Schema<ScriptsVersionsGetResponseResourcesScript>;
export type ScriptsVersionsGetResponseResourcesScriptRuntimeCompatibilityFlagsList = Array<string>;
export declare const ScriptsVersionsGetResponseResourcesScriptRuntimeCompatibilityFlagsList: S.Schema<ScriptsVersionsGetResponseResourcesScriptRuntimeCompatibilityFlagsList>;
export type ScriptsVersionsGetResponseResourcesScriptRuntimeLimits = ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits;
export declare const ScriptsVersionsGetResponseResourcesScriptRuntimeLimits: S.Schema<ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits>;
export type ScriptsVersionsGetResponseResourcesScriptRuntimeUsageModel = "bundled" | "unbound" | "standard";
export declare const ScriptsVersionsGetResponseResourcesScriptRuntimeUsageModel: any;
export interface ScriptsVersionsGetResponseResourcesScriptRuntime {
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. */
    compatibilityFlags?: ScriptsVersionsGetResponseResourcesScriptRuntimeCompatibilityFlagsList | null;
    /** Resource limits for the Worker. */
    limits?: ScriptsVersionsCreateResponseResourcesScriptRuntimeLimits | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsVersionsGetResponseResourcesScriptRuntimeUsageModel | null;
}
export declare const ScriptsVersionsGetResponseResourcesScriptRuntime: S.Schema<ScriptsVersionsGetResponseResourcesScriptRuntime>;
export interface ScriptsVersionsGetResponseResources {
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: ScriptsVersionsGetResponseResourcesBindingsList | null;
    script?: ScriptsVersionsGetResponseResourcesScript | null;
    /** Runtime configuration for the Worker. */
    scriptRuntime?: ScriptsVersionsGetResponseResourcesScriptRuntime | null;
}
export declare const ScriptsVersionsGetResponseResources: S.Schema<ScriptsVersionsGetResponseResources>;
export type ScriptsVersionsGetResponseMetadataSource = "unknown" | "api" | "wrangler" | "terraform" | "dash" | "cf_cli" | "dash_template" | "integration" | "quick_editor" | "playground" | "workersci";
export declare const ScriptsVersionsGetResponseMetadataSource: any;
export interface ScriptsVersionsGetResponseMetadata {
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** When the version was created. */
    createdOn?: string | null;
    /** Whether the version can be previewed. */
    hasPreview?: boolean | null;
    /** When the version was last modified. */
    modifiedOn?: string | null;
    /** The source of the version upload. */
    source?: ScriptsVersionsGetResponseMetadataSource | null;
}
export declare const ScriptsVersionsGetResponseMetadata: S.Schema<ScriptsVersionsGetResponseMetadata>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScriptVersionResponse {
    resources: ScriptsVersionsGetResponseResources;
    /** Unique identifier for the version. */
    id?: string | null;
    metadata?: ScriptsVersionsGetResponseMetadata | null;
    /** Sequential version number. */
    number?: number | null;
}
export declare const GetScriptVersionResponse: S.Schema<GetScriptVersionResponse>;
export interface GetSubdomainRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetSubdomainRequest: S.Schema<GetSubdomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubdomainResponse {
    subdomain: string;
}
export declare const GetSubdomainResponse: S.Schema<GetSubdomainResponse>;
export type ObservabilityTelemetryKeysRequestDatasetsList = Array<string>;
export declare const ObservabilityTelemetryKeysRequestDatasetsList: S.Schema<ObservabilityTelemetryKeysRequestDatasetsList>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FiltersList>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0Kind: any;
export interface ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0: S.Schema<ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItem = ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItem: any;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersList = Array<ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersItem>;
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersList>;
export type ObservabilityTelemetryKeysRequestFiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0Kind: any;
export interface ObservabilityTelemetryKeysRequestFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryKeysRequestFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryKeysRequestFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryKeysRequestFiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryKeysRequestFiltersItemCase0: S.Schema<ObservabilityTelemetryKeysRequestFiltersItemCase0>;
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryKeysRequestFiltersItem = ObservabilityTelemetryKeysRequestFiltersItemCase0 | ObservabilityTelemetryKeysRequestFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryKeysRequestFiltersItem: any;
export type ObservabilityTelemetryKeysRequestFiltersList = Array<ObservabilityTelemetryKeysRequestFiltersItem>;
export declare const ObservabilityTelemetryKeysRequestFiltersList: S.Schema<ObservabilityTelemetryKeysRequestFiltersList>;
export type ObservabilityTelemetryKeysRequestKeyNeedleValue = string | number | boolean;
export declare const ObservabilityTelemetryKeysRequestKeyNeedleValue: any;
export interface ObservabilityTelemetryKeysRequestKeyNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryKeysRequestKeyNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export declare const ObservabilityTelemetryKeysRequestKeyNeedle: S.Schema<ObservabilityTelemetryKeysRequestKeyNeedle>;
export type ObservabilityTelemetryKeysRequestNeedleValue = string | number | boolean;
export declare const ObservabilityTelemetryKeysRequestNeedleValue: any;
export interface ObservabilityTelemetryKeysRequestNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryKeysRequestNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export declare const ObservabilityTelemetryKeysRequestNeedle: S.Schema<ObservabilityTelemetryKeysRequestNeedle>;
export interface KeysObservabilityTelemetryRequest {
    accountId: string;
    /** Leave this empty to use the default datasets */
    datasets?: ObservabilityTelemetryKeysRequestDatasetsList;
    /** Apply filters to narrow key discovery. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilityTelemetryKeysRequestFiltersList;
    from?: number;
    /** If the user suggests a key, use this to narrow down the list of keys returned. Make sure matchCase is false to avoid case sensitivity issues. */
    keyNeedle?: ObservabilityTelemetryKeysRequestKeyNeedle;
    /** Advanced usage: set limit=1000+ to retrieve comprehensive key options without needing additional filtering. */
    limit?: number;
    /** Search for a specific substring in any of the events */
    needle?: ObservabilityTelemetryKeysRequestNeedle;
    to?: number;
}
export declare const KeysObservabilityTelemetryRequest: S.Schema<KeysObservabilityTelemetryRequest>;
export type ObservabilityTelemetryKeysResultItemType = "string" | "boolean" | "number";
export declare const ObservabilityTelemetryKeysResultItemType: any;
export interface ObservabilityTelemetryKeysResultItem {
    key: string;
    lastSeenAt: number;
    type: ObservabilityTelemetryKeysResultItemType;
}
export declare const ObservabilityTelemetryKeysResultItem: S.Schema<ObservabilityTelemetryKeysResultItem>;
export type ObservabilityTelemetryKeysResultList = Array<ObservabilityTelemetryKeysResultItem>;
export declare const ObservabilityTelemetryKeysResultList: S.Schema<ObservabilityTelemetryKeysResultList>;
export interface KeysObservabilityTelemetryResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityTelemetryKeysResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const KeysObservabilityTelemetryResponse: S.Schema<KeysObservabilityTelemetryResponse>;
export type BetaWorkersListRequestOrder = "asc" | "desc";
export declare const BetaWorkersListRequestOrder: any;
export type BetaWorkersListRequestOrderBy = "deployed_on" | "updated_on" | "created_on" | "name";
export declare const BetaWorkersListRequestOrderBy: any;
export interface ListBetaWorkersRequest {
    /** Identifier. */
    accountId: string;
    /** Sort direction. */
    order?: BetaWorkersListRequestOrder | (string & {});
    /** Property to sort results by. */
    orderBy?: BetaWorkersListRequestOrderBy | (string & {});
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export declare const ListBetaWorkersRequest: S.Schema<ListBetaWorkersRequest>;
export type BetaWorkersListResultItemObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersListResultItemObservabilityLogsDestinationsList: S.Schema<BetaWorkersListResultItemObservabilityLogsDestinationsList>;
export interface BetaWorkersListResultItemObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersListResultItemObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const BetaWorkersListResultItemObservabilityLogs: S.Schema<BetaWorkersListResultItemObservabilityLogs>;
export type BetaWorkersListResultItemObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersListResultItemObservabilityTracesDestinationsList: S.Schema<BetaWorkersListResultItemObservabilityTracesDestinationsList>;
export type BetaWorkersListResultItemObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersListResultItemObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersListResultItemObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersListResultItemObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersListResultItemObservabilityTracesPropagationPolicy | null;
}
export declare const BetaWorkersListResultItemObservabilityTraces: S.Schema<BetaWorkersListResultItemObservabilityTraces>;
export interface BetaWorkersListResultItemObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersListResultItemObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersListResultItemObservabilityTraces | null;
}
export declare const BetaWorkersListResultItemObservability: S.Schema<BetaWorkersListResultItemObservability>;
export type BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export declare const BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsItem: S.Schema<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export declare const BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsList: S.Schema<BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsList>;
export type BetaWorkersListResultItemReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export declare const BetaWorkersListResultItemReferencesDomainsItem: S.Schema<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersListResultItemReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export declare const BetaWorkersListResultItemReferencesDomainsList: S.Schema<BetaWorkersListResultItemReferencesDomainsList>;
export type BetaWorkersListResultItemReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export declare const BetaWorkersListResultItemReferencesDurableObjectsItem: S.Schema<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersListResultItemReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export declare const BetaWorkersListResultItemReferencesDurableObjectsList: S.Schema<BetaWorkersListResultItemReferencesDurableObjectsList>;
export type BetaWorkersListResultItemReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export declare const BetaWorkersListResultItemReferencesQueuesItem: S.Schema<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersListResultItemReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export declare const BetaWorkersListResultItemReferencesQueuesList: S.Schema<BetaWorkersListResultItemReferencesQueuesList>;
export type BetaWorkersListResultItemReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export declare const BetaWorkersListResultItemReferencesWorkersItem: S.Schema<BetaWorkersCreateResponseReferencesWorkersItem>;
export type BetaWorkersListResultItemReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export declare const BetaWorkersListResultItemReferencesWorkersList: S.Schema<BetaWorkersListResultItemReferencesWorkersList>;
export interface BetaWorkersListResultItemReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersListResultItemReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersListResultItemReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersListResultItemReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersListResultItemReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersListResultItemReferencesWorkersList;
}
export declare const BetaWorkersListResultItemReferences: S.Schema<BetaWorkersListResultItemReferences>;
export type BetaWorkersListResultItemSubdomain = BetaWorkersCreateResponseSubdomain;
export declare const BetaWorkersListResultItemSubdomain: S.Schema<BetaWorkersCreateResponseSubdomain>;
export type BetaWorkersListResultItemTagsList = Array<string>;
export declare const BetaWorkersListResultItemTagsList: S.Schema<BetaWorkersListResultItemTagsList>;
export type BetaWorkersListResultItemTailConsumersItem = BetaWorkersCreateRequestTailConsumersItem;
export declare const BetaWorkersListResultItemTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersListResultItemTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersListResultItemTailConsumersList: S.Schema<BetaWorkersListResultItemTailConsumersList>;
export interface BetaWorkersListResultItem {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersListResultItemObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersListResultItemReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersListResultItemTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersListResultItemTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
}
export declare const BetaWorkersListResultItem: S.Schema<BetaWorkersListResultItem>;
export type BetaWorkersListResultList = Array<BetaWorkersListResultItem>;
export declare const BetaWorkersListResultList: S.Schema<BetaWorkersListResultList>;
export interface ListBetaWorkersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BetaWorkersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListBetaWorkersResponse: S.Schema<ListBetaWorkersResponse>;
export interface ListBetaWorkerVersionsRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export declare const ListBetaWorkerVersionsRequest: S.Schema<ListBetaWorkerVersionsRequest>;
export type BetaWorkersVersionsListResultItemUrlsList = Array<string>;
export declare const BetaWorkersVersionsListResultItemUrlsList: S.Schema<BetaWorkersVersionsListResultItemUrlsList>;
export type BetaWorkersVersionsListResultItemAnnotations = BetaWorkersVersionsCreateResponseAnnotations;
export declare const BetaWorkersVersionsListResultItemAnnotations: S.Schema<BetaWorkersVersionsCreateResponseAnnotations>;
export type BetaWorkersVersionsListResultItemAssetsConfigHtmlHandling = "auto-trailing-slash" | "force-trailing-slash" | "drop-trailing-slash" | "none";
export declare const BetaWorkersVersionsListResultItemAssetsConfigHtmlHandling: any;
export type BetaWorkersVersionsListResultItemAssetsConfigNotFoundHandling = "none" | "404-page" | "single-page-application";
export declare const BetaWorkersVersionsListResultItemAssetsConfigNotFoundHandling: any;
export type BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirstCase0List = Array<string>;
export declare const BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirstCase0List: S.Schema<BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirstCase0List>;
export type BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirst = boolean | BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirstCase0List;
export declare const BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirst: any;
export interface BetaWorkersVersionsListResultItemAssetsConfig {
    /** Determines the redirects and rewrites of requests for HTML content. */
    htmlHandling?: BetaWorkersVersionsListResultItemAssetsConfigHtmlHandling | null;
    /** Determines the response when a request does not match a static asset, and there is no Worker script. */
    notFoundHandling?: BetaWorkersVersionsListResultItemAssetsConfigNotFoundHandling | null;
    /** Contains a list path rules to control routing to either the Worker or assets. Glob (*) and negative (!) rules are supported. Rules must start with either '/' or '!/'. At least one non-negative rule must be provided, and negative rules have higher precedence than non-negative rules. */
    runWorkerFirst?: BetaWorkersVersionsListResultItemAssetsConfigRunWorkerFirst | null;
}
export declare const BetaWorkersVersionsListResultItemAssetsConfig: S.Schema<BetaWorkersVersionsListResultItemAssetsConfig>;
export interface BetaWorkersVersionsListResultItemAssets {
    /** Configuration for assets within a Worker. */
    config?: BetaWorkersVersionsListResultItemAssetsConfig | null;
    /** Token provided upon successful upload of all files from a registered manifest. */
    jwt?: string | null;
}
export declare const BetaWorkersVersionsListResultItemAssets: S.Schema<BetaWorkersVersionsListResultItemAssets>;
export type BetaWorkersVersionsListResultItemBindingsItemAIType = "ai";
export declare const BetaWorkersVersionsListResultItemBindingsItemAIType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAIType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemAI: S.Schema<BetaWorkersVersionsListResultItemBindingsItemAI>;
export type BetaWorkersVersionsListResultItemBindingsItemAISearchType = "ai_search";
export declare const BetaWorkersVersionsListResultItemBindingsItemAISearchType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemAISearch: S.Schema<BetaWorkersVersionsListResultItemBindingsItemAISearch>;
export type BetaWorkersVersionsListResultItemBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const BetaWorkersVersionsListResultItemBindingsItemAISearchNamespaceType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAISearchNamespaceType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemAISearchNamespace: S.Schema<BetaWorkersVersionsListResultItemBindingsItemAISearchNamespace>;
export type BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngineType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngineType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngine: S.Schema<BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngine>;
export type BetaWorkersVersionsListResultItemBindingsItemAssetsType = "assets";
export declare const BetaWorkersVersionsListResultItemBindingsItemAssetsType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemAssetsType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemAssets: S.Schema<BetaWorkersVersionsListResultItemBindingsItemAssets>;
export type BetaWorkersVersionsListResultItemBindingsItemBrowserType = "browser";
export declare const BetaWorkersVersionsListResultItemBindingsItemBrowserType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemBrowserType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemBrowser: S.Schema<BetaWorkersVersionsListResultItemBindingsItemBrowser>;
export type BetaWorkersVersionsListResultItemBindingsItemD1Type = "d1";
export declare const BetaWorkersVersionsListResultItemBindingsItemD1Type: any;
export interface BetaWorkersVersionsListResultItemBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemD1: S.Schema<BetaWorkersVersionsListResultItemBindingsItemD1>;
export type BetaWorkersVersionsListResultItemBindingsItemDataBlobType = "data_blob";
export declare const BetaWorkersVersionsListResultItemBindingsItemDataBlobType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemDataBlobType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemDataBlob: S.Schema<BetaWorkersVersionsListResultItemBindingsItemDataBlob>;
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceType: any;
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export declare const BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsList>;
export type BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export declare const BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker>;
export interface BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutbound: S.Schema<BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutbound>;
export interface BetaWorkersVersionsListResultItemBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: BetaWorkersVersionsListResultItemBindingsItemDispatchNamespaceOutbound | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemDispatchNamespace: S.Schema<BetaWorkersVersionsListResultItemBindingsItemDispatchNamespace>;
export type BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespaceType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespace: S.Schema<BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespace>;
export type BetaWorkersVersionsListResultItemBindingsItemHyperdriveType = "hyperdrive";
export declare const BetaWorkersVersionsListResultItemBindingsItemHyperdriveType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemHyperdriveType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemHyperdrive: S.Schema<BetaWorkersVersionsListResultItemBindingsItemHyperdrive>;
export type BetaWorkersVersionsListResultItemBindingsItemInheritType = "inherit";
export declare const BetaWorkersVersionsListResultItemBindingsItemInheritType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemInherit: S.Schema<BetaWorkersVersionsListResultItemBindingsItemInherit>;
export type BetaWorkersVersionsListResultItemBindingsItemImagesType = "images";
export declare const BetaWorkersVersionsListResultItemBindingsItemImagesType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemImagesType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemImages: S.Schema<BetaWorkersVersionsListResultItemBindingsItemImages>;
export type BetaWorkersVersionsListResultItemBindingsItemJsonType = "json";
export declare const BetaWorkersVersionsListResultItemBindingsItemJsonType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemJsonType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemJson: S.Schema<BetaWorkersVersionsListResultItemBindingsItemJson>;
export type BetaWorkersVersionsListResultItemBindingsItemKVNamespaceType = "kv_namespace";
export declare const BetaWorkersVersionsListResultItemBindingsItemKVNamespaceType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemKVNamespaceType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemKVNamespace: S.Schema<BetaWorkersVersionsListResultItemBindingsItemKVNamespace>;
export type BetaWorkersVersionsListResultItemBindingsItemMediaType = "media";
export declare const BetaWorkersVersionsListResultItemBindingsItemMediaType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemMediaType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemMedia: S.Schema<BetaWorkersVersionsListResultItemBindingsItemMedia>;
export type BetaWorkersVersionsListResultItemBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const BetaWorkersVersionsListResultItemBindingsItemMTLSCertificateType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemMTLSCertificateType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemMTLSCertificate: S.Schema<BetaWorkersVersionsListResultItemBindingsItemMTLSCertificate>;
export type BetaWorkersVersionsListResultItemBindingsItemPlainTextType = "plain_text";
export declare const BetaWorkersVersionsListResultItemBindingsItemPlainTextType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemPlainTextType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemPlainText: S.Schema<BetaWorkersVersionsListResultItemBindingsItemPlainText>;
export type BetaWorkersVersionsListResultItemBindingsItemPipelinesType = "pipelines";
export declare const BetaWorkersVersionsListResultItemBindingsItemPipelinesType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemPipelinesType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemPipelines: S.Schema<BetaWorkersVersionsListResultItemBindingsItemPipelines>;
export type BetaWorkersVersionsListResultItemBindingsItemQueueType = "queue";
export declare const BetaWorkersVersionsListResultItemBindingsItemQueueType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemQueueType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemQueue: S.Schema<BetaWorkersVersionsListResultItemBindingsItemQueue>;
export type BetaWorkersVersionsListResultItemBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export declare const BetaWorkersVersionsListResultItemBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple>;
export type BetaWorkersVersionsListResultItemBindingsItemRatelimitType = "ratelimit";
export declare const BetaWorkersVersionsListResultItemBindingsItemRatelimitType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemRatelimitType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemRatelimit: S.Schema<BetaWorkersVersionsListResultItemBindingsItemRatelimit>;
export type BetaWorkersVersionsListResultItemBindingsItemR2BucketType = "r2_bucket";
export declare const BetaWorkersVersionsListResultItemBindingsItemR2BucketType: any;
export type BetaWorkersVersionsListResultItemBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const BetaWorkersVersionsListResultItemBindingsItemR2BucketJurisdiction: any;
export interface BetaWorkersVersionsListResultItemBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: BetaWorkersVersionsListResultItemBindingsItemR2BucketJurisdiction | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemR2Bucket: S.Schema<BetaWorkersVersionsListResultItemBindingsItemR2Bucket>;
export type BetaWorkersVersionsListResultItemBindingsItemSecretTextType = "secret_text";
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretTextType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSecretTextType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretText: S.Schema<BetaWorkersVersionsListResultItemBindingsItemSecretText>;
export type BetaWorkersVersionsListResultItemBindingsItemSendEmailType = "send_email";
export declare const BetaWorkersVersionsListResultItemBindingsItemSendEmailType: any;
export type BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedDestinationAddressesList>;
export type BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedSenderAddressesList>;
export interface BetaWorkersVersionsListResultItemBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: BetaWorkersVersionsListResultItemBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemSendEmail: S.Schema<BetaWorkersVersionsListResultItemBindingsItemSendEmail>;
export type BetaWorkersVersionsListResultItemBindingsItemServiceType = "service";
export declare const BetaWorkersVersionsListResultItemBindingsItemServiceType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemService: S.Schema<BetaWorkersVersionsListResultItemBindingsItemService>;
export type BetaWorkersVersionsListResultItemBindingsItemTextBlobType = "text_blob";
export declare const BetaWorkersVersionsListResultItemBindingsItemTextBlobType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemTextBlobType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemTextBlob: S.Schema<BetaWorkersVersionsListResultItemBindingsItemTextBlob>;
export type BetaWorkersVersionsListResultItemBindingsItemVectorizeType = "vectorize";
export declare const BetaWorkersVersionsListResultItemBindingsItemVectorizeType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVectorizeType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemVectorize: S.Schema<BetaWorkersVersionsListResultItemBindingsItemVectorize>;
export type BetaWorkersVersionsListResultItemBindingsItemVersionMetadataType = "version_metadata";
export declare const BetaWorkersVersionsListResultItemBindingsItemVersionMetadataType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVersionMetadataType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemVersionMetadata: S.Schema<BetaWorkersVersionsListResultItemBindingsItemVersionMetadata>;
export type BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecretType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecretType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecret: S.Schema<BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecret>;
export type BetaWorkersVersionsListResultItemBindingsItemFlagshipType = "flagship";
export declare const BetaWorkersVersionsListResultItemBindingsItemFlagshipType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemFlagshipType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemFlagship: S.Schema<BetaWorkersVersionsListResultItemBindingsItemFlagship>;
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretKeyFormat: any;
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyType = "secret_key";
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretKeyType: any;
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesItem: any;
export type BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesList = Array<BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesItem>;
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesList: S.Schema<BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesList>;
export interface BetaWorkersVersionsListResultItemBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: BetaWorkersVersionsListResultItemBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: BetaWorkersVersionsListResultItemBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemSecretKey: S.Schema<BetaWorkersVersionsListResultItemBindingsItemSecretKey>;
export type BetaWorkersVersionsListResultItemBindingsItemWorkflowType = "workflow";
export declare const BetaWorkersVersionsListResultItemBindingsItemWorkflowType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemWorkflow: S.Schema<BetaWorkersVersionsListResultItemBindingsItemWorkflow>;
export type BetaWorkersVersionsListResultItemBindingsItemWasmModuleType = "wasm_module";
export declare const BetaWorkersVersionsListResultItemBindingsItemWasmModuleType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemWasmModuleType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemWasmModule: S.Schema<BetaWorkersVersionsListResultItemBindingsItemWasmModule>;
export type BetaWorkersVersionsListResultItemBindingsItemVPCServiceType = "vpc_service";
export declare const BetaWorkersVersionsListResultItemBindingsItemVPCServiceType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVPCServiceType;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemVPCService: S.Schema<BetaWorkersVersionsListResultItemBindingsItemVPCService>;
export type BetaWorkersVersionsListResultItemBindingsItemVPCNetworkType = "vpc_network";
export declare const BetaWorkersVersionsListResultItemBindingsItemVPCNetworkType: any;
export interface BetaWorkersVersionsListResultItemBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: BetaWorkersVersionsListResultItemBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const BetaWorkersVersionsListResultItemBindingsItemVPCNetwork: S.Schema<BetaWorkersVersionsListResultItemBindingsItemVPCNetwork>;
export type BetaWorkersVersionsListResultItemBindingsItem = BetaWorkersVersionsListResultItemBindingsItemAI | BetaWorkersVersionsListResultItemBindingsItemAISearch | BetaWorkersVersionsListResultItemBindingsItemAISearchNamespace | BetaWorkersVersionsListResultItemBindingsItemAnalyticsEngine | BetaWorkersVersionsListResultItemBindingsItemAssets | BetaWorkersVersionsListResultItemBindingsItemBrowser | BetaWorkersVersionsListResultItemBindingsItemD1 | BetaWorkersVersionsListResultItemBindingsItemDataBlob | BetaWorkersVersionsListResultItemBindingsItemDispatchNamespace | BetaWorkersVersionsListResultItemBindingsItemDurableObjectNamespace | BetaWorkersVersionsListResultItemBindingsItemHyperdrive | BetaWorkersVersionsListResultItemBindingsItemInherit | BetaWorkersVersionsListResultItemBindingsItemImages | BetaWorkersVersionsListResultItemBindingsItemJson | BetaWorkersVersionsListResultItemBindingsItemKVNamespace | BetaWorkersVersionsListResultItemBindingsItemMedia | BetaWorkersVersionsListResultItemBindingsItemMTLSCertificate | BetaWorkersVersionsListResultItemBindingsItemPlainText | BetaWorkersVersionsListResultItemBindingsItemPipelines | BetaWorkersVersionsListResultItemBindingsItemQueue | BetaWorkersVersionsListResultItemBindingsItemRatelimit | BetaWorkersVersionsListResultItemBindingsItemR2Bucket | BetaWorkersVersionsListResultItemBindingsItemSecretText | BetaWorkersVersionsListResultItemBindingsItemSendEmail | BetaWorkersVersionsListResultItemBindingsItemService | BetaWorkersVersionsListResultItemBindingsItemTextBlob | BetaWorkersVersionsListResultItemBindingsItemVectorize | BetaWorkersVersionsListResultItemBindingsItemVersionMetadata | BetaWorkersVersionsListResultItemBindingsItemSecretsStoreSecret | BetaWorkersVersionsListResultItemBindingsItemFlagship | BetaWorkersVersionsListResultItemBindingsItemSecretKey | BetaWorkersVersionsListResultItemBindingsItemWorkflow | BetaWorkersVersionsListResultItemBindingsItemWasmModule | BetaWorkersVersionsListResultItemBindingsItemVPCService | BetaWorkersVersionsListResultItemBindingsItemVPCNetwork;
export declare const BetaWorkersVersionsListResultItemBindingsItem: any;
export type BetaWorkersVersionsListResultItemBindingsList = Array<BetaWorkersVersionsListResultItemBindingsItem>;
export declare const BetaWorkersVersionsListResultItemBindingsList: S.Schema<BetaWorkersVersionsListResultItemBindingsList>;
export type BetaWorkersVersionsListResultItemCacheOptions = BetaWorkersVersionsCreateResponseCacheOptions;
export declare const BetaWorkersVersionsListResultItemCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type BetaWorkersVersionsListResultItemCompatibilityFlagsList = Array<string>;
export declare const BetaWorkersVersionsListResultItemCompatibilityFlagsList: S.Schema<BetaWorkersVersionsListResultItemCompatibilityFlagsList>;
export type BetaWorkersVersionsListResultItemContainersItem = BetaWorkersVersionsCreateRequestContainersItem;
export declare const BetaWorkersVersionsListResultItemContainersItem: S.Schema<BetaWorkersVersionsCreateRequestContainersItem>;
export type BetaWorkersVersionsListResultItemContainersList = Array<BetaWorkersVersionsCreateRequestContainersItem>;
export declare const BetaWorkersVersionsListResultItemContainersList: S.Schema<BetaWorkersVersionsListResultItemContainersList>;
export type BetaWorkersVersionsListResultItemLimits = BetaWorkersVersionsCreateResponseLimits;
export declare const BetaWorkersVersionsListResultItemLimits: S.Schema<BetaWorkersVersionsCreateResponseLimits>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationDeletedClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationDeletedClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewSqliteClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesList>;
export interface BetaWorkersVersionsListResultItemMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsListResultItemMigrationsSingleStepMigrationTransferredClassesList | null;
}
export declare const BetaWorkersVersionsListResultItemMigrationsSingleStepMigration: S.Schema<BetaWorkersVersionsListResultItemMigrationsSingleStepMigration>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsList = Array<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export declare const BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrations: S.Schema<BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrations>;
export type BetaWorkersVersionsListResultItemMigrations = BetaWorkersVersionsListResultItemMigrationsSingleStepMigration | BetaWorkersVersionsListResultItemMigrationsWorkersMultipleStepMigrations;
export declare const BetaWorkersVersionsListResultItemMigrations: any;
export type BetaWorkersVersionsListResultItemModulesItem = BetaWorkersVersionsCreateRequestModulesItem;
export declare const BetaWorkersVersionsListResultItemModulesItem: S.Schema<BetaWorkersVersionsCreateRequestModulesItem>;
export type BetaWorkersVersionsListResultItemModulesList = Array<BetaWorkersVersionsCreateRequestModulesItem>;
export declare const BetaWorkersVersionsListResultItemModulesList: S.Schema<BetaWorkersVersionsListResultItemModulesList>;
export type BetaWorkersVersionsListResultItemPackageDependenciesItem = BetaWorkersVersionsCreateRequestPackageDependenciesItem;
export declare const BetaWorkersVersionsListResultItemPackageDependenciesItem: S.Schema<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export type BetaWorkersVersionsListResultItemPackageDependenciesList = Array<BetaWorkersVersionsCreateRequestPackageDependenciesItem>;
export declare const BetaWorkersVersionsListResultItemPackageDependenciesList: S.Schema<BetaWorkersVersionsListResultItemPackageDependenciesList>;
export type BetaWorkersVersionsListResultItemPlacementModeMode = "smart";
export declare const BetaWorkersVersionsListResultItemPlacementModeMode: any;
export interface BetaWorkersVersionsListResultItemPlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: BetaWorkersVersionsListResultItemPlacementModeMode;
}
export declare const BetaWorkersVersionsListResultItemPlacementMode: S.Schema<BetaWorkersVersionsListResultItemPlacementMode>;
export type BetaWorkersVersionsListResultItemPlacementRegion = BetaWorkersVersionsCreateRequestPlacementRegion;
export declare const BetaWorkersVersionsListResultItemPlacementRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementRegion>;
export type BetaWorkersVersionsListResultItemPlacementHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const BetaWorkersVersionsListResultItemPlacementHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type BetaWorkersVersionsListResultItemPlacementHost = BetaWorkersVersionsCreateRequestPlacementHost;
export declare const BetaWorkersVersionsListResultItemPlacementHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementHost>;
export type BetaWorkersVersionsListResultItemPlacementCase4Mode = "targeted";
export declare const BetaWorkersVersionsListResultItemPlacementCase4Mode: any;
export interface BetaWorkersVersionsListResultItemPlacementCase4 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const BetaWorkersVersionsListResultItemPlacementCase4: S.Schema<BetaWorkersVersionsListResultItemPlacementCase4>;
export type BetaWorkersVersionsListResultItemPlacementCase5Mode = "targeted";
export declare const BetaWorkersVersionsListResultItemPlacementCase5Mode: any;
export interface BetaWorkersVersionsListResultItemPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase5Mode;
}
export declare const BetaWorkersVersionsListResultItemPlacementCase5: S.Schema<BetaWorkersVersionsListResultItemPlacementCase5>;
export type BetaWorkersVersionsListResultItemPlacementCase6Mode = "targeted";
export declare const BetaWorkersVersionsListResultItemPlacementCase6Mode: any;
export interface BetaWorkersVersionsListResultItemPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase6Mode;
}
export declare const BetaWorkersVersionsListResultItemPlacementCase6: S.Schema<BetaWorkersVersionsListResultItemPlacementCase6>;
export type BetaWorkersVersionsListResultItemPlacementCase7Mode = "targeted";
export declare const BetaWorkersVersionsListResultItemPlacementCase7Mode: any;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const BetaWorkersVersionsListResultItemPlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const BetaWorkersVersionsListResultItemPlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const BetaWorkersVersionsListResultItemPlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const BetaWorkersVersionsListResultItemPlacementCase7TargetItem: any;
export type BetaWorkersVersionsListResultItemPlacementCase7TargetList = Array<BetaWorkersVersionsListResultItemPlacementCase7TargetItem>;
export declare const BetaWorkersVersionsListResultItemPlacementCase7TargetList: S.Schema<BetaWorkersVersionsListResultItemPlacementCase7TargetList>;
export interface BetaWorkersVersionsListResultItemPlacementCase7 {
    /** Targeted placement mode. */
    mode: BetaWorkersVersionsListResultItemPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: BetaWorkersVersionsListResultItemPlacementCase7TargetList;
}
export declare const BetaWorkersVersionsListResultItemPlacementCase7: S.Schema<BetaWorkersVersionsListResultItemPlacementCase7>;
export type BetaWorkersVersionsListResultItemPlacement = BetaWorkersVersionsListResultItemPlacementMode | BetaWorkersVersionsCreateRequestPlacementRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementHost | BetaWorkersVersionsListResultItemPlacementCase4 | BetaWorkersVersionsListResultItemPlacementCase5 | BetaWorkersVersionsListResultItemPlacementCase6 | BetaWorkersVersionsListResultItemPlacementCase7;
export declare const BetaWorkersVersionsListResultItemPlacement: any;
export type BetaWorkersVersionsListResultItemUsageModel = "standard" | "bundled" | "unbound";
export declare const BetaWorkersVersionsListResultItemUsageModel: any;
export interface BetaWorkersVersionsListResultItem {
    /** Version identifier. */
    id: string;
    /** When the version was created. */
    createdOn: string;
    /** The integer version number, starting from one. */
    number: number;
    /** All routable URLs that always point to this version. Does not include alias URLs, since aliases can be updated to point to a different version. */
    urls: BetaWorkersVersionsListResultItemUrlsList;
    /** Metadata about the version. */
    annotations?: BetaWorkersVersionsCreateResponseAnnotations | null;
    /** Configuration for assets within a Worker. */
    assets?: BetaWorkersVersionsListResultItemAssets | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: BetaWorkersVersionsListResultItemBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: BetaWorkersVersionsListResultItemCompatibilityFlagsList | null;
    /** List of containers attached to a Worker. Containers can only be attached to Durable Object classes of this Worker script. */
    containers?: BetaWorkersVersionsListResultItemContainersList | null;
    /** Resource limits enforced at runtime. */
    limits?: BetaWorkersVersionsCreateResponseLimits | null;
    /** The name of the main module in the `modules` array (e.g. the name of the module that exports a `fetch` handler). */
    mainModule?: string | null;
    /** Durable Object migration tag. Set when the version is deployed. Omitted if the version has not been deployed or the Worker does not use Durable Objects. */
    migrationTag?: string | null;
    /** Migrations for Durable Objects associated with the version. Migrations are applied when the version is deployed. */
    migrations?: BetaWorkersVersionsListResultItemMigrations | null;
    /** Code, sourcemaps, and other content used at runtime. */
    modules?: BetaWorkersVersionsListResultItemModulesList | null;
    /** The list of npm packages that were installed and used when this Worker */
    packageDependencies?: BetaWorkersVersionsListResultItemPackageDependenciesList | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: BetaWorkersVersionsListResultItemPlacement | null;
    /** The client used to create the version. */
    source?: string | null;
    /** Time in milliseconds spent on [Worker startup](https://developers.cloudflare.com/workers/platform/limits/#worker-startup-time). */
    startupTimeMs?: number | null;
    /** Usage model for the version. */
    usageModel?: BetaWorkersVersionsListResultItemUsageModel | null;
}
export declare const BetaWorkersVersionsListResultItem: S.Schema<BetaWorkersVersionsListResultItem>;
export type BetaWorkersVersionsListResultList = Array<BetaWorkersVersionsListResultItem>;
export declare const BetaWorkersVersionsListResultList: S.Schema<BetaWorkersVersionsListResultList>;
export interface ListBetaWorkerVersionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BetaWorkersVersionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListBetaWorkerVersionsResponse: S.Schema<ListBetaWorkerVersionsResponse>;
export interface ListDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** Worker environment associated with the domain. */
    environment?: string;
    /** Hostname of the domain. */
    hostname?: string;
    /** Name of the Worker associated with the domain. */
    service?: string;
    /** ID of the zone containing the domain hostname. */
    zoneId?: string;
    /** Name of the zone containing the domain hostname. */
    zoneName?: string;
}
export declare const ListDomainsRequest: S.Schema<ListDomainsRequest>;
export interface DomainsListResultItem {
    /** Immutable ID of the domain. */
    id: string;
    /** ID of the TLS certificate issued for the domain. */
    certId: string;
    /** Worker environment associated with the domain. */
    environment: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** ID of the zone containing the domain hostname. */
    zoneId: string;
    /** Name of the zone containing the domain hostname. */
    zoneName: string;
    /** Whether Worker Previews are served on this custom domain. */
    previewsEnabled?: boolean | null;
}
export declare const DomainsListResultItem: S.Schema<DomainsListResultItem>;
export type DomainsListResultList = Array<DomainsListResultItem>;
export declare const DomainsListResultList: S.Schema<DomainsListResultList>;
export interface ListDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDomainsResponse: S.Schema<ListDomainsResponse>;
export type ObservabilityDestinationsListRequestOrder = "asc" | "desc";
export declare const ObservabilityDestinationsListRequestOrder: any;
export type ObservabilityDestinationsListRequestOrderBy = "created" | "updated";
export declare const ObservabilityDestinationsListRequestOrderBy: any;
export interface ListObservabilityDestinationsRequest {
    accountId: string;
    order?: ObservabilityDestinationsListRequestOrder | (string & {});
    orderBy?: ObservabilityDestinationsListRequestOrderBy | (string & {});
    page?: number;
    perPage?: number;
}
export declare const ListObservabilityDestinationsRequest: S.Schema<ListObservabilityDestinationsRequest>;
export type ObservabilityDestinationsListResultItemConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ObservabilityDestinationsListResultItemConfigurationHeadersMap: S.Schema<ObservabilityDestinationsListResultItemConfigurationHeadersMap>;
export interface ObservabilityDestinationsListResultItemConfigurationJobStatus {
    errorMessage: string;
    lastComplete: string;
    lastError: string;
}
export declare const ObservabilityDestinationsListResultItemConfigurationJobStatus: S.Schema<ObservabilityDestinationsListResultItemConfigurationJobStatus>;
export type ObservabilityDestinationsListResultItemConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export declare const ObservabilityDestinationsListResultItemConfigurationLogpushDataset: any;
export type ObservabilityDestinationsListResultItemConfigurationType = "logpush";
export declare const ObservabilityDestinationsListResultItemConfigurationType: any;
export interface ObservabilityDestinationsListResultItemConfiguration {
    destinationConf: string;
    headers: ObservabilityDestinationsListResultItemConfigurationHeadersMap;
    jobStatus: ObservabilityDestinationsListResultItemConfigurationJobStatus;
    logpushDataset: ObservabilityDestinationsListResultItemConfigurationLogpushDataset;
    type: ObservabilityDestinationsListResultItemConfigurationType;
    url: string;
}
export declare const ObservabilityDestinationsListResultItemConfiguration: S.Schema<ObservabilityDestinationsListResultItemConfiguration>;
export type ObservabilityDestinationsListResultItemScriptsList = Array<string>;
export declare const ObservabilityDestinationsListResultItemScriptsList: S.Schema<ObservabilityDestinationsListResultItemScriptsList>;
export interface ObservabilityDestinationsListResultItem {
    configuration: ObservabilityDestinationsListResultItemConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsListResultItemScriptsList;
    slug: string;
}
export declare const ObservabilityDestinationsListResultItem: S.Schema<ObservabilityDestinationsListResultItem>;
export type ObservabilityDestinationsListResultList = Array<ObservabilityDestinationsListResultItem>;
export declare const ObservabilityDestinationsListResultList: S.Schema<ObservabilityDestinationsListResultList>;
export interface ListObservabilityDestinationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityDestinationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListObservabilityDestinationsResponse: S.Schema<ListObservabilityDestinationsResponse>;
export type ObservabilityQueriesListRequestOrder = "asc" | "desc";
export declare const ObservabilityQueriesListRequestOrder: any;
export type ObservabilityQueriesListRequestOrderBy = "created" | "updated";
export declare const ObservabilityQueriesListRequestOrderBy: any;
export interface ListObservabilityQueriesRequest {
    accountId: string;
    order?: ObservabilityQueriesListRequestOrder | (string & {});
    orderBy?: ObservabilityQueriesListRequestOrderBy | (string & {});
    page?: number;
    perPage?: number;
}
export declare const ListObservabilityQueriesRequest: S.Schema<ListObservabilityQueriesRequest>;
export type ObservabilityQueriesListResultItemParametersCalculationsItemOperator = "uniq" | "count" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "COUNT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export declare const ObservabilityQueriesListResultItemParametersCalculationsItemOperator: any;
export type ObservabilityQueriesListResultItemParametersCalculationsItemKeyType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesListResultItemParametersCalculationsItemKeyType: any;
export interface ObservabilityQueriesListResultItemParametersCalculationsItem {
    operator: ObservabilityQueriesListResultItemParametersCalculationsItemOperator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilityQueriesListResultItemParametersCalculationsItemKeyType | null;
}
export declare const ObservabilityQueriesListResultItemParametersCalculationsItem: S.Schema<ObservabilityQueriesListResultItemParametersCalculationsItem>;
export type ObservabilityQueriesListResultItemParametersCalculationsList = Array<ObservabilityQueriesListResultItemParametersCalculationsItem>;
export declare const ObservabilityQueriesListResultItemParametersCalculationsList: S.Schema<ObservabilityQueriesListResultItemParametersCalculationsList>;
export type ObservabilityQueriesListResultItemParametersDatasetsList = Array<string>;
export declare const ObservabilityQueriesListResultItemParametersDatasetsList: S.Schema<ObservabilityQueriesListResultItemParametersDatasetsList>;
export type ObservabilityQueriesListResultItemParametersFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityQueriesListResultItemParametersFilterCombination: any;
export type ObservabilityQueriesListResultItemParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityQueriesListResultItemParametersFiltersItemCase0FilterCombination: any;
export type ObservabilityQueriesListResultItemParametersFiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityQueriesListResultItemParametersFiltersItemCase0FiltersList: S.Schema<ObservabilityQueriesListResultItemParametersFiltersItemCase0FiltersList>;
export type ObservabilityQueriesListResultItemParametersFiltersItemCase0Kind = "group";
export declare const ObservabilityQueriesListResultItemParametersFiltersItemCase0Kind: any;
export interface ObservabilityQueriesListResultItemParametersFiltersItemCase0 {
    filterCombination: ObservabilityQueriesListResultItemParametersFiltersItemCase0FilterCombination;
    filters: ObservabilityQueriesListResultItemParametersFiltersItemCase0FiltersList;
    kind: ObservabilityQueriesListResultItemParametersFiltersItemCase0Kind;
}
export declare const ObservabilityQueriesListResultItemParametersFiltersItemCase0: S.Schema<ObservabilityQueriesListResultItemParametersFiltersItemCase0>;
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export declare const ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityQueriesListResultItemParametersFiltersItem = ObservabilityQueriesListResultItemParametersFiltersItemCase0 | ObservabilityQueriesListResultItemParametersFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityQueriesListResultItemParametersFiltersItem: any;
export type ObservabilityQueriesListResultItemParametersFiltersList = Array<ObservabilityQueriesListResultItemParametersFiltersItem>;
export declare const ObservabilityQueriesListResultItemParametersFiltersList: S.Schema<ObservabilityQueriesListResultItemParametersFiltersList>;
export type ObservabilityQueriesListResultItemParametersGroupBysItemType = "string" | "number" | "boolean";
export declare const ObservabilityQueriesListResultItemParametersGroupBysItemType: any;
export interface ObservabilityQueriesListResultItemParametersGroupBysItem {
    type: ObservabilityQueriesListResultItemParametersGroupBysItemType;
    value: string;
}
export declare const ObservabilityQueriesListResultItemParametersGroupBysItem: S.Schema<ObservabilityQueriesListResultItemParametersGroupBysItem>;
export type ObservabilityQueriesListResultItemParametersGroupBysList = Array<ObservabilityQueriesListResultItemParametersGroupBysItem>;
export declare const ObservabilityQueriesListResultItemParametersGroupBysList: S.Schema<ObservabilityQueriesListResultItemParametersGroupBysList>;
export type ObservabilityQueriesListResultItemParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export declare const ObservabilityQueriesListResultItemParametersHavingsItemOperation: any;
export interface ObservabilityQueriesListResultItemParametersHavingsItem {
    key: string;
    operation: ObservabilityQueriesListResultItemParametersHavingsItemOperation;
    value: number;
}
export declare const ObservabilityQueriesListResultItemParametersHavingsItem: S.Schema<ObservabilityQueriesListResultItemParametersHavingsItem>;
export type ObservabilityQueriesListResultItemParametersHavingsList = Array<ObservabilityQueriesListResultItemParametersHavingsItem>;
export declare const ObservabilityQueriesListResultItemParametersHavingsList: S.Schema<ObservabilityQueriesListResultItemParametersHavingsList>;
export type ObservabilityQueriesListResultItemParametersNeedleValue = string | number | boolean;
export declare const ObservabilityQueriesListResultItemParametersNeedleValue: any;
export interface ObservabilityQueriesListResultItemParametersNeedle {
    value: ObservabilityQueriesListResultItemParametersNeedleValue;
    isRegex?: boolean | null;
    matchCase?: boolean | null;
}
export declare const ObservabilityQueriesListResultItemParametersNeedle: S.Schema<ObservabilityQueriesListResultItemParametersNeedle>;
export type ObservabilityQueriesListResultItemParametersOrderByOrder = "asc" | "desc";
export declare const ObservabilityQueriesListResultItemParametersOrderByOrder: any;
export interface ObservabilityQueriesListResultItemParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityQueriesListResultItemParametersOrderByOrder | null;
}
export declare const ObservabilityQueriesListResultItemParametersOrderBy: S.Schema<ObservabilityQueriesListResultItemParametersOrderBy>;
export interface ObservabilityQueriesListResultItemParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityQueriesListResultItemParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityQueriesListResultItemParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityQueriesListResultItemParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityQueriesListResultItemParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityQueriesListResultItemParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityQueriesListResultItemParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilityQueriesListResultItemParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityQueriesListResultItemParametersOrderBy | null;
}
export declare const ObservabilityQueriesListResultItemParameters: S.Schema<ObservabilityQueriesListResultItemParameters>;
export interface ObservabilityQueriesListResultItem {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityQueriesListResultItemParameters;
    updated: string;
    updatedBy: string;
}
export declare const ObservabilityQueriesListResultItem: S.Schema<ObservabilityQueriesListResultItem>;
export type ObservabilityQueriesListResultList = Array<ObservabilityQueriesListResultItem>;
export declare const ObservabilityQueriesListResultList: S.Schema<ObservabilityQueriesListResultList>;
export interface ListObservabilityQueriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityQueriesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListObservabilityQueriesResponse: S.Schema<ListObservabilityQueriesResponse>;
export interface ListRoutesRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListRoutesRequest: S.Schema<ListRoutesRequest>;
export interface RoutesListResultItem {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export declare const RoutesListResultItem: S.Schema<RoutesListResultItem>;
export type RoutesListResultList = Array<RoutesListResultItem>;
export declare const RoutesListResultList: S.Schema<RoutesListResultList>;
export interface ListRoutesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RoutesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRoutesResponse: S.Schema<ListRoutesResponse>;
export interface ListScriptDeploymentsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const ListScriptDeploymentsRequest: S.Schema<ListScriptDeploymentsRequest>;
export type ScriptsDeploymentsListResponseDeploymentsItemStrategy = "percentage";
export declare const ScriptsDeploymentsListResponseDeploymentsItemStrategy: any;
export type ScriptsDeploymentsListResponseDeploymentsItemVersionsItem = ScriptsDeploymentsCreateRequestVersionsItem;
export declare const ScriptsDeploymentsListResponseDeploymentsItemVersionsItem: S.Schema<ScriptsDeploymentsCreateRequestVersionsItem>;
export type ScriptsDeploymentsListResponseDeploymentsItemVersionsList = Array<ScriptsDeploymentsCreateRequestVersionsItem>;
export declare const ScriptsDeploymentsListResponseDeploymentsItemVersionsList: S.Schema<ScriptsDeploymentsListResponseDeploymentsItemVersionsList>;
export type ScriptsDeploymentsListResponseDeploymentsItemAnnotations = ScriptsDeploymentsCreateResponseAnnotations;
export declare const ScriptsDeploymentsListResponseDeploymentsItemAnnotations: S.Schema<ScriptsDeploymentsCreateResponseAnnotations>;
export interface ScriptsDeploymentsListResponseDeploymentsItem {
    id: string;
    createdOn: string;
    source: string;
    strategy: ScriptsDeploymentsListResponseDeploymentsItemStrategy;
    versions: ScriptsDeploymentsListResponseDeploymentsItemVersionsList;
    annotations?: ScriptsDeploymentsCreateResponseAnnotations | null;
    authorEmail?: string | null;
}
export declare const ScriptsDeploymentsListResponseDeploymentsItem: S.Schema<ScriptsDeploymentsListResponseDeploymentsItem>;
export type ScriptsDeploymentsListResponseDeploymentsList = Array<ScriptsDeploymentsListResponseDeploymentsItem>;
export declare const ScriptsDeploymentsListResponseDeploymentsList: S.Schema<ScriptsDeploymentsListResponseDeploymentsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListScriptDeploymentsResponse {
    deployments: ScriptsDeploymentsListResponseDeploymentsList;
}
export declare const ListScriptDeploymentsResponse: S.Schema<ListScriptDeploymentsResponse>;
export interface ListScriptsRequest {
    /** Identifier. */
    accountId: string;
    /** Filter scripts by tags. Format: comma-separated list of tag:allowed pairs where allowed is 'yes' or 'no'. */
    tags?: string;
}
export declare const ListScriptsRequest: S.Schema<ListScriptsRequest>;
export type ScriptsListResultItemCacheOptions = BetaWorkersVersionsCreateResponseCacheOptions;
export declare const ScriptsListResultItemCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type ScriptsListResultItemCompatibilityFlagsList = Array<string>;
export declare const ScriptsListResultItemCompatibilityFlagsList: S.Schema<ScriptsListResultItemCompatibilityFlagsList>;
export type ScriptsListResultItemHandlersList = Array<string>;
export declare const ScriptsListResultItemHandlersList: S.Schema<ScriptsListResultItemHandlersList>;
export type ScriptsListResultItemNamedHandlersItemHandlersList = Array<string>;
export declare const ScriptsListResultItemNamedHandlersItemHandlersList: S.Schema<ScriptsListResultItemNamedHandlersItemHandlersList>;
export interface ScriptsListResultItemNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsListResultItemNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export declare const ScriptsListResultItemNamedHandlersItem: S.Schema<ScriptsListResultItemNamedHandlersItem>;
export type ScriptsListResultItemNamedHandlersList = Array<ScriptsListResultItemNamedHandlersItem>;
export declare const ScriptsListResultItemNamedHandlersList: S.Schema<ScriptsListResultItemNamedHandlersList>;
export type ScriptsListResultItemObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsListResultItemObservabilityLogsDestinationsList: S.Schema<ScriptsListResultItemObservabilityLogsDestinationsList>;
export interface ScriptsListResultItemObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsListResultItemObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const ScriptsListResultItemObservabilityLogs: S.Schema<ScriptsListResultItemObservabilityLogs>;
export type ScriptsListResultItemObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsListResultItemObservabilityTracesDestinationsList: S.Schema<ScriptsListResultItemObservabilityTracesDestinationsList>;
export type ScriptsListResultItemObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsListResultItemObservabilityTracesPropagationPolicy: any;
export interface ScriptsListResultItemObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsListResultItemObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsListResultItemObservabilityTracesPropagationPolicy | null;
}
export declare const ScriptsListResultItemObservabilityTraces: S.Schema<ScriptsListResultItemObservabilityTraces>;
export interface ScriptsListResultItemObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: ScriptsListResultItemObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsListResultItemObservabilityTraces | null;
}
export declare const ScriptsListResultItemObservability: S.Schema<ScriptsListResultItemObservability>;
export type ScriptsListResultItemPlacementCase0Mode = "smart";
export declare const ScriptsListResultItemPlacementCase0Mode: any;
export type ScriptsListResultItemPlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase0Status: any;
export interface ScriptsListResultItemPlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsListResultItemPlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase0Status | null;
}
export declare const ScriptsListResultItemPlacementCase0: S.Schema<ScriptsListResultItemPlacementCase0>;
export type ScriptsListResultItemPlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase1Status: any;
export interface ScriptsListResultItemPlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase1Status | null;
}
export declare const ScriptsListResultItemPlacementCase1: S.Schema<ScriptsListResultItemPlacementCase1>;
export type ScriptsListResultItemPlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase2Status: any;
export interface ScriptsListResultItemPlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase2Status | null;
}
export declare const ScriptsListResultItemPlacementCase2: S.Schema<ScriptsListResultItemPlacementCase2>;
export type ScriptsListResultItemPlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase3Status: any;
export interface ScriptsListResultItemPlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase3Status | null;
}
export declare const ScriptsListResultItemPlacementCase3: S.Schema<ScriptsListResultItemPlacementCase3>;
export type ScriptsListResultItemPlacementCase4Mode = "targeted";
export declare const ScriptsListResultItemPlacementCase4Mode: any;
export type ScriptsListResultItemPlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase4Status: any;
export interface ScriptsListResultItemPlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase4Status | null;
}
export declare const ScriptsListResultItemPlacementCase4: S.Schema<ScriptsListResultItemPlacementCase4>;
export type ScriptsListResultItemPlacementCase5Mode = "targeted";
export declare const ScriptsListResultItemPlacementCase5Mode: any;
export type ScriptsListResultItemPlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase5Status: any;
export interface ScriptsListResultItemPlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase5Status | null;
}
export declare const ScriptsListResultItemPlacementCase5: S.Schema<ScriptsListResultItemPlacementCase5>;
export type ScriptsListResultItemPlacementCase6Mode = "targeted";
export declare const ScriptsListResultItemPlacementCase6Mode: any;
export type ScriptsListResultItemPlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase6Status: any;
export interface ScriptsListResultItemPlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase6Status | null;
}
export declare const ScriptsListResultItemPlacementCase6: S.Schema<ScriptsListResultItemPlacementCase6>;
export type ScriptsListResultItemPlacementCase7Mode = "targeted";
export declare const ScriptsListResultItemPlacementCase7Mode: any;
export type ScriptsListResultItemPlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const ScriptsListResultItemPlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type ScriptsListResultItemPlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const ScriptsListResultItemPlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type ScriptsListResultItemPlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsListResultItemPlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type ScriptsListResultItemPlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsListResultItemPlacementCase7TargetItem: any;
export type ScriptsListResultItemPlacementCase7TargetList = Array<ScriptsListResultItemPlacementCase7TargetItem>;
export declare const ScriptsListResultItemPlacementCase7TargetList: S.Schema<ScriptsListResultItemPlacementCase7TargetList>;
export type ScriptsListResultItemPlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementCase7Status: any;
export interface ScriptsListResultItemPlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsListResultItemPlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsListResultItemPlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsListResultItemPlacementCase7Status | null;
}
export declare const ScriptsListResultItemPlacementCase7: S.Schema<ScriptsListResultItemPlacementCase7>;
export type ScriptsListResultItemPlacement = ScriptsListResultItemPlacementCase0 | ScriptsListResultItemPlacementCase1 | ScriptsListResultItemPlacementCase2 | ScriptsListResultItemPlacementCase3 | ScriptsListResultItemPlacementCase4 | ScriptsListResultItemPlacementCase5 | ScriptsListResultItemPlacementCase6 | ScriptsListResultItemPlacementCase7;
export declare const ScriptsListResultItemPlacement: any;
export type ScriptsListResultItemPlacementMode = "smart" | "targeted";
export declare const ScriptsListResultItemPlacementMode: any;
export type ScriptsListResultItemPlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsListResultItemPlacementStatus: any;
export type ScriptsListResultItemRoutesItem = RoutesListResultItem;
export declare const ScriptsListResultItemRoutesItem: S.Schema<RoutesListResultItem>;
export type ScriptsListResultItemRoutesList = Array<RoutesListResultItem>;
export declare const ScriptsListResultItemRoutesList: S.Schema<ScriptsListResultItemRoutesList>;
export type ScriptsListResultItemTagsList = Array<string>;
export declare const ScriptsListResultItemTagsList: S.Schema<ScriptsListResultItemTagsList>;
export type ScriptsListResultItemTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export declare const ScriptsListResultItemTailConsumersItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsListResultItemTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export declare const ScriptsListResultItemTailConsumersList: S.Schema<ScriptsListResultItemTailConsumersList>;
export type ScriptsListResultItemUsageModel = "standard" | "bundled" | "unbound";
export declare const ScriptsListResultItemUsageModel: any;
export interface ScriptsListResultItem {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsListResultItemCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsListResultItemHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsListResultItemNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsListResultItemObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsListResultItemPlacement | null;
    placementMode?: ScriptsListResultItemPlacementMode | null;
    placementStatus?: ScriptsListResultItemPlacementStatus | null;
    /** Routes associated with the Worker. */
    routes?: ScriptsListResultItemRoutesList | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsListResultItemTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsListResultItemTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsListResultItemUsageModel | null;
}
export declare const ScriptsListResultItem: S.Schema<ScriptsListResultItem>;
export type ScriptsListResultList = Array<ScriptsListResultItem>;
export declare const ScriptsListResultList: S.Schema<ScriptsListResultList>;
export interface ListScriptsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScriptsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListScriptsResponse: S.Schema<ListScriptsResponse>;
export interface ListScriptSecretsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
}
export declare const ListScriptSecretsRequest: S.Schema<ListScriptSecretsRequest>;
export type ScriptsSecretsListResultItemSecretTextType = "secret_text";
export declare const ScriptsSecretsListResultItemSecretTextType: any;
export interface ScriptsSecretsListResultItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsListResultItemSecretTextType;
}
export declare const ScriptsSecretsListResultItemSecretText: S.Schema<ScriptsSecretsListResultItemSecretText>;
export type ScriptsSecretsListResultItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsSecretsListResultItemSecretKeyFormat: any;
export type ScriptsSecretsListResultItemSecretKeyType = "secret_key";
export declare const ScriptsSecretsListResultItemSecretKeyType: any;
export type ScriptsSecretsListResultItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsSecretsListResultItemSecretKeyUsagesItem: any;
export type ScriptsSecretsListResultItemSecretKeyUsagesList = Array<ScriptsSecretsListResultItemSecretKeyUsagesItem>;
export declare const ScriptsSecretsListResultItemSecretKeyUsagesList: S.Schema<ScriptsSecretsListResultItemSecretKeyUsagesList>;
export interface ScriptsSecretsListResultItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsListResultItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsListResultItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsListResultItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsSecretsListResultItemSecretKey: S.Schema<ScriptsSecretsListResultItemSecretKey>;
export type ScriptsSecretsListResultItem = ScriptsSecretsListResultItemSecretText | ScriptsSecretsListResultItemSecretKey;
export declare const ScriptsSecretsListResultItem: any;
export type ScriptsSecretsListResultList = Array<ScriptsSecretsListResultItem>;
export declare const ScriptsSecretsListResultList: S.Schema<ScriptsSecretsListResultList>;
export interface ListScriptSecretsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ScriptsSecretsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListScriptSecretsResponse: S.Schema<ListScriptSecretsResponse>;
export interface ListScriptVersionsRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script. */
    scriptName: string;
    /** Only return versions that can be used in a deployment. Ignores pagination. */
    deployable?: boolean;
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export declare const ListScriptVersionsRequest: S.Schema<ListScriptVersionsRequest>;
export type ScriptsVersionsListResponseItemsItemMetadataSource = "unknown" | "api" | "wrangler" | "terraform" | "dash" | "cf_cli" | "dash_template" | "integration" | "quick_editor" | "playground" | "workersci";
export declare const ScriptsVersionsListResponseItemsItemMetadataSource: any;
export interface ScriptsVersionsListResponseItemsItemMetadata {
    /** Email of the user who created the version. */
    authorEmail?: string | null;
    /** Identifier of the user who created the version. */
    authorId?: string | null;
    /** When the version was created. */
    createdOn?: string | null;
    /** Whether the version can be previewed. */
    hasPreview?: boolean | null;
    /** When the version was last modified. */
    modifiedOn?: string | null;
    /** The source of the version upload. */
    source?: ScriptsVersionsListResponseItemsItemMetadataSource | null;
}
export declare const ScriptsVersionsListResponseItemsItemMetadata: S.Schema<ScriptsVersionsListResponseItemsItemMetadata>;
export interface ScriptsVersionsListResponseItemsItem {
    /** Unique identifier for the version. */
    id?: string | null;
    metadata?: ScriptsVersionsListResponseItemsItemMetadata | null;
    /** Sequential version number. */
    number?: number | null;
}
export declare const ScriptsVersionsListResponseItemsItem: S.Schema<ScriptsVersionsListResponseItemsItem>;
export type ScriptsVersionsListResponseItemsList = Array<ScriptsVersionsListResponseItemsItem>;
export declare const ScriptsVersionsListResponseItemsList: S.Schema<ScriptsVersionsListResponseItemsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListScriptVersionsResponse {
    items?: ScriptsVersionsListResponseItemsList | null;
}
export declare const ListScriptVersionsResponse: S.Schema<ListScriptVersionsResponse>;
export interface LiveTailHeartbeatObservabilityTelemetryRequest {
    accountId: string;
    scriptId?: string;
}
export declare const LiveTailHeartbeatObservabilityTelemetryRequest: S.Schema<LiveTailHeartbeatObservabilityTelemetryRequest>;
export type LiveTailHeartbeatObservabilityTelemetryResponse = unknown;
export declare const LiveTailHeartbeatObservabilityTelemetryResponse: S.Schema<LiveTailHeartbeatObservabilityTelemetryResponse>;
export type ObservabilityTelemetryLiveTailRequestFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryLiveTailRequestFilterCombination: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FiltersList>;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0Kind: any;
export interface ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0: S.Schema<ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0>;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItem = ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItem: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersList = Array<ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersItem>;
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersList>;
export type ObservabilityTelemetryLiveTailRequestFiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0Kind: any;
export interface ObservabilityTelemetryLiveTailRequestFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryLiveTailRequestFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryLiveTailRequestFiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemCase0: S.Schema<ObservabilityTelemetryLiveTailRequestFiltersItemCase0>;
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryLiveTailRequestFiltersItem = ObservabilityTelemetryLiveTailRequestFiltersItemCase0 | ObservabilityTelemetryLiveTailRequestFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryLiveTailRequestFiltersItem: any;
export type ObservabilityTelemetryLiveTailRequestFiltersList = Array<ObservabilityTelemetryLiveTailRequestFiltersItem>;
export declare const ObservabilityTelemetryLiveTailRequestFiltersList: S.Schema<ObservabilityTelemetryLiveTailRequestFiltersList>;
export interface LiveTailObservabilityTelemetryRequest {
    accountId: string;
    /** Set a flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityTelemetryLiveTailRequestFilterCombination | (string & {});
    /** Apply filters to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityTelemetryLiveTailRequestFiltersList;
    scriptId?: string;
}
export declare const LiveTailObservabilityTelemetryRequest: S.Schema<LiveTailObservabilityTelemetryRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface LiveTailObservabilityTelemetryResponse {
    /** WebSocket URL clients connect to in order to stream live tail events. */
    wsUrl: string;
}
export declare const LiveTailObservabilityTelemetryResponse: S.Schema<LiveTailObservabilityTelemetryResponse>;
export type BetaWorkersEditRequestObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersEditRequestObservabilityLogsDestinationsList: S.Schema<BetaWorkersEditRequestObservabilityLogsDestinationsList>;
export interface BetaWorkersEditRequestObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersEditRequestObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export declare const BetaWorkersEditRequestObservabilityLogs: S.Schema<BetaWorkersEditRequestObservabilityLogs>;
export type BetaWorkersEditRequestObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersEditRequestObservabilityTracesDestinationsList: S.Schema<BetaWorkersEditRequestObservabilityTracesDestinationsList>;
export type BetaWorkersEditRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersEditRequestObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersEditRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersEditRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersEditRequestObservabilityTracesPropagationPolicy | (string & {});
}
export declare const BetaWorkersEditRequestObservabilityTraces: S.Schema<BetaWorkersEditRequestObservabilityTraces>;
export interface BetaWorkersEditRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Log settings for the Worker. */
    logs?: BetaWorkersEditRequestObservabilityLogs;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersEditRequestObservabilityTraces;
}
export declare const BetaWorkersEditRequestObservability: S.Schema<BetaWorkersEditRequestObservability>;
export type BetaWorkersEditRequestSubdomain = BetaWorkersCreateRequestSubdomain;
export declare const BetaWorkersEditRequestSubdomain: S.Schema<BetaWorkersCreateRequestSubdomain>;
export type BetaWorkersEditRequestTagsList = Array<string>;
export declare const BetaWorkersEditRequestTagsList: S.Schema<BetaWorkersEditRequestTagsList>;
export type BetaWorkersEditRequestTailConsumersItem = BetaWorkersCreateRequestTailConsumersItem;
export declare const BetaWorkersEditRequestTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersEditRequestTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersEditRequestTailConsumersList: S.Schema<BetaWorkersEditRequestTailConsumersList>;
export interface PatchBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersEditRequestObservability;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateRequestSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersEditRequestTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersEditRequestTailConsumersList;
}
export declare const PatchBetaWorkerRequest: S.Schema<PatchBetaWorkerRequest>;
export type BetaWorkersEditResponseObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersEditResponseObservabilityLogsDestinationsList: S.Schema<BetaWorkersEditResponseObservabilityLogsDestinationsList>;
export interface BetaWorkersEditResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersEditResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const BetaWorkersEditResponseObservabilityLogs: S.Schema<BetaWorkersEditResponseObservabilityLogs>;
export type BetaWorkersEditResponseObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersEditResponseObservabilityTracesDestinationsList: S.Schema<BetaWorkersEditResponseObservabilityTracesDestinationsList>;
export type BetaWorkersEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersEditResponseObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersEditResponseObservabilityTracesPropagationPolicy | null;
}
export declare const BetaWorkersEditResponseObservabilityTraces: S.Schema<BetaWorkersEditResponseObservabilityTraces>;
export interface BetaWorkersEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersEditResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersEditResponseObservabilityTraces | null;
}
export declare const BetaWorkersEditResponseObservability: S.Schema<BetaWorkersEditResponseObservability>;
export type BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export declare const BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsItem: S.Schema<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export declare const BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsList: S.Schema<BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsList>;
export type BetaWorkersEditResponseReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export declare const BetaWorkersEditResponseReferencesDomainsItem: S.Schema<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersEditResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export declare const BetaWorkersEditResponseReferencesDomainsList: S.Schema<BetaWorkersEditResponseReferencesDomainsList>;
export type BetaWorkersEditResponseReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export declare const BetaWorkersEditResponseReferencesDurableObjectsItem: S.Schema<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersEditResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export declare const BetaWorkersEditResponseReferencesDurableObjectsList: S.Schema<BetaWorkersEditResponseReferencesDurableObjectsList>;
export type BetaWorkersEditResponseReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export declare const BetaWorkersEditResponseReferencesQueuesItem: S.Schema<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersEditResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export declare const BetaWorkersEditResponseReferencesQueuesList: S.Schema<BetaWorkersEditResponseReferencesQueuesList>;
export type BetaWorkersEditResponseReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export declare const BetaWorkersEditResponseReferencesWorkersItem: S.Schema<BetaWorkersCreateResponseReferencesWorkersItem>;
export type BetaWorkersEditResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export declare const BetaWorkersEditResponseReferencesWorkersList: S.Schema<BetaWorkersEditResponseReferencesWorkersList>;
export interface BetaWorkersEditResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersEditResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersEditResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersEditResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersEditResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersEditResponseReferencesWorkersList;
}
export declare const BetaWorkersEditResponseReferences: S.Schema<BetaWorkersEditResponseReferences>;
export type BetaWorkersEditResponseSubdomain = BetaWorkersCreateResponseSubdomain;
export declare const BetaWorkersEditResponseSubdomain: S.Schema<BetaWorkersCreateResponseSubdomain>;
export type BetaWorkersEditResponseTagsList = Array<string>;
export declare const BetaWorkersEditResponseTagsList: S.Schema<BetaWorkersEditResponseTagsList>;
export type BetaWorkersEditResponseTailConsumersItem = BetaWorkersCreateRequestTailConsumersItem;
export declare const BetaWorkersEditResponseTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersEditResponseTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersEditResponseTailConsumersList: S.Schema<BetaWorkersEditResponseTailConsumersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersEditResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersEditResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersEditResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersEditResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
}
export declare const PatchBetaWorkerResponse: S.Schema<PatchBetaWorkerResponse>;
export type ObservabilityDestinationsUpdateRequestConfigurationHeadersMap = {
    [key: string]: string | undefined;
};
export declare const ObservabilityDestinationsUpdateRequestConfigurationHeadersMap: S.Schema<ObservabilityDestinationsUpdateRequestConfigurationHeadersMap>;
export type ObservabilityDestinationsUpdateRequestConfigurationType = "logpush";
export declare const ObservabilityDestinationsUpdateRequestConfigurationType: any;
export interface ObservabilityDestinationsUpdateRequestConfiguration {
    headers: ObservabilityDestinationsUpdateRequestConfigurationHeadersMap;
    type: ObservabilityDestinationsUpdateRequestConfigurationType | (string & {});
    url: string;
}
export declare const ObservabilityDestinationsUpdateRequestConfiguration: S.Schema<ObservabilityDestinationsUpdateRequestConfiguration>;
export interface PatchObservabilityDestinationRequest {
    accountId: string;
    slug: string;
    configuration: ObservabilityDestinationsUpdateRequestConfiguration;
    enabled: boolean;
}
export declare const PatchObservabilityDestinationRequest: S.Schema<PatchObservabilityDestinationRequest>;
export type ObservabilityDestinationsUpdateResponseConfigurationLogpushDataset = "opentelemetry-traces" | "opentelemetry-logs" | "opentelemetry-metrics";
export declare const ObservabilityDestinationsUpdateResponseConfigurationLogpushDataset: any;
export type ObservabilityDestinationsUpdateResponseConfigurationType = "logpush";
export declare const ObservabilityDestinationsUpdateResponseConfigurationType: any;
export interface ObservabilityDestinationsUpdateResponseConfiguration {
    destinationConf: string;
    logpushDataset: ObservabilityDestinationsUpdateResponseConfigurationLogpushDataset;
    logpushJob: number;
    type: ObservabilityDestinationsUpdateResponseConfigurationType;
    url: string;
}
export declare const ObservabilityDestinationsUpdateResponseConfiguration: S.Schema<ObservabilityDestinationsUpdateResponseConfiguration>;
export type ObservabilityDestinationsUpdateResponseScriptsList = Array<string>;
export declare const ObservabilityDestinationsUpdateResponseScriptsList: S.Schema<ObservabilityDestinationsUpdateResponseScriptsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchObservabilityDestinationResponse {
    configuration: ObservabilityDestinationsUpdateResponseConfiguration;
    enabled: boolean;
    name: string;
    scripts: ObservabilityDestinationsUpdateResponseScriptsList;
    slug: string;
}
export declare const PatchObservabilityDestinationResponse: S.Schema<PatchObservabilityDestinationResponse>;
export interface PatchScriptScriptAndVersionSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Worker settings to patch (bindings, tags, tail consumers, ...), JSON-encoded as the multipart `settings` part. */
    settings?: unknown;
}
export declare const PatchScriptScriptAndVersionSettingRequest: S.Schema<PatchScriptScriptAndVersionSettingRequest>;
export type ScriptsScriptAndVersionSettingsEditResponseAnnotations = ScriptsScriptAndVersionSettingsGetResponseAnnotations;
export declare const ScriptsScriptAndVersionSettingsEditResponseAnnotations: S.Schema<ScriptsScriptAndVersionSettingsGetResponseAnnotations>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAIType = "ai";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAIType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAI {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAIType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAI: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemAI>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchType = "ai_search";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearch {
    /** The user-chosen instance name. Must exist at deploy time. The worker can search, chat, update, and manage items/jobs on this instance. */
    instanceName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchType;
    /** The namespace the instance belongs to. Defaults to "default" if omitted. Customers who don't use namespaces can simply omit this field. */
    namespace?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearch: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearch>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespaceType = "ai_search_namespace";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespaceType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The user-chosen namespace name. Must exist before deploy -- Wrangler handles auto-creation on deploy failure (R2 bucket pattern). The "default" namespace is auto-created by config-api for new accounts. Grants full access (CRUD + search + chat) to all instances within the namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespaceType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespace: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespace>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngineType = "analytics_engine";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngineType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngine {
    /** The name of the dataset to bind to. */
    dataset: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngineType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngine: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngine>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssetsType = "assets";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssetsType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssets {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssetsType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssets: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssets>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowserType = "browser";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowserType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowser {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowserType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowser: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowser>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1Type = "d1";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1Type: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1 {
    /** Identifier of the D1 database to bind to. */
    databaseId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1Type;
    /** Identifier of the D1 database to bind to. */
    id?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlobType = "data_blob";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlobType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the data content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlobType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlob: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlob>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceType = "dispatch_namespace";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceType: any;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsItem = BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsItem: S.Schema<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList = Array<BetaWorkersVersionsCreateRequestBindingsItemDispatchNamespaceOutboundParamsItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundWorker = BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundWorker: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker>;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutbound {
    /** Pass information from the Dispatch Worker to the Outbound Worker through the parameters. */
    params?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutboundParamsList | null;
    /** Outbound worker. */
    worker?: BetaWorkersVersionsCreateResponseBindingsItemDispatchNamespaceOutboundWorker | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutbound: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutbound>;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the dispatch namespace. */
    namespace: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceType;
    /** Outbound worker. */
    outbound?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespaceOutbound | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespace: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespace>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespaceType = "durable_object_namespace";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespaceType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespaceType;
    /** The exported class name of the Durable Object. */
    className?: string | null;
    /** The dispatch namespace the Durable Object script belongs to. */
    dispatchNamespace?: string | null;
    /** The environment of the script_name to bind to. */
    environment?: string | null;
    /** Namespace identifier tag. */
    namespaceId?: string | null;
    /** The script where the Durable Object is defined, if it is external to this Worker. */
    scriptName?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespace: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespace>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdriveType = "hyperdrive";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdriveType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdrive {
    /** Identifier of the Hyperdrive connection to bind to. */
    id: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdriveType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdrive: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdrive>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemInheritType = "inherit";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemInheritType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemInherit {
    /** The name of the inherited binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemInheritType;
    /** The old name of the inherited binding. If set, the binding will be renamed from `old_name` to `name` in the new version. If not set, the binding will keep the same name between versions. */
    oldName?: string | null;
    /** Identifier for the version to inherit the binding from, which can be the version ID or the literal "latest" to inherit from the latest version. Defaults to inheriting the binding from the latest version. */
    versionId?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemInherit: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemInherit>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemImagesType = "images";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemImagesType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemImages {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemImagesType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemImages: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemImages>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemJsonType = "json";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemJsonType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemJson {
    /** JSON data to use. */
    json: unknown;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemJsonType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemJson: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemJson>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespaceType = "kv_namespace";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespaceType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespace {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespaceType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespace: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespace>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemMediaType = "media";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemMediaType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemMedia {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemMediaType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemMedia: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemMedia>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificateType = "mtls_certificate";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificateType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificate {
    /** Identifier of the certificate to bind to. */
    certificateId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificateType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificate: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificate>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainTextType = "plain_text";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainTextType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The text value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainTextType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainText: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainText>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelinesType = "pipelines";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelinesType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelines {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Pipeline to bind to. */
    pipeline: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelinesType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelines: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelines>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueueType = "queue";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueueType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueue {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the Queue to bind to. */
    queueName: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueueType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueue: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueue>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitSimple = BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitSimple: S.Schema<BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitType = "ratelimit";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimit {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the rate limit namespace to bind to. */
    namespaceId: string;
    /** The rate limit configuration. */
    simple: BetaWorkersVersionsCreateResponseBindingsItemRatelimitSimple;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimitType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimit: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimit>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketType = "r2_bucket";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketType: any;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketJurisdiction = "eu" | "fedramp" | "fedramp-high";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketJurisdiction: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2Bucket {
    /** R2 bucket to bind to. */
    bucketName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketType;
    /** The [jurisdiction](https://developers.cloudflare.com/r2/reference/data-location/#jurisdictional-restrictions) of the R2 bucket. */
    jurisdiction?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2BucketJurisdiction | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2Bucket: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2Bucket>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretTextType = "secret_text";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretTextType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretTextType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretText: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretText>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailType = "send_email";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailType: any;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList>;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmail {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailType;
    /** List of allowed destination addresses. */
    allowedDestinationAddresses?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedDestinationAddressesList | null;
    /** List of allowed sender addresses. */
    allowedSenderAddresses?: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmailAllowedSenderAddressesList | null;
    /** Destination address for the email. */
    destinationAddress?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmail: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmail>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemServiceType = "service";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemServiceType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of Worker to bind to. */
    service: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemServiceType;
    /** Entrypoint to invoke on the target Worker. */
    entrypoint?: string | null;
    /** Optional environment if the Worker utilizes one. */
    environment?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemService: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemService>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlobType = "text_blob";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlobType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlob {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the text content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlobType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlob: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlob>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorizeType = "vectorize";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorizeType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorize {
    /** Name of the Vectorize index to bind to. */
    indexName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorizeType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorize: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorize>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadataType = "version_metadata";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadataType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadata {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadataType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadata: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadata>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecretType = "secrets_store_secret";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecretType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecret {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Name of the secret in the store. */
    secretName: string;
    /** ID of the store containing the secret. */
    storeId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecretType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecret: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecret>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagshipType = "flagship";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagshipType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagship {
    /** ID of the Flagship app to bind to for feature flag evaluation. */
    appId: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagshipType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagship: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagship>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyFormat: any;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyType = "secret_key";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyType: any;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesItem: any;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesList = Array<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesList>;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKey: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKey>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflowType = "workflow";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflowType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflow {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflowType;
    /** Name of the Workflow to bind to. */
    workflowName: string;
    /** Class name of the Workflow. Should only be provided if the Workflow belongs to this script. */
    className?: string | null;
    /** Script name that contains the Workflow. If not provided, defaults to this script name. */
    scriptName?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflow: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflow>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModuleType = "wasm_module";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModuleType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModule {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The name of the file containing the WebAssembly module content. Only accepted for `service worker syntax` Workers. */
    part: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModuleType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModule: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModule>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCServiceType = "vpc_service";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCServiceType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCService {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** Identifier of the VPC service to bind to. */
    serviceId: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCServiceType;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCService: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCService>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetworkType = "vpc_network";
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetworkType: any;
export interface ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetwork {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetworkType;
    /** Identifier of the network to bind to. Only "cf1:network" is currently supported. Mutually exclusive with tunnel_id. */
    networkId?: string | null;
    /** UUID of the Cloudflare Tunnel to bind to. Mutually exclusive with network_id. */
    tunnelId?: string | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetwork: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetwork>;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsItem = ScriptsScriptAndVersionSettingsEditResponseBindingsItemAI | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearch | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAISearchNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAnalyticsEngine | ScriptsScriptAndVersionSettingsEditResponseBindingsItemAssets | ScriptsScriptAndVersionSettingsEditResponseBindingsItemBrowser | ScriptsScriptAndVersionSettingsEditResponseBindingsItemD1 | ScriptsScriptAndVersionSettingsEditResponseBindingsItemDataBlob | ScriptsScriptAndVersionSettingsEditResponseBindingsItemDispatchNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemDurableObjectNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemHyperdrive | ScriptsScriptAndVersionSettingsEditResponseBindingsItemInherit | ScriptsScriptAndVersionSettingsEditResponseBindingsItemImages | ScriptsScriptAndVersionSettingsEditResponseBindingsItemJson | ScriptsScriptAndVersionSettingsEditResponseBindingsItemKVNamespace | ScriptsScriptAndVersionSettingsEditResponseBindingsItemMedia | ScriptsScriptAndVersionSettingsEditResponseBindingsItemMTLSCertificate | ScriptsScriptAndVersionSettingsEditResponseBindingsItemPlainText | ScriptsScriptAndVersionSettingsEditResponseBindingsItemPipelines | ScriptsScriptAndVersionSettingsEditResponseBindingsItemQueue | ScriptsScriptAndVersionSettingsEditResponseBindingsItemRatelimit | ScriptsScriptAndVersionSettingsEditResponseBindingsItemR2Bucket | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretText | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSendEmail | ScriptsScriptAndVersionSettingsEditResponseBindingsItemService | ScriptsScriptAndVersionSettingsEditResponseBindingsItemTextBlob | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVectorize | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVersionMetadata | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretsStoreSecret | ScriptsScriptAndVersionSettingsEditResponseBindingsItemFlagship | ScriptsScriptAndVersionSettingsEditResponseBindingsItemSecretKey | ScriptsScriptAndVersionSettingsEditResponseBindingsItemWorkflow | ScriptsScriptAndVersionSettingsEditResponseBindingsItemWasmModule | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCService | ScriptsScriptAndVersionSettingsEditResponseBindingsItemVPCNetwork;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsItem: any;
export type ScriptsScriptAndVersionSettingsEditResponseBindingsList = Array<ScriptsScriptAndVersionSettingsEditResponseBindingsItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseBindingsList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseBindingsList>;
export type ScriptsScriptAndVersionSettingsEditResponseCacheOptions = BetaWorkersVersionsCreateResponseCacheOptions;
export declare const ScriptsScriptAndVersionSettingsEditResponseCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type ScriptsScriptAndVersionSettingsEditResponseCompatibilityFlagsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseCompatibilityFlagsList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseCompatibilityFlagsList>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueType = "worker" | "durable-object";
export declare const ScriptsScriptAndVersionSettingsEditResponseExportsValueType: any;
export type ScriptsScriptAndVersionSettingsEditResponseExportsValueCache = ScriptsScriptAndVersionSettingsGetResponseExportsValueCache;
export declare const ScriptsScriptAndVersionSettingsEditResponseExportsValueCache: S.Schema<ScriptsScriptAndVersionSettingsGetResponseExportsValueCache>;
export interface ScriptsScriptAndVersionSettingsEditResponseExportsValue {
    /** The kind of export. */
    type: ScriptsScriptAndVersionSettingsEditResponseExportsValueType;
    /** Cache override for this entrypoint. It applies only to */
    cache?: ScriptsScriptAndVersionSettingsGetResponseExportsValueCache | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseExportsValue: S.Schema<ScriptsScriptAndVersionSettingsEditResponseExportsValue>;
export type ScriptsScriptAndVersionSettingsEditResponseExportsMap = {
    [key: string]: ScriptsScriptAndVersionSettingsEditResponseExportsValue | undefined;
};
export declare const ScriptsScriptAndVersionSettingsEditResponseExportsMap: S.Schema<ScriptsScriptAndVersionSettingsEditResponseExportsMap>;
export type ScriptsScriptAndVersionSettingsEditResponseLimits = ScriptsScriptAndVersionSettingsGetResponseLimits;
export declare const ScriptsScriptAndVersionSettingsEditResponseLimits: S.Schema<ScriptsScriptAndVersionSettingsGetResponseLimits>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList>;
export interface ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigration {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationNewSqliteClassesList | null;
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigrationTransferredClassesList | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigration: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigration>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationRenamedClassesItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem = BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesItem: S.Schema<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList = Array<BetaWorkersVersionsCreateResponseMigrationsSingleStepMigrationTransferredClassesItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList>;
export interface ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem {
    /** A list of classes to delete Durable Object namespaces from. */
    deletedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemDeletedClassesList | null;
    /** A list of classes to create Durable Object namespaces from. */
    newClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewClassesList | null;
    /** A list of classes to create Durable Object namespaces with SQLite from. */
    newSqliteClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemNewSqliteClassesList | null;
    /** A list of classes with Durable Object namespaces that were renamed. */
    renamedClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemRenamedClassesList | null;
    /** A list of transfers for Durable Object namespaces from a different Worker and class to a class defined in this Worker. */
    transferredClasses?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItemTransferredClassesList | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList = Array<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList>;
export interface ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrations {
    /** Tag to set as the latest migration tag. */
    newTag?: string | null;
    /** Tag used to verify against the latest migration tag for this Worker. If they don't match, the upload is rejected. */
    oldTag?: string | null;
    /** Migrations to apply in order. */
    steps?: ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrationsStepsList | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrations: S.Schema<ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrations>;
export type ScriptsScriptAndVersionSettingsEditResponseMigrations = ScriptsScriptAndVersionSettingsEditResponseMigrationsSingleStepMigration | ScriptsScriptAndVersionSettingsEditResponseMigrationsWorkersMultipleStepMigrations;
export declare const ScriptsScriptAndVersionSettingsEditResponseMigrations: any;
export type ScriptsScriptAndVersionSettingsEditResponseObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseObservabilityLogsDestinationsList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseObservabilityLogsDestinationsList>;
export interface ScriptsScriptAndVersionSettingsEditResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsEditResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseObservabilityLogs: S.Schema<ScriptsScriptAndVersionSettingsEditResponseObservabilityLogs>;
export type ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesDestinationsList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesDestinationsList>;
export type ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesPropagationPolicy: any;
export interface ScriptsScriptAndVersionSettingsEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsScriptAndVersionSettingsEditResponseObservabilityTracesPropagationPolicy | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseObservabilityTraces: S.Schema<ScriptsScriptAndVersionSettingsEditResponseObservabilityTraces>;
export interface ScriptsScriptAndVersionSettingsEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: ScriptsScriptAndVersionSettingsEditResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsScriptAndVersionSettingsEditResponseObservabilityTraces | null;
}
export declare const ScriptsScriptAndVersionSettingsEditResponseObservability: S.Schema<ScriptsScriptAndVersionSettingsEditResponseObservability>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementModeMode = "smart";
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementModeMode: any;
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementMode {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementModeMode;
}
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementMode: S.Schema<ScriptsScriptAndVersionSettingsEditResponsePlacementMode>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementRegion = BetaWorkersVersionsCreateRequestPlacementRegion;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementRegion>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementHost = BetaWorkersVersionsCreateRequestPlacementHost;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementHost>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase4Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase4Mode: any;
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
}
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase4: S.Schema<ScriptsScriptAndVersionSettingsEditResponsePlacementCase4>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase5Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase5Mode: any;
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase5Mode;
}
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase5: S.Schema<ScriptsScriptAndVersionSettingsEditResponsePlacementCase5>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase6Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase6Mode: any;
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase6Mode;
}
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase6: S.Schema<ScriptsScriptAndVersionSettingsEditResponsePlacementCase6>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7Mode = "targeted";
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase7Mode: any;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItem: any;
export type ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetList = Array<ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetList: S.Schema<ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetList>;
export interface ScriptsScriptAndVersionSettingsEditResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsScriptAndVersionSettingsEditResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsScriptAndVersionSettingsEditResponsePlacementCase7TargetList;
}
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacementCase7: S.Schema<ScriptsScriptAndVersionSettingsEditResponsePlacementCase7>;
export type ScriptsScriptAndVersionSettingsEditResponsePlacement = ScriptsScriptAndVersionSettingsEditResponsePlacementMode | BetaWorkersVersionsCreateRequestPlacementRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementHost | ScriptsScriptAndVersionSettingsEditResponsePlacementCase4 | ScriptsScriptAndVersionSettingsEditResponsePlacementCase5 | ScriptsScriptAndVersionSettingsEditResponsePlacementCase6 | ScriptsScriptAndVersionSettingsEditResponsePlacementCase7;
export declare const ScriptsScriptAndVersionSettingsEditResponsePlacement: any;
export type ScriptsScriptAndVersionSettingsEditResponseTagsList = Array<string>;
export declare const ScriptsScriptAndVersionSettingsEditResponseTagsList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseTagsList>;
export type ScriptsScriptAndVersionSettingsEditResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export declare const ScriptsScriptAndVersionSettingsEditResponseTailConsumersItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsScriptAndVersionSettingsEditResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export declare const ScriptsScriptAndVersionSettingsEditResponseTailConsumersList: S.Schema<ScriptsScriptAndVersionSettingsEditResponseTailConsumersList>;
export type ScriptsScriptAndVersionSettingsEditResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const ScriptsScriptAndVersionSettingsEditResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchScriptScriptAndVersionSettingResponse {
    /** Annotations for the Worker version. Annotations are not inherited across settings updates; omitting this field means the new version will have no annotations. */
    annotations?: ScriptsScriptAndVersionSettingsGetResponseAnnotations | null;
    /** List of bindings attached to a Worker. You can find more about bindings on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/#bindings. */
    bindings?: ScriptsScriptAndVersionSettingsEditResponseBindingsList | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsScriptAndVersionSettingsEditResponseCompatibilityFlagsList | null;
    /** Declarative exports for the Worker. Worker entrypoint entries */
    exports?: ScriptsScriptAndVersionSettingsEditResponseExportsMap | null;
    /** Limits to apply for this Worker. */
    limits?: ScriptsScriptAndVersionSettingsGetResponseLimits | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Migrations to apply for Durable Objects associated with this Worker. */
    migrations?: ScriptsScriptAndVersionSettingsEditResponseMigrations | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsScriptAndVersionSettingsEditResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsScriptAndVersionSettingsEditResponsePlacement | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsScriptAndVersionSettingsEditResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsScriptAndVersionSettingsEditResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsScriptAndVersionSettingsEditResponseUsageModel | null;
}
export declare const PatchScriptScriptAndVersionSettingResponse: S.Schema<PatchScriptScriptAndVersionSettingResponse>;
export type ScriptsSettingsEditRequestObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsSettingsEditRequestObservabilityLogsDestinationsList: S.Schema<ScriptsSettingsEditRequestObservabilityLogsDestinationsList>;
export interface ScriptsSettingsEditRequestObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsSettingsEditRequestObservabilityLogsDestinationsList;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export declare const ScriptsSettingsEditRequestObservabilityLogs: S.Schema<ScriptsSettingsEditRequestObservabilityLogs>;
export type ScriptsSettingsEditRequestObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsSettingsEditRequestObservabilityTracesDestinationsList: S.Schema<ScriptsSettingsEditRequestObservabilityTracesDestinationsList>;
export type ScriptsSettingsEditRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsSettingsEditRequestObservabilityTracesPropagationPolicy: any;
export interface ScriptsSettingsEditRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsSettingsEditRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsSettingsEditRequestObservabilityTracesPropagationPolicy | (string & {});
}
export declare const ScriptsSettingsEditRequestObservabilityTraces: S.Schema<ScriptsSettingsEditRequestObservabilityTraces>;
export interface ScriptsSettingsEditRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number;
    /** Log settings for the Worker. */
    logs?: ScriptsSettingsEditRequestObservabilityLogs;
    /** Trace settings for the Worker. */
    traces?: ScriptsSettingsEditRequestObservabilityTraces;
}
export declare const ScriptsSettingsEditRequestObservability: S.Schema<ScriptsSettingsEditRequestObservability>;
export type ScriptsSettingsEditRequestTagsList = Array<string>;
export declare const ScriptsSettingsEditRequestTagsList: S.Schema<ScriptsSettingsEditRequestTagsList>;
export interface ScriptsSettingsEditRequestTailConsumersItem {
    /** Name of Worker that is to be the consumer. */
    service: string;
    /** Optional environment if the Worker utilizes one. */
    environment?: string;
    /** Optional dispatch namespace the script belongs to. */
    namespace?: string;
}
export declare const ScriptsSettingsEditRequestTailConsumersItem: S.Schema<ScriptsSettingsEditRequestTailConsumersItem>;
export type ScriptsSettingsEditRequestTailConsumersList = Array<ScriptsSettingsEditRequestTailConsumersItem>;
export declare const ScriptsSettingsEditRequestTailConsumersList: S.Schema<ScriptsSettingsEditRequestTailConsumersList>;
export interface PatchScriptSettingRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean;
    /** Observability settings for the Worker. */
    observability?: ScriptsSettingsEditRequestObservability;
    /** Tags associated with the Worker. */
    tags?: ScriptsSettingsEditRequestTagsList;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsSettingsEditRequestTailConsumersList;
}
export declare const PatchScriptSettingRequest: S.Schema<PatchScriptSettingRequest>;
export type ScriptsSettingsEditResponseObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsSettingsEditResponseObservabilityLogsDestinationsList: S.Schema<ScriptsSettingsEditResponseObservabilityLogsDestinationsList>;
export interface ScriptsSettingsEditResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsSettingsEditResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const ScriptsSettingsEditResponseObservabilityLogs: S.Schema<ScriptsSettingsEditResponseObservabilityLogs>;
export type ScriptsSettingsEditResponseObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsSettingsEditResponseObservabilityTracesDestinationsList: S.Schema<ScriptsSettingsEditResponseObservabilityTracesDestinationsList>;
export type ScriptsSettingsEditResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsSettingsEditResponseObservabilityTracesPropagationPolicy: any;
export interface ScriptsSettingsEditResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsSettingsEditResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsSettingsEditResponseObservabilityTracesPropagationPolicy | null;
}
export declare const ScriptsSettingsEditResponseObservabilityTraces: S.Schema<ScriptsSettingsEditResponseObservabilityTraces>;
export interface ScriptsSettingsEditResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: ScriptsSettingsEditResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsSettingsEditResponseObservabilityTraces | null;
}
export declare const ScriptsSettingsEditResponseObservability: S.Schema<ScriptsSettingsEditResponseObservability>;
export type ScriptsSettingsEditResponseTagsList = Array<string>;
export declare const ScriptsSettingsEditResponseTagsList: S.Schema<ScriptsSettingsEditResponseTagsList>;
export type ScriptsSettingsEditResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export declare const ScriptsSettingsEditResponseTailConsumersItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsSettingsEditResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export declare const ScriptsSettingsEditResponseTailConsumersList: S.Schema<ScriptsSettingsEditResponseTailConsumersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchScriptSettingResponse {
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsSettingsEditResponseObservability | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsSettingsEditResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsSettingsEditResponseTailConsumersList | null;
}
export declare const PatchScriptSettingResponse: S.Schema<PatchScriptSettingResponse>;
export interface PutAccountSettingRequest {
    /** Identifier. */
    accountId: string;
    defaultUsageModel?: string;
    greenCompute?: boolean;
}
export declare const PutAccountSettingRequest: S.Schema<PutAccountSettingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutAccountSettingResponse {
    defaultUsageModel?: string | null;
    greenCompute?: boolean | null;
}
export declare const PutAccountSettingResponse: S.Schema<PutAccountSettingResponse>;
export interface PutDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** Worker environment associated with the domain. */
    environment?: string;
    /** ID of the zone containing the domain hostname. */
    zoneId?: string;
    /** Name of the zone containing the domain hostname. */
    zoneName?: string;
    /** Serve Worker Previews on this custom domain as `<preview-name>.<hostname>`. */
    previewsEnabled?: boolean;
}
export declare const PutDomainRequest: S.Schema<PutDomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutDomainResponse {
    /** Immutable ID of the domain. */
    id: string;
    /** ID of the TLS certificate issued for the domain. */
    certId: string;
    /** Worker environment associated with the domain. */
    environment: string;
    /** Hostname of the domain. Can be either the zone apex or a subdomain of the zone. Requests to this hostname will be routed to the configured Worker. */
    hostname: string;
    /** Name of the Worker associated with the domain. Requests to the configured hostname will be routed to this Worker. */
    service: string;
    /** ID of the zone containing the domain hostname. */
    zoneId: string;
    /** Name of the zone containing the domain hostname. */
    zoneName: string;
    /** Whether Worker Previews are served on this custom domain. */
    previewsEnabled?: boolean | null;
}
export declare const PutDomainResponse: S.Schema<PutDomainResponse>;
export type ScriptsUpdateRequestBindingsInherit = "strict";
export declare const ScriptsUpdateRequestBindingsInherit: any;
export interface PutScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** When set to "strict", the upload will fail if any `inherit` type bindings cannot be resolved against the previous version of the Worker. Without this, unresolvable inherit bindings are silently dropped. */
    bindingsInherit?: ScriptsUpdateRequestBindingsInherit | (string & {});
    metadata: PutScriptMetadata;
    /** Module / asset file parts, appended under their own filenames. */
    files?: File | Blob | (File | Blob)[];
}
export declare const PutScriptRequest: S.Schema<PutScriptRequest>;
export type ScriptsUpdateResponseCacheOptions = BetaWorkersVersionsCreateResponseCacheOptions;
export declare const ScriptsUpdateResponseCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type ScriptsUpdateResponseCompatibilityFlagsList = Array<string>;
export declare const ScriptsUpdateResponseCompatibilityFlagsList: S.Schema<ScriptsUpdateResponseCompatibilityFlagsList>;
export type ScriptsUpdateResponseHandlersList = Array<string>;
export declare const ScriptsUpdateResponseHandlersList: S.Schema<ScriptsUpdateResponseHandlersList>;
export type ScriptsUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export declare const ScriptsUpdateResponseNamedHandlersItemHandlersList: S.Schema<ScriptsUpdateResponseNamedHandlersItemHandlersList>;
export interface ScriptsUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export declare const ScriptsUpdateResponseNamedHandlersItem: S.Schema<ScriptsUpdateResponseNamedHandlersItem>;
export type ScriptsUpdateResponseNamedHandlersList = Array<ScriptsUpdateResponseNamedHandlersItem>;
export declare const ScriptsUpdateResponseNamedHandlersList: S.Schema<ScriptsUpdateResponseNamedHandlersList>;
export type ScriptsUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsUpdateResponseObservabilityLogsDestinationsList: S.Schema<ScriptsUpdateResponseObservabilityLogsDestinationsList>;
export interface ScriptsUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const ScriptsUpdateResponseObservabilityLogs: S.Schema<ScriptsUpdateResponseObservabilityLogs>;
export type ScriptsUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsUpdateResponseObservabilityTracesDestinationsList: S.Schema<ScriptsUpdateResponseObservabilityTracesDestinationsList>;
export type ScriptsUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsUpdateResponseObservabilityTracesPropagationPolicy: any;
export interface ScriptsUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export declare const ScriptsUpdateResponseObservabilityTraces: S.Schema<ScriptsUpdateResponseObservabilityTraces>;
export interface ScriptsUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: ScriptsUpdateResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsUpdateResponseObservabilityTraces | null;
}
export declare const ScriptsUpdateResponseObservability: S.Schema<ScriptsUpdateResponseObservability>;
export type ScriptsUpdateResponsePlacementCase0Mode = "smart";
export declare const ScriptsUpdateResponsePlacementCase0Mode: any;
export type ScriptsUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase0Status: any;
export interface ScriptsUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase0Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase0: S.Schema<ScriptsUpdateResponsePlacementCase0>;
export type ScriptsUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase1Status: any;
export interface ScriptsUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase1Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase1: S.Schema<ScriptsUpdateResponsePlacementCase1>;
export type ScriptsUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase2Status: any;
export interface ScriptsUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase2Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase2: S.Schema<ScriptsUpdateResponsePlacementCase2>;
export type ScriptsUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase3Status: any;
export interface ScriptsUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase3Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase3: S.Schema<ScriptsUpdateResponsePlacementCase3>;
export type ScriptsUpdateResponsePlacementCase4Mode = "targeted";
export declare const ScriptsUpdateResponsePlacementCase4Mode: any;
export type ScriptsUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase4Status: any;
export interface ScriptsUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase4Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase4: S.Schema<ScriptsUpdateResponsePlacementCase4>;
export type ScriptsUpdateResponsePlacementCase5Mode = "targeted";
export declare const ScriptsUpdateResponsePlacementCase5Mode: any;
export type ScriptsUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase5Status: any;
export interface ScriptsUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase5Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase5: S.Schema<ScriptsUpdateResponsePlacementCase5>;
export type ScriptsUpdateResponsePlacementCase6Mode = "targeted";
export declare const ScriptsUpdateResponsePlacementCase6Mode: any;
export type ScriptsUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase6Status: any;
export interface ScriptsUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase6Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase6: S.Schema<ScriptsUpdateResponsePlacementCase6>;
export type ScriptsUpdateResponsePlacementCase7Mode = "targeted";
export declare const ScriptsUpdateResponsePlacementCase7Mode: any;
export type ScriptsUpdateResponsePlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const ScriptsUpdateResponsePlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type ScriptsUpdateResponsePlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const ScriptsUpdateResponsePlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type ScriptsUpdateResponsePlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsUpdateResponsePlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type ScriptsUpdateResponsePlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsUpdateResponsePlacementCase7TargetItem: any;
export type ScriptsUpdateResponsePlacementCase7TargetList = Array<ScriptsUpdateResponsePlacementCase7TargetItem>;
export declare const ScriptsUpdateResponsePlacementCase7TargetList: S.Schema<ScriptsUpdateResponsePlacementCase7TargetList>;
export type ScriptsUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementCase7Status: any;
export interface ScriptsUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsUpdateResponsePlacementCase7Status | null;
}
export declare const ScriptsUpdateResponsePlacementCase7: S.Schema<ScriptsUpdateResponsePlacementCase7>;
export interface ScriptsUpdateResponsePlacementCase8 {
    /** Targeted placement mode (no target echoed). */
    mode: ScriptsUpdateResponsePlacementCase7Mode;
}
export declare const ScriptsUpdateResponsePlacementCase8: S.Schema<ScriptsUpdateResponsePlacementCase8>;
export type ScriptsUpdateResponsePlacement = ScriptsUpdateResponsePlacementCase0 | ScriptsUpdateResponsePlacementCase1 | ScriptsUpdateResponsePlacementCase2 | ScriptsUpdateResponsePlacementCase3 | ScriptsUpdateResponsePlacementCase4 | ScriptsUpdateResponsePlacementCase5 | ScriptsUpdateResponsePlacementCase6 | ScriptsUpdateResponsePlacementCase7 | ScriptsUpdateResponsePlacementCase8;
export declare const ScriptsUpdateResponsePlacement: any;
export type ScriptsUpdateResponsePlacementMode = "smart" | "targeted";
export declare const ScriptsUpdateResponsePlacementMode: any;
export type ScriptsUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsUpdateResponsePlacementStatus: any;
export type ScriptsUpdateResponseTagsList = Array<string>;
export declare const ScriptsUpdateResponseTagsList: S.Schema<ScriptsUpdateResponseTagsList>;
export type ScriptsUpdateResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export declare const ScriptsUpdateResponseTailConsumersItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsUpdateResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export declare const ScriptsUpdateResponseTailConsumersList: S.Schema<ScriptsUpdateResponseTailConsumersList>;
export type ScriptsUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const ScriptsUpdateResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutScriptResponse {
    startupTimeMs: number;
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** The entry point for the script. */
    entryPoint?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsUpdateResponsePlacement | null;
    placementMode?: ScriptsUpdateResponsePlacementMode | null;
    placementStatus?: ScriptsUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsUpdateResponseUsageModel | null;
}
export declare const PutScriptResponse: S.Schema<PutScriptResponse>;
export interface PutScriptContentRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    cfworkerbodypart?: string;
    cfworkermainmodulepart?: string;
}
export declare const PutScriptContentRequest: S.Schema<PutScriptContentRequest>;
export type ScriptsContentUpdateResponseCacheOptions = BetaWorkersVersionsCreateResponseCacheOptions;
export declare const ScriptsContentUpdateResponseCacheOptions: S.Schema<BetaWorkersVersionsCreateResponseCacheOptions>;
export type ScriptsContentUpdateResponseCompatibilityFlagsList = Array<string>;
export declare const ScriptsContentUpdateResponseCompatibilityFlagsList: S.Schema<ScriptsContentUpdateResponseCompatibilityFlagsList>;
export type ScriptsContentUpdateResponseHandlersList = Array<string>;
export declare const ScriptsContentUpdateResponseHandlersList: S.Schema<ScriptsContentUpdateResponseHandlersList>;
export type ScriptsContentUpdateResponseNamedHandlersItemHandlersList = Array<string>;
export declare const ScriptsContentUpdateResponseNamedHandlersItemHandlersList: S.Schema<ScriptsContentUpdateResponseNamedHandlersItemHandlersList>;
export interface ScriptsContentUpdateResponseNamedHandlersItem {
    /** The names of handlers exported as part of the named export. */
    handlers?: ScriptsContentUpdateResponseNamedHandlersItemHandlersList | null;
    /** The name of the export. */
    name?: string | null;
}
export declare const ScriptsContentUpdateResponseNamedHandlersItem: S.Schema<ScriptsContentUpdateResponseNamedHandlersItem>;
export type ScriptsContentUpdateResponseNamedHandlersList = Array<ScriptsContentUpdateResponseNamedHandlersItem>;
export declare const ScriptsContentUpdateResponseNamedHandlersList: S.Schema<ScriptsContentUpdateResponseNamedHandlersList>;
export type ScriptsContentUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export declare const ScriptsContentUpdateResponseObservabilityLogsDestinationsList: S.Schema<ScriptsContentUpdateResponseObservabilityLogsDestinationsList>;
export interface ScriptsContentUpdateResponseObservabilityLogs {
    /** Whether logs are enabled for the Worker. */
    enabled: boolean;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs: boolean;
    /** A list of destinations where logs will be exported to. */
    destinations?: ScriptsContentUpdateResponseObservabilityLogsDestinationsList | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const ScriptsContentUpdateResponseObservabilityLogs: S.Schema<ScriptsContentUpdateResponseObservabilityLogs>;
export type ScriptsContentUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export declare const ScriptsContentUpdateResponseObservabilityTracesDestinationsList: S.Schema<ScriptsContentUpdateResponseObservabilityTracesDestinationsList>;
export type ScriptsContentUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const ScriptsContentUpdateResponseObservabilityTracesPropagationPolicy: any;
export interface ScriptsContentUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: ScriptsContentUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: ScriptsContentUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export declare const ScriptsContentUpdateResponseObservabilityTraces: S.Schema<ScriptsContentUpdateResponseObservabilityTraces>;
export interface ScriptsContentUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled: boolean;
    /** The sampling rate for incoming requests. From 0 to 1 (1 = 100%, 0.1 = 10%). Default is 1. */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: ScriptsContentUpdateResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: ScriptsContentUpdateResponseObservabilityTraces | null;
}
export declare const ScriptsContentUpdateResponseObservability: S.Schema<ScriptsContentUpdateResponseObservability>;
export type ScriptsContentUpdateResponsePlacementCase0Mode = "smart";
export declare const ScriptsContentUpdateResponsePlacementCase0Mode: any;
export type ScriptsContentUpdateResponsePlacementCase0Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase0Status: any;
export interface ScriptsContentUpdateResponsePlacementCase0 {
    /** Enables [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    mode: ScriptsContentUpdateResponsePlacementCase0Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase0Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase0: S.Schema<ScriptsContentUpdateResponsePlacementCase0>;
export type ScriptsContentUpdateResponsePlacementCase1Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase1Status: any;
export interface ScriptsContentUpdateResponsePlacementCase1 {
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase1Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase1: S.Schema<ScriptsContentUpdateResponsePlacementCase1>;
export type ScriptsContentUpdateResponsePlacementCase2Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase2Status: any;
export interface ScriptsContentUpdateResponsePlacementCase2 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase2Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase2: S.Schema<ScriptsContentUpdateResponsePlacementCase2>;
export type ScriptsContentUpdateResponsePlacementCase3Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase3Status: any;
export interface ScriptsContentUpdateResponsePlacementCase3 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase3Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase3: S.Schema<ScriptsContentUpdateResponsePlacementCase3>;
export type ScriptsContentUpdateResponsePlacementCase4Mode = "targeted";
export declare const ScriptsContentUpdateResponsePlacementCase4Mode: any;
export type ScriptsContentUpdateResponsePlacementCase4Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase4Status: any;
export interface ScriptsContentUpdateResponsePlacementCase4 {
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase4Mode;
    /** Cloud region for targeted placement in format 'provider:region'. */
    region: string;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase4Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase4: S.Schema<ScriptsContentUpdateResponsePlacementCase4>;
export type ScriptsContentUpdateResponsePlacementCase5Mode = "targeted";
export declare const ScriptsContentUpdateResponsePlacementCase5Mode: any;
export type ScriptsContentUpdateResponsePlacementCase5Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase5Status: any;
export interface ScriptsContentUpdateResponsePlacementCase5 {
    /** HTTP hostname for targeted placement. */
    hostname: string;
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase5Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase5Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase5: S.Schema<ScriptsContentUpdateResponsePlacementCase5>;
export type ScriptsContentUpdateResponsePlacementCase6Mode = "targeted";
export declare const ScriptsContentUpdateResponsePlacementCase6Mode: any;
export type ScriptsContentUpdateResponsePlacementCase6Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase6Status: any;
export interface ScriptsContentUpdateResponsePlacementCase6 {
    /** TCP host and port for targeted placement. */
    host: string;
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase6Mode;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase6Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase6: S.Schema<ScriptsContentUpdateResponsePlacementCase6>;
export type ScriptsContentUpdateResponsePlacementCase7Mode = "targeted";
export declare const ScriptsContentUpdateResponsePlacementCase7Mode: any;
export type ScriptsContentUpdateResponsePlacementCase7TargetItemRegion = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion;
export declare const ScriptsContentUpdateResponsePlacementCase7TargetItemRegion: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion>;
export type ScriptsContentUpdateResponsePlacementCase7TargetItemHostname = BetaWorkersVersionsCreateRequestPlacementHostname;
export declare const ScriptsContentUpdateResponsePlacementCase7TargetItemHostname: S.Schema<BetaWorkersVersionsCreateRequestPlacementHostname>;
export type ScriptsContentUpdateResponsePlacementCase7TargetItemHost = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsContentUpdateResponsePlacementCase7TargetItemHost: S.Schema<BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost>;
export type ScriptsContentUpdateResponsePlacementCase7TargetItem = BetaWorkersVersionsCreateRequestPlacementCase7TargetItemRegion | BetaWorkersVersionsCreateRequestPlacementHostname | BetaWorkersVersionsCreateRequestPlacementCase7TargetItemHost;
export declare const ScriptsContentUpdateResponsePlacementCase7TargetItem: any;
export type ScriptsContentUpdateResponsePlacementCase7TargetList = Array<ScriptsContentUpdateResponsePlacementCase7TargetItem>;
export declare const ScriptsContentUpdateResponsePlacementCase7TargetList: S.Schema<ScriptsContentUpdateResponsePlacementCase7TargetList>;
export type ScriptsContentUpdateResponsePlacementCase7Status = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementCase7Status: any;
export interface ScriptsContentUpdateResponsePlacementCase7 {
    /** Targeted placement mode. */
    mode: ScriptsContentUpdateResponsePlacementCase7Mode;
    /** Array of placement targets (currently limited to single target). */
    target: ScriptsContentUpdateResponsePlacementCase7TargetList;
    /** The last time the script was analyzed for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    lastAnalyzedAt?: string | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    status?: ScriptsContentUpdateResponsePlacementCase7Status | null;
}
export declare const ScriptsContentUpdateResponsePlacementCase7: S.Schema<ScriptsContentUpdateResponsePlacementCase7>;
export type ScriptsContentUpdateResponsePlacement = ScriptsContentUpdateResponsePlacementCase0 | ScriptsContentUpdateResponsePlacementCase1 | ScriptsContentUpdateResponsePlacementCase2 | ScriptsContentUpdateResponsePlacementCase3 | ScriptsContentUpdateResponsePlacementCase4 | ScriptsContentUpdateResponsePlacementCase5 | ScriptsContentUpdateResponsePlacementCase6 | ScriptsContentUpdateResponsePlacementCase7;
export declare const ScriptsContentUpdateResponsePlacement: any;
export type ScriptsContentUpdateResponsePlacementMode = "smart" | "targeted";
export declare const ScriptsContentUpdateResponsePlacementMode: any;
export type ScriptsContentUpdateResponsePlacementStatus = "SUCCESS" | "UNSUPPORTED_APPLICATION" | "INSUFFICIENT_INVOCATIONS";
export declare const ScriptsContentUpdateResponsePlacementStatus: any;
export type ScriptsContentUpdateResponseTagsList = Array<string>;
export declare const ScriptsContentUpdateResponseTagsList: S.Schema<ScriptsContentUpdateResponseTagsList>;
export type ScriptsContentUpdateResponseTailConsumersItem = ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem;
export declare const ScriptsContentUpdateResponseTailConsumersItem: S.Schema<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export type ScriptsContentUpdateResponseTailConsumersList = Array<ScriptsScriptAndVersionSettingsGetResponseTailConsumersItem>;
export declare const ScriptsContentUpdateResponseTailConsumersList: S.Schema<ScriptsContentUpdateResponseTailConsumersList>;
export type ScriptsContentUpdateResponseUsageModel = "standard" | "bundled" | "unbound";
export declare const ScriptsContentUpdateResponseUsageModel: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutScriptContentResponse {
    /** The name used to identify the script. */
    id?: string | null;
    /** Global CacheW configuration for the Worker. When caching is on, */
    cacheOptions?: BetaWorkersVersionsCreateResponseCacheOptions | null;
    /** Date indicating targeted support in the Workers runtime. Backwards incompatible fixes to the runtime following this date will not affect this Worker. */
    compatibilityDate?: string | null;
    /** Flags that enable or disable certain features in the Workers runtime. Used to enable upcoming features or opt in or out of specific changes not included in a `compatibility_date`. */
    compatibilityFlags?: ScriptsContentUpdateResponseCompatibilityFlagsList | null;
    /** When the script was created. */
    createdOn?: string | null;
    /** Hashed script content, can be used in a If-None-Match header when updating. */
    etag?: string | null;
    /** The names of handlers exported as part of the default export. */
    handlers?: ScriptsContentUpdateResponseHandlersList | null;
    /** Whether a Worker contains assets. */
    hasAssets?: boolean | null;
    /** Whether a Worker contains modules. */
    hasModules?: boolean | null;
    /** The client most recently used to deploy this Worker. */
    lastDeployedFrom?: string | null;
    /** Whether Logpush is turned on for the Worker. */
    logpush?: boolean | null;
    /** The tag of the Durable Object migration that was most recently applied for this Worker. */
    migrationTag?: string | null;
    /** When the script was last modified. */
    modifiedOn?: string | null;
    /** Named exports, such as Durable Object class implementations and named entrypoints. */
    namedHandlers?: ScriptsContentUpdateResponseNamedHandlersList | null;
    /** Observability settings for the Worker. */
    observability?: ScriptsContentUpdateResponseObservability | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placement?: ScriptsContentUpdateResponsePlacement | null;
    /** Configuration for [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). Specify mode='smart' for Smart Placement, or one of region/hostname/host. */
    placementMode?: ScriptsContentUpdateResponsePlacementMode | null;
    /** Status of [Smart Placement](https://developers.cloudflare.com/workers/configuration/smart-placement). */
    placementStatus?: ScriptsContentUpdateResponsePlacementStatus | null;
    /** The immutable ID of the script. */
    tag?: string | null;
    /** Tags associated with the Worker. */
    tags?: ScriptsContentUpdateResponseTagsList | null;
    /** List of Workers that will consume logs from the attached Worker. */
    tailConsumers?: ScriptsContentUpdateResponseTailConsumersList | null;
    /** Usage model for the Worker invocations. */
    usageModel?: ScriptsContentUpdateResponseUsageModel | null;
}
export declare const PutScriptContentResponse: S.Schema<PutScriptContentResponse>;
export interface ScriptsSchedulesUpdateRequestBodyItem {
    cron: string;
    createdOn?: string;
    modifiedOn?: string;
}
export declare const ScriptsSchedulesUpdateRequestBodyItem: S.Schema<ScriptsSchedulesUpdateRequestBodyItem>;
export type ScriptsSchedulesUpdateRequestBodyList = Array<ScriptsSchedulesUpdateRequestBodyItem>;
export declare const ScriptsSchedulesUpdateRequestBodyList: S.Schema<ScriptsSchedulesUpdateRequestBodyList>;
export interface PutScriptScheduleRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    body: ScriptsSchedulesUpdateRequestBodyList;
}
export declare const PutScriptScheduleRequest: S.Schema<PutScriptScheduleRequest>;
export type ScriptsSchedulesUpdateResponseSchedulesItem = ScriptsSchedulesGetResponseSchedulesItem;
export declare const ScriptsSchedulesUpdateResponseSchedulesItem: S.Schema<ScriptsSchedulesGetResponseSchedulesItem>;
export type ScriptsSchedulesUpdateResponseSchedulesList = Array<ScriptsSchedulesGetResponseSchedulesItem>;
export declare const ScriptsSchedulesUpdateResponseSchedulesList: S.Schema<ScriptsSchedulesUpdateResponseSchedulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutScriptScheduleResponse {
    schedules: ScriptsSchedulesUpdateResponseSchedulesList;
}
export declare const PutScriptScheduleResponse: S.Schema<PutScriptScheduleResponse>;
export type ScriptsSecretsUpdateRequestType = "secret_text" | "secret_key";
export declare const ScriptsSecretsUpdateRequestType: any;
export type ScriptsSecretsUpdateRequestFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsSecretsUpdateRequestFormat: any;
export type ScriptsSecretsUpdateRequestUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsSecretsUpdateRequestUsagesItem: any;
export type ScriptsSecretsUpdateRequestUsagesList = Array<ScriptsSecretsUpdateRequestUsagesItem | (string & {})>;
export declare const ScriptsSecretsUpdateRequestUsagesList: S.Schema<ScriptsSecretsUpdateRequestUsagesList>;
export interface PutScriptSecretRequest {
    /** Identifier. */
    accountId: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text?: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsUpdateRequestType | (string & {});
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm?: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format?: ScriptsSecretsUpdateRequestFormat | (string & {});
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages?: ScriptsSecretsUpdateRequestUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown;
}
export declare const PutScriptSecretRequest: S.Schema<PutScriptSecretRequest>;
export type ScriptsSecretsUpdateResultSecretTextType = "secret_text";
export declare const ScriptsSecretsUpdateResultSecretTextType: any;
export interface ScriptsSecretsUpdateResultSecretText {
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The secret value to use. */
    text: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsUpdateResultSecretTextType;
}
export declare const ScriptsSecretsUpdateResultSecretText: S.Schema<ScriptsSecretsUpdateResultSecretText>;
export type ScriptsSecretsUpdateResultSecretKeyFormat = "raw" | "pkcs8" | "spki" | "jwk";
export declare const ScriptsSecretsUpdateResultSecretKeyFormat: any;
export type ScriptsSecretsUpdateResultSecretKeyType = "secret_key";
export declare const ScriptsSecretsUpdateResultSecretKeyType: any;
export type ScriptsSecretsUpdateResultSecretKeyUsagesItem = "encrypt" | "decrypt" | "sign" | "verify" | "deriveKey" | "deriveBits" | "wrapKey" | "unwrapKey";
export declare const ScriptsSecretsUpdateResultSecretKeyUsagesItem: any;
export type ScriptsSecretsUpdateResultSecretKeyUsagesList = Array<ScriptsSecretsUpdateResultSecretKeyUsagesItem>;
export declare const ScriptsSecretsUpdateResultSecretKeyUsagesList: S.Schema<ScriptsSecretsUpdateResultSecretKeyUsagesList>;
export interface ScriptsSecretsUpdateResultSecretKey {
    /** Algorithm-specific key parameters. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#algorithm). */
    algorithm: unknown;
    /** Data format of the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#format). */
    format: ScriptsSecretsUpdateResultSecretKeyFormat;
    /** A JavaScript variable name for the binding. */
    name: string;
    /** The kind of resource that the binding provides. */
    type: ScriptsSecretsUpdateResultSecretKeyType;
    /** Allowed operations with the key. [Learn more](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#keyUsages). */
    usages: ScriptsSecretsUpdateResultSecretKeyUsagesList;
    /** Base64-encoded key data. Required if `format` is "raw", "pkcs8", or "spki". */
    keyBase64?: string | null;
    /** Key data in [JSON Web Key](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/importKey#json_web_key) format. Required if `format` is "jwk". */
    keyJwk?: unknown | null;
}
export declare const ScriptsSecretsUpdateResultSecretKey: S.Schema<ScriptsSecretsUpdateResultSecretKey>;
export type ScriptsSecretsUpdateResult = ScriptsSecretsUpdateResultSecretText | ScriptsSecretsUpdateResultSecretKey;
export declare const ScriptsSecretsUpdateResult: any;
export type PutScriptSecretResponse = ScriptsSecretsUpdateResult;
export declare const PutScriptSecretResponse: S.Schema<PutScriptSecretResponse>;
export interface PutSubdomainRequest {
    /** Identifier. */
    accountId: string;
    subdomain: string;
}
export declare const PutSubdomainRequest: S.Schema<PutSubdomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSubdomainResponse {
    subdomain: string;
}
export declare const PutSubdomainResponse: S.Schema<PutSubdomainResponse>;
export type ObservabilityTelemetryQueryRequestTimeframe = ObservabilitySharedQueriesCreateRequestTimeframe;
export declare const ObservabilityTelemetryQueryRequestTimeframe: S.Schema<ObservabilitySharedQueriesCreateRequestTimeframe>;
export type ObservabilityTelemetryQueryRequestParametersCalculationsItemOperator = "uniq" | "count" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "COUNT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export declare const ObservabilityTelemetryQueryRequestParametersCalculationsItemOperator: any;
export type ObservabilityTelemetryQueryRequestParametersCalculationsItemKeyType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryQueryRequestParametersCalculationsItemKeyType: any;
export interface ObservabilityTelemetryQueryRequestParametersCalculationsItem {
    /** Aggregation operator to apply. Examples: count, avg, sum, min, max, median, p90, p95, p99, uniq, stddev, variance. */
    operator: ObservabilityTelemetryQueryRequestParametersCalculationsItemOperator | (string & {});
    /** Custom label for this calculation in the results. Useful for distinguishing multiple calculations. */
    alias?: string;
    /** Field name to calculate over. Must exist in the data — verify with the keys endpoint. Omit for operators that don't require a key (e.g. count). */
    key?: string;
    /** Data type of the key. Required when key is provided to ensure correct aggregation. */
    keyType?: ObservabilityTelemetryQueryRequestParametersCalculationsItemKeyType | (string & {});
}
export declare const ObservabilityTelemetryQueryRequestParametersCalculationsItem: S.Schema<ObservabilityTelemetryQueryRequestParametersCalculationsItem>;
export type ObservabilityTelemetryQueryRequestParametersCalculationsList = Array<ObservabilityTelemetryQueryRequestParametersCalculationsItem>;
export declare const ObservabilityTelemetryQueryRequestParametersCalculationsList: S.Schema<ObservabilityTelemetryQueryRequestParametersCalculationsList>;
export type ObservabilityTelemetryQueryRequestParametersDatasetsList = Array<string>;
export declare const ObservabilityTelemetryQueryRequestParametersDatasetsList: S.Schema<ObservabilityTelemetryQueryRequestParametersDatasetsList>;
export type ObservabilityTelemetryQueryRequestParametersFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryQueryRequestParametersFilterCombination: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FiltersList>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0Kind: any;
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0: S.Schema<ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItem = ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItem: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersList = Array<ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersItem>;
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersList>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0Kind: any;
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryQueryRequestParametersFiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemCase0: S.Schema<ObservabilityTelemetryQueryRequestParametersFiltersItemCase0>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryQueryRequestParametersFiltersItem = ObservabilityTelemetryQueryRequestParametersFiltersItemCase0 | ObservabilityTelemetryQueryRequestParametersFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryQueryRequestParametersFiltersItem: any;
export type ObservabilityTelemetryQueryRequestParametersFiltersList = Array<ObservabilityTelemetryQueryRequestParametersFiltersItem>;
export declare const ObservabilityTelemetryQueryRequestParametersFiltersList: S.Schema<ObservabilityTelemetryQueryRequestParametersFiltersList>;
export type ObservabilityTelemetryQueryRequestParametersGroupBysItemType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryQueryRequestParametersGroupBysItemType: any;
export interface ObservabilityTelemetryQueryRequestParametersGroupBysItem {
    /** Data type of the group-by field. */
    type: ObservabilityTelemetryQueryRequestParametersGroupBysItemType | (string & {});
    /** Field name to group results by (e.g. $metadata.service, $metadata.statusCode). */
    value: string;
}
export declare const ObservabilityTelemetryQueryRequestParametersGroupBysItem: S.Schema<ObservabilityTelemetryQueryRequestParametersGroupBysItem>;
export type ObservabilityTelemetryQueryRequestParametersGroupBysList = Array<ObservabilityTelemetryQueryRequestParametersGroupBysItem>;
export declare const ObservabilityTelemetryQueryRequestParametersGroupBysList: S.Schema<ObservabilityTelemetryQueryRequestParametersGroupBysList>;
export type ObservabilityTelemetryQueryRequestParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export declare const ObservabilityTelemetryQueryRequestParametersHavingsItemOperation: any;
export interface ObservabilityTelemetryQueryRequestParametersHavingsItem {
    /** Calculation alias or operator to filter on after aggregation. */
    key: string;
    /** Numeric comparison operator: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryRequestParametersHavingsItemOperation | (string & {});
    /** Threshold value to compare the calculation result against. */
    value: number;
}
export declare const ObservabilityTelemetryQueryRequestParametersHavingsItem: S.Schema<ObservabilityTelemetryQueryRequestParametersHavingsItem>;
export type ObservabilityTelemetryQueryRequestParametersHavingsList = Array<ObservabilityTelemetryQueryRequestParametersHavingsItem>;
export declare const ObservabilityTelemetryQueryRequestParametersHavingsList: S.Schema<ObservabilityTelemetryQueryRequestParametersHavingsList>;
export type ObservabilityTelemetryQueryRequestParametersNeedleValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryRequestParametersNeedleValue: any;
export interface ObservabilityTelemetryQueryRequestParametersNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryQueryRequestParametersNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export declare const ObservabilityTelemetryQueryRequestParametersNeedle: S.Schema<ObservabilityTelemetryQueryRequestParametersNeedle>;
export type ObservabilityTelemetryQueryRequestParametersOrderByOrder = "asc" | "desc";
export declare const ObservabilityTelemetryQueryRequestParametersOrderByOrder: any;
export interface ObservabilityTelemetryQueryRequestParametersOrderBy {
    /** Alias of the calculation to order results by. Must match the alias (or operator) of a calculation in the query. */
    value: string;
    /** Sort direction: 'asc' for ascending, 'desc' for descending. */
    order?: ObservabilityTelemetryQueryRequestParametersOrderByOrder | (string & {});
}
export declare const ObservabilityTelemetryQueryRequestParametersOrderBy: S.Schema<ObservabilityTelemetryQueryRequestParametersOrderBy>;
export interface ObservabilityTelemetryQueryRequestParameters {
    /** Aggregation calculations to compute (e.g. count, avg, p99). Each calculation produces aggregate values and optional time-series data. */
    calculations?: ObservabilityTelemetryQueryRequestParametersCalculationsList;
    /** Datasets to query. Leave empty to query all available datasets. */
    datasets?: ObservabilityTelemetryQueryRequestParametersDatasetsList;
    /** Logical operator for combining top-level filters: 'and' (all must match) or 'or' (any must match). Defaults to 'and'. */
    filterCombination?: ObservabilityTelemetryQueryRequestParametersFilterCombination | (string & {});
    /** Filters to narrow query results. Use the keys and values endpoints to discover available fields before building filters. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilityTelemetryQueryRequestParametersFiltersList;
    /** Fields to group calculation results by. Only applicable when the query view is 'calculations'. Produces per-group aggregate values. */
    groupBys?: ObservabilityTelemetryQueryRequestParametersGroupBysList;
    /** Post-aggregation filters applied to calculation results. Use to filter groups after aggregation (e.g. only groups where count > 100). */
    havings?: ObservabilityTelemetryQueryRequestParametersHavingsList;
    /** Maximum number of group-by rows to return in calculation results. A value of 10 is a sensible default for most use cases. */
    limit?: number;
    /** Full-text search expression applied across all event fields. Matches events containing the specified text. */
    needle?: ObservabilityTelemetryQueryRequestParametersNeedle;
    /** Ordering for grouped calculation results. Only effective when a group-by is present. */
    orderBy?: ObservabilityTelemetryQueryRequestParametersOrderBy;
}
export declare const ObservabilityTelemetryQueryRequestParameters: S.Schema<ObservabilityTelemetryQueryRequestParameters>;
export type ObservabilityTelemetryQueryRequestView = "traces" | "events" | "calculations" | "invocations" | "requests" | "agents";
export declare const ObservabilityTelemetryQueryRequestView: any;
export interface QueryObservabilityTelemetryRequest {
    accountId: string;
    /** Identifier for the query. When parameters are omitted, this ID is used to load a previously saved query's parameters. When providing parameters inline, pass any identifier (e.g. an ad-hoc ID). */
    queryId: string;
    /** Timeframe for the query using Unix timestamps in milliseconds. Narrower timeframes produce faster responses and more specific results. */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** When true, includes time-series data in the response. */
    chart?: boolean;
    /** When true, includes a comparison dataset from the previous time period of equal length. */
    compare?: boolean;
    /** When true, executes the query without persisting the results. Useful for validation or previewing. */
    dry?: boolean;
    /** Number of time-series buckets. Only used when view is 'calculations'. Omit to let the system auto-detect an appropriate granularity. */
    granularity?: number;
    /** When true, omits time-series data from the response and returns only aggregated values. Reduces response size when series are not needed. */
    ignoreSeries?: boolean;
    /** Maximum number of events to return when view is 'events'. Also controls the number of group-by rows when view is 'calculations'. */
    limit?: number;
    /** Cursor for pagination in event, trace, and invocation views. Pass the $metadata.id of the last returned item to fetch the next page. */
    offset?: string;
    /** Numeric offset for paginating grouped/pattern results (top-N lists). Use together with limit. Not used by cursor-based pagination. */
    offsetBy?: number;
    /** Pagination direction: 'next' for forward, 'prev' for backward. */
    offsetDirection?: string;
    /** Query parameters defining what data to retrieve — filters, calculations, group-bys, and ordering. In practice this should always be provided for ad-hoc queries. Only omit when executing a previously saved query by queryId. Use the keys and values endpoints to discover available fields before building filters. */
    parameters?: ObservabilityTelemetryQueryRequestParameters;
    /** Controls the shape of the response. 'events': individual log lines matching the query. 'calculations': aggregated metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series. 'invocations': events grouped by request ID. 'traces': distributed trace summaries. 'agents': Durable Object agent summaries. */
    view?: ObservabilityTelemetryQueryRequestView | (string & {});
}
export declare const QueryObservabilityTelemetryRequest: S.Schema<QueryObservabilityTelemetryRequest>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemOperator = "uniq" | "count" | "max" | "min" | "sum" | "avg" | "median" | "p001" | "p01" | "p05" | "p10" | "p25" | "p75" | "p90" | "p95" | "p99" | "p999" | "stddev" | "variance" | "COUNT_DISTINCT" | "COUNT" | "MAX" | "MIN" | "SUM" | "AVG" | "MEDIAN" | "P001" | "P01" | "P05" | "P10" | "P25" | "P75" | "P90" | "P95" | "P99" | "P999" | "STDDEV" | "VARIANCE";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemOperator: any;
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemKeyType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemKeyType: any;
export interface ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItem {
    operator: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemOperator;
    alias?: string | null;
    key?: string | null;
    keyType?: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItemKeyType | null;
}
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItem: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItem>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsItem>;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsList: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsList>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersDatasetsList = Array<string>;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersDatasetsList: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersDatasetsList>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFilterCombination: any;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FiltersList>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0Kind: any;
export interface ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FilterCombination;
    filters: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafOperation;
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafType;
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafKind | null;
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeafValue | null;
}
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItem = ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemCase0 | ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItem: any;
export type ObservabilityTelemetryQueryResponseRunQueryParametersFiltersList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersFiltersItem>;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersFiltersList: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersFiltersList>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItemType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItemType: any;
export interface ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItem {
    type: ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItemType;
    value: string;
}
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItem: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItem>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysItem>;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysList: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysList>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItemOperation = "eq" | "neq" | "gt" | "gte" | "lt" | "lte";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItemOperation: any;
export interface ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItem {
    key: string;
    operation: ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItemOperation;
    value: number;
}
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItem: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItem>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersHavingsList = Array<ObservabilityTelemetryQueryResponseRunQueryParametersHavingsItem>;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersHavingsList: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersHavingsList>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersNeedle = ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle;
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersNeedle: S.Schema<ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle>;
export type ObservabilityTelemetryQueryResponseRunQueryParametersOrderByOrder = "asc" | "desc";
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersOrderByOrder: any;
export interface ObservabilityTelemetryQueryResponseRunQueryParametersOrderBy {
    /** Configure which Calculation to order the results by. */
    value: string;
    /** Set the order of the results */
    order?: ObservabilityTelemetryQueryResponseRunQueryParametersOrderByOrder | null;
}
export declare const ObservabilityTelemetryQueryResponseRunQueryParametersOrderBy: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParametersOrderBy>;
export interface ObservabilityTelemetryQueryResponseRunQueryParameters {
    /** Create Calculations to compute as part of the query. */
    calculations?: ObservabilityTelemetryQueryResponseRunQueryParametersCalculationsList | null;
    /** Set the Datasets to query. Leave it empty to query all the datasets. */
    datasets?: ObservabilityTelemetryQueryResponseRunQueryParametersDatasetsList | null;
    /** Set a Flag to describe how to combine the filters on the query. */
    filterCombination?: ObservabilityTelemetryQueryResponseRunQueryParametersFilterCombination | null;
    /** Configure the Filters to apply to the query. Supports nested groups via kind: 'group'. */
    filters?: ObservabilityTelemetryQueryResponseRunQueryParametersFiltersList | null;
    /** Define how to group the results of the query. */
    groupBys?: ObservabilityTelemetryQueryResponseRunQueryParametersGroupBysList | null;
    /** Configure the Having clauses that filter on calculations in the query result. */
    havings?: ObservabilityTelemetryQueryResponseRunQueryParametersHavingsList | null;
    /** Set a limit on the number of results / records returned by the query */
    limit?: number | null;
    /** Define an expression to search using full-text search. */
    needle?: ObservabilitySharedQueriesGetResponseRunQueryParametersNeedle | null;
    /** Configure the order of the results returned by the query. */
    orderBy?: ObservabilityTelemetryQueryResponseRunQueryParametersOrderBy | null;
}
export declare const ObservabilityTelemetryQueryResponseRunQueryParameters: S.Schema<ObservabilityTelemetryQueryResponseRunQueryParameters>;
export interface ObservabilityTelemetryQueryResponseRunQuery {
    id: string;
    /** If the query wasn't explcitly saved */
    adhoc: boolean;
    created: string;
    createdBy: string;
    description: string;
    /** Query name */
    name: string;
    parameters: ObservabilityTelemetryQueryResponseRunQueryParameters;
    updated: string;
    updatedBy: string;
}
export declare const ObservabilityTelemetryQueryResponseRunQuery: S.Schema<ObservabilityTelemetryQueryResponseRunQuery>;
export type ObservabilityTelemetryQueryResponseRunStatus = "STARTED" | "COMPLETED";
export declare const ObservabilityTelemetryQueryResponseRunStatus: any;
export type ObservabilityTelemetryQueryResponseRunTimeframe = ObservabilitySharedQueriesCreateRequestTimeframe;
export declare const ObservabilityTelemetryQueryResponseRunTimeframe: S.Schema<ObservabilitySharedQueriesCreateRequestTimeframe>;
export type ObservabilityTelemetryQueryResponseRunStatistics = ObservabilitySharedQueriesGetResponseRunStatistics;
export declare const ObservabilityTelemetryQueryResponseRunStatistics: S.Schema<ObservabilitySharedQueriesGetResponseRunStatistics>;
export interface ObservabilityTelemetryQueryResponseRun {
    /** Unique identifier for this query run. */
    id: string;
    /** Cloudflare account ID that owns this query run. */
    accountId: string;
    /** Whether this was a dry run (results not persisted). */
    dry: boolean;
    /** Number of time-series buckets used for the query. Higher values produce more detailed series data. */
    granularity: number;
    /** A saved query definition with its parameters, metadata, and ownership information. */
    query: ObservabilityTelemetryQueryResponseRunQuery;
    /** Current execution status of the query run. */
    status: ObservabilityTelemetryQueryResponseRunStatus;
    /** Time range for the query execution */
    timeframe: ObservabilitySharedQueriesCreateRequestTimeframe;
    /** ID of the user who initiated the query run. */
    userId: string;
    /** ISO-8601 timestamp when the query run was created. */
    created?: string | null;
    /** Query performance statistics from the database (does not include network latency). */
    statistics?: ObservabilitySharedQueriesGetResponseRunStatistics | null;
    /** ISO-8601 timestamp when the query run was last updated. */
    updated?: string | null;
}
export declare const ObservabilityTelemetryQueryResponseRun: S.Schema<ObservabilityTelemetryQueryResponseRun>;
export type ObservabilityTelemetryQueryResponseStatistics = ObservabilitySharedQueriesGetResponseRunStatistics;
export declare const ObservabilityTelemetryQueryResponseStatistics: S.Schema<ObservabilitySharedQueriesGetResponseRunStatistics>;
export type ObservabilityTelemetryQueryResponseAgentsItemEventTypeCountsMap = {
    [key: string]: number | undefined;
};
export declare const ObservabilityTelemetryQueryResponseAgentsItemEventTypeCountsMap: S.Schema<ObservabilityTelemetryQueryResponseAgentsItemEventTypeCountsMap>;
export interface ObservabilityTelemetryQueryResponseAgentsItem {
    /** Class name of the Durable Object agent. */
    agentClass: string;
    /** Breakdown of event counts by event type. */
    eventTypeCounts: ObservabilityTelemetryQueryResponseAgentsItemEventTypeCountsMap;
    /** Timestamp of the earliest event from this agent in the queried window (Unix epoch ms). */
    firstEventMs: number;
    /** Whether the agent emitted any error events in the queried window. */
    hasErrors: boolean;
    /** Timestamp of the most recent event from this agent (Unix epoch ms). */
    lastEventMs: number;
    /** Durable Object namespace the agent belongs to. */
    namespace: string;
    /** Worker service name that hosts this agent. */
    service: string;
    /** Total number of events emitted by this agent in the queried window. */
    totalEvents: number;
}
export declare const ObservabilityTelemetryQueryResponseAgentsItem: S.Schema<ObservabilityTelemetryQueryResponseAgentsItem>;
export type ObservabilityTelemetryQueryResponseAgentsList = Array<ObservabilityTelemetryQueryResponseAgentsItem>;
export declare const ObservabilityTelemetryQueryResponseAgentsList: S.Schema<ObservabilityTelemetryQueryResponseAgentsList>;
export type ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItemValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItemValue: any;
export interface ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItemValue;
}
export declare const ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItem: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItem>;
export type ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsList = Array<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsItem>;
export declare const ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsList: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsList>;
export interface ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    groups?: ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItemGroupsList | null;
}
export declare const ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItem: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItem>;
export type ObservabilityTelemetryQueryResponseCalculationsItemAggregatesList = Array<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesItem>;
export declare const ObservabilityTelemetryQueryResponseCalculationsItemAggregatesList: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemAggregatesList>;
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItemValue: any;
export interface ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItemValue;
}
export declare const ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItem: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItem>;
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsList = Array<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsItem>;
export declare const ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsList: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsList>;
export interface ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export declare const ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItem: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItem>;
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataList = Array<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataItem>;
export declare const ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataList: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataList>;
export interface ObservabilityTelemetryQueryResponseCalculationsItemSeriesItem {
    data: ObservabilityTelemetryQueryResponseCalculationsItemSeriesItemDataList;
    time: string;
}
export declare const ObservabilityTelemetryQueryResponseCalculationsItemSeriesItem: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItem>;
export type ObservabilityTelemetryQueryResponseCalculationsItemSeriesList = Array<ObservabilityTelemetryQueryResponseCalculationsItemSeriesItem>;
export declare const ObservabilityTelemetryQueryResponseCalculationsItemSeriesList: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItemSeriesList>;
export interface ObservabilityTelemetryQueryResponseCalculationsItem {
    aggregates: ObservabilityTelemetryQueryResponseCalculationsItemAggregatesList;
    calculation: string;
    series: ObservabilityTelemetryQueryResponseCalculationsItemSeriesList;
    alias?: string | null;
}
export declare const ObservabilityTelemetryQueryResponseCalculationsItem: S.Schema<ObservabilityTelemetryQueryResponseCalculationsItem>;
export type ObservabilityTelemetryQueryResponseCalculationsList = Array<ObservabilityTelemetryQueryResponseCalculationsItem>;
export declare const ObservabilityTelemetryQueryResponseCalculationsList: S.Schema<ObservabilityTelemetryQueryResponseCalculationsList>;
export type ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItemValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItemValue: any;
export interface ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItemValue;
}
export declare const ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItem: S.Schema<ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItem>;
export type ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsList = Array<ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsItem>;
export declare const ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsList: S.Schema<ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsList>;
export interface ObservabilityTelemetryQueryResponseCompareItemAggregatesItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    groups?: ObservabilityTelemetryQueryResponseCompareItemAggregatesItemGroupsList | null;
}
export declare const ObservabilityTelemetryQueryResponseCompareItemAggregatesItem: S.Schema<ObservabilityTelemetryQueryResponseCompareItemAggregatesItem>;
export type ObservabilityTelemetryQueryResponseCompareItemAggregatesList = Array<ObservabilityTelemetryQueryResponseCompareItemAggregatesItem>;
export declare const ObservabilityTelemetryQueryResponseCompareItemAggregatesList: S.Schema<ObservabilityTelemetryQueryResponseCompareItemAggregatesList>;
export type ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItemValue = string | number | boolean;
export declare const ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItemValue: any;
export interface ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItem {
    key: string;
    value: ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItemValue;
}
export declare const ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItem: S.Schema<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItem>;
export type ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsList = Array<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsItem>;
export declare const ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsList: S.Schema<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsList>;
export interface ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItem {
    count: number;
    interval: number;
    sampleInterval: number;
    value: number;
    firstSeen?: string | null;
    groups?: ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItemGroupsList | null;
    lastSeen?: string | null;
}
export declare const ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItem: S.Schema<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItem>;
export type ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataList = Array<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataItem>;
export declare const ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataList: S.Schema<ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataList>;
export interface ObservabilityTelemetryQueryResponseCompareItemSeriesItem {
    data: ObservabilityTelemetryQueryResponseCompareItemSeriesItemDataList;
    time: string;
}
export declare const ObservabilityTelemetryQueryResponseCompareItemSeriesItem: S.Schema<ObservabilityTelemetryQueryResponseCompareItemSeriesItem>;
export type ObservabilityTelemetryQueryResponseCompareItemSeriesList = Array<ObservabilityTelemetryQueryResponseCompareItemSeriesItem>;
export declare const ObservabilityTelemetryQueryResponseCompareItemSeriesList: S.Schema<ObservabilityTelemetryQueryResponseCompareItemSeriesList>;
export interface ObservabilityTelemetryQueryResponseCompareItem {
    aggregates: ObservabilityTelemetryQueryResponseCompareItemAggregatesList;
    calculation: string;
    series: ObservabilityTelemetryQueryResponseCompareItemSeriesList;
    alias?: string | null;
}
export declare const ObservabilityTelemetryQueryResponseCompareItem: S.Schema<ObservabilityTelemetryQueryResponseCompareItem>;
export type ObservabilityTelemetryQueryResponseCompareList = Array<ObservabilityTelemetryQueryResponseCompareItem>;
export declare const ObservabilityTelemetryQueryResponseCompareList: S.Schema<ObservabilityTelemetryQueryResponseCompareList>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemMetadata = ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemMetadata: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemSourceCase1Map: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItemSourceCase1Map>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemSource = string | ObservabilityTelemetryQueryResponseEventsEventsItemSourceCase1Map;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemSource: any;
export type ObservabilityTelemetryQueryResponseEventsEventsItemContainersMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemContainersMap: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItemContainersMap>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventType: any;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventMap: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventMap>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ExecutionModel: any;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0 {
    eventType: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventType;
    requestId: string;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventType: any;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventMap: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventMap>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ExecutionModel: any;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventType;
    outcome: string;
    requestId: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1>;
export type ObservabilityTelemetryQueryResponseEventsEventsItemWorkers = ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase0 | ObservabilityTelemetryQueryResponseEventsEventsItemWorkersCase1;
export declare const ObservabilityTelemetryQueryResponseEventsEventsItemWorkers: any;
export interface ObservabilityTelemetryQueryResponseEventsEventsItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilityTelemetryQueryResponseEventsEventsItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilityTelemetryQueryResponseEventsEventsItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilityTelemetryQueryResponseEventsEventsItemWorkers | null;
}
export declare const ObservabilityTelemetryQueryResponseEventsEventsItem: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsItem>;
export type ObservabilityTelemetryQueryResponseEventsEventsList = Array<ObservabilityTelemetryQueryResponseEventsEventsItem>;
export declare const ObservabilityTelemetryQueryResponseEventsEventsList: S.Schema<ObservabilityTelemetryQueryResponseEventsEventsList>;
export type ObservabilityTelemetryQueryResponseEventsFieldsItem = ObservabilitySharedQueriesGetResponseEventsFieldsItem;
export declare const ObservabilityTelemetryQueryResponseEventsFieldsItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsFieldsItem>;
export type ObservabilityTelemetryQueryResponseEventsFieldsList = Array<ObservabilitySharedQueriesGetResponseEventsFieldsItem>;
export declare const ObservabilityTelemetryQueryResponseEventsFieldsList: S.Schema<ObservabilityTelemetryQueryResponseEventsFieldsList>;
export type ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemAggregates = ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates;
export declare const ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemAggregates: S.Schema<ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates>;
export type ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemGroups = string | number | boolean;
export declare const ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemGroups: any;
export interface ObservabilityTelemetryQueryResponseEventsSeriesItemDataItem {
    aggregates: ObservabilitySharedQueriesGetResponseEventsSeriesItemDataItemAggregates;
    count: number;
    interval: number;
    sampleInterval: number;
    errors?: number | null;
    /** Groups in the query results. */
    groups?: ObservabilityTelemetryQueryResponseEventsSeriesItemDataItemGroups | null;
}
export declare const ObservabilityTelemetryQueryResponseEventsSeriesItemDataItem: S.Schema<ObservabilityTelemetryQueryResponseEventsSeriesItemDataItem>;
export type ObservabilityTelemetryQueryResponseEventsSeriesItemDataList = Array<ObservabilityTelemetryQueryResponseEventsSeriesItemDataItem>;
export declare const ObservabilityTelemetryQueryResponseEventsSeriesItemDataList: S.Schema<ObservabilityTelemetryQueryResponseEventsSeriesItemDataList>;
export interface ObservabilityTelemetryQueryResponseEventsSeriesItem {
    data: ObservabilityTelemetryQueryResponseEventsSeriesItemDataList;
    time: string;
}
export declare const ObservabilityTelemetryQueryResponseEventsSeriesItem: S.Schema<ObservabilityTelemetryQueryResponseEventsSeriesItem>;
export type ObservabilityTelemetryQueryResponseEventsSeriesList = Array<ObservabilityTelemetryQueryResponseEventsSeriesItem>;
export declare const ObservabilityTelemetryQueryResponseEventsSeriesList: S.Schema<ObservabilityTelemetryQueryResponseEventsSeriesList>;
export interface ObservabilityTelemetryQueryResponseEvents {
    /** Total number of events matching the query (may exceed the number returned due to limits). */
    count?: number | null;
    /** List of individual telemetry events matching the query. */
    events?: ObservabilityTelemetryQueryResponseEventsEventsList | null;
    /** List of fields discovered in the matched events. Useful for building dynamic UIs. */
    fields?: ObservabilityTelemetryQueryResponseEventsFieldsList | null;
    /** Time-series data for the matched events, bucketed by the query granularity. */
    series?: ObservabilityTelemetryQueryResponseEventsSeriesList | null;
}
export declare const ObservabilityTelemetryQueryResponseEvents: S.Schema<ObservabilityTelemetryQueryResponseEvents>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemMetadata = ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemMetadata: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemSourceCase1Map = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemSourceCase1Map: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItemSourceCase1Map>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemSource = string | ObservabilityTelemetryQueryResponseInvocationsValueItemSourceCase1Map;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemSource: any;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemContainersMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemContainersMap: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItemContainersMap>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventType: any;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventMap: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventMap>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ExecutionModel: any;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0 {
    eventType: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventType;
    requestId: string;
    scriptName: string;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0ExecutionModel | null;
    outcome?: string | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventType = "fetch" | "scheduled" | "alarm" | "cron" | "queue" | "email" | "tail" | "rpc" | "jsrpc" | "websocket" | "workflow" | "unknown";
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventType: any;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsItem = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsItem: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList = Array<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase1DiagnosticsChannelEventsItem>;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventMap = {
    [key: string]: unknown | undefined;
};
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventMap: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventMap>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ExecutionModel = "durableObject" | "stateless";
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ExecutionModel: any;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1Preview = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1Preview: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ScriptVersion = ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ScriptVersion: S.Schema<ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion>;
export interface ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1 {
    cpuTimeMs: number;
    eventType: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventType;
    outcome: string;
    requestId: string;
    scriptName: string;
    wallTimeMs: number;
    diagnosticsChannelEvents?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1DiagnosticsChannelEventsList | null;
    dispatchNamespace?: string | null;
    durableObjectId?: string | null;
    entrypoint?: string | null;
    event?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1EventMap | null;
    executionModel?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1ExecutionModel | null;
    preview?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0Preview | null;
    scriptVersion?: ObservabilitySharedQueriesGetResponseEventsEventsItemWorkersCase0ScriptVersion | null;
    spanId?: string | null;
    traceId?: string | null;
    truncated?: boolean | null;
}
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1>;
export type ObservabilityTelemetryQueryResponseInvocationsValueItemWorkers = ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase0 | ObservabilityTelemetryQueryResponseInvocationsValueItemWorkersCase1;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItemWorkers: any;
export interface ObservabilityTelemetryQueryResponseInvocationsValueItem {
    /** Structured metadata extracted from the event. These fields are indexed and available for filtering and aggregation. */
    metadata: ObservabilitySharedQueriesGetResponseEventsEventsItemMetadata;
    /** The dataset this event belongs to (e.g. cloudflare-workers). */
    dataset: string;
    /** Raw log payload. May be a string or a structured object depending on how the log was emitted. */
    source: ObservabilityTelemetryQueryResponseInvocationsValueItemSource;
    /** Event timestamp as a Unix epoch in milliseconds. */
    timestamp: number;
    /** Cloudflare Containers event information that enriches your logs for identifying and debugging issues. */
    containers?: ObservabilityTelemetryQueryResponseInvocationsValueItemContainersMap | null;
    /** Cloudflare Workers event information that enriches your logs for identifying and debugging issues. */
    workers?: ObservabilityTelemetryQueryResponseInvocationsValueItemWorkers | null;
}
export declare const ObservabilityTelemetryQueryResponseInvocationsValueItem: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueItem>;
export type ObservabilityTelemetryQueryResponseInvocationsValueList = Array<ObservabilityTelemetryQueryResponseInvocationsValueItem>;
export declare const ObservabilityTelemetryQueryResponseInvocationsValueList: S.Schema<ObservabilityTelemetryQueryResponseInvocationsValueList>;
export type ObservabilityTelemetryQueryResponseInvocationsMap = {
    [key: string]: ObservabilityTelemetryQueryResponseInvocationsValueList | undefined;
};
export declare const ObservabilityTelemetryQueryResponseInvocationsMap: S.Schema<ObservabilityTelemetryQueryResponseInvocationsMap>;
export type ObservabilityTelemetryQueryResponseTracesItemServiceList = Array<string>;
export declare const ObservabilityTelemetryQueryResponseTracesItemServiceList: S.Schema<ObservabilityTelemetryQueryResponseTracesItemServiceList>;
export type ObservabilityTelemetryQueryResponseTracesItemErrorsList = Array<string>;
export declare const ObservabilityTelemetryQueryResponseTracesItemErrorsList: S.Schema<ObservabilityTelemetryQueryResponseTracesItemErrorsList>;
export interface ObservabilityTelemetryQueryResponseTracesItem {
    /** Name of the root span that initiated the trace. */
    rootSpanName: string;
    /** Logical transaction name for the root span. */
    rootTransactionName: string;
    /** List of Worker services involved in the trace. */
    service: ObservabilityTelemetryQueryResponseTracesItemServiceList;
    /** Total number of spans in the trace. */
    spans: number;
    /** Total duration of the trace in milliseconds. */
    traceDurationMs: number;
    /** Trace end time as a Unix epoch in milliseconds. */
    traceEndMs: number;
    /** Unique identifier for the distributed trace. */
    traceId: string;
    /** Trace start time as a Unix epoch in milliseconds. */
    traceStartMs: number;
    /** Error messages encountered during the trace, if any. */
    errors?: ObservabilityTelemetryQueryResponseTracesItemErrorsList | null;
}
export declare const ObservabilityTelemetryQueryResponseTracesItem: S.Schema<ObservabilityTelemetryQueryResponseTracesItem>;
export type ObservabilityTelemetryQueryResponseTracesList = Array<ObservabilityTelemetryQueryResponseTracesItem>;
export declare const ObservabilityTelemetryQueryResponseTracesList: S.Schema<ObservabilityTelemetryQueryResponseTracesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface QueryObservabilityTelemetryResponse {
    /** Represents a single execution of a query against Workers Observability data, including the query definition, execution status, and performance statistics. */
    run: ObservabilityTelemetryQueryResponseRun;
    /** Query performance statistics from the database. Includes execution time, rows scanned, and bytes read. Does not include network latency. */
    statistics: ObservabilitySharedQueriesGetResponseRunStatistics;
    /** Durable Object agent summaries. Present when the query view is 'agents'. Each entry represents an agent with its event counts and status. */
    agents?: ObservabilityTelemetryQueryResponseAgentsList | null;
    /** Aggregated calculation results. Present when the query view is 'calculations'. Contains computed metrics (count, avg, p99, etc.) with optional group-by breakdowns and time-series data. */
    calculations?: ObservabilityTelemetryQueryResponseCalculationsList | null;
    /** Comparison calculation results from the previous time period. Present when the compare option is enabled. Same structure as calculations. */
    compare?: ObservabilityTelemetryQueryResponseCompareList | null;
    /** Individual event results. Present when the query view is 'events'. Contains the matching log lines and their metadata. */
    events?: ObservabilityTelemetryQueryResponseEvents | null;
    /** Events grouped by invocation (request ID). Present when the query view is 'invocations'. Each key is a request ID mapping to all events from that invocation. */
    invocations?: ObservabilityTelemetryQueryResponseInvocationsMap | null;
    /** Trace summaries matching the query. Present when the query view is 'traces'. Each entry represents a distributed trace with its spans, duration, and services involved. */
    traces?: ObservabilityTelemetryQueryResponseTracesList | null;
}
export declare const QueryObservabilityTelemetryResponse: S.Schema<QueryObservabilityTelemetryResponse>;
export type ScriptsSearchRequestOrderBy = "created_on" | "modified_on" | "name";
export declare const ScriptsSearchRequestOrderBy: any;
export interface SearchScriptRequest {
    /** Identifier. */
    accountId: string;
    /** Worker ID (also called tag) to search for. Only exact matches are returned. */
    id?: string;
    /** Worker name to search for. Both exact and partial matches are returned. */
    name?: string;
    /** Property to sort results by. Results are sorted in ascending order. */
    orderBy?: ScriptsSearchRequestOrderBy | (string & {});
    /** Current page. */
    page?: number;
    /** Items per page. */
    perPage?: number;
}
export declare const SearchScriptRequest: S.Schema<SearchScriptRequest>;
export interface ScriptsSearchResultItem {
    /** Identifier. */
    id: string;
    /** When the script was created. */
    createdOn: string;
    /** When the script was last modified. */
    modifiedOn: string;
    /** Name of the script, used in URLs and route configuration. */
    scriptName: string;
    /** Whether the environment is the default environment. */
    environmentIsDefault?: boolean | null;
    /** Name of the environment. */
    environmentName?: string | null;
    /** Name of the service. */
    serviceName?: string | null;
}
export declare const ScriptsSearchResultItem: S.Schema<ScriptsSearchResultItem>;
export type ScriptsSearchResultList = Array<ScriptsSearchResultItem>;
export declare const ScriptsSearchResultList: S.Schema<ScriptsSearchResultList>;
export type SearchScriptResponse = ScriptsSearchResultList;
export declare const SearchScriptResponse: S.Schema<SearchScriptResponse>;
export type BetaWorkersUpdateRequestObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersUpdateRequestObservabilityLogsDestinationsList: S.Schema<BetaWorkersUpdateRequestObservabilityLogsDestinationsList>;
export interface BetaWorkersUpdateRequestObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersUpdateRequestObservabilityLogsDestinationsList;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean;
}
export declare const BetaWorkersUpdateRequestObservabilityLogs: S.Schema<BetaWorkersUpdateRequestObservabilityLogs>;
export type BetaWorkersUpdateRequestObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersUpdateRequestObservabilityTracesDestinationsList: S.Schema<BetaWorkersUpdateRequestObservabilityTracesDestinationsList>;
export type BetaWorkersUpdateRequestObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersUpdateRequestObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersUpdateRequestObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersUpdateRequestObservabilityTracesDestinationsList;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersUpdateRequestObservabilityTracesPropagationPolicy | (string & {});
}
export declare const BetaWorkersUpdateRequestObservabilityTraces: S.Schema<BetaWorkersUpdateRequestObservabilityTraces>;
export interface BetaWorkersUpdateRequestObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number;
    /** Log settings for the Worker. */
    logs?: BetaWorkersUpdateRequestObservabilityLogs;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersUpdateRequestObservabilityTraces;
}
export declare const BetaWorkersUpdateRequestObservability: S.Schema<BetaWorkersUpdateRequestObservability>;
export type BetaWorkersUpdateRequestSubdomain = BetaWorkersCreateRequestSubdomain;
export declare const BetaWorkersUpdateRequestSubdomain: S.Schema<BetaWorkersCreateRequestSubdomain>;
export type BetaWorkersUpdateRequestTagsList = Array<string>;
export declare const BetaWorkersUpdateRequestTagsList: S.Schema<BetaWorkersUpdateRequestTagsList>;
export type BetaWorkersUpdateRequestTailConsumersItem = BetaWorkersCreateRequestTailConsumersItem;
export declare const BetaWorkersUpdateRequestTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersUpdateRequestTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersUpdateRequestTailConsumersList: S.Schema<BetaWorkersUpdateRequestTailConsumersList>;
export interface UpdateBetaWorkerRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier for the Worker, which can be ID or name. */
    workerId: string;
    /** Name of the Worker. */
    name: string;
    /** Whether logpush is enabled for the Worker. */
    logpush?: boolean;
    /** Observability settings for the Worker. */
    observability?: BetaWorkersUpdateRequestObservability;
    /** Subdomain settings for the Worker. */
    subdomain?: BetaWorkersCreateRequestSubdomain;
    /** Tags associated with the Worker. */
    tags?: BetaWorkersUpdateRequestTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers?: BetaWorkersUpdateRequestTailConsumersList;
}
export declare const UpdateBetaWorkerRequest: S.Schema<UpdateBetaWorkerRequest>;
export type BetaWorkersUpdateResponseObservabilityLogsDestinationsList = Array<string>;
export declare const BetaWorkersUpdateResponseObservabilityLogsDestinationsList: S.Schema<BetaWorkersUpdateResponseObservabilityLogsDestinationsList>;
export interface BetaWorkersUpdateResponseObservabilityLogs {
    /** A list of destinations where logs will be exported to. */
    destinations?: BetaWorkersUpdateResponseObservabilityLogsDestinationsList | null;
    /** Whether logs are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for logs. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether [invocation logs](https://developers.cloudflare.com/workers/observability/logs/workers-logs/#invocation-logs) are enabled for the Worker. */
    invocationLogs?: boolean | null;
    /** Whether log persistence is enabled for the Worker. */
    persist?: boolean | null;
}
export declare const BetaWorkersUpdateResponseObservabilityLogs: S.Schema<BetaWorkersUpdateResponseObservabilityLogs>;
export type BetaWorkersUpdateResponseObservabilityTracesDestinationsList = Array<string>;
export declare const BetaWorkersUpdateResponseObservabilityTracesDestinationsList: S.Schema<BetaWorkersUpdateResponseObservabilityTracesDestinationsList>;
export type BetaWorkersUpdateResponseObservabilityTracesPropagationPolicy = "authenticated" | "accept";
export declare const BetaWorkersUpdateResponseObservabilityTracesPropagationPolicy: any;
export interface BetaWorkersUpdateResponseObservabilityTraces {
    /** A list of destinations where traces will be exported to. */
    destinations?: BetaWorkersUpdateResponseObservabilityTracesDestinationsList | null;
    /** Whether traces are enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for traces. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Whether trace persistence is enabled for the Worker. */
    persist?: boolean | null;
    /** Controls how inbound trace context (traceparent/tracestate) headers on incoming requests are handled. "authenticated" (default) honors inbound trace context only when accompanied by a valid trace auth token. "accept" unconditionally accepts inbound trace context. Requires the trace propagation feature to be enabled. */
    propagationPolicy?: BetaWorkersUpdateResponseObservabilityTracesPropagationPolicy | null;
}
export declare const BetaWorkersUpdateResponseObservabilityTraces: S.Schema<BetaWorkersUpdateResponseObservabilityTraces>;
export interface BetaWorkersUpdateResponseObservability {
    /** Whether observability is enabled for the Worker. */
    enabled?: boolean | null;
    /** The sampling rate for observability. From 0 to 1 (1 = 100%, 0.1 = 10%). */
    headSamplingRate?: number | null;
    /** Log settings for the Worker. */
    logs?: BetaWorkersUpdateResponseObservabilityLogs | null;
    /** Trace settings for the Worker. */
    traces?: BetaWorkersUpdateResponseObservabilityTraces | null;
}
export declare const BetaWorkersUpdateResponseObservability: S.Schema<BetaWorkersUpdateResponseObservability>;
export type BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsItem = BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem;
export declare const BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsItem: S.Schema<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export type BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsList = Array<BetaWorkersCreateResponseReferencesDispatchNamespaceOutboundsItem>;
export declare const BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsList: S.Schema<BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsList>;
export type BetaWorkersUpdateResponseReferencesDomainsItem = BetaWorkersCreateResponseReferencesDomainsItem;
export declare const BetaWorkersUpdateResponseReferencesDomainsItem: S.Schema<BetaWorkersCreateResponseReferencesDomainsItem>;
export type BetaWorkersUpdateResponseReferencesDomainsList = Array<BetaWorkersCreateResponseReferencesDomainsItem>;
export declare const BetaWorkersUpdateResponseReferencesDomainsList: S.Schema<BetaWorkersUpdateResponseReferencesDomainsList>;
export type BetaWorkersUpdateResponseReferencesDurableObjectsItem = BetaWorkersCreateResponseReferencesDurableObjectsItem;
export declare const BetaWorkersUpdateResponseReferencesDurableObjectsItem: S.Schema<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export type BetaWorkersUpdateResponseReferencesDurableObjectsList = Array<BetaWorkersCreateResponseReferencesDurableObjectsItem>;
export declare const BetaWorkersUpdateResponseReferencesDurableObjectsList: S.Schema<BetaWorkersUpdateResponseReferencesDurableObjectsList>;
export type BetaWorkersUpdateResponseReferencesQueuesItem = BetaWorkersCreateResponseReferencesQueuesItem;
export declare const BetaWorkersUpdateResponseReferencesQueuesItem: S.Schema<BetaWorkersCreateResponseReferencesQueuesItem>;
export type BetaWorkersUpdateResponseReferencesQueuesList = Array<BetaWorkersCreateResponseReferencesQueuesItem>;
export declare const BetaWorkersUpdateResponseReferencesQueuesList: S.Schema<BetaWorkersUpdateResponseReferencesQueuesList>;
export type BetaWorkersUpdateResponseReferencesWorkersItem = BetaWorkersCreateResponseReferencesWorkersItem;
export declare const BetaWorkersUpdateResponseReferencesWorkersItem: S.Schema<BetaWorkersCreateResponseReferencesWorkersItem>;
export type BetaWorkersUpdateResponseReferencesWorkersList = Array<BetaWorkersCreateResponseReferencesWorkersItem>;
export declare const BetaWorkersUpdateResponseReferencesWorkersList: S.Schema<BetaWorkersUpdateResponseReferencesWorkersList>;
export interface BetaWorkersUpdateResponseReferences {
    /** Other Workers that reference the Worker as an outbound for a dispatch namespace. */
    dispatchNamespaceOutbounds: BetaWorkersUpdateResponseReferencesDispatchNamespaceOutboundsList;
    /** Custom domains connected to the Worker. */
    domains: BetaWorkersUpdateResponseReferencesDomainsList;
    /** Other Workers that reference Durable Object classes implemented by the Worker. */
    durableObjects: BetaWorkersUpdateResponseReferencesDurableObjectsList;
    /** Queues that send messages to the Worker. */
    queues: BetaWorkersUpdateResponseReferencesQueuesList;
    /** Other Workers that reference the Worker using [service bindings](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/). */
    workers: BetaWorkersUpdateResponseReferencesWorkersList;
}
export declare const BetaWorkersUpdateResponseReferences: S.Schema<BetaWorkersUpdateResponseReferences>;
export type BetaWorkersUpdateResponseSubdomain = BetaWorkersCreateResponseSubdomain;
export declare const BetaWorkersUpdateResponseSubdomain: S.Schema<BetaWorkersCreateResponseSubdomain>;
export type BetaWorkersUpdateResponseTagsList = Array<string>;
export declare const BetaWorkersUpdateResponseTagsList: S.Schema<BetaWorkersUpdateResponseTagsList>;
export type BetaWorkersUpdateResponseTailConsumersItem = BetaWorkersCreateRequestTailConsumersItem;
export declare const BetaWorkersUpdateResponseTailConsumersItem: S.Schema<BetaWorkersCreateRequestTailConsumersItem>;
export type BetaWorkersUpdateResponseTailConsumersList = Array<BetaWorkersCreateRequestTailConsumersItem>;
export declare const BetaWorkersUpdateResponseTailConsumersList: S.Schema<BetaWorkersUpdateResponseTailConsumersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateBetaWorkerResponse {
    /** Immutable ID of the Worker. */
    id: string;
    /** When the Worker was created. */
    createdOn: string;
    /** Whether logpush is enabled for the Worker. */
    logpush: boolean;
    /** Name of the Worker. */
    name: string;
    /** Observability settings for the Worker. */
    observability: BetaWorkersUpdateResponseObservability;
    /** Other resources that reference the Worker and depend on it existing. */
    references: BetaWorkersUpdateResponseReferences;
    /** Subdomain settings for the Worker. */
    subdomain: BetaWorkersCreateResponseSubdomain;
    /** Tags associated with the Worker. */
    tags: BetaWorkersUpdateResponseTagsList;
    /** Other Workers that should consume logs from the Worker. */
    tailConsumers: BetaWorkersUpdateResponseTailConsumersList;
    /** When the Worker was most recently updated. */
    updatedOn: string;
    /** When the Worker's most recent deployment was created. `null` if the Worker has never been deployed. */
    deployedOn?: string | null;
}
export declare const UpdateBetaWorkerResponse: S.Schema<UpdateBetaWorkerResponse>;
export interface UpdateRouteRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    routeId: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string;
}
export declare const UpdateRouteRequest: S.Schema<UpdateRouteRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRouteResponse {
    /** Identifier. */
    id: string;
    /** Pattern to match incoming requests against. [Learn more](https://developers.cloudflare.com/workers/configuration/routing/routes/#matching-behavior). */
    pattern: string;
    /** Name of the script to run if the route matches. */
    script?: string | null;
}
export declare const UpdateRouteResponse: S.Schema<UpdateRouteResponse>;
export type ObservabilityTelemetryValuesRequestDatasetsList = Array<string>;
export declare const ObservabilityTelemetryValuesRequestDatasetsList: S.Schema<ObservabilityTelemetryValuesRequestDatasetsList>;
export interface ObservabilityTelemetryValuesRequestTimeframe {
    from: number;
    to: number;
}
export declare const ObservabilityTelemetryValuesRequestTimeframe: S.Schema<ObservabilityTelemetryValuesRequestTimeframe>;
export type ObservabilityTelemetryValuesRequestType = "string" | "boolean" | "number";
export declare const ObservabilityTelemetryValuesRequestType: any;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FilterCombination = "and" | "or" | "AND" | "OR";
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FilterCombination: any;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FiltersList = Array<unknown>;
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FiltersList>;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0Kind: any;
export interface ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0 {
    filterCombination: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0: S.Schema<ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0>;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItem = ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemCase0 | ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItem: any;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersList = Array<ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersItem>;
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersList: S.Schema<ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersList>;
export type ObservabilityTelemetryValuesRequestFiltersItemCase0Kind = "group";
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0Kind: any;
export interface ObservabilityTelemetryValuesRequestFiltersItemCase0 {
    filterCombination: ObservabilityTelemetryValuesRequestFiltersItemCase0FilterCombination | (string & {});
    filters: ObservabilityTelemetryValuesRequestFiltersItemCase0FiltersList;
    kind: ObservabilityTelemetryValuesRequestFiltersItemCase0Kind;
}
export declare const ObservabilityTelemetryValuesRequestFiltersItemCase0: S.Schema<ObservabilityTelemetryValuesRequestFiltersItemCase0>;
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafOperation = "includes" | "not_includes" | "starts_with" | "ends_with" | "regex" | "exists" | "is_null" | "in" | "not_in" | "eq" | "neq" | "gt" | "gte" | "lt" | "lte" | "=" | "!=" | ">" | ">=" | "<" | "<=" | "INCLUDES" | "DOES_NOT_INCLUDE" | "MATCH_REGEX" | "EXISTS" | "DOES_NOT_EXIST" | "IN" | "NOT_IN" | "STARTS_WITH" | "ENDS_WITH";
export declare const ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafOperation: any;
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafType = "string" | "number" | "boolean";
export declare const ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafType: any;
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafKind = "filter";
export declare const ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafKind: any;
export type ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafValue = string | number | boolean;
export declare const ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafValue: any;
export interface ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeaf {
    /** Filter field name. Use verified keys from previous query results or the keys endpoint. Common keys include $metadata.service, $metadata.origin, $metadata.trigger, $metadata.message, and $metadata.error. */
    key: string;
    /** Comparison operator. String operators: includes, not_includes, starts_with, ends_with, regex. Existence: exists, is_null. Set membership: in, not_in (comma-separated values). Numeric: eq, neq, gt, gte, lt, lte. */
    operation: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafOperation | (string & {});
    /** Data type of the filter field. Must match the actual type of the key being filtered. */
    type: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafType | (string & {});
    /** Discriminator for leaf filter nodes. Always 'filter' when present; may be omitted. */
    kind?: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafKind | (string & {});
    /** Comparison value. Must match actual values in your data — verify with the values endpoint. Ensure the value type (string/number/boolean) matches the field type. String comparisons are case-sensitive. Regex uses RE2 syntax (no lookaheads/lookbehinds). */
    value?: ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeafValue;
}
export declare const ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeaf: S.Schema<ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeaf>;
export type ObservabilityTelemetryValuesRequestFiltersItem = ObservabilityTelemetryValuesRequestFiltersItemCase0 | ObservabilityTelemetryValuesRequestFiltersItemWorkersObservabilityFilterLeaf;
export declare const ObservabilityTelemetryValuesRequestFiltersItem: any;
export type ObservabilityTelemetryValuesRequestFiltersList = Array<ObservabilityTelemetryValuesRequestFiltersItem>;
export declare const ObservabilityTelemetryValuesRequestFiltersList: S.Schema<ObservabilityTelemetryValuesRequestFiltersList>;
export type ObservabilityTelemetryValuesRequestNeedleValue = string | number | boolean;
export declare const ObservabilityTelemetryValuesRequestNeedleValue: any;
export interface ObservabilityTelemetryValuesRequestNeedle {
    /** The text or pattern to search for. */
    value: ObservabilityTelemetryValuesRequestNeedleValue;
    /** When true, treats the value as a regular expression (RE2 syntax). */
    isRegex?: boolean;
    /** When true, performs a case-sensitive search. Defaults to case-insensitive. */
    matchCase?: boolean;
}
export declare const ObservabilityTelemetryValuesRequestNeedle: S.Schema<ObservabilityTelemetryValuesRequestNeedle>;
export interface ValuesObservabilityTelemetryRequest {
    accountId: string;
    /** Leave this empty to use the default datasets */
    datasets: ObservabilityTelemetryValuesRequestDatasetsList;
    key: string;
    timeframe: ObservabilityTelemetryValuesRequestTimeframe;
    type: ObservabilityTelemetryValuesRequestType | (string & {});
    /** Apply filters before listing values. Supports nested groups via kind: 'group'. Maximum nesting depth is 4. */
    filters?: ObservabilityTelemetryValuesRequestFiltersList;
    limit?: number;
    /** Full-text search expression to match events containing the specified text or pattern. */
    needle?: ObservabilityTelemetryValuesRequestNeedle;
}
export declare const ValuesObservabilityTelemetryRequest: S.Schema<ValuesObservabilityTelemetryRequest>;
export type ObservabilityTelemetryValuesResultItemType = "string" | "boolean" | "number";
export declare const ObservabilityTelemetryValuesResultItemType: any;
export type ObservabilityTelemetryValuesResultItemValue = string | number | boolean;
export declare const ObservabilityTelemetryValuesResultItemValue: any;
export interface ObservabilityTelemetryValuesResultItem {
    dataset: string;
    key: string;
    type: ObservabilityTelemetryValuesResultItemType;
    value: ObservabilityTelemetryValuesResultItemValue;
}
export declare const ObservabilityTelemetryValuesResultItem: S.Schema<ObservabilityTelemetryValuesResultItem>;
export type ObservabilityTelemetryValuesResultList = Array<ObservabilityTelemetryValuesResultItem>;
export declare const ObservabilityTelemetryValuesResultList: S.Schema<ObservabilityTelemetryValuesResultList>;
export interface ValuesObservabilityTelemetryResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ObservabilityTelemetryValuesResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ValuesObservabilityTelemetryResponse: S.Schema<ValuesObservabilityTelemetryResponse>;
export type BulkUpdateScriptSecretsError = CloudflareOpError;
/** Create, update, or delete multiple secrets on a script in a single operation using JSON Merge Patch (RFC 7396). Usage: - To create or update a secret, set its value to a secret object. - To delete a secret, set its value to `null`. - Secrets not included in the request are left unchanged. */
export declare const bulkUpdateScriptSecrets: API.OperationMethod<BulkUpdateScriptSecretsRequest, BulkUpdateScriptSecretsResponse, BulkUpdateScriptSecretsError, CloudflareOpContext>;
export type CreateAssetUploadError = InvalidRoute | CloudflareOpError;
/** Upload assets ahead of creating a Worker version. To learn more about the direct uploads of assets, see https://developers.cloudflare.com/workers/static-assets/direct-upload/. */
export declare const createAssetUpload: API.OperationMethod<CreateAssetUploadRequest, CreateAssetUploadResponse, CreateAssetUploadError, CloudflareOpContext>;
export type CreateBetaWorkerError = InvalidRoute | CloudflareOpError;
/** Create a new Worker. */
export declare const createBetaWorker: API.OperationMethod<CreateBetaWorkerRequest, CreateBetaWorkerResponse, CreateBetaWorkerError, CloudflareOpContext>;
export type CreateBetaWorkerVersionError = WorkerNotFound | CloudflareOpError;
/** Create a new version. */
export declare const createBetaWorkerVersion: API.OperationMethod<CreateBetaWorkerVersionRequest, CreateBetaWorkerVersionResponse, CreateBetaWorkerVersionError, CloudflareOpContext>;
export type CreateObservabilityDestinationError = ObservabilityDestinationCreateFailed | Forbidden | CloudflareOpError;
/** Create a new Workers Observability Telemetry Destination. */
export declare const createObservabilityDestination: API.OperationMethod<CreateObservabilityDestinationRequest, CreateObservabilityDestinationResponse, CreateObservabilityDestinationError, CloudflareOpContext>;
export type CreateObservabilityQueryError = CloudflareOpError;
/** Persist query for later use. */
export declare const createObservabilityQuery: API.OperationMethod<CreateObservabilityQueryRequest, CreateObservabilityQueryResponse, CreateObservabilityQueryError, CloudflareOpContext>;
export type CreateObservabilitySharedQueryError = CloudflareOpError;
/** Shared queries store the results of a previously run query, allowing you to share the results with others. */
export declare const createObservabilitySharedQuery: API.OperationMethod<CreateObservabilitySharedQueryRequest, CreateObservabilitySharedQueryResponse, CreateObservabilitySharedQueryError, CloudflareOpContext>;
export type CreatePreviewError = WorkerNotFound | CloudflareOpError;
/** Create a Worker Preview. Does not deploy code; follow with createPreviewDeployment. */
export declare const createPreview: API.OperationMethod<CreatePreviewRequest, PreviewResource, CreatePreviewError, CloudflareOpContext>;
export type CreatePreviewDeploymentError = PreviewNotFound | WorkerNotFound | CloudflareOpError;
/** Upload code, bindings, and assets as a new deployment of a Preview. */
export declare const createPreviewDeployment: API.OperationMethod<CreatePreviewDeploymentRequest, PreviewDeploymentResource, CreatePreviewDeploymentError, CloudflareOpContext>;
export type CreateRouteError = InvalidRoutePattern | InvalidRoute | Forbidden | RouteScriptNotFound | CloudflareOpError;
/** Creates a route that maps a URL pattern to a Worker. */
export declare const createRoute: API.OperationMethod<CreateRouteRequest, CreateRouteResponse, CreateRouteError, CloudflareOpContext>;
export type CreateScriptAssetUploadError = CloudflareOpError;
/** Start uploading a collection of assets for use in a Worker version. To learn more about the direct uploads of assets, see https://developers.cloudflare.com/workers/static-assets/direct-upload/. */
export declare const createScriptAssetUpload: API.OperationMethod<CreateScriptAssetUploadRequest, CreateScriptAssetUploadResponse, CreateScriptAssetUploadError, CloudflareOpContext>;
export type CreateScriptDeploymentError = WorkerNotFound | CloudflareOpError;
/** Deployments configure how [Worker Versions](https://developers.cloudflare.com/api/operations/worker-versions-list-versions) are deployed to traffic. A deployment can consist of one or two versions of a Worker. */
export declare const createScriptDeployment: API.OperationMethod<CreateScriptDeploymentRequest, CreateScriptDeploymentResponse, CreateScriptDeploymentError, CloudflareOpContext>;
export type CreateScriptEdgePreviewError = InvalidRoute | CloudflareOpError;
/** Upload a preview worker under an edge-preview session (undocumented endpoint). */
export declare const createScriptEdgePreview: API.OperationMethod<CreateScriptEdgePreviewRequest, CreateScriptEdgePreviewResponse, CreateScriptEdgePreviewError, CloudflareOpContext>;
export type CreateScriptSubdomainError = WorkerNotFound | CloudflareOpError;
/** Enable or disable the Worker on the workers.dev subdomain. */
export declare const createScriptSubdomain: API.OperationMethod<CreateScriptSubdomainRequest, CreateScriptSubdomainResponse, CreateScriptSubdomainError, CloudflareOpContext>;
export type CreateScriptTailError = WorkerNotFound | CloudflareOpError;
/** Starts a tail that receives logs and exception from a Worker. */
export declare const createScriptTail: API.OperationMethod<CreateScriptTailRequest, CreateScriptTailResponse, CreateScriptTailError, CloudflareOpContext>;
export type CreateScriptVersionError = WorkerNotFound | CloudflareOpError;
/** Upload a Worker Version without deploying to Cloudflare's network. You can find more about the multipart metadata on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/. */
export declare const createScriptVersion: API.OperationMethod<CreateScriptVersionRequest, CreateScriptVersionResponse, CreateScriptVersionError, CloudflareOpContext>;
export type CreateServiceEdgePreviewError = InvalidRoute | CloudflareOpError;
/** Upload a preview worker for one environment of a service under an edge-preview session (undocumented endpoint). */
export declare const createServiceEdgePreview: API.OperationMethod<CreateServiceEdgePreviewRequest, CreateServiceEdgePreviewResponse, CreateServiceEdgePreviewError, CloudflareOpContext>;
export type CreateSubdomainEdgePreviewSessionError = InvalidRoute | CloudflareOpError;
/** Create an edge-preview session for the account's workers.dev subdomain (undocumented endpoint). */
export declare const createSubdomainEdgePreviewSession: API.OperationMethod<CreateSubdomainEdgePreviewSessionRequest, CreateSubdomainEdgePreviewSessionResponse, CreateSubdomainEdgePreviewSessionError, CloudflareOpContext>;
export type CreateZoneEdgePreviewSessionError = InvalidRoute | CloudflareOpError;
/** Create an edge-preview session scoped to a zone (undocumented endpoint). */
export declare const createZoneEdgePreviewSession: API.OperationMethod<CreateZoneEdgePreviewSessionRequest, CreateZoneEdgePreviewSessionResponse, CreateZoneEdgePreviewSessionError, CloudflareOpContext>;
export type DeleteBetaWorkerError = WorkerNotFound | CloudflareOpError;
/** Delete a Worker and all its associated resources (versions, deployments, etc.). */
export declare const deleteBetaWorker: API.OperationMethod<DeleteBetaWorkerRequest, DeleteBetaWorkerResponse, DeleteBetaWorkerError, CloudflareOpContext>;
export type DeleteBetaWorkerVersionError = WorkerNotFound | WorkerVersionNotFound | CloudflareOpError;
/** Delete a version. */
export declare const deleteBetaWorkerVersion: API.OperationMethod<DeleteBetaWorkerVersionRequest, DeleteBetaWorkerVersionResponse, DeleteBetaWorkerVersionError, CloudflareOpContext>;
export type DeleteDomainError = DomainNotFound | CloudflareOpError;
/** Detaches a domain from a Worker. Both the Worker and all of its previews are no longer routable using this domain. */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest, DeleteDomainResponse, DeleteDomainError, CloudflareOpContext>;
export type DeleteObservabilityDestinationError = ObservabilityDestinationNotFound | Forbidden | CloudflareOpError;
/** Delete a Workers Observability Telemetry Destination. */
export declare const deleteObservabilityDestination: API.OperationMethod<DeleteObservabilityDestinationRequest, DeleteObservabilityDestinationResponse, DeleteObservabilityDestinationError, CloudflareOpContext>;
export type DeletePreviewError = PreviewNotFound | WorkerNotFound | CloudflareOpError;
/** Delete a Worker Preview and all its deployments. */
export declare const deletePreview: API.OperationMethod<DeletePreviewRequest, DeletePreviewResponse, DeletePreviewError, CloudflareOpContext>;
export type DeleteRouteError = RouteNotFound | CloudflareOpError;
/** Deletes a route. */
export declare const deleteRoute: API.OperationMethod<DeleteRouteRequest, DeleteRouteResponse, DeleteRouteError, CloudflareOpContext>;
export type DeleteScriptError = WorkerNotFound | QueueConsumerConflict | ServiceBindingConflict | CloudflareOpError;
/** Delete your worker. This call has no response body on a successful delete. */
export declare const deleteScript: API.OperationMethod<DeleteScriptRequest, DeleteScriptResponse, DeleteScriptError, CloudflareOpContext>;
export type DeleteScriptDeploymentError = WorkerNotFound | DeploymentNotFound | CloudflareOpError;
/** Delete a Worker Deployment. The latest deployment, which is actively serving traffic, cannot be deleted. All other deployments can be deleted. */
export declare const deleteScriptDeployment: API.OperationMethod<DeleteScriptDeploymentRequest, DeleteScriptDeploymentResponse, DeleteScriptDeploymentError, CloudflareOpContext>;
export type DeleteScriptSecretError = WorkerNotFound | SecretNotFound | CloudflareOpError;
/** Remove a secret from a script. */
export declare const deleteScriptSecret: API.OperationMethod<DeleteScriptSecretRequest, DeleteScriptSecretResponse, DeleteScriptSecretError, CloudflareOpContext>;
export type DeleteScriptSubdomainError = WorkerNotFound | CloudflareOpError;
/** Disable all workers.dev subdomains for a Worker. */
export declare const deleteScriptSubdomain: API.OperationMethod<DeleteScriptSubdomainRequest, DeleteScriptSubdomainResponse, DeleteScriptSubdomainError, CloudflareOpContext>;
export type DeleteScriptTailError = WorkerNotFound | CloudflareOpError;
/** Deletes a tail from a Worker. */
export declare const deleteScriptTail: API.OperationMethod<DeleteScriptTailRequest, DeleteScriptTailResponse, DeleteScriptTailError, CloudflareOpContext>;
export type DeleteSubdomainError = InvalidRoute | SubdomainNotFound | Forbidden | CloudflareOpError;
/** Deletes a Workers subdomain for an account. */
export declare const deleteSubdomain: API.OperationMethod<DeleteSubdomainRequest, DeleteSubdomainResponse, DeleteSubdomainError, CloudflareOpContext>;
export type GetAccountSettingError = InvalidRoute | Forbidden | CloudflareOpError;
/** Fetches Worker account settings for an account. */
export declare const getAccountSetting: API.OperationMethod<GetAccountSettingRequest, GetAccountSettingResponse, GetAccountSettingError, CloudflareOpContext>;
export type GetBetaWorkerError = WorkerNotFound | InvalidRoute | CloudflareOpError;
/** Get details about a specific Worker. */
export declare const getBetaWorker: API.OperationMethod<GetBetaWorkerRequest, GetBetaWorkerResponse, GetBetaWorkerError, CloudflareOpContext>;
export type GetBetaWorkerVersionError = WorkerNotFound | WorkerVersionNotFound | CloudflareOpError;
/** Get details about a specific version. */
export declare const getBetaWorkerVersion: API.OperationMethod<GetBetaWorkerVersionRequest, GetBetaWorkerVersionResponse, GetBetaWorkerVersionError, CloudflareOpContext>;
export type GetDomainError = DomainNotFound | InvalidRoute | CloudflareOpError;
/** Gets information about a domain. */
export declare const getDomain: API.OperationMethod<GetDomainRequest, GetDomainResponse, GetDomainError, CloudflareOpContext>;
export type GetObservabilitySharedQueryError = CloudflareOpError;
/** Shared queries store the results of a previously run query, allowing you to share the results with others. */
export declare const getObservabilitySharedQuery: API.OperationMethod<GetObservabilitySharedQueryRequest, GetObservabilitySharedQueryResponse, GetObservabilitySharedQueryError, CloudflareOpContext>;
export type GetPreviewError = PreviewNotFound | WorkerNotFound | CloudflareOpError;
/** Get a Worker Preview by id or name. */
export declare const getPreview: API.OperationMethod<GetPreviewRequest, PreviewResource, GetPreviewError, CloudflareOpContext>;
export type GetPreviewDeploymentError = PreviewNotFound | PreviewDeploymentNotFound | WorkerNotFound | CloudflareOpError;
/** Get a Preview deployment by id, or `latest`. */
export declare const getPreviewDeployment: API.OperationMethod<GetPreviewDeploymentRequest, PreviewDeploymentResource, GetPreviewDeploymentError, CloudflareOpContext>;
export type GetRouteError = WorkerNotFound | RouteNotFound | InvalidRoute | Forbidden | CloudflareOpError;
/** Returns information about a route, including URL pattern and Worker. */
export declare const getRoute: API.OperationMethod<GetRouteRequest, GetRouteResponse, GetRouteError, CloudflareOpContext>;
export type GetScriptError = WorkerNotFound | InvalidRoute | WorkerHasNoVersions | CloudflareOpError;
/** Fetch raw script content for your worker. Note this is the original script content, not JSON encoded. */
export declare const getScript: API.OperationMethod<GetScriptRequest, GetScriptResponse, GetScriptError, CloudflareOpContext>;
export type GetScriptContentError = WorkerNotFound | CloudflareOpError;
/** Fetch script content only. */
export declare const getScriptContent: API.OperationMethod<GetScriptContentRequest, GetScriptContentResponse, GetScriptContentError, CloudflareOpContext>;
export type GetScriptDeploymentError = WorkerNotFound | DeploymentNotFound | CloudflareOpError;
/** Get information about a Worker Deployment. */
export declare const getScriptDeployment: API.OperationMethod<GetScriptDeploymentRequest, GetScriptDeploymentResponse, GetScriptDeploymentError, CloudflareOpContext>;
export type GetScriptScheduleError = WorkerNotFound | CloudflareOpError;
/** Fetches Cron Triggers for a Worker. */
export declare const getScriptSchedule: API.OperationMethod<GetScriptScheduleRequest, GetScriptScheduleResponse, GetScriptScheduleError, CloudflareOpContext>;
export type GetScriptScriptAndVersionSettingError = WorkerNotFound | WorkerHasNoVersions | CloudflareOpError;
/** Get metadata and config, such as bindings or usage model. */
export declare const getScriptScriptAndVersionSetting: API.OperationMethod<GetScriptScriptAndVersionSettingRequest, GetScriptScriptAndVersionSettingResponse, GetScriptScriptAndVersionSettingError, CloudflareOpContext>;
export type GetScriptSecretError = WorkerNotFound | SecretNotFound | CloudflareOpError;
/** Get a given secret binding (value omitted) on a script. */
export declare const getScriptSecret: API.OperationMethod<GetScriptSecretRequest, GetScriptSecretResponse, GetScriptSecretError, CloudflareOpContext>;
export type GetScriptSettingError = WorkerNotFound | WorkerHasNoVersions | CloudflareOpError;
/** Get script-level settings when using [Worker Versions](https://developers.cloudflare.com/api/operations/worker-versions-list-versions). Includes Logpush and Tail Consumers. */
export declare const getScriptSetting: API.OperationMethod<GetScriptSettingRequest, GetScriptSettingResponse, GetScriptSettingError, CloudflareOpContext>;
export type GetScriptSubdomainError = WorkerNotFound | CloudflareOpError;
/** Get if the Worker is available on the workers.dev subdomain. */
export declare const getScriptSubdomain: API.OperationMethod<GetScriptSubdomainRequest, GetScriptSubdomainResponse, GetScriptSubdomainError, CloudflareOpContext>;
export type GetScriptTailError = WorkerNotFound | CloudflareOpError;
/** Get list of tails currently deployed on a Worker. */
export declare const getScriptTail: API.OperationMethod<GetScriptTailRequest, GetScriptTailResponse, GetScriptTailError, CloudflareOpContext>;
export type GetScriptVersionError = WorkerNotFound | VersionNotFound | CloudflareOpError;
/** Retrieves detailed information about a specific version of a Workers script. */
export declare const getScriptVersion: API.OperationMethod<GetScriptVersionRequest, GetScriptVersionResponse, GetScriptVersionError, CloudflareOpContext>;
export type GetSubdomainError = InvalidRoute | SubdomainNotFound | Forbidden | CloudflareOpError;
/** Returns a Workers subdomain for an account. */
export declare const getSubdomain: API.OperationMethod<GetSubdomainRequest, GetSubdomainResponse, GetSubdomainError, CloudflareOpContext>;
export type KeysObservabilityTelemetryError = InvalidRoute | CloudflareOpError;
/** List all the keys in your telemetry events. */
export declare const keysObservabilityTelemetry: API.PaginatedOperationMethod<KeysObservabilityTelemetryRequest, KeysObservabilityTelemetryResponse, KeysObservabilityTelemetryError, CloudflareOpContext, ObservabilityTelemetryKeysResultItem>;
export type ListBetaWorkersError = InvalidRoute | CloudflareOpError;
/** List all Workers for an account. */
export declare const listBetaWorkers: API.PaginatedOperationMethod<ListBetaWorkersRequest, ListBetaWorkersResponse, ListBetaWorkersError, CloudflareOpContext, BetaWorkersListResultItem>;
export type ListBetaWorkerVersionsError = WorkerNotFound | CloudflareOpError;
/** List all versions for a Worker. */
export declare const listBetaWorkerVersions: API.PaginatedOperationMethod<ListBetaWorkerVersionsRequest, ListBetaWorkerVersionsResponse, ListBetaWorkerVersionsError, CloudflareOpContext, BetaWorkersVersionsListResultItem>;
export type ListDomainsError = InvalidRoute | CloudflareOpError;
/** Lists all domains for an account. */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest, ListDomainsResponse, ListDomainsError, CloudflareOpContext, DomainsListResultItem>;
export type ListObservabilityDestinationsError = Forbidden | CloudflareOpError;
/** List your Workers Observability Telemetry Destinations. */
export declare const listObservabilityDestinations: API.PaginatedOperationMethod<ListObservabilityDestinationsRequest, ListObservabilityDestinationsResponse, ListObservabilityDestinationsError, CloudflareOpContext, ObservabilityDestinationsListResultItem>;
export type ListObservabilityQueriesError = CloudflareOpError;
/** List saved queries. */
export declare const listObservabilityQueries: API.PaginatedOperationMethod<ListObservabilityQueriesRequest, ListObservabilityQueriesResponse, ListObservabilityQueriesError, CloudflareOpContext, ObservabilityQueriesListResultItem>;
export type ListRoutesError = InvalidRoute | Forbidden | CloudflareOpError;
/** Returns routes for a zone. */
export declare const listRoutes: API.PaginatedOperationMethod<ListRoutesRequest, ListRoutesResponse, ListRoutesError, CloudflareOpContext, RoutesListResultItem>;
export type ListScriptDeploymentsError = WorkerNotFound | CloudflareOpError;
/** List of Worker Deployments. The first deployment in the list is the latest deployment actively serving traffic. */
export declare const listScriptDeployments: API.OperationMethod<ListScriptDeploymentsRequest, ListScriptDeploymentsResponse, ListScriptDeploymentsError, CloudflareOpContext>;
export type ListScriptsError = InvalidRoute | CloudflareOpError;
/** Fetch a list of uploaded workers. */
export declare const listScripts: API.PaginatedOperationMethod<ListScriptsRequest, ListScriptsResponse, ListScriptsError, CloudflareOpContext, ScriptsListResultItem>;
export type ListScriptSecretsError = WorkerNotFound | CloudflareOpError;
/** List secrets bound to a script. */
export declare const listScriptSecrets: API.PaginatedOperationMethod<ListScriptSecretsRequest, ListScriptSecretsResponse, ListScriptSecretsError, CloudflareOpContext, ScriptsSecretsListResultItem>;
export type ListScriptVersionsError = WorkerNotFound | CloudflareOpError;
/** List of Worker Versions. The first version in the list is the latest version. */
export declare const listScriptVersions: API.OperationMethod<ListScriptVersionsRequest, ListScriptVersionsResponse, ListScriptVersionsError, CloudflareOpContext>;
export type LiveTailHeartbeatObservabilityTelemetryError = CloudflareOpError;
/** Notify live tail that user is still eligible to receive live events. */
export declare const liveTailHeartbeatObservabilityTelemetry: API.OperationMethod<LiveTailHeartbeatObservabilityTelemetryRequest, LiveTailHeartbeatObservabilityTelemetryResponse, LiveTailHeartbeatObservabilityTelemetryError, CloudflareOpContext>;
export type LiveTailObservabilityTelemetryError = CloudflareOpError;
/** Prepare websocket server for live tail. */
export declare const liveTailObservabilityTelemetry: API.OperationMethod<LiveTailObservabilityTelemetryRequest, LiveTailObservabilityTelemetryResponse, LiveTailObservabilityTelemetryError, CloudflareOpContext>;
export type PatchBetaWorkerError = WorkerNotFound | CloudflareOpError;
/** Perform a partial update on a Worker, where omitted properties are left unchanged from their current values. */
export declare const patchBetaWorker: API.OperationMethod<PatchBetaWorkerRequest, PatchBetaWorkerResponse, PatchBetaWorkerError, CloudflareOpContext>;
export type PatchObservabilityDestinationError = ObservabilityDestinationNotFound | ObservabilityDestinationPreflightFailed | Forbidden | CloudflareOpError;
/** Update an existing Workers Observability Telemetry Destination. */
export declare const patchObservabilityDestination: API.OperationMethod<PatchObservabilityDestinationRequest, PatchObservabilityDestinationResponse, PatchObservabilityDestinationError, CloudflareOpContext>;
export type PatchScriptScriptAndVersionSettingError = WorkerNotFound | ContentTypeRequired | CloudflareOpError;
/** Patch metadata or config, such as bindings or usage model. */
export declare const patchScriptScriptAndVersionSetting: API.OperationMethod<PatchScriptScriptAndVersionSettingRequest, PatchScriptScriptAndVersionSettingResponse, PatchScriptScriptAndVersionSettingError, CloudflareOpContext>;
export type PatchScriptSettingError = WorkerNotFound | CloudflareOpError;
/** Patch script-level settings when using [Worker Versions](https://developers.cloudflare.com/api/operations/worker-versions-list-versions). Including but not limited to Logpush and Tail Consumers. */
export declare const patchScriptSetting: API.OperationMethod<PatchScriptSettingRequest, PatchScriptSettingResponse, PatchScriptSettingError, CloudflareOpContext>;
export type PutAccountSettingError = InvalidRoute | Forbidden | CloudflareOpError;
/** Creates Worker account settings for an account. */
export declare const putAccountSetting: API.OperationMethod<PutAccountSettingRequest, PutAccountSettingResponse, PutAccountSettingError, CloudflareOpContext>;
export type PutDomainError = WorkerNotFound | InvalidRoute | HostnameAlreadyInUse | CloudflareOpError;
/** Attaches a domain that routes traffic to a Worker. */
export declare const putDomain: API.OperationMethod<PutDomainRequest, PutDomainResponse, PutDomainError, CloudflareOpContext>;
export type PutScriptError = InvalidRoute | InvalidWorkerScript | DurableObjectMustBeSqlite | DuplicateMigrationTarget | ScriptStartupError | ScriptModuleNotFound | SecretsStoreBindingNotFound | KVNamespaceNotFound | R2BucketNotFound | D1DatabaseNotFound | QueueNotFound | ServiceBindingNotFound | DurableObjectClassNotFound | HyperdriveConfigNotFound | VectorizeIndexNotFound | DispatchNamespaceNotFound | MtlsCertificateNotFound | CloudflareOpError;
/** Upload a worker module. You can find more about the multipart metadata on our docs: https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/. */
export declare const putScript: API.OperationMethod<PutScriptRequest, PutScriptResponse, PutScriptError, CloudflareOpContext>;
export type PutScriptContentError = WorkerNotFound | InvalidWorkerScript | ScriptStartupError | ScriptModuleNotFound | CloudflareOpError;
/** Put script content without touching config or metadata. */
export declare const putScriptContent: API.OperationMethod<PutScriptContentRequest, PutScriptContentResponse, PutScriptContentError, CloudflareOpContext>;
export type PutScriptScheduleError = WorkerNotFound | CloudflareOpError;
/** Updates Cron Triggers for a Worker. */
export declare const putScriptSchedule: API.OperationMethod<PutScriptScheduleRequest, PutScriptScheduleResponse, PutScriptScheduleError, CloudflareOpContext>;
export type PutScriptSecretError = WorkerNotFound | CloudflareOpError;
/** Add a secret to a script. */
export declare const putScriptSecret: API.OperationMethod<PutScriptSecretRequest, PutScriptSecretResponse, PutScriptSecretError, CloudflareOpContext>;
export type PutSubdomainError = SubdomainAlreadyExists | InvalidRoute | Forbidden | CloudflareOpError;
/** Creates a Workers subdomain for an account. */
export declare const putSubdomain: API.OperationMethod<PutSubdomainRequest, PutSubdomainResponse, PutSubdomainError, CloudflareOpContext>;
export type QueryObservabilityTelemetryError = InvalidRoute | CloudflareOpError;
/** Run a temporary or saved query. */
export declare const queryObservabilityTelemetry: API.OperationMethod<QueryObservabilityTelemetryRequest, QueryObservabilityTelemetryResponse, QueryObservabilityTelemetryError, CloudflareOpContext>;
export type SearchScriptError = InvalidRoute | CloudflareOpError;
/** Search for Workers in an account. */
export declare const searchScript: API.OperationMethod<SearchScriptRequest, SearchScriptResponse, SearchScriptError, CloudflareOpContext>;
export type UpdateBetaWorkerError = WorkerNotFound | CloudflareOpError;
/** Perform a complete replacement of a Worker, where omitted properties are set to their default values. This is the exact same as the Create Worker endpoint, but operates on an existing Worker. To perform a partial update instead, use the Edit Worker endpoint. */
export declare const updateBetaWorker: API.OperationMethod<UpdateBetaWorkerRequest, UpdateBetaWorkerResponse, UpdateBetaWorkerError, CloudflareOpContext>;
export type UpdateRouteError = RouteNotFound | InvalidRoutePattern | CloudflareOpError;
/** Updates the URL pattern or Worker associated with a route. */
export declare const updateRoute: API.OperationMethod<UpdateRouteRequest, UpdateRouteResponse, UpdateRouteError, CloudflareOpContext>;
export type ValuesObservabilityTelemetryError = InvalidRoute | CloudflareOpError;
/** List unique values found in your events. */
export declare const valuesObservabilityTelemetry: API.PaginatedOperationMethod<ValuesObservabilityTelemetryRequest, ValuesObservabilityTelemetryResponse, ValuesObservabilityTelemetryError, CloudflareOpContext, ObservabilityTelemetryValuesResultItem>;
//# sourceMappingURL=workers.d.ts.map