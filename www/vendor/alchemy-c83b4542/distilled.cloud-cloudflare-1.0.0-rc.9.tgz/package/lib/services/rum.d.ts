import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const MaxRulesExceeded_base: S.Class<MaxRulesExceeded, S.TaggedStruct<"MaxRulesExceeded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaxRulesExceeded extends /*@__PURE__*/ MaxRulesExceeded_base {
}
declare const RuleNotFound_base: S.Class<RuleNotFound, S.TaggedStruct<"RuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RuleNotFound extends /*@__PURE__*/ RuleNotFound_base {
}
declare const RulesetNotFound_base: S.Class<RulesetNotFound, S.TaggedStruct<"RulesetNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RulesetNotFound extends /*@__PURE__*/ RulesetNotFound_base {
}
declare const RumSiteQuotaExceeded_base: S.Class<RumSiteQuotaExceeded, S.TaggedStruct<"RumSiteQuotaExceeded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class RumSiteQuotaExceeded extends /*@__PURE__*/ RumSiteQuotaExceeded_base {
}
declare const SiteNotFound_base: S.Class<SiteNotFound, S.TaggedStruct<"SiteNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SiteNotFound extends /*@__PURE__*/ SiteNotFound_base {
}
export type RulesBulkCreateRequestDeleteRulesList = Array<string>;
export declare const RulesBulkCreateRequestDeleteRulesList: S.Schema<RulesBulkCreateRequestDeleteRulesList>;
export type RulesBulkCreateRequestRulesItemPathsList = Array<string>;
export declare const RulesBulkCreateRequestRulesItemPathsList: S.Schema<RulesBulkCreateRequestRulesItemPathsList>;
export interface RulesBulkCreateRequestRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string;
    host?: string;
    inclusive?: boolean;
    isPaused?: boolean;
    paths?: RulesBulkCreateRequestRulesItemPathsList;
}
export declare const RulesBulkCreateRequestRulesItem: S.Schema<RulesBulkCreateRequestRulesItem>;
export type RulesBulkCreateRequestRulesList = Array<RulesBulkCreateRequestRulesItem>;
export declare const RulesBulkCreateRequestRulesList: S.Schema<RulesBulkCreateRequestRulesList>;
export interface BulkCreateRulesRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    /** A list of rule identifiers to delete. */
    deleteRules?: RulesBulkCreateRequestDeleteRulesList;
    /** A list of rules to create or update. */
    rules?: RulesBulkCreateRequestRulesList;
}
export declare const BulkCreateRulesRequest: S.Schema<BulkCreateRulesRequest>;
export type RulesBulkCreateResponseRulesItemPathsList = Array<string>;
export declare const RulesBulkCreateResponseRulesItemPathsList: S.Schema<RulesBulkCreateResponseRulesItemPathsList>;
export interface RulesBulkCreateResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesBulkCreateResponseRulesItemPathsList | null;
    priority?: number | null;
}
export declare const RulesBulkCreateResponseRulesItem: S.Schema<RulesBulkCreateResponseRulesItem>;
export type RulesBulkCreateResponseRulesList = Array<RulesBulkCreateResponseRulesItem>;
export declare const RulesBulkCreateResponseRulesList: S.Schema<RulesBulkCreateResponseRulesList>;
export interface RulesBulkCreateResponseRuleset {
    /** The Web Analytics ruleset identifier. */
    id?: string | null;
    /** Whether the ruleset is enabled. */
    enabled?: boolean | null;
    zoneName?: string | null;
    /** The zone identifier. */
    zoneTag?: string | null;
}
export declare const RulesBulkCreateResponseRuleset: S.Schema<RulesBulkCreateResponseRuleset>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkCreateRulesResponse {
    /** A list of rules. */
    rules?: RulesBulkCreateResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
}
export declare const BulkCreateRulesResponse: S.Schema<BulkCreateRulesResponse>;
export type RulesCreateRequestPathsList = Array<string>;
export declare const RulesCreateRequestPathsList: S.Schema<RulesCreateRequestPathsList>;
export interface CreateRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    host?: string;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean;
    /** Whether the rule is paused or not. */
    isPaused?: boolean;
    paths?: RulesCreateRequestPathsList;
}
export declare const CreateRuleRequest: S.Schema<CreateRuleRequest>;
export type RulesCreateResponsePathsList = Array<string>;
export declare const RulesCreateResponsePathsList: S.Schema<RulesCreateResponsePathsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRuleResponse {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesCreateResponsePathsList | null;
    priority?: number | null;
}
export declare const CreateRuleResponse: S.Schema<CreateRuleResponse>;
export interface CreateSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean;
    /** The hostname to use for gray-clouded sites. */
    host?: string;
    /** The zone identifier. */
    zoneTag?: string;
}
export declare const CreateSiteInfoRequest: S.Schema<CreateSiteInfoRequest>;
export type SiteInfoCreateResponseRulesItemPathsList = Array<string>;
export declare const SiteInfoCreateResponseRulesItemPathsList: S.Schema<SiteInfoCreateResponseRulesItemPathsList>;
export interface SiteInfoCreateResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoCreateResponseRulesItemPathsList | null;
    priority?: number | null;
}
export declare const SiteInfoCreateResponseRulesItem: S.Schema<SiteInfoCreateResponseRulesItem>;
export type SiteInfoCreateResponseRulesList = Array<SiteInfoCreateResponseRulesItem>;
export declare const SiteInfoCreateResponseRulesList: S.Schema<SiteInfoCreateResponseRulesList>;
export type SiteInfoCreateResponseRuleset = RulesBulkCreateResponseRuleset;
export declare const SiteInfoCreateResponseRuleset: S.Schema<RulesBulkCreateResponseRuleset>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSiteInfoResponse {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoCreateResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export declare const CreateSiteInfoResponse: S.Schema<CreateSiteInfoResponse>;
export interface DeleteRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    /** The Web Analytics rule identifier. */
    ruleId: string;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** The Web Analytics rule identifier. */
    id?: string | null;
}
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface DeleteSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    siteId: string;
}
export declare const DeleteSiteInfoRequest: S.Schema<DeleteSiteInfoRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSiteInfoResponse {
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
}
export declare const DeleteSiteInfoResponse: S.Schema<DeleteSiteInfoResponse>;
export interface GetSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    siteId: string;
}
export declare const GetSiteInfoRequest: S.Schema<GetSiteInfoRequest>;
export type SiteInfoGetResponseRulesItemPathsList = Array<string>;
export declare const SiteInfoGetResponseRulesItemPathsList: S.Schema<SiteInfoGetResponseRulesItemPathsList>;
export interface SiteInfoGetResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoGetResponseRulesItemPathsList | null;
    priority?: number | null;
}
export declare const SiteInfoGetResponseRulesItem: S.Schema<SiteInfoGetResponseRulesItem>;
export type SiteInfoGetResponseRulesList = Array<SiteInfoGetResponseRulesItem>;
export declare const SiteInfoGetResponseRulesList: S.Schema<SiteInfoGetResponseRulesList>;
export type SiteInfoGetResponseRuleset = RulesBulkCreateResponseRuleset;
export declare const SiteInfoGetResponseRuleset: S.Schema<RulesBulkCreateResponseRuleset>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSiteInfoResponse {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoGetResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export declare const GetSiteInfoResponse: S.Schema<GetSiteInfoResponse>;
export interface ListRulesRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export type RulesListResponseRulesItemPathsList = Array<string>;
export declare const RulesListResponseRulesItemPathsList: S.Schema<RulesListResponseRulesItemPathsList>;
export interface RulesListResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesListResponseRulesItemPathsList | null;
    priority?: number | null;
}
export declare const RulesListResponseRulesItem: S.Schema<RulesListResponseRulesItem>;
export type RulesListResponseRulesList = Array<RulesListResponseRulesItem>;
export declare const RulesListResponseRulesList: S.Schema<RulesListResponseRulesList>;
export type RulesListResponseRuleset = RulesBulkCreateResponseRuleset;
export declare const RulesListResponseRuleset: S.Schema<RulesBulkCreateResponseRuleset>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListRulesResponse {
    /** A list of rules. */
    rules?: RulesListResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export type SiteInfoListRequestOrderBy = "host" | "created";
export declare const SiteInfoListRequestOrderBy: any;
export interface ListSiteInfosRequest {
    /** Identifier. */
    accountId: string;
    /** The property used to sort the list of results. */
    orderBy?: SiteInfoListRequestOrderBy | (string & {});
    /** Current page within the paginated list of results. */
    page?: number;
    /** Number of items to return per page of results. */
    perPage?: number;
}
export declare const ListSiteInfosRequest: S.Schema<ListSiteInfosRequest>;
export type SiteInfoListResultItemRulesItemPathsList = Array<string>;
export declare const SiteInfoListResultItemRulesItemPathsList: S.Schema<SiteInfoListResultItemRulesItemPathsList>;
export interface SiteInfoListResultItemRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoListResultItemRulesItemPathsList | null;
    priority?: number | null;
}
export declare const SiteInfoListResultItemRulesItem: S.Schema<SiteInfoListResultItemRulesItem>;
export type SiteInfoListResultItemRulesList = Array<SiteInfoListResultItemRulesItem>;
export declare const SiteInfoListResultItemRulesList: S.Schema<SiteInfoListResultItemRulesList>;
export type SiteInfoListResultItemRuleset = RulesBulkCreateResponseRuleset;
export declare const SiteInfoListResultItemRuleset: S.Schema<RulesBulkCreateResponseRuleset>;
export interface SiteInfoListResultItem {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoListResultItemRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export declare const SiteInfoListResultItem: S.Schema<SiteInfoListResultItem>;
export type SiteInfoListResultList = Array<SiteInfoListResultItem>;
export declare const SiteInfoListResultList: S.Schema<SiteInfoListResultList>;
export interface ListSiteInfosResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SiteInfoListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSiteInfosResponse: S.Schema<ListSiteInfosResponse>;
export type RulesUpdateRequestPathsList = Array<string>;
export declare const RulesUpdateRequestPathsList: S.Schema<RulesUpdateRequestPathsList>;
export interface UpdateRuleRequest {
    /** Identifier. */
    accountId: string;
    /** The Web Analytics ruleset identifier. */
    rulesetId: string;
    /** The Web Analytics rule identifier. */
    ruleId: string;
    host?: string;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean;
    /** Whether the rule is paused or not. */
    isPaused?: boolean;
    paths?: RulesUpdateRequestPathsList;
}
export declare const UpdateRuleRequest: S.Schema<UpdateRuleRequest>;
export type RulesUpdateResponsePathsList = Array<string>;
export declare const RulesUpdateResponsePathsList: S.Schema<RulesUpdateResponsePathsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: RulesUpdateResponsePathsList | null;
    priority?: number | null;
}
export declare const UpdateRuleResponse: S.Schema<UpdateRuleResponse>;
export interface UpdateSiteInfoRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    siteId: string;
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean;
    /** Enables or disables RUM. This option can be used only when auto_install is set to true. */
    enabled?: boolean;
    /** The hostname to use for gray-clouded sites. */
    host?: string;
    /** If enabled, the JavaScript snippet will not be injected for visitors from the EU. */
    lite?: boolean;
    /** The zone identifier. */
    zoneTag?: string;
}
export declare const UpdateSiteInfoRequest: S.Schema<UpdateSiteInfoRequest>;
export type SiteInfoUpdateResponseRulesItemPathsList = Array<string>;
export declare const SiteInfoUpdateResponseRulesItemPathsList: S.Schema<SiteInfoUpdateResponseRulesItemPathsList>;
export interface SiteInfoUpdateResponseRulesItem {
    /** The Web Analytics rule identifier. */
    id?: string | null;
    created?: string | null;
    /** The hostname the rule will be applied to. */
    host?: string | null;
    /** Whether the rule includes or excludes traffic from being measured. */
    inclusive?: boolean | null;
    /** Whether the rule is paused or not. */
    isPaused?: boolean | null;
    /** The paths the rule will be applied to. */
    paths?: SiteInfoUpdateResponseRulesItemPathsList | null;
    priority?: number | null;
}
export declare const SiteInfoUpdateResponseRulesItem: S.Schema<SiteInfoUpdateResponseRulesItem>;
export type SiteInfoUpdateResponseRulesList = Array<SiteInfoUpdateResponseRulesItem>;
export declare const SiteInfoUpdateResponseRulesList: S.Schema<SiteInfoUpdateResponseRulesList>;
export type SiteInfoUpdateResponseRuleset = RulesBulkCreateResponseRuleset;
export declare const SiteInfoUpdateResponseRuleset: S.Schema<RulesBulkCreateResponseRuleset>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSiteInfoResponse {
    /** If enabled, the JavaScript snippet is automatically injected for orange-clouded sites. */
    autoInstall?: boolean | null;
    created?: string | null;
    /** A list of rules. */
    rules?: SiteInfoUpdateResponseRulesList | null;
    ruleset?: RulesBulkCreateResponseRuleset | null;
    /** The Web Analytics site identifier. */
    siteTag?: string | null;
    /** The Web Analytics site token. */
    siteToken?: string | null;
    /** Encoded JavaScript snippet. */
    snippet?: string | null;
    /** The hostname the site measures (gray-clouded sites). */
    host?: string | null;
}
export declare const UpdateSiteInfoResponse: S.Schema<UpdateSiteInfoResponse>;
export type BulkCreateRulesError = CloudflareOpError;
/** Modifies one or more rules in a Web Analytics ruleset with a single request. */
export declare const bulkCreateRules: API.OperationMethod<BulkCreateRulesRequest, BulkCreateRulesResponse, BulkCreateRulesError, CloudflareOpContext>;
export type CreateRuleError = Forbidden | RulesetNotFound | MaxRulesExceeded | CloudflareOpError;
/** Creates a new rule in a Web Analytics ruleset. */
export declare const createRule: API.OperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext>;
export type CreateSiteInfoError = Forbidden | RumSiteQuotaExceeded | CloudflareOpError;
/** Creates a new Web Analytics site. */
export declare const createSiteInfo: API.OperationMethod<CreateSiteInfoRequest, CreateSiteInfoResponse, CreateSiteInfoError, CloudflareOpContext>;
export type DeleteRuleError = Forbidden | RulesetNotFound | RuleNotFound | CloudflareOpError;
/** Deletes an existing rule from a Web Analytics ruleset. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DeleteSiteInfoError = SiteNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing Web Analytics site. */
export declare const deleteSiteInfo: API.OperationMethod<DeleteSiteInfoRequest, DeleteSiteInfoResponse, DeleteSiteInfoError, CloudflareOpContext>;
export type GetSiteInfoError = SiteNotFound | Forbidden | CloudflareOpError;
/** Retrieves a Web Analytics site. */
export declare const getSiteInfo: API.OperationMethod<GetSiteInfoRequest, GetSiteInfoResponse, GetSiteInfoError, CloudflareOpContext>;
export type ListRulesError = Forbidden | RulesetNotFound | CloudflareOpError;
/** Lists all the rules in a Web Analytics ruleset. */
export declare const listRules: API.OperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext>;
export type ListSiteInfosError = Forbidden | CloudflareOpError;
/** Lists all Web Analytics sites of an account. */
export declare const listSiteInfos: API.PaginatedOperationMethod<ListSiteInfosRequest, ListSiteInfosResponse, ListSiteInfosError, CloudflareOpContext, SiteInfoListResultItem>;
export type UpdateRuleError = Forbidden | RulesetNotFound | CloudflareOpError;
/** Updates a rule in a Web Analytics ruleset. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
export type UpdateSiteInfoError = SiteNotFound | Forbidden | CloudflareOpError;
/** Updates an existing Web Analytics site. */
export declare const updateSiteInfo: API.OperationMethod<UpdateSiteInfoRequest, UpdateSiteInfoResponse, UpdateSiteInfoError, CloudflareOpContext>;
//# sourceMappingURL=rum.d.ts.map