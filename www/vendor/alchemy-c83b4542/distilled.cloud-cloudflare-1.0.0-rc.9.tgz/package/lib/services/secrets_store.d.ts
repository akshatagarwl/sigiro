import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidAccountId_base: S.Class<InvalidAccountId, S.TaggedStruct<"InvalidAccountId", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidAccountId extends /*@__PURE__*/ InvalidAccountId_base {
}
declare const InvalidJsonBody_base: S.Class<InvalidJsonBody, S.TaggedStruct<"InvalidJsonBody", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidJsonBody extends /*@__PURE__*/ InvalidJsonBody_base {
}
declare const MaximumStoresExceeded_base: S.Class<MaximumStoresExceeded, S.TaggedStruct<"MaximumStoresExceeded", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MaximumStoresExceeded extends /*@__PURE__*/ MaximumStoresExceeded_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
declare const SecretNameAlreadyExists_base: S.Class<SecretNameAlreadyExists, S.TaggedStruct<"SecretNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretNameAlreadyExists extends /*@__PURE__*/ SecretNameAlreadyExists_base {
}
declare const SecretNameEmpty_base: S.Class<SecretNameEmpty, S.TaggedStruct<"SecretNameEmpty", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretNameEmpty extends /*@__PURE__*/ SecretNameEmpty_base {
}
declare const SecretNotFound_base: S.Class<SecretNotFound, S.TaggedStruct<"SecretNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretNotFound extends /*@__PURE__*/ SecretNotFound_base {
}
declare const SecretScopeInvalid_base: S.Class<SecretScopeInvalid, S.TaggedStruct<"SecretScopeInvalid", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretScopeInvalid extends /*@__PURE__*/ SecretScopeInvalid_base {
}
declare const SecretScopesEmpty_base: S.Class<SecretScopesEmpty, S.TaggedStruct<"SecretScopesEmpty", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SecretScopesEmpty extends /*@__PURE__*/ SecretScopesEmpty_base {
}
declare const StoreNotFound_base: S.Class<StoreNotFound, S.TaggedStruct<"StoreNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class StoreNotFound extends /*@__PURE__*/ StoreNotFound_base {
}
export interface BulkDeleteStoreSecretsRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
}
export declare const BulkDeleteStoreSecretsRequest: S.Schema<BulkDeleteStoreSecretsRequest>;
export type BulkDeleteStoreSecretsResponse = unknown;
export declare const BulkDeleteStoreSecretsResponse: S.Schema<BulkDeleteStoreSecretsResponse>;
export interface CreateStoreRequest {
    /** Account Identifier */
    accountId: string;
    /** The name of the store */
    name: string;
}
export declare const CreateStoreRequest: S.Schema<CreateStoreRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateStoreResponse {
    /** Store Identifier */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the store */
    name: string;
    /** Account Identifier */
    accountId?: string | null;
}
export declare const CreateStoreResponse: S.Schema<CreateStoreResponse>;
export type StoresSecretsCreateRequestBodyItemScopesList = Array<string>;
export declare const StoresSecretsCreateRequestBodyItemScopesList: S.Schema<StoresSecretsCreateRequestBodyItemScopesList>;
export interface StoresSecretsCreateRequestBodyItem {
    /** The name of the secret */
    name: string;
    /** The list of services that can use this secret. */
    scopes: StoresSecretsCreateRequestBodyItemScopesList;
    /** The value of the secret. Maximum 64 KiB (65,536 bytes). Note that this is 'write only' - no API response will provide this value, it is only used to create/modify secrets. */
    value: string;
    /** Freeform text describing the secret */
    comment?: string;
}
export declare const StoresSecretsCreateRequestBodyItem: S.Schema<StoresSecretsCreateRequestBodyItem>;
export type StoresSecretsCreateRequestBodyList = Array<StoresSecretsCreateRequestBodyItem>;
export declare const StoresSecretsCreateRequestBodyList: S.Schema<StoresSecretsCreateRequestBodyList>;
export interface CreateStoreSecretRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
    body: StoresSecretsCreateRequestBodyList;
}
export declare const CreateStoreSecretRequest: S.Schema<CreateStoreSecretRequest>;
export type StoresSecretsCreateResultItemStatus = "pending" | "active" | "deleted";
export declare const StoresSecretsCreateResultItemStatus: any;
export type StoresSecretsCreateResultItemScopesList = Array<string>;
export declare const StoresSecretsCreateResultItemScopesList: S.Schema<StoresSecretsCreateResultItemScopesList>;
export interface StoresSecretsCreateResultItem {
    /** Secret identifier tag. */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret */
    name: string;
    status: StoresSecretsCreateResultItemStatus;
    /** Store Identifier */
    storeId: string;
    /** Freeform text describing the secret */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsCreateResultItemScopesList | null;
}
export declare const StoresSecretsCreateResultItem: S.Schema<StoresSecretsCreateResultItem>;
export type StoresSecretsCreateResultList = Array<StoresSecretsCreateResultItem>;
export declare const StoresSecretsCreateResultList: S.Schema<StoresSecretsCreateResultList>;
export interface CreateStoreSecretResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StoresSecretsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateStoreSecretResponse: S.Schema<CreateStoreSecretResponse>;
export interface DeleteStoreRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
    /** When true, cascade-deletes all secrets in the store before deleting */
    force?: boolean;
}
export declare const DeleteStoreRequest: S.Schema<DeleteStoreRequest>;
export type DeleteStoreResponse = unknown;
export declare const DeleteStoreResponse: S.Schema<DeleteStoreResponse>;
export interface DeleteStoreSecretRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
    /** Secret identifier tag. */
    secretId: string;
}
export declare const DeleteStoreSecretRequest: S.Schema<DeleteStoreSecretRequest>;
export type DeleteStoreSecretResponse = unknown;
export declare const DeleteStoreSecretResponse: S.Schema<DeleteStoreSecretResponse>;
export type StoresSecretsDuplicateRequestScopesList = Array<string>;
export declare const StoresSecretsDuplicateRequestScopesList: S.Schema<StoresSecretsDuplicateRequestScopesList>;
export interface DuplicateStoreSecretRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
    /** Secret identifier tag. */
    secretId: string;
    /** The name of the secret */
    name: string;
    /** The list of services that can use this secret. */
    scopes: StoresSecretsDuplicateRequestScopesList;
    /** Freeform text describing the secret */
    comment?: string;
}
export declare const DuplicateStoreSecretRequest: S.Schema<DuplicateStoreSecretRequest>;
export type StoresSecretsDuplicateResponseStatus = "pending" | "active" | "deleted";
export declare const StoresSecretsDuplicateResponseStatus: any;
export type StoresSecretsDuplicateResponseScopesList = Array<string>;
export declare const StoresSecretsDuplicateResponseScopesList: S.Schema<StoresSecretsDuplicateResponseScopesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DuplicateStoreSecretResponse {
    /** Secret identifier tag. */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret */
    name: string;
    status: StoresSecretsDuplicateResponseStatus;
    /** Store Identifier */
    storeId: string;
    /** Freeform text describing the secret */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsDuplicateResponseScopesList | null;
}
export declare const DuplicateStoreSecretResponse: S.Schema<DuplicateStoreSecretResponse>;
export interface GetQuotaRequest {
    /** Account Identifier */
    accountId: string;
}
export declare const GetQuotaRequest: S.Schema<GetQuotaRequest>;
export interface QuotaGetResponseSecrets {
    /** The number of secrets the account is entitlted to use */
    quota: number;
    /** The number of secrets the account is currently using */
    usage: number;
}
export declare const QuotaGetResponseSecrets: S.Schema<QuotaGetResponseSecrets>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetQuotaResponse {
    secrets: QuotaGetResponseSecrets;
}
export declare const GetQuotaResponse: S.Schema<GetQuotaResponse>;
export interface GetStoreRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
}
export declare const GetStoreRequest: S.Schema<GetStoreRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStoreResponse {
    /** Store Identifier */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the store */
    name: string;
    /** Account Identifier */
    accountId?: string | null;
}
export declare const GetStoreResponse: S.Schema<GetStoreResponse>;
export interface GetStoreSecretRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
    /** Secret identifier tag. */
    secretId: string;
}
export declare const GetStoreSecretRequest: S.Schema<GetStoreSecretRequest>;
export type StoresSecretsGetResponseStatus = "pending" | "active" | "deleted";
export declare const StoresSecretsGetResponseStatus: any;
export type StoresSecretsGetResponseScopesList = Array<string>;
export declare const StoresSecretsGetResponseScopesList: S.Schema<StoresSecretsGetResponseScopesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStoreSecretResponse {
    /** Secret identifier tag. */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret */
    name: string;
    status: StoresSecretsGetResponseStatus;
    /** Store Identifier */
    storeId: string;
    /** Freeform text describing the secret */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsGetResponseScopesList | null;
}
export declare const GetStoreSecretResponse: S.Schema<GetStoreSecretResponse>;
export type StoresListRequestDirection = "asc" | "desc";
export declare const StoresListRequestDirection: any;
export type StoresListRequestOrder = "name" | "comment" | "created" | "modified" | "status";
export declare const StoresListRequestOrder: any;
export interface ListStoresRequest {
    /** Account Identifier */
    accountId: string;
    /** Direction to sort objects */
    direction?: StoresListRequestDirection | (string & {});
    /** Order secrets by values in the given field */
    order?: StoresListRequestOrder | (string & {});
    /** Page number */
    page?: number;
    /** Number of objects to return per page */
    perPage?: number;
}
export declare const ListStoresRequest: S.Schema<ListStoresRequest>;
export interface StoresListResultItem {
    /** Store Identifier */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the store */
    name: string;
    /** Account Identifier */
    accountId?: string | null;
}
export declare const StoresListResultItem: S.Schema<StoresListResultItem>;
export type StoresListResultList = Array<StoresListResultItem>;
export declare const StoresListResultList: S.Schema<StoresListResultList>;
export interface ListStoresResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StoresListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListStoresResponse: S.Schema<ListStoresResponse>;
export type StoresSecretsListRequestDirection = "asc" | "desc";
export declare const StoresSecretsListRequestDirection: any;
export type StoresSecretsListRequestOrder = "name" | "comment" | "created" | "modified" | "status";
export declare const StoresSecretsListRequestOrder: any;
export type StoresSecretsListRequestScopesList = Array<string>;
export declare const StoresSecretsListRequestScopesList: S.Schema<StoresSecretsListRequestScopesList>;
export interface ListStoreSecretsRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
    /** Direction to sort objects */
    direction?: StoresSecretsListRequestDirection | (string & {});
    /** Order secrets by values in the given field */
    order?: StoresSecretsListRequestOrder | (string & {});
    /** Page number */
    page?: number;
    /** Number of objects to return per page */
    perPage?: number;
    /** Only secrets with the given scopes will be returned */
    scopes?: StoresSecretsListRequestScopesList;
    /** Search secrets using a filter string, filtering across name and comment */
    search?: string;
}
export declare const ListStoreSecretsRequest: S.Schema<ListStoreSecretsRequest>;
export type StoresSecretsListResultItemStatus = "pending" | "active" | "deleted";
export declare const StoresSecretsListResultItemStatus: any;
export type StoresSecretsListResultItemScopesList = Array<string>;
export declare const StoresSecretsListResultItemScopesList: S.Schema<StoresSecretsListResultItemScopesList>;
export interface StoresSecretsListResultItem {
    /** Secret identifier tag. */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret */
    name: string;
    status: StoresSecretsListResultItemStatus;
    /** Store Identifier */
    storeId: string;
    /** Freeform text describing the secret */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsListResultItemScopesList | null;
}
export declare const StoresSecretsListResultItem: S.Schema<StoresSecretsListResultItem>;
export type StoresSecretsListResultList = Array<StoresSecretsListResultItem>;
export declare const StoresSecretsListResultList: S.Schema<StoresSecretsListResultList>;
export interface ListStoreSecretsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: StoresSecretsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListStoreSecretsResponse: S.Schema<ListStoreSecretsResponse>;
export type StoresSecretsEditRequestScopesList = Array<string>;
export declare const StoresSecretsEditRequestScopesList: S.Schema<StoresSecretsEditRequestScopesList>;
export interface PatchStoreSecretRequest {
    /** Account Identifier */
    accountId: string;
    /** Store Identifier */
    storeId: string;
    /** Secret identifier tag. */
    secretId: string;
    /** Freeform text describing the secret */
    comment?: string;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsEditRequestScopesList;
    /** The value of the secret. Maximum 64 KiB (65,536 bytes). Note that this is 'write only' - no API response will provide this value, it is only used to create/modify secrets. */
    value?: string;
}
export declare const PatchStoreSecretRequest: S.Schema<PatchStoreSecretRequest>;
export type StoresSecretsEditResponseStatus = "pending" | "active" | "deleted";
export declare const StoresSecretsEditResponseStatus: any;
export type StoresSecretsEditResponseScopesList = Array<string>;
export declare const StoresSecretsEditResponseScopesList: S.Schema<StoresSecretsEditResponseScopesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchStoreSecretResponse {
    /** Secret identifier tag. */
    id: string;
    /** Whenthe secret was created. */
    created: string;
    /** When the secret was modified. */
    modified: string;
    /** The name of the secret */
    name: string;
    status: StoresSecretsEditResponseStatus;
    /** Store Identifier */
    storeId: string;
    /** Freeform text describing the secret */
    comment?: string | null;
    /** The list of services that can use this secret. */
    scopes?: StoresSecretsEditResponseScopesList | null;
}
export declare const PatchStoreSecretResponse: S.Schema<PatchStoreSecretResponse>;
export type BulkDeleteStoreSecretsError = StoreNotFound | InvalidAccountId | InvalidJsonBody | CloudflareOpError;
/** Deletes one or more secrets */
export declare const bulkDeleteStoreSecrets: API.OperationMethod<BulkDeleteStoreSecretsRequest, BulkDeleteStoreSecretsResponse, BulkDeleteStoreSecretsError, CloudflareOpContext>;
export type CreateStoreError = InvalidAccountId | MaximumStoresExceeded | CloudflareOpError;
/** Creates a store in the account */
export declare const createStore: API.OperationMethod<CreateStoreRequest, CreateStoreResponse, CreateStoreError, CloudflareOpContext>;
export type CreateStoreSecretError = StoreNotFound | InvalidAccountId | SecretNameEmpty | SecretNameAlreadyExists | SecretScopeInvalid | CloudflareOpError;
/** Creates a secret in the account */
export declare const createStoreSecret: API.PaginatedOperationMethod<CreateStoreSecretRequest, CreateStoreSecretResponse, CreateStoreSecretError, CloudflareOpContext, StoresSecretsCreateResultItem>;
export type DeleteStoreError = StoreNotFound | InvalidAccountId | NotFound | CloudflareOpError;
/** Deletes a single store. By default, a store that still contains secrets cannot be deleted and returns HTTP 409 (Conflict) with the "store_not_empty" error. Pass `force=true` to cascade-delete all secrets in the store. Empty stores are always deleted regardless of the force parameter. */
export declare const deleteStore: API.OperationMethod<DeleteStoreRequest, DeleteStoreResponse, DeleteStoreError, CloudflareOpContext>;
export type DeleteStoreSecretError = StoreNotFound | SecretNotFound | InvalidAccountId | NotFound | CloudflareOpError;
/** Deletes a single secret */
export declare const deleteStoreSecret: API.OperationMethod<DeleteStoreSecretRequest, DeleteStoreSecretResponse, DeleteStoreSecretError, CloudflareOpContext>;
export type DuplicateStoreSecretError = StoreNotFound | SecretNotFound | SecretNameEmpty | SecretScopesEmpty | SecretNameAlreadyExists | InvalidAccountId | SecretScopeInvalid | CloudflareOpError;
/** Duplicates the secret, keeping the value */
export declare const duplicateStoreSecret: API.OperationMethod<DuplicateStoreSecretRequest, DuplicateStoreSecretResponse, DuplicateStoreSecretError, CloudflareOpContext>;
export type GetQuotaError = InvalidAccountId | CloudflareOpError;
/** Lists the number of secrets used in the account. */
export declare const getQuota: API.OperationMethod<GetQuotaRequest, GetQuotaResponse, GetQuotaError, CloudflareOpContext>;
export type GetStoreError = CloudflareOpError;
/** Returns details of a single store */
export declare const getStore: API.OperationMethod<GetStoreRequest, GetStoreResponse, GetStoreError, CloudflareOpContext>;
export type GetStoreSecretError = StoreNotFound | SecretNotFound | InvalidAccountId | NotFound | CloudflareOpError;
/** Returns details of a single secret */
export declare const getStoreSecret: API.OperationMethod<GetStoreSecretRequest, GetStoreSecretResponse, GetStoreSecretError, CloudflareOpContext>;
export type ListStoresError = InvalidAccountId | CloudflareOpError;
/** Lists all the stores in an account */
export declare const listStores: API.PaginatedOperationMethod<ListStoresRequest, ListStoresResponse, ListStoresError, CloudflareOpContext, StoresListResultItem>;
export type ListStoreSecretsError = StoreNotFound | InvalidAccountId | CloudflareOpError;
/** Lists all store secrets */
export declare const listStoreSecrets: API.PaginatedOperationMethod<ListStoreSecretsRequest, ListStoreSecretsResponse, ListStoreSecretsError, CloudflareOpContext, StoresSecretsListResultItem>;
export type PatchStoreSecretError = StoreNotFound | SecretNotFound | InvalidAccountId | SecretScopeInvalid | CloudflareOpError;
/** Updates a single secret */
export declare const patchStoreSecret: API.OperationMethod<PatchStoreSecretRequest, PatchStoreSecretResponse, PatchStoreSecretError, CloudflareOpContext>;
//# sourceMappingURL=secrets_store.d.ts.map