import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AclNotFound_base: S.Class<AclNotFound, S.TaggedStruct<"AclNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AclNotFound extends /*@__PURE__*/ AclNotFound_base {
}
declare const DnsRecordAlreadyExists_base: S.Class<DnsRecordAlreadyExists, S.TaggedStruct<"DnsRecordAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DnsRecordAlreadyExists extends /*@__PURE__*/ DnsRecordAlreadyExists_base {
}
declare const DnsSettingNotAvailable_base: S.Class<DnsSettingNotAvailable, S.TaggedStruct<"DnsSettingNotAvailable", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DnsSettingNotAvailable extends /*@__PURE__*/ DnsSettingNotAvailable_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const IncomingZoneTransferNotFound_base: S.Class<IncomingZoneTransferNotFound, S.TaggedStruct<"IncomingZoneTransferNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class IncomingZoneTransferNotFound extends /*@__PURE__*/ IncomingZoneTransferNotFound_base {
}
declare const InternalDnsNotAvailable_base: S.Class<InternalDnsNotAvailable, S.TaggedStruct<"InternalDnsNotAvailable", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InternalDnsNotAvailable extends /*@__PURE__*/ InternalDnsNotAvailable_base {
}
declare const OutgoingZoneTransferNotFound_base: S.Class<OutgoingZoneTransferNotFound, S.TaggedStruct<"OutgoingZoneTransferNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OutgoingZoneTransferNotFound extends /*@__PURE__*/ OutgoingZoneTransferNotFound_base {
}
declare const OutgoingZoneTransfersNotAllowed_base: S.Class<OutgoingZoneTransfersNotAllowed, S.TaggedStruct<"OutgoingZoneTransfersNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OutgoingZoneTransfersNotAllowed extends /*@__PURE__*/ OutgoingZoneTransfersNotAllowed_base {
}
declare const PeerNotFound_base: S.Class<PeerNotFound, S.TaggedStruct<"PeerNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PeerNotFound extends /*@__PURE__*/ PeerNotFound_base {
}
declare const TsigNotFound_base: S.Class<TsigNotFound, S.TaggedStruct<"TsigNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TsigNotFound extends /*@__PURE__*/ TsigNotFound_base {
}
declare const ViewNotFound_base: S.Class<ViewNotFound, S.TaggedStruct<"ViewNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ViewNotFound extends /*@__PURE__*/ ViewNotFound_base {
}
export interface RecordsBatchRequestDeletesItem {
    /** Identifier. */
    id: string;
}
export declare const RecordsBatchRequestDeletesItem: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestDeletesList = Array<RecordsBatchRequestDeletesItem>;
export declare const RecordsBatchRequestDeletesList: S.Schema<RecordsBatchRequestDeletesList>;
export type RecordsBatchRequestPatchesItemARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemAAAARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemAAAARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemCNAMERecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemCNAMERecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemMXRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemMXRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemNSRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemNSRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsBatchRequestPatchesItemOpenpgpkeyRecordType: any;
export interface RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings {
    /** When enabled, only A records will be generated, and AAAA records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv4Only?: boolean;
    /** When enabled, only AAAA records will be generated, and A records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv6Only?: boolean;
}
export declare const RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPatchesItemOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPatchesItemOpenpgpkeyRecordTagsList: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordTagsList>;
export interface RecordsBatchRequestPatchesItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPatchesItemOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordTagsList;
}
export declare const RecordsBatchRequestPatchesItemOpenpgpkeyRecord: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecord>;
export type RecordsBatchRequestPatchesItemPTRRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemPTRRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemTXTRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemTXTRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemCAARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemCAARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemCERTRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemCERTRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemDNSKEYRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemDNSKEYRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemDSRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemDSRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemHTTPSRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemHTTPSRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemLOCRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemLOCRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemNAPTRRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemNAPTRRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemSMIMEARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemSMIMEARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemSRVRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemSRVRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemSSHFPRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemSSHFPRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemSVCBRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemSVCBRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemTLSARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemTLSARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItemURIRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItemURIRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPatchesItem = RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestPatchesItemOpenpgpkeyRecord | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPatchesItem: any;
export type RecordsBatchRequestPatchesList = Array<RecordsBatchRequestPatchesItem>;
export declare const RecordsBatchRequestPatchesList: S.Schema<RecordsBatchRequestPatchesList>;
export type RecordsBatchRequestPostsItemARecordType = "A";
export declare const RecordsBatchRequestPostsItemARecordType: any;
export type RecordsBatchRequestPostsItemARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemARecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemARecordTagsList: S.Schema<RecordsBatchRequestPostsItemARecordTagsList>;
export interface RecordsBatchRequestPostsItemARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemARecordTagsList;
}
export declare const RecordsBatchRequestPostsItemARecord: S.Schema<RecordsBatchRequestPostsItemARecord>;
export type RecordsBatchRequestPostsItemAAAARecordType = "AAAA";
export declare const RecordsBatchRequestPostsItemAAAARecordType: any;
export type RecordsBatchRequestPostsItemAAAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemAAAARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemAAAARecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemAAAARecordTagsList: S.Schema<RecordsBatchRequestPostsItemAAAARecordTagsList>;
export interface RecordsBatchRequestPostsItemAAAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemAAAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv6 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemAAAARecordTagsList;
}
export declare const RecordsBatchRequestPostsItemAAAARecord: S.Schema<RecordsBatchRequestPostsItemAAAARecord>;
export type RecordsBatchRequestPostsItemCNAMERecordType = "CNAME";
export declare const RecordsBatchRequestPostsItemCNAMERecordType: any;
export interface RecordsBatchRequestPostsItemCNAMERecordSettings {
    /** If enabled, causes the CNAME record to be resolved externally and the resulting address records (e.g., A and AAAA) to be returned instead of the CNAME record itself. This setting is unavailable for proxied records, since they are always flattened. */
    flattenCname?: boolean;
    /** When enabled, only A records will be generated, and AAAA records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv4Only?: boolean;
    /** When enabled, only AAAA records will be generated, and A records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv6Only?: boolean;
}
export declare const RecordsBatchRequestPostsItemCNAMERecordSettings: S.Schema<RecordsBatchRequestPostsItemCNAMERecordSettings>;
export type RecordsBatchRequestPostsItemCNAMERecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemCNAMERecordTagsList: S.Schema<RecordsBatchRequestPostsItemCNAMERecordTagsList>;
export interface RecordsBatchRequestPostsItemCNAMERecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemCNAMERecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid hostname. Must not match the record's name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPostsItemCNAMERecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemCNAMERecordTagsList;
}
export declare const RecordsBatchRequestPostsItemCNAMERecord: S.Schema<RecordsBatchRequestPostsItemCNAMERecord>;
export type RecordsBatchRequestPostsItemMXRecordType = "MX";
export declare const RecordsBatchRequestPostsItemMXRecordType: any;
export type RecordsBatchRequestPostsItemMXRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemMXRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemMXRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemMXRecordTagsList: S.Schema<RecordsBatchRequestPostsItemMXRecordTagsList>;
export interface RecordsBatchRequestPostsItemMXRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemMXRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid mail server hostname. */
    content?: string;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemMXRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemMXRecord: S.Schema<RecordsBatchRequestPostsItemMXRecord>;
export type RecordsBatchRequestPostsItemNSRecordType = "NS";
export declare const RecordsBatchRequestPostsItemNSRecordType: any;
export type RecordsBatchRequestPostsItemNSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemNSRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemNSRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemNSRecordTagsList: S.Schema<RecordsBatchRequestPostsItemNSRecordTagsList>;
export interface RecordsBatchRequestPostsItemNSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemNSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid name server host name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemNSRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemNSRecord: S.Schema<RecordsBatchRequestPostsItemNSRecord>;
export type RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordType: any;
export type RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordTagsList: S.Schema<RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordTagsList>;
export interface RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecord: S.Schema<RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecord>;
export type RecordsBatchRequestPostsItemPTRRecordType = "PTR";
export declare const RecordsBatchRequestPostsItemPTRRecordType: any;
export type RecordsBatchRequestPostsItemPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemPTRRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemPTRRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemPTRRecordTagsList: S.Schema<RecordsBatchRequestPostsItemPTRRecordTagsList>;
export interface RecordsBatchRequestPostsItemPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Domain name pointing to the address. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemPTRRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemPTRRecord: S.Schema<RecordsBatchRequestPostsItemPTRRecord>;
export type RecordsBatchRequestPostsItemTXTRecordType = "TXT";
export declare const RecordsBatchRequestPostsItemTXTRecordType: any;
export type RecordsBatchRequestPostsItemTXTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemTXTRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemTXTRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemTXTRecordTagsList: S.Schema<RecordsBatchRequestPostsItemTXTRecordTagsList>;
export interface RecordsBatchRequestPostsItemTXTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemTXTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Text content for the record. The content must consist of quoted "character strings" (RFC 1035), each with a length of up to 255 bytes. Strings exceeding this allowed maximum length are automatically split. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemTXTRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemTXTRecord: S.Schema<RecordsBatchRequestPostsItemTXTRecord>;
export type RecordsBatchRequestPostsItemCAARecordType = "CAA";
export declare const RecordsBatchRequestPostsItemCAARecordType: any;
export interface RecordsBatchRequestPostsItemCAARecordData {
    /** Flags for the CAA record. */
    flags?: number;
    /** Name of the property controlled by this record (e.g.: issue, issuewild, iodef). */
    tag?: string;
    /** Value of the record. This field's semantics depend on the chosen tag. */
    value?: string;
}
export declare const RecordsBatchRequestPostsItemCAARecordData: S.Schema<RecordsBatchRequestPostsItemCAARecordData>;
export type RecordsBatchRequestPostsItemCAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemCAARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemCAARecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemCAARecordTagsList: S.Schema<RecordsBatchRequestPostsItemCAARecordTagsList>;
export interface RecordsBatchRequestPostsItemCAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemCAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CAA content. See 'data' to set CAA properties. */
    content?: string;
    /** Components of a CAA record. */
    data?: RecordsBatchRequestPostsItemCAARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemCAARecordTagsList;
}
export declare const RecordsBatchRequestPostsItemCAARecord: S.Schema<RecordsBatchRequestPostsItemCAARecord>;
export type RecordsBatchRequestPostsItemCERTRecordType = "CERT";
export declare const RecordsBatchRequestPostsItemCERTRecordType: any;
export interface RecordsBatchRequestPostsItemCERTRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Certificate. */
    certificate?: string;
    /** Key Tag. */
    keyTag?: number;
    /** Type. */
    type?: number;
}
export declare const RecordsBatchRequestPostsItemCERTRecordData: S.Schema<RecordsBatchRequestPostsItemCERTRecordData>;
export type RecordsBatchRequestPostsItemCERTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemCERTRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemCERTRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemCERTRecordTagsList: S.Schema<RecordsBatchRequestPostsItemCERTRecordTagsList>;
export interface RecordsBatchRequestPostsItemCERTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemCERTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CERT content. See 'data' to set CERT properties. */
    content?: string;
    /** Components of a CERT record. */
    data?: RecordsBatchRequestPostsItemCERTRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemCERTRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemCERTRecord: S.Schema<RecordsBatchRequestPostsItemCERTRecord>;
export type RecordsBatchRequestPostsItemDNSKEYRecordType = "DNSKEY";
export declare const RecordsBatchRequestPostsItemDNSKEYRecordType: any;
export interface RecordsBatchRequestPostsItemDNSKEYRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Flags. */
    flags?: number;
    /** Protocol. */
    protocol?: number;
    /** Public Key. */
    publicKey?: string;
}
export declare const RecordsBatchRequestPostsItemDNSKEYRecordData: S.Schema<RecordsBatchRequestPostsItemDNSKEYRecordData>;
export type RecordsBatchRequestPostsItemDNSKEYRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemDNSKEYRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemDNSKEYRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemDNSKEYRecordTagsList: S.Schema<RecordsBatchRequestPostsItemDNSKEYRecordTagsList>;
export interface RecordsBatchRequestPostsItemDNSKEYRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemDNSKEYRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DNSKEY content. See 'data' to set DNSKEY properties. */
    content?: string;
    /** Components of a DNSKEY record. */
    data?: RecordsBatchRequestPostsItemDNSKEYRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemDNSKEYRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemDNSKEYRecord: S.Schema<RecordsBatchRequestPostsItemDNSKEYRecord>;
export type RecordsBatchRequestPostsItemDSRecordType = "DS";
export declare const RecordsBatchRequestPostsItemDSRecordType: any;
export interface RecordsBatchRequestPostsItemDSRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Digest. */
    digest?: string;
    /** Digest Type. */
    digestType?: number;
    /** Key Tag. */
    keyTag?: number;
}
export declare const RecordsBatchRequestPostsItemDSRecordData: S.Schema<RecordsBatchRequestPostsItemDSRecordData>;
export type RecordsBatchRequestPostsItemDSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemDSRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemDSRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemDSRecordTagsList: S.Schema<RecordsBatchRequestPostsItemDSRecordTagsList>;
export interface RecordsBatchRequestPostsItemDSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemDSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DS content. See 'data' to set DS properties. */
    content?: string;
    /** Components of a DS record. */
    data?: RecordsBatchRequestPostsItemDSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemDSRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemDSRecord: S.Schema<RecordsBatchRequestPostsItemDSRecord>;
export type RecordsBatchRequestPostsItemHTTPSRecordType = "HTTPS";
export declare const RecordsBatchRequestPostsItemHTTPSRecordType: any;
export interface RecordsBatchRequestPostsItemHTTPSRecordData {
    /** Priority. */
    priority?: number;
    /** Target. */
    target?: string;
    /** Value. */
    value?: string;
}
export declare const RecordsBatchRequestPostsItemHTTPSRecordData: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordData>;
export type RecordsBatchRequestPostsItemHTTPSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemHTTPSRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemHTTPSRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemHTTPSRecordTagsList: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordTagsList>;
export interface RecordsBatchRequestPostsItemHTTPSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemHTTPSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted HTTPS content. See 'data' to set HTTPS properties. */
    content?: string;
    /** Components of a HTTPS record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemHTTPSRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemHTTPSRecord: S.Schema<RecordsBatchRequestPostsItemHTTPSRecord>;
export type RecordsBatchRequestPostsItemLOCRecordType = "LOC";
export declare const RecordsBatchRequestPostsItemLOCRecordType: any;
export type RecordsBatchRequestPostsItemLOCRecordDataLatDirection = "N" | "S";
export declare const RecordsBatchRequestPostsItemLOCRecordDataLatDirection: any;
export type RecordsBatchRequestPostsItemLOCRecordDataLongDirection = "E" | "W";
export declare const RecordsBatchRequestPostsItemLOCRecordDataLongDirection: any;
export interface RecordsBatchRequestPostsItemLOCRecordData {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsBatchRequestPostsItemLOCRecordDataLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsBatchRequestPostsItemLOCRecordDataLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export declare const RecordsBatchRequestPostsItemLOCRecordData: S.Schema<RecordsBatchRequestPostsItemLOCRecordData>;
export type RecordsBatchRequestPostsItemLOCRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemLOCRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemLOCRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemLOCRecordTagsList: S.Schema<RecordsBatchRequestPostsItemLOCRecordTagsList>;
export interface RecordsBatchRequestPostsItemLOCRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemLOCRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted LOC content. See 'data' to set LOC properties. */
    content?: string;
    /** Components of a LOC record. */
    data?: RecordsBatchRequestPostsItemLOCRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemLOCRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemLOCRecord: S.Schema<RecordsBatchRequestPostsItemLOCRecord>;
export type RecordsBatchRequestPostsItemNAPTRRecordType = "NAPTR";
export declare const RecordsBatchRequestPostsItemNAPTRRecordType: any;
export interface RecordsBatchRequestPostsItemNAPTRRecordData {
    /** Flags. */
    flags?: string;
    /** Order. */
    order?: number;
    /** Preference. */
    preference?: number;
    /** Regex. */
    regex?: string;
    /** Replacement. */
    replacement?: string;
    /** Service. */
    service?: string;
}
export declare const RecordsBatchRequestPostsItemNAPTRRecordData: S.Schema<RecordsBatchRequestPostsItemNAPTRRecordData>;
export type RecordsBatchRequestPostsItemNAPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemNAPTRRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemNAPTRRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemNAPTRRecordTagsList: S.Schema<RecordsBatchRequestPostsItemNAPTRRecordTagsList>;
export interface RecordsBatchRequestPostsItemNAPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemNAPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted NAPTR content. See 'data' to set NAPTR properties. */
    content?: string;
    /** Components of a NAPTR record. */
    data?: RecordsBatchRequestPostsItemNAPTRRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemNAPTRRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemNAPTRRecord: S.Schema<RecordsBatchRequestPostsItemNAPTRRecord>;
export type RecordsBatchRequestPostsItemSMIMEARecordType = "SMIMEA";
export declare const RecordsBatchRequestPostsItemSMIMEARecordType: any;
export interface RecordsBatchRequestPostsItemSMIMEARecordData {
    /** Certificate. */
    certificate?: string;
    /** Matching Type. */
    matchingType?: number;
    /** Selector. */
    selector?: number;
    /** Usage. */
    usage?: number;
}
export declare const RecordsBatchRequestPostsItemSMIMEARecordData: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordData>;
export type RecordsBatchRequestPostsItemSMIMEARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemSMIMEARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemSMIMEARecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemSMIMEARecordTagsList: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordTagsList>;
export interface RecordsBatchRequestPostsItemSMIMEARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSMIMEARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SMIMEA content. See 'data' to set SMIMEA properties. */
    content?: string;
    /** Components of a SMIMEA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSMIMEARecordTagsList;
}
export declare const RecordsBatchRequestPostsItemSMIMEARecord: S.Schema<RecordsBatchRequestPostsItemSMIMEARecord>;
export type RecordsBatchRequestPostsItemSRVRecordType = "SRV";
export declare const RecordsBatchRequestPostsItemSRVRecordType: any;
export interface RecordsBatchRequestPostsItemSRVRecordData {
    /** The port of the service. */
    port?: number;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** A valid hostname. */
    target?: string;
    /** The record weight. */
    weight?: number;
}
export declare const RecordsBatchRequestPostsItemSRVRecordData: S.Schema<RecordsBatchRequestPostsItemSRVRecordData>;
export type RecordsBatchRequestPostsItemSRVRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemSRVRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemSRVRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemSRVRecordTagsList: S.Schema<RecordsBatchRequestPostsItemSRVRecordTagsList>;
export interface RecordsBatchRequestPostsItemSRVRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSRVRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Priority, weight, port, and SRV target. See 'data' for setting the individual component values. */
    content?: string;
    /** Components of a SRV record. */
    data?: RecordsBatchRequestPostsItemSRVRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSRVRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemSRVRecord: S.Schema<RecordsBatchRequestPostsItemSRVRecord>;
export type RecordsBatchRequestPostsItemSSHFPRecordType = "SSHFP";
export declare const RecordsBatchRequestPostsItemSSHFPRecordType: any;
export interface RecordsBatchRequestPostsItemSSHFPRecordData {
    /** Algorithm. */
    algorithm?: number;
    /** Fingerprint. */
    fingerprint?: string;
    /** Type. */
    type?: number;
}
export declare const RecordsBatchRequestPostsItemSSHFPRecordData: S.Schema<RecordsBatchRequestPostsItemSSHFPRecordData>;
export type RecordsBatchRequestPostsItemSSHFPRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemSSHFPRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemSSHFPRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemSSHFPRecordTagsList: S.Schema<RecordsBatchRequestPostsItemSSHFPRecordTagsList>;
export interface RecordsBatchRequestPostsItemSSHFPRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSSHFPRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SSHFP content. See 'data' to set SSHFP properties. */
    content?: string;
    /** Components of a SSHFP record. */
    data?: RecordsBatchRequestPostsItemSSHFPRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSSHFPRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemSSHFPRecord: S.Schema<RecordsBatchRequestPostsItemSSHFPRecord>;
export type RecordsBatchRequestPostsItemSVCBRecordType = "SVCB";
export declare const RecordsBatchRequestPostsItemSVCBRecordType: any;
export type RecordsBatchRequestPostsItemSVCBRecordData = RecordsBatchRequestPostsItemHTTPSRecordData;
export declare const RecordsBatchRequestPostsItemSVCBRecordData: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordData>;
export type RecordsBatchRequestPostsItemSVCBRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemSVCBRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemSVCBRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemSVCBRecordTagsList: S.Schema<RecordsBatchRequestPostsItemSVCBRecordTagsList>;
export interface RecordsBatchRequestPostsItemSVCBRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemSVCBRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SVCB content. See 'data' to set SVCB properties. */
    content?: string;
    /** Components of a SVCB record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemSVCBRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemSVCBRecord: S.Schema<RecordsBatchRequestPostsItemSVCBRecord>;
export type RecordsBatchRequestPostsItemTLSARecordType = "TLSA";
export declare const RecordsBatchRequestPostsItemTLSARecordType: any;
export type RecordsBatchRequestPostsItemTLSARecordData = RecordsBatchRequestPostsItemSMIMEARecordData;
export declare const RecordsBatchRequestPostsItemTLSARecordData: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordData>;
export type RecordsBatchRequestPostsItemTLSARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemTLSARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemTLSARecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemTLSARecordTagsList: S.Schema<RecordsBatchRequestPostsItemTLSARecordTagsList>;
export interface RecordsBatchRequestPostsItemTLSARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemTLSARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted TLSA content. See 'data' to set TLSA properties. */
    content?: string;
    /** Components of a TLSA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemTLSARecordTagsList;
}
export declare const RecordsBatchRequestPostsItemTLSARecord: S.Schema<RecordsBatchRequestPostsItemTLSARecord>;
export type RecordsBatchRequestPostsItemURIRecordType = "URI";
export declare const RecordsBatchRequestPostsItemURIRecordType: any;
export interface RecordsBatchRequestPostsItemURIRecordData {
    /** The record content. */
    target?: string;
    /** The record weight. */
    weight?: number;
}
export declare const RecordsBatchRequestPostsItemURIRecordData: S.Schema<RecordsBatchRequestPostsItemURIRecordData>;
export type RecordsBatchRequestPostsItemURIRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPostsItemURIRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPostsItemURIRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPostsItemURIRecordTagsList: S.Schema<RecordsBatchRequestPostsItemURIRecordTagsList>;
export interface RecordsBatchRequestPostsItemURIRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPostsItemURIRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted URI content. See 'data' to set URI properties. */
    content?: string;
    /** Components of a URI record. */
    data?: RecordsBatchRequestPostsItemURIRecordData;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPostsItemURIRecordTagsList;
}
export declare const RecordsBatchRequestPostsItemURIRecord: S.Schema<RecordsBatchRequestPostsItemURIRecord>;
export type RecordsBatchRequestPostsItem = RecordsBatchRequestPostsItemARecord | RecordsBatchRequestPostsItemAAAARecord | RecordsBatchRequestPostsItemCNAMERecord | RecordsBatchRequestPostsItemMXRecord | RecordsBatchRequestPostsItemNSRecord | RecordsBatchRequestPostsItemDNSRecordsOpenpgpkeyRecord | RecordsBatchRequestPostsItemPTRRecord | RecordsBatchRequestPostsItemTXTRecord | RecordsBatchRequestPostsItemCAARecord | RecordsBatchRequestPostsItemCERTRecord | RecordsBatchRequestPostsItemDNSKEYRecord | RecordsBatchRequestPostsItemDSRecord | RecordsBatchRequestPostsItemHTTPSRecord | RecordsBatchRequestPostsItemLOCRecord | RecordsBatchRequestPostsItemNAPTRRecord | RecordsBatchRequestPostsItemSMIMEARecord | RecordsBatchRequestPostsItemSRVRecord | RecordsBatchRequestPostsItemSSHFPRecord | RecordsBatchRequestPostsItemSVCBRecord | RecordsBatchRequestPostsItemTLSARecord | RecordsBatchRequestPostsItemURIRecord;
export declare const RecordsBatchRequestPostsItem: any;
export type RecordsBatchRequestPostsList = Array<RecordsBatchRequestPostsItem>;
export declare const RecordsBatchRequestPostsList: S.Schema<RecordsBatchRequestPostsList>;
export type RecordsBatchRequestPutsItemARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemAAAARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemAAAARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemCNAMERecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemCNAMERecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemMXRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemMXRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemNSRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemNSRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsBatchRequestPutsItemOpenpgpkeyRecordType: any;
export type RecordsBatchRequestPutsItemOpenpgpkeyRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsBatchRequestPutsItemOpenpgpkeyRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchRequestPutsItemOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsBatchRequestPutsItemOpenpgpkeyRecordTagsList: S.Schema<RecordsBatchRequestPutsItemOpenpgpkeyRecordTagsList>;
export interface RecordsBatchRequestPutsItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchRequestPutsItemOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsBatchRequestPutsItemOpenpgpkeyRecordTagsList;
}
export declare const RecordsBatchRequestPutsItemOpenpgpkeyRecord: S.Schema<RecordsBatchRequestPutsItemOpenpgpkeyRecord>;
export type RecordsBatchRequestPutsItemPTRRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemPTRRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemTXTRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemTXTRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemCAARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemCAARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemCERTRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemCERTRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemDNSKEYRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemDNSKEYRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemDSRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemDSRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemHTTPSRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemHTTPSRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemLOCRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemLOCRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemNAPTRRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemNAPTRRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemSMIMEARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemSMIMEARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemSRVRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemSRVRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemSSHFPRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemSSHFPRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemSVCBRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemSVCBRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemTLSARecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemTLSARecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItemURIRecord = RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItemURIRecord: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsBatchRequestPutsItem = RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestPutsItemOpenpgpkeyRecord | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem | RecordsBatchRequestDeletesItem;
export declare const RecordsBatchRequestPutsItem: any;
export type RecordsBatchRequestPutsList = Array<RecordsBatchRequestPutsItem>;
export declare const RecordsBatchRequestPutsList: S.Schema<RecordsBatchRequestPutsList>;
export interface BatchRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    deletes?: RecordsBatchRequestDeletesList;
    patches?: RecordsBatchRequestPatchesList;
    posts?: RecordsBatchRequestPostsList;
    puts?: RecordsBatchRequestPutsList;
}
export declare const BatchRecordRequest: S.Schema<BatchRecordRequest>;
export type RecordsBatchResponseDeletesItemARecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemARecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemARecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemARecordMeta: S.Schema<RecordsBatchResponseDeletesItemARecordMeta>;
export interface RecordsBatchResponseDeletesItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemARecord: S.Schema<RecordsBatchResponseDeletesItemARecord>;
export type RecordsBatchResponseDeletesItemAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemAAAARecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemAAAARecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemAAAARecordMeta: S.Schema<RecordsBatchResponseDeletesItemAAAARecordMeta>;
export interface RecordsBatchResponseDeletesItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemAAAARecord: S.Schema<RecordsBatchResponseDeletesItemAAAARecord>;
export type RecordsBatchResponseDeletesItemCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemCNAMERecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemCNAMERecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemCNAMERecordMeta: S.Schema<RecordsBatchResponseDeletesItemCNAMERecordMeta>;
export interface RecordsBatchResponseDeletesItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemCNAMERecord: S.Schema<RecordsBatchResponseDeletesItemCNAMERecord>;
export type RecordsBatchResponseDeletesItemMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemMXRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemMXRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemMXRecordMeta: S.Schema<RecordsBatchResponseDeletesItemMXRecordMeta>;
export interface RecordsBatchResponseDeletesItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemMXRecord: S.Schema<RecordsBatchResponseDeletesItemMXRecord>;
export type RecordsBatchResponseDeletesItemNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemNSRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemNSRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemNSRecordMeta: S.Schema<RecordsBatchResponseDeletesItemNSRecordMeta>;
export interface RecordsBatchResponseDeletesItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemNSRecord: S.Schema<RecordsBatchResponseDeletesItemNSRecord>;
export type RecordsBatchResponseDeletesItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemOpenpgpkeyRecordMeta: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordMeta>;
export interface RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings {
    /** When enabled, only A records will be generated, and AAAA records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv4Only?: boolean | null;
    /** When enabled, only AAAA records will be generated, and A records will not be created. This setting is intended for exceptional cases. Note that this option only applies to proxied records and it has no effect on whether Cloudflare communicates with the origin using IPv4 or IPv6. */
    ipv6Only?: boolean | null;
}
export declare const RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsBatchResponseDeletesItemOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsBatchResponseDeletesItemOpenpgpkeyRecordTagsList: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordTagsList>;
export type RecordsBatchResponseDeletesItemOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsBatchResponseDeletesItemOpenpgpkeyRecordType: any;
export interface RecordsBatchResponseDeletesItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsBatchResponseDeletesItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsBatchResponseDeletesItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemOpenpgpkeyRecord: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecord>;
export type RecordsBatchResponseDeletesItemPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemPTRRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemPTRRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemPTRRecordMeta: S.Schema<RecordsBatchResponseDeletesItemPTRRecordMeta>;
export interface RecordsBatchResponseDeletesItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemPTRRecord: S.Schema<RecordsBatchResponseDeletesItemPTRRecord>;
export type RecordsBatchResponseDeletesItemTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemTXTRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemTXTRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemTXTRecordMeta: S.Schema<RecordsBatchResponseDeletesItemTXTRecordMeta>;
export interface RecordsBatchResponseDeletesItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemTXTRecord: S.Schema<RecordsBatchResponseDeletesItemTXTRecord>;
export type RecordsBatchResponseDeletesItemCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemCAARecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemCAARecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemCAARecordMeta: S.Schema<RecordsBatchResponseDeletesItemCAARecordMeta>;
export interface RecordsBatchResponseDeletesItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemCAARecord: S.Schema<RecordsBatchResponseDeletesItemCAARecord>;
export type RecordsBatchResponseDeletesItemCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemCERTRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemCERTRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemCERTRecordMeta: S.Schema<RecordsBatchResponseDeletesItemCERTRecordMeta>;
export interface RecordsBatchResponseDeletesItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemCERTRecord: S.Schema<RecordsBatchResponseDeletesItemCERTRecord>;
export type RecordsBatchResponseDeletesItemDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemDNSKEYRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemDNSKEYRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemDNSKEYRecordMeta: S.Schema<RecordsBatchResponseDeletesItemDNSKEYRecordMeta>;
export interface RecordsBatchResponseDeletesItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemDNSKEYRecord: S.Schema<RecordsBatchResponseDeletesItemDNSKEYRecord>;
export type RecordsBatchResponseDeletesItemDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemDSRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemDSRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemDSRecordMeta: S.Schema<RecordsBatchResponseDeletesItemDSRecordMeta>;
export interface RecordsBatchResponseDeletesItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemDSRecord: S.Schema<RecordsBatchResponseDeletesItemDSRecord>;
export type RecordsBatchResponseDeletesItemHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemHTTPSRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemHTTPSRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemHTTPSRecordMeta: S.Schema<RecordsBatchResponseDeletesItemHTTPSRecordMeta>;
export interface RecordsBatchResponseDeletesItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemHTTPSRecord: S.Schema<RecordsBatchResponseDeletesItemHTTPSRecord>;
export type RecordsBatchResponseDeletesItemLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemLOCRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemLOCRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemLOCRecordMeta: S.Schema<RecordsBatchResponseDeletesItemLOCRecordMeta>;
export interface RecordsBatchResponseDeletesItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemLOCRecord: S.Schema<RecordsBatchResponseDeletesItemLOCRecord>;
export type RecordsBatchResponseDeletesItemNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemNAPTRRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemNAPTRRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemNAPTRRecordMeta: S.Schema<RecordsBatchResponseDeletesItemNAPTRRecordMeta>;
export interface RecordsBatchResponseDeletesItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemNAPTRRecord: S.Schema<RecordsBatchResponseDeletesItemNAPTRRecord>;
export type RecordsBatchResponseDeletesItemSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemSMIMEARecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemSMIMEARecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemSMIMEARecordMeta: S.Schema<RecordsBatchResponseDeletesItemSMIMEARecordMeta>;
export interface RecordsBatchResponseDeletesItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemSMIMEARecord: S.Schema<RecordsBatchResponseDeletesItemSMIMEARecord>;
export type RecordsBatchResponseDeletesItemSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemSRVRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemSRVRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemSRVRecordMeta: S.Schema<RecordsBatchResponseDeletesItemSRVRecordMeta>;
export interface RecordsBatchResponseDeletesItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemSRVRecord: S.Schema<RecordsBatchResponseDeletesItemSRVRecord>;
export type RecordsBatchResponseDeletesItemSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemSSHFPRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemSSHFPRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemSSHFPRecordMeta: S.Schema<RecordsBatchResponseDeletesItemSSHFPRecordMeta>;
export interface RecordsBatchResponseDeletesItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemSSHFPRecord: S.Schema<RecordsBatchResponseDeletesItemSSHFPRecord>;
export type RecordsBatchResponseDeletesItemSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemSVCBRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemSVCBRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemSVCBRecordMeta: S.Schema<RecordsBatchResponseDeletesItemSVCBRecordMeta>;
export interface RecordsBatchResponseDeletesItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemSVCBRecord: S.Schema<RecordsBatchResponseDeletesItemSVCBRecord>;
export type RecordsBatchResponseDeletesItemTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemTLSARecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemTLSARecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemTLSARecordMeta: S.Schema<RecordsBatchResponseDeletesItemTLSARecordMeta>;
export interface RecordsBatchResponseDeletesItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemTLSARecord: S.Schema<RecordsBatchResponseDeletesItemTLSARecord>;
export type RecordsBatchResponseDeletesItemURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsBatchResponseDeletesItemURIRecordMetaShadowedByList: S.Schema<RecordsBatchResponseDeletesItemURIRecordMetaShadowedByList>;
export interface RecordsBatchResponseDeletesItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsBatchResponseDeletesItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsBatchResponseDeletesItemURIRecordMeta: S.Schema<RecordsBatchResponseDeletesItemURIRecordMeta>;
export interface RecordsBatchResponseDeletesItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsBatchResponseDeletesItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsBatchResponseDeletesItemURIRecord: S.Schema<RecordsBatchResponseDeletesItemURIRecord>;
export type RecordsBatchResponseDeletesItem = RecordsBatchResponseDeletesItemARecord | RecordsBatchResponseDeletesItemAAAARecord | RecordsBatchResponseDeletesItemCNAMERecord | RecordsBatchResponseDeletesItemMXRecord | RecordsBatchResponseDeletesItemNSRecord | RecordsBatchResponseDeletesItemOpenpgpkeyRecord | RecordsBatchResponseDeletesItemPTRRecord | RecordsBatchResponseDeletesItemTXTRecord | RecordsBatchResponseDeletesItemCAARecord | RecordsBatchResponseDeletesItemCERTRecord | RecordsBatchResponseDeletesItemDNSKEYRecord | RecordsBatchResponseDeletesItemDSRecord | RecordsBatchResponseDeletesItemHTTPSRecord | RecordsBatchResponseDeletesItemLOCRecord | RecordsBatchResponseDeletesItemNAPTRRecord | RecordsBatchResponseDeletesItemSMIMEARecord | RecordsBatchResponseDeletesItemSRVRecord | RecordsBatchResponseDeletesItemSSHFPRecord | RecordsBatchResponseDeletesItemSVCBRecord | RecordsBatchResponseDeletesItemTLSARecord | RecordsBatchResponseDeletesItemURIRecord;
export declare const RecordsBatchResponseDeletesItem: any;
export type RecordsBatchResponseDeletesList = Array<RecordsBatchResponseDeletesItem>;
export declare const RecordsBatchResponseDeletesList: S.Schema<RecordsBatchResponseDeletesList>;
export interface RecordsBatchResponsePatchesItemOpenpgpkeyRecord {
    id?: unknown | null;
    comment?: unknown | null;
    content?: unknown | null;
}
export declare const RecordsBatchResponsePatchesItemOpenpgpkeyRecord: S.Schema<RecordsBatchResponsePatchesItemOpenpgpkeyRecord>;
export type RecordsBatchResponsePatchesItem = RecordsBatchResponseDeletesItemARecord | RecordsBatchResponseDeletesItemAAAARecord | RecordsBatchResponseDeletesItemCNAMERecord | RecordsBatchResponseDeletesItemMXRecord | RecordsBatchResponseDeletesItemNSRecord | RecordsBatchResponsePatchesItemOpenpgpkeyRecord | RecordsBatchResponseDeletesItemPTRRecord | RecordsBatchResponseDeletesItemTXTRecord | RecordsBatchResponseDeletesItemCAARecord | RecordsBatchResponseDeletesItemCERTRecord | RecordsBatchResponseDeletesItemDNSKEYRecord | RecordsBatchResponseDeletesItemDSRecord | RecordsBatchResponseDeletesItemHTTPSRecord | RecordsBatchResponseDeletesItemLOCRecord | RecordsBatchResponseDeletesItemNAPTRRecord | RecordsBatchResponseDeletesItemSMIMEARecord | RecordsBatchResponseDeletesItemSRVRecord | RecordsBatchResponseDeletesItemSSHFPRecord | RecordsBatchResponseDeletesItemSVCBRecord | RecordsBatchResponseDeletesItemTLSARecord | RecordsBatchResponseDeletesItemURIRecord;
export declare const RecordsBatchResponsePatchesItem: any;
export type RecordsBatchResponsePatchesList = Array<RecordsBatchResponsePatchesItem>;
export declare const RecordsBatchResponsePatchesList: S.Schema<RecordsBatchResponsePatchesList>;
export type RecordsBatchResponsePostsItemOpenpgpkeyRecord = RecordsBatchResponsePatchesItemOpenpgpkeyRecord;
export declare const RecordsBatchResponsePostsItemOpenpgpkeyRecord: S.Schema<RecordsBatchResponsePatchesItemOpenpgpkeyRecord>;
export type RecordsBatchResponsePostsItem = RecordsBatchResponseDeletesItemARecord | RecordsBatchResponseDeletesItemAAAARecord | RecordsBatchResponseDeletesItemCNAMERecord | RecordsBatchResponseDeletesItemMXRecord | RecordsBatchResponseDeletesItemNSRecord | RecordsBatchResponsePatchesItemOpenpgpkeyRecord | RecordsBatchResponseDeletesItemPTRRecord | RecordsBatchResponseDeletesItemTXTRecord | RecordsBatchResponseDeletesItemCAARecord | RecordsBatchResponseDeletesItemCERTRecord | RecordsBatchResponseDeletesItemDNSKEYRecord | RecordsBatchResponseDeletesItemDSRecord | RecordsBatchResponseDeletesItemHTTPSRecord | RecordsBatchResponseDeletesItemLOCRecord | RecordsBatchResponseDeletesItemNAPTRRecord | RecordsBatchResponseDeletesItemSMIMEARecord | RecordsBatchResponseDeletesItemSRVRecord | RecordsBatchResponseDeletesItemSSHFPRecord | RecordsBatchResponseDeletesItemSVCBRecord | RecordsBatchResponseDeletesItemTLSARecord | RecordsBatchResponseDeletesItemURIRecord;
export declare const RecordsBatchResponsePostsItem: any;
export type RecordsBatchResponsePostsList = Array<RecordsBatchResponsePostsItem>;
export declare const RecordsBatchResponsePostsList: S.Schema<RecordsBatchResponsePostsList>;
export type RecordsBatchResponsePutsItemOpenpgpkeyRecord = RecordsBatchResponsePatchesItemOpenpgpkeyRecord;
export declare const RecordsBatchResponsePutsItemOpenpgpkeyRecord: S.Schema<RecordsBatchResponsePatchesItemOpenpgpkeyRecord>;
export type RecordsBatchResponsePutsItem = RecordsBatchResponseDeletesItemARecord | RecordsBatchResponseDeletesItemAAAARecord | RecordsBatchResponseDeletesItemCNAMERecord | RecordsBatchResponseDeletesItemMXRecord | RecordsBatchResponseDeletesItemNSRecord | RecordsBatchResponsePatchesItemOpenpgpkeyRecord | RecordsBatchResponseDeletesItemPTRRecord | RecordsBatchResponseDeletesItemTXTRecord | RecordsBatchResponseDeletesItemCAARecord | RecordsBatchResponseDeletesItemCERTRecord | RecordsBatchResponseDeletesItemDNSKEYRecord | RecordsBatchResponseDeletesItemDSRecord | RecordsBatchResponseDeletesItemHTTPSRecord | RecordsBatchResponseDeletesItemLOCRecord | RecordsBatchResponseDeletesItemNAPTRRecord | RecordsBatchResponseDeletesItemSMIMEARecord | RecordsBatchResponseDeletesItemSRVRecord | RecordsBatchResponseDeletesItemSSHFPRecord | RecordsBatchResponseDeletesItemSVCBRecord | RecordsBatchResponseDeletesItemTLSARecord | RecordsBatchResponseDeletesItemURIRecord;
export declare const RecordsBatchResponsePutsItem: any;
export type RecordsBatchResponsePutsList = Array<RecordsBatchResponsePutsItem>;
export declare const RecordsBatchResponsePutsList: S.Schema<RecordsBatchResponsePutsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BatchRecordResponse {
    deletes?: RecordsBatchResponseDeletesList | null;
    patches?: RecordsBatchResponsePatchesList | null;
    posts?: RecordsBatchResponsePostsList | null;
    puts?: RecordsBatchResponsePutsList | null;
}
export declare const BatchRecordResponse: S.Schema<BatchRecordResponse>;
export type RecordsCreateRequestType = "A" | "AAAA" | "CNAME" | "MX" | "NS" | "OPENPGPKEY" | "PTR" | "TXT" | "CAA" | "CERT" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "NAPTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export declare const RecordsCreateRequestType: any;
export type RecordsCreateRequestSettingsARecord = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsCreateRequestSettingsARecord: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsCreateRequestSettingsCNAMERecord = RecordsBatchRequestPostsItemCNAMERecordSettings;
export declare const RecordsCreateRequestSettingsCNAMERecord: S.Schema<RecordsBatchRequestPostsItemCNAMERecordSettings>;
export type RecordsCreateRequestSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings | RecordsBatchRequestPostsItemCNAMERecordSettings;
export declare const RecordsCreateRequestSettings: any;
export type RecordsCreateRequestTagsList = Array<unknown>;
export declare const RecordsCreateRequestTagsList: S.Schema<RecordsCreateRequestTagsList>;
export type RecordsCreateRequestDataCAARecord = RecordsBatchRequestPostsItemCAARecordData;
export declare const RecordsCreateRequestDataCAARecord: S.Schema<RecordsBatchRequestPostsItemCAARecordData>;
export type RecordsCreateRequestDataCERTRecord = RecordsBatchRequestPostsItemCERTRecordData;
export declare const RecordsCreateRequestDataCERTRecord: S.Schema<RecordsBatchRequestPostsItemCERTRecordData>;
export type RecordsCreateRequestDataDNSKEYRecord = RecordsBatchRequestPostsItemDNSKEYRecordData;
export declare const RecordsCreateRequestDataDNSKEYRecord: S.Schema<RecordsBatchRequestPostsItemDNSKEYRecordData>;
export type RecordsCreateRequestDataDSRecord = RecordsBatchRequestPostsItemDSRecordData;
export declare const RecordsCreateRequestDataDSRecord: S.Schema<RecordsBatchRequestPostsItemDSRecordData>;
export type RecordsCreateRequestDataHTTPSRecord = RecordsBatchRequestPostsItemHTTPSRecordData;
export declare const RecordsCreateRequestDataHTTPSRecord: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordData>;
export type RecordsCreateRequestDataLOCRecordLatDirection = "N" | "S";
export declare const RecordsCreateRequestDataLOCRecordLatDirection: any;
export type RecordsCreateRequestDataLOCRecordLongDirection = "E" | "W";
export declare const RecordsCreateRequestDataLOCRecordLongDirection: any;
export interface RecordsCreateRequestDataLOCRecord {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsCreateRequestDataLOCRecordLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsCreateRequestDataLOCRecordLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export declare const RecordsCreateRequestDataLOCRecord: S.Schema<RecordsCreateRequestDataLOCRecord>;
export type RecordsCreateRequestDataNAPTRRecord = RecordsBatchRequestPostsItemNAPTRRecordData;
export declare const RecordsCreateRequestDataNAPTRRecord: S.Schema<RecordsBatchRequestPostsItemNAPTRRecordData>;
export type RecordsCreateRequestDataSMIMEARecord = RecordsBatchRequestPostsItemSMIMEARecordData;
export declare const RecordsCreateRequestDataSMIMEARecord: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordData>;
export type RecordsCreateRequestDataSRVRecord = RecordsBatchRequestPostsItemSRVRecordData;
export declare const RecordsCreateRequestDataSRVRecord: S.Schema<RecordsBatchRequestPostsItemSRVRecordData>;
export type RecordsCreateRequestDataSSHFPRecord = RecordsBatchRequestPostsItemSSHFPRecordData;
export declare const RecordsCreateRequestDataSSHFPRecord: S.Schema<RecordsBatchRequestPostsItemSSHFPRecordData>;
export type RecordsCreateRequestDataURIRecord = RecordsBatchRequestPostsItemURIRecordData;
export declare const RecordsCreateRequestDataURIRecord: S.Schema<RecordsBatchRequestPostsItemURIRecordData>;
export type RecordsCreateRequestData = RecordsBatchRequestPostsItemCAARecordData | RecordsBatchRequestPostsItemCERTRecordData | RecordsBatchRequestPostsItemDNSKEYRecordData | RecordsBatchRequestPostsItemDSRecordData | RecordsBatchRequestPostsItemHTTPSRecordData | RecordsCreateRequestDataLOCRecord | RecordsBatchRequestPostsItemNAPTRRecordData | RecordsBatchRequestPostsItemSMIMEARecordData | RecordsBatchRequestPostsItemSRVRecordData | RecordsBatchRequestPostsItemSSHFPRecordData | RecordsBatchRequestPostsItemURIRecordData;
export declare const RecordsCreateRequestData: any;
export interface CreateRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsCreateRequestType | (string & {});
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsCreateRequestSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsCreateRequestTagsList;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Components of a CAA record. */
    data?: RecordsCreateRequestData;
}
export declare const CreateRecordRequest: S.Schema<CreateRecordRequest>;
export type RecordsCreateResultARecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultARecordMetaShadowedByList: S.Schema<RecordsCreateResultARecordMetaShadowedByList>;
export interface RecordsCreateResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultARecordMeta: S.Schema<RecordsCreateResultARecordMeta>;
export type DnsRecordTypeA = "A";
export declare const DnsRecordTypeA: any;
export type DnsRecordTagsList = Array<string>;
export declare const DnsRecordTagsList: S.Schema<DnsRecordTagsList>;
export interface RecordsCreateResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultARecord: S.Schema<RecordsCreateResultARecord>;
export type RecordsCreateResultAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultAAAARecordMetaShadowedByList: S.Schema<RecordsCreateResultAAAARecordMetaShadowedByList>;
export interface RecordsCreateResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultAAAARecordMeta: S.Schema<RecordsCreateResultAAAARecordMeta>;
export type DnsRecordTypeAAAA = "AAAA";
export declare const DnsRecordTypeAAAA: any;
export interface RecordsCreateResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultAAAARecord: S.Schema<RecordsCreateResultAAAARecord>;
export type RecordsCreateResultCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultCNAMERecordMetaShadowedByList: S.Schema<RecordsCreateResultCNAMERecordMetaShadowedByList>;
export interface RecordsCreateResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultCNAMERecordMeta: S.Schema<RecordsCreateResultCNAMERecordMeta>;
export type DnsRecordTypeCNAME = "CNAME";
export declare const DnsRecordTypeCNAME: any;
export interface RecordsCreateResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultCNAMERecord: S.Schema<RecordsCreateResultCNAMERecord>;
export type RecordsCreateResultMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultMXRecordMetaShadowedByList: S.Schema<RecordsCreateResultMXRecordMetaShadowedByList>;
export interface RecordsCreateResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultMXRecordMeta: S.Schema<RecordsCreateResultMXRecordMeta>;
export type DnsRecordTypeMX = "MX";
export declare const DnsRecordTypeMX: any;
export interface RecordsCreateResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultMXRecord: S.Schema<RecordsCreateResultMXRecord>;
export type RecordsCreateResultNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultNSRecordMetaShadowedByList: S.Schema<RecordsCreateResultNSRecordMetaShadowedByList>;
export interface RecordsCreateResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultNSRecordMeta: S.Schema<RecordsCreateResultNSRecordMeta>;
export type DnsRecordTypeNS = "NS";
export declare const DnsRecordTypeNS: any;
export interface RecordsCreateResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultNSRecord: S.Schema<RecordsCreateResultNSRecord>;
export type RecordsCreateResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsCreateResultOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsCreateResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultOpenpgpkeyRecordMeta: S.Schema<RecordsCreateResultOpenpgpkeyRecordMeta>;
export type RecordsCreateResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export declare const RecordsCreateResultOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsCreateResultOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsCreateResultOpenpgpkeyRecordTagsList: S.Schema<RecordsCreateResultOpenpgpkeyRecordTagsList>;
export type RecordsCreateResultOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsCreateResultOpenpgpkeyRecordType: any;
export interface RecordsCreateResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsCreateResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsCreateResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsCreateResultOpenpgpkeyRecord: S.Schema<RecordsCreateResultOpenpgpkeyRecord>;
export type RecordsCreateResultPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultPTRRecordMetaShadowedByList: S.Schema<RecordsCreateResultPTRRecordMetaShadowedByList>;
export interface RecordsCreateResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultPTRRecordMeta: S.Schema<RecordsCreateResultPTRRecordMeta>;
export type DnsRecordTypePTR = "PTR";
export declare const DnsRecordTypePTR: any;
export interface RecordsCreateResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultPTRRecord: S.Schema<RecordsCreateResultPTRRecord>;
export type RecordsCreateResultTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultTXTRecordMetaShadowedByList: S.Schema<RecordsCreateResultTXTRecordMetaShadowedByList>;
export interface RecordsCreateResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultTXTRecordMeta: S.Schema<RecordsCreateResultTXTRecordMeta>;
export type DnsRecordTypeTXT = "TXT";
export declare const DnsRecordTypeTXT: any;
export interface RecordsCreateResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultTXTRecord: S.Schema<RecordsCreateResultTXTRecord>;
export type RecordsCreateResultCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultCAARecordMetaShadowedByList: S.Schema<RecordsCreateResultCAARecordMetaShadowedByList>;
export interface RecordsCreateResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultCAARecordMeta: S.Schema<RecordsCreateResultCAARecordMeta>;
export type DnsRecordTypeCAA = "CAA";
export declare const DnsRecordTypeCAA: any;
export interface RecordsCreateResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultCAARecord: S.Schema<RecordsCreateResultCAARecord>;
export type RecordsCreateResultCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultCERTRecordMetaShadowedByList: S.Schema<RecordsCreateResultCERTRecordMetaShadowedByList>;
export interface RecordsCreateResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultCERTRecordMeta: S.Schema<RecordsCreateResultCERTRecordMeta>;
export type DnsRecordTypeCERT = "CERT";
export declare const DnsRecordTypeCERT: any;
export interface RecordsCreateResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultCERTRecord: S.Schema<RecordsCreateResultCERTRecord>;
export type RecordsCreateResultDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultDNSKEYRecordMetaShadowedByList: S.Schema<RecordsCreateResultDNSKEYRecordMetaShadowedByList>;
export interface RecordsCreateResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultDNSKEYRecordMeta: S.Schema<RecordsCreateResultDNSKEYRecordMeta>;
export type DnsRecordTypeDNSKEY = "DNSKEY";
export declare const DnsRecordTypeDNSKEY: any;
export interface RecordsCreateResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultDNSKEYRecord: S.Schema<RecordsCreateResultDNSKEYRecord>;
export type RecordsCreateResultDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultDSRecordMetaShadowedByList: S.Schema<RecordsCreateResultDSRecordMetaShadowedByList>;
export interface RecordsCreateResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultDSRecordMeta: S.Schema<RecordsCreateResultDSRecordMeta>;
export type DnsRecordTypeDS = "DS";
export declare const DnsRecordTypeDS: any;
export interface RecordsCreateResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultDSRecord: S.Schema<RecordsCreateResultDSRecord>;
export type RecordsCreateResultHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultHTTPSRecordMetaShadowedByList: S.Schema<RecordsCreateResultHTTPSRecordMetaShadowedByList>;
export interface RecordsCreateResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultHTTPSRecordMeta: S.Schema<RecordsCreateResultHTTPSRecordMeta>;
export type DnsRecordTypeHTTPS = "HTTPS";
export declare const DnsRecordTypeHTTPS: any;
export interface RecordsCreateResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultHTTPSRecord: S.Schema<RecordsCreateResultHTTPSRecord>;
export type RecordsCreateResultLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultLOCRecordMetaShadowedByList: S.Schema<RecordsCreateResultLOCRecordMetaShadowedByList>;
export interface RecordsCreateResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultLOCRecordMeta: S.Schema<RecordsCreateResultLOCRecordMeta>;
export type DnsRecordTypeLOC = "LOC";
export declare const DnsRecordTypeLOC: any;
export interface RecordsCreateResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultLOCRecord: S.Schema<RecordsCreateResultLOCRecord>;
export type RecordsCreateResultNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultNAPTRRecordMetaShadowedByList: S.Schema<RecordsCreateResultNAPTRRecordMetaShadowedByList>;
export interface RecordsCreateResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultNAPTRRecordMeta: S.Schema<RecordsCreateResultNAPTRRecordMeta>;
export type DnsRecordTypeNAPTR = "NAPTR";
export declare const DnsRecordTypeNAPTR: any;
export interface RecordsCreateResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultNAPTRRecord: S.Schema<RecordsCreateResultNAPTRRecord>;
export type RecordsCreateResultSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultSMIMEARecordMetaShadowedByList: S.Schema<RecordsCreateResultSMIMEARecordMetaShadowedByList>;
export interface RecordsCreateResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultSMIMEARecordMeta: S.Schema<RecordsCreateResultSMIMEARecordMeta>;
export type DnsRecordTypeSMIMEA = "SMIMEA";
export declare const DnsRecordTypeSMIMEA: any;
export interface RecordsCreateResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultSMIMEARecord: S.Schema<RecordsCreateResultSMIMEARecord>;
export type RecordsCreateResultSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultSRVRecordMetaShadowedByList: S.Schema<RecordsCreateResultSRVRecordMetaShadowedByList>;
export interface RecordsCreateResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultSRVRecordMeta: S.Schema<RecordsCreateResultSRVRecordMeta>;
export type DnsRecordTypeSRV = "SRV";
export declare const DnsRecordTypeSRV: any;
export interface RecordsCreateResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultSRVRecord: S.Schema<RecordsCreateResultSRVRecord>;
export type RecordsCreateResultSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultSSHFPRecordMetaShadowedByList: S.Schema<RecordsCreateResultSSHFPRecordMetaShadowedByList>;
export interface RecordsCreateResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultSSHFPRecordMeta: S.Schema<RecordsCreateResultSSHFPRecordMeta>;
export type DnsRecordTypeSSHFP = "SSHFP";
export declare const DnsRecordTypeSSHFP: any;
export interface RecordsCreateResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultSSHFPRecord: S.Schema<RecordsCreateResultSSHFPRecord>;
export type RecordsCreateResultSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultSVCBRecordMetaShadowedByList: S.Schema<RecordsCreateResultSVCBRecordMetaShadowedByList>;
export interface RecordsCreateResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultSVCBRecordMeta: S.Schema<RecordsCreateResultSVCBRecordMeta>;
export type DnsRecordTypeSVCB = "SVCB";
export declare const DnsRecordTypeSVCB: any;
export interface RecordsCreateResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultSVCBRecord: S.Schema<RecordsCreateResultSVCBRecord>;
export type RecordsCreateResultTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultTLSARecordMetaShadowedByList: S.Schema<RecordsCreateResultTLSARecordMetaShadowedByList>;
export interface RecordsCreateResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultTLSARecordMeta: S.Schema<RecordsCreateResultTLSARecordMeta>;
export type DnsRecordTypeTLSA = "TLSA";
export declare const DnsRecordTypeTLSA: any;
export interface RecordsCreateResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultTLSARecord: S.Schema<RecordsCreateResultTLSARecord>;
export type RecordsCreateResultURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsCreateResultURIRecordMetaShadowedByList: S.Schema<RecordsCreateResultURIRecordMetaShadowedByList>;
export interface RecordsCreateResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsCreateResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsCreateResultURIRecordMeta: S.Schema<RecordsCreateResultURIRecordMeta>;
export type DnsRecordTypeURI = "URI";
export declare const DnsRecordTypeURI: any;
export interface RecordsCreateResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsCreateResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsCreateResultURIRecord: S.Schema<RecordsCreateResultURIRecord>;
export type RecordsCreateResult = RecordsCreateResultARecord | RecordsCreateResultAAAARecord | RecordsCreateResultCNAMERecord | RecordsCreateResultMXRecord | RecordsCreateResultNSRecord | RecordsCreateResultOpenpgpkeyRecord | RecordsCreateResultPTRRecord | RecordsCreateResultTXTRecord | RecordsCreateResultCAARecord | RecordsCreateResultCERTRecord | RecordsCreateResultDNSKEYRecord | RecordsCreateResultDSRecord | RecordsCreateResultHTTPSRecord | RecordsCreateResultLOCRecord | RecordsCreateResultNAPTRRecord | RecordsCreateResultSMIMEARecord | RecordsCreateResultSRVRecord | RecordsCreateResultSSHFPRecord | RecordsCreateResultSVCBRecord | RecordsCreateResultTLSARecord | RecordsCreateResultURIRecord;
export declare const RecordsCreateResult: any;
export type CreateRecordResponse = RecordsCreateResult;
export declare const CreateRecordResponse: S.Schema<CreateRecordResponse>;
export type SettingsAccountViewsCreateRequestZonesList = Array<string>;
export declare const SettingsAccountViewsCreateRequestZonesList: S.Schema<SettingsAccountViewsCreateRequestZonesList>;
export interface CreateSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsCreateRequestZonesList;
}
export declare const CreateSettingAccountViewRequest: S.Schema<CreateSettingAccountViewRequest>;
export type SettingsAccountViewsCreateResponseZonesList = Array<string>;
export declare const SettingsAccountViewsCreateResponseZonesList: S.Schema<SettingsAccountViewsCreateResponseZonesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingAccountViewResponse {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsCreateResponseZonesList;
}
export declare const CreateSettingAccountViewResponse: S.Schema<CreateSettingAccountViewResponse>;
export interface CreateZoneTransferAclRequest {
    accountId: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export declare const CreateZoneTransferAclRequest: S.Schema<CreateZoneTransferAclRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferAclResponse {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export declare const CreateZoneTransferAclResponse: S.Schema<CreateZoneTransferAclResponse>;
export interface CreateZoneTransferForceAxfrRequest {
    zoneId: string;
}
export declare const CreateZoneTransferForceAxfrRequest: S.Schema<CreateZoneTransferForceAxfrRequest>;
export type CreateZoneTransferForceAxfrResponse = unknown;
export declare const CreateZoneTransferForceAxfrResponse: S.Schema<CreateZoneTransferForceAxfrResponse>;
export type ZoneTransfersIncomingCreateRequestPeersList = Array<string>;
export declare const ZoneTransfersIncomingCreateRequestPeersList: S.Schema<ZoneTransfersIncomingCreateRequestPeersList>;
export interface CreateZoneTransferIncomingRequest {
    zoneId: string;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. */
    autoRefreshSeconds: number;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersIncomingCreateRequestPeersList;
}
export declare const CreateZoneTransferIncomingRequest: S.Schema<CreateZoneTransferIncomingRequest>;
export type ZoneTransfersIncomingCreateResponsePeersList = Array<string>;
export declare const ZoneTransfersIncomingCreateResponsePeersList: S.Schema<ZoneTransfersIncomingCreateResponsePeersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferIncomingResponse {
    id?: string | null;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. */
    autoRefreshSeconds?: number | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    modifiedTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersIncomingCreateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export declare const CreateZoneTransferIncomingResponse: S.Schema<CreateZoneTransferIncomingResponse>;
export type ZoneTransfersOutgoingCreateRequestPeersList = Array<string>;
export declare const ZoneTransfersOutgoingCreateRequestPeersList: S.Schema<ZoneTransfersOutgoingCreateRequestPeersList>;
export interface CreateZoneTransferOutgoingRequest {
    zoneId: string;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersOutgoingCreateRequestPeersList;
}
export declare const CreateZoneTransferOutgoingRequest: S.Schema<CreateZoneTransferOutgoingRequest>;
export type ZoneTransfersOutgoingCreateResponsePeersList = Array<string>;
export declare const ZoneTransfersOutgoingCreateResponsePeersList: S.Schema<ZoneTransfersOutgoingCreateResponsePeersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferOutgoingResponse {
    id?: string | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    lastTransferredTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersOutgoingCreateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export declare const CreateZoneTransferOutgoingResponse: S.Schema<CreateZoneTransferOutgoingResponse>;
export interface CreateZoneTransferPeerRequest {
    accountId: string;
    /** The name of the peer. */
    name: string;
}
export declare const CreateZoneTransferPeerRequest: S.Schema<CreateZoneTransferPeerRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferPeerResponse {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export declare const CreateZoneTransferPeerResponse: S.Schema<CreateZoneTransferPeerResponse>;
export interface CreateZoneTransferTsigRequest {
    accountId: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export declare const CreateZoneTransferTsigRequest: S.Schema<CreateZoneTransferTsigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateZoneTransferTsigResponse {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export declare const CreateZoneTransferTsigResponse: S.Schema<CreateZoneTransferTsigResponse>;
export interface DeleteDnssecRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const DeleteDnssecRequest: S.Schema<DeleteDnssecRequest>;
export type DeleteDnssecResponse = string;
export declare const DeleteDnssecResponse: S.Schema<DeleteDnssecResponse>;
export interface DeleteRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
}
export declare const DeleteRecordRequest: S.Schema<DeleteRecordRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRecordResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const DeleteRecordResponse: S.Schema<DeleteRecordResponse>;
export interface DeleteSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    viewId: string;
}
export declare const DeleteSettingAccountViewRequest: S.Schema<DeleteSettingAccountViewRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingAccountViewResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const DeleteSettingAccountViewResponse: S.Schema<DeleteSettingAccountViewResponse>;
export interface DeleteZoneTransferAclRequest {
    accountId: string;
    aclId: string;
}
export declare const DeleteZoneTransferAclRequest: S.Schema<DeleteZoneTransferAclRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferAclResponse {
    id?: string | null;
}
export declare const DeleteZoneTransferAclResponse: S.Schema<DeleteZoneTransferAclResponse>;
export interface DeleteZoneTransferIncomingRequest {
    zoneId: string;
}
export declare const DeleteZoneTransferIncomingRequest: S.Schema<DeleteZoneTransferIncomingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferIncomingResponse {
    id?: string | null;
}
export declare const DeleteZoneTransferIncomingResponse: S.Schema<DeleteZoneTransferIncomingResponse>;
export interface DeleteZoneTransferOutgoingRequest {
    zoneId: string;
}
export declare const DeleteZoneTransferOutgoingRequest: S.Schema<DeleteZoneTransferOutgoingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferOutgoingResponse {
    id?: string | null;
}
export declare const DeleteZoneTransferOutgoingResponse: S.Schema<DeleteZoneTransferOutgoingResponse>;
export interface DeleteZoneTransferPeerRequest {
    accountId: string;
    peerId: string;
}
export declare const DeleteZoneTransferPeerRequest: S.Schema<DeleteZoneTransferPeerRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferPeerResponse {
    id?: string | null;
}
export declare const DeleteZoneTransferPeerResponse: S.Schema<DeleteZoneTransferPeerResponse>;
export interface DeleteZoneTransferTsigRequest {
    accountId: string;
    tsigId: string;
}
export declare const DeleteZoneTransferTsigRequest: S.Schema<DeleteZoneTransferTsigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteZoneTransferTsigResponse {
    id?: string | null;
}
export declare const DeleteZoneTransferTsigResponse: S.Schema<DeleteZoneTransferTsigResponse>;
export interface DisableZoneTransferOutgoingRequest {
    zoneId: string;
}
export declare const DisableZoneTransferOutgoingRequest: S.Schema<DisableZoneTransferOutgoingRequest>;
export type DisableZoneTransferOutgoingResponse = unknown;
export declare const DisableZoneTransferOutgoingResponse: S.Schema<DisableZoneTransferOutgoingResponse>;
export interface EnableZoneTransferOutgoingRequest {
    zoneId: string;
}
export declare const EnableZoneTransferOutgoingRequest: S.Schema<EnableZoneTransferOutgoingRequest>;
export type EnableZoneTransferOutgoingResponse = unknown;
export declare const EnableZoneTransferOutgoingResponse: S.Schema<EnableZoneTransferOutgoingResponse>;
export interface ExportRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ExportRecordRequest: S.Schema<ExportRecordRequest>;
export interface ExportRecordResponse {
}
export declare const ExportRecordResponse: S.Schema<ExportRecordResponse>;
export interface ForceNotifyZoneTransferOutgoingRequest {
    zoneId: string;
}
export declare const ForceNotifyZoneTransferOutgoingRequest: S.Schema<ForceNotifyZoneTransferOutgoingRequest>;
export type ForceNotifyZoneTransferOutgoingResponse = string;
export declare const ForceNotifyZoneTransferOutgoingResponse: S.Schema<ForceNotifyZoneTransferOutgoingResponse>;
export interface GetAnalyticReportRequest {
    /** Identifier. */
    zoneId: string;
    /** A comma-separated list of dimensions to group results by. */
    dimensions?: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string;
    /** Limit number of returned metrics. */
    limit?: number;
    /** A comma-separated list of metrics to query. */
    metrics?: string;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since?: string;
    /** A comma-separated list of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: string;
    /** End date and time of requesting data period in ISO 8601 format. */
    until?: string;
}
export declare const GetAnalyticReportRequest: S.Schema<GetAnalyticReportRequest>;
export type AnalyticsReportsGetResponseDataItemDimensionsList = Array<string>;
export declare const AnalyticsReportsGetResponseDataItemDimensionsList: S.Schema<AnalyticsReportsGetResponseDataItemDimensionsList>;
export type AnalyticsReportsGetResponseDataItemMetricsList = Array<number>;
export declare const AnalyticsReportsGetResponseDataItemMetricsList: S.Schema<AnalyticsReportsGetResponseDataItemMetricsList>;
export interface AnalyticsReportsGetResponseDataItem {
    /** Array of dimension values, representing the combination of dimension values corresponding to this row. */
    dimensions: AnalyticsReportsGetResponseDataItemDimensionsList;
    /** Array with one item per requested metric. Each item is a single value. */
    metrics: AnalyticsReportsGetResponseDataItemMetricsList;
}
export declare const AnalyticsReportsGetResponseDataItem: S.Schema<AnalyticsReportsGetResponseDataItem>;
export type AnalyticsReportsGetResponseDataList = Array<AnalyticsReportsGetResponseDataItem>;
export declare const AnalyticsReportsGetResponseDataList: S.Schema<AnalyticsReportsGetResponseDataList>;
export type AnalyticsReportsGetResponseQueryDimensionsList = Array<string>;
export declare const AnalyticsReportsGetResponseQueryDimensionsList: S.Schema<AnalyticsReportsGetResponseQueryDimensionsList>;
export type AnalyticsReportsGetResponseQueryMetricsList = Array<string>;
export declare const AnalyticsReportsGetResponseQueryMetricsList: S.Schema<AnalyticsReportsGetResponseQueryMetricsList>;
export type AnalyticsReportsGetResponseQuerySortList = Array<string>;
export declare const AnalyticsReportsGetResponseQuerySortList: S.Schema<AnalyticsReportsGetResponseQuerySortList>;
export interface AnalyticsReportsGetResponseQuery {
    /** Array of dimension names. */
    dimensions: AnalyticsReportsGetResponseQueryDimensionsList;
    /** Limit number of returned metrics. */
    limit: number;
    /** Array of metric names. */
    metrics: AnalyticsReportsGetResponseQueryMetricsList;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since: string;
    /** End date and time of requesting data period in ISO 8601 format. */
    until: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string | null;
    /** Array of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: AnalyticsReportsGetResponseQuerySortList | null;
}
export declare const AnalyticsReportsGetResponseQuery: S.Schema<AnalyticsReportsGetResponseQuery>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticReportResponse {
    /** Array with one row per combination of dimension values. */
    data: AnalyticsReportsGetResponseDataList;
    /** Number of seconds between current time and last processed event, in another words how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum results for each metric (object mapping metric names to values). Currently always an empty object. */
    max: unknown;
    /** Minimum results for each metric (object mapping metric names to values). Currently always an empty object. */
    min: unknown;
    query: AnalyticsReportsGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Total results for metrics across all data (object mapping metric names to values). */
    totals: unknown;
}
export declare const GetAnalyticReportResponse: S.Schema<GetAnalyticReportResponse>;
export type AnalyticsReportsBytimesGetRequestTimeDelta = "all" | "auto" | "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export declare const AnalyticsReportsBytimesGetRequestTimeDelta: any;
export interface GetAnalyticReportBytimeRequest {
    /** Identifier. */
    zoneId: string;
    /** A comma-separated list of dimensions to group results by. */
    dimensions?: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string;
    /** Limit number of returned metrics. */
    limit?: number;
    /** A comma-separated list of metrics to query. */
    metrics?: string;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since?: string;
    /** A comma-separated list of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: string;
    /** Unit of time to group data by. */
    timeDelta?: AnalyticsReportsBytimesGetRequestTimeDelta | (string & {});
    /** End date and time of requesting data period in ISO 8601 format. */
    until?: string;
}
export declare const GetAnalyticReportBytimeRequest: S.Schema<GetAnalyticReportBytimeRequest>;
export type AnalyticsReportsBytimesGetResponseDataItemDimensionsList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseDataItemDimensionsList: S.Schema<AnalyticsReportsBytimesGetResponseDataItemDimensionsList>;
export type AnalyticsReportsBytimesGetResponseDataItemMetricsItemList = Array<number>;
export declare const AnalyticsReportsBytimesGetResponseDataItemMetricsItemList: S.Schema<AnalyticsReportsBytimesGetResponseDataItemMetricsItemList>;
export type AnalyticsReportsBytimesGetResponseDataItemMetricsList = Array<AnalyticsReportsBytimesGetResponseDataItemMetricsItemList>;
export declare const AnalyticsReportsBytimesGetResponseDataItemMetricsList: S.Schema<AnalyticsReportsBytimesGetResponseDataItemMetricsList>;
export interface AnalyticsReportsBytimesGetResponseDataItem {
    /** Array of dimension values, representing the combination of dimension values corresponding to this row. */
    dimensions: AnalyticsReportsBytimesGetResponseDataItemDimensionsList;
    /** Array with one item per requested metric. Each item is an array of values, broken down by time interval. */
    metrics: AnalyticsReportsBytimesGetResponseDataItemMetricsList;
}
export declare const AnalyticsReportsBytimesGetResponseDataItem: S.Schema<AnalyticsReportsBytimesGetResponseDataItem>;
export type AnalyticsReportsBytimesGetResponseDataList = Array<AnalyticsReportsBytimesGetResponseDataItem>;
export declare const AnalyticsReportsBytimesGetResponseDataList: S.Schema<AnalyticsReportsBytimesGetResponseDataList>;
export type AnalyticsReportsBytimesGetResponseQueryDimensionsList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseQueryDimensionsList: S.Schema<AnalyticsReportsBytimesGetResponseQueryDimensionsList>;
export type AnalyticsReportsBytimesGetResponseQueryMetricsList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseQueryMetricsList: S.Schema<AnalyticsReportsBytimesGetResponseQueryMetricsList>;
export type AnalyticsReportsBytimesGetResponseQueryTimeDelta = "all" | "auto" | "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export declare const AnalyticsReportsBytimesGetResponseQueryTimeDelta: any;
export type AnalyticsReportsBytimesGetResponseQuerySortList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseQuerySortList: S.Schema<AnalyticsReportsBytimesGetResponseQuerySortList>;
export interface AnalyticsReportsBytimesGetResponseQuery {
    /** Array of dimension names. */
    dimensions: AnalyticsReportsBytimesGetResponseQueryDimensionsList;
    /** Limit number of returned metrics. */
    limit: number;
    /** Array of metric names. */
    metrics: AnalyticsReportsBytimesGetResponseQueryMetricsList;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since: string;
    /** Unit of time to group data by. */
    timeDelta: AnalyticsReportsBytimesGetResponseQueryTimeDelta;
    /** End date and time of requesting data period in ISO 8601 format. */
    until: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string | null;
    /** Array of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: AnalyticsReportsBytimesGetResponseQuerySortList | null;
}
export declare const AnalyticsReportsBytimesGetResponseQuery: S.Schema<AnalyticsReportsBytimesGetResponseQuery>;
export type AnalyticsReportsBytimesGetResponseTimeIntervalsItemList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseTimeIntervalsItemList: S.Schema<AnalyticsReportsBytimesGetResponseTimeIntervalsItemList>;
export type AnalyticsReportsBytimesGetResponseTimeIntervalsList = Array<AnalyticsReportsBytimesGetResponseTimeIntervalsItemList>;
export declare const AnalyticsReportsBytimesGetResponseTimeIntervalsList: S.Schema<AnalyticsReportsBytimesGetResponseTimeIntervalsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticReportBytimeResponse {
    /** Array with one row per combination of dimension values. */
    data: AnalyticsReportsBytimesGetResponseDataList;
    /** Number of seconds between current time and last processed event, in another words how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum results for each metric (object mapping metric names to values). Currently always an empty object. */
    max: unknown;
    /** Minimum results for each metric (object mapping metric names to values). Currently always an empty object. */
    min: unknown;
    query: AnalyticsReportsBytimesGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Array of time intervals in the response data. Each interval is represented as an array containing two values: the start time, and the end time. */
    timeIntervals: AnalyticsReportsBytimesGetResponseTimeIntervalsList;
    /** Total results for metrics across all data (object mapping metric names to values). */
    totals: unknown;
}
export declare const GetAnalyticReportBytimeResponse: S.Schema<GetAnalyticReportBytimeResponse>;
export interface GetDnssecRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetDnssecRequest: S.Schema<GetDnssecRequest>;
export type DnssecGetResponseStatus = "active" | "pending" | "disabled" | "pending-disabled" | "error";
export declare const DnssecGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDnssecResponse {
    /** Algorithm key code. */
    algorithm?: string | null;
    /** Digest hash. */
    digest?: string | null;
    /** Type of digest algorithm. */
    digestAlgorithm?: string | null;
    /** Coded type for digest algorithm. */
    digestType?: string | null;
    /** If true, multi-signer DNSSEC is enabled on the zone, allowing multiple */
    dnssecMultiSigner?: boolean | null;
    /** If true, allows Cloudflare to transfer in a DNSSEC-signed zone */
    dnssecPresigned?: boolean | null;
    /** If true, enables the use of NSEC3 together with DNSSEC on the zone. */
    dnssecUseNsec3?: boolean | null;
    /** Full DS record. */
    ds?: string | null;
    /** Flag for DNSSEC record. */
    flags?: number | null;
    /** Code for key tag. */
    keyTag?: number | null;
    /** Algorithm key type. */
    keyType?: string | null;
    /** When DNSSEC was last modified. */
    modifiedOn?: string | null;
    /** Public key for DS record. */
    publicKey?: string | null;
    /** Status of DNSSEC, based on user-desired state and presence of necessary records. */
    status?: DnssecGetResponseStatus | null;
}
export declare const GetDnssecResponse: S.Schema<GetDnssecResponse>;
export interface GetRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
}
export declare const GetRecordRequest: S.Schema<GetRecordRequest>;
export type RecordsGetResultARecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultARecordMetaShadowedByList: S.Schema<RecordsGetResultARecordMetaShadowedByList>;
export interface RecordsGetResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultARecordMeta: S.Schema<RecordsGetResultARecordMeta>;
export interface RecordsGetResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultARecord: S.Schema<RecordsGetResultARecord>;
export type RecordsGetResultAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultAAAARecordMetaShadowedByList: S.Schema<RecordsGetResultAAAARecordMetaShadowedByList>;
export interface RecordsGetResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultAAAARecordMeta: S.Schema<RecordsGetResultAAAARecordMeta>;
export interface RecordsGetResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultAAAARecord: S.Schema<RecordsGetResultAAAARecord>;
export type RecordsGetResultCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultCNAMERecordMetaShadowedByList: S.Schema<RecordsGetResultCNAMERecordMetaShadowedByList>;
export interface RecordsGetResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultCNAMERecordMeta: S.Schema<RecordsGetResultCNAMERecordMeta>;
export interface RecordsGetResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultCNAMERecord: S.Schema<RecordsGetResultCNAMERecord>;
export type RecordsGetResultMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultMXRecordMetaShadowedByList: S.Schema<RecordsGetResultMXRecordMetaShadowedByList>;
export interface RecordsGetResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultMXRecordMeta: S.Schema<RecordsGetResultMXRecordMeta>;
export interface RecordsGetResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultMXRecord: S.Schema<RecordsGetResultMXRecord>;
export type RecordsGetResultNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultNSRecordMetaShadowedByList: S.Schema<RecordsGetResultNSRecordMetaShadowedByList>;
export interface RecordsGetResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultNSRecordMeta: S.Schema<RecordsGetResultNSRecordMeta>;
export interface RecordsGetResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultNSRecord: S.Schema<RecordsGetResultNSRecord>;
export type RecordsGetResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsGetResultOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsGetResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultOpenpgpkeyRecordMeta: S.Schema<RecordsGetResultOpenpgpkeyRecordMeta>;
export type RecordsGetResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export declare const RecordsGetResultOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsGetResultOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsGetResultOpenpgpkeyRecordTagsList: S.Schema<RecordsGetResultOpenpgpkeyRecordTagsList>;
export type RecordsGetResultOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsGetResultOpenpgpkeyRecordType: any;
export interface RecordsGetResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsGetResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsGetResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsGetResultOpenpgpkeyRecord: S.Schema<RecordsGetResultOpenpgpkeyRecord>;
export type RecordsGetResultPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultPTRRecordMetaShadowedByList: S.Schema<RecordsGetResultPTRRecordMetaShadowedByList>;
export interface RecordsGetResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultPTRRecordMeta: S.Schema<RecordsGetResultPTRRecordMeta>;
export interface RecordsGetResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultPTRRecord: S.Schema<RecordsGetResultPTRRecord>;
export type RecordsGetResultTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultTXTRecordMetaShadowedByList: S.Schema<RecordsGetResultTXTRecordMetaShadowedByList>;
export interface RecordsGetResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultTXTRecordMeta: S.Schema<RecordsGetResultTXTRecordMeta>;
export interface RecordsGetResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultTXTRecord: S.Schema<RecordsGetResultTXTRecord>;
export type RecordsGetResultCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultCAARecordMetaShadowedByList: S.Schema<RecordsGetResultCAARecordMetaShadowedByList>;
export interface RecordsGetResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultCAARecordMeta: S.Schema<RecordsGetResultCAARecordMeta>;
export interface RecordsGetResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultCAARecord: S.Schema<RecordsGetResultCAARecord>;
export type RecordsGetResultCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultCERTRecordMetaShadowedByList: S.Schema<RecordsGetResultCERTRecordMetaShadowedByList>;
export interface RecordsGetResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultCERTRecordMeta: S.Schema<RecordsGetResultCERTRecordMeta>;
export interface RecordsGetResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultCERTRecord: S.Schema<RecordsGetResultCERTRecord>;
export type RecordsGetResultDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultDNSKEYRecordMetaShadowedByList: S.Schema<RecordsGetResultDNSKEYRecordMetaShadowedByList>;
export interface RecordsGetResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultDNSKEYRecordMeta: S.Schema<RecordsGetResultDNSKEYRecordMeta>;
export interface RecordsGetResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultDNSKEYRecord: S.Schema<RecordsGetResultDNSKEYRecord>;
export type RecordsGetResultDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultDSRecordMetaShadowedByList: S.Schema<RecordsGetResultDSRecordMetaShadowedByList>;
export interface RecordsGetResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultDSRecordMeta: S.Schema<RecordsGetResultDSRecordMeta>;
export interface RecordsGetResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultDSRecord: S.Schema<RecordsGetResultDSRecord>;
export type RecordsGetResultHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultHTTPSRecordMetaShadowedByList: S.Schema<RecordsGetResultHTTPSRecordMetaShadowedByList>;
export interface RecordsGetResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultHTTPSRecordMeta: S.Schema<RecordsGetResultHTTPSRecordMeta>;
export interface RecordsGetResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultHTTPSRecord: S.Schema<RecordsGetResultHTTPSRecord>;
export type RecordsGetResultLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultLOCRecordMetaShadowedByList: S.Schema<RecordsGetResultLOCRecordMetaShadowedByList>;
export interface RecordsGetResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultLOCRecordMeta: S.Schema<RecordsGetResultLOCRecordMeta>;
export interface RecordsGetResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultLOCRecord: S.Schema<RecordsGetResultLOCRecord>;
export type RecordsGetResultNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultNAPTRRecordMetaShadowedByList: S.Schema<RecordsGetResultNAPTRRecordMetaShadowedByList>;
export interface RecordsGetResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultNAPTRRecordMeta: S.Schema<RecordsGetResultNAPTRRecordMeta>;
export interface RecordsGetResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultNAPTRRecord: S.Schema<RecordsGetResultNAPTRRecord>;
export type RecordsGetResultSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultSMIMEARecordMetaShadowedByList: S.Schema<RecordsGetResultSMIMEARecordMetaShadowedByList>;
export interface RecordsGetResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultSMIMEARecordMeta: S.Schema<RecordsGetResultSMIMEARecordMeta>;
export interface RecordsGetResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultSMIMEARecord: S.Schema<RecordsGetResultSMIMEARecord>;
export type RecordsGetResultSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultSRVRecordMetaShadowedByList: S.Schema<RecordsGetResultSRVRecordMetaShadowedByList>;
export interface RecordsGetResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultSRVRecordMeta: S.Schema<RecordsGetResultSRVRecordMeta>;
export interface RecordsGetResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultSRVRecord: S.Schema<RecordsGetResultSRVRecord>;
export type RecordsGetResultSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultSSHFPRecordMetaShadowedByList: S.Schema<RecordsGetResultSSHFPRecordMetaShadowedByList>;
export interface RecordsGetResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultSSHFPRecordMeta: S.Schema<RecordsGetResultSSHFPRecordMeta>;
export interface RecordsGetResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultSSHFPRecord: S.Schema<RecordsGetResultSSHFPRecord>;
export type RecordsGetResultSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultSVCBRecordMetaShadowedByList: S.Schema<RecordsGetResultSVCBRecordMetaShadowedByList>;
export interface RecordsGetResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultSVCBRecordMeta: S.Schema<RecordsGetResultSVCBRecordMeta>;
export interface RecordsGetResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultSVCBRecord: S.Schema<RecordsGetResultSVCBRecord>;
export type RecordsGetResultTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultTLSARecordMetaShadowedByList: S.Schema<RecordsGetResultTLSARecordMetaShadowedByList>;
export interface RecordsGetResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultTLSARecordMeta: S.Schema<RecordsGetResultTLSARecordMeta>;
export interface RecordsGetResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultTLSARecord: S.Schema<RecordsGetResultTLSARecord>;
export type RecordsGetResultURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsGetResultURIRecordMetaShadowedByList: S.Schema<RecordsGetResultURIRecordMetaShadowedByList>;
export interface RecordsGetResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsGetResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsGetResultURIRecordMeta: S.Schema<RecordsGetResultURIRecordMeta>;
export interface RecordsGetResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsGetResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsGetResultURIRecord: S.Schema<RecordsGetResultURIRecord>;
export type RecordsGetResult = RecordsGetResultARecord | RecordsGetResultAAAARecord | RecordsGetResultCNAMERecord | RecordsGetResultMXRecord | RecordsGetResultNSRecord | RecordsGetResultOpenpgpkeyRecord | RecordsGetResultPTRRecord | RecordsGetResultTXTRecord | RecordsGetResultCAARecord | RecordsGetResultCERTRecord | RecordsGetResultDNSKEYRecord | RecordsGetResultDSRecord | RecordsGetResultHTTPSRecord | RecordsGetResultLOCRecord | RecordsGetResultNAPTRRecord | RecordsGetResultSMIMEARecord | RecordsGetResultSRVRecord | RecordsGetResultSSHFPRecord | RecordsGetResultSVCBRecord | RecordsGetResultTLSARecord | RecordsGetResultURIRecord;
export declare const RecordsGetResult: any;
export type GetRecordResponse = RecordsGetResult;
export declare const GetRecordResponse: S.Schema<GetRecordResponse>;
export interface GetSettingAccountRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetSettingAccountRequest: S.Schema<GetSettingAccountRequest>;
export interface SettingsAccountGetResponseZoneDefaultsInternalDns {
    /** The ID of the zone to fallback to. */
    referenceZoneId?: string | null;
}
export declare const SettingsAccountGetResponseZoneDefaultsInternalDns: S.Schema<SettingsAccountGetResponseZoneDefaultsInternalDns>;
export type SettingsAccountGetResponseZoneDefaultsNameserversType = "cloudflare.standard" | "cloudflare.standard.random" | "custom.account" | "custom.tenant";
export declare const SettingsAccountGetResponseZoneDefaultsNameserversType: any;
export interface SettingsAccountGetResponseZoneDefaultsNameservers {
    /** Nameserver type */
    type: SettingsAccountGetResponseZoneDefaultsNameserversType;
}
export declare const SettingsAccountGetResponseZoneDefaultsNameservers: S.Schema<SettingsAccountGetResponseZoneDefaultsNameservers>;
export interface SettingsAccountGetResponseZoneDefaultsSoa {
    /** Time in seconds of being unable to query the primary server after which secondary servers should stop serving the zone. */
    expire?: number | null;
    /** The time to live (TTL) for negative caching of records within the zone. */
    minTtl?: number | null;
    /** The primary nameserver, which may be used for outbound zone transfers. If null, a Cloudflare-assigned value will be used. */
    mname?: string | null;
    /** Time in seconds after which secondary servers should re-check the SOA record to see if the zone has been updated. */
    refresh?: number | null;
    /** Time in seconds after which secondary servers should retry queries after the primary server was unresponsive. */
    retry?: number | null;
    /** The email address of the zone administrator, with the first label representing the local part of the email address. */
    rname?: string | null;
    /** The time to live (TTL) of the SOA record itself. */
    ttl?: number | null;
}
export declare const SettingsAccountGetResponseZoneDefaultsSoa: S.Schema<SettingsAccountGetResponseZoneDefaultsSoa>;
export type SettingsAccountGetResponseZoneDefaultsZoneMode = "standard" | "cdn_only" | "dns_only";
export declare const SettingsAccountGetResponseZoneDefaultsZoneMode: any;
export interface SettingsAccountGetResponseZoneDefaults {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** Whether to enable Foundation DNS Advanced Nameservers on the zone. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers: SettingsAccountGetResponseZoneDefaultsNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsAccountGetResponseZoneDefaultsZoneMode;
}
export declare const SettingsAccountGetResponseZoneDefaults: S.Schema<SettingsAccountGetResponseZoneDefaults>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingAccountResponse {
    zoneDefaults: SettingsAccountGetResponseZoneDefaults;
    /** When enabled, forces all proxied DNS records in the account to behave as DNS-only at the edge, regardless of each record's individual proxy setting. Note that this account-level override does not modify the records themselves; it only affects how they are served at the edge. See more on [Enforce DNS-only](https://developers.cloudflare.com/dns/proxy-status/enforce-dns-only). */
    enforceDnsOnly?: boolean | null;
}
export declare const GetSettingAccountResponse: S.Schema<GetSettingAccountResponse>;
export interface GetSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    viewId: string;
}
export declare const GetSettingAccountViewRequest: S.Schema<GetSettingAccountViewRequest>;
export type SettingsAccountViewsGetResponseZonesList = Array<string>;
export declare const SettingsAccountViewsGetResponseZonesList: S.Schema<SettingsAccountViewsGetResponseZonesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingAccountViewResponse {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsGetResponseZonesList;
}
export declare const GetSettingAccountViewResponse: S.Schema<GetSettingAccountViewResponse>;
export interface GetSettingZoneRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetSettingZoneRequest: S.Schema<GetSettingZoneRequest>;
export type SettingsZoneGetResponseInternalDns = SettingsAccountGetResponseZoneDefaultsInternalDns;
export declare const SettingsZoneGetResponseInternalDns: S.Schema<SettingsAccountGetResponseZoneDefaultsInternalDns>;
export type SettingsZoneGetResponseNameserversType = "cloudflare.standard" | "custom.account" | "custom.tenant" | "custom.zone";
export declare const SettingsZoneGetResponseNameserversType: any;
export interface SettingsZoneGetResponseNameservers {
    /** Nameserver type */
    type: SettingsZoneGetResponseNameserversType;
    /** Configured nameserver set to be used for this zone */
    nsSet?: number | null;
}
export declare const SettingsZoneGetResponseNameservers: S.Schema<SettingsZoneGetResponseNameservers>;
export type SettingsZoneGetResponseSoa = SettingsAccountGetResponseZoneDefaultsSoa;
export declare const SettingsZoneGetResponseSoa: S.Schema<SettingsAccountGetResponseZoneDefaultsSoa>;
export type SettingsZoneGetResponseZoneMode = "standard" | "cdn_only" | "dns_only";
export declare const SettingsZoneGetResponseZoneMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingZoneResponse {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** Whether to enable Foundation DNS Advanced Nameservers on the zone. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers: SettingsZoneGetResponseNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsZoneGetResponseZoneMode;
}
export declare const GetSettingZoneResponse: S.Schema<GetSettingZoneResponse>;
export interface GetUsageAccountRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetUsageAccountRequest: S.Schema<GetUsageAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUsageAccountResponse {
    /** Maximum number of DNS records allowed across all public zones in the account. Null if using zone-level quota. */
    recordQuota: number;
    /** Current number of DNS records across all public zones in the account. */
    recordUsage: number;
    /** Maximum number of DNS records allowed across all internal zones in the account. Only present if internal DNS is enabled. */
    internalRecordQuota?: number | null;
    /** Current number of DNS records across all internal zones in the account. Only present if internal DNS is enabled. */
    internalRecordUsage?: number | null;
}
export declare const GetUsageAccountResponse: S.Schema<GetUsageAccountResponse>;
export interface GetUsageZoneRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetUsageZoneRequest: S.Schema<GetUsageZoneRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUsageZoneResponse {
    /** Maximum number of DNS records allowed for the zone. Null if using account-level quota. */
    recordQuota: number;
    /** Current number of DNS records in the zone. */
    recordUsage: number;
}
export declare const GetUsageZoneResponse: S.Schema<GetUsageZoneResponse>;
export interface GetZoneTransferAclRequest {
    accountId: string;
    aclId: string;
}
export declare const GetZoneTransferAclRequest: S.Schema<GetZoneTransferAclRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferAclResponse {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export declare const GetZoneTransferAclResponse: S.Schema<GetZoneTransferAclResponse>;
export interface GetZoneTransferIncomingRequest {
    zoneId: string;
}
export declare const GetZoneTransferIncomingRequest: S.Schema<GetZoneTransferIncomingRequest>;
export type ZoneTransfersIncomingGetResponsePeersList = Array<string>;
export declare const ZoneTransfersIncomingGetResponsePeersList: S.Schema<ZoneTransfersIncomingGetResponsePeersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferIncomingResponse {
    id?: string | null;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. */
    autoRefreshSeconds?: number | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    modifiedTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersIncomingGetResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export declare const GetZoneTransferIncomingResponse: S.Schema<GetZoneTransferIncomingResponse>;
export interface GetZoneTransferOutgoingRequest {
    zoneId: string;
}
export declare const GetZoneTransferOutgoingRequest: S.Schema<GetZoneTransferOutgoingRequest>;
export type ZoneTransfersOutgoingGetResponsePeersList = Array<string>;
export declare const ZoneTransfersOutgoingGetResponsePeersList: S.Schema<ZoneTransfersOutgoingGetResponsePeersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferOutgoingResponse {
    id?: string | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    lastTransferredTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersOutgoingGetResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export declare const GetZoneTransferOutgoingResponse: S.Schema<GetZoneTransferOutgoingResponse>;
export interface GetZoneTransferOutgoingStatusRequest {
    zoneId: string;
}
export declare const GetZoneTransferOutgoingStatusRequest: S.Schema<GetZoneTransferOutgoingStatusRequest>;
export type GetZoneTransferOutgoingStatusResponse = string;
export declare const GetZoneTransferOutgoingStatusResponse: S.Schema<GetZoneTransferOutgoingStatusResponse>;
export interface GetZoneTransferPeerRequest {
    accountId: string;
    peerId: string;
}
export declare const GetZoneTransferPeerRequest: S.Schema<GetZoneTransferPeerRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferPeerResponse {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export declare const GetZoneTransferPeerResponse: S.Schema<GetZoneTransferPeerResponse>;
export interface GetZoneTransferTsigRequest {
    accountId: string;
    tsigId: string;
}
export declare const GetZoneTransferTsigRequest: S.Schema<GetZoneTransferTsigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetZoneTransferTsigResponse {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export declare const GetZoneTransferTsigResponse: S.Schema<GetZoneTransferTsigResponse>;
export interface ImportRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ImportRecordRequest: S.Schema<ImportRecordRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ImportRecordResponse {
    /** Number of DNS records added. */
    recsAdded?: number | null;
    /** Total number of DNS records parsed. */
    totalRecordsParsed?: number | null;
}
export declare const ImportRecordResponse: S.Schema<ImportRecordResponse>;
export interface RecordsListRequestComment {
    /** If this parameter is present, only records *without* a comment are returned. */
    absent?: string;
    /** Substring of the DNS record comment. Comment filters are case-insensitive. */
    contains?: string;
    /** Suffix of the DNS record comment. Comment filters are case-insensitive. */
    endswith?: string;
    /** Exact value of the DNS record comment. Comment filters are case-insensitive. */
    exact?: string;
    /** If this parameter is present, only records *with* a comment are returned. */
    present?: string;
    /** Prefix of the DNS record comment. Comment filters are case-insensitive. */
    startswith?: string;
}
export declare const RecordsListRequestComment: S.Schema<RecordsListRequestComment>;
export interface RecordsListRequestContent {
    /** Substring of the DNS record content. Content filters are case-insensitive. */
    contains?: string;
    /** Suffix of the DNS record content. Content filters are case-insensitive. */
    endswith?: string;
    /** Exact value of the DNS record content. Content filters are case-insensitive. */
    exact?: string;
    /** Prefix of the DNS record content. Content filters are case-insensitive. */
    startswith?: string;
}
export declare const RecordsListRequestContent: S.Schema<RecordsListRequestContent>;
export type RecordsListRequestMatch = "any" | "all";
export declare const RecordsListRequestMatch: any;
export interface RecordsListRequestName {
    /** Substring of the DNS record name. Name filters are case-insensitive. */
    contains?: string;
    /** Suffix of the DNS record name. Name filters are case-insensitive. */
    endswith?: string;
    /** Exact value of the DNS record name. Name filters are case-insensitive. */
    exact?: string;
    /** Prefix of the DNS record name. Name filters are case-insensitive. */
    startswith?: string;
}
export declare const RecordsListRequestName: S.Schema<RecordsListRequestName>;
export type RecordsListRequestOrder = "type" | "name" | "content" | "ttl" | "proxied";
export declare const RecordsListRequestOrder: any;
export interface RecordsListRequestTag {
    /** Name of a tag which must *not* be present on the DNS record. Tag filters are case-insensitive. */
    absent?: string;
    /** A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value contains `<tag-value>`. Tag filters are case-insensitive. */
    contains?: string;
    /** A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value ends with `<tag-value>`. Tag filters are case-insensitive. */
    endswith?: string;
    /** A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value is `<tag-value>`. Tag filters are case-insensitive. */
    exact?: string;
    /** Name of a tag which must be present on the DNS record. Tag filters are case-insensitive. */
    present?: string;
    /** A tag and value, of the form `<tag-name>:<tag-value>`. The API will only return DNS records that have a tag named `<tag-name>` whose value starts with `<tag-value>`. Tag filters are case-insensitive. */
    startswith?: string;
}
export declare const RecordsListRequestTag: S.Schema<RecordsListRequestTag>;
export type RecordsListRequestTagMatch = "any" | "all";
export declare const RecordsListRequestTagMatch: any;
export type RecordsListRequestType = "A" | "AAAA" | "CAA" | "CERT" | "CNAME" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "MX" | "NAPTR" | "NS" | "OPENPGPKEY" | "PTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "TXT" | "URI";
export declare const RecordsListRequestType: any;
export interface ListRecordsRequest {
    /** Identifier. */
    zoneId: string;
    comment?: RecordsListRequestComment;
    content?: RecordsListRequestContent;
    /** Direction to order DNS records in. */
    direction?: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Whether to match all search requirements or at least one (any). If set to `all`, acts like a logical AND between filters. If set to `any`, acts like a logical OR instead. Note that the interaction between tag filters is controlled by the `tag-match` parameter instead. */
    match?: RecordsListRequestMatch | (string & {});
    name?: RecordsListRequestName;
    /** Field to order DNS records by. */
    order?: RecordsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of DNS records per page. */
    perPage?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Allows searching in multiple properties of a DNS record simultaneously. This parameter is intended for human users, not automation. Its exact behavior is intentionally left unspecified and is subject to change in the future. This parameter works independently of the `match` setting. For automated searches, please use the other available parameters. */
    search?: string;
    /** Filters to records at or below the given NS delegation name, excluding the NS records that form the delegation itself. The value must be a subdomain of the zone; the zone apex is not accepted. Requires `include_shadow_metadata=true`. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedByName?: string;
    /** Returns NS records that shadow the given name, searching at the name itself and each of its ancestor names within the zone, excluding the zone apex. The value must be a subdomain of the zone; the zone apex is not accepted. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowingName?: string;
    tag?: RecordsListRequestTag;
    /** Whether to match all tag search requirements or at least one (any). If set to `all`, acts like a logical AND between tag filters. If set to `any`, acts like a logical OR instead. Note that the regular `match` parameter is still used to combine the resulting condition with other filters that aren't related to tags. */
    tagMatch?: RecordsListRequestTagMatch | (string & {});
    /** Record type. */
    type?: RecordsListRequestType | (string & {});
}
export declare const ListRecordsRequest: S.Schema<ListRecordsRequest>;
export type RecordsListResultItemARecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemARecordMetaShadowedByList: S.Schema<RecordsListResultItemARecordMetaShadowedByList>;
export interface RecordsListResultItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemARecordMeta: S.Schema<RecordsListResultItemARecordMeta>;
export type RecordsListResultItemARecordType = "A";
export declare const RecordsListResultItemARecordType: any;
export interface RecordsListResultItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemARecord: S.Schema<RecordsListResultItemARecord>;
export type RecordsListResultItemAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemAAAARecordMetaShadowedByList: S.Schema<RecordsListResultItemAAAARecordMetaShadowedByList>;
export interface RecordsListResultItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemAAAARecordMeta: S.Schema<RecordsListResultItemAAAARecordMeta>;
export type RecordsListResultItemAAAARecordType = "AAAA";
export declare const RecordsListResultItemAAAARecordType: any;
export interface RecordsListResultItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemAAAARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemAAAARecord: S.Schema<RecordsListResultItemAAAARecord>;
export type RecordsListResultItemCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemCNAMERecordMetaShadowedByList: S.Schema<RecordsListResultItemCNAMERecordMetaShadowedByList>;
export interface RecordsListResultItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemCNAMERecordMeta: S.Schema<RecordsListResultItemCNAMERecordMeta>;
export type RecordsListResultItemCNAMERecordType = "CNAME";
export declare const RecordsListResultItemCNAMERecordType: any;
export interface RecordsListResultItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemCNAMERecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemCNAMERecord: S.Schema<RecordsListResultItemCNAMERecord>;
export type RecordsListResultItemMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemMXRecordMetaShadowedByList: S.Schema<RecordsListResultItemMXRecordMetaShadowedByList>;
export interface RecordsListResultItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemMXRecordMeta: S.Schema<RecordsListResultItemMXRecordMeta>;
export type RecordsListResultItemMXRecordType = "MX";
export declare const RecordsListResultItemMXRecordType: any;
export interface RecordsListResultItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemMXRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemMXRecord: S.Schema<RecordsListResultItemMXRecord>;
export type RecordsListResultItemNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemNSRecordMetaShadowedByList: S.Schema<RecordsListResultItemNSRecordMetaShadowedByList>;
export interface RecordsListResultItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemNSRecordMeta: S.Schema<RecordsListResultItemNSRecordMeta>;
export type RecordsListResultItemNSRecordType = "NS";
export declare const RecordsListResultItemNSRecordType: any;
export interface RecordsListResultItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemNSRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemNSRecord: S.Schema<RecordsListResultItemNSRecord>;
export type RecordsListResultItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsListResultItemOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsListResultItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemOpenpgpkeyRecordMeta: S.Schema<RecordsListResultItemOpenpgpkeyRecordMeta>;
export type RecordsListResultItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export declare const RecordsListResultItemOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsListResultItemOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsListResultItemOpenpgpkeyRecordTagsList: S.Schema<RecordsListResultItemOpenpgpkeyRecordTagsList>;
export type RecordsListResultItemOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsListResultItemOpenpgpkeyRecordType: any;
export interface RecordsListResultItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsListResultItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsListResultItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsListResultItemOpenpgpkeyRecord: S.Schema<RecordsListResultItemOpenpgpkeyRecord>;
export type RecordsListResultItemPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemPTRRecordMetaShadowedByList: S.Schema<RecordsListResultItemPTRRecordMetaShadowedByList>;
export interface RecordsListResultItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemPTRRecordMeta: S.Schema<RecordsListResultItemPTRRecordMeta>;
export type RecordsListResultItemPTRRecordType = "PTR";
export declare const RecordsListResultItemPTRRecordType: any;
export interface RecordsListResultItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemPTRRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemPTRRecord: S.Schema<RecordsListResultItemPTRRecord>;
export type RecordsListResultItemTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemTXTRecordMetaShadowedByList: S.Schema<RecordsListResultItemTXTRecordMetaShadowedByList>;
export interface RecordsListResultItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemTXTRecordMeta: S.Schema<RecordsListResultItemTXTRecordMeta>;
export type RecordsListResultItemTXTRecordType = "TXT";
export declare const RecordsListResultItemTXTRecordType: any;
export interface RecordsListResultItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemTXTRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemTXTRecord: S.Schema<RecordsListResultItemTXTRecord>;
export type RecordsListResultItemCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemCAARecordMetaShadowedByList: S.Schema<RecordsListResultItemCAARecordMetaShadowedByList>;
export interface RecordsListResultItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemCAARecordMeta: S.Schema<RecordsListResultItemCAARecordMeta>;
export type RecordsListResultItemCAARecordType = "CAA";
export declare const RecordsListResultItemCAARecordType: any;
export interface RecordsListResultItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemCAARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemCAARecord: S.Schema<RecordsListResultItemCAARecord>;
export type RecordsListResultItemCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemCERTRecordMetaShadowedByList: S.Schema<RecordsListResultItemCERTRecordMetaShadowedByList>;
export interface RecordsListResultItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemCERTRecordMeta: S.Schema<RecordsListResultItemCERTRecordMeta>;
export type RecordsListResultItemCERTRecordType = "CERT";
export declare const RecordsListResultItemCERTRecordType: any;
export interface RecordsListResultItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemCERTRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemCERTRecord: S.Schema<RecordsListResultItemCERTRecord>;
export type RecordsListResultItemDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemDNSKEYRecordMetaShadowedByList: S.Schema<RecordsListResultItemDNSKEYRecordMetaShadowedByList>;
export interface RecordsListResultItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemDNSKEYRecordMeta: S.Schema<RecordsListResultItemDNSKEYRecordMeta>;
export type RecordsListResultItemDNSKEYRecordType = "DNSKEY";
export declare const RecordsListResultItemDNSKEYRecordType: any;
export interface RecordsListResultItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemDNSKEYRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemDNSKEYRecord: S.Schema<RecordsListResultItemDNSKEYRecord>;
export type RecordsListResultItemDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemDSRecordMetaShadowedByList: S.Schema<RecordsListResultItemDSRecordMetaShadowedByList>;
export interface RecordsListResultItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemDSRecordMeta: S.Schema<RecordsListResultItemDSRecordMeta>;
export type RecordsListResultItemDSRecordType = "DS";
export declare const RecordsListResultItemDSRecordType: any;
export interface RecordsListResultItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemDSRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemDSRecord: S.Schema<RecordsListResultItemDSRecord>;
export type RecordsListResultItemHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemHTTPSRecordMetaShadowedByList: S.Schema<RecordsListResultItemHTTPSRecordMetaShadowedByList>;
export interface RecordsListResultItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemHTTPSRecordMeta: S.Schema<RecordsListResultItemHTTPSRecordMeta>;
export type RecordsListResultItemHTTPSRecordType = "HTTPS";
export declare const RecordsListResultItemHTTPSRecordType: any;
export interface RecordsListResultItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemHTTPSRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemHTTPSRecord: S.Schema<RecordsListResultItemHTTPSRecord>;
export type RecordsListResultItemLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemLOCRecordMetaShadowedByList: S.Schema<RecordsListResultItemLOCRecordMetaShadowedByList>;
export interface RecordsListResultItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemLOCRecordMeta: S.Schema<RecordsListResultItemLOCRecordMeta>;
export type RecordsListResultItemLOCRecordType = "LOC";
export declare const RecordsListResultItemLOCRecordType: any;
export interface RecordsListResultItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemLOCRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemLOCRecord: S.Schema<RecordsListResultItemLOCRecord>;
export type RecordsListResultItemNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemNAPTRRecordMetaShadowedByList: S.Schema<RecordsListResultItemNAPTRRecordMetaShadowedByList>;
export interface RecordsListResultItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemNAPTRRecordMeta: S.Schema<RecordsListResultItemNAPTRRecordMeta>;
export type RecordsListResultItemNAPTRRecordType = "NAPTR";
export declare const RecordsListResultItemNAPTRRecordType: any;
export interface RecordsListResultItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemNAPTRRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemNAPTRRecord: S.Schema<RecordsListResultItemNAPTRRecord>;
export type RecordsListResultItemSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemSMIMEARecordMetaShadowedByList: S.Schema<RecordsListResultItemSMIMEARecordMetaShadowedByList>;
export interface RecordsListResultItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemSMIMEARecordMeta: S.Schema<RecordsListResultItemSMIMEARecordMeta>;
export type RecordsListResultItemSMIMEARecordType = "SMIMEA";
export declare const RecordsListResultItemSMIMEARecordType: any;
export interface RecordsListResultItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSMIMEARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemSMIMEARecord: S.Schema<RecordsListResultItemSMIMEARecord>;
export type RecordsListResultItemSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemSRVRecordMetaShadowedByList: S.Schema<RecordsListResultItemSRVRecordMetaShadowedByList>;
export interface RecordsListResultItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemSRVRecordMeta: S.Schema<RecordsListResultItemSRVRecordMeta>;
export type RecordsListResultItemSRVRecordType = "SRV";
export declare const RecordsListResultItemSRVRecordType: any;
export interface RecordsListResultItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSRVRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemSRVRecord: S.Schema<RecordsListResultItemSRVRecord>;
export type RecordsListResultItemSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemSSHFPRecordMetaShadowedByList: S.Schema<RecordsListResultItemSSHFPRecordMetaShadowedByList>;
export interface RecordsListResultItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemSSHFPRecordMeta: S.Schema<RecordsListResultItemSSHFPRecordMeta>;
export type RecordsListResultItemSSHFPRecordType = "SSHFP";
export declare const RecordsListResultItemSSHFPRecordType: any;
export interface RecordsListResultItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSSHFPRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemSSHFPRecord: S.Schema<RecordsListResultItemSSHFPRecord>;
export type RecordsListResultItemSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemSVCBRecordMetaShadowedByList: S.Schema<RecordsListResultItemSVCBRecordMetaShadowedByList>;
export interface RecordsListResultItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemSVCBRecordMeta: S.Schema<RecordsListResultItemSVCBRecordMeta>;
export type RecordsListResultItemSVCBRecordType = "SVCB";
export declare const RecordsListResultItemSVCBRecordType: any;
export interface RecordsListResultItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemSVCBRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemSVCBRecord: S.Schema<RecordsListResultItemSVCBRecord>;
export type RecordsListResultItemTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemTLSARecordMetaShadowedByList: S.Schema<RecordsListResultItemTLSARecordMetaShadowedByList>;
export interface RecordsListResultItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemTLSARecordMeta: S.Schema<RecordsListResultItemTLSARecordMeta>;
export type RecordsListResultItemTLSARecordType = "TLSA";
export declare const RecordsListResultItemTLSARecordType: any;
export interface RecordsListResultItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemTLSARecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemTLSARecord: S.Schema<RecordsListResultItemTLSARecord>;
export type RecordsListResultItemURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsListResultItemURIRecordMetaShadowedByList: S.Schema<RecordsListResultItemURIRecordMetaShadowedByList>;
export interface RecordsListResultItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsListResultItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsListResultItemURIRecordMeta: S.Schema<RecordsListResultItemURIRecordMeta>;
export type RecordsListResultItemURIRecordType = "URI";
export declare const RecordsListResultItemURIRecordType: any;
export interface RecordsListResultItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsListResultItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Record type. */
    type: RecordsListResultItemURIRecordType;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsListResultItemURIRecord: S.Schema<RecordsListResultItemURIRecord>;
export type RecordsListResultItem = RecordsListResultItemARecord | RecordsListResultItemAAAARecord | RecordsListResultItemCNAMERecord | RecordsListResultItemMXRecord | RecordsListResultItemNSRecord | RecordsListResultItemOpenpgpkeyRecord | RecordsListResultItemPTRRecord | RecordsListResultItemTXTRecord | RecordsListResultItemCAARecord | RecordsListResultItemCERTRecord | RecordsListResultItemDNSKEYRecord | RecordsListResultItemDSRecord | RecordsListResultItemHTTPSRecord | RecordsListResultItemLOCRecord | RecordsListResultItemNAPTRRecord | RecordsListResultItemSMIMEARecord | RecordsListResultItemSRVRecord | RecordsListResultItemSSHFPRecord | RecordsListResultItemSVCBRecord | RecordsListResultItemTLSARecord | RecordsListResultItemURIRecord;
export declare const RecordsListResultItem: any;
export type RecordsListResultList = Array<RecordsListResultItem>;
export declare const RecordsListResultList: S.Schema<RecordsListResultList>;
export interface ListRecordsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RecordsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRecordsResponse: S.Schema<ListRecordsResponse>;
export type SettingsAccountViewsListRequestDirection = "asc" | "desc";
export declare const SettingsAccountViewsListRequestDirection: any;
export type SettingsAccountViewsListRequestMatch = "any" | "all";
export declare const SettingsAccountViewsListRequestMatch: any;
export interface SettingsAccountViewsListRequestName {
    /** Substring of the DNS view name. */
    contains?: string;
    /** Suffix of the DNS view name. */
    endswith?: string;
    /** Exact value of the DNS view name. */
    exact?: string;
    /** Prefix of the DNS view name. */
    startswith?: string;
}
export declare const SettingsAccountViewsListRequestName: S.Schema<SettingsAccountViewsListRequestName>;
export type SettingsAccountViewsListRequestOrder = "name" | "created_on" | "modified_on";
export declare const SettingsAccountViewsListRequestOrder: any;
export interface ListSettingAccountViewsRequest {
    /** Identifier. */
    accountId: string;
    /** Direction to order DNS views in. */
    direction?: SettingsAccountViewsListRequestDirection | (string & {});
    /** Whether to match all search requirements or at least one (any). If set to `all`, acts like a logical AND between filters. If set to `any`, acts like a logical OR instead. */
    match?: SettingsAccountViewsListRequestMatch | (string & {});
    name?: SettingsAccountViewsListRequestName;
    /** Field to order DNS views by. */
    order?: SettingsAccountViewsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of DNS views per page. */
    perPage?: number;
    /** A zone ID that exists in the zones list for the view. */
    zoneId?: string;
    /** A zone name that exists in the zones list for the view. */
    zoneName?: string;
}
export declare const ListSettingAccountViewsRequest: S.Schema<ListSettingAccountViewsRequest>;
export type SettingsAccountViewsListResultItemZonesList = Array<string>;
export declare const SettingsAccountViewsListResultItemZonesList: S.Schema<SettingsAccountViewsListResultItemZonesList>;
export interface SettingsAccountViewsListResultItem {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsListResultItemZonesList;
}
export declare const SettingsAccountViewsListResultItem: S.Schema<SettingsAccountViewsListResultItem>;
export type SettingsAccountViewsListResultList = Array<SettingsAccountViewsListResultItem>;
export declare const SettingsAccountViewsListResultList: S.Schema<SettingsAccountViewsListResultList>;
export interface ListSettingAccountViewsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsAccountViewsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingAccountViewsResponse: S.Schema<ListSettingAccountViewsResponse>;
export interface ListZoneTransferAclsRequest {
    accountId: string;
}
export declare const ListZoneTransferAclsRequest: S.Schema<ListZoneTransferAclsRequest>;
export interface ZoneTransfersAclsListResultItem {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export declare const ZoneTransfersAclsListResultItem: S.Schema<ZoneTransfersAclsListResultItem>;
export type ZoneTransfersAclsListResultList = Array<ZoneTransfersAclsListResultItem>;
export declare const ZoneTransfersAclsListResultList: S.Schema<ZoneTransfersAclsListResultList>;
export interface ListZoneTransferAclsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ZoneTransfersAclsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListZoneTransferAclsResponse: S.Schema<ListZoneTransferAclsResponse>;
export interface ListZoneTransferPeersRequest {
    accountId: string;
}
export declare const ListZoneTransferPeersRequest: S.Schema<ListZoneTransferPeersRequest>;
export interface ZoneTransfersPeersListResultItem {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export declare const ZoneTransfersPeersListResultItem: S.Schema<ZoneTransfersPeersListResultItem>;
export type ZoneTransfersPeersListResultList = Array<ZoneTransfersPeersListResultItem>;
export declare const ZoneTransfersPeersListResultList: S.Schema<ZoneTransfersPeersListResultList>;
export interface ListZoneTransferPeersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ZoneTransfersPeersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListZoneTransferPeersResponse: S.Schema<ListZoneTransferPeersResponse>;
export interface ListZoneTransferTsigsRequest {
    accountId: string;
}
export declare const ListZoneTransferTsigsRequest: S.Schema<ListZoneTransferTsigsRequest>;
export interface ZoneTransfersTsigsListResultItem {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export declare const ZoneTransfersTsigsListResultItem: S.Schema<ZoneTransfersTsigsListResultItem>;
export type ZoneTransfersTsigsListResultList = Array<ZoneTransfersTsigsListResultItem>;
export declare const ZoneTransfersTsigsListResultList: S.Schema<ZoneTransfersTsigsListResultList>;
export interface ListZoneTransferTsigsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ZoneTransfersTsigsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListZoneTransferTsigsResponse: S.Schema<ListZoneTransferTsigsResponse>;
export type DnssecEditRequestStatus = "active" | "disabled";
export declare const DnssecEditRequestStatus: any;
export interface PatchDnssecRequest {
    /** Identifier. */
    zoneId: string;
    /** If true, multi-signer DNSSEC is enabled on the zone, allowing multiple */
    dnssecMultiSigner?: boolean;
    /** If true, allows Cloudflare to transfer in a DNSSEC-signed zone */
    dnssecPresigned?: boolean;
    /** If true, enables the use of NSEC3 together with DNSSEC on the zone. */
    dnssecUseNsec3?: boolean;
    /** Status of DNSSEC, based on user-desired state and presence of necessary records. */
    status?: DnssecEditRequestStatus | (string & {});
}
export declare const PatchDnssecRequest: S.Schema<PatchDnssecRequest>;
export type DnssecEditResponseStatus = "active" | "pending" | "disabled" | "pending-disabled" | "error";
export declare const DnssecEditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDnssecResponse {
    /** Algorithm key code. */
    algorithm?: string | null;
    /** Digest hash. */
    digest?: string | null;
    /** Type of digest algorithm. */
    digestAlgorithm?: string | null;
    /** Coded type for digest algorithm. */
    digestType?: string | null;
    /** If true, multi-signer DNSSEC is enabled on the zone, allowing multiple */
    dnssecMultiSigner?: boolean | null;
    /** If true, allows Cloudflare to transfer in a DNSSEC-signed zone */
    dnssecPresigned?: boolean | null;
    /** If true, enables the use of NSEC3 together with DNSSEC on the zone. */
    dnssecUseNsec3?: boolean | null;
    /** Full DS record. */
    ds?: string | null;
    /** Flag for DNSSEC record. */
    flags?: number | null;
    /** Code for key tag. */
    keyTag?: number | null;
    /** Algorithm key type. */
    keyType?: string | null;
    /** When DNSSEC was last modified. */
    modifiedOn?: string | null;
    /** Public key for DS record. */
    publicKey?: string | null;
    /** Status of DNSSEC, based on user-desired state and presence of necessary records. */
    status?: DnssecEditResponseStatus | null;
}
export declare const PatchDnssecResponse: S.Schema<PatchDnssecResponse>;
export type RecordsEditRequestType = "A" | "AAAA" | "CNAME" | "MX" | "NS" | "OPENPGPKEY" | "PTR" | "TXT" | "CAA" | "CERT" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "NAPTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export declare const RecordsEditRequestType: any;
export type RecordsEditRequestSettingsARecord = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsEditRequestSettingsARecord: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsEditRequestSettingsCNAMERecord = RecordsBatchRequestPostsItemCNAMERecordSettings;
export declare const RecordsEditRequestSettingsCNAMERecord: S.Schema<RecordsBatchRequestPostsItemCNAMERecordSettings>;
export type RecordsEditRequestSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings | RecordsBatchRequestPostsItemCNAMERecordSettings;
export declare const RecordsEditRequestSettings: any;
export type RecordsEditRequestTagsList = Array<unknown>;
export declare const RecordsEditRequestTagsList: S.Schema<RecordsEditRequestTagsList>;
export type RecordsEditRequestDataCAARecord = RecordsBatchRequestPostsItemCAARecordData;
export declare const RecordsEditRequestDataCAARecord: S.Schema<RecordsBatchRequestPostsItemCAARecordData>;
export type RecordsEditRequestDataCERTRecord = RecordsBatchRequestPostsItemCERTRecordData;
export declare const RecordsEditRequestDataCERTRecord: S.Schema<RecordsBatchRequestPostsItemCERTRecordData>;
export type RecordsEditRequestDataDNSKEYRecord = RecordsBatchRequestPostsItemDNSKEYRecordData;
export declare const RecordsEditRequestDataDNSKEYRecord: S.Schema<RecordsBatchRequestPostsItemDNSKEYRecordData>;
export type RecordsEditRequestDataDSRecord = RecordsBatchRequestPostsItemDSRecordData;
export declare const RecordsEditRequestDataDSRecord: S.Schema<RecordsBatchRequestPostsItemDSRecordData>;
export type RecordsEditRequestDataHTTPSRecord = RecordsBatchRequestPostsItemHTTPSRecordData;
export declare const RecordsEditRequestDataHTTPSRecord: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordData>;
export type RecordsEditRequestDataLOCRecordLatDirection = "N" | "S";
export declare const RecordsEditRequestDataLOCRecordLatDirection: any;
export type RecordsEditRequestDataLOCRecordLongDirection = "E" | "W";
export declare const RecordsEditRequestDataLOCRecordLongDirection: any;
export interface RecordsEditRequestDataLOCRecord {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsEditRequestDataLOCRecordLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsEditRequestDataLOCRecordLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export declare const RecordsEditRequestDataLOCRecord: S.Schema<RecordsEditRequestDataLOCRecord>;
export type RecordsEditRequestDataNAPTRRecord = RecordsBatchRequestPostsItemNAPTRRecordData;
export declare const RecordsEditRequestDataNAPTRRecord: S.Schema<RecordsBatchRequestPostsItemNAPTRRecordData>;
export type RecordsEditRequestDataSMIMEARecord = RecordsBatchRequestPostsItemSMIMEARecordData;
export declare const RecordsEditRequestDataSMIMEARecord: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordData>;
export type RecordsEditRequestDataSRVRecord = RecordsBatchRequestPostsItemSRVRecordData;
export declare const RecordsEditRequestDataSRVRecord: S.Schema<RecordsBatchRequestPostsItemSRVRecordData>;
export type RecordsEditRequestDataSSHFPRecord = RecordsBatchRequestPostsItemSSHFPRecordData;
export declare const RecordsEditRequestDataSSHFPRecord: S.Schema<RecordsBatchRequestPostsItemSSHFPRecordData>;
export type RecordsEditRequestDataURIRecord = RecordsBatchRequestPostsItemURIRecordData;
export declare const RecordsEditRequestDataURIRecord: S.Schema<RecordsBatchRequestPostsItemURIRecordData>;
export type RecordsEditRequestData = RecordsBatchRequestPostsItemCAARecordData | RecordsBatchRequestPostsItemCERTRecordData | RecordsBatchRequestPostsItemDNSKEYRecordData | RecordsBatchRequestPostsItemDSRecordData | RecordsBatchRequestPostsItemHTTPSRecordData | RecordsEditRequestDataLOCRecord | RecordsBatchRequestPostsItemNAPTRRecordData | RecordsBatchRequestPostsItemSMIMEARecordData | RecordsBatchRequestPostsItemSRVRecordData | RecordsBatchRequestPostsItemSSHFPRecordData | RecordsBatchRequestPostsItemURIRecordData;
export declare const RecordsEditRequestData: any;
export interface PatchRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsEditRequestType | (string & {});
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsEditRequestSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsEditRequestTagsList;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Components of a CAA record. */
    data?: RecordsEditRequestData;
}
export declare const PatchRecordRequest: S.Schema<PatchRecordRequest>;
export type RecordsEditResultARecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultARecordMetaShadowedByList: S.Schema<RecordsEditResultARecordMetaShadowedByList>;
export interface RecordsEditResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultARecordMeta: S.Schema<RecordsEditResultARecordMeta>;
export interface RecordsEditResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultARecord: S.Schema<RecordsEditResultARecord>;
export type RecordsEditResultAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultAAAARecordMetaShadowedByList: S.Schema<RecordsEditResultAAAARecordMetaShadowedByList>;
export interface RecordsEditResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultAAAARecordMeta: S.Schema<RecordsEditResultAAAARecordMeta>;
export interface RecordsEditResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultAAAARecord: S.Schema<RecordsEditResultAAAARecord>;
export type RecordsEditResultCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultCNAMERecordMetaShadowedByList: S.Schema<RecordsEditResultCNAMERecordMetaShadowedByList>;
export interface RecordsEditResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultCNAMERecordMeta: S.Schema<RecordsEditResultCNAMERecordMeta>;
export interface RecordsEditResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultCNAMERecord: S.Schema<RecordsEditResultCNAMERecord>;
export type RecordsEditResultMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultMXRecordMetaShadowedByList: S.Schema<RecordsEditResultMXRecordMetaShadowedByList>;
export interface RecordsEditResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultMXRecordMeta: S.Schema<RecordsEditResultMXRecordMeta>;
export interface RecordsEditResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultMXRecord: S.Schema<RecordsEditResultMXRecord>;
export type RecordsEditResultNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultNSRecordMetaShadowedByList: S.Schema<RecordsEditResultNSRecordMetaShadowedByList>;
export interface RecordsEditResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultNSRecordMeta: S.Schema<RecordsEditResultNSRecordMeta>;
export interface RecordsEditResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultNSRecord: S.Schema<RecordsEditResultNSRecord>;
export type RecordsEditResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsEditResultOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsEditResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultOpenpgpkeyRecordMeta: S.Schema<RecordsEditResultOpenpgpkeyRecordMeta>;
export type RecordsEditResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export declare const RecordsEditResultOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsEditResultOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsEditResultOpenpgpkeyRecordTagsList: S.Schema<RecordsEditResultOpenpgpkeyRecordTagsList>;
export type RecordsEditResultOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsEditResultOpenpgpkeyRecordType: any;
export interface RecordsEditResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsEditResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsEditResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsEditResultOpenpgpkeyRecord: S.Schema<RecordsEditResultOpenpgpkeyRecord>;
export type RecordsEditResultPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultPTRRecordMetaShadowedByList: S.Schema<RecordsEditResultPTRRecordMetaShadowedByList>;
export interface RecordsEditResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultPTRRecordMeta: S.Schema<RecordsEditResultPTRRecordMeta>;
export interface RecordsEditResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultPTRRecord: S.Schema<RecordsEditResultPTRRecord>;
export type RecordsEditResultTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultTXTRecordMetaShadowedByList: S.Schema<RecordsEditResultTXTRecordMetaShadowedByList>;
export interface RecordsEditResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultTXTRecordMeta: S.Schema<RecordsEditResultTXTRecordMeta>;
export interface RecordsEditResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultTXTRecord: S.Schema<RecordsEditResultTXTRecord>;
export type RecordsEditResultCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultCAARecordMetaShadowedByList: S.Schema<RecordsEditResultCAARecordMetaShadowedByList>;
export interface RecordsEditResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultCAARecordMeta: S.Schema<RecordsEditResultCAARecordMeta>;
export interface RecordsEditResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultCAARecord: S.Schema<RecordsEditResultCAARecord>;
export type RecordsEditResultCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultCERTRecordMetaShadowedByList: S.Schema<RecordsEditResultCERTRecordMetaShadowedByList>;
export interface RecordsEditResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultCERTRecordMeta: S.Schema<RecordsEditResultCERTRecordMeta>;
export interface RecordsEditResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultCERTRecord: S.Schema<RecordsEditResultCERTRecord>;
export type RecordsEditResultDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultDNSKEYRecordMetaShadowedByList: S.Schema<RecordsEditResultDNSKEYRecordMetaShadowedByList>;
export interface RecordsEditResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultDNSKEYRecordMeta: S.Schema<RecordsEditResultDNSKEYRecordMeta>;
export interface RecordsEditResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultDNSKEYRecord: S.Schema<RecordsEditResultDNSKEYRecord>;
export type RecordsEditResultDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultDSRecordMetaShadowedByList: S.Schema<RecordsEditResultDSRecordMetaShadowedByList>;
export interface RecordsEditResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultDSRecordMeta: S.Schema<RecordsEditResultDSRecordMeta>;
export interface RecordsEditResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultDSRecord: S.Schema<RecordsEditResultDSRecord>;
export type RecordsEditResultHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultHTTPSRecordMetaShadowedByList: S.Schema<RecordsEditResultHTTPSRecordMetaShadowedByList>;
export interface RecordsEditResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultHTTPSRecordMeta: S.Schema<RecordsEditResultHTTPSRecordMeta>;
export interface RecordsEditResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultHTTPSRecord: S.Schema<RecordsEditResultHTTPSRecord>;
export type RecordsEditResultLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultLOCRecordMetaShadowedByList: S.Schema<RecordsEditResultLOCRecordMetaShadowedByList>;
export interface RecordsEditResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultLOCRecordMeta: S.Schema<RecordsEditResultLOCRecordMeta>;
export interface RecordsEditResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultLOCRecord: S.Schema<RecordsEditResultLOCRecord>;
export type RecordsEditResultNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultNAPTRRecordMetaShadowedByList: S.Schema<RecordsEditResultNAPTRRecordMetaShadowedByList>;
export interface RecordsEditResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultNAPTRRecordMeta: S.Schema<RecordsEditResultNAPTRRecordMeta>;
export interface RecordsEditResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultNAPTRRecord: S.Schema<RecordsEditResultNAPTRRecord>;
export type RecordsEditResultSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultSMIMEARecordMetaShadowedByList: S.Schema<RecordsEditResultSMIMEARecordMetaShadowedByList>;
export interface RecordsEditResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultSMIMEARecordMeta: S.Schema<RecordsEditResultSMIMEARecordMeta>;
export interface RecordsEditResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultSMIMEARecord: S.Schema<RecordsEditResultSMIMEARecord>;
export type RecordsEditResultSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultSRVRecordMetaShadowedByList: S.Schema<RecordsEditResultSRVRecordMetaShadowedByList>;
export interface RecordsEditResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultSRVRecordMeta: S.Schema<RecordsEditResultSRVRecordMeta>;
export interface RecordsEditResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultSRVRecord: S.Schema<RecordsEditResultSRVRecord>;
export type RecordsEditResultSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultSSHFPRecordMetaShadowedByList: S.Schema<RecordsEditResultSSHFPRecordMetaShadowedByList>;
export interface RecordsEditResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultSSHFPRecordMeta: S.Schema<RecordsEditResultSSHFPRecordMeta>;
export interface RecordsEditResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultSSHFPRecord: S.Schema<RecordsEditResultSSHFPRecord>;
export type RecordsEditResultSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultSVCBRecordMetaShadowedByList: S.Schema<RecordsEditResultSVCBRecordMetaShadowedByList>;
export interface RecordsEditResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultSVCBRecordMeta: S.Schema<RecordsEditResultSVCBRecordMeta>;
export interface RecordsEditResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultSVCBRecord: S.Schema<RecordsEditResultSVCBRecord>;
export type RecordsEditResultTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultTLSARecordMetaShadowedByList: S.Schema<RecordsEditResultTLSARecordMetaShadowedByList>;
export interface RecordsEditResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultTLSARecordMeta: S.Schema<RecordsEditResultTLSARecordMeta>;
export interface RecordsEditResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultTLSARecord: S.Schema<RecordsEditResultTLSARecord>;
export type RecordsEditResultURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsEditResultURIRecordMetaShadowedByList: S.Schema<RecordsEditResultURIRecordMetaShadowedByList>;
export interface RecordsEditResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsEditResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsEditResultURIRecordMeta: S.Schema<RecordsEditResultURIRecordMeta>;
export interface RecordsEditResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsEditResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsEditResultURIRecord: S.Schema<RecordsEditResultURIRecord>;
export type RecordsEditResult = RecordsEditResultARecord | RecordsEditResultAAAARecord | RecordsEditResultCNAMERecord | RecordsEditResultMXRecord | RecordsEditResultNSRecord | RecordsEditResultOpenpgpkeyRecord | RecordsEditResultPTRRecord | RecordsEditResultTXTRecord | RecordsEditResultCAARecord | RecordsEditResultCERTRecord | RecordsEditResultDNSKEYRecord | RecordsEditResultDSRecord | RecordsEditResultHTTPSRecord | RecordsEditResultLOCRecord | RecordsEditResultNAPTRRecord | RecordsEditResultSMIMEARecord | RecordsEditResultSRVRecord | RecordsEditResultSSHFPRecord | RecordsEditResultSVCBRecord | RecordsEditResultTLSARecord | RecordsEditResultURIRecord;
export declare const RecordsEditResult: any;
export type PatchRecordResponse = RecordsEditResult;
export declare const PatchRecordResponse: S.Schema<PatchRecordResponse>;
export interface SettingsAccountEditRequestZoneDefaultsInternalDns {
    /** The ID of the zone to fallback to. */
    referenceZoneId?: string;
}
export declare const SettingsAccountEditRequestZoneDefaultsInternalDns: S.Schema<SettingsAccountEditRequestZoneDefaultsInternalDns>;
export type SettingsAccountEditRequestZoneDefaultsNameserversType = "cloudflare.standard" | "cloudflare.standard.random" | "custom.account" | "custom.tenant";
export declare const SettingsAccountEditRequestZoneDefaultsNameserversType: any;
export interface SettingsAccountEditRequestZoneDefaultsNameservers {
    /** Nameserver type */
    type?: SettingsAccountEditRequestZoneDefaultsNameserversType | (string & {});
}
export declare const SettingsAccountEditRequestZoneDefaultsNameservers: S.Schema<SettingsAccountEditRequestZoneDefaultsNameservers>;
export interface SettingsAccountEditRequestZoneDefaultsSoa {
    /** Time in seconds of being unable to query the primary server after which secondary servers should stop serving the zone. */
    expire?: number;
    /** The time to live (TTL) for negative caching of records within the zone. */
    minTtl?: number;
    /** The primary nameserver, which may be used for outbound zone transfers. If null, a Cloudflare-assigned value will be used. */
    mname?: string;
    /** Time in seconds after which secondary servers should re-check the SOA record to see if the zone has been updated. */
    refresh?: number;
    /** Time in seconds after which secondary servers should retry queries after the primary server was unresponsive. */
    retry?: number;
    /** The email address of the zone administrator, with the first label representing the local part of the email address. */
    rname?: string;
    /** The time to live (TTL) of the SOA record itself. */
    ttl?: number;
}
export declare const SettingsAccountEditRequestZoneDefaultsSoa: S.Schema<SettingsAccountEditRequestZoneDefaultsSoa>;
export type SettingsAccountEditRequestZoneDefaultsZoneMode = "standard" | "cdn_only" | "dns_only";
export declare const SettingsAccountEditRequestZoneDefaultsZoneMode: any;
export interface SettingsAccountEditRequestZoneDefaults {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames?: boolean;
    /** Whether to enable Foundation DNS Advanced Nameservers on the zone. */
    foundationDns?: boolean;
    /** Settings for this internal zone. */
    internalDns?: SettingsAccountEditRequestZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider?: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers?: SettingsAccountEditRequestZoneDefaultsNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl?: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides?: boolean;
    /** Components of the zone's SOA record. */
    soa?: SettingsAccountEditRequestZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode?: SettingsAccountEditRequestZoneDefaultsZoneMode | (string & {});
}
export declare const SettingsAccountEditRequestZoneDefaults: S.Schema<SettingsAccountEditRequestZoneDefaults>;
export interface PatchSettingAccountRequest {
    /** Identifier. */
    accountId: string;
    /** When enabled, forces all proxied DNS records in the account to behave as DNS-only at the edge, regardless of each record's individual proxy setting. Note that this account-level override does not modify the records themselves; it only affects how they are served at the edge. See more on [Enforce DNS-only](https://developers.cloudflare.com/dns/proxy-status/enforce-dns-only). */
    enforceDnsOnly?: boolean;
    zoneDefaults?: SettingsAccountEditRequestZoneDefaults;
}
export declare const PatchSettingAccountRequest: S.Schema<PatchSettingAccountRequest>;
export type SettingsAccountEditResponseZoneDefaultsInternalDns = SettingsAccountGetResponseZoneDefaultsInternalDns;
export declare const SettingsAccountEditResponseZoneDefaultsInternalDns: S.Schema<SettingsAccountGetResponseZoneDefaultsInternalDns>;
export type SettingsAccountEditResponseZoneDefaultsNameserversType = "cloudflare.standard" | "cloudflare.standard.random" | "custom.account" | "custom.tenant";
export declare const SettingsAccountEditResponseZoneDefaultsNameserversType: any;
export interface SettingsAccountEditResponseZoneDefaultsNameservers {
    /** Nameserver type */
    type: SettingsAccountEditResponseZoneDefaultsNameserversType;
}
export declare const SettingsAccountEditResponseZoneDefaultsNameservers: S.Schema<SettingsAccountEditResponseZoneDefaultsNameservers>;
export type SettingsAccountEditResponseZoneDefaultsSoa = SettingsAccountGetResponseZoneDefaultsSoa;
export declare const SettingsAccountEditResponseZoneDefaultsSoa: S.Schema<SettingsAccountGetResponseZoneDefaultsSoa>;
export type SettingsAccountEditResponseZoneDefaultsZoneMode = "standard" | "cdn_only" | "dns_only";
export declare const SettingsAccountEditResponseZoneDefaultsZoneMode: any;
export interface SettingsAccountEditResponseZoneDefaults {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** Whether to enable Foundation DNS Advanced Nameservers on the zone. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers: SettingsAccountEditResponseZoneDefaultsNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsAccountEditResponseZoneDefaultsZoneMode;
}
export declare const SettingsAccountEditResponseZoneDefaults: S.Schema<SettingsAccountEditResponseZoneDefaults>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingAccountResponse {
    zoneDefaults: SettingsAccountEditResponseZoneDefaults;
    /** When enabled, forces all proxied DNS records in the account to behave as DNS-only at the edge, regardless of each record's individual proxy setting. Note that this account-level override does not modify the records themselves; it only affects how they are served at the edge. See more on [Enforce DNS-only](https://developers.cloudflare.com/dns/proxy-status/enforce-dns-only). */
    enforceDnsOnly?: boolean | null;
}
export declare const PatchSettingAccountResponse: S.Schema<PatchSettingAccountResponse>;
export type SettingsAccountViewsEditRequestZonesList = Array<string>;
export declare const SettingsAccountViewsEditRequestZonesList: S.Schema<SettingsAccountViewsEditRequestZonesList>;
export interface PatchSettingAccountViewRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    viewId: string;
    /** The name of the view. */
    name?: string;
    /** The list of zones linked to this view. */
    zones?: SettingsAccountViewsEditRequestZonesList;
}
export declare const PatchSettingAccountViewRequest: S.Schema<PatchSettingAccountViewRequest>;
export type SettingsAccountViewsEditResponseZonesList = Array<string>;
export declare const SettingsAccountViewsEditResponseZonesList: S.Schema<SettingsAccountViewsEditResponseZonesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingAccountViewResponse {
    /** Identifier. */
    id: string;
    /** When the view was created. */
    createdTime: string;
    /** When the view was last modified. */
    modifiedTime: string;
    /** The name of the view. */
    name: string;
    /** The list of zones linked to this view. */
    zones: SettingsAccountViewsEditResponseZonesList;
}
export declare const PatchSettingAccountViewResponse: S.Schema<PatchSettingAccountViewResponse>;
export type SettingsZoneEditRequestInternalDns = SettingsAccountEditRequestZoneDefaultsInternalDns;
export declare const SettingsZoneEditRequestInternalDns: S.Schema<SettingsAccountEditRequestZoneDefaultsInternalDns>;
export type SettingsZoneEditRequestNameserversType = "cloudflare.standard" | "custom.account" | "custom.tenant" | "custom.zone";
export declare const SettingsZoneEditRequestNameserversType: any;
export interface SettingsZoneEditRequestNameservers {
    /** Configured nameserver set to be used for this zone */
    nsSet?: number;
    /** Nameserver type */
    type?: SettingsZoneEditRequestNameserversType | (string & {});
}
export declare const SettingsZoneEditRequestNameservers: S.Schema<SettingsZoneEditRequestNameservers>;
export type SettingsZoneEditRequestSoa = SettingsAccountEditRequestZoneDefaultsSoa;
export declare const SettingsZoneEditRequestSoa: S.Schema<SettingsAccountEditRequestZoneDefaultsSoa>;
export type SettingsZoneEditRequestZoneMode = "standard" | "cdn_only" | "dns_only";
export declare const SettingsZoneEditRequestZoneMode: any;
export interface PatchSettingZoneRequest {
    /** Identifier. */
    zoneId: string;
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames?: boolean;
    /** Whether to enable Foundation DNS Advanced Nameservers on the zone. */
    foundationDns?: boolean;
    /** Settings for this internal zone. */
    internalDns?: SettingsAccountEditRequestZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider?: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers?: SettingsZoneEditRequestNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl?: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides?: boolean;
    /** Components of the zone's SOA record. */
    soa?: SettingsAccountEditRequestZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode?: SettingsZoneEditRequestZoneMode | (string & {});
}
export declare const PatchSettingZoneRequest: S.Schema<PatchSettingZoneRequest>;
export type SettingsZoneEditResponseInternalDns = SettingsAccountGetResponseZoneDefaultsInternalDns;
export declare const SettingsZoneEditResponseInternalDns: S.Schema<SettingsAccountGetResponseZoneDefaultsInternalDns>;
export type SettingsZoneEditResponseNameserversType = "cloudflare.standard" | "custom.account" | "custom.tenant" | "custom.zone";
export declare const SettingsZoneEditResponseNameserversType: any;
export interface SettingsZoneEditResponseNameservers {
    /** Nameserver type */
    type: SettingsZoneEditResponseNameserversType;
    /** Configured nameserver set to be used for this zone */
    nsSet?: number | null;
}
export declare const SettingsZoneEditResponseNameservers: S.Schema<SettingsZoneEditResponseNameservers>;
export type SettingsZoneEditResponseSoa = SettingsAccountGetResponseZoneDefaultsSoa;
export declare const SettingsZoneEditResponseSoa: S.Schema<SettingsAccountGetResponseZoneDefaultsSoa>;
export type SettingsZoneEditResponseZoneMode = "standard" | "cdn_only" | "dns_only";
export declare const SettingsZoneEditResponseZoneMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingZoneResponse {
    /** Whether to flatten all CNAME records in the zone. Note that, due to DNS limitations, a CNAME record at the zone apex will always be flattened. */
    flattenAllCnames: boolean;
    /** Whether to enable Foundation DNS Advanced Nameservers on the zone. */
    foundationDns: boolean;
    /** Settings for this internal zone. */
    internalDns: SettingsAccountGetResponseZoneDefaultsInternalDns;
    /** Whether to enable multi-provider DNS, which causes Cloudflare to activate the zone even when non-Cloudflare NS records exist, and to respect NS records at the zone apex during outbound zone transfers. */
    multiProvider: boolean;
    /** Settings determining the nameservers through which the zone should be available. */
    nameservers: SettingsZoneEditResponseNameservers;
    /** The time to live (TTL) of the zone's nameserver (NS) records. */
    nsTtl: number;
    /** Allows a Secondary DNS zone to use (proxied) override records and CNAME flattening at the zone apex. */
    secondaryOverrides: boolean;
    /** Components of the zone's SOA record. */
    soa: SettingsAccountGetResponseZoneDefaultsSoa;
    /** Whether the zone mode is a regular or CDN/DNS only zone. */
    zoneMode: SettingsZoneEditResponseZoneMode;
}
export declare const PatchSettingZoneResponse: S.Schema<PatchSettingZoneResponse>;
export interface ScanListRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ScanListRecordRequest: S.Schema<ScanListRecordRequest>;
export type RecordsScanListResultItemARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemARecordMetaShadowedByList: S.Schema<RecordsScanListResultItemARecordMetaShadowedByList>;
export interface RecordsScanListResultItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemARecordMeta: S.Schema<RecordsScanListResultItemARecordMeta>;
export interface RecordsScanListResultItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemARecord: S.Schema<RecordsScanListResultItemARecord>;
export type RecordsScanListResultItemAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemAAAARecordMetaShadowedByList: S.Schema<RecordsScanListResultItemAAAARecordMetaShadowedByList>;
export interface RecordsScanListResultItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemAAAARecordMeta: S.Schema<RecordsScanListResultItemAAAARecordMeta>;
export interface RecordsScanListResultItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemAAAARecord: S.Schema<RecordsScanListResultItemAAAARecord>;
export type RecordsScanListResultItemCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemCNAMERecordMetaShadowedByList: S.Schema<RecordsScanListResultItemCNAMERecordMetaShadowedByList>;
export interface RecordsScanListResultItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemCNAMERecordMeta: S.Schema<RecordsScanListResultItemCNAMERecordMeta>;
export interface RecordsScanListResultItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemCNAMERecord: S.Schema<RecordsScanListResultItemCNAMERecord>;
export type RecordsScanListResultItemMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemMXRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemMXRecordMetaShadowedByList>;
export interface RecordsScanListResultItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemMXRecordMeta: S.Schema<RecordsScanListResultItemMXRecordMeta>;
export interface RecordsScanListResultItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemMXRecord: S.Schema<RecordsScanListResultItemMXRecord>;
export type RecordsScanListResultItemNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemNSRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemNSRecordMetaShadowedByList>;
export interface RecordsScanListResultItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemNSRecordMeta: S.Schema<RecordsScanListResultItemNSRecordMeta>;
export interface RecordsScanListResultItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemNSRecord: S.Schema<RecordsScanListResultItemNSRecord>;
export type RecordsScanListResultItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsScanListResultItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemOpenpgpkeyRecordMeta: S.Schema<RecordsScanListResultItemOpenpgpkeyRecordMeta>;
export type RecordsScanListResultItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanListResultItemOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsScanListResultItemOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsScanListResultItemOpenpgpkeyRecordTagsList: S.Schema<RecordsScanListResultItemOpenpgpkeyRecordTagsList>;
export type RecordsScanListResultItemOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsScanListResultItemOpenpgpkeyRecordType: any;
export interface RecordsScanListResultItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsScanListResultItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanListResultItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanListResultItemOpenpgpkeyRecord: S.Schema<RecordsScanListResultItemOpenpgpkeyRecord>;
export type RecordsScanListResultItemPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemPTRRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemPTRRecordMetaShadowedByList>;
export interface RecordsScanListResultItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemPTRRecordMeta: S.Schema<RecordsScanListResultItemPTRRecordMeta>;
export interface RecordsScanListResultItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemPTRRecord: S.Schema<RecordsScanListResultItemPTRRecord>;
export type RecordsScanListResultItemTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemTXTRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemTXTRecordMetaShadowedByList>;
export interface RecordsScanListResultItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemTXTRecordMeta: S.Schema<RecordsScanListResultItemTXTRecordMeta>;
export interface RecordsScanListResultItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemTXTRecord: S.Schema<RecordsScanListResultItemTXTRecord>;
export type RecordsScanListResultItemCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemCAARecordMetaShadowedByList: S.Schema<RecordsScanListResultItemCAARecordMetaShadowedByList>;
export interface RecordsScanListResultItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemCAARecordMeta: S.Schema<RecordsScanListResultItemCAARecordMeta>;
export interface RecordsScanListResultItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemCAARecord: S.Schema<RecordsScanListResultItemCAARecord>;
export type RecordsScanListResultItemCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemCERTRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemCERTRecordMetaShadowedByList>;
export interface RecordsScanListResultItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemCERTRecordMeta: S.Schema<RecordsScanListResultItemCERTRecordMeta>;
export interface RecordsScanListResultItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemCERTRecord: S.Schema<RecordsScanListResultItemCERTRecord>;
export type RecordsScanListResultItemDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemDNSKEYRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemDNSKEYRecordMetaShadowedByList>;
export interface RecordsScanListResultItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemDNSKEYRecordMeta: S.Schema<RecordsScanListResultItemDNSKEYRecordMeta>;
export interface RecordsScanListResultItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemDNSKEYRecord: S.Schema<RecordsScanListResultItemDNSKEYRecord>;
export type RecordsScanListResultItemDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemDSRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemDSRecordMetaShadowedByList>;
export interface RecordsScanListResultItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemDSRecordMeta: S.Schema<RecordsScanListResultItemDSRecordMeta>;
export interface RecordsScanListResultItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemDSRecord: S.Schema<RecordsScanListResultItemDSRecord>;
export type RecordsScanListResultItemHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemHTTPSRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemHTTPSRecordMetaShadowedByList>;
export interface RecordsScanListResultItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemHTTPSRecordMeta: S.Schema<RecordsScanListResultItemHTTPSRecordMeta>;
export interface RecordsScanListResultItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemHTTPSRecord: S.Schema<RecordsScanListResultItemHTTPSRecord>;
export type RecordsScanListResultItemLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemLOCRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemLOCRecordMetaShadowedByList>;
export interface RecordsScanListResultItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemLOCRecordMeta: S.Schema<RecordsScanListResultItemLOCRecordMeta>;
export interface RecordsScanListResultItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemLOCRecord: S.Schema<RecordsScanListResultItemLOCRecord>;
export type RecordsScanListResultItemNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemNAPTRRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemNAPTRRecordMetaShadowedByList>;
export interface RecordsScanListResultItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemNAPTRRecordMeta: S.Schema<RecordsScanListResultItemNAPTRRecordMeta>;
export interface RecordsScanListResultItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemNAPTRRecord: S.Schema<RecordsScanListResultItemNAPTRRecord>;
export type RecordsScanListResultItemSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemSMIMEARecordMetaShadowedByList: S.Schema<RecordsScanListResultItemSMIMEARecordMetaShadowedByList>;
export interface RecordsScanListResultItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemSMIMEARecordMeta: S.Schema<RecordsScanListResultItemSMIMEARecordMeta>;
export interface RecordsScanListResultItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemSMIMEARecord: S.Schema<RecordsScanListResultItemSMIMEARecord>;
export type RecordsScanListResultItemSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemSRVRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemSRVRecordMetaShadowedByList>;
export interface RecordsScanListResultItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemSRVRecordMeta: S.Schema<RecordsScanListResultItemSRVRecordMeta>;
export interface RecordsScanListResultItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemSRVRecord: S.Schema<RecordsScanListResultItemSRVRecord>;
export type RecordsScanListResultItemSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemSSHFPRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemSSHFPRecordMetaShadowedByList>;
export interface RecordsScanListResultItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemSSHFPRecordMeta: S.Schema<RecordsScanListResultItemSSHFPRecordMeta>;
export interface RecordsScanListResultItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemSSHFPRecord: S.Schema<RecordsScanListResultItemSSHFPRecord>;
export type RecordsScanListResultItemSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemSVCBRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemSVCBRecordMetaShadowedByList>;
export interface RecordsScanListResultItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemSVCBRecordMeta: S.Schema<RecordsScanListResultItemSVCBRecordMeta>;
export interface RecordsScanListResultItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemSVCBRecord: S.Schema<RecordsScanListResultItemSVCBRecord>;
export type RecordsScanListResultItemTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemTLSARecordMetaShadowedByList: S.Schema<RecordsScanListResultItemTLSARecordMetaShadowedByList>;
export interface RecordsScanListResultItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemTLSARecordMeta: S.Schema<RecordsScanListResultItemTLSARecordMeta>;
export interface RecordsScanListResultItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemTLSARecord: S.Schema<RecordsScanListResultItemTLSARecord>;
export type RecordsScanListResultItemURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanListResultItemURIRecordMetaShadowedByList: S.Schema<RecordsScanListResultItemURIRecordMetaShadowedByList>;
export interface RecordsScanListResultItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanListResultItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanListResultItemURIRecordMeta: S.Schema<RecordsScanListResultItemURIRecordMeta>;
export interface RecordsScanListResultItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanListResultItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsScanListResultItemURIRecord: S.Schema<RecordsScanListResultItemURIRecord>;
export type RecordsScanListResultItem = RecordsScanListResultItemARecord | RecordsScanListResultItemAAAARecord | RecordsScanListResultItemCNAMERecord | RecordsScanListResultItemMXRecord | RecordsScanListResultItemNSRecord | RecordsScanListResultItemOpenpgpkeyRecord | RecordsScanListResultItemPTRRecord | RecordsScanListResultItemTXTRecord | RecordsScanListResultItemCAARecord | RecordsScanListResultItemCERTRecord | RecordsScanListResultItemDNSKEYRecord | RecordsScanListResultItemDSRecord | RecordsScanListResultItemHTTPSRecord | RecordsScanListResultItemLOCRecord | RecordsScanListResultItemNAPTRRecord | RecordsScanListResultItemSMIMEARecord | RecordsScanListResultItemSRVRecord | RecordsScanListResultItemSSHFPRecord | RecordsScanListResultItemSVCBRecord | RecordsScanListResultItemTLSARecord | RecordsScanListResultItemURIRecord;
export declare const RecordsScanListResultItem: any;
export type RecordsScanListResultList = Array<RecordsScanListResultItem>;
export declare const RecordsScanListResultList: S.Schema<RecordsScanListResultList>;
export interface ScanListRecordResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RecordsScanListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ScanListRecordResponse: S.Schema<ScanListRecordResponse>;
export interface ScanRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ScanRecordRequest: S.Schema<ScanRecordRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ScanRecordResponse {
    /** Number of DNS records added. */
    recsAdded?: number | null;
    /** Total number of DNS records parsed. */
    totalRecordsParsed?: number | null;
}
export declare const ScanRecordResponse: S.Schema<ScanRecordResponse>;
export type RecordsScanReviewRequestAcceptsItemARecordType = "A";
export declare const RecordsScanReviewRequestAcceptsItemARecordType: any;
export type RecordsScanReviewRequestAcceptsItemARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemARecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemARecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemARecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemARecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemARecord: S.Schema<RecordsScanReviewRequestAcceptsItemARecord>;
export type RecordsScanReviewRequestAcceptsItemAAAARecordType = "AAAA";
export declare const RecordsScanReviewRequestAcceptsItemAAAARecordType: any;
export type RecordsScanReviewRequestAcceptsItemAAAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemAAAARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemAAAARecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemAAAARecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemAAAARecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemAAAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemAAAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv6 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemAAAARecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemAAAARecord: S.Schema<RecordsScanReviewRequestAcceptsItemAAAARecord>;
export type RecordsScanReviewRequestAcceptsItemCNAMERecordType = "CNAME";
export declare const RecordsScanReviewRequestAcceptsItemCNAMERecordType: any;
export type RecordsScanReviewRequestAcceptsItemCNAMERecordSettings = RecordsBatchRequestPostsItemCNAMERecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemCNAMERecordSettings: S.Schema<RecordsBatchRequestPostsItemCNAMERecordSettings>;
export type RecordsScanReviewRequestAcceptsItemCNAMERecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemCNAMERecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemCNAMERecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemCNAMERecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemCNAMERecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid hostname. Must not match the record's name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPostsItemCNAMERecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemCNAMERecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemCNAMERecord: S.Schema<RecordsScanReviewRequestAcceptsItemCNAMERecord>;
export type RecordsScanReviewRequestAcceptsItemMXRecordType = "MX";
export declare const RecordsScanReviewRequestAcceptsItemMXRecordType: any;
export type RecordsScanReviewRequestAcceptsItemMXRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemMXRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemMXRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemMXRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemMXRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemMXRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemMXRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid mail server hostname. */
    content?: string;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemMXRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemMXRecord: S.Schema<RecordsScanReviewRequestAcceptsItemMXRecord>;
export type RecordsScanReviewRequestAcceptsItemNSRecordType = "NS";
export declare const RecordsScanReviewRequestAcceptsItemNSRecordType: any;
export type RecordsScanReviewRequestAcceptsItemNSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemNSRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemNSRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemNSRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemNSRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemNSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemNSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid name server host name. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemNSRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemNSRecord: S.Schema<RecordsScanReviewRequestAcceptsItemNSRecord>;
export type RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordType: any;
export type RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecord: S.Schema<RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecord>;
export type RecordsScanReviewRequestAcceptsItemPTRRecordType = "PTR";
export declare const RecordsScanReviewRequestAcceptsItemPTRRecordType: any;
export type RecordsScanReviewRequestAcceptsItemPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemPTRRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemPTRRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemPTRRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemPTRRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Domain name pointing to the address. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemPTRRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemPTRRecord: S.Schema<RecordsScanReviewRequestAcceptsItemPTRRecord>;
export type RecordsScanReviewRequestAcceptsItemTXTRecordType = "TXT";
export declare const RecordsScanReviewRequestAcceptsItemTXTRecordType: any;
export type RecordsScanReviewRequestAcceptsItemTXTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemTXTRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemTXTRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemTXTRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemTXTRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemTXTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemTXTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Text content for the record. The content must consist of quoted "character strings" (RFC 1035), each with a length of up to 255 bytes. Strings exceeding this allowed maximum length are automatically split. */
    content?: string;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemTXTRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemTXTRecord: S.Schema<RecordsScanReviewRequestAcceptsItemTXTRecord>;
export type RecordsScanReviewRequestAcceptsItemCAARecordType = "CAA";
export declare const RecordsScanReviewRequestAcceptsItemCAARecordType: any;
export type RecordsScanReviewRequestAcceptsItemCAARecordData = RecordsBatchRequestPostsItemCAARecordData;
export declare const RecordsScanReviewRequestAcceptsItemCAARecordData: S.Schema<RecordsBatchRequestPostsItemCAARecordData>;
export type RecordsScanReviewRequestAcceptsItemCAARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemCAARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemCAARecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemCAARecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemCAARecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemCAARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemCAARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CAA content. See 'data' to set CAA properties. */
    content?: string;
    /** Components of a CAA record. */
    data?: RecordsBatchRequestPostsItemCAARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemCAARecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemCAARecord: S.Schema<RecordsScanReviewRequestAcceptsItemCAARecord>;
export type RecordsScanReviewRequestAcceptsItemCERTRecordType = "CERT";
export declare const RecordsScanReviewRequestAcceptsItemCERTRecordType: any;
export type RecordsScanReviewRequestAcceptsItemCERTRecordData = RecordsBatchRequestPostsItemCERTRecordData;
export declare const RecordsScanReviewRequestAcceptsItemCERTRecordData: S.Schema<RecordsBatchRequestPostsItemCERTRecordData>;
export type RecordsScanReviewRequestAcceptsItemCERTRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemCERTRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemCERTRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemCERTRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemCERTRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemCERTRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemCERTRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted CERT content. See 'data' to set CERT properties. */
    content?: string;
    /** Components of a CERT record. */
    data?: RecordsBatchRequestPostsItemCERTRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemCERTRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemCERTRecord: S.Schema<RecordsScanReviewRequestAcceptsItemCERTRecord>;
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordType = "DNSKEY";
export declare const RecordsScanReviewRequestAcceptsItemDNSKEYRecordType: any;
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordData = RecordsBatchRequestPostsItemDNSKEYRecordData;
export declare const RecordsScanReviewRequestAcceptsItemDNSKEYRecordData: S.Schema<RecordsBatchRequestPostsItemDNSKEYRecordData>;
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemDNSKEYRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemDNSKEYRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemDNSKEYRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemDNSKEYRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemDNSKEYRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemDNSKEYRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DNSKEY content. See 'data' to set DNSKEY properties. */
    content?: string;
    /** Components of a DNSKEY record. */
    data?: RecordsBatchRequestPostsItemDNSKEYRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemDNSKEYRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemDNSKEYRecord: S.Schema<RecordsScanReviewRequestAcceptsItemDNSKEYRecord>;
export type RecordsScanReviewRequestAcceptsItemDSRecordType = "DS";
export declare const RecordsScanReviewRequestAcceptsItemDSRecordType: any;
export type RecordsScanReviewRequestAcceptsItemDSRecordData = RecordsBatchRequestPostsItemDSRecordData;
export declare const RecordsScanReviewRequestAcceptsItemDSRecordData: S.Schema<RecordsBatchRequestPostsItemDSRecordData>;
export type RecordsScanReviewRequestAcceptsItemDSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemDSRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemDSRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemDSRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemDSRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemDSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemDSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted DS content. See 'data' to set DS properties. */
    content?: string;
    /** Components of a DS record. */
    data?: RecordsBatchRequestPostsItemDSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemDSRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemDSRecord: S.Schema<RecordsScanReviewRequestAcceptsItemDSRecord>;
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordType = "HTTPS";
export declare const RecordsScanReviewRequestAcceptsItemHTTPSRecordType: any;
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordData = RecordsBatchRequestPostsItemHTTPSRecordData;
export declare const RecordsScanReviewRequestAcceptsItemHTTPSRecordData: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordData>;
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemHTTPSRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemHTTPSRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemHTTPSRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemHTTPSRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemHTTPSRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemHTTPSRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted HTTPS content. See 'data' to set HTTPS properties. */
    content?: string;
    /** Components of a HTTPS record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemHTTPSRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemHTTPSRecord: S.Schema<RecordsScanReviewRequestAcceptsItemHTTPSRecord>;
export type RecordsScanReviewRequestAcceptsItemLOCRecordType = "LOC";
export declare const RecordsScanReviewRequestAcceptsItemLOCRecordType: any;
export type RecordsScanReviewRequestAcceptsItemLOCRecordDataLatDirection = "N" | "S";
export declare const RecordsScanReviewRequestAcceptsItemLOCRecordDataLatDirection: any;
export type RecordsScanReviewRequestAcceptsItemLOCRecordDataLongDirection = "E" | "W";
export declare const RecordsScanReviewRequestAcceptsItemLOCRecordDataLongDirection: any;
export interface RecordsScanReviewRequestAcceptsItemLOCRecordData {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsScanReviewRequestAcceptsItemLOCRecordDataLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsScanReviewRequestAcceptsItemLOCRecordDataLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export declare const RecordsScanReviewRequestAcceptsItemLOCRecordData: S.Schema<RecordsScanReviewRequestAcceptsItemLOCRecordData>;
export type RecordsScanReviewRequestAcceptsItemLOCRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemLOCRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemLOCRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemLOCRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemLOCRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemLOCRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemLOCRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted LOC content. See 'data' to set LOC properties. */
    content?: string;
    /** Components of a LOC record. */
    data?: RecordsScanReviewRequestAcceptsItemLOCRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemLOCRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemLOCRecord: S.Schema<RecordsScanReviewRequestAcceptsItemLOCRecord>;
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordType = "NAPTR";
export declare const RecordsScanReviewRequestAcceptsItemNAPTRRecordType: any;
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordData = RecordsBatchRequestPostsItemNAPTRRecordData;
export declare const RecordsScanReviewRequestAcceptsItemNAPTRRecordData: S.Schema<RecordsBatchRequestPostsItemNAPTRRecordData>;
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemNAPTRRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemNAPTRRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemNAPTRRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemNAPTRRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemNAPTRRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemNAPTRRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted NAPTR content. See 'data' to set NAPTR properties. */
    content?: string;
    /** Components of a NAPTR record. */
    data?: RecordsBatchRequestPostsItemNAPTRRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemNAPTRRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemNAPTRRecord: S.Schema<RecordsScanReviewRequestAcceptsItemNAPTRRecord>;
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordType = "SMIMEA";
export declare const RecordsScanReviewRequestAcceptsItemSMIMEARecordType: any;
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordData = RecordsBatchRequestPostsItemSMIMEARecordData;
export declare const RecordsScanReviewRequestAcceptsItemSMIMEARecordData: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordData>;
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemSMIMEARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemSMIMEARecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemSMIMEARecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemSMIMEARecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemSMIMEARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSMIMEARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SMIMEA content. See 'data' to set SMIMEA properties. */
    content?: string;
    /** Components of a SMIMEA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSMIMEARecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemSMIMEARecord: S.Schema<RecordsScanReviewRequestAcceptsItemSMIMEARecord>;
export type RecordsScanReviewRequestAcceptsItemSRVRecordType = "SRV";
export declare const RecordsScanReviewRequestAcceptsItemSRVRecordType: any;
export type RecordsScanReviewRequestAcceptsItemSRVRecordData = RecordsBatchRequestPostsItemSRVRecordData;
export declare const RecordsScanReviewRequestAcceptsItemSRVRecordData: S.Schema<RecordsBatchRequestPostsItemSRVRecordData>;
export type RecordsScanReviewRequestAcceptsItemSRVRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemSRVRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemSRVRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemSRVRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemSRVRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemSRVRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSRVRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Priority, weight, port, and SRV target. See 'data' for setting the individual component values. */
    content?: string;
    /** Components of a SRV record. */
    data?: RecordsBatchRequestPostsItemSRVRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSRVRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemSRVRecord: S.Schema<RecordsScanReviewRequestAcceptsItemSRVRecord>;
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordType = "SSHFP";
export declare const RecordsScanReviewRequestAcceptsItemSSHFPRecordType: any;
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordData = RecordsBatchRequestPostsItemSSHFPRecordData;
export declare const RecordsScanReviewRequestAcceptsItemSSHFPRecordData: S.Schema<RecordsBatchRequestPostsItemSSHFPRecordData>;
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemSSHFPRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemSSHFPRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemSSHFPRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemSSHFPRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemSSHFPRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSSHFPRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SSHFP content. See 'data' to set SSHFP properties. */
    content?: string;
    /** Components of a SSHFP record. */
    data?: RecordsBatchRequestPostsItemSSHFPRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSSHFPRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemSSHFPRecord: S.Schema<RecordsScanReviewRequestAcceptsItemSSHFPRecord>;
export type RecordsScanReviewRequestAcceptsItemSVCBRecordType = "SVCB";
export declare const RecordsScanReviewRequestAcceptsItemSVCBRecordType: any;
export type RecordsScanReviewRequestAcceptsItemSVCBRecordData = RecordsBatchRequestPostsItemHTTPSRecordData;
export declare const RecordsScanReviewRequestAcceptsItemSVCBRecordData: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordData>;
export type RecordsScanReviewRequestAcceptsItemSVCBRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemSVCBRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemSVCBRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemSVCBRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemSVCBRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemSVCBRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemSVCBRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted SVCB content. See 'data' to set SVCB properties. */
    content?: string;
    /** Components of a SVCB record. */
    data?: RecordsBatchRequestPostsItemHTTPSRecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemSVCBRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemSVCBRecord: S.Schema<RecordsScanReviewRequestAcceptsItemSVCBRecord>;
export type RecordsScanReviewRequestAcceptsItemTLSARecordType = "TLSA";
export declare const RecordsScanReviewRequestAcceptsItemTLSARecordType: any;
export type RecordsScanReviewRequestAcceptsItemTLSARecordData = RecordsBatchRequestPostsItemSMIMEARecordData;
export declare const RecordsScanReviewRequestAcceptsItemTLSARecordData: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordData>;
export type RecordsScanReviewRequestAcceptsItemTLSARecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemTLSARecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemTLSARecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemTLSARecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemTLSARecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemTLSARecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemTLSARecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted TLSA content. See 'data' to set TLSA properties. */
    content?: string;
    /** Components of a TLSA record. */
    data?: RecordsBatchRequestPostsItemSMIMEARecordData;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemTLSARecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemTLSARecord: S.Schema<RecordsScanReviewRequestAcceptsItemTLSARecord>;
export type RecordsScanReviewRequestAcceptsItemURIRecordType = "URI";
export declare const RecordsScanReviewRequestAcceptsItemURIRecordType: any;
export type RecordsScanReviewRequestAcceptsItemURIRecordData = RecordsBatchRequestPostsItemURIRecordData;
export declare const RecordsScanReviewRequestAcceptsItemURIRecordData: S.Schema<RecordsBatchRequestPostsItemURIRecordData>;
export type RecordsScanReviewRequestAcceptsItemURIRecordSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewRequestAcceptsItemURIRecordSettings: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewRequestAcceptsItemURIRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewRequestAcceptsItemURIRecordTagsList: S.Schema<RecordsScanReviewRequestAcceptsItemURIRecordTagsList>;
export interface RecordsScanReviewRequestAcceptsItemURIRecord {
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewRequestAcceptsItemURIRecordType;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** Formatted URI content. See 'data' to set URI properties. */
    content?: string;
    /** Components of a URI record. */
    data?: RecordsBatchRequestPostsItemURIRecordData;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsScanReviewRequestAcceptsItemURIRecordTagsList;
}
export declare const RecordsScanReviewRequestAcceptsItemURIRecord: S.Schema<RecordsScanReviewRequestAcceptsItemURIRecord>;
export type RecordsScanReviewRequestAcceptsItem = RecordsScanReviewRequestAcceptsItemARecord | RecordsScanReviewRequestAcceptsItemAAAARecord | RecordsScanReviewRequestAcceptsItemCNAMERecord | RecordsScanReviewRequestAcceptsItemMXRecord | RecordsScanReviewRequestAcceptsItemNSRecord | RecordsScanReviewRequestAcceptsItemDNSRecordsOpenpgpkeyRecord | RecordsScanReviewRequestAcceptsItemPTRRecord | RecordsScanReviewRequestAcceptsItemTXTRecord | RecordsScanReviewRequestAcceptsItemCAARecord | RecordsScanReviewRequestAcceptsItemCERTRecord | RecordsScanReviewRequestAcceptsItemDNSKEYRecord | RecordsScanReviewRequestAcceptsItemDSRecord | RecordsScanReviewRequestAcceptsItemHTTPSRecord | RecordsScanReviewRequestAcceptsItemLOCRecord | RecordsScanReviewRequestAcceptsItemNAPTRRecord | RecordsScanReviewRequestAcceptsItemSMIMEARecord | RecordsScanReviewRequestAcceptsItemSRVRecord | RecordsScanReviewRequestAcceptsItemSSHFPRecord | RecordsScanReviewRequestAcceptsItemSVCBRecord | RecordsScanReviewRequestAcceptsItemTLSARecord | RecordsScanReviewRequestAcceptsItemURIRecord;
export declare const RecordsScanReviewRequestAcceptsItem: any;
export type RecordsScanReviewRequestAcceptsList = Array<RecordsScanReviewRequestAcceptsItem>;
export declare const RecordsScanReviewRequestAcceptsList: S.Schema<RecordsScanReviewRequestAcceptsList>;
export type RecordsScanReviewRequestRejectsItem = RecordsBatchRequestDeletesItem;
export declare const RecordsScanReviewRequestRejectsItem: S.Schema<RecordsBatchRequestDeletesItem>;
export type RecordsScanReviewRequestRejectsList = Array<RecordsBatchRequestDeletesItem>;
export declare const RecordsScanReviewRequestRejectsList: S.Schema<RecordsScanReviewRequestRejectsList>;
export interface ScanReviewRecordRequest {
    /** Identifier. */
    zoneId: string;
    accepts?: RecordsScanReviewRequestAcceptsList;
    rejects?: RecordsScanReviewRequestRejectsList;
}
export declare const ScanReviewRecordRequest: S.Schema<ScanReviewRecordRequest>;
export type RecordsScanReviewResponseAcceptsItemARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemARecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemARecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemARecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemARecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemARecord: S.Schema<RecordsScanReviewResponseAcceptsItemARecord>;
export type RecordsScanReviewResponseAcceptsItemAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemAAAARecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemAAAARecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemAAAARecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemAAAARecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemAAAARecord: S.Schema<RecordsScanReviewResponseAcceptsItemAAAARecord>;
export type RecordsScanReviewResponseAcceptsItemCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemCNAMERecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemCNAMERecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemCNAMERecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemCNAMERecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemCNAMERecord: S.Schema<RecordsScanReviewResponseAcceptsItemCNAMERecord>;
export type RecordsScanReviewResponseAcceptsItemMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemMXRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemMXRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemMXRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemMXRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemMXRecord: S.Schema<RecordsScanReviewResponseAcceptsItemMXRecord>;
export type RecordsScanReviewResponseAcceptsItemNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemNSRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemNSRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemNSRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemNSRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemNSRecord: S.Schema<RecordsScanReviewResponseAcceptsItemNSRecord>;
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMeta>;
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export declare const RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordTagsList: S.Schema<RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordTagsList>;
export type RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordType: any;
export interface RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecord: S.Schema<RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecord>;
export type RecordsScanReviewResponseAcceptsItemPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemPTRRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemPTRRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemPTRRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemPTRRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemPTRRecord: S.Schema<RecordsScanReviewResponseAcceptsItemPTRRecord>;
export type RecordsScanReviewResponseAcceptsItemTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemTXTRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemTXTRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemTXTRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemTXTRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemTXTRecord: S.Schema<RecordsScanReviewResponseAcceptsItemTXTRecord>;
export type RecordsScanReviewResponseAcceptsItemCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemCAARecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemCAARecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemCAARecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemCAARecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemCAARecord: S.Schema<RecordsScanReviewResponseAcceptsItemCAARecord>;
export type RecordsScanReviewResponseAcceptsItemCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemCERTRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemCERTRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemCERTRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemCERTRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemCERTRecord: S.Schema<RecordsScanReviewResponseAcceptsItemCERTRecord>;
export type RecordsScanReviewResponseAcceptsItemDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemDNSKEYRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemDNSKEYRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemDNSKEYRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemDNSKEYRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemDNSKEYRecord: S.Schema<RecordsScanReviewResponseAcceptsItemDNSKEYRecord>;
export type RecordsScanReviewResponseAcceptsItemDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemDSRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemDSRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemDSRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemDSRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemDSRecord: S.Schema<RecordsScanReviewResponseAcceptsItemDSRecord>;
export type RecordsScanReviewResponseAcceptsItemHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemHTTPSRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemHTTPSRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemHTTPSRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemHTTPSRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemHTTPSRecord: S.Schema<RecordsScanReviewResponseAcceptsItemHTTPSRecord>;
export type RecordsScanReviewResponseAcceptsItemLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemLOCRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemLOCRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemLOCRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemLOCRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemLOCRecord: S.Schema<RecordsScanReviewResponseAcceptsItemLOCRecord>;
export type RecordsScanReviewResponseAcceptsItemNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemNAPTRRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemNAPTRRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemNAPTRRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemNAPTRRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemNAPTRRecord: S.Schema<RecordsScanReviewResponseAcceptsItemNAPTRRecord>;
export type RecordsScanReviewResponseAcceptsItemSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemSMIMEARecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemSMIMEARecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSMIMEARecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemSMIMEARecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSMIMEARecord: S.Schema<RecordsScanReviewResponseAcceptsItemSMIMEARecord>;
export type RecordsScanReviewResponseAcceptsItemSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemSRVRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemSRVRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSRVRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemSRVRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSRVRecord: S.Schema<RecordsScanReviewResponseAcceptsItemSRVRecord>;
export type RecordsScanReviewResponseAcceptsItemSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemSSHFPRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemSSHFPRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSSHFPRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemSSHFPRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSSHFPRecord: S.Schema<RecordsScanReviewResponseAcceptsItemSSHFPRecord>;
export type RecordsScanReviewResponseAcceptsItemSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemSVCBRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemSVCBRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSVCBRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemSVCBRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemSVCBRecord: S.Schema<RecordsScanReviewResponseAcceptsItemSVCBRecord>;
export type RecordsScanReviewResponseAcceptsItemTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemTLSARecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemTLSARecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemTLSARecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemTLSARecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemTLSARecord: S.Schema<RecordsScanReviewResponseAcceptsItemTLSARecord>;
export type RecordsScanReviewResponseAcceptsItemURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsScanReviewResponseAcceptsItemURIRecordMetaShadowedByList: S.Schema<RecordsScanReviewResponseAcceptsItemURIRecordMetaShadowedByList>;
export interface RecordsScanReviewResponseAcceptsItemURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsScanReviewResponseAcceptsItemURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsScanReviewResponseAcceptsItemURIRecordMeta: S.Schema<RecordsScanReviewResponseAcceptsItemURIRecordMeta>;
export interface RecordsScanReviewResponseAcceptsItemURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsScanReviewResponseAcceptsItemURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsScanReviewResponseAcceptsItemURIRecord: S.Schema<RecordsScanReviewResponseAcceptsItemURIRecord>;
export type RecordsScanReviewResponseAcceptsItem = RecordsScanReviewResponseAcceptsItemARecord | RecordsScanReviewResponseAcceptsItemAAAARecord | RecordsScanReviewResponseAcceptsItemCNAMERecord | RecordsScanReviewResponseAcceptsItemMXRecord | RecordsScanReviewResponseAcceptsItemNSRecord | RecordsScanReviewResponseAcceptsItemOpenpgpkeyRecord | RecordsScanReviewResponseAcceptsItemPTRRecord | RecordsScanReviewResponseAcceptsItemTXTRecord | RecordsScanReviewResponseAcceptsItemCAARecord | RecordsScanReviewResponseAcceptsItemCERTRecord | RecordsScanReviewResponseAcceptsItemDNSKEYRecord | RecordsScanReviewResponseAcceptsItemDSRecord | RecordsScanReviewResponseAcceptsItemHTTPSRecord | RecordsScanReviewResponseAcceptsItemLOCRecord | RecordsScanReviewResponseAcceptsItemNAPTRRecord | RecordsScanReviewResponseAcceptsItemSMIMEARecord | RecordsScanReviewResponseAcceptsItemSRVRecord | RecordsScanReviewResponseAcceptsItemSSHFPRecord | RecordsScanReviewResponseAcceptsItemSVCBRecord | RecordsScanReviewResponseAcceptsItemTLSARecord | RecordsScanReviewResponseAcceptsItemURIRecord;
export declare const RecordsScanReviewResponseAcceptsItem: any;
export type RecordsScanReviewResponseAcceptsList = Array<RecordsScanReviewResponseAcceptsItem>;
export declare const RecordsScanReviewResponseAcceptsList: S.Schema<RecordsScanReviewResponseAcceptsList>;
export type RecordsScanReviewResponseRejectsList = Array<string>;
export declare const RecordsScanReviewResponseRejectsList: S.Schema<RecordsScanReviewResponseRejectsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ScanReviewRecordResponse {
    accepts?: RecordsScanReviewResponseAcceptsList | null;
    rejects?: RecordsScanReviewResponseRejectsList | null;
}
export declare const ScanReviewRecordResponse: S.Schema<ScanReviewRecordResponse>;
export interface ScanTriggerRecordRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ScanTriggerRecordRequest: S.Schema<ScanTriggerRecordRequest>;
export interface ScanTriggerRecordResponse {
}
export declare const ScanTriggerRecordResponse: S.Schema<ScanTriggerRecordResponse>;
export type RecordsUpdateRequestType = "A" | "AAAA" | "CNAME" | "MX" | "NS" | "OPENPGPKEY" | "PTR" | "TXT" | "CAA" | "CERT" | "DNSKEY" | "DS" | "HTTPS" | "LOC" | "NAPTR" | "SMIMEA" | "SRV" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export declare const RecordsUpdateRequestType: any;
export type RecordsUpdateRequestSettingsARecord = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings;
export declare const RecordsUpdateRequestSettingsARecord: S.Schema<RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings>;
export type RecordsUpdateRequestSettingsCNAMERecord = RecordsBatchRequestPostsItemCNAMERecordSettings;
export declare const RecordsUpdateRequestSettingsCNAMERecord: S.Schema<RecordsBatchRequestPostsItemCNAMERecordSettings>;
export type RecordsUpdateRequestSettings = RecordsBatchRequestPatchesItemOpenpgpkeyRecordSettings | RecordsBatchRequestPostsItemCNAMERecordSettings;
export declare const RecordsUpdateRequestSettings: any;
export type RecordsUpdateRequestTagsList = Array<unknown>;
export declare const RecordsUpdateRequestTagsList: S.Schema<RecordsUpdateRequestTagsList>;
export type RecordsUpdateRequestDataCAARecord = RecordsBatchRequestPostsItemCAARecordData;
export declare const RecordsUpdateRequestDataCAARecord: S.Schema<RecordsBatchRequestPostsItemCAARecordData>;
export type RecordsUpdateRequestDataCERTRecord = RecordsBatchRequestPostsItemCERTRecordData;
export declare const RecordsUpdateRequestDataCERTRecord: S.Schema<RecordsBatchRequestPostsItemCERTRecordData>;
export type RecordsUpdateRequestDataDNSKEYRecord = RecordsBatchRequestPostsItemDNSKEYRecordData;
export declare const RecordsUpdateRequestDataDNSKEYRecord: S.Schema<RecordsBatchRequestPostsItemDNSKEYRecordData>;
export type RecordsUpdateRequestDataDSRecord = RecordsBatchRequestPostsItemDSRecordData;
export declare const RecordsUpdateRequestDataDSRecord: S.Schema<RecordsBatchRequestPostsItemDSRecordData>;
export type RecordsUpdateRequestDataHTTPSRecord = RecordsBatchRequestPostsItemHTTPSRecordData;
export declare const RecordsUpdateRequestDataHTTPSRecord: S.Schema<RecordsBatchRequestPostsItemHTTPSRecordData>;
export type RecordsUpdateRequestDataLOCRecordLatDirection = "N" | "S";
export declare const RecordsUpdateRequestDataLOCRecordLatDirection: any;
export type RecordsUpdateRequestDataLOCRecordLongDirection = "E" | "W";
export declare const RecordsUpdateRequestDataLOCRecordLongDirection: any;
export interface RecordsUpdateRequestDataLOCRecord {
    /** Altitude of location in meters. */
    altitude?: number;
    /** Degrees of latitude. */
    latDegrees?: number;
    /** Latitude direction. */
    latDirection?: RecordsUpdateRequestDataLOCRecordLatDirection | (string & {});
    /** Minutes of latitude. */
    latMinutes?: number;
    /** Seconds of latitude. */
    latSeconds?: number;
    /** Degrees of longitude. */
    longDegrees?: number;
    /** Longitude direction. */
    longDirection?: RecordsUpdateRequestDataLOCRecordLongDirection | (string & {});
    /** Minutes of longitude. */
    longMinutes?: number;
    /** Seconds of longitude. */
    longSeconds?: number;
    /** Horizontal precision of location. */
    precisionHorz?: number;
    /** Vertical precision of location. */
    precisionVert?: number;
    /** Size of location in meters. */
    size?: number;
}
export declare const RecordsUpdateRequestDataLOCRecord: S.Schema<RecordsUpdateRequestDataLOCRecord>;
export type RecordsUpdateRequestDataNAPTRRecord = RecordsBatchRequestPostsItemNAPTRRecordData;
export declare const RecordsUpdateRequestDataNAPTRRecord: S.Schema<RecordsBatchRequestPostsItemNAPTRRecordData>;
export type RecordsUpdateRequestDataSMIMEARecord = RecordsBatchRequestPostsItemSMIMEARecordData;
export declare const RecordsUpdateRequestDataSMIMEARecord: S.Schema<RecordsBatchRequestPostsItemSMIMEARecordData>;
export type RecordsUpdateRequestDataSRVRecord = RecordsBatchRequestPostsItemSRVRecordData;
export declare const RecordsUpdateRequestDataSRVRecord: S.Schema<RecordsBatchRequestPostsItemSRVRecordData>;
export type RecordsUpdateRequestDataSSHFPRecord = RecordsBatchRequestPostsItemSSHFPRecordData;
export declare const RecordsUpdateRequestDataSSHFPRecord: S.Schema<RecordsBatchRequestPostsItemSSHFPRecordData>;
export type RecordsUpdateRequestDataURIRecord = RecordsBatchRequestPostsItemURIRecordData;
export declare const RecordsUpdateRequestDataURIRecord: S.Schema<RecordsBatchRequestPostsItemURIRecordData>;
export type RecordsUpdateRequestData = RecordsBatchRequestPostsItemCAARecordData | RecordsBatchRequestPostsItemCERTRecordData | RecordsBatchRequestPostsItemDNSKEYRecordData | RecordsBatchRequestPostsItemDSRecordData | RecordsBatchRequestPostsItemHTTPSRecordData | RecordsUpdateRequestDataLOCRecord | RecordsBatchRequestPostsItemNAPTRRecordData | RecordsBatchRequestPostsItemSMIMEARecordData | RecordsBatchRequestPostsItemSRVRecordData | RecordsBatchRequestPostsItemSSHFPRecordData | RecordsBatchRequestPostsItemURIRecordData;
export declare const RecordsUpdateRequestData: any;
export interface UpdateRecordRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    dnsRecordId: string;
    /** Whether to include shadow metadata in the `meta` field of each record in the response. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    includeShadowMetadata?: boolean;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsUpdateRequestType | (string & {});
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment?: string;
    /** A valid IPv4 address. */
    content?: string;
    /** Enables private network routing to the origin. */
    privateRouting?: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied?: boolean;
    /** Settings for the DNS record. */
    settings?: RecordsUpdateRequestSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags?: RecordsUpdateRequestTagsList;
    /** Required for MX and URI records; ignored for other record types (but may still be returned by the API). Records with lower priorities are preferred. This field is to be deprecated in favor of the priority field within the data map. */
    priority?: number;
    /** Components of a CAA record. */
    data?: RecordsUpdateRequestData;
}
export declare const UpdateRecordRequest: S.Schema<UpdateRecordRequest>;
export type RecordsUpdateResultARecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultARecordMetaShadowedByList: S.Schema<RecordsUpdateResultARecordMetaShadowedByList>;
export interface RecordsUpdateResultARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultARecordMeta: S.Schema<RecordsUpdateResultARecordMeta>;
export interface RecordsUpdateResultARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultARecord: S.Schema<RecordsUpdateResultARecord>;
export type RecordsUpdateResultAAAARecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultAAAARecordMetaShadowedByList: S.Schema<RecordsUpdateResultAAAARecordMetaShadowedByList>;
export interface RecordsUpdateResultAAAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultAAAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultAAAARecordMeta: S.Schema<RecordsUpdateResultAAAARecordMeta>;
export interface RecordsUpdateResultAAAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultAAAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeAAAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultAAAARecord: S.Schema<RecordsUpdateResultAAAARecord>;
export type RecordsUpdateResultCNAMERecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultCNAMERecordMetaShadowedByList: S.Schema<RecordsUpdateResultCNAMERecordMetaShadowedByList>;
export interface RecordsUpdateResultCNAMERecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultCNAMERecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultCNAMERecordMeta: S.Schema<RecordsUpdateResultCNAMERecordMeta>;
export interface RecordsUpdateResultCNAMERecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultCNAMERecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCNAME;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultCNAMERecord: S.Schema<RecordsUpdateResultCNAMERecord>;
export type RecordsUpdateResultMXRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultMXRecordMetaShadowedByList: S.Schema<RecordsUpdateResultMXRecordMetaShadowedByList>;
export interface RecordsUpdateResultMXRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultMXRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultMXRecordMeta: S.Schema<RecordsUpdateResultMXRecordMeta>;
export interface RecordsUpdateResultMXRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultMXRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeMX;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultMXRecord: S.Schema<RecordsUpdateResultMXRecord>;
export type RecordsUpdateResultNSRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultNSRecordMetaShadowedByList: S.Schema<RecordsUpdateResultNSRecordMetaShadowedByList>;
export interface RecordsUpdateResultNSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultNSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultNSRecordMeta: S.Schema<RecordsUpdateResultNSRecordMeta>;
export interface RecordsUpdateResultNSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultNSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultNSRecord: S.Schema<RecordsUpdateResultNSRecord>;
export type RecordsUpdateResultOpenpgpkeyRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultOpenpgpkeyRecordMetaShadowedByList: S.Schema<RecordsUpdateResultOpenpgpkeyRecordMetaShadowedByList>;
export interface RecordsUpdateResultOpenpgpkeyRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultOpenpgpkeyRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultOpenpgpkeyRecordMeta: S.Schema<RecordsUpdateResultOpenpgpkeyRecordMeta>;
export type RecordsUpdateResultOpenpgpkeyRecordSettings = RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
export declare const RecordsUpdateResultOpenpgpkeyRecordSettings: S.Schema<RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings>;
export type RecordsUpdateResultOpenpgpkeyRecordTagsList = Array<unknown>;
export declare const RecordsUpdateResultOpenpgpkeyRecordTagsList: S.Schema<RecordsUpdateResultOpenpgpkeyRecordTagsList>;
export type RecordsUpdateResultOpenpgpkeyRecordType = "OPENPGPKEY";
export declare const RecordsUpdateResultOpenpgpkeyRecordType: any;
export interface RecordsUpdateResultOpenpgpkeyRecord {
    /** Identifier. */
    id: string;
    /** Comments or notes about the DNS record. This field has no effect on DNS responses. */
    comment: string;
    /** A single Base64-encoded OpenPGP Transferable Public Key (RFC 4880 Section 11.1) */
    content: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultOpenpgpkeyRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Complete DNS record name, including the zone name, in Punycode. */
    name: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** Whether the record is receiving the performance and security benefits of Cloudflare. */
    proxied: boolean;
    /** Settings for the DNS record. */
    settings: RecordsBatchResponseDeletesItemOpenpgpkeyRecordSettings;
    /** Custom tags for the DNS record. This field has no effect on DNS responses. */
    tags: RecordsUpdateResultOpenpgpkeyRecordTagsList;
    /** Time To Live (TTL) of the DNS record in seconds. Setting to 1 means 'automatic'. Value must be between 60 and 86400, with the minimum reduced to 30 for Enterprise zones. */
    ttl: number;
    /** Record type. */
    type: RecordsUpdateResultOpenpgpkeyRecordType;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
}
export declare const RecordsUpdateResultOpenpgpkeyRecord: S.Schema<RecordsUpdateResultOpenpgpkeyRecord>;
export type RecordsUpdateResultPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultPTRRecordMetaShadowedByList: S.Schema<RecordsUpdateResultPTRRecordMetaShadowedByList>;
export interface RecordsUpdateResultPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultPTRRecordMeta: S.Schema<RecordsUpdateResultPTRRecordMeta>;
export interface RecordsUpdateResultPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypePTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultPTRRecord: S.Schema<RecordsUpdateResultPTRRecord>;
export type RecordsUpdateResultTXTRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultTXTRecordMetaShadowedByList: S.Schema<RecordsUpdateResultTXTRecordMetaShadowedByList>;
export interface RecordsUpdateResultTXTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultTXTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultTXTRecordMeta: S.Schema<RecordsUpdateResultTXTRecordMeta>;
export interface RecordsUpdateResultTXTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultTXTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTXT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultTXTRecord: S.Schema<RecordsUpdateResultTXTRecord>;
export type RecordsUpdateResultCAARecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultCAARecordMetaShadowedByList: S.Schema<RecordsUpdateResultCAARecordMetaShadowedByList>;
export interface RecordsUpdateResultCAARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultCAARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultCAARecordMeta: S.Schema<RecordsUpdateResultCAARecordMeta>;
export interface RecordsUpdateResultCAARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultCAARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCAA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultCAARecord: S.Schema<RecordsUpdateResultCAARecord>;
export type RecordsUpdateResultCERTRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultCERTRecordMetaShadowedByList: S.Schema<RecordsUpdateResultCERTRecordMetaShadowedByList>;
export interface RecordsUpdateResultCERTRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultCERTRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultCERTRecordMeta: S.Schema<RecordsUpdateResultCERTRecordMeta>;
export interface RecordsUpdateResultCERTRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultCERTRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeCERT;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultCERTRecord: S.Schema<RecordsUpdateResultCERTRecord>;
export type RecordsUpdateResultDNSKEYRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultDNSKEYRecordMetaShadowedByList: S.Schema<RecordsUpdateResultDNSKEYRecordMetaShadowedByList>;
export interface RecordsUpdateResultDNSKEYRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultDNSKEYRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultDNSKEYRecordMeta: S.Schema<RecordsUpdateResultDNSKEYRecordMeta>;
export interface RecordsUpdateResultDNSKEYRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultDNSKEYRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDNSKEY;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultDNSKEYRecord: S.Schema<RecordsUpdateResultDNSKEYRecord>;
export type RecordsUpdateResultDSRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultDSRecordMetaShadowedByList: S.Schema<RecordsUpdateResultDSRecordMetaShadowedByList>;
export interface RecordsUpdateResultDSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultDSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultDSRecordMeta: S.Schema<RecordsUpdateResultDSRecordMeta>;
export interface RecordsUpdateResultDSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultDSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeDS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultDSRecord: S.Schema<RecordsUpdateResultDSRecord>;
export type RecordsUpdateResultHTTPSRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultHTTPSRecordMetaShadowedByList: S.Schema<RecordsUpdateResultHTTPSRecordMetaShadowedByList>;
export interface RecordsUpdateResultHTTPSRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultHTTPSRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultHTTPSRecordMeta: S.Schema<RecordsUpdateResultHTTPSRecordMeta>;
export interface RecordsUpdateResultHTTPSRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultHTTPSRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeHTTPS;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultHTTPSRecord: S.Schema<RecordsUpdateResultHTTPSRecord>;
export type RecordsUpdateResultLOCRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultLOCRecordMetaShadowedByList: S.Schema<RecordsUpdateResultLOCRecordMetaShadowedByList>;
export interface RecordsUpdateResultLOCRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultLOCRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultLOCRecordMeta: S.Schema<RecordsUpdateResultLOCRecordMeta>;
export interface RecordsUpdateResultLOCRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultLOCRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeLOC;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultLOCRecord: S.Schema<RecordsUpdateResultLOCRecord>;
export type RecordsUpdateResultNAPTRRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultNAPTRRecordMetaShadowedByList: S.Schema<RecordsUpdateResultNAPTRRecordMetaShadowedByList>;
export interface RecordsUpdateResultNAPTRRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultNAPTRRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultNAPTRRecordMeta: S.Schema<RecordsUpdateResultNAPTRRecordMeta>;
export interface RecordsUpdateResultNAPTRRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultNAPTRRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeNAPTR;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultNAPTRRecord: S.Schema<RecordsUpdateResultNAPTRRecord>;
export type RecordsUpdateResultSMIMEARecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultSMIMEARecordMetaShadowedByList: S.Schema<RecordsUpdateResultSMIMEARecordMetaShadowedByList>;
export interface RecordsUpdateResultSMIMEARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSMIMEARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultSMIMEARecordMeta: S.Schema<RecordsUpdateResultSMIMEARecordMeta>;
export interface RecordsUpdateResultSMIMEARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSMIMEARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSMIMEA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultSMIMEARecord: S.Schema<RecordsUpdateResultSMIMEARecord>;
export type RecordsUpdateResultSRVRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultSRVRecordMetaShadowedByList: S.Schema<RecordsUpdateResultSRVRecordMetaShadowedByList>;
export interface RecordsUpdateResultSRVRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSRVRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultSRVRecordMeta: S.Schema<RecordsUpdateResultSRVRecordMeta>;
export interface RecordsUpdateResultSRVRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSRVRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSRV;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultSRVRecord: S.Schema<RecordsUpdateResultSRVRecord>;
export type RecordsUpdateResultSSHFPRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultSSHFPRecordMetaShadowedByList: S.Schema<RecordsUpdateResultSSHFPRecordMetaShadowedByList>;
export interface RecordsUpdateResultSSHFPRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSSHFPRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultSSHFPRecordMeta: S.Schema<RecordsUpdateResultSSHFPRecordMeta>;
export interface RecordsUpdateResultSSHFPRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSSHFPRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSSHFP;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultSSHFPRecord: S.Schema<RecordsUpdateResultSSHFPRecord>;
export type RecordsUpdateResultSVCBRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultSVCBRecordMetaShadowedByList: S.Schema<RecordsUpdateResultSVCBRecordMetaShadowedByList>;
export interface RecordsUpdateResultSVCBRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultSVCBRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultSVCBRecordMeta: S.Schema<RecordsUpdateResultSVCBRecordMeta>;
export interface RecordsUpdateResultSVCBRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultSVCBRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeSVCB;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultSVCBRecord: S.Schema<RecordsUpdateResultSVCBRecord>;
export type RecordsUpdateResultTLSARecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultTLSARecordMetaShadowedByList: S.Schema<RecordsUpdateResultTLSARecordMetaShadowedByList>;
export interface RecordsUpdateResultTLSARecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultTLSARecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultTLSARecordMeta: S.Schema<RecordsUpdateResultTLSARecordMeta>;
export interface RecordsUpdateResultTLSARecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultTLSARecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeTLSA;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultTLSARecord: S.Schema<RecordsUpdateResultTLSARecord>;
export type RecordsUpdateResultURIRecordMetaShadowedByList = Array<string>;
export declare const RecordsUpdateResultURIRecordMetaShadowedByList: S.Schema<RecordsUpdateResultURIRecordMetaShadowedByList>;
export interface RecordsUpdateResultURIRecordMeta {
    /** Whether this glue record is not served because a shallower NS delegation takes precedence over the deeper delegation that needs it. Present only when true; reachable glue carries only `is_glue`. See [Unreachable glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#unreachable-glue-records). */
    deadGlue?: boolean | null;
    /** Whether this A or AAAA record is glue for a subdomain NS delegation. See [Glue records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records#glue-records). */
    isGlue?: boolean | null;
    /** IDs of the NS records that shadow this record. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedBy?: RecordsUpdateResultURIRecordMetaShadowedByList | null;
    /** Number of records shadowed by this NS delegation. See [Shadowed records](https://developers.cloudflare.com/dns/manage-dns-records/reference/shadowed-records). */
    shadowedRecordsCount?: number | null;
}
export declare const RecordsUpdateResultURIRecordMeta: S.Schema<RecordsUpdateResultURIRecordMeta>;
export interface RecordsUpdateResultURIRecord {
    /** Identifier. */
    id: string;
    /** When the record was created. */
    createdOn: string;
    /** Extra Cloudflare-specific metadata about the record. */
    meta: RecordsUpdateResultURIRecordMeta;
    /** When the record was last modified. */
    modifiedOn: string;
    /** Whether the record can be proxied by Cloudflare or not. */
    proxiable: boolean;
    /** When the record comment was last modified. Omitted if there is no comment. */
    commentModifiedOn?: string | null;
    /** When the record tags were last modified. Omitted if there are no tags. */
    tagsModifiedOn?: string | null;
    name: string;
    type: DnsRecordTypeURI;
    ttl: number;
    content?: string | null;
    comment?: string | null;
    proxied?: boolean | null;
    priority?: number | null;
    tags?: DnsRecordTagsList | null;
    settings?: unknown | null;
    data?: unknown | null;
}
export declare const RecordsUpdateResultURIRecord: S.Schema<RecordsUpdateResultURIRecord>;
export type RecordsUpdateResult = RecordsUpdateResultARecord | RecordsUpdateResultAAAARecord | RecordsUpdateResultCNAMERecord | RecordsUpdateResultMXRecord | RecordsUpdateResultNSRecord | RecordsUpdateResultOpenpgpkeyRecord | RecordsUpdateResultPTRRecord | RecordsUpdateResultTXTRecord | RecordsUpdateResultCAARecord | RecordsUpdateResultCERTRecord | RecordsUpdateResultDNSKEYRecord | RecordsUpdateResultDSRecord | RecordsUpdateResultHTTPSRecord | RecordsUpdateResultLOCRecord | RecordsUpdateResultNAPTRRecord | RecordsUpdateResultSMIMEARecord | RecordsUpdateResultSRVRecord | RecordsUpdateResultSSHFPRecord | RecordsUpdateResultSVCBRecord | RecordsUpdateResultTLSARecord | RecordsUpdateResultURIRecord;
export declare const RecordsUpdateResult: any;
export type UpdateRecordResponse = RecordsUpdateResult;
export declare const UpdateRecordResponse: S.Schema<UpdateRecordResponse>;
export interface UpdateZoneTransferAclRequest {
    accountId: string;
    aclId: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export declare const UpdateZoneTransferAclRequest: S.Schema<UpdateZoneTransferAclRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferAclResponse {
    id: string;
    /** Allowed IPv4/IPv6 address range of primary or secondary nameservers. This will be applied for the entire account. The IP range is used to allow additional NOTIFY IPs for secondary zones and IPs Cloudflare allows AXFR/IXFR requests from for primary zones. CIDRs are limited to a maximum of /24 for IPv4 and /64 for IPv6 respectively. */
    ipRange: string;
    /** The name of the acl. */
    name: string;
}
export declare const UpdateZoneTransferAclResponse: S.Schema<UpdateZoneTransferAclResponse>;
export type ZoneTransfersIncomingUpdateRequestPeersList = Array<string>;
export declare const ZoneTransfersIncomingUpdateRequestPeersList: S.Schema<ZoneTransfersIncomingUpdateRequestPeersList>;
export interface UpdateZoneTransferIncomingRequest {
    zoneId: string;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. */
    autoRefreshSeconds: number;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersIncomingUpdateRequestPeersList;
}
export declare const UpdateZoneTransferIncomingRequest: S.Schema<UpdateZoneTransferIncomingRequest>;
export type ZoneTransfersIncomingUpdateResponsePeersList = Array<string>;
export declare const ZoneTransfersIncomingUpdateResponsePeersList: S.Schema<ZoneTransfersIncomingUpdateResponsePeersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferIncomingResponse {
    id?: string | null;
    /** How often should a secondary zone auto refresh regardless of DNS NOTIFY. */
    autoRefreshSeconds?: number | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    modifiedTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersIncomingUpdateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export declare const UpdateZoneTransferIncomingResponse: S.Schema<UpdateZoneTransferIncomingResponse>;
export type ZoneTransfersOutgoingUpdateRequestPeersList = Array<string>;
export declare const ZoneTransfersOutgoingUpdateRequestPeersList: S.Schema<ZoneTransfersOutgoingUpdateRequestPeersList>;
export interface UpdateZoneTransferOutgoingRequest {
    zoneId: string;
    /** Zone name. */
    name: string;
    /** A list of peer tags. */
    peers: ZoneTransfersOutgoingUpdateRequestPeersList;
}
export declare const UpdateZoneTransferOutgoingRequest: S.Schema<UpdateZoneTransferOutgoingRequest>;
export type ZoneTransfersOutgoingUpdateResponsePeersList = Array<string>;
export declare const ZoneTransfersOutgoingUpdateResponsePeersList: S.Schema<ZoneTransfersOutgoingUpdateResponsePeersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferOutgoingResponse {
    id?: string | null;
    /** The time for a specific event. */
    checkedTime?: string | null;
    /** The time for a specific event. */
    createdTime?: string | null;
    /** The time for a specific event. */
    lastTransferredTime?: string | null;
    /** Zone name. */
    name?: string | null;
    /** A list of peer tags. */
    peers?: ZoneTransfersOutgoingUpdateResponsePeersList | null;
    /** The serial number of the SOA for the given zone. */
    soaSerial?: number | null;
}
export declare const UpdateZoneTransferOutgoingResponse: S.Schema<UpdateZoneTransferOutgoingResponse>;
export interface UpdateZoneTransferPeerRequest {
    accountId: string;
    peerId: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string;
}
export declare const UpdateZoneTransferPeerRequest: S.Schema<UpdateZoneTransferPeerRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferPeerResponse {
    id: string;
    /** The name of the peer. */
    name: string;
    /** IPv4/IPv6 address of primary or secondary nameserver, depending on what zone this peer is linked to. For primary zones this IP defines the IP of the secondary nameserver Cloudflare will NOTIFY upon zone changes. For secondary zones this IP defines the IP of the primary nameserver Cloudflare will send AXFR/IXFR requests to. */
    ip?: string | null;
    /** Enable IXFR transfer protocol, default is AXFR. Only applicable to secondary zones. */
    ixfrEnable?: boolean | null;
    /** DNS port of primary or secondary nameserver, depending on what zone this peer is linked to. */
    port?: number | null;
    /** TSIG authentication will be used for zone transfer if configured. */
    tsigId?: string | null;
}
export declare const UpdateZoneTransferPeerResponse: S.Schema<UpdateZoneTransferPeerResponse>;
export interface UpdateZoneTransferTsigRequest {
    accountId: string;
    tsigId: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export declare const UpdateZoneTransferTsigRequest: S.Schema<UpdateZoneTransferTsigRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateZoneTransferTsigResponse {
    id: string;
    /** TSIG algorithm. */
    algo: string;
    /** TSIG key name. */
    name: string;
    /** TSIG secret. */
    secret: string;
}
export declare const UpdateZoneTransferTsigResponse: S.Schema<UpdateZoneTransferTsigResponse>;
export type BatchRecordError = CloudflareOpError;
/** Send a Batch of DNS Record API calls to be executed together. Notes: - Although Cloudflare will execute the batched operations in a single database transaction, Cloudflare's distributed KV store must treat each record change as a single key-value pair. This means that the propagation of changes is not atomic. See [the documentation](https://developers.cloudflare.com/dns/manage-dns-records/how-to/batch-record-changes/ "Batch DNS records") for more information. - The operations you specify within the /batch request body are always executed in the following order: - Deletes - Patches - Puts - Posts */
export declare const batchRecord: API.OperationMethod<BatchRecordRequest, BatchRecordResponse, BatchRecordError, CloudflareOpContext>;
export type CreateRecordError = DnsRecordAlreadyExists | Forbidden | CloudflareOpError;
/** Create a new DNS record for a zone. Notes: - A/AAAA records cannot exist on the same name as CNAME records. - NS records cannot exist on the same name as any other record type. - Domain names are always represented in Punycode, even if Unicode characters were used when creating the record. */
export declare const createRecord: API.OperationMethod<CreateRecordRequest, CreateRecordResponse, CreateRecordError, CloudflareOpContext>;
export type CreateSettingAccountViewError = InternalDnsNotAvailable | CloudflareOpError;
/** Create Internal DNS View for an account */
export declare const createSettingAccountView: API.OperationMethod<CreateSettingAccountViewRequest, CreateSettingAccountViewResponse, CreateSettingAccountViewError, CloudflareOpContext>;
export type CreateZoneTransferAclError = CloudflareOpError;
/** Create ACL. */
export declare const createZoneTransferAcl: API.OperationMethod<CreateZoneTransferAclRequest, CreateZoneTransferAclResponse, CreateZoneTransferAclError, CloudflareOpContext>;
export type CreateZoneTransferForceAxfrError = CloudflareOpError;
/** Sends AXFR zone transfer request to primary nameserver(s). */
export declare const createZoneTransferForceAxfr: API.OperationMethod<CreateZoneTransferForceAxfrRequest, CreateZoneTransferForceAxfrResponse, CreateZoneTransferForceAxfrError, CloudflareOpContext>;
export type CreateZoneTransferIncomingError = CloudflareOpError;
/** Create secondary zone configuration for incoming zone transfers. */
export declare const createZoneTransferIncoming: API.OperationMethod<CreateZoneTransferIncomingRequest, CreateZoneTransferIncomingResponse, CreateZoneTransferIncomingError, CloudflareOpContext>;
export type CreateZoneTransferOutgoingError = OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Create primary zone configuration for outgoing zone transfers. */
export declare const createZoneTransferOutgoing: API.OperationMethod<CreateZoneTransferOutgoingRequest, CreateZoneTransferOutgoingResponse, CreateZoneTransferOutgoingError, CloudflareOpContext>;
export type CreateZoneTransferPeerError = CloudflareOpError;
/** Create Peer. */
export declare const createZoneTransferPeer: API.OperationMethod<CreateZoneTransferPeerRequest, CreateZoneTransferPeerResponse, CreateZoneTransferPeerError, CloudflareOpContext>;
export type CreateZoneTransferTsigError = CloudflareOpError;
/** Create TSIG. */
export declare const createZoneTransferTsig: API.OperationMethod<CreateZoneTransferTsigRequest, CreateZoneTransferTsigResponse, CreateZoneTransferTsigError, CloudflareOpContext>;
export type DeleteDnssecError = Forbidden | CloudflareOpError;
/** Delete DNSSEC. */
export declare const deleteDnssec: API.OperationMethod<DeleteDnssecRequest, DeleteDnssecResponse, DeleteDnssecError, CloudflareOpContext>;
export type DeleteRecordError = CloudflareOpError;
/** Permanently removes a DNS record from the zone. */
export declare const deleteRecord: API.OperationMethod<DeleteRecordRequest, DeleteRecordResponse, DeleteRecordError, CloudflareOpContext>;
export type DeleteSettingAccountViewError = ViewNotFound | CloudflareOpError;
/** Delete an existing Internal DNS View */
export declare const deleteSettingAccountView: API.OperationMethod<DeleteSettingAccountViewRequest, DeleteSettingAccountViewResponse, DeleteSettingAccountViewError, CloudflareOpContext>;
export type DeleteZoneTransferAclError = AclNotFound | CloudflareOpError;
/** Delete ACL. */
export declare const deleteZoneTransferAcl: API.OperationMethod<DeleteZoneTransferAclRequest, DeleteZoneTransferAclResponse, DeleteZoneTransferAclError, CloudflareOpContext>;
export type DeleteZoneTransferIncomingError = IncomingZoneTransferNotFound | CloudflareOpError;
/** Delete secondary zone configuration for incoming zone transfers. */
export declare const deleteZoneTransferIncoming: API.OperationMethod<DeleteZoneTransferIncomingRequest, DeleteZoneTransferIncomingResponse, DeleteZoneTransferIncomingError, CloudflareOpContext>;
export type DeleteZoneTransferOutgoingError = OutgoingZoneTransferNotFound | OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Delete primary zone configuration for outgoing zone transfers. */
export declare const deleteZoneTransferOutgoing: API.OperationMethod<DeleteZoneTransferOutgoingRequest, DeleteZoneTransferOutgoingResponse, DeleteZoneTransferOutgoingError, CloudflareOpContext>;
export type DeleteZoneTransferPeerError = PeerNotFound | CloudflareOpError;
/** Delete Peer. */
export declare const deleteZoneTransferPeer: API.OperationMethod<DeleteZoneTransferPeerRequest, DeleteZoneTransferPeerResponse, DeleteZoneTransferPeerError, CloudflareOpContext>;
export type DeleteZoneTransferTsigError = TsigNotFound | CloudflareOpError;
/** Delete TSIG. */
export declare const deleteZoneTransferTsig: API.OperationMethod<DeleteZoneTransferTsigRequest, DeleteZoneTransferTsigResponse, DeleteZoneTransferTsigError, CloudflareOpContext>;
export type DisableZoneTransferOutgoingError = OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Disable outgoing zone transfers for primary zone and clears IXFR backlog of primary zone. */
export declare const disableZoneTransferOutgoing: API.OperationMethod<DisableZoneTransferOutgoingRequest, DisableZoneTransferOutgoingResponse, DisableZoneTransferOutgoingError, CloudflareOpContext>;
export type EnableZoneTransferOutgoingError = OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Enable outgoing zone transfers for primary zone. */
export declare const enableZoneTransferOutgoing: API.OperationMethod<EnableZoneTransferOutgoingRequest, EnableZoneTransferOutgoingResponse, EnableZoneTransferOutgoingError, CloudflareOpContext>;
export type ExportRecordError = CloudflareOpError;
/** You can export your [BIND config](https://en.wikipedia.org/wiki/Zone_file "Zone file") through this endpoint. See [the documentation](https://developers.cloudflare.com/dns/manage-dns-records/how-to/import-and-export/ "Import and export records") for more information. */
export declare const exportRecord: API.OperationMethod<ExportRecordRequest, ExportRecordResponse, ExportRecordError, CloudflareOpContext>;
export type ForceNotifyZoneTransferOutgoingError = CloudflareOpError;
/** Notifies the secondary nameserver(s) and clears IXFR backlog of primary zone. */
export declare const forceNotifyZoneTransferOutgoing: API.OperationMethod<ForceNotifyZoneTransferOutgoingRequest, ForceNotifyZoneTransferOutgoingResponse, ForceNotifyZoneTransferOutgoingError, CloudflareOpContext>;
export type GetAnalyticReportError = CloudflareOpError;
/** Retrieves a list of summarised aggregate metrics over a given time period. See [Analytics API properties](https://developers.cloudflare.com/dns/reference/analytics-api-properties/) for detailed information about the available query parameters. */
export declare const getAnalyticReport: API.OperationMethod<GetAnalyticReportRequest, GetAnalyticReportResponse, GetAnalyticReportError, CloudflareOpContext>;
export type GetAnalyticReportBytimeError = CloudflareOpError;
/** Retrieves a list of aggregate metrics grouped by time interval. See [Analytics API properties](https://developers.cloudflare.com/dns/reference/analytics-api-properties/) for detailed information about the available query parameters. */
export declare const getAnalyticReportBytime: API.OperationMethod<GetAnalyticReportBytimeRequest, GetAnalyticReportBytimeResponse, GetAnalyticReportBytimeError, CloudflareOpContext>;
export type GetDnssecError = Forbidden | CloudflareOpError;
/** Details about DNSSEC status and configuration. */
export declare const getDnssec: API.OperationMethod<GetDnssecRequest, GetDnssecResponse, GetDnssecError, CloudflareOpContext>;
export type GetRecordError = Forbidden | CloudflareOpError;
/** Retrieves details for a specific DNS record in the zone. */
export declare const getRecord: API.OperationMethod<GetRecordRequest, GetRecordResponse, GetRecordError, CloudflareOpContext>;
export type GetSettingAccountError = CloudflareOpError;
/** Show DNS settings for an account */
export declare const getSettingAccount: API.OperationMethod<GetSettingAccountRequest, GetSettingAccountResponse, GetSettingAccountError, CloudflareOpContext>;
export type GetSettingAccountViewError = ViewNotFound | CloudflareOpError;
/** Get DNS Internal View */
export declare const getSettingAccountView: API.OperationMethod<GetSettingAccountViewRequest, GetSettingAccountViewResponse, GetSettingAccountViewError, CloudflareOpContext>;
export type GetSettingZoneError = Forbidden | CloudflareOpError;
/** Show DNS settings for a zone */
export declare const getSettingZone: API.OperationMethod<GetSettingZoneRequest, GetSettingZoneResponse, GetSettingZoneError, CloudflareOpContext>;
export type GetUsageAccountError = CloudflareOpError;
/** Get the current DNS record usage and quota for an account. May include internal DNS usage and quota. */
export declare const getUsageAccount: API.OperationMethod<GetUsageAccountRequest, GetUsageAccountResponse, GetUsageAccountError, CloudflareOpContext>;
export type GetUsageZoneError = CloudflareOpError;
/** Get the current DNS record usage for a zone, including the number of records and the quota limit. */
export declare const getUsageZone: API.OperationMethod<GetUsageZoneRequest, GetUsageZoneResponse, GetUsageZoneError, CloudflareOpContext>;
export type GetZoneTransferAclError = AclNotFound | CloudflareOpError;
/** Get ACL. */
export declare const getZoneTransferAcl: API.OperationMethod<GetZoneTransferAclRequest, GetZoneTransferAclResponse, GetZoneTransferAclError, CloudflareOpContext>;
export type GetZoneTransferIncomingError = IncomingZoneTransferNotFound | CloudflareOpError;
/** Get secondary zone configuration for incoming zone transfers. */
export declare const getZoneTransferIncoming: API.OperationMethod<GetZoneTransferIncomingRequest, GetZoneTransferIncomingResponse, GetZoneTransferIncomingError, CloudflareOpContext>;
export type GetZoneTransferOutgoingError = OutgoingZoneTransferNotFound | OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Get primary zone configuration for outgoing zone transfers. */
export declare const getZoneTransferOutgoing: API.OperationMethod<GetZoneTransferOutgoingRequest, GetZoneTransferOutgoingResponse, GetZoneTransferOutgoingError, CloudflareOpContext>;
export type GetZoneTransferOutgoingStatusError = CloudflareOpError;
/** Get primary zone transfer status. */
export declare const getZoneTransferOutgoingStatus: API.OperationMethod<GetZoneTransferOutgoingStatusRequest, GetZoneTransferOutgoingStatusResponse, GetZoneTransferOutgoingStatusError, CloudflareOpContext>;
export type GetZoneTransferPeerError = PeerNotFound | CloudflareOpError;
/** Get Peer. */
export declare const getZoneTransferPeer: API.OperationMethod<GetZoneTransferPeerRequest, GetZoneTransferPeerResponse, GetZoneTransferPeerError, CloudflareOpContext>;
export type GetZoneTransferTsigError = TsigNotFound | CloudflareOpError;
/** Get TSIG. */
export declare const getZoneTransferTsig: API.OperationMethod<GetZoneTransferTsigRequest, GetZoneTransferTsigResponse, GetZoneTransferTsigError, CloudflareOpContext>;
export type ImportRecordError = CloudflareOpError;
/** You can upload your [BIND config](https://en.wikipedia.org/wiki/Zone_file "Zone file") through this endpoint. It assumes that cURL is called from a location with bind_config.txt (valid BIND config) present. See [the documentation](https://developers.cloudflare.com/dns/manage-dns-records/how-to/import-and-export/ "Import and export records") for more information. */
export declare const importRecord: API.OperationMethod<ImportRecordRequest, ImportRecordResponse, ImportRecordError, CloudflareOpContext>;
export type ListRecordsError = Forbidden | CloudflareOpError;
/** List, search, sort, and filter a zones' DNS records. */
export declare const listRecords: API.PaginatedOperationMethod<ListRecordsRequest, ListRecordsResponse, ListRecordsError, CloudflareOpContext, RecordsListResultItem>;
export type ListSettingAccountViewsError = CloudflareOpError;
/** List DNS Internal Views for an Account */
export declare const listSettingAccountViews: API.PaginatedOperationMethod<ListSettingAccountViewsRequest, ListSettingAccountViewsResponse, ListSettingAccountViewsError, CloudflareOpContext, SettingsAccountViewsListResultItem>;
export type ListZoneTransferAclsError = CloudflareOpError;
/** List ACLs. */
export declare const listZoneTransferAcls: API.PaginatedOperationMethod<ListZoneTransferAclsRequest, ListZoneTransferAclsResponse, ListZoneTransferAclsError, CloudflareOpContext, ZoneTransfersAclsListResultItem>;
export type ListZoneTransferPeersError = CloudflareOpError;
/** List Peers. */
export declare const listZoneTransferPeers: API.PaginatedOperationMethod<ListZoneTransferPeersRequest, ListZoneTransferPeersResponse, ListZoneTransferPeersError, CloudflareOpContext, ZoneTransfersPeersListResultItem>;
export type ListZoneTransferTsigsError = CloudflareOpError;
/** List TSIGs. */
export declare const listZoneTransferTsigs: API.PaginatedOperationMethod<ListZoneTransferTsigsRequest, ListZoneTransferTsigsResponse, ListZoneTransferTsigsError, CloudflareOpContext, ZoneTransfersTsigsListResultItem>;
export type PatchDnssecError = Forbidden | CloudflareOpError;
/** Enable or disable DNSSEC. */
export declare const patchDnssec: API.OperationMethod<PatchDnssecRequest, PatchDnssecResponse, PatchDnssecError, CloudflareOpContext>;
export type PatchRecordError = CloudflareOpError;
/** Update an existing DNS record. Notes: - A/AAAA records cannot exist on the same name as CNAME records. - NS records cannot exist on the same name as any other record type. - Domain names are always represented in Punycode, even if Unicode characters were used when creating the record. */
export declare const patchRecord: API.OperationMethod<PatchRecordRequest, PatchRecordResponse, PatchRecordError, CloudflareOpContext>;
export type PatchSettingAccountError = DnsSettingNotAvailable | CloudflareOpError;
/** Update DNS settings for an account */
export declare const patchSettingAccount: API.OperationMethod<PatchSettingAccountRequest, PatchSettingAccountResponse, PatchSettingAccountError, CloudflareOpContext>;
export type PatchSettingAccountViewError = ViewNotFound | CloudflareOpError;
/** Update an existing Internal DNS View */
export declare const patchSettingAccountView: API.OperationMethod<PatchSettingAccountViewRequest, PatchSettingAccountViewResponse, PatchSettingAccountViewError, CloudflareOpContext>;
export type PatchSettingZoneError = Forbidden | CloudflareOpError;
/** Update DNS settings for a zone */
export declare const patchSettingZone: API.OperationMethod<PatchSettingZoneRequest, PatchSettingZoneResponse, PatchSettingZoneError, CloudflareOpContext>;
export type ScanListRecordError = CloudflareOpError;
/** Retrieves the list of DNS records discovered up to this point by the asynchronous scan. These records are temporary until explicitly accepted or rejected via `POST /scan/review`. Additional records may be discovered by the scan later. */
export declare const scanListRecord: API.PaginatedOperationMethod<ScanListRecordRequest, ScanListRecordResponse, ScanListRecordError, CloudflareOpContext, RecordsScanListResultItem>;
export type ScanRecordError = CloudflareOpError;
/** Scan for common DNS records on your domain and automatically add them to your zone. Useful if you haven't updated your nameservers yet. */
export declare const scanRecord: API.OperationMethod<ScanRecordRequest, ScanRecordResponse, ScanRecordError, CloudflareOpContext>;
export type ScanReviewRecordError = CloudflareOpError;
/** Accept or reject DNS records found by the DNS records scan. Accepted records will be permanently added to the zone, while rejected records will be permanently deleted. */
export declare const scanReviewRecord: API.OperationMethod<ScanReviewRecordRequest, ScanReviewRecordResponse, ScanReviewRecordError, CloudflareOpContext>;
export type ScanTriggerRecordError = CloudflareOpError;
/** Initiates an asynchronous scan for common DNS records on your domain. Note that this **does not** automatically add records to your zone. The scan runs in the background, and results can be reviewed later using the `/scan/review` endpoints. Useful if you haven't updated your nameservers yet. */
export declare const scanTriggerRecord: API.OperationMethod<ScanTriggerRecordRequest, ScanTriggerRecordResponse, ScanTriggerRecordError, CloudflareOpContext>;
export type UpdateRecordError = CloudflareOpError;
/** Overwrite an existing DNS record. Notes: - A/AAAA records cannot exist on the same name as CNAME records. - NS records cannot exist on the same name as any other record type. - Domain names are always represented in Punycode, even if Unicode characters were used when creating the record. */
export declare const updateRecord: API.OperationMethod<UpdateRecordRequest, UpdateRecordResponse, UpdateRecordError, CloudflareOpContext>;
export type UpdateZoneTransferAclError = AclNotFound | CloudflareOpError;
/** Modify ACL. */
export declare const updateZoneTransferAcl: API.OperationMethod<UpdateZoneTransferAclRequest, UpdateZoneTransferAclResponse, UpdateZoneTransferAclError, CloudflareOpContext>;
export type UpdateZoneTransferIncomingError = IncomingZoneTransferNotFound | CloudflareOpError;
/** Update secondary zone configuration for incoming zone transfers. */
export declare const updateZoneTransferIncoming: API.OperationMethod<UpdateZoneTransferIncomingRequest, UpdateZoneTransferIncomingResponse, UpdateZoneTransferIncomingError, CloudflareOpContext>;
export type UpdateZoneTransferOutgoingError = OutgoingZoneTransferNotFound | OutgoingZoneTransfersNotAllowed | CloudflareOpError;
/** Update primary zone configuration for outgoing zone transfers. */
export declare const updateZoneTransferOutgoing: API.OperationMethod<UpdateZoneTransferOutgoingRequest, UpdateZoneTransferOutgoingResponse, UpdateZoneTransferOutgoingError, CloudflareOpContext>;
export type UpdateZoneTransferPeerError = PeerNotFound | CloudflareOpError;
/** Modify Peer. */
export declare const updateZoneTransferPeer: API.OperationMethod<UpdateZoneTransferPeerRequest, UpdateZoneTransferPeerResponse, UpdateZoneTransferPeerError, CloudflareOpContext>;
export type UpdateZoneTransferTsigError = TsigNotFound | CloudflareOpError;
/** Modify TSIG. */
export declare const updateZoneTransferTsig: API.OperationMethod<UpdateZoneTransferTsigRequest, UpdateZoneTransferTsigResponse, UpdateZoneTransferTsigError, CloudflareOpContext>;
//# sourceMappingURL=dns.d.ts.map