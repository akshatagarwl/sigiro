import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const FiltersRequired_base: S.Class<FiltersRequired, S.TaggedStruct<"FiltersRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FiltersRequired extends /*@__PURE__*/ FiltersRequired_base {
}
declare const InvalidAlertType_base: S.Class<InvalidAlertType, S.TaggedStruct<"InvalidAlertType", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidAlertType extends /*@__PURE__*/ InvalidAlertType_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidSilence_base: S.Class<InvalidSilence, S.TaggedStruct<"InvalidSilence", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSilence extends /*@__PURE__*/ InvalidSilence_base {
}
declare const InvalidWebhookId_base: S.Class<InvalidWebhookId, S.TaggedStruct<"InvalidWebhookId", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidWebhookId extends /*@__PURE__*/ InvalidWebhookId_base {
}
declare const MechanismRequired_base: S.Class<MechanismRequired, S.TaggedStruct<"MechanismRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MechanismRequired extends /*@__PURE__*/ MechanismRequired_base {
}
declare const PolicyNotFound_base: S.Class<PolicyNotFound, S.TaggedStruct<"PolicyNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PolicyNotFound extends /*@__PURE__*/ PolicyNotFound_base {
}
declare const SilenceAlreadyExists_base: S.Class<SilenceAlreadyExists, S.TaggedStruct<"SilenceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SilenceAlreadyExists extends /*@__PURE__*/ SilenceAlreadyExists_base {
}
declare const SilenceNotFound_base: S.Class<SilenceNotFound, S.TaggedStruct<"SilenceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SilenceNotFound extends /*@__PURE__*/ SilenceNotFound_base {
}
declare const WebhookNotFound_base: S.Class<WebhookNotFound, S.TaggedStruct<"WebhookNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WebhookNotFound extends /*@__PURE__*/ WebhookNotFound_base {
}
declare const WebhookTestFailed_base: S.Class<WebhookTestFailed, S.TaggedStruct<"WebhookTestFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WebhookTestFailed extends /*@__PURE__*/ WebhookTestFailed_base {
}
export interface CreateDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
}
export declare const CreateDestinationPagerdutyRequest: S.Schema<CreateDestinationPagerdutyRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDestinationPagerdutyResponse {
    /** token in form of UUID */
    id?: string | null;
}
export declare const CreateDestinationPagerdutyResponse: S.Schema<CreateDestinationPagerdutyResponse>;
export interface CreateDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name: string;
    /** The POST endpoint to call when dispatching a notification. */
    url: string;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string;
}
export declare const CreateDestinationWebhookRequest: S.Schema<CreateDestinationWebhookRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDestinationWebhookResponse {
    /** UUID */
    id?: string | null;
}
export declare const CreateDestinationWebhookResponse: S.Schema<CreateDestinationWebhookResponse>;
export type PoliciesCreateRequestAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type";
export declare const PoliciesCreateRequestAlertType: any;
export interface PoliciesCreateRequestMechanismsEmailItem {
    /** The email address */
    id?: string;
}
export declare const PoliciesCreateRequestMechanismsEmailItem: S.Schema<PoliciesCreateRequestMechanismsEmailItem>;
export type PoliciesCreateRequestMechanismsEmailList = Array<PoliciesCreateRequestMechanismsEmailItem>;
export declare const PoliciesCreateRequestMechanismsEmailList: S.Schema<PoliciesCreateRequestMechanismsEmailList>;
export interface PoliciesCreateRequestMechanismsPagerdutyItem {
    /** UUID */
    id?: string;
}
export declare const PoliciesCreateRequestMechanismsPagerdutyItem: S.Schema<PoliciesCreateRequestMechanismsPagerdutyItem>;
export type PoliciesCreateRequestMechanismsPagerdutyList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export declare const PoliciesCreateRequestMechanismsPagerdutyList: S.Schema<PoliciesCreateRequestMechanismsPagerdutyList>;
export type PoliciesCreateRequestMechanismsWebhooksItem = PoliciesCreateRequestMechanismsPagerdutyItem;
export declare const PoliciesCreateRequestMechanismsWebhooksItem: S.Schema<PoliciesCreateRequestMechanismsPagerdutyItem>;
export type PoliciesCreateRequestMechanismsWebhooksList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export declare const PoliciesCreateRequestMechanismsWebhooksList: S.Schema<PoliciesCreateRequestMechanismsWebhooksList>;
export interface PoliciesCreateRequestMechanisms {
    email?: PoliciesCreateRequestMechanismsEmailList;
    pagerduty?: PoliciesCreateRequestMechanismsPagerdutyList;
    webhooks?: PoliciesCreateRequestMechanismsWebhooksList;
}
export declare const PoliciesCreateRequestMechanisms: S.Schema<PoliciesCreateRequestMechanisms>;
export type PoliciesCreateRequestFiltersActionsList = Array<string>;
export declare const PoliciesCreateRequestFiltersActionsList: S.Schema<PoliciesCreateRequestFiltersActionsList>;
export type PoliciesCreateRequestFiltersAffectedAsnsList = Array<string>;
export declare const PoliciesCreateRequestFiltersAffectedAsnsList: S.Schema<PoliciesCreateRequestFiltersAffectedAsnsList>;
export type PoliciesCreateRequestFiltersAffectedComponentsList = Array<string>;
export declare const PoliciesCreateRequestFiltersAffectedComponentsList: S.Schema<PoliciesCreateRequestFiltersAffectedComponentsList>;
export type PoliciesCreateRequestFiltersAffectedLocationsList = Array<string>;
export declare const PoliciesCreateRequestFiltersAffectedLocationsList: S.Schema<PoliciesCreateRequestFiltersAffectedLocationsList>;
export type PoliciesCreateRequestFiltersAirportCodeList = Array<string>;
export declare const PoliciesCreateRequestFiltersAirportCodeList: S.Schema<PoliciesCreateRequestFiltersAirportCodeList>;
export type PoliciesCreateRequestFiltersAlertTriggerPreferencesList = Array<string>;
export declare const PoliciesCreateRequestFiltersAlertTriggerPreferencesList: S.Schema<PoliciesCreateRequestFiltersAlertTriggerPreferencesList>;
export type PoliciesCreateRequestFiltersAlertTriggerPreferencesValueList = Array<string>;
export declare const PoliciesCreateRequestFiltersAlertTriggerPreferencesValueList: S.Schema<PoliciesCreateRequestFiltersAlertTriggerPreferencesValueList>;
export type PoliciesCreateRequestFiltersEnabledList = Array<string>;
export declare const PoliciesCreateRequestFiltersEnabledList: S.Schema<PoliciesCreateRequestFiltersEnabledList>;
export type PoliciesCreateRequestFiltersEnvironmentList = Array<string>;
export declare const PoliciesCreateRequestFiltersEnvironmentList: S.Schema<PoliciesCreateRequestFiltersEnvironmentList>;
export type PoliciesCreateRequestFiltersEventList = Array<string>;
export declare const PoliciesCreateRequestFiltersEventList: S.Schema<PoliciesCreateRequestFiltersEventList>;
export type PoliciesCreateRequestFiltersEventSourceList = Array<string>;
export declare const PoliciesCreateRequestFiltersEventSourceList: S.Schema<PoliciesCreateRequestFiltersEventSourceList>;
export type PoliciesCreateRequestFiltersEventTypeList = Array<string>;
export declare const PoliciesCreateRequestFiltersEventTypeList: S.Schema<PoliciesCreateRequestFiltersEventTypeList>;
export type PoliciesCreateRequestFiltersGroupByList = Array<string>;
export declare const PoliciesCreateRequestFiltersGroupByList: S.Schema<PoliciesCreateRequestFiltersGroupByList>;
export type PoliciesCreateRequestFiltersHealthCheckIdList = Array<string>;
export declare const PoliciesCreateRequestFiltersHealthCheckIdList: S.Schema<PoliciesCreateRequestFiltersHealthCheckIdList>;
export type PoliciesCreateRequestFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export declare const PoliciesCreateRequestFiltersIncidentImpactItem: any;
export type PoliciesCreateRequestFiltersIncidentImpactList = Array<PoliciesCreateRequestFiltersIncidentImpactItem | (string & {})>;
export declare const PoliciesCreateRequestFiltersIncidentImpactList: S.Schema<PoliciesCreateRequestFiltersIncidentImpactList>;
export type PoliciesCreateRequestFiltersInputIdList = Array<string>;
export declare const PoliciesCreateRequestFiltersInputIdList: S.Schema<PoliciesCreateRequestFiltersInputIdList>;
export type PoliciesCreateRequestFiltersInsightClassList = Array<string>;
export declare const PoliciesCreateRequestFiltersInsightClassList: S.Schema<PoliciesCreateRequestFiltersInsightClassList>;
export type PoliciesCreateRequestFiltersLimitList = Array<string>;
export declare const PoliciesCreateRequestFiltersLimitList: S.Schema<PoliciesCreateRequestFiltersLimitList>;
export type PoliciesCreateRequestFiltersLogoTagList = Array<string>;
export declare const PoliciesCreateRequestFiltersLogoTagList: S.Schema<PoliciesCreateRequestFiltersLogoTagList>;
export type PoliciesCreateRequestFiltersMegabitsPerSecondList = Array<string>;
export declare const PoliciesCreateRequestFiltersMegabitsPerSecondList: S.Schema<PoliciesCreateRequestFiltersMegabitsPerSecondList>;
export type PoliciesCreateRequestFiltersNewHealthList = Array<string>;
export declare const PoliciesCreateRequestFiltersNewHealthList: S.Schema<PoliciesCreateRequestFiltersNewHealthList>;
export type PoliciesCreateRequestFiltersNewStatusList = Array<string>;
export declare const PoliciesCreateRequestFiltersNewStatusList: S.Schema<PoliciesCreateRequestFiltersNewStatusList>;
export type PoliciesCreateRequestFiltersPacketsPerSecondList = Array<string>;
export declare const PoliciesCreateRequestFiltersPacketsPerSecondList: S.Schema<PoliciesCreateRequestFiltersPacketsPerSecondList>;
export type PoliciesCreateRequestFiltersPoolIdList = Array<string>;
export declare const PoliciesCreateRequestFiltersPoolIdList: S.Schema<PoliciesCreateRequestFiltersPoolIdList>;
export type PoliciesCreateRequestFiltersPopNamesList = Array<string>;
export declare const PoliciesCreateRequestFiltersPopNamesList: S.Schema<PoliciesCreateRequestFiltersPopNamesList>;
export type PoliciesCreateRequestFiltersProductList = Array<string>;
export declare const PoliciesCreateRequestFiltersProductList: S.Schema<PoliciesCreateRequestFiltersProductList>;
export type PoliciesCreateRequestFiltersProjectIdList = Array<string>;
export declare const PoliciesCreateRequestFiltersProjectIdList: S.Schema<PoliciesCreateRequestFiltersProjectIdList>;
export type PoliciesCreateRequestFiltersProtocolList = Array<string>;
export declare const PoliciesCreateRequestFiltersProtocolList: S.Schema<PoliciesCreateRequestFiltersProtocolList>;
export type PoliciesCreateRequestFiltersQueryTagList = Array<string>;
export declare const PoliciesCreateRequestFiltersQueryTagList: S.Schema<PoliciesCreateRequestFiltersQueryTagList>;
export type PoliciesCreateRequestFiltersRequestsPerSecondList = Array<string>;
export declare const PoliciesCreateRequestFiltersRequestsPerSecondList: S.Schema<PoliciesCreateRequestFiltersRequestsPerSecondList>;
export type PoliciesCreateRequestFiltersSelectorsList = Array<string>;
export declare const PoliciesCreateRequestFiltersSelectorsList: S.Schema<PoliciesCreateRequestFiltersSelectorsList>;
export type PoliciesCreateRequestFiltersServicesList = Array<string>;
export declare const PoliciesCreateRequestFiltersServicesList: S.Schema<PoliciesCreateRequestFiltersServicesList>;
export type PoliciesCreateRequestFiltersSloList = Array<string>;
export declare const PoliciesCreateRequestFiltersSloList: S.Schema<PoliciesCreateRequestFiltersSloList>;
export type PoliciesCreateRequestFiltersStatusList = Array<string>;
export declare const PoliciesCreateRequestFiltersStatusList: S.Schema<PoliciesCreateRequestFiltersStatusList>;
export type PoliciesCreateRequestFiltersTargetHostnameList = Array<string>;
export declare const PoliciesCreateRequestFiltersTargetHostnameList: S.Schema<PoliciesCreateRequestFiltersTargetHostnameList>;
export type PoliciesCreateRequestFiltersTargetIpList = Array<string>;
export declare const PoliciesCreateRequestFiltersTargetIpList: S.Schema<PoliciesCreateRequestFiltersTargetIpList>;
export type PoliciesCreateRequestFiltersTargetZoneNameList = Array<string>;
export declare const PoliciesCreateRequestFiltersTargetZoneNameList: S.Schema<PoliciesCreateRequestFiltersTargetZoneNameList>;
export type PoliciesCreateRequestFiltersTrafficExclusionsItem = "security_events";
export declare const PoliciesCreateRequestFiltersTrafficExclusionsItem: any;
export type PoliciesCreateRequestFiltersTrafficExclusionsList = Array<PoliciesCreateRequestFiltersTrafficExclusionsItem | (string & {})>;
export declare const PoliciesCreateRequestFiltersTrafficExclusionsList: S.Schema<PoliciesCreateRequestFiltersTrafficExclusionsList>;
export type PoliciesCreateRequestFiltersTunnelIdList = Array<string>;
export declare const PoliciesCreateRequestFiltersTunnelIdList: S.Schema<PoliciesCreateRequestFiltersTunnelIdList>;
export type PoliciesCreateRequestFiltersTunnelNameList = Array<string>;
export declare const PoliciesCreateRequestFiltersTunnelNameList: S.Schema<PoliciesCreateRequestFiltersTunnelNameList>;
export type PoliciesCreateRequestFiltersTypeList = Array<string>;
export declare const PoliciesCreateRequestFiltersTypeList: S.Schema<PoliciesCreateRequestFiltersTypeList>;
export type PoliciesCreateRequestFiltersWhereList = Array<string>;
export declare const PoliciesCreateRequestFiltersWhereList: S.Schema<PoliciesCreateRequestFiltersWhereList>;
export type PoliciesCreateRequestFiltersZonesList = Array<string>;
export declare const PoliciesCreateRequestFiltersZonesList: S.Schema<PoliciesCreateRequestFiltersZonesList>;
export interface PoliciesCreateRequestFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesCreateRequestFiltersActionsList;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesCreateRequestFiltersAffectedAsnsList;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesCreateRequestFiltersAffectedComponentsList;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesCreateRequestFiltersAffectedLocationsList;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesCreateRequestFiltersAirportCodeList;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesCreateRequestFiltersAlertTriggerPreferencesList;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesCreateRequestFiltersAlertTriggerPreferencesValueList;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesCreateRequestFiltersEnabledList;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesCreateRequestFiltersEnvironmentList;
    /** Used for configuring pages_event_alert */
    event?: PoliciesCreateRequestFiltersEventList;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesCreateRequestFiltersEventSourceList;
    /** Usage depends on specific alert type */
    eventType?: PoliciesCreateRequestFiltersEventTypeList;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesCreateRequestFiltersGroupByList;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesCreateRequestFiltersHealthCheckIdList;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesCreateRequestFiltersIncidentImpactList;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesCreateRequestFiltersInputIdList;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesCreateRequestFiltersInsightClassList;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesCreateRequestFiltersLimitList;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesCreateRequestFiltersLogoTagList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesCreateRequestFiltersMegabitsPerSecondList;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesCreateRequestFiltersNewHealthList;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesCreateRequestFiltersNewStatusList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesCreateRequestFiltersPacketsPerSecondList;
    /** Usage depends on specific alert type */
    poolId?: PoliciesCreateRequestFiltersPoolIdList;
    /** Usage depends on specific alert type */
    popNames?: PoliciesCreateRequestFiltersPopNamesList;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesCreateRequestFiltersProductList;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesCreateRequestFiltersProjectIdList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesCreateRequestFiltersProtocolList;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesCreateRequestFiltersQueryTagList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesCreateRequestFiltersRequestsPerSecondList;
    /** Usage depends on specific alert type */
    selectors?: PoliciesCreateRequestFiltersSelectorsList;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesCreateRequestFiltersServicesList;
    /** Usage depends on specific alert type */
    slo?: PoliciesCreateRequestFiltersSloList;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesCreateRequestFiltersStatusList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesCreateRequestFiltersTargetHostnameList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesCreateRequestFiltersTargetIpList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesCreateRequestFiltersTargetZoneNameList;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesCreateRequestFiltersTrafficExclusionsList;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesCreateRequestFiltersTunnelIdList;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesCreateRequestFiltersTunnelNameList;
    /** Usage depends on specific alert type */
    type?: PoliciesCreateRequestFiltersTypeList;
    /** Usage depends on specific alert type */
    where?: PoliciesCreateRequestFiltersWhereList;
    /** Usage depends on specific alert type */
    zones?: PoliciesCreateRequestFiltersZonesList;
}
export declare const PoliciesCreateRequestFilters: S.Schema<PoliciesCreateRequestFilters>;
export interface CreatePolicyRequest {
    /** The account id */
    accountId: string;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType: PoliciesCreateRequestAlertType | (string & {});
    /** Whether or not the Notification policy is enabled. */
    enabled: boolean;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms: PoliciesCreateRequestMechanisms;
    /** Name of the policy. */
    name: string;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string;
    /** Optional description for the Notification policy. */
    description?: string;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesCreateRequestFilters;
}
export declare const CreatePolicyRequest: S.Schema<CreatePolicyRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePolicyResponse {
    /** UUID */
    id?: string | null;
}
export declare const CreatePolicyResponse: S.Schema<CreatePolicyResponse>;
export interface SilencesCreateRequestBodyItem {
    /** When the silence ends. */
    endTime?: string;
    /** The unique identifier of a notification policy */
    policyId?: string;
    /** When the silence starts. */
    startTime?: string;
}
export declare const SilencesCreateRequestBodyItem: S.Schema<SilencesCreateRequestBodyItem>;
export type SilencesCreateRequestBodyList = Array<SilencesCreateRequestBodyItem>;
export declare const SilencesCreateRequestBodyList: S.Schema<SilencesCreateRequestBodyList>;
export interface CreateSilenceRequest {
    /** The account id */
    accountId: string;
    body: SilencesCreateRequestBodyList;
}
export declare const CreateSilenceRequest: S.Schema<CreateSilenceRequest>;
export interface CreateSilenceResponse {
}
export declare const CreateSilenceResponse: S.Schema<CreateSilenceResponse>;
export interface DeleteDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
}
export declare const DeleteDestinationPagerdutyRequest: S.Schema<DeleteDestinationPagerdutyRequest>;
export interface DeleteDestinationPagerdutyResponse {
}
export declare const DeleteDestinationPagerdutyResponse: S.Schema<DeleteDestinationPagerdutyResponse>;
export interface DeleteDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a webhook */
    webhookId: string;
}
export declare const DeleteDestinationWebhookRequest: S.Schema<DeleteDestinationWebhookRequest>;
export interface DeleteDestinationWebhookResponse {
}
export declare const DeleteDestinationWebhookResponse: S.Schema<DeleteDestinationWebhookResponse>;
export interface DeletePolicyRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a notification policy */
    policyId: string;
}
export declare const DeletePolicyRequest: S.Schema<DeletePolicyRequest>;
export interface DeletePolicyResponse {
}
export declare const DeletePolicyResponse: S.Schema<DeletePolicyResponse>;
export interface DeleteSilenceRequest {
    /** The account id */
    accountId: string;
    /** Silence ID */
    silenceId: string;
}
export declare const DeleteSilenceRequest: S.Schema<DeleteSilenceRequest>;
export interface DeleteSilenceResponse {
}
export declare const DeleteSilenceResponse: S.Schema<DeleteSilenceResponse>;
export interface GetDestinationEligibleRequest {
    /** The account id */
    accountId: string;
}
export declare const GetDestinationEligibleRequest: S.Schema<GetDestinationEligibleRequest>;
export type DestinationsEligibleGetResultValueItemType = "email" | "pagerduty" | "webhook";
export declare const DestinationsEligibleGetResultValueItemType: any;
export interface DestinationsEligibleGetResultValueItem {
    /** Determines whether or not the account is eligible for the delivery mechanism. */
    eligible?: boolean | null;
    /** Beta flag. Users can create a policy with a mechanism that is not ready, but we cannot guarantee successful delivery of notifications. */
    ready?: boolean | null;
    /** Determines type of delivery mechanism. */
    type?: DestinationsEligibleGetResultValueItemType | null;
}
export declare const DestinationsEligibleGetResultValueItem: S.Schema<DestinationsEligibleGetResultValueItem>;
export type DestinationsEligibleGetResultValueList = Array<DestinationsEligibleGetResultValueItem>;
export declare const DestinationsEligibleGetResultValueList: S.Schema<DestinationsEligibleGetResultValueList>;
export type DestinationsEligibleGetResultMap = {
    [key: string]: DestinationsEligibleGetResultValueList | undefined;
};
export declare const DestinationsEligibleGetResultMap: S.Schema<DestinationsEligibleGetResultMap>;
export type GetDestinationEligibleResponse = DestinationsEligibleGetResultMap;
export declare const GetDestinationEligibleResponse: S.Schema<GetDestinationEligibleResponse>;
export interface GetDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
}
export declare const GetDestinationPagerdutyRequest: S.Schema<GetDestinationPagerdutyRequest>;
export interface DestinationsPagerdutyGetResultItem {
    /** UUID */
    id?: string | null;
    /** The name of the pagerduty service. */
    name?: string | null;
}
export declare const DestinationsPagerdutyGetResultItem: S.Schema<DestinationsPagerdutyGetResultItem>;
export type DestinationsPagerdutyGetResultList = Array<DestinationsPagerdutyGetResultItem>;
export declare const DestinationsPagerdutyGetResultList: S.Schema<DestinationsPagerdutyGetResultList>;
export interface GetDestinationPagerdutyResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DestinationsPagerdutyGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetDestinationPagerdutyResponse: S.Schema<GetDestinationPagerdutyResponse>;
export interface GetDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a webhook */
    webhookId: string;
}
export declare const GetDestinationWebhookRequest: S.Schema<GetDestinationWebhookRequest>;
export type DestinationsWebhooksGetResponseType = "datadog" | "discord" | "feishu" | "gchat" | "generic" | "opsgenie" | "slack" | "splunk";
export declare const DestinationsWebhooksGetResponseType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDestinationWebhookResponse {
    /** The unique identifier of a webhook */
    id?: string | null;
    /** Timestamp of when the webhook destination was created. */
    createdAt?: string | null;
    /** Timestamp of the last time an attempt to dispatch a notification to this webhook failed. */
    lastFailure?: string | null;
    /** Timestamp of the last time Cloudflare was able to successfully dispatch a notification using this webhook. */
    lastSuccess?: string | null;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name?: string | null;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string | null;
    /** Type of webhook endpoint. */
    type?: DestinationsWebhooksGetResponseType | null;
    /** The POST endpoint to call when dispatching a notification. */
    url?: string | null;
}
export declare const GetDestinationWebhookResponse: S.Schema<GetDestinationWebhookResponse>;
export interface GetPolicyRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a notification policy */
    policyId: string;
}
export declare const GetPolicyRequest: S.Schema<GetPolicyRequest>;
export type PoliciesGetResponseAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type";
export declare const PoliciesGetResponseAlertType: any;
export type PoliciesGetResponseFiltersActionsList = Array<string>;
export declare const PoliciesGetResponseFiltersActionsList: S.Schema<PoliciesGetResponseFiltersActionsList>;
export type PoliciesGetResponseFiltersAffectedAsnsList = Array<string>;
export declare const PoliciesGetResponseFiltersAffectedAsnsList: S.Schema<PoliciesGetResponseFiltersAffectedAsnsList>;
export type PoliciesGetResponseFiltersAffectedComponentsList = Array<string>;
export declare const PoliciesGetResponseFiltersAffectedComponentsList: S.Schema<PoliciesGetResponseFiltersAffectedComponentsList>;
export type PoliciesGetResponseFiltersAffectedLocationsList = Array<string>;
export declare const PoliciesGetResponseFiltersAffectedLocationsList: S.Schema<PoliciesGetResponseFiltersAffectedLocationsList>;
export type PoliciesGetResponseFiltersAirportCodeList = Array<string>;
export declare const PoliciesGetResponseFiltersAirportCodeList: S.Schema<PoliciesGetResponseFiltersAirportCodeList>;
export type PoliciesGetResponseFiltersAlertTriggerPreferencesList = Array<string>;
export declare const PoliciesGetResponseFiltersAlertTriggerPreferencesList: S.Schema<PoliciesGetResponseFiltersAlertTriggerPreferencesList>;
export type PoliciesGetResponseFiltersAlertTriggerPreferencesValueList = Array<string>;
export declare const PoliciesGetResponseFiltersAlertTriggerPreferencesValueList: S.Schema<PoliciesGetResponseFiltersAlertTriggerPreferencesValueList>;
export type PoliciesGetResponseFiltersEnabledList = Array<string>;
export declare const PoliciesGetResponseFiltersEnabledList: S.Schema<PoliciesGetResponseFiltersEnabledList>;
export type PoliciesGetResponseFiltersEnvironmentList = Array<string>;
export declare const PoliciesGetResponseFiltersEnvironmentList: S.Schema<PoliciesGetResponseFiltersEnvironmentList>;
export type PoliciesGetResponseFiltersEventList = Array<string>;
export declare const PoliciesGetResponseFiltersEventList: S.Schema<PoliciesGetResponseFiltersEventList>;
export type PoliciesGetResponseFiltersEventSourceList = Array<string>;
export declare const PoliciesGetResponseFiltersEventSourceList: S.Schema<PoliciesGetResponseFiltersEventSourceList>;
export type PoliciesGetResponseFiltersEventTypeList = Array<string>;
export declare const PoliciesGetResponseFiltersEventTypeList: S.Schema<PoliciesGetResponseFiltersEventTypeList>;
export type PoliciesGetResponseFiltersGroupByList = Array<string>;
export declare const PoliciesGetResponseFiltersGroupByList: S.Schema<PoliciesGetResponseFiltersGroupByList>;
export type PoliciesGetResponseFiltersHealthCheckIdList = Array<string>;
export declare const PoliciesGetResponseFiltersHealthCheckIdList: S.Schema<PoliciesGetResponseFiltersHealthCheckIdList>;
export type PoliciesGetResponseFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export declare const PoliciesGetResponseFiltersIncidentImpactItem: any;
export type PoliciesGetResponseFiltersIncidentImpactList = Array<PoliciesGetResponseFiltersIncidentImpactItem>;
export declare const PoliciesGetResponseFiltersIncidentImpactList: S.Schema<PoliciesGetResponseFiltersIncidentImpactList>;
export type PoliciesGetResponseFiltersInputIdList = Array<string>;
export declare const PoliciesGetResponseFiltersInputIdList: S.Schema<PoliciesGetResponseFiltersInputIdList>;
export type PoliciesGetResponseFiltersInsightClassList = Array<string>;
export declare const PoliciesGetResponseFiltersInsightClassList: S.Schema<PoliciesGetResponseFiltersInsightClassList>;
export type PoliciesGetResponseFiltersLimitList = Array<string>;
export declare const PoliciesGetResponseFiltersLimitList: S.Schema<PoliciesGetResponseFiltersLimitList>;
export type PoliciesGetResponseFiltersLogoTagList = Array<string>;
export declare const PoliciesGetResponseFiltersLogoTagList: S.Schema<PoliciesGetResponseFiltersLogoTagList>;
export type PoliciesGetResponseFiltersMegabitsPerSecondList = Array<string>;
export declare const PoliciesGetResponseFiltersMegabitsPerSecondList: S.Schema<PoliciesGetResponseFiltersMegabitsPerSecondList>;
export type PoliciesGetResponseFiltersNewHealthList = Array<string>;
export declare const PoliciesGetResponseFiltersNewHealthList: S.Schema<PoliciesGetResponseFiltersNewHealthList>;
export type PoliciesGetResponseFiltersNewStatusList = Array<string>;
export declare const PoliciesGetResponseFiltersNewStatusList: S.Schema<PoliciesGetResponseFiltersNewStatusList>;
export type PoliciesGetResponseFiltersPacketsPerSecondList = Array<string>;
export declare const PoliciesGetResponseFiltersPacketsPerSecondList: S.Schema<PoliciesGetResponseFiltersPacketsPerSecondList>;
export type PoliciesGetResponseFiltersPoolIdList = Array<string>;
export declare const PoliciesGetResponseFiltersPoolIdList: S.Schema<PoliciesGetResponseFiltersPoolIdList>;
export type PoliciesGetResponseFiltersPopNamesList = Array<string>;
export declare const PoliciesGetResponseFiltersPopNamesList: S.Schema<PoliciesGetResponseFiltersPopNamesList>;
export type PoliciesGetResponseFiltersProductList = Array<string>;
export declare const PoliciesGetResponseFiltersProductList: S.Schema<PoliciesGetResponseFiltersProductList>;
export type PoliciesGetResponseFiltersProjectIdList = Array<string>;
export declare const PoliciesGetResponseFiltersProjectIdList: S.Schema<PoliciesGetResponseFiltersProjectIdList>;
export type PoliciesGetResponseFiltersProtocolList = Array<string>;
export declare const PoliciesGetResponseFiltersProtocolList: S.Schema<PoliciesGetResponseFiltersProtocolList>;
export type PoliciesGetResponseFiltersQueryTagList = Array<string>;
export declare const PoliciesGetResponseFiltersQueryTagList: S.Schema<PoliciesGetResponseFiltersQueryTagList>;
export type PoliciesGetResponseFiltersRequestsPerSecondList = Array<string>;
export declare const PoliciesGetResponseFiltersRequestsPerSecondList: S.Schema<PoliciesGetResponseFiltersRequestsPerSecondList>;
export type PoliciesGetResponseFiltersSelectorsList = Array<string>;
export declare const PoliciesGetResponseFiltersSelectorsList: S.Schema<PoliciesGetResponseFiltersSelectorsList>;
export type PoliciesGetResponseFiltersServicesList = Array<string>;
export declare const PoliciesGetResponseFiltersServicesList: S.Schema<PoliciesGetResponseFiltersServicesList>;
export type PoliciesGetResponseFiltersSloList = Array<string>;
export declare const PoliciesGetResponseFiltersSloList: S.Schema<PoliciesGetResponseFiltersSloList>;
export type PoliciesGetResponseFiltersStatusList = Array<string>;
export declare const PoliciesGetResponseFiltersStatusList: S.Schema<PoliciesGetResponseFiltersStatusList>;
export type PoliciesGetResponseFiltersTargetHostnameList = Array<string>;
export declare const PoliciesGetResponseFiltersTargetHostnameList: S.Schema<PoliciesGetResponseFiltersTargetHostnameList>;
export type PoliciesGetResponseFiltersTargetIpList = Array<string>;
export declare const PoliciesGetResponseFiltersTargetIpList: S.Schema<PoliciesGetResponseFiltersTargetIpList>;
export type PoliciesGetResponseFiltersTargetZoneNameList = Array<string>;
export declare const PoliciesGetResponseFiltersTargetZoneNameList: S.Schema<PoliciesGetResponseFiltersTargetZoneNameList>;
export type PoliciesGetResponseFiltersTrafficExclusionsItem = "security_events";
export declare const PoliciesGetResponseFiltersTrafficExclusionsItem: any;
export type PoliciesGetResponseFiltersTrafficExclusionsList = Array<PoliciesGetResponseFiltersTrafficExclusionsItem>;
export declare const PoliciesGetResponseFiltersTrafficExclusionsList: S.Schema<PoliciesGetResponseFiltersTrafficExclusionsList>;
export type PoliciesGetResponseFiltersTunnelIdList = Array<string>;
export declare const PoliciesGetResponseFiltersTunnelIdList: S.Schema<PoliciesGetResponseFiltersTunnelIdList>;
export type PoliciesGetResponseFiltersTunnelNameList = Array<string>;
export declare const PoliciesGetResponseFiltersTunnelNameList: S.Schema<PoliciesGetResponseFiltersTunnelNameList>;
export type PoliciesGetResponseFiltersTypeList = Array<string>;
export declare const PoliciesGetResponseFiltersTypeList: S.Schema<PoliciesGetResponseFiltersTypeList>;
export type PoliciesGetResponseFiltersWhereList = Array<string>;
export declare const PoliciesGetResponseFiltersWhereList: S.Schema<PoliciesGetResponseFiltersWhereList>;
export type PoliciesGetResponseFiltersZonesList = Array<string>;
export declare const PoliciesGetResponseFiltersZonesList: S.Schema<PoliciesGetResponseFiltersZonesList>;
export interface PoliciesGetResponseFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesGetResponseFiltersActionsList | null;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesGetResponseFiltersAffectedAsnsList | null;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesGetResponseFiltersAffectedComponentsList | null;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesGetResponseFiltersAffectedLocationsList | null;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesGetResponseFiltersAirportCodeList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesGetResponseFiltersAlertTriggerPreferencesList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesGetResponseFiltersAlertTriggerPreferencesValueList | null;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesGetResponseFiltersEnabledList | null;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesGetResponseFiltersEnvironmentList | null;
    /** Used for configuring pages_event_alert */
    event?: PoliciesGetResponseFiltersEventList | null;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesGetResponseFiltersEventSourceList | null;
    /** Usage depends on specific alert type */
    eventType?: PoliciesGetResponseFiltersEventTypeList | null;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesGetResponseFiltersGroupByList | null;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesGetResponseFiltersHealthCheckIdList | null;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesGetResponseFiltersIncidentImpactList | null;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesGetResponseFiltersInputIdList | null;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesGetResponseFiltersInsightClassList | null;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesGetResponseFiltersLimitList | null;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesGetResponseFiltersLogoTagList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesGetResponseFiltersMegabitsPerSecondList | null;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesGetResponseFiltersNewHealthList | null;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesGetResponseFiltersNewStatusList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesGetResponseFiltersPacketsPerSecondList | null;
    /** Usage depends on specific alert type */
    poolId?: PoliciesGetResponseFiltersPoolIdList | null;
    /** Usage depends on specific alert type */
    popNames?: PoliciesGetResponseFiltersPopNamesList | null;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesGetResponseFiltersProductList | null;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesGetResponseFiltersProjectIdList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesGetResponseFiltersProtocolList | null;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesGetResponseFiltersQueryTagList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesGetResponseFiltersRequestsPerSecondList | null;
    /** Usage depends on specific alert type */
    selectors?: PoliciesGetResponseFiltersSelectorsList | null;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesGetResponseFiltersServicesList | null;
    /** Usage depends on specific alert type */
    slo?: PoliciesGetResponseFiltersSloList | null;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesGetResponseFiltersStatusList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesGetResponseFiltersTargetHostnameList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesGetResponseFiltersTargetIpList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesGetResponseFiltersTargetZoneNameList | null;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesGetResponseFiltersTrafficExclusionsList | null;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesGetResponseFiltersTunnelIdList | null;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesGetResponseFiltersTunnelNameList | null;
    /** Usage depends on specific alert type */
    type?: PoliciesGetResponseFiltersTypeList | null;
    /** Usage depends on specific alert type */
    where?: PoliciesGetResponseFiltersWhereList | null;
    /** Usage depends on specific alert type */
    zones?: PoliciesGetResponseFiltersZonesList | null;
}
export declare const PoliciesGetResponseFilters: S.Schema<PoliciesGetResponseFilters>;
export interface PoliciesGetResponseMechanismsEmailItem {
    /** The email address */
    id?: string | null;
}
export declare const PoliciesGetResponseMechanismsEmailItem: S.Schema<PoliciesGetResponseMechanismsEmailItem>;
export type PoliciesGetResponseMechanismsEmailList = Array<PoliciesGetResponseMechanismsEmailItem>;
export declare const PoliciesGetResponseMechanismsEmailList: S.Schema<PoliciesGetResponseMechanismsEmailList>;
export interface PoliciesGetResponseMechanismsPagerdutyItem {
    /** UUID */
    id?: string | null;
}
export declare const PoliciesGetResponseMechanismsPagerdutyItem: S.Schema<PoliciesGetResponseMechanismsPagerdutyItem>;
export type PoliciesGetResponseMechanismsPagerdutyList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export declare const PoliciesGetResponseMechanismsPagerdutyList: S.Schema<PoliciesGetResponseMechanismsPagerdutyList>;
export type PoliciesGetResponseMechanismsWebhooksItem = PoliciesGetResponseMechanismsPagerdutyItem;
export declare const PoliciesGetResponseMechanismsWebhooksItem: S.Schema<PoliciesGetResponseMechanismsPagerdutyItem>;
export type PoliciesGetResponseMechanismsWebhooksList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export declare const PoliciesGetResponseMechanismsWebhooksList: S.Schema<PoliciesGetResponseMechanismsWebhooksList>;
export interface PoliciesGetResponseMechanisms {
    email?: PoliciesGetResponseMechanismsEmailList | null;
    pagerduty?: PoliciesGetResponseMechanismsPagerdutyList | null;
    webhooks?: PoliciesGetResponseMechanismsWebhooksList | null;
}
export declare const PoliciesGetResponseMechanisms: S.Schema<PoliciesGetResponseMechanisms>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPolicyResponse {
    /** The unique identifier of a notification policy */
    id?: string | null;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string | null;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType?: PoliciesGetResponseAlertType | null;
    created?: string | null;
    /** Optional description for the Notification policy. */
    description?: string | null;
    /** Whether or not the Notification policy is enabled. */
    enabled?: boolean | null;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesGetResponseFilters | null;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms?: PoliciesGetResponseMechanisms | null;
    modified?: string | null;
    /** Name of the policy. */
    name?: string | null;
}
export declare const GetPolicyResponse: S.Schema<GetPolicyResponse>;
export interface GetSilenceRequest {
    /** The account id */
    accountId: string;
    /** Silence ID */
    silenceId: string;
}
export declare const GetSilenceRequest: S.Schema<GetSilenceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSilenceResponse {
    /** Silence ID */
    id?: string | null;
    /** When the silence was created. */
    createdAt?: string | null;
    /** When the silence ends. */
    endTime?: string | null;
    /** The unique identifier of a notification policy */
    policyId?: string | null;
    /** When the silence starts. */
    startTime?: string | null;
    /** When the silence was modified. */
    updatedAt?: string | null;
}
export declare const GetSilenceResponse: S.Schema<GetSilenceResponse>;
export interface LinkDestinationPagerdutyRequest {
    /** The account id */
    accountId: string;
    /** The token integration key */
    tokenId: string;
}
export declare const LinkDestinationPagerdutyRequest: S.Schema<LinkDestinationPagerdutyRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface LinkDestinationPagerdutyResponse {
    /** UUID */
    id?: string | null;
}
export declare const LinkDestinationPagerdutyResponse: S.Schema<LinkDestinationPagerdutyResponse>;
export interface ListAvailableAlertsRequest {
    /** The account id */
    accountId: string;
}
export declare const ListAvailableAlertsRequest: S.Schema<ListAvailableAlertsRequest>;
export type AvailableAlertsListResultValueItemFilterOptionsList = Array<unknown>;
export declare const AvailableAlertsListResultValueItemFilterOptionsList: S.Schema<AvailableAlertsListResultValueItemFilterOptionsList>;
export interface AvailableAlertsListResultValueItem {
    /** Describes the alert type. */
    description?: string | null;
    /** Alert type name. */
    displayName?: string | null;
    /** Format of additional configuration options (filters) for the alert type. Data type of filters during policy creation: Array of strings. */
    filterOptions?: AvailableAlertsListResultValueItemFilterOptionsList | null;
    /** Use this value when creating and updating a notification policy. */
    type?: string | null;
}
export declare const AvailableAlertsListResultValueItem: S.Schema<AvailableAlertsListResultValueItem>;
export type AvailableAlertsListResultValueList = Array<AvailableAlertsListResultValueItem>;
export declare const AvailableAlertsListResultValueList: S.Schema<AvailableAlertsListResultValueList>;
export type AvailableAlertsListResultMap = {
    [key: string]: AvailableAlertsListResultValueList | undefined;
};
export declare const AvailableAlertsListResultMap: S.Schema<AvailableAlertsListResultMap>;
export type ListAvailableAlertsResponse = AvailableAlertsListResultMap;
export declare const ListAvailableAlertsResponse: S.Schema<ListAvailableAlertsResponse>;
export interface ListDestinationWebhooksRequest {
    /** The account id */
    accountId: string;
}
export declare const ListDestinationWebhooksRequest: S.Schema<ListDestinationWebhooksRequest>;
export type DestinationsWebhooksListResultItemType = "datadog" | "discord" | "feishu" | "gchat" | "generic" | "opsgenie" | "slack" | "splunk";
export declare const DestinationsWebhooksListResultItemType: any;
export interface DestinationsWebhooksListResultItem {
    /** The unique identifier of a webhook */
    id?: string | null;
    /** Timestamp of when the webhook destination was created. */
    createdAt?: string | null;
    /** Timestamp of the last time an attempt to dispatch a notification to this webhook failed. */
    lastFailure?: string | null;
    /** Timestamp of the last time Cloudflare was able to successfully dispatch a notification using this webhook. */
    lastSuccess?: string | null;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name?: string | null;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string | null;
    /** Type of webhook endpoint. */
    type?: DestinationsWebhooksListResultItemType | null;
    /** The POST endpoint to call when dispatching a notification. */
    url?: string | null;
}
export declare const DestinationsWebhooksListResultItem: S.Schema<DestinationsWebhooksListResultItem>;
export type DestinationsWebhooksListResultList = Array<DestinationsWebhooksListResultItem>;
export declare const DestinationsWebhooksListResultList: S.Schema<DestinationsWebhooksListResultList>;
export interface ListDestinationWebhooksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DestinationsWebhooksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDestinationWebhooksResponse: S.Schema<ListDestinationWebhooksResponse>;
export interface ListHistoriesRequest {
    /** The account id */
    accountId: string;
    /** Limit the returned results to history records older than the specified date. This must be a timestamp that conforms to RFC3339. */
    before?: string;
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
    /** Limit the returned results to history records newer than the specified date. This must be a timestamp that conforms to RFC3339. */
    since?: string;
}
export declare const ListHistoriesRequest: S.Schema<ListHistoriesRequest>;
export type HistoryListResultItemMechanismType = "email" | "pagerduty" | "webhook";
export declare const HistoryListResultItemMechanismType: any;
export interface HistoryListResultItem {
    /** UUID */
    id?: string | null;
    /** Message body included in the notification sent. */
    alertBody?: string | null;
    /** Type of notification that has been dispatched. */
    alertType?: string | null;
    /** Description of the notification policy (if present). */
    description?: string | null;
    /** The mechanism to which the notification has been dispatched. */
    mechanism?: string | null;
    /** The type of mechanism to which the notification has been dispatched. This can be email/pagerduty/webhook based on the mechanism configured. */
    mechanismType?: HistoryListResultItemMechanismType | null;
    /** Name of the policy. */
    name?: string | null;
    /** The unique identifier of a notification policy */
    policyId?: string | null;
    /** Timestamp of when the notification was dispatched in ISO 8601 format. */
    sent?: string | null;
}
export declare const HistoryListResultItem: S.Schema<HistoryListResultItem>;
export type HistoryListResultList = Array<HistoryListResultItem>;
export declare const HistoryListResultList: S.Schema<HistoryListResultList>;
export interface ListHistoriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: HistoryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListHistoriesResponse: S.Schema<ListHistoriesResponse>;
export interface ListPoliciesRequest {
    /** The account id */
    accountId: string;
}
export declare const ListPoliciesRequest: S.Schema<ListPoliciesRequest>;
export type PoliciesListResultItemAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type";
export declare const PoliciesListResultItemAlertType: any;
export type PoliciesListResultItemFiltersActionsList = Array<string>;
export declare const PoliciesListResultItemFiltersActionsList: S.Schema<PoliciesListResultItemFiltersActionsList>;
export type PoliciesListResultItemFiltersAffectedAsnsList = Array<string>;
export declare const PoliciesListResultItemFiltersAffectedAsnsList: S.Schema<PoliciesListResultItemFiltersAffectedAsnsList>;
export type PoliciesListResultItemFiltersAffectedComponentsList = Array<string>;
export declare const PoliciesListResultItemFiltersAffectedComponentsList: S.Schema<PoliciesListResultItemFiltersAffectedComponentsList>;
export type PoliciesListResultItemFiltersAffectedLocationsList = Array<string>;
export declare const PoliciesListResultItemFiltersAffectedLocationsList: S.Schema<PoliciesListResultItemFiltersAffectedLocationsList>;
export type PoliciesListResultItemFiltersAirportCodeList = Array<string>;
export declare const PoliciesListResultItemFiltersAirportCodeList: S.Schema<PoliciesListResultItemFiltersAirportCodeList>;
export type PoliciesListResultItemFiltersAlertTriggerPreferencesList = Array<string>;
export declare const PoliciesListResultItemFiltersAlertTriggerPreferencesList: S.Schema<PoliciesListResultItemFiltersAlertTriggerPreferencesList>;
export type PoliciesListResultItemFiltersAlertTriggerPreferencesValueList = Array<string>;
export declare const PoliciesListResultItemFiltersAlertTriggerPreferencesValueList: S.Schema<PoliciesListResultItemFiltersAlertTriggerPreferencesValueList>;
export type PoliciesListResultItemFiltersEnabledList = Array<string>;
export declare const PoliciesListResultItemFiltersEnabledList: S.Schema<PoliciesListResultItemFiltersEnabledList>;
export type PoliciesListResultItemFiltersEnvironmentList = Array<string>;
export declare const PoliciesListResultItemFiltersEnvironmentList: S.Schema<PoliciesListResultItemFiltersEnvironmentList>;
export type PoliciesListResultItemFiltersEventList = Array<string>;
export declare const PoliciesListResultItemFiltersEventList: S.Schema<PoliciesListResultItemFiltersEventList>;
export type PoliciesListResultItemFiltersEventSourceList = Array<string>;
export declare const PoliciesListResultItemFiltersEventSourceList: S.Schema<PoliciesListResultItemFiltersEventSourceList>;
export type PoliciesListResultItemFiltersEventTypeList = Array<string>;
export declare const PoliciesListResultItemFiltersEventTypeList: S.Schema<PoliciesListResultItemFiltersEventTypeList>;
export type PoliciesListResultItemFiltersGroupByList = Array<string>;
export declare const PoliciesListResultItemFiltersGroupByList: S.Schema<PoliciesListResultItemFiltersGroupByList>;
export type PoliciesListResultItemFiltersHealthCheckIdList = Array<string>;
export declare const PoliciesListResultItemFiltersHealthCheckIdList: S.Schema<PoliciesListResultItemFiltersHealthCheckIdList>;
export type PoliciesListResultItemFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export declare const PoliciesListResultItemFiltersIncidentImpactItem: any;
export type PoliciesListResultItemFiltersIncidentImpactList = Array<PoliciesListResultItemFiltersIncidentImpactItem>;
export declare const PoliciesListResultItemFiltersIncidentImpactList: S.Schema<PoliciesListResultItemFiltersIncidentImpactList>;
export type PoliciesListResultItemFiltersInputIdList = Array<string>;
export declare const PoliciesListResultItemFiltersInputIdList: S.Schema<PoliciesListResultItemFiltersInputIdList>;
export type PoliciesListResultItemFiltersInsightClassList = Array<string>;
export declare const PoliciesListResultItemFiltersInsightClassList: S.Schema<PoliciesListResultItemFiltersInsightClassList>;
export type PoliciesListResultItemFiltersLimitList = Array<string>;
export declare const PoliciesListResultItemFiltersLimitList: S.Schema<PoliciesListResultItemFiltersLimitList>;
export type PoliciesListResultItemFiltersLogoTagList = Array<string>;
export declare const PoliciesListResultItemFiltersLogoTagList: S.Schema<PoliciesListResultItemFiltersLogoTagList>;
export type PoliciesListResultItemFiltersMegabitsPerSecondList = Array<string>;
export declare const PoliciesListResultItemFiltersMegabitsPerSecondList: S.Schema<PoliciesListResultItemFiltersMegabitsPerSecondList>;
export type PoliciesListResultItemFiltersNewHealthList = Array<string>;
export declare const PoliciesListResultItemFiltersNewHealthList: S.Schema<PoliciesListResultItemFiltersNewHealthList>;
export type PoliciesListResultItemFiltersNewStatusList = Array<string>;
export declare const PoliciesListResultItemFiltersNewStatusList: S.Schema<PoliciesListResultItemFiltersNewStatusList>;
export type PoliciesListResultItemFiltersPacketsPerSecondList = Array<string>;
export declare const PoliciesListResultItemFiltersPacketsPerSecondList: S.Schema<PoliciesListResultItemFiltersPacketsPerSecondList>;
export type PoliciesListResultItemFiltersPoolIdList = Array<string>;
export declare const PoliciesListResultItemFiltersPoolIdList: S.Schema<PoliciesListResultItemFiltersPoolIdList>;
export type PoliciesListResultItemFiltersPopNamesList = Array<string>;
export declare const PoliciesListResultItemFiltersPopNamesList: S.Schema<PoliciesListResultItemFiltersPopNamesList>;
export type PoliciesListResultItemFiltersProductList = Array<string>;
export declare const PoliciesListResultItemFiltersProductList: S.Schema<PoliciesListResultItemFiltersProductList>;
export type PoliciesListResultItemFiltersProjectIdList = Array<string>;
export declare const PoliciesListResultItemFiltersProjectIdList: S.Schema<PoliciesListResultItemFiltersProjectIdList>;
export type PoliciesListResultItemFiltersProtocolList = Array<string>;
export declare const PoliciesListResultItemFiltersProtocolList: S.Schema<PoliciesListResultItemFiltersProtocolList>;
export type PoliciesListResultItemFiltersQueryTagList = Array<string>;
export declare const PoliciesListResultItemFiltersQueryTagList: S.Schema<PoliciesListResultItemFiltersQueryTagList>;
export type PoliciesListResultItemFiltersRequestsPerSecondList = Array<string>;
export declare const PoliciesListResultItemFiltersRequestsPerSecondList: S.Schema<PoliciesListResultItemFiltersRequestsPerSecondList>;
export type PoliciesListResultItemFiltersSelectorsList = Array<string>;
export declare const PoliciesListResultItemFiltersSelectorsList: S.Schema<PoliciesListResultItemFiltersSelectorsList>;
export type PoliciesListResultItemFiltersServicesList = Array<string>;
export declare const PoliciesListResultItemFiltersServicesList: S.Schema<PoliciesListResultItemFiltersServicesList>;
export type PoliciesListResultItemFiltersSloList = Array<string>;
export declare const PoliciesListResultItemFiltersSloList: S.Schema<PoliciesListResultItemFiltersSloList>;
export type PoliciesListResultItemFiltersStatusList = Array<string>;
export declare const PoliciesListResultItemFiltersStatusList: S.Schema<PoliciesListResultItemFiltersStatusList>;
export type PoliciesListResultItemFiltersTargetHostnameList = Array<string>;
export declare const PoliciesListResultItemFiltersTargetHostnameList: S.Schema<PoliciesListResultItemFiltersTargetHostnameList>;
export type PoliciesListResultItemFiltersTargetIpList = Array<string>;
export declare const PoliciesListResultItemFiltersTargetIpList: S.Schema<PoliciesListResultItemFiltersTargetIpList>;
export type PoliciesListResultItemFiltersTargetZoneNameList = Array<string>;
export declare const PoliciesListResultItemFiltersTargetZoneNameList: S.Schema<PoliciesListResultItemFiltersTargetZoneNameList>;
export type PoliciesListResultItemFiltersTrafficExclusionsItem = "security_events";
export declare const PoliciesListResultItemFiltersTrafficExclusionsItem: any;
export type PoliciesListResultItemFiltersTrafficExclusionsList = Array<PoliciesListResultItemFiltersTrafficExclusionsItem>;
export declare const PoliciesListResultItemFiltersTrafficExclusionsList: S.Schema<PoliciesListResultItemFiltersTrafficExclusionsList>;
export type PoliciesListResultItemFiltersTunnelIdList = Array<string>;
export declare const PoliciesListResultItemFiltersTunnelIdList: S.Schema<PoliciesListResultItemFiltersTunnelIdList>;
export type PoliciesListResultItemFiltersTunnelNameList = Array<string>;
export declare const PoliciesListResultItemFiltersTunnelNameList: S.Schema<PoliciesListResultItemFiltersTunnelNameList>;
export type PoliciesListResultItemFiltersTypeList = Array<string>;
export declare const PoliciesListResultItemFiltersTypeList: S.Schema<PoliciesListResultItemFiltersTypeList>;
export type PoliciesListResultItemFiltersWhereList = Array<string>;
export declare const PoliciesListResultItemFiltersWhereList: S.Schema<PoliciesListResultItemFiltersWhereList>;
export type PoliciesListResultItemFiltersZonesList = Array<string>;
export declare const PoliciesListResultItemFiltersZonesList: S.Schema<PoliciesListResultItemFiltersZonesList>;
export interface PoliciesListResultItemFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesListResultItemFiltersActionsList | null;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesListResultItemFiltersAffectedAsnsList | null;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesListResultItemFiltersAffectedComponentsList | null;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesListResultItemFiltersAffectedLocationsList | null;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesListResultItemFiltersAirportCodeList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesListResultItemFiltersAlertTriggerPreferencesList | null;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesListResultItemFiltersAlertTriggerPreferencesValueList | null;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesListResultItemFiltersEnabledList | null;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesListResultItemFiltersEnvironmentList | null;
    /** Used for configuring pages_event_alert */
    event?: PoliciesListResultItemFiltersEventList | null;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesListResultItemFiltersEventSourceList | null;
    /** Usage depends on specific alert type */
    eventType?: PoliciesListResultItemFiltersEventTypeList | null;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesListResultItemFiltersGroupByList | null;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesListResultItemFiltersHealthCheckIdList | null;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesListResultItemFiltersIncidentImpactList | null;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesListResultItemFiltersInputIdList | null;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesListResultItemFiltersInsightClassList | null;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesListResultItemFiltersLimitList | null;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesListResultItemFiltersLogoTagList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesListResultItemFiltersMegabitsPerSecondList | null;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesListResultItemFiltersNewHealthList | null;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesListResultItemFiltersNewStatusList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesListResultItemFiltersPacketsPerSecondList | null;
    /** Usage depends on specific alert type */
    poolId?: PoliciesListResultItemFiltersPoolIdList | null;
    /** Usage depends on specific alert type */
    popNames?: PoliciesListResultItemFiltersPopNamesList | null;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesListResultItemFiltersProductList | null;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesListResultItemFiltersProjectIdList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesListResultItemFiltersProtocolList | null;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesListResultItemFiltersQueryTagList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesListResultItemFiltersRequestsPerSecondList | null;
    /** Usage depends on specific alert type */
    selectors?: PoliciesListResultItemFiltersSelectorsList | null;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesListResultItemFiltersServicesList | null;
    /** Usage depends on specific alert type */
    slo?: PoliciesListResultItemFiltersSloList | null;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesListResultItemFiltersStatusList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesListResultItemFiltersTargetHostnameList | null;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesListResultItemFiltersTargetIpList | null;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesListResultItemFiltersTargetZoneNameList | null;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesListResultItemFiltersTrafficExclusionsList | null;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesListResultItemFiltersTunnelIdList | null;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesListResultItemFiltersTunnelNameList | null;
    /** Usage depends on specific alert type */
    type?: PoliciesListResultItemFiltersTypeList | null;
    /** Usage depends on specific alert type */
    where?: PoliciesListResultItemFiltersWhereList | null;
    /** Usage depends on specific alert type */
    zones?: PoliciesListResultItemFiltersZonesList | null;
}
export declare const PoliciesListResultItemFilters: S.Schema<PoliciesListResultItemFilters>;
export type PoliciesListResultItemMechanismsEmailItem = PoliciesGetResponseMechanismsEmailItem;
export declare const PoliciesListResultItemMechanismsEmailItem: S.Schema<PoliciesGetResponseMechanismsEmailItem>;
export type PoliciesListResultItemMechanismsEmailList = Array<PoliciesGetResponseMechanismsEmailItem>;
export declare const PoliciesListResultItemMechanismsEmailList: S.Schema<PoliciesListResultItemMechanismsEmailList>;
export type PoliciesListResultItemMechanismsPagerdutyItem = PoliciesGetResponseMechanismsPagerdutyItem;
export declare const PoliciesListResultItemMechanismsPagerdutyItem: S.Schema<PoliciesGetResponseMechanismsPagerdutyItem>;
export type PoliciesListResultItemMechanismsPagerdutyList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export declare const PoliciesListResultItemMechanismsPagerdutyList: S.Schema<PoliciesListResultItemMechanismsPagerdutyList>;
export type PoliciesListResultItemMechanismsWebhooksItem = PoliciesGetResponseMechanismsPagerdutyItem;
export declare const PoliciesListResultItemMechanismsWebhooksItem: S.Schema<PoliciesGetResponseMechanismsPagerdutyItem>;
export type PoliciesListResultItemMechanismsWebhooksList = Array<PoliciesGetResponseMechanismsPagerdutyItem>;
export declare const PoliciesListResultItemMechanismsWebhooksList: S.Schema<PoliciesListResultItemMechanismsWebhooksList>;
export interface PoliciesListResultItemMechanisms {
    email?: PoliciesListResultItemMechanismsEmailList | null;
    pagerduty?: PoliciesListResultItemMechanismsPagerdutyList | null;
    webhooks?: PoliciesListResultItemMechanismsWebhooksList | null;
}
export declare const PoliciesListResultItemMechanisms: S.Schema<PoliciesListResultItemMechanisms>;
export interface PoliciesListResultItem {
    /** The unique identifier of a notification policy */
    id?: string | null;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string | null;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType?: PoliciesListResultItemAlertType | null;
    created?: string | null;
    /** Optional description for the Notification policy. */
    description?: string | null;
    /** Whether or not the Notification policy is enabled. */
    enabled?: boolean | null;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesListResultItemFilters | null;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms?: PoliciesListResultItemMechanisms | null;
    modified?: string | null;
    /** Name of the policy. */
    name?: string | null;
}
export declare const PoliciesListResultItem: S.Schema<PoliciesListResultItem>;
export type PoliciesListResultList = Array<PoliciesListResultItem>;
export declare const PoliciesListResultList: S.Schema<PoliciesListResultList>;
export interface ListPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPoliciesResponse: S.Schema<ListPoliciesResponse>;
export interface ListSilencesRequest {
    /** The account id */
    accountId: string;
}
export declare const ListSilencesRequest: S.Schema<ListSilencesRequest>;
export interface SilencesListResultItem {
    /** Silence ID */
    id?: string | null;
    /** When the silence was created. */
    createdAt?: string | null;
    /** When the silence ends. */
    endTime?: string | null;
    /** The unique identifier of a notification policy */
    policyId?: string | null;
    /** When the silence starts. */
    startTime?: string | null;
    /** When the silence was modified. */
    updatedAt?: string | null;
}
export declare const SilencesListResultItem: S.Schema<SilencesListResultItem>;
export type SilencesListResultList = Array<SilencesListResultItem>;
export declare const SilencesListResultList: S.Schema<SilencesListResultList>;
export interface ListSilencesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SilencesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSilencesResponse: S.Schema<ListSilencesResponse>;
export interface UpdateDestinationWebhookRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a webhook */
    webhookId: string;
    /** The name of the webhook destination. This will be included in the request body when you receive a webhook notification. */
    name: string;
    /** The POST endpoint to call when dispatching a notification. */
    url: string;
    /** Optional secret that will be passed in the `cf-webhook-auth` header when dispatching generic webhook notifications or formatted for supported destinations. Secrets are not returned in any API response body. */
    secret?: string;
}
export declare const UpdateDestinationWebhookRequest: S.Schema<UpdateDestinationWebhookRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateDestinationWebhookResponse {
    /** UUID */
    id?: string | null;
}
export declare const UpdateDestinationWebhookResponse: S.Schema<UpdateDestinationWebhookResponse>;
export type PoliciesUpdateRequestAlertType = "abuse_report_alert" | "access_custom_certificate_expiration_type" | "advanced_ddos_attack_l4_alert" | "advanced_ddos_attack_l7_alert" | "advanced_http_alert_error" | "bgp_hijack_notification" | "billing_usage_alert" | "block_notification_block_removed" | "block_notification_new_block" | "block_notification_review_rejected" | "bot_traffic_basic_alert" | "brand_protection_alert" | "brand_protection_digest" | "clickhouse_alert_fw_anomaly" | "clickhouse_alert_fw_ent_anomaly" | "cloudforce_one_request_notification" | "cni_maintenance_notification" | "custom_analytics" | "custom_bot_detection_alert" | "custom_ssl_certificate_event_type" | "dedicated_ssl_certificate_event_type" | "device_connectivity_anomaly_alert" | "dos_attack_l4" | "dos_attack_l7" | "expiring_service_token_alert" | "failing_logpush_job_disabled_alert" | "fbm_auto_advertisement" | "fbm_dosd_attack" | "fbm_volumetric_attack" | "health_check_status_notification" | "hostname_aop_custom_certificate_expiration_type" | "http_alert_edge_error" | "http_alert_origin_error" | "image_notification" | "image_resizing_notification" | "incident_alert" | "load_balancing_health_alert" | "load_balancing_pool_enablement_alert" | "logo_match_alert" | "magic_tunnel_health_check_event" | "magic_wan_tunnel_health" | "maintenance_event_notification" | "mtls_certificate_store_certificate_expiration_type" | "pages_event_alert" | "radar_notification" | "real_origin_monitoring" | "scriptmonitor_alert_new_code_change_detections" | "scriptmonitor_alert_new_hosts" | "scriptmonitor_alert_new_malicious_hosts" | "scriptmonitor_alert_new_malicious_scripts" | "scriptmonitor_alert_new_malicious_url" | "scriptmonitor_alert_new_max_length_resource_url" | "scriptmonitor_alert_new_resources" | "secondary_dns_all_primaries_failing" | "secondary_dns_primaries_failing" | "secondary_dns_warning" | "secondary_dns_zone_successfully_updated" | "secondary_dns_zone_validation_warning" | "security_insights_alert" | "sentinel_alert" | "stream_live_notifications" | "synthetic_test_latency_alert" | "synthetic_test_low_availability_alert" | "traffic_anomalies_alert" | "tunnel_health_event" | "tunnel_update_event" | "universal_ssl_event_type" | "web_analytics_metrics_update" | "zone_aop_custom_certificate_expiration_type";
export declare const PoliciesUpdateRequestAlertType: any;
export type PoliciesUpdateRequestFiltersActionsList = Array<string>;
export declare const PoliciesUpdateRequestFiltersActionsList: S.Schema<PoliciesUpdateRequestFiltersActionsList>;
export type PoliciesUpdateRequestFiltersAffectedAsnsList = Array<string>;
export declare const PoliciesUpdateRequestFiltersAffectedAsnsList: S.Schema<PoliciesUpdateRequestFiltersAffectedAsnsList>;
export type PoliciesUpdateRequestFiltersAffectedComponentsList = Array<string>;
export declare const PoliciesUpdateRequestFiltersAffectedComponentsList: S.Schema<PoliciesUpdateRequestFiltersAffectedComponentsList>;
export type PoliciesUpdateRequestFiltersAffectedLocationsList = Array<string>;
export declare const PoliciesUpdateRequestFiltersAffectedLocationsList: S.Schema<PoliciesUpdateRequestFiltersAffectedLocationsList>;
export type PoliciesUpdateRequestFiltersAirportCodeList = Array<string>;
export declare const PoliciesUpdateRequestFiltersAirportCodeList: S.Schema<PoliciesUpdateRequestFiltersAirportCodeList>;
export type PoliciesUpdateRequestFiltersAlertTriggerPreferencesList = Array<string>;
export declare const PoliciesUpdateRequestFiltersAlertTriggerPreferencesList: S.Schema<PoliciesUpdateRequestFiltersAlertTriggerPreferencesList>;
export type PoliciesUpdateRequestFiltersAlertTriggerPreferencesValueList = Array<string>;
export declare const PoliciesUpdateRequestFiltersAlertTriggerPreferencesValueList: S.Schema<PoliciesUpdateRequestFiltersAlertTriggerPreferencesValueList>;
export type PoliciesUpdateRequestFiltersEnabledList = Array<string>;
export declare const PoliciesUpdateRequestFiltersEnabledList: S.Schema<PoliciesUpdateRequestFiltersEnabledList>;
export type PoliciesUpdateRequestFiltersEnvironmentList = Array<string>;
export declare const PoliciesUpdateRequestFiltersEnvironmentList: S.Schema<PoliciesUpdateRequestFiltersEnvironmentList>;
export type PoliciesUpdateRequestFiltersEventList = Array<string>;
export declare const PoliciesUpdateRequestFiltersEventList: S.Schema<PoliciesUpdateRequestFiltersEventList>;
export type PoliciesUpdateRequestFiltersEventSourceList = Array<string>;
export declare const PoliciesUpdateRequestFiltersEventSourceList: S.Schema<PoliciesUpdateRequestFiltersEventSourceList>;
export type PoliciesUpdateRequestFiltersEventTypeList = Array<string>;
export declare const PoliciesUpdateRequestFiltersEventTypeList: S.Schema<PoliciesUpdateRequestFiltersEventTypeList>;
export type PoliciesUpdateRequestFiltersGroupByList = Array<string>;
export declare const PoliciesUpdateRequestFiltersGroupByList: S.Schema<PoliciesUpdateRequestFiltersGroupByList>;
export type PoliciesUpdateRequestFiltersHealthCheckIdList = Array<string>;
export declare const PoliciesUpdateRequestFiltersHealthCheckIdList: S.Schema<PoliciesUpdateRequestFiltersHealthCheckIdList>;
export type PoliciesUpdateRequestFiltersIncidentImpactItem = "INCIDENT_IMPACT_NONE" | "INCIDENT_IMPACT_MINOR" | "INCIDENT_IMPACT_MAJOR" | "INCIDENT_IMPACT_CRITICAL";
export declare const PoliciesUpdateRequestFiltersIncidentImpactItem: any;
export type PoliciesUpdateRequestFiltersIncidentImpactList = Array<PoliciesUpdateRequestFiltersIncidentImpactItem | (string & {})>;
export declare const PoliciesUpdateRequestFiltersIncidentImpactList: S.Schema<PoliciesUpdateRequestFiltersIncidentImpactList>;
export type PoliciesUpdateRequestFiltersInputIdList = Array<string>;
export declare const PoliciesUpdateRequestFiltersInputIdList: S.Schema<PoliciesUpdateRequestFiltersInputIdList>;
export type PoliciesUpdateRequestFiltersInsightClassList = Array<string>;
export declare const PoliciesUpdateRequestFiltersInsightClassList: S.Schema<PoliciesUpdateRequestFiltersInsightClassList>;
export type PoliciesUpdateRequestFiltersLimitList = Array<string>;
export declare const PoliciesUpdateRequestFiltersLimitList: S.Schema<PoliciesUpdateRequestFiltersLimitList>;
export type PoliciesUpdateRequestFiltersLogoTagList = Array<string>;
export declare const PoliciesUpdateRequestFiltersLogoTagList: S.Schema<PoliciesUpdateRequestFiltersLogoTagList>;
export type PoliciesUpdateRequestFiltersMegabitsPerSecondList = Array<string>;
export declare const PoliciesUpdateRequestFiltersMegabitsPerSecondList: S.Schema<PoliciesUpdateRequestFiltersMegabitsPerSecondList>;
export type PoliciesUpdateRequestFiltersNewHealthList = Array<string>;
export declare const PoliciesUpdateRequestFiltersNewHealthList: S.Schema<PoliciesUpdateRequestFiltersNewHealthList>;
export type PoliciesUpdateRequestFiltersNewStatusList = Array<string>;
export declare const PoliciesUpdateRequestFiltersNewStatusList: S.Schema<PoliciesUpdateRequestFiltersNewStatusList>;
export type PoliciesUpdateRequestFiltersPacketsPerSecondList = Array<string>;
export declare const PoliciesUpdateRequestFiltersPacketsPerSecondList: S.Schema<PoliciesUpdateRequestFiltersPacketsPerSecondList>;
export type PoliciesUpdateRequestFiltersPoolIdList = Array<string>;
export declare const PoliciesUpdateRequestFiltersPoolIdList: S.Schema<PoliciesUpdateRequestFiltersPoolIdList>;
export type PoliciesUpdateRequestFiltersPopNamesList = Array<string>;
export declare const PoliciesUpdateRequestFiltersPopNamesList: S.Schema<PoliciesUpdateRequestFiltersPopNamesList>;
export type PoliciesUpdateRequestFiltersProductList = Array<string>;
export declare const PoliciesUpdateRequestFiltersProductList: S.Schema<PoliciesUpdateRequestFiltersProductList>;
export type PoliciesUpdateRequestFiltersProjectIdList = Array<string>;
export declare const PoliciesUpdateRequestFiltersProjectIdList: S.Schema<PoliciesUpdateRequestFiltersProjectIdList>;
export type PoliciesUpdateRequestFiltersProtocolList = Array<string>;
export declare const PoliciesUpdateRequestFiltersProtocolList: S.Schema<PoliciesUpdateRequestFiltersProtocolList>;
export type PoliciesUpdateRequestFiltersQueryTagList = Array<string>;
export declare const PoliciesUpdateRequestFiltersQueryTagList: S.Schema<PoliciesUpdateRequestFiltersQueryTagList>;
export type PoliciesUpdateRequestFiltersRequestsPerSecondList = Array<string>;
export declare const PoliciesUpdateRequestFiltersRequestsPerSecondList: S.Schema<PoliciesUpdateRequestFiltersRequestsPerSecondList>;
export type PoliciesUpdateRequestFiltersSelectorsList = Array<string>;
export declare const PoliciesUpdateRequestFiltersSelectorsList: S.Schema<PoliciesUpdateRequestFiltersSelectorsList>;
export type PoliciesUpdateRequestFiltersServicesList = Array<string>;
export declare const PoliciesUpdateRequestFiltersServicesList: S.Schema<PoliciesUpdateRequestFiltersServicesList>;
export type PoliciesUpdateRequestFiltersSloList = Array<string>;
export declare const PoliciesUpdateRequestFiltersSloList: S.Schema<PoliciesUpdateRequestFiltersSloList>;
export type PoliciesUpdateRequestFiltersStatusList = Array<string>;
export declare const PoliciesUpdateRequestFiltersStatusList: S.Schema<PoliciesUpdateRequestFiltersStatusList>;
export type PoliciesUpdateRequestFiltersTargetHostnameList = Array<string>;
export declare const PoliciesUpdateRequestFiltersTargetHostnameList: S.Schema<PoliciesUpdateRequestFiltersTargetHostnameList>;
export type PoliciesUpdateRequestFiltersTargetIpList = Array<string>;
export declare const PoliciesUpdateRequestFiltersTargetIpList: S.Schema<PoliciesUpdateRequestFiltersTargetIpList>;
export type PoliciesUpdateRequestFiltersTargetZoneNameList = Array<string>;
export declare const PoliciesUpdateRequestFiltersTargetZoneNameList: S.Schema<PoliciesUpdateRequestFiltersTargetZoneNameList>;
export type PoliciesUpdateRequestFiltersTrafficExclusionsItem = "security_events";
export declare const PoliciesUpdateRequestFiltersTrafficExclusionsItem: any;
export type PoliciesUpdateRequestFiltersTrafficExclusionsList = Array<PoliciesUpdateRequestFiltersTrafficExclusionsItem | (string & {})>;
export declare const PoliciesUpdateRequestFiltersTrafficExclusionsList: S.Schema<PoliciesUpdateRequestFiltersTrafficExclusionsList>;
export type PoliciesUpdateRequestFiltersTunnelIdList = Array<string>;
export declare const PoliciesUpdateRequestFiltersTunnelIdList: S.Schema<PoliciesUpdateRequestFiltersTunnelIdList>;
export type PoliciesUpdateRequestFiltersTunnelNameList = Array<string>;
export declare const PoliciesUpdateRequestFiltersTunnelNameList: S.Schema<PoliciesUpdateRequestFiltersTunnelNameList>;
export type PoliciesUpdateRequestFiltersTypeList = Array<string>;
export declare const PoliciesUpdateRequestFiltersTypeList: S.Schema<PoliciesUpdateRequestFiltersTypeList>;
export type PoliciesUpdateRequestFiltersWhereList = Array<string>;
export declare const PoliciesUpdateRequestFiltersWhereList: S.Schema<PoliciesUpdateRequestFiltersWhereList>;
export type PoliciesUpdateRequestFiltersZonesList = Array<string>;
export declare const PoliciesUpdateRequestFiltersZonesList: S.Schema<PoliciesUpdateRequestFiltersZonesList>;
export interface PoliciesUpdateRequestFilters {
    /** Usage depends on specific alert type */
    actions?: PoliciesUpdateRequestFiltersActionsList;
    /** Used for configuring radar_notification */
    affectedAsns?: PoliciesUpdateRequestFiltersAffectedAsnsList;
    /** Used for configuring incident_alert */
    affectedComponents?: PoliciesUpdateRequestFiltersAffectedComponentsList;
    /** Used for configuring radar_notification */
    affectedLocations?: PoliciesUpdateRequestFiltersAffectedLocationsList;
    /** Used for configuring maintenance_event_notification */
    airportCode?: PoliciesUpdateRequestFiltersAirportCodeList;
    /** Usage depends on specific alert type */
    alertTriggerPreferences?: PoliciesUpdateRequestFiltersAlertTriggerPreferencesList;
    /** Usage depends on specific alert type */
    alertTriggerPreferencesValue?: PoliciesUpdateRequestFiltersAlertTriggerPreferencesValueList;
    /** Used for configuring load_balancing_pool_enablement_alert */
    enabled?: PoliciesUpdateRequestFiltersEnabledList;
    /** Used for configuring pages_event_alert */
    environment?: PoliciesUpdateRequestFiltersEnvironmentList;
    /** Used for configuring pages_event_alert */
    event?: PoliciesUpdateRequestFiltersEventList;
    /** Used for configuring load_balancing_health_alert */
    eventSource?: PoliciesUpdateRequestFiltersEventSourceList;
    /** Usage depends on specific alert type */
    eventType?: PoliciesUpdateRequestFiltersEventTypeList;
    /** Usage depends on specific alert type */
    groupBy?: PoliciesUpdateRequestFiltersGroupByList;
    /** Used for configuring health_check_status_notification */
    healthCheckId?: PoliciesUpdateRequestFiltersHealthCheckIdList;
    /** Used for configuring incident_alert */
    incidentImpact?: PoliciesUpdateRequestFiltersIncidentImpactList;
    /** Used for configuring stream_live_notifications */
    inputId?: PoliciesUpdateRequestFiltersInputIdList;
    /** Used for configuring security_insights_alert */
    insightClass?: PoliciesUpdateRequestFiltersInsightClassList;
    /** Used for configuring billing_usage_alert */
    limit?: PoliciesUpdateRequestFiltersLimitList;
    /** Used for configuring logo_match_alert */
    logoTag?: PoliciesUpdateRequestFiltersLogoTagList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    megabitsPerSecond?: PoliciesUpdateRequestFiltersMegabitsPerSecondList;
    /** Used for configuring load_balancing_health_alert */
    newHealth?: PoliciesUpdateRequestFiltersNewHealthList;
    /** Used for configuring tunnel_health_event */
    newStatus?: PoliciesUpdateRequestFiltersNewStatusList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    packetsPerSecond?: PoliciesUpdateRequestFiltersPacketsPerSecondList;
    /** Usage depends on specific alert type */
    poolId?: PoliciesUpdateRequestFiltersPoolIdList;
    /** Usage depends on specific alert type */
    popNames?: PoliciesUpdateRequestFiltersPopNamesList;
    /** Used for configuring billing_usage_alert */
    product?: PoliciesUpdateRequestFiltersProductList;
    /** Used for configuring pages_event_alert */
    projectId?: PoliciesUpdateRequestFiltersProjectIdList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    protocol?: PoliciesUpdateRequestFiltersProtocolList;
    /** Usage depends on specific alert type */
    queryTag?: PoliciesUpdateRequestFiltersQueryTagList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    requestsPerSecond?: PoliciesUpdateRequestFiltersRequestsPerSecondList;
    /** Usage depends on specific alert type */
    selectors?: PoliciesUpdateRequestFiltersSelectorsList;
    /** Used for configuring clickhouse_alert_fw_ent_anomaly */
    services?: PoliciesUpdateRequestFiltersServicesList;
    /** Usage depends on specific alert type */
    slo?: PoliciesUpdateRequestFiltersSloList;
    /** Used for configuring health_check_status_notification */
    status?: PoliciesUpdateRequestFiltersStatusList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetHostname?: PoliciesUpdateRequestFiltersTargetHostnameList;
    /** Used for configuring advanced_ddos_attack_l4_alert */
    targetIp?: PoliciesUpdateRequestFiltersTargetIpList;
    /** Used for configuring advanced_ddos_attack_l7_alert */
    targetZoneName?: PoliciesUpdateRequestFiltersTargetZoneNameList;
    /** Used for configuring traffic_anomalies_alert */
    trafficExclusions?: PoliciesUpdateRequestFiltersTrafficExclusionsList;
    /** Used for configuring tunnel_health_event */
    tunnelId?: PoliciesUpdateRequestFiltersTunnelIdList;
    /** Usage depends on specific alert type */
    tunnelName?: PoliciesUpdateRequestFiltersTunnelNameList;
    /** Usage depends on specific alert type */
    type?: PoliciesUpdateRequestFiltersTypeList;
    /** Usage depends on specific alert type */
    where?: PoliciesUpdateRequestFiltersWhereList;
    /** Usage depends on specific alert type */
    zones?: PoliciesUpdateRequestFiltersZonesList;
}
export declare const PoliciesUpdateRequestFilters: S.Schema<PoliciesUpdateRequestFilters>;
export type PoliciesUpdateRequestMechanismsEmailItem = PoliciesCreateRequestMechanismsEmailItem;
export declare const PoliciesUpdateRequestMechanismsEmailItem: S.Schema<PoliciesCreateRequestMechanismsEmailItem>;
export type PoliciesUpdateRequestMechanismsEmailList = Array<PoliciesCreateRequestMechanismsEmailItem>;
export declare const PoliciesUpdateRequestMechanismsEmailList: S.Schema<PoliciesUpdateRequestMechanismsEmailList>;
export type PoliciesUpdateRequestMechanismsPagerdutyItem = PoliciesCreateRequestMechanismsPagerdutyItem;
export declare const PoliciesUpdateRequestMechanismsPagerdutyItem: S.Schema<PoliciesCreateRequestMechanismsPagerdutyItem>;
export type PoliciesUpdateRequestMechanismsPagerdutyList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export declare const PoliciesUpdateRequestMechanismsPagerdutyList: S.Schema<PoliciesUpdateRequestMechanismsPagerdutyList>;
export type PoliciesUpdateRequestMechanismsWebhooksItem = PoliciesCreateRequestMechanismsPagerdutyItem;
export declare const PoliciesUpdateRequestMechanismsWebhooksItem: S.Schema<PoliciesCreateRequestMechanismsPagerdutyItem>;
export type PoliciesUpdateRequestMechanismsWebhooksList = Array<PoliciesCreateRequestMechanismsPagerdutyItem>;
export declare const PoliciesUpdateRequestMechanismsWebhooksList: S.Schema<PoliciesUpdateRequestMechanismsWebhooksList>;
export interface PoliciesUpdateRequestMechanisms {
    email?: PoliciesUpdateRequestMechanismsEmailList;
    pagerduty?: PoliciesUpdateRequestMechanismsPagerdutyList;
    webhooks?: PoliciesUpdateRequestMechanismsWebhooksList;
}
export declare const PoliciesUpdateRequestMechanisms: S.Schema<PoliciesUpdateRequestMechanisms>;
export interface UpdatePolicyRequest {
    /** The account id */
    accountId: string;
    /** The unique identifier of a notification policy */
    policyId: string;
    /** Optional specification of how often to re-alert from the same incident, not support on all alert types. */
    alertInterval?: string;
    /** Refers to which event will trigger a Notification dispatch. You can use the endpoint to get available alert types which then will give you a list of possible values. */
    alertType?: PoliciesUpdateRequestAlertType | (string & {});
    /** Optional description for the Notification policy. */
    description?: string;
    /** Whether or not the Notification policy is enabled. */
    enabled?: boolean;
    /** Optional filters that allow you to be alerted only on a subset of events for that alert type based on some criteria. This is only available for select alert types. See alert type documentation for more details. */
    filters?: PoliciesUpdateRequestFilters;
    /** List of IDs that will be used when dispatching a notification. IDs for email type will be the email address. */
    mechanisms?: PoliciesUpdateRequestMechanisms;
    /** Name of the policy. */
    name?: string;
}
export declare const UpdatePolicyRequest: S.Schema<UpdatePolicyRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePolicyResponse {
    /** UUID */
    id?: string | null;
}
export declare const UpdatePolicyResponse: S.Schema<UpdatePolicyResponse>;
export interface SilencesUpdateRequestBodyItem {
    /** Silence ID */
    id?: string;
    /** When the silence ends. */
    endTime?: string;
    /** When the silence starts. */
    startTime?: string;
}
export declare const SilencesUpdateRequestBodyItem: S.Schema<SilencesUpdateRequestBodyItem>;
export type SilencesUpdateRequestBodyList = Array<SilencesUpdateRequestBodyItem>;
export declare const SilencesUpdateRequestBodyList: S.Schema<SilencesUpdateRequestBodyList>;
export interface UpdateSilenceRequest {
    /** The account id */
    accountId: string;
    body: SilencesUpdateRequestBodyList;
}
export declare const UpdateSilenceRequest: S.Schema<UpdateSilenceRequest>;
export type SilencesUpdateResultItem = SilencesListResultItem;
export declare const SilencesUpdateResultItem: S.Schema<SilencesListResultItem>;
export type SilencesUpdateResultList = Array<SilencesListResultItem>;
export declare const SilencesUpdateResultList: S.Schema<SilencesUpdateResultList>;
export interface UpdateSilenceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SilencesUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const UpdateSilenceResponse: S.Schema<UpdateSilenceResponse>;
export type CreateDestinationPagerdutyError = InvalidRoute | CloudflareOpError;
/** Creates a new token for integrating with PagerDuty. */
export declare const createDestinationPagerduty: API.OperationMethod<CreateDestinationPagerdutyRequest, CreateDestinationPagerdutyResponse, CreateDestinationPagerdutyError, CloudflareOpContext>;
export type CreateDestinationWebhookError = InvalidRoute | WebhookTestFailed | CloudflareOpError;
/** Creates a new webhook destination. */
export declare const createDestinationWebhook: API.OperationMethod<CreateDestinationWebhookRequest, CreateDestinationWebhookResponse, CreateDestinationWebhookError, CloudflareOpContext>;
export type CreatePolicyError = InvalidRoute | FiltersRequired | MechanismRequired | CloudflareOpError;
/** Creates a new Notification policy. */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest, CreatePolicyResponse, CreatePolicyError, CloudflareOpContext>;
export type CreateSilenceError = InvalidRoute | InvalidSilence | SilenceAlreadyExists | CloudflareOpError;
/** Creates a new silence for an account. */
export declare const createSilence: API.OperationMethod<CreateSilenceRequest, CreateSilenceResponse, CreateSilenceError, CloudflareOpContext>;
export type DeleteDestinationPagerdutyError = InvalidRoute | CloudflareOpError;
/** Deletes all the PagerDuty Services connected to the account. */
export declare const deleteDestinationPagerduty: API.OperationMethod<DeleteDestinationPagerdutyRequest, DeleteDestinationPagerdutyResponse, DeleteDestinationPagerdutyError, CloudflareOpContext>;
export type DeleteDestinationWebhookError = InvalidRoute | CloudflareOpError;
/** Delete a configured webhook destination. */
export declare const deleteDestinationWebhook: API.OperationMethod<DeleteDestinationWebhookRequest, DeleteDestinationWebhookResponse, DeleteDestinationWebhookError, CloudflareOpContext>;
export type DeletePolicyError = InvalidRoute | PolicyNotFound | CloudflareOpError;
/** Delete a Notification policy. */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest, DeletePolicyResponse, DeletePolicyError, CloudflareOpContext>;
export type DeleteSilenceError = InvalidRoute | SilenceNotFound | CloudflareOpError;
/** Deletes an existing silence for an account. */
export declare const deleteSilence: API.OperationMethod<DeleteSilenceRequest, DeleteSilenceResponse, DeleteSilenceError, CloudflareOpContext>;
export type GetDestinationEligibleError = InvalidRoute | CloudflareOpError;
/** Get a list of all delivery mechanism types for which an account is eligible. */
export declare const getDestinationEligible: API.OperationMethod<GetDestinationEligibleRequest, GetDestinationEligibleResponse, GetDestinationEligibleError, CloudflareOpContext>;
export type GetDestinationPagerdutyError = CloudflareOpError;
/** Get a list of all configured PagerDuty services. */
export declare const getDestinationPagerduty: API.PaginatedOperationMethod<GetDestinationPagerdutyRequest, GetDestinationPagerdutyResponse, GetDestinationPagerdutyError, CloudflareOpContext, DestinationsPagerdutyGetResultItem>;
export type GetDestinationWebhookError = InvalidRoute | WebhookNotFound | CloudflareOpError;
/** Get details for a single webhooks destination. */
export declare const getDestinationWebhook: API.OperationMethod<GetDestinationWebhookRequest, GetDestinationWebhookResponse, GetDestinationWebhookError, CloudflareOpContext>;
export type GetPolicyError = InvalidRoute | PolicyNotFound | CloudflareOpError;
/** Get details for a single policy. */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest, GetPolicyResponse, GetPolicyError, CloudflareOpContext>;
export type GetSilenceError = InvalidRoute | SilenceNotFound | CloudflareOpError;
/** Gets a specific silence for an account. */
export declare const getSilence: API.OperationMethod<GetSilenceRequest, GetSilenceResponse, GetSilenceError, CloudflareOpContext>;
export type LinkDestinationPagerdutyError = InvalidRoute | CloudflareOpError;
/** Links PagerDuty with the account using the integration token. */
export declare const linkDestinationPagerduty: API.OperationMethod<LinkDestinationPagerdutyRequest, LinkDestinationPagerdutyResponse, LinkDestinationPagerdutyError, CloudflareOpContext>;
export type ListAvailableAlertsError = InvalidRoute | CloudflareOpError;
/** Gets a list of all alert types for which an account is eligible. */
export declare const listAvailableAlerts: API.OperationMethod<ListAvailableAlertsRequest, ListAvailableAlertsResponse, ListAvailableAlertsError, CloudflareOpContext>;
export type ListDestinationWebhooksError = CloudflareOpError;
/** Gets a list of all configured webhook destinations. */
export declare const listDestinationWebhooks: API.PaginatedOperationMethod<ListDestinationWebhooksRequest, ListDestinationWebhooksResponse, ListDestinationWebhooksError, CloudflareOpContext, DestinationsWebhooksListResultItem>;
export type ListHistoriesError = CloudflareOpError;
/** Gets a list of history records for notifications sent to an account. The records are displayed for last `x` number of days based on the zone plan (free = 30, pro = 30, biz = 30, ent = 90). */
export declare const listHistories: API.PaginatedOperationMethod<ListHistoriesRequest, ListHistoriesResponse, ListHistoriesError, CloudflareOpContext, HistoryListResultItem>;
export type ListPoliciesError = CloudflareOpError;
/** Get a list of all Notification policies. */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest, ListPoliciesResponse, ListPoliciesError, CloudflareOpContext, PoliciesListResultItem>;
export type ListSilencesError = CloudflareOpError;
/** Gets a list of silences for an account. */
export declare const listSilences: API.PaginatedOperationMethod<ListSilencesRequest, ListSilencesResponse, ListSilencesError, CloudflareOpContext, SilencesListResultItem>;
export type UpdateDestinationWebhookError = InvalidRoute | InvalidWebhookId | WebhookTestFailed | CloudflareOpError;
/** Update a webhook destination. */
export declare const updateDestinationWebhook: API.OperationMethod<UpdateDestinationWebhookRequest, UpdateDestinationWebhookResponse, UpdateDestinationWebhookError, CloudflareOpContext>;
export type UpdatePolicyError = InvalidRoute | PolicyNotFound | InvalidAlertType | MechanismRequired | CloudflareOpError;
/** Update a Notification policy. */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest, UpdatePolicyResponse, UpdatePolicyError, CloudflareOpContext>;
export type UpdateSilenceError = SilenceNotFound | InvalidSilence | CloudflareOpError;
/** Updates existing silences for an account. */
export declare const updateSilence: API.PaginatedOperationMethod<UpdateSilenceRequest, UpdateSilenceResponse, UpdateSilenceError, CloudflareOpContext, SilencesListResultItem>;
//# sourceMappingURL=alerting.d.ts.map