import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CustomNameserverAlreadyExists_base: S.Class<CustomNameserverAlreadyExists, S.TaggedStruct<"CustomNameserverAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CustomNameserverAlreadyExists extends /*@__PURE__*/ CustomNameserverAlreadyExists_base {
}
declare const CustomNameserverNotFound_base: S.Class<CustomNameserverNotFound, S.TaggedStruct<"CustomNameserverNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CustomNameserverNotFound extends /*@__PURE__*/ CustomNameserverNotFound_base {
}
declare const CustomNameserversNotEnabled_base: S.Class<CustomNameserversNotEnabled, S.TaggedStruct<"CustomNameserversNotEnabled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CustomNameserversNotEnabled extends /*@__PURE__*/ CustomNameserversNotEnabled_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CreateCustomNameserverRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The FQDN of the name server. */
    nsName: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number;
}
export declare const CreateCustomNameserverRequest: S.Schema<CreateCustomNameserverRequest>;
export type CreateResponseDnsRecordsItemType = "A" | "AAAA";
export declare const CreateResponseDnsRecordsItemType: any;
export interface CreateResponseDnsRecordsItem {
    /** DNS record type. */
    type?: CreateResponseDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export declare const CreateResponseDnsRecordsItem: S.Schema<CreateResponseDnsRecordsItem>;
export type CreateResponseDnsRecordsList = Array<CreateResponseDnsRecordsItem>;
export declare const CreateResponseDnsRecordsList: S.Schema<CreateResponseDnsRecordsList>;
export type CreateResponseStatus = "moved" | "pending" | "verified";
export declare const CreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomNameserverResponse {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: CreateResponseDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: CreateResponseStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export declare const CreateCustomNameserverResponse: S.Schema<CreateCustomNameserverResponse>;
export interface DeleteCustomNameserverRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The FQDN of the name server. */
    customNsId: string;
}
export declare const DeleteCustomNameserverRequest: S.Schema<DeleteCustomNameserverRequest>;
export type DeleteResultList = Array<string>;
export declare const DeleteResultList: S.Schema<DeleteResultList>;
export interface DeleteCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const DeleteCustomNameserverResponse: S.Schema<DeleteCustomNameserverResponse>;
export interface GetCustomNameserverRequest {
    /** Account identifier tag. */
    accountId: string;
}
export declare const GetCustomNameserverRequest: S.Schema<GetCustomNameserverRequest>;
export type GetResultItemDnsRecordsItemType = "A" | "AAAA";
export declare const GetResultItemDnsRecordsItemType: any;
export interface GetResultItemDnsRecordsItem {
    /** DNS record type. */
    type?: GetResultItemDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export declare const GetResultItemDnsRecordsItem: S.Schema<GetResultItemDnsRecordsItem>;
export type GetResultItemDnsRecordsList = Array<GetResultItemDnsRecordsItem>;
export declare const GetResultItemDnsRecordsList: S.Schema<GetResultItemDnsRecordsList>;
export type GetResultItemStatus = "moved" | "pending" | "verified";
export declare const GetResultItemStatus: any;
export interface GetResultItem {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: GetResultItemDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: GetResultItemStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export declare const GetResultItem: S.Schema<GetResultItem>;
export type GetResultList = Array<GetResultItem>;
export declare const GetResultList: S.Schema<GetResultList>;
export interface GetCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: GetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetCustomNameserverResponse: S.Schema<GetCustomNameserverResponse>;
export type CreateCustomNameserverError = CustomNameserversNotEnabled | CustomNameserverAlreadyExists | Forbidden | CloudflareOpError;
/** Adds a custom nameserver to the account for use as a vanity nameserver on zones. */
export declare const createCustomNameserver: API.OperationMethod<CreateCustomNameserverRequest, CreateCustomNameserverResponse, CreateCustomNameserverError, CloudflareOpContext>;
export type DeleteCustomNameserverError = CustomNameserversNotEnabled | CustomNameserverNotFound | Forbidden | CloudflareOpError;
/** Removes a custom nameserver from the account. */
export declare const deleteCustomNameserver: API.PaginatedOperationMethod<DeleteCustomNameserverRequest, DeleteCustomNameserverResponse, DeleteCustomNameserverError, CloudflareOpContext, string>;
export type GetCustomNameserverError = CustomNameserversNotEnabled | Forbidden | CloudflareOpError;
/** List an account's custom nameservers. */
export declare const getCustomNameserver: API.PaginatedOperationMethod<GetCustomNameserverRequest, GetCustomNameserverResponse, GetCustomNameserverError, CloudflareOpContext, GetResultItem>;
//# sourceMappingURL=custom_nameservers.d.ts.map