import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AdvancedCertificateManagerRequired_base: S.Class<AdvancedCertificateManagerRequired, S.TaggedStruct<"AdvancedCertificateManagerRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AdvancedCertificateManagerRequired extends /*@__PURE__*/ AdvancedCertificateManagerRequired_base {
}
declare const CustomTrustStoreNotFound_base: S.Class<CustomTrustStoreNotFound, S.TaggedStruct<"CustomTrustStoreNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CustomTrustStoreNotFound extends /*@__PURE__*/ CustomTrustStoreNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidObjectIdentifier_base: S.Class<InvalidObjectIdentifier, S.TaggedStruct<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const NoStateChange_base: S.Class<NoStateChange, S.TaggedStruct<"NoStateChange", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NoStateChange extends /*@__PURE__*/ NoStateChange_base {
}
declare const PreviousJobInProgress_base: S.Class<PreviousJobInProgress, S.TaggedStruct<"PreviousJobInProgress", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PreviousJobInProgress extends /*@__PURE__*/ PreviousJobInProgress_base {
}
export interface CreateCustomTrustStoreRequest {
    /** Identifier. */
    zoneId: string;
    /** The root CA certificate in PEM format. Only root CA certificates are accepted; intermediate and leaf certificates are not supported. */
    certificate: string;
}
export declare const CreateCustomTrustStoreRequest: S.Schema<CreateCustomTrustStoreRequest>;
export type CustomTrustStoreCreateResponseStatus = "initializing" | "pending_deployment" | "active" | "pending_deletion" | "deleted" | "expired";
export declare const CustomTrustStoreCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCustomTrustStoreResponse {
    /** Identifier. */
    id: string;
    /** The root CA certificate in PEM format. Only root CA certificates are accepted; intermediate and leaf certificates are not supported. */
    certificate: string;
    /** When the certificate expires. */
    expiresOn: string;
    /** The certificate authority that issued the certificate. */
    issuer: string;
    /** The type of hash used for the certificate. */
    signature: string;
    /** Status of the zone's custom SSL. */
    status: CustomTrustStoreCreateResponseStatus;
    /** When the certificate was last modified. */
    updatedAt: string;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn: string;
}
export declare const CreateCustomTrustStoreResponse: S.Schema<CreateCustomTrustStoreResponse>;
export interface DeleteCustomTrustStoreRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    customOriginTrustStoreId: string;
}
export declare const DeleteCustomTrustStoreRequest: S.Schema<DeleteCustomTrustStoreRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCustomTrustStoreResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const DeleteCustomTrustStoreResponse: S.Schema<DeleteCustomTrustStoreResponse>;
export interface GetCustomTrustStoreRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    customOriginTrustStoreId: string;
}
export declare const GetCustomTrustStoreRequest: S.Schema<GetCustomTrustStoreRequest>;
export type CustomTrustStoreGetResponseStatus = "initializing" | "pending_deployment" | "active" | "pending_deletion" | "deleted" | "expired";
export declare const CustomTrustStoreGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomTrustStoreResponse {
    /** Identifier. */
    id: string;
    /** The root CA certificate in PEM format. Only root CA certificates are accepted; intermediate and leaf certificates are not supported. */
    certificate: string;
    /** When the certificate expires. */
    expiresOn: string;
    /** The certificate authority that issued the certificate. */
    issuer: string;
    /** The type of hash used for the certificate. */
    signature: string;
    /** Status of the zone's custom SSL. */
    status: CustomTrustStoreGetResponseStatus;
    /** When the certificate was last modified. */
    updatedAt: string;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn: string;
}
export declare const GetCustomTrustStoreResponse: S.Schema<GetCustomTrustStoreResponse>;
export interface GetTotalTlRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetTotalTlRequest: S.Schema<GetTotalTlRequest>;
export type TotalTlsGetResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const TotalTlsGetResponseCertificateAuthority: any;
export type TotalTlsGetResponseValidityPeriod = 90;
export declare const TotalTlsGetResponseValidityPeriod: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTotalTlResponse {
    /** The Certificate Authority that Total TLS certificates will be issued through. */
    certificateAuthority?: TotalTlsGetResponseCertificateAuthority | null;
    /** If enabled, Total TLS will order a hostname specific TLS certificate for any proxied A, AAAA, or CNAME record in your zone. */
    enabled?: boolean | null;
    /** The validity period in days for the certificates ordered via Total TLS. */
    validityPeriod?: TotalTlsGetResponseValidityPeriod | null;
}
export declare const GetTotalTlResponse: S.Schema<GetTotalTlResponse>;
export interface ListCustomTrustStoresRequest {
    /** Identifier. */
    zoneId: string;
    /** Limit to the number of records returned. */
    limit?: number;
    /** Offset the results. */
    offset?: number;
    /** Page number of paginated results. */
    page?: number;
    /** Number of records per page. */
    perPage?: number;
}
export declare const ListCustomTrustStoresRequest: S.Schema<ListCustomTrustStoresRequest>;
export type CustomTrustStoreListResultItemStatus = "initializing" | "pending_deployment" | "active" | "pending_deletion" | "deleted" | "expired";
export declare const CustomTrustStoreListResultItemStatus: any;
export interface CustomTrustStoreListResultItem {
    /** Identifier. */
    id: string;
    /** The root CA certificate in PEM format. Only root CA certificates are accepted; intermediate and leaf certificates are not supported. */
    certificate: string;
    /** When the certificate expires. */
    expiresOn: string;
    /** The certificate authority that issued the certificate. */
    issuer: string;
    /** The type of hash used for the certificate. */
    signature: string;
    /** Status of the zone's custom SSL. */
    status: CustomTrustStoreListResultItemStatus;
    /** When the certificate was last modified. */
    updatedAt: string;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn: string;
}
export declare const CustomTrustStoreListResultItem: S.Schema<CustomTrustStoreListResultItem>;
export type CustomTrustStoreListResultList = Array<CustomTrustStoreListResultItem>;
export declare const CustomTrustStoreListResultList: S.Schema<CustomTrustStoreListResultList>;
export interface ListCustomTrustStoresResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CustomTrustStoreListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCustomTrustStoresResponse: S.Schema<ListCustomTrustStoresResponse>;
export type TotalTlsEditRequestCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const TotalTlsEditRequestCertificateAuthority: any;
export interface UpdateTotalTlRequest {
    /** Identifier. */
    zoneId: string;
    /** If enabled, Total TLS will order a hostname specific TLS certificate for any proxied A, AAAA, or CNAME record in your zone. */
    enabled: boolean;
    /** The Certificate Authority that Total TLS certificates will be issued through. */
    certificateAuthority?: TotalTlsEditRequestCertificateAuthority | (string & {});
}
export declare const UpdateTotalTlRequest: S.Schema<UpdateTotalTlRequest>;
export type TotalTlsEditResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const TotalTlsEditResponseCertificateAuthority: any;
export type TotalTlsEditResponseValidityPeriod = 90;
export declare const TotalTlsEditResponseValidityPeriod: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTotalTlResponse {
    /** The Certificate Authority that Total TLS certificates will be issued through. */
    certificateAuthority?: TotalTlsEditResponseCertificateAuthority | null;
    /** If enabled, Total TLS will order a hostname specific TLS certificate for any proxied A, AAAA, or CNAME record in your zone. */
    enabled?: boolean | null;
    /** The validity period in days for the certificates ordered via Total TLS. */
    validityPeriod?: TotalTlsEditResponseValidityPeriod | null;
}
export declare const UpdateTotalTlResponse: S.Schema<UpdateTotalTlResponse>;
export type UpdateTotalTlsRequestCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const UpdateTotalTlsRequestCertificateAuthority: any;
export interface UpdateTotalTlsRequest {
    /** Identifier. */
    zoneId: string;
    /** If enabled, Total TLS will order a hostname specific TLS certificate for any proxied A, AAAA, or CNAME record in your zone. */
    enabled: boolean;
    /** The Certificate Authority that Total TLS certificates will be issued through. */
    certificateAuthority?: UpdateTotalTlsRequestCertificateAuthority | (string & {});
}
export declare const UpdateTotalTlsRequest: S.Schema<UpdateTotalTlsRequest>;
export type UpdateTotalTlsResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const UpdateTotalTlsResponseCertificateAuthority: any;
export type UpdateTotalTlsResponseValidityPeriod = 90;
export declare const UpdateTotalTlsResponseValidityPeriod: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTotalTlsResponse {
    /** The Certificate Authority that Total TLS certificates will be issued through. */
    certificateAuthority?: UpdateTotalTlsResponseCertificateAuthority | null;
    /** If enabled, Total TLS will order a hostname specific TLS certificate for any proxied A, AAAA, or CNAME record in your zone. */
    enabled?: boolean | null;
    /** The validity period in days for the certificates ordered via Total TLS. */
    validityPeriod?: UpdateTotalTlsResponseValidityPeriod | null;
}
export declare const UpdateTotalTlsResponse: S.Schema<UpdateTotalTlsResponse>;
export type CreateCustomTrustStoreError = InvalidObjectIdentifier | AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** Upload a root CA certificate to the Custom Origin Trust Store for a Zone. Only root CA certificates are accepted. */
export declare const createCustomTrustStore: API.OperationMethod<CreateCustomTrustStoreRequest, CreateCustomTrustStoreResponse, CreateCustomTrustStoreError, CloudflareOpContext>;
export type DeleteCustomTrustStoreError = InvalidObjectIdentifier | AdvancedCertificateManagerRequired | CustomTrustStoreNotFound | Forbidden | CloudflareOpError;
/** Removes a root CA certificate from the custom origin trust store. Origins using certificates signed by this CA will no longer be trusted. */
export declare const deleteCustomTrustStore: API.OperationMethod<DeleteCustomTrustStoreRequest, DeleteCustomTrustStoreResponse, DeleteCustomTrustStoreError, CloudflareOpContext>;
export type GetCustomTrustStoreError = InvalidObjectIdentifier | AdvancedCertificateManagerRequired | CustomTrustStoreNotFound | Forbidden | CloudflareOpError;
/** Retrieves details about a specific root CA certificate in the custom origin trust store, including expiration and subject information. */
export declare const getCustomTrustStore: API.OperationMethod<GetCustomTrustStoreRequest, GetCustomTrustStoreResponse, GetCustomTrustStoreError, CloudflareOpContext>;
export type GetTotalTlError = InvalidObjectIdentifier | AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** Get Total TLS Settings for a Zone. */
export declare const getTotalTl: API.OperationMethod<GetTotalTlRequest, GetTotalTlResponse, GetTotalTlError, CloudflareOpContext>;
export type ListCustomTrustStoresError = AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** Get Custom Origin Trust Store for a Zone. */
export declare const listCustomTrustStores: API.PaginatedOperationMethod<ListCustomTrustStoresRequest, ListCustomTrustStoresResponse, ListCustomTrustStoresError, CloudflareOpContext, CustomTrustStoreListResultItem>;
export type UpdateTotalTlError = InvalidObjectIdentifier | AdvancedCertificateManagerRequired | NoStateChange | PreviousJobInProgress | Forbidden | CloudflareOpError;
/** Set Total TLS Settings or disable the feature for a Zone. */
export declare const updateTotalTl: API.OperationMethod<UpdateTotalTlRequest, UpdateTotalTlResponse, UpdateTotalTlError, CloudflareOpContext>;
export type UpdateTotalTlsError = InvalidObjectIdentifier | AdvancedCertificateManagerRequired | NoStateChange | PreviousJobInProgress | Forbidden | CloudflareOpError;
/** Set Total TLS Settings or disable the feature for a Zone. */
export declare const updateTotalTls: API.OperationMethod<UpdateTotalTlsRequest, UpdateTotalTlsResponse, UpdateTotalTlsError, CloudflareOpContext>;
export declare const editTotalTl: API.OperationMethod<UpdateTotalTlRequest, UpdateTotalTlResponse, UpdateTotalTlError, CloudflareOpContext>;
export type EditTotalTlRequest = UpdateTotalTlRequest;
export type EditTotalTlResponse = UpdateTotalTlResponse;
export type EditTotalTlError = UpdateTotalTlError;
//# sourceMappingURL=acm.d.ts.map