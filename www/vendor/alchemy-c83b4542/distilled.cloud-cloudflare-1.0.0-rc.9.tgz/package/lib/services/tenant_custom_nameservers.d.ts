import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateTenantCustomNameserverRequest {
    /** Tenant identifier tag. */
    tenantTag: string;
    /** The FQDN of the name server. */
    nsName: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number;
}
export declare const CreateTenantCustomNameserverRequest: S.Schema<CreateTenantCustomNameserverRequest>;
export type CreateResponseDnsRecordsItemType = "A" | "AAAA";
export declare const CreateResponseDnsRecordsItemType: any;
export interface CreateResponseDnsRecordsItem {
    /** DNS record type. */
    type?: CreateResponseDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export declare const CreateResponseDnsRecordsItem: S.Schema<CreateResponseDnsRecordsItem>;
export type CreateResponseDnsRecordsList = Array<CreateResponseDnsRecordsItem>;
export declare const CreateResponseDnsRecordsList: S.Schema<CreateResponseDnsRecordsList>;
export type CreateResponseStatus = "moved" | "pending" | "verified";
export declare const CreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTenantCustomNameserverResponse {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: CreateResponseDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: CreateResponseStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export declare const CreateTenantCustomNameserverResponse: S.Schema<CreateTenantCustomNameserverResponse>;
export interface DeleteTenantCustomNameserverRequest {
    /** Tenant identifier tag. */
    tenantTag: string;
    /** The FQDN of the name server. */
    customNsId: string;
}
export declare const DeleteTenantCustomNameserverRequest: S.Schema<DeleteTenantCustomNameserverRequest>;
export type DeleteResultList = Array<string>;
export declare const DeleteResultList: S.Schema<DeleteResultList>;
export interface DeleteTenantCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const DeleteTenantCustomNameserverResponse: S.Schema<DeleteTenantCustomNameserverResponse>;
export interface GetTenantCustomNameserverRequest {
    /** Tenant identifier tag. */
    tenantTag: string;
}
export declare const GetTenantCustomNameserverRequest: S.Schema<GetTenantCustomNameserverRequest>;
export type GetResultItemDnsRecordsItemType = "A" | "AAAA";
export declare const GetResultItemDnsRecordsItemType: any;
export interface GetResultItemDnsRecordsItem {
    /** DNS record type. */
    type?: GetResultItemDnsRecordsItemType | null;
    /** DNS record contents (an IPv4 or IPv6 address). */
    value?: string | null;
}
export declare const GetResultItemDnsRecordsItem: S.Schema<GetResultItemDnsRecordsItem>;
export type GetResultItemDnsRecordsList = Array<GetResultItemDnsRecordsItem>;
export declare const GetResultItemDnsRecordsList: S.Schema<GetResultItemDnsRecordsList>;
export type GetResultItemStatus = "moved" | "pending" | "verified";
export declare const GetResultItemStatus: any;
export interface GetResultItem {
    /** A and AAAA records associated with the nameserver. */
    dnsRecords: GetResultItemDnsRecordsList;
    /** The FQDN of the name server. */
    nsName: string;
    /** Verification status of the nameserver. */
    status: GetResultItemStatus;
    /** Identifier. */
    zoneTag: string;
    /** The number of the set that this name server belongs to. */
    nsSet?: number | null;
}
export declare const GetResultItem: S.Schema<GetResultItem>;
export type GetResultList = Array<GetResultItem>;
export declare const GetResultList: S.Schema<GetResultList>;
export interface GetTenantCustomNameserverResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: GetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetTenantCustomNameserverResponse: S.Schema<GetTenantCustomNameserverResponse>;
export type CreateTenantCustomNameserverError = CloudflareOpError;
/** Add Tenant Custom Nameserver */
export declare const createTenantCustomNameserver: API.OperationMethod<CreateTenantCustomNameserverRequest, CreateTenantCustomNameserverResponse, CreateTenantCustomNameserverError, CloudflareOpContext>;
export type DeleteTenantCustomNameserverError = CloudflareOpError;
/** Delete Tenant Custom Nameserver */
export declare const deleteTenantCustomNameserver: API.PaginatedOperationMethod<DeleteTenantCustomNameserverRequest, DeleteTenantCustomNameserverResponse, DeleteTenantCustomNameserverError, CloudflareOpContext, string>;
export type GetTenantCustomNameserverError = CloudflareOpError;
/** List a tenant's custom nameservers. */
export declare const getTenantCustomNameserver: API.PaginatedOperationMethod<GetTenantCustomNameserverRequest, GetTenantCustomNameserverResponse, GetTenantCustomNameserverError, CloudflareOpContext, GetResultItem>;
//# sourceMappingURL=tenant_custom_nameservers.d.ts.map