import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ContainerApplicationNotFound_base: S.Class<ContainerApplicationNotFound, S.TaggedStruct<"ContainerApplicationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ContainerApplicationNotFound extends /*@__PURE__*/ ContainerApplicationNotFound_base {
}
declare const DurableObjectAlreadyHasApplication_base: S.Class<DurableObjectAlreadyHasApplication, S.TaggedStruct<"DurableObjectAlreadyHasApplication", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DurableObjectAlreadyHasApplication extends /*@__PURE__*/ DurableObjectAlreadyHasApplication_base {
}
declare const DurableObjectCheckError_base: S.Class<DurableObjectCheckError, S.TaggedStruct<"DurableObjectCheckError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DurableObjectCheckError extends /*@__PURE__*/ DurableObjectCheckError_base {
}
declare const DurableObjectNotContainerEnabled_base: S.Class<DurableObjectNotContainerEnabled, S.TaggedStruct<"DurableObjectNotContainerEnabled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DurableObjectNotContainerEnabled extends /*@__PURE__*/ DurableObjectNotContainerEnabled_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
export interface EnvironmentVariable {
    name: string;
    value: string;
}
export declare const EnvironmentVariable: S.Schema<EnvironmentVariable>;
export type EnvironmentVariableList = Array<EnvironmentVariable>;
export declare const EnvironmentVariableList: S.Schema<EnvironmentVariableList>;
export type DocumentList = Array<unknown>;
export declare const DocumentList: S.Schema<DocumentList>;
export type StringList = Array<string>;
export declare const StringList: S.Schema<StringList>;
export interface ContainerConfiguration {
    image: string;
    instanceType?: string | null;
    vcpu?: number | null;
    memory?: string | null;
    memoryMib?: number | null;
    disk?: unknown | null;
    environmentVariables?: EnvironmentVariableList | null;
    secrets?: DocumentList | null;
    labels?: DocumentList | null;
    ports?: DocumentList | null;
    network?: unknown | null;
    command?: StringList | null;
    entrypoint?: StringList | null;
    observability?: unknown | null;
    checks?: DocumentList | null;
    dns?: unknown | null;
    sshPublicKeyIds?: StringList | null;
}
export declare const ContainerConfiguration: S.Schema<ContainerConfiguration>;
export interface DurableObjectsRef {
    namespaceId: string;
}
export declare const DurableObjectsRef: S.Schema<DurableObjectsRef>;
export interface CreateContainerApplicationRequest {
    accountId: string;
    name: string;
    maxInstances: number;
    configuration: ContainerConfiguration;
    durableObjects?: DurableObjectsRef;
    instances?: number;
    schedulingPolicy?: string;
    constraints?: unknown;
    affinities?: unknown;
    jobs?: boolean;
}
export declare const CreateContainerApplicationRequest: S.Schema<CreateContainerApplicationRequest>;
export interface ContainerApplicationItem {
    id: string;
    name: string;
    accountId: string;
    schedulingPolicy: string;
    instances: number;
    maxInstances: number;
    constraints?: unknown | null;
    affinities?: unknown | null;
    configuration: ContainerConfiguration;
    durableObjects?: DurableObjectsRef | null;
    createdAt: string;
    version: number;
}
export declare const ContainerApplicationItem: S.Schema<ContainerApplicationItem>;
export type CreateContainerApplicationResponse = ContainerApplicationItem;
export declare const CreateContainerApplicationResponse: S.Schema<CreateContainerApplicationResponse>;
export interface CreateContainerApplicationRolloutRequest {
    accountId: string;
    applicationId: string;
    description: string;
    strategy: string;
    kind?: string;
    stepPercentage?: number;
    targetConfiguration?: ContainerConfiguration;
}
export declare const CreateContainerApplicationRolloutRequest: S.Schema<CreateContainerApplicationRolloutRequest>;
export type CreateContainerApplicationRolloutResponse = ContainerApplicationItem;
export declare const CreateContainerApplicationRolloutResponse: S.Schema<CreateContainerApplicationRolloutResponse>;
export interface CreateContainerRegistryCredentialsRequest {
    accountId: string;
    registryId: string;
    permissions: StringList;
    expirationMinutes: number;
}
export declare const CreateContainerRegistryCredentialsRequest: S.Schema<CreateContainerRegistryCredentialsRequest>;
/** Registry credentials (transcribed from the distilled SDK — endpoint is docs-absent). */
export interface CreateContainerRegistryCredentialsResult {
    user?: string | null;
    username?: string | null;
    password: string;
}
export declare const CreateContainerRegistryCredentialsResult: S.Schema<CreateContainerRegistryCredentialsResult>;
export type CreateContainerRegistryCredentialsResponse = CreateContainerRegistryCredentialsResult;
export declare const CreateContainerRegistryCredentialsResponse: S.Schema<CreateContainerRegistryCredentialsResponse>;
export interface DeleteContainerApplicationRequest {
    accountId: string;
    applicationId: string;
}
export declare const DeleteContainerApplicationRequest: S.Schema<DeleteContainerApplicationRequest>;
export type DeleteContainerApplicationResponse = unknown;
export declare const DeleteContainerApplicationResponse: S.Schema<DeleteContainerApplicationResponse>;
export interface GetContainerApplicationRequest {
    accountId: string;
    applicationId: string;
}
export declare const GetContainerApplicationRequest: S.Schema<GetContainerApplicationRequest>;
export type GetContainerApplicationResponse = ContainerApplicationItem;
export declare const GetContainerApplicationResponse: S.Schema<GetContainerApplicationResponse>;
export interface GetContainerIdentityRequest {
    accountId: string;
}
export declare const GetContainerIdentityRequest: S.Schema<GetContainerIdentityRequest>;
export type GetContainerIdentityResponse = unknown;
export declare const GetContainerIdentityResponse: S.Schema<GetContainerIdentityResponse>;
export interface ListContainerApplicationsRequest {
    accountId: string;
}
export declare const ListContainerApplicationsRequest: S.Schema<ListContainerApplicationsRequest>;
export type ContainerApplicationItemList = Array<ContainerApplicationItem>;
export declare const ContainerApplicationItemList: S.Schema<ContainerApplicationItemList>;
export type ListContainerApplicationsResponse = ContainerApplicationItemList;
export declare const ListContainerApplicationsResponse: S.Schema<ListContainerApplicationsResponse>;
export interface UpdateContainerApplicationRequest {
    accountId: string;
    applicationId: string;
    maxInstances?: number;
    configuration?: ContainerConfiguration;
    instances?: number;
    schedulingPolicy?: string;
    constraints?: unknown;
    affinities?: unknown;
}
export declare const UpdateContainerApplicationRequest: S.Schema<UpdateContainerApplicationRequest>;
export type UpdateContainerApplicationResponse = ContainerApplicationItem;
export declare const UpdateContainerApplicationResponse: S.Schema<UpdateContainerApplicationResponse>;
export type CreateContainerApplicationError = InvalidRoute | DurableObjectAlreadyHasApplication | DurableObjectNotContainerEnabled | DurableObjectCheckError | CloudflareOpError;
export declare const createContainerApplication: API.OperationMethod<CreateContainerApplicationRequest, CreateContainerApplicationResponse, CreateContainerApplicationError, CloudflareOpContext>;
export type CreateContainerApplicationRolloutError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const createContainerApplicationRollout: API.OperationMethod<CreateContainerApplicationRolloutRequest, CreateContainerApplicationRolloutResponse, CreateContainerApplicationRolloutError, CloudflareOpContext>;
export type CreateContainerRegistryCredentialsError = InvalidRoute | CloudflareOpError;
export declare const createContainerRegistryCredentials: API.OperationMethod<CreateContainerRegistryCredentialsRequest, CreateContainerRegistryCredentialsResponse, CreateContainerRegistryCredentialsError, CloudflareOpContext>;
export type DeleteContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const deleteContainerApplication: API.OperationMethod<DeleteContainerApplicationRequest, DeleteContainerApplicationResponse, DeleteContainerApplicationError, CloudflareOpContext>;
export type GetContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const getContainerApplication: API.OperationMethod<GetContainerApplicationRequest, GetContainerApplicationResponse, GetContainerApplicationError, CloudflareOpContext>;
export type GetContainerIdentityError = InvalidRoute | CloudflareOpError;
export declare const getContainerIdentity: API.OperationMethod<GetContainerIdentityRequest, GetContainerIdentityResponse, GetContainerIdentityError, CloudflareOpContext>;
export type ListContainerApplicationsError = InvalidRoute | CloudflareOpError;
export declare const listContainerApplications: API.OperationMethod<ListContainerApplicationsRequest, ListContainerApplicationsResponse, ListContainerApplicationsError, CloudflareOpContext>;
export type UpdateContainerApplicationError = InvalidRoute | ContainerApplicationNotFound | CloudflareOpError;
export declare const updateContainerApplication: API.OperationMethod<UpdateContainerApplicationRequest, UpdateContainerApplicationResponse, UpdateContainerApplicationError, CloudflareOpContext>;
//# sourceMappingURL=containers.d.ts.map