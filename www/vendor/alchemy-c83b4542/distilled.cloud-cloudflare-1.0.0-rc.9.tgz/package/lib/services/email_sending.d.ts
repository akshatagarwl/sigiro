import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const SendingSubdomainAlreadyExists_base: S.Class<SendingSubdomainAlreadyExists, S.TaggedStruct<"SendingSubdomainAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SendingSubdomainAlreadyExists extends /*@__PURE__*/ SendingSubdomainAlreadyExists_base {
}
declare const SendingSubdomainNotFound_base: S.Class<SendingSubdomainNotFound, S.TaggedStruct<"SendingSubdomainNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SendingSubdomainNotFound extends /*@__PURE__*/ SendingSubdomainNotFound_base {
}
export interface CreateSubdomainRequest {
    /** Identifier. */
    zoneId: string;
    /** The subdomain name. Must be within the zone. */
    name: string;
}
export declare const CreateSubdomainRequest: S.Schema<CreateSubdomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubdomainResponse {
    /** Whether Email Sending is enabled on this subdomain. */
    enabled: boolean;
    /** The subdomain domain name. */
    name: string;
    /** Sending subdomain identifier. */
    tag: string;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The DKIM selector used for email signing. */
    dkimSelector?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean | null;
    /** The return-path domain used for bounce handling. */
    returnPathDomain?: string | null;
}
export declare const CreateSubdomainResponse: S.Schema<CreateSubdomainResponse>;
export interface DeleteSubdomainRequest {
    /** Identifier. */
    zoneId: string;
    /** Sending subdomain identifier. */
    subdomainId: string;
}
export declare const DeleteSubdomainRequest: S.Schema<DeleteSubdomainRequest>;
export interface DeleteSubdomainResponse {
}
export declare const DeleteSubdomainResponse: S.Schema<DeleteSubdomainResponse>;
export interface GetSubdomainRequest {
    /** Identifier. */
    zoneId: string;
    /** Sending subdomain identifier. */
    subdomainId: string;
}
export declare const GetSubdomainRequest: S.Schema<GetSubdomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubdomainResponse {
    /** Whether Email Sending is enabled on this subdomain. */
    enabled: boolean;
    /** The subdomain domain name. */
    name: string;
    /** Sending subdomain identifier. */
    tag: string;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The DKIM selector used for email signing. */
    dkimSelector?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean | null;
    /** The return-path domain used for bounce handling. */
    returnPathDomain?: string | null;
}
export declare const GetSubdomainResponse: S.Schema<GetSubdomainResponse>;
export interface GetSubdomainDnsRequest {
    /** Identifier. */
    zoneId: string;
    /** Sending subdomain identifier. */
    subdomainId: string;
}
export declare const GetSubdomainDnsRequest: S.Schema<GetSubdomainDnsRequest>;
export type SubdomainsDnsGetResultItemType = "A" | "AAAA" | "CNAME" | "HTTPS" | "TXT" | "SRV" | "LOC" | "MX" | "NS" | "CERT" | "DNSKEY" | "DS" | "NAPTR" | "SMIMEA" | "SSHFP" | "SVCB" | "TLSA" | "URI";
export declare const SubdomainsDnsGetResultItemType: any;
export interface SubdomainsDnsGetResultItem {
    /** DNS record content. */
    content?: string | null;
    /** DNS record name (or @ for the zone apex). */
    name?: string | null;
    /** Required for MX, SRV and URI records. Unused by other record types. Records with lower priorities are preferred. */
    priority?: number | null;
    /** Time to live, in seconds, of the DNS record. Must be between 60 and 86400, or 1 for 'automatic'. */
    ttl?: number | null;
    /** DNS record type. */
    type?: SubdomainsDnsGetResultItemType | null;
}
export declare const SubdomainsDnsGetResultItem: S.Schema<SubdomainsDnsGetResultItem>;
export type SubdomainsDnsGetResultList = Array<SubdomainsDnsGetResultItem>;
export declare const SubdomainsDnsGetResultList: S.Schema<SubdomainsDnsGetResultList>;
export interface GetSubdomainDnsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubdomainsDnsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetSubdomainDnsResponse: S.Schema<GetSubdomainDnsResponse>;
export interface ListSubdomainsRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const ListSubdomainsRequest: S.Schema<ListSubdomainsRequest>;
export interface SubdomainsListResultItem {
    /** Whether Email Sending is enabled on this subdomain. */
    enabled: boolean;
    /** The subdomain domain name. */
    name: string;
    /** Sending subdomain identifier. */
    tag: string;
    /** The date and time the destination address has been created. */
    created?: string | null;
    /** The DKIM selector used for email signing. */
    dkimSelector?: string | null;
    /** The date and time the destination address was last modified. */
    modified?: string | null;
    /** Whether sent messages from this subdomain can be previewed in the activity log. */
    previewEnabled?: boolean | null;
    /** The return-path domain used for bounce handling. */
    returnPathDomain?: string | null;
}
export declare const SubdomainsListResultItem: S.Schema<SubdomainsListResultItem>;
export type SubdomainsListResultList = Array<SubdomainsListResultItem>;
export declare const SubdomainsListResultList: S.Schema<SubdomainsListResultList>;
export interface ListSubdomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubdomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSubdomainsResponse: S.Schema<ListSubdomainsResponse>;
export interface SendRequestFromEmailSendingEmailAddressObject {
    /** Email address (e.g., 'user@example.com'). */
    address: string;
    /** Display name for the email address (e.g., 'John Doe'). Optional — omit or set to null for no display name. */
    name?: string;
}
export declare const SendRequestFromEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestFrom = string | SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestFrom: any;
export type SendRequestAttachmentsItemInlineDisposition = "inline";
export declare const SendRequestAttachmentsItemInlineDisposition: any;
export interface SendRequestAttachmentsItemInline {
    /** Base64-encoded content of the attachment. */
    content: string;
    /** Content ID used to reference this attachment in HTML via cid: URI (e.g., <img src="cid:logo">). */
    contentId: string;
    /** Must be 'inline'. Indicates the attachment is embedded in the email body. */
    disposition: SendRequestAttachmentsItemInlineDisposition;
    /** Filename for the attachment. */
    filename: string;
    /** MIME type of the attachment (e.g., 'image/png', 'text/plain'). */
    type: string;
}
export declare const SendRequestAttachmentsItemInline: S.Schema<SendRequestAttachmentsItemInline>;
export type SendRequestAttachmentsItemAttachmentDisposition = "attachment";
export declare const SendRequestAttachmentsItemAttachmentDisposition: any;
export interface SendRequestAttachmentsItemAttachment {
    /** Base64-encoded content of the attachment. */
    content: string;
    /** Must be 'attachment'. Indicates a standard file attachment. */
    disposition: SendRequestAttachmentsItemAttachmentDisposition;
    /** Filename for the attachment. */
    filename: string;
    /** MIME type of the attachment (e.g., 'application/pdf', 'text/plain'). */
    type: string;
}
export declare const SendRequestAttachmentsItemAttachment: S.Schema<SendRequestAttachmentsItemAttachment>;
export type SendRequestAttachmentsItem = SendRequestAttachmentsItemInline | SendRequestAttachmentsItemAttachment;
export declare const SendRequestAttachmentsItem: any;
export type SendRequestAttachmentsList = Array<SendRequestAttachmentsItem>;
export declare const SendRequestAttachmentsList: S.Schema<SendRequestAttachmentsList>;
export type SendRequestBccEmailSendingEmailAddressObject = SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestBccEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestBccCase2ItemEmailSendingEmailAddressObject = SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestBccCase2ItemEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestBccCase2Item = string | SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestBccCase2Item: any;
export type SendRequestBccCase2List = Array<SendRequestBccCase2Item>;
export declare const SendRequestBccCase2List: S.Schema<SendRequestBccCase2List>;
export type SendRequestBcc = string | SendRequestFromEmailSendingEmailAddressObject | SendRequestBccCase2List;
export declare const SendRequestBcc: any;
export type SendRequestCcEmailSendingEmailAddressObject = SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestCcEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestCcCase2ItemEmailSendingEmailAddressObject = SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestCcCase2ItemEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestCcCase2Item = string | SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestCcCase2Item: any;
export type SendRequestCcCase2List = Array<SendRequestCcCase2Item>;
export declare const SendRequestCcCase2List: S.Schema<SendRequestCcCase2List>;
export type SendRequestCc = string | SendRequestFromEmailSendingEmailAddressObject | SendRequestCcCase2List;
export declare const SendRequestCc: any;
export type SendRequestHeadersMap = {
    [key: string]: string | undefined;
};
export declare const SendRequestHeadersMap: S.Schema<SendRequestHeadersMap>;
export type SendRequestReplyToEmailSendingEmailAddressObject = SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestReplyToEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestReplyTo = string | SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestReplyTo: any;
export type SendRequestToEmailSendingEmailAddressObject = SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestToEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestToCase2ItemEmailSendingEmailAddressObject = SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestToCase2ItemEmailSendingEmailAddressObject: S.Schema<SendRequestFromEmailSendingEmailAddressObject>;
export type SendRequestToCase2Item = string | SendRequestFromEmailSendingEmailAddressObject;
export declare const SendRequestToCase2Item: any;
export type SendRequestToCase2List = Array<SendRequestToCase2Item>;
export declare const SendRequestToCase2List: S.Schema<SendRequestToCase2List>;
export type SendRequestTo = string | SendRequestFromEmailSendingEmailAddressObject | SendRequestToCase2List;
export declare const SendRequestTo: any;
export interface SendEmailSendingRequest {
    /** Identifier of the account. */
    accountId: string;
    /** Sender email address. Either a plain string or an object with address and name. */
    from: SendRequestFrom;
    /** Email subject line. */
    subject: string;
    /** File attachments and inline images. */
    attachments?: SendRequestAttachmentsList;
    /** BCC recipient(s). A single email string, a named address object, or an array of either. */
    bcc?: SendRequestBcc;
    /** CC recipient(s). A single email string, a named address object, or an array of either. */
    cc?: SendRequestCc;
    /** Custom email headers as key-value pairs. */
    headers?: SendRequestHeadersMap;
    /** HTML body of the email. At least one of text or html must be provided (non-empty). */
    html?: string;
    /** Reply-to address. Either a plain string or an object with address and name. */
    replyTo?: SendRequestReplyTo;
    /** Plain text body of the email. At least one of text or html must be provided (non-empty). */
    text?: string;
    /** Recipient(s). Optional if cc or bcc is provided. A single email string, a named address object, or an array of either. */
    to?: SendRequestTo;
}
export declare const SendEmailSendingRequest: S.Schema<SendEmailSendingRequest>;
export type SendResponseDeliveredList = Array<string>;
export declare const SendResponseDeliveredList: S.Schema<SendResponseDeliveredList>;
export type SendResponsePermanentBouncesList = Array<string>;
export declare const SendResponsePermanentBouncesList: S.Schema<SendResponsePermanentBouncesList>;
export type SendResponseQueuedList = Array<string>;
export declare const SendResponseQueuedList: S.Schema<SendResponseQueuedList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SendEmailSendingResponse {
    /** Email addresses to which the message was delivered immediately. */
    delivered: SendResponseDeliveredList;
    /** Message ID of the sent email. */
    messageId: string;
    /** Email addresses that permanently bounced. */
    permanentBounces: SendResponsePermanentBouncesList;
    /** Email addresses for which delivery was queued for later. */
    queued: SendResponseQueuedList;
}
export declare const SendEmailSendingResponse: S.Schema<SendEmailSendingResponse>;
export type SendRawRequestRecipientsList = Array<string>;
export declare const SendRawRequestRecipientsList: S.Schema<SendRawRequestRecipientsList>;
export interface SendRawEmailSendingRequest {
    /** Identifier of the account. */
    accountId: string;
    /** Sender email address. */
    from: string;
    /** The full MIME-encoded email message. Should include standard RFC 5322 headers such as From, To, Subject, and Content-Type. The from and recipients fields in the request body control SMTP envelope routing; the From and To headers in the MIME message control what the recipient's email client displays. */
    mimeMessage: string;
    /** List of recipient email addresses. */
    recipients: SendRawRequestRecipientsList;
}
export declare const SendRawEmailSendingRequest: S.Schema<SendRawEmailSendingRequest>;
export type SendRawResponseDeliveredList = Array<string>;
export declare const SendRawResponseDeliveredList: S.Schema<SendRawResponseDeliveredList>;
export type SendRawResponsePermanentBouncesList = Array<string>;
export declare const SendRawResponsePermanentBouncesList: S.Schema<SendRawResponsePermanentBouncesList>;
export type SendRawResponseQueuedList = Array<string>;
export declare const SendRawResponseQueuedList: S.Schema<SendRawResponseQueuedList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SendRawEmailSendingResponse {
    /** Email addresses to which the message was delivered immediately. */
    delivered: SendRawResponseDeliveredList;
    /** Message ID of the sent email. */
    messageId: string;
    /** Email addresses that permanently bounced. */
    permanentBounces: SendRawResponsePermanentBouncesList;
    /** Email addresses for which delivery was queued for later. */
    queued: SendRawResponseQueuedList;
}
export declare const SendRawEmailSendingResponse: S.Schema<SendRawEmailSendingResponse>;
export type CreateSubdomainError = Forbidden | SendingSubdomainAlreadyExists | CloudflareOpError;
/** Creates a new sending subdomain or re-enables sending on an existing subdomain that had it disabled. If zone-level Email Sending has not been enabled yet, the zone flag is automatically set when the entitlement is present. */
export declare const createSubdomain: API.OperationMethod<CreateSubdomainRequest, CreateSubdomainResponse, CreateSubdomainError, CloudflareOpContext>;
export type DeleteSubdomainError = Forbidden | SendingSubdomainNotFound | CloudflareOpError;
/** Disables sending on a subdomain and removes its DNS records. If routing is still active on the subdomain, only sending is disabled. */
export declare const deleteSubdomain: API.OperationMethod<DeleteSubdomainRequest, DeleteSubdomainResponse, DeleteSubdomainError, CloudflareOpContext>;
export type GetSubdomainError = Forbidden | SendingSubdomainNotFound | CloudflareOpError;
/** Gets information for a specific sending subdomain. */
export declare const getSubdomain: API.OperationMethod<GetSubdomainRequest, GetSubdomainResponse, GetSubdomainError, CloudflareOpContext>;
export type GetSubdomainDnsError = CloudflareOpError;
/** Returns the expected DNS records for a sending subdomain. */
export declare const getSubdomainDns: API.PaginatedOperationMethod<GetSubdomainDnsRequest, GetSubdomainDnsResponse, GetSubdomainDnsError, CloudflareOpContext, SubdomainsDnsGetResultItem>;
export type ListSubdomainsError = Forbidden | CloudflareOpError;
/** Lists all sending-enabled subdomains for the zone. */
export declare const listSubdomains: API.PaginatedOperationMethod<ListSubdomainsRequest, ListSubdomainsResponse, ListSubdomainsError, CloudflareOpContext, SubdomainsListResultItem>;
export type SendEmailSendingError = CloudflareOpError;
/** Send an email */
export declare const sendEmailSending: API.OperationMethod<SendEmailSendingRequest, SendEmailSendingResponse, SendEmailSendingError, CloudflareOpContext>;
export type SendRawEmailSendingError = CloudflareOpError;
/** Send a raw MIME email */
export declare const sendRawEmailSending: API.OperationMethod<SendRawEmailSendingRequest, SendRawEmailSendingResponse, SendRawEmailSendingError, CloudflareOpContext>;
//# sourceMappingURL=email_sending.d.ts.map