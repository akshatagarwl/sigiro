import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ClientCertificateAlreadyRevoked_base: S.Class<ClientCertificateAlreadyRevoked, S.TaggedStruct<"ClientCertificateAlreadyRevoked", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ClientCertificateAlreadyRevoked extends /*@__PURE__*/ ClientCertificateAlreadyRevoked_base {
}
declare const ClientCertificateNotFound_base: S.Class<ClientCertificateNotFound, S.TaggedStruct<"ClientCertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ClientCertificateNotFound extends /*@__PURE__*/ ClientCertificateNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CreateClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr: string;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays: number;
}
export declare const CreateClientCertificateRequest: S.Schema<CreateClientCertificateRequest>;
export interface CreateResponseCertificateAuthority {
    id?: string | null;
    name?: string | null;
}
export declare const CreateResponseCertificateAuthority: S.Schema<CreateResponseCertificateAuthority>;
export type CreateResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export declare const CreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateClientCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The Client Certificate PEM. */
    certificate?: string | null;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null;
    /** Common Name of the Client Certificate. */
    commonName?: string | null;
    /** Country, provided by the CSR. */
    country?: string | null;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null;
    /** Location, provided by the CSR. */
    location?: string | null;
    /** Organization, provided by the CSR. */
    organization?: string | null;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null;
    /** Subject Key Identifier. */
    ski?: string | null;
    /** State, provided by the CSR. */
    state?: string | null;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: CreateResponseStatus | null;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null;
}
export declare const CreateClientCertificateResponse: S.Schema<CreateClientCertificateResponse>;
export interface DeleteClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    clientCertificateId: string;
}
export declare const DeleteClientCertificateRequest: S.Schema<DeleteClientCertificateRequest>;
export type DeleteResponseCertificateAuthority = CreateResponseCertificateAuthority;
export declare const DeleteResponseCertificateAuthority: S.Schema<CreateResponseCertificateAuthority>;
export type DeleteResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export declare const DeleteResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteClientCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The Client Certificate PEM. */
    certificate?: string | null;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null;
    /** Common Name of the Client Certificate. */
    commonName?: string | null;
    /** Country, provided by the CSR. */
    country?: string | null;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null;
    /** Location, provided by the CSR. */
    location?: string | null;
    /** Organization, provided by the CSR. */
    organization?: string | null;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null;
    /** Subject Key Identifier. */
    ski?: string | null;
    /** State, provided by the CSR. */
    state?: string | null;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: DeleteResponseStatus | null;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null;
}
export declare const DeleteClientCertificateResponse: S.Schema<DeleteClientCertificateResponse>;
export interface GetClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    clientCertificateId: string;
}
export declare const GetClientCertificateRequest: S.Schema<GetClientCertificateRequest>;
export type GetResponseCertificateAuthority = CreateResponseCertificateAuthority;
export declare const GetResponseCertificateAuthority: S.Schema<CreateResponseCertificateAuthority>;
export type GetResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export declare const GetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetClientCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The Client Certificate PEM. */
    certificate?: string | null;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null;
    /** Common Name of the Client Certificate. */
    commonName?: string | null;
    /** Country, provided by the CSR. */
    country?: string | null;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null;
    /** Location, provided by the CSR. */
    location?: string | null;
    /** Organization, provided by the CSR. */
    organization?: string | null;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null;
    /** Subject Key Identifier. */
    ski?: string | null;
    /** State, provided by the CSR. */
    state?: string | null;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: GetResponseStatus | null;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null;
}
export declare const GetClientCertificateResponse: S.Schema<GetClientCertificateResponse>;
export type ListRequestStatus = "all" | "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export declare const ListRequestStatus: any;
export interface ListClientCertificatesRequest {
    /** Identifier. */
    zoneId: string;
    /** Limit to the number of records returned. */
    limit?: number;
    /** Offset the results. */
    offset?: number;
    /** Page number of paginated results. */
    page?: number;
    /** Number of records per page. */
    perPage?: number;
    /** Client Certitifcate Status to filter results by. */
    status?: ListRequestStatus | (string & {});
}
export declare const ListClientCertificatesRequest: S.Schema<ListClientCertificatesRequest>;
export type ListResultItemCertificateAuthority = CreateResponseCertificateAuthority;
export declare const ListResultItemCertificateAuthority: S.Schema<CreateResponseCertificateAuthority>;
export type ListResultItemStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export declare const ListResultItemStatus: any;
export interface ListResultItem {
    /** Identifier. */
    id?: string | null;
    /** The Client Certificate PEM. */
    certificate?: string | null;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null;
    /** Common Name of the Client Certificate. */
    commonName?: string | null;
    /** Country, provided by the CSR. */
    country?: string | null;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null;
    /** Location, provided by the CSR. */
    location?: string | null;
    /** Organization, provided by the CSR. */
    organization?: string | null;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null;
    /** Subject Key Identifier. */
    ski?: string | null;
    /** State, provided by the CSR. */
    state?: string | null;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: ListResultItemStatus | null;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListClientCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListClientCertificatesResponse: S.Schema<ListClientCertificatesResponse>;
export interface PatchClientCertificateRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    clientCertificateId: string;
    reactivate?: boolean;
}
export declare const PatchClientCertificateRequest: S.Schema<PatchClientCertificateRequest>;
export type EditResponseCertificateAuthority = CreateResponseCertificateAuthority;
export declare const EditResponseCertificateAuthority: S.Schema<CreateResponseCertificateAuthority>;
export type EditResponseStatus = "active" | "pending_reactivation" | "pending_revocation" | "revoked";
export declare const EditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchClientCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** The Client Certificate PEM. */
    certificate?: string | null;
    /** Certificate Authority used to issue the Client Certificate. */
    certificateAuthority?: CreateResponseCertificateAuthority | null;
    /** Common Name of the Client Certificate. */
    commonName?: string | null;
    /** Country, provided by the CSR. */
    country?: string | null;
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr?: string | null;
    /** Date that the Client Certificate expires. */
    expiresOn?: string | null;
    /** Unique identifier of the Client Certificate. */
    fingerprintSha256?: string | null;
    /** Date that the Client Certificate was issued by the Certificate Authority. */
    issuedOn?: string | null;
    /** Location, provided by the CSR. */
    location?: string | null;
    /** Organization, provided by the CSR. */
    organization?: string | null;
    /** Organizational Unit, provided by the CSR. */
    organizationalUnit?: string | null;
    /** The serial number on the created Client Certificate. */
    serialNumber?: string | null;
    /** The type of hash used for the Client Certificate.. */
    signature?: string | null;
    /** Subject Key Identifier. */
    ski?: string | null;
    /** State, provided by the CSR. */
    state?: string | null;
    /** Client Certificates may be active or revoked, and the pending_reactivation or pending_revocation represent in-progress asynchronous transitions. */
    status?: EditResponseStatus | null;
    /** The number of days the Client Certificate will be valid after the issued_on date. */
    validityDays?: number | null;
}
export declare const PatchClientCertificateResponse: S.Schema<PatchClientCertificateResponse>;
export type CreateClientCertificateError = Forbidden | CloudflareOpError;
/** Create a new API Shield mTLS Client Certificate. */
export declare const createClientCertificate: API.OperationMethod<CreateClientCertificateRequest, CreateClientCertificateResponse, CreateClientCertificateError, CloudflareOpContext>;
export type DeleteClientCertificateError = ClientCertificateNotFound | ClientCertificateAlreadyRevoked | Forbidden | CloudflareOpError;
/** Set a API Shield mTLS Client Certificate to pending_revocation status for processing to revoked status. */
export declare const deleteClientCertificate: API.OperationMethod<DeleteClientCertificateRequest, DeleteClientCertificateResponse, DeleteClientCertificateError, CloudflareOpContext>;
export type GetClientCertificateError = ClientCertificateNotFound | Forbidden | CloudflareOpError;
/** Get Details for a single mTLS API Shield Client Certificate. */
export declare const getClientCertificate: API.OperationMethod<GetClientCertificateRequest, GetClientCertificateResponse, GetClientCertificateError, CloudflareOpContext>;
export type ListClientCertificatesError = Forbidden | CloudflareOpError;
/** List all of your Zone's API Shield mTLS Client Certificates by Status and/or using Pagination. */
export declare const listClientCertificates: API.PaginatedOperationMethod<ListClientCertificatesRequest, ListClientCertificatesResponse, ListClientCertificatesError, CloudflareOpContext, ListResultItem>;
export type PatchClientCertificateError = ClientCertificateNotFound | Forbidden | CloudflareOpError;
/** If a API Shield mTLS Client Certificate is in a pending_revocation state, you may reactivate it with this endpoint. */
export declare const patchClientCertificate: API.OperationMethod<PatchClientCertificateRequest, PatchClientCertificateResponse, PatchClientCertificateError, CloudflareOpContext>;
//# sourceMappingURL=client_certificates.d.ts.map