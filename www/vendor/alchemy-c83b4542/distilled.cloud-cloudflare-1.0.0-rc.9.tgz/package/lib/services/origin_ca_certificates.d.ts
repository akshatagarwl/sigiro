import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CertificateAlreadyRevoked_base: S.Class<CertificateAlreadyRevoked, S.TaggedStruct<"CertificateAlreadyRevoked", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateAlreadyRevoked extends /*@__PURE__*/ CertificateAlreadyRevoked_base {
}
declare const CertificateNotFound_base: S.Class<CertificateNotFound, S.TaggedStruct<"CertificateNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateNotFound extends /*@__PURE__*/ CertificateNotFound_base {
}
declare const CertificateRevocationFailed_base: S.Class<CertificateRevocationFailed, S.TaggedStruct<"CertificateRevocationFailed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificateRevocationFailed extends /*@__PURE__*/ CertificateRevocationFailed_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const HostnameNotAuthorized_base: S.Class<HostnameNotAuthorized, S.TaggedStruct<"HostnameNotAuthorized", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class HostnameNotAuthorized extends /*@__PURE__*/ HostnameNotAuthorized_base {
}
export type CreateRequestHostnamesList = Array<string>;
export declare const CreateRequestHostnamesList: S.Schema<CreateRequestHostnamesList>;
export type CreateRequestRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export declare const CreateRequestRequestType: any;
export type CreateRequestRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
export declare const CreateRequestRequestedValidity: any;
export interface CreateOriginCaCertificateRequest {
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr: string;
    /** Array of hostnames or wildcard names bound to the certificate. */
    hostnames: CreateRequestHostnamesList;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType: CreateRequestRequestType | (string & {});
    /** The number of days for which the certificate should be valid. */
    requestedValidity?: CreateRequestRequestedValidity | (number & {});
}
export declare const CreateOriginCaCertificateRequest: S.Schema<CreateOriginCaCertificateRequest>;
export type CreateResponseHostnamesList = Array<string>;
export declare const CreateResponseHostnamesList: S.Schema<CreateResponseHostnamesList>;
export type CreateResponseRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export declare const CreateResponseRequestType: any;
export type CreateResponseRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
export declare const CreateResponseRequestedValidity: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOriginCaCertificateResponse {
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr: string;
    /** Array of hostnames or wildcard names bound to the certificate. */
    hostnames: CreateResponseHostnamesList;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType: CreateResponseRequestType;
    /** The number of days for which the certificate should be valid. */
    requestedValidity: CreateResponseRequestedValidity;
    /** Identifier. */
    id?: string | null;
    /** The Origin CA certificate. Will be newline-encoded. */
    certificate?: string | null;
    /** When the certificate will expire. */
    expiresOn?: string | null;
    /** When the certificate was revoked; absent while the certificate is live. */
    revokedAt?: string | null;
}
export declare const CreateOriginCaCertificateResponse: S.Schema<CreateOriginCaCertificateResponse>;
export interface DeleteOriginCaCertificateRequest {
    /** Identifier. */
    certificateId: string;
}
export declare const DeleteOriginCaCertificateRequest: S.Schema<DeleteOriginCaCertificateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOriginCaCertificateResponse {
    /** Identifier. */
    id?: string | null;
    /** When the certificate was revoked. */
    revokedAt?: string | null;
}
export declare const DeleteOriginCaCertificateResponse: S.Schema<DeleteOriginCaCertificateResponse>;
export interface GetOriginCaCertificateRequest {
    /** Identifier. */
    certificateId: string;
}
export declare const GetOriginCaCertificateRequest: S.Schema<GetOriginCaCertificateRequest>;
export type GetResponseHostnamesList = Array<string>;
export declare const GetResponseHostnamesList: S.Schema<GetResponseHostnamesList>;
export type GetResponseRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export declare const GetResponseRequestType: any;
export type GetResponseRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
export declare const GetResponseRequestedValidity: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOriginCaCertificateResponse {
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr: string;
    /** Array of hostnames or wildcard names bound to the certificate. */
    hostnames: GetResponseHostnamesList;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType: GetResponseRequestType;
    /** The number of days for which the certificate should be valid. */
    requestedValidity: GetResponseRequestedValidity;
    /** Identifier. */
    id?: string | null;
    /** The Origin CA certificate. Will be newline-encoded. */
    certificate?: string | null;
    /** When the certificate will expire. */
    expiresOn?: string | null;
    /** When the certificate was revoked; absent while the certificate is live. */
    revokedAt?: string | null;
}
export declare const GetOriginCaCertificateResponse: S.Schema<GetOriginCaCertificateResponse>;
export interface ListOriginCaCertificatesRequest {
    /** Identifier. */
    zoneId: string;
    /** Limit to the number of records returned. */
    limit?: number;
    /** Offset the results. */
    offset?: number;
    /** Page number of paginated results. */
    page?: number;
    /** Number of records per page. */
    perPage?: number;
}
export declare const ListOriginCaCertificatesRequest: S.Schema<ListOriginCaCertificatesRequest>;
export type ListResultItemHostnamesList = Array<string>;
export declare const ListResultItemHostnamesList: S.Schema<ListResultItemHostnamesList>;
export type ListResultItemRequestType = "origin-rsa" | "origin-ecc" | "keyless-certificate";
export declare const ListResultItemRequestType: any;
export type ListResultItemRequestedValidity = 7 | 30 | 90 | 365 | 730 | 1095 | 5475;
export declare const ListResultItemRequestedValidity: any;
export interface ListResultItem {
    /** The Certificate Signing Request (CSR). Must be newline-encoded. */
    csr: string;
    /** Array of hostnames or wildcard names bound to the certificate. */
    hostnames: ListResultItemHostnamesList;
    /** Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers). */
    requestType: ListResultItemRequestType;
    /** The number of days for which the certificate should be valid. */
    requestedValidity: ListResultItemRequestedValidity;
    /** Identifier. */
    id?: string | null;
    /** The Origin CA certificate. Will be newline-encoded. */
    certificate?: string | null;
    /** When the certificate will expire. */
    expiresOn?: string | null;
    /** When the certificate was revoked; absent while the certificate is live. */
    revokedAt?: string | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListOriginCaCertificatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOriginCaCertificatesResponse: S.Schema<ListOriginCaCertificatesResponse>;
export type CreateOriginCaCertificateError = HostnameNotAuthorized | Forbidden | CloudflareOpError;
/** Create an Origin CA certificate. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const createOriginCaCertificate: API.OperationMethod<CreateOriginCaCertificateRequest, CreateOriginCaCertificateResponse, CreateOriginCaCertificateError, CloudflareOpContext>;
export type DeleteOriginCaCertificateError = CertificateNotFound | CertificateAlreadyRevoked | CertificateRevocationFailed | Forbidden | CloudflareOpError;
/** Revoke an existing Origin CA certificate by its serial number. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const deleteOriginCaCertificate: API.OperationMethod<DeleteOriginCaCertificateRequest, DeleteOriginCaCertificateResponse, DeleteOriginCaCertificateError, CloudflareOpContext>;
export type GetOriginCaCertificateError = CertificateNotFound | Forbidden | CloudflareOpError;
/** Get an existing Origin CA certificate by its serial number. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const getOriginCaCertificate: API.OperationMethod<GetOriginCaCertificateRequest, GetOriginCaCertificateResponse, GetOriginCaCertificateError, CloudflareOpContext>;
export type ListOriginCaCertificatesError = Forbidden | CloudflareOpError;
/** List all existing Origin CA certificates for a given zone. You can use an Origin CA Key as your User Service Key or an API token when calling this endpoint ([see above](#requests)). */
export declare const listOriginCaCertificates: API.PaginatedOperationMethod<ListOriginCaCertificatesRequest, ListOriginCaCertificatesResponse, ListOriginCaCertificatesError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=origin_ca_certificates.d.ts.map