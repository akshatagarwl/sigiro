import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetDmarcReportRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetDmarcReportRequest: S.Schema<GetDmarcReportRequest>;
export type DmarcReportsGetResponseApprovedSourcesItemIpsList = Array<string>;
export declare const DmarcReportsGetResponseApprovedSourcesItemIpsList: S.Schema<DmarcReportsGetResponseApprovedSourcesItemIpsList>;
export interface DmarcReportsGetResponseApprovedSourcesItem {
    /** Deprecated, use created_at */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** The source domain */
    domain?: string | null;
    /** Resolved IP addresses from SPF */
    ips?: DmarcReportsGetResponseApprovedSourcesItemIpsList | null;
    /** Deprecated, use modified_at */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Source name (typically same as domain) */
    name?: string | null;
    /** URL-friendly identifier */
    slug?: string | null;
    /** Source UUID */
    tag?: string | null;
}
export declare const DmarcReportsGetResponseApprovedSourcesItem: S.Schema<DmarcReportsGetResponseApprovedSourcesItem>;
export type DmarcReportsGetResponseApprovedSourcesList = Array<DmarcReportsGetResponseApprovedSourcesItem>;
export declare const DmarcReportsGetResponseApprovedSourcesList: S.Schema<DmarcReportsGetResponseApprovedSourcesList>;
export interface DmarcReportsGetResponseRecordsBimiRecordsItem {
    /** DNS record ID */
    id?: string | null;
    /** Record content */
    content?: string | null;
    /** DNS record name */
    name?: string | null;
    /** Time to live in seconds */
    ttl?: number | null;
    /** Record type */
    type?: string | null;
}
export declare const DmarcReportsGetResponseRecordsBimiRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsBimiRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsGetResponseRecordsBimiRecordsList: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsList>;
export type DmarcReportsGetResponseRecordsCnameDkimRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsGetResponseRecordsCnameDkimRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsCnameDkimRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsGetResponseRecordsCnameDkimRecordsList: S.Schema<DmarcReportsGetResponseRecordsCnameDkimRecordsList>;
export type DmarcReportsGetResponseRecordsCnameDmarcRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsGetResponseRecordsCnameDmarcRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsCnameDmarcRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsGetResponseRecordsCnameDmarcRecordsList: S.Schema<DmarcReportsGetResponseRecordsCnameDmarcRecordsList>;
export type DmarcReportsGetResponseRecordsCnameSpfRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsGetResponseRecordsCnameSpfRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsCnameSpfRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsGetResponseRecordsCnameSpfRecordsList: S.Schema<DmarcReportsGetResponseRecordsCnameSpfRecordsList>;
export type DmarcReportsGetResponseRecordsDkimRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsGetResponseRecordsDkimRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsDkimRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsGetResponseRecordsDkimRecordsList: S.Schema<DmarcReportsGetResponseRecordsDkimRecordsList>;
export type DmarcReportsGetResponseRecordsDmarcRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsGetResponseRecordsDmarcRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsDmarcRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsGetResponseRecordsDmarcRecordsList: S.Schema<DmarcReportsGetResponseRecordsDmarcRecordsList>;
export type DmarcReportsGetResponseRecordsSpfRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsGetResponseRecordsSpfRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsGetResponseRecordsSpfRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsGetResponseRecordsSpfRecordsList: S.Schema<DmarcReportsGetResponseRecordsSpfRecordsList>;
export interface DmarcReportsGetResponseRecords {
    /** BIMI TXT records */
    bimiRecords?: DmarcReportsGetResponseRecordsBimiRecordsList | null;
    /** CNAME records for DKIM */
    cnameDkimRecords?: DmarcReportsGetResponseRecordsCnameDkimRecordsList | null;
    /** CNAME records at _dmarc (problematic) */
    cnameDmarcRecords?: DmarcReportsGetResponseRecordsCnameDmarcRecordsList | null;
    /** CNAME records for SPF */
    cnameSpfRecords?: DmarcReportsGetResponseRecordsCnameSpfRecordsList | null;
    /** DKIM TXT records */
    dkimRecords?: DmarcReportsGetResponseRecordsDkimRecordsList | null;
    /** DMARC TXT records */
    dmarcRecords?: DmarcReportsGetResponseRecordsDmarcRecordsList | null;
    /** SPF TXT records */
    spfRecords?: DmarcReportsGetResponseRecordsSpfRecordsList | null;
}
export declare const DmarcReportsGetResponseRecords: S.Schema<DmarcReportsGetResponseRecords>;
export type DmarcReportsGetResponseStatus = "missing-dmarc-report" | "multiple-dmarc-reports" | "missing-dmarc-rua" | "cname-on-dmarc-record";
export declare const DmarcReportsGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDmarcReportResponse {
    /** List of approved sending sources (omitted when empty) */
    approvedSources?: DmarcReportsGetResponseApprovedSourcesList | null;
    /** Deprecated, use created_at */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** Whether DMARC reports are enabled */
    enabled?: boolean | null;
    /** Deprecated, use modified_at */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Live DNS records for the zone, grouped by type */
    records?: DmarcReportsGetResponseRecords | null;
    /** Prefix for DMARC RUA addresses (32-char hex string) */
    ruaPrefix?: string | null;
    /** Whether to skip the setup wizard */
    skipWizard?: boolean | null;
    /** DMARC configuration status */
    status?: DmarcReportsGetResponseStatus | null;
    /** Use `zone_id` instead */
    tag?: string | null;
    /** Zone identifier */
    zoneId?: string | null;
}
export declare const GetDmarcReportResponse: S.Schema<GetDmarcReportResponse>;
export interface GetSpfInspectRequest {
    /** Identifier. */
    zoneId: string;
    /** DNS record ID (rec_tag) to inspect */
    id: string;
}
export declare const GetSpfInspectRequest: S.Schema<GetSpfInspectRequest>;
export type SpfInspectGetResponseComponentsList = Array<unknown>;
export declare const SpfInspectGetResponseComponentsList: S.Schema<SpfInspectGetResponseComponentsList>;
export interface SpfInspectGetResponseErrorsItem {
    /** Error code. Known values: */
    code: string;
    /** Domain where the error occurred */
    domain: string;
    /** Human-readable error message */
    message: string;
    /** Additional error-specific details (optional). */
    details?: string | null;
}
export declare const SpfInspectGetResponseErrorsItem: S.Schema<SpfInspectGetResponseErrorsItem>;
export type SpfInspectGetResponseErrorsList = Array<SpfInspectGetResponseErrorsItem>;
export declare const SpfInspectGetResponseErrorsList: S.Schema<SpfInspectGetResponseErrorsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSpfInspectResponse {
    /** Parsed SPF components (mechanisms) */
    components: SpfInspectGetResponseComponentsList;
    /** Domain being inspected */
    domain: string;
    /** Raw SPF record content */
    record: string;
    /** Total number of DNS lookups performed across all includes */
    totalLookups: number;
    /** All errors encountered during inspection, collected from the entire tree. */
    errors?: SpfInspectGetResponseErrorsList | null;
}
export declare const GetSpfInspectResponse: S.Schema<GetSpfInspectResponse>;
export interface PatchDmarcReportRequest {
    /** Identifier. */
    zoneId: string;
    /** Enable or disable DMARC reports for this zone */
    enabled?: boolean;
    /** Skip the DMARC setup wizard */
    skipWizard?: boolean;
}
export declare const PatchDmarcReportRequest: S.Schema<PatchDmarcReportRequest>;
export type DmarcReportsEditResponseApprovedSourcesItemIpsList = Array<string>;
export declare const DmarcReportsEditResponseApprovedSourcesItemIpsList: S.Schema<DmarcReportsEditResponseApprovedSourcesItemIpsList>;
export interface DmarcReportsEditResponseApprovedSourcesItem {
    /** Deprecated, use created_at */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** The source domain */
    domain?: string | null;
    /** Resolved IP addresses from SPF */
    ips?: DmarcReportsEditResponseApprovedSourcesItemIpsList | null;
    /** Deprecated, use modified_at */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Source name (typically same as domain) */
    name?: string | null;
    /** URL-friendly identifier */
    slug?: string | null;
    /** Source UUID */
    tag?: string | null;
}
export declare const DmarcReportsEditResponseApprovedSourcesItem: S.Schema<DmarcReportsEditResponseApprovedSourcesItem>;
export type DmarcReportsEditResponseApprovedSourcesList = Array<DmarcReportsEditResponseApprovedSourcesItem>;
export declare const DmarcReportsEditResponseApprovedSourcesList: S.Schema<DmarcReportsEditResponseApprovedSourcesList>;
export type DmarcReportsEditResponseRecordsBimiRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsEditResponseRecordsBimiRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsBimiRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsEditResponseRecordsBimiRecordsList: S.Schema<DmarcReportsEditResponseRecordsBimiRecordsList>;
export type DmarcReportsEditResponseRecordsCnameDkimRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsEditResponseRecordsCnameDkimRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsCnameDkimRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsEditResponseRecordsCnameDkimRecordsList: S.Schema<DmarcReportsEditResponseRecordsCnameDkimRecordsList>;
export type DmarcReportsEditResponseRecordsCnameDmarcRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsEditResponseRecordsCnameDmarcRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsCnameDmarcRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsEditResponseRecordsCnameDmarcRecordsList: S.Schema<DmarcReportsEditResponseRecordsCnameDmarcRecordsList>;
export type DmarcReportsEditResponseRecordsCnameSpfRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsEditResponseRecordsCnameSpfRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsCnameSpfRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsEditResponseRecordsCnameSpfRecordsList: S.Schema<DmarcReportsEditResponseRecordsCnameSpfRecordsList>;
export type DmarcReportsEditResponseRecordsDkimRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsEditResponseRecordsDkimRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsDkimRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsEditResponseRecordsDkimRecordsList: S.Schema<DmarcReportsEditResponseRecordsDkimRecordsList>;
export type DmarcReportsEditResponseRecordsDmarcRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsEditResponseRecordsDmarcRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsDmarcRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsEditResponseRecordsDmarcRecordsList: S.Schema<DmarcReportsEditResponseRecordsDmarcRecordsList>;
export type DmarcReportsEditResponseRecordsSpfRecordsItem = DmarcReportsGetResponseRecordsBimiRecordsItem;
export declare const DmarcReportsEditResponseRecordsSpfRecordsItem: S.Schema<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export type DmarcReportsEditResponseRecordsSpfRecordsList = Array<DmarcReportsGetResponseRecordsBimiRecordsItem>;
export declare const DmarcReportsEditResponseRecordsSpfRecordsList: S.Schema<DmarcReportsEditResponseRecordsSpfRecordsList>;
export interface DmarcReportsEditResponseRecords {
    /** BIMI TXT records */
    bimiRecords?: DmarcReportsEditResponseRecordsBimiRecordsList | null;
    /** CNAME records for DKIM */
    cnameDkimRecords?: DmarcReportsEditResponseRecordsCnameDkimRecordsList | null;
    /** CNAME records at _dmarc (problematic) */
    cnameDmarcRecords?: DmarcReportsEditResponseRecordsCnameDmarcRecordsList | null;
    /** CNAME records for SPF */
    cnameSpfRecords?: DmarcReportsEditResponseRecordsCnameSpfRecordsList | null;
    /** DKIM TXT records */
    dkimRecords?: DmarcReportsEditResponseRecordsDkimRecordsList | null;
    /** DMARC TXT records */
    dmarcRecords?: DmarcReportsEditResponseRecordsDmarcRecordsList | null;
    /** SPF TXT records */
    spfRecords?: DmarcReportsEditResponseRecordsSpfRecordsList | null;
}
export declare const DmarcReportsEditResponseRecords: S.Schema<DmarcReportsEditResponseRecords>;
export type DmarcReportsEditResponseStatus = "missing-dmarc-report" | "multiple-dmarc-reports" | "missing-dmarc-rua" | "cname-on-dmarc-record";
export declare const DmarcReportsEditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDmarcReportResponse {
    /** List of approved sending sources (omitted when empty) */
    approvedSources?: DmarcReportsEditResponseApprovedSourcesList | null;
    /** Deprecated, use created_at */
    created?: string | null;
    /** Creation timestamp */
    createdAt?: string | null;
    /** Whether DMARC reports are enabled */
    enabled?: boolean | null;
    /** Deprecated, use modified_at */
    modified?: string | null;
    /** Last modification timestamp */
    modifiedAt?: string | null;
    /** Live DNS records for the zone, grouped by type */
    records?: DmarcReportsEditResponseRecords | null;
    /** Prefix for DMARC RUA addresses (32-char hex string) */
    ruaPrefix?: string | null;
    /** Whether to skip the setup wizard */
    skipWizard?: boolean | null;
    /** DMARC configuration status */
    status?: DmarcReportsEditResponseStatus | null;
    /** Use `zone_id` instead */
    tag?: string | null;
    /** Zone identifier */
    zoneId?: string | null;
}
export declare const PatchDmarcReportResponse: S.Schema<PatchDmarcReportResponse>;
export type GetDmarcReportError = CloudflareOpError;
/** Retrieves the current DMARC report configuration and status for a zone. Returns the RUA prefix, enabled status, approved sources, and DNS records. */
export declare const getDmarcReport: API.OperationMethod<GetDmarcReportRequest, GetDmarcReportResponse, GetDmarcReportError, CloudflareOpContext>;
export type GetSpfInspectError = CloudflareOpError;
/** Inspects a specific SPF TXT record and returns a parsed tree structure in the spflimit-worker format. The record ID must be provided via the `id` query parameter. Returns a recursive tree showing: - Parsed components with their qualifiers and types - Nested includes recursively resolved within components - Per-component and total lookup counts - Detailed error information with context */
export declare const getSpfInspect: API.OperationMethod<GetSpfInspectRequest, GetSpfInspectResponse, GetSpfInspectError, CloudflareOpContext>;
export type PatchDmarcReportError = CloudflareOpError;
/** Updates the DMARC report configuration for a zone. At least one of `enabled` or `skip_wizard` must be provided. When enabling, the handler will ensure the DMARC RUA record exists in DNS. */
export declare const patchDmarcReport: API.OperationMethod<PatchDmarcReportRequest, PatchDmarcReportResponse, PatchDmarcReportError, CloudflareOpContext>;
//# sourceMappingURL=email_auth.d.ts.map