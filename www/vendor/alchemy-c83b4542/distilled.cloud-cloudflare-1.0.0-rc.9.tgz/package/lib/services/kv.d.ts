import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import * as T from "../traits.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidExpirationTtl_base: S.Class<InvalidExpirationTtl, S.TaggedStruct<"InvalidExpirationTtl", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidExpirationTtl extends /*@__PURE__*/ InvalidExpirationTtl_base {
}
declare const InvalidObjectIdentifier_base: S.Class<InvalidObjectIdentifier, S.TaggedStruct<"InvalidObjectIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidObjectIdentifier extends /*@__PURE__*/ InvalidObjectIdentifier_base {
}
declare const InvalidRequestBody_base: S.Class<InvalidRequestBody, S.TaggedStruct<"InvalidRequestBody", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestBody extends /*@__PURE__*/ InvalidRequestBody_base {
}
declare const KeyNotFound_base: S.Class<KeyNotFound, S.TaggedStruct<"KeyNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class KeyNotFound extends /*@__PURE__*/ KeyNotFound_base {
}
declare const MethodNotAllowed_base: S.Class<MethodNotAllowed, S.TaggedStruct<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const MinimumKeysRequired_base: S.Class<MinimumKeysRequired, S.TaggedStruct<"MinimumKeysRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MinimumKeysRequired extends /*@__PURE__*/ MinimumKeysRequired_base {
}
declare const NamespaceNotFound_base: S.Class<NamespaceNotFound, S.TaggedStruct<"NamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
declare const NamespaceTitleAlreadyExists_base: S.Class<NamespaceTitleAlreadyExists, S.TaggedStruct<"NamespaceTitleAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NamespaceTitleAlreadyExists extends /*@__PURE__*/ NamespaceTitleAlreadyExists_base {
}
declare const TitleRequired_base: S.Class<TitleRequired, S.TaggedStruct<"TitleRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TitleRequired extends /*@__PURE__*/ TitleRequired_base {
}
export type NamespacesBulkDeleteRequestBodyList = Array<string>;
export declare const NamespacesBulkDeleteRequestBodyList: S.Schema<NamespacesBulkDeleteRequestBodyList>;
export interface BulkDeleteNamespacesRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    body: NamespacesBulkDeleteRequestBodyList;
}
export declare const BulkDeleteNamespacesRequest: S.Schema<BulkDeleteNamespacesRequest>;
export type NamespacesBulkDeleteResponseUnsuccessfulKeysList = Array<string>;
export declare const NamespacesBulkDeleteResponseUnsuccessfulKeysList: S.Schema<NamespacesBulkDeleteResponseUnsuccessfulKeysList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkDeleteNamespacesResponse {
    /** Number of keys successfully updated. */
    successfulKeyCount?: number | null;
    /** Name of the keys that failed to be fully updated. They should be retried. */
    unsuccessfulKeys?: NamespacesBulkDeleteResponseUnsuccessfulKeysList | null;
}
export declare const BulkDeleteNamespacesResponse: S.Schema<BulkDeleteNamespacesResponse>;
export type NamespacesBulkGetRequestKeysList = Array<string>;
export declare const NamespacesBulkGetRequestKeysList: S.Schema<NamespacesBulkGetRequestKeysList>;
export type NamespacesBulkGetRequestType = "text" | "json";
export declare const NamespacesBulkGetRequestType: any;
export interface BulkGetNamespacesRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** Array of keys to retrieve (maximum of 100). */
    keys: NamespacesBulkGetRequestKeysList;
    /** Whether to parse JSON values in the response. */
    type?: NamespacesBulkGetRequestType | (string & {});
    /** Whether to include metadata in the response. */
    withMetadata?: boolean;
}
export declare const BulkGetNamespacesRequest: S.Schema<BulkGetNamespacesRequest>;
export type NamespacesBulkGetResultWorkersKVBulkGetResultValuesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesBulkGetResultWorkersKVBulkGetResultValuesCase3Map: S.Schema<NamespacesBulkGetResultWorkersKVBulkGetResultValuesCase3Map>;
export type NamespacesBulkGetResultWorkersKVBulkGetResultValues = string | number | boolean | NamespacesBulkGetResultWorkersKVBulkGetResultValuesCase3Map;
export declare const NamespacesBulkGetResultWorkersKVBulkGetResultValues: any;
export interface NamespacesBulkGetResultWorkersKVBulkGetResult {
    /** Requested keys are paired with their values in an object. */
    values?: NamespacesBulkGetResultWorkersKVBulkGetResultValues | null;
}
export declare const NamespacesBulkGetResultWorkersKVBulkGetResult: S.Schema<NamespacesBulkGetResultWorkersKVBulkGetResult>;
export interface NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue {
    /** The metadata associated with the key. */
    metadata: unknown;
    /** The value associated with the key. */
    value: unknown;
    /** Expires the key at a certain time, measured in number of seconds since the UNIX epoch. */
    expiration?: number | null;
}
export declare const NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue: S.Schema<NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue>;
export type NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap = {
    [key: string]: NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue | undefined;
};
export declare const NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap: S.Schema<NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap>;
export interface NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadata {
    /** Requested keys are paired with their values and metadata in an object. */
    values?: NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap | null;
}
export declare const NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadata: S.Schema<NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadata>;
export type NamespacesBulkGetResult = NamespacesBulkGetResultWorkersKVBulkGetResult | NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadata;
export declare const NamespacesBulkGetResult: any;
export type BulkGetNamespacesResponse = NamespacesBulkGetResult;
export declare const BulkGetNamespacesResponse: S.Schema<BulkGetNamespacesResponse>;
export interface NamespacesBulkUpdateRequestBodyItem {
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. */
    key: string;
    /** A UTF-8 encoded string to be stored, up to 25 MiB in length. */
    value: string;
    /** Indicates whether or not the server should base64 decode the value before storing it. Useful for writing values that wouldn't otherwise be valid JSON strings, such as images. */
    base64?: boolean;
    /** Expires the key at a certain time, measured in number of seconds since the UNIX epoch. */
    expiration?: number;
    /** Expires the key after a number of seconds. Must be at least 60. */
    expirationTtl?: number;
    /** Arbitrary JSON that is associated with a key. */
    metadata?: unknown;
}
export declare const NamespacesBulkUpdateRequestBodyItem: S.Schema<NamespacesBulkUpdateRequestBodyItem>;
export type NamespacesBulkUpdateRequestBodyList = Array<NamespacesBulkUpdateRequestBodyItem>;
export declare const NamespacesBulkUpdateRequestBodyList: S.Schema<NamespacesBulkUpdateRequestBodyList>;
export interface BulkPutNamespacesRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    body: NamespacesBulkUpdateRequestBodyList;
}
export declare const BulkPutNamespacesRequest: S.Schema<BulkPutNamespacesRequest>;
export type NamespacesBulkUpdateResponseUnsuccessfulKeysList = Array<string>;
export declare const NamespacesBulkUpdateResponseUnsuccessfulKeysList: S.Schema<NamespacesBulkUpdateResponseUnsuccessfulKeysList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPutNamespacesResponse {
    /** Number of keys successfully updated. */
    successfulKeyCount?: number | null;
    /** Name of the keys that failed to be fully updated. They should be retried. */
    unsuccessfulKeys?: NamespacesBulkUpdateResponseUnsuccessfulKeysList | null;
}
export declare const BulkPutNamespacesResponse: S.Schema<BulkPutNamespacesResponse>;
export interface CreateNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** A human-readable string name for a Namespace. */
    title: string;
}
export declare const CreateNamespaceRequest: S.Schema<CreateNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateNamespaceResponse {
    /** Namespace identifier tag. */
    id: string;
    /** A human-readable string name for a Namespace. */
    title: string;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export declare const CreateNamespaceResponse: S.Schema<CreateNamespaceResponse>;
export interface DeleteNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
}
export declare const DeleteNamespaceRequest: S.Schema<DeleteNamespaceRequest>;
export interface DeleteNamespaceResponse {
}
export declare const DeleteNamespaceResponse: S.Schema<DeleteNamespaceResponse>;
export interface DeleteNamespaceValueRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
}
export declare const DeleteNamespaceValueRequest: S.Schema<DeleteNamespaceValueRequest>;
export interface DeleteNamespaceValueResponse {
}
export declare const DeleteNamespaceValueResponse: S.Schema<DeleteNamespaceValueResponse>;
export interface GetNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
}
export declare const GetNamespaceRequest: S.Schema<GetNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetNamespaceResponse {
    /** Namespace identifier tag. */
    id: string;
    /** A human-readable string name for a Namespace. */
    title: string;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export declare const GetNamespaceResponse: S.Schema<GetNamespaceResponse>;
export interface GetNamespaceMetadataRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
}
export declare const GetNamespaceMetadataRequest: S.Schema<GetNamespaceMetadataRequest>;
export type GetNamespaceMetadataResponse = unknown;
export declare const GetNamespaceMetadataResponse: S.Schema<GetNamespaceMetadataResponse>;
export interface GetNamespaceValueRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
}
export declare const GetNamespaceValueRequest: S.Schema<GetNamespaceValueRequest>;
export interface GetNamespaceValueResponse {
    /** Raw value body as an Effect Stream. */
    body: T.BinaryResponseBody;
    /** Expiration time of the KV pair, seconds since the UNIX epoch (set when the pair is set to expire). */
    expiration?: number;
    /** MIME type the value was stored with. */
    contentType?: string;
}
export declare const GetNamespaceValueResponse: S.Schema<GetNamespaceValueResponse>;
export interface ListNamespaceKeysRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** Opaque token indicating the position from which to continue when requesting the next set of records if the amount of list results was limited by the limit parameter. A valid value for the cursor can be obtained from the `cursors` object in the `result_info` structure. */
    cursor?: string;
    /** Limits the number of keys returned in the response. The cursor attribute may be used to iterate over the next batch of keys if there are more than the limit. */
    limit?: number;
    /** Filters returned keys by a name prefix. Exact matches and any key names that begin with the prefix will be returned. */
    prefix?: string;
}
export declare const ListNamespaceKeysRequest: S.Schema<ListNamespaceKeysRequest>;
export interface NamespacesKeysListResultItem {
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    name: string;
    /** The time, measured in number of seconds since the UNIX epoch, at which the key will expire. This property is omitted for keys that will not expire. */
    expiration?: number | null;
    /** Arbitrary JSON that is associated with a key. */
    metadata?: unknown | null;
}
export declare const NamespacesKeysListResultItem: S.Schema<NamespacesKeysListResultItem>;
export type NamespacesKeysListResultList = Array<NamespacesKeysListResultItem>;
export declare const NamespacesKeysListResultList: S.Schema<NamespacesKeysListResultList>;
export interface ListNamespaceKeysResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesKeysListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespaceKeysResponse: S.Schema<ListNamespaceKeysResponse>;
export type NamespacesListRequestDirection = "asc" | "desc";
export declare const NamespacesListRequestDirection: any;
export type NamespacesListRequestOrder = "id" | "title";
export declare const NamespacesListRequestOrder: any;
export interface ListNamespacesRequest {
    /** Identifier. */
    accountId: string;
    /** Direction to order namespaces. */
    direction?: NamespacesListRequestDirection | (string & {});
    /** Field to order results by. */
    order?: NamespacesListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListNamespacesRequest: S.Schema<ListNamespacesRequest>;
export interface NamespacesListResultItem {
    /** Namespace identifier tag. */
    id: string;
    /** A human-readable string name for a Namespace. */
    title: string;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export declare const NamespacesListResultItem: S.Schema<NamespacesListResultItem>;
export type NamespacesListResultList = Array<NamespacesListResultItem>;
export declare const NamespacesListResultList: S.Schema<NamespacesListResultList>;
export interface ListNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespacesResponse: S.Schema<ListNamespacesResponse>;
export type NamespacesKeysBulkDeleteRequestBodyList = Array<string>;
export declare const NamespacesKeysBulkDeleteRequestBodyList: S.Schema<NamespacesKeysBulkDeleteRequestBodyList>;
export interface NamespacesKeysBulkDeleteRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    body: NamespacesKeysBulkDeleteRequestBodyList;
}
export declare const NamespacesKeysBulkDeleteRequest: S.Schema<NamespacesKeysBulkDeleteRequest>;
export type NamespacesKeysBulkDeleteResponseUnsuccessfulKeysList = Array<string>;
export declare const NamespacesKeysBulkDeleteResponseUnsuccessfulKeysList: S.Schema<NamespacesKeysBulkDeleteResponseUnsuccessfulKeysList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface NamespacesKeysBulkDeleteResponse {
    /** Number of keys successfully updated. */
    successfulKeyCount?: number | null;
    /** Name of the keys that failed to be fully updated. They should be retried. */
    unsuccessfulKeys?: NamespacesKeysBulkDeleteResponseUnsuccessfulKeysList | null;
}
export declare const NamespacesKeysBulkDeleteResponse: S.Schema<NamespacesKeysBulkDeleteResponse>;
export type NamespacesKeysBulkGetRequestKeysList = Array<string>;
export declare const NamespacesKeysBulkGetRequestKeysList: S.Schema<NamespacesKeysBulkGetRequestKeysList>;
export type NamespacesKeysBulkGetRequestType = "text" | "json";
export declare const NamespacesKeysBulkGetRequestType: any;
export interface NamespacesKeysBulkGetRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** Array of keys to retrieve (maximum of 100). */
    keys: NamespacesKeysBulkGetRequestKeysList;
    /** Whether to parse JSON values in the response. */
    type?: NamespacesKeysBulkGetRequestType | (string & {});
    /** Whether to include metadata in the response. */
    withMetadata?: boolean;
}
export declare const NamespacesKeysBulkGetRequest: S.Schema<NamespacesKeysBulkGetRequest>;
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultValuesCase3Map = {
    [key: string]: unknown | undefined;
};
export declare const NamespacesKeysBulkGetResultWorkersKVBulkGetResultValuesCase3Map: S.Schema<NamespacesKeysBulkGetResultWorkersKVBulkGetResultValuesCase3Map>;
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultValues = string | number | boolean | NamespacesKeysBulkGetResultWorkersKVBulkGetResultValuesCase3Map;
export declare const NamespacesKeysBulkGetResultWorkersKVBulkGetResultValues: any;
export interface NamespacesKeysBulkGetResultWorkersKVBulkGetResult {
    /** Requested keys are paired with their values in an object. */
    values?: NamespacesKeysBulkGetResultWorkersKVBulkGetResultValues | null;
}
export declare const NamespacesKeysBulkGetResultWorkersKVBulkGetResult: S.Schema<NamespacesKeysBulkGetResultWorkersKVBulkGetResult>;
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue = NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue;
export declare const NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue: S.Schema<NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue>;
export type NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap = {
    [key: string]: NamespacesBulkGetResultWorkersKVBulkGetResultWithMetadataValuesValue | undefined;
};
export declare const NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap: S.Schema<NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap>;
export interface NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadata {
    /** Requested keys are paired with their values and metadata in an object. */
    values?: NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadataValuesMap | null;
}
export declare const NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadata: S.Schema<NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadata>;
export type NamespacesKeysBulkGetResult = NamespacesKeysBulkGetResultWorkersKVBulkGetResult | NamespacesKeysBulkGetResultWorkersKVBulkGetResultWithMetadata;
export declare const NamespacesKeysBulkGetResult: any;
export type NamespacesKeysBulkGetResponse = NamespacesKeysBulkGetResult;
export declare const NamespacesKeysBulkGetResponse: S.Schema<NamespacesKeysBulkGetResponse>;
export type NamespacesKeysBulkUpdateRequestBodyItem = NamespacesBulkUpdateRequestBodyItem;
export declare const NamespacesKeysBulkUpdateRequestBodyItem: S.Schema<NamespacesBulkUpdateRequestBodyItem>;
export type NamespacesKeysBulkUpdateRequestBodyList = Array<NamespacesBulkUpdateRequestBodyItem>;
export declare const NamespacesKeysBulkUpdateRequestBodyList: S.Schema<NamespacesKeysBulkUpdateRequestBodyList>;
export interface NamespacesKeysBulkUpdateRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    body: NamespacesKeysBulkUpdateRequestBodyList;
}
export declare const NamespacesKeysBulkUpdateRequest: S.Schema<NamespacesKeysBulkUpdateRequest>;
export type NamespacesKeysBulkUpdateResponseUnsuccessfulKeysList = Array<string>;
export declare const NamespacesKeysBulkUpdateResponseUnsuccessfulKeysList: S.Schema<NamespacesKeysBulkUpdateResponseUnsuccessfulKeysList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface NamespacesKeysBulkUpdateResponse {
    /** Number of keys successfully updated. */
    successfulKeyCount?: number | null;
    /** Name of the keys that failed to be fully updated. They should be retried. */
    unsuccessfulKeys?: NamespacesKeysBulkUpdateResponseUnsuccessfulKeysList | null;
}
export declare const NamespacesKeysBulkUpdateResponse: S.Schema<NamespacesKeysBulkUpdateResponse>;
export interface PutNamespaceValueRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** A key's name. The name may be at most 512 bytes. All printable, non-whitespace characters are valid. Use percent-encoding to define key names as part of a URL. */
    keyName: string;
    /** Expires the key at a certain time, measured in number of seconds since the UNIX epoch. */
    expiration?: number;
    /** Expires the key after a number of seconds. Must be at least 60. */
    expirationTtl?: number;
    /** A byte sequence to be stored, up to 25 MiB in length. */
    value: string | File | Blob;
    /** Associates arbitrary JSON data with a key/value pair. */
    metadata?: unknown;
}
export declare const PutNamespaceValueRequest: S.Schema<PutNamespaceValueRequest>;
export interface PutNamespaceValueResponse {
}
export declare const PutNamespaceValueResponse: S.Schema<PutNamespaceValueResponse>;
export interface UpdateNamespaceRequest {
    /** Identifier. */
    accountId: string;
    /** Namespace identifier tag. */
    namespaceId: string;
    /** A human-readable string name for a Namespace. */
    title: string;
}
export declare const UpdateNamespaceRequest: S.Schema<UpdateNamespaceRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateNamespaceResponse {
    /** Namespace identifier tag. */
    id: string;
    /** A human-readable string name for a Namespace. */
    title: string;
    /** True if keys written on the URL will be URL-decoded before storing. For example, if set to "true", a key written on the URL as "%3F" will be stored as "?". */
    supportsUrlEncoding?: boolean | null;
}
export declare const UpdateNamespaceResponse: S.Schema<UpdateNamespaceResponse>;
export type BulkDeleteNamespacesError = NamespaceNotFound | InvalidRequestBody | InvalidObjectIdentifier | CloudflareOpError;
/** Remove multiple KV pairs from the namespace. Body should be an array of up to 10,000 keys to be removed. */
export declare const bulkDeleteNamespaces: API.OperationMethod<BulkDeleteNamespacesRequest, BulkDeleteNamespacesResponse, BulkDeleteNamespacesError, CloudflareOpContext>;
export type BulkGetNamespacesError = InvalidRequestBody | MinimumKeysRequired | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Retrieve up to 100 KV pairs from the namespace. Keys must contain text-based values. JSON values can optionally be parsed instead of being returned as a string value. Metadata can be included if `withMetadata` is true. */
export declare const bulkGetNamespaces: API.OperationMethod<BulkGetNamespacesRequest, BulkGetNamespacesResponse, BulkGetNamespacesError, CloudflareOpContext>;
export type BulkPutNamespacesError = InvalidRequestBody | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Write multiple keys and values at once. Body should be an array of up to 10,000 key-value pairs to be stored, along with optional expiration information. Existing values and expirations will be overwritten. If neither `expiration` nor `expiration_ttl` is specified, the key-value pair will never expire. If both are set, `expiration_ttl` is used and `expiration` is ignored. The entire request size must be 100 megabytes or less. */
export declare const bulkPutNamespaces: API.OperationMethod<BulkPutNamespacesRequest, BulkPutNamespacesResponse, BulkPutNamespacesError, CloudflareOpContext>;
export type CreateNamespaceError = TitleRequired | InvalidObjectIdentifier | NamespaceTitleAlreadyExists | CloudflareOpError;
/** Creates a namespace under the given title. A `400` is returned if the account already owns a namespace with this title. A namespace must be explicitly deleted to be replaced. */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest, CreateNamespaceResponse, CreateNamespaceError, CloudflareOpContext>;
export type DeleteNamespaceError = MethodNotAllowed | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Deletes the namespace corresponding to the given ID. */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest, DeleteNamespaceResponse, DeleteNamespaceError, CloudflareOpContext>;
export type DeleteNamespaceValueError = NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Remove a KV pair from the namespace. Use URL-encoding to use special characters (for example, `:`, `!`, `%`) in the key name. */
export declare const deleteNamespaceValue: API.OperationMethod<DeleteNamespaceValueRequest, DeleteNamespaceValueResponse, DeleteNamespaceValueError, CloudflareOpContext>;
export type GetNamespaceError = NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Get the namespace corresponding to the given ID. */
export declare const getNamespace: API.OperationMethod<GetNamespaceRequest, GetNamespaceResponse, GetNamespaceError, CloudflareOpContext>;
export type GetNamespaceMetadataError = KeyNotFound | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Returns the metadata associated with the given key in the given namespace. Use URL-encoding to use special characters (for example, `:`, `!`, `%`) in the key name. */
export declare const getNamespaceMetadata: API.OperationMethod<GetNamespaceMetadataRequest, GetNamespaceMetadataResponse, GetNamespaceMetadataError, CloudflareOpContext>;
export type GetNamespaceValueError = KeyNotFound | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Returns the value associated with the given key in the given namespace. Use URL-encoding to use special characters (for example, `:`, `!`, `%`) in the key name. If the KV-pair is set to expire at some point, the expiration time as measured in seconds since the UNIX epoch will be returned in the `expiration` response header. */
export declare const getNamespaceValue: API.OperationMethod<GetNamespaceValueRequest, GetNamespaceValueResponse, GetNamespaceValueError, CloudflareOpContext>;
export type ListNamespaceKeysError = CloudflareOpError;
/** Lists a namespace's keys. */
export declare const listNamespaceKeys: API.PaginatedOperationMethod<ListNamespaceKeysRequest, ListNamespaceKeysResponse, ListNamespaceKeysError, CloudflareOpContext, NamespacesKeysListResultItem>;
export type ListNamespacesError = CloudflareOpError;
/** Returns the namespaces owned by an account. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext, NamespacesListResultItem>;
export type NamespacesKeysBulkDeleteError = NamespaceNotFound | InvalidRequestBody | InvalidObjectIdentifier | CloudflareOpError;
/** Remove multiple KV pairs from the namespace. Body should be an array of up to 10,000 keys to be removed. */
export declare const namespacesKeysBulkDelete: API.OperationMethod<NamespacesKeysBulkDeleteRequest, NamespacesKeysBulkDeleteResponse, NamespacesKeysBulkDeleteError, CloudflareOpContext>;
export type NamespacesKeysBulkGetError = InvalidRequestBody | MinimumKeysRequired | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Retrieve up to 100 KV pairs from the namespace. Keys must contain text-based values. JSON values can optionally be parsed instead of being returned as a string value. Metadata can be included if `withMetadata` is true. */
export declare const namespacesKeysBulkGet: API.OperationMethod<NamespacesKeysBulkGetRequest, NamespacesKeysBulkGetResponse, NamespacesKeysBulkGetError, CloudflareOpContext>;
export type NamespacesKeysBulkUpdateError = InvalidRequestBody | NamespaceNotFound | InvalidObjectIdentifier | CloudflareOpError;
/** Write multiple keys and values at once. Body should be an array of up to 10,000 key-value pairs to be stored, along with optional expiration information. Existing values and expirations will be overwritten. If neither `expiration` nor `expiration_ttl` is specified, the key-value pair will never expire. If both are set, `expiration_ttl` is used and `expiration` is ignored. The entire request size must be 100 megabytes or less. */
export declare const namespacesKeysBulkUpdate: API.OperationMethod<NamespacesKeysBulkUpdateRequest, NamespacesKeysBulkUpdateResponse, NamespacesKeysBulkUpdateError, CloudflareOpContext>;
export type PutNamespaceValueError = NamespaceNotFound | InvalidObjectIdentifier | InvalidExpirationTtl | CloudflareOpError;
/** Write a value identified by a key. Use URL-encoding to use special characters (for example, `:`, `!`, `%`) in the key name. Body should be the value to be stored. If JSON metadata to be associated with the key/value pair is needed, use `multipart/form-data` content type for your PUT request (see dropdown below in `REQUEST BODY SCHEMA`). Existing values, expirations, and metadata will be overwritten. If neither `expiration` nor `expiration_ttl` is specified, the key-value pair will never expire. If both are set, `expiration_ttl` is used and `expiration` is ignored. */
export declare const putNamespaceValue: API.OperationMethod<PutNamespaceValueRequest, PutNamespaceValueResponse, PutNamespaceValueError, CloudflareOpContext>;
export type UpdateNamespaceError = NamespaceNotFound | TitleRequired | InvalidObjectIdentifier | NamespaceTitleAlreadyExists | CloudflareOpError;
/** Modifies a namespace's title. */
export declare const updateNamespace: API.OperationMethod<UpdateNamespaceRequest, UpdateNamespaceResponse, UpdateNamespaceError, CloudflareOpContext>;
export declare const bulkDeleteNamespaceKeys: API.OperationMethod<BulkDeleteNamespacesRequest, BulkDeleteNamespacesResponse, BulkDeleteNamespacesError, CloudflareOpContext>;
export type BulkDeleteNamespaceKeysRequest = BulkDeleteNamespacesRequest;
export type BulkDeleteNamespaceKeysResponse = BulkDeleteNamespacesResponse;
export type BulkDeleteNamespaceKeysError = BulkDeleteNamespacesError;
export declare const bulkGetNamespaceKeys: API.OperationMethod<BulkGetNamespacesRequest, NamespacesBulkGetResult, BulkGetNamespacesError, CloudflareOpContext>;
export type BulkGetNamespaceKeysRequest = BulkGetNamespacesRequest;
export type BulkGetNamespaceKeysResponse = BulkGetNamespacesResponse;
export type BulkGetNamespaceKeysError = BulkGetNamespacesError;
export declare const bulkPutNamespaceKeys: API.OperationMethod<BulkPutNamespacesRequest, BulkPutNamespacesResponse, BulkPutNamespacesError, CloudflareOpContext>;
export type BulkPutNamespaceKeysRequest = BulkPutNamespacesRequest;
export type BulkPutNamespaceKeysResponse = BulkPutNamespacesResponse;
export type BulkPutNamespaceKeysError = BulkPutNamespacesError;
//# sourceMappingURL=kv.d.ts.map