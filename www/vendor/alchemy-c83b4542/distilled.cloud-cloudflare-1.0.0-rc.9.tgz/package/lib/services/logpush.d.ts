import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const JobNotFound_base: S.Class<JobNotFound, S.TaggedStruct<"JobNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class JobNotFound extends /*@__PURE__*/ JobNotFound_base {
}
declare const NotFound_base: S.Class<NotFound, S.TaggedStruct<"NotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NotFound extends /*@__PURE__*/ NotFound_base {
}
export interface CreateEdgeRequest {
    /** Identifier. */
    zoneId: string;
    /** Comma-separated list of fields. */
    fields?: string;
    /** Filters to drill down into specific events. */
    filter?: string;
    /** The sample parameter is the sample rate of the records set by the client: "sample": 1 is 100% of records "sample": 10 is 10% and so on. */
    sample?: number;
}
export declare const CreateEdgeRequest: S.Schema<CreateEdgeRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateEdgeResponse {
    /** Unique WebSocket address that will receive messages from Cloudflare’s edge. */
    destinationConf?: string | null;
    /** Comma-separated list of fields. */
    fields?: string | null;
    /** Filters to drill down into specific events. */
    filter?: string | null;
    /** The sample parameter is the sample rate of the records set by the client: "sample": 1 is 100% of records "sample": 10 is 10% and so on. */
    sample?: number | null;
    /** Unique session id of the job. */
    sessionId?: string | null;
}
export declare const CreateEdgeResponse: S.Schema<CreateEdgeResponse>;
export type JobsCreateRequestDataset = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const JobsCreateRequestDataset: any;
export type JobsCreateRequestFrequency = "high" | "low";
export declare const JobsCreateRequestFrequency: any;
export type JobsCreateRequestKind = "" | "edge";
export declare const JobsCreateRequestKind: any;
export type JobsCreateRequestOutputOptionsFieldNamesList = Array<string>;
export declare const JobsCreateRequestOutputOptionsFieldNamesList: S.Schema<JobsCreateRequestOutputOptionsFieldNamesList>;
export type JobsCreateRequestOutputOptionsOutputType = "ndjson" | "csv";
export declare const JobsCreateRequestOutputOptionsOutputType: any;
export type JobsCreateRequestOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export declare const JobsCreateRequestOutputOptionsTimestampFormat: any;
export interface JobsCreateRequestOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string;
    /** String to be appended after each batch. */
    batchSuffix?: string;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsCreateRequestOutputOptionsFieldNamesList;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsCreateRequestOutputOptionsOutputType | (string & {});
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string;
    /** String to be prepended before each record. */
    recordPrefix?: string;
    /** String to be appended after each record. */
    recordSuffix?: string;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string;
    /** Floating number to specify sampling rate. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsCreateRequestOutputOptionsTimestampFormat | (string & {});
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean;
}
export declare const JobsCreateRequestOutputOptions: S.Schema<JobsCreateRequestOutputOptions>;
export interface CreateJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsCreateRequestDataset | (string & {});
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsCreateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsCreateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsCreateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export declare const CreateJobForAccountRequest: S.Schema<CreateJobForAccountRequest>;
export type JobsCreateResponseDataset = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const JobsCreateResponseDataset: any;
export type JobsCreateResponseFrequency = "high" | "low";
export declare const JobsCreateResponseFrequency: any;
export type JobsCreateResponseKind = "" | "edge";
export declare const JobsCreateResponseKind: any;
export type JobsCreateResponseOutputOptionsFieldNamesList = Array<string>;
export declare const JobsCreateResponseOutputOptionsFieldNamesList: S.Schema<JobsCreateResponseOutputOptionsFieldNamesList>;
export type JobsCreateResponseOutputOptionsOutputType = "ndjson" | "csv";
export declare const JobsCreateResponseOutputOptionsOutputType: any;
export type JobsCreateResponseOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export declare const JobsCreateResponseOutputOptionsTimestampFormat: any;
export interface JobsCreateResponseOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsCreateResponseOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsCreateResponseOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Floating number to specify sampling rate. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsCreateResponseOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
export declare const JobsCreateResponseOutputOptions: S.Schema<JobsCreateResponseOutputOptions>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateJobResponse {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsCreateResponseDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsCreateResponseFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsCreateResponseKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsCreateResponseOutputOptions | null;
}
export declare const CreateJobResponse: S.Schema<CreateJobResponse>;
export interface CreateJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsCreateRequestDataset | (string & {});
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsCreateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsCreateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsCreateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export declare const CreateJobForZoneRequest: S.Schema<CreateJobForZoneRequest>;
export interface CreateOwnershipForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export declare const CreateOwnershipForAccountRequest: S.Schema<CreateOwnershipForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOwnershipResponse {
    filename?: string | null;
    message?: string | null;
    valid?: boolean | null;
}
export declare const CreateOwnershipResponse: S.Schema<CreateOwnershipResponse>;
export interface CreateOwnershipForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export declare const CreateOwnershipForZoneRequest: S.Schema<CreateOwnershipForZoneRequest>;
export interface DeleteJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique id of the job. */
    jobId: number;
}
export declare const DeleteJobForAccountRequest: S.Schema<DeleteJobForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteJobResponse {
    /** Unique id of the job. */
    id?: number | null;
}
export declare const DeleteJobResponse: S.Schema<DeleteJobResponse>;
export interface DeleteJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique id of the job. */
    jobId: number;
}
export declare const DeleteJobForZoneRequest: S.Schema<DeleteJobForZoneRequest>;
export interface DestinationExistsValidateForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export declare const DestinationExistsValidateForAccountRequest: S.Schema<DestinationExistsValidateForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DestinationExistsValidateResponse {
    exists?: boolean | null;
}
export declare const DestinationExistsValidateResponse: S.Schema<DestinationExistsValidateResponse>;
export interface DestinationExistsValidateForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export declare const DestinationExistsValidateForZoneRequest: S.Schema<DestinationExistsValidateForZoneRequest>;
export interface DestinationValidateForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export declare const DestinationValidateForAccountRequest: S.Schema<DestinationValidateForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DestinationValidateResponse {
    message?: string | null;
    valid?: boolean | null;
}
export declare const DestinationValidateResponse: S.Schema<DestinationValidateResponse>;
export interface DestinationValidateForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
}
export declare const DestinationValidateForZoneRequest: S.Schema<DestinationValidateForZoneRequest>;
export type DatasetsFieldsGetRequestDatasetId = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const DatasetsFieldsGetRequestDatasetId: any;
export interface GetDatasetFieldForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsFieldsGetRequestDatasetId | (string & {});
}
export declare const GetDatasetFieldForAccountRequest: S.Schema<GetDatasetFieldForAccountRequest>;
export type GetDatasetFieldResponse = unknown;
export declare const GetDatasetFieldResponse: S.Schema<GetDatasetFieldResponse>;
export interface GetDatasetFieldForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsFieldsGetRequestDatasetId | (string & {});
}
export declare const GetDatasetFieldForZoneRequest: S.Schema<GetDatasetFieldForZoneRequest>;
export type DatasetsJobsGetRequestDatasetId = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const DatasetsJobsGetRequestDatasetId: any;
export interface GetDatasetJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsJobsGetRequestDatasetId | (string & {});
}
export declare const GetDatasetJobForAccountRequest: S.Schema<GetDatasetJobForAccountRequest>;
export type DatasetsJobsGetResultItemDataset = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const DatasetsJobsGetResultItemDataset: any;
export type DatasetsJobsGetResultItemFrequency = "high" | "low";
export declare const DatasetsJobsGetResultItemFrequency: any;
export type DatasetsJobsGetResultItemKind = "" | "edge";
export declare const DatasetsJobsGetResultItemKind: any;
export type DatasetsJobsGetResultItemOutputOptionsFieldNamesList = Array<string>;
export declare const DatasetsJobsGetResultItemOutputOptionsFieldNamesList: S.Schema<DatasetsJobsGetResultItemOutputOptionsFieldNamesList>;
export type DatasetsJobsGetResultItemOutputOptionsOutputType = "ndjson" | "csv";
export declare const DatasetsJobsGetResultItemOutputOptionsOutputType: any;
export type DatasetsJobsGetResultItemOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export declare const DatasetsJobsGetResultItemOutputOptionsTimestampFormat: any;
export interface DatasetsJobsGetResultItemOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: DatasetsJobsGetResultItemOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: DatasetsJobsGetResultItemOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Floating number to specify sampling rate. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: DatasetsJobsGetResultItemOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
export declare const DatasetsJobsGetResultItemOutputOptions: S.Schema<DatasetsJobsGetResultItemOutputOptions>;
export interface DatasetsJobsGetResultItem {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: DatasetsJobsGetResultItemDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: DatasetsJobsGetResultItemFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: DatasetsJobsGetResultItemKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: DatasetsJobsGetResultItemOutputOptions | null;
}
export declare const DatasetsJobsGetResultItem: S.Schema<DatasetsJobsGetResultItem>;
export type DatasetsJobsGetResultList = Array<DatasetsJobsGetResultItem>;
export declare const DatasetsJobsGetResultList: S.Schema<DatasetsJobsGetResultList>;
export interface GetDatasetJobResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DatasetsJobsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetDatasetJobResponse: S.Schema<GetDatasetJobResponse>;
export interface GetDatasetJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    datasetId: DatasetsJobsGetRequestDatasetId | (string & {});
}
export declare const GetDatasetJobForZoneRequest: S.Schema<GetDatasetJobForZoneRequest>;
export interface GetEdgeRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetEdgeRequest: S.Schema<GetEdgeRequest>;
export interface EdgeGetResultItem {
    /** Unique WebSocket address that will receive messages from Cloudflare’s edge. */
    destinationConf?: string | null;
    /** Comma-separated list of fields. */
    fields?: string | null;
    /** Filters to drill down into specific events. */
    filter?: string | null;
    /** The sample parameter is the sample rate of the records set by the client: "sample": 1 is 100% of records "sample": 10 is 10% and so on. */
    sample?: number | null;
    /** Unique session id of the job. */
    sessionId?: string | null;
}
export declare const EdgeGetResultItem: S.Schema<EdgeGetResultItem>;
export type EdgeGetResultList = Array<EdgeGetResultItem>;
export declare const EdgeGetResultList: S.Schema<EdgeGetResultList>;
export interface GetEdgeResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: EdgeGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetEdgeResponse: S.Schema<GetEdgeResponse>;
export interface GetJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique id of the job. */
    jobId: number;
}
export declare const GetJobForAccountRequest: S.Schema<GetJobForAccountRequest>;
export type JobsGetResponseDataset = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const JobsGetResponseDataset: any;
export type JobsGetResponseFrequency = "high" | "low";
export declare const JobsGetResponseFrequency: any;
export type JobsGetResponseKind = "" | "edge";
export declare const JobsGetResponseKind: any;
export type JobsGetResponseOutputOptionsFieldNamesList = Array<string>;
export declare const JobsGetResponseOutputOptionsFieldNamesList: S.Schema<JobsGetResponseOutputOptionsFieldNamesList>;
export type JobsGetResponseOutputOptionsOutputType = "ndjson" | "csv";
export declare const JobsGetResponseOutputOptionsOutputType: any;
export type JobsGetResponseOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export declare const JobsGetResponseOutputOptionsTimestampFormat: any;
export interface JobsGetResponseOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsGetResponseOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsGetResponseOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Floating number to specify sampling rate. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsGetResponseOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
export declare const JobsGetResponseOutputOptions: S.Schema<JobsGetResponseOutputOptions>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetJobResponse {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsGetResponseDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsGetResponseFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsGetResponseKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsGetResponseOutputOptions | null;
}
export declare const GetJobResponse: S.Schema<GetJobResponse>;
export interface GetJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique id of the job. */
    jobId: number;
}
export declare const GetJobForZoneRequest: S.Schema<GetJobForZoneRequest>;
export interface ListJobsForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export declare const ListJobsForAccountRequest: S.Schema<ListJobsForAccountRequest>;
export type JobsListResultItemDataset = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const JobsListResultItemDataset: any;
export type JobsListResultItemFrequency = "high" | "low";
export declare const JobsListResultItemFrequency: any;
export type JobsListResultItemKind = "" | "edge";
export declare const JobsListResultItemKind: any;
export type JobsListResultItemOutputOptionsFieldNamesList = Array<string>;
export declare const JobsListResultItemOutputOptionsFieldNamesList: S.Schema<JobsListResultItemOutputOptionsFieldNamesList>;
export type JobsListResultItemOutputOptionsOutputType = "ndjson" | "csv";
export declare const JobsListResultItemOutputOptionsOutputType: any;
export type JobsListResultItemOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export declare const JobsListResultItemOutputOptionsTimestampFormat: any;
export interface JobsListResultItemOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsListResultItemOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsListResultItemOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Floating number to specify sampling rate. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsListResultItemOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
export declare const JobsListResultItemOutputOptions: S.Schema<JobsListResultItemOutputOptions>;
export interface JobsListResultItem {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsListResultItemDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsListResultItemFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsListResultItemKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsListResultItemOutputOptions | null;
}
export declare const JobsListResultItem: S.Schema<JobsListResultItem>;
export type JobsListResultList = Array<JobsListResultItem>;
export declare const JobsListResultList: S.Schema<JobsListResultList>;
export interface ListJobsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: JobsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListJobsResponse: S.Schema<ListJobsResponse>;
export interface ListJobsForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
}
export declare const ListJobsForZoneRequest: S.Schema<ListJobsForZoneRequest>;
export interface OriginValidateForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions: string;
}
export declare const OriginValidateForAccountRequest: S.Schema<OriginValidateForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface OriginValidateResponse {
    message?: string | null;
    valid?: boolean | null;
}
export declare const OriginValidateResponse: S.Schema<OriginValidateResponse>;
export interface OriginValidateForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions: string;
}
export declare const OriginValidateForZoneRequest: S.Schema<OriginValidateForZoneRequest>;
export type JobsUpdateRequestFrequency = "high" | "low";
export declare const JobsUpdateRequestFrequency: any;
export type JobsUpdateRequestKind = "" | "edge";
export declare const JobsUpdateRequestKind: any;
export type JobsUpdateRequestOutputOptionsFieldNamesList = Array<string>;
export declare const JobsUpdateRequestOutputOptionsFieldNamesList: S.Schema<JobsUpdateRequestOutputOptionsFieldNamesList>;
export type JobsUpdateRequestOutputOptionsOutputType = "ndjson" | "csv";
export declare const JobsUpdateRequestOutputOptionsOutputType: any;
export type JobsUpdateRequestOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export declare const JobsUpdateRequestOutputOptionsTimestampFormat: any;
export interface JobsUpdateRequestOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string;
    /** String to be appended after each batch. */
    batchSuffix?: string;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsUpdateRequestOutputOptionsFieldNamesList;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsUpdateRequestOutputOptionsOutputType | (string & {});
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string;
    /** String to be prepended before each record. */
    recordPrefix?: string;
    /** String to be appended after each record. */
    recordSuffix?: string;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string;
    /** Floating number to specify sampling rate. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsUpdateRequestOutputOptionsTimestampFormat | (string & {});
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean;
}
export declare const JobsUpdateRequestOutputOptions: S.Schema<JobsUpdateRequestOutputOptions>;
export interface UpdateJobForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique id of the job. */
    jobId: number;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsUpdateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsUpdateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsUpdateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export declare const UpdateJobForAccountRequest: S.Schema<UpdateJobForAccountRequest>;
export type JobsUpdateResponseDataset = "access_requests" | "audit_logs" | "audit_logs_v2" | "biso_user_actions" | "casb_findings" | "device_posture_results" | "dex_application_tests" | "dex_device_state_events" | "dlp_forensic_copies" | "dns_firewall_logs" | "dns_logs" | "email_security_alerts" | "email_security_post_delivery_events" | "firewall_events" | "gateway_dns" | "gateway_http" | "gateway_network" | "http_requests" | "ipsec_logs" | "magic_ids_detections" | "mcp_portal_logs" | "mnm_flow_logs" | "nel_reports" | "network_analytics_logs" | "page_shield_events" | "sinkhole_http_logs" | "spectrum_events" | "ssh_logs" | "turnstile_events" | "warp_config_changes" | "warp_toggle_changes" | "websocket_analytics" | "workers_trace_events" | "zaraz_events" | "zero_trust_network_sessions";
export declare const JobsUpdateResponseDataset: any;
export type JobsUpdateResponseFrequency = "high" | "low";
export declare const JobsUpdateResponseFrequency: any;
export type JobsUpdateResponseKind = "" | "edge";
export declare const JobsUpdateResponseKind: any;
export type JobsUpdateResponseOutputOptionsFieldNamesList = Array<string>;
export declare const JobsUpdateResponseOutputOptionsFieldNamesList: S.Schema<JobsUpdateResponseOutputOptionsFieldNamesList>;
export type JobsUpdateResponseOutputOptionsOutputType = "ndjson" | "csv";
export declare const JobsUpdateResponseOutputOptionsOutputType: any;
export type JobsUpdateResponseOutputOptionsTimestampFormat = "unixnano" | "unix" | "rfc3339" | "rfc3339ms" | "rfc3339ns";
export declare const JobsUpdateResponseOutputOptionsTimestampFormat: any;
export interface JobsUpdateResponseOutputOptions {
    /** String to be prepended before each batch. */
    batchPrefix?: string | null;
    /** String to be appended after each batch. */
    batchSuffix?: string | null;
    /** String to join fields. This field be ignored when `record_template` is set. */
    fieldDelimiter?: string | null;
    /** List of field names to be included in the Logpush output. For the moment, there is no option to add all fields at once, so you must specify all the fields names you are interested in. */
    fieldNames?: JobsUpdateResponseOutputOptionsFieldNamesList | null;
    /** If set to true, subrequests will be merged into the parent request. Only supported for the `http_requests` dataset. */
    mergeSubrequests?: boolean | null;
    /** Specifies the output type, such as `ndjson` or `csv`. This sets default values for the rest of the settings, depending on the chosen output type. Some formatting rules, like string quoting, are different between output types. */
    outputType?: JobsUpdateResponseOutputOptionsOutputType | null;
    /** String to be inserted in-between the records as separator. */
    recordDelimiter?: string | null;
    /** String to be prepended before each record. */
    recordPrefix?: string | null;
    /** String to be appended after each record. */
    recordSuffix?: string | null;
    /** String to use as template for each record instead of the default json key value mapping. All fields used in the template must be present in `field_names` as well, otherwise they will end up as null. Format as a Go `text/template` without any standard functions, like conditionals, loops, sub-templates, etc. */
    recordTemplate?: string | null;
    /** Floating number to specify sampling rate. Sampling is applied on top of filtering, and regardless of the current `sample_interval` of the data. */
    sampleRate?: number | null;
    /** String to specify the format for timestamps, such as `unixnano`, `unix`, `rfc3339`, `rfc3339ms` or `rfc3339ns`. */
    timestampFormat?: JobsUpdateResponseOutputOptionsTimestampFormat | null;
    /** If set to true, will cause all occurrences of `${` in the generated files to be replaced with `x{`. */
    "cve-2021-44228"?: boolean | null;
}
export declare const JobsUpdateResponseOutputOptions: S.Schema<JobsUpdateResponseOutputOptions>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateJobResponse {
    /** Unique id of the job. */
    id?: number | null;
    /** Name of the dataset. A list of supported datasets can be found on the [Developer Docs](https://developers.cloudflare.com/logs/reference/log-fields/). */
    dataset?: JobsUpdateResponseDataset | null;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string | null;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean | null;
    /** If not null, the job is currently failing. Failures are usually. repetitive (example: no permissions to write to destination bucket). Only the last failure is recorded. On successful execution of a job the error_message and last_error are set to null. */
    errorMessage?: string | null;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsUpdateResponseFrequency | null;
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsUpdateResponseKind | null;
    /** Records the last time for which logs have been successfully pushed. If the last successful push was for logs range 2018-07-23T10:00:00Z to 2018-07-23T10:01:00Z then the value of this field will be 2018-07-23T10:01:00Z. If the job has never run or has just been enabled and hasn't run yet then the field will be empty. */
    lastComplete?: string | null;
    /** Records the last time the job failed. If not null, the job is currently. failing. If null, the job has either never failed or has run successfully at least once since last failure. See also the error_message field. */
    lastError?: string | null;
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string | null;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number | null;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number | null;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number | null;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string | null;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsUpdateResponseOutputOptions | null;
}
export declare const UpdateJobResponse: S.Schema<UpdateJobResponse>;
export interface UpdateJobForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique id of the job. */
    jobId: number;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf?: string;
    /** Flag that indicates if the job is enabled. */
    enabled?: boolean;
    /** The filters to select the events to include and/or remove from your logs. For more information, refer to [Filters](https://developers.cloudflare.com/logs/reference/filters/). */
    filter?: string;
    /** This field is deprecated. Please use `max_upload_*` parameters instead. . The frequency at which Cloudflare sends batches of logs to your destination. Setting frequency to high sends your logs in larger quantities of smaller files. Setting frequency to low sends logs in smaller quantities of larger files. */
    frequency?: JobsUpdateRequestFrequency | (string & {});
    /** The kind parameter (optional) is used to differentiate between Logpush and Edge Log Delivery jobs (when supported by the dataset). */
    kind?: JobsUpdateRequestKind | (string & {});
    /** This field is deprecated. Use `output_options` instead. Configuration string. It specifies things like requested fields and timestamp formats. If migrating from the logpull api, copy the url (full url or just the query string) of your call here, and logpush will keep on making this call for you, setting start and end times appropriately. */
    logpullOptions?: string;
    /** The maximum uncompressed file size of a batch of logs. This setting value must be between `5 MB` and `1 GB`, or `0` to disable it. Note that you cannot set a minimum file size; this means that log files may be much smaller than this batch size. */
    maxUploadBytes?: number;
    /** The maximum interval in seconds for log batches. This setting must be between 30 and 300 seconds (5 minutes), or `0` to disable it. Note that you cannot specify a minimum interval for log batches; this means that log files may be sent in shorter intervals than this. */
    maxUploadIntervalSeconds?: number;
    /** The maximum number of log lines per batch. This setting must be between 1000 and 1,000,000 lines, or `0` to disable it. Note that you cannot specify a minimum number of log lines per batch; this means that log files may contain many fewer lines than this. */
    maxUploadRecords?: number;
    /** Optional human readable job name. Not unique. Cloudflare suggests. that you set this to a meaningful string, like the domain name, to make it easier to identify your job. */
    name?: string;
    /** The structured replacement for `logpull_options`. When including this field, the `logpull_option` field will be ignored. */
    outputOptions?: JobsUpdateRequestOutputOptions;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge?: string;
}
export declare const UpdateJobForZoneRequest: S.Schema<UpdateJobForZoneRequest>;
export interface ValidateOwnershipForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge: string;
}
export declare const ValidateOwnershipForAccountRequest: S.Schema<ValidateOwnershipForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ValidateOwnershipResponse {
    valid?: boolean | null;
}
export declare const ValidateOwnershipResponse: S.Schema<ValidateOwnershipResponse>;
export interface ValidateOwnershipForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Uniquely identifies a resource (such as an s3 bucket) where data. will be pushed. Additional configuration parameters supported by the destination may be included. */
    destinationConf: string;
    /** Ownership challenge token to prove destination ownership. */
    ownershipChallenge: string;
}
export declare const ValidateOwnershipForZoneRequest: S.Schema<ValidateOwnershipForZoneRequest>;
export type CreateEdgeError = CloudflareOpError;
/** Creates a new Instant Logs job for a zone. */
export declare const createEdge: API.OperationMethod<CreateEdgeRequest, CreateEdgeResponse, CreateEdgeError, CloudflareOpContext>;
export type CreateJobForAccountError = CloudflareOpError;
/** Creates a new Logpush job for an account or zone. */
export declare const createJobForAccount: API.OperationMethod<CreateJobForAccountRequest, CreateJobResponse, CreateJobForAccountError, CloudflareOpContext>;
export type CreateJobForZoneError = CloudflareOpError;
/** Creates a new Logpush job for an account or zone. */
export declare const createJobForZone: API.OperationMethod<CreateJobForZoneRequest, CreateJobResponse, CreateJobForZoneError, CloudflareOpContext>;
export type CreateOwnershipForAccountError = CloudflareOpError;
/** Gets a new ownership challenge sent to your destination. */
export declare const createOwnershipForAccount: API.OperationMethod<CreateOwnershipForAccountRequest, CreateOwnershipResponse, CreateOwnershipForAccountError, CloudflareOpContext>;
export type CreateOwnershipForZoneError = CloudflareOpError;
/** Gets a new ownership challenge sent to your destination. */
export declare const createOwnershipForZone: API.OperationMethod<CreateOwnershipForZoneRequest, CreateOwnershipResponse, CreateOwnershipForZoneError, CloudflareOpContext>;
export type DeleteJobForAccountError = JobNotFound | CloudflareOpError;
/** Deletes a Logpush job. */
export declare const deleteJobForAccount: API.OperationMethod<DeleteJobForAccountRequest, DeleteJobResponse, DeleteJobForAccountError, CloudflareOpContext>;
export type DeleteJobForZoneError = JobNotFound | CloudflareOpError;
/** Deletes a Logpush job. */
export declare const deleteJobForZone: API.OperationMethod<DeleteJobForZoneRequest, DeleteJobResponse, DeleteJobForZoneError, CloudflareOpContext>;
export type DestinationExistsValidateForAccountError = CloudflareOpError;
/** Checks if there is an existing job with a destination. */
export declare const destinationExistsValidateForAccount: API.OperationMethod<DestinationExistsValidateForAccountRequest, DestinationExistsValidateResponse, DestinationExistsValidateForAccountError, CloudflareOpContext>;
export type DestinationExistsValidateForZoneError = CloudflareOpError;
/** Checks if there is an existing job with a destination. */
export declare const destinationExistsValidateForZone: API.OperationMethod<DestinationExistsValidateForZoneRequest, DestinationExistsValidateResponse, DestinationExistsValidateForZoneError, CloudflareOpContext>;
export type DestinationValidateForAccountError = CloudflareOpError;
/** Validates destination. */
export declare const destinationValidateForAccount: API.OperationMethod<DestinationValidateForAccountRequest, DestinationValidateResponse, DestinationValidateForAccountError, CloudflareOpContext>;
export type DestinationValidateForZoneError = CloudflareOpError;
/** Validates destination. */
export declare const destinationValidateForZone: API.OperationMethod<DestinationValidateForZoneRequest, DestinationValidateResponse, DestinationValidateForZoneError, CloudflareOpContext>;
export type GetDatasetFieldForAccountError = CloudflareOpError;
/** Lists all fields available for a dataset. The response result is. an object with key-value pairs, where keys are field names, and values are descriptions. */
export declare const getDatasetFieldForAccount: API.OperationMethod<GetDatasetFieldForAccountRequest, GetDatasetFieldResponse, GetDatasetFieldForAccountError, CloudflareOpContext>;
export type GetDatasetFieldForZoneError = CloudflareOpError;
/** Lists all fields available for a dataset. The response result is. an object with key-value pairs, where keys are field names, and values are descriptions. */
export declare const getDatasetFieldForZone: API.OperationMethod<GetDatasetFieldForZoneRequest, GetDatasetFieldResponse, GetDatasetFieldForZoneError, CloudflareOpContext>;
export type GetDatasetJobForAccountError = CloudflareOpError;
/** Lists Logpush jobs for an account or zone for a dataset. */
export declare const getDatasetJobForAccount: API.PaginatedOperationMethod<GetDatasetJobForAccountRequest, GetDatasetJobResponse, GetDatasetJobForAccountError, CloudflareOpContext, DatasetsJobsGetResultItem>;
export type GetDatasetJobForZoneError = CloudflareOpError;
/** Lists Logpush jobs for an account or zone for a dataset. */
export declare const getDatasetJobForZone: API.PaginatedOperationMethod<GetDatasetJobForZoneRequest, GetDatasetJobResponse, GetDatasetJobForZoneError, CloudflareOpContext, DatasetsJobsGetResultItem>;
export type GetEdgeError = CloudflareOpError;
/** Lists Instant Logs jobs for a zone. */
export declare const getEdge: API.PaginatedOperationMethod<GetEdgeRequest, GetEdgeResponse, GetEdgeError, CloudflareOpContext, EdgeGetResultItem>;
export type GetJobForAccountError = JobNotFound | Forbidden | CloudflareOpError;
/** Gets the details of a Logpush job. */
export declare const getJobForAccount: API.OperationMethod<GetJobForAccountRequest, GetJobResponse, GetJobForAccountError, CloudflareOpContext>;
export type GetJobForZoneError = JobNotFound | Forbidden | CloudflareOpError;
/** Gets the details of a Logpush job. */
export declare const getJobForZone: API.OperationMethod<GetJobForZoneRequest, GetJobResponse, GetJobForZoneError, CloudflareOpContext>;
export type ListJobsForAccountError = Forbidden | NotFound | CloudflareOpError;
/** Lists Logpush jobs for an account or zone. */
export declare const listJobsForAccount: API.PaginatedOperationMethod<ListJobsForAccountRequest, ListJobsResponse, ListJobsForAccountError, CloudflareOpContext, JobsListResultItem>;
export type ListJobsForZoneError = Forbidden | NotFound | CloudflareOpError;
/** Lists Logpush jobs for an account or zone. */
export declare const listJobsForZone: API.PaginatedOperationMethod<ListJobsForZoneRequest, ListJobsResponse, ListJobsForZoneError, CloudflareOpContext, JobsListResultItem>;
export type OriginValidateForAccountError = CloudflareOpError;
/** Validates logpull origin with logpull_options. */
export declare const originValidateForAccount: API.OperationMethod<OriginValidateForAccountRequest, OriginValidateResponse, OriginValidateForAccountError, CloudflareOpContext>;
export type OriginValidateForZoneError = CloudflareOpError;
/** Validates logpull origin with logpull_options. */
export declare const originValidateForZone: API.OperationMethod<OriginValidateForZoneRequest, OriginValidateResponse, OriginValidateForZoneError, CloudflareOpContext>;
export type UpdateJobForAccountError = CloudflareOpError;
/** Updates a Logpush job. */
export declare const updateJobForAccount: API.OperationMethod<UpdateJobForAccountRequest, UpdateJobResponse, UpdateJobForAccountError, CloudflareOpContext>;
export type UpdateJobForZoneError = CloudflareOpError;
/** Updates a Logpush job. */
export declare const updateJobForZone: API.OperationMethod<UpdateJobForZoneRequest, UpdateJobResponse, UpdateJobForZoneError, CloudflareOpContext>;
export type ValidateOwnershipForAccountError = CloudflareOpError;
/** Validates ownership challenge of the destination. */
export declare const validateOwnershipForAccount: API.OperationMethod<ValidateOwnershipForAccountRequest, ValidateOwnershipResponse, ValidateOwnershipForAccountError, CloudflareOpContext>;
export type ValidateOwnershipForZoneError = CloudflareOpError;
/** Validates ownership challenge of the destination. */
export declare const validateOwnershipForZone: API.OperationMethod<ValidateOwnershipForZoneRequest, ValidateOwnershipResponse, ValidateOwnershipForZoneError, CloudflareOpContext>;
//# sourceMappingURL=logpush.d.ts.map