import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const DnsFirewallNotEntitled_base: S.Class<DnsFirewallNotEntitled, S.TaggedStruct<"DnsFirewallNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DnsFirewallNotEntitled extends /*@__PURE__*/ DnsFirewallNotEntitled_base {
}
declare const DnsFirewallNotFound_base: S.Class<DnsFirewallNotFound, S.TaggedStruct<"DnsFirewallNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DnsFirewallNotFound extends /*@__PURE__*/ DnsFirewallNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export type CreateRequestUpstreamIpsList = Array<string>;
export declare const CreateRequestUpstreamIpsList: S.Schema<CreateRequestUpstreamIpsList>;
export interface CreateRequestAttackMitigation {
    /** When enabled, automatically mitigate random-prefix attacks to protect upstream DNS servers */
    enabled?: boolean;
    /** Only mitigate attacks when upstream servers seem unhealthy */
    onlyWhenUpstreamUnhealthy?: boolean;
}
export declare const CreateRequestAttackMitigation: S.Schema<CreateRequestAttackMitigation>;
export interface CreateDnsFirewallRequest {
    /** Identifier. */
    accountId: string;
    /** DNS Firewall cluster name */
    name: string;
    upstreamIps: CreateRequestUpstreamIpsList;
    /** Attack mitigation settings */
    attackMitigation?: CreateRequestAttackMitigation;
    /** Whether to refuse to answer queries for the ANY type */
    deprecateAnyRequests?: boolean;
    /** Number of IPv4 addresses to assign to the DNS Firewall cluster. Only used during cluster creation and cannot be changed later. */
    dnsFirewallIpCount?: number;
    /** Whether to forward client IP (resolver) subnet if no EDNS Client Subnet is sent */
    ecsFallback?: boolean;
    /** By default, Cloudflare attempts to cache responses for as long as */
    maximumCacheTtl?: number;
    /** By default, Cloudflare attempts to cache responses for as long as */
    minimumCacheTtl?: number;
    /** This setting controls how long DNS Firewall should cache negative */
    negativeCacheTtl?: number | null;
    /** Maximum number of DNS queries per second that will be forwarded to your upstream nameservers. The limit is enforced per server, where each server receives a fraction of the configured value. The actual aggregate rate for a data center may vary depending on how many servers are present. Responses served from cache do not count toward this limit. Set to null to disable rate limiting. */
    ratelimit?: number | null;
    /** Number of retries for fetching DNS responses from upstream nameservers (not counting the initial attempt) */
    retries?: number;
}
export declare const CreateDnsFirewallRequest: S.Schema<CreateDnsFirewallRequest>;
export type CreateResponseDnsFirewallIpsList = Array<string>;
export declare const CreateResponseDnsFirewallIpsList: S.Schema<CreateResponseDnsFirewallIpsList>;
export type CreateResponseUpstreamIpsList = Array<string>;
export declare const CreateResponseUpstreamIpsList: S.Schema<CreateResponseUpstreamIpsList>;
export interface CreateResponseAttackMitigation {
    /** When enabled, automatically mitigate random-prefix attacks to protect upstream DNS servers */
    enabled?: boolean | null;
    /** Only mitigate attacks when upstream servers seem unhealthy */
    onlyWhenUpstreamUnhealthy?: boolean | null;
}
export declare const CreateResponseAttackMitigation: S.Schema<CreateResponseAttackMitigation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDnsFirewallResponse {
    /** Identifier. */
    id: string;
    /** Whether to refuse to answer queries for the ANY type */
    deprecateAnyRequests: boolean;
    dnsFirewallIps: CreateResponseDnsFirewallIpsList;
    /** Whether to forward client IP (resolver) subnet if no EDNS Client Subnet is sent */
    ecsFallback: boolean;
    /** By default, Cloudflare attempts to cache responses for as long as */
    maximumCacheTtl: number;
    /** By default, Cloudflare attempts to cache responses for as long as */
    minimumCacheTtl: number;
    /** Last modification of DNS Firewall cluster */
    modifiedOn: string;
    /** DNS Firewall cluster name */
    name: string;
    /** This setting controls how long DNS Firewall should cache negative */
    negativeCacheTtl: number;
    /** Maximum number of DNS queries per second that will be forwarded to your upstream nameservers. The limit is enforced per server, where each server receives a fraction of the configured value. The actual aggregate rate for a data center may vary depending on how many servers are present. Responses served from cache do not count toward this limit. Set to null to disable rate limiting. */
    ratelimit: number;
    /** Number of retries for fetching DNS responses from upstream nameservers (not counting the initial attempt) */
    retries: number;
    upstreamIps: CreateResponseUpstreamIpsList;
    /** Attack mitigation settings */
    attackMitigation?: CreateResponseAttackMitigation | null;
}
export declare const CreateDnsFirewallResponse: S.Schema<CreateDnsFirewallResponse>;
export interface DeleteDnsFirewallRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    dnsFirewallId: string;
}
export declare const DeleteDnsFirewallRequest: S.Schema<DeleteDnsFirewallRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteDnsFirewallResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const DeleteDnsFirewallResponse: S.Schema<DeleteDnsFirewallResponse>;
export interface GetAnalyticReportRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    dnsFirewallId: string;
    /** A comma-separated list of dimensions to group results by. */
    dimensions?: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string;
    /** Limit number of returned metrics. */
    limit?: number;
    /** A comma-separated list of metrics to query. */
    metrics?: string;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since?: string;
    /** A comma-separated list of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: string;
    /** End date and time of requesting data period in ISO 8601 format. */
    until?: string;
}
export declare const GetAnalyticReportRequest: S.Schema<GetAnalyticReportRequest>;
export type AnalyticsReportsGetResponseDataItemDimensionsList = Array<string>;
export declare const AnalyticsReportsGetResponseDataItemDimensionsList: S.Schema<AnalyticsReportsGetResponseDataItemDimensionsList>;
export type AnalyticsReportsGetResponseDataItemMetricsList = Array<number>;
export declare const AnalyticsReportsGetResponseDataItemMetricsList: S.Schema<AnalyticsReportsGetResponseDataItemMetricsList>;
export interface AnalyticsReportsGetResponseDataItem {
    /** Array of dimension values, representing the combination of dimension values corresponding to this row. */
    dimensions: AnalyticsReportsGetResponseDataItemDimensionsList;
    /** Array with one item per requested metric. Each item is a single value. */
    metrics: AnalyticsReportsGetResponseDataItemMetricsList;
}
export declare const AnalyticsReportsGetResponseDataItem: S.Schema<AnalyticsReportsGetResponseDataItem>;
export type AnalyticsReportsGetResponseDataList = Array<AnalyticsReportsGetResponseDataItem>;
export declare const AnalyticsReportsGetResponseDataList: S.Schema<AnalyticsReportsGetResponseDataList>;
export type AnalyticsReportsGetResponseQueryDimensionsList = Array<string>;
export declare const AnalyticsReportsGetResponseQueryDimensionsList: S.Schema<AnalyticsReportsGetResponseQueryDimensionsList>;
export type AnalyticsReportsGetResponseQueryMetricsList = Array<string>;
export declare const AnalyticsReportsGetResponseQueryMetricsList: S.Schema<AnalyticsReportsGetResponseQueryMetricsList>;
export type AnalyticsReportsGetResponseQuerySortList = Array<string>;
export declare const AnalyticsReportsGetResponseQuerySortList: S.Schema<AnalyticsReportsGetResponseQuerySortList>;
export interface AnalyticsReportsGetResponseQuery {
    /** Array of dimension names. */
    dimensions: AnalyticsReportsGetResponseQueryDimensionsList;
    /** Limit number of returned metrics. */
    limit: number;
    /** Array of metric names. */
    metrics: AnalyticsReportsGetResponseQueryMetricsList;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since: string;
    /** End date and time of requesting data period in ISO 8601 format. */
    until: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string | null;
    /** Array of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: AnalyticsReportsGetResponseQuerySortList | null;
}
export declare const AnalyticsReportsGetResponseQuery: S.Schema<AnalyticsReportsGetResponseQuery>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticReportResponse {
    /** Array with one row per combination of dimension values. */
    data: AnalyticsReportsGetResponseDataList;
    /** Number of seconds between current time and last processed event, in another words how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum results for each metric (object mapping metric names to values). Currently always an empty object. */
    max: unknown;
    /** Minimum results for each metric (object mapping metric names to values). Currently always an empty object. */
    min: unknown;
    query: AnalyticsReportsGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Total results for metrics across all data (object mapping metric names to values). */
    totals: unknown;
}
export declare const GetAnalyticReportResponse: S.Schema<GetAnalyticReportResponse>;
export type AnalyticsReportsBytimesGetRequestTimeDelta = "all" | "auto" | "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export declare const AnalyticsReportsBytimesGetRequestTimeDelta: any;
export interface GetAnalyticReportBytimeRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    dnsFirewallId: string;
    /** A comma-separated list of dimensions to group results by. */
    dimensions?: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string;
    /** Limit number of returned metrics. */
    limit?: number;
    /** A comma-separated list of metrics to query. */
    metrics?: string;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since?: string;
    /** A comma-separated list of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: string;
    /** Unit of time to group data by. */
    timeDelta?: AnalyticsReportsBytimesGetRequestTimeDelta | (string & {});
    /** End date and time of requesting data period in ISO 8601 format. */
    until?: string;
}
export declare const GetAnalyticReportBytimeRequest: S.Schema<GetAnalyticReportBytimeRequest>;
export type AnalyticsReportsBytimesGetResponseDataItemDimensionsList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseDataItemDimensionsList: S.Schema<AnalyticsReportsBytimesGetResponseDataItemDimensionsList>;
export type AnalyticsReportsBytimesGetResponseDataItemMetricsItemList = Array<number>;
export declare const AnalyticsReportsBytimesGetResponseDataItemMetricsItemList: S.Schema<AnalyticsReportsBytimesGetResponseDataItemMetricsItemList>;
export type AnalyticsReportsBytimesGetResponseDataItemMetricsList = Array<AnalyticsReportsBytimesGetResponseDataItemMetricsItemList>;
export declare const AnalyticsReportsBytimesGetResponseDataItemMetricsList: S.Schema<AnalyticsReportsBytimesGetResponseDataItemMetricsList>;
export interface AnalyticsReportsBytimesGetResponseDataItem {
    /** Array of dimension values, representing the combination of dimension values corresponding to this row. */
    dimensions: AnalyticsReportsBytimesGetResponseDataItemDimensionsList;
    /** Array with one item per requested metric. Each item is an array of values, broken down by time interval. */
    metrics: AnalyticsReportsBytimesGetResponseDataItemMetricsList;
}
export declare const AnalyticsReportsBytimesGetResponseDataItem: S.Schema<AnalyticsReportsBytimesGetResponseDataItem>;
export type AnalyticsReportsBytimesGetResponseDataList = Array<AnalyticsReportsBytimesGetResponseDataItem>;
export declare const AnalyticsReportsBytimesGetResponseDataList: S.Schema<AnalyticsReportsBytimesGetResponseDataList>;
export type AnalyticsReportsBytimesGetResponseQueryDimensionsList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseQueryDimensionsList: S.Schema<AnalyticsReportsBytimesGetResponseQueryDimensionsList>;
export type AnalyticsReportsBytimesGetResponseQueryMetricsList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseQueryMetricsList: S.Schema<AnalyticsReportsBytimesGetResponseQueryMetricsList>;
export type AnalyticsReportsBytimesGetResponseQueryTimeDelta = "all" | "auto" | "year" | "quarter" | "month" | "week" | "day" | "hour" | "dekaminute" | "minute";
export declare const AnalyticsReportsBytimesGetResponseQueryTimeDelta: any;
export type AnalyticsReportsBytimesGetResponseQuerySortList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseQuerySortList: S.Schema<AnalyticsReportsBytimesGetResponseQuerySortList>;
export interface AnalyticsReportsBytimesGetResponseQuery {
    /** Array of dimension names. */
    dimensions: AnalyticsReportsBytimesGetResponseQueryDimensionsList;
    /** Limit number of returned metrics. */
    limit: number;
    /** Array of metric names. */
    metrics: AnalyticsReportsBytimesGetResponseQueryMetricsList;
    /** Start date and time of requesting data period in ISO 8601 format. */
    since: string;
    /** Unit of time to group data by. */
    timeDelta: AnalyticsReportsBytimesGetResponseQueryTimeDelta;
    /** End date and time of requesting data period in ISO 8601 format. */
    until: string;
    /** Segmentation filter in 'attribute operator value' format. */
    filters?: string | null;
    /** Array of dimensions to sort by, where each dimension may be prefixed by - (descending) or + (ascending). */
    sort?: AnalyticsReportsBytimesGetResponseQuerySortList | null;
}
export declare const AnalyticsReportsBytimesGetResponseQuery: S.Schema<AnalyticsReportsBytimesGetResponseQuery>;
export type AnalyticsReportsBytimesGetResponseTimeIntervalsItemList = Array<string>;
export declare const AnalyticsReportsBytimesGetResponseTimeIntervalsItemList: S.Schema<AnalyticsReportsBytimesGetResponseTimeIntervalsItemList>;
export type AnalyticsReportsBytimesGetResponseTimeIntervalsList = Array<AnalyticsReportsBytimesGetResponseTimeIntervalsItemList>;
export declare const AnalyticsReportsBytimesGetResponseTimeIntervalsList: S.Schema<AnalyticsReportsBytimesGetResponseTimeIntervalsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAnalyticReportBytimeResponse {
    /** Array with one row per combination of dimension values. */
    data: AnalyticsReportsBytimesGetResponseDataList;
    /** Number of seconds between current time and last processed event, in another words how many seconds of data could be missing. */
    dataLag: number;
    /** Maximum results for each metric (object mapping metric names to values). Currently always an empty object. */
    max: unknown;
    /** Minimum results for each metric (object mapping metric names to values). Currently always an empty object. */
    min: unknown;
    query: AnalyticsReportsBytimesGetResponseQuery;
    /** Total number of rows in the result. */
    rows: number;
    /** Array of time intervals in the response data. Each interval is represented as an array containing two values: the start time, and the end time. */
    timeIntervals: AnalyticsReportsBytimesGetResponseTimeIntervalsList;
    /** Total results for metrics across all data (object mapping metric names to values). */
    totals: unknown;
}
export declare const GetAnalyticReportBytimeResponse: S.Schema<GetAnalyticReportBytimeResponse>;
export interface GetDnsFirewallRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    dnsFirewallId: string;
}
export declare const GetDnsFirewallRequest: S.Schema<GetDnsFirewallRequest>;
export type GetResponseDnsFirewallIpsList = Array<string>;
export declare const GetResponseDnsFirewallIpsList: S.Schema<GetResponseDnsFirewallIpsList>;
export type GetResponseUpstreamIpsList = Array<string>;
export declare const GetResponseUpstreamIpsList: S.Schema<GetResponseUpstreamIpsList>;
export type GetResponseAttackMitigation = CreateResponseAttackMitigation;
export declare const GetResponseAttackMitigation: S.Schema<CreateResponseAttackMitigation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDnsFirewallResponse {
    /** Identifier. */
    id: string;
    /** Whether to refuse to answer queries for the ANY type */
    deprecateAnyRequests: boolean;
    dnsFirewallIps: GetResponseDnsFirewallIpsList;
    /** Whether to forward client IP (resolver) subnet if no EDNS Client Subnet is sent */
    ecsFallback: boolean;
    /** By default, Cloudflare attempts to cache responses for as long as */
    maximumCacheTtl: number;
    /** By default, Cloudflare attempts to cache responses for as long as */
    minimumCacheTtl: number;
    /** Last modification of DNS Firewall cluster */
    modifiedOn: string;
    /** DNS Firewall cluster name */
    name: string;
    /** This setting controls how long DNS Firewall should cache negative */
    negativeCacheTtl: number;
    /** Maximum number of DNS queries per second that will be forwarded to your upstream nameservers. The limit is enforced per server, where each server receives a fraction of the configured value. The actual aggregate rate for a data center may vary depending on how many servers are present. Responses served from cache do not count toward this limit. Set to null to disable rate limiting. */
    ratelimit: number;
    /** Number of retries for fetching DNS responses from upstream nameservers (not counting the initial attempt) */
    retries: number;
    upstreamIps: GetResponseUpstreamIpsList;
    /** Attack mitigation settings */
    attackMitigation?: CreateResponseAttackMitigation | null;
}
export declare const GetDnsFirewallResponse: S.Schema<GetDnsFirewallResponse>;
export interface GetReverseDnRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    dnsFirewallId: string;
}
export declare const GetReverseDnRequest: S.Schema<GetReverseDnRequest>;
export type ReverseDnsGetResponsePtrMap = {
    [key: string]: string | undefined;
};
export declare const ReverseDnsGetResponsePtrMap: S.Schema<ReverseDnsGetResponsePtrMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetReverseDnResponse {
    /** Map of cluster IP addresses to PTR record contents */
    ptr: ReverseDnsGetResponsePtrMap;
}
export declare const GetReverseDnResponse: S.Schema<GetReverseDnResponse>;
export interface ListDnsFirewallsRequest {
    /** Identifier. */
    accountId: string;
    /** Page number of paginated results */
    page?: number;
    /** Number of clusters per page */
    perPage?: number;
}
export declare const ListDnsFirewallsRequest: S.Schema<ListDnsFirewallsRequest>;
export type ListResultItemDnsFirewallIpsList = Array<string>;
export declare const ListResultItemDnsFirewallIpsList: S.Schema<ListResultItemDnsFirewallIpsList>;
export type ListResultItemUpstreamIpsList = Array<string>;
export declare const ListResultItemUpstreamIpsList: S.Schema<ListResultItemUpstreamIpsList>;
export type ListResultItemAttackMitigation = CreateResponseAttackMitigation;
export declare const ListResultItemAttackMitigation: S.Schema<CreateResponseAttackMitigation>;
export interface ListResultItem {
    /** Identifier. */
    id: string;
    /** Whether to refuse to answer queries for the ANY type */
    deprecateAnyRequests: boolean;
    dnsFirewallIps: ListResultItemDnsFirewallIpsList;
    /** Whether to forward client IP (resolver) subnet if no EDNS Client Subnet is sent */
    ecsFallback: boolean;
    /** By default, Cloudflare attempts to cache responses for as long as */
    maximumCacheTtl: number;
    /** By default, Cloudflare attempts to cache responses for as long as */
    minimumCacheTtl: number;
    /** Last modification of DNS Firewall cluster */
    modifiedOn: string;
    /** DNS Firewall cluster name */
    name: string;
    /** This setting controls how long DNS Firewall should cache negative */
    negativeCacheTtl: number;
    /** Maximum number of DNS queries per second that will be forwarded to your upstream nameservers. The limit is enforced per server, where each server receives a fraction of the configured value. The actual aggregate rate for a data center may vary depending on how many servers are present. Responses served from cache do not count toward this limit. Set to null to disable rate limiting. */
    ratelimit: number;
    /** Number of retries for fetching DNS responses from upstream nameservers (not counting the initial attempt) */
    retries: number;
    upstreamIps: ListResultItemUpstreamIpsList;
    /** Attack mitigation settings */
    attackMitigation?: CreateResponseAttackMitigation | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListDnsFirewallsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDnsFirewallsResponse: S.Schema<ListDnsFirewallsResponse>;
export type EditRequestAttackMitigation = CreateRequestAttackMitigation;
export declare const EditRequestAttackMitigation: S.Schema<CreateRequestAttackMitigation>;
export type EditRequestUpstreamIpsList = Array<string>;
export declare const EditRequestUpstreamIpsList: S.Schema<EditRequestUpstreamIpsList>;
export interface PatchDnsFirewallRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    dnsFirewallId: string;
    /** Attack mitigation settings */
    attackMitigation?: CreateRequestAttackMitigation;
    /** Whether to refuse to answer queries for the ANY type */
    deprecateAnyRequests?: boolean;
    /** Whether to forward client IP (resolver) subnet if no EDNS Client Subnet is sent */
    ecsFallback?: boolean;
    /** By default, Cloudflare attempts to cache responses for as long as */
    maximumCacheTtl?: number;
    /** By default, Cloudflare attempts to cache responses for as long as */
    minimumCacheTtl?: number;
    /** DNS Firewall cluster name */
    name?: string;
    /** This setting controls how long DNS Firewall should cache negative */
    negativeCacheTtl?: number | null;
    /** Maximum number of DNS queries per second that will be forwarded to your upstream nameservers. The limit is enforced per server, where each server receives a fraction of the configured value. The actual aggregate rate for a data center may vary depending on how many servers are present. Responses served from cache do not count toward this limit. Set to null to disable rate limiting. */
    ratelimit?: number | null;
    /** Number of retries for fetching DNS responses from upstream nameservers (not counting the initial attempt) */
    retries?: number;
    upstreamIps?: EditRequestUpstreamIpsList;
}
export declare const PatchDnsFirewallRequest: S.Schema<PatchDnsFirewallRequest>;
export type EditResponseDnsFirewallIpsList = Array<string>;
export declare const EditResponseDnsFirewallIpsList: S.Schema<EditResponseDnsFirewallIpsList>;
export type EditResponseUpstreamIpsList = Array<string>;
export declare const EditResponseUpstreamIpsList: S.Schema<EditResponseUpstreamIpsList>;
export type EditResponseAttackMitigation = CreateResponseAttackMitigation;
export declare const EditResponseAttackMitigation: S.Schema<CreateResponseAttackMitigation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchDnsFirewallResponse {
    /** Identifier. */
    id: string;
    /** Whether to refuse to answer queries for the ANY type */
    deprecateAnyRequests: boolean;
    dnsFirewallIps: EditResponseDnsFirewallIpsList;
    /** Whether to forward client IP (resolver) subnet if no EDNS Client Subnet is sent */
    ecsFallback: boolean;
    /** By default, Cloudflare attempts to cache responses for as long as */
    maximumCacheTtl: number;
    /** By default, Cloudflare attempts to cache responses for as long as */
    minimumCacheTtl: number;
    /** Last modification of DNS Firewall cluster */
    modifiedOn: string;
    /** DNS Firewall cluster name */
    name: string;
    /** This setting controls how long DNS Firewall should cache negative */
    negativeCacheTtl: number;
    /** Maximum number of DNS queries per second that will be forwarded to your upstream nameservers. The limit is enforced per server, where each server receives a fraction of the configured value. The actual aggregate rate for a data center may vary depending on how many servers are present. Responses served from cache do not count toward this limit. Set to null to disable rate limiting. */
    ratelimit: number;
    /** Number of retries for fetching DNS responses from upstream nameservers (not counting the initial attempt) */
    retries: number;
    upstreamIps: EditResponseUpstreamIpsList;
    /** Attack mitigation settings */
    attackMitigation?: CreateResponseAttackMitigation | null;
}
export declare const PatchDnsFirewallResponse: S.Schema<PatchDnsFirewallResponse>;
export type ReverseDnsEditRequestPtrMap = {
    [key: string]: string | undefined;
};
export declare const ReverseDnsEditRequestPtrMap: S.Schema<ReverseDnsEditRequestPtrMap>;
export interface PatchReverseDnRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    dnsFirewallId: string;
    /** Map of cluster IP addresses to PTR record contents */
    ptr?: ReverseDnsEditRequestPtrMap;
}
export declare const PatchReverseDnRequest: S.Schema<PatchReverseDnRequest>;
export type ReverseDnsEditResponsePtrMap = {
    [key: string]: string | undefined;
};
export declare const ReverseDnsEditResponsePtrMap: S.Schema<ReverseDnsEditResponsePtrMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchReverseDnResponse {
    /** Map of cluster IP addresses to PTR record contents */
    ptr: ReverseDnsEditResponsePtrMap;
}
export declare const PatchReverseDnResponse: S.Schema<PatchReverseDnResponse>;
export type CreateDnsFirewallError = DnsFirewallNotEntitled | Forbidden | CloudflareOpError;
/** Create a DNS Firewall cluster */
export declare const createDnsFirewall: API.OperationMethod<CreateDnsFirewallRequest, CreateDnsFirewallResponse, CreateDnsFirewallError, CloudflareOpContext>;
export type DeleteDnsFirewallError = DnsFirewallNotFound | Forbidden | CloudflareOpError;
/** Delete a DNS Firewall cluster */
export declare const deleteDnsFirewall: API.OperationMethod<DeleteDnsFirewallRequest, DeleteDnsFirewallResponse, DeleteDnsFirewallError, CloudflareOpContext>;
export type GetAnalyticReportError = CloudflareOpError;
/** Retrieves a list of summarised aggregate metrics over a given time period. See [Analytics API properties](https://developers.cloudflare.com/dns/reference/analytics-api-properties/) for detailed information about the available query parameters. */
export declare const getAnalyticReport: API.OperationMethod<GetAnalyticReportRequest, GetAnalyticReportResponse, GetAnalyticReportError, CloudflareOpContext>;
export type GetAnalyticReportBytimeError = CloudflareOpError;
/** Retrieves a list of aggregate metrics grouped by time interval. See [Analytics API properties](https://developers.cloudflare.com/dns/reference/analytics-api-properties/) for detailed information about the available query parameters. */
export declare const getAnalyticReportBytime: API.OperationMethod<GetAnalyticReportBytimeRequest, GetAnalyticReportBytimeResponse, GetAnalyticReportBytimeError, CloudflareOpContext>;
export type GetDnsFirewallError = DnsFirewallNotFound | Forbidden | CloudflareOpError;
/** Show a single DNS Firewall cluster for an account */
export declare const getDnsFirewall: API.OperationMethod<GetDnsFirewallRequest, GetDnsFirewallResponse, GetDnsFirewallError, CloudflareOpContext>;
export type GetReverseDnError = DnsFirewallNotFound | Forbidden | CloudflareOpError;
/** Show reverse DNS configuration (PTR records) for a DNS Firewall cluster */
export declare const getReverseDn: API.OperationMethod<GetReverseDnRequest, GetReverseDnResponse, GetReverseDnError, CloudflareOpContext>;
export type ListDnsFirewallsError = Forbidden | CloudflareOpError;
/** List DNS Firewall clusters for an account */
export declare const listDnsFirewalls: API.PaginatedOperationMethod<ListDnsFirewallsRequest, ListDnsFirewallsResponse, ListDnsFirewallsError, CloudflareOpContext, ListResultItem>;
export type PatchDnsFirewallError = DnsFirewallNotFound | Forbidden | CloudflareOpError;
/** Modify the configuration of a DNS Firewall cluster */
export declare const patchDnsFirewall: API.OperationMethod<PatchDnsFirewallRequest, PatchDnsFirewallResponse, PatchDnsFirewallError, CloudflareOpContext>;
export type PatchReverseDnError = DnsFirewallNotFound | Forbidden | CloudflareOpError;
/** Update reverse DNS configuration (PTR records) for a DNS Firewall cluster */
export declare const patchReverseDn: API.OperationMethod<PatchReverseDnRequest, PatchReverseDnResponse, PatchReverseDnError, CloudflareOpContext>;
//# sourceMappingURL=dns_firewall.d.ts.map