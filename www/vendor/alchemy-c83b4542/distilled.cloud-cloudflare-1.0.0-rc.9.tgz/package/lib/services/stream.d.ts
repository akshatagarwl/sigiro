import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LiveInputNotFound_base: S.Class<LiveInputNotFound, S.TaggedStruct<"LiveInputNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LiveInputNotFound extends /*@__PURE__*/ LiveInputNotFound_base {
}
declare const OutputNotFound_base: S.Class<OutputNotFound, S.TaggedStruct<"OutputNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OutputNotFound extends /*@__PURE__*/ OutputNotFound_base {
}
declare const SigningKeyNotFound_base: S.Class<SigningKeyNotFound, S.TaggedStruct<"SigningKeyNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SigningKeyNotFound extends /*@__PURE__*/ SigningKeyNotFound_base {
}
declare const WatermarkImageInvalid_base: S.Class<WatermarkImageInvalid, S.TaggedStruct<"WatermarkImageInvalid", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WatermarkImageInvalid extends /*@__PURE__*/ WatermarkImageInvalid_base {
}
declare const WatermarkNotFound_base: S.Class<WatermarkNotFound, S.TaggedStruct<"WatermarkNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WatermarkNotFound extends /*@__PURE__*/ WatermarkNotFound_base {
}
declare const WebhookNotFound_base: S.Class<WebhookNotFound, S.TaggedStruct<"WebhookNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WebhookNotFound extends /*@__PURE__*/ WebhookNotFound_base {
}
export interface CopyAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label: string;
    /** An audio track URL. The server must be publicly routable and support `HTTP HEAD` requests and `HTTP GET` range requests. The server should respond to `HTTP HEAD` requests with a `content-range` header that includes the size of the file. */
    url?: string;
}
export declare const CopyAudioTrackRequest: S.Schema<CopyAudioTrackRequest>;
export type AudioTracksCopyResponseStatus = "queued" | "ready" | "error";
export declare const AudioTracksCopyResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CopyAudioTrackResponse {
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean | null;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string | null;
    /** Specifies the processing status of the video. */
    status?: AudioTracksCopyResponseStatus | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
}
export declare const CopyAudioTrackResponse: S.Schema<CopyAudioTrackResponse>;
export interface CreateCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export declare const CreateCaptionLanguageRequest: S.Schema<CreateCaptionLanguageRequest>;
export type CaptionsLanguageCreateResponseStatus = "ready" | "inprogress" | "error";
export declare const CaptionsLanguageCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCaptionLanguageResponse {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null;
    /** The language label displayed in the native language to users. */
    label?: string | null;
    /** The language tag in BCP 47 format. */
    language?: string | null;
    /** The status of a generated caption. */
    status?: CaptionsLanguageCreateResponseStatus | null;
}
export declare const CreateCaptionLanguageResponse: S.Schema<CreateCaptionLanguageResponse>;
export type ClipCreateRequestAllowedOriginsList = Array<unknown>;
export declare const ClipCreateRequestAllowedOriginsList: S.Schema<ClipCreateRequestAllowedOriginsList>;
export interface ClipCreateRequestWatermark {
    /** The unique identifier for the watermark profile. */
    uid?: string;
}
export declare const ClipCreateRequestWatermark: S.Schema<ClipCreateRequestWatermark>;
export interface CreateClipRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The unique video identifier (UID). */
    clippedFromVideoUID: string;
    /** Specifies the end time for the video clip in seconds. */
    endTimeSeconds: number;
    /** Specifies the start time for the video clip in seconds. */
    startTimeSeconds: number;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: ClipCreateRequestAllowedOriginsList;
    /** A user-defined identifier for the media creator. */
    creator?: string;
    /** A video's URL. Preferred over 'url'. */
    input?: string;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown;
    /** A name for the video. */
    name?: string;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number;
    /** A video's URL (legacy field, use 'input' instead). */
    url?: string;
    watermark?: ClipCreateRequestWatermark;
}
export declare const CreateClipRequest: S.Schema<CreateClipRequest>;
export type ClipCreateResponseAllowedOriginsList = Array<unknown>;
export declare const ClipCreateResponseAllowedOriginsList: S.Schema<ClipCreateResponseAllowedOriginsList>;
export interface ClipCreateResponseInput {
    /** The video height in pixels. A value of `-1` means the height is unknown. The value becomes available after the upload and before the video is ready. */
    height?: number | null;
    /** The video width in pixels. A value of `-1` means the width is unknown. The value becomes available after the upload and before the video is ready. */
    width?: number | null;
}
export declare const ClipCreateResponseInput: S.Schema<ClipCreateResponseInput>;
export interface ClipCreateResponsePlayback {
    /** DASH Media Presentation Description for the video. */
    dash?: string | null;
    /** The HLS manifest for the video. */
    hls?: string | null;
}
export declare const ClipCreateResponsePlayback: S.Schema<ClipCreateResponsePlayback>;
export interface ClipCreateResponsePublicDetails {
    channelLink?: string | null;
    logo?: string | null;
    mediaId?: number | null;
    shareLink?: string | null;
    title?: string | null;
}
export declare const ClipCreateResponsePublicDetails: S.Schema<ClipCreateResponsePublicDetails>;
export type ClipCreateResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export declare const ClipCreateResponseStatusState: any;
export interface ClipCreateResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null;
    /** Specifies the processing status for all quality levels for a video. */
    state?: ClipCreateResponseStatusState | null;
}
export declare const ClipCreateResponseStatus: S.Schema<ClipCreateResponseStatus>;
export interface ClipCreateResponseWatermark {
    /** The date and a time a watermark profile was created. */
    created?: string | null;
    /** The source URL for a downloaded image. If the watermark profile was created via direct upload, this field is null. */
    downloadedFrom?: string | null;
    /** The height of the image in pixels. */
    height?: number | null;
    /** A short description of the watermark profile. */
    name?: string | null;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number | null;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number | null;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string | null;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0`fills the entire video. */
    scale?: number | null;
    /** The size of the image in bytes. */
    size?: number | null;
    /** The unique identifier for a watermark profile. */
    uid?: string | null;
    /** The width of the image in pixels. */
    width?: number | null;
}
export declare const ClipCreateResponseWatermark: S.Schema<ClipCreateResponseWatermark>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateClipResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: ClipCreateResponseAllowedOriginsList | null;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null;
    /** The date and time the media item was created. */
    created?: string | null;
    /** A user-defined identifier for the media creator. */
    creator?: string | null;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null;
    input?: ClipCreateResponseInput | null;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null;
    /** The date and time the media item was last modified. */
    modified?: string | null;
    playback?: ClipCreateResponsePlayback | null;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null;
    /** The size of the media item in bytes. */
    size?: number | null;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: ClipCreateResponseStatus | null;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null;
    watermark?: ClipCreateResponseWatermark | null;
}
export declare const CreateClipResponse: S.Schema<CreateClipResponse>;
export type CopyCreateRequestAllowedOriginsList = Array<unknown>;
export declare const CopyCreateRequestAllowedOriginsList: S.Schema<CopyCreateRequestAllowedOriginsList>;
export type CopyCreateRequestWatermark = ClipCreateRequestWatermark;
export declare const CopyCreateRequestWatermark: S.Schema<ClipCreateRequestWatermark>;
export interface CreateCopyRequest {
    /** The account identifier tag. */
    accountId: string;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: CopyCreateRequestAllowedOriginsList;
    /** A user-defined identifier for the media creator. */
    creator?: string;
    /** A video's URL. The server must be publicly routable and support `HTTP HEAD` requests and `HTTP GET` range requests. The server should respond to `HTTP HEAD` requests with a `content-range` header that includes the size of the file. This is the preferred field over `url`. */
    input?: string;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown;
    /** A video's name. Used for legacy compatibility. */
    name?: string;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number;
    /** A video's URL. The server must be publicly routable and support `HTTP HEAD` requests and `HTTP GET` range requests. The server should respond to `HTTP HEAD` requests with a `content-range` header that includes the size of the file. This field is deprecated in favor of `input`. */
    url?: string;
    watermark?: ClipCreateRequestWatermark;
    /** A user-defined identifier for the media creator. */
    uploadCreator?: string;
}
export declare const CreateCopyRequest: S.Schema<CreateCopyRequest>;
export type CopyCreateResponseAllowedOriginsList = Array<unknown>;
export declare const CopyCreateResponseAllowedOriginsList: S.Schema<CopyCreateResponseAllowedOriginsList>;
export type CopyCreateResponseInput = ClipCreateResponseInput;
export declare const CopyCreateResponseInput: S.Schema<ClipCreateResponseInput>;
export type CopyCreateResponsePlayback = ClipCreateResponsePlayback;
export declare const CopyCreateResponsePlayback: S.Schema<ClipCreateResponsePlayback>;
export type CopyCreateResponsePublicDetails = ClipCreateResponsePublicDetails;
export declare const CopyCreateResponsePublicDetails: S.Schema<ClipCreateResponsePublicDetails>;
export type CopyCreateResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export declare const CopyCreateResponseStatusState: any;
export interface CopyCreateResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null;
    /** Specifies the processing status for all quality levels for a video. */
    state?: CopyCreateResponseStatusState | null;
}
export declare const CopyCreateResponseStatus: S.Schema<CopyCreateResponseStatus>;
export type CopyCreateResponseWatermark = ClipCreateResponseWatermark;
export declare const CopyCreateResponseWatermark: S.Schema<ClipCreateResponseWatermark>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCopyResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: CopyCreateResponseAllowedOriginsList | null;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null;
    /** The date and time the media item was created. */
    created?: string | null;
    /** A user-defined identifier for the media creator. */
    creator?: string | null;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null;
    input?: ClipCreateResponseInput | null;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null;
    /** The date and time the media item was last modified. */
    modified?: string | null;
    playback?: ClipCreateResponsePlayback | null;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null;
    /** The size of the media item in bytes. */
    size?: number | null;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: CopyCreateResponseStatus | null;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null;
    watermark?: ClipCreateResponseWatermark | null;
}
export declare const CreateCopyResponse: S.Schema<CreateCopyResponse>;
export type DirectUploadCreateRequestAllowedOriginsList = Array<unknown>;
export declare const DirectUploadCreateRequestAllowedOriginsList: S.Schema<DirectUploadCreateRequestAllowedOriginsList>;
export type DirectUploadCreateRequestWatermark = ClipCreateRequestWatermark;
export declare const DirectUploadCreateRequestWatermark: S.Schema<ClipCreateRequestWatermark>;
export interface CreateDirectUploadRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds: number;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: DirectUploadCreateRequestAllowedOriginsList;
    /** A user-defined identifier for the media creator. */
    creator?: string;
    /** The date and time after upload when videos will not be accepted. */
    expiry?: string;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number;
    watermark?: ClipCreateRequestWatermark;
    /** A user-defined identifier for the media creator. */
    uploadCreator?: string;
}
export declare const CreateDirectUploadRequest: S.Schema<CreateDirectUploadRequest>;
export type DirectUploadCreateResponseWatermark = ClipCreateResponseWatermark;
export declare const DirectUploadCreateResponseWatermark: S.Schema<ClipCreateResponseWatermark>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDirectUploadResponse {
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
    /** The URL an unauthenticated upload can use for a single `HTTP POST multipart/form-data` request. */
    uploadURL?: string | null;
    watermark?: ClipCreateResponseWatermark | null;
}
export declare const CreateDirectUploadResponse: S.Schema<CreateDirectUploadResponse>;
export interface CreateDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const CreateDownloadRequest: S.Schema<CreateDownloadRequest>;
export type DownloadsCreateResponseAudioStatus = "ready" | "inprogress" | "error";
export declare const DownloadsCreateResponseAudioStatus: any;
export interface DownloadsCreateResponseAudio {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsCreateResponseAudioStatus;
    /** The URL to access the generated download. */
    url?: string | null;
}
export declare const DownloadsCreateResponseAudio: S.Schema<DownloadsCreateResponseAudio>;
export type DownloadsCreateResponseDefaultStatus = "ready" | "inprogress" | "error";
export declare const DownloadsCreateResponseDefaultStatus: any;
export interface DownloadsCreateResponseDefault {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsCreateResponseDefaultStatus;
    /** The URL to access the generated download. */
    url?: string | null;
}
export declare const DownloadsCreateResponseDefault: S.Schema<DownloadsCreateResponseDefault>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateDownloadResponse {
    /** The audio-only download. Only present if this download type has been created. */
    audio?: DownloadsCreateResponseAudio | null;
    /** The default video download. Only present if this download type has been created. */
    default?: DownloadsCreateResponseDefault | null;
}
export declare const CreateDownloadResponse: S.Schema<CreateDownloadResponse>;
export interface CreateKeyRequest {
    /** Identifier. */
    accountId: string;
}
export declare const CreateKeyRequest: S.Schema<CreateKeyRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateKeyResponse {
    /** Identifier. */
    id?: string | null;
    /** The date and time a signing key was created. */
    created?: string | null;
    /** The signing key in JWK format. */
    jwk?: string | null;
    /** The signing key in PEM format. */
    pem?: string | null;
}
export declare const CreateKeyResponse: S.Schema<CreateKeyResponse>;
export type LiveInputsCreateRequestRecordingAllowedOriginsList = Array<string>;
export declare const LiveInputsCreateRequestRecordingAllowedOriginsList: S.Schema<LiveInputsCreateRequestRecordingAllowedOriginsList>;
export type LiveInputsCreateRequestRecordingMode = "off" | "automatic";
export declare const LiveInputsCreateRequestRecordingMode: any;
export interface LiveInputsCreateRequestRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsCreateRequestRecordingAllowedOriginsList;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsCreateRequestRecordingMode | (string & {});
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number;
}
export declare const LiveInputsCreateRequestRecording: S.Schema<LiveInputsCreateRequestRecording>;
export interface CreateLiveInputRequest {
    /** Identifier. */
    accountId: string;
    /** Sets the creator ID asssociated with this live input. */
    defaultCreator?: string;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsCreateRequestRecording;
}
export declare const CreateLiveInputRequest: S.Schema<CreateLiveInputRequest>;
export type LiveInputsCreateResponseRecordingAllowedOriginsList = Array<string>;
export declare const LiveInputsCreateResponseRecordingAllowedOriginsList: S.Schema<LiveInputsCreateResponseRecordingAllowedOriginsList>;
export type LiveInputsCreateResponseRecordingMode = "off" | "automatic";
export declare const LiveInputsCreateResponseRecordingMode: any;
export interface LiveInputsCreateResponseRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsCreateResponseRecordingAllowedOriginsList | null;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | null;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsCreateResponseRecordingMode | null;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | null;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | null;
}
export declare const LiveInputsCreateResponseRecording: S.Schema<LiveInputsCreateResponseRecording>;
export interface LiveInputsCreateResponseRtmps {
    /** The secret key to use when streaming via RTMPS to a live input. */
    streamKey?: string | null;
    /** The RTMPS URL you provide to the broadcaster, which they stream live video to. */
    url?: string | null;
}
export declare const LiveInputsCreateResponseRtmps: S.Schema<LiveInputsCreateResponseRtmps>;
export interface LiveInputsCreateResponseRtmpsPlayback {
    /** The secret key to use for playback via RTMPS. */
    streamKey?: string | null;
    /** The URL used to play live video over RTMPS. */
    url?: string | null;
}
export declare const LiveInputsCreateResponseRtmpsPlayback: S.Schema<LiveInputsCreateResponseRtmpsPlayback>;
export interface LiveInputsCreateResponseSrt {
    /** The secret key to use when streaming via SRT to a live input. */
    passphrase?: string | null;
    /** The identifier of the live input to use when streaming via SRT. */
    streamId?: string | null;
    /** The SRT URL you provide to the broadcaster, which they stream live video to. */
    url?: string | null;
}
export declare const LiveInputsCreateResponseSrt: S.Schema<LiveInputsCreateResponseSrt>;
export interface LiveInputsCreateResponseSrtPlayback {
    /** The secret key to use for playback via SRT. */
    passphrase?: string | null;
    /** The identifier of the live input to use for playback via SRT. */
    streamId?: string | null;
    /** The URL used to play live video over SRT. */
    url?: string | null;
}
export declare const LiveInputsCreateResponseSrtPlayback: S.Schema<LiveInputsCreateResponseSrtPlayback>;
export type LiveInputsCreateResponseStatus = "connected" | "reconnected" | "reconnecting" | "client_disconnect" | "ttl_exceeded" | "failed_to_connect" | "failed_to_reconnect" | "new_configuration_accepted";
export declare const LiveInputsCreateResponseStatus: any;
export interface LiveInputsCreateResponseWebRTC {
    /** The WebRTC URL you provide to the broadcaster, which they stream live video to. */
    url?: string | null;
}
export declare const LiveInputsCreateResponseWebRTC: S.Schema<LiveInputsCreateResponseWebRTC>;
export interface LiveInputsCreateResponseWebRTCPlayback {
    /** The URL used to play live video over WebRTC. */
    url?: string | null;
}
export declare const LiveInputsCreateResponseWebRTCPlayback: S.Schema<LiveInputsCreateResponseWebRTCPlayback>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLiveInputResponse {
    /** The date and time the live input was created. */
    created?: string | null;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null;
    /** The date and time the live input keys were last rotated. Omitted for live inputs that have never had their keys rotated. */
    keysRotatedAt?: string | null;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null;
    /** The date and time the live input was last modified. */
    modified?: string | null;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | null;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsCreateResponseRecording | null;
    /** Details for streaming to an live input using RTMPS. */
    rtmps?: LiveInputsCreateResponseRtmps | null;
    /** Details for playback from an live input using RTMPS. */
    rtmpsPlayback?: LiveInputsCreateResponseRtmpsPlayback | null;
    /** Details for streaming to a live input using SRT. */
    srt?: LiveInputsCreateResponseSrt | null;
    /** Details for playback from an live input using SRT. */
    srtPlayback?: LiveInputsCreateResponseSrtPlayback | null;
    /** The connection status of a live input. */
    status?: LiveInputsCreateResponseStatus | null;
    /** A unique identifier for a live input. */
    uid?: string | null;
    /** Details for streaming to a live input using WebRTC. */
    webRTC?: LiveInputsCreateResponseWebRTC | null;
    /** Details for playback from a live input using WebRTC. */
    webRTCPlayback?: LiveInputsCreateResponseWebRTCPlayback | null;
}
export declare const CreateLiveInputResponse: S.Schema<CreateLiveInputResponse>;
export interface CreateLiveInputOutputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** The streamKey used to authenticate against an output's target. */
    streamKey: string;
    /** The URL an output uses to restream. */
    url: string;
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean;
}
export declare const CreateLiveInputOutputRequest: S.Schema<CreateLiveInputOutputRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLiveInputOutputResponse {
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean | null;
    /** The streamKey used to authenticate against an output's target. */
    streamKey?: string | null;
    /** A unique identifier for the output. */
    uid?: string | null;
    /** The URL an output uses to restream. */
    url?: string | null;
}
export declare const CreateLiveInputOutputResponse: S.Schema<CreateLiveInputOutputResponse>;
export type CreateRequestTusResumable = "1.0.0";
export declare const CreateRequestTusResumable: any;
export interface CreateStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** Provisions a URL to let your end users upload videos directly to Cloudflare Stream without exposing your API token to clients. */
    directUser?: boolean;
    /** Specifies the TUS protocol version. This value must be included in every upload request. */
    tusResumable: CreateRequestTusResumable | (string & {});
    /** Indicates the size of the entire upload in bytes. The value must be a non-negative integer. */
    uploadLength: number;
    /** A user-defined identifier for the media creator. */
    uploadCreator?: string;
    /** Comma-separated key-value pairs following the TUS protocol specification. Values are Base-64 encoded. */
    uploadMetadata?: string;
}
export declare const CreateStreamRequest: S.Schema<CreateStreamRequest>;
export interface CreateStreamResponse {
}
export declare const CreateStreamResponse: S.Schema<CreateStreamResponse>;
export type TokenCreateRequestAccessRulesItemAction = "allow" | "block";
export declare const TokenCreateRequestAccessRulesItemAction: any;
export type TokenCreateRequestAccessRulesItemCountryList = Array<string>;
export declare const TokenCreateRequestAccessRulesItemCountryList: S.Schema<TokenCreateRequestAccessRulesItemCountryList>;
export type TokenCreateRequestAccessRulesItemIpList = Array<string>;
export declare const TokenCreateRequestAccessRulesItemIpList: S.Schema<TokenCreateRequestAccessRulesItemIpList>;
export type TokenCreateRequestAccessRulesItemType = "any" | "ip.src" | "ip.geoip.country";
export declare const TokenCreateRequestAccessRulesItemType: any;
export interface TokenCreateRequestAccessRulesItem {
    /** The action to take when a request matches a rule. If the action is `block`, the signed token blocks views for viewers matching the rule. */
    action?: TokenCreateRequestAccessRulesItemAction | (string & {});
    /** An array of 2-letter country codes in ISO 3166-1 Alpha-2 format used to match requests. */
    country?: TokenCreateRequestAccessRulesItemCountryList;
    /** An array of IPv4 or IPV6 addresses or CIDRs used to match requests. */
    ip?: TokenCreateRequestAccessRulesItemIpList;
    /** Lists available rule types to match for requests. An `any` type matches all requests and can be used as a wildcard to apply default actions after other rules. */
    type?: TokenCreateRequestAccessRulesItemType | (string & {});
}
export declare const TokenCreateRequestAccessRulesItem: S.Schema<TokenCreateRequestAccessRulesItem>;
export type TokenCreateRequestAccessRulesList = Array<TokenCreateRequestAccessRulesItem>;
export declare const TokenCreateRequestAccessRulesList: S.Schema<TokenCreateRequestAccessRulesList>;
export interface TokenCreateRequestFlags {
    /** Whether to return the original video without transformations. */
    original?: boolean;
}
export declare const TokenCreateRequestFlags: S.Schema<TokenCreateRequestFlags>;
export interface CreateTokenRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The optional ID of a Stream signing key. If present, the `pem` field is also required. */
    id?: string;
    /** The optional list of access rule constraints on the token. Access can be blocked or allowed based on an IP, IP range, or by country. Access rules are evaluated from first to last. If a rule matches, the associated action is applied and no further rules are evaluated. */
    accessRules?: TokenCreateRequestAccessRulesList;
    /** The optional boolean value that enables using signed tokens to access MP4 download links for a video. */
    downloadable?: boolean;
    /** The optional unix epoch timestamp that specficies the time after a token is not accepted. The maximum time specification is 24 hours from issuing time. If this field is not set, the default is one hour after issuing. */
    exp?: number;
    /** Optional flags for the signed token. */
    flags?: TokenCreateRequestFlags;
    /** The optional unix epoch timestamp that specifies the time before a the token is not accepted. If this field is not set, the default is one hour before issuing. */
    nbf?: number;
    /** The optional base64 encoded private key in PEM format associated with a Stream signing key. If present, the `id` field is also required. */
    pem?: string;
}
export declare const CreateTokenRequest: S.Schema<CreateTokenRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** The signed token used with the signed URLs feature. */
    token?: string | null;
}
export declare const CreateTokenResponse: S.Schema<CreateTokenResponse>;
export interface CreateWatermarkRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A short description of the watermark profile. */
    name?: string;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0`fills the entire video. */
    scale?: number;
    /** URL of the watermark image to copy. */
    url?: string;
}
export declare const CreateWatermarkRequest: S.Schema<CreateWatermarkRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateWatermarkResponse {
    /** The date and a time a watermark profile was created. */
    created?: string | null;
    /** The source URL for a downloaded image. If the watermark profile was created via direct upload, this field is null. */
    downloadedFrom?: string | null;
    /** The height of the image in pixels. */
    height?: number | null;
    /** A short description of the watermark profile. */
    name?: string | null;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number | null;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number | null;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string | null;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0`fills the entire video. */
    scale?: number | null;
    /** The size of the image in bytes. */
    size?: number | null;
    /** The unique identifier for a watermark profile. */
    uid?: string | null;
    /** The width of the image in pixels. */
    width?: number | null;
}
export declare const CreateWatermarkResponse: S.Schema<CreateWatermarkResponse>;
export interface DeleteAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The unique identifier for an additional audio track. */
    audioIdentifier: string;
}
export declare const DeleteAudioTrackRequest: S.Schema<DeleteAudioTrackRequest>;
export type DeleteAudioTrackResponse = string;
export declare const DeleteAudioTrackResponse: S.Schema<DeleteAudioTrackResponse>;
export interface DeleteCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export declare const DeleteCaptionLanguageRequest: S.Schema<DeleteCaptionLanguageRequest>;
export type DeleteCaptionLanguageResponse = string;
export declare const DeleteCaptionLanguageResponse: S.Schema<DeleteCaptionLanguageResponse>;
export interface DeleteDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const DeleteDownloadRequest: S.Schema<DeleteDownloadRequest>;
export type DeleteDownloadResponse = string;
export declare const DeleteDownloadResponse: S.Schema<DeleteDownloadResponse>;
export interface DeleteKeyRequest {
    /** Identifier. */
    accountId: string;
    /** Identifier. */
    identifier: string;
}
export declare const DeleteKeyRequest: S.Schema<DeleteKeyRequest>;
export type DeleteKeyResponse = string;
export declare const DeleteKeyResponse: S.Schema<DeleteKeyResponse>;
export interface DeleteLiveInputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
}
export declare const DeleteLiveInputRequest: S.Schema<DeleteLiveInputRequest>;
export interface DeleteLiveInputResponse {
}
export declare const DeleteLiveInputResponse: S.Schema<DeleteLiveInputResponse>;
export interface DeleteLiveInputOutputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** A unique identifier for the output. */
    outputIdentifier: string;
}
export declare const DeleteLiveInputOutputRequest: S.Schema<DeleteLiveInputOutputRequest>;
export interface DeleteLiveInputOutputResponse {
}
export declare const DeleteLiveInputOutputResponse: S.Schema<DeleteLiveInputOutputResponse>;
export interface DeleteStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const DeleteStreamRequest: S.Schema<DeleteStreamRequest>;
export interface DeleteStreamResponse {
}
export declare const DeleteStreamResponse: S.Schema<DeleteStreamResponse>;
export interface DeleteWatermarkRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The unique identifier for a watermark profile. */
    identifier: string;
}
export declare const DeleteWatermarkRequest: S.Schema<DeleteWatermarkRequest>;
export type DeleteWatermarkResponse = string;
export declare const DeleteWatermarkResponse: S.Schema<DeleteWatermarkResponse>;
export interface DeleteWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
}
export declare const DeleteWebhookRequest: S.Schema<DeleteWebhookRequest>;
export type DeleteWebhookResponse = string;
export declare const DeleteWebhookResponse: S.Schema<DeleteWebhookResponse>;
export type EditRequestAllowedOriginsList = Array<unknown>;
export declare const EditRequestAllowedOriginsList: S.Schema<EditRequestAllowedOriginsList>;
export interface EditRequestPublicDetails {
    channelLink?: string;
    logo?: string;
    shareLink?: string;
    title?: string;
}
export declare const EditRequestPublicDetails: S.Schema<EditRequestPublicDetails>;
export interface EditStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: EditRequestAllowedOriginsList;
    /** A user-defined identifier for the media creator. */
    creator?: string;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: EditRequestPublicDetails;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number;
    /** The unique identifier for the video. Can be used to verify the video being updated. */
    uid?: string;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string;
}
export declare const EditStreamRequest: S.Schema<EditStreamRequest>;
export type EditResponseAllowedOriginsList = Array<unknown>;
export declare const EditResponseAllowedOriginsList: S.Schema<EditResponseAllowedOriginsList>;
export type EditResponseInput = ClipCreateResponseInput;
export declare const EditResponseInput: S.Schema<ClipCreateResponseInput>;
export type EditResponsePlayback = ClipCreateResponsePlayback;
export declare const EditResponsePlayback: S.Schema<ClipCreateResponsePlayback>;
export type EditResponsePublicDetails = ClipCreateResponsePublicDetails;
export declare const EditResponsePublicDetails: S.Schema<ClipCreateResponsePublicDetails>;
export type EditResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export declare const EditResponseStatusState: any;
export interface EditResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null;
    /** Specifies the processing status for all quality levels for a video. */
    state?: EditResponseStatusState | null;
}
export declare const EditResponseStatus: S.Schema<EditResponseStatus>;
export type EditResponseWatermark = ClipCreateResponseWatermark;
export declare const EditResponseWatermark: S.Schema<ClipCreateResponseWatermark>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface EditStreamResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: EditResponseAllowedOriginsList | null;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null;
    /** The date and time the media item was created. */
    created?: string | null;
    /** A user-defined identifier for the media creator. */
    creator?: string | null;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null;
    input?: ClipCreateResponseInput | null;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null;
    /** The date and time the media item was last modified. */
    modified?: string | null;
    playback?: ClipCreateResponsePlayback | null;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null;
    /** The size of the media item in bytes. */
    size?: number | null;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: EditResponseStatus | null;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null;
    watermark?: ClipCreateResponseWatermark | null;
}
export declare const EditStreamResponse: S.Schema<EditStreamResponse>;
export interface GetAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const GetAudioTrackRequest: S.Schema<GetAudioTrackRequest>;
export type AudioTracksGetResponseAudioItemStatus = "queued" | "ready" | "error";
export declare const AudioTracksGetResponseAudioItemStatus: any;
export interface AudioTracksGetResponseAudioItem {
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean | null;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string | null;
    /** Specifies the processing status of the video. */
    status?: AudioTracksGetResponseAudioItemStatus | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
}
export declare const AudioTracksGetResponseAudioItem: S.Schema<AudioTracksGetResponseAudioItem>;
export type AudioTracksGetResponseAudioList = Array<AudioTracksGetResponseAudioItem>;
export declare const AudioTracksGetResponseAudioList: S.Schema<AudioTracksGetResponseAudioList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAudioTrackResponse {
    /** Array of audio tracks for the video. */
    audio?: AudioTracksGetResponseAudioList | null;
}
export declare const GetAudioTrackResponse: S.Schema<GetAudioTrackResponse>;
export interface GetCaptionRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const GetCaptionRequest: S.Schema<GetCaptionRequest>;
export type CaptionsGetResultItemStatus = "ready" | "inprogress" | "error";
export declare const CaptionsGetResultItemStatus: any;
export interface CaptionsGetResultItem {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null;
    /** The language label displayed in the native language to users. */
    label?: string | null;
    /** The language tag in BCP 47 format. */
    language?: string | null;
    /** The status of a generated caption. */
    status?: CaptionsGetResultItemStatus | null;
}
export declare const CaptionsGetResultItem: S.Schema<CaptionsGetResultItem>;
export type CaptionsGetResultList = Array<CaptionsGetResultItem>;
export declare const CaptionsGetResultList: S.Schema<CaptionsGetResultList>;
export interface GetCaptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CaptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetCaptionResponse: S.Schema<GetCaptionResponse>;
export interface GetCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export declare const GetCaptionLanguageRequest: S.Schema<GetCaptionLanguageRequest>;
export type CaptionsLanguageGetResponseStatus = "ready" | "inprogress" | "error";
export declare const CaptionsLanguageGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCaptionLanguageResponse {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null;
    /** The language label displayed in the native language to users. */
    label?: string | null;
    /** The language tag in BCP 47 format. */
    language?: string | null;
    /** The status of a generated caption. */
    status?: CaptionsLanguageGetResponseStatus | null;
}
export declare const GetCaptionLanguageResponse: S.Schema<GetCaptionLanguageResponse>;
export interface GetCaptionLanguageVttRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export declare const GetCaptionLanguageVttRequest: S.Schema<GetCaptionLanguageVttRequest>;
export interface GetCaptionLanguageVttResponse {
}
export declare const GetCaptionLanguageVttResponse: S.Schema<GetCaptionLanguageVttResponse>;
export interface GetDownloadRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const GetDownloadRequest: S.Schema<GetDownloadRequest>;
export type DownloadsGetResponseAudioStatus = "ready" | "inprogress" | "error";
export declare const DownloadsGetResponseAudioStatus: any;
export interface DownloadsGetResponseAudio {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsGetResponseAudioStatus;
    /** The URL to access the generated download. */
    url?: string | null;
}
export declare const DownloadsGetResponseAudio: S.Schema<DownloadsGetResponseAudio>;
export type DownloadsGetResponseDefaultStatus = "ready" | "inprogress" | "error";
export declare const DownloadsGetResponseDefaultStatus: any;
export interface DownloadsGetResponseDefault {
    /** Indicates the progress as a percentage between 0 and 100. */
    percentComplete: number;
    /** The status of a generated download. */
    status: DownloadsGetResponseDefaultStatus;
    /** The URL to access the generated download. */
    url?: string | null;
}
export declare const DownloadsGetResponseDefault: S.Schema<DownloadsGetResponseDefault>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetDownloadResponse {
    /** The audio-only download. Only present if this download type has been created. */
    audio?: DownloadsGetResponseAudio | null;
    /** The default video download. Only present if this download type has been created. */
    default?: DownloadsGetResponseDefault | null;
}
export declare const GetDownloadResponse: S.Schema<GetDownloadResponse>;
export interface GetEmbedRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const GetEmbedRequest: S.Schema<GetEmbedRequest>;
export interface GetEmbedResponse {
}
export declare const GetEmbedResponse: S.Schema<GetEmbedResponse>;
export interface GetKeyRequest {
    /** Identifier. */
    accountId: string;
}
export declare const GetKeyRequest: S.Schema<GetKeyRequest>;
export interface KeysGetResultItem {
    /** Identifier. */
    id?: string | null;
    /** The date and time a signing key was created. */
    created?: string | null;
    /** The unique identifier for the signing key. */
    keyId?: string | null;
}
export declare const KeysGetResultItem: S.Schema<KeysGetResultItem>;
export type KeysGetResultList = Array<KeysGetResultItem>;
export declare const KeysGetResultList: S.Schema<KeysGetResultList>;
export interface GetKeyResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: KeysGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetKeyResponse: S.Schema<GetKeyResponse>;
export interface GetLiveInputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
}
export declare const GetLiveInputRequest: S.Schema<GetLiveInputRequest>;
export type LiveInputsGetResponseRecordingAllowedOriginsList = Array<string>;
export declare const LiveInputsGetResponseRecordingAllowedOriginsList: S.Schema<LiveInputsGetResponseRecordingAllowedOriginsList>;
export type LiveInputsGetResponseRecordingMode = "off" | "automatic";
export declare const LiveInputsGetResponseRecordingMode: any;
export interface LiveInputsGetResponseRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsGetResponseRecordingAllowedOriginsList | null;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | null;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsGetResponseRecordingMode | null;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | null;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | null;
}
export declare const LiveInputsGetResponseRecording: S.Schema<LiveInputsGetResponseRecording>;
export type LiveInputsGetResponseRtmps = LiveInputsCreateResponseRtmps;
export declare const LiveInputsGetResponseRtmps: S.Schema<LiveInputsCreateResponseRtmps>;
export type LiveInputsGetResponseRtmpsPlayback = LiveInputsCreateResponseRtmpsPlayback;
export declare const LiveInputsGetResponseRtmpsPlayback: S.Schema<LiveInputsCreateResponseRtmpsPlayback>;
export type LiveInputsGetResponseSrt = LiveInputsCreateResponseSrt;
export declare const LiveInputsGetResponseSrt: S.Schema<LiveInputsCreateResponseSrt>;
export type LiveInputsGetResponseSrtPlayback = LiveInputsCreateResponseSrtPlayback;
export declare const LiveInputsGetResponseSrtPlayback: S.Schema<LiveInputsCreateResponseSrtPlayback>;
export type LiveInputsGetResponseStatus = "connected" | "reconnected" | "reconnecting" | "client_disconnect" | "ttl_exceeded" | "failed_to_connect" | "failed_to_reconnect" | "new_configuration_accepted";
export declare const LiveInputsGetResponseStatus: any;
export type LiveInputsGetResponseWebRTC = LiveInputsCreateResponseWebRTC;
export declare const LiveInputsGetResponseWebRTC: S.Schema<LiveInputsCreateResponseWebRTC>;
export type LiveInputsGetResponseWebRTCPlayback = LiveInputsCreateResponseWebRTCPlayback;
export declare const LiveInputsGetResponseWebRTCPlayback: S.Schema<LiveInputsCreateResponseWebRTCPlayback>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLiveInputResponse {
    /** The date and time the live input was created. */
    created?: string | null;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null;
    /** The date and time the live input keys were last rotated. Omitted for live inputs that have never had their keys rotated. */
    keysRotatedAt?: string | null;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null;
    /** The date and time the live input was last modified. */
    modified?: string | null;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | null;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsGetResponseRecording | null;
    /** Details for streaming to an live input using RTMPS. */
    rtmps?: LiveInputsCreateResponseRtmps | null;
    /** Details for playback from an live input using RTMPS. */
    rtmpsPlayback?: LiveInputsCreateResponseRtmpsPlayback | null;
    /** Details for streaming to a live input using SRT. */
    srt?: LiveInputsCreateResponseSrt | null;
    /** Details for playback from an live input using SRT. */
    srtPlayback?: LiveInputsCreateResponseSrtPlayback | null;
    /** The connection status of a live input. */
    status?: LiveInputsGetResponseStatus | null;
    /** A unique identifier for a live input. */
    uid?: string | null;
    /** Details for streaming to a live input using WebRTC. */
    webRTC?: LiveInputsCreateResponseWebRTC | null;
    /** Details for playback from a live input using WebRTC. */
    webRTCPlayback?: LiveInputsCreateResponseWebRTCPlayback | null;
}
export declare const GetLiveInputResponse: S.Schema<GetLiveInputResponse>;
export interface GetStreamRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
}
export declare const GetStreamRequest: S.Schema<GetStreamRequest>;
export type GetResponseAllowedOriginsList = Array<unknown>;
export declare const GetResponseAllowedOriginsList: S.Schema<GetResponseAllowedOriginsList>;
export type GetResponseInput = ClipCreateResponseInput;
export declare const GetResponseInput: S.Schema<ClipCreateResponseInput>;
export type GetResponsePlayback = ClipCreateResponsePlayback;
export declare const GetResponsePlayback: S.Schema<ClipCreateResponsePlayback>;
export type GetResponsePublicDetails = ClipCreateResponsePublicDetails;
export declare const GetResponsePublicDetails: S.Schema<ClipCreateResponsePublicDetails>;
export type GetResponseStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export declare const GetResponseStatusState: any;
export interface GetResponseStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null;
    /** Specifies the processing status for all quality levels for a video. */
    state?: GetResponseStatusState | null;
}
export declare const GetResponseStatus: S.Schema<GetResponseStatus>;
export type GetResponseWatermark = ClipCreateResponseWatermark;
export declare const GetResponseWatermark: S.Schema<ClipCreateResponseWatermark>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetStreamResponse {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: GetResponseAllowedOriginsList | null;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null;
    /** The date and time the media item was created. */
    created?: string | null;
    /** A user-defined identifier for the media creator. */
    creator?: string | null;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null;
    input?: ClipCreateResponseInput | null;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null;
    /** The date and time the media item was last modified. */
    modified?: string | null;
    playback?: ClipCreateResponsePlayback | null;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null;
    /** The size of the media item in bytes. */
    size?: number | null;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: GetResponseStatus | null;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null;
    watermark?: ClipCreateResponseWatermark | null;
}
export declare const GetStreamResponse: S.Schema<GetStreamResponse>;
export interface GetWatermarkRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The unique identifier for a watermark profile. */
    identifier: string;
}
export declare const GetWatermarkRequest: S.Schema<GetWatermarkRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWatermarkResponse {
    /** The date and a time a watermark profile was created. */
    created?: string | null;
    /** The source URL for a downloaded image. If the watermark profile was created via direct upload, this field is null. */
    downloadedFrom?: string | null;
    /** The height of the image in pixels. */
    height?: number | null;
    /** A short description of the watermark profile. */
    name?: string | null;
    /** The translucency of the image. A value of `0.0` makes the image completely transparent, and `1.0` makes the image completely opaque. Note that if the image is already semi-transparent, setting this to `1.0` will not make the image completely opaque. */
    opacity?: number | null;
    /** The whitespace between the adjacent edges (determined by position) of the video and the image. `0.0` indicates no padding, and `1.0` indicates a fully padded video width or length, as determined by the algorithm. */
    padding?: number | null;
    /** The location of the image. Valid positions are: `upperRight`, `upperLeft`, `lowerLeft`, `lowerRight`, and `center`. Note that `center` ignores the `padding` parameter. */
    position?: string | null;
    /** The size of the image relative to the overall size of the video. This parameter will adapt to horizontal and vertical videos automatically. `0.0` indicates no scaling (use the size of the image as-is), and `1.0`fills the entire video. */
    scale?: number | null;
    /** The size of the image in bytes. */
    size?: number | null;
    /** The unique identifier for a watermark profile. */
    uid?: string | null;
    /** The width of the image in pixels. */
    width?: number | null;
}
export declare const GetWatermarkResponse: S.Schema<GetWatermarkResponse>;
export interface GetWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
}
export declare const GetWebhookRequest: S.Schema<GetWebhookRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWebhookResponse {
    /** The date and time the webhook was last modified. */
    modified?: string | null;
    /** The URL where webhooks will be sent. */
    notificationUrl?: string | null;
    /** The secret used to verify webhook signatures. */
    secret?: string | null;
}
export declare const GetWebhookResponse: S.Schema<GetWebhookResponse>;
export interface ListLiveInputOutputsRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
}
export declare const ListLiveInputOutputsRequest: S.Schema<ListLiveInputOutputsRequest>;
export interface LiveInputsOutputsListResultItem {
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean | null;
    /** The streamKey used to authenticate against an output's target. */
    streamKey?: string | null;
    /** A unique identifier for the output. */
    uid?: string | null;
    /** The URL an output uses to restream. */
    url?: string | null;
}
export declare const LiveInputsOutputsListResultItem: S.Schema<LiveInputsOutputsListResultItem>;
export type LiveInputsOutputsListResultList = Array<LiveInputsOutputsListResultItem>;
export declare const LiveInputsOutputsListResultList: S.Schema<LiveInputsOutputsListResultList>;
export interface ListLiveInputOutputsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LiveInputsOutputsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLiveInputOutputsResponse: S.Schema<ListLiveInputOutputsResponse>;
export interface ListLiveInputsRequest {
    /** Identifier. */
    accountId: string;
    /** Includes the total number of videos associated with the submitted query parameters. */
    includeCounts?: boolean;
}
export declare const ListLiveInputsRequest: S.Schema<ListLiveInputsRequest>;
export interface LiveInputsListResponseLiveInputsItem {
    /** The date and time the live input was created. */
    created?: string | null;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null;
    /** The date and time the live input was last modified. */
    modified?: string | null;
    /** A unique identifier for a live input. */
    uid?: string | null;
}
export declare const LiveInputsListResponseLiveInputsItem: S.Schema<LiveInputsListResponseLiveInputsItem>;
export type LiveInputsListResponseLiveInputsList = Array<LiveInputsListResponseLiveInputsItem>;
export declare const LiveInputsListResponseLiveInputsList: S.Schema<LiveInputsListResponseLiveInputsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListLiveInputsResponse {
    liveInputs?: LiveInputsListResponseLiveInputsList | null;
    /** The total number of remaining live inputs based on cursor position. */
    range?: number | null;
    /** The total number of live inputs that match the provided filters. */
    total?: number | null;
}
export declare const ListLiveInputsResponse: S.Schema<ListLiveInputsResponse>;
export type ListRequestStatus = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export declare const ListRequestStatus: any;
export interface ListStreamsRequest {
    /** The account identifier tag. */
    accountId: string;
    /** Filter by video ID(s). Can be a single ID or a comma-separated list of IDs. */
    id?: string;
    /** Alias for 'start'. Returns videos created after this date/time (RFC 3339 format). */
    after?: string;
    /** Lists videos in ascending order of creation. */
    asc?: boolean;
    /** Alias for 'end'. Returns videos created before this date/time (RFC 3339 format). */
    before?: string;
    /** A user-defined identifier for the media creator. */
    creator?: string;
    /** Lists videos created before the specified date. */
    end?: string;
    /** Includes the total number of videos associated with the submitted query parameters. */
    includeCounts?: boolean;
    /** Maximum number of videos to return (default 1000, max 1000). */
    limit?: number;
    /** Filter by live input ID to find videos associated with a specific live stream. */
    liveInputId?: string;
    /** Filter by video name/UID(s). Can be a single name or a comma-separated list. */
    name?: string;
    /** Provides a partial word match of the `name` key in the `meta` field. Slow for medium to large video libraries. May be unavailable for very large libraries. */
    search?: string;
    /** Lists videos created after the specified date. */
    start?: string;
    /** Specifies the processing status for all quality levels for a video. */
    status?: ListRequestStatus | (string & {});
    /** Specifies whether the video is `vod` or `live`. */
    type?: string;
    /** Provides a fast, exact string match on the `name` key in the `meta` field. */
    videoName?: string;
}
export declare const ListStreamsRequest: S.Schema<ListStreamsRequest>;
export type ListResultItemAllowedOriginsList = Array<unknown>;
export declare const ListResultItemAllowedOriginsList: S.Schema<ListResultItemAllowedOriginsList>;
export type ListResultItemInput = ClipCreateResponseInput;
export declare const ListResultItemInput: S.Schema<ClipCreateResponseInput>;
export type ListResultItemPlayback = ClipCreateResponsePlayback;
export declare const ListResultItemPlayback: S.Schema<ClipCreateResponsePlayback>;
export type ListResultItemPublicDetails = ClipCreateResponsePublicDetails;
export declare const ListResultItemPublicDetails: S.Schema<ClipCreateResponsePublicDetails>;
export type ListResultItemStatusState = "pendingupload" | "downloading" | "queued" | "inprogress" | "ready" | "error" | "live-inprogress";
export declare const ListResultItemStatusState: any;
export interface ListResultItemStatus {
    /** Specifies why the video failed to encode. This field is empty if the video is not in an `error` state. Preferred for programmatic use. */
    errorReasonCode?: string | null;
    /** Specifies why the video failed to encode using a human readable error message in English. This field is empty if the video is not in an `error` state. */
    errorReasonText?: string | null;
    /** Indicates the progress as a percentage between 0 and 100. */
    pctComplete?: string | null;
    /** Specifies the processing status for all quality levels for a video. */
    state?: ListResultItemStatusState | null;
}
export declare const ListResultItemStatus: S.Schema<ListResultItemStatus>;
export type ListResultItemWatermark = ClipCreateResponseWatermark;
export declare const ListResultItemWatermark: S.Schema<ClipCreateResponseWatermark>;
export interface ListResultItem {
    /** Lists the origins allowed to display the video. Enter allowed origin domains in an array and use `*` for wildcard subdomains. Empty arrays allow the video to be viewed on any origin. */
    allowedOrigins?: ListResultItemAllowedOriginsList | null;
    /** The unique identifier of the source video this video was clipped from. */
    clippedFrom?: string | null;
    /** The date and time the media item was created. */
    created?: string | null;
    /** A user-defined identifier for the media creator. */
    creator?: string | null;
    /** The duration of the video in seconds. A value of `-1` means the duration is unknown. The duration becomes available after the upload and before the video is ready. */
    duration?: number | null;
    input?: ClipCreateResponseInput | null;
    /** The live input ID used to upload a video with Stream Live. */
    liveInput?: string | null;
    /** The maximum duration in seconds for a video upload. Can be set for a video that is not yet uploaded to limit its duration. Uploads that exceed the specified duration will fail during processing. A value of `-1` means the value is unknown. */
    maxDurationSeconds?: number | null;
    /** The maximum size in bytes for the video upload. */
    maxSizeBytes?: number | null;
    /** A user modifiable key-value store used to reference other systems of record for managing videos. */
    meta?: unknown | null;
    /** The date and time the media item was last modified. */
    modified?: string | null;
    playback?: ClipCreateResponsePlayback | null;
    /** The video's preview page URI. This field is omitted until encoding is complete. */
    preview?: string | null;
    /** Public details for the video including title, share link, channel link, and logo. */
    publicDetails?: ClipCreateResponsePublicDetails | null;
    /** Indicates whether the video is playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStream?: boolean | null;
    /** Indicates the time at which the video became playable. The field is empty if the video is not ready for viewing or the live stream is still in progress. */
    readyToStreamAt?: string | null;
    /** Indicates whether the video can be a accessed using the UID. When set to `true`, a signed token must be generated with a signing key to view the video. */
    requireSignedURLs?: boolean | null;
    /** Indicates the date and time at which the video will be deleted. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. If specified, must be at least 30 days from upload time. */
    scheduledDeletion?: string | null;
    /** The size of the media item in bytes. */
    size?: number | null;
    /** Specifies a detailed status for a video. If the `state` is `inprogress` or `error`, the `step` field returns `encoding` or `manifest`. If the `state` is `inprogress`, `pctComplete` returns a number between 0 and 100 to indicate the approximate percent of completion. If the `state` is `error`, `errorReasonCode` and `errorReasonText` provide additional details. */
    status?: ListResultItemStatus | null;
    /** The media item's thumbnail URI. This field is omitted until encoding is complete. */
    thumbnail?: string | null;
    /** The timestamp for a thumbnail image calculated as a percentage value of the video's duration. To convert from a second-wise timestamp to a percentage, divide the desired timestamp by the total duration of the video. If this value is not set, the default thumbnail image is taken from 0s of the video. */
    thumbnailTimestampPct?: number | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
    /** The date and time the media item was uploaded. */
    uploaded?: string | null;
    /** The date and time when the video upload URL is no longer valid for direct user uploads. */
    uploadExpiry?: string | null;
    watermark?: ClipCreateResponseWatermark | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListStreamsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListStreamsResponse: S.Schema<ListStreamsResponse>;
export interface ListWatermarksRequest {
    /** The account identifier tag. */
    accountId: string;
}
export declare const ListWatermarksRequest: S.Schema<ListWatermarksRequest>;
export type WatermarksListResultItem = ClipCreateResponseWatermark;
export declare const WatermarksListResultItem: S.Schema<ClipCreateResponseWatermark>;
export type WatermarksListResultList = Array<ClipCreateResponseWatermark>;
export declare const WatermarksListResultList: S.Schema<WatermarksListResultList>;
export interface ListWatermarksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WatermarksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListWatermarksResponse: S.Schema<ListWatermarksResponse>;
export interface PatchAudioTrackRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The unique identifier for an additional audio track. */
    audioIdentifier: string;
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string;
}
export declare const PatchAudioTrackRequest: S.Schema<PatchAudioTrackRequest>;
export type AudioTracksEditResponseStatus = "queued" | "ready" | "error";
export declare const AudioTracksEditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAudioTrackResponse {
    /** Denotes whether the audio track will be played by default in a player. */
    default?: boolean | null;
    /** A string to uniquely identify the track amongst other audio track labels for the specified video. */
    label?: string | null;
    /** Specifies the processing status of the video. */
    status?: AudioTracksEditResponseStatus | null;
    /** A Cloudflare-generated unique identifier for a media item. */
    uid?: string | null;
}
export declare const PatchAudioTrackResponse: S.Schema<PatchAudioTrackResponse>;
export interface PutWebhookRequest {
    /** The account identifier tag. */
    accountId: string;
    /** The URL where webhooks will be sent. */
    notificationUrl?: string;
}
export declare const PutWebhookRequest: S.Schema<PutWebhookRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutWebhookResponse {
    /** The date and time the webhook was last modified. */
    modified?: string | null;
    /** The URL where webhooks will be sent. */
    notificationUrl?: string | null;
    /** The secret used to verify webhook signatures. */
    secret?: string | null;
}
export declare const PutWebhookResponse: S.Schema<PutWebhookResponse>;
export interface StorageUsageVideoRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A user-defined identifier for the media creator. */
    creator?: string;
}
export declare const StorageUsageVideoRequest: S.Schema<StorageUsageVideoRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StorageUsageVideoResponse {
    /** A user-defined identifier for the media creator. */
    creator?: string | null;
    /** The total minutes of video content stored in the account. May contain decimal values. */
    totalStorageMinutes?: number | null;
    /** The storage capacity alloted for the account. */
    totalStorageMinutesLimit?: number | null;
    /** The total count of videos associated with the account. */
    videoCount?: number | null;
}
export declare const StorageUsageVideoResponse: S.Schema<StorageUsageVideoResponse>;
export interface UpdateCaptionLanguageRequest {
    /** Identifier. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a media item. */
    identifier: string;
    /** The language tag in BCP 47 format. */
    language: string;
}
export declare const UpdateCaptionLanguageRequest: S.Schema<UpdateCaptionLanguageRequest>;
export type CaptionsLanguageUpdateResponseStatus = "ready" | "inprogress" | "error";
export declare const CaptionsLanguageUpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateCaptionLanguageResponse {
    /** Whether the caption was generated via AI. */
    generated?: boolean | null;
    /** The language label displayed in the native language to users. */
    label?: string | null;
    /** The language tag in BCP 47 format. */
    language?: string | null;
    /** The status of a generated caption. */
    status?: CaptionsLanguageUpdateResponseStatus | null;
}
export declare const UpdateCaptionLanguageResponse: S.Schema<UpdateCaptionLanguageResponse>;
export type LiveInputsUpdateRequestRecordingAllowedOriginsList = Array<string>;
export declare const LiveInputsUpdateRequestRecordingAllowedOriginsList: S.Schema<LiveInputsUpdateRequestRecordingAllowedOriginsList>;
export type LiveInputsUpdateRequestRecordingMode = "off" | "automatic";
export declare const LiveInputsUpdateRequestRecordingMode: any;
export interface LiveInputsUpdateRequestRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsUpdateRequestRecordingAllowedOriginsList;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsUpdateRequestRecordingMode | (string & {});
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number;
}
export declare const LiveInputsUpdateRequestRecording: S.Schema<LiveInputsUpdateRequestRecording>;
export interface UpdateLiveInputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** Sets the creator ID asssociated with this live input. */
    defaultCreator?: string;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsUpdateRequestRecording;
}
export declare const UpdateLiveInputRequest: S.Schema<UpdateLiveInputRequest>;
export type LiveInputsUpdateResponseRecordingAllowedOriginsList = Array<string>;
export declare const LiveInputsUpdateResponseRecordingAllowedOriginsList: S.Schema<LiveInputsUpdateResponseRecordingAllowedOriginsList>;
export type LiveInputsUpdateResponseRecordingMode = "off" | "automatic";
export declare const LiveInputsUpdateResponseRecordingMode: any;
export interface LiveInputsUpdateResponseRecording {
    /** Lists the origins allowed to display videos created with this input. Enter allowed origin domains in an array and use `*` for wildcard subdomains. An empty array allows videos to be viewed on any origin. */
    allowedOrigins?: LiveInputsUpdateResponseRecordingAllowedOriginsList | null;
    /** Disables reporting the number of live viewers when this property is set to `true`. */
    hideLiveViewerCount?: boolean | null;
    /** Specifies the recording behavior for the live input. Set this value to `off` to prevent a recording. Set the value to `automatic` to begin a recording and transition to on-demand after Stream Live stops receiving input. */
    mode?: LiveInputsUpdateResponseRecordingMode | null;
    /** Indicates if a video using the live input has the `requireSignedURLs` property set. Also enforces access controls on any video recording of the livestream with the live input. */
    requireSignedURLs?: boolean | null;
    /** Determines the amount of time a live input configured in `automatic` mode should wait before a recording transitions from live to on-demand. `0` is recommended for most use cases and indicates the platform default should be used. */
    timeoutSeconds?: number | null;
}
export declare const LiveInputsUpdateResponseRecording: S.Schema<LiveInputsUpdateResponseRecording>;
export type LiveInputsUpdateResponseRtmps = LiveInputsCreateResponseRtmps;
export declare const LiveInputsUpdateResponseRtmps: S.Schema<LiveInputsCreateResponseRtmps>;
export type LiveInputsUpdateResponseRtmpsPlayback = LiveInputsCreateResponseRtmpsPlayback;
export declare const LiveInputsUpdateResponseRtmpsPlayback: S.Schema<LiveInputsCreateResponseRtmpsPlayback>;
export type LiveInputsUpdateResponseSrt = LiveInputsCreateResponseSrt;
export declare const LiveInputsUpdateResponseSrt: S.Schema<LiveInputsCreateResponseSrt>;
export type LiveInputsUpdateResponseSrtPlayback = LiveInputsCreateResponseSrtPlayback;
export declare const LiveInputsUpdateResponseSrtPlayback: S.Schema<LiveInputsCreateResponseSrtPlayback>;
export type LiveInputsUpdateResponseStatus = "connected" | "reconnected" | "reconnecting" | "client_disconnect" | "ttl_exceeded" | "failed_to_connect" | "failed_to_reconnect" | "new_configuration_accepted";
export declare const LiveInputsUpdateResponseStatus: any;
export type LiveInputsUpdateResponseWebRTC = LiveInputsCreateResponseWebRTC;
export declare const LiveInputsUpdateResponseWebRTC: S.Schema<LiveInputsCreateResponseWebRTC>;
export type LiveInputsUpdateResponseWebRTCPlayback = LiveInputsCreateResponseWebRTCPlayback;
export declare const LiveInputsUpdateResponseWebRTCPlayback: S.Schema<LiveInputsCreateResponseWebRTCPlayback>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLiveInputResponse {
    /** The date and time the live input was created. */
    created?: string | null;
    /** Indicates the number of days after which the live inputs recordings will be deleted. When a stream completes and the recording is ready, the value is used to calculate a scheduled deletion date for that recording. Omit the field to indicate no change, or include with a `null` value to remove an existing scheduled deletion. */
    deleteRecordingAfterDays?: number | null;
    /** Indicates whether the live input is enabled and can accept streams. */
    enabled?: boolean | null;
    /** The date and time the live input keys were last rotated. Omitted for live inputs that have never had their keys rotated. */
    keysRotatedAt?: string | null;
    /** A user modifiable key-value store used to reference other systems of record for managing live inputs. */
    meta?: unknown | null;
    /** The date and time the live input was last modified. */
    modified?: string | null;
    /** When enabled, the live stream is delivered using Low-Latency HLS (LL-HLS), reducing glass-to-glass latency for viewers at the cost of reduced player compatibility. */
    preferLowLatency?: boolean | null;
    /** Records the input to a Cloudflare Stream video. Behavior depends on the mode. In most cases, the video will initially be viewable as a live video and transition to on-demand after a condition is satisfied. */
    recording?: LiveInputsUpdateResponseRecording | null;
    /** Details for streaming to an live input using RTMPS. */
    rtmps?: LiveInputsCreateResponseRtmps | null;
    /** Details for playback from an live input using RTMPS. */
    rtmpsPlayback?: LiveInputsCreateResponseRtmpsPlayback | null;
    /** Details for streaming to a live input using SRT. */
    srt?: LiveInputsCreateResponseSrt | null;
    /** Details for playback from an live input using SRT. */
    srtPlayback?: LiveInputsCreateResponseSrtPlayback | null;
    /** The connection status of a live input. */
    status?: LiveInputsUpdateResponseStatus | null;
    /** A unique identifier for a live input. */
    uid?: string | null;
    /** Details for streaming to a live input using WebRTC. */
    webRTC?: LiveInputsCreateResponseWebRTC | null;
    /** Details for playback from a live input using WebRTC. */
    webRTCPlayback?: LiveInputsCreateResponseWebRTCPlayback | null;
}
export declare const UpdateLiveInputResponse: S.Schema<UpdateLiveInputResponse>;
export interface UpdateLiveInputOutputRequest {
    /** Identifier. */
    accountId: string;
    /** A unique identifier for a live input. */
    liveInputIdentifier: string;
    /** A unique identifier for the output. */
    outputIdentifier: string;
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled: boolean;
}
export declare const UpdateLiveInputOutputRequest: S.Schema<UpdateLiveInputOutputRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLiveInputOutputResponse {
    /** When enabled, live video streamed to the associated live input will be sent to the output URL. When disabled, live video will not be sent to the output URL, even when streaming to the associated live input. Use this to control precisely when you start and stop simulcasting to specific destinations like YouTube and Twitch. */
    enabled?: boolean | null;
    /** The streamKey used to authenticate against an output's target. */
    streamKey?: string | null;
    /** A unique identifier for the output. */
    uid?: string | null;
    /** The URL an output uses to restream. */
    url?: string | null;
}
export declare const UpdateLiveInputOutputResponse: S.Schema<UpdateLiveInputOutputResponse>;
export type CopyAudioTrackError = CloudflareOpError;
/** Adds an additional audio track to a video using the provided audio track URL. */
export declare const copyAudioTrack: API.OperationMethod<CopyAudioTrackRequest, CopyAudioTrackResponse, CopyAudioTrackError, CloudflareOpContext>;
export type CreateCaptionLanguageError = CloudflareOpError;
/** Generate captions or subtitles for provided language via AI. */
export declare const createCaptionLanguage: API.OperationMethod<CreateCaptionLanguageRequest, CreateCaptionLanguageResponse, CreateCaptionLanguageError, CloudflareOpContext>;
export type CreateClipError = CloudflareOpError;
/** Clips a video based on the specified start and end times provided in seconds. */
export declare const createClip: API.OperationMethod<CreateClipRequest, CreateClipResponse, CreateClipError, CloudflareOpContext>;
export type CreateCopyError = CloudflareOpError;
/** Uploads a video to Stream from a provided URL. */
export declare const createCopy: API.OperationMethod<CreateCopyRequest, CreateCopyResponse, CreateCopyError, CloudflareOpContext>;
export type CreateDirectUploadError = CloudflareOpError;
/** Creates a direct upload that allows video uploads without an API key. */
export declare const createDirectUpload: API.OperationMethod<CreateDirectUploadRequest, CreateDirectUploadResponse, CreateDirectUploadError, CloudflareOpContext>;
export type CreateDownloadError = CloudflareOpError;
/** Creates a download for a video when a video is ready to view. Use `/downloads/{download_type}` instead for type-specific downloads. Available types are `default` and `audio`. */
export declare const createDownload: API.OperationMethod<CreateDownloadRequest, CreateDownloadResponse, CreateDownloadError, CloudflareOpContext>;
export type CreateKeyError = CloudflareOpError;
/** Creates an RSA private key in PEM and JWK formats. Key files are only displayed once after creation. Keys are created, used, and deleted independently of videos, and every key can sign any video. */
export declare const createKey: API.OperationMethod<CreateKeyRequest, CreateKeyResponse, CreateKeyError, CloudflareOpContext>;
export type CreateLiveInputError = CloudflareOpError;
/** Creates a live input, and returns credentials that you or your users can use to stream live video to Cloudflare Stream. */
export declare const createLiveInput: API.OperationMethod<CreateLiveInputRequest, CreateLiveInputResponse, CreateLiveInputError, CloudflareOpContext>;
export type CreateLiveInputOutputError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Creates a new output that can be used to simulcast or restream live video to other RTMP or SRT destinations. Outputs are always linked to a specific live input —&nbsp;one live input can have many outputs. */
export declare const createLiveInputOutput: API.OperationMethod<CreateLiveInputOutputRequest, CreateLiveInputOutputResponse, CreateLiveInputOutputError, CloudflareOpContext>;
export type CreateStreamError = CloudflareOpError;
/** Initiates a video upload using the TUS protocol. On success, the server responds with a status code 201 (created) and includes a `location` header to indicate where the content should be uploaded. Refer to https://tus.io for protocol details. */
export declare const createStream: API.OperationMethod<CreateStreamRequest, CreateStreamResponse, CreateStreamError, CloudflareOpContext>;
export type CreateTokenError = CloudflareOpError;
/** Creates a signed URL token for a video. If a body is not provided in the request, a token is created with default values. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type CreateWatermarkError = WatermarkImageInvalid | Forbidden | CloudflareOpError;
/** Creates watermark profiles using a single `HTTP POST multipart/form-data` request. */
export declare const createWatermark: API.OperationMethod<CreateWatermarkRequest, CreateWatermarkResponse, CreateWatermarkError, CloudflareOpContext>;
export type DeleteAudioTrackError = CloudflareOpError;
/** Deletes additional audio tracks on a video. Deleting a default audio track is not allowed. You must assign another audio track as default prior to deletion. */
export declare const deleteAudioTrack: API.OperationMethod<DeleteAudioTrackRequest, DeleteAudioTrackResponse, DeleteAudioTrackError, CloudflareOpContext>;
export type DeleteCaptionLanguageError = CloudflareOpError;
/** Removes the captions or subtitles from a video. */
export declare const deleteCaptionLanguage: API.OperationMethod<DeleteCaptionLanguageRequest, DeleteCaptionLanguageResponse, DeleteCaptionLanguageError, CloudflareOpContext>;
export type DeleteDownloadError = CloudflareOpError;
/** Delete the downloads for a video. Use `/downloads/{download_type}` instead for type-specific downloads. Available types are `default` and `audio`. */
export declare const deleteDownload: API.OperationMethod<DeleteDownloadRequest, DeleteDownloadResponse, DeleteDownloadError, CloudflareOpContext>;
export type DeleteKeyError = SigningKeyNotFound | Forbidden | CloudflareOpError;
/** Deletes signing keys and revokes all signed URLs generated with the key. */
export declare const deleteKey: API.OperationMethod<DeleteKeyRequest, DeleteKeyResponse, DeleteKeyError, CloudflareOpContext>;
export type DeleteLiveInputError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Prevents a live input from being streamed to and makes the live input inaccessible to any future API calls. */
export declare const deleteLiveInput: API.OperationMethod<DeleteLiveInputRequest, DeleteLiveInputResponse, DeleteLiveInputError, CloudflareOpContext>;
export type DeleteLiveInputOutputError = OutputNotFound | Forbidden | CloudflareOpError;
/** Deletes an output and removes it from the associated live input. */
export declare const deleteLiveInputOutput: API.OperationMethod<DeleteLiveInputOutputRequest, DeleteLiveInputOutputResponse, DeleteLiveInputOutputError, CloudflareOpContext>;
export type DeleteStreamError = CloudflareOpError;
/** Deletes a video and its copies from Cloudflare Stream. */
export declare const deleteStream: API.OperationMethod<DeleteStreamRequest, DeleteStreamResponse, DeleteStreamError, CloudflareOpContext>;
export type DeleteWatermarkError = WatermarkNotFound | Forbidden | CloudflareOpError;
/** Deletes a watermark profile. */
export declare const deleteWatermark: API.OperationMethod<DeleteWatermarkRequest, DeleteWatermarkResponse, DeleteWatermarkError, CloudflareOpContext>;
export type DeleteWebhookError = WebhookNotFound | Forbidden | CloudflareOpError;
/** Deletes a webhook. */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookRequest, DeleteWebhookResponse, DeleteWebhookError, CloudflareOpContext>;
export type EditStreamError = CloudflareOpError;
/** Edit details for a single video. */
export declare const editStream: API.OperationMethod<EditStreamRequest, EditStreamResponse, EditStreamError, CloudflareOpContext>;
export type GetAudioTrackError = CloudflareOpError;
/** Lists additional audio tracks on a video. Note this API will not return information for audio attached to the video upload. */
export declare const getAudioTrack: API.OperationMethod<GetAudioTrackRequest, GetAudioTrackResponse, GetAudioTrackError, CloudflareOpContext>;
export type GetCaptionError = CloudflareOpError;
/** Lists the available captions or subtitles for a specific video. */
export declare const getCaption: API.PaginatedOperationMethod<GetCaptionRequest, GetCaptionResponse, GetCaptionError, CloudflareOpContext, CaptionsGetResultItem>;
export type GetCaptionLanguageError = CloudflareOpError;
/** Lists the captions or subtitles for provided language. */
export declare const getCaptionLanguage: API.OperationMethod<GetCaptionLanguageRequest, GetCaptionLanguageResponse, GetCaptionLanguageError, CloudflareOpContext>;
export type GetCaptionLanguageVttError = CloudflareOpError;
/** Return WebVTT captions for a provided language. */
export declare const getCaptionLanguageVtt: API.OperationMethod<GetCaptionLanguageVttRequest, GetCaptionLanguageVttResponse, GetCaptionLanguageVttError, CloudflareOpContext>;
export type GetDownloadError = CloudflareOpError;
/** Lists the downloads created for a video. */
export declare const getDownload: API.OperationMethod<GetDownloadRequest, GetDownloadResponse, GetDownloadError, CloudflareOpContext>;
export type GetEmbedError = CloudflareOpError;
/** Fetches an HTML code snippet to embed a video in a web page delivered through Cloudflare. On success, returns an HTML fragment for use on web pages to display a video. On failure, returns a JSON response body. */
export declare const getEmbed: API.OperationMethod<GetEmbedRequest, GetEmbedResponse, GetEmbedError, CloudflareOpContext>;
export type GetKeyError = Forbidden | CloudflareOpError;
/** Lists the video ID and creation date and time when a signing key was created. */
export declare const getKey: API.PaginatedOperationMethod<GetKeyRequest, GetKeyResponse, GetKeyError, CloudflareOpContext, KeysGetResultItem>;
export type GetLiveInputError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Retrieves details of an existing live input. */
export declare const getLiveInput: API.OperationMethod<GetLiveInputRequest, GetLiveInputResponse, GetLiveInputError, CloudflareOpContext>;
export type GetStreamError = CloudflareOpError;
/** Fetches details for a single video. */
export declare const getStream: API.OperationMethod<GetStreamRequest, GetStreamResponse, GetStreamError, CloudflareOpContext>;
export type GetWatermarkError = WatermarkNotFound | Forbidden | CloudflareOpError;
/** Retrieves details for a single watermark profile. */
export declare const getWatermark: API.OperationMethod<GetWatermarkRequest, GetWatermarkResponse, GetWatermarkError, CloudflareOpContext>;
export type GetWebhookError = WebhookNotFound | Forbidden | CloudflareOpError;
/** Retrieves a list of webhooks. */
export declare const getWebhook: API.OperationMethod<GetWebhookRequest, GetWebhookResponse, GetWebhookError, CloudflareOpContext>;
export type ListLiveInputOutputsError = LiveInputNotFound | Forbidden | CloudflareOpError;
/** Retrieves all outputs associated with a specified live input. */
export declare const listLiveInputOutputs: API.PaginatedOperationMethod<ListLiveInputOutputsRequest, ListLiveInputOutputsResponse, ListLiveInputOutputsError, CloudflareOpContext, LiveInputsOutputsListResultItem>;
export type ListLiveInputsError = CloudflareOpError;
/** Lists the live inputs created for an account. To get the credentials needed to stream to a specific live input, request a single live input. */
export declare const listLiveInputs: API.OperationMethod<ListLiveInputsRequest, ListLiveInputsResponse, ListLiveInputsError, CloudflareOpContext>;
export type ListStreamsError = CloudflareOpError;
/** Lists up to 1000 videos from a single request. For a specific range, refer to the optional parameters. */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsRequest, ListStreamsResponse, ListStreamsError, CloudflareOpContext, ListResultItem>;
export type ListWatermarksError = CloudflareOpError;
/** Lists all watermark profiles for an account. */
export declare const listWatermarks: API.PaginatedOperationMethod<ListWatermarksRequest, ListWatermarksResponse, ListWatermarksError, CloudflareOpContext, ClipCreateResponseWatermark>;
export type PatchAudioTrackError = CloudflareOpError;
/** Edits additional audio tracks on a video. Editing the default status of an audio track to `true` will mark all other audio tracks on the video default status to `false`. */
export declare const patchAudioTrack: API.OperationMethod<PatchAudioTrackRequest, PatchAudioTrackResponse, PatchAudioTrackError, CloudflareOpContext>;
export type PutWebhookError = CloudflareOpError;
/** Creates a webhook notification. */
export declare const putWebhook: API.OperationMethod<PutWebhookRequest, PutWebhookResponse, PutWebhookError, CloudflareOpContext>;
export type StorageUsageVideoError = CloudflareOpError;
/** Returns information about an account's storage use. */
export declare const storageUsageVideo: API.OperationMethod<StorageUsageVideoRequest, StorageUsageVideoResponse, StorageUsageVideoError, CloudflareOpContext>;
export type UpdateCaptionLanguageError = CloudflareOpError;
/** Uploads the caption or subtitle file to the endpoint for a specific BCP47 language. One caption or subtitle file per language is allowed. */
export declare const updateCaptionLanguage: API.OperationMethod<UpdateCaptionLanguageRequest, UpdateCaptionLanguageResponse, UpdateCaptionLanguageError, CloudflareOpContext>;
export type UpdateLiveInputError = CloudflareOpError;
/** Updates a specified live input. */
export declare const updateLiveInput: API.OperationMethod<UpdateLiveInputRequest, UpdateLiveInputResponse, UpdateLiveInputError, CloudflareOpContext>;
export type UpdateLiveInputOutputError = OutputNotFound | Forbidden | CloudflareOpError;
/** Updates the state of an output. */
export declare const updateLiveInputOutput: API.OperationMethod<UpdateLiveInputOutputRequest, UpdateLiveInputOutputResponse, UpdateLiveInputOutputError, CloudflareOpContext>;
//# sourceMappingURL=stream.d.ts.map