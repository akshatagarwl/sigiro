import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidIdentifier_base: S.Class<InvalidIdentifier, S.TaggedStruct<"InvalidIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidIdentifier extends /*@__PURE__*/ InvalidIdentifier_base {
}
declare const MalformedParameter_base: S.Class<MalformedParameter, S.TaggedStruct<"MalformedParameter", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MalformedParameter extends /*@__PURE__*/ MalformedParameter_base {
}
declare const NamespaceNotFound_base: S.Class<NamespaceNotFound, S.TaggedStruct<"NamespaceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
export interface ListNamespaceObjectsRequest {
    /** Identifier. */
    accountId: string;
    /** ID of the namespace. */
    id: string;
    /** Opaque token indicating the position from which to continue when requesting the next set of records. A valid value for the cursor can be obtained from the cursors object in the result_info structure. */
    cursor?: string;
    /** The number of objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number;
}
export declare const ListNamespaceObjectsRequest: S.Schema<ListNamespaceObjectsRequest>;
export interface NamespacesObjectsListResultItem {
    /** ID of the Durable Object. */
    id?: string | null;
    /** Whether the Durable Object has stored data. */
    hasStoredData?: boolean | null;
}
export declare const NamespacesObjectsListResultItem: S.Schema<NamespacesObjectsListResultItem>;
export type NamespacesObjectsListResultList = Array<NamespacesObjectsListResultItem>;
export declare const NamespacesObjectsListResultList: S.Schema<NamespacesObjectsListResultList>;
export interface ListNamespaceObjectsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesObjectsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespaceObjectsResponse: S.Schema<ListNamespaceObjectsResponse>;
export interface ListNamespacesRequest {
    /** Identifier. */
    accountId: string;
    /** Current page. */
    page?: number;
    /** Items per-page. */
    perPage?: number;
}
export declare const ListNamespacesRequest: S.Schema<ListNamespacesRequest>;
export interface NamespacesListResultItem {
    id?: string | null;
    class?: string | null;
    name?: string | null;
    script?: string | null;
    useSqlite?: boolean | null;
}
export declare const NamespacesListResultItem: S.Schema<NamespacesListResultItem>;
export type NamespacesListResultList = Array<NamespacesListResultItem>;
export declare const NamespacesListResultList: S.Schema<NamespacesListResultList>;
export interface ListNamespacesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: NamespacesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListNamespacesResponse: S.Schema<ListNamespacesResponse>;
export type ListNamespaceObjectsError = NamespaceNotFound | InvalidIdentifier | MalformedParameter | CloudflareOpError;
/** Returns the Durable Objects in a given namespace. */
export declare const listNamespaceObjects: API.PaginatedOperationMethod<ListNamespaceObjectsRequest, ListNamespaceObjectsResponse, ListNamespaceObjectsError, CloudflareOpContext, NamespacesObjectsListResultItem>;
export type ListNamespacesError = InvalidIdentifier | CloudflareOpError;
/** Returns the Durable Object namespaces owned by an account. */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest, ListNamespacesResponse, ListNamespacesError, CloudflareOpContext, NamespacesListResultItem>;
//# sourceMappingURL=durable_objects.d.ts.map