import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AiSecurityNotEntitled_base: S.Class<AiSecurityNotEntitled, S.TaggedStruct<"AiSecurityNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AiSecurityNotEntitled extends /*@__PURE__*/ AiSecurityNotEntitled_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ZoneNotAuthorized_base: S.Class<ZoneNotAuthorized, S.TaggedStruct<"ZoneNotAuthorized", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZoneNotAuthorized extends /*@__PURE__*/ ZoneNotAuthorized_base {
}
export interface GetAiSecurityRequest {
    /** Defines the zone. */
    zoneId: string;
}
export declare const GetAiSecurityRequest: S.Schema<GetAiSecurityRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAiSecurityResponse {
    /** Whether AI Security for Apps is enabled on the zone. */
    enabled?: boolean | null;
}
export declare const GetAiSecurityResponse: S.Schema<GetAiSecurityResponse>;
export interface GetCustomTopicRequest {
    /** Defines the zone. */
    zoneId: string;
}
export declare const GetCustomTopicRequest: S.Schema<GetCustomTopicRequest>;
export interface CustomTopicsGetResponseTopicsItem {
    /** Unique label identifier. Must contain only lowercase letters (a–z), digits (0–9), and hyphens. */
    label: string;
    /** Description of the topic category. Must contain only printable ASCII characters. */
    topic: string;
}
export declare const CustomTopicsGetResponseTopicsItem: S.Schema<CustomTopicsGetResponseTopicsItem>;
export type CustomTopicsGetResponseTopicsList = Array<CustomTopicsGetResponseTopicsItem>;
export declare const CustomTopicsGetResponseTopicsList: S.Schema<CustomTopicsGetResponseTopicsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCustomTopicResponse {
    /** Custom topic categories for AI Security for Apps content detection. */
    topics?: CustomTopicsGetResponseTopicsList | null;
}
export declare const GetCustomTopicResponse: S.Schema<GetCustomTopicResponse>;
export interface PutAiSecurityRequest {
    /** Defines the zone. */
    zoneId: string;
    /** Whether AI Security for Apps is enabled on the zone. */
    enabled?: boolean;
}
export declare const PutAiSecurityRequest: S.Schema<PutAiSecurityRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutAiSecurityResponse {
    /** Whether AI Security for Apps is enabled on the zone. */
    enabled?: boolean | null;
}
export declare const PutAiSecurityResponse: S.Schema<PutAiSecurityResponse>;
export type CustomTopicsUpdateRequestTopicsItem = CustomTopicsGetResponseTopicsItem;
export declare const CustomTopicsUpdateRequestTopicsItem: S.Schema<CustomTopicsGetResponseTopicsItem>;
export type CustomTopicsUpdateRequestTopicsList = Array<CustomTopicsGetResponseTopicsItem>;
export declare const CustomTopicsUpdateRequestTopicsList: S.Schema<CustomTopicsUpdateRequestTopicsList>;
export interface PutCustomTopicRequest {
    /** Defines the zone. */
    zoneId: string;
    /** Custom topic categories for AI Security for Apps content detection. */
    topics?: CustomTopicsUpdateRequestTopicsList;
}
export declare const PutCustomTopicRequest: S.Schema<PutCustomTopicRequest>;
export type CustomTopicsUpdateResponseTopicsItem = CustomTopicsGetResponseTopicsItem;
export declare const CustomTopicsUpdateResponseTopicsItem: S.Schema<CustomTopicsGetResponseTopicsItem>;
export type CustomTopicsUpdateResponseTopicsList = Array<CustomTopicsGetResponseTopicsItem>;
export declare const CustomTopicsUpdateResponseTopicsList: S.Schema<CustomTopicsUpdateResponseTopicsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutCustomTopicResponse {
    /** Custom topic categories for AI Security for Apps content detection. */
    topics?: CustomTopicsUpdateResponseTopicsList | null;
}
export declare const PutCustomTopicResponse: S.Schema<PutCustomTopicResponse>;
export type GetAiSecurityError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Get whether AI Security for Apps is enabled or disabled for a zone. */
export declare const getAiSecurity: API.OperationMethod<GetAiSecurityRequest, GetAiSecurityResponse, GetAiSecurityError, CloudflareOpContext>;
export type GetCustomTopicError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Get the AI Security for Apps custom topic categories for a zone. */
export declare const getCustomTopic: API.OperationMethod<GetCustomTopicRequest, GetCustomTopicResponse, GetCustomTopicError, CloudflareOpContext>;
export type PutAiSecurityError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Enable or disable AI Security for Apps for a zone. Changes can take up to a minute to propagate to the zone. */
export declare const putAiSecurity: API.OperationMethod<PutAiSecurityRequest, PutAiSecurityResponse, PutAiSecurityError, CloudflareOpContext>;
export type PutCustomTopicError = AiSecurityNotEntitled | ZoneNotAuthorized | Forbidden | CloudflareOpError;
/** Set the AI Security for Apps custom topic categories for a zone. A maximum of 20 custom topics can be configured per zone. Each topic label must be 2–20 characters using only lowercase letters (a–z), digits (0–9), and hyphens. Each topic description must be 2–50 printable ASCII characters. Changes can take up to a minute to propagate to the zone. */
export declare const putCustomTopic: API.OperationMethod<PutCustomTopicRequest, PutCustomTopicResponse, PutCustomTopicError, CloudflareOpContext>;
//# sourceMappingURL=ai_security.d.ts.map