import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CancelBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
}
export declare const CancelBuildRequest: S.Schema<CancelBuildRequest>;
export type CancelBuildResponseBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export declare const CancelBuildResponseBuildOutcome: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CancelBuildResponse {
    buildOutcome?: CancelBuildResponseBuildOutcome | null;
    /** Build UUID. */
    buildUuid?: string | null;
    stoppedOn?: string | null;
}
export declare const CancelBuildResponse: S.Schema<CancelBuildResponse>;
export interface CreateTokenRequest {
    /** Account identifier. */
    accountId: string;
    buildTokenName: string;
    buildTokenSecret: string;
    cloudflareTokenId: string;
}
export declare const CreateTokenRequest: S.Schema<CreateTokenRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    cloudflareTokenId?: string | null;
    ownerType?: string | null;
}
export declare const CreateTokenResponse: S.Schema<CreateTokenResponse>;
export type CreateTriggerRequestBranchExcludesList = Array<string>;
export declare const CreateTriggerRequestBranchExcludesList: S.Schema<CreateTriggerRequestBranchExcludesList>;
export type CreateTriggerRequestBranchIncludesList = Array<string>;
export declare const CreateTriggerRequestBranchIncludesList: S.Schema<CreateTriggerRequestBranchIncludesList>;
export type CreateTriggerRequestPathExcludesList = Array<string>;
export declare const CreateTriggerRequestPathExcludesList: S.Schema<CreateTriggerRequestPathExcludesList>;
export type CreateTriggerRequestPathIncludesList = Array<string>;
export declare const CreateTriggerRequestPathIncludesList: S.Schema<CreateTriggerRequestPathIncludesList>;
export interface CreateTriggerRequest {
    /** Account identifier. */
    accountId: string;
    branchExcludes: CreateTriggerRequestBranchExcludesList;
    branchIncludes: CreateTriggerRequestBranchIncludesList;
    buildCommand: string;
    /** Build token UUID. */
    buildTokenUuid: string;
    deployCommand: string;
    /** System-generated worker script tag. */
    externalScriptId: string;
    pathExcludes: CreateTriggerRequestPathExcludesList;
    pathIncludes: CreateTriggerRequestPathIncludesList;
    /** Repository connection UUID. */
    repoConnectionUuid: string;
    /** Root directory path. */
    rootDirectory: string;
    triggerName: string;
    buildCachingEnabled?: boolean;
}
export declare const CreateTriggerRequest: S.Schema<CreateTriggerRequest>;
export type CreateTriggerResponseBranchExcludesList = Array<string>;
export declare const CreateTriggerResponseBranchExcludesList: S.Schema<CreateTriggerResponseBranchExcludesList>;
export type CreateTriggerResponseBranchIncludesList = Array<string>;
export declare const CreateTriggerResponseBranchIncludesList: S.Schema<CreateTriggerResponseBranchIncludesList>;
export type CreateTriggerResponsePathExcludesList = Array<string>;
export declare const CreateTriggerResponsePathExcludesList: S.Schema<CreateTriggerResponsePathExcludesList>;
export type CreateTriggerResponsePathIncludesList = Array<string>;
export declare const CreateTriggerResponsePathIncludesList: S.Schema<CreateTriggerResponsePathIncludesList>;
export type CreateTriggerResponseRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const CreateTriggerResponseRepoConnectionProviderType: any;
export interface CreateTriggerResponseRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: CreateTriggerResponseRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const CreateTriggerResponseRepoConnection: S.Schema<CreateTriggerResponseRepoConnection>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTriggerResponse {
    branchExcludes?: CreateTriggerResponseBranchExcludesList | null;
    branchIncludes?: CreateTriggerResponseBranchIncludesList | null;
    buildCachingEnabled?: boolean | null;
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    deployCommand?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    pathExcludes?: CreateTriggerResponsePathExcludesList | null;
    pathIncludes?: CreateTriggerResponsePathIncludesList | null;
    repoConnection?: CreateTriggerResponseRepoConnection | null;
    /** Root directory path. */
    rootDirectory?: string | null;
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export declare const CreateTriggerResponse: S.Schema<CreateTriggerResponse>;
export interface DeleteReposConnectionRequest {
    /** Account identifier. */
    accountId: string;
    /** Repository connection UUID. */
    repoConnectionUuid: string;
}
export declare const DeleteReposConnectionRequest: S.Schema<DeleteReposConnectionRequest>;
export type DeleteReposConnectionResponse = unknown;
export declare const DeleteReposConnectionResponse: S.Schema<DeleteReposConnectionResponse>;
export interface DeleteTokenRequest {
    /** Account identifier. */
    accountId: string;
    /** Build token UUID. */
    buildTokenUuid: string;
}
export declare const DeleteTokenRequest: S.Schema<DeleteTokenRequest>;
export type DeleteTokenResponse = unknown;
export declare const DeleteTokenResponse: S.Schema<DeleteTokenResponse>;
export interface DeleteTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export declare const DeleteTriggerRequest: S.Schema<DeleteTriggerRequest>;
export type DeleteTriggerResponse = unknown;
export declare const DeleteTriggerResponse: S.Schema<DeleteTriggerResponse>;
export interface DeleteTriggersEnvironmentVariableRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Environment variable key. */
    environmentVariableKey: string;
}
export declare const DeleteTriggersEnvironmentVariableRequest: S.Schema<DeleteTriggersEnvironmentVariableRequest>;
export type DeleteTriggersEnvironmentVariableResponse = unknown;
export declare const DeleteTriggersEnvironmentVariableResponse: S.Schema<DeleteTriggersEnvironmentVariableResponse>;
export interface DeployHooksCreateRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the worker. */
    scriptName: string;
    /** Git branch name. */
    branch: string;
    /** Deploy hook name (1-58 characters). */
    deployHookName: string;
}
export declare const DeployHooksCreateRequest: S.Schema<DeployHooksCreateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksCreateResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export declare const DeployHooksCreateResponse: S.Schema<DeployHooksCreateResponse>;
export interface DeployHooksDeleteRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
export declare const DeployHooksDeleteRequest: S.Schema<DeployHooksDeleteRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksDeleteResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export declare const DeployHooksDeleteResponse: S.Schema<DeployHooksDeleteResponse>;
export interface DeployHooksGetRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
export declare const DeployHooksGetRequest: S.Schema<DeployHooksGetRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksGetResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export declare const DeployHooksGetResponse: S.Schema<DeployHooksGetResponse>;
export interface DeployHooksListRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the worker. */
    scriptName: string;
}
export declare const DeployHooksListRequest: S.Schema<DeployHooksListRequest>;
export interface DeployHooksListResultItemLatestBuild {
    createdOn?: string | null;
}
export declare const DeployHooksListResultItemLatestBuild: S.Schema<DeployHooksListResultItemLatestBuild>;
export interface DeployHooksListResultItem {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    latestBuild?: DeployHooksListResultItemLatestBuild | null;
    modifiedOn?: string | null;
}
export declare const DeployHooksListResultItem: S.Schema<DeployHooksListResultItem>;
export type DeployHooksListResultList = Array<DeployHooksListResultItem>;
export declare const DeployHooksListResultList: S.Schema<DeployHooksListResultList>;
export type DeployHooksListResponse = DeployHooksListResultList;
export declare const DeployHooksListResponse: S.Schema<DeployHooksListResponse>;
export interface DeployHooksTriggerRequest {
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
export declare const DeployHooksTriggerRequest: S.Schema<DeployHooksTriggerRequest>;
export type DeployHooksTriggerResponseStatus = "queued" | "initializing" | "running" | "stopped";
export declare const DeployHooksTriggerResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksTriggerResponse {
    /** True if a pending build already exists for this branch */
    alreadyExists?: boolean | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    status?: DeployHooksTriggerResponseStatus | null;
}
export declare const DeployHooksTriggerResponse: S.Schema<DeployHooksTriggerResponse>;
export interface DeployHooksUpdateRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
    /** Git branch name. */
    branch: string;
    /** Deploy hook name (1-58 characters). */
    deployHookName: string;
}
export declare const DeployHooksUpdateRequest: S.Schema<DeployHooksUpdateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeployHooksUpdateResponse {
    /** Git branch name. */
    branch?: string | null;
    createdOn?: string | null;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
}
export declare const DeployHooksUpdateResponse: S.Schema<DeployHooksUpdateResponse>;
export interface GetAccountLimitsRequest {
    /** Account identifier. */
    accountId: string;
}
export declare const GetAccountLimitsRequest: S.Schema<GetAccountLimitsRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountLimitsResponse {
    /** When build minutes will refresh (only for non-paid plans) */
    buildMinutesRefreshOn?: string | null;
    /** Whether build minutes limit has been reached (only for non-paid plans) */
    hasReachedBuildMinutesLimit?: boolean | null;
}
export declare const GetAccountLimitsResponse: S.Schema<GetAccountLimitsResponse>;
export interface GetBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
}
export declare const GetBuildRequest: S.Schema<GetBuildRequest>;
export type GetBuildResponseBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export declare const GetBuildResponseBuildOutcome: any;
export type GetBuildResponseBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export declare const GetBuildResponseBuildTriggerMetadataBuildTriggerSource: any;
export type GetBuildResponseBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const GetBuildResponseBuildTriggerMetadataEnvironmentVariablesMap: S.Schema<GetBuildResponseBuildTriggerMetadataEnvironmentVariablesMap>;
export type GetBuildResponseBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const GetBuildResponseBuildTriggerMetadataProviderType: any;
export interface GetBuildResponseBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: GetBuildResponseBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    deployCommand?: string | null;
    environmentVariables?: GetBuildResponseBuildTriggerMetadataEnvironmentVariablesMap | null;
    providerAccountName?: string | null;
    providerType?: GetBuildResponseBuildTriggerMetadataProviderType | null;
    repoName?: string | null;
    /** Root directory path. */
    rootDirectory?: string | null;
}
export declare const GetBuildResponseBuildTriggerMetadata: S.Schema<GetBuildResponseBuildTriggerMetadata>;
export interface GetBuildResponsePullRequest {
    createdOn?: string | null;
    pullRequestUrl?: string | null;
}
export declare const GetBuildResponsePullRequest: S.Schema<GetBuildResponsePullRequest>;
export type GetBuildResponseStatus = "queued" | "initializing" | "running" | "stopped";
export declare const GetBuildResponseStatus: any;
export type GetBuildResponseTriggerBranchExcludesList = Array<string>;
export declare const GetBuildResponseTriggerBranchExcludesList: S.Schema<GetBuildResponseTriggerBranchExcludesList>;
export type GetBuildResponseTriggerBranchIncludesList = Array<string>;
export declare const GetBuildResponseTriggerBranchIncludesList: S.Schema<GetBuildResponseTriggerBranchIncludesList>;
export type GetBuildResponseTriggerPathExcludesList = Array<string>;
export declare const GetBuildResponseTriggerPathExcludesList: S.Schema<GetBuildResponseTriggerPathExcludesList>;
export type GetBuildResponseTriggerPathIncludesList = Array<string>;
export declare const GetBuildResponseTriggerPathIncludesList: S.Schema<GetBuildResponseTriggerPathIncludesList>;
export type GetBuildResponseTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const GetBuildResponseTriggerRepoConnectionProviderType: any;
export interface GetBuildResponseTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: GetBuildResponseTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const GetBuildResponseTriggerRepoConnection: S.Schema<GetBuildResponseTriggerRepoConnection>;
export interface GetBuildResponseTrigger {
    branchExcludes?: GetBuildResponseTriggerBranchExcludesList | null;
    branchIncludes?: GetBuildResponseTriggerBranchIncludesList | null;
    buildCachingEnabled?: boolean | null;
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    deployCommand?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    pathExcludes?: GetBuildResponseTriggerPathExcludesList | null;
    pathIncludes?: GetBuildResponseTriggerPathIncludesList | null;
    repoConnection?: GetBuildResponseTriggerRepoConnection | null;
    /** Root directory path. */
    rootDirectory?: string | null;
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export declare const GetBuildResponseTrigger: S.Schema<GetBuildResponseTrigger>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBuildResponse {
    buildOutcome?: GetBuildResponseBuildOutcome | null;
    buildTriggerMetadata?: GetBuildResponseBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: GetBuildResponseStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: GetBuildResponseTrigger | null;
}
export declare const GetBuildResponse: S.Schema<GetBuildResponse>;
export interface GetBuildsByVersionRequest {
    /** Account identifier. */
    accountId: string;
    /** Comma-separated list of version UUIDs (max 20). */
    versionIds: string;
}
export declare const GetBuildsByVersionRequest: S.Schema<GetBuildsByVersionRequest>;
export type GetBuildsByVersionResponseBuildsValueBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export declare const GetBuildsByVersionResponseBuildsValueBuildOutcome: any;
export type GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export declare const GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataBuildTriggerSource: any;
export type GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap: S.Schema<GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap>;
export type GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataProviderType: any;
export interface GetBuildsByVersionResponseBuildsValueBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    deployCommand?: string | null;
    environmentVariables?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap | null;
    providerAccountName?: string | null;
    providerType?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadataProviderType | null;
    repoName?: string | null;
    /** Root directory path. */
    rootDirectory?: string | null;
}
export declare const GetBuildsByVersionResponseBuildsValueBuildTriggerMetadata: S.Schema<GetBuildsByVersionResponseBuildsValueBuildTriggerMetadata>;
export type GetBuildsByVersionResponseBuildsValuePullRequest = GetBuildResponsePullRequest;
export declare const GetBuildsByVersionResponseBuildsValuePullRequest: S.Schema<GetBuildResponsePullRequest>;
export type GetBuildsByVersionResponseBuildsValueStatus = "queued" | "initializing" | "running" | "stopped";
export declare const GetBuildsByVersionResponseBuildsValueStatus: any;
export type GetBuildsByVersionResponseBuildsValueTriggerBranchExcludesList = Array<string>;
export declare const GetBuildsByVersionResponseBuildsValueTriggerBranchExcludesList: S.Schema<GetBuildsByVersionResponseBuildsValueTriggerBranchExcludesList>;
export type GetBuildsByVersionResponseBuildsValueTriggerBranchIncludesList = Array<string>;
export declare const GetBuildsByVersionResponseBuildsValueTriggerBranchIncludesList: S.Schema<GetBuildsByVersionResponseBuildsValueTriggerBranchIncludesList>;
export type GetBuildsByVersionResponseBuildsValueTriggerPathExcludesList = Array<string>;
export declare const GetBuildsByVersionResponseBuildsValueTriggerPathExcludesList: S.Schema<GetBuildsByVersionResponseBuildsValueTriggerPathExcludesList>;
export type GetBuildsByVersionResponseBuildsValueTriggerPathIncludesList = Array<string>;
export declare const GetBuildsByVersionResponseBuildsValueTriggerPathIncludesList: S.Schema<GetBuildsByVersionResponseBuildsValueTriggerPathIncludesList>;
export type GetBuildsByVersionResponseBuildsValueTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const GetBuildsByVersionResponseBuildsValueTriggerRepoConnectionProviderType: any;
export interface GetBuildsByVersionResponseBuildsValueTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: GetBuildsByVersionResponseBuildsValueTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const GetBuildsByVersionResponseBuildsValueTriggerRepoConnection: S.Schema<GetBuildsByVersionResponseBuildsValueTriggerRepoConnection>;
export interface GetBuildsByVersionResponseBuildsValueTrigger {
    branchExcludes?: GetBuildsByVersionResponseBuildsValueTriggerBranchExcludesList | null;
    branchIncludes?: GetBuildsByVersionResponseBuildsValueTriggerBranchIncludesList | null;
    buildCachingEnabled?: boolean | null;
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    deployCommand?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    pathExcludes?: GetBuildsByVersionResponseBuildsValueTriggerPathExcludesList | null;
    pathIncludes?: GetBuildsByVersionResponseBuildsValueTriggerPathIncludesList | null;
    repoConnection?: GetBuildsByVersionResponseBuildsValueTriggerRepoConnection | null;
    /** Root directory path. */
    rootDirectory?: string | null;
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export declare const GetBuildsByVersionResponseBuildsValueTrigger: S.Schema<GetBuildsByVersionResponseBuildsValueTrigger>;
export interface GetBuildsByVersionResponseBuildsValue {
    buildOutcome?: GetBuildsByVersionResponseBuildsValueBuildOutcome | null;
    buildTriggerMetadata?: GetBuildsByVersionResponseBuildsValueBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: GetBuildsByVersionResponseBuildsValueStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: GetBuildsByVersionResponseBuildsValueTrigger | null;
}
export declare const GetBuildsByVersionResponseBuildsValue: S.Schema<GetBuildsByVersionResponseBuildsValue>;
export type GetBuildsByVersionResponseBuildsMap = {
    [key: string]: GetBuildsByVersionResponseBuildsValue | undefined;
};
export declare const GetBuildsByVersionResponseBuildsMap: S.Schema<GetBuildsByVersionResponseBuildsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBuildsByVersionResponse {
    builds?: GetBuildsByVersionResponseBuildsMap | null;
}
export declare const GetBuildsByVersionResponse: S.Schema<GetBuildsByVersionResponse>;
export interface GetBuildsLogRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
    /** Pagination cursor for log retrieval. */
    cursor?: string;
}
export declare const GetBuildsLogRequest: S.Schema<GetBuildsLogRequest>;
export type GetBuildsLogResponseLinesItem = string | number;
export declare const GetBuildsLogResponseLinesItem: any;
export type GetBuildsLogResponseLinesList = Array<GetBuildsLogResponseLinesItem>;
export declare const GetBuildsLogResponseLinesList: S.Schema<GetBuildsLogResponseLinesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBuildsLogResponse {
    /** Pagination cursor for log retrieval. */
    cursor?: string | null;
    lines?: GetBuildsLogResponseLinesList | null;
    truncated?: boolean | null;
}
export declare const GetBuildsLogResponse: S.Schema<GetBuildsLogResponse>;
export interface GetLatestBuildsRequest {
    /** Account identifier. */
    accountId: string;
    /** Comma-separated list of system-generated worker script tags (max 20). */
    externalScriptIds: string;
}
export declare const GetLatestBuildsRequest: S.Schema<GetLatestBuildsRequest>;
export type GetLatestBuildsResponseBuildsValueBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export declare const GetLatestBuildsResponseBuildsValueBuildOutcome: any;
export type GetLatestBuildsResponseBuildsValueBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export declare const GetLatestBuildsResponseBuildsValueBuildTriggerMetadataBuildTriggerSource: any;
export type GetLatestBuildsResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const GetLatestBuildsResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap: S.Schema<GetLatestBuildsResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap>;
export type GetLatestBuildsResponseBuildsValueBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const GetLatestBuildsResponseBuildsValueBuildTriggerMetadataProviderType: any;
export interface GetLatestBuildsResponseBuildsValueBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    deployCommand?: string | null;
    environmentVariables?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadataEnvironmentVariablesMap | null;
    providerAccountName?: string | null;
    providerType?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadataProviderType | null;
    repoName?: string | null;
    /** Root directory path. */
    rootDirectory?: string | null;
}
export declare const GetLatestBuildsResponseBuildsValueBuildTriggerMetadata: S.Schema<GetLatestBuildsResponseBuildsValueBuildTriggerMetadata>;
export type GetLatestBuildsResponseBuildsValuePullRequest = GetBuildResponsePullRequest;
export declare const GetLatestBuildsResponseBuildsValuePullRequest: S.Schema<GetBuildResponsePullRequest>;
export type GetLatestBuildsResponseBuildsValueStatus = "queued" | "initializing" | "running" | "stopped";
export declare const GetLatestBuildsResponseBuildsValueStatus: any;
export type GetLatestBuildsResponseBuildsValueTriggerBranchExcludesList = Array<string>;
export declare const GetLatestBuildsResponseBuildsValueTriggerBranchExcludesList: S.Schema<GetLatestBuildsResponseBuildsValueTriggerBranchExcludesList>;
export type GetLatestBuildsResponseBuildsValueTriggerBranchIncludesList = Array<string>;
export declare const GetLatestBuildsResponseBuildsValueTriggerBranchIncludesList: S.Schema<GetLatestBuildsResponseBuildsValueTriggerBranchIncludesList>;
export type GetLatestBuildsResponseBuildsValueTriggerPathExcludesList = Array<string>;
export declare const GetLatestBuildsResponseBuildsValueTriggerPathExcludesList: S.Schema<GetLatestBuildsResponseBuildsValueTriggerPathExcludesList>;
export type GetLatestBuildsResponseBuildsValueTriggerPathIncludesList = Array<string>;
export declare const GetLatestBuildsResponseBuildsValueTriggerPathIncludesList: S.Schema<GetLatestBuildsResponseBuildsValueTriggerPathIncludesList>;
export type GetLatestBuildsResponseBuildsValueTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const GetLatestBuildsResponseBuildsValueTriggerRepoConnectionProviderType: any;
export interface GetLatestBuildsResponseBuildsValueTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: GetLatestBuildsResponseBuildsValueTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const GetLatestBuildsResponseBuildsValueTriggerRepoConnection: S.Schema<GetLatestBuildsResponseBuildsValueTriggerRepoConnection>;
export interface GetLatestBuildsResponseBuildsValueTrigger {
    branchExcludes?: GetLatestBuildsResponseBuildsValueTriggerBranchExcludesList | null;
    branchIncludes?: GetLatestBuildsResponseBuildsValueTriggerBranchIncludesList | null;
    buildCachingEnabled?: boolean | null;
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    deployCommand?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    pathExcludes?: GetLatestBuildsResponseBuildsValueTriggerPathExcludesList | null;
    pathIncludes?: GetLatestBuildsResponseBuildsValueTriggerPathIncludesList | null;
    repoConnection?: GetLatestBuildsResponseBuildsValueTriggerRepoConnection | null;
    /** Root directory path. */
    rootDirectory?: string | null;
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export declare const GetLatestBuildsResponseBuildsValueTrigger: S.Schema<GetLatestBuildsResponseBuildsValueTrigger>;
export interface GetLatestBuildsResponseBuildsValue {
    buildOutcome?: GetLatestBuildsResponseBuildsValueBuildOutcome | null;
    buildTriggerMetadata?: GetLatestBuildsResponseBuildsValueBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: GetLatestBuildsResponseBuildsValueStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: GetLatestBuildsResponseBuildsValueTrigger | null;
}
export declare const GetLatestBuildsResponseBuildsValue: S.Schema<GetLatestBuildsResponseBuildsValue>;
export type GetLatestBuildsResponseBuildsMap = {
    [key: string]: GetLatestBuildsResponseBuildsValue | undefined;
};
export declare const GetLatestBuildsResponseBuildsMap: S.Schema<GetLatestBuildsResponseBuildsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLatestBuildsResponse {
    builds?: GetLatestBuildsResponseBuildsMap | null;
}
export declare const GetLatestBuildsResponse: S.Schema<GetLatestBuildsResponse>;
export type GetReposConfigAutofillRequestProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const GetReposConfigAutofillRequestProviderType: any;
export interface GetReposConfigAutofillRequest {
    /** Account identifier. */
    accountId: string;
    providerType: GetReposConfigAutofillRequestProviderType | (string & {});
    /** Provider account identifier. */
    providerAccountId: string;
    /** Repository identifier. */
    repoId: string;
    /** Git branch name. */
    branch: string;
    /** Root directory path. */
    rootDirectory?: string;
}
export declare const GetReposConfigAutofillRequest: S.Schema<GetReposConfigAutofillRequest>;
export type GetReposConfigAutofillResponseEnvWorkerNamesMap = {
    [key: string]: string | undefined;
};
export declare const GetReposConfigAutofillResponseEnvWorkerNamesMap: S.Schema<GetReposConfigAutofillResponseEnvWorkerNamesMap>;
export type GetReposConfigAutofillResponsePackageManager = "npm" | "yarn" | "pnpm" | "bun" | "uv";
export declare const GetReposConfigAutofillResponsePackageManager: any;
export type GetReposConfigAutofillResponseScriptsMap = {
    [key: string]: string | undefined;
};
export declare const GetReposConfigAutofillResponseScriptsMap: S.Schema<GetReposConfigAutofillResponseScriptsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetReposConfigAutofillResponse {
    configFile?: string | null;
    defaultWorkerName?: string | null;
    envWorkerNames?: GetReposConfigAutofillResponseEnvWorkerNamesMap | null;
    packageManager?: GetReposConfigAutofillResponsePackageManager | null;
    scripts?: GetReposConfigAutofillResponseScriptsMap | null;
}
export declare const GetReposConfigAutofillResponse: S.Schema<GetReposConfigAutofillResponse>;
export interface ListBuildsRequest {
    /** Account identifier. */
    accountId: string;
    /** System-generated worker script tag. */
    externalScriptId: string;
    /** Page number for pagination */
    page?: number;
    /** Number of items per page */
    perPage?: number;
}
export declare const ListBuildsRequest: S.Schema<ListBuildsRequest>;
export type ListBuildsResultItemBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export declare const ListBuildsResultItemBuildOutcome: any;
export type ListBuildsResultItemBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export declare const ListBuildsResultItemBuildTriggerMetadataBuildTriggerSource: any;
export type ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export declare const ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap: S.Schema<ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap>;
export type ListBuildsResultItemBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const ListBuildsResultItemBuildTriggerMetadataProviderType: any;
export interface ListBuildsResultItemBuildTriggerMetadata {
    author?: string | null;
    /** Git branch name. */
    branch?: string | null;
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    buildTriggerSource?: ListBuildsResultItemBuildTriggerMetadataBuildTriggerSource | null;
    /** Git commit hash */
    commitHash?: string | null;
    commitMessage?: string | null;
    deployCommand?: string | null;
    environmentVariables?: ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap | null;
    providerAccountName?: string | null;
    providerType?: ListBuildsResultItemBuildTriggerMetadataProviderType | null;
    repoName?: string | null;
    /** Root directory path. */
    rootDirectory?: string | null;
}
export declare const ListBuildsResultItemBuildTriggerMetadata: S.Schema<ListBuildsResultItemBuildTriggerMetadata>;
export type ListBuildsResultItemPullRequest = GetBuildResponsePullRequest;
export declare const ListBuildsResultItemPullRequest: S.Schema<GetBuildResponsePullRequest>;
export type ListBuildsResultItemStatus = "queued" | "initializing" | "running" | "stopped";
export declare const ListBuildsResultItemStatus: any;
export type ListBuildsResultItemTriggerBranchExcludesList = Array<string>;
export declare const ListBuildsResultItemTriggerBranchExcludesList: S.Schema<ListBuildsResultItemTriggerBranchExcludesList>;
export type ListBuildsResultItemTriggerBranchIncludesList = Array<string>;
export declare const ListBuildsResultItemTriggerBranchIncludesList: S.Schema<ListBuildsResultItemTriggerBranchIncludesList>;
export type ListBuildsResultItemTriggerPathExcludesList = Array<string>;
export declare const ListBuildsResultItemTriggerPathExcludesList: S.Schema<ListBuildsResultItemTriggerPathExcludesList>;
export type ListBuildsResultItemTriggerPathIncludesList = Array<string>;
export declare const ListBuildsResultItemTriggerPathIncludesList: S.Schema<ListBuildsResultItemTriggerPathIncludesList>;
export type ListBuildsResultItemTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const ListBuildsResultItemTriggerRepoConnectionProviderType: any;
export interface ListBuildsResultItemTriggerRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: ListBuildsResultItemTriggerRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const ListBuildsResultItemTriggerRepoConnection: S.Schema<ListBuildsResultItemTriggerRepoConnection>;
export interface ListBuildsResultItemTrigger {
    branchExcludes?: ListBuildsResultItemTriggerBranchExcludesList | null;
    branchIncludes?: ListBuildsResultItemTriggerBranchIncludesList | null;
    buildCachingEnabled?: boolean | null;
    buildCommand?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    deployCommand?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    pathExcludes?: ListBuildsResultItemTriggerPathExcludesList | null;
    pathIncludes?: ListBuildsResultItemTriggerPathIncludesList | null;
    repoConnection?: ListBuildsResultItemTriggerRepoConnection | null;
    /** Root directory path. */
    rootDirectory?: string | null;
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export declare const ListBuildsResultItemTrigger: S.Schema<ListBuildsResultItemTrigger>;
export interface ListBuildsResultItem {
    buildOutcome?: ListBuildsResultItemBuildOutcome | null;
    buildTriggerMetadata?: ListBuildsResultItemBuildTriggerMetadata | null;
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
    initializingOn?: string | null;
    modifiedOn?: string | null;
    pullRequest?: GetBuildResponsePullRequest | null;
    runningOn?: string | null;
    status?: ListBuildsResultItemStatus | null;
    stoppedOn?: string | null;
    /** Trigger information without build_token_uuid */
    trigger?: ListBuildsResultItemTrigger | null;
}
export declare const ListBuildsResultItem: S.Schema<ListBuildsResultItem>;
export type ListBuildsResultList = Array<ListBuildsResultItem>;
export declare const ListBuildsResultList: S.Schema<ListBuildsResultList>;
export type ListBuildsResponse = ListBuildsResultList;
export declare const ListBuildsResponse: S.Schema<ListBuildsResponse>;
export interface ListTokensRequest {
    /** Account identifier. */
    accountId: string;
    /** Page number for pagination */
    page?: number;
    /** Number of items per page */
    perPage?: number;
}
export declare const ListTokensRequest: S.Schema<ListTokensRequest>;
export interface ListTokensResultItem {
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    cloudflareTokenId?: string | null;
    ownerType?: string | null;
}
export declare const ListTokensResultItem: S.Schema<ListTokensResultItem>;
export type ListTokensResultList = Array<ListTokensResultItem>;
export declare const ListTokensResultList: S.Schema<ListTokensResultList>;
export type ListTokensResponse = ListTokensResultList;
export declare const ListTokensResponse: S.Schema<ListTokensResponse>;
export interface ListTriggersRequest {
    /** Account identifier. */
    accountId: string;
    /** System-generated worker script tag. */
    externalScriptId: string;
}
export declare const ListTriggersRequest: S.Schema<ListTriggersRequest>;
export type ListTriggersResultItemBranchExcludesList = Array<string>;
export declare const ListTriggersResultItemBranchExcludesList: S.Schema<ListTriggersResultItemBranchExcludesList>;
export type ListTriggersResultItemBranchIncludesList = Array<string>;
export declare const ListTriggersResultItemBranchIncludesList: S.Schema<ListTriggersResultItemBranchIncludesList>;
export type ListTriggersResultItemPathExcludesList = Array<string>;
export declare const ListTriggersResultItemPathExcludesList: S.Schema<ListTriggersResultItemPathExcludesList>;
export type ListTriggersResultItemPathIncludesList = Array<string>;
export declare const ListTriggersResultItemPathIncludesList: S.Schema<ListTriggersResultItemPathIncludesList>;
export type ListTriggersResultItemRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const ListTriggersResultItemRepoConnectionProviderType: any;
export interface ListTriggersResultItemRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: ListTriggersResultItemRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const ListTriggersResultItemRepoConnection: S.Schema<ListTriggersResultItemRepoConnection>;
export interface ListTriggersResultItem {
    branchExcludes?: ListTriggersResultItemBranchExcludesList | null;
    branchIncludes?: ListTriggersResultItemBranchIncludesList | null;
    buildCachingEnabled?: boolean | null;
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    deployCommand?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    pathExcludes?: ListTriggersResultItemPathExcludesList | null;
    pathIncludes?: ListTriggersResultItemPathIncludesList | null;
    repoConnection?: ListTriggersResultItemRepoConnection | null;
    /** Root directory path. */
    rootDirectory?: string | null;
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export declare const ListTriggersResultItem: S.Schema<ListTriggersResultItem>;
export type ListTriggersResultList = Array<ListTriggersResultItem>;
export declare const ListTriggersResultList: S.Schema<ListTriggersResultList>;
export type ListTriggersResponse = ListTriggersResultList;
export declare const ListTriggersResponse: S.Schema<ListTriggersResponse>;
export interface ListTriggersEnvironmentVariablesRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export declare const ListTriggersEnvironmentVariablesRequest: S.Schema<ListTriggersEnvironmentVariablesRequest>;
export interface ListTriggersEnvironmentVariablesResultValue {
    createdOn: string;
    isSecret: boolean;
    /** Value is null for secret environment variables */
    value?: string | null;
}
export declare const ListTriggersEnvironmentVariablesResultValue: S.Schema<ListTriggersEnvironmentVariablesResultValue>;
export type ListTriggersEnvironmentVariablesResultMap = {
    [key: string]: ListTriggersEnvironmentVariablesResultValue | undefined;
};
export declare const ListTriggersEnvironmentVariablesResultMap: S.Schema<ListTriggersEnvironmentVariablesResultMap>;
export type ListTriggersEnvironmentVariablesResponse = ListTriggersEnvironmentVariablesResultMap;
export declare const ListTriggersEnvironmentVariablesResponse: S.Schema<ListTriggersEnvironmentVariablesResponse>;
export type TriggersCreateBuildRequestSeedRepoProvider = "github" | "gitlab" | "gitlab_internal";
export declare const TriggersCreateBuildRequestSeedRepoProvider: any;
export interface TriggersCreateBuildRequestSeedRepoFilesItem {
    content: string;
    filename: string;
    isBase64?: boolean;
    /** Text to replace in the file */
    replace?: string;
}
export declare const TriggersCreateBuildRequestSeedRepoFilesItem: S.Schema<TriggersCreateBuildRequestSeedRepoFilesItem>;
export type TriggersCreateBuildRequestSeedRepoFilesList = Array<TriggersCreateBuildRequestSeedRepoFilesItem>;
export declare const TriggersCreateBuildRequestSeedRepoFilesList: S.Schema<TriggersCreateBuildRequestSeedRepoFilesList>;
export interface TriggersCreateBuildRequestSeedRepo {
    /** Git branch name. */
    branch: string;
    owner: string;
    path: string;
    provider: TriggersCreateBuildRequestSeedRepoProvider | (string & {});
    repository: string;
    files?: TriggersCreateBuildRequestSeedRepoFilesList;
}
export declare const TriggersCreateBuildRequestSeedRepo: S.Schema<TriggersCreateBuildRequestSeedRepo>;
export interface TriggersCreateBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Git branch name (required if commit_hash not provided) */
    branch?: string;
    /** Git commit hash (required if branch not provided) */
    commitHash?: string;
    seedRepo?: TriggersCreateBuildRequestSeedRepo;
}
export declare const TriggersCreateBuildRequest: S.Schema<TriggersCreateBuildRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TriggersCreateBuildResponse {
    /** Build UUID. */
    buildUuid?: string | null;
    createdOn?: string | null;
}
export declare const TriggersCreateBuildResponse: S.Schema<TriggersCreateBuildResponse>;
export interface TriggersPurgeCacheRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export declare const TriggersPurgeCacheRequest: S.Schema<TriggersPurgeCacheRequest>;
export type TriggersPurgeCacheResponse = unknown;
export declare const TriggersPurgeCacheResponse: S.Schema<TriggersPurgeCacheResponse>;
export type UpdateTriggerRequestBranchExcludesList = Array<string>;
export declare const UpdateTriggerRequestBranchExcludesList: S.Schema<UpdateTriggerRequestBranchExcludesList>;
export type UpdateTriggerRequestBranchIncludesList = Array<string>;
export declare const UpdateTriggerRequestBranchIncludesList: S.Schema<UpdateTriggerRequestBranchIncludesList>;
export type UpdateTriggerRequestPathExcludesList = Array<string>;
export declare const UpdateTriggerRequestPathExcludesList: S.Schema<UpdateTriggerRequestPathExcludesList>;
export type UpdateTriggerRequestPathIncludesList = Array<string>;
export declare const UpdateTriggerRequestPathIncludesList: S.Schema<UpdateTriggerRequestPathIncludesList>;
export interface UpdateTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    branchExcludes?: UpdateTriggerRequestBranchExcludesList;
    branchIncludes?: UpdateTriggerRequestBranchIncludesList;
    buildCachingEnabled?: boolean;
    buildCommand?: string;
    /** Build token UUID. */
    buildTokenUuid?: string;
    deployCommand?: string;
    pathExcludes?: UpdateTriggerRequestPathExcludesList;
    pathIncludes?: UpdateTriggerRequestPathIncludesList;
    /** Root directory path. */
    rootDirectory?: string;
    triggerName?: string;
}
export declare const UpdateTriggerRequest: S.Schema<UpdateTriggerRequest>;
export type UpdateTriggerResponseBranchExcludesList = Array<string>;
export declare const UpdateTriggerResponseBranchExcludesList: S.Schema<UpdateTriggerResponseBranchExcludesList>;
export type UpdateTriggerResponseBranchIncludesList = Array<string>;
export declare const UpdateTriggerResponseBranchIncludesList: S.Schema<UpdateTriggerResponseBranchIncludesList>;
export type UpdateTriggerResponsePathExcludesList = Array<string>;
export declare const UpdateTriggerResponsePathExcludesList: S.Schema<UpdateTriggerResponsePathExcludesList>;
export type UpdateTriggerResponsePathIncludesList = Array<string>;
export declare const UpdateTriggerResponsePathIncludesList: S.Schema<UpdateTriggerResponsePathIncludesList>;
export type UpdateTriggerResponseRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const UpdateTriggerResponseRepoConnectionProviderType: any;
export interface UpdateTriggerResponseRepoConnection {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: UpdateTriggerResponseRepoConnectionProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const UpdateTriggerResponseRepoConnection: S.Schema<UpdateTriggerResponseRepoConnection>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTriggerResponse {
    branchExcludes?: UpdateTriggerResponseBranchExcludesList | null;
    branchIncludes?: UpdateTriggerResponseBranchIncludesList | null;
    buildCachingEnabled?: boolean | null;
    buildCommand?: string | null;
    buildTokenName?: string | null;
    /** Build token UUID. */
    buildTokenUuid?: string | null;
    createdOn?: string | null;
    deletedOn?: string | null;
    deployCommand?: string | null;
    /** System-generated worker script tag. */
    externalScriptId?: string | null;
    modifiedOn?: string | null;
    pathExcludes?: UpdateTriggerResponsePathExcludesList | null;
    pathIncludes?: UpdateTriggerResponsePathIncludesList | null;
    repoConnection?: UpdateTriggerResponseRepoConnection | null;
    /** Root directory path. */
    rootDirectory?: string | null;
    triggerName?: string | null;
    /** Trigger UUID. */
    triggerUuid?: string | null;
}
export declare const UpdateTriggerResponse: S.Schema<UpdateTriggerResponse>;
export type UpsertReposConnectionRequestProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const UpsertReposConnectionRequestProviderType: any;
export interface UpsertReposConnectionRequest {
    /** Account identifier. */
    accountId: string;
    /** Provider account identifier. */
    providerAccountId: string;
    providerAccountName: string;
    providerType: UpsertReposConnectionRequestProviderType | (string & {});
    /** Repository identifier. */
    repoId: string;
    repoName: string;
}
export declare const UpsertReposConnectionRequest: S.Schema<UpsertReposConnectionRequest>;
export type UpsertReposConnectionResponseProviderType = "github" | "gitlab" | "gitlab_internal";
export declare const UpsertReposConnectionResponseProviderType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpsertReposConnectionResponse {
    createdOn?: string | null;
    deletedOn?: string | null;
    modifiedOn?: string | null;
    /** Provider account identifier. */
    providerAccountId?: string | null;
    providerAccountName?: string | null;
    providerType?: UpsertReposConnectionResponseProviderType | null;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null;
    /** Repository identifier. */
    repoId?: string | null;
    repoName?: string | null;
}
export declare const UpsertReposConnectionResponse: S.Schema<UpsertReposConnectionResponse>;
export interface UpsertTriggersEnvironmentVariableRequestBodyValue {
    isSecret: boolean;
    value?: string;
}
export declare const UpsertTriggersEnvironmentVariableRequestBodyValue: S.Schema<UpsertTriggersEnvironmentVariableRequestBodyValue>;
export type UpsertTriggersEnvironmentVariableRequestBodyMap = {
    [key: string]: UpsertTriggersEnvironmentVariableRequestBodyValue | undefined;
};
export declare const UpsertTriggersEnvironmentVariableRequestBodyMap: S.Schema<UpsertTriggersEnvironmentVariableRequestBodyMap>;
export interface UpsertTriggersEnvironmentVariableRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    body: UpsertTriggersEnvironmentVariableRequestBodyMap;
}
export declare const UpsertTriggersEnvironmentVariableRequest: S.Schema<UpsertTriggersEnvironmentVariableRequest>;
export type UpsertTriggersEnvironmentVariableResultValue = ListTriggersEnvironmentVariablesResultValue;
export declare const UpsertTriggersEnvironmentVariableResultValue: S.Schema<ListTriggersEnvironmentVariablesResultValue>;
export type UpsertTriggersEnvironmentVariableResultMap = {
    [key: string]: ListTriggersEnvironmentVariablesResultValue | undefined;
};
export declare const UpsertTriggersEnvironmentVariableResultMap: S.Schema<UpsertTriggersEnvironmentVariableResultMap>;
export type UpsertTriggersEnvironmentVariableResponse = UpsertTriggersEnvironmentVariableResultMap;
export declare const UpsertTriggersEnvironmentVariableResponse: S.Schema<UpsertTriggersEnvironmentVariableResponse>;
export type CancelBuildError = CloudflareOpError;
/** Cancel a running or queued build */
export declare const cancelBuild: API.OperationMethod<CancelBuildRequest, CancelBuildResponse, CancelBuildError, CloudflareOpContext>;
export type CreateTokenError = CloudflareOpError;
/** Create a new build authentication token */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type CreateTriggerError = CloudflareOpError;
/** Create a new CI/CD trigger */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest, CreateTriggerResponse, CreateTriggerError, CloudflareOpContext>;
export type DeleteReposConnectionError = CloudflareOpError;
/** Remove a repository connection */
export declare const deleteReposConnection: API.OperationMethod<DeleteReposConnectionRequest, DeleteReposConnectionResponse, DeleteReposConnectionError, CloudflareOpContext>;
export type DeleteTokenError = CloudflareOpError;
/** Remove a build authentication token */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type DeleteTriggerError = CloudflareOpError;
/** Remove a CI/CD trigger */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest, DeleteTriggerResponse, DeleteTriggerError, CloudflareOpContext>;
export type DeleteTriggersEnvironmentVariableError = CloudflareOpError;
/** Remove a specific environment variable from a trigger */
export declare const deleteTriggersEnvironmentVariable: API.OperationMethod<DeleteTriggersEnvironmentVariableRequest, DeleteTriggersEnvironmentVariableResponse, DeleteTriggersEnvironmentVariableError, CloudflareOpContext>;
export type DeployHooksCreateError = CloudflareOpError;
/** Create a new deploy hook for a worker script. */
export declare const deployHooksCreate: API.OperationMethod<DeployHooksCreateRequest, DeployHooksCreateResponse, DeployHooksCreateError, CloudflareOpContext>;
export type DeployHooksDeleteError = CloudflareOpError;
/** Delete a deploy hook. */
export declare const deployHooksDelete: API.OperationMethod<DeployHooksDeleteRequest, DeployHooksDeleteResponse, DeployHooksDeleteError, CloudflareOpContext>;
export type DeployHooksGetError = CloudflareOpError;
/** Get details of a specific deploy hook. */
export declare const deployHooksGet: API.OperationMethod<DeployHooksGetRequest, DeployHooksGetResponse, DeployHooksGetError, CloudflareOpContext>;
export type DeployHooksListError = CloudflareOpError;
/** Get all deploy hooks for a specific worker script. */
export declare const deployHooksList: API.OperationMethod<DeployHooksListRequest, DeployHooksListResponse, DeployHooksListError, CloudflareOpContext>;
export type DeployHooksTriggerError = CloudflareOpError;
/** Trigger a build using a deploy hook. This endpoint does not require authentication - the deploy_hook_uuid acts as a secret token. */
export declare const deployHooksTrigger: API.OperationMethod<DeployHooksTriggerRequest, DeployHooksTriggerResponse, DeployHooksTriggerError, CloudflareOpContext>;
export type DeployHooksUpdateError = CloudflareOpError;
/** Update an existing deploy hook. */
export declare const deployHooksUpdate: API.OperationMethod<DeployHooksUpdateRequest, DeployHooksUpdateResponse, DeployHooksUpdateError, CloudflareOpContext>;
export type GetAccountLimitsError = CloudflareOpError;
/** Retrieve account limits and usage information */
export declare const getAccountLimits: API.OperationMethod<GetAccountLimitsRequest, GetAccountLimitsResponse, GetAccountLimitsError, CloudflareOpContext>;
export type GetBuildError = CloudflareOpError;
/** Retrieve detailed information about a specific build */
export declare const getBuild: API.OperationMethod<GetBuildRequest, GetBuildResponse, GetBuildError, CloudflareOpContext>;
export type GetBuildsByVersionError = CloudflareOpError;
/** Retrieve builds for specific version IDs */
export declare const getBuildsByVersion: API.OperationMethod<GetBuildsByVersionRequest, GetBuildsByVersionResponse, GetBuildsByVersionError, CloudflareOpContext>;
export type GetBuildsLogError = CloudflareOpError;
/** Retrieve logs for a specific build with cursor-based pagination */
export declare const getBuildsLog: API.OperationMethod<GetBuildsLogRequest, GetBuildsLogResponse, GetBuildsLogError, CloudflareOpContext>;
export type GetLatestBuildsError = CloudflareOpError;
/** Retrieve the most recent builds for multiple worker scripts */
export declare const getLatestBuilds: API.OperationMethod<GetLatestBuildsRequest, GetLatestBuildsResponse, GetLatestBuildsError, CloudflareOpContext>;
export type GetReposConfigAutofillError = CloudflareOpError;
/** Analyze repository for automatic configuration detection */
export declare const getReposConfigAutofill: API.OperationMethod<GetReposConfigAutofillRequest, GetReposConfigAutofillResponse, GetReposConfigAutofillError, CloudflareOpContext>;
export type ListBuildsError = CloudflareOpError;
/** Get all builds for a specific worker script with pagination */
export declare const listBuilds: API.OperationMethod<ListBuildsRequest, ListBuildsResponse, ListBuildsError, CloudflareOpContext>;
export type ListTokensError = CloudflareOpError;
/** Get all build tokens with pagination */
export declare const listTokens: API.OperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext>;
export type ListTriggersError = CloudflareOpError;
/** Get all triggers for a specific worker script */
export declare const listTriggers: API.OperationMethod<ListTriggersRequest, ListTriggersResponse, ListTriggersError, CloudflareOpContext>;
export type ListTriggersEnvironmentVariablesError = CloudflareOpError;
/** Get all environment variables for a trigger */
export declare const listTriggersEnvironmentVariables: API.OperationMethod<ListTriggersEnvironmentVariablesRequest, ListTriggersEnvironmentVariablesResponse, ListTriggersEnvironmentVariablesError, CloudflareOpContext>;
export type TriggersCreateBuildError = CloudflareOpError;
/** Trigger a manual build for a specific trigger */
export declare const triggersCreateBuild: API.OperationMethod<TriggersCreateBuildRequest, TriggersCreateBuildResponse, TriggersCreateBuildError, CloudflareOpContext>;
export type TriggersPurgeCacheError = CloudflareOpError;
/** Clear the build cache for a specific trigger */
export declare const triggersPurgeCache: API.OperationMethod<TriggersPurgeCacheRequest, TriggersPurgeCacheResponse, TriggersPurgeCacheError, CloudflareOpContext>;
export type UpdateTriggerError = CloudflareOpError;
/** Update an existing CI/CD trigger */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest, UpdateTriggerResponse, UpdateTriggerError, CloudflareOpContext>;
export type UpsertReposConnectionError = CloudflareOpError;
/** Upsert a repository connection for CI/CD integration */
export declare const upsertReposConnection: API.OperationMethod<UpsertReposConnectionRequest, UpsertReposConnectionResponse, UpsertReposConnectionError, CloudflareOpContext>;
export type UpsertTriggersEnvironmentVariableError = CloudflareOpError;
/** Create or update environment variables for a trigger */
export declare const upsertTriggersEnvironmentVariable: API.OperationMethod<UpsertTriggersEnvironmentVariableRequest, UpsertTriggersEnvironmentVariableResponse, UpsertTriggersEnvironmentVariableError, CloudflareOpContext>;
//# sourceMappingURL=workers_builds.d.ts.map