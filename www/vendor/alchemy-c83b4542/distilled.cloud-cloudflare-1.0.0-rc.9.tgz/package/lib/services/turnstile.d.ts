import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const WidgetNotFound_base: S.Class<WidgetNotFound, S.TaggedStruct<"WidgetNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WidgetNotFound extends /*@__PURE__*/ WidgetNotFound_base {
}
export type WidgetsCreateRequestDirection = "asc" | "desc";
export declare const WidgetsCreateRequestDirection: any;
export type WidgetsCreateRequestOrder = "id" | "sitekey" | "name" | "created_on" | "modified_on";
export declare const WidgetsCreateRequestOrder: any;
export type WidgetsCreateRequestDomainsList = Array<string>;
export declare const WidgetsCreateRequestDomainsList: S.Schema<WidgetsCreateRequestDomainsList>;
export type WidgetsCreateRequestMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsCreateRequestMode: any;
export type WidgetsCreateRequestClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsCreateRequestClearanceLevel: any;
export type WidgetsCreateRequestRegion = "world" | "china";
export declare const WidgetsCreateRequestRegion: any;
export interface CreateWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Direction to order widgets. */
    direction?: WidgetsCreateRequestDirection | (string & {});
    /** Filter widgets by field using case-insensitive substring matching. */
    filter?: string;
    /** Field to order widgets by. */
    order?: WidgetsCreateRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
    domains: WidgetsCreateRequestDomainsList;
    /** Widget Mode */
    mode: WidgetsCreateRequestMode | (string & {});
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode?: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel?: WidgetsCreateRequestClearanceLevel | (string & {});
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId?: boolean;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel?: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region?: WidgetsCreateRequestRegion | (string & {});
}
export declare const CreateWidgetRequest: S.Schema<CreateWidgetRequest>;
export type WidgetsCreateResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsCreateResponseClearanceLevel: any;
export type WidgetsCreateResponseDomainsList = Array<string>;
export declare const WidgetsCreateResponseDomainsList: S.Schema<WidgetsCreateResponseDomainsList>;
export type WidgetsCreateResponseMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsCreateResponseMode: any;
export type WidgetsCreateResponseRegion = "world" | "china";
export declare const WidgetsCreateResponseRegion: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel: WidgetsCreateResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsCreateResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsCreateResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsCreateResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const CreateWidgetResponse: S.Schema<CreateWidgetResponse>;
export interface DeleteWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const DeleteWidgetRequest: S.Schema<DeleteWidgetRequest>;
export type WidgetsDeleteResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsDeleteResponseClearanceLevel: any;
export type WidgetsDeleteResponseDomainsList = Array<string>;
export declare const WidgetsDeleteResponseDomainsList: S.Schema<WidgetsDeleteResponseDomainsList>;
export type WidgetsDeleteResponseMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsDeleteResponseMode: any;
export type WidgetsDeleteResponseRegion = "world" | "china";
export declare const WidgetsDeleteResponseRegion: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel: WidgetsDeleteResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsDeleteResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsDeleteResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsDeleteResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const DeleteWidgetResponse: S.Schema<DeleteWidgetResponse>;
export interface GetWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const GetWidgetRequest: S.Schema<GetWidgetRequest>;
export type WidgetsGetResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsGetResponseClearanceLevel: any;
export type WidgetsGetResponseDomainsList = Array<string>;
export declare const WidgetsGetResponseDomainsList: S.Schema<WidgetsGetResponseDomainsList>;
export type WidgetsGetResponseMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsGetResponseMode: any;
export type WidgetsGetResponseRegion = "world" | "china";
export declare const WidgetsGetResponseRegion: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel: WidgetsGetResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsGetResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsGetResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsGetResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const GetWidgetResponse: S.Schema<GetWidgetResponse>;
export type WidgetsListRequestDirection = "asc" | "desc";
export declare const WidgetsListRequestDirection: any;
export type WidgetsListRequestOrder = "id" | "sitekey" | "name" | "created_on" | "modified_on";
export declare const WidgetsListRequestOrder: any;
export interface ListWidgetsRequest {
    /** Identifier */
    accountId: string;
    /** Direction to order widgets. */
    direction?: WidgetsListRequestDirection | (string & {});
    /** Filter widgets by field using case-insensitive substring matching. */
    filter?: string;
    /** Field to order widgets by. */
    order?: WidgetsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
}
export declare const ListWidgetsRequest: S.Schema<ListWidgetsRequest>;
export type WidgetsListResultItemClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsListResultItemClearanceLevel: any;
export type WidgetsListResultItemDomainsList = Array<string>;
export declare const WidgetsListResultItemDomainsList: S.Schema<WidgetsListResultItemDomainsList>;
export type WidgetsListResultItemMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsListResultItemMode: any;
export type WidgetsListResultItemRegion = "world" | "china";
export declare const WidgetsListResultItemRegion: any;
export interface WidgetsListResultItem {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel: WidgetsListResultItemClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsListResultItemDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsListResultItemMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsListResultItemRegion;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const WidgetsListResultItem: S.Schema<WidgetsListResultItem>;
export type WidgetsListResultList = Array<WidgetsListResultItem>;
export declare const WidgetsListResultList: S.Schema<WidgetsListResultList>;
export interface ListWidgetsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WidgetsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListWidgetsResponse: S.Schema<ListWidgetsResponse>;
export interface RotateSecretWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Widget item identifier tag. */
    sitekey: string;
    /** If `invalidate_immediately` is set to `false`, the previous secret will */
    invalidateImmediately?: boolean;
}
export declare const RotateSecretWidgetRequest: S.Schema<RotateSecretWidgetRequest>;
export type WidgetsRotateSecretResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsRotateSecretResponseClearanceLevel: any;
export type WidgetsRotateSecretResponseDomainsList = Array<string>;
export declare const WidgetsRotateSecretResponseDomainsList: S.Schema<WidgetsRotateSecretResponseDomainsList>;
export type WidgetsRotateSecretResponseMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsRotateSecretResponseMode: any;
export type WidgetsRotateSecretResponseRegion = "world" | "china";
export declare const WidgetsRotateSecretResponseRegion: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface RotateSecretWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel: WidgetsRotateSecretResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsRotateSecretResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsRotateSecretResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsRotateSecretResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const RotateSecretWidgetResponse: S.Schema<RotateSecretWidgetResponse>;
export type WidgetsUpdateRequestDomainsList = Array<string>;
export declare const WidgetsUpdateRequestDomainsList: S.Schema<WidgetsUpdateRequestDomainsList>;
export type WidgetsUpdateRequestMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsUpdateRequestMode: any;
export type WidgetsUpdateRequestClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsUpdateRequestClearanceLevel: any;
export type WidgetsUpdateRequestRegion = "world" | "china";
export declare const WidgetsUpdateRequestRegion: any;
export interface UpdateWidgetRequest {
    /** Identifier */
    accountId: string;
    /** Widget item identifier tag. */
    sitekey: string;
    domains: WidgetsUpdateRequestDomainsList;
    /** Widget Mode */
    mode: WidgetsUpdateRequestMode | (string & {});
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode?: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel?: WidgetsUpdateRequestClearanceLevel | (string & {});
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId?: boolean;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel?: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region?: WidgetsUpdateRequestRegion | (string & {});
}
export declare const UpdateWidgetRequest: S.Schema<UpdateWidgetRequest>;
export type WidgetsUpdateResponseClearanceLevel = "no_clearance" | "jschallenge" | "managed" | "interactive";
export declare const WidgetsUpdateResponseClearanceLevel: any;
export type WidgetsUpdateResponseDomainsList = Array<string>;
export declare const WidgetsUpdateResponseDomainsList: S.Schema<WidgetsUpdateResponseDomainsList>;
export type WidgetsUpdateResponseMode = "non-interactive" | "invisible" | "managed";
export declare const WidgetsUpdateResponseMode: any;
export type WidgetsUpdateResponseRegion = "world" | "china";
export declare const WidgetsUpdateResponseRegion: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateWidgetResponse {
    /** If bot_fight_mode is set to `true`, Cloudflare issues computationally */
    botFightMode: boolean;
    /** If Turnstile is embedded on a Cloudflare site and the widget should grant challenge clearance, */
    clearanceLevel: WidgetsUpdateResponseClearanceLevel;
    /** When the widget was created. */
    createdOn: string;
    domains: WidgetsUpdateResponseDomainsList;
    /** Return the Ephemeral ID in /siteverify (ENT only). */
    ephemeralId: boolean;
    /** Widget Mode */
    mode: WidgetsUpdateResponseMode;
    /** When the widget was modified. */
    modifiedOn: string;
    /** Human readable widget name. Not unique. Cloudflare suggests that you */
    name: string;
    /** Do not show any Cloudflare branding on the widget (ENT only). */
    offlabel: boolean;
    /** Region where this widget can be used. This cannot be changed after creation. */
    region: WidgetsUpdateResponseRegion;
    /** Secret key for this widget. */
    secret: string;
    /** Widget item identifier tag. */
    sitekey: string;
}
export declare const UpdateWidgetResponse: S.Schema<UpdateWidgetResponse>;
export type CreateWidgetError = CloudflareOpError;
/** Lists challenge widgets. */
export declare const createWidget: API.OperationMethod<CreateWidgetRequest, CreateWidgetResponse, CreateWidgetError, CloudflareOpContext>;
export type DeleteWidgetError = WidgetNotFound | Forbidden | CloudflareOpError;
/** Destroy a Turnstile Widget. */
export declare const deleteWidget: API.OperationMethod<DeleteWidgetRequest, DeleteWidgetResponse, DeleteWidgetError, CloudflareOpContext>;
export type GetWidgetError = WidgetNotFound | Forbidden | CloudflareOpError;
/** Show a single challenge widget configuration. */
export declare const getWidget: API.OperationMethod<GetWidgetRequest, GetWidgetResponse, GetWidgetError, CloudflareOpContext>;
export type ListWidgetsError = CloudflareOpError;
/** Lists all turnstile widgets of an account. */
export declare const listWidgets: API.PaginatedOperationMethod<ListWidgetsRequest, ListWidgetsResponse, ListWidgetsError, CloudflareOpContext, WidgetsListResultItem>;
export type RotateSecretWidgetError = CloudflareOpError;
/** Generate a new secret key for this widget. If `invalidate_immediately` is set to `false`, the previous secret remains valid for 2 hours. Note that secrets cannot be rotated again during the grace period. */
export declare const rotateSecretWidget: API.OperationMethod<RotateSecretWidgetRequest, RotateSecretWidgetResponse, RotateSecretWidgetError, CloudflareOpContext>;
export type UpdateWidgetError = CloudflareOpError;
/** Update the configuration of a widget. */
export declare const updateWidget: API.OperationMethod<UpdateWidgetRequest, UpdateWidgetResponse, UpdateWidgetError, CloudflareOpContext>;
//# sourceMappingURL=turnstile.d.ts.map