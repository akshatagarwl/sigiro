import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenName_base: S.Class<InvalidTokenName, S.TaggedStruct<"InvalidTokenName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidTokenName extends /*@__PURE__*/ InvalidTokenName_base {
}
declare const MethodNotAllowed_base: S.Class<MethodNotAllowed, S.TaggedStruct<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const PermissionGroupNotFound_base: S.Class<PermissionGroupNotFound, S.TaggedStruct<"PermissionGroupNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PermissionGroupNotFound extends /*@__PURE__*/ PermissionGroupNotFound_base {
}
declare const TokenNotFound_base: S.Class<TokenNotFound, S.TaggedStruct<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
export type TokensCreateRequestPoliciesItemEffect = "allow" | "deny";
export declare const TokensCreateRequestPoliciesItemEffect: any;
export interface TokensCreateRequestPoliciesItemPermissionGroupsItemMeta {
    key?: string;
    value?: string;
}
export declare const TokensCreateRequestPoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItemMeta>;
export interface TokensCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
    /** Name of the permission group. */
    name?: string;
}
export declare const TokensCreateRequestPoliciesItemPermissionGroupsItem: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensCreateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const TokensCreateRequestPoliciesItemPermissionGroupsList: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsList>;
export type TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensCreateRequestPoliciesItemResourcesValue = string | TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensCreateRequestPoliciesItemResourcesValue: any;
export type TokensCreateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensCreateRequestPoliciesItemResourcesValue | undefined;
};
export declare const TokensCreateRequestPoliciesItemResourcesMap: S.Schema<TokensCreateRequestPoliciesItemResourcesMap>;
export interface TokensCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensCreateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateRequestPoliciesItemResourcesMap;
}
export declare const TokensCreateRequestPoliciesItem: S.Schema<TokensCreateRequestPoliciesItem>;
export type TokensCreateRequestPoliciesList = Array<TokensCreateRequestPoliciesItem>;
export declare const TokensCreateRequestPoliciesList: S.Schema<TokensCreateRequestPoliciesList>;
export type TokensCreateRequestConditionRequestIpInList = Array<string>;
export declare const TokensCreateRequestConditionRequestIpInList: S.Schema<TokensCreateRequestConditionRequestIpInList>;
export type TokensCreateRequestConditionRequestIpNotInList = Array<string>;
export declare const TokensCreateRequestConditionRequestIpNotInList: S.Schema<TokensCreateRequestConditionRequestIpNotInList>;
export interface TokensCreateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateRequestConditionRequestIpNotInList;
}
export declare const TokensCreateRequestConditionRequestIp: S.Schema<TokensCreateRequestConditionRequestIp>;
export interface TokensCreateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateRequestConditionRequestIp;
}
export declare const TokensCreateRequestCondition: S.Schema<TokensCreateRequestCondition>;
export interface CreateTokenRequest {
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensCreateRequestPoliciesList;
    condition?: TokensCreateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
}
export declare const CreateTokenRequest: S.Schema<CreateTokenRequest>;
export type TokensCreateResponseConditionRequestIpInList = Array<string>;
export declare const TokensCreateResponseConditionRequestIpInList: S.Schema<TokensCreateResponseConditionRequestIpInList>;
export type TokensCreateResponseConditionRequestIpNotInList = Array<string>;
export declare const TokensCreateResponseConditionRequestIpNotInList: S.Schema<TokensCreateResponseConditionRequestIpNotInList>;
export interface TokensCreateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateResponseConditionRequestIpNotInList | null;
}
export declare const TokensCreateResponseConditionRequestIp: S.Schema<TokensCreateResponseConditionRequestIp>;
export interface TokensCreateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateResponseConditionRequestIp | null;
}
export declare const TokensCreateResponseCondition: S.Schema<TokensCreateResponseCondition>;
export type TokensCreateResponsePoliciesItemEffect = "allow" | "deny";
export declare const TokensCreateResponsePoliciesItemEffect: any;
export interface TokensCreateResponsePoliciesItemPermissionGroupsItemMeta {
    key?: string | null;
    value?: string | null;
}
export declare const TokensCreateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export interface TokensCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export declare const TokensCreateResponsePoliciesItemPermissionGroupsItem: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensCreateResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensCreateResponsePoliciesItemPermissionGroupsList: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsList>;
export type TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensCreateResponsePoliciesItemResourcesValue = string | TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensCreateResponsePoliciesItemResourcesValue: any;
export type TokensCreateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensCreateResponsePoliciesItemResourcesValue | undefined;
};
export declare const TokensCreateResponsePoliciesItemResourcesMap: S.Schema<TokensCreateResponsePoliciesItemResourcesMap>;
export interface TokensCreateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensCreateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateResponsePoliciesItemResourcesMap;
}
export declare const TokensCreateResponsePoliciesItem: S.Schema<TokensCreateResponsePoliciesItem>;
export type TokensCreateResponsePoliciesList = Array<TokensCreateResponsePoliciesItem>;
export declare const TokensCreateResponsePoliciesList: S.Schema<TokensCreateResponsePoliciesList>;
export type TokensCreateResponseStatus = "active" | "disabled" | "expired";
export declare const TokensCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensCreateResponseCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensCreateResponsePoliciesList | null;
    /** Status of the token. */
    status?: TokensCreateResponseStatus | null;
    /** The token value. */
    value?: string | null;
}
export declare const CreateTokenResponse: S.Schema<CreateTokenResponse>;
export interface DeleteOrganizationRequest {
    /** Identifier */
    organizationId: string;
}
export declare const DeleteOrganizationRequest: S.Schema<DeleteOrganizationRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteOrganizationResponse {
    /** Identifier */
    id?: string | null;
}
export declare const DeleteOrganizationResponse: S.Schema<DeleteOrganizationResponse>;
export interface DeleteSubscriptionRequest {
    /** Subscription identifier tag. */
    identifier: string;
}
export declare const DeleteSubscriptionRequest: S.Schema<DeleteSubscriptionRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface DeleteSubscriptionResponse {
    /** Subscription identifier tag. */
    subscriptionId?: string | null;
}
export declare const DeleteSubscriptionResponse: S.Schema<DeleteSubscriptionResponse>;
export interface DeleteTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
}
export declare const DeleteTokenRequest: S.Schema<DeleteTokenRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTokenResponse {
    /** Identifier */
    id: string;
}
export declare const DeleteTokenResponse: S.Schema<DeleteTokenResponse>;
export interface GetBillingProfileRequest {
}
export declare const GetBillingProfileRequest: S.Schema<GetBillingProfileRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetBillingProfileResponse {
    /** Billing item identifier tag. */
    id?: string | null;
    accountType?: string | null;
    address?: string | null;
    address2?: string | null;
    balance?: string | null;
    cardExpiryMonth?: number | null;
    cardExpiryYear?: number | null;
    cardNumber?: string | null;
    city?: string | null;
    company?: string | null;
    country?: string | null;
    createdOn?: string | null;
    deviceData?: string | null;
    editedOn?: string | null;
    enterpriseBillingEmail?: string | null;
    enterprisePrimaryEmail?: string | null;
    firstName?: string | null;
    isPartner?: boolean | null;
    lastName?: string | null;
    nextBillDate?: string | null;
    paymentAddress?: string | null;
    paymentAddress2?: string | null;
    paymentCity?: string | null;
    paymentCountry?: string | null;
    paymentEmail?: string | null;
    paymentFirstName?: string | null;
    paymentGateway?: string | null;
    paymentLastName?: string | null;
    paymentNonce?: string | null;
    paymentState?: string | null;
    paymentZipcode?: string | null;
    primaryEmail?: string | null;
    state?: string | null;
    taxIdType?: string | null;
    telephone?: string | null;
    useLegacy?: boolean | null;
    validationCode?: string | null;
    vat?: string | null;
    zipcode?: string | null;
}
export declare const GetBillingProfileResponse: S.Schema<GetBillingProfileResponse>;
export interface GetInviteRequest {
    /** Invite identifier tag. */
    inviteId: string;
}
export declare const GetInviteRequest: S.Schema<GetInviteRequest>;
export type InvitesGetResponseRolesList = Array<string>;
export declare const InvitesGetResponseRolesList: S.Schema<InvitesGetResponseRolesList>;
export type InvitesGetResponseStatus = "pending" | "accepted" | "rejected" | "expired";
export declare const InvitesGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInviteResponse {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null;
    /** When the invite is no longer active. */
    expiresOn?: string | null;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null;
    /** When the invite was sent. */
    invitedOn?: string | null;
    organizationIsEnforcingTwofactor?: boolean | null;
    /** Organization name. */
    organizationName?: string | null;
    /** List of role names the membership has for this account. */
    roles?: InvitesGetResponseRolesList | null;
    /** Current status of the invitation. */
    status?: InvitesGetResponseStatus | null;
}
export declare const GetInviteResponse: S.Schema<GetInviteResponse>;
export interface GetOrganizationRequest {
    /** Identifier */
    organizationId: string;
}
export declare const GetOrganizationRequest: S.Schema<GetOrganizationRequest>;
export type GetOrganizationResponse = unknown;
export declare const GetOrganizationResponse: S.Schema<GetOrganizationResponse>;
export interface GetSubscriptionRequest {
}
export declare const GetSubscriptionRequest: S.Schema<GetSubscriptionRequest>;
export type SubscriptionsGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsGetResultItemFrequency: any;
export type SubscriptionsGetResultItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsGetResultItemRatePlanId: any;
export type SubscriptionsGetResultItemRatePlanSetsList = Array<string>;
export declare const SubscriptionsGetResultItemRatePlanSetsList: S.Schema<SubscriptionsGetResultItemRatePlanSetsList>;
export interface SubscriptionsGetResultItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResultItemRatePlanId | null;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null;
    /** The full name of the rate plan. */
    publicName?: string | null;
    /** The scope that this rate plan applies to. */
    scope?: string | null;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResultItemRatePlanSetsList | null;
}
export declare const SubscriptionsGetResultItemRatePlan: S.Schema<SubscriptionsGetResultItemRatePlan>;
export type SubscriptionsGetResultItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export declare const SubscriptionsGetResultItemState: any;
export interface SubscriptionsGetResultItem {
    /** Subscription identifier tag. */
    id?: string | null;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResultItemFrequency | null;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResultItemRatePlan | null;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResultItemState | null;
}
export declare const SubscriptionsGetResultItem: S.Schema<SubscriptionsGetResultItem>;
export type SubscriptionsGetResultList = Array<SubscriptionsGetResultItem>;
export declare const SubscriptionsGetResultList: S.Schema<SubscriptionsGetResultList>;
export interface GetSubscriptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const GetSubscriptionResponse: S.Schema<GetSubscriptionResponse>;
export interface GetTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
}
export declare const GetTokenRequest: S.Schema<GetTokenRequest>;
export type TokensGetResponseConditionRequestIpInList = Array<string>;
export declare const TokensGetResponseConditionRequestIpInList: S.Schema<TokensGetResponseConditionRequestIpInList>;
export type TokensGetResponseConditionRequestIpNotInList = Array<string>;
export declare const TokensGetResponseConditionRequestIpNotInList: S.Schema<TokensGetResponseConditionRequestIpNotInList>;
export interface TokensGetResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensGetResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensGetResponseConditionRequestIpNotInList | null;
}
export declare const TokensGetResponseConditionRequestIp: S.Schema<TokensGetResponseConditionRequestIp>;
export interface TokensGetResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensGetResponseConditionRequestIp | null;
}
export declare const TokensGetResponseCondition: S.Schema<TokensGetResponseCondition>;
export type TokensGetResponsePoliciesItemEffect = "allow" | "deny";
export declare const TokensGetResponsePoliciesItemEffect: any;
export type TokensGetResponsePoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const TokensGetResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type TokensGetResponsePoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export declare const TokensGetResponsePoliciesItemPermissionGroupsItem: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensGetResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensGetResponsePoliciesItemPermissionGroupsList: S.Schema<TokensGetResponsePoliciesItemPermissionGroupsList>;
export type TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensGetResponsePoliciesItemResourcesValue = string | TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensGetResponsePoliciesItemResourcesValue: any;
export type TokensGetResponsePoliciesItemResourcesMap = {
    [key: string]: TokensGetResponsePoliciesItemResourcesValue | undefined;
};
export declare const TokensGetResponsePoliciesItemResourcesMap: S.Schema<TokensGetResponsePoliciesItemResourcesMap>;
export interface TokensGetResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensGetResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensGetResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensGetResponsePoliciesItemResourcesMap;
}
export declare const TokensGetResponsePoliciesItem: S.Schema<TokensGetResponsePoliciesItem>;
export type TokensGetResponsePoliciesList = Array<TokensGetResponsePoliciesItem>;
export declare const TokensGetResponsePoliciesList: S.Schema<TokensGetResponsePoliciesList>;
export type TokensGetResponseStatus = "active" | "disabled" | "expired";
export declare const TokensGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensGetResponseCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensGetResponsePoliciesList | null;
    /** Status of the token. */
    status?: TokensGetResponseStatus | null;
}
export declare const GetTokenResponse: S.Schema<GetTokenResponse>;
export interface GetUserRequest {
}
export declare const GetUserRequest: S.Schema<GetUserRequest>;
export type GetResponseBetasList = Array<string>;
export declare const GetResponseBetasList: S.Schema<GetResponseBetasList>;
export type GetResponseOrganizationsItemPermissionsList = Array<unknown>;
export declare const GetResponseOrganizationsItemPermissionsList: S.Schema<GetResponseOrganizationsItemPermissionsList>;
export type GetResponseOrganizationsItemRolesList = Array<string>;
export declare const GetResponseOrganizationsItemRolesList: S.Schema<GetResponseOrganizationsItemRolesList>;
export type GetResponseOrganizationsItemStatus = "member" | "invited";
export declare const GetResponseOrganizationsItemStatus: any;
export interface GetResponseOrganizationsItem {
    /** Identifier */
    id?: string | null;
    /** Organization name. */
    name?: string | null;
    /** Access permissions for this User. */
    permissions?: GetResponseOrganizationsItemPermissionsList | null;
    /** List of roles that a user has within an organization. */
    roles?: GetResponseOrganizationsItemRolesList | null;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: GetResponseOrganizationsItemStatus | null;
}
export declare const GetResponseOrganizationsItem: S.Schema<GetResponseOrganizationsItem>;
export type GetResponseOrganizationsList = Array<GetResponseOrganizationsItem>;
export declare const GetResponseOrganizationsList: S.Schema<GetResponseOrganizationsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUserResponse {
    /** Identifier of the user. */
    id: string;
    /** Current email address of the user. */
    email: string;
    /** Lists the betas that the user is participating in. */
    betas?: GetResponseBetasList | null;
    /** The country in which the user lives. */
    country?: string | null;
    /** User's first name */
    firstName?: string | null;
    /** Indicates whether user has any business zones */
    hasBusinessZones?: boolean | null;
    /** Indicates whether user has any enterprise zones */
    hasEnterpriseZones?: boolean | null;
    /** Indicates whether user has any pro zones */
    hasProZones?: boolean | null;
    /** User's last name */
    lastName?: string | null;
    organizations?: GetResponseOrganizationsList | null;
    /** Indicates whether user has been suspended */
    suspended?: boolean | null;
    /** User's telephone number */
    telephone?: string | null;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null;
    /** Indicates whether two-factor authentication is required by one of the accounts that the user is a member of. */
    twoFactorAuthenticationLocked?: boolean | null;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string | null;
}
export declare const GetUserResponse: S.Schema<GetUserResponse>;
export interface AuditLogsListRequestAction {
    /** Filters by the action type. */
    type?: string;
}
export declare const AuditLogsListRequestAction: S.Schema<AuditLogsListRequestAction>;
export interface AuditLogsListRequestActor {
    /** Filters by the email address of the actor that made the change. */
    email?: string;
    /** Filters by the IP address of the request that made the change by specific IP address or valid CIDR Range. */
    ip?: string;
}
export declare const AuditLogsListRequestActor: S.Schema<AuditLogsListRequestActor>;
export type AuditLogsListRequestDirection = "desc" | "asc";
export declare const AuditLogsListRequestDirection: any;
export interface AuditLogsListRequestZone {
    /** Filters by the name of the zone associated to the change. */
    name?: string;
}
export declare const AuditLogsListRequestZone: S.Schema<AuditLogsListRequestZone>;
export interface ListAuditLogsRequest {
    /** Finds a specific log by its ID. */
    id?: string;
    action?: AuditLogsListRequestAction;
    actor?: AuditLogsListRequestActor;
    /** Limits the returned results to logs older than the specified date. A `full-date` that conforms to RFC3339. */
    before?: string;
    /** Changes the direction of the chronological sorting. */
    direction?: AuditLogsListRequestDirection | (string & {});
    /** Indicates that this request is an export of logs in CSV format. */
    export?: boolean;
    /** Indicates whether or not to hide user level audit logs. */
    hideUserLogs?: boolean;
    /** Defines which page of results to return. */
    page?: number;
    /** Sets the number of results to return per page. */
    perPage?: number;
    /** Limits the returned results to logs newer than the specified date. A `full-date` that conforms to RFC3339. */
    since?: string;
    zone?: AuditLogsListRequestZone;
}
export declare const ListAuditLogsRequest: S.Schema<ListAuditLogsRequest>;
export interface AuditLogsListResultItemAction {
    /** A boolean that indicates if the action attempted was successful. */
    result?: boolean | null;
    /** A short string that describes the action that was performed. */
    type?: string | null;
}
export declare const AuditLogsListResultItemAction: S.Schema<AuditLogsListResultItemAction>;
export type AuditLogsListResultItemActorType = "user" | "admin" | "Cloudflare";
export declare const AuditLogsListResultItemActorType: any;
export interface AuditLogsListResultItemActor {
    /** The ID of the actor that performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null;
    /** The email of the user that performed the action. */
    email?: string | null;
    /** The IP address of the request that performed the action. */
    ip?: string | null;
    /** The type of actor, whether a User, Cloudflare Admin, or an Automated System. */
    type?: AuditLogsListResultItemActorType | null;
}
export declare const AuditLogsListResultItemActor: S.Schema<AuditLogsListResultItemActor>;
export interface AuditLogsListResultItemOwner {
    /** Identifier */
    id?: string | null;
}
export declare const AuditLogsListResultItemOwner: S.Schema<AuditLogsListResultItemOwner>;
export interface AuditLogsListResultItemResource {
    /** An identifier for the resource that was affected by the action. */
    id?: string | null;
    /** A short string that describes the resource that was affected by the action. */
    type?: string | null;
}
export declare const AuditLogsListResultItemResource: S.Schema<AuditLogsListResultItemResource>;
export interface AuditLogsListResultItem {
    /** A string that uniquely identifies the audit log. */
    id?: string | null;
    action?: AuditLogsListResultItemAction | null;
    actor?: AuditLogsListResultItemActor | null;
    /** The source of the event. */
    interface?: string | null;
    /** An object which can lend more context to the action being logged. This is a flexible value and varies between different actions. */
    metadata?: unknown | null;
    /** The new value of the resource that was modified. */
    newValue?: string | null;
    /** The value of the resource before it was modified. */
    oldValue?: string | null;
    owner?: AuditLogsListResultItemOwner | null;
    resource?: AuditLogsListResultItemResource | null;
    /** A UTC RFC3339 timestamp that specifies when the action being logged occured. */
    when?: string | null;
}
export declare const AuditLogsListResultItem: S.Schema<AuditLogsListResultItem>;
export type AuditLogsListResultList = Array<AuditLogsListResultItem>;
export declare const AuditLogsListResultList: S.Schema<AuditLogsListResultList>;
export interface ListAuditLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AuditLogsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAuditLogsResponse: S.Schema<ListAuditLogsResponse>;
export type BillingHistoryListRequestOrder = "type" | "occurred_at" | "action";
export declare const BillingHistoryListRequestOrder: any;
export interface ListBillingHistoriesRequest {
    /** The billing item action. */
    action?: string;
    /** When the billing item was created. */
    occurredAt?: string;
    /** Field to order billing history by. */
    order?: BillingHistoryListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of items per page. */
    perPage?: number;
    /** The billing item type. */
    type?: string;
}
export declare const ListBillingHistoriesRequest: S.Schema<ListBillingHistoriesRequest>;
export interface BillingHistoryListResultItemZone {
    name?: string | null;
}
export declare const BillingHistoryListResultItemZone: S.Schema<BillingHistoryListResultItemZone>;
export interface BillingHistoryListResultItem {
    /** Billing item identifier tag. */
    id: string;
    /** The billing item action. */
    action: string;
    /** The amount associated with this billing item. */
    amount: number;
    /** The monetary unit in which pricing information is displayed. */
    currency: string;
    /** The billing item description. */
    description: string;
    /** When the billing item was created. */
    occurredAt: string;
    /** The billing item type. */
    type: string;
    zone: BillingHistoryListResultItemZone;
}
export declare const BillingHistoryListResultItem: S.Schema<BillingHistoryListResultItem>;
export type BillingHistoryListResultList = Array<BillingHistoryListResultItem>;
export declare const BillingHistoryListResultList: S.Schema<BillingHistoryListResultList>;
export interface ListBillingHistoriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: BillingHistoryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListBillingHistoriesResponse: S.Schema<ListBillingHistoriesResponse>;
export interface ListInvitesRequest {
}
export declare const ListInvitesRequest: S.Schema<ListInvitesRequest>;
export type InvitesListResultItemRolesList = Array<string>;
export declare const InvitesListResultItemRolesList: S.Schema<InvitesListResultItemRolesList>;
export type InvitesListResultItemStatus = "pending" | "accepted" | "rejected" | "expired";
export declare const InvitesListResultItemStatus: any;
export interface InvitesListResultItem {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null;
    /** When the invite is no longer active. */
    expiresOn?: string | null;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null;
    /** When the invite was sent. */
    invitedOn?: string | null;
    organizationIsEnforcingTwofactor?: boolean | null;
    /** Organization name. */
    organizationName?: string | null;
    /** List of role names the membership has for this account. */
    roles?: InvitesListResultItemRolesList | null;
    /** Current status of the invitation. */
    status?: InvitesListResultItemStatus | null;
}
export declare const InvitesListResultItem: S.Schema<InvitesListResultItem>;
export type InvitesListResultList = Array<InvitesListResultItem>;
export declare const InvitesListResultList: S.Schema<InvitesListResultList>;
export interface ListInvitesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvitesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInvitesResponse: S.Schema<ListInvitesResponse>;
export type OrganizationsListRequestDirection = "asc" | "desc";
export declare const OrganizationsListRequestDirection: any;
export type OrganizationsListRequestMatch = "any" | "all";
export declare const OrganizationsListRequestMatch: any;
export type OrganizationsListRequestOrder = "id" | "name" | "status";
export declare const OrganizationsListRequestOrder: any;
export type OrganizationsListRequestStatus = "member" | "invited";
export declare const OrganizationsListRequestStatus: any;
export interface ListOrganizationsRequest {
    /** Direction to order organizations. */
    direction?: OrganizationsListRequestDirection | (string & {});
    /** Whether to match all search requirements or at least one (any). */
    match?: OrganizationsListRequestMatch | (string & {});
    /** Organization name. */
    name?: string;
    /** Field to order organizations by. */
    order?: OrganizationsListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of organizations per page. */
    perPage?: number;
    /** Whether the user is a member of the organization or has an inivitation pending. */
    status?: OrganizationsListRequestStatus | (string & {});
}
export declare const ListOrganizationsRequest: S.Schema<ListOrganizationsRequest>;
export type OrganizationsListResultItemPermissionsList = Array<unknown>;
export declare const OrganizationsListResultItemPermissionsList: S.Schema<OrganizationsListResultItemPermissionsList>;
export type OrganizationsListResultItemRolesList = Array<string>;
export declare const OrganizationsListResultItemRolesList: S.Schema<OrganizationsListResultItemRolesList>;
export type OrganizationsListResultItemStatus = "member" | "invited";
export declare const OrganizationsListResultItemStatus: any;
export interface OrganizationsListResultItem {
    /** Identifier */
    id?: string | null;
    /** Organization name. */
    name?: string | null;
    /** Access permissions for this User. */
    permissions?: OrganizationsListResultItemPermissionsList | null;
    /** List of roles that a user has within an organization. */
    roles?: OrganizationsListResultItemRolesList | null;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: OrganizationsListResultItemStatus | null;
}
export declare const OrganizationsListResultItem: S.Schema<OrganizationsListResultItem>;
export type OrganizationsListResultList = Array<OrganizationsListResultItem>;
export declare const OrganizationsListResultList: S.Schema<OrganizationsListResultList>;
export interface ListOrganizationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OrganizationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOrganizationsResponse: S.Schema<ListOrganizationsResponse>;
export interface ListTenantsRequest {
}
export declare const ListTenantsRequest: S.Schema<ListTenantsRequest>;
export interface TenantsListResultItemMetaFlags {
    accountCreation: string;
    accountDeletion: string;
    accountMigration: string;
    accountMobility: string;
    subOrgCreation: string;
}
export declare const TenantsListResultItemMetaFlags: S.Schema<TenantsListResultItemMetaFlags>;
export type TenantsListResultItemMetaHierarchyTagsList = Array<string>;
export declare const TenantsListResultItemMetaHierarchyTagsList: S.Schema<TenantsListResultItemMetaHierarchyTagsList>;
export interface TenantsListResultItemMeta {
    /** Enable features for Organizations. */
    flags?: TenantsListResultItemMetaFlags | null;
    /** Ordered chain of organization tags from the root organization down to */
    hierarchyTags?: TenantsListResultItemMetaHierarchyTagsList | null;
    managedBy?: string | null;
}
export declare const TenantsListResultItemMeta: S.Schema<TenantsListResultItemMeta>;
export interface TenantsListResultItemParent {
    id: string;
    name: string;
}
export declare const TenantsListResultItemParent: S.Schema<TenantsListResultItemParent>;
export interface TenantsListResultItemProfile {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export declare const TenantsListResultItemProfile: S.Schema<TenantsListResultItemProfile>;
export interface TenantsListResultItem {
    id: string;
    createTime: string;
    meta: TenantsListResultItemMeta;
    name: string;
    parent?: TenantsListResultItemParent | null;
    profile?: TenantsListResultItemProfile | null;
}
export declare const TenantsListResultItem: S.Schema<TenantsListResultItem>;
export type TenantsListResultList = Array<TenantsListResultItem>;
export declare const TenantsListResultList: S.Schema<TenantsListResultList>;
export interface ListTenantsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TenantsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListTenantsResponse: S.Schema<ListTenantsResponse>;
export interface ListTokenPermissionGroupsRequest {
    /** Filter by the name of the permission group. */
    name?: string;
    /** Filter by the scope of the permission group. */
    scope?: string;
}
export declare const ListTokenPermissionGroupsRequest: S.Schema<ListTokenPermissionGroupsRequest>;
export type TokensPermissionGroupsListResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export declare const TokensPermissionGroupsListResultItemCategory: any;
export type TokensPermissionGroupsListResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export declare const TokensPermissionGroupsListResultItemScopesItem: any;
export type TokensPermissionGroupsListResultItemScopesList = Array<TokensPermissionGroupsListResultItemScopesItem>;
export declare const TokensPermissionGroupsListResultItemScopesList: S.Schema<TokensPermissionGroupsListResultItemScopesList>;
export interface TokensPermissionGroupsListResultItem {
    /** Public ID. */
    id?: string | null;
    /** Product category that this permission group belongs to. */
    category?: TokensPermissionGroupsListResultItemCategory | null;
    /** Permission Group Name */
    name?: string | null;
    /** Resources to which the Permission Group is scoped */
    scopes?: TokensPermissionGroupsListResultItemScopesList | null;
}
export declare const TokensPermissionGroupsListResultItem: S.Schema<TokensPermissionGroupsListResultItem>;
export type TokensPermissionGroupsListResultList = Array<TokensPermissionGroupsListResultItem>;
export declare const TokensPermissionGroupsListResultList: S.Schema<TokensPermissionGroupsListResultList>;
export interface ListTokenPermissionGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensPermissionGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListTokenPermissionGroupsResponse: S.Schema<ListTokenPermissionGroupsResponse>;
export type TokensListRequestDirection = "asc" | "desc";
export declare const TokensListRequestDirection: any;
export interface ListTokensRequest {
    /** Direction to order results. */
    direction?: TokensListRequestDirection | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListTokensRequest: S.Schema<ListTokensRequest>;
export type TokensListResultItemConditionRequestIpInList = Array<string>;
export declare const TokensListResultItemConditionRequestIpInList: S.Schema<TokensListResultItemConditionRequestIpInList>;
export type TokensListResultItemConditionRequestIpNotInList = Array<string>;
export declare const TokensListResultItemConditionRequestIpNotInList: S.Schema<TokensListResultItemConditionRequestIpNotInList>;
export interface TokensListResultItemConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensListResultItemConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensListResultItemConditionRequestIpNotInList | null;
}
export declare const TokensListResultItemConditionRequestIp: S.Schema<TokensListResultItemConditionRequestIp>;
export interface TokensListResultItemCondition {
    /** Client IP restrictions. */
    requestIp?: TokensListResultItemConditionRequestIp | null;
}
export declare const TokensListResultItemCondition: S.Schema<TokensListResultItemCondition>;
export type TokensListResultItemPoliciesItemEffect = "allow" | "deny";
export declare const TokensListResultItemPoliciesItemEffect: any;
export type TokensListResultItemPoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const TokensListResultItemPoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type TokensListResultItemPoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export declare const TokensListResultItemPoliciesItemPermissionGroupsItem: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensListResultItemPoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensListResultItemPoliciesItemPermissionGroupsList: S.Schema<TokensListResultItemPoliciesItemPermissionGroupsList>;
export type TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensListResultItemPoliciesItemResourcesValue = string | TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensListResultItemPoliciesItemResourcesValue: any;
export type TokensListResultItemPoliciesItemResourcesMap = {
    [key: string]: TokensListResultItemPoliciesItemResourcesValue | undefined;
};
export declare const TokensListResultItemPoliciesItemResourcesMap: S.Schema<TokensListResultItemPoliciesItemResourcesMap>;
export interface TokensListResultItemPoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensListResultItemPoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensListResultItemPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensListResultItemPoliciesItemResourcesMap;
}
export declare const TokensListResultItemPoliciesItem: S.Schema<TokensListResultItemPoliciesItem>;
export type TokensListResultItemPoliciesList = Array<TokensListResultItemPoliciesItem>;
export declare const TokensListResultItemPoliciesList: S.Schema<TokensListResultItemPoliciesList>;
export type TokensListResultItemStatus = "active" | "disabled" | "expired";
export declare const TokensListResultItemStatus: any;
export interface TokensListResultItem {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensListResultItemCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensListResultItemPoliciesList | null;
    /** Status of the token. */
    status?: TokensListResultItemStatus | null;
}
export declare const TokensListResultItem: S.Schema<TokensListResultItem>;
export type TokensListResultList = Array<TokensListResultItem>;
export declare const TokensListResultList: S.Schema<TokensListResultList>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListTokensResponse: S.Schema<ListTokensResponse>;
export type InvitesEditRequestStatus = "accepted" | "rejected";
export declare const InvitesEditRequestStatus: any;
export interface PatchInviteRequest {
    /** Invite identifier tag. */
    inviteId: string;
    /** Status of your response to the invitation (rejected or accepted). */
    status: InvitesEditRequestStatus | (string & {});
}
export declare const PatchInviteRequest: S.Schema<PatchInviteRequest>;
export type InvitesEditResponseRolesList = Array<string>;
export declare const InvitesEditResponseRolesList: S.Schema<InvitesEditResponseRolesList>;
export type InvitesEditResponseStatus = "pending" | "accepted" | "rejected" | "expired";
export declare const InvitesEditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchInviteResponse {
    /** ID of the user to add to the organization. */
    invitedMemberId: string;
    /** ID of the organization the user will be added to. */
    organizationId: string;
    /** Invite identifier tag. */
    id?: string | null;
    /** When the invite is no longer active. */
    expiresOn?: string | null;
    /** The email address of the user who created the invite. */
    invitedBy?: string | null;
    /** Email address of the user to add to the organization. */
    invitedMemberEmail?: string | null;
    /** When the invite was sent. */
    invitedOn?: string | null;
    organizationIsEnforcingTwofactor?: boolean | null;
    /** Organization name. */
    organizationName?: string | null;
    /** List of role names the membership has for this account. */
    roles?: InvitesEditResponseRolesList | null;
    /** Current status of the invitation. */
    status?: InvitesEditResponseStatus | null;
}
export declare const PatchInviteResponse: S.Schema<PatchInviteResponse>;
export interface PatchUserRequest {
    /** The country in which the user lives. */
    country?: string;
    /** User's first name */
    firstName?: string;
    /** User's last name */
    lastName?: string;
    /** User's telephone number */
    telephone?: string;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string;
}
export declare const PatchUserRequest: S.Schema<PatchUserRequest>;
export type EditResponseBetasList = Array<string>;
export declare const EditResponseBetasList: S.Schema<EditResponseBetasList>;
export type EditResponseOrganizationsItemPermissionsList = Array<unknown>;
export declare const EditResponseOrganizationsItemPermissionsList: S.Schema<EditResponseOrganizationsItemPermissionsList>;
export type EditResponseOrganizationsItemRolesList = Array<string>;
export declare const EditResponseOrganizationsItemRolesList: S.Schema<EditResponseOrganizationsItemRolesList>;
export type EditResponseOrganizationsItemStatus = "member" | "invited";
export declare const EditResponseOrganizationsItemStatus: any;
export interface EditResponseOrganizationsItem {
    /** Identifier */
    id?: string | null;
    /** Organization name. */
    name?: string | null;
    /** Access permissions for this User. */
    permissions?: EditResponseOrganizationsItemPermissionsList | null;
    /** List of roles that a user has within an organization. */
    roles?: EditResponseOrganizationsItemRolesList | null;
    /** Whether the user is a member of the organization or has an invitation pending. */
    status?: EditResponseOrganizationsItemStatus | null;
}
export declare const EditResponseOrganizationsItem: S.Schema<EditResponseOrganizationsItem>;
export type EditResponseOrganizationsList = Array<EditResponseOrganizationsItem>;
export declare const EditResponseOrganizationsList: S.Schema<EditResponseOrganizationsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchUserResponse {
    /** Identifier of the user. */
    id: string;
    /** Current email address of the user. */
    email: string;
    /** Lists the betas that the user is participating in. */
    betas?: EditResponseBetasList | null;
    /** The country in which the user lives. */
    country?: string | null;
    /** User's first name */
    firstName?: string | null;
    /** Indicates whether user has any business zones */
    hasBusinessZones?: boolean | null;
    /** Indicates whether user has any enterprise zones */
    hasEnterpriseZones?: boolean | null;
    /** Indicates whether user has any pro zones */
    hasProZones?: boolean | null;
    /** User's last name */
    lastName?: string | null;
    organizations?: EditResponseOrganizationsList | null;
    /** Indicates whether user has been suspended */
    suspended?: boolean | null;
    /** User's telephone number */
    telephone?: string | null;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null;
    /** Indicates whether two-factor authentication is required by one of the accounts that the user is a member of. */
    twoFactorAuthenticationLocked?: boolean | null;
    /** The zipcode or postal code where the user lives. */
    zipcode?: string | null;
}
export declare const PatchUserResponse: S.Schema<PatchUserResponse>;
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export declare const SubscriptionsUpdateRequestFrequency: any;
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export declare const SubscriptionsUpdateRequestRatePlanId: any;
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export declare const SubscriptionsUpdateRequestRatePlanSetsList: S.Schema<SubscriptionsUpdateRequestRatePlanSetsList>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {});
    /** The currency applied to the rate plan subscription. */
    currency?: string;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean;
    /** The full name of the rate plan. */
    publicName?: string;
    /** The scope that this rate plan applies to. */
    scope?: string;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList;
}
export declare const SubscriptionsUpdateRequestRatePlan: S.Schema<SubscriptionsUpdateRequestRatePlan>;
export interface PutSubscriptionRequest {
    /** Subscription identifier tag. */
    identifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {});
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan;
}
export declare const PutSubscriptionRequest: S.Schema<PutSubscriptionRequest>;
export type PutSubscriptionResponse = unknown;
export declare const PutSubscriptionResponse: S.Schema<PutSubscriptionResponse>;
export interface PutTokenValueRequest {
    /** Token identifier tag. */
    tokenId: string;
}
export declare const PutTokenValueRequest: S.Schema<PutTokenValueRequest>;
export type PutTokenValueResponse = unknown;
export declare const PutTokenValueResponse: S.Schema<PutTokenValueResponse>;
export type TokensUpdateRequestPoliciesItemEffect = "allow" | "deny";
export declare const TokensUpdateRequestPoliciesItemEffect: any;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta = TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
export declare const TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItemMeta>;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItem = TokensCreateRequestPoliciesItemPermissionGroupsItem;
export declare const TokensUpdateRequestPoliciesItemPermissionGroupsItem: S.Schema<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensUpdateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export declare const TokensUpdateRequestPoliciesItemPermissionGroupsList: S.Schema<TokensUpdateRequestPoliciesItemPermissionGroupsList>;
export type TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensUpdateRequestPoliciesItemResourcesValue = string | TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensUpdateRequestPoliciesItemResourcesValue: any;
export type TokensUpdateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensUpdateRequestPoliciesItemResourcesValue | undefined;
};
export declare const TokensUpdateRequestPoliciesItemResourcesMap: S.Schema<TokensUpdateRequestPoliciesItemResourcesMap>;
export interface TokensUpdateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateRequestPoliciesItemResourcesMap;
}
export declare const TokensUpdateRequestPoliciesItem: S.Schema<TokensUpdateRequestPoliciesItem>;
export type TokensUpdateRequestPoliciesList = Array<TokensUpdateRequestPoliciesItem>;
export declare const TokensUpdateRequestPoliciesList: S.Schema<TokensUpdateRequestPoliciesList>;
export type TokensUpdateRequestConditionRequestIpInList = Array<string>;
export declare const TokensUpdateRequestConditionRequestIpInList: S.Schema<TokensUpdateRequestConditionRequestIpInList>;
export type TokensUpdateRequestConditionRequestIpNotInList = Array<string>;
export declare const TokensUpdateRequestConditionRequestIpNotInList: S.Schema<TokensUpdateRequestConditionRequestIpNotInList>;
export interface TokensUpdateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateRequestConditionRequestIpInList;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateRequestConditionRequestIpNotInList;
}
export declare const TokensUpdateRequestConditionRequestIp: S.Schema<TokensUpdateRequestConditionRequestIp>;
export interface TokensUpdateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateRequestConditionRequestIp;
}
export declare const TokensUpdateRequestCondition: S.Schema<TokensUpdateRequestCondition>;
export type TokensUpdateRequestStatus = "active" | "disabled" | "expired";
export declare const TokensUpdateRequestStatus: any;
export interface UpdateTokenRequest {
    /** Token identifier tag. */
    tokenId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensUpdateRequestPoliciesList;
    condition?: TokensUpdateRequestCondition;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string;
    /** Status of the token. */
    status?: TokensUpdateRequestStatus | (string & {});
}
export declare const UpdateTokenRequest: S.Schema<UpdateTokenRequest>;
export type TokensUpdateResponseConditionRequestIpInList = Array<string>;
export declare const TokensUpdateResponseConditionRequestIpInList: S.Schema<TokensUpdateResponseConditionRequestIpInList>;
export type TokensUpdateResponseConditionRequestIpNotInList = Array<string>;
export declare const TokensUpdateResponseConditionRequestIpNotInList: S.Schema<TokensUpdateResponseConditionRequestIpNotInList>;
export interface TokensUpdateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateResponseConditionRequestIpInList | null;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateResponseConditionRequestIpNotInList | null;
}
export declare const TokensUpdateResponseConditionRequestIp: S.Schema<TokensUpdateResponseConditionRequestIp>;
export interface TokensUpdateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateResponseConditionRequestIp | null;
}
export declare const TokensUpdateResponseCondition: S.Schema<TokensUpdateResponseCondition>;
export type TokensUpdateResponsePoliciesItemEffect = "allow" | "deny";
export declare const TokensUpdateResponsePoliciesItemEffect: any;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta = TokensCreateResponsePoliciesItemPermissionGroupsItemMeta;
export declare const TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItemMeta>;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItem = TokensCreateResponsePoliciesItemPermissionGroupsItem;
export declare const TokensUpdateResponsePoliciesItemPermissionGroupsItem: S.Schema<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensUpdateResponsePoliciesItemPermissionGroupsList = Array<TokensCreateResponsePoliciesItemPermissionGroupsItem>;
export declare const TokensUpdateResponsePoliciesItemPermissionGroupsList: S.Schema<TokensUpdateResponsePoliciesItemPermissionGroupsList>;
export type TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export declare const TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap: S.Schema<TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap>;
export type TokensUpdateResponsePoliciesItemResourcesValue = string | TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export declare const TokensUpdateResponsePoliciesItemResourcesValue: any;
export type TokensUpdateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensUpdateResponsePoliciesItemResourcesValue | undefined;
};
export declare const TokensUpdateResponsePoliciesItemResourcesMap: S.Schema<TokensUpdateResponsePoliciesItemResourcesMap>;
export interface TokensUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateResponsePoliciesItemResourcesMap;
}
export declare const TokensUpdateResponsePoliciesItem: S.Schema<TokensUpdateResponsePoliciesItem>;
export type TokensUpdateResponsePoliciesList = Array<TokensUpdateResponsePoliciesItem>;
export declare const TokensUpdateResponsePoliciesList: S.Schema<TokensUpdateResponsePoliciesList>;
export type TokensUpdateResponseStatus = "active" | "disabled" | "expired";
export declare const TokensUpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    /** Token identifier tag. */
    id?: string | null;
    condition?: TokensUpdateResponseCondition | null;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time on which the token was created. */
    issuedOn?: string | null;
    /** Last time the token was used. */
    lastUsedOn?: string | null;
    /** Last time the token was modified. */
    modifiedOn?: string | null;
    /** Token name. */
    name?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
    /** List of access policies assigned to the token. */
    policies?: TokensUpdateResponsePoliciesList | null;
    /** Status of the token. */
    status?: TokensUpdateResponseStatus | null;
}
export declare const UpdateTokenResponse: S.Schema<UpdateTokenResponse>;
export interface VerifyTokenRequest {
}
export declare const VerifyTokenRequest: S.Schema<VerifyTokenRequest>;
export type TokensVerifyResponseStatus = "active" | "disabled" | "expired";
export declare const TokensVerifyResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface VerifyTokenResponse {
    /** Token identifier tag. */
    id: string;
    /** Status of the token. */
    status: TokensVerifyResponseStatus;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null;
}
export declare const VerifyTokenResponse: S.Schema<VerifyTokenResponse>;
export type CreateTokenError = InvalidRoute | InvalidTokenName | PermissionGroupNotFound | CloudflareOpError;
/** Create a new access token. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteOrganizationError = CloudflareOpError;
/** Removes association to an organization. */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest, DeleteOrganizationResponse, DeleteOrganizationError, CloudflareOpContext>;
export type DeleteSubscriptionError = CloudflareOpError;
/** Deletes a user's subscription. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type DeleteTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | CloudflareOpError;
/** Destroy a token. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type GetBillingProfileError = CloudflareOpError;
/** Accesses your billing profile object. */
export declare const getBillingProfile: API.OperationMethod<GetBillingProfileRequest, GetBillingProfileResponse, GetBillingProfileError, CloudflareOpContext>;
export type GetInviteError = CloudflareOpError;
/** Gets the details of an invitation. */
export declare const getInvite: API.OperationMethod<GetInviteRequest, GetInviteResponse, GetInviteError, CloudflareOpContext>;
export type GetOrganizationError = CloudflareOpError;
/** Gets a specific organization the user is associated with. */
export declare const getOrganization: API.OperationMethod<GetOrganizationRequest, GetOrganizationResponse, GetOrganizationError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists all of a user's subscriptions. */
export declare const getSubscription: API.PaginatedOperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext, SubscriptionsGetResultItem>;
export type GetTokenError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Get information about a specific token. */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, CloudflareOpContext>;
export type GetUserError = CloudflareOpError;
/** Retrieves detailed information about the currently authenticated user, including email, name, and account memberships. */
export declare const getUser: API.OperationMethod<GetUserRequest, GetUserResponse, GetUserError, CloudflareOpContext>;
export type ListAuditLogsError = CloudflareOpError;
/** Gets a list of audit logs for a user account. Can be filtered by who made the change, on which zone, and the timeframe of the change. */
export declare const listAuditLogs: API.PaginatedOperationMethod<ListAuditLogsRequest, ListAuditLogsResponse, ListAuditLogsError, CloudflareOpContext, AuditLogsListResultItem>;
export type ListBillingHistoriesError = CloudflareOpError;
/** Accesses your billing history object. */
export declare const listBillingHistories: API.PaginatedOperationMethod<ListBillingHistoriesRequest, ListBillingHistoriesResponse, ListBillingHistoriesError, CloudflareOpContext, BillingHistoryListResultItem>;
export type ListInvitesError = CloudflareOpError;
/** Lists all invitations associated with my user. */
export declare const listInvites: API.PaginatedOperationMethod<ListInvitesRequest, ListInvitesResponse, ListInvitesError, CloudflareOpContext, InvitesListResultItem>;
export type ListOrganizationsError = CloudflareOpError;
/** Lists organizations the user is associated with. */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest, ListOrganizationsResponse, ListOrganizationsError, CloudflareOpContext, OrganizationsListResultItem>;
export type ListTenantsError = CloudflareOpError;
/** Retrieves list of tenants the authenticated user / method has access to. */
export declare const listTenants: API.PaginatedOperationMethod<ListTenantsRequest, ListTenantsResponse, ListTenantsError, CloudflareOpContext, TenantsListResultItem>;
export type ListTokenPermissionGroupsError = CloudflareOpError;
/** Find all available permission groups for API Tokens. */
export declare const listTokenPermissionGroups: API.PaginatedOperationMethod<ListTokenPermissionGroupsRequest, ListTokenPermissionGroupsResponse, ListTokenPermissionGroupsError, CloudflareOpContext, TokensPermissionGroupsListResultItem>;
export type ListTokensError = CloudflareOpError;
/** List all access tokens you created. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type PatchInviteError = CloudflareOpError;
/** Responds to an invitation. */
export declare const patchInvite: API.OperationMethod<PatchInviteRequest, PatchInviteResponse, PatchInviteError, CloudflareOpContext>;
export type PatchUserError = CloudflareOpError;
/** Edit part of your user details. */
export declare const patchUser: API.OperationMethod<PatchUserRequest, PatchUserResponse, PatchUserError, CloudflareOpContext>;
export type PutSubscriptionError = CloudflareOpError;
/** Updates a user's subscriptions. */
export declare const putSubscription: API.OperationMethod<PutSubscriptionRequest, PutSubscriptionResponse, PutSubscriptionError, CloudflareOpContext>;
export type PutTokenValueError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Roll the token secret. */
export declare const putTokenValue: API.OperationMethod<PutTokenValueRequest, PutTokenValueResponse, PutTokenValueError, CloudflareOpContext>;
export type UpdateTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | PermissionGroupNotFound | CloudflareOpError;
/** Update an existing token. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type VerifyTokenError = Forbidden | CloudflareOpError;
/** Test whether a token works. */
export declare const verifyToken: API.OperationMethod<VerifyTokenRequest, VerifyTokenResponse, VerifyTokenError, CloudflareOpContext>;
//# sourceMappingURL=user.d.ts.map