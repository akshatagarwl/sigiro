import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ListAlreadyExists_base: S.Class<ListAlreadyExists, S.TaggedStruct<"ListAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ListAlreadyExists extends /*@__PURE__*/ ListAlreadyExists_base {
}
declare const ListNotFound_base: S.Class<ListNotFound, S.TaggedStruct<"ListNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ListNotFound extends /*@__PURE__*/ ListNotFound_base {
}
export type ListsCreateRequestKind = "ip" | "redirect" | "hostname" | "asn";
export declare const ListsCreateRequestKind: any;
export interface CreateListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsCreateRequestKind | (string & {});
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** An informative summary of the list. */
    description?: string;
}
export declare const CreateListRequest: S.Schema<CreateListRequest>;
export type ListsCreateResponseKind = "ip" | "redirect" | "hostname" | "asn";
export declare const ListsCreateResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateListResponse {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsCreateResponseKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export declare const CreateListResponse: S.Schema<CreateListResponse>;
export interface ListsItemsCreateRequestBodyItemListsListItemIPComment {
    /** An IPv4 address, an IPv4 CIDR, an IPv6 address, or an IPv6 CIDR. */
    ip: string;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export declare const ListsItemsCreateRequestBodyItemListsListItemIPComment: S.Schema<ListsItemsCreateRequestBodyItemListsListItemIPComment>;
export type ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode = 301 | 302 | 307 | 308;
export declare const ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode: any;
export interface ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean;
    preservePathSuffix?: boolean;
    preserveQueryString?: boolean;
    statusCode?: ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode | (number & {});
    subpathMatching?: boolean;
}
export declare const ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirect: S.Schema<ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirect>;
export interface ListsItemsCreateRequestBodyItemListsListItemRedirectComment {
    /** The definition of the redirect. */
    redirect: ListsItemsCreateRequestBodyItemListsListItemRedirectCommentRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export declare const ListsItemsCreateRequestBodyItemListsListItemRedirectComment: S.Schema<ListsItemsCreateRequestBodyItemListsListItemRedirectComment>;
export interface ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname {
    urlHostname: string;
    /** Only applies to wildcard hostnames (e.g., *.example.com). When true (default), only subdomains are blocked. When false, both the root domain and subdomains are blocked. */
    excludeExactHostname?: boolean;
}
export declare const ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname: S.Schema<ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname>;
export interface ListsItemsCreateRequestBodyItemListsListItemHostnameComment {
    /** Valid characters for hostnames are ASCII(7) letters from a to z, the digits from 0 to 9, wildcards (*), and the hyphen (-). */
    hostname: ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export declare const ListsItemsCreateRequestBodyItemListsListItemHostnameComment: S.Schema<ListsItemsCreateRequestBodyItemListsListItemHostnameComment>;
export interface ListsItemsCreateRequestBodyItemListsListItemASNComment {
    /** Defines a non-negative 32 bit integer. */
    asn: number;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export declare const ListsItemsCreateRequestBodyItemListsListItemASNComment: S.Schema<ListsItemsCreateRequestBodyItemListsListItemASNComment>;
export type ListsItemsCreateRequestBodyItem = ListsItemsCreateRequestBodyItemListsListItemIPComment | ListsItemsCreateRequestBodyItemListsListItemRedirectComment | ListsItemsCreateRequestBodyItemListsListItemHostnameComment | ListsItemsCreateRequestBodyItemListsListItemASNComment;
export declare const ListsItemsCreateRequestBodyItem: any;
export type ListsItemsCreateRequestBodyList = Array<ListsItemsCreateRequestBodyItem>;
export declare const ListsItemsCreateRequestBodyList: S.Schema<ListsItemsCreateRequestBodyList>;
export interface CreateListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    body: ListsItemsCreateRequestBodyList;
}
export declare const CreateListItemRequest: S.Schema<CreateListItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateListItemResponse {
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export declare const CreateListItemResponse: S.Schema<CreateListItemResponse>;
export interface DeleteListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
}
export declare const DeleteListRequest: S.Schema<DeleteListRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteListResponse {
    /** The unique ID of the list. */
    id: string;
}
export declare const DeleteListResponse: S.Schema<DeleteListResponse>;
export interface ListsItemsDeleteRequestItemsItem {
    /** Defines the unique ID of the item in the List. */
    id: string;
}
export declare const ListsItemsDeleteRequestItemsItem: S.Schema<ListsItemsDeleteRequestItemsItem>;
export type ListsItemsDeleteRequestItemsList = Array<ListsItemsDeleteRequestItemsItem>;
export declare const ListsItemsDeleteRequestItemsList: S.Schema<ListsItemsDeleteRequestItemsList>;
export interface DeleteListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    items?: ListsItemsDeleteRequestItemsList;
}
export declare const DeleteListItemRequest: S.Schema<DeleteListItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteListItemResponse {
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export declare const DeleteListItemResponse: S.Schema<DeleteListItemResponse>;
export interface GetListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
}
export declare const GetListRequest: S.Schema<GetListRequest>;
export type ListsGetResponseKind = "ip" | "redirect" | "hostname" | "asn";
export declare const ListsGetResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetListResponse {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsGetResponseKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export declare const GetListResponse: S.Schema<GetListResponse>;
export interface GetListBulkOperationRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export declare const GetListBulkOperationRequest: S.Schema<GetListBulkOperationRequest>;
export type ListsBulkOperationsGetResultListsBulkOperationPendingOrRunningStatus = "pending" | "running";
export declare const ListsBulkOperationsGetResultListsBulkOperationPendingOrRunningStatus: any;
export interface ListsBulkOperationsGetResultListsBulkOperationPendingOrRunning {
    /** The unique operation ID of the asynchronous action. */
    id: string;
    /** The current status of the asynchronous operation. */
    status: ListsBulkOperationsGetResultListsBulkOperationPendingOrRunningStatus;
}
export declare const ListsBulkOperationsGetResultListsBulkOperationPendingOrRunning: S.Schema<ListsBulkOperationsGetResultListsBulkOperationPendingOrRunning>;
export type ListsBulkOperationsGetResultListsBulkOperationCompletedStatus = "completed";
export declare const ListsBulkOperationsGetResultListsBulkOperationCompletedStatus: any;
export interface ListsBulkOperationsGetResultListsBulkOperationCompleted {
    /** The unique operation ID of the asynchronous action. */
    id: string;
    /** The RFC 3339 timestamp of when the operation was completed. */
    completed: string;
    /** The current status of the asynchronous operation. */
    status: ListsBulkOperationsGetResultListsBulkOperationCompletedStatus;
}
export declare const ListsBulkOperationsGetResultListsBulkOperationCompleted: S.Schema<ListsBulkOperationsGetResultListsBulkOperationCompleted>;
export type ListsBulkOperationsGetResultListsBulkOperationFailedStatus = "failed";
export declare const ListsBulkOperationsGetResultListsBulkOperationFailedStatus: any;
export interface ListsBulkOperationsGetResultListsBulkOperationFailed {
    /** The unique operation ID of the asynchronous action. */
    id: string;
    /** The RFC 3339 timestamp of when the operation was completed. */
    completed: string;
    /** A message describing the error when the status is `failed`. */
    error: string;
    /** The current status of the asynchronous operation. */
    status: ListsBulkOperationsGetResultListsBulkOperationFailedStatus;
}
export declare const ListsBulkOperationsGetResultListsBulkOperationFailed: S.Schema<ListsBulkOperationsGetResultListsBulkOperationFailed>;
export type ListsBulkOperationsGetResult = ListsBulkOperationsGetResultListsBulkOperationPendingOrRunning | ListsBulkOperationsGetResultListsBulkOperationCompleted | ListsBulkOperationsGetResultListsBulkOperationFailed;
export declare const ListsBulkOperationsGetResult: any;
export type GetListBulkOperationResponse = ListsBulkOperationsGetResult;
export declare const GetListBulkOperationResponse: S.Schema<GetListBulkOperationResponse>;
export interface GetListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    /** Defines the unique ID of the item in the List. */
    itemId: string;
}
export declare const GetListItemRequest: S.Schema<GetListItemRequest>;
export interface ListsItemsGetResultListsListItemIPFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** An IPv4 address, an IPv4 CIDR, an IPv6 address, or an IPv6 CIDR. */
    ip: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export declare const ListsItemsGetResultListsListItemIPFull: S.Schema<ListsItemsGetResultListsListItemIPFull>;
export interface ListsItemsGetResultListsListItemHostnameFullHostname {
    urlHostname: string;
    /** Only applies to wildcard hostnames (e.g., *.example.com). When true (default), only subdomains are blocked. When false, both the root domain and subdomains are blocked. */
    excludeExactHostname?: boolean | null;
}
export declare const ListsItemsGetResultListsListItemHostnameFullHostname: S.Schema<ListsItemsGetResultListsListItemHostnameFullHostname>;
export interface ListsItemsGetResultListsListItemHostnameFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** Valid characters for hostnames are ASCII(7) letters from a to z, the digits from 0 to 9, wildcards (*), and the hyphen (-). */
    hostname: ListsItemsGetResultListsListItemHostnameFullHostname;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export declare const ListsItemsGetResultListsListItemHostnameFull: S.Schema<ListsItemsGetResultListsListItemHostnameFull>;
export type ListsItemsGetResultListsListItemRedirectFullRedirectStatusCode = 301 | 302 | 307 | 308;
export declare const ListsItemsGetResultListsListItemRedirectFullRedirectStatusCode: any;
export interface ListsItemsGetResultListsListItemRedirectFullRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean | null;
    preservePathSuffix?: boolean | null;
    preserveQueryString?: boolean | null;
    statusCode?: ListsItemsGetResultListsListItemRedirectFullRedirectStatusCode | null;
    subpathMatching?: boolean | null;
}
export declare const ListsItemsGetResultListsListItemRedirectFullRedirect: S.Schema<ListsItemsGetResultListsListItemRedirectFullRedirect>;
export interface ListsItemsGetResultListsListItemRedirectFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** The definition of the redirect. */
    redirect: ListsItemsGetResultListsListItemRedirectFullRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export declare const ListsItemsGetResultListsListItemRedirectFull: S.Schema<ListsItemsGetResultListsListItemRedirectFull>;
export interface ListsItemsGetResultListsListItemASNFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** Defines a non-negative 32 bit integer. */
    asn: number;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export declare const ListsItemsGetResultListsListItemASNFull: S.Schema<ListsItemsGetResultListsListItemASNFull>;
export type ListsItemsGetResult = ListsItemsGetResultListsListItemIPFull | ListsItemsGetResultListsListItemHostnameFull | ListsItemsGetResultListsListItemRedirectFull | ListsItemsGetResultListsListItemASNFull;
export declare const ListsItemsGetResult: any;
export type GetListItemResponse = ListsItemsGetResult;
export declare const GetListItemResponse: S.Schema<GetListItemResponse>;
export interface ListListItemsRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    /** The pagination cursor. An opaque string token indicating the position from which to continue when requesting the next/previous set of records. Cursor values are provided under `result_info.cursors` in the response. You should make no assumptions about a cursor's content or length. */
    cursor?: string;
    /** Amount of results to include in each paginated response. A non-negative 32 bit integer. */
    perPage?: number;
    /** A search query to filter returned items. Its meaning depends on the list type: IP addresses must start with the provided string, hostnames and bulk redirects must contain the string, and ASNs must match the string exactly. */
    search?: string;
}
export declare const ListListItemsRequest: S.Schema<ListListItemsRequest>;
export type ListsItemsListResultItemListsListItemIPFull = ListsItemsGetResultListsListItemIPFull;
export declare const ListsItemsListResultItemListsListItemIPFull: S.Schema<ListsItemsGetResultListsListItemIPFull>;
export type ListsItemsListResultItemListsListItemHostnameFullHostname = ListsItemsGetResultListsListItemHostnameFullHostname;
export declare const ListsItemsListResultItemListsListItemHostnameFullHostname: S.Schema<ListsItemsGetResultListsListItemHostnameFullHostname>;
export type ListsItemsListResultItemListsListItemHostnameFull = ListsItemsGetResultListsListItemHostnameFull;
export declare const ListsItemsListResultItemListsListItemHostnameFull: S.Schema<ListsItemsGetResultListsListItemHostnameFull>;
export type ListsItemsListResultItemListsListItemRedirectFullRedirectStatusCode = 301 | 302 | 307 | 308;
export declare const ListsItemsListResultItemListsListItemRedirectFullRedirectStatusCode: any;
export interface ListsItemsListResultItemListsListItemRedirectFullRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean | null;
    preservePathSuffix?: boolean | null;
    preserveQueryString?: boolean | null;
    statusCode?: ListsItemsListResultItemListsListItemRedirectFullRedirectStatusCode | null;
    subpathMatching?: boolean | null;
}
export declare const ListsItemsListResultItemListsListItemRedirectFullRedirect: S.Schema<ListsItemsListResultItemListsListItemRedirectFullRedirect>;
export interface ListsItemsListResultItemListsListItemRedirectFull {
    /** Defines the unique ID of the item in the List. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** The definition of the redirect. */
    redirect: ListsItemsListResultItemListsListItemRedirectFullRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string | null;
}
export declare const ListsItemsListResultItemListsListItemRedirectFull: S.Schema<ListsItemsListResultItemListsListItemRedirectFull>;
export type ListsItemsListResultItemListsListItemASNFull = ListsItemsGetResultListsListItemASNFull;
export declare const ListsItemsListResultItemListsListItemASNFull: S.Schema<ListsItemsGetResultListsListItemASNFull>;
export type ListsItemsListResultItem = ListsItemsGetResultListsListItemIPFull | ListsItemsGetResultListsListItemHostnameFull | ListsItemsListResultItemListsListItemRedirectFull | ListsItemsGetResultListsListItemASNFull;
export declare const ListsItemsListResultItem: any;
export type ListsItemsListResultList = Array<ListsItemsListResultItem>;
export declare const ListsItemsListResultList: S.Schema<ListsItemsListResultList>;
export interface ListListItemsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListsItemsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListListItemsResponse: S.Schema<ListListItemsResponse>;
export interface ListListsRequest {
    /** The Account ID for this resource. */
    accountId: string;
}
export declare const ListListsRequest: S.Schema<ListListsRequest>;
export type ListsListResultItemKind = "ip" | "redirect" | "hostname" | "asn";
export declare const ListsListResultItemKind: any;
export interface ListsListResultItem {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsListResultItemKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export declare const ListsListResultItem: S.Schema<ListsListResultItem>;
export type ListsListResultList = Array<ListsListResultItem>;
export declare const ListsListResultList: S.Schema<ListsListResultList>;
export interface ListListsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListListsResponse: S.Schema<ListListsResponse>;
export interface UpdateListRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    /** An informative summary of the list. */
    description?: string;
}
export declare const UpdateListRequest: S.Schema<UpdateListRequest>;
export type ListsUpdateResponseKind = "ip" | "redirect" | "hostname" | "asn";
export declare const ListsUpdateResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateListResponse {
    /** The unique ID of the list. */
    id: string;
    /** The RFC 3339 timestamp of when the list was created. */
    createdOn: string;
    /** The type of the list. Each type supports specific list items (IP addresses, ASNs, hostnames or redirects). */
    kind: ListsUpdateResponseKind;
    /** The RFC 3339 timestamp of when the list was last modified. */
    modifiedOn: string;
    /** An informative name for the list. Use this name in filter and rule expressions. */
    name: string;
    /** The number of items in the list. */
    numItems: number;
    /** The number of [filters](/api/resources/filters/) referencing the list. */
    numReferencingFilters: number;
    /** An informative summary of the list. */
    description?: string | null;
}
export declare const UpdateListResponse: S.Schema<UpdateListResponse>;
export type ListsItemsUpdateRequestBodyItemListsListItemIPComment = ListsItemsCreateRequestBodyItemListsListItemIPComment;
export declare const ListsItemsUpdateRequestBodyItemListsListItemIPComment: S.Schema<ListsItemsCreateRequestBodyItemListsListItemIPComment>;
export type ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode = 301 | 302 | 307 | 308;
export declare const ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode: any;
export interface ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirect {
    sourceUrl: string;
    targetUrl: string;
    includeSubdomains?: boolean;
    preservePathSuffix?: boolean;
    preserveQueryString?: boolean;
    statusCode?: ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirectStatusCode | (number & {});
    subpathMatching?: boolean;
}
export declare const ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirect: S.Schema<ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirect>;
export interface ListsItemsUpdateRequestBodyItemListsListItemRedirectComment {
    /** The definition of the redirect. */
    redirect: ListsItemsUpdateRequestBodyItemListsListItemRedirectCommentRedirect;
    /** Defines an informative summary of the list item. */
    comment?: string;
}
export declare const ListsItemsUpdateRequestBodyItemListsListItemRedirectComment: S.Schema<ListsItemsUpdateRequestBodyItemListsListItemRedirectComment>;
export type ListsItemsUpdateRequestBodyItemListsListItemHostnameCommentHostname = ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname;
export declare const ListsItemsUpdateRequestBodyItemListsListItemHostnameCommentHostname: S.Schema<ListsItemsCreateRequestBodyItemListsListItemHostnameCommentHostname>;
export type ListsItemsUpdateRequestBodyItemListsListItemHostnameComment = ListsItemsCreateRequestBodyItemListsListItemHostnameComment;
export declare const ListsItemsUpdateRequestBodyItemListsListItemHostnameComment: S.Schema<ListsItemsCreateRequestBodyItemListsListItemHostnameComment>;
export type ListsItemsUpdateRequestBodyItemListsListItemASNComment = ListsItemsCreateRequestBodyItemListsListItemASNComment;
export declare const ListsItemsUpdateRequestBodyItemListsListItemASNComment: S.Schema<ListsItemsCreateRequestBodyItemListsListItemASNComment>;
export type ListsItemsUpdateRequestBodyItem = ListsItemsCreateRequestBodyItemListsListItemIPComment | ListsItemsUpdateRequestBodyItemListsListItemRedirectComment | ListsItemsCreateRequestBodyItemListsListItemHostnameComment | ListsItemsCreateRequestBodyItemListsListItemASNComment;
export declare const ListsItemsUpdateRequestBodyItem: any;
export type ListsItemsUpdateRequestBodyList = Array<ListsItemsUpdateRequestBodyItem>;
export declare const ListsItemsUpdateRequestBodyList: S.Schema<ListsItemsUpdateRequestBodyList>;
export interface UpdateListItemRequest {
    /** The Account ID for this resource. */
    accountId: string;
    /** The unique ID of the list. */
    listId: string;
    body: ListsItemsUpdateRequestBodyList;
}
export declare const UpdateListItemRequest: S.Schema<UpdateListItemRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateListItemResponse {
    /** The unique operation ID of the asynchronous action. */
    operationId: string;
}
export declare const UpdateListItemResponse: S.Schema<UpdateListItemResponse>;
export type CreateListError = ListAlreadyExists | Forbidden | CloudflareOpError;
/** Creates a new list of the specified kind. */
export declare const createList: API.OperationMethod<CreateListRequest, CreateListResponse, CreateListError, CloudflareOpContext>;
export type CreateListItemError = CloudflareOpError;
/** Appends new items to the list. This operation is asynchronous. To get current the operation status, invoke the `Get bulk operation status` endpoint with the returned `operation_id`. There is a limit of 1 pending bulk operation per account. If an outstanding bulk operation is in progress, the request will be rejected. */
export declare const createListItem: API.OperationMethod<CreateListItemRequest, CreateListItemResponse, CreateListItemError, CloudflareOpContext>;
export type DeleteListError = ListNotFound | Forbidden | CloudflareOpError;
/** Deletes a specific list and all its items. */
export declare const deleteList: API.OperationMethod<DeleteListRequest, DeleteListResponse, DeleteListError, CloudflareOpContext>;
export type DeleteListItemError = CloudflareOpError;
/** Removes one or more items from a list. This operation is asynchronous. To get current the operation status, invoke the `Get bulk operation status` endpoint with the returned `operation_id`. There is a limit of 1 pending bulk operation per account. If an outstanding bulk operation is in progress, the request will be rejected. */
export declare const deleteListItem: API.OperationMethod<DeleteListItemRequest, DeleteListItemResponse, DeleteListItemError, CloudflareOpContext>;
export type GetListError = ListNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a list. */
export declare const getList: API.OperationMethod<GetListRequest, GetListResponse, GetListError, CloudflareOpContext>;
export type GetListBulkOperationError = ListNotFound | Forbidden | CloudflareOpError;
/** Gets the current status of an asynchronous operation on a list. The `status` property can have one of the following values: `pending`, `running`, `completed`, or `failed`. If the status is `failed`, the `error` property will contain a message describing the error. */
export declare const getListBulkOperation: API.OperationMethod<GetListBulkOperationRequest, GetListBulkOperationResponse, GetListBulkOperationError, CloudflareOpContext>;
export type GetListItemError = CloudflareOpError;
/** Fetches a list item in the list. */
export declare const getListItem: API.OperationMethod<GetListItemRequest, GetListItemResponse, GetListItemError, CloudflareOpContext>;
export type ListListItemsError = ListNotFound | Forbidden | CloudflareOpError;
/** Fetches all the items in the list. */
export declare const listListItems: API.PaginatedOperationMethod<ListListItemsRequest, ListListItemsResponse, ListListItemsError, CloudflareOpContext, ListsItemsListResultItem>;
export type ListListsError = Forbidden | CloudflareOpError;
/** Fetches all lists in the account. */
export declare const listLists: API.PaginatedOperationMethod<ListListsRequest, ListListsResponse, ListListsError, CloudflareOpContext, ListsListResultItem>;
export type UpdateListError = ListNotFound | Forbidden | CloudflareOpError;
/** Updates the description of a list. */
export declare const updateList: API.OperationMethod<UpdateListRequest, UpdateListResponse, UpdateListError, CloudflareOpContext>;
export type UpdateListItemError = ListNotFound | Forbidden | CloudflareOpError;
/** Removes all existing items from the list and adds the provided items to the list. This operation is asynchronous. To get current the operation status, invoke the `Get bulk operation status` endpoint with the returned `operation_id`. There is a limit of 1 pending bulk operation per account. If an outstanding bulk operation is in progress, the request will be rejected. */
export declare const updateListItem: API.OperationMethod<UpdateListItemRequest, UpdateListItemResponse, UpdateListItemError, CloudflareOpContext>;
//# sourceMappingURL=rules.d.ts.map