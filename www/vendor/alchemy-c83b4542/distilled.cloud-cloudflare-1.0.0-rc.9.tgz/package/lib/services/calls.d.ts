import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CallsAppNotFound_base: S.Class<CallsAppNotFound, S.TaggedStruct<"CallsAppNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CallsAppNotFound extends /*@__PURE__*/ CallsAppNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TurnKeyNotFound_base: S.Class<TurnKeyNotFound, S.TaggedStruct<"TurnKeyNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TurnKeyNotFound extends /*@__PURE__*/ TurnKeyNotFound_base {
}
export interface CreateSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A short description of Calls app, not shown to end users. */
    name?: string;
}
export declare const CreateSfuRequest: S.Schema<CreateSfuRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSfuResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** Bearer token */
    secret?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const CreateSfuResponse: S.Schema<CreateSfuResponse>;
export interface CreateTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A short description of a TURN key, not shown to end users. */
    name?: string;
}
export declare const CreateTurnRequest: S.Schema<CreateTurnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTurnResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** Bearer token */
    key?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of a TURN key, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const CreateTurnResponse: S.Schema<CreateTurnResponse>;
export interface DeleteSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    appId: string;
}
export declare const DeleteSfuRequest: S.Schema<DeleteSfuRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSfuResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const DeleteSfuResponse: S.Schema<DeleteSfuResponse>;
export interface DeleteTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    keyId: string;
}
export declare const DeleteTurnRequest: S.Schema<DeleteTurnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTurnResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const DeleteTurnResponse: S.Schema<DeleteTurnResponse>;
export interface GetSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    appId: string;
}
export declare const GetSfuRequest: S.Schema<GetSfuRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSfuResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const GetSfuResponse: S.Schema<GetSfuResponse>;
export interface GetTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    keyId: string;
}
export declare const GetTurnRequest: S.Schema<GetTurnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTurnResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const GetTurnResponse: S.Schema<GetTurnResponse>;
export interface ListSfusRequest {
    /** The account identifier tag. */
    accountId: string;
}
export declare const ListSfusRequest: S.Schema<ListSfusRequest>;
export interface SfuListResultItem {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const SfuListResultItem: S.Schema<SfuListResultItem>;
export type SfuListResultList = Array<SfuListResultItem>;
export declare const SfuListResultList: S.Schema<SfuListResultList>;
export interface ListSfusResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SfuListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSfusResponse: S.Schema<ListSfusResponse>;
export interface ListTurnsRequest {
    /** The account identifier tag. */
    accountId: string;
}
export declare const ListTurnsRequest: S.Schema<ListTurnsRequest>;
export type TurnListResultItem = SfuListResultItem;
export declare const TurnListResultItem: S.Schema<SfuListResultItem>;
export type TurnListResultList = Array<SfuListResultItem>;
export declare const TurnListResultList: S.Schema<TurnListResultList>;
export interface ListTurnsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TurnListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListTurnsResponse: S.Schema<ListTurnsResponse>;
export interface UpdateSfuRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    appId: string;
    /** A short description of Calls app, not shown to end users. */
    name?: string;
}
export declare const UpdateSfuRequest: S.Schema<UpdateSfuRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSfuResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const UpdateSfuResponse: S.Schema<UpdateSfuResponse>;
export interface UpdateTurnRequest {
    /** The account identifier tag. */
    accountId: string;
    /** A Cloudflare-generated unique identifier for a item. */
    keyId: string;
    /** A short description of a TURN key, not shown to end users. */
    name?: string;
}
export declare const UpdateTurnRequest: S.Schema<UpdateTurnRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTurnResponse {
    /** The date and time the item was created. */
    created?: string | null;
    /** The date and time the item was last modified. */
    modified?: string | null;
    /** A short description of Calls app, not shown to end users. */
    name?: string | null;
    /** A Cloudflare-generated unique identifier for a item. */
    uid?: string | null;
}
export declare const UpdateTurnResponse: S.Schema<UpdateTurnResponse>;
export type CreateSfuError = Forbidden | CloudflareOpError;
/** Creates a new Cloudflare calls app. An app is an unique enviroment where each Session can access all Tracks within the app. */
export declare const createSfu: API.OperationMethod<CreateSfuRequest, CreateSfuResponse, CreateSfuError, CloudflareOpContext>;
export type CreateTurnError = Forbidden | CloudflareOpError;
/** Creates a new Cloudflare Calls TURN key. */
export declare const createTurn: API.OperationMethod<CreateTurnRequest, CreateTurnResponse, CreateTurnError, CloudflareOpContext>;
export type DeleteSfuError = CallsAppNotFound | Forbidden | CloudflareOpError;
/** Deletes an app from Cloudflare Calls */
export declare const deleteSfu: API.OperationMethod<DeleteSfuRequest, DeleteSfuResponse, DeleteSfuError, CloudflareOpContext>;
export type DeleteTurnError = TurnKeyNotFound | Forbidden | CloudflareOpError;
/** Deletes a TURN key from Cloudflare Calls */
export declare const deleteTurn: API.OperationMethod<DeleteTurnRequest, DeleteTurnResponse, DeleteTurnError, CloudflareOpContext>;
export type GetSfuError = CallsAppNotFound | Forbidden | CloudflareOpError;
/** Fetches details for a single Calls app. */
export declare const getSfu: API.OperationMethod<GetSfuRequest, GetSfuResponse, GetSfuError, CloudflareOpContext>;
export type GetTurnError = TurnKeyNotFound | Forbidden | CloudflareOpError;
/** Fetches details for a single TURN key. */
export declare const getTurn: API.OperationMethod<GetTurnRequest, GetTurnResponse, GetTurnError, CloudflareOpContext>;
export type ListSfusError = CloudflareOpError;
/** Lists all apps in the Cloudflare account */
export declare const listSfus: API.PaginatedOperationMethod<ListSfusRequest, ListSfusResponse, ListSfusError, CloudflareOpContext, SfuListResultItem>;
export type ListTurnsError = CloudflareOpError;
/** Lists all TURN keys in the Cloudflare account */
export declare const listTurns: API.PaginatedOperationMethod<ListTurnsRequest, ListTurnsResponse, ListTurnsError, CloudflareOpContext, SfuListResultItem>;
export type UpdateSfuError = CallsAppNotFound | Forbidden | CloudflareOpError;
/** Edit details for a single app. */
export declare const updateSfu: API.OperationMethod<UpdateSfuRequest, UpdateSfuResponse, UpdateSfuError, CloudflareOpContext>;
export type UpdateTurnError = TurnKeyNotFound | Forbidden | CloudflareOpError;
/** Edit details for a single TURN key. */
export declare const updateTurn: API.OperationMethod<UpdateTurnRequest, UpdateTurnResponse, UpdateTurnError, CloudflareOpContext>;
//# sourceMappingURL=calls.d.ts.map