import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface DeleteMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
}
export declare const DeleteMembershipRequest: S.Schema<DeleteMembershipRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null;
}
export declare const DeleteMembershipResponse: S.Schema<DeleteMembershipResponse>;
export interface GetMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
}
export declare const GetMembershipRequest: S.Schema<GetMembershipRequest>;
export type GetResponseAccountType = "standard" | "enterprise";
export declare const GetResponseAccountType: any;
export interface GetResponseAccountManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string | null;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string | null;
}
export declare const GetResponseAccountManagedBy: S.Schema<GetResponseAccountManagedBy>;
export interface GetResponseAccountSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string | null;
    /** Indicates whether membership in this account requires that */
    enforceTwofactor?: boolean | null;
}
export declare const GetResponseAccountSettings: S.Schema<GetResponseAccountSettings>;
export interface GetResponseAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: GetResponseAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null;
    /** Account settings */
    settings?: GetResponseAccountSettings | null;
}
export declare const GetResponseAccount: S.Schema<GetResponseAccount>;
export interface GetResponsePermissionsAnalytics {
    read?: boolean | null;
    write?: boolean | null;
}
export declare const GetResponsePermissionsAnalytics: S.Schema<GetResponsePermissionsAnalytics>;
export interface GetResponsePermissions {
    analytics?: GetResponsePermissionsAnalytics | null;
    billing?: GetResponsePermissionsAnalytics | null;
    cachePurge?: GetResponsePermissionsAnalytics | null;
    dns?: GetResponsePermissionsAnalytics | null;
    dnsRecords?: GetResponsePermissionsAnalytics | null;
    lb?: GetResponsePermissionsAnalytics | null;
    logs?: GetResponsePermissionsAnalytics | null;
    organization?: GetResponsePermissionsAnalytics | null;
    ssl?: GetResponsePermissionsAnalytics | null;
    waf?: GetResponsePermissionsAnalytics | null;
    zoneSettings?: GetResponsePermissionsAnalytics | null;
    zones?: GetResponsePermissionsAnalytics | null;
}
export declare const GetResponsePermissions: S.Schema<GetResponsePermissions>;
export type GetResponsePoliciesItemAccess = "allow" | "deny";
export declare const GetResponsePoliciesItemAccess: any;
export interface GetResponsePoliciesItemPermissionGroupsItemMeta {
    key?: string | null;
    value?: string | null;
}
export declare const GetResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<GetResponsePoliciesItemPermissionGroupsItemMeta>;
export interface GetResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: GetResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the permission group. */
    name?: string | null;
}
export declare const GetResponsePoliciesItemPermissionGroupsItem: S.Schema<GetResponsePoliciesItemPermissionGroupsItem>;
export type GetResponsePoliciesItemPermissionGroupsList = Array<GetResponsePoliciesItemPermissionGroupsItem>;
export declare const GetResponsePoliciesItemPermissionGroupsList: S.Schema<GetResponsePoliciesItemPermissionGroupsList>;
export interface GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export declare const GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export type GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export declare const GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface GetResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const GetResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<GetResponsePoliciesItemResourceGroupsItemScopeItem>;
export type GetResponsePoliciesItemResourceGroupsItemScopeList = Array<GetResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const GetResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<GetResponsePoliciesItemResourceGroupsItemScopeList>;
export type GetResponsePoliciesItemResourceGroupsItemMeta = GetResponsePoliciesItemPermissionGroupsItemMeta;
export declare const GetResponsePoliciesItemResourceGroupsItemMeta: S.Schema<GetResponsePoliciesItemPermissionGroupsItemMeta>;
export interface GetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: GetResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: GetResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const GetResponsePoliciesItemResourceGroupsItem: S.Schema<GetResponsePoliciesItemResourceGroupsItem>;
export type GetResponsePoliciesItemResourceGroupsList = Array<GetResponsePoliciesItemResourceGroupsItem>;
export declare const GetResponsePoliciesItemResourceGroupsList: S.Schema<GetResponsePoliciesItemResourceGroupsList>;
export interface GetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: GetResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: GetResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: GetResponsePoliciesItemResourceGroupsList | null;
}
export declare const GetResponsePoliciesItem: S.Schema<GetResponsePoliciesItem>;
export type GetResponsePoliciesList = Array<GetResponsePoliciesItem>;
export declare const GetResponsePoliciesList: S.Schema<GetResponsePoliciesList>;
export type GetResponseRolesList = Array<string>;
export declare const GetResponseRolesList: S.Schema<GetResponseRolesList>;
export type GetResponseStatus = "accepted" | "pending" | "rejected";
export declare const GetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null;
    account?: GetResponseAccount | null;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null;
    /** Access policy for the membership */
    policies?: GetResponsePoliciesList | null;
    /** List of role names the membership has for this account. */
    roles?: GetResponseRolesList | null;
    /** Status of this membership. */
    status?: GetResponseStatus | null;
}
export declare const GetMembershipResponse: S.Schema<GetMembershipResponse>;
export interface ListRequestAccount {
    /** Account name */
    name?: string;
}
export declare const ListRequestAccount: S.Schema<ListRequestAccount>;
export type ListRequestDirection = "asc" | "desc";
export declare const ListRequestDirection: any;
export type ListRequestOrder = "id" | "account.name" | "status";
export declare const ListRequestOrder: any;
export type ListRequestStatus = "accepted" | "pending" | "rejected";
export declare const ListRequestStatus: any;
export interface ListMembershipsRequest {
    account?: ListRequestAccount;
    /** Direction to order memberships. */
    direction?: ListRequestDirection | (string & {});
    /** Account name */
    name?: string;
    /** Field to order memberships by. */
    order?: ListRequestOrder | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of memberships per page. */
    perPage?: number;
    /** Status of this membership. */
    status?: ListRequestStatus | (string & {});
}
export declare const ListMembershipsRequest: S.Schema<ListMembershipsRequest>;
export type ListResultItemAccountType = "standard" | "enterprise";
export declare const ListResultItemAccountType: any;
export type ListResultItemAccountManagedBy = GetResponseAccountManagedBy;
export declare const ListResultItemAccountManagedBy: S.Schema<GetResponseAccountManagedBy>;
export type ListResultItemAccountSettings = GetResponseAccountSettings;
export declare const ListResultItemAccountSettings: S.Schema<GetResponseAccountSettings>;
export interface ListResultItemAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: ListResultItemAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null;
    /** Account settings */
    settings?: GetResponseAccountSettings | null;
}
export declare const ListResultItemAccount: S.Schema<ListResultItemAccount>;
export type ListResultItemPermissionsAnalytics = GetResponsePermissionsAnalytics;
export declare const ListResultItemPermissionsAnalytics: S.Schema<GetResponsePermissionsAnalytics>;
export type ListResultItemPermissions = GetResponsePermissions;
export declare const ListResultItemPermissions: S.Schema<GetResponsePermissions>;
export type ListResultItemRolesList = Array<string>;
export declare const ListResultItemRolesList: S.Schema<ListResultItemRolesList>;
export type ListResultItemStatus = "accepted" | "pending" | "rejected";
export declare const ListResultItemStatus: any;
export interface ListResultItem {
    /** Membership identifier tag. */
    id?: string | null;
    account?: ListResultItemAccount | null;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null;
    /** List of role names the membership has for this account. */
    roles?: ListResultItemRolesList | null;
    /** Status of this membership. */
    status?: ListResultItemStatus | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListMembershipsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListMembershipsResponse: S.Schema<ListMembershipsResponse>;
export type UpdateRequestStatus = "accepted" | "rejected";
export declare const UpdateRequestStatus: any;
export interface PutMembershipRequest {
    /** Membership identifier tag. */
    membershipId: string;
    /** Whether to accept or reject this account invitation. */
    status: UpdateRequestStatus | (string & {});
}
export declare const PutMembershipRequest: S.Schema<PutMembershipRequest>;
export type UpdateResponseAccountType = "standard" | "enterprise";
export declare const UpdateResponseAccountType: any;
export type UpdateResponseAccountManagedBy = GetResponseAccountManagedBy;
export declare const UpdateResponseAccountManagedBy: S.Schema<GetResponseAccountManagedBy>;
export type UpdateResponseAccountSettings = GetResponseAccountSettings;
export declare const UpdateResponseAccountSettings: S.Schema<GetResponseAccountSettings>;
export interface UpdateResponseAccount {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: UpdateResponseAccountType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null;
    /** Parent container details */
    managedBy?: GetResponseAccountManagedBy | null;
    /** Account settings */
    settings?: GetResponseAccountSettings | null;
}
export declare const UpdateResponseAccount: S.Schema<UpdateResponseAccount>;
export type UpdateResponsePermissionsAnalytics = GetResponsePermissionsAnalytics;
export declare const UpdateResponsePermissionsAnalytics: S.Schema<GetResponsePermissionsAnalytics>;
export type UpdateResponsePermissions = GetResponsePermissions;
export declare const UpdateResponsePermissions: S.Schema<GetResponsePermissions>;
export type UpdateResponsePoliciesItemAccess = "allow" | "deny";
export declare const UpdateResponsePoliciesItemAccess: any;
export type UpdateResponsePoliciesItemPermissionGroupsItemMeta = GetResponsePoliciesItemPermissionGroupsItemMeta;
export declare const UpdateResponsePoliciesItemPermissionGroupsItemMeta: S.Schema<GetResponsePoliciesItemPermissionGroupsItemMeta>;
export type UpdateResponsePoliciesItemPermissionGroupsItem = GetResponsePoliciesItemPermissionGroupsItem;
export declare const UpdateResponsePoliciesItemPermissionGroupsItem: S.Schema<GetResponsePoliciesItemPermissionGroupsItem>;
export type UpdateResponsePoliciesItemPermissionGroupsList = Array<GetResponsePoliciesItemPermissionGroupsItem>;
export declare const UpdateResponsePoliciesItemPermissionGroupsList: S.Schema<UpdateResponsePoliciesItemPermissionGroupsList>;
export type UpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem = GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem;
export declare const UpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem: S.Schema<GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export type UpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList = Array<GetResponsePoliciesItemResourceGroupsItemScopeItemObjectsItem>;
export declare const UpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList: S.Schema<UpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList>;
export interface UpdateResponsePoliciesItemResourceGroupsItemScopeItem {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: UpdateResponsePoliciesItemResourceGroupsItemScopeItemObjectsList;
}
export declare const UpdateResponsePoliciesItemResourceGroupsItemScopeItem: S.Schema<UpdateResponsePoliciesItemResourceGroupsItemScopeItem>;
export type UpdateResponsePoliciesItemResourceGroupsItemScopeList = Array<UpdateResponsePoliciesItemResourceGroupsItemScopeItem>;
export declare const UpdateResponsePoliciesItemResourceGroupsItemScopeList: S.Schema<UpdateResponsePoliciesItemResourceGroupsItemScopeList>;
export type UpdateResponsePoliciesItemResourceGroupsItemMeta = GetResponsePoliciesItemPermissionGroupsItemMeta;
export declare const UpdateResponsePoliciesItemResourceGroupsItemMeta: S.Schema<GetResponsePoliciesItemPermissionGroupsItemMeta>;
export interface UpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: UpdateResponsePoliciesItemResourceGroupsItemScopeList;
    /** Attributes associated to the resource group. */
    meta?: GetResponsePoliciesItemPermissionGroupsItemMeta | null;
    /** Name of the resource group. */
    name?: string | null;
}
export declare const UpdateResponsePoliciesItemResourceGroupsItem: S.Schema<UpdateResponsePoliciesItemResourceGroupsItem>;
export type UpdateResponsePoliciesItemResourceGroupsList = Array<UpdateResponsePoliciesItemResourceGroupsItem>;
export declare const UpdateResponsePoliciesItemResourceGroupsList: S.Schema<UpdateResponsePoliciesItemResourceGroupsList>;
export interface UpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null;
    /** Allow or deny operations against the resources. */
    access?: UpdateResponsePoliciesItemAccess | null;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: UpdateResponsePoliciesItemPermissionGroupsList | null;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: UpdateResponsePoliciesItemResourceGroupsList | null;
}
export declare const UpdateResponsePoliciesItem: S.Schema<UpdateResponsePoliciesItem>;
export type UpdateResponsePoliciesList = Array<UpdateResponsePoliciesItem>;
export declare const UpdateResponsePoliciesList: S.Schema<UpdateResponsePoliciesList>;
export type UpdateResponseRolesList = Array<string>;
export declare const UpdateResponseRolesList: S.Schema<UpdateResponseRolesList>;
export type UpdateResponseStatus = "accepted" | "pending" | "rejected";
export declare const UpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutMembershipResponse {
    /** Membership identifier tag. */
    id?: string | null;
    account?: UpdateResponseAccount | null;
    /** Enterprise only. Indicates whether or not API access is enabled specifically for this user on a given account. */
    apiAccessEnabled?: boolean | null;
    /** All access permissions for the user at the account. */
    permissions?: GetResponsePermissions | null;
    /** Access policy for the membership */
    policies?: UpdateResponsePoliciesList | null;
    /** List of role names the membership has for this account. */
    roles?: UpdateResponseRolesList | null;
    /** Status of this membership. */
    status?: UpdateResponseStatus | null;
}
export declare const PutMembershipResponse: S.Schema<PutMembershipResponse>;
export type DeleteMembershipError = CloudflareOpError;
/** Remove the associated member from an account. */
export declare const deleteMembership: API.OperationMethod<DeleteMembershipRequest, DeleteMembershipResponse, DeleteMembershipError, CloudflareOpContext>;
export type GetMembershipError = CloudflareOpError;
/** Get a specific membership. */
export declare const getMembership: API.OperationMethod<GetMembershipRequest, GetMembershipResponse, GetMembershipError, CloudflareOpContext>;
export type ListMembershipsError = CloudflareOpError;
/** List memberships of accounts the user can access. */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, CloudflareOpContext, ListResultItem>;
export type PutMembershipError = CloudflareOpError;
/** Accept or reject this account invitation. */
export declare const putMembership: API.OperationMethod<PutMembershipRequest, PutMembershipResponse, PutMembershipError, CloudflareOpContext>;
//# sourceMappingURL=memberships.d.ts.map