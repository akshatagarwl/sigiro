import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface CnisCreateRequestMagic {
    conduitName: string;
    description: string;
    mtu: number;
}
export declare const CnisCreateRequestMagic: S.Schema<CnisCreateRequestMagic>;
export type CnisCreateRequestBgpExtraPrefixesList = Array<string>;
export declare const CnisCreateRequestBgpExtraPrefixesList: S.Schema<CnisCreateRequestBgpExtraPrefixesList>;
export interface CnisCreateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session */
    extraPrefixes: CnisCreateRequestBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string;
}
export declare const CnisCreateRequestBgp: S.Schema<CnisCreateRequestBgp>;
export interface CreateCniRequest {
    /** Customer account tag */
    accountId: string;
    /** Customer account tag */
    account: string;
    interconnect: string;
    magic: CnisCreateRequestMagic;
    bgp?: CnisCreateRequestBgp;
}
export declare const CreateCniRequest: S.Schema<CreateCniRequest>;
export type CnisCreateResponseMagic = CnisCreateRequestMagic;
export declare const CnisCreateResponseMagic: S.Schema<CnisCreateRequestMagic>;
export type CnisCreateResponseBgpExtraPrefixesList = Array<string>;
export declare const CnisCreateResponseBgpExtraPrefixesList: S.Schema<CnisCreateResponseBgpExtraPrefixesList>;
export interface CnisCreateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session */
    extraPrefixes: CnisCreateResponseBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const CnisCreateResponseBgp: S.Schema<CnisCreateResponseBgp>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateCniResponse {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisCreateResponseBgp | null;
}
export declare const CreateCniResponse: S.Schema<CreateCniResponse>;
export type InterconnectsCreateRequestBandwidth = "50M" | "100M" | "200M" | "300M" | "400M" | "500M" | "1G" | "2G" | "5G" | "10G" | "20G" | "50G";
export declare const InterconnectsCreateRequestBandwidth: any;
export interface CreateInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    account: string;
    slotId?: string;
    type: string;
    speed?: string;
    /** Bandwidth structure as visible through the customer-facing API. */
    bandwidth?: InterconnectsCreateRequestBandwidth | (string & {});
    /** Pairing key provided by GCP */
    pairingKey?: string;
}
export declare const CreateInterconnectRequest: S.Schema<CreateInterconnectRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface CreateInterconnectResponse {
}
export declare const CreateInterconnectResponse: S.Schema<CreateInterconnectResponse>;
export interface DeleteCniRequest {
    /** Customer account tag */
    accountId: string;
    cni: string;
}
export declare const DeleteCniRequest: S.Schema<DeleteCniRequest>;
export interface DeleteCniResponse {
}
export declare const DeleteCniResponse: S.Schema<DeleteCniResponse>;
export interface DeleteInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
}
export declare const DeleteInterconnectRequest: S.Schema<DeleteInterconnectRequest>;
export interface DeleteInterconnectResponse {
}
export declare const DeleteInterconnectResponse: S.Schema<DeleteInterconnectResponse>;
export interface GetCniRequest {
    /** Customer account tag */
    accountId: string;
    cni: string;
}
export declare const GetCniRequest: S.Schema<GetCniRequest>;
export type CnisGetResponseMagic = CnisCreateRequestMagic;
export declare const CnisGetResponseMagic: S.Schema<CnisCreateRequestMagic>;
export type CnisGetResponseBgpExtraPrefixesList = Array<string>;
export declare const CnisGetResponseBgpExtraPrefixesList: S.Schema<CnisGetResponseBgpExtraPrefixesList>;
export interface CnisGetResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session */
    extraPrefixes: CnisGetResponseBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const CnisGetResponseBgp: S.Schema<CnisGetResponseBgp>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetCniResponse {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisGetResponseBgp | null;
}
export declare const GetCniResponse: S.Schema<GetCniResponse>;
export interface GetInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
}
export declare const GetInterconnectRequest: S.Schema<GetInterconnectRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetInterconnectResponse {
}
export declare const GetInterconnectResponse: S.Schema<GetInterconnectResponse>;
export interface GetSettingRequest {
    accountId: string;
}
export declare const GetSettingRequest: S.Schema<GetSettingRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSettingResponse {
    defaultAsn: number;
}
export declare const GetSettingResponse: S.Schema<GetSettingResponse>;
export interface GetSlotRequest {
    /** Customer account tag */
    accountId: string;
    slot: string;
}
export declare const GetSlotRequest: S.Schema<GetSlotRequest>;
export type SlotsGetResponseFacilityAddressList = Array<string>;
export declare const SlotsGetResponseFacilityAddressList: S.Schema<SlotsGetResponseFacilityAddressList>;
export interface SlotsGetResponseFacility {
    address: SlotsGetResponseFacilityAddressList;
    name: string;
}
export declare const SlotsGetResponseFacility: S.Schema<SlotsGetResponseFacility>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetSlotResponse {
    /** Slot ID */
    id: string;
    facility: SlotsGetResponseFacility;
    /** Whether the slot is occupied or not */
    occupied: boolean;
    site: string;
    speed: string;
    /** Customer account tag */
    account?: string | null;
}
export declare const GetSlotResponse: S.Schema<GetSlotResponse>;
export interface ListCnisRequest {
    /** Customer account tag */
    accountId: string;
    cursor?: number;
    limit?: number;
    /** If specified, only show CNIs associated with the specified slot */
    slot?: string;
    /** If specified, only show cnis associated with the specified tunnel id */
    tunnelId?: string;
}
export declare const ListCnisRequest: S.Schema<ListCnisRequest>;
export type CnisListResponseItemsItemMagic = CnisCreateRequestMagic;
export declare const CnisListResponseItemsItemMagic: S.Schema<CnisCreateRequestMagic>;
export type CnisListResponseItemsItemBgpExtraPrefixesList = Array<string>;
export declare const CnisListResponseItemsItemBgpExtraPrefixesList: S.Schema<CnisListResponseItemsItemBgpExtraPrefixesList>;
export interface CnisListResponseItemsItemBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session */
    extraPrefixes: CnisListResponseItemsItemBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const CnisListResponseItemsItemBgp: S.Schema<CnisListResponseItemsItemBgp>;
export interface CnisListResponseItemsItem {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisListResponseItemsItemBgp | null;
}
export declare const CnisListResponseItemsItem: S.Schema<CnisListResponseItemsItem>;
export type CnisListResponseItemsList = Array<CnisListResponseItemsItem>;
export declare const CnisListResponseItemsList: S.Schema<CnisListResponseItemsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListCnisResponse {
    items: CnisListResponseItemsList;
    next?: number | null;
}
export declare const ListCnisResponse: S.Schema<ListCnisResponse>;
export interface ListInterconnectsRequest {
    /** Customer account tag */
    accountId: string;
    cursor?: number;
    limit?: number;
    /** If specified, only show interconnects located at the given site */
    site?: string;
    /** If specified, only show interconnects of the given type */
    type?: string;
}
export declare const ListInterconnectsRequest: S.Schema<ListInterconnectsRequest>;
export type InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacilityAddressList = Array<string>;
export declare const InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacilityAddressList: S.Schema<InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacilityAddressList>;
export interface InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacility {
    address: InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacilityAddressList;
    name: string;
}
export declare const InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacility: S.Schema<InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacility>;
export interface InterconnectsListResponseItemsItemNscInterconnectPhysicalBody {
    account: string;
    facility: InterconnectsListResponseItemsItemNscInterconnectPhysicalBodyFacility;
    name: string;
    /** A Cloudflare site name. */
    site: string;
    slotId: string;
    speed: string;
    type: string;
    owner?: string | null;
}
export declare const InterconnectsListResponseItemsItemNscInterconnectPhysicalBody: S.Schema<InterconnectsListResponseItemsItemNscInterconnectPhysicalBody>;
export type InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBodySpeed = "50M" | "100M" | "200M" | "300M" | "400M" | "500M" | "1G" | "2G" | "5G" | "10G" | "20G" | "50G";
export declare const InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBodySpeed: any;
export interface InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBody {
    account: string;
    name: string;
    region: string;
    type: string;
    owner?: string | null;
    /** Bandwidth structure as visible through the customer-facing API. */
    speed?: InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBodySpeed | null;
}
export declare const InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBody: S.Schema<InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBody>;
export type InterconnectsListResponseItemsItem = InterconnectsListResponseItemsItemNscInterconnectPhysicalBody | InterconnectsListResponseItemsItemNscInterconnectGcpPartnerBody;
export declare const InterconnectsListResponseItemsItem: any;
export type InterconnectsListResponseItemsList = Array<InterconnectsListResponseItemsItem>;
export declare const InterconnectsListResponseItemsList: S.Schema<InterconnectsListResponseItemsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListInterconnectsResponse {
    items: InterconnectsListResponseItemsList;
    next?: number | null;
}
export declare const ListInterconnectsResponse: S.Schema<ListInterconnectsResponse>;
export interface ListSlotsRequest {
    /** Customer account tag */
    accountId: string;
    /** If specified, only show slots with the given text in their address field */
    addressContains?: string;
    cursor?: number;
    limit?: number;
    /** If specified, only show slots with a specific occupied/unoccupied state */
    occupied?: boolean;
    /** If specified, only show slots located at the given site */
    site?: string;
    /** If specified, only show slots that support the given speed */
    speed?: string;
}
export declare const ListSlotsRequest: S.Schema<ListSlotsRequest>;
export type SlotsListResponseItemsItemFacilityAddressList = Array<string>;
export declare const SlotsListResponseItemsItemFacilityAddressList: S.Schema<SlotsListResponseItemsItemFacilityAddressList>;
export interface SlotsListResponseItemsItemFacility {
    address: SlotsListResponseItemsItemFacilityAddressList;
    name: string;
}
export declare const SlotsListResponseItemsItemFacility: S.Schema<SlotsListResponseItemsItemFacility>;
export interface SlotsListResponseItemsItem {
    /** Slot ID */
    id: string;
    facility: SlotsListResponseItemsItemFacility;
    /** Whether the slot is occupied or not */
    occupied: boolean;
    site: string;
    speed: string;
    /** Customer account tag */
    account?: string | null;
}
export declare const SlotsListResponseItemsItem: S.Schema<SlotsListResponseItemsItem>;
export type SlotsListResponseItemsList = Array<SlotsListResponseItemsItem>;
export declare const SlotsListResponseItemsList: S.Schema<SlotsListResponseItemsList>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListSlotsResponse {
    items: SlotsListResponseItemsList;
    next?: number | null;
}
export declare const ListSlotsResponse: S.Schema<ListSlotsResponse>;
export interface LoaInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
}
export declare const LoaInterconnectRequest: S.Schema<LoaInterconnectRequest>;
export interface LoaInterconnectResponse {
}
export declare const LoaInterconnectResponse: S.Schema<LoaInterconnectResponse>;
export interface PutSettingRequest {
    accountId: string;
    defaultAsn?: number;
}
export declare const PutSettingRequest: S.Schema<PutSettingRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface PutSettingResponse {
    defaultAsn: number;
}
export declare const PutSettingResponse: S.Schema<PutSettingResponse>;
export interface StatusInterconnectRequest {
    /** Customer account tag */
    accountId: string;
    icon: string;
}
export declare const StatusInterconnectRequest: S.Schema<StatusInterconnectRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface StatusInterconnectResponse {
}
export declare const StatusInterconnectResponse: S.Schema<StatusInterconnectResponse>;
export type CnisUpdateRequestMagic = CnisCreateRequestMagic;
export declare const CnisUpdateRequestMagic: S.Schema<CnisCreateRequestMagic>;
export type CnisUpdateRequestBgpExtraPrefixesList = Array<string>;
export declare const CnisUpdateRequestBgpExtraPrefixesList: S.Schema<CnisUpdateRequestBgpExtraPrefixesList>;
export interface CnisUpdateRequestBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session */
    extraPrefixes: CnisUpdateRequestBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string;
}
export declare const CnisUpdateRequestBgp: S.Schema<CnisUpdateRequestBgp>;
export interface UpdateCniRequest {
    /** Customer account tag */
    accountId: string;
    cni: string;
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisUpdateRequestBgp;
}
export declare const UpdateCniRequest: S.Schema<UpdateCniRequest>;
export type CnisUpdateResponseMagic = CnisCreateRequestMagic;
export declare const CnisUpdateResponseMagic: S.Schema<CnisCreateRequestMagic>;
export type CnisUpdateResponseBgpExtraPrefixesList = Array<string>;
export declare const CnisUpdateResponseBgpExtraPrefixesList: S.Schema<CnisUpdateResponseBgpExtraPrefixesList>;
export interface CnisUpdateResponseBgp {
    /** ASN used on the customer end of the BGP session */
    customerAsn: number;
    /** Extra set of static prefixes to advertise to the customer's end of the session */
    extraPrefixes: CnisUpdateResponseBgpExtraPrefixesList;
    /** MD5 key to use for session authentication. */
    md5Key?: string | null;
}
export declare const CnisUpdateResponseBgp: S.Schema<CnisUpdateResponseBgp>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface UpdateCniResponse {
    id: string;
    /** Customer account tag */
    account: string;
    /** Customer end of the point-to-point link */
    custIp: string;
    /** Interconnect identifier hosting this CNI */
    interconnect: string;
    magic: CnisCreateRequestMagic;
    /** Cloudflare end of the point-to-point link */
    p2pIp: string;
    bgp?: CnisUpdateResponseBgp | null;
}
export declare const UpdateCniResponse: S.Schema<UpdateCniResponse>;
export type CreateCniError = CloudflareOpError;
/** Create a new CNI object */
export declare const createCni: API.OperationMethod<CreateCniRequest, CreateCniResponse, CreateCniError, CloudflareOpContext>;
export type CreateInterconnectError = CloudflareOpError;
/** Create a new interconnect */
export declare const createInterconnect: API.OperationMethod<CreateInterconnectRequest, CreateInterconnectResponse, CreateInterconnectError, CloudflareOpContext>;
export type DeleteCniError = CloudflareOpError;
/** Delete a specified CNI object */
export declare const deleteCni: API.OperationMethod<DeleteCniRequest, DeleteCniResponse, DeleteCniError, CloudflareOpContext>;
export type DeleteInterconnectError = CloudflareOpError;
/** Delete an interconnect object */
export declare const deleteInterconnect: API.OperationMethod<DeleteInterconnectRequest, DeleteInterconnectResponse, DeleteInterconnectError, CloudflareOpContext>;
export type GetCniError = CloudflareOpError;
/** Get information about a CNI object */
export declare const getCni: API.OperationMethod<GetCniRequest, GetCniResponse, GetCniError, CloudflareOpContext>;
export type GetInterconnectError = CloudflareOpError;
/** Get information about an interconnect object */
export declare const getInterconnect: API.OperationMethod<GetInterconnectRequest, GetInterconnectResponse, GetInterconnectError, CloudflareOpContext>;
export type GetSettingError = Forbidden | CloudflareOpError;
/** Get the current settings for the active account */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetSlotError = CloudflareOpError;
/** Get information about the specified slot */
export declare const getSlot: API.OperationMethod<GetSlotRequest, GetSlotResponse, GetSlotError, CloudflareOpContext>;
export type ListCnisError = CloudflareOpError;
/** List existing CNI objects */
export declare const listCnis: API.OperationMethod<ListCnisRequest, ListCnisResponse, ListCnisError, CloudflareOpContext>;
export type ListInterconnectsError = CloudflareOpError;
/** List existing interconnects */
export declare const listInterconnects: API.OperationMethod<ListInterconnectsRequest, ListInterconnectsResponse, ListInterconnectsError, CloudflareOpContext>;
export type ListSlotsError = CloudflareOpError;
/** Retrieve a list of all slots matching the specified parameters */
export declare const listSlots: API.OperationMethod<ListSlotsRequest, ListSlotsResponse, ListSlotsError, CloudflareOpContext>;
export type LoaInterconnectError = CloudflareOpError;
/** Generate the Letter of Authorization (LOA) for a given interconnect */
export declare const loaInterconnect: API.OperationMethod<LoaInterconnectRequest, LoaInterconnectResponse, LoaInterconnectError, CloudflareOpContext>;
export type PutSettingError = Forbidden | CloudflareOpError;
/** Update the current settings for the active account */
export declare const putSetting: API.OperationMethod<PutSettingRequest, PutSettingResponse, PutSettingError, CloudflareOpContext>;
export type StatusInterconnectError = CloudflareOpError;
/** Get the current status of an interconnect object */
export declare const statusInterconnect: API.OperationMethod<StatusInterconnectRequest, StatusInterconnectResponse, StatusInterconnectError, CloudflareOpContext>;
export type UpdateCniError = CloudflareOpError;
/** Modify stored information about a CNI object */
export declare const updateCni: API.OperationMethod<UpdateCniRequest, UpdateCniResponse, UpdateCniError, CloudflareOpContext>;
//# sourceMappingURL=network_interconnects.d.ts.map