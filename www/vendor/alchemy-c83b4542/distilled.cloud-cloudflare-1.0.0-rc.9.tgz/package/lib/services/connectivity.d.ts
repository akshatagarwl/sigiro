import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const VpcServiceNameAlreadyExists_base: S.Class<VpcServiceNameAlreadyExists, S.TaggedStruct<"VpcServiceNameAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VpcServiceNameAlreadyExists extends /*@__PURE__*/ VpcServiceNameAlreadyExists_base {
}
declare const VpcServiceNotFound_base: S.Class<VpcServiceNotFound, S.TaggedStruct<"VpcServiceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VpcServiceNotFound extends /*@__PURE__*/ VpcServiceNotFound_base {
}
declare const VpcTunnelNotFound_base: S.Class<VpcTunnelNotFound, S.TaggedStruct<"VpcTunnelNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VpcTunnelNotFound extends /*@__PURE__*/ VpcTunnelNotFound_base {
}
export interface DirectoryServicesCreateRequestHostInfraIPv4HostNetwork {
    tunnelId: string;
}
export declare const DirectoryServicesCreateRequestHostInfraIPv4HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export interface DirectoryServicesCreateRequestHostInfraIPv4Host {
    ipv4: string;
    network: DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
}
export declare const DirectoryServicesCreateRequestHostInfraIPv4Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4Host>;
export type DirectoryServicesCreateRequestHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesCreateRequestHostInfraIPv6HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export interface DirectoryServicesCreateRequestHostInfraIPv6Host {
    ipv6: string;
    network: DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
}
export declare const DirectoryServicesCreateRequestHostInfraIPv6Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv6Host>;
export type DirectoryServicesCreateRequestHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesCreateRequestHostInfraDualStackHostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export interface DirectoryServicesCreateRequestHostInfraDualStackHost {
    ipv4: string;
    ipv6: string;
    network: DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
}
export declare const DirectoryServicesCreateRequestHostInfraDualStackHost: S.Schema<DirectoryServicesCreateRequestHostInfraDualStackHost>;
export type DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export declare const DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetworkResolverIpsList: S.Schema<DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetworkResolverIpsList>;
export interface DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetworkResolverIpsList;
}
export declare const DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetwork>;
export interface DirectoryServicesCreateRequestHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesCreateRequestHostInfraHostnameHostResolverNetwork;
}
export declare const DirectoryServicesCreateRequestHostInfraHostnameHost: S.Schema<DirectoryServicesCreateRequestHostInfraHostnameHost>;
export type DirectoryServicesCreateRequestHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesCreateRequestHostInfraHostnameHost;
export declare const DirectoryServicesCreateRequestHost: any;
export type DirectoryServicesCreateRequestType = "tcp" | "http";
export declare const DirectoryServicesCreateRequestType: any;
export interface DirectoryServicesCreateRequestTlsSettings {
    /** TLS certificate verification mode for the connection to the origin. */
    certVerificationMode: string;
}
export declare const DirectoryServicesCreateRequestTlsSettings: S.Schema<DirectoryServicesCreateRequestTlsSettings>;
export type DirectoryServicesCreateRequestAppProtocol = "postgresql" | "mysql";
export declare const DirectoryServicesCreateRequestAppProtocol: any;
export interface CreateDirectoryServiceRequest {
    /** Account identifier */
    accountId: string;
    host: DirectoryServicesCreateRequestHost;
    name: string;
    type: DirectoryServicesCreateRequestType | (string & {});
    createdAt?: string;
    httpPort?: number;
    httpsPort?: number;
    serviceId?: string;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings;
    updatedAt?: string;
    appProtocol?: DirectoryServicesCreateRequestAppProtocol | (string & {});
    tcpPort?: number;
}
export declare const CreateDirectoryServiceRequest: S.Schema<CreateDirectoryServiceRequest>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv4Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4Host>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraIPv6Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv6Host>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraDualStackHost: S.Schema<DirectoryServicesCreateRequestHostInfraDualStackHost>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList: S.Schema<DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList>;
export interface DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork: S.Schema<DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork>;
export interface DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHost: S.Schema<DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHost>;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesCreateResultInfraHTTPServiceConfigHostInfraHostnameHost;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigHost: any;
export type DirectoryServicesCreateResultType = "tcp" | "http";
export declare const DirectoryServicesCreateResultType: any;
export type DirectoryServicesCreateResultInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export declare const DirectoryServicesCreateResultInfraHTTPServiceConfigTlsSettings: S.Schema<DirectoryServicesCreateRequestTlsSettings>;
export type DirectoryServicesCreateResultInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export declare const DirectoryServicesCreateResultInfraTCPServiceConfigAppProtocol: any;
export interface DirectoryServicesCreateResult {
    host: DirectoryServicesCreateResultInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesCreateResultType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesCreateResultInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export declare const DirectoryServicesCreateResult: S.Schema<DirectoryServicesCreateResult>;
export type CreateDirectoryServiceResponse = DirectoryServicesCreateResult;
export declare const CreateDirectoryServiceResponse: S.Schema<CreateDirectoryServiceResponse>;
export interface DeleteDirectoryServiceRequest {
    accountId: string;
    serviceId: string;
}
export declare const DeleteDirectoryServiceRequest: S.Schema<DeleteDirectoryServiceRequest>;
export interface DeleteDirectoryServiceResponse {
}
export declare const DeleteDirectoryServiceResponse: S.Schema<DeleteDirectoryServiceResponse>;
export interface GetDirectoryServiceRequest {
    accountId: string;
    serviceId: string;
}
export declare const GetDirectoryServiceRequest: S.Schema<GetDirectoryServiceRequest>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv4Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4Host>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraIPv6Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv6Host>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraDualStackHost: S.Schema<DirectoryServicesCreateRequestHostInfraDualStackHost>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList: S.Schema<DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList>;
export interface DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork: S.Schema<DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork>;
export interface DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHost: S.Schema<DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHost>;
export type DirectoryServicesGetResultInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesGetResultInfraHTTPServiceConfigHostInfraHostnameHost;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigHost: any;
export type DirectoryServicesGetResultType = "tcp" | "http";
export declare const DirectoryServicesGetResultType: any;
export type DirectoryServicesGetResultInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export declare const DirectoryServicesGetResultInfraHTTPServiceConfigTlsSettings: S.Schema<DirectoryServicesCreateRequestTlsSettings>;
export type DirectoryServicesGetResultInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export declare const DirectoryServicesGetResultInfraTCPServiceConfigAppProtocol: any;
export interface DirectoryServicesGetResult {
    host: DirectoryServicesGetResultInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesGetResultType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesGetResultInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export declare const DirectoryServicesGetResult: S.Schema<DirectoryServicesGetResult>;
export type GetDirectoryServiceResponse = DirectoryServicesGetResult;
export declare const GetDirectoryServiceResponse: S.Schema<GetDirectoryServiceResponse>;
export type DirectoryServicesListRequestType = "tcp" | "http";
export declare const DirectoryServicesListRequestType: any;
export interface ListDirectoryServicesRequest {
    /** Account identifier */
    accountId: string;
    /** Current page in the response */
    page?: number;
    /** Max amount of entries returned per page */
    perPage?: number;
    type?: DirectoryServicesListRequestType | (string & {});
}
export declare const ListDirectoryServicesRequest: S.Schema<ListDirectoryServicesRequest>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv4HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv4Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4Host>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv6HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraIPv6Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv6Host>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraDualStackHostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraDualStackHost: S.Schema<DirectoryServicesCreateRequestHostInfraDualStackHost>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList: S.Schema<DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList>;
export interface DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork: S.Schema<DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork>;
export interface DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHost: S.Schema<DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHost>;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesListResultItemInfraHTTPServiceConfigHostInfraHostnameHost;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigHost: any;
export type DirectoryServicesListResultItemType = "tcp" | "http";
export declare const DirectoryServicesListResultItemType: any;
export type DirectoryServicesListResultItemInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export declare const DirectoryServicesListResultItemInfraHTTPServiceConfigTlsSettings: S.Schema<DirectoryServicesCreateRequestTlsSettings>;
export type DirectoryServicesListResultItemInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export declare const DirectoryServicesListResultItemInfraTCPServiceConfigAppProtocol: any;
export interface DirectoryServicesListResultItem {
    host: DirectoryServicesListResultItemInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesListResultItemType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesListResultItemInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export declare const DirectoryServicesListResultItem: S.Schema<DirectoryServicesListResultItem>;
export type DirectoryServicesListResultList = Array<DirectoryServicesListResultItem>;
export declare const DirectoryServicesListResultList: S.Schema<DirectoryServicesListResultList>;
export interface ListDirectoryServicesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: DirectoryServicesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListDirectoryServicesResponse: S.Schema<ListDirectoryServicesResponse>;
export type DirectoryServicesUpdateRequestHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesUpdateRequestHostInfraIPv4HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesUpdateRequestHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export declare const DirectoryServicesUpdateRequestHostInfraIPv4Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4Host>;
export type DirectoryServicesUpdateRequestHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesUpdateRequestHostInfraIPv6HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesUpdateRequestHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export declare const DirectoryServicesUpdateRequestHostInfraIPv6Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv6Host>;
export type DirectoryServicesUpdateRequestHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesUpdateRequestHostInfraDualStackHostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesUpdateRequestHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export declare const DirectoryServicesUpdateRequestHostInfraDualStackHost: S.Schema<DirectoryServicesCreateRequestHostInfraDualStackHost>;
export type DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export declare const DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetworkResolverIpsList: S.Schema<DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetworkResolverIpsList>;
export interface DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetworkResolverIpsList;
}
export declare const DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetwork: S.Schema<DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetwork>;
export interface DirectoryServicesUpdateRequestHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesUpdateRequestHostInfraHostnameHostResolverNetwork;
}
export declare const DirectoryServicesUpdateRequestHostInfraHostnameHost: S.Schema<DirectoryServicesUpdateRequestHostInfraHostnameHost>;
export type DirectoryServicesUpdateRequestHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesUpdateRequestHostInfraHostnameHost;
export declare const DirectoryServicesUpdateRequestHost: any;
export type DirectoryServicesUpdateRequestType = "tcp" | "http";
export declare const DirectoryServicesUpdateRequestType: any;
export type DirectoryServicesUpdateRequestTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export declare const DirectoryServicesUpdateRequestTlsSettings: S.Schema<DirectoryServicesCreateRequestTlsSettings>;
export type DirectoryServicesUpdateRequestAppProtocol = "postgresql" | "mysql";
export declare const DirectoryServicesUpdateRequestAppProtocol: any;
export interface UpdateDirectoryServiceRequest {
    accountId: string;
    serviceId: string;
    host: DirectoryServicesUpdateRequestHost;
    name: string;
    type: DirectoryServicesUpdateRequestType | (string & {});
    createdAt?: string;
    httpPort?: number;
    httpsPort?: number;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings;
    updatedAt?: string;
    appProtocol?: DirectoryServicesUpdateRequestAppProtocol | (string & {});
    tcpPort?: number;
}
export declare const UpdateDirectoryServiceRequest: S.Schema<UpdateDirectoryServiceRequest>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv4HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv4Host = DirectoryServicesCreateRequestHostInfraIPv4Host;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv4Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4Host>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv6HostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv6Host = DirectoryServicesCreateRequestHostInfraIPv6Host;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraIPv6Host: S.Schema<DirectoryServicesCreateRequestHostInfraIPv6Host>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork = DirectoryServicesCreateRequestHostInfraIPv4HostNetwork;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraDualStackHostNetwork: S.Schema<DirectoryServicesCreateRequestHostInfraIPv4HostNetwork>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraDualStackHost = DirectoryServicesCreateRequestHostInfraDualStackHost;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraDualStackHost: S.Schema<DirectoryServicesCreateRequestHostInfraDualStackHost>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList = Array<string>;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList: S.Schema<DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList>;
export interface DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork {
    tunnelId: string;
    resolverIps?: DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetworkResolverIpsList | null;
}
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork: S.Schema<DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork>;
export interface DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHost {
    hostname: string;
    resolverNetwork: DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHostResolverNetwork;
}
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHost: S.Schema<DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHost>;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigHost = DirectoryServicesCreateRequestHostInfraIPv4Host | DirectoryServicesCreateRequestHostInfraIPv6Host | DirectoryServicesCreateRequestHostInfraDualStackHost | DirectoryServicesUpdateResultInfraHTTPServiceConfigHostInfraHostnameHost;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigHost: any;
export type DirectoryServicesUpdateResultType = "tcp" | "http";
export declare const DirectoryServicesUpdateResultType: any;
export type DirectoryServicesUpdateResultInfraHTTPServiceConfigTlsSettings = DirectoryServicesCreateRequestTlsSettings;
export declare const DirectoryServicesUpdateResultInfraHTTPServiceConfigTlsSettings: S.Schema<DirectoryServicesCreateRequestTlsSettings>;
export type DirectoryServicesUpdateResultInfraTCPServiceConfigAppProtocol = "postgresql" | "mysql";
export declare const DirectoryServicesUpdateResultInfraTCPServiceConfigAppProtocol: any;
export interface DirectoryServicesUpdateResult {
    host: DirectoryServicesUpdateResultInfraHTTPServiceConfigHost;
    name: string;
    type: DirectoryServicesUpdateResultType;
    createdAt?: string | null;
    httpPort?: number | null;
    httpsPort?: number | null;
    serviceId?: string | null;
    /** TLS settings for a connectivity service. */
    tlsSettings?: DirectoryServicesCreateRequestTlsSettings | null;
    updatedAt?: string | null;
    appProtocol?: DirectoryServicesUpdateResultInfraTCPServiceConfigAppProtocol | null;
    tcpPort?: number | null;
}
export declare const DirectoryServicesUpdateResult: S.Schema<DirectoryServicesUpdateResult>;
export type UpdateDirectoryServiceResponse = DirectoryServicesUpdateResult;
export declare const UpdateDirectoryServiceResponse: S.Schema<UpdateDirectoryServiceResponse>;
export type CreateDirectoryServiceError = VpcServiceNameAlreadyExists | VpcTunnelNotFound | Forbidden | CloudflareOpError;
/** Create Workers VPC connectivity service */
export declare const createDirectoryService: API.OperationMethod<CreateDirectoryServiceRequest, CreateDirectoryServiceResponse, CreateDirectoryServiceError, CloudflareOpContext>;
export type DeleteDirectoryServiceError = VpcServiceNotFound | Forbidden | CloudflareOpError;
/** Delete Workers VPC connectivity service */
export declare const deleteDirectoryService: API.OperationMethod<DeleteDirectoryServiceRequest, DeleteDirectoryServiceResponse, DeleteDirectoryServiceError, CloudflareOpContext>;
export type GetDirectoryServiceError = VpcServiceNotFound | Forbidden | CloudflareOpError;
/** Get Workers VPC connectivity service */
export declare const getDirectoryService: API.OperationMethod<GetDirectoryServiceRequest, GetDirectoryServiceResponse, GetDirectoryServiceError, CloudflareOpContext>;
export type ListDirectoryServicesError = Forbidden | CloudflareOpError;
/** List Workers VPC connectivity services */
export declare const listDirectoryServices: API.PaginatedOperationMethod<ListDirectoryServicesRequest, ListDirectoryServicesResponse, ListDirectoryServicesError, CloudflareOpContext, DirectoryServicesListResultItem>;
export type UpdateDirectoryServiceError = VpcServiceNotFound | VpcServiceNameAlreadyExists | VpcTunnelNotFound | Forbidden | CloudflareOpError;
/** Update Workers VPC connectivity service */
export declare const updateDirectoryService: API.OperationMethod<UpdateDirectoryServiceRequest, UpdateDirectoryServiceResponse, UpdateDirectoryServiceError, CloudflareOpContext>;
//# sourceMappingURL=connectivity.d.ts.map