import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetCsamScannerRequest {
    /** Identifier for the zone. */
    zoneId: string;
}
export declare const GetCsamScannerRequest: S.Schema<GetCsamScannerRequest>;
export type GetResponseId = "csam_scanner";
export declare const GetResponseId: any;
export type GetResponseValueEmailState = "valid" | "pending" | "unverified";
export declare const GetResponseValueEmailState: any;
export type GetResponseValueSourcesMap = {
    [key: string]: boolean | undefined;
};
export declare const GetResponseValueSourcesMap: S.Schema<GetResponseValueSourcesMap>;
export interface GetResponseValue {
    /** Notification email address for CSAM scan results. Masked in */
    email?: string | null;
    /** Current verification state of the notification email. */
    emailState?: GetResponseValueEmailState | null;
    /** Whether CSAM scanning is enabled for this zone. */
    enabled?: boolean | null;
    /** Map of scanning sources and their enabled state. */
    sources?: GetResponseValueSourcesMap | null;
    /** The zone's plan level. */
    zonePlan?: string | null;
}
export declare const GetResponseValue: S.Schema<GetResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCsamScannerResponse {
    /** The feature identifier. */
    id?: GetResponseId | null;
    /** Whether the feature state can be changed. When false, the zone */
    editable?: boolean | null;
    /** When the setting was last modified. Currently always null as the */
    modifiedOn?: string | null;
    /** The CSAM Scanner feature configuration values. Contains the */
    value?: GetResponseValue | null;
}
export declare const GetCsamScannerResponse: S.Schema<GetCsamScannerResponse>;
export type EditRequestId = "csam_scanner";
export declare const EditRequestId: any;
export type EditRequestValueSourcesMap = {
    [key: string]: boolean | undefined;
};
export declare const EditRequestValueSourcesMap: S.Schema<EditRequestValueSourcesMap>;
export interface EditRequestValue {
    /** Notification email address for CSAM scan results. When changed, */
    email?: string;
    /** Whether CSAM scanning is enabled for this zone. */
    enabled?: boolean;
    /** Set to true to trigger re-sending the email verification. */
    resendEmail?: boolean;
    /** Map of scanning sources and their enabled state. */
    sources?: EditRequestValueSourcesMap;
}
export declare const EditRequestValue: S.Schema<EditRequestValue>;
export interface PatchCsamScannerRequest {
    /** Identifier for the zone. */
    zoneId: string;
    /** The feature identifier. */
    id?: EditRequestId | (string & {});
    /** Writable CSAM Scanner feature configuration values. */
    value?: EditRequestValue;
}
export declare const PatchCsamScannerRequest: S.Schema<PatchCsamScannerRequest>;
export type EditResponseId = "csam_scanner";
export declare const EditResponseId: any;
export type EditResponseValueEmailState = "valid" | "pending" | "unverified";
export declare const EditResponseValueEmailState: any;
export type EditResponseValueSourcesMap = {
    [key: string]: boolean | undefined;
};
export declare const EditResponseValueSourcesMap: S.Schema<EditResponseValueSourcesMap>;
export interface EditResponseValue {
    /** Notification email address for CSAM scan results. Masked in */
    email?: string | null;
    /** Current verification state of the notification email. */
    emailState?: EditResponseValueEmailState | null;
    /** Whether CSAM scanning is enabled for this zone. */
    enabled?: boolean | null;
    /** Map of scanning sources and their enabled state. */
    sources?: EditResponseValueSourcesMap | null;
    /** The zone's plan level. */
    zonePlan?: string | null;
}
export declare const EditResponseValue: S.Schema<EditResponseValue>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCsamScannerResponse {
    /** The feature identifier. */
    id?: EditResponseId | null;
    /** Whether the feature state can be changed. When false, the zone */
    editable?: boolean | null;
    /** When the setting was last modified. Currently always null as the */
    modifiedOn?: string | null;
    /** The CSAM Scanner feature configuration values. Contains the */
    value?: EditResponseValue | null;
}
export declare const PatchCsamScannerResponse: S.Schema<PatchCsamScannerResponse>;
export type GetCsamScannerError = CloudflareOpError;
/** Retrieve the current CSAM Scanner configuration for a zone. The notification email is masked by default in responses. */
export declare const getCsamScanner: API.OperationMethod<GetCsamScannerRequest, GetCsamScannerResponse, GetCsamScannerError, CloudflareOpContext>;
export type PatchCsamScannerError = CloudflareOpError;
/** Update the CSAM Scanner configuration for a zone. Allows enabling or disabling CSAM scanning, updating the notification email, and configuring scanning sources. When a new email is provided, email verification is triggered automatically. The `enabled` field is a toggle; the server may adjust it based on whether the notification email is verified. Returns 403 if the zone or account is locked by Trust & Safety. */
export declare const patchCsamScanner: API.OperationMethod<PatchCsamScannerRequest, PatchCsamScannerResponse, PatchCsamScannerError, CloudflareOpContext>;
//# sourceMappingURL=csam_scanner.d.ts.map