import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidSchema_base: S.Class<InvalidSchema, S.TaggedStruct<"InvalidSchema", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidSchema extends /*@__PURE__*/ InvalidSchema_base {
}
declare const OperationNotFound_base: S.Class<OperationNotFound, S.TaggedStruct<"OperationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OperationNotFound extends /*@__PURE__*/ OperationNotFound_base {
}
declare const SchemaNotFound_base: S.Class<SchemaNotFound, S.TaggedStruct<"SchemaNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SchemaNotFound extends /*@__PURE__*/ SchemaNotFound_base {
}
declare const UnentitledMitigationAction_base: S.Class<UnentitledMitigationAction, S.TaggedStruct<"UnentitledMitigationAction", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnentitledMitigationAction extends /*@__PURE__*/ UnentitledMitigationAction_base {
}
declare const ZonePurged_base: S.Class<ZonePurged, S.TaggedStruct<"ZonePurged", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ZonePurged extends /*@__PURE__*/ ZonePurged_base {
}
export type SettingsOperationsBulkEditRequestBodyValueMitigationAction = "none" | "log" | "block";
export declare const SettingsOperationsBulkEditRequestBodyValueMitigationAction: any;
export interface SettingsOperationsBulkEditRequestBodyValue {
    /** Mitigation actions are as follows: */
    mitigationAction?: SettingsOperationsBulkEditRequestBodyValueMitigationAction | (string & {});
}
export declare const SettingsOperationsBulkEditRequestBodyValue: S.Schema<SettingsOperationsBulkEditRequestBodyValue>;
export type SettingsOperationsBulkEditRequestBodyMap = {
    [key: string]: SettingsOperationsBulkEditRequestBodyValue | undefined;
};
export declare const SettingsOperationsBulkEditRequestBodyMap: S.Schema<SettingsOperationsBulkEditRequestBodyMap>;
export interface BulkPatchSettingOperationsRequest {
    /** Identifier. */
    zoneId: string;
    body: SettingsOperationsBulkEditRequestBodyMap;
}
export declare const BulkPatchSettingOperationsRequest: S.Schema<BulkPatchSettingOperationsRequest>;
export type SettingsOperationsBulkEditResultValueMitigationAction = "log" | "block" | "none";
export declare const SettingsOperationsBulkEditResultValueMitigationAction: any;
export interface SettingsOperationsBulkEditResultValue {
    /** When set, this applies a mitigation action to this operation which supersedes a global schema validation setting just for this operation */
    mitigationAction: SettingsOperationsBulkEditResultValueMitigationAction;
    /** UUID. */
    operationId: string;
}
export declare const SettingsOperationsBulkEditResultValue: S.Schema<SettingsOperationsBulkEditResultValue>;
export type SettingsOperationsBulkEditResultMap = {
    [key: string]: SettingsOperationsBulkEditResultValue | undefined;
};
export declare const SettingsOperationsBulkEditResultMap: S.Schema<SettingsOperationsBulkEditResultMap>;
export type BulkPatchSettingOperationsResponse = SettingsOperationsBulkEditResultMap;
export declare const BulkPatchSettingOperationsResponse: S.Schema<BulkPatchSettingOperationsResponse>;
export type SchemasCreateRequestKind = "openapi_v3";
export declare const SchemasCreateRequestKind: any;
export interface CreateSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** The kind of the schema */
    kind: SchemasCreateRequestKind | (string & {});
    /** A human-readable name for the schema */
    name: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled: boolean;
}
export declare const CreateSchemaRequest: S.Schema<CreateSchemaRequest>;
export type SchemasCreateResponseKind = "openapi_v3";
export declare const SchemasCreateResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSchemaResponse {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasCreateResponseKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export declare const CreateSchemaResponse: S.Schema<CreateSchemaResponse>;
export interface DeleteSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    schemaId: string;
}
export declare const DeleteSchemaRequest: S.Schema<DeleteSchemaRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSchemaResponse {
    /** The ID of the schema that was just deleted */
    id: string;
}
export declare const DeleteSchemaResponse: S.Schema<DeleteSchemaResponse>;
export interface DeleteSettingOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export declare const DeleteSettingOperationRequest: S.Schema<DeleteSettingOperationRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingOperationResponse {
    /** UUID. */
    operationId?: string | null;
}
export declare const DeleteSettingOperationResponse: S.Schema<DeleteSettingOperationResponse>;
export interface GetSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    schemaId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
}
export declare const GetSchemaRequest: S.Schema<GetSchemaRequest>;
export type SchemasGetResponseKind = "openapi_v3";
export declare const SchemasGetResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSchemaResponse {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasGetResponseKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export declare const GetSchemaResponse: S.Schema<GetSchemaResponse>;
export interface GetSettingRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetSettingRequest: S.Schema<GetSettingRequest>;
export type SettingsGetResponseValidationDefaultMitigationAction = "none" | "log" | "block";
export declare const SettingsGetResponseValidationDefaultMitigationAction: any;
export type SettingsGetResponseValidationOverrideMitigationAction = "none";
export declare const SettingsGetResponseValidationOverrideMitigationAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingResponse {
    /** The default mitigation action used */
    validationDefaultMitigationAction: SettingsGetResponseValidationDefaultMitigationAction;
    /** When not null, this overrides global both zone level and operation level mitigation actions. This can serve as a quick way to disable schema validation for the whole zone. */
    validationOverrideMitigationAction?: SettingsGetResponseValidationOverrideMitigationAction | null;
}
export declare const GetSettingResponse: S.Schema<GetSettingResponse>;
export interface GetSettingOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
}
export declare const GetSettingOperationRequest: S.Schema<GetSettingOperationRequest>;
export type SettingsOperationsGetResponseMitigationAction = "log" | "block" | "none";
export declare const SettingsOperationsGetResponseMitigationAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingOperationResponse {
    /** When set, this applies a mitigation action to this operation which supersedes a global schema validation setting just for this operation */
    mitigationAction: SettingsOperationsGetResponseMitigationAction;
    /** UUID. */
    operationId: string;
}
export declare const GetSettingOperationResponse: S.Schema<GetSettingOperationResponse>;
export interface ListSchemasRequest {
    /** Identifier. */
    zoneId: string;
    /** Omit the source-files of schemas and only retrieve their meta-data. */
    omitSource?: boolean;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
    /** Filter for enabled schemas */
    validationEnabled?: boolean;
}
export declare const ListSchemasRequest: S.Schema<ListSchemasRequest>;
export type SchemasListResultItemKind = "openapi_v3";
export declare const SchemasListResultItemKind: any;
export interface SchemasListResultItem {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasListResultItemKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export declare const SchemasListResultItem: S.Schema<SchemasListResultItem>;
export type SchemasListResultList = Array<SchemasListResultItem>;
export declare const SchemasListResultList: S.Schema<SchemasListResultList>;
export interface ListSchemasResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SchemasListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSchemasResponse: S.Schema<ListSchemasResponse>;
export interface ListSettingOperationsRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number;
    /** Maximum number of results per page. */
    perPage?: number;
}
export declare const ListSettingOperationsRequest: S.Schema<ListSettingOperationsRequest>;
export type SettingsOperationsListResultItemMitigationAction = "log" | "block" | "none";
export declare const SettingsOperationsListResultItemMitigationAction: any;
export interface SettingsOperationsListResultItem {
    /** When set, this applies a mitigation action to this operation which supersedes a global schema validation setting just for this operation */
    mitigationAction: SettingsOperationsListResultItemMitigationAction;
    /** UUID. */
    operationId: string;
}
export declare const SettingsOperationsListResultItem: S.Schema<SettingsOperationsListResultItem>;
export type SettingsOperationsListResultList = Array<SettingsOperationsListResultItem>;
export declare const SettingsOperationsListResultList: S.Schema<SettingsOperationsListResultList>;
export interface ListSettingOperationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsOperationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingOperationsResponse: S.Schema<ListSettingOperationsResponse>;
export interface PatchSchemaRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    schemaId: string;
    /** Flag whether schema is enabled for validation. */
    validationEnabled?: boolean;
}
export declare const PatchSchemaRequest: S.Schema<PatchSchemaRequest>;
export type SchemasEditResponseKind = "openapi_v3";
export declare const SchemasEditResponseKind: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSchemaResponse {
    createdAt: string;
    /** The kind of the schema */
    kind: SchemasEditResponseKind;
    /** A human-readable name for the schema */
    name: string;
    /** A unique identifier of this schema */
    schemaId: string;
    /** The raw schema, e.g., the OpenAPI schema, either as JSON or YAML */
    source: string;
    /** An indicator if this schema is enabled */
    validationEnabled?: boolean | null;
}
export declare const PatchSchemaResponse: S.Schema<PatchSchemaResponse>;
export type SettingsEditRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export declare const SettingsEditRequestValidationDefaultMitigationAction: any;
export type SettingsEditRequestValidationOverrideMitigationAction = "none";
export declare const SettingsEditRequestValidationOverrideMitigationAction: any;
export interface PatchSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used */
    validationDefaultMitigationAction?: SettingsEditRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsEditRequestValidationOverrideMitigationAction | (string & {}) | null;
}
export declare const PatchSettingRequest: S.Schema<PatchSettingRequest>;
export type SettingsEditResponseValidationDefaultMitigationAction = "none" | "log" | "block";
export declare const SettingsEditResponseValidationDefaultMitigationAction: any;
export type SettingsEditResponseValidationOverrideMitigationAction = "none";
export declare const SettingsEditResponseValidationOverrideMitigationAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingResponse {
    /** The default mitigation action used */
    validationDefaultMitigationAction: SettingsEditResponseValidationDefaultMitigationAction;
    /** When not null, this overrides global both zone level and operation level mitigation actions. This can serve as a quick way to disable schema validation for the whole zone. */
    validationOverrideMitigationAction?: SettingsEditResponseValidationOverrideMitigationAction | null;
}
export declare const PatchSettingResponse: S.Schema<PatchSettingResponse>;
export type SettingsUpdateRequestValidationDefaultMitigationAction = "none" | "log" | "block";
export declare const SettingsUpdateRequestValidationDefaultMitigationAction: any;
export type SettingsUpdateRequestValidationOverrideMitigationAction = "none";
export declare const SettingsUpdateRequestValidationOverrideMitigationAction: any;
export interface PutSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** The default mitigation action used */
    validationDefaultMitigationAction: SettingsUpdateRequestValidationDefaultMitigationAction | (string & {});
    /** When set, this overrides both zone level and operation level mitigation actions. */
    validationOverrideMitigationAction?: SettingsUpdateRequestValidationOverrideMitigationAction | (string & {}) | null;
}
export declare const PutSettingRequest: S.Schema<PutSettingRequest>;
export type SettingsUpdateResponseValidationDefaultMitigationAction = "none" | "log" | "block";
export declare const SettingsUpdateResponseValidationDefaultMitigationAction: any;
export type SettingsUpdateResponseValidationOverrideMitigationAction = "none";
export declare const SettingsUpdateResponseValidationOverrideMitigationAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingResponse {
    /** The default mitigation action used */
    validationDefaultMitigationAction: SettingsUpdateResponseValidationDefaultMitigationAction;
    /** When not null, this overrides global both zone level and operation level mitigation actions. This can serve as a quick way to disable schema validation for the whole zone. */
    validationOverrideMitigationAction?: SettingsUpdateResponseValidationOverrideMitigationAction | null;
}
export declare const PutSettingResponse: S.Schema<PutSettingResponse>;
export type SettingsOperationsUpdateRequestMitigationAction = "log" | "block" | "none";
export declare const SettingsOperationsUpdateRequestMitigationAction: any;
export interface PutSettingOperationRequest {
    /** Identifier. */
    zoneId: string;
    /** UUID. */
    operationId: string;
    /** When set, this applies a mitigation action to this operation */
    mitigationAction: SettingsOperationsUpdateRequestMitigationAction | (string & {});
}
export declare const PutSettingOperationRequest: S.Schema<PutSettingOperationRequest>;
export type SettingsOperationsUpdateResponseMitigationAction = "log" | "block" | "none";
export declare const SettingsOperationsUpdateResponseMitigationAction: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutSettingOperationResponse {
    /** When set, this applies a mitigation action to this operation which supersedes a global schema validation setting just for this operation */
    mitigationAction: SettingsOperationsUpdateResponseMitigationAction;
    /** UUID. */
    operationId: string;
}
export declare const PutSettingOperationResponse: S.Schema<PutSettingOperationResponse>;
export type BulkPatchSettingOperationsError = CloudflareOpError;
/** Updates schema validation settings for multiple API operations in a single request. Efficient for applying consistent validation rules across endpoints. */
export declare const bulkPatchSettingOperations: API.OperationMethod<BulkPatchSettingOperationsRequest, BulkPatchSettingOperationsResponse, BulkPatchSettingOperationsError, CloudflareOpContext>;
export type CreateSchemaError = InvalidSchema | Forbidden | CloudflareOpError;
/** Uploads a new OpenAPI schema for API Shield schema validation. The schema defines expected request/response formats for API endpoints. */
export declare const createSchema: API.OperationMethod<CreateSchemaRequest, CreateSchemaResponse, CreateSchemaError, CloudflareOpContext>;
export type DeleteSchemaError = SchemaNotFound | CloudflareOpError;
/** Permanently removes an uploaded OpenAPI schema from API Shield. Operations using this schema will lose their validation rules. */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaRequest, DeleteSchemaResponse, DeleteSchemaError, CloudflareOpContext>;
export type DeleteSettingOperationError = OperationNotFound | CloudflareOpError;
/** Removes custom schema validation settings for a specific API operation, reverting to zone-level defaults. */
export declare const deleteSettingOperation: API.OperationMethod<DeleteSettingOperationRequest, DeleteSettingOperationResponse, DeleteSettingOperationError, CloudflareOpContext>;
export type GetSchemaError = SchemaNotFound | Forbidden | CloudflareOpError;
/** Gets the contents and metadata of a specific OpenAPI schema uploaded to API Shield. */
export declare const getSchema: API.OperationMethod<GetSchemaRequest, GetSchemaResponse, GetSchemaError, CloudflareOpContext>;
export type GetSettingError = Forbidden | CloudflareOpError;
/** Retrieves the current global schema validation settings for a zone. */
export declare const getSetting: API.OperationMethod<GetSettingRequest, GetSettingResponse, GetSettingError, CloudflareOpContext>;
export type GetSettingOperationError = OperationNotFound | Forbidden | CloudflareOpError;
/** Retrieves the schema validation settings configured for a specific API operation. */
export declare const getSettingOperation: API.OperationMethod<GetSettingOperationRequest, GetSettingOperationResponse, GetSettingOperationError, CloudflareOpContext>;
export type ListSchemasError = ZonePurged | Forbidden | CloudflareOpError;
/** Lists all OpenAPI schemas uploaded to API Shield with pagination support. */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasRequest, ListSchemasResponse, ListSchemasError, CloudflareOpContext, SchemasListResultItem>;
export type ListSettingOperationsError = CloudflareOpError;
/** Lists all per-operation schema validation settings configured for the zone. */
export declare const listSettingOperations: API.PaginatedOperationMethod<ListSettingOperationsRequest, ListSettingOperationsResponse, ListSettingOperationsError, CloudflareOpContext, SettingsOperationsListResultItem>;
export type PatchSchemaError = SchemaNotFound | CloudflareOpError;
/** Modifies an existing OpenAPI schema in API Shield, updating the validation rules for associated API operations. */
export declare const patchSchema: API.OperationMethod<PatchSchemaRequest, PatchSchemaResponse, PatchSchemaError, CloudflareOpContext>;
export type PatchSettingError = CloudflareOpError;
/** Partially updates global schema validation settings for a zone using PATCH semantics. */
export declare const patchSetting: API.OperationMethod<PatchSettingRequest, PatchSettingResponse, PatchSettingError, CloudflareOpContext>;
export type PutSettingError = UnentitledMitigationAction | Forbidden | CloudflareOpError;
/** Fully updates global schema validation settings for a zone, replacing existing configuration. */
export declare const putSetting: API.OperationMethod<PutSettingRequest, PutSettingResponse, PutSettingError, CloudflareOpContext>;
export type PutSettingOperationError = OperationNotFound | UnentitledMitigationAction | CloudflareOpError;
/** Fully updates schema validation settings for a specific API operation. */
export declare const putSettingOperation: API.OperationMethod<PutSettingOperationRequest, PutSettingOperationResponse, PutSettingOperationError, CloudflareOpContext>;
//# sourceMappingURL=schema_validation.d.ts.map