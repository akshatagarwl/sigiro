import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AllowPolicyNotFound_base: S.Class<AllowPolicyNotFound, S.TaggedStruct<"AllowPolicyNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AllowPolicyNotFound extends /*@__PURE__*/ AllowPolicyNotFound_base {
}
declare const BlockSenderNotFound_base: S.Class<BlockSenderNotFound, S.TaggedStruct<"BlockSenderNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class BlockSenderNotFound extends /*@__PURE__*/ BlockSenderNotFound_base {
}
declare const EmailSecurityDomainNotFound_base: S.Class<EmailSecurityDomainNotFound, S.TaggedStruct<"EmailSecurityDomainNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EmailSecurityDomainNotFound extends /*@__PURE__*/ EmailSecurityDomainNotFound_base {
}
declare const EmailSecurityNotEntitled_base: S.Class<EmailSecurityNotEntitled, S.TaggedStruct<"EmailSecurityNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class EmailSecurityNotEntitled extends /*@__PURE__*/ EmailSecurityNotEntitled_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ImpersonationRegistryEntryNotFound_base: S.Class<ImpersonationRegistryEntryNotFound, S.TaggedStruct<"ImpersonationRegistryEntryNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ImpersonationRegistryEntryNotFound extends /*@__PURE__*/ ImpersonationRegistryEntryNotFound_base {
}
declare const TrustedDomainNotFound_base: S.Class<TrustedDomainNotFound, S.TaggedStruct<"TrustedDomainNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class TrustedDomainNotFound extends /*@__PURE__*/ TrustedDomainNotFound_base {
}
export type InvestigateMoveBulkRequestDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateMoveBulkRequestDestination: any;
export type InvestigateMoveBulkRequestExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateMoveBulkRequestExpectedDisposition: any;
export type InvestigateMoveBulkRequestIdsList = Array<string>;
export declare const InvestigateMoveBulkRequestIdsList: S.Schema<InvestigateMoveBulkRequestIdsList>;
export type InvestigateMoveBulkRequestPostfixIdsList = Array<string>;
export declare const InvestigateMoveBulkRequestPostfixIdsList: S.Schema<InvestigateMoveBulkRequestPostfixIdsList>;
export interface BulkInvestigateMoveRequest {
    /** Identifier. */
    accountId: string;
    destination: InvestigateMoveBulkRequestDestination | (string & {});
    expectedDisposition?: InvestigateMoveBulkRequestExpectedDisposition | (string & {});
    /** List of message IDs to move */
    ids?: InvestigateMoveBulkRequestIdsList;
    /** Deprecated, use `ids` instead. End of life: November 1, 2026. List of message IDs to move. */
    postfixIds?: InvestigateMoveBulkRequestPostfixIdsList;
}
export declare const BulkInvestigateMoveRequest: S.Schema<BulkInvestigateMoveRequest>;
export interface InvestigateMoveBulkResultItem {
    /** Whether the operation succeeded */
    success: boolean;
    /** When the move operation completed (UTC) */
    completedAt?: string | null;
    /** Deprecated, use `completed_at` instead. End of life: November 1, 2026. */
    completedTimestamp?: string | null;
    /** Destination folder for the message */
    destination?: string | null;
    /** Number of items moved. End of life: November 1, 2026. */
    itemCount?: number | null;
    /** Message identifier */
    messageId?: string | null;
    /** Type of operation performed */
    operation?: string | null;
    /** Recipient email address */
    recipient?: string | null;
    /** Operation status */
    status?: string | null;
}
export declare const InvestigateMoveBulkResultItem: S.Schema<InvestigateMoveBulkResultItem>;
export type InvestigateMoveBulkResultList = Array<InvestigateMoveBulkResultItem>;
export declare const InvestigateMoveBulkResultList: S.Schema<InvestigateMoveBulkResultList>;
export interface BulkInvestigateMoveResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateMoveBulkResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkInvestigateMoveResponse: S.Schema<BulkInvestigateMoveResponse>;
export type InvestigateReleaseBulkRequestBodyList = Array<string>;
export declare const InvestigateReleaseBulkRequestBodyList: S.Schema<InvestigateReleaseBulkRequestBodyList>;
export interface BulkInvestigateReleaseRequest {
    /** Identifier. */
    accountId: string;
    body: InvestigateReleaseBulkRequestBodyList;
}
export declare const BulkInvestigateReleaseRequest: S.Schema<BulkInvestigateReleaseRequest>;
export type InvestigateReleaseBulkResultItemDeliveredList = Array<string>;
export declare const InvestigateReleaseBulkResultItemDeliveredList: S.Schema<InvestigateReleaseBulkResultItemDeliveredList>;
export type InvestigateReleaseBulkResultItemFailedList = Array<string>;
export declare const InvestigateReleaseBulkResultItemFailedList: S.Schema<InvestigateReleaseBulkResultItemFailedList>;
export type InvestigateReleaseBulkResultItemUndeliveredList = Array<string>;
export declare const InvestigateReleaseBulkResultItemUndeliveredList: S.Schema<InvestigateReleaseBulkResultItemUndeliveredList>;
export interface InvestigateReleaseBulkResultItem {
    /** Unique identifier for a message retrieved from investigation */
    id: string;
    delivered?: InvestigateReleaseBulkResultItemDeliveredList | null;
    failed?: InvestigateReleaseBulkResultItemFailedList | null;
    /** Deprecated, use `id` instead. End of life: November 1, 2026. */
    postfixId?: string | null;
    undelivered?: InvestigateReleaseBulkResultItemUndeliveredList | null;
}
export declare const InvestigateReleaseBulkResultItem: S.Schema<InvestigateReleaseBulkResultItem>;
export type InvestigateReleaseBulkResultList = Array<InvestigateReleaseBulkResultItem>;
export declare const InvestigateReleaseBulkResultList: S.Schema<InvestigateReleaseBulkResultList>;
export interface BulkInvestigateReleaseResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateReleaseBulkResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkInvestigateReleaseResponse: S.Schema<BulkInvestigateReleaseResponse>;
export type InvestigateBulkCreateRequestAction = "MOVE" | "RELEASE";
export declare const InvestigateBulkCreateRequestAction: any;
export type InvestigateBulkCreateRequestSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateBulkCreateRequestSearchParamsDeliveryStatus: any;
export type InvestigateBulkCreateRequestSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkCreateRequestSearchParamsFinalDisposition: any;
export type InvestigateBulkCreateRequestSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export declare const InvestigateBulkCreateRequestSearchParamsMessageAction: any;
export interface InvestigateBulkCreateRequestSearchParams {
    /** Deprecated, use `GET /investigate/{investigate_id}/action_log` instead. End of life: November 1, 2026. */
    actionLog?: boolean;
    alertId?: string;
    /** Delivery status of the message. */
    deliveryStatus?: InvestigateBulkCreateRequestSearchParamsDeliveryStatus | (string & {});
    detectionsOnly?: boolean;
    domain?: string;
    /** End of search date range */
    end?: string;
    exactSubject?: string;
    finalDisposition?: InvestigateBulkCreateRequestSearchParamsFinalDisposition | (string & {});
    messageAction?: InvestigateBulkCreateRequestSearchParamsMessageAction | (string & {});
    messageId?: string;
    metric?: string;
    query?: string;
    recipient?: string;
    sender?: string;
    /** Beginning of search date range */
    start?: string;
    subject?: string;
    submissions?: boolean;
}
export declare const InvestigateBulkCreateRequestSearchParams: S.Schema<InvestigateBulkCreateRequestSearchParams>;
export type InvestigateBulkCreateRequestDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateBulkCreateRequestDestination: any;
export type InvestigateBulkCreateRequestExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkCreateRequestExpectedDisposition: any;
export interface CreateInvestigateBulkRequest {
    /** Identifier. */
    accountId: string;
    action: InvestigateBulkCreateRequestAction | (string & {});
    searchParams: InvestigateBulkCreateRequestSearchParams;
    comment?: string;
    destination?: InvestigateBulkCreateRequestDestination | (string & {});
    expectedDisposition?: InvestigateBulkCreateRequestExpectedDisposition | (string & {});
}
export declare const CreateInvestigateBulkRequest: S.Schema<CreateInvestigateBulkRequest>;
export type InvestigateBulkCreateResponseActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateBulkCreateResponseActionParamsMoveDestination: any;
export type InvestigateBulkCreateResponseActionParamsMoveType = "MOVE";
export declare const InvestigateBulkCreateResponseActionParamsMoveType: any;
export type InvestigateBulkCreateResponseActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkCreateResponseActionParamsMoveExpectedDisposition: any;
export interface InvestigateBulkCreateResponseActionParamsMove {
    destination: InvestigateBulkCreateResponseActionParamsMoveDestination;
    type: InvestigateBulkCreateResponseActionParamsMoveType;
    expectedDisposition?: InvestigateBulkCreateResponseActionParamsMoveExpectedDisposition | null;
}
export declare const InvestigateBulkCreateResponseActionParamsMove: S.Schema<InvestigateBulkCreateResponseActionParamsMove>;
export type InvestigateBulkCreateResponseActionParamsReleaseType = "RELEASE";
export declare const InvestigateBulkCreateResponseActionParamsReleaseType: any;
export interface InvestigateBulkCreateResponseActionParamsRelease {
    type: InvestigateBulkCreateResponseActionParamsReleaseType;
}
export declare const InvestigateBulkCreateResponseActionParamsRelease: S.Schema<InvestigateBulkCreateResponseActionParamsRelease>;
export type InvestigateBulkCreateResponseActionParams = InvestigateBulkCreateResponseActionParamsMove | InvestigateBulkCreateResponseActionParamsRelease;
export declare const InvestigateBulkCreateResponseActionParams: any;
export type InvestigateBulkCreateResponseActionType = "MOVE" | "RELEASE";
export declare const InvestigateBulkCreateResponseActionType: any;
export type InvestigateBulkCreateResponseSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateBulkCreateResponseSearchParamsDeliveryStatus: any;
export type InvestigateBulkCreateResponseSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkCreateResponseSearchParamsFinalDisposition: any;
export type InvestigateBulkCreateResponseSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export declare const InvestigateBulkCreateResponseSearchParamsMessageAction: any;
export interface InvestigateBulkCreateResponseSearchParams {
    /** Deprecated, use `GET /investigate/{investigate_id}/action_log` instead. End of life: November 1, 2026. */
    actionLog?: boolean | null;
    alertId?: string | null;
    /** Delivery status of the message. */
    deliveryStatus?: InvestigateBulkCreateResponseSearchParamsDeliveryStatus | null;
    detectionsOnly?: boolean | null;
    domain?: string | null;
    /** End of search date range */
    end?: string | null;
    exactSubject?: string | null;
    finalDisposition?: InvestigateBulkCreateResponseSearchParamsFinalDisposition | null;
    messageAction?: InvestigateBulkCreateResponseSearchParamsMessageAction | null;
    messageId?: string | null;
    metric?: string | null;
    query?: string | null;
    recipient?: string | null;
    sender?: string | null;
    /** Beginning of search date range */
    start?: string | null;
    subject?: string | null;
    submissions?: boolean | null;
}
export declare const InvestigateBulkCreateResponseSearchParams: S.Schema<InvestigateBulkCreateResponseSearchParams>;
export type InvestigateBulkCreateResponseStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export declare const InvestigateBulkCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInvestigateBulkResponse {
    actionParams: InvestigateBulkCreateResponseActionParams;
    actionType: InvestigateBulkCreateResponseActionType;
    createdAt: string;
    jobId: string;
    messagesFailed: number;
    messagesPending: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkCreateResponseSearchParams;
    status: InvestigateBulkCreateResponseStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export declare const CreateInvestigateBulkResponse: S.Schema<CreateInvestigateBulkResponse>;
export interface CreateInvestigateBulkCancelRequest {
    /** Identifier. */
    accountId: string;
    jobId: string;
}
export declare const CreateInvestigateBulkCancelRequest: S.Schema<CreateInvestigateBulkCancelRequest>;
export type InvestigateBulkCancelCreateResponseActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateBulkCancelCreateResponseActionParamsMoveDestination: any;
export type InvestigateBulkCancelCreateResponseActionParamsMoveType = "MOVE";
export declare const InvestigateBulkCancelCreateResponseActionParamsMoveType: any;
export type InvestigateBulkCancelCreateResponseActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkCancelCreateResponseActionParamsMoveExpectedDisposition: any;
export interface InvestigateBulkCancelCreateResponseActionParamsMove {
    destination: InvestigateBulkCancelCreateResponseActionParamsMoveDestination;
    type: InvestigateBulkCancelCreateResponseActionParamsMoveType;
    expectedDisposition?: InvestigateBulkCancelCreateResponseActionParamsMoveExpectedDisposition | null;
}
export declare const InvestigateBulkCancelCreateResponseActionParamsMove: S.Schema<InvestigateBulkCancelCreateResponseActionParamsMove>;
export type InvestigateBulkCancelCreateResponseActionParamsReleaseType = "RELEASE";
export declare const InvestigateBulkCancelCreateResponseActionParamsReleaseType: any;
export interface InvestigateBulkCancelCreateResponseActionParamsRelease {
    type: InvestigateBulkCancelCreateResponseActionParamsReleaseType;
}
export declare const InvestigateBulkCancelCreateResponseActionParamsRelease: S.Schema<InvestigateBulkCancelCreateResponseActionParamsRelease>;
export type InvestigateBulkCancelCreateResponseActionParams = InvestigateBulkCancelCreateResponseActionParamsMove | InvestigateBulkCancelCreateResponseActionParamsRelease;
export declare const InvestigateBulkCancelCreateResponseActionParams: any;
export type InvestigateBulkCancelCreateResponseActionType = "MOVE" | "RELEASE";
export declare const InvestigateBulkCancelCreateResponseActionType: any;
export type InvestigateBulkCancelCreateResponseSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateBulkCancelCreateResponseSearchParamsDeliveryStatus: any;
export type InvestigateBulkCancelCreateResponseSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkCancelCreateResponseSearchParamsFinalDisposition: any;
export type InvestigateBulkCancelCreateResponseSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export declare const InvestigateBulkCancelCreateResponseSearchParamsMessageAction: any;
export interface InvestigateBulkCancelCreateResponseSearchParams {
    /** Deprecated, use `GET /investigate/{investigate_id}/action_log` instead. End of life: November 1, 2026. */
    actionLog?: boolean | null;
    alertId?: string | null;
    /** Delivery status of the message. */
    deliveryStatus?: InvestigateBulkCancelCreateResponseSearchParamsDeliveryStatus | null;
    detectionsOnly?: boolean | null;
    domain?: string | null;
    /** End of search date range */
    end?: string | null;
    exactSubject?: string | null;
    finalDisposition?: InvestigateBulkCancelCreateResponseSearchParamsFinalDisposition | null;
    messageAction?: InvestigateBulkCancelCreateResponseSearchParamsMessageAction | null;
    messageId?: string | null;
    metric?: string | null;
    query?: string | null;
    recipient?: string | null;
    sender?: string | null;
    /** Beginning of search date range */
    start?: string | null;
    subject?: string | null;
    submissions?: boolean | null;
}
export declare const InvestigateBulkCancelCreateResponseSearchParams: S.Schema<InvestigateBulkCancelCreateResponseSearchParams>;
export type InvestigateBulkCancelCreateResponseStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export declare const InvestigateBulkCancelCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInvestigateBulkCancelResponse {
    actionParams: InvestigateBulkCancelCreateResponseActionParams;
    actionType: InvestigateBulkCancelCreateResponseActionType;
    createdAt: string;
    jobId: string;
    messagesFailed: number;
    messagesPending: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkCancelCreateResponseSearchParams;
    status: InvestigateBulkCancelCreateResponseStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export declare const CreateInvestigateBulkCancelResponse: S.Schema<CreateInvestigateBulkCancelResponse>;
export type InvestigateMoveCreateRequestDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateMoveCreateRequestDestination: any;
export type InvestigateMoveCreateRequestExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateMoveCreateRequestExpectedDisposition: any;
export interface CreateInvestigateMoveRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation */
    investigateId: string;
    destination: InvestigateMoveCreateRequestDestination | (string & {});
    expectedDisposition?: InvestigateMoveCreateRequestExpectedDisposition | (string & {});
}
export declare const CreateInvestigateMoveRequest: S.Schema<CreateInvestigateMoveRequest>;
export type InvestigateMoveCreateResultItem = InvestigateMoveBulkResultItem;
export declare const InvestigateMoveCreateResultItem: S.Schema<InvestigateMoveBulkResultItem>;
export type InvestigateMoveCreateResultList = Array<InvestigateMoveBulkResultItem>;
export declare const InvestigateMoveCreateResultList: S.Schema<InvestigateMoveCreateResultList>;
export interface CreateInvestigateMoveResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateMoveCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateInvestigateMoveResponse: S.Schema<CreateInvestigateMoveResponse>;
export interface CreateInvestigatePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** The identifier of the message */
    postfixId: string;
}
export declare const CreateInvestigatePreviewRequest: S.Schema<CreateInvestigatePreviewRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInvestigatePreviewResponse {
    /** A base64 encoded PNG image of the email. */
    screenshot: string;
}
export declare const CreateInvestigatePreviewResponse: S.Schema<CreateInvestigatePreviewResponse>;
export type InvestigateReclassifyCreateRequestExpectedDisposition = "NONE" | "BULK" | "MALICIOUS" | "SPAM" | "SPOOF" | "SUSPICIOUS";
export declare const InvestigateReclassifyCreateRequestExpectedDisposition: any;
export interface CreateInvestigateReclassifyRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation */
    investigateId: string;
    expectedDisposition: InvestigateReclassifyCreateRequestExpectedDisposition | (string & {});
    /** Base64 encoded content of the EML file. */
    emlContent?: string;
    escalatedSubmissionId?: string;
}
export declare const CreateInvestigateReclassifyRequest: S.Schema<CreateInvestigateReclassifyRequest>;
export type CreateInvestigateReclassifyResponse = unknown;
export declare const CreateInvestigateReclassifyResponse: S.Schema<CreateInvestigateReclassifyResponse>;
export type SettingsAllowPoliciesCreateRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsAllowPoliciesCreateRequestPatternType: any;
export interface CreateSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Messages from this sender will be exempted from Spam, Spoof and Bulk dispositions. Note - This will not exempt messages with Malicious or Suspicious dispositions. */
    isAcceptableSender: boolean;
    /** Messages to this recipient will bypass all detections */
    isExemptRecipient: boolean;
    isRegex: boolean;
    /** Messages from this sender will bypass all detections and link following */
    isTrustedSender: boolean;
    pattern: string;
    /** Type of pattern matching. */
    patternType: SettingsAllowPoliciesCreateRequestPatternType | (string & {});
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender: boolean;
    comments?: string;
    /** Deprecated as of July 1, 2025. Use `is_exempt_recipient` instead. End of life: July 1, 2026. */
    isRecipient?: boolean;
    /** Deprecated as of July 1, 2025. Use `is_trusted_sender` instead. End of life: July 1, 2026. */
    isSender?: boolean;
    /** Deprecated as of July 1, 2025. Use `is_acceptable_sender` instead. End of life: July 1, 2026. */
    isSpoof?: boolean;
}
export declare const CreateSettingAllowPolicyRequest: S.Schema<CreateSettingAllowPolicyRequest>;
export type SettingsAllowPoliciesCreateResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsAllowPoliciesCreateResponsePatternType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingAllowPolicyResponse {
    /** Allow policy identifier */
    id: string;
    createdAt: string;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified: string;
    comments?: string | null;
    /** Messages from this sender will be exempted from Spam, Spoof and Bulk dispositions. Note - This will not exempt messages with Malicious or Suspicious dispositions. */
    isAcceptableSender?: boolean | null;
    /** Messages to this recipient will bypass all detections */
    isExemptRecipient?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_exempt_recipient` instead. End of life: July 1, 2026. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_trusted_sender` instead. End of life: July 1, 2026. */
    isSender?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_acceptable_sender` instead. End of life: July 1, 2026. */
    isSpoof?: boolean | null;
    /** Messages from this sender will bypass all detections and link following */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesCreateResponsePatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export declare const CreateSettingAllowPolicyResponse: S.Schema<CreateSettingAllowPolicyResponse>;
export type SettingsBlockSendersCreateRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsBlockSendersCreateRequestPatternType: any;
export interface CreateSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    isRegex: boolean;
    pattern: string;
    /** Type of pattern matching. */
    patternType: SettingsBlockSendersCreateRequestPatternType | (string & {});
    comments?: string;
}
export declare const CreateSettingBlockSenderRequest: S.Schema<CreateSettingBlockSenderRequest>;
export type SettingsBlockSendersCreateResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsBlockSendersCreateResponsePatternType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingBlockSenderResponse {
    /** Blocked sender pattern identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    isRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersCreateResponsePatternType | null;
}
export declare const CreateSettingBlockSenderResponse: S.Schema<CreateSettingBlockSenderResponse>;
export type SettingsImpersonationRegistryCreateRequestProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export declare const SettingsImpersonationRegistryCreateRequestProvenance: any;
export interface CreateSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    email: string;
    isEmailRegex: boolean;
    name: string;
    comments?: string;
    directoryId?: number;
    directoryNodeId?: number;
    externalDirectoryNodeId?: string;
    provenance?: SettingsImpersonationRegistryCreateRequestProvenance | (string & {});
}
export declare const CreateSettingImpersonationRegistryRequest: S.Schema<CreateSettingImpersonationRegistryRequest>;
export type SettingsImpersonationRegistryCreateResponseProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export declare const SettingsImpersonationRegistryCreateResponseProvenance: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    directoryId?: number | null;
    directoryNodeId?: number | null;
    email?: string | null;
    externalDirectoryNodeId?: string | null;
    isEmailRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    name?: string | null;
    provenance?: SettingsImpersonationRegistryCreateResponseProvenance | null;
}
export declare const CreateSettingImpersonationRegistryResponse: S.Schema<CreateSettingImpersonationRegistryResponse>;
export type SettingsSendingDomainRestrictionsCreateRequestExcludeList = Array<string>;
export declare const SettingsSendingDomainRestrictionsCreateRequestExcludeList: S.Schema<SettingsSendingDomainRestrictionsCreateRequestExcludeList>;
export interface CreateSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Domain that requires TLS enforcement. */
    domain: string;
    /** Excluded subdomains that are exempt from TLS requirements. */
    exclude: SettingsSendingDomainRestrictionsCreateRequestExcludeList;
    comments?: string;
}
export declare const CreateSettingSendingDomainRestrictionRequest: S.Schema<CreateSettingSendingDomainRestrictionRequest>;
export type SettingsSendingDomainRestrictionsCreateResponseExcludeList = Array<string>;
export declare const SettingsSendingDomainRestrictionsCreateResponseExcludeList: S.Schema<SettingsSendingDomainRestrictionsCreateResponseExcludeList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Excluded subdomains that are exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsCreateResponseExcludeList | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const CreateSettingSendingDomainRestrictionResponse: S.Schema<CreateSettingSendingDomainRestrictionResponse>;
export interface CreateSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent: boolean;
    isRegex: boolean;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity: boolean;
    pattern: string;
    comments?: string;
}
export declare const CreateSettingTrustedDomainRequest: S.Schema<CreateSettingTrustedDomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingTrustedDomainResponse {
    /** Trusted domain identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
}
export declare const CreateSettingTrustedDomainResponse: S.Schema<CreateSettingTrustedDomainResponse>;
export interface CreateSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** Regular expression matching URLs that should not be rewritten. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string;
}
export declare const CreateSettingUrlIgnorePatternRequest: S.Schema<CreateSettingUrlIgnorePatternRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier */
    id: string;
    createdAt: string;
    /** Regular expression matching URLs that should not be rewritten. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const CreateSettingUrlIgnorePatternResponse: S.Schema<CreateSettingUrlIgnorePatternResponse>;
export interface DeleteInvestigateBulkRequest {
    /** Identifier. */
    accountId: string;
    jobId: string;
}
export declare const DeleteInvestigateBulkRequest: S.Schema<DeleteInvestigateBulkRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteInvestigateBulkResponse {
    id: string;
}
export declare const DeleteInvestigateBulkResponse: S.Schema<DeleteInvestigateBulkResponse>;
export interface DeleteSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Allow policy identifier */
    policyId: string;
}
export declare const DeleteSettingAllowPolicyRequest: S.Schema<DeleteSettingAllowPolicyRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingAllowPolicyResponse {
    /** Allow policy identifier */
    id: string;
}
export declare const DeleteSettingAllowPolicyResponse: S.Schema<DeleteSettingAllowPolicyResponse>;
export interface DeleteSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    /** Blocked sender pattern identifier */
    patternId: string;
}
export declare const DeleteSettingBlockSenderRequest: S.Schema<DeleteSettingBlockSenderRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingBlockSenderResponse {
    /** Blocked sender pattern identifier */
    id: string;
}
export declare const DeleteSettingBlockSenderResponse: S.Schema<DeleteSettingBlockSenderResponse>;
export interface DeleteSettingDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Domain identifier */
    domainId: string;
}
export declare const DeleteSettingDomainRequest: S.Schema<DeleteSettingDomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingDomainResponse {
    /** Domain identifier */
    id: string;
}
export declare const DeleteSettingDomainResponse: S.Schema<DeleteSettingDomainResponse>;
export interface DeleteSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    /** Impersonation registry entry identifier */
    impersonationRegistryId: string;
}
export declare const DeleteSettingImpersonationRegistryRequest: S.Schema<DeleteSettingImpersonationRegistryRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier */
    id: string;
}
export declare const DeleteSettingImpersonationRegistryResponse: S.Schema<DeleteSettingImpersonationRegistryResponse>;
export interface DeleteSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Sending domain restriction identifier. */
    sendingDomainRestrictionId: string;
}
export declare const DeleteSettingSendingDomainRestrictionRequest: S.Schema<DeleteSettingSendingDomainRestrictionRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id: string;
}
export declare const DeleteSettingSendingDomainRestrictionResponse: S.Schema<DeleteSettingSendingDomainRestrictionResponse>;
export interface DeleteSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Trusted domain identifier */
    trustedDomainId: string;
}
export declare const DeleteSettingTrustedDomainRequest: S.Schema<DeleteSettingTrustedDomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingTrustedDomainResponse {
    /** Trusted domain identifier */
    id: string;
}
export declare const DeleteSettingTrustedDomainResponse: S.Schema<DeleteSettingTrustedDomainResponse>;
export interface DeleteSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** URL ignore pattern identifier */
    patternId: string;
}
export declare const DeleteSettingUrlIgnorePatternRequest: S.Schema<DeleteSettingUrlIgnorePatternRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier */
    id: string;
}
export declare const DeleteSettingUrlIgnorePatternResponse: S.Schema<DeleteSettingUrlIgnorePatternResponse>;
export interface GetInvestigateRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation */
    investigateId: string;
    /** When true, search the submissions datastore only. When false or omitted, search the */
    submission?: boolean;
}
export declare const GetInvestigateRequest: S.Schema<GetInvestigateRequest>;
export type InvestigateGetResponseActionLogItemOperation = "MOVE" | "RELEASE" | "RECLASSIFY" | "SUBMISSION" | "QUARANTINE_RELEASE" | "PREVIEW";
export declare const InvestigateGetResponseActionLogItemOperation: any;
export interface InvestigateGetResponseActionLogItemProperties {
    /** Target folder for move operations */
    folder?: string | null;
    /** User who requested the action */
    requestedBy?: string | null;
}
export declare const InvestigateGetResponseActionLogItemProperties: S.Schema<InvestigateGetResponseActionLogItemProperties>;
export interface InvestigateGetResponseActionLogItem {
    /** Timestamp when action completed */
    completedAt: string;
    /** Type of action performed */
    operation: InvestigateGetResponseActionLogItemOperation;
    /** Deprecated, use `completed_at` instead. End of life: November 1, 2026. */
    completedTimestamp?: string | null;
    /** Additional properties for the action */
    properties?: InvestigateGetResponseActionLogItemProperties | null;
    /** Status of the action */
    status?: string | null;
}
export declare const InvestigateGetResponseActionLogItem: S.Schema<InvestigateGetResponseActionLogItem>;
export type InvestigateGetResponseActionLogList = Array<InvestigateGetResponseActionLogItem>;
export declare const InvestigateGetResponseActionLogList: S.Schema<InvestigateGetResponseActionLogList>;
export type InvestigateGetResponseClientRecipientsList = Array<string>;
export declare const InvestigateGetResponseClientRecipientsList: S.Schema<InvestigateGetResponseClientRecipientsList>;
export type InvestigateGetResponseDetectionReasonsList = Array<string>;
export declare const InvestigateGetResponseDetectionReasonsList: S.Schema<InvestigateGetResponseDetectionReasonsList>;
export type InvestigateGetResponsePropertiesAllowlistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export declare const InvestigateGetResponsePropertiesAllowlistedPatternType: any;
export type InvestigateGetResponsePropertiesWhitelistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export declare const InvestigateGetResponsePropertiesWhitelistedPatternType: any;
export interface InvestigateGetResponseProperties {
    /** Pattern that allowlisted this message */
    allowlistedPattern?: string | null;
    /** Type of allowlist pattern */
    allowlistedPatternType?: InvestigateGetResponsePropertiesAllowlistedPatternType | null;
    /** Whether message was blocklisted */
    blocklistedMessage?: boolean | null;
    /** Pattern that blocklisted this message */
    blocklistedPattern?: string | null;
    /** Legacy field for allowlist pattern type */
    whitelistedPatternType?: InvestigateGetResponsePropertiesWhitelistedPatternType | null;
}
export declare const InvestigateGetResponseProperties: S.Schema<InvestigateGetResponseProperties>;
export type InvestigateGetResponseDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "REVIEW_SUBMISSION" | "DMARC_UNVERIFIED" | "DMARC_FAILURE_REPORT" | "DMARC_AGGREGATE_REPORT" | "THREAT_INTEL_SUBMISSION" | "SIMULATION_SUBMISSION" | "API" | "RETRO_SCAN";
export declare const InvestigateGetResponseDeliveryMode: any;
export type InvestigateGetResponseDeliveryStatusItem = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateGetResponseDeliveryStatusItem: any;
export type InvestigateGetResponseDeliveryStatusList = Array<InvestigateGetResponseDeliveryStatusItem>;
export declare const InvestigateGetResponseDeliveryStatusList: S.Schema<InvestigateGetResponseDeliveryStatusList>;
export type InvestigateGetResponseEnvelopeToList = Array<string>;
export declare const InvestigateGetResponseEnvelopeToList: S.Schema<InvestigateGetResponseEnvelopeToList>;
export type InvestigateGetResponseFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateGetResponseFinalDisposition: any;
export type InvestigateGetResponseFindingsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateGetResponseFindingsItemDetection: any;
export interface InvestigateGetResponseFindingsItem {
    attachment?: string | null;
    detail?: string | null;
    detection?: InvestigateGetResponseFindingsItemDetection | null;
    field?: string | null;
    name?: string | null;
    portion?: string | null;
    reason?: string | null;
    score?: number | null;
    value?: string | null;
}
export declare const InvestigateGetResponseFindingsItem: S.Schema<InvestigateGetResponseFindingsItem>;
export type InvestigateGetResponseFindingsList = Array<InvestigateGetResponseFindingsItem>;
export declare const InvestigateGetResponseFindingsList: S.Schema<InvestigateGetResponseFindingsList>;
export type InvestigateGetResponsePostDeliveryOperationsItem = "PREVIEW" | "QUARANTINE_RELEASE" | "SUBMISSION" | "MOVE";
export declare const InvestigateGetResponsePostDeliveryOperationsItem: any;
export type InvestigateGetResponsePostDeliveryOperationsList = Array<InvestigateGetResponsePostDeliveryOperationsItem>;
export declare const InvestigateGetResponsePostDeliveryOperationsList: S.Schema<InvestigateGetResponsePostDeliveryOperationsList>;
export type InvestigateGetResponseThreatCategoriesList = Array<string>;
export declare const InvestigateGetResponseThreatCategoriesList: S.Schema<InvestigateGetResponseThreatCategoriesList>;
export type InvestigateGetResponseToList = Array<string>;
export declare const InvestigateGetResponseToList: S.Schema<InvestigateGetResponseToList>;
export type InvestigateGetResponseToNameList = Array<string>;
export declare const InvestigateGetResponseToNameList: S.Schema<InvestigateGetResponseToNameList>;
export type InvestigateGetResponseValidationDkim = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateGetResponseValidationDkim: any;
export type InvestigateGetResponseValidationDmarc = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateGetResponseValidationDmarc: any;
export type InvestigateGetResponseValidationSpf = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateGetResponseValidationSpf: any;
export interface InvestigateGetResponseValidation {
    comment?: string | null;
    dkim?: InvestigateGetResponseValidationDkim | null;
    dmarc?: InvestigateGetResponseValidationDmarc | null;
    spf?: InvestigateGetResponseValidationSpf | null;
}
export declare const InvestigateGetResponseValidation: S.Schema<InvestigateGetResponseValidation>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateResponse {
    /** Unique identifier for a message retrieved from investigation */
    id: string;
    /** Deprecated, use `GET /investigate/{investigate_id}/action_log` instead. End of life: November 1, 2026. */
    actionLog: InvestigateGetResponseActionLogList;
    clientRecipients: InvestigateGetResponseClientRecipientsList;
    detectionReasons: InvestigateGetResponseDetectionReasonsList;
    isPhishSubmission: boolean;
    isQuarantined: boolean;
    /** The identifier of the message */
    postfixId: string;
    /** Message processing properties */
    properties: InvestigateGetResponseProperties;
    /** Deprecated, use `scanned_at` instead. End of life: November 1, 2026. */
    ts: string;
    alertId?: string | null;
    deliveryMode?: InvestigateGetResponseDeliveryMode | null;
    deliveryStatus?: InvestigateGetResponseDeliveryStatusList | null;
    edfHash?: string | null;
    envelopeFrom?: string | null;
    envelopeTo?: InvestigateGetResponseEnvelopeToList | null;
    finalDisposition?: InvestigateGetResponseFinalDisposition | null;
    /** Deprecated, use the `findings` field from `GET /investigate/{investigate_id}/detections` instead. End of life: November 1, 2026. Detection findings for this message. */
    findings?: InvestigateGetResponseFindingsList | null;
    from?: string | null;
    fromName?: string | null;
    htmltextStructureHash?: string | null;
    messageId?: string | null;
    /** Post-delivery operations performed on this message */
    postDeliveryOperations?: InvestigateGetResponsePostDeliveryOperationsList | null;
    postfixIdOutbound?: string | null;
    replyto?: string | null;
    /** When the message was scanned (UTC) */
    scannedAt?: string | null;
    /** When the message was sent (UTC) */
    sentAt?: string | null;
    sentDate?: string | null;
    smtpHeloServerIp?: string | null;
    smtpPreviousHopIp?: string | null;
    subject?: string | null;
    threatCategories?: InvestigateGetResponseThreatCategoriesList | null;
    to?: InvestigateGetResponseToList | null;
    toName?: InvestigateGetResponseToNameList | null;
    validation?: InvestigateGetResponseValidation | null;
    xOriginatingIp?: string | null;
}
export declare const GetInvestigateResponse: S.Schema<GetInvestigateResponse>;
export interface GetInvestigateBulkRequest {
    /** Identifier. */
    accountId: string;
    jobId: string;
}
export declare const GetInvestigateBulkRequest: S.Schema<GetInvestigateBulkRequest>;
export type InvestigateBulkGetResponseActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateBulkGetResponseActionParamsMoveDestination: any;
export type InvestigateBulkGetResponseActionParamsMoveType = "MOVE";
export declare const InvestigateBulkGetResponseActionParamsMoveType: any;
export type InvestigateBulkGetResponseActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkGetResponseActionParamsMoveExpectedDisposition: any;
export interface InvestigateBulkGetResponseActionParamsMove {
    destination: InvestigateBulkGetResponseActionParamsMoveDestination;
    type: InvestigateBulkGetResponseActionParamsMoveType;
    expectedDisposition?: InvestigateBulkGetResponseActionParamsMoveExpectedDisposition | null;
}
export declare const InvestigateBulkGetResponseActionParamsMove: S.Schema<InvestigateBulkGetResponseActionParamsMove>;
export type InvestigateBulkGetResponseActionParamsReleaseType = "RELEASE";
export declare const InvestigateBulkGetResponseActionParamsReleaseType: any;
export interface InvestigateBulkGetResponseActionParamsRelease {
    type: InvestigateBulkGetResponseActionParamsReleaseType;
}
export declare const InvestigateBulkGetResponseActionParamsRelease: S.Schema<InvestigateBulkGetResponseActionParamsRelease>;
export type InvestigateBulkGetResponseActionParams = InvestigateBulkGetResponseActionParamsMove | InvestigateBulkGetResponseActionParamsRelease;
export declare const InvestigateBulkGetResponseActionParams: any;
export type InvestigateBulkGetResponseActionType = "MOVE" | "RELEASE";
export declare const InvestigateBulkGetResponseActionType: any;
export type InvestigateBulkGetResponseSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateBulkGetResponseSearchParamsDeliveryStatus: any;
export type InvestigateBulkGetResponseSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkGetResponseSearchParamsFinalDisposition: any;
export type InvestigateBulkGetResponseSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export declare const InvestigateBulkGetResponseSearchParamsMessageAction: any;
export interface InvestigateBulkGetResponseSearchParams {
    /** Deprecated, use `GET /investigate/{investigate_id}/action_log` instead. End of life: November 1, 2026. */
    actionLog?: boolean | null;
    alertId?: string | null;
    /** Delivery status of the message. */
    deliveryStatus?: InvestigateBulkGetResponseSearchParamsDeliveryStatus | null;
    detectionsOnly?: boolean | null;
    domain?: string | null;
    /** End of search date range */
    end?: string | null;
    exactSubject?: string | null;
    finalDisposition?: InvestigateBulkGetResponseSearchParamsFinalDisposition | null;
    messageAction?: InvestigateBulkGetResponseSearchParamsMessageAction | null;
    messageId?: string | null;
    metric?: string | null;
    query?: string | null;
    recipient?: string | null;
    sender?: string | null;
    /** Beginning of search date range */
    start?: string | null;
    subject?: string | null;
    submissions?: boolean | null;
}
export declare const InvestigateBulkGetResponseSearchParams: S.Schema<InvestigateBulkGetResponseSearchParams>;
export type InvestigateBulkGetResponseStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export declare const InvestigateBulkGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateBulkResponse {
    actionParams: InvestigateBulkGetResponseActionParams;
    actionType: InvestigateBulkGetResponseActionType;
    createdAt: string;
    jobId: string;
    messagesFailed: number;
    messagesPending: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkGetResponseSearchParams;
    status: InvestigateBulkGetResponseStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export declare const GetInvestigateBulkResponse: S.Schema<GetInvestigateBulkResponse>;
export interface GetInvestigateDetectionRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation */
    investigateId: string;
}
export declare const GetInvestigateDetectionRequest: S.Schema<GetInvestigateDetectionRequest>;
export type InvestigateDetectionsGetResponseAttachmentsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateDetectionsGetResponseAttachmentsItemDetection: any;
export interface InvestigateDetectionsGetResponseAttachmentsItem {
    /** Size of the attachment in bytes */
    size: number;
    /** MIME type of the attachment */
    contentType?: string | null;
    /** Detection result for this attachment */
    detection?: InvestigateDetectionsGetResponseAttachmentsItemDetection | null;
    /** Whether the attachment is encrypted */
    encrypted?: boolean | null;
    /** Name of the attached file */
    filename?: string | null;
    /** MD5 hash of the attachment */
    md5?: string | null;
    /** Attachment name (alternative to filename) */
    name?: string | null;
    /** SHA1 hash of the attachment */
    sha1?: string | null;
    /** SHA256 hash of the attachment */
    sha256?: string | null;
}
export declare const InvestigateDetectionsGetResponseAttachmentsItem: S.Schema<InvestigateDetectionsGetResponseAttachmentsItem>;
export type InvestigateDetectionsGetResponseAttachmentsList = Array<InvestigateDetectionsGetResponseAttachmentsItem>;
export declare const InvestigateDetectionsGetResponseAttachmentsList: S.Schema<InvestigateDetectionsGetResponseAttachmentsList>;
export type InvestigateDetectionsGetResponseFindingsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateDetectionsGetResponseFindingsItemDetection: any;
export interface InvestigateDetectionsGetResponseFindingsItem {
    attachment?: string | null;
    detail?: string | null;
    detection?: InvestigateDetectionsGetResponseFindingsItemDetection | null;
    field?: string | null;
    name?: string | null;
    portion?: string | null;
    reason?: string | null;
    score?: number | null;
    value?: string | null;
}
export declare const InvestigateDetectionsGetResponseFindingsItem: S.Schema<InvestigateDetectionsGetResponseFindingsItem>;
export type InvestigateDetectionsGetResponseFindingsList = Array<InvestigateDetectionsGetResponseFindingsItem>;
export declare const InvestigateDetectionsGetResponseFindingsList: S.Schema<InvestigateDetectionsGetResponseFindingsList>;
export interface InvestigateDetectionsGetResponseHeadersItem {
    name: string;
    value: string;
}
export declare const InvestigateDetectionsGetResponseHeadersItem: S.Schema<InvestigateDetectionsGetResponseHeadersItem>;
export type InvestigateDetectionsGetResponseHeadersList = Array<InvestigateDetectionsGetResponseHeadersItem>;
export declare const InvestigateDetectionsGetResponseHeadersList: S.Schema<InvestigateDetectionsGetResponseHeadersList>;
export interface InvestigateDetectionsGetResponseLinksItem {
    href: string;
    text?: string | null;
}
export declare const InvestigateDetectionsGetResponseLinksItem: S.Schema<InvestigateDetectionsGetResponseLinksItem>;
export type InvestigateDetectionsGetResponseLinksList = Array<InvestigateDetectionsGetResponseLinksItem>;
export declare const InvestigateDetectionsGetResponseLinksList: S.Schema<InvestigateDetectionsGetResponseLinksList>;
export interface InvestigateDetectionsGetResponseSenderInfo {
    /** The name of the autonomous system. */
    asName?: string | null;
    /** The number of the autonomous system. */
    asNumber?: number | null;
    geo?: string | null;
    ip?: string | null;
    pld?: string | null;
}
export declare const InvestigateDetectionsGetResponseSenderInfo: S.Schema<InvestigateDetectionsGetResponseSenderInfo>;
export interface InvestigateDetectionsGetResponseThreatCategoriesItem {
    id?: number | null;
    description?: string | null;
    name?: string | null;
}
export declare const InvestigateDetectionsGetResponseThreatCategoriesItem: S.Schema<InvestigateDetectionsGetResponseThreatCategoriesItem>;
export type InvestigateDetectionsGetResponseThreatCategoriesList = Array<InvestigateDetectionsGetResponseThreatCategoriesItem>;
export declare const InvestigateDetectionsGetResponseThreatCategoriesList: S.Schema<InvestigateDetectionsGetResponseThreatCategoriesList>;
export type InvestigateDetectionsGetResponseValidationDkim = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateDetectionsGetResponseValidationDkim: any;
export type InvestigateDetectionsGetResponseValidationDmarc = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateDetectionsGetResponseValidationDmarc: any;
export type InvestigateDetectionsGetResponseValidationSpf = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateDetectionsGetResponseValidationSpf: any;
export interface InvestigateDetectionsGetResponseValidation {
    comment?: string | null;
    dkim?: InvestigateDetectionsGetResponseValidationDkim | null;
    dmarc?: InvestigateDetectionsGetResponseValidationDmarc | null;
    spf?: InvestigateDetectionsGetResponseValidationSpf | null;
}
export declare const InvestigateDetectionsGetResponseValidation: S.Schema<InvestigateDetectionsGetResponseValidation>;
export type InvestigateDetectionsGetResponseFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateDetectionsGetResponseFinalDisposition: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateDetectionResponse {
    action: string;
    attachments: InvestigateDetectionsGetResponseAttachmentsList;
    findings: InvestigateDetectionsGetResponseFindingsList;
    headers: InvestigateDetectionsGetResponseHeadersList;
    links: InvestigateDetectionsGetResponseLinksList;
    senderInfo: InvestigateDetectionsGetResponseSenderInfo;
    threatCategories: InvestigateDetectionsGetResponseThreatCategoriesList;
    validation: InvestigateDetectionsGetResponseValidation;
    finalDisposition?: InvestigateDetectionsGetResponseFinalDisposition | null;
}
export declare const GetInvestigateDetectionResponse: S.Schema<GetInvestigateDetectionResponse>;
export interface GetInvestigatePreviewRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation */
    investigateId: string;
}
export declare const GetInvestigatePreviewRequest: S.Schema<GetInvestigatePreviewRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigatePreviewResponse {
    /** A base64 encoded PNG image of the email. */
    screenshot: string;
}
export declare const GetInvestigatePreviewResponse: S.Schema<GetInvestigatePreviewResponse>;
export interface GetInvestigateRawRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation */
    investigateId: string;
}
export declare const GetInvestigateRawRequest: S.Schema<GetInvestigateRawRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateRawResponse {
    /** A UTF-8 encoded eml file of the email. */
    raw: string;
}
export declare const GetInvestigateRawResponse: S.Schema<GetInvestigateRawResponse>;
export interface GetInvestigateTraceRequest {
    /** Identifier. */
    accountId: string;
    /** Unique identifier for a message retrieved from investigation */
    investigateId: string;
}
export declare const GetInvestigateTraceRequest: S.Schema<GetInvestigateTraceRequest>;
export interface InvestigateTraceGetResponseInboundLinesItem {
    /** Line number in the trace log */
    lineno?: number | null;
    loggedAt?: string | null;
    message?: string | null;
    /** Deprecated, use `logged_at` instead. End of life: November 1, 2026. */
    ts?: string | null;
}
export declare const InvestigateTraceGetResponseInboundLinesItem: S.Schema<InvestigateTraceGetResponseInboundLinesItem>;
export type InvestigateTraceGetResponseInboundLinesList = Array<InvestigateTraceGetResponseInboundLinesItem>;
export declare const InvestigateTraceGetResponseInboundLinesList: S.Schema<InvestigateTraceGetResponseInboundLinesList>;
export interface InvestigateTraceGetResponseInbound {
    lines?: InvestigateTraceGetResponseInboundLinesList | null;
    pending?: boolean | null;
}
export declare const InvestigateTraceGetResponseInbound: S.Schema<InvestigateTraceGetResponseInbound>;
export type InvestigateTraceGetResponseOutboundLinesItem = InvestigateTraceGetResponseInboundLinesItem;
export declare const InvestigateTraceGetResponseOutboundLinesItem: S.Schema<InvestigateTraceGetResponseInboundLinesItem>;
export type InvestigateTraceGetResponseOutboundLinesList = Array<InvestigateTraceGetResponseInboundLinesItem>;
export declare const InvestigateTraceGetResponseOutboundLinesList: S.Schema<InvestigateTraceGetResponseOutboundLinesList>;
export interface InvestigateTraceGetResponseOutbound {
    lines?: InvestigateTraceGetResponseOutboundLinesList | null;
    pending?: boolean | null;
}
export declare const InvestigateTraceGetResponseOutbound: S.Schema<InvestigateTraceGetResponseOutbound>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInvestigateTraceResponse {
    inbound: InvestigateTraceGetResponseInbound;
    outbound: InvestigateTraceGetResponseOutbound;
}
export declare const GetInvestigateTraceResponse: S.Schema<GetInvestigateTraceResponse>;
export interface GetSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Allow policy identifier */
    policyId: string;
}
export declare const GetSettingAllowPolicyRequest: S.Schema<GetSettingAllowPolicyRequest>;
export type SettingsAllowPoliciesGetResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsAllowPoliciesGetResponsePatternType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingAllowPolicyResponse {
    /** Allow policy identifier */
    id: string;
    createdAt: string;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified: string;
    comments?: string | null;
    /** Messages from this sender will be exempted from Spam, Spoof and Bulk dispositions. Note - This will not exempt messages with Malicious or Suspicious dispositions. */
    isAcceptableSender?: boolean | null;
    /** Messages to this recipient will bypass all detections */
    isExemptRecipient?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_exempt_recipient` instead. End of life: July 1, 2026. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_trusted_sender` instead. End of life: July 1, 2026. */
    isSender?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_acceptable_sender` instead. End of life: July 1, 2026. */
    isSpoof?: boolean | null;
    /** Messages from this sender will bypass all detections and link following */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesGetResponsePatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export declare const GetSettingAllowPolicyResponse: S.Schema<GetSettingAllowPolicyResponse>;
export interface GetSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    /** Blocked sender pattern identifier */
    patternId: string;
}
export declare const GetSettingBlockSenderRequest: S.Schema<GetSettingBlockSenderRequest>;
export type SettingsBlockSendersGetResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsBlockSendersGetResponsePatternType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingBlockSenderResponse {
    /** Blocked sender pattern identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    isRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersGetResponsePatternType | null;
}
export declare const GetSettingBlockSenderResponse: S.Schema<GetSettingBlockSenderResponse>;
export interface GetSettingDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Domain identifier */
    domainId: string;
}
export declare const GetSettingDomainRequest: S.Schema<GetSettingDomainRequest>;
export type SettingsDomainsGetResponseAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export declare const SettingsDomainsGetResponseAllowedDeliveryModesItem: any;
export type SettingsDomainsGetResponseAllowedDeliveryModesList = Array<SettingsDomainsGetResponseAllowedDeliveryModesItem>;
export declare const SettingsDomainsGetResponseAllowedDeliveryModesList: S.Schema<SettingsDomainsGetResponseAllowedDeliveryModesList>;
export interface SettingsDomainsGetResponseAuthorization {
    authorized: boolean;
    timestamp: string;
    statusMessage?: string | null;
}
export declare const SettingsDomainsGetResponseAuthorization: S.Schema<SettingsDomainsGetResponseAuthorization>;
export type SettingsDomainsGetResponseDmarcStatus = "none" | "good" | "invalid";
export declare const SettingsDomainsGetResponseDmarcStatus: any;
export type SettingsDomainsGetResponseDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const SettingsDomainsGetResponseDropDispositionsItem: any;
export type SettingsDomainsGetResponseDropDispositionsList = Array<SettingsDomainsGetResponseDropDispositionsItem>;
export declare const SettingsDomainsGetResponseDropDispositionsList: S.Schema<SettingsDomainsGetResponseDropDispositionsList>;
export interface SettingsDomainsGetResponseEmailsProcessed {
    timestamp: string;
    totalEmailsProcessed: number;
    totalEmailsProcessedPrevious: number;
}
export declare const SettingsDomainsGetResponseEmailsProcessed: S.Schema<SettingsDomainsGetResponseEmailsProcessed>;
export type SettingsDomainsGetResponseFolder = "AllItems" | "Inbox";
export declare const SettingsDomainsGetResponseFolder: any;
export type SettingsDomainsGetResponseInboxProvider = "Microsoft" | "Google";
export declare const SettingsDomainsGetResponseInboxProvider: any;
export type SettingsDomainsGetResponseIpRestrictionsList = Array<string>;
export declare const SettingsDomainsGetResponseIpRestrictionsList: S.Schema<SettingsDomainsGetResponseIpRestrictionsList>;
export type SettingsDomainsGetResponseRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export declare const SettingsDomainsGetResponseRegionsItem: any;
export type SettingsDomainsGetResponseRegionsList = Array<SettingsDomainsGetResponseRegionsItem>;
export declare const SettingsDomainsGetResponseRegionsList: S.Schema<SettingsDomainsGetResponseRegionsList>;
export type SettingsDomainsGetResponseSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export declare const SettingsDomainsGetResponseSpfStatus: any;
export type SettingsDomainsGetResponseStatus = "pending" | "active" | "failed" | "timeout";
export declare const SettingsDomainsGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingDomainResponse {
    /** Domain identifier */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsGetResponseAllowedDeliveryModesList | null;
    authorization?: SettingsDomainsGetResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsGetResponseDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsGetResponseDropDispositionsList | null;
    emailsProcessed?: SettingsDomainsGetResponseEmailsProcessed | null;
    folder?: SettingsDomainsGetResponseFolder | null;
    inboxProvider?: SettingsDomainsGetResponseInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsGetResponseIpRestrictionsList | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsGetResponseRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsGetResponseSpfStatus | null;
    status?: SettingsDomainsGetResponseStatus | null;
    transport?: string | null;
}
export declare const GetSettingDomainResponse: S.Schema<GetSettingDomainResponse>;
export interface GetSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    /** Impersonation registry entry identifier */
    impersonationRegistryId: string;
}
export declare const GetSettingImpersonationRegistryRequest: S.Schema<GetSettingImpersonationRegistryRequest>;
export type SettingsImpersonationRegistryGetResponseProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export declare const SettingsImpersonationRegistryGetResponseProvenance: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    directoryId?: number | null;
    directoryNodeId?: number | null;
    email?: string | null;
    externalDirectoryNodeId?: string | null;
    isEmailRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    name?: string | null;
    provenance?: SettingsImpersonationRegistryGetResponseProvenance | null;
}
export declare const GetSettingImpersonationRegistryResponse: S.Schema<GetSettingImpersonationRegistryResponse>;
export interface GetSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Sending domain restriction identifier. */
    sendingDomainRestrictionId: string;
}
export declare const GetSettingSendingDomainRestrictionRequest: S.Schema<GetSettingSendingDomainRestrictionRequest>;
export type SettingsSendingDomainRestrictionsGetResponseExcludeList = Array<string>;
export declare const SettingsSendingDomainRestrictionsGetResponseExcludeList: S.Schema<SettingsSendingDomainRestrictionsGetResponseExcludeList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Excluded subdomains that are exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsGetResponseExcludeList | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const GetSettingSendingDomainRestrictionResponse: S.Schema<GetSettingSendingDomainRestrictionResponse>;
export interface GetSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Trusted domain identifier */
    trustedDomainId: string;
}
export declare const GetSettingTrustedDomainRequest: S.Schema<GetSettingTrustedDomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingTrustedDomainResponse {
    /** Trusted domain identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
}
export declare const GetSettingTrustedDomainResponse: S.Schema<GetSettingTrustedDomainResponse>;
export interface GetSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** URL ignore pattern identifier */
    patternId: string;
}
export declare const GetSettingUrlIgnorePatternRequest: S.Schema<GetSettingUrlIgnorePatternRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier */
    id: string;
    createdAt: string;
    /** Regular expression matching URLs that should not be rewritten. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const GetSettingUrlIgnorePatternResponse: S.Schema<GetSettingUrlIgnorePatternResponse>;
export type InvestigateBulkMessagesListRequestStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export declare const InvestigateBulkMessagesListRequestStatus: any;
export interface ListInvestigateBulkMessagesRequest {
    /** Identifier. */
    accountId: string;
    jobId: string;
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    status?: InvestigateBulkMessagesListRequestStatus | (string & {});
}
export declare const ListInvestigateBulkMessagesRequest: S.Schema<ListInvestigateBulkMessagesRequest>;
export type InvestigateBulkMessagesListResultItemActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateBulkMessagesListResultItemActionParamsMoveDestination: any;
export type InvestigateBulkMessagesListResultItemActionParamsMoveType = "MOVE";
export declare const InvestigateBulkMessagesListResultItemActionParamsMoveType: any;
export type InvestigateBulkMessagesListResultItemActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkMessagesListResultItemActionParamsMoveExpectedDisposition: any;
export interface InvestigateBulkMessagesListResultItemActionParamsMove {
    clientRecipient: string;
    destination: InvestigateBulkMessagesListResultItemActionParamsMoveDestination;
    type: InvestigateBulkMessagesListResultItemActionParamsMoveType;
    expectedDisposition?: InvestigateBulkMessagesListResultItemActionParamsMoveExpectedDisposition | null;
}
export declare const InvestigateBulkMessagesListResultItemActionParamsMove: S.Schema<InvestigateBulkMessagesListResultItemActionParamsMove>;
export type InvestigateBulkMessagesListResultItemActionParamsReleaseType = "RELEASE";
export declare const InvestigateBulkMessagesListResultItemActionParamsReleaseType: any;
export interface InvestigateBulkMessagesListResultItemActionParamsRelease {
    clientRecipient: string;
    type: InvestigateBulkMessagesListResultItemActionParamsReleaseType;
}
export declare const InvestigateBulkMessagesListResultItemActionParamsRelease: S.Schema<InvestigateBulkMessagesListResultItemActionParamsRelease>;
export type InvestigateBulkMessagesListResultItemActionParams = InvestigateBulkMessagesListResultItemActionParamsMove | InvestigateBulkMessagesListResultItemActionParamsRelease;
export declare const InvestigateBulkMessagesListResultItemActionParams: any;
export type InvestigateBulkMessagesListResultItemActionType = "MOVE" | "RELEASE";
export declare const InvestigateBulkMessagesListResultItemActionType: any;
export type InvestigateBulkMessagesListResultItemStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export declare const InvestigateBulkMessagesListResultItemStatus: any;
export interface InvestigateBulkMessagesListResultItem {
    actionParams: InvestigateBulkMessagesListResultItemActionParams;
    actionType: InvestigateBulkMessagesListResultItemActionType;
    createdAt: string;
    messageId: string;
    postfixId: string;
    retryCount: number;
    status: InvestigateBulkMessagesListResultItemStatus;
    alertId?: string | null;
    emailMessageId?: string | null;
    processedAt?: string | null;
    /** When to retry the action if it failed */
    retryAfter?: string | null;
    statusMessage?: string | null;
}
export declare const InvestigateBulkMessagesListResultItem: S.Schema<InvestigateBulkMessagesListResultItem>;
export type InvestigateBulkMessagesListResultList = Array<InvestigateBulkMessagesListResultItem>;
export declare const InvestigateBulkMessagesListResultList: S.Schema<InvestigateBulkMessagesListResultList>;
export interface ListInvestigateBulkMessagesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateBulkMessagesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInvestigateBulkMessagesResponse: S.Schema<ListInvestigateBulkMessagesResponse>;
export type InvestigateBulkListRequestActionType = "MOVE" | "RELEASE";
export declare const InvestigateBulkListRequestActionType: any;
export type InvestigateBulkListRequestStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export declare const InvestigateBulkListRequestStatus: any;
export interface ListInvestigateBulksRequest {
    /** Identifier. */
    accountId: string;
    actionType?: InvestigateBulkListRequestActionType | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    status?: InvestigateBulkListRequestStatus | (string & {});
}
export declare const ListInvestigateBulksRequest: S.Schema<ListInvestigateBulksRequest>;
export type InvestigateBulkListResultItemActionParamsMoveDestination = "Inbox" | "JunkEmail" | "DeletedItems" | "RecoverableItemsDeletions" | "RecoverableItemsPurges";
export declare const InvestigateBulkListResultItemActionParamsMoveDestination: any;
export type InvestigateBulkListResultItemActionParamsMoveType = "MOVE";
export declare const InvestigateBulkListResultItemActionParamsMoveType: any;
export type InvestigateBulkListResultItemActionParamsMoveExpectedDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkListResultItemActionParamsMoveExpectedDisposition: any;
export interface InvestigateBulkListResultItemActionParamsMove {
    destination: InvestigateBulkListResultItemActionParamsMoveDestination;
    type: InvestigateBulkListResultItemActionParamsMoveType;
    expectedDisposition?: InvestigateBulkListResultItemActionParamsMoveExpectedDisposition | null;
}
export declare const InvestigateBulkListResultItemActionParamsMove: S.Schema<InvestigateBulkListResultItemActionParamsMove>;
export type InvestigateBulkListResultItemActionParamsReleaseType = "RELEASE";
export declare const InvestigateBulkListResultItemActionParamsReleaseType: any;
export interface InvestigateBulkListResultItemActionParamsRelease {
    type: InvestigateBulkListResultItemActionParamsReleaseType;
}
export declare const InvestigateBulkListResultItemActionParamsRelease: S.Schema<InvestigateBulkListResultItemActionParamsRelease>;
export type InvestigateBulkListResultItemActionParams = InvestigateBulkListResultItemActionParamsMove | InvestigateBulkListResultItemActionParamsRelease;
export declare const InvestigateBulkListResultItemActionParams: any;
export type InvestigateBulkListResultItemActionType = "MOVE" | "RELEASE";
export declare const InvestigateBulkListResultItemActionType: any;
export type InvestigateBulkListResultItemSearchParamsDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateBulkListResultItemSearchParamsDeliveryStatus: any;
export type InvestigateBulkListResultItemSearchParamsFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateBulkListResultItemSearchParamsFinalDisposition: any;
export type InvestigateBulkListResultItemSearchParamsMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export declare const InvestigateBulkListResultItemSearchParamsMessageAction: any;
export interface InvestigateBulkListResultItemSearchParams {
    /** Deprecated, use `GET /investigate/{investigate_id}/action_log` instead. End of life: November 1, 2026. */
    actionLog?: boolean | null;
    alertId?: string | null;
    /** Delivery status of the message. */
    deliveryStatus?: InvestigateBulkListResultItemSearchParamsDeliveryStatus | null;
    detectionsOnly?: boolean | null;
    domain?: string | null;
    /** End of search date range */
    end?: string | null;
    exactSubject?: string | null;
    finalDisposition?: InvestigateBulkListResultItemSearchParamsFinalDisposition | null;
    messageAction?: InvestigateBulkListResultItemSearchParamsMessageAction | null;
    messageId?: string | null;
    metric?: string | null;
    query?: string | null;
    recipient?: string | null;
    sender?: string | null;
    /** Beginning of search date range */
    start?: string | null;
    subject?: string | null;
    submissions?: boolean | null;
}
export declare const InvestigateBulkListResultItemSearchParams: S.Schema<InvestigateBulkListResultItemSearchParams>;
export type InvestigateBulkListResultItemStatus = "PENDING" | "DISCOVERING" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED" | "SKIPPED";
export declare const InvestigateBulkListResultItemStatus: any;
export interface InvestigateBulkListResultItem {
    actionParams: InvestigateBulkListResultItemActionParams;
    actionType: InvestigateBulkListResultItemActionType;
    createdAt: string;
    jobId: string;
    messagesFailed: number;
    messagesPending: number;
    messagesSuccessful: number;
    searchParams: InvestigateBulkListResultItemSearchParams;
    status: InvestigateBulkListResultItemStatus;
    totalMessagesDiscovered: number;
    comment?: string | null;
    completedAt?: string | null;
    startedAt?: string | null;
    statusMessage?: string | null;
}
export declare const InvestigateBulkListResultItem: S.Schema<InvestigateBulkListResultItem>;
export type InvestigateBulkListResultList = Array<InvestigateBulkListResultItem>;
export declare const InvestigateBulkListResultList: S.Schema<InvestigateBulkListResultList>;
export interface ListInvestigateBulksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateBulkListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInvestigateBulksResponse: S.Schema<ListInvestigateBulksResponse>;
export type InvestigateListRequestDeliveryStatus = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateListRequestDeliveryStatus: any;
export type InvestigateListRequestFinalDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const InvestigateListRequestFinalDisposition: any;
export type InvestigateListRequestMessageAction = "PREVIEW" | "QUARANTINE_RELEASED" | "MOVED";
export declare const InvestigateListRequestMessageAction: any;
export interface ListInvestigatesRequest {
    /** Identifier. */
    accountId: string;
    alertId?: string;
    cursor?: string;
    /** Delivery status to filter by. */
    deliveryStatus?: InvestigateListRequestDeliveryStatus | (string & {});
    /** Whether to include only detections in search results. */
    detectionsOnly?: boolean;
    /** Sender domains to filter by. */
    domain?: string;
    /** The end of the search date range. Defaults to `now`. */
    end?: string;
    /** Dispositions to filter by. */
    finalDisposition?: InvestigateListRequestFinalDisposition | (string & {});
    /** Message actions to filter by. */
    messageAction?: InvestigateListRequestMessageAction | (string & {});
    messageId?: string;
    metric?: string;
    /** Deprecated: Use cursor pagination instead. End of life: November 1, 2026. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Space-delimited search term. Case-insensitive. */
    query?: string;
    recipient?: string;
    sender?: string;
    /** The beginning of the search date range. Defaults to `now - 30 days`. */
    start?: string;
    subject?: string;
}
export declare const ListInvestigatesRequest: S.Schema<ListInvestigatesRequest>;
export type InvestigateListResultItemActionLogItemOperation = "MOVE" | "RELEASE" | "RECLASSIFY" | "SUBMISSION" | "QUARANTINE_RELEASE" | "PREVIEW";
export declare const InvestigateListResultItemActionLogItemOperation: any;
export type InvestigateListResultItemActionLogItemProperties = InvestigateGetResponseActionLogItemProperties;
export declare const InvestigateListResultItemActionLogItemProperties: S.Schema<InvestigateGetResponseActionLogItemProperties>;
export interface InvestigateListResultItemActionLogItem {
    /** Timestamp when action completed */
    completedAt: string;
    /** Type of action performed */
    operation: InvestigateListResultItemActionLogItemOperation;
    /** Deprecated, use `completed_at` instead. End of life: November 1, 2026. */
    completedTimestamp?: string | null;
    /** Additional properties for the action */
    properties?: InvestigateGetResponseActionLogItemProperties | null;
    /** Status of the action */
    status?: string | null;
}
export declare const InvestigateListResultItemActionLogItem: S.Schema<InvestigateListResultItemActionLogItem>;
export type InvestigateListResultItemActionLogList = Array<InvestigateListResultItemActionLogItem>;
export declare const InvestigateListResultItemActionLogList: S.Schema<InvestigateListResultItemActionLogList>;
export type InvestigateListResultItemClientRecipientsList = Array<string>;
export declare const InvestigateListResultItemClientRecipientsList: S.Schema<InvestigateListResultItemClientRecipientsList>;
export type InvestigateListResultItemDetectionReasonsList = Array<string>;
export declare const InvestigateListResultItemDetectionReasonsList: S.Schema<InvestigateListResultItemDetectionReasonsList>;
export type InvestigateListResultItemPropertiesAllowlistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export declare const InvestigateListResultItemPropertiesAllowlistedPatternType: any;
export type InvestigateListResultItemPropertiesWhitelistedPatternType = "quarantine_release" | "acceptable_sender" | "allowed_sender" | "allowed_recipient" | "domain_similarity" | "domain_recency" | "managed_acceptable_sender" | "outbound_ndr";
export declare const InvestigateListResultItemPropertiesWhitelistedPatternType: any;
export interface InvestigateListResultItemProperties {
    /** Pattern that allowlisted this message */
    allowlistedPattern?: string | null;
    /** Type of allowlist pattern */
    allowlistedPatternType?: InvestigateListResultItemPropertiesAllowlistedPatternType | null;
    /** Whether message was blocklisted */
    blocklistedMessage?: boolean | null;
    /** Pattern that blocklisted this message */
    blocklistedPattern?: string | null;
    /** Legacy field for allowlist pattern type */
    whitelistedPatternType?: InvestigateListResultItemPropertiesWhitelistedPatternType | null;
}
export declare const InvestigateListResultItemProperties: S.Schema<InvestigateListResultItemProperties>;
export type InvestigateListResultItemDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "REVIEW_SUBMISSION" | "DMARC_UNVERIFIED" | "DMARC_FAILURE_REPORT" | "DMARC_AGGREGATE_REPORT" | "THREAT_INTEL_SUBMISSION" | "SIMULATION_SUBMISSION" | "API" | "RETRO_SCAN";
export declare const InvestigateListResultItemDeliveryMode: any;
export type InvestigateListResultItemDeliveryStatusItem = "delivered" | "moved" | "quarantined" | "rejected" | "deferred" | "bounced" | "queued";
export declare const InvestigateListResultItemDeliveryStatusItem: any;
export type InvestigateListResultItemDeliveryStatusList = Array<InvestigateListResultItemDeliveryStatusItem>;
export declare const InvestigateListResultItemDeliveryStatusList: S.Schema<InvestigateListResultItemDeliveryStatusList>;
export type InvestigateListResultItemEnvelopeToList = Array<string>;
export declare const InvestigateListResultItemEnvelopeToList: S.Schema<InvestigateListResultItemEnvelopeToList>;
export type InvestigateListResultItemFinalDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateListResultItemFinalDisposition: any;
export type InvestigateListResultItemFindingsItemDetection = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const InvestigateListResultItemFindingsItemDetection: any;
export interface InvestigateListResultItemFindingsItem {
    attachment?: string | null;
    detail?: string | null;
    detection?: InvestigateListResultItemFindingsItemDetection | null;
    field?: string | null;
    name?: string | null;
    portion?: string | null;
    reason?: string | null;
    score?: number | null;
    value?: string | null;
}
export declare const InvestigateListResultItemFindingsItem: S.Schema<InvestigateListResultItemFindingsItem>;
export type InvestigateListResultItemFindingsList = Array<InvestigateListResultItemFindingsItem>;
export declare const InvestigateListResultItemFindingsList: S.Schema<InvestigateListResultItemFindingsList>;
export type InvestigateListResultItemPostDeliveryOperationsItem = "PREVIEW" | "QUARANTINE_RELEASE" | "SUBMISSION" | "MOVE";
export declare const InvestigateListResultItemPostDeliveryOperationsItem: any;
export type InvestigateListResultItemPostDeliveryOperationsList = Array<InvestigateListResultItemPostDeliveryOperationsItem>;
export declare const InvestigateListResultItemPostDeliveryOperationsList: S.Schema<InvestigateListResultItemPostDeliveryOperationsList>;
export type InvestigateListResultItemThreatCategoriesList = Array<string>;
export declare const InvestigateListResultItemThreatCategoriesList: S.Schema<InvestigateListResultItemThreatCategoriesList>;
export type InvestigateListResultItemToList = Array<string>;
export declare const InvestigateListResultItemToList: S.Schema<InvestigateListResultItemToList>;
export type InvestigateListResultItemToNameList = Array<string>;
export declare const InvestigateListResultItemToNameList: S.Schema<InvestigateListResultItemToNameList>;
export type InvestigateListResultItemValidationDkim = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateListResultItemValidationDkim: any;
export type InvestigateListResultItemValidationDmarc = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateListResultItemValidationDmarc: any;
export type InvestigateListResultItemValidationSpf = "pass" | "neutral" | "fail" | "error" | "none";
export declare const InvestigateListResultItemValidationSpf: any;
export interface InvestigateListResultItemValidation {
    comment?: string | null;
    dkim?: InvestigateListResultItemValidationDkim | null;
    dmarc?: InvestigateListResultItemValidationDmarc | null;
    spf?: InvestigateListResultItemValidationSpf | null;
}
export declare const InvestigateListResultItemValidation: S.Schema<InvestigateListResultItemValidation>;
export interface InvestigateListResultItem {
    /** Unique identifier for a message retrieved from investigation */
    id: string;
    /** Deprecated, use `GET /investigate/{investigate_id}/action_log` instead. End of life: November 1, 2026. */
    actionLog: InvestigateListResultItemActionLogList;
    clientRecipients: InvestigateListResultItemClientRecipientsList;
    detectionReasons: InvestigateListResultItemDetectionReasonsList;
    isPhishSubmission: boolean;
    isQuarantined: boolean;
    /** The identifier of the message */
    postfixId: string;
    /** Message processing properties */
    properties: InvestigateListResultItemProperties;
    /** Deprecated, use `scanned_at` instead. End of life: November 1, 2026. */
    ts: string;
    alertId?: string | null;
    deliveryMode?: InvestigateListResultItemDeliveryMode | null;
    deliveryStatus?: InvestigateListResultItemDeliveryStatusList | null;
    edfHash?: string | null;
    envelopeFrom?: string | null;
    envelopeTo?: InvestigateListResultItemEnvelopeToList | null;
    finalDisposition?: InvestigateListResultItemFinalDisposition | null;
    /** Deprecated, use the `findings` field from `GET /investigate/{investigate_id}/detections` instead. End of life: November 1, 2026. Detection findings for this message. */
    findings?: InvestigateListResultItemFindingsList | null;
    from?: string | null;
    fromName?: string | null;
    htmltextStructureHash?: string | null;
    messageId?: string | null;
    /** Post-delivery operations performed on this message */
    postDeliveryOperations?: InvestigateListResultItemPostDeliveryOperationsList | null;
    postfixIdOutbound?: string | null;
    replyto?: string | null;
    /** When the message was scanned (UTC) */
    scannedAt?: string | null;
    /** When the message was sent (UTC) */
    sentAt?: string | null;
    sentDate?: string | null;
    smtpHeloServerIp?: string | null;
    smtpPreviousHopIp?: string | null;
    subject?: string | null;
    threatCategories?: InvestigateListResultItemThreatCategoriesList | null;
    to?: InvestigateListResultItemToList | null;
    toName?: InvestigateListResultItemToNameList | null;
    validation?: InvestigateListResultItemValidation | null;
    xOriginatingIp?: string | null;
}
export declare const InvestigateListResultItem: S.Schema<InvestigateListResultItem>;
export type InvestigateListResultList = Array<InvestigateListResultItem>;
export declare const InvestigateListResultList: S.Schema<InvestigateListResultList>;
export interface ListInvestigatesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InvestigateListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInvestigatesResponse: S.Schema<ListInvestigatesResponse>;
export interface ListPhishguardReportsRequest {
    /** Identifier. */
    accountId: string;
    /** End of the time range (RFC3339). Takes precedence over to_date. */
    end?: string;
    /** Deprecated, use `start` instead. Start date in YYYY-MM-DD format. */
    fromDate?: string;
    /** Start of the time range (RFC3339). Takes precedence over from_date. */
    start?: string;
    /** Deprecated, use `end` instead. End date in YYYY-MM-DD format. */
    toDate?: string;
}
export declare const ListPhishguardReportsRequest: S.Schema<ListPhishguardReportsRequest>;
export type PhishguardReportsListResultItemDisposition = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const PhishguardReportsListResultItemDisposition: any;
export type PhishguardReportsListResultItemFieldsToList = Array<string>;
export declare const PhishguardReportsListResultItemFieldsToList: S.Schema<PhishguardReportsListResultItemFieldsToList>;
export interface PhishguardReportsListResultItemFields {
    to: PhishguardReportsListResultItemFieldsToList;
    from?: string | null;
    occurredAt?: string | null;
    postfixId?: string | null;
    /** Deprecated, use `occurred_at` instead */
    ts?: string | null;
}
export declare const PhishguardReportsListResultItemFields: S.Schema<PhishguardReportsListResultItemFields>;
export interface PhishguardReportsListResultItemTagsItem {
    category: string;
    value: string;
}
export declare const PhishguardReportsListResultItemTagsItem: S.Schema<PhishguardReportsListResultItemTagsItem>;
export type PhishguardReportsListResultItemTagsList = Array<PhishguardReportsListResultItemTagsItem>;
export declare const PhishguardReportsListResultItemTagsList: S.Schema<PhishguardReportsListResultItemTagsList>;
export interface PhishguardReportsListResultItem {
    id: number;
    content: string;
    disposition: PhishguardReportsListResultItemDisposition;
    fields: PhishguardReportsListResultItemFields;
    priority: string;
    title: string;
    createdAt?: string | null;
    tags?: PhishguardReportsListResultItemTagsList | null;
    /** Deprecated, use `created_at` instead */
    ts?: string | null;
    updatedAt?: string | null;
}
export declare const PhishguardReportsListResultItem: S.Schema<PhishguardReportsListResultItem>;
export type PhishguardReportsListResultList = Array<PhishguardReportsListResultItem>;
export declare const PhishguardReportsListResultList: S.Schema<PhishguardReportsListResultList>;
export interface ListPhishguardReportsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PhishguardReportsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPhishguardReportsResponse: S.Schema<ListPhishguardReportsResponse>;
export type SettingsAllowPoliciesListRequestDirection = "asc" | "desc";
export declare const SettingsAllowPoliciesListRequestDirection: any;
export type SettingsAllowPoliciesListRequestOrder = "pattern" | "created_at";
export declare const SettingsAllowPoliciesListRequestOrder: any;
export type SettingsAllowPoliciesListRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsAllowPoliciesListRequestPatternType: any;
export interface ListSettingAllowPoliciesRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsAllowPoliciesListRequestDirection | (string & {});
    /** Filter to show only policies where messages from the sender are exempted from Spam, Spoof, and Bulk dispositions (not Malicious or Suspicious). */
    isAcceptableSender?: boolean;
    /** Filter to show only policies where messages to the recipient bypass all detections. */
    isExemptRecipient?: boolean;
    /** Filter to show only policies where messages from the sender bypass all detections and link following. */
    isTrustedSender?: boolean;
    /** Field to sort by. */
    order?: SettingsAllowPoliciesListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesListRequestPatternType | (string & {});
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
    /** Filter to show only policies that enforce DMARC, SPF, or DKIM authentication. */
    verifySender?: boolean;
}
export declare const ListSettingAllowPoliciesRequest: S.Schema<ListSettingAllowPoliciesRequest>;
export type SettingsAllowPoliciesListResultItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsAllowPoliciesListResultItemPatternType: any;
export interface SettingsAllowPoliciesListResultItem {
    /** Allow policy identifier */
    id: string;
    createdAt: string;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified: string;
    comments?: string | null;
    /** Messages from this sender will be exempted from Spam, Spoof and Bulk dispositions. Note - This will not exempt messages with Malicious or Suspicious dispositions. */
    isAcceptableSender?: boolean | null;
    /** Messages to this recipient will bypass all detections */
    isExemptRecipient?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_exempt_recipient` instead. End of life: July 1, 2026. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_trusted_sender` instead. End of life: July 1, 2026. */
    isSender?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_acceptable_sender` instead. End of life: July 1, 2026. */
    isSpoof?: boolean | null;
    /** Messages from this sender will bypass all detections and link following */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesListResultItemPatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export declare const SettingsAllowPoliciesListResultItem: S.Schema<SettingsAllowPoliciesListResultItem>;
export type SettingsAllowPoliciesListResultList = Array<SettingsAllowPoliciesListResultItem>;
export declare const SettingsAllowPoliciesListResultList: S.Schema<SettingsAllowPoliciesListResultList>;
export interface ListSettingAllowPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsAllowPoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingAllowPoliciesResponse: S.Schema<ListSettingAllowPoliciesResponse>;
export type SettingsBlockSendersListRequestDirection = "asc" | "desc";
export declare const SettingsBlockSendersListRequestDirection: any;
export type SettingsBlockSendersListRequestOrder = "pattern" | "created_at";
export declare const SettingsBlockSendersListRequestOrder: any;
export type SettingsBlockSendersListRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsBlockSendersListRequestPatternType: any;
export interface ListSettingBlockSendersRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsBlockSendersListRequestDirection | (string & {});
    /** Field to sort by. */
    order?: SettingsBlockSendersListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** Filter by pattern value. */
    pattern?: string;
    /** Filter by pattern type. */
    patternType?: SettingsBlockSendersListRequestPatternType | (string & {});
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export declare const ListSettingBlockSendersRequest: S.Schema<ListSettingBlockSendersRequest>;
export type SettingsBlockSendersListResultItemPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsBlockSendersListResultItemPatternType: any;
export interface SettingsBlockSendersListResultItem {
    /** Blocked sender pattern identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    isRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersListResultItemPatternType | null;
}
export declare const SettingsBlockSendersListResultItem: S.Schema<SettingsBlockSendersListResultItem>;
export type SettingsBlockSendersListResultList = Array<SettingsBlockSendersListResultItem>;
export declare const SettingsBlockSendersListResultList: S.Schema<SettingsBlockSendersListResultList>;
export interface ListSettingBlockSendersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsBlockSendersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingBlockSendersResponse: S.Schema<ListSettingBlockSendersResponse>;
export type SettingsDomainsListRequestActiveDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export declare const SettingsDomainsListRequestActiveDeliveryMode: any;
export type SettingsDomainsListRequestAllowedDeliveryMode = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export declare const SettingsDomainsListRequestAllowedDeliveryMode: any;
export type SettingsDomainsListRequestDirection = "asc" | "desc";
export declare const SettingsDomainsListRequestDirection: any;
export type SettingsDomainsListRequestDomainList = Array<string>;
export declare const SettingsDomainsListRequestDomainList: S.Schema<SettingsDomainsListRequestDomainList>;
export type SettingsDomainsListRequestOrder = "domain" | "created_at";
export declare const SettingsDomainsListRequestOrder: any;
export type SettingsDomainsListRequestStatus = "pending" | "active" | "failed" | "timeout";
export declare const SettingsDomainsListRequestStatus: any;
export interface ListSettingDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** Currently active delivery mode to filter by. */
    activeDeliveryMode?: SettingsDomainsListRequestActiveDeliveryMode | (string & {});
    /** Delivery mode to filter by. */
    allowedDeliveryMode?: SettingsDomainsListRequestAllowedDeliveryMode | (string & {});
    /** The sorting direction. */
    direction?: SettingsDomainsListRequestDirection | (string & {});
    /** Domain names to filter by. */
    domain?: SettingsDomainsListRequestDomainList;
    /** Integration ID to filter by. */
    integrationId?: string;
    /** Field to sort by. */
    order?: SettingsDomainsListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
    /** Filters response to domains with the provided status. */
    status?: SettingsDomainsListRequestStatus | (string & {});
}
export declare const ListSettingDomainsRequest: S.Schema<ListSettingDomainsRequest>;
export type SettingsDomainsListResultItemAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export declare const SettingsDomainsListResultItemAllowedDeliveryModesItem: any;
export type SettingsDomainsListResultItemAllowedDeliveryModesList = Array<SettingsDomainsListResultItemAllowedDeliveryModesItem>;
export declare const SettingsDomainsListResultItemAllowedDeliveryModesList: S.Schema<SettingsDomainsListResultItemAllowedDeliveryModesList>;
export type SettingsDomainsListResultItemAuthorization = SettingsDomainsGetResponseAuthorization;
export declare const SettingsDomainsListResultItemAuthorization: S.Schema<SettingsDomainsGetResponseAuthorization>;
export type SettingsDomainsListResultItemDmarcStatus = "none" | "good" | "invalid";
export declare const SettingsDomainsListResultItemDmarcStatus: any;
export type SettingsDomainsListResultItemDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const SettingsDomainsListResultItemDropDispositionsItem: any;
export type SettingsDomainsListResultItemDropDispositionsList = Array<SettingsDomainsListResultItemDropDispositionsItem>;
export declare const SettingsDomainsListResultItemDropDispositionsList: S.Schema<SettingsDomainsListResultItemDropDispositionsList>;
export type SettingsDomainsListResultItemEmailsProcessed = SettingsDomainsGetResponseEmailsProcessed;
export declare const SettingsDomainsListResultItemEmailsProcessed: S.Schema<SettingsDomainsGetResponseEmailsProcessed>;
export type SettingsDomainsListResultItemFolder = "AllItems" | "Inbox";
export declare const SettingsDomainsListResultItemFolder: any;
export type SettingsDomainsListResultItemInboxProvider = "Microsoft" | "Google";
export declare const SettingsDomainsListResultItemInboxProvider: any;
export type SettingsDomainsListResultItemIpRestrictionsList = Array<string>;
export declare const SettingsDomainsListResultItemIpRestrictionsList: S.Schema<SettingsDomainsListResultItemIpRestrictionsList>;
export type SettingsDomainsListResultItemRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export declare const SettingsDomainsListResultItemRegionsItem: any;
export type SettingsDomainsListResultItemRegionsList = Array<SettingsDomainsListResultItemRegionsItem>;
export declare const SettingsDomainsListResultItemRegionsList: S.Schema<SettingsDomainsListResultItemRegionsList>;
export type SettingsDomainsListResultItemSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export declare const SettingsDomainsListResultItemSpfStatus: any;
export type SettingsDomainsListResultItemStatus = "pending" | "active" | "failed" | "timeout";
export declare const SettingsDomainsListResultItemStatus: any;
export interface SettingsDomainsListResultItem {
    /** Domain identifier */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsListResultItemAllowedDeliveryModesList | null;
    authorization?: SettingsDomainsGetResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsListResultItemDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsListResultItemDropDispositionsList | null;
    emailsProcessed?: SettingsDomainsGetResponseEmailsProcessed | null;
    folder?: SettingsDomainsListResultItemFolder | null;
    inboxProvider?: SettingsDomainsListResultItemInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsListResultItemIpRestrictionsList | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsListResultItemRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsListResultItemSpfStatus | null;
    status?: SettingsDomainsListResultItemStatus | null;
    transport?: string | null;
}
export declare const SettingsDomainsListResultItem: S.Schema<SettingsDomainsListResultItem>;
export type SettingsDomainsListResultList = Array<SettingsDomainsListResultItem>;
export declare const SettingsDomainsListResultList: S.Schema<SettingsDomainsListResultList>;
export interface ListSettingDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsDomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingDomainsResponse: S.Schema<ListSettingDomainsResponse>;
export type SettingsImpersonationRegistryListRequestDirection = "asc" | "desc";
export declare const SettingsImpersonationRegistryListRequestDirection: any;
export type SettingsImpersonationRegistryListRequestOrder = "name" | "email" | "created_at";
export declare const SettingsImpersonationRegistryListRequestOrder: any;
export type SettingsImpersonationRegistryListRequestProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export declare const SettingsImpersonationRegistryListRequestProvenance: any;
export interface ListSettingImpersonationRegistriesRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsImpersonationRegistryListRequestDirection | (string & {});
    /** Field to sort by. */
    order?: SettingsImpersonationRegistryListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    provenance?: SettingsImpersonationRegistryListRequestProvenance | (string & {});
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export declare const ListSettingImpersonationRegistriesRequest: S.Schema<ListSettingImpersonationRegistriesRequest>;
export type SettingsImpersonationRegistryListResultItemProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export declare const SettingsImpersonationRegistryListResultItemProvenance: any;
export interface SettingsImpersonationRegistryListResultItem {
    /** Impersonation registry entry identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    directoryId?: number | null;
    directoryNodeId?: number | null;
    email?: string | null;
    externalDirectoryNodeId?: string | null;
    isEmailRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    name?: string | null;
    provenance?: SettingsImpersonationRegistryListResultItemProvenance | null;
}
export declare const SettingsImpersonationRegistryListResultItem: S.Schema<SettingsImpersonationRegistryListResultItem>;
export type SettingsImpersonationRegistryListResultList = Array<SettingsImpersonationRegistryListResultItem>;
export declare const SettingsImpersonationRegistryListResultList: S.Schema<SettingsImpersonationRegistryListResultList>;
export interface ListSettingImpersonationRegistriesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsImpersonationRegistryListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingImpersonationRegistriesResponse: S.Schema<ListSettingImpersonationRegistriesResponse>;
export type SettingsSendingDomainRestrictionsListRequestDirection = "asc" | "desc";
export declare const SettingsSendingDomainRestrictionsListRequestDirection: any;
export type SettingsSendingDomainRestrictionsListRequestOrder = "domain" | "created_at";
export declare const SettingsSendingDomainRestrictionsListRequestOrder: any;
export interface ListSettingSendingDomainRestrictionsRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsSendingDomainRestrictionsListRequestDirection | (string & {});
    /** Field to sort by. */
    order?: SettingsSendingDomainRestrictionsListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export declare const ListSettingSendingDomainRestrictionsRequest: S.Schema<ListSettingSendingDomainRestrictionsRequest>;
export type SettingsSendingDomainRestrictionsListResultItemExcludeList = Array<string>;
export declare const SettingsSendingDomainRestrictionsListResultItemExcludeList: S.Schema<SettingsSendingDomainRestrictionsListResultItemExcludeList>;
export interface SettingsSendingDomainRestrictionsListResultItem {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Excluded subdomains that are exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsListResultItemExcludeList | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const SettingsSendingDomainRestrictionsListResultItem: S.Schema<SettingsSendingDomainRestrictionsListResultItem>;
export type SettingsSendingDomainRestrictionsListResultList = Array<SettingsSendingDomainRestrictionsListResultItem>;
export declare const SettingsSendingDomainRestrictionsListResultList: S.Schema<SettingsSendingDomainRestrictionsListResultList>;
export interface ListSettingSendingDomainRestrictionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsSendingDomainRestrictionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingSendingDomainRestrictionsResponse: S.Schema<ListSettingSendingDomainRestrictionsResponse>;
export type SettingsTrustedDomainsListRequestDirection = "asc" | "desc";
export declare const SettingsTrustedDomainsListRequestDirection: any;
export type SettingsTrustedDomainsListRequestOrder = "pattern" | "created_at";
export declare const SettingsTrustedDomainsListRequestOrder: any;
export interface ListSettingTrustedDomainsRequest {
    /** Identifier. */
    accountId: string;
    /** The sorting direction. */
    direction?: SettingsTrustedDomainsListRequestDirection | (string & {});
    /** Filter to show only recently registered domains that are trusted to prevent triggering Suspicious or Malicious dispositions. */
    isRecent?: boolean;
    /** Filter to show only proximity domains (partner or approved domains with similar spelling to connected domains) that prevent Spoof dispositions. */
    isSimilarity?: boolean;
    /** Field to sort by. */
    order?: SettingsTrustedDomainsListRequestOrder | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    pattern?: string;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    /** Search term for filtering records. Behavior may change. */
    search?: string;
}
export declare const ListSettingTrustedDomainsRequest: S.Schema<ListSettingTrustedDomainsRequest>;
export interface SettingsTrustedDomainsListResultItem {
    /** Trusted domain identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
}
export declare const SettingsTrustedDomainsListResultItem: S.Schema<SettingsTrustedDomainsListResultItem>;
export type SettingsTrustedDomainsListResultList = Array<SettingsTrustedDomainsListResultItem>;
export declare const SettingsTrustedDomainsListResultList: S.Schema<SettingsTrustedDomainsListResultList>;
export interface ListSettingTrustedDomainsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsTrustedDomainsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingTrustedDomainsResponse: S.Schema<ListSettingTrustedDomainsResponse>;
export interface ListSettingUrlIgnorePatternsRequest {
    /** Identifier. */
    accountId: string;
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
}
export declare const ListSettingUrlIgnorePatternsRequest: S.Schema<ListSettingUrlIgnorePatternsRequest>;
export interface SettingsUrlIgnorePatternsListResultItem {
    /** URL ignore pattern identifier */
    id: string;
    createdAt: string;
    /** Regular expression matching URLs that should not be rewritten. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const SettingsUrlIgnorePatternsListResultItem: S.Schema<SettingsUrlIgnorePatternsListResultItem>;
export type SettingsUrlIgnorePatternsListResultList = Array<SettingsUrlIgnorePatternsListResultItem>;
export declare const SettingsUrlIgnorePatternsListResultList: S.Schema<SettingsUrlIgnorePatternsListResultList>;
export interface ListSettingUrlIgnorePatternsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SettingsUrlIgnorePatternsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSettingUrlIgnorePatternsResponse: S.Schema<ListSettingUrlIgnorePatternsResponse>;
export type SubmissionsListRequestOriginalDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const SubmissionsListRequestOriginalDisposition: any;
export type SubmissionsListRequestOutcomeDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const SubmissionsListRequestOutcomeDisposition: any;
export type SubmissionsListRequestRequestedDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const SubmissionsListRequestRequestedDisposition: any;
export type SubmissionsListRequestType = "TEAM" | "USER";
export declare const SubmissionsListRequestType: any;
export interface ListSubmissionsRequest {
    /** Identifier. */
    accountId: string;
    /** The end of the search date range. Defaults to `now`. */
    end?: string;
    /** When true, return only submissions that were escalated by an end user (vs. by the security team). When false, return only submissions that were not escalated by an end user. When omitted, no filter is applied. */
    escalatedFromUser?: boolean;
    originalDisposition?: SubmissionsListRequestOriginalDisposition | (string & {});
    outcomeDisposition?: SubmissionsListRequestOutcomeDisposition | (string & {});
    /** Current page within paginated list of results. */
    page?: number;
    /** The number of results per page. Maximum value is 1000. */
    perPage?: number;
    query?: string;
    requestedDisposition?: SubmissionsListRequestRequestedDisposition | (string & {});
    /** The beginning of the search date range. Defaults to `now - 30 days`. */
    start?: string;
    status?: string;
    submissionId?: string;
    type?: SubmissionsListRequestType | (string & {});
}
export declare const ListSubmissionsRequest: S.Schema<ListSubmissionsRequest>;
export type SubmissionsListResultItemCustomerStatus = "escalated" | "reviewed" | "unreviewed";
export declare const SubmissionsListResultItemCustomerStatus: any;
export type SubmissionsListResultItemEscalatedAs = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const SubmissionsListResultItemEscalatedAs: any;
export type SubmissionsListResultItemOriginalDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const SubmissionsListResultItemOriginalDisposition: any;
export type SubmissionsListResultItemOutcomeDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const SubmissionsListResultItemOutcomeDisposition: any;
export type SubmissionsListResultItemRequestedDisposition = "MALICIOUS" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "NONE";
export declare const SubmissionsListResultItemRequestedDisposition: any;
export type SubmissionsListResultItemType = "Team" | "User";
export declare const SubmissionsListResultItemType: any;
export interface SubmissionsListResultItem {
    /** When the submission was requested (UTC). */
    requestedAt: string;
    submissionId: string;
    customerStatus?: SubmissionsListResultItemCustomerStatus | null;
    escalatedAs?: SubmissionsListResultItemEscalatedAs | null;
    escalatedAt?: string | null;
    escalatedBy?: string | null;
    escalatedSubmissionId?: string | null;
    originalDisposition?: SubmissionsListResultItemOriginalDisposition | null;
    originalEdfHash?: string | null;
    /** The postfix ID of the original message that was submitted */
    originalPostfixId?: string | null;
    outcome?: string | null;
    outcomeDisposition?: SubmissionsListResultItemOutcomeDisposition | null;
    requestedBy?: string | null;
    requestedDisposition?: SubmissionsListResultItemRequestedDisposition | null;
    /** Deprecated, use `requested_at` instead */
    requestedTs?: string | null;
    status?: string | null;
    subject?: string | null;
    /** Whether the submission was created by a team member or an end user. */
    type?: SubmissionsListResultItemType | null;
}
export declare const SubmissionsListResultItem: S.Schema<SubmissionsListResultItem>;
export type SubmissionsListResultList = Array<SubmissionsListResultItem>;
export declare const SubmissionsListResultList: S.Schema<SubmissionsListResultList>;
export interface ListSubmissionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubmissionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSubmissionsResponse: S.Schema<ListSubmissionsResponse>;
export type SettingsAllowPoliciesEditRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsAllowPoliciesEditRequestPatternType: any;
export interface PatchSettingAllowPolicyRequest {
    /** Identifier. */
    accountId: string;
    /** Allow policy identifier */
    policyId: string;
    comments?: string;
    /** Messages from this sender will be exempted from Spam, Spoof and Bulk dispositions. Note - This will not exempt messages with Malicious or Suspicious dispositions. */
    isAcceptableSender?: boolean;
    /** Messages to this recipient will bypass all detections */
    isExemptRecipient?: boolean;
    /** Deprecated as of July 1, 2025. Use `is_exempt_recipient` instead. End of life: July 1, 2026. */
    isRecipient?: boolean;
    isRegex?: boolean;
    /** Deprecated as of July 1, 2025. Use `is_trusted_sender` instead. End of life: July 1, 2026. */
    isSender?: boolean;
    /** Deprecated as of July 1, 2025. Use `is_acceptable_sender` instead. End of life: July 1, 2026. */
    isSpoof?: boolean;
    /** Messages from this sender will bypass all detections and link following */
    isTrustedSender?: boolean;
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesEditRequestPatternType | (string & {});
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean;
}
export declare const PatchSettingAllowPolicyRequest: S.Schema<PatchSettingAllowPolicyRequest>;
export type SettingsAllowPoliciesEditResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsAllowPoliciesEditResponsePatternType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingAllowPolicyResponse {
    /** Allow policy identifier */
    id: string;
    createdAt: string;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified: string;
    comments?: string | null;
    /** Messages from this sender will be exempted from Spam, Spoof and Bulk dispositions. Note - This will not exempt messages with Malicious or Suspicious dispositions. */
    isAcceptableSender?: boolean | null;
    /** Messages to this recipient will bypass all detections */
    isExemptRecipient?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_exempt_recipient` instead. End of life: July 1, 2026. */
    isRecipient?: boolean | null;
    isRegex?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_trusted_sender` instead. End of life: July 1, 2026. */
    isSender?: boolean | null;
    /** Deprecated as of July 1, 2025. Use `is_acceptable_sender` instead. End of life: July 1, 2026. */
    isSpoof?: boolean | null;
    /** Messages from this sender will bypass all detections and link following */
    isTrustedSender?: boolean | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsAllowPoliciesEditResponsePatternType | null;
    /** Enforce DMARC, SPF or DKIM authentication. When on, Email Security only honors policies that pass authentication. */
    verifySender?: boolean | null;
}
export declare const PatchSettingAllowPolicyResponse: S.Schema<PatchSettingAllowPolicyResponse>;
export type SettingsBlockSendersEditRequestPatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsBlockSendersEditRequestPatternType: any;
export interface PatchSettingBlockSenderRequest {
    /** Identifier. */
    accountId: string;
    /** Blocked sender pattern identifier */
    patternId: string;
    comments?: string;
    isRegex?: boolean;
    pattern?: string;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersEditRequestPatternType | (string & {});
}
export declare const PatchSettingBlockSenderRequest: S.Schema<PatchSettingBlockSenderRequest>;
export type SettingsBlockSendersEditResponsePatternType = "EMAIL" | "DOMAIN" | "IP" | "UNKNOWN";
export declare const SettingsBlockSendersEditResponsePatternType: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingBlockSenderResponse {
    /** Blocked sender pattern identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    isRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
    /** Type of pattern matching. */
    patternType?: SettingsBlockSendersEditResponsePatternType | null;
}
export declare const PatchSettingBlockSenderResponse: S.Schema<PatchSettingBlockSenderResponse>;
export type SettingsDomainsEditRequestAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export declare const SettingsDomainsEditRequestAllowedDeliveryModesItem: any;
export type SettingsDomainsEditRequestAllowedDeliveryModesList = Array<SettingsDomainsEditRequestAllowedDeliveryModesItem | (string & {})>;
export declare const SettingsDomainsEditRequestAllowedDeliveryModesList: S.Schema<SettingsDomainsEditRequestAllowedDeliveryModesList>;
export type SettingsDomainsEditRequestDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const SettingsDomainsEditRequestDropDispositionsItem: any;
export type SettingsDomainsEditRequestDropDispositionsList = Array<SettingsDomainsEditRequestDropDispositionsItem | (string & {})>;
export declare const SettingsDomainsEditRequestDropDispositionsList: S.Schema<SettingsDomainsEditRequestDropDispositionsList>;
export type SettingsDomainsEditRequestFolder = "AllItems" | "Inbox";
export declare const SettingsDomainsEditRequestFolder: any;
export type SettingsDomainsEditRequestIpRestrictionsList = Array<string>;
export declare const SettingsDomainsEditRequestIpRestrictionsList: S.Schema<SettingsDomainsEditRequestIpRestrictionsList>;
export type SettingsDomainsEditRequestRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export declare const SettingsDomainsEditRequestRegionsItem: any;
export type SettingsDomainsEditRequestRegionsList = Array<SettingsDomainsEditRequestRegionsItem | (string & {})>;
export declare const SettingsDomainsEditRequestRegionsList: S.Schema<SettingsDomainsEditRequestRegionsList>;
export interface PatchSettingDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Domain identifier */
    domainId: string;
    allowedDeliveryModes?: SettingsDomainsEditRequestAllowedDeliveryModesList;
    domain?: string;
    dropDispositions?: SettingsDomainsEditRequestDropDispositionsList;
    folder?: SettingsDomainsEditRequestFolder | (string & {});
    integrationId?: string;
    ipRestrictions?: SettingsDomainsEditRequestIpRestrictionsList;
    lookbackHops?: number;
    regions?: SettingsDomainsEditRequestRegionsList;
    requireTlsInbound?: boolean;
    requireTlsOutbound?: boolean;
    transport?: string;
}
export declare const PatchSettingDomainRequest: S.Schema<PatchSettingDomainRequest>;
export type SettingsDomainsEditResponseAllowedDeliveryModesItem = "DIRECT" | "BCC" | "JOURNAL" | "API" | "RETRO_SCAN";
export declare const SettingsDomainsEditResponseAllowedDeliveryModesItem: any;
export type SettingsDomainsEditResponseAllowedDeliveryModesList = Array<SettingsDomainsEditResponseAllowedDeliveryModesItem>;
export declare const SettingsDomainsEditResponseAllowedDeliveryModesList: S.Schema<SettingsDomainsEditResponseAllowedDeliveryModesList>;
export type SettingsDomainsEditResponseAuthorization = SettingsDomainsGetResponseAuthorization;
export declare const SettingsDomainsEditResponseAuthorization: S.Schema<SettingsDomainsGetResponseAuthorization>;
export type SettingsDomainsEditResponseDmarcStatus = "none" | "good" | "invalid";
export declare const SettingsDomainsEditResponseDmarcStatus: any;
export type SettingsDomainsEditResponseDropDispositionsItem = "MALICIOUS" | "MALICIOUS-BEC" | "SUSPICIOUS" | "SPOOF" | "SPAM" | "BULK" | "ENCRYPTED" | "EXTERNAL" | "UNKNOWN" | "NONE";
export declare const SettingsDomainsEditResponseDropDispositionsItem: any;
export type SettingsDomainsEditResponseDropDispositionsList = Array<SettingsDomainsEditResponseDropDispositionsItem>;
export declare const SettingsDomainsEditResponseDropDispositionsList: S.Schema<SettingsDomainsEditResponseDropDispositionsList>;
export type SettingsDomainsEditResponseEmailsProcessed = SettingsDomainsGetResponseEmailsProcessed;
export declare const SettingsDomainsEditResponseEmailsProcessed: S.Schema<SettingsDomainsGetResponseEmailsProcessed>;
export type SettingsDomainsEditResponseFolder = "AllItems" | "Inbox";
export declare const SettingsDomainsEditResponseFolder: any;
export type SettingsDomainsEditResponseInboxProvider = "Microsoft" | "Google";
export declare const SettingsDomainsEditResponseInboxProvider: any;
export type SettingsDomainsEditResponseIpRestrictionsList = Array<string>;
export declare const SettingsDomainsEditResponseIpRestrictionsList: S.Schema<SettingsDomainsEditResponseIpRestrictionsList>;
export type SettingsDomainsEditResponseRegionsItem = "GLOBAL" | "AU" | "DE" | "IN" | "US";
export declare const SettingsDomainsEditResponseRegionsItem: any;
export type SettingsDomainsEditResponseRegionsList = Array<SettingsDomainsEditResponseRegionsItem>;
export declare const SettingsDomainsEditResponseRegionsList: S.Schema<SettingsDomainsEditResponseRegionsList>;
export type SettingsDomainsEditResponseSpfStatus = "none" | "good" | "neutral" | "open" | "invalid";
export declare const SettingsDomainsEditResponseSpfStatus: any;
export type SettingsDomainsEditResponseStatus = "pending" | "active" | "failed" | "timeout";
export declare const SettingsDomainsEditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingDomainResponse {
    /** Domain identifier */
    id?: string | null;
    allowedDeliveryModes?: SettingsDomainsEditResponseAllowedDeliveryModesList | null;
    authorization?: SettingsDomainsGetResponseAuthorization | null;
    createdAt?: string | null;
    dmarcStatus?: SettingsDomainsEditResponseDmarcStatus | null;
    domain?: string | null;
    dropDispositions?: SettingsDomainsEditResponseDropDispositionsList | null;
    emailsProcessed?: SettingsDomainsGetResponseEmailsProcessed | null;
    folder?: SettingsDomainsEditResponseFolder | null;
    inboxProvider?: SettingsDomainsEditResponseInboxProvider | null;
    integrationId?: string | null;
    ipRestrictions?: SettingsDomainsEditResponseIpRestrictionsList | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    lookbackHops?: number | null;
    modifiedAt?: string | null;
    o365TenantId?: string | null;
    regions?: SettingsDomainsEditResponseRegionsList | null;
    requireTlsInbound?: boolean | null;
    requireTlsOutbound?: boolean | null;
    spfStatus?: SettingsDomainsEditResponseSpfStatus | null;
    status?: SettingsDomainsEditResponseStatus | null;
    transport?: string | null;
}
export declare const PatchSettingDomainResponse: S.Schema<PatchSettingDomainResponse>;
export type SettingsImpersonationRegistryEditRequestProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export declare const SettingsImpersonationRegistryEditRequestProvenance: any;
export interface PatchSettingImpersonationRegistryRequest {
    /** Identifier. */
    accountId: string;
    /** Impersonation registry entry identifier */
    impersonationRegistryId: string;
    comments?: string;
    directoryId?: number;
    directoryNodeId?: number;
    email?: string;
    externalDirectoryNodeId?: string;
    isEmailRegex?: boolean;
    name?: string;
    provenance?: SettingsImpersonationRegistryEditRequestProvenance | (string & {});
}
export declare const PatchSettingImpersonationRegistryRequest: S.Schema<PatchSettingImpersonationRegistryRequest>;
export type SettingsImpersonationRegistryEditResponseProvenance = "A1S_INTERNAL" | "SNOOPY-CASB_OFFICE_365" | "SNOOPY-OFFICE_365" | "SNOOPY-GOOGLE_DIRECTORY";
export declare const SettingsImpersonationRegistryEditResponseProvenance: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingImpersonationRegistryResponse {
    /** Impersonation registry entry identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    directoryId?: number | null;
    directoryNodeId?: number | null;
    email?: string | null;
    externalDirectoryNodeId?: string | null;
    isEmailRegex?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    name?: string | null;
    provenance?: SettingsImpersonationRegistryEditResponseProvenance | null;
}
export declare const PatchSettingImpersonationRegistryResponse: S.Schema<PatchSettingImpersonationRegistryResponse>;
export type SettingsSendingDomainRestrictionsEditRequestExcludeList = Array<string>;
export declare const SettingsSendingDomainRestrictionsEditRequestExcludeList: S.Schema<SettingsSendingDomainRestrictionsEditRequestExcludeList>;
export interface PatchSettingSendingDomainRestrictionRequest {
    /** Identifier. */
    accountId: string;
    /** Sending domain restriction identifier. */
    sendingDomainRestrictionId: string;
    comments?: string;
    /** Domain that requires TLS enforcement. */
    domain?: string;
    /** Excluded subdomains that are exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsEditRequestExcludeList;
}
export declare const PatchSettingSendingDomainRestrictionRequest: S.Schema<PatchSettingSendingDomainRestrictionRequest>;
export type SettingsSendingDomainRestrictionsEditResponseExcludeList = Array<string>;
export declare const SettingsSendingDomainRestrictionsEditResponseExcludeList: S.Schema<SettingsSendingDomainRestrictionsEditResponseExcludeList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingSendingDomainRestrictionResponse {
    /** Sending domain restriction identifier. */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Domain that requires TLS enforcement. */
    domain?: string | null;
    /** Excluded subdomains that are exempt from TLS requirements. */
    exclude?: SettingsSendingDomainRestrictionsEditResponseExcludeList | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const PatchSettingSendingDomainRestrictionResponse: S.Schema<PatchSettingSendingDomainRestrictionResponse>;
export interface PatchSettingTrustedDomainRequest {
    /** Identifier. */
    accountId: string;
    /** Trusted domain identifier */
    trustedDomainId: string;
    comments?: string;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean;
    isRegex?: boolean;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean;
    pattern?: string;
}
export declare const PatchSettingTrustedDomainRequest: S.Schema<PatchSettingTrustedDomainRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingTrustedDomainResponse {
    /** Trusted domain identifier */
    id?: string | null;
    comments?: string | null;
    createdAt?: string | null;
    /** Select to prevent recently registered domains from triggering a Suspicious or Malicious disposition. */
    isRecent?: boolean | null;
    isRegex?: boolean | null;
    /** Select for partner or other approved domains that have similar spelling to your connected domains. Prevents listed domains from triggering a Spoof disposition. */
    isSimilarity?: boolean | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
    pattern?: string | null;
}
export declare const PatchSettingTrustedDomainResponse: S.Schema<PatchSettingTrustedDomainResponse>;
export interface PatchSettingUrlIgnorePatternRequest {
    /** Identifier. */
    accountId: string;
    /** URL ignore pattern identifier */
    patternId: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string;
    /** Regular expression matching URLs that should not be rewritten. */
    pattern?: string;
}
export declare const PatchSettingUrlIgnorePatternRequest: S.Schema<PatchSettingUrlIgnorePatternRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSettingUrlIgnorePatternResponse {
    /** URL ignore pattern identifier */
    id: string;
    createdAt: string;
    /** Regular expression matching URLs that should not be rewritten. */
    pattern: string;
    /** Optional note describing the reason for the ignore pattern. */
    comments?: string | null;
    /** Deprecated, use `modified_at` instead. End of life: November 1, 2026. */
    lastModified?: string | null;
    modifiedAt?: string | null;
}
export declare const PatchSettingUrlIgnorePatternResponse: S.Schema<PatchSettingUrlIgnorePatternResponse>;
export type BulkInvestigateMoveError = CloudflareOpError;
/** Moves multiple messages to a specified mailbox folder (Inbox, JunkEmail, DeletedItems, RecoverableItemsDeletions, or RecoverableItemsPurges). Requires active integration. */
export declare const bulkInvestigateMove: API.PaginatedOperationMethod<BulkInvestigateMoveRequest, BulkInvestigateMoveResponse, BulkInvestigateMoveError, CloudflareOpContext, InvestigateMoveBulkResultItem>;
export type BulkInvestigateReleaseError = CloudflareOpError;
/** Releases one or more quarantined messages, delivering them to the intended recipients. Use when a message was incorrectly quarantined. Returns delivery status for each recipient. */
export declare const bulkInvestigateRelease: API.PaginatedOperationMethod<BulkInvestigateReleaseRequest, BulkInvestigateReleaseResponse, BulkInvestigateReleaseError, CloudflareOpContext, InvestigateReleaseBulkResultItem>;
export type CreateInvestigateBulkError = CloudflareOpError;
/** Create a bulk action job */
export declare const createInvestigateBulk: API.OperationMethod<CreateInvestigateBulkRequest, CreateInvestigateBulkResponse, CreateInvestigateBulkError, CloudflareOpContext>;
export type CreateInvestigateBulkCancelError = CloudflareOpError;
/** Marks the job as cancelled and stops any pending message processing. The job record remains visible in list and detail endpoints. */
export declare const createInvestigateBulkCancel: API.OperationMethod<CreateInvestigateBulkCancelRequest, CreateInvestigateBulkCancelResponse, CreateInvestigateBulkCancelError, CloudflareOpContext>;
export type CreateInvestigateMoveError = CloudflareOpError;
/** Moves a single message to a specified mailbox folder (Inbox, JunkEmail, DeletedItems, RecoverableItemsDeletions, or RecoverableItemsPurges). Requires active integration. */
export declare const createInvestigateMove: API.PaginatedOperationMethod<CreateInvestigateMoveRequest, CreateInvestigateMoveResponse, CreateInvestigateMoveError, CloudflareOpContext, InvestigateMoveBulkResultItem>;
export type CreateInvestigatePreviewError = CloudflareOpError;
/** Generates a preview image for a message that was not flagged as a detection. Useful for investigating benign messages. Returns a base64-encoded PNG screenshot of the email body. */
export declare const createInvestigatePreview: API.OperationMethod<CreateInvestigatePreviewRequest, CreateInvestigatePreviewResponse, CreateInvestigatePreviewError, CloudflareOpContext>;
export type CreateInvestigateReclassifyError = CloudflareOpError;
/** Submits a request to reclassify an email's disposition. Use for reporting false positives or false negatives. Optionally provide the raw EML content for reanalysis. The reclassification is processed asynchronously. */
export declare const createInvestigateReclassify: API.OperationMethod<CreateInvestigateReclassifyRequest, CreateInvestigateReclassifyResponse, CreateInvestigateReclassifyError, CloudflareOpContext>;
export type CreateSettingAllowPolicyError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new allow policy that exempts matching emails from security detections. Use with caution as this bypasses email security scanning. Policies can match on sender patterns and apply to specific detections or all detections. */
export declare const createSettingAllowPolicy: API.OperationMethod<CreateSettingAllowPolicyRequest, CreateSettingAllowPolicyResponse, CreateSettingAllowPolicyError, CloudflareOpContext>;
export type CreateSettingBlockSenderError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new blocked sender pattern. Emails matching this pattern will be blocked from delivery. Patterns can be email addresses, domains, or IP addresses, and support regular expressions. */
export declare const createSettingBlockSender: API.OperationMethod<CreateSettingBlockSenderRequest, CreateSettingBlockSenderResponse, CreateSettingBlockSenderError, CloudflareOpContext>;
export type CreateSettingImpersonationRegistryError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new entry in the impersonation registry to protect against impersonation. Emails attempting to impersonate this identity will be flagged. Supports regex patterns for flexible email matching. */
export declare const createSettingImpersonationRegistry: API.OperationMethod<CreateSettingImpersonationRegistryRequest, CreateSettingImpersonationRegistryResponse, CreateSettingImpersonationRegistryError, CloudflareOpContext>;
export type CreateSettingSendingDomainRestrictionError = CloudflareOpError;
/** Creates a new sending domain restriction to enforce TLS requirements for a domain. Emails without TLS from this domain will be dropped unless the subdomain is in the exclude list. */
export declare const createSettingSendingDomainRestriction: API.OperationMethod<CreateSettingSendingDomainRestrictionRequest, CreateSettingSendingDomainRestrictionResponse, CreateSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type CreateSettingTrustedDomainError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Creates a new trusted domain pattern. Use for partner domains or approved senders that should bypass recent domain registration and similarity checks. Configure whether it prevents recent domain or spoof dispositions. */
export declare const createSettingTrustedDomain: API.OperationMethod<CreateSettingTrustedDomainRequest, CreateSettingTrustedDomainResponse, CreateSettingTrustedDomainError, CloudflareOpContext>;
export type CreateSettingUrlIgnorePatternError = CloudflareOpError;
/** Creates a new URL rewrite ignore pattern. URLs matching this pattern will not be rewritten. */
export declare const createSettingUrlIgnorePattern: API.OperationMethod<CreateSettingUrlIgnorePatternRequest, CreateSettingUrlIgnorePatternResponse, CreateSettingUrlIgnorePatternError, CloudflareOpContext>;
export type DeleteInvestigateBulkError = CloudflareOpError;
/** Deletes the job, removing it from all list and detail endpoints. Only jobs in a terminal state (`COMPLETED`, `CANCELLED`, `FAILED`, or `SKIPPED`) can be deleted. To stop an in-progress job without removing it, use the cancel endpoint instead. */
export declare const deleteInvestigateBulk: API.OperationMethod<DeleteInvestigateBulkRequest, DeleteInvestigateBulkResponse, DeleteInvestigateBulkError, CloudflareOpContext>;
export type DeleteSettingAllowPolicyError = AllowPolicyNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes an allow policy. After deletion, emails matching this pattern will be subject to normal security scanning and disposition actions. */
export declare const deleteSettingAllowPolicy: API.OperationMethod<DeleteSettingAllowPolicyRequest, DeleteSettingAllowPolicyResponse, DeleteSettingAllowPolicyError, CloudflareOpContext>;
export type DeleteSettingBlockSenderError = BlockSenderNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes a blocked sender pattern. After deletion, emails from this sender will no longer be automatically blocked based on this rule. */
export declare const deleteSettingBlockSender: API.OperationMethod<DeleteSettingBlockSenderRequest, DeleteSettingBlockSenderResponse, DeleteSettingBlockSenderError, CloudflareOpContext>;
export type DeleteSettingDomainError = EmailSecurityDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes email security protection from a domain. After deletion, emails for this domain will no longer be processed by Email Security. This action cannot be undone. */
export declare const deleteSettingDomain: API.OperationMethod<DeleteSettingDomainRequest, DeleteSettingDomainResponse, DeleteSettingDomainError, CloudflareOpContext>;
export type DeleteSettingImpersonationRegistryError = ImpersonationRegistryEntryNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes an entry from the impersonation registry. After deletion, this identity will no longer be protected from impersonation. */
export declare const deleteSettingImpersonationRegistry: API.OperationMethod<DeleteSettingImpersonationRegistryRequest, DeleteSettingImpersonationRegistryResponse, DeleteSettingImpersonationRegistryError, CloudflareOpContext>;
export type DeleteSettingSendingDomainRestrictionError = CloudflareOpError;
/** Removes a sending domain restriction. After deletion, TLS will no longer be enforced for emails from this domain. */
export declare const deleteSettingSendingDomainRestriction: API.OperationMethod<DeleteSettingSendingDomainRestrictionRequest, DeleteSettingSendingDomainRestrictionResponse, DeleteSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type DeleteSettingTrustedDomainError = TrustedDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Removes a trusted domain pattern. After deletion, emails from this domain will be subject to normal recent domain and similarity checks. */
export declare const deleteSettingTrustedDomain: API.OperationMethod<DeleteSettingTrustedDomainRequest, DeleteSettingTrustedDomainResponse, DeleteSettingTrustedDomainError, CloudflareOpContext>;
export type DeleteSettingUrlIgnorePatternError = CloudflareOpError;
/** Removes a URL rewrite ignore pattern. After deletion, URLs matching this pattern will be rewritten again. */
export declare const deleteSettingUrlIgnorePattern: API.OperationMethod<DeleteSettingUrlIgnorePatternRequest, DeleteSettingUrlIgnorePatternResponse, DeleteSettingUrlIgnorePatternError, CloudflareOpContext>;
export type GetInvestigateError = CloudflareOpError;
/** Retrieves comprehensive details for a specific email message including headers, recipients, sender information, and current quarantine status. Use the investigate_id from search results to fetch detailed information. */
export declare const getInvestigate: API.OperationMethod<GetInvestigateRequest, GetInvestigateResponse, GetInvestigateError, CloudflareOpContext>;
export type GetInvestigateBulkError = CloudflareOpError;
/** Get bulk action job details */
export declare const getInvestigateBulk: API.OperationMethod<GetInvestigateBulkRequest, GetInvestigateBulkResponse, GetInvestigateBulkError, CloudflareOpContext>;
export type GetInvestigateDetectionError = CloudflareOpError;
/** Returns detection details such as threat categories and sender information for non-benign messages. */
export declare const getInvestigateDetection: API.OperationMethod<GetInvestigateDetectionRequest, GetInvestigateDetectionResponse, GetInvestigateDetectionError, CloudflareOpContext>;
export type GetInvestigatePreviewError = CloudflareOpError;
/** Returns a preview of the message body as a base64 encoded PNG image for non-benign messages. */
export declare const getInvestigatePreview: API.OperationMethod<GetInvestigatePreviewRequest, GetInvestigatePreviewResponse, GetInvestigatePreviewError, CloudflareOpContext>;
export type GetInvestigateRawError = CloudflareOpError;
/** Returns the raw eml of any non-benign message. */
export declare const getInvestigateRaw: API.OperationMethod<GetInvestigateRawRequest, GetInvestigateRawResponse, GetInvestigateRawError, CloudflareOpContext>;
export type GetInvestigateTraceError = CloudflareOpError;
/** Retrieves delivery and processing trace information for an email message. Shows the delivery path, retraction history, and move operations performed on the message. Useful for debugging delivery issues. */
export declare const getInvestigateTrace: API.OperationMethod<GetInvestigateTraceRequest, GetInvestigateTraceResponse, GetInvestigateTraceError, CloudflareOpContext>;
export type GetSettingAllowPolicyError = AllowPolicyNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific allow policy including its pattern, dispositions that are exempted, and whether it applies to all detections. */
export declare const getSettingAllowPolicy: API.OperationMethod<GetSettingAllowPolicyRequest, GetSettingAllowPolicyResponse, GetSettingAllowPolicyError, CloudflareOpContext>;
export type GetSettingBlockSenderError = BlockSenderNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific blocked sender pattern including its pattern type, value, and metadata. */
export declare const getSettingBlockSender: API.OperationMethod<GetSettingBlockSenderRequest, GetSettingBlockSenderResponse, GetSettingBlockSenderError, CloudflareOpContext>;
export type GetSettingDomainError = EmailSecurityDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves detailed information for a specific protected email domain including its delivery configuration, SPF/DMARC status, and authorization state. */
export declare const getSettingDomain: API.OperationMethod<GetSettingDomainRequest, GetSettingDomainResponse, GetSettingDomainError, CloudflareOpContext>;
export type GetSettingImpersonationRegistryError = ImpersonationRegistryEntryNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific impersonation registry entry including the protected identity, email pattern, and synchronization source if directory-synced. */
export declare const getSettingImpersonationRegistry: API.OperationMethod<GetSettingImpersonationRegistryRequest, GetSettingImpersonationRegistryResponse, GetSettingImpersonationRegistryError, CloudflareOpContext>;
export type GetSettingSendingDomainRestrictionError = CloudflareOpError;
/** Retrieves details for a specific sending domain restriction including the domain requiring TLS and any excluded subdomains exempt from the TLS requirement. */
export declare const getSettingSendingDomainRestriction: API.OperationMethod<GetSettingSendingDomainRestrictionRequest, GetSettingSendingDomainRestrictionResponse, GetSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type GetSettingTrustedDomainError = TrustedDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Retrieves details for a specific trusted domain pattern including its pattern value, whether it uses regex matching, and which detection types it affects. */
export declare const getSettingTrustedDomain: API.OperationMethod<GetSettingTrustedDomainRequest, GetSettingTrustedDomainResponse, GetSettingTrustedDomainError, CloudflareOpContext>;
export type GetSettingUrlIgnorePatternError = CloudflareOpError;
/** Returns a single URL rewrite ignore pattern by its identifier. */
export declare const getSettingUrlIgnorePattern: API.OperationMethod<GetSettingUrlIgnorePatternRequest, GetSettingUrlIgnorePatternResponse, GetSettingUrlIgnorePatternError, CloudflareOpContext>;
export type ListInvestigateBulkMessagesError = CloudflareOpError;
/** List messages for a bulk action job */
export declare const listInvestigateBulkMessages: API.PaginatedOperationMethod<ListInvestigateBulkMessagesRequest, ListInvestigateBulkMessagesResponse, ListInvestigateBulkMessagesError, CloudflareOpContext, InvestigateBulkMessagesListResultItem>;
export type ListInvestigateBulksError = CloudflareOpError;
/** List bulk action jobs */
export declare const listInvestigateBulks: API.PaginatedOperationMethod<ListInvestigateBulksRequest, ListInvestigateBulksResponse, ListInvestigateBulksError, CloudflareOpContext, InvestigateBulkListResultItem>;
export type ListInvestigatesError = CloudflareOpError;
/** Returns information for each email that matches the search parameter(s). */
export declare const listInvestigates: API.PaginatedOperationMethod<ListInvestigatesRequest, ListInvestigatesResponse, ListInvestigatesError, CloudflareOpContext, InvestigateListResultItem>;
export type ListPhishguardReportsError = CloudflareOpError;
/** Retrieves PhishGuard security alert reports for a specified date range. Reports include detected threats, dispositions, and contextual information. Use for security monitoring and threat analysis. */
export declare const listPhishguardReports: API.PaginatedOperationMethod<ListPhishguardReportsRequest, ListPhishguardReportsResponse, ListPhishguardReportsError, CloudflareOpContext, PhishguardReportsListResultItem>;
export type ListSettingAllowPoliciesError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of email allow policies. These policies exempt matching emails from security detection, allowing them to bypass disposition actions. Supports filtering by pattern type and policy attributes. */
export declare const listSettingAllowPolicies: API.PaginatedOperationMethod<ListSettingAllowPoliciesRequest, ListSettingAllowPoliciesResponse, ListSettingAllowPoliciesError, CloudflareOpContext, SettingsAllowPoliciesListResultItem>;
export type ListSettingBlockSendersError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of blocked email sender patterns. These patterns prevent emails from matching senders from being delivered. Supports filtering by pattern type and searching across patterns. */
export declare const listSettingBlockSenders: API.PaginatedOperationMethod<ListSettingBlockSendersRequest, ListSettingBlockSendersResponse, ListSettingBlockSendersError, CloudflareOpContext, SettingsBlockSendersListResultItem>;
export type ListSettingDomainsError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of email domains protected by Email Security. Includes domain configuration, delivery modes, and authorization status. Supports filtering by delivery mode and integration ID. */
export declare const listSettingDomains: API.PaginatedOperationMethod<ListSettingDomainsRequest, ListSettingDomainsResponse, ListSettingDomainsError, CloudflareOpContext, SettingsDomainsListResultItem>;
export type ListSettingImpersonationRegistriesError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of protected identities in the impersonation registry. These entries define identities and email addresses to protect from impersonation attacks. Can be manually added or automatically synced from directory integrations. */
export declare const listSettingImpersonationRegistries: API.PaginatedOperationMethod<ListSettingImpersonationRegistriesRequest, ListSettingImpersonationRegistriesResponse, ListSettingImpersonationRegistriesError, CloudflareOpContext, SettingsImpersonationRegistryListResultItem>;
export type ListSettingSendingDomainRestrictionsError = CloudflareOpError;
/** Returns a paginated list of sending domain restrictions. These restrictions enforce TLS requirements for emails from specific domains. Mail without TLS from restricted domains will be dropped unless the subdomain is in the exclude list. Supports sorting and searching. */
export declare const listSettingSendingDomainRestrictions: API.PaginatedOperationMethod<ListSettingSendingDomainRestrictionsRequest, ListSettingSendingDomainRestrictionsResponse, ListSettingSendingDomainRestrictionsError, CloudflareOpContext, SettingsSendingDomainRestrictionsListResultItem>;
export type ListSettingTrustedDomainsError = EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Returns a paginated list of trusted domain patterns. Trusted domains prevent false positives for recently registered domains and lookalike domain detections. Patterns can use regular expressions for flexible matching. */
export declare const listSettingTrustedDomains: API.PaginatedOperationMethod<ListSettingTrustedDomainsRequest, ListSettingTrustedDomainsResponse, ListSettingTrustedDomainsError, CloudflareOpContext, SettingsTrustedDomainsListResultItem>;
export type ListSettingUrlIgnorePatternsError = CloudflareOpError;
/** Returns a paginated list of URL rewrite ignore patterns for the account. URLs matching these patterns will not be rewritten. */
export declare const listSettingUrlIgnorePatterns: API.PaginatedOperationMethod<ListSettingUrlIgnorePatternsRequest, ListSettingUrlIgnorePatternsResponse, ListSettingUrlIgnorePatternsError, CloudflareOpContext, SettingsUrlIgnorePatternsListResultItem>;
export type ListSubmissionsError = CloudflareOpError;
/** Returns information for submissions made to reclassify emails. Shows the status, outcome, and disposition changes for reclassification requests made by users or the security team. Useful for tracking false positive/negative reports. */
export declare const listSubmissions: API.PaginatedOperationMethod<ListSubmissionsRequest, ListSubmissionsResponse, ListSubmissionsError, CloudflareOpContext, SubmissionsListResultItem>;
export type PatchSettingAllowPolicyError = AllowPolicyNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing allow policy. Only provided fields will be modified. Changes take effect for new emails matching the pattern. */
export declare const patchSettingAllowPolicy: API.OperationMethod<PatchSettingAllowPolicyRequest, PatchSettingAllowPolicyResponse, PatchSettingAllowPolicyError, CloudflareOpContext>;
export type PatchSettingBlockSenderError = BlockSenderNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing blocked sender pattern. Only provided fields will be modified. The pattern will continue blocking emails until deleted. */
export declare const patchSettingBlockSender: API.OperationMethod<PatchSettingBlockSenderRequest, PatchSettingBlockSenderResponse, PatchSettingBlockSenderError, CloudflareOpContext>;
export type PatchSettingDomainError = EmailSecurityDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates configuration for a protected email domain. Only provided fields will be modified. Changes affect delivery mode, security settings, and regional processing. */
export declare const patchSettingDomain: API.OperationMethod<PatchSettingDomainRequest, PatchSettingDomainResponse, PatchSettingDomainError, CloudflareOpContext>;
export type PatchSettingImpersonationRegistryError = ImpersonationRegistryEntryNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing impersonation registry entry. Only provided fields will be modified. Directory-synced entries can't be updated. */
export declare const patchSettingImpersonationRegistry: API.OperationMethod<PatchSettingImpersonationRegistryRequest, PatchSettingImpersonationRegistryResponse, PatchSettingImpersonationRegistryError, CloudflareOpContext>;
export type PatchSettingSendingDomainRestrictionError = CloudflareOpError;
/** Updates an existing sending domain restriction. Only provided fields will be modified. Changes affect which domains require TLS and which subdomains are excluded. */
export declare const patchSettingSendingDomainRestriction: API.OperationMethod<PatchSettingSendingDomainRestrictionRequest, PatchSettingSendingDomainRestrictionResponse, PatchSettingSendingDomainRestrictionError, CloudflareOpContext>;
export type PatchSettingTrustedDomainError = TrustedDomainNotFound | EmailSecurityNotEntitled | Forbidden | CloudflareOpError;
/** Updates an existing trusted domain pattern. Only provided fields will be modified. Changes take effect for new emails matching the pattern. */
export declare const patchSettingTrustedDomain: API.OperationMethod<PatchSettingTrustedDomainRequest, PatchSettingTrustedDomainResponse, PatchSettingTrustedDomainError, CloudflareOpContext>;
export type PatchSettingUrlIgnorePatternError = CloudflareOpError;
/** Updates an existing URL rewrite ignore pattern. Only provided fields will be modified. */
export declare const patchSettingUrlIgnorePattern: API.OperationMethod<PatchSettingUrlIgnorePatternRequest, PatchSettingUrlIgnorePatternResponse, PatchSettingUrlIgnorePatternError, CloudflareOpContext>;
//# sourceMappingURL=email_security.d.ts.map