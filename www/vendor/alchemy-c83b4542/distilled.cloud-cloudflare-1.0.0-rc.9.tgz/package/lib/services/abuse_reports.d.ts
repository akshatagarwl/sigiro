import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InvalidAccountId_base: S.Class<InvalidAccountId, S.TaggedStruct<"InvalidAccountId", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAccountId extends /*@__PURE__*/ InvalidAccountId_base {
}
declare const InvalidRequest_base: S.Class<InvalidRequest, S.TaggedStruct<"InvalidRequest", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequest extends /*@__PURE__*/ InvalidRequest_base {
}
export type CreateRequestAct = "abuse_dmca" | "abuse_trademark" | "abuse_general" | "abuse_phishing" | "abuse_children" | "abuse_threat" | "abuse_registrar_whois" | "abuse_ncsei";
export declare const CreateRequestAct: any;
export type CreateRequestAgree = 1;
export declare const CreateRequestAgree: any;
export type CreateRequestHostNotificationEnum = "send";
export declare const CreateRequestHostNotificationEnum: any;
export type CreateRequestHostNotificationAbuseGeneral = "send" | "send-anon";
export declare const CreateRequestHostNotificationAbuseGeneral: any;
export type CreateRequestHostNotification = CreateRequestHostNotificationEnum | (string & {}) | CreateRequestHostNotificationAbuseGeneral | (string & {});
export declare const CreateRequestHostNotification: any;
export type CreateRequestOwnerNotificationEnum = "send";
export declare const CreateRequestOwnerNotificationEnum: any;
export type CreateRequestOwnerNotificationAbuseGeneral = "send" | "send-anon";
export declare const CreateRequestOwnerNotificationAbuseGeneral: any;
export type CreateRequestOwnerNotificationAbuseChildren = "send" | "send-anon" | "none";
export declare const CreateRequestOwnerNotificationAbuseChildren: any;
export type CreateRequestOwnerNotification = CreateRequestOwnerNotificationEnum | (string & {}) | CreateRequestOwnerNotificationAbuseGeneral | (string & {}) | CreateRequestOwnerNotificationAbuseChildren | (string & {});
export declare const CreateRequestOwnerNotification: any;
export type CreateRequestNcmecNotification = "send" | "send-anon";
export declare const CreateRequestNcmecNotification: any;
export type CreateRequestRegWhoRequestRegWhoRequestType = "disclosure" | "invalid_whois";
export declare const CreateRequestRegWhoRequestRegWhoRequestType: any;
export type CreateRequestRegWhoRequestRegWhoRequestedDataElementsItem = "registrant_name" | "registrant_organization" | "registrant_email" | "registrant_phone" | "registrant_address" | "registrant_address_country" | "registrant_address_postal_code" | "admin_name" | "admin_organization" | "admin_email" | "admin_phone" | "admin_address" | "tech_name" | "tech_organization" | "tech_email" | "tech_phone" | "tech_address";
export declare const CreateRequestRegWhoRequestRegWhoRequestedDataElementsItem: any;
export type CreateRequestRegWhoRequestRegWhoRequestedDataElementsList = Array<CreateRequestRegWhoRequestRegWhoRequestedDataElementsItem | (string & {})>;
export declare const CreateRequestRegWhoRequestRegWhoRequestedDataElementsList: S.Schema<CreateRequestRegWhoRequestRegWhoRequestedDataElementsList>;
export type CreateRequestRegWhoRequestRegWhoRequestorType = "government" | "corporation" | "individual";
export declare const CreateRequestRegWhoRequestRegWhoRequestorType: any;
export interface CreateRequestRegWhoRequest {
    /** Affirmation that the request is made in good faith per RDP 10.2.4. Must be true. */
    regWhoGoodFaithAffirmation: boolean;
    /** Agreement to process data lawfully per RDP 10.2.5. Must be true. */
    regWhoLawfulProcessingAgreement: boolean;
    /** Legal rights and rationale for the request per RDP 10.2.3. Required for all WHOIS requests. */
    regWhoLegalBasis: string;
    /** The type of WHOIS data request per RDP procedure. */
    regWhoRequestType: CreateRequestRegWhoRequestRegWhoRequestType | (string & {});
    /** The specific WHOIS data elements being requested per RDP 10.2.2. Required for all WHOIS requests. */
    regWhoRequestedDataElements: CreateRequestRegWhoRequestRegWhoRequestedDataElementsList;
    /** Optional authorization statement or power of attorney per RDP 10.2.1.3. */
    regWhoAuthorizationStatement?: string;
    /** The nature of the requestor per RDP 10.2.1.2. */
    regWhoRequestorType?: CreateRequestRegWhoRequestRegWhoRequestorType | (string & {});
}
export declare const CreateRequestRegWhoRequest: S.Schema<CreateRequestRegWhoRequest>;
export interface CreateAbuseReportRequest {
    accountId: string;
    /** The report type for submitted reports. */
    reportParam: string;
    /** The report type for submitted reports. */
    act: CreateRequestAct | (string & {});
    /** Text not exceeding 100 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    address1?: string;
    /** The name of the copyright holder. Text not exceeding 60 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    agentName?: string;
    /** Can be `0` for false or `1` for true. Must be value: 1 for DMCA reports */
    agree?: CreateRequestAgree | (number & {});
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    city?: string;
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    country?: string;
    /** A valid email of the abuse reporter. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    email: string;
    /** Should match the value provided in `email` */
    email2: string;
    /** Notification type based on the abuse type. NOTE: Copyright (DMCA) and Trademark reports cannot be anonymous. */
    hostNotification?: CreateRequestHostNotification;
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    name: string;
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    originalWork?: string;
    /** Notification type based on the abuse type. NOTE: Copyright (DMCA) and Trademark reports cannot be anonymous. */
    ownerNotification: CreateRequestOwnerNotification;
    /** Required for DMCA reports, should be same as Name. An affirmation that all information in the report is true and accurate while agreeing to the policies of Cloudflare's abuse reports */
    signature?: string;
    /** Text not exceeding 255 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    state?: string;
    /** A list of valid URLs separated by ‘\n’ (new line character). The list of the URLs should not exceed 250 URLs. All URLs should have the same hostname. Each URL should be unique. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    urls: string;
    /** Any additional comments about the infringement not exceeding 2000 characters */
    comments?: string;
    /** Text not exceeding 100 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    company?: string;
    /** Text containing 2 characters */
    reportedCountry?: string;
    /** Text not exceeding 255 characters */
    reportedUserAgent?: string;
    /** Text not exceeding 20 characters. This field may be released by Cloudflare to third parties such as the Lumen Database (https://lumendatabase.org/). */
    tele?: string;
    /** Text not exceeding 255 characters */
    title?: string;
    /** A detailed description of the infringement, including any necessary access details and the exact steps needed to view the content, not exceeding 5000 characters. */
    justification?: string;
    /** Text not exceeding 1000 characters */
    trademarkNumber?: string;
    /** Text not exceeding 1000 characters */
    trademarkOffice?: string;
    /** Text not exceeding 1000 characters */
    trademarkSymbol?: string;
    /** A list of IP addresses separated by ‘\n’ (new line character). The list of destination IPs should not exceed 30 IP addresses. Each one of the IP addresses ought to be unique. */
    destinationIps?: string;
    /** A comma separated list of ports and protocols e.g. 80/TCP, 22/UDP. The total size of the field should not exceed 2000 characters. Each individual port/protocol should not exceed 100 characters. The list should not have more than 30 unique ports and protocols. */
    portsProtocols?: string;
    /** A list of IP addresses separated by ‘\n’ (new line character). The list of source IPs should not exceed 30 IP addresses. Each one of the IP addresses ought to be unique. */
    sourceIps?: string;
    /** Notification type based on the abuse type. NOTE: Copyright (DMCA) and Trademark reports cannot be anonymous. */
    ncmecNotification?: CreateRequestNcmecNotification | (string & {});
    /** RDP-mandated fields for registrar WHOIS data disclosure requests. */
    regWhoRequest?: CreateRequestRegWhoRequest;
    /** If the submitter is the target of NCSEI in the URLs of the abuse report. */
    ncseiSubjectRepresentation?: boolean;
}
export declare const CreateAbuseReportRequest: S.Schema<CreateAbuseReportRequest>;
export type CreateAbuseReportResponse = string;
export declare const CreateAbuseReportResponse: S.Schema<CreateAbuseReportResponse>;
export interface GetRequest {
    accountId: string;
    reportParam: string;
}
export declare const GetRequest: S.Schema<GetRequest>;
export interface GetResponseMitigationSummary {
    /** How many of the reported URLs were confirmed as abusive. */
    acceptedUrlCount: number;
    /** How many mitigations are active. */
    activeCount: number;
    /** Whether the report has been forwarded to an external hosting provider. */
    externalHostNotified: boolean;
    /** How many mitigations are under review. */
    inReviewCount: number;
    /** How many mitigations are pending their effective date. */
    pendingCount: number;
}
export declare const GetResponseMitigationSummary: S.Schema<GetResponseMitigationSummary>;
export type GetResponseStatus = "accepted" | "in_review";
export declare const GetResponseStatus: any;
export type GetResponseType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export declare const GetResponseType: any;
export interface GetResponseSubmitter {
    company?: string | null;
    email?: string | null;
    name?: string | null;
    telephone?: string | null;
}
export declare const GetResponseSubmitter: S.Schema<GetResponseSubmitter>;
export type GetResponseUrlsList = Array<string>;
export declare const GetResponseUrlsList: S.Schema<GetResponseUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResponse {
    /** Public facing ID of abuse report, aka abuse_rand. */
    id: string;
    /** Creation date of report. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    cdate: string;
    /** Domain that relates to the report. */
    domain: string;
    /** A summary of the mitigations related to this report. */
    mitigationSummary: GetResponseMitigationSummary;
    /** An enum value that represents the status of an abuse record */
    status: GetResponseStatus;
    /** The abuse report type */
    type: GetResponseType;
    /** Justification for the report. */
    justification?: string | null;
    /** Original work / Targeted brand in the alleged abuse. */
    originalWork?: string | null;
    /** Information about the submitter of the report. */
    submitter?: GetResponseSubmitter | null;
    urls?: GetResponseUrlsList | null;
}
export declare const GetResponse: S.Schema<GetResponse>;
export type ListRequestMitigationStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export declare const ListRequestMitigationStatus: any;
export type ListRequestStatus = "accepted" | "in_review";
export declare const ListRequestStatus: any;
export type ListRequestType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export declare const ListRequestType: any;
export interface ListAbuseReportsRequest {
    accountId: string;
    /** Returns reports created after the specified date */
    createdAfter?: string;
    /** Returns reports created before the specified date */
    createdBefore?: string;
    /** Filter by domain name related to the abuse report */
    domain?: string;
    /** Filter reports that have any mitigations in the given status. */
    mitigationStatus?: ListRequestMitigationStatus | (string & {});
    /** Where in pagination to start listing abuse reports */
    page?: number;
    /** How many abuse reports per page to list */
    perPage?: number;
    /** A property to sort by, followed by the order (id, cdate, domain, type, status) */
    sort?: string;
    /** Filter by the status of the report. */
    status?: ListRequestStatus | (string & {});
    /** Filter by the type of the report. */
    type?: ListRequestType | (string & {});
}
export declare const ListAbuseReportsRequest: S.Schema<ListAbuseReportsRequest>;
export type ListResponseReportsItemMitigationSummary = GetResponseMitigationSummary;
export declare const ListResponseReportsItemMitigationSummary: S.Schema<GetResponseMitigationSummary>;
export type ListResponseReportsItemStatus = "accepted" | "in_review";
export declare const ListResponseReportsItemStatus: any;
export type ListResponseReportsItemType = "PHISH" | "GEN" | "THREAT" | "DMCA" | "EMER" | "TM" | "REG_WHO" | "NCSEI" | "NETWORK";
export declare const ListResponseReportsItemType: any;
export type ListResponseReportsItemSubmitter = GetResponseSubmitter;
export declare const ListResponseReportsItemSubmitter: S.Schema<GetResponseSubmitter>;
export type ListResponseReportsItemUrlsList = Array<string>;
export declare const ListResponseReportsItemUrlsList: S.Schema<ListResponseReportsItemUrlsList>;
export interface ListResponseReportsItem {
    /** Public facing ID of abuse report, aka abuse_rand. */
    id: string;
    /** Creation date of report. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    cdate: string;
    /** Domain that relates to the report. */
    domain: string;
    /** A summary of the mitigations related to this report. */
    mitigationSummary: GetResponseMitigationSummary;
    /** An enum value that represents the status of an abuse record */
    status: ListResponseReportsItemStatus;
    /** The abuse report type */
    type: ListResponseReportsItemType;
    /** Justification for the report. */
    justification?: string | null;
    /** Original work / Targeted brand in the alleged abuse. */
    originalWork?: string | null;
    /** Information about the submitter of the report. */
    submitter?: GetResponseSubmitter | null;
    urls?: ListResponseReportsItemUrlsList | null;
}
export declare const ListResponseReportsItem: S.Schema<ListResponseReportsItem>;
export type ListResponseReportsList = Array<ListResponseReportsItem>;
export declare const ListResponseReportsList: S.Schema<ListResponseReportsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListAbuseReportsResponse {
    reports: ListResponseReportsList;
}
export declare const ListAbuseReportsResponse: S.Schema<ListAbuseReportsResponse>;
export type MitigationsListRequestEntityType = "url_pattern" | "account" | "zone";
export declare const MitigationsListRequestEntityType: any;
export type MitigationsListRequestSort = "type,asc" | "type,desc" | "effective_date,asc" | "effective_date,desc" | "status,asc" | "status,desc" | "entity_type,asc" | "entity_type,desc";
export declare const MitigationsListRequestSort: any;
export type MitigationsListRequestStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export declare const MitigationsListRequestStatus: any;
export type MitigationsListRequestType = "account_suspend" | "copyright_interstitial" | "geo_block" | "legal_block" | "malware_interstitial" | "misleading_interstitial" | "network_block" | "phishing_interstitial" | "playfairite_enforce" | "r2_takedown_account" | "r2_takedown_bucket" | "r2_takedown_object" | "rate_limit_cache" | "redirect_video_stream" | "registrar_freeze" | "registrar_parking" | "stream_block_account" | "user_suspend" | "workers_takedown_by_zone_id";
export declare const MitigationsListRequestType: any;
export interface ListMitigationsRequest {
    accountId: string;
    reportId: string;
    /** Returns mitigation that were dispatched after the given date */
    effectiveAfter?: string;
    /** Returns mitigations that were dispatched before the given date */
    effectiveBefore?: string;
    /** Filter by the type of entity the mitigation impacts. */
    entityType?: MitigationsListRequestEntityType | (string & {});
    /** Where in pagination to start listing abuse reports */
    page?: number;
    /** How many abuse reports per page to list */
    perPage?: number;
    /** A property to sort by, followed by the order */
    sort?: MitigationsListRequestSort | (string & {});
    /** Filter by the status of the mitigation. */
    status?: MitigationsListRequestStatus | (string & {});
    /** Filter by the type of mitigation. This filter parameter can be specified multiple times to include multiple types of mitigations in the result set, e.g. ?type=rate_limit_cache&type=legal_block. */
    type?: MitigationsListRequestType | (string & {});
}
export declare const ListMitigationsRequest: S.Schema<ListMitigationsRequest>;
export type MitigationsListResponseMitigationsItemEntityType = "url_pattern" | "account" | "zone";
export declare const MitigationsListResponseMitigationsItemEntityType: any;
export type MitigationsListResponseMitigationsItemStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export declare const MitigationsListResponseMitigationsItemStatus: any;
export type MitigationsListResponseMitigationsItemType = "account_suspend" | "copyright_interstitial" | "geo_block" | "legal_block" | "malware_interstitial" | "misleading_interstitial" | "network_block" | "phishing_interstitial" | "playfairite_enforce" | "r2_takedown_account" | "r2_takedown_bucket" | "r2_takedown_object" | "rate_limit_cache" | "redirect_video_stream" | "registrar_freeze" | "registrar_parking" | "stream_block_account" | "user_suspend" | "workers_takedown_by_zone_id";
export declare const MitigationsListResponseMitigationsItemType: any;
export interface MitigationsListResponseMitigationsItem {
    /** ID of remediation. */
    id: string;
    /** Date when the mitigation will become active. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    effectiveDate: string;
    entityId: string;
    /** The type of entity targeted by a mitigation. */
    entityType: MitigationsListResponseMitigationsItemEntityType;
    /** The status of a mitigation */
    status: MitigationsListResponseMitigationsItemStatus;
    /** The type of mitigation applied to a reported entity. */
    type: MitigationsListResponseMitigationsItemType;
}
export declare const MitigationsListResponseMitigationsItem: S.Schema<MitigationsListResponseMitigationsItem>;
export type MitigationsListResponseMitigationsList = Array<MitigationsListResponseMitigationsItem>;
export declare const MitigationsListResponseMitigationsList: S.Schema<MitigationsListResponseMitigationsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListMitigationsResponse {
    mitigations: MitigationsListResponseMitigationsList;
}
export declare const ListMitigationsResponse: S.Schema<ListMitigationsResponse>;
export type MitigationsReviewRequestAppealsItemReason = "removed" | "misclassified";
export declare const MitigationsReviewRequestAppealsItemReason: any;
export interface MitigationsReviewRequestAppealsItem {
    /** ID of the mitigation to appeal. */
    id: string;
    /** Reason why the customer is appealing. */
    reason: MitigationsReviewRequestAppealsItemReason | (string & {});
}
export declare const MitigationsReviewRequestAppealsItem: S.Schema<MitigationsReviewRequestAppealsItem>;
export type MitigationsReviewRequestAppealsList = Array<MitigationsReviewRequestAppealsItem>;
export declare const MitigationsReviewRequestAppealsList: S.Schema<MitigationsReviewRequestAppealsList>;
export interface ReviewMitigationRequest {
    accountId: string;
    reportId: string;
    /** List of mitigations to appeal. */
    appeals: MitigationsReviewRequestAppealsList;
}
export declare const ReviewMitigationRequest: S.Schema<ReviewMitigationRequest>;
export type MitigationsReviewResultItemEntityType = "url_pattern" | "account" | "zone";
export declare const MitigationsReviewResultItemEntityType: any;
export type MitigationsReviewResultItemStatus = "pending" | "active" | "in_review" | "cancelled" | "removed";
export declare const MitigationsReviewResultItemStatus: any;
export type MitigationsReviewResultItemType = "account_suspend" | "copyright_interstitial" | "geo_block" | "legal_block" | "malware_interstitial" | "misleading_interstitial" | "network_block" | "phishing_interstitial" | "playfairite_enforce" | "r2_takedown_account" | "r2_takedown_bucket" | "r2_takedown_object" | "rate_limit_cache" | "redirect_video_stream" | "registrar_freeze" | "registrar_parking" | "stream_block_account" | "user_suspend" | "workers_takedown_by_zone_id";
export declare const MitigationsReviewResultItemType: any;
export interface MitigationsReviewResultItem {
    /** ID of remediation. */
    id: string;
    /** Date when the mitigation will become active. Time in RFC 3339 format (https://www.rfc-editor.org/rfc/rfc3339.html) */
    effectiveDate: string;
    entityId: string;
    /** The type of entity targeted by a mitigation. */
    entityType: MitigationsReviewResultItemEntityType;
    /** The status of a mitigation */
    status: MitigationsReviewResultItemStatus;
    /** The type of mitigation applied to a reported entity. */
    type: MitigationsReviewResultItemType;
}
export declare const MitigationsReviewResultItem: S.Schema<MitigationsReviewResultItem>;
export type MitigationsReviewResultList = Array<MitigationsReviewResultItem>;
export declare const MitigationsReviewResultList: S.Schema<MitigationsReviewResultList>;
export interface ReviewMitigationResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MitigationsReviewResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ReviewMitigationResponse: S.Schema<ReviewMitigationResponse>;
export type CreateAbuseReportError = InvalidRequest | CloudflareOpError;
/** Submit the Abuse Report of a particular type */
export declare const createAbuseReport: API.OperationMethod<CreateAbuseReportRequest, CreateAbuseReportResponse, CreateAbuseReportError, CloudflareOpContext>;
export type GetError = CloudflareOpError;
/** Retrieve the details of an abuse report. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type ListAbuseReportsError = InvalidAccountId | CloudflareOpError;
/** List the abuse reports for a given account */
export declare const listAbuseReports: API.OperationMethod<ListAbuseReportsRequest, ListAbuseReportsResponse, ListAbuseReportsError, CloudflareOpContext>;
export type ListMitigationsError = CloudflareOpError;
/** List mitigations done to remediate the abuse report. */
export declare const listMitigations: API.OperationMethod<ListMitigationsRequest, ListMitigationsResponse, ListMitigationsError, CloudflareOpContext>;
export type ReviewMitigationError = CloudflareOpError;
/** Request a review for mitigations on an account. */
export declare const reviewMitigation: API.PaginatedOperationMethod<ReviewMitigationRequest, ReviewMitigationResponse, ReviewMitigationError, CloudflareOpContext, MitigationsReviewResultItem>;
//# sourceMappingURL=abuse_reports.d.ts.map