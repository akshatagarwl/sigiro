import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const InstanceAlreadyExists_base: S.Class<InstanceAlreadyExists, S.TaggedStruct<"InstanceAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceAlreadyExists extends /*@__PURE__*/ InstanceAlreadyExists_base {
}
declare const InstanceCannotTerminate_base: S.Class<InstanceCannotTerminate, S.TaggedStruct<"InstanceCannotTerminate", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceCannotTerminate extends /*@__PURE__*/ InstanceCannotTerminate_base {
}
declare const InstanceNotFound_base: S.Class<InstanceNotFound, S.TaggedStruct<"InstanceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InstanceNotFound extends /*@__PURE__*/ InstanceNotFound_base {
}
declare const InvalidBody_base: S.Class<InvalidBody, S.TaggedStruct<"InvalidBody", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidBody extends /*@__PURE__*/ InvalidBody_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const VersionNotFound_base: S.Class<VersionNotFound, S.TaggedStruct<"VersionNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class VersionNotFound extends /*@__PURE__*/ VersionNotFound_base {
}
declare const WorkflowInternalError_base: S.Class<WorkflowInternalError, S.TaggedStruct<"WorkflowInternalError", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WorkflowInternalError extends /*@__PURE__*/ WorkflowInternalError_base {
}
declare const WorkflowNotFound_base: S.Class<WorkflowNotFound, S.TaggedStruct<"WorkflowNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WorkflowNotFound extends /*@__PURE__*/ WorkflowNotFound_base {
}
export type InstancesBulkRequestBodyItemInstanceRetentionErrorRetention = string | number;
export declare const InstancesBulkRequestBodyItemInstanceRetentionErrorRetention: any;
export type InstancesBulkRequestBodyItemInstanceRetentionSuccessRetention = string | number;
export declare const InstancesBulkRequestBodyItemInstanceRetentionSuccessRetention: any;
export interface InstancesBulkRequestBodyItemInstanceRetention {
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    errorRetention?: InstancesBulkRequestBodyItemInstanceRetentionErrorRetention;
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    successRetention?: InstancesBulkRequestBodyItemInstanceRetentionSuccessRetention;
}
export declare const InstancesBulkRequestBodyItemInstanceRetention: S.Schema<InstancesBulkRequestBodyItemInstanceRetention>;
export interface InstancesBulkRequestBodyItem {
    instanceId?: string;
    instanceRetention?: InstancesBulkRequestBodyItemInstanceRetention;
    params?: unknown;
}
export declare const InstancesBulkRequestBodyItem: S.Schema<InstancesBulkRequestBodyItem>;
export type InstancesBulkRequestBodyList = Array<InstancesBulkRequestBodyItem>;
export declare const InstancesBulkRequestBodyList: S.Schema<InstancesBulkRequestBodyList>;
export interface BulkInstanceRequest {
    accountId: string;
    workflowName: string;
    body?: InstancesBulkRequestBodyList;
}
export declare const BulkInstanceRequest: S.Schema<BulkInstanceRequest>;
export type InstancesBulkResultItemStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export declare const InstancesBulkResultItemStatus: any;
export type InstancesBulkResultItemTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
export declare const InstancesBulkResultItemTriggerSource: any;
export interface InstancesBulkResultItem {
    id: string;
    status: InstancesBulkResultItemStatus;
    versionId: string;
    workflowId: string;
    triggerSource?: InstancesBulkResultItemTriggerSource | null;
}
export declare const InstancesBulkResultItem: S.Schema<InstancesBulkResultItem>;
export type InstancesBulkResultList = Array<InstancesBulkResultItem>;
export declare const InstancesBulkResultList: S.Schema<InstancesBulkResultList>;
export interface BulkInstanceResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesBulkResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkInstanceResponse: S.Schema<BulkInstanceResponse>;
export type InstancesCreateRequestInstanceRetentionErrorRetention = string | number;
export declare const InstancesCreateRequestInstanceRetentionErrorRetention: any;
export type InstancesCreateRequestInstanceRetentionSuccessRetention = string | number;
export declare const InstancesCreateRequestInstanceRetentionSuccessRetention: any;
export interface InstancesCreateRequestInstanceRetention {
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    errorRetention?: InstancesCreateRequestInstanceRetentionErrorRetention;
    /** Specifies the duration in milliseconds or as a string like '5 minutes'. */
    successRetention?: InstancesCreateRequestInstanceRetentionSuccessRetention;
}
export declare const InstancesCreateRequestInstanceRetention: S.Schema<InstancesCreateRequestInstanceRetention>;
export interface CreateInstanceRequest {
    accountId: string;
    workflowName: string;
    instanceId?: string;
    instanceRetention?: InstancesCreateRequestInstanceRetention;
    params?: unknown;
}
export declare const CreateInstanceRequest: S.Schema<CreateInstanceRequest>;
export type InstancesCreateResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export declare const InstancesCreateResponseStatus: any;
export type InstancesCreateResponseTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
export declare const InstancesCreateResponseTriggerSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateInstanceResponse {
    id: string;
    status: InstancesCreateResponseStatus;
    versionId: string;
    workflowId: string;
    triggerSource?: InstancesCreateResponseTriggerSource | null;
}
export declare const CreateInstanceResponse: S.Schema<CreateInstanceResponse>;
export interface CreateInstanceEventRequest {
    accountId: string;
    workflowName: string;
    /** Instance identifier. User-created instances match `^[a-zA-Z0-9_][a-zA-Z0-9-_]*$` (max 100 characters); cron-triggered instances can use a longer, system-generated id derived from the cron expression. */
    instanceId: string;
    eventType: string;
}
export declare const CreateInstanceEventRequest: S.Schema<CreateInstanceEventRequest>;
export type CreateInstanceEventResponse = unknown;
export declare const CreateInstanceEventResponse: S.Schema<CreateInstanceEventResponse>;
export interface DeleteWorkflowRequest {
    accountId: string;
    workflowName: string;
}
export declare const DeleteWorkflowRequest: S.Schema<DeleteWorkflowRequest>;
export type DeleteResponseStatus = "ok";
export declare const DeleteResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteWorkflowResponse {
    status: DeleteResponseStatus;
    success: boolean;
}
export declare const DeleteWorkflowResponse: S.Schema<DeleteWorkflowResponse>;
export type InstancesGetRequestOrder = "asc" | "desc";
export declare const InstancesGetRequestOrder: any;
export type InstancesGetRequestSimple = "true" | "false";
export declare const InstancesGetRequestSimple: any;
export interface GetInstanceRequest {
    accountId: string;
    workflowName: string;
    /** Instance identifier. User-created instances match `^[a-zA-Z0-9_][a-zA-Z0-9-_]*$` (max 100 characters); cron-triggered instances can use a longer, system-generated id derived from the cron expression. */
    instanceId: string;
    /** Step ordering: "asc" (default, oldest first) or "desc" (newest first). */
    order?: InstancesGetRequestOrder | (string & {});
    /** When true, omits step details and returns only metadata with step_count. */
    simple?: InstancesGetRequestSimple | (string & {});
}
export declare const GetInstanceRequest: S.Schema<GetInstanceRequest>;
export interface InstancesGetResponseError {
    message: string;
    name: string;
}
export declare const InstancesGetResponseError: S.Schema<InstancesGetResponseError>;
export type InstancesGetResponseOutput = string | number;
export declare const InstancesGetResponseOutput: any;
export type InstancesGetResponseRollbackError = InstancesGetResponseError;
export declare const InstancesGetResponseRollbackError: S.Schema<InstancesGetResponseError>;
export type InstancesGetResponseRollbackOutcome = "complete" | "failed";
export declare const InstancesGetResponseRollbackOutcome: any;
export interface InstancesGetResponseRollback {
    error: InstancesGetResponseError;
    outcome: InstancesGetResponseRollbackOutcome;
}
export declare const InstancesGetResponseRollback: S.Schema<InstancesGetResponseRollback>;
export type InstancesGetResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export declare const InstancesGetResponseStatus: any;
export type InstancesGetResponseStepsItemCase0AttemptsItemError = InstancesGetResponseError;
export declare const InstancesGetResponseStepsItemCase0AttemptsItemError: S.Schema<InstancesGetResponseError>;
export interface InstancesGetResponseStepsItemCase0AttemptsItem {
    end: string;
    error: InstancesGetResponseError;
    start: string;
    success: boolean;
}
export declare const InstancesGetResponseStepsItemCase0AttemptsItem: S.Schema<InstancesGetResponseStepsItemCase0AttemptsItem>;
export type InstancesGetResponseStepsItemCase0AttemptsList = Array<InstancesGetResponseStepsItemCase0AttemptsItem>;
export declare const InstancesGetResponseStepsItemCase0AttemptsList: S.Schema<InstancesGetResponseStepsItemCase0AttemptsList>;
export type InstancesGetResponseStepsItemCase0ConfigRetriesDelay = string | number;
export declare const InstancesGetResponseStepsItemCase0ConfigRetriesDelay: any;
export type InstancesGetResponseStepsItemCase0ConfigRetriesBackoff = "constant" | "linear" | "exponential";
export declare const InstancesGetResponseStepsItemCase0ConfigRetriesBackoff: any;
export interface InstancesGetResponseStepsItemCase0ConfigRetries {
    /** Specifies the delay duration. '[dynamic]' indicates the delay is computed by a user-supplied function. */
    delay: InstancesGetResponseStepsItemCase0ConfigRetriesDelay;
    limit: number;
    backoff?: InstancesGetResponseStepsItemCase0ConfigRetriesBackoff | null;
}
export declare const InstancesGetResponseStepsItemCase0ConfigRetries: S.Schema<InstancesGetResponseStepsItemCase0ConfigRetries>;
export type InstancesGetResponseStepsItemCase0ConfigTimeout = string | number;
export declare const InstancesGetResponseStepsItemCase0ConfigTimeout: any;
export type InstancesGetResponseStepsItemCase0ConfigSensitive = "output";
export declare const InstancesGetResponseStepsItemCase0ConfigSensitive: any;
export interface InstancesGetResponseStepsItemCase0Config {
    retries: InstancesGetResponseStepsItemCase0ConfigRetries;
    /** Specifies the timeout duration. */
    timeout: InstancesGetResponseStepsItemCase0ConfigTimeout;
    /** When set to 'output', step output is redacted from log and step output responses. */
    sensitive?: InstancesGetResponseStepsItemCase0ConfigSensitive | null;
}
export declare const InstancesGetResponseStepsItemCase0Config: S.Schema<InstancesGetResponseStepsItemCase0Config>;
export type InstancesGetResponseStepsItemCase0Type = "step" | "rollback";
export declare const InstancesGetResponseStepsItemCase0Type: any;
export interface InstancesGetResponseStepsItemCase0 {
    attempts: InstancesGetResponseStepsItemCase0AttemptsList;
    config: InstancesGetResponseStepsItemCase0Config;
    end: string;
    name: string;
    output: string;
    start: string;
    success: boolean;
    type: InstancesGetResponseStepsItemCase0Type;
}
export declare const InstancesGetResponseStepsItemCase0: S.Schema<InstancesGetResponseStepsItemCase0>;
export type InstancesGetResponseStepsItemCase1Error = InstancesGetResponseError;
export declare const InstancesGetResponseStepsItemCase1Error: S.Schema<InstancesGetResponseError>;
export type InstancesGetResponseStepsItemCase1Type = "sleep";
export declare const InstancesGetResponseStepsItemCase1Type: any;
export interface InstancesGetResponseStepsItemCase1 {
    end: string;
    error: InstancesGetResponseError;
    finished: boolean;
    name: string;
    start: string;
    type: InstancesGetResponseStepsItemCase1Type;
}
export declare const InstancesGetResponseStepsItemCase1: S.Schema<InstancesGetResponseStepsItemCase1>;
export interface InstancesGetResponseStepsItemCase2Trigger {
    source: string;
}
export declare const InstancesGetResponseStepsItemCase2Trigger: S.Schema<InstancesGetResponseStepsItemCase2Trigger>;
export type InstancesGetResponseStepsItemCase2Type = "termination";
export declare const InstancesGetResponseStepsItemCase2Type: any;
export interface InstancesGetResponseStepsItemCase2 {
    trigger: InstancesGetResponseStepsItemCase2Trigger;
    type: InstancesGetResponseStepsItemCase2Type;
}
export declare const InstancesGetResponseStepsItemCase2: S.Schema<InstancesGetResponseStepsItemCase2>;
export type InstancesGetResponseStepsItemCase3Error = InstancesGetResponseError;
export declare const InstancesGetResponseStepsItemCase3Error: S.Schema<InstancesGetResponseError>;
export type InstancesGetResponseStepsItemCase3Type = "waitForEvent";
export declare const InstancesGetResponseStepsItemCase3Type: any;
export interface InstancesGetResponseStepsItemCase3 {
    end: string;
    error: InstancesGetResponseError;
    finished: boolean;
    name: string;
    start: string;
    type: InstancesGetResponseStepsItemCase3Type;
    output?: string | null;
}
export declare const InstancesGetResponseStepsItemCase3: S.Schema<InstancesGetResponseStepsItemCase3>;
export type InstancesGetResponseStepsItem = InstancesGetResponseStepsItemCase0 | InstancesGetResponseStepsItemCase1 | InstancesGetResponseStepsItemCase2 | InstancesGetResponseStepsItemCase3;
export declare const InstancesGetResponseStepsItem: any;
export type InstancesGetResponseStepsList = Array<InstancesGetResponseStepsItem>;
export declare const InstancesGetResponseStepsList: S.Schema<InstancesGetResponseStepsList>;
export type InstancesGetResponseTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
export declare const InstancesGetResponseTriggerSource: any;
export interface InstancesGetResponseTrigger {
    source: InstancesGetResponseTriggerSource;
}
export declare const InstancesGetResponseTrigger: S.Schema<InstancesGetResponseTrigger>;
export interface InstancesGetResponseSchedule {
    cron: string;
    scheduledTime: number;
}
export declare const InstancesGetResponseSchedule: S.Schema<InstancesGetResponseSchedule>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetInstanceResponse {
    end: string;
    error: InstancesGetResponseError;
    output: InstancesGetResponseOutput;
    params: unknown;
    queued: string;
    rollback: InstancesGetResponseRollback;
    start: string;
    status: InstancesGetResponseStatus;
    stepCount: number;
    steps: InstancesGetResponseStepsList;
    success: boolean;
    trigger: InstancesGetResponseTrigger;
    versionId: string;
    schedule?: InstancesGetResponseSchedule | null;
}
export declare const GetInstanceResponse: S.Schema<GetInstanceResponse>;
export interface GetVersionRequest {
    accountId: string;
    workflowName: string;
    versionId: string;
}
export declare const GetVersionRequest: S.Schema<GetVersionRequest>;
export type VersionsGetResponseLanguage = "javascript" | "python";
export declare const VersionsGetResponseLanguage: any;
export interface VersionsGetResponseLimits {
    steps?: number | null;
}
export declare const VersionsGetResponseLimits: S.Schema<VersionsGetResponseLimits>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetVersionResponse {
    id: string;
    className: string;
    createdOn: string;
    hasDag: boolean;
    /** The programming language of the workflow implementation */
    language: VersionsGetResponseLanguage;
    modifiedOn: string;
    workflowId: string;
    limits?: VersionsGetResponseLimits | null;
}
export declare const GetVersionResponse: S.Schema<GetVersionResponse>;
export interface GetWorkflowRequest {
    accountId: string;
    workflowName: string;
}
export declare const GetWorkflowRequest: S.Schema<GetWorkflowRequest>;
export interface GetResponseInstances {
    complete?: number | null;
    errored?: number | null;
    paused?: number | null;
    queued?: number | null;
    rollingBack?: number | null;
    running?: number | null;
    terminated?: number | null;
    waiting?: number | null;
    waitingForPause?: number | null;
}
export declare const GetResponseInstances: S.Schema<GetResponseInstances>;
export interface GetResponseSchedulesItem {
    cron: string;
    nextInstance: string;
}
export declare const GetResponseSchedulesItem: S.Schema<GetResponseSchedulesItem>;
export type GetResponseSchedulesList = Array<GetResponseSchedulesItem>;
export declare const GetResponseSchedulesList: S.Schema<GetResponseSchedulesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWorkflowResponse {
    id: string;
    className: string;
    createdOn: string;
    instances: GetResponseInstances;
    modifiedOn: string;
    name: string;
    scriptName: string;
    triggeredOn: string;
    schedules?: GetResponseSchedulesList | null;
}
export declare const GetWorkflowResponse: S.Schema<GetWorkflowResponse>;
export interface GraphVersionRequest {
    accountId: string;
    workflowName: string;
    versionId: string;
}
export declare const GraphVersionRequest: S.Schema<GraphVersionRequest>;
export type VersionsGraphResponseGraphWorkflowFunctionsValueNodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowFunctionsValueNodesList: S.Schema<VersionsGraphResponseGraphWorkflowFunctionsValueNodesList>;
export type VersionsGraphResponseGraphWorkflowFunctionsValueType = "function_def";
export declare const VersionsGraphResponseGraphWorkflowFunctionsValueType: any;
export interface VersionsGraphResponseGraphWorkflowFunctionsValue {
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowFunctionsValueNodesList;
    type: VersionsGraphResponseGraphWorkflowFunctionsValueType;
}
export declare const VersionsGraphResponseGraphWorkflowFunctionsValue: S.Schema<VersionsGraphResponseGraphWorkflowFunctionsValue>;
export type VersionsGraphResponseGraphWorkflowFunctionsMap = {
    [key: string]: VersionsGraphResponseGraphWorkflowFunctionsValue | undefined;
};
export declare const VersionsGraphResponseGraphWorkflowFunctionsMap: S.Schema<VersionsGraphResponseGraphWorkflowFunctionsMap>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase0Duration = string | number;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase0Duration: any;
export type VersionsGraphResponseGraphWorkflowNodesItemCase0Type = "step_sleep";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase0Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase0 {
    /** Duration as milliseconds (number) or human-readable string. */
    duration: VersionsGraphResponseGraphWorkflowNodesItemCase0Duration;
    name: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase0Type;
    resolves?: number | null;
    starts?: number | null;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase0: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase0>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesBackoff = "constant" | "linear" | "exponential";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesBackoff: any;
export type VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesDelay = string | number;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesDelay: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetries {
    /** Backoff strategy for step retries. */
    backoff: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesBackoff;
    /** Duration as milliseconds (number) or human-readable string. */
    delay: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetriesDelay;
    limit: number;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetries: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetries>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigTimeout = string | number;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigTimeout: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase1Config {
    /** Retry policy for a step. */
    retries: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigRetries;
    /** Duration as milliseconds (number) or human-readable string. */
    timeout: VersionsGraphResponseGraphWorkflowNodesItemCase1ConfigTimeout;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1Config: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase1Config>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase1NodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1NodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase1NodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase1Type = "step_do";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase1 {
    /** Configuration for a step (retries and timeout). */
    config: VersionsGraphResponseGraphWorkflowNodesItemCase1Config;
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase1NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase1Type;
    resolves?: number | null;
    starts?: number | null;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase1: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase1>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase2OptionsTimeout = string | number;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2OptionsTimeout: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2Options {
    eventType: string;
    /** Duration as milliseconds (number) or human-readable string. */
    timeout: VersionsGraphResponseGraphWorkflowNodesItemCase2OptionsTimeout;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2Options: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase2Options>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase2Type = "step_wait_for_event";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2Type: any;
export type VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadTypeType = "unknown";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadTypeType: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadType {
    type: VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadTypeType;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadType: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadType>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1FieldsMap = {
    [key: string]: unknown | undefined;
};
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1FieldsMap: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1FieldsMap>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1Type = "object";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1 {
    /** Nested JsonShape fields (recursive structure). */
    fields: VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1FieldsMap;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase2Payload = VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadType | VersionsGraphResponseGraphWorkflowNodesItemCase2PayloadCase1;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2Payload: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase2 {
    name: string;
    /** Options for a waitForEvent step. */
    options: VersionsGraphResponseGraphWorkflowNodesItemCase2Options;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase2Type;
    /** Shape descriptor for JSON payloads. */
    payload?: VersionsGraphResponseGraphWorkflowNodesItemCase2Payload | null;
    resolves?: number | null;
    starts?: number | null;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase2: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase2>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase3Type = "step_sleep_until";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase3Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase3 {
    name: string;
    timestamp: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase3Type;
    resolves?: number | null;
    starts?: number | null;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase3: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase3>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase4NodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase4NodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase4NodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase4Type = "loop";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase4Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase4 {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase4NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase4Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase4: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase4>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase5Kind = "all" | "any" | "all_settled" | "race";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase5Kind: any;
export type VersionsGraphResponseGraphWorkflowNodesItemCase5NodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase5NodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase5NodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase5Type = "parallel";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase5Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase5 {
    /** Parallel execution strategy. */
    kind: VersionsGraphResponseGraphWorkflowNodesItemCase5Kind;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase5NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase5Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase5: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase5>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockNodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockNodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockNodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockType = "block";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockType: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlock {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlockType;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlock: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlock>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockNodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockNodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockNodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockType = "block";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockType: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlock {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlockType;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlock: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlock>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockNodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockNodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockNodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockType = "block";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockType: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlock {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlockType;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlock: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlock>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase6Type = "try";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase6 {
    catchBlock: VersionsGraphResponseGraphWorkflowNodesItemCase6CatchBlock;
    finallyBlock: VersionsGraphResponseGraphWorkflowNodesItemCase6FinallyBlock;
    tryBlock: VersionsGraphResponseGraphWorkflowNodesItemCase6TryBlock;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase6Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase6: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase6>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase7NodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase7NodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase7NodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase7Type = "block";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase7Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase7 {
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase7NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase7Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase7: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase7>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItemNodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItemNodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItemNodesList>;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItem {
    condition: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItemNodesList;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItem: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItem>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesList = Array<VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesItem>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase8Type = "if";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase8Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase8 {
    branches: VersionsGraphResponseGraphWorkflowNodesItemCase8BranchesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase8Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase8: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase8>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItemNodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItemNodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItemNodesList>;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItem {
    condition: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItemNodesList;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItem: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItem>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesList = Array<VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesItem>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase9Type = "switch";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase9Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase9 {
    branches: VersionsGraphResponseGraphWorkflowNodesItemCase9BranchesList;
    discriminant: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase9Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase9: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase9>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueNodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueNodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueNodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueType = "function_def";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueType: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValue {
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueNodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValueType;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValue: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValue>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsMap = {
    [key: string]: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsValue | undefined;
};
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsMap: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsMap>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10NodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10NodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10NodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10Type = "start";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10Type: any;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadTypeType = "unknown";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadTypeType: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadType {
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadTypeType;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadType: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadType>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1FieldsMap = {
    [key: string]: unknown | undefined;
};
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1FieldsMap: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1FieldsMap>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1Type = "object";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1 {
    /** Nested JsonShape fields (recursive structure). */
    fields: VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1FieldsMap;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase10Payload = VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadType | VersionsGraphResponseGraphWorkflowNodesItemCase10PayloadCase1;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10Payload: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase10 {
    className: string;
    functions: VersionsGraphResponseGraphWorkflowNodesItemCase10FunctionsMap;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase10NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase10Type;
    /** Shape descriptor for JSON payloads. */
    payload?: VersionsGraphResponseGraphWorkflowNodesItemCase10Payload | null;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase10: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase10>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase11Type = "function_call";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase11Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase11 {
    name: string;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase11Type;
    resolves?: number | null;
    starts?: number | null;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase11: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase11>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase12NodesList = Array<unknown>;
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase12NodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase12NodesList>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase12Type = "function_def";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase12Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase12 {
    name: string;
    /** Child nodes (recursive). */
    nodes: VersionsGraphResponseGraphWorkflowNodesItemCase12NodesList;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase12Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase12: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase12>;
export type VersionsGraphResponseGraphWorkflowNodesItemCase13Kind = "break" | "return";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase13Kind: any;
export type VersionsGraphResponseGraphWorkflowNodesItemCase13Type = "break";
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase13Type: any;
export interface VersionsGraphResponseGraphWorkflowNodesItemCase13 {
    /** Break or return from a loop. */
    kind: VersionsGraphResponseGraphWorkflowNodesItemCase13Kind;
    type: VersionsGraphResponseGraphWorkflowNodesItemCase13Type;
}
export declare const VersionsGraphResponseGraphWorkflowNodesItemCase13: S.Schema<VersionsGraphResponseGraphWorkflowNodesItemCase13>;
export type VersionsGraphResponseGraphWorkflowNodesItem = VersionsGraphResponseGraphWorkflowNodesItemCase0 | VersionsGraphResponseGraphWorkflowNodesItemCase1 | VersionsGraphResponseGraphWorkflowNodesItemCase2 | VersionsGraphResponseGraphWorkflowNodesItemCase3 | VersionsGraphResponseGraphWorkflowNodesItemCase4 | VersionsGraphResponseGraphWorkflowNodesItemCase5 | VersionsGraphResponseGraphWorkflowNodesItemCase6 | VersionsGraphResponseGraphWorkflowNodesItemCase7 | VersionsGraphResponseGraphWorkflowNodesItemCase8 | VersionsGraphResponseGraphWorkflowNodesItemCase9 | VersionsGraphResponseGraphWorkflowNodesItemCase10 | VersionsGraphResponseGraphWorkflowNodesItemCase11 | VersionsGraphResponseGraphWorkflowNodesItemCase12 | VersionsGraphResponseGraphWorkflowNodesItemCase13;
export declare const VersionsGraphResponseGraphWorkflowNodesItem: any;
export type VersionsGraphResponseGraphWorkflowNodesList = Array<VersionsGraphResponseGraphWorkflowNodesItem>;
export declare const VersionsGraphResponseGraphWorkflowNodesList: S.Schema<VersionsGraphResponseGraphWorkflowNodesList>;
export type VersionsGraphResponseGraphWorkflowPayloadTypeType = "unknown";
export declare const VersionsGraphResponseGraphWorkflowPayloadTypeType: any;
export interface VersionsGraphResponseGraphWorkflowPayloadType {
    type: VersionsGraphResponseGraphWorkflowPayloadTypeType;
}
export declare const VersionsGraphResponseGraphWorkflowPayloadType: S.Schema<VersionsGraphResponseGraphWorkflowPayloadType>;
export type VersionsGraphResponseGraphWorkflowPayloadCase1FieldsMap = {
    [key: string]: unknown | undefined;
};
export declare const VersionsGraphResponseGraphWorkflowPayloadCase1FieldsMap: S.Schema<VersionsGraphResponseGraphWorkflowPayloadCase1FieldsMap>;
export type VersionsGraphResponseGraphWorkflowPayloadCase1Type = "object";
export declare const VersionsGraphResponseGraphWorkflowPayloadCase1Type: any;
export interface VersionsGraphResponseGraphWorkflowPayloadCase1 {
    /** Nested JsonShape fields (recursive structure). */
    fields: VersionsGraphResponseGraphWorkflowPayloadCase1FieldsMap;
    type: VersionsGraphResponseGraphWorkflowPayloadCase1Type;
}
export declare const VersionsGraphResponseGraphWorkflowPayloadCase1: S.Schema<VersionsGraphResponseGraphWorkflowPayloadCase1>;
export type VersionsGraphResponseGraphWorkflowPayload = VersionsGraphResponseGraphWorkflowPayloadType | VersionsGraphResponseGraphWorkflowPayloadCase1;
export declare const VersionsGraphResponseGraphWorkflowPayload: any;
export interface VersionsGraphResponseGraphWorkflow {
    className: string;
    functions: VersionsGraphResponseGraphWorkflowFunctionsMap;
    nodes: VersionsGraphResponseGraphWorkflowNodesList;
    /** Shape descriptor for JSON payloads. */
    payload?: VersionsGraphResponseGraphWorkflowPayload | null;
}
export declare const VersionsGraphResponseGraphWorkflow: S.Schema<VersionsGraphResponseGraphWorkflow>;
export interface VersionsGraphResponseGraph {
    version: number;
    /** A parsed workflow entrypoint with its step graph. */
    workflow: VersionsGraphResponseGraphWorkflow;
}
export declare const VersionsGraphResponseGraph: S.Schema<VersionsGraphResponseGraph>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GraphVersionResponse {
    id: string;
    className: string;
    createdOn: string;
    /** Versioned workflow graph payload. */
    graph: VersionsGraphResponseGraph;
    modifiedOn: string;
    workflowId: string;
}
export declare const GraphVersionResponse: S.Schema<GraphVersionResponse>;
export type InstancesListRequestDirection = "asc" | "desc";
export declare const InstancesListRequestDirection: any;
export type InstancesListRequestStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export declare const InstancesListRequestStatus: any;
export interface ListInstancesRequest {
    accountId: string;
    workflowName: string;
    /** Opaque token for cursor-based pagination. Mutually exclusive with `page`. */
    cursor?: string;
    /** Accepts ISO 8601 with no timezone offsets and in UTC. */
    dateEnd?: string;
    /** Accepts ISO 8601 with no timezone offsets and in UTC. */
    dateStart?: string;
    /** Defines the direction for cursor-based pagination. */
    direction?: InstancesListRequestDirection | (string & {});
    /** Deprecated: use `cursor` for pagination instead. */
    page?: number;
    perPage?: number;
    status?: InstancesListRequestStatus | (string & {});
}
export declare const ListInstancesRequest: S.Schema<ListInstancesRequest>;
export type InstancesListResultItemStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export declare const InstancesListResultItemStatus: any;
export type InstancesListResultItemTriggerSource = "unknown" | "api" | "binding" | "event" | "cron";
export declare const InstancesListResultItemTriggerSource: any;
export interface InstancesListResultItem {
    id: string;
    createdOn: string;
    endedOn: string;
    modifiedOn: string;
    startedOn: string;
    status: InstancesListResultItemStatus;
    versionId: string;
    workflowId: string;
    triggerSource?: InstancesListResultItemTriggerSource | null;
}
export declare const InstancesListResultItem: S.Schema<InstancesListResultItem>;
export type InstancesListResultList = Array<InstancesListResultItem>;
export declare const InstancesListResultList: S.Schema<InstancesListResultList>;
export interface ListInstancesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: InstancesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListInstancesResponse: S.Schema<ListInstancesResponse>;
export interface ListVersionsRequest {
    accountId: string;
    workflowName: string;
    page?: number;
    perPage?: number;
}
export declare const ListVersionsRequest: S.Schema<ListVersionsRequest>;
export type VersionsListResultItemLanguage = "javascript" | "python";
export declare const VersionsListResultItemLanguage: any;
export type VersionsListResultItemLimits = VersionsGetResponseLimits;
export declare const VersionsListResultItemLimits: S.Schema<VersionsGetResponseLimits>;
export interface VersionsListResultItem {
    id: string;
    className: string;
    createdOn: string;
    hasDag: boolean;
    /** The programming language of the workflow implementation */
    language: VersionsListResultItemLanguage;
    modifiedOn: string;
    workflowId: string;
    limits?: VersionsGetResponseLimits | null;
}
export declare const VersionsListResultItem: S.Schema<VersionsListResultItem>;
export type VersionsListResultList = Array<VersionsListResultItem>;
export declare const VersionsListResultList: S.Schema<VersionsListResultList>;
export interface ListVersionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: VersionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListVersionsResponse: S.Schema<ListVersionsResponse>;
export interface ListWorkflowsRequest {
    accountId: string;
    page?: number;
    perPage?: number;
    /** Allows filtering workflows` name. */
    search?: string;
}
export declare const ListWorkflowsRequest: S.Schema<ListWorkflowsRequest>;
export type ListResultItemInstances = GetResponseInstances;
export declare const ListResultItemInstances: S.Schema<GetResponseInstances>;
export type ListResultItemSchedulesItem = GetResponseSchedulesItem;
export declare const ListResultItemSchedulesItem: S.Schema<GetResponseSchedulesItem>;
export type ListResultItemSchedulesList = Array<GetResponseSchedulesItem>;
export declare const ListResultItemSchedulesList: S.Schema<ListResultItemSchedulesList>;
export interface ListResultItem {
    id: string;
    className: string;
    createdOn: string;
    instances: GetResponseInstances;
    modifiedOn: string;
    name: string;
    scriptName: string;
    triggeredOn: string;
    schedules?: ListResultItemSchedulesList | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListWorkflowsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListWorkflowsResponse: S.Schema<ListWorkflowsResponse>;
export type InstancesStatusEditRequestStatus = "pause" | "resume" | "terminate" | "restart";
export declare const InstancesStatusEditRequestStatus: any;
export type InstancesStatusEditRequestFromType = "do" | "sleep" | "waitForEvent";
export declare const InstancesStatusEditRequestFromType: any;
export interface InstancesStatusEditRequestFrom {
    name: string;
    count?: number;
    type?: InstancesStatusEditRequestFromType | (string & {});
}
export declare const InstancesStatusEditRequestFrom: S.Schema<InstancesStatusEditRequestFrom>;
export interface PatchInstanceStatusRequest {
    accountId: string;
    workflowName: string;
    /** Instance identifier. User-created instances match `^[a-zA-Z0-9_][a-zA-Z0-9-_]*$` (max 100 characters); cron-triggered instances can use a longer, system-generated id derived from the cron expression. */
    instanceId: string;
    status?: InstancesStatusEditRequestStatus | (string & {});
    /** Run rollback before terminating. */
    rollback?: boolean;
    /** Step to restart from. */
    from?: InstancesStatusEditRequestFrom;
}
export declare const PatchInstanceStatusRequest: S.Schema<PatchInstanceStatusRequest>;
export type InstancesStatusEditResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export declare const InstancesStatusEditResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchInstanceStatusResponse {
    status: InstancesStatusEditResponseStatus;
    /** Accepts ISO 8601 with no timezone offsets and in UTC. */
    timestamp: string;
}
export declare const PatchInstanceStatusResponse: S.Schema<PatchInstanceStatusResponse>;
export interface UpdateRequestLimits {
    steps?: number;
}
export declare const UpdateRequestLimits: S.Schema<UpdateRequestLimits>;
export interface UpdateRequestSchedulesItem {
    cron: string;
}
export declare const UpdateRequestSchedulesItem: S.Schema<UpdateRequestSchedulesItem>;
export type UpdateRequestSchedulesList = Array<UpdateRequestSchedulesItem>;
export declare const UpdateRequestSchedulesList: S.Schema<UpdateRequestSchedulesList>;
export interface PutWorkflowRequest {
    accountId: string;
    workflowName: string;
    className: string;
    scriptName: string;
    limits?: UpdateRequestLimits;
    schedules?: UpdateRequestSchedulesList;
}
export declare const PutWorkflowRequest: S.Schema<PutWorkflowRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutWorkflowResponse {
    id: string;
    className: string;
    createdOn: string;
    isDeleted: number;
    modifiedOn: string;
    name: string;
    scriptName: string;
    terminatorRunning: number;
    triggeredOn: string;
    versionId: string;
}
export declare const PutWorkflowResponse: S.Schema<PutWorkflowResponse>;
export type InstancesStepRequestType = "step" | "waitForEvent";
export declare const InstancesStepRequestType: any;
export interface StepInstanceRequest {
    accountId: string;
    workflowName: string;
    /** Instance identifier. User-created instances match `^[a-zA-Z0-9_][a-zA-Z0-9-_]*$` (max 100 characters); cron-triggered instances can use a longer, system-generated id derived from the cron expression. */
    instanceId: string;
    /** Exact step name from the instance logs response, including the generated counter suffix. */
    name: string;
    /** Step type to disambiguate step.do and waitForEvent entries that share the same name. */
    type: InstancesStepRequestType | (string & {});
    /** Specific attempt number to retrieve output or error for. */
    attempt?: number;
}
export declare const StepInstanceRequest: S.Schema<StepInstanceRequest>;
export type InstancesStepResponseError = InstancesGetResponseError;
export declare const InstancesStepResponseError: S.Schema<InstancesGetResponseError>;
export type InstancesStepResponseStatus = "queued" | "running" | "paused" | "errored" | "terminated" | "complete" | "waitingForPause" | "waiting" | "rollingBack";
export declare const InstancesStepResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StepInstanceResponse {
    /** Error details when status='errored'; null otherwise. */
    error: InstancesGetResponseError;
    status: InstancesStepResponseStatus;
    /** Full step output or waitForEvent payload without truncation. Sensitive outputs are returned as '[REDACTED]'. Populated when status='complete'. May be a ReadableStream when the step returned one from step.do; stream outputs are served as application/octet-stream rather than JSON. */
    output?: unknown | null;
}
export declare const StepInstanceResponse: S.Schema<StepInstanceResponse>;
export type BulkInstanceError = WorkflowNotFound | InstanceAlreadyExists | InvalidRoute | InvalidBody | CloudflareOpError;
/** Creates multiple workflow instances in a single batch operation. */
export declare const bulkInstance: API.PaginatedOperationMethod<BulkInstanceRequest, BulkInstanceResponse, BulkInstanceError, CloudflareOpContext, InstancesBulkResultItem>;
export type CreateInstanceError = WorkflowNotFound | InstanceAlreadyExists | InvalidRoute | InvalidBody | CloudflareOpError;
/** Creates a new instance of a workflow, starting its execution. */
export declare const createInstance: API.OperationMethod<CreateInstanceRequest, CreateInstanceResponse, CreateInstanceError, CloudflareOpContext>;
export type CreateInstanceEventError = WorkflowNotFound | InvalidRoute | InstanceNotFound | InvalidBody | CloudflareOpError;
/** Sends an event to a running workflow instance to trigger state transitions. */
export declare const createInstanceEvent: API.OperationMethod<CreateInstanceEventRequest, CreateInstanceEventResponse, CreateInstanceEventError, CloudflareOpContext>;
export type DeleteWorkflowError = WorkflowNotFound | InvalidRoute | CloudflareOpError;
/** Deletes a Workflow. This only deletes the Workflow and does not delete or modify any Worker associated to this Workflow or bounded to it. */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest, DeleteWorkflowResponse, DeleteWorkflowError, CloudflareOpContext>;
export type GetInstanceError = WorkflowNotFound | InvalidRoute | InstanceNotFound | CloudflareOpError;
/** Retrieves logs and execution status for a specific workflow instance. */
export declare const getInstance: API.OperationMethod<GetInstanceRequest, GetInstanceResponse, GetInstanceError, CloudflareOpContext>;
export type GetVersionError = WorkflowNotFound | InvalidRoute | VersionNotFound | CloudflareOpError;
/** Retrieves details for a specific deployed workflow version. */
export declare const getVersion: API.OperationMethod<GetVersionRequest, GetVersionResponse, GetVersionError, CloudflareOpContext>;
export type GetWorkflowError = WorkflowNotFound | InvalidRoute | CloudflareOpError;
/** Retrieves configuration and metadata for a specific workflow. */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, GetWorkflowResponse, GetWorkflowError, CloudflareOpContext>;
export type GraphVersionError = CloudflareOpError;
/** Retrieves the graph visualization of a workflow version. */
export declare const graphVersion: API.OperationMethod<GraphVersionRequest, GraphVersionResponse, GraphVersionError, CloudflareOpContext>;
export type ListInstancesError = WorkflowNotFound | WorkflowInternalError | InvalidRoute | InvalidBody | CloudflareOpError;
/** Lists all instances of a workflow with their execution status. */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest, ListInstancesResponse, ListInstancesError, CloudflareOpContext, InstancesListResultItem>;
export type ListVersionsError = WorkflowNotFound | InvalidRoute | CloudflareOpError;
/** Lists all deployed versions of a workflow. */
export declare const listVersions: API.PaginatedOperationMethod<ListVersionsRequest, ListVersionsResponse, ListVersionsError, CloudflareOpContext, VersionsListResultItem>;
export type ListWorkflowsError = CloudflareOpError;
/** Lists all workflows configured for the account. */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest, ListWorkflowsResponse, ListWorkflowsError, CloudflareOpContext, ListResultItem>;
export type PatchInstanceStatusError = WorkflowNotFound | InvalidRoute | InstanceNotFound | InstanceCannotTerminate | CloudflareOpError;
/** Changes the execution status of a workflow instance (e.g., pause, resume, terminate). */
export declare const patchInstanceStatus: API.OperationMethod<PatchInstanceStatusRequest, PatchInstanceStatusResponse, PatchInstanceStatusError, CloudflareOpContext>;
export type PutWorkflowError = WorkflowInternalError | InvalidRoute | CloudflareOpError;
/** Creates a new workflow or updates an existing workflow definition. */
export declare const putWorkflow: API.OperationMethod<PutWorkflowRequest, PutWorkflowResponse, PutWorkflowError, CloudflareOpContext>;
export type StepInstanceError = CloudflareOpError;
/** Retrieves the full, untruncated output for a specific step on a workflow instance. Returns a flat status-shaped JSON body with step `status` ('running' | 'waiting' | 'complete' | 'errored'), `error` (nullable), and `output` (the step value, or null while running/waiting/errored). When the step returned a ReadableStream from step.do, the response is served as 'application/octet-stream' with the raw bytes as the body instead of JSON. A `status='running'` response with non-null `error` indicates the step is currently retrying after a prior attempt failed. */
export declare const stepInstance: API.OperationMethod<StepInstanceRequest, StepInstanceResponse, StepInstanceError, CloudflareOpContext>;
//# sourceMappingURL=workflows.d.ts.map