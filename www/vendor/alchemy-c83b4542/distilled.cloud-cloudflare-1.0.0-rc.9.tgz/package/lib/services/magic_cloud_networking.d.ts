import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const CatalogSyncNotFound_base: S.Class<CatalogSyncNotFound, S.TaggedStruct<"CatalogSyncNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CatalogSyncNotFound extends /*@__PURE__*/ CatalogSyncNotFound_base {
}
declare const CloudIntegrationNotFound_base: S.Class<CloudIntegrationNotFound, S.TaggedStruct<"CloudIntegrationNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CloudIntegrationNotFound extends /*@__PURE__*/ CloudIntegrationNotFound_base {
}
declare const FeatureNotEnabled_base: S.Class<FeatureNotEnabled, S.TaggedStruct<"FeatureNotEnabled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class FeatureNotEnabled extends /*@__PURE__*/ FeatureNotEnabled_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const OnRampNotFound_base: S.Class<OnRampNotFound, S.TaggedStruct<"OnRampNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class OnRampNotFound extends /*@__PURE__*/ OnRampNotFound_base {
}
export interface ApplyOnRampRequest {
    accountId: string;
    onrampId: string;
}
export declare const ApplyOnRampRequest: S.Schema<ApplyOnRampRequest>;
export interface ApplyOnRampResponse {
}
export declare const ApplyOnRampResponse: S.Schema<ApplyOnRampResponse>;
export type CatalogSyncsCreateRequestDestinationType = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsCreateRequestDestinationType: any;
export type CatalogSyncsCreateRequestUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsCreateRequestUpdateMode: any;
export interface CreateCatalogSyncRequest {
    accountId: string;
    forwarded?: string;
    destinationType: CatalogSyncsCreateRequestDestinationType | (string & {});
    name: string;
    updateMode: CatalogSyncsCreateRequestUpdateMode | (string & {});
    description?: string;
    policy?: string;
}
export declare const CreateCatalogSyncRequest: S.Schema<CreateCatalogSyncRequest>;
export type CatalogSyncsCreateResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsCreateResponseDestinationType: any;
export type CatalogSyncsCreateResponseUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsCreateResponseUpdateMode: any;
export type CatalogSyncsCreateResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const CatalogSyncsCreateResponseErrorsValueCode: any;
export interface CatalogSyncsCreateResponseErrorsValueMeta {
    l10nKey?: string | null;
    loggableError?: string | null;
    templateData?: unknown | null;
    traceId?: string | null;
}
export declare const CatalogSyncsCreateResponseErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export interface CatalogSyncsCreateResponseErrorsValueSource {
    parameter?: string | null;
    parameterValueIndex?: number | null;
    pointer?: string | null;
}
export declare const CatalogSyncsCreateResponseErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface CatalogSyncsCreateResponseErrorsValue {
    code: CatalogSyncsCreateResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const CatalogSyncsCreateResponseErrorsValue: S.Schema<CatalogSyncsCreateResponseErrorsValue>;
export type CatalogSyncsCreateResponseErrorsMap = {
    [key: string]: CatalogSyncsCreateResponseErrorsValue | undefined;
};
export declare const CatalogSyncsCreateResponseErrorsMap: S.Schema<CatalogSyncsCreateResponseErrorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsCreateResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsCreateResponseUpdateMode;
    errors?: CatalogSyncsCreateResponseErrorsMap | null;
    includesDiscoveriesUntil?: string | null;
    lastAttemptedUpdateAt?: string | null;
    lastSuccessfulUpdateAt?: string | null;
}
export declare const CreateCatalogSyncResponse: S.Schema<CreateCatalogSyncResponse>;
export type CloudIntegrationsCreateRequestCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const CloudIntegrationsCreateRequestCloudType: any;
export interface CreateCloudIntegrationRequest {
    accountId: string;
    forwarded?: string;
    cloudType: CloudIntegrationsCreateRequestCloudType | (string & {});
    friendlyName: string;
    description?: string;
}
export declare const CreateCloudIntegrationRequest: S.Schema<CreateCloudIntegrationRequest>;
export type CloudIntegrationsCreateResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const CloudIntegrationsCreateResponseCloudType: any;
export type CloudIntegrationsCreateResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export declare const CloudIntegrationsCreateResponseLifecycleState: any;
export type CloudIntegrationsCreateResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsCreateResponseState: any;
export type CloudIntegrationsCreateResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsCreateResponseStateV2: any;
export interface CloudIntegrationsCreateResponseStatusDiscoveryProgress {
    done: number;
    total: number;
    unit: string;
}
export declare const CloudIntegrationsCreateResponseStatusDiscoveryProgress: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsCreateResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsCreateResponseStatusDiscoveryProgressV2: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsCreateResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsCreateResponseStatusLastDiscoveryStatus: any;
export type CloudIntegrationsCreateResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsCreateResponseStatusLastDiscoveryStatusV2: any;
export type CloudIntegrationsCreateResponseStatusRegionsList = Array<string>;
export declare const CloudIntegrationsCreateResponseStatusRegionsList: S.Schema<CloudIntegrationsCreateResponseStatusRegionsList>;
export type CloudIntegrationsCreateResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const CloudIntegrationsCreateResponseStatusInUseByItemClientType: any;
export interface CloudIntegrationsCreateResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsCreateResponseStatusInUseByItemClientType;
    name: string;
}
export declare const CloudIntegrationsCreateResponseStatusInUseByItem: S.Schema<CloudIntegrationsCreateResponseStatusInUseByItem>;
export type CloudIntegrationsCreateResponseStatusInUseByList = Array<CloudIntegrationsCreateResponseStatusInUseByItem>;
export declare const CloudIntegrationsCreateResponseStatusInUseByList: S.Schema<CloudIntegrationsCreateResponseStatusInUseByList>;
export interface CloudIntegrationsCreateResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsCreateResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsCreateResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsCreateResponseStatusRegionsList;
    credentialsGoodSince?: string | null;
    credentialsMissingSince?: string | null;
    credentialsRejectedSince?: string | null;
    discoveryMessage?: string | null;
    discoveryMessageV2?: string | null;
    inUseBy?: CloudIntegrationsCreateResponseStatusInUseByList | null;
    lastDiscoveryCompletedAt?: string | null;
    lastDiscoveryCompletedAtV2?: string | null;
    lastDiscoveryStartedAt?: string | null;
    lastDiscoveryStartedAtV2?: string | null;
    lastUpdated?: string | null;
}
export declare const CloudIntegrationsCreateResponseStatus: S.Schema<CloudIntegrationsCreateResponseStatus>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsCreateResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsCreateResponseLifecycleState;
    state: CloudIntegrationsCreateResponseState;
    stateV2: CloudIntegrationsCreateResponseStateV2;
    awsArn?: string | null;
    azureSubscriptionId?: string | null;
    azureTenantId?: string | null;
    description?: string | null;
    gcpProjectId?: string | null;
    gcpServiceAccountEmail?: string | null;
    status?: CloudIntegrationsCreateResponseStatus | null;
}
export declare const CreateCloudIntegrationResponse: S.Schema<CreateCloudIntegrationResponse>;
export type OnRampsCreateRequestCloudType = "AWS" | "AZURE" | "GOOGLE";
export declare const OnRampsCreateRequestCloudType: any;
export type OnRampsCreateRequestType = "OnrampTypeSingle" | "OnrampTypeHub";
export declare const OnRampsCreateRequestType: any;
export type OnRampsCreateRequestAttachedHubsList = Array<string>;
export declare const OnRampsCreateRequestAttachedHubsList: S.Schema<OnRampsCreateRequestAttachedHubsList>;
export type OnRampsCreateRequestAttachedVpcsList = Array<string>;
export declare const OnRampsCreateRequestAttachedVpcsList: S.Schema<OnRampsCreateRequestAttachedVpcsList>;
export interface CreateOnRampRequest {
    accountId: string;
    forwarded?: string;
    cloudType: OnRampsCreateRequestCloudType | (string & {});
    /** Enables BGP routing. When enabling this feature, set both install_routes_in_cloud and install_routes_in_magic_wan to false. */
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsCreateRequestType | (string & {});
    adoptedHubId?: string;
    attachedHubs?: OnRampsCreateRequestAttachedHubsList;
    attachedVpcs?: OnRampsCreateRequestAttachedVpcsList;
    /** Sets the cloud-side ASN. If unset or zero, the cloud's default ASN takes effect. */
    cloudAsn?: number;
    description?: string;
    hubProviderId?: string;
    manageHubToHubAttachments?: boolean;
    manageVpcToHubAttachments?: boolean;
    region?: string;
    vpc?: string;
}
export declare const CreateOnRampRequest: S.Schema<CreateOnRampRequest>;
export type OnRampsCreateResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export declare const OnRampsCreateResponseCloudType: any;
export type OnRampsCreateResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export declare const OnRampsCreateResponseType: any;
export type OnRampsCreateResponseAttachedHubsList = Array<string>;
export declare const OnRampsCreateResponseAttachedHubsList: S.Schema<OnRampsCreateResponseAttachedHubsList>;
export type OnRampsCreateResponseAttachedVpcsList = Array<string>;
export declare const OnRampsCreateResponseAttachedVpcsList: S.Schema<OnRampsCreateResponseAttachedVpcsList>;
export interface OnRampsCreateResponsePlannedMonthlyCostEstimate {
    currency: string;
    currentMonthlyCost: number;
    diff: number;
    proposedMonthlyCost: number;
}
export declare const OnRampsCreateResponsePlannedMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export interface OnRampsCreateResponsePlannedResourcesItemDiff {
    diff: string;
    leftDescription: string;
    leftYaml: string;
    rightDescription: string;
    rightYaml: string;
}
export declare const OnRampsCreateResponsePlannedResourcesItemDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsCreateResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export declare const OnRampsCreateResponsePlannedResourcesItemKeysRequireReplaceList: S.Schema<OnRampsCreateResponsePlannedResourcesItemKeysRequireReplaceList>;
export type OnRampsCreateResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsCreateResponsePlannedResourcesItemMonthlyCostEstimateDiff: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsCreateResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export declare const OnRampsCreateResponsePlannedResourcesItemPlannedAction: any;
export type OnRampsCreateResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponsePlannedResourcesItemResourceCloudType: any;
export type OnRampsCreateResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponsePlannedResourcesItemResourceResourceType: any;
export interface OnRampsCreateResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsCreateResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export declare const OnRampsCreateResponsePlannedResourcesItemResource: S.Schema<OnRampsCreateResponsePlannedResourcesItemResource>;
export interface OnRampsCreateResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsCreateResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsCreateResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsCreateResponsePlannedResourcesItemResource;
}
export declare const OnRampsCreateResponsePlannedResourcesItem: S.Schema<OnRampsCreateResponsePlannedResourcesItem>;
export type OnRampsCreateResponsePlannedResourcesList = Array<OnRampsCreateResponsePlannedResourcesItem>;
export declare const OnRampsCreateResponsePlannedResourcesList: S.Schema<OnRampsCreateResponsePlannedResourcesList>;
export interface OnRampsCreateResponsePostApplyMonthlyCostEstimate {
    currency: string;
    monthlyCost: number;
}
export declare const OnRampsCreateResponsePostApplyMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsCreateResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponsePostApplyResourcesValueCloudType: any;
export type OnRampsCreateResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsCreateResponsePostApplyResourcesValueConfigMap: S.Schema<OnRampsCreateResponsePostApplyResourcesValueConfigMap>;
export type OnRampsCreateResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsCreateResponsePostApplyResourcesValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export interface OnRampsCreateResponsePostApplyResourcesValueObservationsValue {
    firstObservedAt: string;
    lastObservedAt: string;
    providerId: string;
    resourceId: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsCreateResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsCreateResponsePostApplyResourcesValueObservationsMap: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsMap>;
export type OnRampsCreateResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export declare const OnRampsCreateResponsePostApplyResourcesValueProviderIdsList: S.Schema<OnRampsCreateResponsePostApplyResourcesValueProviderIdsList>;
export type OnRampsCreateResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsCreateResponsePostApplyResourcesValueProviderNamesByIdMap: S.Schema<OnRampsCreateResponsePostApplyResourcesValueProviderNamesByIdMap>;
export type OnRampsCreateResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponsePostApplyResourcesValueResourceType: any;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem {
    itemType: string;
    string: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem {
    itemType: string;
    yaml: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem {
    itemType: string;
    yamlDiff: OnRampsCreateResponsePlannedResourcesItemDiff;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsList: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsList>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsList: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsList>;
export interface OnRampsCreateResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsCreateResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsCreateResponsePostApplyResourcesValueSectionsList = Array<OnRampsCreateResponsePostApplyResourcesValueSectionsItem>;
export declare const OnRampsCreateResponsePostApplyResourcesValueSectionsList: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsList>;
export type OnRampsCreateResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsCreateResponsePostApplyResourcesValueStateMap: S.Schema<OnRampsCreateResponsePostApplyResourcesValueStateMap>;
export type OnRampsCreateResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsCreateResponsePostApplyResourcesValueTagsMap: S.Schema<OnRampsCreateResponsePostApplyResourcesValueTagsMap>;
export type OnRampsCreateResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsCreateResponsePostApplyResourcesValueManagedByItemClientType: any;
export interface OnRampsCreateResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsCreateResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsCreateResponsePostApplyResourcesValueManagedByItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueManagedByItem>;
export type OnRampsCreateResponsePostApplyResourcesValueManagedByList = Array<OnRampsCreateResponsePostApplyResourcesValueManagedByItem>;
export declare const OnRampsCreateResponsePostApplyResourcesValueManagedByList: S.Schema<OnRampsCreateResponsePostApplyResourcesValueManagedByList>;
export interface OnRampsCreateResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsCreateResponsePostApplyResourcesValueCloudType;
    config: OnRampsCreateResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsCreateResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsCreateResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsCreateResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsCreateResponsePostApplyResourcesValueResourceType;
    sections: OnRampsCreateResponsePostApplyResourcesValueSectionsList;
    state: OnRampsCreateResponsePostApplyResourcesValueStateMap;
    tags: OnRampsCreateResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsCreateResponsePostApplyResourcesValueManagedByList | null;
}
export declare const OnRampsCreateResponsePostApplyResourcesValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValue>;
export type OnRampsCreateResponsePostApplyResourcesMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValue | undefined;
};
export declare const OnRampsCreateResponsePostApplyResourcesMap: S.Schema<OnRampsCreateResponsePostApplyResourcesMap>;
export interface OnRampsCreateResponseStatusApplyProgress {
    done: number;
    total: number;
}
export declare const OnRampsCreateResponseStatusApplyProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsCreateResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export declare const OnRampsCreateResponseStatusLifecycleState: any;
export type OnRampsCreateResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsCreateResponseStatusPlanProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsCreateResponseStatusRoutesList = Array<string>;
export declare const OnRampsCreateResponseStatusRoutesList: S.Schema<OnRampsCreateResponseStatusRoutesList>;
export type OnRampsCreateResponseStatusTunnelsList = Array<string>;
export declare const OnRampsCreateResponseStatusTunnelsList: S.Schema<OnRampsCreateResponseStatusTunnelsList>;
export type OnRampsCreateResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const OnRampsCreateResponseStatusLifecycleErrorsValueCode: any;
export type OnRampsCreateResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const OnRampsCreateResponseStatusLifecycleErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type OnRampsCreateResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const OnRampsCreateResponseStatusLifecycleErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface OnRampsCreateResponseStatusLifecycleErrorsValue {
    code: OnRampsCreateResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const OnRampsCreateResponseStatusLifecycleErrorsValue: S.Schema<OnRampsCreateResponseStatusLifecycleErrorsValue>;
export type OnRampsCreateResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsCreateResponseStatusLifecycleErrorsValue | undefined;
};
export declare const OnRampsCreateResponseStatusLifecycleErrorsMap: S.Schema<OnRampsCreateResponseStatusLifecycleErrorsMap>;
export interface OnRampsCreateResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsCreateResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsCreateResponseStatusRoutesList;
    tunnels: OnRampsCreateResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsCreateResponseStatusLifecycleErrorsMap | null;
}
export declare const OnRampsCreateResponseStatus: S.Schema<OnRampsCreateResponseStatus>;
export type OnRampsCreateResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponseVpcsByIdValueCloudType: any;
export type OnRampsCreateResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsCreateResponseVpcsByIdValueConfigMap: S.Schema<OnRampsCreateResponseVpcsByIdValueConfigMap>;
export type OnRampsCreateResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsCreateResponseVpcsByIdValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsCreateResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsCreateResponseVpcsByIdValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsCreateResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsCreateResponseVpcsByIdValueObservationsMap: S.Schema<OnRampsCreateResponseVpcsByIdValueObservationsMap>;
export type OnRampsCreateResponseVpcsByIdValueProviderIdsList = Array<string>;
export declare const OnRampsCreateResponseVpcsByIdValueProviderIdsList: S.Schema<OnRampsCreateResponseVpcsByIdValueProviderIdsList>;
export type OnRampsCreateResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsCreateResponseVpcsByIdValueProviderNamesByIdMap: S.Schema<OnRampsCreateResponseVpcsByIdValueProviderNamesByIdMap>;
export type OnRampsCreateResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponseVpcsByIdValueResourceType: any;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsList: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsList>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsList: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsList>;
export interface OnRampsCreateResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsCreateResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsCreateResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsCreateResponseVpcsByIdValueSectionsItem: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsItem>;
export type OnRampsCreateResponseVpcsByIdValueSectionsList = Array<OnRampsCreateResponseVpcsByIdValueSectionsItem>;
export declare const OnRampsCreateResponseVpcsByIdValueSectionsList: S.Schema<OnRampsCreateResponseVpcsByIdValueSectionsList>;
export type OnRampsCreateResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsCreateResponseVpcsByIdValueStateMap: S.Schema<OnRampsCreateResponseVpcsByIdValueStateMap>;
export type OnRampsCreateResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsCreateResponseVpcsByIdValueTagsMap: S.Schema<OnRampsCreateResponseVpcsByIdValueTagsMap>;
export type OnRampsCreateResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsCreateResponseVpcsByIdValueManagedByItemClientType: any;
export interface OnRampsCreateResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsCreateResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsCreateResponseVpcsByIdValueManagedByItem: S.Schema<OnRampsCreateResponseVpcsByIdValueManagedByItem>;
export type OnRampsCreateResponseVpcsByIdValueManagedByList = Array<OnRampsCreateResponseVpcsByIdValueManagedByItem>;
export declare const OnRampsCreateResponseVpcsByIdValueManagedByList: S.Schema<OnRampsCreateResponseVpcsByIdValueManagedByList>;
export interface OnRampsCreateResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsCreateResponseVpcsByIdValueCloudType;
    config: OnRampsCreateResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsCreateResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsCreateResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsCreateResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsCreateResponseVpcsByIdValueResourceType;
    sections: OnRampsCreateResponseVpcsByIdValueSectionsList;
    state: OnRampsCreateResponseVpcsByIdValueStateMap;
    tags: OnRampsCreateResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsCreateResponseVpcsByIdValueManagedByList | null;
}
export declare const OnRampsCreateResponseVpcsByIdValue: S.Schema<OnRampsCreateResponseVpcsByIdValue>;
export type OnRampsCreateResponseVpcsByIdMap = {
    [key: string]: OnRampsCreateResponseVpcsByIdValue | undefined;
};
export declare const OnRampsCreateResponseVpcsByIdMap: S.Schema<OnRampsCreateResponseVpcsByIdMap>;
export type OnRampsCreateResponseVpcsByIdUnavailableList = Array<string>;
export declare const OnRampsCreateResponseVpcsByIdUnavailableList: S.Schema<OnRampsCreateResponseVpcsByIdUnavailableList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateOnRampResponse {
    id: string;
    cloudType: OnRampsCreateResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsCreateResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsCreateResponseAttachedHubsList | null;
    attachedVpcs?: OnRampsCreateResponseAttachedVpcsList | null;
    cloudAsn?: number | null;
    description?: string | null;
    hub?: string | null;
    lastAppliedAt?: string | null;
    lastExportedAt?: string | null;
    lastPlannedAt?: string | null;
    manageHubToHubAttachments?: boolean | null;
    manageVpcToHubAttachments?: boolean | null;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null;
    plannedResources?: OnRampsCreateResponsePlannedResourcesList | null;
    plannedResourcesUnavailable?: boolean | null;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null;
    postApplyResources?: OnRampsCreateResponsePostApplyResourcesMap | null;
    postApplyResourcesUnavailable?: boolean | null;
    region?: string | null;
    status?: OnRampsCreateResponseStatus | null;
    vpc?: string | null;
    vpcsById?: OnRampsCreateResponseVpcsByIdMap | null;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsCreateResponseVpcsByIdUnavailableList | null;
}
export declare const CreateOnRampResponse: S.Schema<CreateOnRampResponse>;
export interface DeleteCatalogSyncRequest {
    accountId: string;
    syncId: string;
    deleteDestination?: boolean;
}
export declare const DeleteCatalogSyncRequest: S.Schema<DeleteCatalogSyncRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCatalogSyncResponse {
    id: string;
}
export declare const DeleteCatalogSyncResponse: S.Schema<DeleteCatalogSyncResponse>;
export interface DeleteCloudIntegrationRequest {
    accountId: string;
    providerId: string;
}
export declare const DeleteCloudIntegrationRequest: S.Schema<DeleteCloudIntegrationRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCloudIntegrationResponse {
    id: string;
}
export declare const DeleteCloudIntegrationResponse: S.Schema<DeleteCloudIntegrationResponse>;
export interface DeleteOnRampRequest {
    accountId: string;
    onrampId: string;
    destroy?: boolean;
    force?: boolean;
}
export declare const DeleteOnRampRequest: S.Schema<DeleteOnRampRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteOnRampResponse {
    id: string;
}
export declare const DeleteOnRampResponse: S.Schema<DeleteOnRampResponse>;
export interface DiscoverAllCloudIntegrationRequest {
    accountId: string;
}
export declare const DiscoverAllCloudIntegrationRequest: S.Schema<DiscoverAllCloudIntegrationRequest>;
export interface DiscoverAllCloudIntegrationResponse {
}
export declare const DiscoverAllCloudIntegrationResponse: S.Schema<DiscoverAllCloudIntegrationResponse>;
export interface DiscoverCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    v2?: boolean;
}
export declare const DiscoverCloudIntegrationRequest: S.Schema<DiscoverCloudIntegrationRequest>;
export interface DiscoverCloudIntegrationResponse {
}
export declare const DiscoverCloudIntegrationResponse: S.Schema<DiscoverCloudIntegrationResponse>;
export interface ExportOnRampRequest {
    accountId: string;
    onrampId: string;
}
export declare const ExportOnRampRequest: S.Schema<ExportOnRampRequest>;
export interface ExportOnRampResponse {
}
export declare const ExportOnRampResponse: S.Schema<ExportOnRampResponse>;
export type ResourcesExportRequestResourceIdList = Array<string>;
export declare const ResourcesExportRequestResourceIdList: S.Schema<ResourcesExportRequestResourceIdList>;
export type ResourcesExportRequestResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesExportRequestResourceType: any;
export type ResourcesExportRequestResourceTypeList = Array<ResourcesExportRequestResourceType | (string & {})>;
export declare const ResourcesExportRequestResourceTypeList: S.Schema<ResourcesExportRequestResourceTypeList>;
export type ResourcesExportRequestSearchList = Array<string>;
export declare const ResourcesExportRequestSearchList: S.Schema<ResourcesExportRequestSearchList>;
export interface ExportResourceRequest {
    accountId: string;
    desc?: boolean;
    /** One of ["id", "resource_type", "region"]. */
    orderBy?: string;
    providerId?: string;
    region?: string;
    resourceGroup?: string;
    resourceId?: ResourcesExportRequestResourceIdList;
    resourceType?: ResourcesExportRequestResourceTypeList;
    search?: ResourcesExportRequestSearchList;
    v2?: boolean;
}
export declare const ExportResourceRequest: S.Schema<ExportResourceRequest>;
export interface ExportResourceResponse {
}
export declare const ExportResourceResponse: S.Schema<ExportResourceResponse>;
export interface GetCatalogSyncRequest {
    accountId: string;
    syncId: string;
}
export declare const GetCatalogSyncRequest: S.Schema<GetCatalogSyncRequest>;
export type CatalogSyncsGetResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsGetResponseDestinationType: any;
export type CatalogSyncsGetResponseUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsGetResponseUpdateMode: any;
export type CatalogSyncsGetResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const CatalogSyncsGetResponseErrorsValueCode: any;
export type CatalogSyncsGetResponseErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const CatalogSyncsGetResponseErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type CatalogSyncsGetResponseErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const CatalogSyncsGetResponseErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface CatalogSyncsGetResponseErrorsValue {
    code: CatalogSyncsGetResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const CatalogSyncsGetResponseErrorsValue: S.Schema<CatalogSyncsGetResponseErrorsValue>;
export type CatalogSyncsGetResponseErrorsMap = {
    [key: string]: CatalogSyncsGetResponseErrorsValue | undefined;
};
export declare const CatalogSyncsGetResponseErrorsMap: S.Schema<CatalogSyncsGetResponseErrorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsGetResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsGetResponseUpdateMode;
    errors?: CatalogSyncsGetResponseErrorsMap | null;
    includesDiscoveriesUntil?: string | null;
    lastAttemptedUpdateAt?: string | null;
    lastSuccessfulUpdateAt?: string | null;
}
export declare const GetCatalogSyncResponse: S.Schema<GetCatalogSyncResponse>;
export interface GetCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    status?: boolean;
}
export declare const GetCloudIntegrationRequest: S.Schema<GetCloudIntegrationRequest>;
export type CloudIntegrationsGetResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const CloudIntegrationsGetResponseCloudType: any;
export type CloudIntegrationsGetResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export declare const CloudIntegrationsGetResponseLifecycleState: any;
export type CloudIntegrationsGetResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsGetResponseState: any;
export type CloudIntegrationsGetResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsGetResponseStateV2: any;
export type CloudIntegrationsGetResponseStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsGetResponseStatusDiscoveryProgress: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsGetResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsGetResponseStatusDiscoveryProgressV2: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsGetResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsGetResponseStatusLastDiscoveryStatus: any;
export type CloudIntegrationsGetResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsGetResponseStatusLastDiscoveryStatusV2: any;
export type CloudIntegrationsGetResponseStatusRegionsList = Array<string>;
export declare const CloudIntegrationsGetResponseStatusRegionsList: S.Schema<CloudIntegrationsGetResponseStatusRegionsList>;
export type CloudIntegrationsGetResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const CloudIntegrationsGetResponseStatusInUseByItemClientType: any;
export interface CloudIntegrationsGetResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsGetResponseStatusInUseByItemClientType;
    name: string;
}
export declare const CloudIntegrationsGetResponseStatusInUseByItem: S.Schema<CloudIntegrationsGetResponseStatusInUseByItem>;
export type CloudIntegrationsGetResponseStatusInUseByList = Array<CloudIntegrationsGetResponseStatusInUseByItem>;
export declare const CloudIntegrationsGetResponseStatusInUseByList: S.Schema<CloudIntegrationsGetResponseStatusInUseByList>;
export interface CloudIntegrationsGetResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsGetResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsGetResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsGetResponseStatusRegionsList;
    credentialsGoodSince?: string | null;
    credentialsMissingSince?: string | null;
    credentialsRejectedSince?: string | null;
    discoveryMessage?: string | null;
    discoveryMessageV2?: string | null;
    inUseBy?: CloudIntegrationsGetResponseStatusInUseByList | null;
    lastDiscoveryCompletedAt?: string | null;
    lastDiscoveryCompletedAtV2?: string | null;
    lastDiscoveryStartedAt?: string | null;
    lastDiscoveryStartedAtV2?: string | null;
    lastUpdated?: string | null;
}
export declare const CloudIntegrationsGetResponseStatus: S.Schema<CloudIntegrationsGetResponseStatus>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsGetResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsGetResponseLifecycleState;
    state: CloudIntegrationsGetResponseState;
    stateV2: CloudIntegrationsGetResponseStateV2;
    awsArn?: string | null;
    azureSubscriptionId?: string | null;
    azureTenantId?: string | null;
    description?: string | null;
    gcpProjectId?: string | null;
    gcpServiceAccountEmail?: string | null;
    status?: CloudIntegrationsGetResponseStatus | null;
}
export declare const GetCloudIntegrationResponse: S.Schema<GetCloudIntegrationResponse>;
export interface GetOnRampRequest {
    accountId: string;
    onrampId: string;
    plannedResources?: boolean;
    postApplyResources?: boolean;
    status?: boolean;
    vpcs?: boolean;
}
export declare const GetOnRampRequest: S.Schema<GetOnRampRequest>;
export type OnRampsGetResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export declare const OnRampsGetResponseCloudType: any;
export type OnRampsGetResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export declare const OnRampsGetResponseType: any;
export type OnRampsGetResponseAttachedHubsList = Array<string>;
export declare const OnRampsGetResponseAttachedHubsList: S.Schema<OnRampsGetResponseAttachedHubsList>;
export type OnRampsGetResponseAttachedVpcsList = Array<string>;
export declare const OnRampsGetResponseAttachedVpcsList: S.Schema<OnRampsGetResponseAttachedVpcsList>;
export type OnRampsGetResponsePlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsGetResponsePlannedMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsGetResponsePlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsGetResponsePlannedResourcesItemDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsGetResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export declare const OnRampsGetResponsePlannedResourcesItemKeysRequireReplaceList: S.Schema<OnRampsGetResponsePlannedResourcesItemKeysRequireReplaceList>;
export type OnRampsGetResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsGetResponsePlannedResourcesItemMonthlyCostEstimateDiff: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsGetResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export declare const OnRampsGetResponsePlannedResourcesItemPlannedAction: any;
export type OnRampsGetResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponsePlannedResourcesItemResourceCloudType: any;
export type OnRampsGetResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponsePlannedResourcesItemResourceResourceType: any;
export interface OnRampsGetResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsGetResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export declare const OnRampsGetResponsePlannedResourcesItemResource: S.Schema<OnRampsGetResponsePlannedResourcesItemResource>;
export interface OnRampsGetResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsGetResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsGetResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsGetResponsePlannedResourcesItemResource;
}
export declare const OnRampsGetResponsePlannedResourcesItem: S.Schema<OnRampsGetResponsePlannedResourcesItem>;
export type OnRampsGetResponsePlannedResourcesList = Array<OnRampsGetResponsePlannedResourcesItem>;
export declare const OnRampsGetResponsePlannedResourcesList: S.Schema<OnRampsGetResponsePlannedResourcesList>;
export type OnRampsGetResponsePostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsGetResponsePostApplyMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsGetResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponsePostApplyResourcesValueCloudType: any;
export type OnRampsGetResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsGetResponsePostApplyResourcesValueConfigMap: S.Schema<OnRampsGetResponsePostApplyResourcesValueConfigMap>;
export type OnRampsGetResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsGetResponsePostApplyResourcesValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsGetResponsePostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsGetResponsePostApplyResourcesValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsGetResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsGetResponsePostApplyResourcesValueObservationsMap: S.Schema<OnRampsGetResponsePostApplyResourcesValueObservationsMap>;
export type OnRampsGetResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export declare const OnRampsGetResponsePostApplyResourcesValueProviderIdsList: S.Schema<OnRampsGetResponsePostApplyResourcesValueProviderIdsList>;
export type OnRampsGetResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsGetResponsePostApplyResourcesValueProviderNamesByIdMap: S.Schema<OnRampsGetResponsePostApplyResourcesValueProviderNamesByIdMap>;
export type OnRampsGetResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponsePostApplyResourcesValueResourceType: any;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsList: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsList>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsList: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsList>;
export interface OnRampsGetResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsGetResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsGetResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsGetResponsePostApplyResourcesValueSectionsList = Array<OnRampsGetResponsePostApplyResourcesValueSectionsItem>;
export declare const OnRampsGetResponsePostApplyResourcesValueSectionsList: S.Schema<OnRampsGetResponsePostApplyResourcesValueSectionsList>;
export type OnRampsGetResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsGetResponsePostApplyResourcesValueStateMap: S.Schema<OnRampsGetResponsePostApplyResourcesValueStateMap>;
export type OnRampsGetResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsGetResponsePostApplyResourcesValueTagsMap: S.Schema<OnRampsGetResponsePostApplyResourcesValueTagsMap>;
export type OnRampsGetResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsGetResponsePostApplyResourcesValueManagedByItemClientType: any;
export interface OnRampsGetResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsGetResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsGetResponsePostApplyResourcesValueManagedByItem: S.Schema<OnRampsGetResponsePostApplyResourcesValueManagedByItem>;
export type OnRampsGetResponsePostApplyResourcesValueManagedByList = Array<OnRampsGetResponsePostApplyResourcesValueManagedByItem>;
export declare const OnRampsGetResponsePostApplyResourcesValueManagedByList: S.Schema<OnRampsGetResponsePostApplyResourcesValueManagedByList>;
export interface OnRampsGetResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsGetResponsePostApplyResourcesValueCloudType;
    config: OnRampsGetResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsGetResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsGetResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsGetResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsGetResponsePostApplyResourcesValueResourceType;
    sections: OnRampsGetResponsePostApplyResourcesValueSectionsList;
    state: OnRampsGetResponsePostApplyResourcesValueStateMap;
    tags: OnRampsGetResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsGetResponsePostApplyResourcesValueManagedByList | null;
}
export declare const OnRampsGetResponsePostApplyResourcesValue: S.Schema<OnRampsGetResponsePostApplyResourcesValue>;
export type OnRampsGetResponsePostApplyResourcesMap = {
    [key: string]: OnRampsGetResponsePostApplyResourcesValue | undefined;
};
export declare const OnRampsGetResponsePostApplyResourcesMap: S.Schema<OnRampsGetResponsePostApplyResourcesMap>;
export type OnRampsGetResponseStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsGetResponseStatusApplyProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsGetResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export declare const OnRampsGetResponseStatusLifecycleState: any;
export type OnRampsGetResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsGetResponseStatusPlanProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsGetResponseStatusRoutesList = Array<string>;
export declare const OnRampsGetResponseStatusRoutesList: S.Schema<OnRampsGetResponseStatusRoutesList>;
export type OnRampsGetResponseStatusTunnelsList = Array<string>;
export declare const OnRampsGetResponseStatusTunnelsList: S.Schema<OnRampsGetResponseStatusTunnelsList>;
export type OnRampsGetResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const OnRampsGetResponseStatusLifecycleErrorsValueCode: any;
export type OnRampsGetResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const OnRampsGetResponseStatusLifecycleErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type OnRampsGetResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const OnRampsGetResponseStatusLifecycleErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface OnRampsGetResponseStatusLifecycleErrorsValue {
    code: OnRampsGetResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const OnRampsGetResponseStatusLifecycleErrorsValue: S.Schema<OnRampsGetResponseStatusLifecycleErrorsValue>;
export type OnRampsGetResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsGetResponseStatusLifecycleErrorsValue | undefined;
};
export declare const OnRampsGetResponseStatusLifecycleErrorsMap: S.Schema<OnRampsGetResponseStatusLifecycleErrorsMap>;
export interface OnRampsGetResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsGetResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsGetResponseStatusRoutesList;
    tunnels: OnRampsGetResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsGetResponseStatusLifecycleErrorsMap | null;
}
export declare const OnRampsGetResponseStatus: S.Schema<OnRampsGetResponseStatus>;
export type OnRampsGetResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponseVpcsByIdValueCloudType: any;
export type OnRampsGetResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsGetResponseVpcsByIdValueConfigMap: S.Schema<OnRampsGetResponseVpcsByIdValueConfigMap>;
export type OnRampsGetResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsGetResponseVpcsByIdValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsGetResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsGetResponseVpcsByIdValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsGetResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsGetResponseVpcsByIdValueObservationsMap: S.Schema<OnRampsGetResponseVpcsByIdValueObservationsMap>;
export type OnRampsGetResponseVpcsByIdValueProviderIdsList = Array<string>;
export declare const OnRampsGetResponseVpcsByIdValueProviderIdsList: S.Schema<OnRampsGetResponseVpcsByIdValueProviderIdsList>;
export type OnRampsGetResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsGetResponseVpcsByIdValueProviderNamesByIdMap: S.Schema<OnRampsGetResponseVpcsByIdValueProviderNamesByIdMap>;
export type OnRampsGetResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponseVpcsByIdValueResourceType: any;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsList: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsList>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export declare const OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsList: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsList>;
export interface OnRampsGetResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsGetResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsGetResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsGetResponseVpcsByIdValueSectionsItem: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsItem>;
export type OnRampsGetResponseVpcsByIdValueSectionsList = Array<OnRampsGetResponseVpcsByIdValueSectionsItem>;
export declare const OnRampsGetResponseVpcsByIdValueSectionsList: S.Schema<OnRampsGetResponseVpcsByIdValueSectionsList>;
export type OnRampsGetResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsGetResponseVpcsByIdValueStateMap: S.Schema<OnRampsGetResponseVpcsByIdValueStateMap>;
export type OnRampsGetResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsGetResponseVpcsByIdValueTagsMap: S.Schema<OnRampsGetResponseVpcsByIdValueTagsMap>;
export type OnRampsGetResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsGetResponseVpcsByIdValueManagedByItemClientType: any;
export interface OnRampsGetResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsGetResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsGetResponseVpcsByIdValueManagedByItem: S.Schema<OnRampsGetResponseVpcsByIdValueManagedByItem>;
export type OnRampsGetResponseVpcsByIdValueManagedByList = Array<OnRampsGetResponseVpcsByIdValueManagedByItem>;
export declare const OnRampsGetResponseVpcsByIdValueManagedByList: S.Schema<OnRampsGetResponseVpcsByIdValueManagedByList>;
export interface OnRampsGetResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsGetResponseVpcsByIdValueCloudType;
    config: OnRampsGetResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsGetResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsGetResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsGetResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsGetResponseVpcsByIdValueResourceType;
    sections: OnRampsGetResponseVpcsByIdValueSectionsList;
    state: OnRampsGetResponseVpcsByIdValueStateMap;
    tags: OnRampsGetResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsGetResponseVpcsByIdValueManagedByList | null;
}
export declare const OnRampsGetResponseVpcsByIdValue: S.Schema<OnRampsGetResponseVpcsByIdValue>;
export type OnRampsGetResponseVpcsByIdMap = {
    [key: string]: OnRampsGetResponseVpcsByIdValue | undefined;
};
export declare const OnRampsGetResponseVpcsByIdMap: S.Schema<OnRampsGetResponseVpcsByIdMap>;
export type OnRampsGetResponseVpcsByIdUnavailableList = Array<string>;
export declare const OnRampsGetResponseVpcsByIdUnavailableList: S.Schema<OnRampsGetResponseVpcsByIdUnavailableList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetOnRampResponse {
    id: string;
    cloudType: OnRampsGetResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsGetResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsGetResponseAttachedHubsList | null;
    attachedVpcs?: OnRampsGetResponseAttachedVpcsList | null;
    cloudAsn?: number | null;
    description?: string | null;
    hub?: string | null;
    lastAppliedAt?: string | null;
    lastExportedAt?: string | null;
    lastPlannedAt?: string | null;
    manageHubToHubAttachments?: boolean | null;
    manageVpcToHubAttachments?: boolean | null;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null;
    plannedResources?: OnRampsGetResponsePlannedResourcesList | null;
    plannedResourcesUnavailable?: boolean | null;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null;
    postApplyResources?: OnRampsGetResponsePostApplyResourcesMap | null;
    postApplyResourcesUnavailable?: boolean | null;
    region?: string | null;
    status?: OnRampsGetResponseStatus | null;
    vpc?: string | null;
    vpcsById?: OnRampsGetResponseVpcsByIdMap | null;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsGetResponseVpcsByIdUnavailableList | null;
}
export declare const GetOnRampResponse: S.Schema<GetOnRampResponse>;
export interface GetResourceRequest {
    accountId: string;
    resourceId: string;
    v2?: boolean;
}
export declare const GetResourceRequest: S.Schema<GetResourceRequest>;
export type ResourcesGetResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesGetResponseCloudType: any;
export type ResourcesGetResponseConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const ResourcesGetResponseConfigMap: S.Schema<ResourcesGetResponseConfigMap>;
export type ResourcesGetResponseMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const ResourcesGetResponseMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type ResourcesGetResponseObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const ResourcesGetResponseObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type ResourcesGetResponseObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const ResourcesGetResponseObservationsMap: S.Schema<ResourcesGetResponseObservationsMap>;
export type ResourcesGetResponseProviderIdsList = Array<string>;
export declare const ResourcesGetResponseProviderIdsList: S.Schema<ResourcesGetResponseProviderIdsList>;
export type ResourcesGetResponseProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const ResourcesGetResponseProviderNamesByIdMap: S.Schema<ResourcesGetResponseProviderNamesByIdMap>;
export type ResourcesGetResponseResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesGetResponseResourceType: any;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListList = Array<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | ResourcesGetResponseSectionsItemHiddenItemsItemValueMcnListItem;
export declare const ResourcesGetResponseSectionsItemHiddenItemsItemValue: any;
export interface ResourcesGetResponseSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: ResourcesGetResponseSectionsItemHiddenItemsItemValue | null;
}
export declare const ResourcesGetResponseSectionsItemHiddenItemsItem: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsItem>;
export type ResourcesGetResponseSectionsItemHiddenItemsList = Array<ResourcesGetResponseSectionsItemHiddenItemsItem>;
export declare const ResourcesGetResponseSectionsItemHiddenItemsList: S.Schema<ResourcesGetResponseSectionsItemHiddenItemsList>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListList = Array<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | ResourcesGetResponseSectionsItemVisibleItemsItemValueMcnListItem;
export declare const ResourcesGetResponseSectionsItemVisibleItemsItemValue: any;
export interface ResourcesGetResponseSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: ResourcesGetResponseSectionsItemVisibleItemsItemValue | null;
}
export declare const ResourcesGetResponseSectionsItemVisibleItemsItem: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsItem>;
export type ResourcesGetResponseSectionsItemVisibleItemsList = Array<ResourcesGetResponseSectionsItemVisibleItemsItem>;
export declare const ResourcesGetResponseSectionsItemVisibleItemsList: S.Schema<ResourcesGetResponseSectionsItemVisibleItemsList>;
export interface ResourcesGetResponseSectionsItem {
    hiddenItems: ResourcesGetResponseSectionsItemHiddenItemsList;
    name: string;
    visibleItems: ResourcesGetResponseSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const ResourcesGetResponseSectionsItem: S.Schema<ResourcesGetResponseSectionsItem>;
export type ResourcesGetResponseSectionsList = Array<ResourcesGetResponseSectionsItem>;
export declare const ResourcesGetResponseSectionsList: S.Schema<ResourcesGetResponseSectionsList>;
export type ResourcesGetResponseStateMap = {
    [key: string]: unknown | undefined;
};
export declare const ResourcesGetResponseStateMap: S.Schema<ResourcesGetResponseStateMap>;
export type ResourcesGetResponseTagsMap = {
    [key: string]: string | undefined;
};
export declare const ResourcesGetResponseTagsMap: S.Schema<ResourcesGetResponseTagsMap>;
export type ResourcesGetResponseManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const ResourcesGetResponseManagedByItemClientType: any;
export interface ResourcesGetResponseManagedByItem {
    id: string;
    clientType: ResourcesGetResponseManagedByItemClientType;
    name: string;
}
export declare const ResourcesGetResponseManagedByItem: S.Schema<ResourcesGetResponseManagedByItem>;
export type ResourcesGetResponseManagedByList = Array<ResourcesGetResponseManagedByItem>;
export declare const ResourcesGetResponseManagedByList: S.Schema<ResourcesGetResponseManagedByList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceResponse {
    id: string;
    accountId: string;
    cloudType: ResourcesGetResponseCloudType;
    config: ResourcesGetResponseConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: ResourcesGetResponseObservationsMap;
    providerIds: ResourcesGetResponseProviderIdsList;
    providerNamesById: ResourcesGetResponseProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: ResourcesGetResponseResourceType;
    sections: ResourcesGetResponseSectionsList;
    state: ResourcesGetResponseStateMap;
    tags: ResourcesGetResponseTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: ResourcesGetResponseManagedByList | null;
}
export declare const GetResourceResponse: S.Schema<GetResourceResponse>;
export interface InitialSetupCloudIntegrationRequest {
    accountId: string;
    providerId: string;
}
export declare const InitialSetupCloudIntegrationRequest: S.Schema<InitialSetupCloudIntegrationRequest>;
export interface CloudIntegrationsInitialSetupResultMcnAwsTrustPolicy {
    awsTrustPolicy: string;
    itemType: string;
}
export declare const CloudIntegrationsInitialSetupResultMcnAwsTrustPolicy: S.Schema<CloudIntegrationsInitialSetupResultMcnAwsTrustPolicy>;
export interface CloudIntegrationsInitialSetupResultMcnAzureSetup {
    azureConsentUrl: string;
    integrationIdentityTag: string;
    itemType: string;
    tagCliCommand: string;
}
export declare const CloudIntegrationsInitialSetupResultMcnAzureSetup: S.Schema<CloudIntegrationsInitialSetupResultMcnAzureSetup>;
export interface CloudIntegrationsInitialSetupResultMcnGcpSetup {
    integrationIdentityTag: string;
    itemType: string;
    tagCliCommand: string;
}
export declare const CloudIntegrationsInitialSetupResultMcnGcpSetup: S.Schema<CloudIntegrationsInitialSetupResultMcnGcpSetup>;
export type CloudIntegrationsInitialSetupResult = CloudIntegrationsInitialSetupResultMcnAwsTrustPolicy | CloudIntegrationsInitialSetupResultMcnAzureSetup | CloudIntegrationsInitialSetupResultMcnGcpSetup;
export declare const CloudIntegrationsInitialSetupResult: any;
export type InitialSetupCloudIntegrationResponse = CloudIntegrationsInitialSetupResult;
export declare const InitialSetupCloudIntegrationResponse: S.Schema<InitialSetupCloudIntegrationResponse>;
export type CatalogSyncsPrebuiltPoliciesListRequestDestinationType = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsPrebuiltPoliciesListRequestDestinationType: any;
export interface ListCatalogSyncPrebuiltPoliciesRequest {
    accountId: string;
    /** Specify type of destination, omit to return all. */
    destinationType?: CatalogSyncsPrebuiltPoliciesListRequestDestinationType | (string & {});
}
export declare const ListCatalogSyncPrebuiltPoliciesRequest: S.Schema<ListCatalogSyncPrebuiltPoliciesRequest>;
export type CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsItem = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsItem: any;
export type CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsList = Array<CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsItem>;
export declare const CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsList: S.Schema<CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsList>;
export interface CatalogSyncsPrebuiltPoliciesListResultItem {
    applicableDestinations: CatalogSyncsPrebuiltPoliciesListResultItemApplicableDestinationsList;
    policyDescription: string;
    policyName: string;
    policyString: string;
}
export declare const CatalogSyncsPrebuiltPoliciesListResultItem: S.Schema<CatalogSyncsPrebuiltPoliciesListResultItem>;
export type CatalogSyncsPrebuiltPoliciesListResultList = Array<CatalogSyncsPrebuiltPoliciesListResultItem>;
export declare const CatalogSyncsPrebuiltPoliciesListResultList: S.Schema<CatalogSyncsPrebuiltPoliciesListResultList>;
export interface ListCatalogSyncPrebuiltPoliciesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CatalogSyncsPrebuiltPoliciesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCatalogSyncPrebuiltPoliciesResponse: S.Schema<ListCatalogSyncPrebuiltPoliciesResponse>;
export interface ListCatalogSyncsRequest {
    accountId: string;
}
export declare const ListCatalogSyncsRequest: S.Schema<ListCatalogSyncsRequest>;
export type CatalogSyncsListResultItemDestinationType = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsListResultItemDestinationType: any;
export type CatalogSyncsListResultItemUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsListResultItemUpdateMode: any;
export type CatalogSyncsListResultItemErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const CatalogSyncsListResultItemErrorsValueCode: any;
export type CatalogSyncsListResultItemErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const CatalogSyncsListResultItemErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type CatalogSyncsListResultItemErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const CatalogSyncsListResultItemErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface CatalogSyncsListResultItemErrorsValue {
    code: CatalogSyncsListResultItemErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const CatalogSyncsListResultItemErrorsValue: S.Schema<CatalogSyncsListResultItemErrorsValue>;
export type CatalogSyncsListResultItemErrorsMap = {
    [key: string]: CatalogSyncsListResultItemErrorsValue | undefined;
};
export declare const CatalogSyncsListResultItemErrorsMap: S.Schema<CatalogSyncsListResultItemErrorsMap>;
export interface CatalogSyncsListResultItem {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsListResultItemDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsListResultItemUpdateMode;
    errors?: CatalogSyncsListResultItemErrorsMap | null;
    includesDiscoveriesUntil?: string | null;
    lastAttemptedUpdateAt?: string | null;
    lastSuccessfulUpdateAt?: string | null;
}
export declare const CatalogSyncsListResultItem: S.Schema<CatalogSyncsListResultItem>;
export type CatalogSyncsListResultList = Array<CatalogSyncsListResultItem>;
export declare const CatalogSyncsListResultList: S.Schema<CatalogSyncsListResultList>;
export interface ListCatalogSyncsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CatalogSyncsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCatalogSyncsResponse: S.Schema<ListCatalogSyncsResponse>;
export interface ListCloudIntegrationsRequest {
    accountId: string;
    cloudflare?: boolean;
    desc?: boolean;
    /** One of ["updated_at", "id", "cloud_type", "name"]. */
    orderBy?: string;
    status?: boolean;
}
export declare const ListCloudIntegrationsRequest: S.Schema<ListCloudIntegrationsRequest>;
export type CloudIntegrationsListResultItemCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const CloudIntegrationsListResultItemCloudType: any;
export type CloudIntegrationsListResultItemLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export declare const CloudIntegrationsListResultItemLifecycleState: any;
export type CloudIntegrationsListResultItemState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsListResultItemState: any;
export type CloudIntegrationsListResultItemStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsListResultItemStateV2: any;
export type CloudIntegrationsListResultItemStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsListResultItemStatusDiscoveryProgress: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsListResultItemStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsListResultItemStatusDiscoveryProgressV2: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsListResultItemStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsListResultItemStatusLastDiscoveryStatus: any;
export type CloudIntegrationsListResultItemStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsListResultItemStatusLastDiscoveryStatusV2: any;
export type CloudIntegrationsListResultItemStatusRegionsList = Array<string>;
export declare const CloudIntegrationsListResultItemStatusRegionsList: S.Schema<CloudIntegrationsListResultItemStatusRegionsList>;
export type CloudIntegrationsListResultItemStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const CloudIntegrationsListResultItemStatusInUseByItemClientType: any;
export interface CloudIntegrationsListResultItemStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsListResultItemStatusInUseByItemClientType;
    name: string;
}
export declare const CloudIntegrationsListResultItemStatusInUseByItem: S.Schema<CloudIntegrationsListResultItemStatusInUseByItem>;
export type CloudIntegrationsListResultItemStatusInUseByList = Array<CloudIntegrationsListResultItemStatusInUseByItem>;
export declare const CloudIntegrationsListResultItemStatusInUseByList: S.Schema<CloudIntegrationsListResultItemStatusInUseByList>;
export interface CloudIntegrationsListResultItemStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsListResultItemStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsListResultItemStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsListResultItemStatusRegionsList;
    credentialsGoodSince?: string | null;
    credentialsMissingSince?: string | null;
    credentialsRejectedSince?: string | null;
    discoveryMessage?: string | null;
    discoveryMessageV2?: string | null;
    inUseBy?: CloudIntegrationsListResultItemStatusInUseByList | null;
    lastDiscoveryCompletedAt?: string | null;
    lastDiscoveryCompletedAtV2?: string | null;
    lastDiscoveryStartedAt?: string | null;
    lastDiscoveryStartedAtV2?: string | null;
    lastUpdated?: string | null;
}
export declare const CloudIntegrationsListResultItemStatus: S.Schema<CloudIntegrationsListResultItemStatus>;
export interface CloudIntegrationsListResultItem {
    id: string;
    cloudType: CloudIntegrationsListResultItemCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsListResultItemLifecycleState;
    state: CloudIntegrationsListResultItemState;
    stateV2: CloudIntegrationsListResultItemStateV2;
    awsArn?: string | null;
    azureSubscriptionId?: string | null;
    azureTenantId?: string | null;
    description?: string | null;
    gcpProjectId?: string | null;
    gcpServiceAccountEmail?: string | null;
    status?: CloudIntegrationsListResultItemStatus | null;
}
export declare const CloudIntegrationsListResultItem: S.Schema<CloudIntegrationsListResultItem>;
export type CloudIntegrationsListResultList = Array<CloudIntegrationsListResultItem>;
export declare const CloudIntegrationsListResultList: S.Schema<CloudIntegrationsListResultList>;
export interface ListCloudIntegrationsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CloudIntegrationsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCloudIntegrationsResponse: S.Schema<ListCloudIntegrationsResponse>;
export interface ListOnRampAddressSpacesRequest {
    accountId: string;
}
export declare const ListOnRampAddressSpacesRequest: S.Schema<ListOnRampAddressSpacesRequest>;
export type OnRampsAddressSpacesListResponsePrefixesList = Array<string>;
export declare const OnRampsAddressSpacesListResponsePrefixesList: S.Schema<OnRampsAddressSpacesListResponsePrefixesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListOnRampAddressSpacesResponse {
    prefixes: OnRampsAddressSpacesListResponsePrefixesList;
}
export declare const ListOnRampAddressSpacesResponse: S.Schema<ListOnRampAddressSpacesResponse>;
export interface ListOnRampsRequest {
    accountId: string;
    desc?: boolean;
    /** One of ["updated_at", "id", "cloud_type", "name"]. */
    orderBy?: string;
    status?: boolean;
    vpcs?: boolean;
}
export declare const ListOnRampsRequest: S.Schema<ListOnRampsRequest>;
export type OnRampsListResultItemCloudType = "AWS" | "AZURE" | "GOOGLE";
export declare const OnRampsListResultItemCloudType: any;
export type OnRampsListResultItemType = "OnrampTypeSingle" | "OnrampTypeHub";
export declare const OnRampsListResultItemType: any;
export type OnRampsListResultItemAttachedHubsList = Array<string>;
export declare const OnRampsListResultItemAttachedHubsList: S.Schema<OnRampsListResultItemAttachedHubsList>;
export type OnRampsListResultItemAttachedVpcsList = Array<string>;
export declare const OnRampsListResultItemAttachedVpcsList: S.Schema<OnRampsListResultItemAttachedVpcsList>;
export type OnRampsListResultItemPlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsListResultItemPlannedMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsListResultItemPlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsListResultItemPlannedResourcesItemDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsListResultItemPlannedResourcesItemKeysRequireReplaceList = Array<string>;
export declare const OnRampsListResultItemPlannedResourcesItemKeysRequireReplaceList: S.Schema<OnRampsListResultItemPlannedResourcesItemKeysRequireReplaceList>;
export type OnRampsListResultItemPlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsListResultItemPlannedResourcesItemMonthlyCostEstimateDiff: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsListResultItemPlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export declare const OnRampsListResultItemPlannedResourcesItemPlannedAction: any;
export type OnRampsListResultItemPlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemPlannedResourcesItemResourceCloudType: any;
export type OnRampsListResultItemPlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemPlannedResourcesItemResourceResourceType: any;
export interface OnRampsListResultItemPlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsListResultItemPlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPlannedResourcesItemResourceResourceType;
    title: string;
}
export declare const OnRampsListResultItemPlannedResourcesItemResource: S.Schema<OnRampsListResultItemPlannedResourcesItemResource>;
export interface OnRampsListResultItemPlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsListResultItemPlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsListResultItemPlannedResourcesItemPlannedAction;
    resource: OnRampsListResultItemPlannedResourcesItemResource;
}
export declare const OnRampsListResultItemPlannedResourcesItem: S.Schema<OnRampsListResultItemPlannedResourcesItem>;
export type OnRampsListResultItemPlannedResourcesList = Array<OnRampsListResultItemPlannedResourcesItem>;
export declare const OnRampsListResultItemPlannedResourcesList: S.Schema<OnRampsListResultItemPlannedResourcesList>;
export type OnRampsListResultItemPostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsListResultItemPostApplyMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsListResultItemPostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemPostApplyResourcesValueCloudType: any;
export type OnRampsListResultItemPostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsListResultItemPostApplyResourcesValueConfigMap: S.Schema<OnRampsListResultItemPostApplyResourcesValueConfigMap>;
export type OnRampsListResultItemPostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsListResultItemPostApplyResourcesValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsListResultItemPostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsListResultItemPostApplyResourcesValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsListResultItemPostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsListResultItemPostApplyResourcesValueObservationsMap: S.Schema<OnRampsListResultItemPostApplyResourcesValueObservationsMap>;
export type OnRampsListResultItemPostApplyResourcesValueProviderIdsList = Array<string>;
export declare const OnRampsListResultItemPostApplyResourcesValueProviderIdsList: S.Schema<OnRampsListResultItemPostApplyResourcesValueProviderIdsList>;
export type OnRampsListResultItemPostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsListResultItemPostApplyResourcesValueProviderNamesByIdMap: S.Schema<OnRampsListResultItemPostApplyResourcesValueProviderNamesByIdMap>;
export type OnRampsListResultItemPostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemPostApplyResourcesValueResourceType: any;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsItem>;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsList: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsList>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsItem>;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsList: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsList>;
export interface OnRampsListResultItemPostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsListResultItemPostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsListResultItemPostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsItem>;
export type OnRampsListResultItemPostApplyResourcesValueSectionsList = Array<OnRampsListResultItemPostApplyResourcesValueSectionsItem>;
export declare const OnRampsListResultItemPostApplyResourcesValueSectionsList: S.Schema<OnRampsListResultItemPostApplyResourcesValueSectionsList>;
export type OnRampsListResultItemPostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsListResultItemPostApplyResourcesValueStateMap: S.Schema<OnRampsListResultItemPostApplyResourcesValueStateMap>;
export type OnRampsListResultItemPostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsListResultItemPostApplyResourcesValueTagsMap: S.Schema<OnRampsListResultItemPostApplyResourcesValueTagsMap>;
export type OnRampsListResultItemPostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsListResultItemPostApplyResourcesValueManagedByItemClientType: any;
export interface OnRampsListResultItemPostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsListResultItemPostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsListResultItemPostApplyResourcesValueManagedByItem: S.Schema<OnRampsListResultItemPostApplyResourcesValueManagedByItem>;
export type OnRampsListResultItemPostApplyResourcesValueManagedByList = Array<OnRampsListResultItemPostApplyResourcesValueManagedByItem>;
export declare const OnRampsListResultItemPostApplyResourcesValueManagedByList: S.Schema<OnRampsListResultItemPostApplyResourcesValueManagedByList>;
export interface OnRampsListResultItemPostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsListResultItemPostApplyResourcesValueCloudType;
    config: OnRampsListResultItemPostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsListResultItemPostApplyResourcesValueObservationsMap;
    providerIds: OnRampsListResultItemPostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsListResultItemPostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsListResultItemPostApplyResourcesValueResourceType;
    sections: OnRampsListResultItemPostApplyResourcesValueSectionsList;
    state: OnRampsListResultItemPostApplyResourcesValueStateMap;
    tags: OnRampsListResultItemPostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsListResultItemPostApplyResourcesValueManagedByList | null;
}
export declare const OnRampsListResultItemPostApplyResourcesValue: S.Schema<OnRampsListResultItemPostApplyResourcesValue>;
export type OnRampsListResultItemPostApplyResourcesMap = {
    [key: string]: OnRampsListResultItemPostApplyResourcesValue | undefined;
};
export declare const OnRampsListResultItemPostApplyResourcesMap: S.Schema<OnRampsListResultItemPostApplyResourcesMap>;
export type OnRampsListResultItemStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsListResultItemStatusApplyProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsListResultItemStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export declare const OnRampsListResultItemStatusLifecycleState: any;
export type OnRampsListResultItemStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsListResultItemStatusPlanProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsListResultItemStatusRoutesList = Array<string>;
export declare const OnRampsListResultItemStatusRoutesList: S.Schema<OnRampsListResultItemStatusRoutesList>;
export type OnRampsListResultItemStatusTunnelsList = Array<string>;
export declare const OnRampsListResultItemStatusTunnelsList: S.Schema<OnRampsListResultItemStatusTunnelsList>;
export type OnRampsListResultItemStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const OnRampsListResultItemStatusLifecycleErrorsValueCode: any;
export type OnRampsListResultItemStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const OnRampsListResultItemStatusLifecycleErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type OnRampsListResultItemStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const OnRampsListResultItemStatusLifecycleErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface OnRampsListResultItemStatusLifecycleErrorsValue {
    code: OnRampsListResultItemStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const OnRampsListResultItemStatusLifecycleErrorsValue: S.Schema<OnRampsListResultItemStatusLifecycleErrorsValue>;
export type OnRampsListResultItemStatusLifecycleErrorsMap = {
    [key: string]: OnRampsListResultItemStatusLifecycleErrorsValue | undefined;
};
export declare const OnRampsListResultItemStatusLifecycleErrorsMap: S.Schema<OnRampsListResultItemStatusLifecycleErrorsMap>;
export interface OnRampsListResultItemStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsListResultItemStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsListResultItemStatusRoutesList;
    tunnels: OnRampsListResultItemStatusTunnelsList;
    lifecycleErrors?: OnRampsListResultItemStatusLifecycleErrorsMap | null;
}
export declare const OnRampsListResultItemStatus: S.Schema<OnRampsListResultItemStatus>;
export type OnRampsListResultItemVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemVpcsByIdValueCloudType: any;
export type OnRampsListResultItemVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsListResultItemVpcsByIdValueConfigMap: S.Schema<OnRampsListResultItemVpcsByIdValueConfigMap>;
export type OnRampsListResultItemVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsListResultItemVpcsByIdValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsListResultItemVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsListResultItemVpcsByIdValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsListResultItemVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsListResultItemVpcsByIdValueObservationsMap: S.Schema<OnRampsListResultItemVpcsByIdValueObservationsMap>;
export type OnRampsListResultItemVpcsByIdValueProviderIdsList = Array<string>;
export declare const OnRampsListResultItemVpcsByIdValueProviderIdsList: S.Schema<OnRampsListResultItemVpcsByIdValueProviderIdsList>;
export type OnRampsListResultItemVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsListResultItemVpcsByIdValueProviderNamesByIdMap: S.Schema<OnRampsListResultItemVpcsByIdValueProviderNamesByIdMap>;
export type OnRampsListResultItemVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemVpcsByIdValueResourceType: any;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsItem>;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsList: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsList>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsItem>;
export declare const OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsList: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsList>;
export interface OnRampsListResultItemVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsListResultItemVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsListResultItemVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsListResultItemVpcsByIdValueSectionsItem: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsItem>;
export type OnRampsListResultItemVpcsByIdValueSectionsList = Array<OnRampsListResultItemVpcsByIdValueSectionsItem>;
export declare const OnRampsListResultItemVpcsByIdValueSectionsList: S.Schema<OnRampsListResultItemVpcsByIdValueSectionsList>;
export type OnRampsListResultItemVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsListResultItemVpcsByIdValueStateMap: S.Schema<OnRampsListResultItemVpcsByIdValueStateMap>;
export type OnRampsListResultItemVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsListResultItemVpcsByIdValueTagsMap: S.Schema<OnRampsListResultItemVpcsByIdValueTagsMap>;
export type OnRampsListResultItemVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsListResultItemVpcsByIdValueManagedByItemClientType: any;
export interface OnRampsListResultItemVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsListResultItemVpcsByIdValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsListResultItemVpcsByIdValueManagedByItem: S.Schema<OnRampsListResultItemVpcsByIdValueManagedByItem>;
export type OnRampsListResultItemVpcsByIdValueManagedByList = Array<OnRampsListResultItemVpcsByIdValueManagedByItem>;
export declare const OnRampsListResultItemVpcsByIdValueManagedByList: S.Schema<OnRampsListResultItemVpcsByIdValueManagedByList>;
export interface OnRampsListResultItemVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsListResultItemVpcsByIdValueCloudType;
    config: OnRampsListResultItemVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsListResultItemVpcsByIdValueObservationsMap;
    providerIds: OnRampsListResultItemVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsListResultItemVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsListResultItemVpcsByIdValueResourceType;
    sections: OnRampsListResultItemVpcsByIdValueSectionsList;
    state: OnRampsListResultItemVpcsByIdValueStateMap;
    tags: OnRampsListResultItemVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsListResultItemVpcsByIdValueManagedByList | null;
}
export declare const OnRampsListResultItemVpcsByIdValue: S.Schema<OnRampsListResultItemVpcsByIdValue>;
export type OnRampsListResultItemVpcsByIdMap = {
    [key: string]: OnRampsListResultItemVpcsByIdValue | undefined;
};
export declare const OnRampsListResultItemVpcsByIdMap: S.Schema<OnRampsListResultItemVpcsByIdMap>;
export type OnRampsListResultItemVpcsByIdUnavailableList = Array<string>;
export declare const OnRampsListResultItemVpcsByIdUnavailableList: S.Schema<OnRampsListResultItemVpcsByIdUnavailableList>;
export interface OnRampsListResultItem {
    id: string;
    cloudType: OnRampsListResultItemCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsListResultItemType;
    updatedAt: string;
    attachedHubs?: OnRampsListResultItemAttachedHubsList | null;
    attachedVpcs?: OnRampsListResultItemAttachedVpcsList | null;
    cloudAsn?: number | null;
    description?: string | null;
    hub?: string | null;
    lastAppliedAt?: string | null;
    lastExportedAt?: string | null;
    lastPlannedAt?: string | null;
    manageHubToHubAttachments?: boolean | null;
    manageVpcToHubAttachments?: boolean | null;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null;
    plannedResources?: OnRampsListResultItemPlannedResourcesList | null;
    plannedResourcesUnavailable?: boolean | null;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null;
    postApplyResources?: OnRampsListResultItemPostApplyResourcesMap | null;
    postApplyResourcesUnavailable?: boolean | null;
    region?: string | null;
    status?: OnRampsListResultItemStatus | null;
    vpc?: string | null;
    vpcsById?: OnRampsListResultItemVpcsByIdMap | null;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsListResultItemVpcsByIdUnavailableList | null;
}
export declare const OnRampsListResultItem: S.Schema<OnRampsListResultItem>;
export type OnRampsListResultList = Array<OnRampsListResultItem>;
export declare const OnRampsListResultList: S.Schema<OnRampsListResultList>;
export interface ListOnRampsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: OnRampsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListOnRampsResponse: S.Schema<ListOnRampsResponse>;
export type ResourcesListRequestResourceIdList = Array<string>;
export declare const ResourcesListRequestResourceIdList: S.Schema<ResourcesListRequestResourceIdList>;
export type ResourcesListRequestResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesListRequestResourceType: any;
export type ResourcesListRequestResourceTypeList = Array<ResourcesListRequestResourceType | (string & {})>;
export declare const ResourcesListRequestResourceTypeList: S.Schema<ResourcesListRequestResourceTypeList>;
export type ResourcesListRequestSearchList = Array<string>;
export declare const ResourcesListRequestSearchList: S.Schema<ResourcesListRequestSearchList>;
export interface ListResourcesRequest {
    accountId: string;
    cloudflare?: boolean;
    desc?: boolean;
    managed?: boolean;
    /** One of ["id", "resource_type", "region"]. */
    orderBy?: string;
    page?: number;
    perPage?: number;
    providerId?: string;
    region?: string;
    resourceGroup?: string;
    resourceId?: ResourcesListRequestResourceIdList;
    resourceType?: ResourcesListRequestResourceTypeList;
    search?: ResourcesListRequestSearchList;
    v2?: boolean;
}
export declare const ListResourcesRequest: S.Schema<ListResourcesRequest>;
export type ResourcesListResultItemCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesListResultItemCloudType: any;
export type ResourcesListResultItemConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const ResourcesListResultItemConfigMap: S.Schema<ResourcesListResultItemConfigMap>;
export type ResourcesListResultItemMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const ResourcesListResultItemMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type ResourcesListResultItemObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const ResourcesListResultItemObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type ResourcesListResultItemObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const ResourcesListResultItemObservationsMap: S.Schema<ResourcesListResultItemObservationsMap>;
export type ResourcesListResultItemProviderIdsList = Array<string>;
export declare const ResourcesListResultItemProviderIdsList: S.Schema<ResourcesListResultItemProviderIdsList>;
export type ResourcesListResultItemProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const ResourcesListResultItemProviderNamesByIdMap: S.Schema<ResourcesListResultItemProviderNamesByIdMap>;
export type ResourcesListResultItemResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesListResultItemResourceType: any;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListList = Array<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | ResourcesListResultItemSectionsItemHiddenItemsItemValueMcnListItem;
export declare const ResourcesListResultItemSectionsItemHiddenItemsItemValue: any;
export interface ResourcesListResultItemSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: ResourcesListResultItemSectionsItemHiddenItemsItemValue | null;
}
export declare const ResourcesListResultItemSectionsItemHiddenItemsItem: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsItem>;
export type ResourcesListResultItemSectionsItemHiddenItemsList = Array<ResourcesListResultItemSectionsItemHiddenItemsItem>;
export declare const ResourcesListResultItemSectionsItemHiddenItemsList: S.Schema<ResourcesListResultItemSectionsItemHiddenItemsList>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListList = Array<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | ResourcesListResultItemSectionsItemVisibleItemsItemValueMcnListItem;
export declare const ResourcesListResultItemSectionsItemVisibleItemsItemValue: any;
export interface ResourcesListResultItemSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: ResourcesListResultItemSectionsItemVisibleItemsItemValue | null;
}
export declare const ResourcesListResultItemSectionsItemVisibleItemsItem: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsItem>;
export type ResourcesListResultItemSectionsItemVisibleItemsList = Array<ResourcesListResultItemSectionsItemVisibleItemsItem>;
export declare const ResourcesListResultItemSectionsItemVisibleItemsList: S.Schema<ResourcesListResultItemSectionsItemVisibleItemsList>;
export interface ResourcesListResultItemSectionsItem {
    hiddenItems: ResourcesListResultItemSectionsItemHiddenItemsList;
    name: string;
    visibleItems: ResourcesListResultItemSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const ResourcesListResultItemSectionsItem: S.Schema<ResourcesListResultItemSectionsItem>;
export type ResourcesListResultItemSectionsList = Array<ResourcesListResultItemSectionsItem>;
export declare const ResourcesListResultItemSectionsList: S.Schema<ResourcesListResultItemSectionsList>;
export type ResourcesListResultItemStateMap = {
    [key: string]: unknown | undefined;
};
export declare const ResourcesListResultItemStateMap: S.Schema<ResourcesListResultItemStateMap>;
export type ResourcesListResultItemTagsMap = {
    [key: string]: string | undefined;
};
export declare const ResourcesListResultItemTagsMap: S.Schema<ResourcesListResultItemTagsMap>;
export type ResourcesListResultItemManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const ResourcesListResultItemManagedByItemClientType: any;
export interface ResourcesListResultItemManagedByItem {
    id: string;
    clientType: ResourcesListResultItemManagedByItemClientType;
    name: string;
}
export declare const ResourcesListResultItemManagedByItem: S.Schema<ResourcesListResultItemManagedByItem>;
export type ResourcesListResultItemManagedByList = Array<ResourcesListResultItemManagedByItem>;
export declare const ResourcesListResultItemManagedByList: S.Schema<ResourcesListResultItemManagedByList>;
export interface ResourcesListResultItem {
    id: string;
    accountId: string;
    cloudType: ResourcesListResultItemCloudType;
    config: ResourcesListResultItemConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: ResourcesListResultItemObservationsMap;
    providerIds: ResourcesListResultItemProviderIdsList;
    providerNamesById: ResourcesListResultItemProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: ResourcesListResultItemResourceType;
    sections: ResourcesListResultItemSectionsList;
    state: ResourcesListResultItemStateMap;
    tags: ResourcesListResultItemTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: ResourcesListResultItemManagedByList | null;
}
export declare const ResourcesListResultItem: S.Schema<ResourcesListResultItem>;
export type ResourcesListResultList = Array<ResourcesListResultItem>;
export declare const ResourcesListResultList: S.Schema<ResourcesListResultList>;
export interface ListResourcesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ResourcesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListResourcesResponse: S.Schema<ListResourcesResponse>;
export type CatalogSyncsEditRequestUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsEditRequestUpdateMode: any;
export interface PatchCatalogSyncRequest {
    accountId: string;
    syncId: string;
    description?: string;
    name?: string;
    policy?: string;
    updateMode?: CatalogSyncsEditRequestUpdateMode | (string & {});
}
export declare const PatchCatalogSyncRequest: S.Schema<PatchCatalogSyncRequest>;
export type CatalogSyncsEditResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsEditResponseDestinationType: any;
export type CatalogSyncsEditResponseUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsEditResponseUpdateMode: any;
export type CatalogSyncsEditResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const CatalogSyncsEditResponseErrorsValueCode: any;
export type CatalogSyncsEditResponseErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const CatalogSyncsEditResponseErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type CatalogSyncsEditResponseErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const CatalogSyncsEditResponseErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface CatalogSyncsEditResponseErrorsValue {
    code: CatalogSyncsEditResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const CatalogSyncsEditResponseErrorsValue: S.Schema<CatalogSyncsEditResponseErrorsValue>;
export type CatalogSyncsEditResponseErrorsMap = {
    [key: string]: CatalogSyncsEditResponseErrorsValue | undefined;
};
export declare const CatalogSyncsEditResponseErrorsMap: S.Schema<CatalogSyncsEditResponseErrorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsEditResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsEditResponseUpdateMode;
    errors?: CatalogSyncsEditResponseErrorsMap | null;
    includesDiscoveriesUntil?: string | null;
    lastAttemptedUpdateAt?: string | null;
    lastSuccessfulUpdateAt?: string | null;
}
export declare const PatchCatalogSyncResponse: S.Schema<PatchCatalogSyncResponse>;
export interface PatchCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    awsArn?: string;
    azureSubscriptionId?: string;
    azureTenantId?: string;
    description?: string;
    friendlyName?: string;
    gcpProjectId?: string;
    gcpServiceAccountEmail?: string;
}
export declare const PatchCloudIntegrationRequest: S.Schema<PatchCloudIntegrationRequest>;
export type CloudIntegrationsEditResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const CloudIntegrationsEditResponseCloudType: any;
export type CloudIntegrationsEditResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export declare const CloudIntegrationsEditResponseLifecycleState: any;
export type CloudIntegrationsEditResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsEditResponseState: any;
export type CloudIntegrationsEditResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsEditResponseStateV2: any;
export type CloudIntegrationsEditResponseStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsEditResponseStatusDiscoveryProgress: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsEditResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsEditResponseStatusDiscoveryProgressV2: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsEditResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsEditResponseStatusLastDiscoveryStatus: any;
export type CloudIntegrationsEditResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsEditResponseStatusLastDiscoveryStatusV2: any;
export type CloudIntegrationsEditResponseStatusRegionsList = Array<string>;
export declare const CloudIntegrationsEditResponseStatusRegionsList: S.Schema<CloudIntegrationsEditResponseStatusRegionsList>;
export type CloudIntegrationsEditResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const CloudIntegrationsEditResponseStatusInUseByItemClientType: any;
export interface CloudIntegrationsEditResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsEditResponseStatusInUseByItemClientType;
    name: string;
}
export declare const CloudIntegrationsEditResponseStatusInUseByItem: S.Schema<CloudIntegrationsEditResponseStatusInUseByItem>;
export type CloudIntegrationsEditResponseStatusInUseByList = Array<CloudIntegrationsEditResponseStatusInUseByItem>;
export declare const CloudIntegrationsEditResponseStatusInUseByList: S.Schema<CloudIntegrationsEditResponseStatusInUseByList>;
export interface CloudIntegrationsEditResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsEditResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsEditResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsEditResponseStatusRegionsList;
    credentialsGoodSince?: string | null;
    credentialsMissingSince?: string | null;
    credentialsRejectedSince?: string | null;
    discoveryMessage?: string | null;
    discoveryMessageV2?: string | null;
    inUseBy?: CloudIntegrationsEditResponseStatusInUseByList | null;
    lastDiscoveryCompletedAt?: string | null;
    lastDiscoveryCompletedAtV2?: string | null;
    lastDiscoveryStartedAt?: string | null;
    lastDiscoveryStartedAtV2?: string | null;
    lastUpdated?: string | null;
}
export declare const CloudIntegrationsEditResponseStatus: S.Schema<CloudIntegrationsEditResponseStatus>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsEditResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsEditResponseLifecycleState;
    state: CloudIntegrationsEditResponseState;
    stateV2: CloudIntegrationsEditResponseStateV2;
    awsArn?: string | null;
    azureSubscriptionId?: string | null;
    azureTenantId?: string | null;
    description?: string | null;
    gcpProjectId?: string | null;
    gcpServiceAccountEmail?: string | null;
    status?: CloudIntegrationsEditResponseStatus | null;
}
export declare const PatchCloudIntegrationResponse: S.Schema<PatchCloudIntegrationResponse>;
export type OnRampsEditRequestAttachedHubsList = Array<string>;
export declare const OnRampsEditRequestAttachedHubsList: S.Schema<OnRampsEditRequestAttachedHubsList>;
export type OnRampsEditRequestAttachedVpcsList = Array<string>;
export declare const OnRampsEditRequestAttachedVpcsList: S.Schema<OnRampsEditRequestAttachedVpcsList>;
export interface PatchOnRampRequest {
    accountId: string;
    onrampId: string;
    attachedHubs?: OnRampsEditRequestAttachedHubsList;
    attachedVpcs?: OnRampsEditRequestAttachedVpcsList;
    description?: string;
    installRoutesInCloud?: boolean;
    installRoutesInMagicWan?: boolean;
    manageHubToHubAttachments?: boolean;
    manageVpcToHubAttachments?: boolean;
    name?: string;
    vpc?: string;
}
export declare const PatchOnRampRequest: S.Schema<PatchOnRampRequest>;
export type OnRampsEditResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export declare const OnRampsEditResponseCloudType: any;
export type OnRampsEditResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export declare const OnRampsEditResponseType: any;
export type OnRampsEditResponseAttachedHubsList = Array<string>;
export declare const OnRampsEditResponseAttachedHubsList: S.Schema<OnRampsEditResponseAttachedHubsList>;
export type OnRampsEditResponseAttachedVpcsList = Array<string>;
export declare const OnRampsEditResponseAttachedVpcsList: S.Schema<OnRampsEditResponseAttachedVpcsList>;
export type OnRampsEditResponsePlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsEditResponsePlannedMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsEditResponsePlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsEditResponsePlannedResourcesItemDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsEditResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export declare const OnRampsEditResponsePlannedResourcesItemKeysRequireReplaceList: S.Schema<OnRampsEditResponsePlannedResourcesItemKeysRequireReplaceList>;
export type OnRampsEditResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsEditResponsePlannedResourcesItemMonthlyCostEstimateDiff: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsEditResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export declare const OnRampsEditResponsePlannedResourcesItemPlannedAction: any;
export type OnRampsEditResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponsePlannedResourcesItemResourceCloudType: any;
export type OnRampsEditResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponsePlannedResourcesItemResourceResourceType: any;
export interface OnRampsEditResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsEditResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export declare const OnRampsEditResponsePlannedResourcesItemResource: S.Schema<OnRampsEditResponsePlannedResourcesItemResource>;
export interface OnRampsEditResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsEditResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsEditResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsEditResponsePlannedResourcesItemResource;
}
export declare const OnRampsEditResponsePlannedResourcesItem: S.Schema<OnRampsEditResponsePlannedResourcesItem>;
export type OnRampsEditResponsePlannedResourcesList = Array<OnRampsEditResponsePlannedResourcesItem>;
export declare const OnRampsEditResponsePlannedResourcesList: S.Schema<OnRampsEditResponsePlannedResourcesList>;
export type OnRampsEditResponsePostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsEditResponsePostApplyMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsEditResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponsePostApplyResourcesValueCloudType: any;
export type OnRampsEditResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsEditResponsePostApplyResourcesValueConfigMap: S.Schema<OnRampsEditResponsePostApplyResourcesValueConfigMap>;
export type OnRampsEditResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsEditResponsePostApplyResourcesValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsEditResponsePostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsEditResponsePostApplyResourcesValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsEditResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsEditResponsePostApplyResourcesValueObservationsMap: S.Schema<OnRampsEditResponsePostApplyResourcesValueObservationsMap>;
export type OnRampsEditResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export declare const OnRampsEditResponsePostApplyResourcesValueProviderIdsList: S.Schema<OnRampsEditResponsePostApplyResourcesValueProviderIdsList>;
export type OnRampsEditResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsEditResponsePostApplyResourcesValueProviderNamesByIdMap: S.Schema<OnRampsEditResponsePostApplyResourcesValueProviderNamesByIdMap>;
export type OnRampsEditResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponsePostApplyResourcesValueResourceType: any;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsList: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsList>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsList: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsList>;
export interface OnRampsEditResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsEditResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsEditResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsEditResponsePostApplyResourcesValueSectionsList = Array<OnRampsEditResponsePostApplyResourcesValueSectionsItem>;
export declare const OnRampsEditResponsePostApplyResourcesValueSectionsList: S.Schema<OnRampsEditResponsePostApplyResourcesValueSectionsList>;
export type OnRampsEditResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsEditResponsePostApplyResourcesValueStateMap: S.Schema<OnRampsEditResponsePostApplyResourcesValueStateMap>;
export type OnRampsEditResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsEditResponsePostApplyResourcesValueTagsMap: S.Schema<OnRampsEditResponsePostApplyResourcesValueTagsMap>;
export type OnRampsEditResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsEditResponsePostApplyResourcesValueManagedByItemClientType: any;
export interface OnRampsEditResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsEditResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsEditResponsePostApplyResourcesValueManagedByItem: S.Schema<OnRampsEditResponsePostApplyResourcesValueManagedByItem>;
export type OnRampsEditResponsePostApplyResourcesValueManagedByList = Array<OnRampsEditResponsePostApplyResourcesValueManagedByItem>;
export declare const OnRampsEditResponsePostApplyResourcesValueManagedByList: S.Schema<OnRampsEditResponsePostApplyResourcesValueManagedByList>;
export interface OnRampsEditResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsEditResponsePostApplyResourcesValueCloudType;
    config: OnRampsEditResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsEditResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsEditResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsEditResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsEditResponsePostApplyResourcesValueResourceType;
    sections: OnRampsEditResponsePostApplyResourcesValueSectionsList;
    state: OnRampsEditResponsePostApplyResourcesValueStateMap;
    tags: OnRampsEditResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsEditResponsePostApplyResourcesValueManagedByList | null;
}
export declare const OnRampsEditResponsePostApplyResourcesValue: S.Schema<OnRampsEditResponsePostApplyResourcesValue>;
export type OnRampsEditResponsePostApplyResourcesMap = {
    [key: string]: OnRampsEditResponsePostApplyResourcesValue | undefined;
};
export declare const OnRampsEditResponsePostApplyResourcesMap: S.Schema<OnRampsEditResponsePostApplyResourcesMap>;
export type OnRampsEditResponseStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsEditResponseStatusApplyProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsEditResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export declare const OnRampsEditResponseStatusLifecycleState: any;
export type OnRampsEditResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsEditResponseStatusPlanProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsEditResponseStatusRoutesList = Array<string>;
export declare const OnRampsEditResponseStatusRoutesList: S.Schema<OnRampsEditResponseStatusRoutesList>;
export type OnRampsEditResponseStatusTunnelsList = Array<string>;
export declare const OnRampsEditResponseStatusTunnelsList: S.Schema<OnRampsEditResponseStatusTunnelsList>;
export type OnRampsEditResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const OnRampsEditResponseStatusLifecycleErrorsValueCode: any;
export type OnRampsEditResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const OnRampsEditResponseStatusLifecycleErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type OnRampsEditResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const OnRampsEditResponseStatusLifecycleErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface OnRampsEditResponseStatusLifecycleErrorsValue {
    code: OnRampsEditResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const OnRampsEditResponseStatusLifecycleErrorsValue: S.Schema<OnRampsEditResponseStatusLifecycleErrorsValue>;
export type OnRampsEditResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsEditResponseStatusLifecycleErrorsValue | undefined;
};
export declare const OnRampsEditResponseStatusLifecycleErrorsMap: S.Schema<OnRampsEditResponseStatusLifecycleErrorsMap>;
export interface OnRampsEditResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsEditResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsEditResponseStatusRoutesList;
    tunnels: OnRampsEditResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsEditResponseStatusLifecycleErrorsMap | null;
}
export declare const OnRampsEditResponseStatus: S.Schema<OnRampsEditResponseStatus>;
export type OnRampsEditResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponseVpcsByIdValueCloudType: any;
export type OnRampsEditResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsEditResponseVpcsByIdValueConfigMap: S.Schema<OnRampsEditResponseVpcsByIdValueConfigMap>;
export type OnRampsEditResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsEditResponseVpcsByIdValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsEditResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsEditResponseVpcsByIdValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsEditResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsEditResponseVpcsByIdValueObservationsMap: S.Schema<OnRampsEditResponseVpcsByIdValueObservationsMap>;
export type OnRampsEditResponseVpcsByIdValueProviderIdsList = Array<string>;
export declare const OnRampsEditResponseVpcsByIdValueProviderIdsList: S.Schema<OnRampsEditResponseVpcsByIdValueProviderIdsList>;
export type OnRampsEditResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsEditResponseVpcsByIdValueProviderNamesByIdMap: S.Schema<OnRampsEditResponseVpcsByIdValueProviderNamesByIdMap>;
export type OnRampsEditResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponseVpcsByIdValueResourceType: any;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsList: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsList>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export declare const OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsList: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsList>;
export interface OnRampsEditResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsEditResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsEditResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsEditResponseVpcsByIdValueSectionsItem: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsItem>;
export type OnRampsEditResponseVpcsByIdValueSectionsList = Array<OnRampsEditResponseVpcsByIdValueSectionsItem>;
export declare const OnRampsEditResponseVpcsByIdValueSectionsList: S.Schema<OnRampsEditResponseVpcsByIdValueSectionsList>;
export type OnRampsEditResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsEditResponseVpcsByIdValueStateMap: S.Schema<OnRampsEditResponseVpcsByIdValueStateMap>;
export type OnRampsEditResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsEditResponseVpcsByIdValueTagsMap: S.Schema<OnRampsEditResponseVpcsByIdValueTagsMap>;
export type OnRampsEditResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsEditResponseVpcsByIdValueManagedByItemClientType: any;
export interface OnRampsEditResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsEditResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsEditResponseVpcsByIdValueManagedByItem: S.Schema<OnRampsEditResponseVpcsByIdValueManagedByItem>;
export type OnRampsEditResponseVpcsByIdValueManagedByList = Array<OnRampsEditResponseVpcsByIdValueManagedByItem>;
export declare const OnRampsEditResponseVpcsByIdValueManagedByList: S.Schema<OnRampsEditResponseVpcsByIdValueManagedByList>;
export interface OnRampsEditResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsEditResponseVpcsByIdValueCloudType;
    config: OnRampsEditResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsEditResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsEditResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsEditResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsEditResponseVpcsByIdValueResourceType;
    sections: OnRampsEditResponseVpcsByIdValueSectionsList;
    state: OnRampsEditResponseVpcsByIdValueStateMap;
    tags: OnRampsEditResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsEditResponseVpcsByIdValueManagedByList | null;
}
export declare const OnRampsEditResponseVpcsByIdValue: S.Schema<OnRampsEditResponseVpcsByIdValue>;
export type OnRampsEditResponseVpcsByIdMap = {
    [key: string]: OnRampsEditResponseVpcsByIdValue | undefined;
};
export declare const OnRampsEditResponseVpcsByIdMap: S.Schema<OnRampsEditResponseVpcsByIdMap>;
export type OnRampsEditResponseVpcsByIdUnavailableList = Array<string>;
export declare const OnRampsEditResponseVpcsByIdUnavailableList: S.Schema<OnRampsEditResponseVpcsByIdUnavailableList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOnRampResponse {
    id: string;
    cloudType: OnRampsEditResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsEditResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsEditResponseAttachedHubsList | null;
    attachedVpcs?: OnRampsEditResponseAttachedVpcsList | null;
    cloudAsn?: number | null;
    description?: string | null;
    hub?: string | null;
    lastAppliedAt?: string | null;
    lastExportedAt?: string | null;
    lastPlannedAt?: string | null;
    manageHubToHubAttachments?: boolean | null;
    manageVpcToHubAttachments?: boolean | null;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null;
    plannedResources?: OnRampsEditResponsePlannedResourcesList | null;
    plannedResourcesUnavailable?: boolean | null;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null;
    postApplyResources?: OnRampsEditResponsePostApplyResourcesMap | null;
    postApplyResourcesUnavailable?: boolean | null;
    region?: string | null;
    status?: OnRampsEditResponseStatus | null;
    vpc?: string | null;
    vpcsById?: OnRampsEditResponseVpcsByIdMap | null;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsEditResponseVpcsByIdUnavailableList | null;
}
export declare const PatchOnRampResponse: S.Schema<PatchOnRampResponse>;
export type OnRampsAddressSpacesEditRequestPrefixesList = Array<string>;
export declare const OnRampsAddressSpacesEditRequestPrefixesList: S.Schema<OnRampsAddressSpacesEditRequestPrefixesList>;
export interface PatchOnRampAddressSpaceRequest {
    accountId: string;
    prefixes: OnRampsAddressSpacesEditRequestPrefixesList;
}
export declare const PatchOnRampAddressSpaceRequest: S.Schema<PatchOnRampAddressSpaceRequest>;
export type OnRampsAddressSpacesEditResponsePrefixesList = Array<string>;
export declare const OnRampsAddressSpacesEditResponsePrefixesList: S.Schema<OnRampsAddressSpacesEditResponsePrefixesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchOnRampAddressSpaceResponse {
    prefixes: OnRampsAddressSpacesEditResponsePrefixesList;
}
export declare const PatchOnRampAddressSpaceResponse: S.Schema<PatchOnRampAddressSpaceResponse>;
export interface PlanOnRampRequest {
    accountId: string;
    onrampId: string;
}
export declare const PlanOnRampRequest: S.Schema<PlanOnRampRequest>;
export interface PlanOnRampResponse {
}
export declare const PlanOnRampResponse: S.Schema<PlanOnRampResponse>;
export interface PolicyPreviewResourceRequest {
    accountId: string;
    policy: string;
}
export declare const PolicyPreviewResourceRequest: S.Schema<PolicyPreviewResourceRequest>;
export type PolicyPreviewResourceResponse = string;
export declare const PolicyPreviewResourceResponse: S.Schema<PolicyPreviewResourceResponse>;
export type OnRampsAddressSpacesUpdateRequestPrefixesList = Array<string>;
export declare const OnRampsAddressSpacesUpdateRequestPrefixesList: S.Schema<OnRampsAddressSpacesUpdateRequestPrefixesList>;
export interface PutOnRampAddressSpaceRequest {
    accountId: string;
    prefixes: OnRampsAddressSpacesUpdateRequestPrefixesList;
}
export declare const PutOnRampAddressSpaceRequest: S.Schema<PutOnRampAddressSpaceRequest>;
export type OnRampsAddressSpacesUpdateResponsePrefixesList = Array<string>;
export declare const OnRampsAddressSpacesUpdateResponsePrefixesList: S.Schema<OnRampsAddressSpacesUpdateResponsePrefixesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutOnRampAddressSpaceResponse {
    prefixes: OnRampsAddressSpacesUpdateResponsePrefixesList;
}
export declare const PutOnRampAddressSpaceResponse: S.Schema<PutOnRampAddressSpaceResponse>;
export interface RefreshCatalogSyncRequest {
    accountId: string;
    syncId: string;
}
export declare const RefreshCatalogSyncRequest: S.Schema<RefreshCatalogSyncRequest>;
export type RefreshCatalogSyncResponse = string;
export declare const RefreshCatalogSyncResponse: S.Schema<RefreshCatalogSyncResponse>;
export type CatalogSyncsUpdateRequestUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsUpdateRequestUpdateMode: any;
export interface UpdateCatalogSyncRequest {
    accountId: string;
    syncId: string;
    description?: string;
    name?: string;
    policy?: string;
    updateMode?: CatalogSyncsUpdateRequestUpdateMode | (string & {});
}
export declare const UpdateCatalogSyncRequest: S.Schema<UpdateCatalogSyncRequest>;
export type CatalogSyncsUpdateResponseDestinationType = "NONE" | "ZERO_TRUST_LIST";
export declare const CatalogSyncsUpdateResponseDestinationType: any;
export type CatalogSyncsUpdateResponseUpdateMode = "AUTO" | "MANUAL";
export declare const CatalogSyncsUpdateResponseUpdateMode: any;
export type CatalogSyncsUpdateResponseErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const CatalogSyncsUpdateResponseErrorsValueCode: any;
export type CatalogSyncsUpdateResponseErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const CatalogSyncsUpdateResponseErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type CatalogSyncsUpdateResponseErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const CatalogSyncsUpdateResponseErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface CatalogSyncsUpdateResponseErrorsValue {
    code: CatalogSyncsUpdateResponseErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const CatalogSyncsUpdateResponseErrorsValue: S.Schema<CatalogSyncsUpdateResponseErrorsValue>;
export type CatalogSyncsUpdateResponseErrorsMap = {
    [key: string]: CatalogSyncsUpdateResponseErrorsValue | undefined;
};
export declare const CatalogSyncsUpdateResponseErrorsMap: S.Schema<CatalogSyncsUpdateResponseErrorsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateCatalogSyncResponse {
    id: string;
    description: string;
    destinationId: string;
    destinationType: CatalogSyncsUpdateResponseDestinationType;
    lastUserUpdateAt: string;
    name: string;
    policy: string;
    updateMode: CatalogSyncsUpdateResponseUpdateMode;
    errors?: CatalogSyncsUpdateResponseErrorsMap | null;
    includesDiscoveriesUntil?: string | null;
    lastAttemptedUpdateAt?: string | null;
    lastSuccessfulUpdateAt?: string | null;
}
export declare const UpdateCatalogSyncResponse: S.Schema<UpdateCatalogSyncResponse>;
export interface UpdateCloudIntegrationRequest {
    accountId: string;
    providerId: string;
    awsArn?: string;
    azureSubscriptionId?: string;
    azureTenantId?: string;
    description?: string;
    friendlyName?: string;
    gcpProjectId?: string;
    gcpServiceAccountEmail?: string;
}
export declare const UpdateCloudIntegrationRequest: S.Schema<UpdateCloudIntegrationRequest>;
export type CloudIntegrationsUpdateResponseCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const CloudIntegrationsUpdateResponseCloudType: any;
export type CloudIntegrationsUpdateResponseLifecycleState = "ACTIVE" | "PENDING_SETUP" | "RETIRED";
export declare const CloudIntegrationsUpdateResponseLifecycleState: any;
export type CloudIntegrationsUpdateResponseState = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsUpdateResponseState: any;
export type CloudIntegrationsUpdateResponseStateV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsUpdateResponseStateV2: any;
export type CloudIntegrationsUpdateResponseStatusDiscoveryProgress = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsUpdateResponseStatusDiscoveryProgress: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsUpdateResponseStatusDiscoveryProgressV2 = CloudIntegrationsCreateResponseStatusDiscoveryProgress;
export declare const CloudIntegrationsUpdateResponseStatusDiscoveryProgressV2: S.Schema<CloudIntegrationsCreateResponseStatusDiscoveryProgress>;
export type CloudIntegrationsUpdateResponseStatusLastDiscoveryStatus = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsUpdateResponseStatusLastDiscoveryStatus: any;
export type CloudIntegrationsUpdateResponseStatusLastDiscoveryStatusV2 = "UNSPECIFIED" | "PENDING" | "DISCOVERING" | "FAILED" | "SUCCEEDED";
export declare const CloudIntegrationsUpdateResponseStatusLastDiscoveryStatusV2: any;
export type CloudIntegrationsUpdateResponseStatusRegionsList = Array<string>;
export declare const CloudIntegrationsUpdateResponseStatusRegionsList: S.Schema<CloudIntegrationsUpdateResponseStatusRegionsList>;
export type CloudIntegrationsUpdateResponseStatusInUseByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const CloudIntegrationsUpdateResponseStatusInUseByItemClientType: any;
export interface CloudIntegrationsUpdateResponseStatusInUseByItem {
    id: string;
    clientType: CloudIntegrationsUpdateResponseStatusInUseByItemClientType;
    name: string;
}
export declare const CloudIntegrationsUpdateResponseStatusInUseByItem: S.Schema<CloudIntegrationsUpdateResponseStatusInUseByItem>;
export type CloudIntegrationsUpdateResponseStatusInUseByList = Array<CloudIntegrationsUpdateResponseStatusInUseByItem>;
export declare const CloudIntegrationsUpdateResponseStatusInUseByList: S.Schema<CloudIntegrationsUpdateResponseStatusInUseByList>;
export interface CloudIntegrationsUpdateResponseStatus {
    discoveryProgress: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    discoveryProgressV2: CloudIntegrationsCreateResponseStatusDiscoveryProgress;
    lastDiscoveryStatus: CloudIntegrationsUpdateResponseStatusLastDiscoveryStatus;
    lastDiscoveryStatusV2: CloudIntegrationsUpdateResponseStatusLastDiscoveryStatusV2;
    regions: CloudIntegrationsUpdateResponseStatusRegionsList;
    credentialsGoodSince?: string | null;
    credentialsMissingSince?: string | null;
    credentialsRejectedSince?: string | null;
    discoveryMessage?: string | null;
    discoveryMessageV2?: string | null;
    inUseBy?: CloudIntegrationsUpdateResponseStatusInUseByList | null;
    lastDiscoveryCompletedAt?: string | null;
    lastDiscoveryCompletedAtV2?: string | null;
    lastDiscoveryStartedAt?: string | null;
    lastDiscoveryStartedAtV2?: string | null;
    lastUpdated?: string | null;
}
export declare const CloudIntegrationsUpdateResponseStatus: S.Schema<CloudIntegrationsUpdateResponseStatus>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateCloudIntegrationResponse {
    id: string;
    cloudType: CloudIntegrationsUpdateResponseCloudType;
    friendlyName: string;
    lastUpdated: string;
    lifecycleState: CloudIntegrationsUpdateResponseLifecycleState;
    state: CloudIntegrationsUpdateResponseState;
    stateV2: CloudIntegrationsUpdateResponseStateV2;
    awsArn?: string | null;
    azureSubscriptionId?: string | null;
    azureTenantId?: string | null;
    description?: string | null;
    gcpProjectId?: string | null;
    gcpServiceAccountEmail?: string | null;
    status?: CloudIntegrationsUpdateResponseStatus | null;
}
export declare const UpdateCloudIntegrationResponse: S.Schema<UpdateCloudIntegrationResponse>;
export type OnRampsUpdateRequestAttachedHubsList = Array<string>;
export declare const OnRampsUpdateRequestAttachedHubsList: S.Schema<OnRampsUpdateRequestAttachedHubsList>;
export type OnRampsUpdateRequestAttachedVpcsList = Array<string>;
export declare const OnRampsUpdateRequestAttachedVpcsList: S.Schema<OnRampsUpdateRequestAttachedVpcsList>;
export interface UpdateOnRampRequest {
    accountId: string;
    onrampId: string;
    attachedHubs?: OnRampsUpdateRequestAttachedHubsList;
    attachedVpcs?: OnRampsUpdateRequestAttachedVpcsList;
    description?: string;
    installRoutesInCloud?: boolean;
    installRoutesInMagicWan?: boolean;
    manageHubToHubAttachments?: boolean;
    manageVpcToHubAttachments?: boolean;
    name?: string;
    vpc?: string;
}
export declare const UpdateOnRampRequest: S.Schema<UpdateOnRampRequest>;
export type OnRampsUpdateResponseCloudType = "AWS" | "AZURE" | "GOOGLE";
export declare const OnRampsUpdateResponseCloudType: any;
export type OnRampsUpdateResponseType = "OnrampTypeSingle" | "OnrampTypeHub";
export declare const OnRampsUpdateResponseType: any;
export type OnRampsUpdateResponseAttachedHubsList = Array<string>;
export declare const OnRampsUpdateResponseAttachedHubsList: S.Schema<OnRampsUpdateResponseAttachedHubsList>;
export type OnRampsUpdateResponseAttachedVpcsList = Array<string>;
export declare const OnRampsUpdateResponseAttachedVpcsList: S.Schema<OnRampsUpdateResponseAttachedVpcsList>;
export type OnRampsUpdateResponsePlannedMonthlyCostEstimate = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsUpdateResponsePlannedMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsUpdateResponsePlannedResourcesItemDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsUpdateResponsePlannedResourcesItemDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsUpdateResponsePlannedResourcesItemKeysRequireReplaceList = Array<string>;
export declare const OnRampsUpdateResponsePlannedResourcesItemKeysRequireReplaceList: S.Schema<OnRampsUpdateResponsePlannedResourcesItemKeysRequireReplaceList>;
export type OnRampsUpdateResponsePlannedResourcesItemMonthlyCostEstimateDiff = OnRampsCreateResponsePlannedMonthlyCostEstimate;
export declare const OnRampsUpdateResponsePlannedResourcesItemMonthlyCostEstimateDiff: S.Schema<OnRampsCreateResponsePlannedMonthlyCostEstimate>;
export type OnRampsUpdateResponsePlannedResourcesItemPlannedAction = "no_op" | "create" | "update" | "replace" | "destroy";
export declare const OnRampsUpdateResponsePlannedResourcesItemPlannedAction: any;
export type OnRampsUpdateResponsePlannedResourcesItemResourceCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponsePlannedResourcesItemResourceCloudType: any;
export type OnRampsUpdateResponsePlannedResourcesItemResourceResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponsePlannedResourcesItemResourceResourceType: any;
export interface OnRampsUpdateResponsePlannedResourcesItemResource {
    id: string;
    cloudType: OnRampsUpdateResponsePlannedResourcesItemResourceCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePlannedResourcesItemResourceResourceType;
    title: string;
}
export declare const OnRampsUpdateResponsePlannedResourcesItemResource: S.Schema<OnRampsUpdateResponsePlannedResourcesItemResource>;
export interface OnRampsUpdateResponsePlannedResourcesItem {
    diff: OnRampsCreateResponsePlannedResourcesItemDiff;
    keysRequireReplace: OnRampsUpdateResponsePlannedResourcesItemKeysRequireReplaceList;
    monthlyCostEstimateDiff: OnRampsCreateResponsePlannedMonthlyCostEstimate;
    plannedAction: OnRampsUpdateResponsePlannedResourcesItemPlannedAction;
    resource: OnRampsUpdateResponsePlannedResourcesItemResource;
}
export declare const OnRampsUpdateResponsePlannedResourcesItem: S.Schema<OnRampsUpdateResponsePlannedResourcesItem>;
export type OnRampsUpdateResponsePlannedResourcesList = Array<OnRampsUpdateResponsePlannedResourcesItem>;
export declare const OnRampsUpdateResponsePlannedResourcesList: S.Schema<OnRampsUpdateResponsePlannedResourcesList>;
export type OnRampsUpdateResponsePostApplyMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsUpdateResponsePostApplyMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsUpdateResponsePostApplyResourcesValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponsePostApplyResourcesValueCloudType: any;
export type OnRampsUpdateResponsePostApplyResourcesValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsUpdateResponsePostApplyResourcesValueConfigMap: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueConfigMap>;
export type OnRampsUpdateResponsePostApplyResourcesValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsUpdateResponsePostApplyResourcesValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsUpdateResponsePostApplyResourcesValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsUpdateResponsePostApplyResourcesValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsUpdateResponsePostApplyResourcesValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsUpdateResponsePostApplyResourcesValueObservationsMap: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueObservationsMap>;
export type OnRampsUpdateResponsePostApplyResourcesValueProviderIdsList = Array<string>;
export declare const OnRampsUpdateResponsePostApplyResourcesValueProviderIdsList: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueProviderIdsList>;
export type OnRampsUpdateResponsePostApplyResourcesValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsUpdateResponsePostApplyResourcesValueProviderNamesByIdMap: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueProviderNamesByIdMap>;
export type OnRampsUpdateResponsePostApplyResourcesValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponsePostApplyResourcesValueResourceType: any;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsItem>;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsList: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsList>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsItem>;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsList: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsList>;
export interface OnRampsUpdateResponsePostApplyResourcesValueSectionsItem {
    hiddenItems: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsUpdateResponsePostApplyResourcesValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueSectionsList = Array<OnRampsUpdateResponsePostApplyResourcesValueSectionsItem>;
export declare const OnRampsUpdateResponsePostApplyResourcesValueSectionsList: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueSectionsList>;
export type OnRampsUpdateResponsePostApplyResourcesValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsUpdateResponsePostApplyResourcesValueStateMap: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueStateMap>;
export type OnRampsUpdateResponsePostApplyResourcesValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsUpdateResponsePostApplyResourcesValueTagsMap: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueTagsMap>;
export type OnRampsUpdateResponsePostApplyResourcesValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsUpdateResponsePostApplyResourcesValueManagedByItemClientType: any;
export interface OnRampsUpdateResponsePostApplyResourcesValueManagedByItem {
    id: string;
    clientType: OnRampsUpdateResponsePostApplyResourcesValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValueManagedByItem: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueManagedByItem>;
export type OnRampsUpdateResponsePostApplyResourcesValueManagedByList = Array<OnRampsUpdateResponsePostApplyResourcesValueManagedByItem>;
export declare const OnRampsUpdateResponsePostApplyResourcesValueManagedByList: S.Schema<OnRampsUpdateResponsePostApplyResourcesValueManagedByList>;
export interface OnRampsUpdateResponsePostApplyResourcesValue {
    id: string;
    accountId: string;
    cloudType: OnRampsUpdateResponsePostApplyResourcesValueCloudType;
    config: OnRampsUpdateResponsePostApplyResourcesValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsUpdateResponsePostApplyResourcesValueObservationsMap;
    providerIds: OnRampsUpdateResponsePostApplyResourcesValueProviderIdsList;
    providerNamesById: OnRampsUpdateResponsePostApplyResourcesValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsUpdateResponsePostApplyResourcesValueResourceType;
    sections: OnRampsUpdateResponsePostApplyResourcesValueSectionsList;
    state: OnRampsUpdateResponsePostApplyResourcesValueStateMap;
    tags: OnRampsUpdateResponsePostApplyResourcesValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsUpdateResponsePostApplyResourcesValueManagedByList | null;
}
export declare const OnRampsUpdateResponsePostApplyResourcesValue: S.Schema<OnRampsUpdateResponsePostApplyResourcesValue>;
export type OnRampsUpdateResponsePostApplyResourcesMap = {
    [key: string]: OnRampsUpdateResponsePostApplyResourcesValue | undefined;
};
export declare const OnRampsUpdateResponsePostApplyResourcesMap: S.Schema<OnRampsUpdateResponsePostApplyResourcesMap>;
export type OnRampsUpdateResponseStatusApplyProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsUpdateResponseStatusApplyProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsUpdateResponseStatusLifecycleState = "OnrampNeedsApply" | "OnrampPendingPlan" | "OnrampPlanning" | "OnrampPlanFailed" | "OnrampPendingApproval" | "OnrampPendingApply" | "OnrampApplying" | "OnrampApplyFailed" | "OnrampActive" | "OnrampPendingDestroy" | "OnrampDestroying" | "OnrampDestroyFailed";
export declare const OnRampsUpdateResponseStatusLifecycleState: any;
export type OnRampsUpdateResponseStatusPlanProgress = OnRampsCreateResponseStatusApplyProgress;
export declare const OnRampsUpdateResponseStatusPlanProgress: S.Schema<OnRampsCreateResponseStatusApplyProgress>;
export type OnRampsUpdateResponseStatusRoutesList = Array<string>;
export declare const OnRampsUpdateResponseStatusRoutesList: S.Schema<OnRampsUpdateResponseStatusRoutesList>;
export type OnRampsUpdateResponseStatusTunnelsList = Array<string>;
export declare const OnRampsUpdateResponseStatusTunnelsList: S.Schema<OnRampsUpdateResponseStatusTunnelsList>;
export type OnRampsUpdateResponseStatusLifecycleErrorsValueCode = 1001 | 1002 | 1003 | 1004 | 1005 | 1006 | 1007 | 1008 | 1009 | 1010 | 1011 | 1012 | 1013 | 1014 | 1015 | 1016 | 1017 | 1018 | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 3001 | 3002 | 3003 | 3004 | 3005 | 3006 | 3007 | 4001 | 4002 | 4003 | 4004 | 4005 | 4006 | 4007 | 4008 | 4009 | 4010 | 4011 | 4012 | 4013 | 4014 | 4015 | 4016 | 4017 | 4018 | 4019 | 4020 | 4021 | 4022 | 4023 | 5001 | 5002 | 5003 | 5004 | 102000 | 102001 | 102002 | 102003 | 102004 | 102005 | 102006 | 102007 | 102008 | 102009 | 102010 | 102011 | 102012 | 102013 | 102014 | 102015 | 102016 | 102017 | 102018 | 102019 | 102020 | 102021 | 102022 | 102023 | 102024 | 102025 | 102026 | 102027 | 102028 | 102029 | 102030 | 102031 | 102032 | 102033 | 102034 | 102035 | 102036 | 102037 | 102038 | 102039 | 102040 | 102041 | 102042 | 102043 | 102044 | 102045 | 102046 | 102047 | 102048 | 102049 | 102050 | 102051 | 102052 | 102053 | 102054 | 102055 | 102056 | 102057 | 102058 | 102059 | 102060 | 102061 | 102062 | 102063 | 102064 | 102065 | 102066 | 102067 | 102068 | 102069 | 102070 | 102071 | 102072 | 103001 | 103002 | 103003 | 103004 | 103005 | 103006 | 103007 | 103008;
export declare const OnRampsUpdateResponseStatusLifecycleErrorsValueCode: any;
export type OnRampsUpdateResponseStatusLifecycleErrorsValueMeta = CatalogSyncsCreateResponseErrorsValueMeta;
export declare const OnRampsUpdateResponseStatusLifecycleErrorsValueMeta: S.Schema<CatalogSyncsCreateResponseErrorsValueMeta>;
export type OnRampsUpdateResponseStatusLifecycleErrorsValueSource = CatalogSyncsCreateResponseErrorsValueSource;
export declare const OnRampsUpdateResponseStatusLifecycleErrorsValueSource: S.Schema<CatalogSyncsCreateResponseErrorsValueSource>;
export interface OnRampsUpdateResponseStatusLifecycleErrorsValue {
    code: OnRampsUpdateResponseStatusLifecycleErrorsValueCode;
    message: string;
    documentationUrl?: string | null;
    meta?: CatalogSyncsCreateResponseErrorsValueMeta | null;
    source?: CatalogSyncsCreateResponseErrorsValueSource | null;
}
export declare const OnRampsUpdateResponseStatusLifecycleErrorsValue: S.Schema<OnRampsUpdateResponseStatusLifecycleErrorsValue>;
export type OnRampsUpdateResponseStatusLifecycleErrorsMap = {
    [key: string]: OnRampsUpdateResponseStatusLifecycleErrorsValue | undefined;
};
export declare const OnRampsUpdateResponseStatusLifecycleErrorsMap: S.Schema<OnRampsUpdateResponseStatusLifecycleErrorsMap>;
export interface OnRampsUpdateResponseStatus {
    applyProgress: OnRampsCreateResponseStatusApplyProgress;
    lifecycleState: OnRampsUpdateResponseStatusLifecycleState;
    planProgress: OnRampsCreateResponseStatusApplyProgress;
    routes: OnRampsUpdateResponseStatusRoutesList;
    tunnels: OnRampsUpdateResponseStatusTunnelsList;
    lifecycleErrors?: OnRampsUpdateResponseStatusLifecycleErrorsMap | null;
}
export declare const OnRampsUpdateResponseStatus: S.Schema<OnRampsUpdateResponseStatus>;
export type OnRampsUpdateResponseVpcsByIdValueCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponseVpcsByIdValueCloudType: any;
export type OnRampsUpdateResponseVpcsByIdValueConfigMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsUpdateResponseVpcsByIdValueConfigMap: S.Schema<OnRampsUpdateResponseVpcsByIdValueConfigMap>;
export type OnRampsUpdateResponseVpcsByIdValueMonthlyCostEstimate = OnRampsCreateResponsePostApplyMonthlyCostEstimate;
export declare const OnRampsUpdateResponseVpcsByIdValueMonthlyCostEstimate: S.Schema<OnRampsCreateResponsePostApplyMonthlyCostEstimate>;
export type OnRampsUpdateResponseVpcsByIdValueObservationsValue = OnRampsCreateResponsePostApplyResourcesValueObservationsValue;
export declare const OnRampsUpdateResponseVpcsByIdValueObservationsValue: S.Schema<OnRampsCreateResponsePostApplyResourcesValueObservationsValue>;
export type OnRampsUpdateResponseVpcsByIdValueObservationsMap = {
    [key: string]: OnRampsCreateResponsePostApplyResourcesValueObservationsValue | undefined;
};
export declare const OnRampsUpdateResponseVpcsByIdValueObservationsMap: S.Schema<OnRampsUpdateResponseVpcsByIdValueObservationsMap>;
export type OnRampsUpdateResponseVpcsByIdValueProviderIdsList = Array<string>;
export declare const OnRampsUpdateResponseVpcsByIdValueProviderIdsList: S.Schema<OnRampsUpdateResponseVpcsByIdValueProviderIdsList>;
export type OnRampsUpdateResponseVpcsByIdValueProviderNamesByIdMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsUpdateResponseVpcsByIdValueProviderNamesByIdMap: S.Schema<OnRampsUpdateResponseVpcsByIdValueProviderNamesByIdMap>;
export type OnRampsUpdateResponseVpcsByIdValueResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponseVpcsByIdValueResourceType: any;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem: any;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListItem>;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItemListList;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValueMcnListItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue: any;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItemValue | null;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsItem>;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsList: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsList>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff = OnRampsCreateResponsePlannedResourcesItemDiff;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItemYamlDiff: S.Schema<OnRampsCreateResponsePlannedResourcesItemDiff>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnYamlDiffItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnStringItem: S.Schema<OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType = "AWS" | "AZURE" | "GOOGLE" | "CLOUDFLARE";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType: any;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType = "aws_customer_gateway" | "aws_egress_only_internet_gateway" | "aws_internet_gateway" | "aws_instance" | "aws_network_interface" | "aws_route" | "aws_route_table" | "aws_route_table_association" | "aws_subnet" | "aws_vpc" | "aws_vpc_ipv4_cidr_block_association" | "aws_vpn_connection" | "aws_vpn_connection_route" | "aws_vpn_gateway" | "aws_security_group" | "aws_vpc_security_group_ingress_rule" | "aws_vpc_security_group_egress_rule" | "aws_ec2_managed_prefix_list" | "aws_ec2_transit_gateway" | "aws_ec2_transit_gateway_prefix_list_reference" | "aws_ec2_transit_gateway_vpc_attachment" | "azurerm_application_security_group" | "azurerm_lb" | "azurerm_lb_backend_address_pool" | "azurerm_lb_nat_pool" | "azurerm_lb_nat_rule" | "azurerm_lb_rule" | "azurerm_local_network_gateway" | "azurerm_network_interface" | "azurerm_network_interface_application_security_group_association" | "azurerm_network_interface_backend_address_pool_association" | "azurerm_network_interface_security_group_association" | "azurerm_network_security_group" | "azurerm_public_ip" | "azurerm_route" | "azurerm_route_table" | "azurerm_subnet" | "azurerm_subnet_route_table_association" | "azurerm_virtual_machine" | "azurerm_virtual_network_gateway_connection" | "azurerm_virtual_network" | "azurerm_virtual_network_gateway" | "google_compute_network" | "google_compute_subnetwork" | "google_compute_vpn_gateway" | "google_compute_vpn_tunnel" | "google_compute_route" | "google_compute_address" | "google_compute_global_address" | "google_compute_router" | "google_compute_interconnect_attachment" | "google_compute_ha_vpn_gateway" | "google_compute_forwarding_rule" | "google_compute_network_firewall_policy" | "google_compute_network_firewall_policy_rule" | "cloudflare_static_route" | "cloudflare_ipsec_tunnel";
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType: any;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview {
    id: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewCloudType;
    detail: string;
    name: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreviewResourceType;
    title: string;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem {
    itemType: string;
    resourcePreview: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItemResourcePreview;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItemMcnResourcePreviewItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem: any;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListItem>;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem {
    itemType: string;
    list: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItemListList;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue = OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnStringItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlItem | OnRampsCreateResponsePostApplyResourcesValueSectionsItemHiddenItemsItemValueMcnYamlDiffItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnResourcePreviewItem | OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValueMcnListItem;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue: any;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItem {
    helpText?: string | null;
    name?: string | null;
    value?: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItemValue | null;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsItem>;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsList: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsList>;
export interface OnRampsUpdateResponseVpcsByIdValueSectionsItem {
    hiddenItems: OnRampsUpdateResponseVpcsByIdValueSectionsItemHiddenItemsList;
    name: string;
    visibleItems: OnRampsUpdateResponseVpcsByIdValueSectionsItemVisibleItemsList;
    helpText?: string | null;
}
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsItem>;
export type OnRampsUpdateResponseVpcsByIdValueSectionsList = Array<OnRampsUpdateResponseVpcsByIdValueSectionsItem>;
export declare const OnRampsUpdateResponseVpcsByIdValueSectionsList: S.Schema<OnRampsUpdateResponseVpcsByIdValueSectionsList>;
export type OnRampsUpdateResponseVpcsByIdValueStateMap = {
    [key: string]: unknown | undefined;
};
export declare const OnRampsUpdateResponseVpcsByIdValueStateMap: S.Schema<OnRampsUpdateResponseVpcsByIdValueStateMap>;
export type OnRampsUpdateResponseVpcsByIdValueTagsMap = {
    [key: string]: string | undefined;
};
export declare const OnRampsUpdateResponseVpcsByIdValueTagsMap: S.Schema<OnRampsUpdateResponseVpcsByIdValueTagsMap>;
export type OnRampsUpdateResponseVpcsByIdValueManagedByItemClientType = "MAGIC_WAN_CLOUD_ONRAMP";
export declare const OnRampsUpdateResponseVpcsByIdValueManagedByItemClientType: any;
export interface OnRampsUpdateResponseVpcsByIdValueManagedByItem {
    id: string;
    clientType: OnRampsUpdateResponseVpcsByIdValueManagedByItemClientType;
    name: string;
}
export declare const OnRampsUpdateResponseVpcsByIdValueManagedByItem: S.Schema<OnRampsUpdateResponseVpcsByIdValueManagedByItem>;
export type OnRampsUpdateResponseVpcsByIdValueManagedByList = Array<OnRampsUpdateResponseVpcsByIdValueManagedByItem>;
export declare const OnRampsUpdateResponseVpcsByIdValueManagedByList: S.Schema<OnRampsUpdateResponseVpcsByIdValueManagedByList>;
export interface OnRampsUpdateResponseVpcsByIdValue {
    id: string;
    accountId: string;
    cloudType: OnRampsUpdateResponseVpcsByIdValueCloudType;
    config: OnRampsUpdateResponseVpcsByIdValueConfigMap;
    deploymentProvider: string;
    managed: boolean;
    monthlyCostEstimate: OnRampsCreateResponsePostApplyMonthlyCostEstimate;
    name: string;
    nativeId: string;
    observations: OnRampsUpdateResponseVpcsByIdValueObservationsMap;
    providerIds: OnRampsUpdateResponseVpcsByIdValueProviderIdsList;
    providerNamesById: OnRampsUpdateResponseVpcsByIdValueProviderNamesByIdMap;
    region: string;
    resourceGroup: string;
    resourceType: OnRampsUpdateResponseVpcsByIdValueResourceType;
    sections: OnRampsUpdateResponseVpcsByIdValueSectionsList;
    state: OnRampsUpdateResponseVpcsByIdValueStateMap;
    tags: OnRampsUpdateResponseVpcsByIdValueTagsMap;
    updatedAt: string;
    url: string;
    managedBy?: OnRampsUpdateResponseVpcsByIdValueManagedByList | null;
}
export declare const OnRampsUpdateResponseVpcsByIdValue: S.Schema<OnRampsUpdateResponseVpcsByIdValue>;
export type OnRampsUpdateResponseVpcsByIdMap = {
    [key: string]: OnRampsUpdateResponseVpcsByIdValue | undefined;
};
export declare const OnRampsUpdateResponseVpcsByIdMap: S.Schema<OnRampsUpdateResponseVpcsByIdMap>;
export type OnRampsUpdateResponseVpcsByIdUnavailableList = Array<string>;
export declare const OnRampsUpdateResponseVpcsByIdUnavailableList: S.Schema<OnRampsUpdateResponseVpcsByIdUnavailableList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateOnRampResponse {
    id: string;
    cloudType: OnRampsUpdateResponseCloudType;
    dynamicRouting: boolean;
    installRoutesInCloud: boolean;
    installRoutesInMagicWan: boolean;
    name: string;
    type: OnRampsUpdateResponseType;
    updatedAt: string;
    attachedHubs?: OnRampsUpdateResponseAttachedHubsList | null;
    attachedVpcs?: OnRampsUpdateResponseAttachedVpcsList | null;
    cloudAsn?: number | null;
    description?: string | null;
    hub?: string | null;
    lastAppliedAt?: string | null;
    lastExportedAt?: string | null;
    lastPlannedAt?: string | null;
    manageHubToHubAttachments?: boolean | null;
    manageVpcToHubAttachments?: boolean | null;
    plannedMonthlyCostEstimate?: OnRampsCreateResponsePlannedMonthlyCostEstimate | null;
    plannedResources?: OnRampsUpdateResponsePlannedResourcesList | null;
    plannedResourcesUnavailable?: boolean | null;
    postApplyMonthlyCostEstimate?: OnRampsCreateResponsePostApplyMonthlyCostEstimate | null;
    postApplyResources?: OnRampsUpdateResponsePostApplyResourcesMap | null;
    postApplyResourcesUnavailable?: boolean | null;
    region?: string | null;
    status?: OnRampsUpdateResponseStatus | null;
    vpc?: string | null;
    vpcsById?: OnRampsUpdateResponseVpcsByIdMap | null;
    /** The list of vpc IDs for which resource details failed to generate. */
    vpcsByIdUnavailable?: OnRampsUpdateResponseVpcsByIdUnavailableList | null;
}
export declare const UpdateOnRampResponse: S.Schema<UpdateOnRampResponse>;
export type ApplyOnRampError = CloudflareOpError;
/** Apply an On-ramp (Closed Beta). */
export declare const applyOnRamp: API.OperationMethod<ApplyOnRampRequest, ApplyOnRampResponse, ApplyOnRampError, CloudflareOpContext>;
export type CreateCatalogSyncError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Create a new Catalog Sync (Closed Beta). */
export declare const createCatalogSync: API.OperationMethod<CreateCatalogSyncRequest, CreateCatalogSyncResponse, CreateCatalogSyncError, CloudflareOpContext>;
export type CreateCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Create a new Cloud Integration (Closed Beta). */
export declare const createCloudIntegration: API.OperationMethod<CreateCloudIntegrationRequest, CreateCloudIntegrationResponse, CreateCloudIntegrationError, CloudflareOpContext>;
export type CreateOnRampError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Create a new On-ramp (Closed Beta). */
export declare const createOnRamp: API.OperationMethod<CreateOnRampRequest, CreateOnRampResponse, CreateOnRampError, CloudflareOpContext>;
export type DeleteCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Delete a Catalog Sync (Closed Beta). */
export declare const deleteCatalogSync: API.OperationMethod<DeleteCatalogSyncRequest, DeleteCatalogSyncResponse, DeleteCatalogSyncError, CloudflareOpContext>;
export type DeleteCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Delete a Cloud Integration (Closed Beta). */
export declare const deleteCloudIntegration: API.OperationMethod<DeleteCloudIntegrationRequest, DeleteCloudIntegrationResponse, DeleteCloudIntegrationError, CloudflareOpContext>;
export type DeleteOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Delete an On-ramp (Closed Beta). */
export declare const deleteOnRamp: API.OperationMethod<DeleteOnRampRequest, DeleteOnRampResponse, DeleteOnRampError, CloudflareOpContext>;
export type DiscoverAllCloudIntegrationError = CloudflareOpError;
/** Run discovery for all Cloud Integrations in an account (Closed Beta). */
export declare const discoverAllCloudIntegration: API.OperationMethod<DiscoverAllCloudIntegrationRequest, DiscoverAllCloudIntegrationResponse, DiscoverAllCloudIntegrationError, CloudflareOpContext>;
export type DiscoverCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** Run discovery for a Cloud Integration (Closed Beta). */
export declare const discoverCloudIntegration: API.OperationMethod<DiscoverCloudIntegrationRequest, DiscoverCloudIntegrationResponse, DiscoverCloudIntegrationError, CloudflareOpContext>;
export type ExportOnRampError = CloudflareOpError;
/** Export an On-ramp to terraform ready file(s) (Closed Beta). */
export declare const exportOnRamp: API.OperationMethod<ExportOnRampRequest, ExportOnRampResponse, ExportOnRampError, CloudflareOpContext>;
export type ExportResourceError = CloudflareOpError;
/** Export resources in the Resource Catalog as a JSON file (Closed Beta). */
export declare const exportResource: API.OperationMethod<ExportResourceRequest, ExportResourceResponse, ExportResourceError, CloudflareOpContext>;
export type GetCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Read a Catalog Sync (Closed Beta). */
export declare const getCatalogSync: API.OperationMethod<GetCatalogSyncRequest, GetCatalogSyncResponse, GetCatalogSyncError, CloudflareOpContext>;
export type GetCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Read a Cloud Integration (Closed Beta). */
export declare const getCloudIntegration: API.OperationMethod<GetCloudIntegrationRequest, GetCloudIntegrationResponse, GetCloudIntegrationError, CloudflareOpContext>;
export type GetOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Read an On-ramp (Closed Beta). */
export declare const getOnRamp: API.OperationMethod<GetOnRampRequest, GetOnRampResponse, GetOnRampError, CloudflareOpContext>;
export type GetResourceError = CloudflareOpError;
/** Read an resource from the Resource Catalog (Closed Beta). */
export declare const getResource: API.OperationMethod<GetResourceRequest, GetResourceResponse, GetResourceError, CloudflareOpContext>;
export type InitialSetupCloudIntegrationError = CloudflareOpError;
/** Get initial configuration to complete Cloud Integration setup (Closed Beta). */
export declare const initialSetupCloudIntegration: API.OperationMethod<InitialSetupCloudIntegrationRequest, InitialSetupCloudIntegrationResponse, InitialSetupCloudIntegrationError, CloudflareOpContext>;
export type ListCatalogSyncPrebuiltPoliciesError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List prebuilt catalog sync policies (Closed Beta). */
export declare const listCatalogSyncPrebuiltPolicies: API.PaginatedOperationMethod<ListCatalogSyncPrebuiltPoliciesRequest, ListCatalogSyncPrebuiltPoliciesResponse, ListCatalogSyncPrebuiltPoliciesError, CloudflareOpContext, CatalogSyncsPrebuiltPoliciesListResultItem>;
export type ListCatalogSyncsError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List Catalog Syncs (Closed Beta). */
export declare const listCatalogSyncs: API.PaginatedOperationMethod<ListCatalogSyncsRequest, ListCatalogSyncsResponse, ListCatalogSyncsError, CloudflareOpContext, CatalogSyncsListResultItem>;
export type ListCloudIntegrationsError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List Cloud Integrations (Closed Beta). */
export declare const listCloudIntegrations: API.PaginatedOperationMethod<ListCloudIntegrationsRequest, ListCloudIntegrationsResponse, ListCloudIntegrationsError, CloudflareOpContext, CloudIntegrationsListResultItem>;
export type ListOnRampAddressSpacesError = CloudflareOpError;
/** Read the Magic WAN Address Space (Closed Beta). */
export declare const listOnRampAddressSpaces: API.OperationMethod<ListOnRampAddressSpacesRequest, ListOnRampAddressSpacesResponse, ListOnRampAddressSpacesError, CloudflareOpContext>;
export type ListOnRampsError = FeatureNotEnabled | Forbidden | CloudflareOpError;
/** List On-ramps (Closed Beta). */
export declare const listOnRamps: API.PaginatedOperationMethod<ListOnRampsRequest, ListOnRampsResponse, ListOnRampsError, CloudflareOpContext, OnRampsListResultItem>;
export type ListResourcesError = CloudflareOpError;
/** List resources in the Resource Catalog (Closed Beta). */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest, ListResourcesResponse, ListResourcesError, CloudflareOpContext, ResourcesListResultItem>;
export type PatchCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Update a Catalog Sync (Closed Beta). */
export declare const patchCatalogSync: API.OperationMethod<PatchCatalogSyncRequest, PatchCatalogSyncResponse, PatchCatalogSyncError, CloudflareOpContext>;
export type PatchCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Update a Cloud Integration (Closed Beta). */
export declare const patchCloudIntegration: API.OperationMethod<PatchCloudIntegrationRequest, PatchCloudIntegrationResponse, PatchCloudIntegrationError, CloudflareOpContext>;
export type PatchOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Update an On-ramp (Closed Beta). */
export declare const patchOnRamp: API.OperationMethod<PatchOnRampRequest, PatchOnRampResponse, PatchOnRampError, CloudflareOpContext>;
export type PatchOnRampAddressSpaceError = CloudflareOpError;
/** Update the Magic WAN Address Space (Closed Beta). */
export declare const patchOnRampAddressSpace: API.OperationMethod<PatchOnRampAddressSpaceRequest, PatchOnRampAddressSpaceResponse, PatchOnRampAddressSpaceError, CloudflareOpContext>;
export type PlanOnRampError = CloudflareOpError;
/** Plan an On-ramp (Closed Beta). */
export declare const planOnRamp: API.OperationMethod<PlanOnRampRequest, PlanOnRampResponse, PlanOnRampError, CloudflareOpContext>;
export type PolicyPreviewResourceError = CloudflareOpError;
/** Preview Rego query result against the latest resource catalog (Closed Beta). */
export declare const policyPreviewResource: API.OperationMethod<PolicyPreviewResourceRequest, PolicyPreviewResourceResponse, PolicyPreviewResourceError, CloudflareOpContext>;
export type PutOnRampAddressSpaceError = CloudflareOpError;
/** Update the Magic WAN Address Space (Closed Beta). */
export declare const putOnRampAddressSpace: API.OperationMethod<PutOnRampAddressSpaceRequest, PutOnRampAddressSpaceResponse, PutOnRampAddressSpaceError, CloudflareOpContext>;
export type RefreshCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Refresh a Catalog Sync's destination by running the sync policy against latest resource catalog (Closed Beta). */
export declare const refreshCatalogSync: API.OperationMethod<RefreshCatalogSyncRequest, RefreshCatalogSyncResponse, RefreshCatalogSyncError, CloudflareOpContext>;
export type UpdateCatalogSyncError = FeatureNotEnabled | Forbidden | CatalogSyncNotFound | CloudflareOpError;
/** Update a Catalog Sync (Closed Beta). */
export declare const updateCatalogSync: API.OperationMethod<UpdateCatalogSyncRequest, UpdateCatalogSyncResponse, UpdateCatalogSyncError, CloudflareOpContext>;
export type UpdateCloudIntegrationError = FeatureNotEnabled | Forbidden | CloudIntegrationNotFound | CloudflareOpError;
/** Update a Cloud Integration (Closed Beta). */
export declare const updateCloudIntegration: API.OperationMethod<UpdateCloudIntegrationRequest, UpdateCloudIntegrationResponse, UpdateCloudIntegrationError, CloudflareOpContext>;
export type UpdateOnRampError = FeatureNotEnabled | Forbidden | OnRampNotFound | CloudflareOpError;
/** Update an On-ramp (Closed Beta). */
export declare const updateOnRamp: API.OperationMethod<UpdateOnRampRequest, UpdateOnRampResponse, UpdateOnRampError, CloudflareOpContext>;
//# sourceMappingURL=magic_cloud_networking.d.ts.map