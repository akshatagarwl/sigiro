import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidZoneIdentifier_base: S.Class<InvalidZoneIdentifier, S.TaggedStruct<"InvalidZoneIdentifier", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidZoneIdentifier extends /*@__PURE__*/ InvalidZoneIdentifier_base {
}
declare const PageRuleNotFound_base: S.Class<PageRuleNotFound, S.TaggedStruct<"PageRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class PageRuleNotFound extends /*@__PURE__*/ PageRuleNotFound_base {
}
export type CreateRequestActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const CreateRequestActionsItemAlwaysUseHTTPSId: any;
export interface CreateRequestActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: CreateRequestActionsItemAlwaysUseHTTPSId | (string & {});
}
export declare const CreateRequestActionsItemAlwaysUseHTTPS: S.Schema<CreateRequestActionsItemAlwaysUseHTTPS>;
export type CreateRequestActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const CreateRequestActionsItemAutomaticHTTPSRewritesId: any;
export type CreateRequestActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const CreateRequestActionsItemAutomaticHTTPSRewritesValue: any;
export interface CreateRequestActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: CreateRequestActionsItemAutomaticHTTPSRewritesId | (string & {});
    /** The status of Automatic HTTPS Rewrites. */
    value?: CreateRequestActionsItemAutomaticHTTPSRewritesValue | (string & {});
}
export declare const CreateRequestActionsItemAutomaticHTTPSRewrites: S.Schema<CreateRequestActionsItemAutomaticHTTPSRewrites>;
export type CreateRequestActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const CreateRequestActionsItemBrowserCacheTTLId: any;
export interface CreateRequestActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: CreateRequestActionsItemBrowserCacheTTLId | (string & {});
    /** The number of seconds to cache resources for. */
    value?: number;
}
export declare const CreateRequestActionsItemBrowserCacheTTL: S.Schema<CreateRequestActionsItemBrowserCacheTTL>;
export type CreateRequestActionsItemBrowserCheckId = "browser_check";
export declare const CreateRequestActionsItemBrowserCheckId: any;
export type CreateRequestActionsItemBrowserCheckValue = "on" | "off";
export declare const CreateRequestActionsItemBrowserCheckValue: any;
export interface CreateRequestActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: CreateRequestActionsItemBrowserCheckId | (string & {});
    /** The status of Browser Integrity Check. */
    value?: CreateRequestActionsItemBrowserCheckValue | (string & {});
}
export declare const CreateRequestActionsItemBrowserCheck: S.Schema<CreateRequestActionsItemBrowserCheck>;
export type CreateRequestActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const CreateRequestActionsItemBypassCacheOnCookieId: any;
export interface CreateRequestActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: CreateRequestActionsItemBypassCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the */
    value?: string;
}
export declare const CreateRequestActionsItemBypassCacheOnCookie: S.Schema<CreateRequestActionsItemBypassCacheOnCookie>;
export type CreateRequestActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const CreateRequestActionsItemCacheByDeviceTypeId: any;
export type CreateRequestActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const CreateRequestActionsItemCacheByDeviceTypeValue: any;
export interface CreateRequestActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: CreateRequestActionsItemCacheByDeviceTypeId | (string & {});
    /** The status of Cache By Device Type. */
    value?: CreateRequestActionsItemCacheByDeviceTypeValue | (string & {});
}
export declare const CreateRequestActionsItemCacheByDeviceType: S.Schema<CreateRequestActionsItemCacheByDeviceType>;
export type CreateRequestActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const CreateRequestActionsItemCacheDeceptionArmorId: any;
export type CreateRequestActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const CreateRequestActionsItemCacheDeceptionArmorValue: any;
export interface CreateRequestActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: CreateRequestActionsItemCacheDeceptionArmorId | (string & {});
    /** The status of Cache Deception Armor. */
    value?: CreateRequestActionsItemCacheDeceptionArmorValue | (string & {});
}
export declare const CreateRequestActionsItemCacheDeceptionArmor: S.Schema<CreateRequestActionsItemCacheDeceptionArmor>;
export type CreateRequestActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const CreateRequestActionsItemCacheKeyFieldsId: any;
export type CreateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const CreateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type CreateRequestActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const CreateRequestActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface CreateRequestActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: CreateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList;
    /** A list of cookies to include. */
    include?: CreateRequestActionsItemCacheKeyFieldsValueCookieIncludeList;
}
export declare const CreateRequestActionsItemCacheKeyFieldsValueCookie: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueCookie>;
export type CreateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const CreateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type CreateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const CreateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type CreateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const CreateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface CreateRequestActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: CreateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList;
    /** A list of headers to ignore. */
    exclude?: CreateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList;
    /** A list of headers to include. */
    include?: CreateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList;
}
export declare const CreateRequestActionsItemCacheKeyFieldsValueHeader: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueHeader>;
export interface CreateRequestActionsItemCacheKeyFieldsValueHost {
    /** Whether to include the Host header in the HTTP request sent */
    resolved?: boolean;
}
export declare const CreateRequestActionsItemCacheKeyFieldsValueHost: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueHost>;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringExclude = CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | (string & {}) | CreateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const CreateRequestActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type CreateRequestActionsItemCacheKeyFieldsValueQueryStringInclude = CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | (string & {}) | CreateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const CreateRequestActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface CreateRequestActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: CreateRequestActionsItemCacheKeyFieldsValueQueryStringExclude;
    /** Include all query string parameters. */
    include?: CreateRequestActionsItemCacheKeyFieldsValueQueryStringInclude;
}
export declare const CreateRequestActionsItemCacheKeyFieldsValueQueryString: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueQueryString>;
export interface CreateRequestActionsItemCacheKeyFieldsValueUser {
    /** Classifies a request as `mobile`, `desktop`, or `tablet` */
    deviceType?: boolean;
    /** Includes the client's country, derived from the IP address. */
    geo?: boolean;
    /** Includes the first language code contained in the */
    lang?: boolean;
}
export declare const CreateRequestActionsItemCacheKeyFieldsValueUser: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueUser>;
export interface CreateRequestActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: CreateRequestActionsItemCacheKeyFieldsValueCookie;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: CreateRequestActionsItemCacheKeyFieldsValueHeader;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateRequestActionsItemCacheKeyFieldsValueHost;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: CreateRequestActionsItemCacheKeyFieldsValueQueryString;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateRequestActionsItemCacheKeyFieldsValueUser;
}
export declare const CreateRequestActionsItemCacheKeyFieldsValue: S.Schema<CreateRequestActionsItemCacheKeyFieldsValue>;
export interface CreateRequestActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: CreateRequestActionsItemCacheKeyFieldsId | (string & {});
    value?: CreateRequestActionsItemCacheKeyFieldsValue;
}
export declare const CreateRequestActionsItemCacheKeyFields: S.Schema<CreateRequestActionsItemCacheKeyFields>;
export type CreateRequestActionsItemCacheLevelId = "cache_level";
export declare const CreateRequestActionsItemCacheLevelId: any;
export type CreateRequestActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const CreateRequestActionsItemCacheLevelValue: any;
export interface CreateRequestActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: CreateRequestActionsItemCacheLevelId | (string & {});
    /** * `bypass`: Cloudflare does not cache. */
    value?: CreateRequestActionsItemCacheLevelValue | (string & {});
}
export declare const CreateRequestActionsItemCacheLevel: S.Schema<CreateRequestActionsItemCacheLevel>;
export type CreateRequestActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const CreateRequestActionsItemCacheOnCookieId: any;
export interface CreateRequestActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: CreateRequestActionsItemCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the */
    value?: string;
}
export declare const CreateRequestActionsItemCacheOnCookie: S.Schema<CreateRequestActionsItemCacheOnCookie>;
export type CreateRequestActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const CreateRequestActionsItemCacheTTLByStatusId: any;
export type CreateRequestActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const CreateRequestActionsItemCacheTTLByStatusValueCase0: any;
export type CreateRequestActionsItemCacheTTLByStatusValue = number | CreateRequestActionsItemCacheTTLByStatusValueCase0 | (string & {});
export declare const CreateRequestActionsItemCacheTTLByStatusValue: any;
export interface CreateRequestActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: CreateRequestActionsItemCacheTTLByStatusId | (string & {});
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: CreateRequestActionsItemCacheTTLByStatusValue;
}
export declare const CreateRequestActionsItemCacheTTLByStatus: S.Schema<CreateRequestActionsItemCacheTTLByStatus>;
export type CreateRequestActionsItemDisableAppsId = "disable_apps";
export declare const CreateRequestActionsItemDisableAppsId: any;
export interface CreateRequestActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: CreateRequestActionsItemDisableAppsId | (string & {});
}
export declare const CreateRequestActionsItemDisableApps: S.Schema<CreateRequestActionsItemDisableApps>;
export type CreateRequestActionsItemDisablePerformanceId = "disable_performance";
export declare const CreateRequestActionsItemDisablePerformanceId: any;
export interface CreateRequestActionsItemDisablePerformance {
    /** Turn off */
    id?: CreateRequestActionsItemDisablePerformanceId | (string & {});
}
export declare const CreateRequestActionsItemDisablePerformance: S.Schema<CreateRequestActionsItemDisablePerformance>;
export type CreateRequestActionsItemDisableSecurityId = "disable_security";
export declare const CreateRequestActionsItemDisableSecurityId: any;
export interface CreateRequestActionsItemDisableSecurity {
    /** Turn off */
    id?: CreateRequestActionsItemDisableSecurityId | (string & {});
}
export declare const CreateRequestActionsItemDisableSecurity: S.Schema<CreateRequestActionsItemDisableSecurity>;
export type CreateRequestActionsItemDisableZarazId = "disable_zaraz";
export declare const CreateRequestActionsItemDisableZarazId: any;
export interface CreateRequestActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: CreateRequestActionsItemDisableZarazId | (string & {});
}
export declare const CreateRequestActionsItemDisableZaraz: S.Schema<CreateRequestActionsItemDisableZaraz>;
export type CreateRequestActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const CreateRequestActionsItemEdgeCacheTTLId: any;
export interface CreateRequestActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: CreateRequestActionsItemEdgeCacheTTLId | (string & {});
    value?: number;
}
export declare const CreateRequestActionsItemEdgeCacheTTL: S.Schema<CreateRequestActionsItemEdgeCacheTTL>;
export type CreateRequestActionsItemEmailObfuscationId = "email_obfuscation";
export declare const CreateRequestActionsItemEmailObfuscationId: any;
export type CreateRequestActionsItemEmailObfuscationValue = "on" | "off";
export declare const CreateRequestActionsItemEmailObfuscationValue: any;
export interface CreateRequestActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: CreateRequestActionsItemEmailObfuscationId | (string & {});
    /** The status of Email Obfuscation. */
    value?: CreateRequestActionsItemEmailObfuscationValue | (string & {});
}
export declare const CreateRequestActionsItemEmailObfuscation: S.Schema<CreateRequestActionsItemEmailObfuscation>;
export type CreateRequestActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const CreateRequestActionsItemExplicitCacheControlId: any;
export type CreateRequestActionsItemExplicitCacheControlValue = "on" | "off";
export declare const CreateRequestActionsItemExplicitCacheControlValue: any;
export interface CreateRequestActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: CreateRequestActionsItemExplicitCacheControlId | (string & {});
    /** The status of Origin Cache Control. */
    value?: CreateRequestActionsItemExplicitCacheControlValue | (string & {});
}
export declare const CreateRequestActionsItemExplicitCacheControl: S.Schema<CreateRequestActionsItemExplicitCacheControl>;
export type CreateRequestActionsItemForwardingURLId = "forwarding_url";
export declare const CreateRequestActionsItemForwardingURLId: any;
export type CreateRequestActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const CreateRequestActionsItemForwardingURLValueStatusCode: any;
export interface CreateRequestActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: CreateRequestActionsItemForwardingURLValueStatusCode | (number & {});
    /** The URL to redirect the request to. */
    url?: string;
}
export declare const CreateRequestActionsItemForwardingURLValue: S.Schema<CreateRequestActionsItemForwardingURLValue>;
export interface CreateRequestActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: CreateRequestActionsItemForwardingURLId | (string & {});
    value?: CreateRequestActionsItemForwardingURLValue;
}
export declare const CreateRequestActionsItemForwardingURL: S.Schema<CreateRequestActionsItemForwardingURL>;
export type CreateRequestActionsItemHostHeaderOverrideId = "host_header_override";
export declare const CreateRequestActionsItemHostHeaderOverrideId: any;
export interface CreateRequestActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: CreateRequestActionsItemHostHeaderOverrideId | (string & {});
    /** The hostname to use in the `Host` header */
    value?: string;
}
export declare const CreateRequestActionsItemHostHeaderOverride: S.Schema<CreateRequestActionsItemHostHeaderOverride>;
export type CreateRequestActionsItemIPGeolocationId = "ip_geolocation";
export declare const CreateRequestActionsItemIPGeolocationId: any;
export type CreateRequestActionsItemIPGeolocationValue = "on" | "off";
export declare const CreateRequestActionsItemIPGeolocationValue: any;
export interface CreateRequestActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: CreateRequestActionsItemIPGeolocationId | (string & {});
    /** The status of adding the IP Geolocation Header. */
    value?: CreateRequestActionsItemIPGeolocationValue | (string & {});
}
export declare const CreateRequestActionsItemIPGeolocation: S.Schema<CreateRequestActionsItemIPGeolocation>;
export type CreateRequestActionsItemMirageId = "mirage";
export declare const CreateRequestActionsItemMirageId: any;
export type CreateRequestActionsItemMirageValue = "on" | "off";
export declare const CreateRequestActionsItemMirageValue: any;
export interface CreateRequestActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: CreateRequestActionsItemMirageId | (string & {});
    /** The status of Mirage. */
    value?: CreateRequestActionsItemMirageValue | (string & {});
}
export declare const CreateRequestActionsItemMirage: S.Schema<CreateRequestActionsItemMirage>;
export type CreateRequestActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const CreateRequestActionsItemOpportunisticEncryptionId: any;
export type CreateRequestActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const CreateRequestActionsItemOpportunisticEncryptionValue: any;
export interface CreateRequestActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: CreateRequestActionsItemOpportunisticEncryptionId | (string & {});
    /** The status of Opportunistic Encryption. */
    value?: CreateRequestActionsItemOpportunisticEncryptionValue | (string & {});
}
export declare const CreateRequestActionsItemOpportunisticEncryption: S.Schema<CreateRequestActionsItemOpportunisticEncryption>;
export type CreateRequestActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const CreateRequestActionsItemOriginErrorPagePassThruId: any;
export type CreateRequestActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const CreateRequestActionsItemOriginErrorPagePassThruValue: any;
export interface CreateRequestActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: CreateRequestActionsItemOriginErrorPagePassThruId | (string & {});
    /** The status of Origin Error Page Passthru. */
    value?: CreateRequestActionsItemOriginErrorPagePassThruValue | (string & {});
}
export declare const CreateRequestActionsItemOriginErrorPagePassThru: S.Schema<CreateRequestActionsItemOriginErrorPagePassThru>;
export type CreateRequestActionsItemPolishId = "polish";
export declare const CreateRequestActionsItemPolishId: any;
export type CreateRequestActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const CreateRequestActionsItemPolishValue: any;
export interface CreateRequestActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: CreateRequestActionsItemPolishId | (string & {});
    /** The level of Polish you want applied to your origin. */
    value?: CreateRequestActionsItemPolishValue | (string & {});
}
export declare const CreateRequestActionsItemPolish: S.Schema<CreateRequestActionsItemPolish>;
export type CreateRequestActionsItemResolveOverrideId = "resolve_override";
export declare const CreateRequestActionsItemResolveOverrideId: any;
export interface CreateRequestActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: CreateRequestActionsItemResolveOverrideId | (string & {});
    /** The origin address you want to override with. */
    value?: string;
}
export declare const CreateRequestActionsItemResolveOverride: S.Schema<CreateRequestActionsItemResolveOverride>;
export type CreateRequestActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const CreateRequestActionsItemRespectStrongEtagId: any;
export type CreateRequestActionsItemRespectStrongEtagValue = "on" | "off";
export declare const CreateRequestActionsItemRespectStrongEtagValue: any;
export interface CreateRequestActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: CreateRequestActionsItemRespectStrongEtagId | (string & {});
    /** The status of Respect Strong ETags */
    value?: CreateRequestActionsItemRespectStrongEtagValue | (string & {});
}
export declare const CreateRequestActionsItemRespectStrongEtag: S.Schema<CreateRequestActionsItemRespectStrongEtag>;
export type CreateRequestActionsItemResponseBufferingId = "response_buffering";
export declare const CreateRequestActionsItemResponseBufferingId: any;
export type CreateRequestActionsItemResponseBufferingValue = "on" | "off";
export declare const CreateRequestActionsItemResponseBufferingValue: any;
export interface CreateRequestActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: CreateRequestActionsItemResponseBufferingId | (string & {});
    /** The status of Response Buffering */
    value?: CreateRequestActionsItemResponseBufferingValue | (string & {});
}
export declare const CreateRequestActionsItemResponseBuffering: S.Schema<CreateRequestActionsItemResponseBuffering>;
export type CreateRequestActionsItemRocketLoaderId = "rocket_loader";
export declare const CreateRequestActionsItemRocketLoaderId: any;
export type CreateRequestActionsItemRocketLoaderValue = "on" | "off";
export declare const CreateRequestActionsItemRocketLoaderValue: any;
export interface CreateRequestActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: CreateRequestActionsItemRocketLoaderId | (string & {});
    /** The status of Rocket Loader */
    value?: CreateRequestActionsItemRocketLoaderValue | (string & {});
}
export declare const CreateRequestActionsItemRocketLoader: S.Schema<CreateRequestActionsItemRocketLoader>;
export type CreateRequestActionsItemSecurityLevelId = "security_level";
export declare const CreateRequestActionsItemSecurityLevelId: any;
export type CreateRequestActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const CreateRequestActionsItemSecurityLevelValue: any;
export interface CreateRequestActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: CreateRequestActionsItemSecurityLevelId | (string & {});
    value?: CreateRequestActionsItemSecurityLevelValue | (string & {});
}
export declare const CreateRequestActionsItemSecurityLevel: S.Schema<CreateRequestActionsItemSecurityLevel>;
export type CreateRequestActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const CreateRequestActionsItemSortQueryStringForCacheId: any;
export type CreateRequestActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const CreateRequestActionsItemSortQueryStringForCacheValue: any;
export interface CreateRequestActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: CreateRequestActionsItemSortQueryStringForCacheId | (string & {});
    /** The status of Query String Sort */
    value?: CreateRequestActionsItemSortQueryStringForCacheValue | (string & {});
}
export declare const CreateRequestActionsItemSortQueryStringForCache: S.Schema<CreateRequestActionsItemSortQueryStringForCache>;
export type CreateRequestActionsItemSSLId = "ssl";
export declare const CreateRequestActionsItemSSLId: any;
export type CreateRequestActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const CreateRequestActionsItemSSLValue: any;
export interface CreateRequestActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: CreateRequestActionsItemSSLId | (string & {});
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: CreateRequestActionsItemSSLValue | (string & {});
}
export declare const CreateRequestActionsItemSSL: S.Schema<CreateRequestActionsItemSSL>;
export type CreateRequestActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const CreateRequestActionsItemTrueClientIPHeaderId: any;
export type CreateRequestActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const CreateRequestActionsItemTrueClientIPHeaderValue: any;
export interface CreateRequestActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: CreateRequestActionsItemTrueClientIPHeaderId | (string & {});
    /** The status of True Client IP Header. */
    value?: CreateRequestActionsItemTrueClientIPHeaderValue | (string & {});
}
export declare const CreateRequestActionsItemTrueClientIPHeader: S.Schema<CreateRequestActionsItemTrueClientIPHeader>;
export type CreateRequestActionsItemWAFId = "waf";
export declare const CreateRequestActionsItemWAFId: any;
export type CreateRequestActionsItemWAFValue = "on" | "off";
export declare const CreateRequestActionsItemWAFValue: any;
export interface CreateRequestActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: CreateRequestActionsItemWAFId | (string & {});
    /** The status of WAF managed rules (previous version). */
    value?: CreateRequestActionsItemWAFValue | (string & {});
}
export declare const CreateRequestActionsItemWAF: S.Schema<CreateRequestActionsItemWAF>;
export type CreateRequestActionsItem = CreateRequestActionsItemAlwaysUseHTTPS | CreateRequestActionsItemAutomaticHTTPSRewrites | CreateRequestActionsItemBrowserCacheTTL | CreateRequestActionsItemBrowserCheck | CreateRequestActionsItemBypassCacheOnCookie | CreateRequestActionsItemCacheByDeviceType | CreateRequestActionsItemCacheDeceptionArmor | CreateRequestActionsItemCacheKeyFields | CreateRequestActionsItemCacheLevel | CreateRequestActionsItemCacheOnCookie | CreateRequestActionsItemCacheTTLByStatus | CreateRequestActionsItemDisableApps | CreateRequestActionsItemDisablePerformance | CreateRequestActionsItemDisableSecurity | CreateRequestActionsItemDisableZaraz | CreateRequestActionsItemEdgeCacheTTL | CreateRequestActionsItemEmailObfuscation | CreateRequestActionsItemExplicitCacheControl | CreateRequestActionsItemForwardingURL | CreateRequestActionsItemHostHeaderOverride | CreateRequestActionsItemIPGeolocation | CreateRequestActionsItemMirage | CreateRequestActionsItemOpportunisticEncryption | CreateRequestActionsItemOriginErrorPagePassThru | CreateRequestActionsItemPolish | CreateRequestActionsItemResolveOverride | CreateRequestActionsItemRespectStrongEtag | CreateRequestActionsItemResponseBuffering | CreateRequestActionsItemRocketLoader | CreateRequestActionsItemSecurityLevel | CreateRequestActionsItemSortQueryStringForCache | CreateRequestActionsItemSSL | CreateRequestActionsItemTrueClientIPHeader | CreateRequestActionsItemWAF;
export declare const CreateRequestActionsItem: any;
export type CreateRequestActionsList = Array<CreateRequestActionsItem>;
export declare const CreateRequestActionsList: S.Schema<CreateRequestActionsList>;
export type CreateRequestTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const CreateRequestTargetsItemConstraintOperator: any;
export interface CreateRequestTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: CreateRequestTargetsItemConstraintOperator | (string & {});
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const CreateRequestTargetsItemConstraint: S.Schema<CreateRequestTargetsItemConstraint>;
export type CreateRequestTargetsItemTarget = "url";
export declare const CreateRequestTargetsItemTarget: any;
export interface CreateRequestTargetsItem {
    /** String constraint. */
    constraint?: CreateRequestTargetsItemConstraint;
    /** A target based on the URL of the request. */
    target?: CreateRequestTargetsItemTarget | (string & {});
}
export declare const CreateRequestTargetsItem: S.Schema<CreateRequestTargetsItem>;
export type CreateRequestTargetsList = Array<CreateRequestTargetsItem>;
export declare const CreateRequestTargetsList: S.Schema<CreateRequestTargetsList>;
export type CreateRequestStatus = "active" | "disabled";
export declare const CreateRequestStatus: any;
export interface CreatePageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions: CreateRequestActionsList;
    /** The rule targets to evaluate on each request. */
    targets: CreateRequestTargetsList;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority?: number;
    /** The status of the Page Rule. */
    status?: CreateRequestStatus | (string & {});
}
export declare const CreatePageRuleRequest: S.Schema<CreatePageRuleRequest>;
export type CreateResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const CreateResponseActionsItemAlwaysUseHTTPSId: any;
export interface CreateResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: CreateResponseActionsItemAlwaysUseHTTPSId | null;
}
export declare const CreateResponseActionsItemAlwaysUseHTTPS: S.Schema<CreateResponseActionsItemAlwaysUseHTTPS>;
export type CreateResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const CreateResponseActionsItemAutomaticHTTPSRewritesId: any;
export type CreateResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const CreateResponseActionsItemAutomaticHTTPSRewritesValue: any;
export interface CreateResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: CreateResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: CreateResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export declare const CreateResponseActionsItemAutomaticHTTPSRewrites: S.Schema<CreateResponseActionsItemAutomaticHTTPSRewrites>;
export type CreateResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const CreateResponseActionsItemBrowserCacheTTLId: any;
export interface CreateResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: CreateResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. */
    value?: number | null;
}
export declare const CreateResponseActionsItemBrowserCacheTTL: S.Schema<CreateResponseActionsItemBrowserCacheTTL>;
export type CreateResponseActionsItemBrowserCheckId = "browser_check";
export declare const CreateResponseActionsItemBrowserCheckId: any;
export type CreateResponseActionsItemBrowserCheckValue = "on" | "off";
export declare const CreateResponseActionsItemBrowserCheckValue: any;
export interface CreateResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: CreateResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: CreateResponseActionsItemBrowserCheckValue | null;
}
export declare const CreateResponseActionsItemBrowserCheck: S.Schema<CreateResponseActionsItemBrowserCheck>;
export type CreateResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const CreateResponseActionsItemBypassCacheOnCookieId: any;
export interface CreateResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: CreateResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const CreateResponseActionsItemBypassCacheOnCookie: S.Schema<CreateResponseActionsItemBypassCacheOnCookie>;
export type CreateResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const CreateResponseActionsItemCacheByDeviceTypeId: any;
export type CreateResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const CreateResponseActionsItemCacheByDeviceTypeValue: any;
export interface CreateResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: CreateResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: CreateResponseActionsItemCacheByDeviceTypeValue | null;
}
export declare const CreateResponseActionsItemCacheByDeviceType: S.Schema<CreateResponseActionsItemCacheByDeviceType>;
export type CreateResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const CreateResponseActionsItemCacheDeceptionArmorId: any;
export type CreateResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const CreateResponseActionsItemCacheDeceptionArmorValue: any;
export interface CreateResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: CreateResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: CreateResponseActionsItemCacheDeceptionArmorValue | null;
}
export declare const CreateResponseActionsItemCacheDeceptionArmor: S.Schema<CreateResponseActionsItemCacheDeceptionArmor>;
export type CreateResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const CreateResponseActionsItemCacheKeyFieldsId: any;
export type CreateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const CreateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type CreateResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const CreateResponseActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface CreateResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: CreateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: CreateResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export declare const CreateResponseActionsItemCacheKeyFieldsValueCookie: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueCookie>;
export type CreateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const CreateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type CreateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const CreateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type CreateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const CreateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface CreateResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: CreateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: CreateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: CreateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export declare const CreateResponseActionsItemCacheKeyFieldsValueHeader: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHeader>;
export interface CreateResponseActionsItemCacheKeyFieldsValueHost {
    /** Whether to include the Host header in the HTTP request sent */
    resolved?: boolean | null;
}
export declare const CreateResponseActionsItemCacheKeyFieldsValueHost: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHost>;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringExclude = CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | CreateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const CreateResponseActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type CreateResponseActionsItemCacheKeyFieldsValueQueryStringInclude = CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | CreateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const CreateResponseActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface CreateResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: CreateResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: CreateResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export declare const CreateResponseActionsItemCacheKeyFieldsValueQueryString: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueQueryString>;
export interface CreateResponseActionsItemCacheKeyFieldsValueUser {
    /** Classifies a request as `mobile`, `desktop`, or `tablet` */
    deviceType?: boolean | null;
    /** Includes the client's country, derived from the IP address. */
    geo?: boolean | null;
    /** Includes the first language code contained in the */
    lang?: boolean | null;
}
export declare const CreateResponseActionsItemCacheKeyFieldsValueUser: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueUser>;
export interface CreateResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: CreateResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: CreateResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: CreateResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export declare const CreateResponseActionsItemCacheKeyFieldsValue: S.Schema<CreateResponseActionsItemCacheKeyFieldsValue>;
export interface CreateResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: CreateResponseActionsItemCacheKeyFieldsId | null;
    value?: CreateResponseActionsItemCacheKeyFieldsValue | null;
}
export declare const CreateResponseActionsItemCacheKeyFields: S.Schema<CreateResponseActionsItemCacheKeyFields>;
export type CreateResponseActionsItemCacheLevelId = "cache_level";
export declare const CreateResponseActionsItemCacheLevelId: any;
export type CreateResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const CreateResponseActionsItemCacheLevelValue: any;
export interface CreateResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: CreateResponseActionsItemCacheLevelId | null;
    /** * `bypass`: Cloudflare does not cache. */
    value?: CreateResponseActionsItemCacheLevelValue | null;
}
export declare const CreateResponseActionsItemCacheLevel: S.Schema<CreateResponseActionsItemCacheLevel>;
export type CreateResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const CreateResponseActionsItemCacheOnCookieId: any;
export interface CreateResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: CreateResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const CreateResponseActionsItemCacheOnCookie: S.Schema<CreateResponseActionsItemCacheOnCookie>;
export type CreateResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const CreateResponseActionsItemCacheTTLByStatusId: any;
export type CreateResponseActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const CreateResponseActionsItemCacheTTLByStatusValueCase0: any;
export type CreateResponseActionsItemCacheTTLByStatusValue = number | CreateResponseActionsItemCacheTTLByStatusValueCase0;
export declare const CreateResponseActionsItemCacheTTLByStatusValue: any;
export interface CreateResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: CreateResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: CreateResponseActionsItemCacheTTLByStatusValue | null;
}
export declare const CreateResponseActionsItemCacheTTLByStatus: S.Schema<CreateResponseActionsItemCacheTTLByStatus>;
export type CreateResponseActionsItemDisableAppsId = "disable_apps";
export declare const CreateResponseActionsItemDisableAppsId: any;
export interface CreateResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: CreateResponseActionsItemDisableAppsId | null;
}
export declare const CreateResponseActionsItemDisableApps: S.Schema<CreateResponseActionsItemDisableApps>;
export type CreateResponseActionsItemDisablePerformanceId = "disable_performance";
export declare const CreateResponseActionsItemDisablePerformanceId: any;
export interface CreateResponseActionsItemDisablePerformance {
    /** Turn off */
    id?: CreateResponseActionsItemDisablePerformanceId | null;
}
export declare const CreateResponseActionsItemDisablePerformance: S.Schema<CreateResponseActionsItemDisablePerformance>;
export type CreateResponseActionsItemDisableSecurityId = "disable_security";
export declare const CreateResponseActionsItemDisableSecurityId: any;
export interface CreateResponseActionsItemDisableSecurity {
    /** Turn off */
    id?: CreateResponseActionsItemDisableSecurityId | null;
}
export declare const CreateResponseActionsItemDisableSecurity: S.Schema<CreateResponseActionsItemDisableSecurity>;
export type CreateResponseActionsItemDisableZarazId = "disable_zaraz";
export declare const CreateResponseActionsItemDisableZarazId: any;
export interface CreateResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: CreateResponseActionsItemDisableZarazId | null;
}
export declare const CreateResponseActionsItemDisableZaraz: S.Schema<CreateResponseActionsItemDisableZaraz>;
export type CreateResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const CreateResponseActionsItemEdgeCacheTTLId: any;
export interface CreateResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: CreateResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export declare const CreateResponseActionsItemEdgeCacheTTL: S.Schema<CreateResponseActionsItemEdgeCacheTTL>;
export type CreateResponseActionsItemEmailObfuscationId = "email_obfuscation";
export declare const CreateResponseActionsItemEmailObfuscationId: any;
export type CreateResponseActionsItemEmailObfuscationValue = "on" | "off";
export declare const CreateResponseActionsItemEmailObfuscationValue: any;
export interface CreateResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: CreateResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: CreateResponseActionsItemEmailObfuscationValue | null;
}
export declare const CreateResponseActionsItemEmailObfuscation: S.Schema<CreateResponseActionsItemEmailObfuscation>;
export type CreateResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const CreateResponseActionsItemExplicitCacheControlId: any;
export type CreateResponseActionsItemExplicitCacheControlValue = "on" | "off";
export declare const CreateResponseActionsItemExplicitCacheControlValue: any;
export interface CreateResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: CreateResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: CreateResponseActionsItemExplicitCacheControlValue | null;
}
export declare const CreateResponseActionsItemExplicitCacheControl: S.Schema<CreateResponseActionsItemExplicitCacheControl>;
export type CreateResponseActionsItemForwardingURLId = "forwarding_url";
export declare const CreateResponseActionsItemForwardingURLId: any;
export type CreateResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const CreateResponseActionsItemForwardingURLValueStatusCode: any;
export interface CreateResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: CreateResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. */
    url?: string | null;
}
export declare const CreateResponseActionsItemForwardingURLValue: S.Schema<CreateResponseActionsItemForwardingURLValue>;
export interface CreateResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: CreateResponseActionsItemForwardingURLId | null;
    value?: CreateResponseActionsItemForwardingURLValue | null;
}
export declare const CreateResponseActionsItemForwardingURL: S.Schema<CreateResponseActionsItemForwardingURL>;
export type CreateResponseActionsItemHostHeaderOverrideId = "host_header_override";
export declare const CreateResponseActionsItemHostHeaderOverrideId: any;
export interface CreateResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: CreateResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export declare const CreateResponseActionsItemHostHeaderOverride: S.Schema<CreateResponseActionsItemHostHeaderOverride>;
export type CreateResponseActionsItemIPGeolocationId = "ip_geolocation";
export declare const CreateResponseActionsItemIPGeolocationId: any;
export type CreateResponseActionsItemIPGeolocationValue = "on" | "off";
export declare const CreateResponseActionsItemIPGeolocationValue: any;
export interface CreateResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: CreateResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: CreateResponseActionsItemIPGeolocationValue | null;
}
export declare const CreateResponseActionsItemIPGeolocation: S.Schema<CreateResponseActionsItemIPGeolocation>;
export type CreateResponseActionsItemMirageId = "mirage";
export declare const CreateResponseActionsItemMirageId: any;
export type CreateResponseActionsItemMirageValue = "on" | "off";
export declare const CreateResponseActionsItemMirageValue: any;
export interface CreateResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: CreateResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: CreateResponseActionsItemMirageValue | null;
}
export declare const CreateResponseActionsItemMirage: S.Schema<CreateResponseActionsItemMirage>;
export type CreateResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const CreateResponseActionsItemOpportunisticEncryptionId: any;
export type CreateResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const CreateResponseActionsItemOpportunisticEncryptionValue: any;
export interface CreateResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: CreateResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: CreateResponseActionsItemOpportunisticEncryptionValue | null;
}
export declare const CreateResponseActionsItemOpportunisticEncryption: S.Schema<CreateResponseActionsItemOpportunisticEncryption>;
export type CreateResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const CreateResponseActionsItemOriginErrorPagePassThruId: any;
export type CreateResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const CreateResponseActionsItemOriginErrorPagePassThruValue: any;
export interface CreateResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: CreateResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: CreateResponseActionsItemOriginErrorPagePassThruValue | null;
}
export declare const CreateResponseActionsItemOriginErrorPagePassThru: S.Schema<CreateResponseActionsItemOriginErrorPagePassThru>;
export type CreateResponseActionsItemPolishId = "polish";
export declare const CreateResponseActionsItemPolishId: any;
export type CreateResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const CreateResponseActionsItemPolishValue: any;
export interface CreateResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: CreateResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: CreateResponseActionsItemPolishValue | null;
}
export declare const CreateResponseActionsItemPolish: S.Schema<CreateResponseActionsItemPolish>;
export type CreateResponseActionsItemResolveOverrideId = "resolve_override";
export declare const CreateResponseActionsItemResolveOverrideId: any;
export interface CreateResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: CreateResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export declare const CreateResponseActionsItemResolveOverride: S.Schema<CreateResponseActionsItemResolveOverride>;
export type CreateResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const CreateResponseActionsItemRespectStrongEtagId: any;
export type CreateResponseActionsItemRespectStrongEtagValue = "on" | "off";
export declare const CreateResponseActionsItemRespectStrongEtagValue: any;
export interface CreateResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: CreateResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: CreateResponseActionsItemRespectStrongEtagValue | null;
}
export declare const CreateResponseActionsItemRespectStrongEtag: S.Schema<CreateResponseActionsItemRespectStrongEtag>;
export type CreateResponseActionsItemResponseBufferingId = "response_buffering";
export declare const CreateResponseActionsItemResponseBufferingId: any;
export type CreateResponseActionsItemResponseBufferingValue = "on" | "off";
export declare const CreateResponseActionsItemResponseBufferingValue: any;
export interface CreateResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: CreateResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: CreateResponseActionsItemResponseBufferingValue | null;
}
export declare const CreateResponseActionsItemResponseBuffering: S.Schema<CreateResponseActionsItemResponseBuffering>;
export type CreateResponseActionsItemRocketLoaderId = "rocket_loader";
export declare const CreateResponseActionsItemRocketLoaderId: any;
export type CreateResponseActionsItemRocketLoaderValue = "on" | "off";
export declare const CreateResponseActionsItemRocketLoaderValue: any;
export interface CreateResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: CreateResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: CreateResponseActionsItemRocketLoaderValue | null;
}
export declare const CreateResponseActionsItemRocketLoader: S.Schema<CreateResponseActionsItemRocketLoader>;
export type CreateResponseActionsItemSecurityLevelId = "security_level";
export declare const CreateResponseActionsItemSecurityLevelId: any;
export type CreateResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const CreateResponseActionsItemSecurityLevelValue: any;
export interface CreateResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: CreateResponseActionsItemSecurityLevelId | null;
    value?: CreateResponseActionsItemSecurityLevelValue | null;
}
export declare const CreateResponseActionsItemSecurityLevel: S.Schema<CreateResponseActionsItemSecurityLevel>;
export type CreateResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const CreateResponseActionsItemSortQueryStringForCacheId: any;
export type CreateResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const CreateResponseActionsItemSortQueryStringForCacheValue: any;
export interface CreateResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: CreateResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: CreateResponseActionsItemSortQueryStringForCacheValue | null;
}
export declare const CreateResponseActionsItemSortQueryStringForCache: S.Schema<CreateResponseActionsItemSortQueryStringForCache>;
export type CreateResponseActionsItemSSLId = "ssl";
export declare const CreateResponseActionsItemSSLId: any;
export type CreateResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const CreateResponseActionsItemSSLValue: any;
export interface CreateResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: CreateResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: CreateResponseActionsItemSSLValue | null;
}
export declare const CreateResponseActionsItemSSL: S.Schema<CreateResponseActionsItemSSL>;
export type CreateResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const CreateResponseActionsItemTrueClientIPHeaderId: any;
export type CreateResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const CreateResponseActionsItemTrueClientIPHeaderValue: any;
export interface CreateResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: CreateResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: CreateResponseActionsItemTrueClientIPHeaderValue | null;
}
export declare const CreateResponseActionsItemTrueClientIPHeader: S.Schema<CreateResponseActionsItemTrueClientIPHeader>;
export type CreateResponseActionsItemWAFId = "waf";
export declare const CreateResponseActionsItemWAFId: any;
export type CreateResponseActionsItemWAFValue = "on" | "off";
export declare const CreateResponseActionsItemWAFValue: any;
export interface CreateResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: CreateResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: CreateResponseActionsItemWAFValue | null;
}
export declare const CreateResponseActionsItemWAF: S.Schema<CreateResponseActionsItemWAF>;
export type CreateResponseActionsItem = CreateResponseActionsItemAlwaysUseHTTPS | CreateResponseActionsItemAutomaticHTTPSRewrites | CreateResponseActionsItemBrowserCacheTTL | CreateResponseActionsItemBrowserCheck | CreateResponseActionsItemBypassCacheOnCookie | CreateResponseActionsItemCacheByDeviceType | CreateResponseActionsItemCacheDeceptionArmor | CreateResponseActionsItemCacheKeyFields | CreateResponseActionsItemCacheLevel | CreateResponseActionsItemCacheOnCookie | CreateResponseActionsItemCacheTTLByStatus | CreateResponseActionsItemDisableApps | CreateResponseActionsItemDisablePerformance | CreateResponseActionsItemDisableSecurity | CreateResponseActionsItemDisableZaraz | CreateResponseActionsItemEdgeCacheTTL | CreateResponseActionsItemEmailObfuscation | CreateResponseActionsItemExplicitCacheControl | CreateResponseActionsItemForwardingURL | CreateResponseActionsItemHostHeaderOverride | CreateResponseActionsItemIPGeolocation | CreateResponseActionsItemMirage | CreateResponseActionsItemOpportunisticEncryption | CreateResponseActionsItemOriginErrorPagePassThru | CreateResponseActionsItemPolish | CreateResponseActionsItemResolveOverride | CreateResponseActionsItemRespectStrongEtag | CreateResponseActionsItemResponseBuffering | CreateResponseActionsItemRocketLoader | CreateResponseActionsItemSecurityLevel | CreateResponseActionsItemSortQueryStringForCache | CreateResponseActionsItemSSL | CreateResponseActionsItemTrueClientIPHeader | CreateResponseActionsItemWAF;
export declare const CreateResponseActionsItem: any;
export type CreateResponseActionsList = Array<CreateResponseActionsItem>;
export declare const CreateResponseActionsList: S.Schema<CreateResponseActionsList>;
export type CreateResponseStatus = "active" | "disabled";
export declare const CreateResponseStatus: any;
export type CreateResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const CreateResponseTargetsItemConstraintOperator: any;
export interface CreateResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: CreateResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const CreateResponseTargetsItemConstraint: S.Schema<CreateResponseTargetsItemConstraint>;
export type CreateResponseTargetsItemTarget = "url";
export declare const CreateResponseTargetsItemTarget: any;
export interface CreateResponseTargetsItem {
    /** String constraint. */
    constraint?: CreateResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: CreateResponseTargetsItemTarget | null;
}
export declare const CreateResponseTargetsItem: S.Schema<CreateResponseTargetsItem>;
export type CreateResponseTargetsList = Array<CreateResponseTargetsItem>;
export declare const CreateResponseTargetsList: S.Schema<CreateResponseTargetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions: CreateResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority: number;
    /** The status of the Page Rule. */
    status: CreateResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: CreateResponseTargetsList;
}
export declare const CreatePageRuleResponse: S.Schema<CreatePageRuleResponse>;
export interface DeletePageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
}
export declare const DeletePageRuleRequest: S.Schema<DeletePageRuleRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePageRuleResponse {
    /** Identifier. */
    id: string;
}
export declare const DeletePageRuleResponse: S.Schema<DeletePageRuleResponse>;
export interface GetPageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
}
export declare const GetPageRuleRequest: S.Schema<GetPageRuleRequest>;
export type GetResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const GetResponseActionsItemAlwaysUseHTTPSId: any;
export interface GetResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: GetResponseActionsItemAlwaysUseHTTPSId | null;
}
export declare const GetResponseActionsItemAlwaysUseHTTPS: S.Schema<GetResponseActionsItemAlwaysUseHTTPS>;
export type GetResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const GetResponseActionsItemAutomaticHTTPSRewritesId: any;
export type GetResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const GetResponseActionsItemAutomaticHTTPSRewritesValue: any;
export interface GetResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: GetResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: GetResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export declare const GetResponseActionsItemAutomaticHTTPSRewrites: S.Schema<GetResponseActionsItemAutomaticHTTPSRewrites>;
export type GetResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const GetResponseActionsItemBrowserCacheTTLId: any;
export interface GetResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: GetResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. */
    value?: number | null;
}
export declare const GetResponseActionsItemBrowserCacheTTL: S.Schema<GetResponseActionsItemBrowserCacheTTL>;
export type GetResponseActionsItemBrowserCheckId = "browser_check";
export declare const GetResponseActionsItemBrowserCheckId: any;
export type GetResponseActionsItemBrowserCheckValue = "on" | "off";
export declare const GetResponseActionsItemBrowserCheckValue: any;
export interface GetResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: GetResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: GetResponseActionsItemBrowserCheckValue | null;
}
export declare const GetResponseActionsItemBrowserCheck: S.Schema<GetResponseActionsItemBrowserCheck>;
export type GetResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const GetResponseActionsItemBypassCacheOnCookieId: any;
export interface GetResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: GetResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const GetResponseActionsItemBypassCacheOnCookie: S.Schema<GetResponseActionsItemBypassCacheOnCookie>;
export type GetResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const GetResponseActionsItemCacheByDeviceTypeId: any;
export type GetResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const GetResponseActionsItemCacheByDeviceTypeValue: any;
export interface GetResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: GetResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: GetResponseActionsItemCacheByDeviceTypeValue | null;
}
export declare const GetResponseActionsItemCacheByDeviceType: S.Schema<GetResponseActionsItemCacheByDeviceType>;
export type GetResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const GetResponseActionsItemCacheDeceptionArmorId: any;
export type GetResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const GetResponseActionsItemCacheDeceptionArmorValue: any;
export interface GetResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: GetResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: GetResponseActionsItemCacheDeceptionArmorValue | null;
}
export declare const GetResponseActionsItemCacheDeceptionArmor: S.Schema<GetResponseActionsItemCacheDeceptionArmor>;
export type GetResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const GetResponseActionsItemCacheKeyFieldsId: any;
export type GetResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const GetResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<GetResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type GetResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const GetResponseActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<GetResponseActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface GetResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: GetResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: GetResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export declare const GetResponseActionsItemCacheKeyFieldsValueCookie: S.Schema<GetResponseActionsItemCacheKeyFieldsValueCookie>;
export type GetResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const GetResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<GetResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type GetResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const GetResponseActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<GetResponseActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type GetResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const GetResponseActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<GetResponseActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface GetResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: GetResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: GetResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: GetResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export declare const GetResponseActionsItemCacheKeyFieldsValueHeader: S.Schema<GetResponseActionsItemCacheKeyFieldsValueHeader>;
export type GetResponseActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export declare const GetResponseActionsItemCacheKeyFieldsValueHost: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHost>;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringExclude = GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | GetResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const GetResponseActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type GetResponseActionsItemCacheKeyFieldsValueQueryStringInclude = GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | GetResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const GetResponseActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface GetResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: GetResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: GetResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export declare const GetResponseActionsItemCacheKeyFieldsValueQueryString: S.Schema<GetResponseActionsItemCacheKeyFieldsValueQueryString>;
export type GetResponseActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export declare const GetResponseActionsItemCacheKeyFieldsValueUser: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueUser>;
export interface GetResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: GetResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: GetResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: GetResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export declare const GetResponseActionsItemCacheKeyFieldsValue: S.Schema<GetResponseActionsItemCacheKeyFieldsValue>;
export interface GetResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: GetResponseActionsItemCacheKeyFieldsId | null;
    value?: GetResponseActionsItemCacheKeyFieldsValue | null;
}
export declare const GetResponseActionsItemCacheKeyFields: S.Schema<GetResponseActionsItemCacheKeyFields>;
export type GetResponseActionsItemCacheLevelId = "cache_level";
export declare const GetResponseActionsItemCacheLevelId: any;
export type GetResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const GetResponseActionsItemCacheLevelValue: any;
export interface GetResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: GetResponseActionsItemCacheLevelId | null;
    /** * `bypass`: Cloudflare does not cache. */
    value?: GetResponseActionsItemCacheLevelValue | null;
}
export declare const GetResponseActionsItemCacheLevel: S.Schema<GetResponseActionsItemCacheLevel>;
export type GetResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const GetResponseActionsItemCacheOnCookieId: any;
export interface GetResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: GetResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const GetResponseActionsItemCacheOnCookie: S.Schema<GetResponseActionsItemCacheOnCookie>;
export type GetResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const GetResponseActionsItemCacheTTLByStatusId: any;
export type GetResponseActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const GetResponseActionsItemCacheTTLByStatusValueCase0: any;
export type GetResponseActionsItemCacheTTLByStatusValue = number | GetResponseActionsItemCacheTTLByStatusValueCase0;
export declare const GetResponseActionsItemCacheTTLByStatusValue: any;
export interface GetResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: GetResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: GetResponseActionsItemCacheTTLByStatusValue | null;
}
export declare const GetResponseActionsItemCacheTTLByStatus: S.Schema<GetResponseActionsItemCacheTTLByStatus>;
export type GetResponseActionsItemDisableAppsId = "disable_apps";
export declare const GetResponseActionsItemDisableAppsId: any;
export interface GetResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: GetResponseActionsItemDisableAppsId | null;
}
export declare const GetResponseActionsItemDisableApps: S.Schema<GetResponseActionsItemDisableApps>;
export type GetResponseActionsItemDisablePerformanceId = "disable_performance";
export declare const GetResponseActionsItemDisablePerformanceId: any;
export interface GetResponseActionsItemDisablePerformance {
    /** Turn off */
    id?: GetResponseActionsItemDisablePerformanceId | null;
}
export declare const GetResponseActionsItemDisablePerformance: S.Schema<GetResponseActionsItemDisablePerformance>;
export type GetResponseActionsItemDisableSecurityId = "disable_security";
export declare const GetResponseActionsItemDisableSecurityId: any;
export interface GetResponseActionsItemDisableSecurity {
    /** Turn off */
    id?: GetResponseActionsItemDisableSecurityId | null;
}
export declare const GetResponseActionsItemDisableSecurity: S.Schema<GetResponseActionsItemDisableSecurity>;
export type GetResponseActionsItemDisableZarazId = "disable_zaraz";
export declare const GetResponseActionsItemDisableZarazId: any;
export interface GetResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: GetResponseActionsItemDisableZarazId | null;
}
export declare const GetResponseActionsItemDisableZaraz: S.Schema<GetResponseActionsItemDisableZaraz>;
export type GetResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const GetResponseActionsItemEdgeCacheTTLId: any;
export interface GetResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: GetResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export declare const GetResponseActionsItemEdgeCacheTTL: S.Schema<GetResponseActionsItemEdgeCacheTTL>;
export type GetResponseActionsItemEmailObfuscationId = "email_obfuscation";
export declare const GetResponseActionsItemEmailObfuscationId: any;
export type GetResponseActionsItemEmailObfuscationValue = "on" | "off";
export declare const GetResponseActionsItemEmailObfuscationValue: any;
export interface GetResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: GetResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: GetResponseActionsItemEmailObfuscationValue | null;
}
export declare const GetResponseActionsItemEmailObfuscation: S.Schema<GetResponseActionsItemEmailObfuscation>;
export type GetResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const GetResponseActionsItemExplicitCacheControlId: any;
export type GetResponseActionsItemExplicitCacheControlValue = "on" | "off";
export declare const GetResponseActionsItemExplicitCacheControlValue: any;
export interface GetResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: GetResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: GetResponseActionsItemExplicitCacheControlValue | null;
}
export declare const GetResponseActionsItemExplicitCacheControl: S.Schema<GetResponseActionsItemExplicitCacheControl>;
export type GetResponseActionsItemForwardingURLId = "forwarding_url";
export declare const GetResponseActionsItemForwardingURLId: any;
export type GetResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const GetResponseActionsItemForwardingURLValueStatusCode: any;
export interface GetResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: GetResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. */
    url?: string | null;
}
export declare const GetResponseActionsItemForwardingURLValue: S.Schema<GetResponseActionsItemForwardingURLValue>;
export interface GetResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: GetResponseActionsItemForwardingURLId | null;
    value?: GetResponseActionsItemForwardingURLValue | null;
}
export declare const GetResponseActionsItemForwardingURL: S.Schema<GetResponseActionsItemForwardingURL>;
export type GetResponseActionsItemHostHeaderOverrideId = "host_header_override";
export declare const GetResponseActionsItemHostHeaderOverrideId: any;
export interface GetResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: GetResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export declare const GetResponseActionsItemHostHeaderOverride: S.Schema<GetResponseActionsItemHostHeaderOverride>;
export type GetResponseActionsItemIPGeolocationId = "ip_geolocation";
export declare const GetResponseActionsItemIPGeolocationId: any;
export type GetResponseActionsItemIPGeolocationValue = "on" | "off";
export declare const GetResponseActionsItemIPGeolocationValue: any;
export interface GetResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: GetResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: GetResponseActionsItemIPGeolocationValue | null;
}
export declare const GetResponseActionsItemIPGeolocation: S.Schema<GetResponseActionsItemIPGeolocation>;
export type GetResponseActionsItemMirageId = "mirage";
export declare const GetResponseActionsItemMirageId: any;
export type GetResponseActionsItemMirageValue = "on" | "off";
export declare const GetResponseActionsItemMirageValue: any;
export interface GetResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: GetResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: GetResponseActionsItemMirageValue | null;
}
export declare const GetResponseActionsItemMirage: S.Schema<GetResponseActionsItemMirage>;
export type GetResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const GetResponseActionsItemOpportunisticEncryptionId: any;
export type GetResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const GetResponseActionsItemOpportunisticEncryptionValue: any;
export interface GetResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: GetResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: GetResponseActionsItemOpportunisticEncryptionValue | null;
}
export declare const GetResponseActionsItemOpportunisticEncryption: S.Schema<GetResponseActionsItemOpportunisticEncryption>;
export type GetResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const GetResponseActionsItemOriginErrorPagePassThruId: any;
export type GetResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const GetResponseActionsItemOriginErrorPagePassThruValue: any;
export interface GetResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: GetResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: GetResponseActionsItemOriginErrorPagePassThruValue | null;
}
export declare const GetResponseActionsItemOriginErrorPagePassThru: S.Schema<GetResponseActionsItemOriginErrorPagePassThru>;
export type GetResponseActionsItemPolishId = "polish";
export declare const GetResponseActionsItemPolishId: any;
export type GetResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const GetResponseActionsItemPolishValue: any;
export interface GetResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: GetResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: GetResponseActionsItemPolishValue | null;
}
export declare const GetResponseActionsItemPolish: S.Schema<GetResponseActionsItemPolish>;
export type GetResponseActionsItemResolveOverrideId = "resolve_override";
export declare const GetResponseActionsItemResolveOverrideId: any;
export interface GetResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: GetResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export declare const GetResponseActionsItemResolveOverride: S.Schema<GetResponseActionsItemResolveOverride>;
export type GetResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const GetResponseActionsItemRespectStrongEtagId: any;
export type GetResponseActionsItemRespectStrongEtagValue = "on" | "off";
export declare const GetResponseActionsItemRespectStrongEtagValue: any;
export interface GetResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: GetResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: GetResponseActionsItemRespectStrongEtagValue | null;
}
export declare const GetResponseActionsItemRespectStrongEtag: S.Schema<GetResponseActionsItemRespectStrongEtag>;
export type GetResponseActionsItemResponseBufferingId = "response_buffering";
export declare const GetResponseActionsItemResponseBufferingId: any;
export type GetResponseActionsItemResponseBufferingValue = "on" | "off";
export declare const GetResponseActionsItemResponseBufferingValue: any;
export interface GetResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: GetResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: GetResponseActionsItemResponseBufferingValue | null;
}
export declare const GetResponseActionsItemResponseBuffering: S.Schema<GetResponseActionsItemResponseBuffering>;
export type GetResponseActionsItemRocketLoaderId = "rocket_loader";
export declare const GetResponseActionsItemRocketLoaderId: any;
export type GetResponseActionsItemRocketLoaderValue = "on" | "off";
export declare const GetResponseActionsItemRocketLoaderValue: any;
export interface GetResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: GetResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: GetResponseActionsItemRocketLoaderValue | null;
}
export declare const GetResponseActionsItemRocketLoader: S.Schema<GetResponseActionsItemRocketLoader>;
export type GetResponseActionsItemSecurityLevelId = "security_level";
export declare const GetResponseActionsItemSecurityLevelId: any;
export type GetResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const GetResponseActionsItemSecurityLevelValue: any;
export interface GetResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: GetResponseActionsItemSecurityLevelId | null;
    value?: GetResponseActionsItemSecurityLevelValue | null;
}
export declare const GetResponseActionsItemSecurityLevel: S.Schema<GetResponseActionsItemSecurityLevel>;
export type GetResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const GetResponseActionsItemSortQueryStringForCacheId: any;
export type GetResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const GetResponseActionsItemSortQueryStringForCacheValue: any;
export interface GetResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: GetResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: GetResponseActionsItemSortQueryStringForCacheValue | null;
}
export declare const GetResponseActionsItemSortQueryStringForCache: S.Schema<GetResponseActionsItemSortQueryStringForCache>;
export type GetResponseActionsItemSSLId = "ssl";
export declare const GetResponseActionsItemSSLId: any;
export type GetResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const GetResponseActionsItemSSLValue: any;
export interface GetResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: GetResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: GetResponseActionsItemSSLValue | null;
}
export declare const GetResponseActionsItemSSL: S.Schema<GetResponseActionsItemSSL>;
export type GetResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const GetResponseActionsItemTrueClientIPHeaderId: any;
export type GetResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const GetResponseActionsItemTrueClientIPHeaderValue: any;
export interface GetResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: GetResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: GetResponseActionsItemTrueClientIPHeaderValue | null;
}
export declare const GetResponseActionsItemTrueClientIPHeader: S.Schema<GetResponseActionsItemTrueClientIPHeader>;
export type GetResponseActionsItemWAFId = "waf";
export declare const GetResponseActionsItemWAFId: any;
export type GetResponseActionsItemWAFValue = "on" | "off";
export declare const GetResponseActionsItemWAFValue: any;
export interface GetResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: GetResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: GetResponseActionsItemWAFValue | null;
}
export declare const GetResponseActionsItemWAF: S.Schema<GetResponseActionsItemWAF>;
export type GetResponseActionsItem = GetResponseActionsItemAlwaysUseHTTPS | GetResponseActionsItemAutomaticHTTPSRewrites | GetResponseActionsItemBrowserCacheTTL | GetResponseActionsItemBrowserCheck | GetResponseActionsItemBypassCacheOnCookie | GetResponseActionsItemCacheByDeviceType | GetResponseActionsItemCacheDeceptionArmor | GetResponseActionsItemCacheKeyFields | GetResponseActionsItemCacheLevel | GetResponseActionsItemCacheOnCookie | GetResponseActionsItemCacheTTLByStatus | GetResponseActionsItemDisableApps | GetResponseActionsItemDisablePerformance | GetResponseActionsItemDisableSecurity | GetResponseActionsItemDisableZaraz | GetResponseActionsItemEdgeCacheTTL | GetResponseActionsItemEmailObfuscation | GetResponseActionsItemExplicitCacheControl | GetResponseActionsItemForwardingURL | GetResponseActionsItemHostHeaderOverride | GetResponseActionsItemIPGeolocation | GetResponseActionsItemMirage | GetResponseActionsItemOpportunisticEncryption | GetResponseActionsItemOriginErrorPagePassThru | GetResponseActionsItemPolish | GetResponseActionsItemResolveOverride | GetResponseActionsItemRespectStrongEtag | GetResponseActionsItemResponseBuffering | GetResponseActionsItemRocketLoader | GetResponseActionsItemSecurityLevel | GetResponseActionsItemSortQueryStringForCache | GetResponseActionsItemSSL | GetResponseActionsItemTrueClientIPHeader | GetResponseActionsItemWAF;
export declare const GetResponseActionsItem: any;
export type GetResponseActionsList = Array<GetResponseActionsItem>;
export declare const GetResponseActionsList: S.Schema<GetResponseActionsList>;
export type GetResponseStatus = "active" | "disabled";
export declare const GetResponseStatus: any;
export type GetResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const GetResponseTargetsItemConstraintOperator: any;
export interface GetResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: GetResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const GetResponseTargetsItemConstraint: S.Schema<GetResponseTargetsItemConstraint>;
export type GetResponseTargetsItemTarget = "url";
export declare const GetResponseTargetsItemTarget: any;
export interface GetResponseTargetsItem {
    /** String constraint. */
    constraint?: GetResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: GetResponseTargetsItemTarget | null;
}
export declare const GetResponseTargetsItem: S.Schema<GetResponseTargetsItem>;
export type GetResponseTargetsList = Array<GetResponseTargetsItem>;
export declare const GetResponseTargetsList: S.Schema<GetResponseTargetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions: GetResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority: number;
    /** The status of the Page Rule. */
    status: GetResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: GetResponseTargetsList;
}
export declare const GetPageRuleResponse: S.Schema<GetPageRuleResponse>;
export type ListRequestDirection = "asc" | "desc";
export declare const ListRequestDirection: any;
export type ListRequestMatch = "any" | "all";
export declare const ListRequestMatch: any;
export type ListRequestOrder = "status" | "priority";
export declare const ListRequestOrder: any;
export type ListRequestStatus = "active" | "disabled";
export declare const ListRequestStatus: any;
export interface ListPageRulesRequest {
    /** Identifier. */
    zoneId: string;
    /** The direction used to sort returned Page Rules. */
    direction?: ListRequestDirection | (string & {});
    /** When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: ListRequestMatch | (string & {});
    /** The field used to sort returned Page Rules. */
    order?: ListRequestOrder | (string & {});
    /** The status of the Page Rule. */
    status?: ListRequestStatus | (string & {});
}
export declare const ListPageRulesRequest: S.Schema<ListPageRulesRequest>;
export type ListResultItemActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const ListResultItemActionsItemAlwaysUseHTTPSId: any;
export interface ListResultItemActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: ListResultItemActionsItemAlwaysUseHTTPSId | null;
}
export declare const ListResultItemActionsItemAlwaysUseHTTPS: S.Schema<ListResultItemActionsItemAlwaysUseHTTPS>;
export type ListResultItemActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const ListResultItemActionsItemAutomaticHTTPSRewritesId: any;
export type ListResultItemActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const ListResultItemActionsItemAutomaticHTTPSRewritesValue: any;
export interface ListResultItemActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: ListResultItemActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: ListResultItemActionsItemAutomaticHTTPSRewritesValue | null;
}
export declare const ListResultItemActionsItemAutomaticHTTPSRewrites: S.Schema<ListResultItemActionsItemAutomaticHTTPSRewrites>;
export type ListResultItemActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const ListResultItemActionsItemBrowserCacheTTLId: any;
export interface ListResultItemActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: ListResultItemActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. */
    value?: number | null;
}
export declare const ListResultItemActionsItemBrowserCacheTTL: S.Schema<ListResultItemActionsItemBrowserCacheTTL>;
export type ListResultItemActionsItemBrowserCheckId = "browser_check";
export declare const ListResultItemActionsItemBrowserCheckId: any;
export type ListResultItemActionsItemBrowserCheckValue = "on" | "off";
export declare const ListResultItemActionsItemBrowserCheckValue: any;
export interface ListResultItemActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: ListResultItemActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: ListResultItemActionsItemBrowserCheckValue | null;
}
export declare const ListResultItemActionsItemBrowserCheck: S.Schema<ListResultItemActionsItemBrowserCheck>;
export type ListResultItemActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const ListResultItemActionsItemBypassCacheOnCookieId: any;
export interface ListResultItemActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: ListResultItemActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const ListResultItemActionsItemBypassCacheOnCookie: S.Schema<ListResultItemActionsItemBypassCacheOnCookie>;
export type ListResultItemActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const ListResultItemActionsItemCacheByDeviceTypeId: any;
export type ListResultItemActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const ListResultItemActionsItemCacheByDeviceTypeValue: any;
export interface ListResultItemActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: ListResultItemActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: ListResultItemActionsItemCacheByDeviceTypeValue | null;
}
export declare const ListResultItemActionsItemCacheByDeviceType: S.Schema<ListResultItemActionsItemCacheByDeviceType>;
export type ListResultItemActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const ListResultItemActionsItemCacheDeceptionArmorId: any;
export type ListResultItemActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const ListResultItemActionsItemCacheDeceptionArmorValue: any;
export interface ListResultItemActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: ListResultItemActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: ListResultItemActionsItemCacheDeceptionArmorValue | null;
}
export declare const ListResultItemActionsItemCacheDeceptionArmor: S.Schema<ListResultItemActionsItemCacheDeceptionArmor>;
export type ListResultItemActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const ListResultItemActionsItemCacheKeyFieldsId: any;
export type ListResultItemActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const ListResultItemActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type ListResultItemActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const ListResultItemActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface ListResultItemActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: ListResultItemActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: ListResultItemActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export declare const ListResultItemActionsItemCacheKeyFieldsValueCookie: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueCookie>;
export type ListResultItemActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const ListResultItemActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type ListResultItemActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const ListResultItemActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type ListResultItemActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const ListResultItemActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface ListResultItemActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: ListResultItemActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: ListResultItemActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: ListResultItemActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export declare const ListResultItemActionsItemCacheKeyFieldsValueHeader: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueHeader>;
export type ListResultItemActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export declare const ListResultItemActionsItemCacheKeyFieldsValueHost: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHost>;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringExclude = ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | ListResultItemActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const ListResultItemActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type ListResultItemActionsItemCacheKeyFieldsValueQueryStringInclude = ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | ListResultItemActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const ListResultItemActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface ListResultItemActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: ListResultItemActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: ListResultItemActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export declare const ListResultItemActionsItemCacheKeyFieldsValueQueryString: S.Schema<ListResultItemActionsItemCacheKeyFieldsValueQueryString>;
export type ListResultItemActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export declare const ListResultItemActionsItemCacheKeyFieldsValueUser: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueUser>;
export interface ListResultItemActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: ListResultItemActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: ListResultItemActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: ListResultItemActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export declare const ListResultItemActionsItemCacheKeyFieldsValue: S.Schema<ListResultItemActionsItemCacheKeyFieldsValue>;
export interface ListResultItemActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: ListResultItemActionsItemCacheKeyFieldsId | null;
    value?: ListResultItemActionsItemCacheKeyFieldsValue | null;
}
export declare const ListResultItemActionsItemCacheKeyFields: S.Schema<ListResultItemActionsItemCacheKeyFields>;
export type ListResultItemActionsItemCacheLevelId = "cache_level";
export declare const ListResultItemActionsItemCacheLevelId: any;
export type ListResultItemActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const ListResultItemActionsItemCacheLevelValue: any;
export interface ListResultItemActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: ListResultItemActionsItemCacheLevelId | null;
    /** * `bypass`: Cloudflare does not cache. */
    value?: ListResultItemActionsItemCacheLevelValue | null;
}
export declare const ListResultItemActionsItemCacheLevel: S.Schema<ListResultItemActionsItemCacheLevel>;
export type ListResultItemActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const ListResultItemActionsItemCacheOnCookieId: any;
export interface ListResultItemActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: ListResultItemActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const ListResultItemActionsItemCacheOnCookie: S.Schema<ListResultItemActionsItemCacheOnCookie>;
export type ListResultItemActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const ListResultItemActionsItemCacheTTLByStatusId: any;
export type ListResultItemActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const ListResultItemActionsItemCacheTTLByStatusValueCase0: any;
export type ListResultItemActionsItemCacheTTLByStatusValue = number | ListResultItemActionsItemCacheTTLByStatusValueCase0;
export declare const ListResultItemActionsItemCacheTTLByStatusValue: any;
export interface ListResultItemActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: ListResultItemActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: ListResultItemActionsItemCacheTTLByStatusValue | null;
}
export declare const ListResultItemActionsItemCacheTTLByStatus: S.Schema<ListResultItemActionsItemCacheTTLByStatus>;
export type ListResultItemActionsItemDisableAppsId = "disable_apps";
export declare const ListResultItemActionsItemDisableAppsId: any;
export interface ListResultItemActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: ListResultItemActionsItemDisableAppsId | null;
}
export declare const ListResultItemActionsItemDisableApps: S.Schema<ListResultItemActionsItemDisableApps>;
export type ListResultItemActionsItemDisablePerformanceId = "disable_performance";
export declare const ListResultItemActionsItemDisablePerformanceId: any;
export interface ListResultItemActionsItemDisablePerformance {
    /** Turn off */
    id?: ListResultItemActionsItemDisablePerformanceId | null;
}
export declare const ListResultItemActionsItemDisablePerformance: S.Schema<ListResultItemActionsItemDisablePerformance>;
export type ListResultItemActionsItemDisableSecurityId = "disable_security";
export declare const ListResultItemActionsItemDisableSecurityId: any;
export interface ListResultItemActionsItemDisableSecurity {
    /** Turn off */
    id?: ListResultItemActionsItemDisableSecurityId | null;
}
export declare const ListResultItemActionsItemDisableSecurity: S.Schema<ListResultItemActionsItemDisableSecurity>;
export type ListResultItemActionsItemDisableZarazId = "disable_zaraz";
export declare const ListResultItemActionsItemDisableZarazId: any;
export interface ListResultItemActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: ListResultItemActionsItemDisableZarazId | null;
}
export declare const ListResultItemActionsItemDisableZaraz: S.Schema<ListResultItemActionsItemDisableZaraz>;
export type ListResultItemActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const ListResultItemActionsItemEdgeCacheTTLId: any;
export interface ListResultItemActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: ListResultItemActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export declare const ListResultItemActionsItemEdgeCacheTTL: S.Schema<ListResultItemActionsItemEdgeCacheTTL>;
export type ListResultItemActionsItemEmailObfuscationId = "email_obfuscation";
export declare const ListResultItemActionsItemEmailObfuscationId: any;
export type ListResultItemActionsItemEmailObfuscationValue = "on" | "off";
export declare const ListResultItemActionsItemEmailObfuscationValue: any;
export interface ListResultItemActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: ListResultItemActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: ListResultItemActionsItemEmailObfuscationValue | null;
}
export declare const ListResultItemActionsItemEmailObfuscation: S.Schema<ListResultItemActionsItemEmailObfuscation>;
export type ListResultItemActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const ListResultItemActionsItemExplicitCacheControlId: any;
export type ListResultItemActionsItemExplicitCacheControlValue = "on" | "off";
export declare const ListResultItemActionsItemExplicitCacheControlValue: any;
export interface ListResultItemActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: ListResultItemActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: ListResultItemActionsItemExplicitCacheControlValue | null;
}
export declare const ListResultItemActionsItemExplicitCacheControl: S.Schema<ListResultItemActionsItemExplicitCacheControl>;
export type ListResultItemActionsItemForwardingURLId = "forwarding_url";
export declare const ListResultItemActionsItemForwardingURLId: any;
export type ListResultItemActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const ListResultItemActionsItemForwardingURLValueStatusCode: any;
export interface ListResultItemActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: ListResultItemActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. */
    url?: string | null;
}
export declare const ListResultItemActionsItemForwardingURLValue: S.Schema<ListResultItemActionsItemForwardingURLValue>;
export interface ListResultItemActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: ListResultItemActionsItemForwardingURLId | null;
    value?: ListResultItemActionsItemForwardingURLValue | null;
}
export declare const ListResultItemActionsItemForwardingURL: S.Schema<ListResultItemActionsItemForwardingURL>;
export type ListResultItemActionsItemHostHeaderOverrideId = "host_header_override";
export declare const ListResultItemActionsItemHostHeaderOverrideId: any;
export interface ListResultItemActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: ListResultItemActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export declare const ListResultItemActionsItemHostHeaderOverride: S.Schema<ListResultItemActionsItemHostHeaderOverride>;
export type ListResultItemActionsItemIPGeolocationId = "ip_geolocation";
export declare const ListResultItemActionsItemIPGeolocationId: any;
export type ListResultItemActionsItemIPGeolocationValue = "on" | "off";
export declare const ListResultItemActionsItemIPGeolocationValue: any;
export interface ListResultItemActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: ListResultItemActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: ListResultItemActionsItemIPGeolocationValue | null;
}
export declare const ListResultItemActionsItemIPGeolocation: S.Schema<ListResultItemActionsItemIPGeolocation>;
export type ListResultItemActionsItemMirageId = "mirage";
export declare const ListResultItemActionsItemMirageId: any;
export type ListResultItemActionsItemMirageValue = "on" | "off";
export declare const ListResultItemActionsItemMirageValue: any;
export interface ListResultItemActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: ListResultItemActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: ListResultItemActionsItemMirageValue | null;
}
export declare const ListResultItemActionsItemMirage: S.Schema<ListResultItemActionsItemMirage>;
export type ListResultItemActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const ListResultItemActionsItemOpportunisticEncryptionId: any;
export type ListResultItemActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const ListResultItemActionsItemOpportunisticEncryptionValue: any;
export interface ListResultItemActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: ListResultItemActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: ListResultItemActionsItemOpportunisticEncryptionValue | null;
}
export declare const ListResultItemActionsItemOpportunisticEncryption: S.Schema<ListResultItemActionsItemOpportunisticEncryption>;
export type ListResultItemActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const ListResultItemActionsItemOriginErrorPagePassThruId: any;
export type ListResultItemActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const ListResultItemActionsItemOriginErrorPagePassThruValue: any;
export interface ListResultItemActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: ListResultItemActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: ListResultItemActionsItemOriginErrorPagePassThruValue | null;
}
export declare const ListResultItemActionsItemOriginErrorPagePassThru: S.Schema<ListResultItemActionsItemOriginErrorPagePassThru>;
export type ListResultItemActionsItemPolishId = "polish";
export declare const ListResultItemActionsItemPolishId: any;
export type ListResultItemActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const ListResultItemActionsItemPolishValue: any;
export interface ListResultItemActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: ListResultItemActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: ListResultItemActionsItemPolishValue | null;
}
export declare const ListResultItemActionsItemPolish: S.Schema<ListResultItemActionsItemPolish>;
export type ListResultItemActionsItemResolveOverrideId = "resolve_override";
export declare const ListResultItemActionsItemResolveOverrideId: any;
export interface ListResultItemActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: ListResultItemActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export declare const ListResultItemActionsItemResolveOverride: S.Schema<ListResultItemActionsItemResolveOverride>;
export type ListResultItemActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const ListResultItemActionsItemRespectStrongEtagId: any;
export type ListResultItemActionsItemRespectStrongEtagValue = "on" | "off";
export declare const ListResultItemActionsItemRespectStrongEtagValue: any;
export interface ListResultItemActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: ListResultItemActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: ListResultItemActionsItemRespectStrongEtagValue | null;
}
export declare const ListResultItemActionsItemRespectStrongEtag: S.Schema<ListResultItemActionsItemRespectStrongEtag>;
export type ListResultItemActionsItemResponseBufferingId = "response_buffering";
export declare const ListResultItemActionsItemResponseBufferingId: any;
export type ListResultItemActionsItemResponseBufferingValue = "on" | "off";
export declare const ListResultItemActionsItemResponseBufferingValue: any;
export interface ListResultItemActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: ListResultItemActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: ListResultItemActionsItemResponseBufferingValue | null;
}
export declare const ListResultItemActionsItemResponseBuffering: S.Schema<ListResultItemActionsItemResponseBuffering>;
export type ListResultItemActionsItemRocketLoaderId = "rocket_loader";
export declare const ListResultItemActionsItemRocketLoaderId: any;
export type ListResultItemActionsItemRocketLoaderValue = "on" | "off";
export declare const ListResultItemActionsItemRocketLoaderValue: any;
export interface ListResultItemActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: ListResultItemActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: ListResultItemActionsItemRocketLoaderValue | null;
}
export declare const ListResultItemActionsItemRocketLoader: S.Schema<ListResultItemActionsItemRocketLoader>;
export type ListResultItemActionsItemSecurityLevelId = "security_level";
export declare const ListResultItemActionsItemSecurityLevelId: any;
export type ListResultItemActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const ListResultItemActionsItemSecurityLevelValue: any;
export interface ListResultItemActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: ListResultItemActionsItemSecurityLevelId | null;
    value?: ListResultItemActionsItemSecurityLevelValue | null;
}
export declare const ListResultItemActionsItemSecurityLevel: S.Schema<ListResultItemActionsItemSecurityLevel>;
export type ListResultItemActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const ListResultItemActionsItemSortQueryStringForCacheId: any;
export type ListResultItemActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const ListResultItemActionsItemSortQueryStringForCacheValue: any;
export interface ListResultItemActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: ListResultItemActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: ListResultItemActionsItemSortQueryStringForCacheValue | null;
}
export declare const ListResultItemActionsItemSortQueryStringForCache: S.Schema<ListResultItemActionsItemSortQueryStringForCache>;
export type ListResultItemActionsItemSSLId = "ssl";
export declare const ListResultItemActionsItemSSLId: any;
export type ListResultItemActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const ListResultItemActionsItemSSLValue: any;
export interface ListResultItemActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: ListResultItemActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: ListResultItemActionsItemSSLValue | null;
}
export declare const ListResultItemActionsItemSSL: S.Schema<ListResultItemActionsItemSSL>;
export type ListResultItemActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const ListResultItemActionsItemTrueClientIPHeaderId: any;
export type ListResultItemActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const ListResultItemActionsItemTrueClientIPHeaderValue: any;
export interface ListResultItemActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: ListResultItemActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: ListResultItemActionsItemTrueClientIPHeaderValue | null;
}
export declare const ListResultItemActionsItemTrueClientIPHeader: S.Schema<ListResultItemActionsItemTrueClientIPHeader>;
export type ListResultItemActionsItemWAFId = "waf";
export declare const ListResultItemActionsItemWAFId: any;
export type ListResultItemActionsItemWAFValue = "on" | "off";
export declare const ListResultItemActionsItemWAFValue: any;
export interface ListResultItemActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: ListResultItemActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: ListResultItemActionsItemWAFValue | null;
}
export declare const ListResultItemActionsItemWAF: S.Schema<ListResultItemActionsItemWAF>;
export type ListResultItemActionsItem = ListResultItemActionsItemAlwaysUseHTTPS | ListResultItemActionsItemAutomaticHTTPSRewrites | ListResultItemActionsItemBrowserCacheTTL | ListResultItemActionsItemBrowserCheck | ListResultItemActionsItemBypassCacheOnCookie | ListResultItemActionsItemCacheByDeviceType | ListResultItemActionsItemCacheDeceptionArmor | ListResultItemActionsItemCacheKeyFields | ListResultItemActionsItemCacheLevel | ListResultItemActionsItemCacheOnCookie | ListResultItemActionsItemCacheTTLByStatus | ListResultItemActionsItemDisableApps | ListResultItemActionsItemDisablePerformance | ListResultItemActionsItemDisableSecurity | ListResultItemActionsItemDisableZaraz | ListResultItemActionsItemEdgeCacheTTL | ListResultItemActionsItemEmailObfuscation | ListResultItemActionsItemExplicitCacheControl | ListResultItemActionsItemForwardingURL | ListResultItemActionsItemHostHeaderOverride | ListResultItemActionsItemIPGeolocation | ListResultItemActionsItemMirage | ListResultItemActionsItemOpportunisticEncryption | ListResultItemActionsItemOriginErrorPagePassThru | ListResultItemActionsItemPolish | ListResultItemActionsItemResolveOverride | ListResultItemActionsItemRespectStrongEtag | ListResultItemActionsItemResponseBuffering | ListResultItemActionsItemRocketLoader | ListResultItemActionsItemSecurityLevel | ListResultItemActionsItemSortQueryStringForCache | ListResultItemActionsItemSSL | ListResultItemActionsItemTrueClientIPHeader | ListResultItemActionsItemWAF;
export declare const ListResultItemActionsItem: any;
export type ListResultItemActionsList = Array<ListResultItemActionsItem>;
export declare const ListResultItemActionsList: S.Schema<ListResultItemActionsList>;
export type ListResultItemStatus = "active" | "disabled";
export declare const ListResultItemStatus: any;
export type ListResultItemTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const ListResultItemTargetsItemConstraintOperator: any;
export interface ListResultItemTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: ListResultItemTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const ListResultItemTargetsItemConstraint: S.Schema<ListResultItemTargetsItemConstraint>;
export type ListResultItemTargetsItemTarget = "url";
export declare const ListResultItemTargetsItemTarget: any;
export interface ListResultItemTargetsItem {
    /** String constraint. */
    constraint?: ListResultItemTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: ListResultItemTargetsItemTarget | null;
}
export declare const ListResultItemTargetsItem: S.Schema<ListResultItemTargetsItem>;
export type ListResultItemTargetsList = Array<ListResultItemTargetsItem>;
export declare const ListResultItemTargetsList: S.Schema<ListResultItemTargetsList>;
export interface ListResultItem {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions: ListResultItemActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority: number;
    /** The status of the Page Rule. */
    status: ListResultItemStatus;
    /** The rule targets to evaluate on each request. */
    targets: ListResultItemTargetsList;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export type ListPageRulesResponse = ListResultList;
export declare const ListPageRulesResponse: S.Schema<ListPageRulesResponse>;
export type EditRequestActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const EditRequestActionsItemAlwaysUseHTTPSId: any;
export interface EditRequestActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: EditRequestActionsItemAlwaysUseHTTPSId | (string & {});
}
export declare const EditRequestActionsItemAlwaysUseHTTPS: S.Schema<EditRequestActionsItemAlwaysUseHTTPS>;
export type EditRequestActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const EditRequestActionsItemAutomaticHTTPSRewritesId: any;
export type EditRequestActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const EditRequestActionsItemAutomaticHTTPSRewritesValue: any;
export interface EditRequestActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: EditRequestActionsItemAutomaticHTTPSRewritesId | (string & {});
    /** The status of Automatic HTTPS Rewrites. */
    value?: EditRequestActionsItemAutomaticHTTPSRewritesValue | (string & {});
}
export declare const EditRequestActionsItemAutomaticHTTPSRewrites: S.Schema<EditRequestActionsItemAutomaticHTTPSRewrites>;
export type EditRequestActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const EditRequestActionsItemBrowserCacheTTLId: any;
export interface EditRequestActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: EditRequestActionsItemBrowserCacheTTLId | (string & {});
    /** The number of seconds to cache resources for. */
    value?: number;
}
export declare const EditRequestActionsItemBrowserCacheTTL: S.Schema<EditRequestActionsItemBrowserCacheTTL>;
export type EditRequestActionsItemBrowserCheckId = "browser_check";
export declare const EditRequestActionsItemBrowserCheckId: any;
export type EditRequestActionsItemBrowserCheckValue = "on" | "off";
export declare const EditRequestActionsItemBrowserCheckValue: any;
export interface EditRequestActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: EditRequestActionsItemBrowserCheckId | (string & {});
    /** The status of Browser Integrity Check. */
    value?: EditRequestActionsItemBrowserCheckValue | (string & {});
}
export declare const EditRequestActionsItemBrowserCheck: S.Schema<EditRequestActionsItemBrowserCheck>;
export type EditRequestActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const EditRequestActionsItemBypassCacheOnCookieId: any;
export interface EditRequestActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: EditRequestActionsItemBypassCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the */
    value?: string;
}
export declare const EditRequestActionsItemBypassCacheOnCookie: S.Schema<EditRequestActionsItemBypassCacheOnCookie>;
export type EditRequestActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const EditRequestActionsItemCacheByDeviceTypeId: any;
export type EditRequestActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const EditRequestActionsItemCacheByDeviceTypeValue: any;
export interface EditRequestActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: EditRequestActionsItemCacheByDeviceTypeId | (string & {});
    /** The status of Cache By Device Type. */
    value?: EditRequestActionsItemCacheByDeviceTypeValue | (string & {});
}
export declare const EditRequestActionsItemCacheByDeviceType: S.Schema<EditRequestActionsItemCacheByDeviceType>;
export type EditRequestActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const EditRequestActionsItemCacheDeceptionArmorId: any;
export type EditRequestActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const EditRequestActionsItemCacheDeceptionArmorValue: any;
export interface EditRequestActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: EditRequestActionsItemCacheDeceptionArmorId | (string & {});
    /** The status of Cache Deception Armor. */
    value?: EditRequestActionsItemCacheDeceptionArmorValue | (string & {});
}
export declare const EditRequestActionsItemCacheDeceptionArmor: S.Schema<EditRequestActionsItemCacheDeceptionArmor>;
export type EditRequestActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const EditRequestActionsItemCacheKeyFieldsId: any;
export type EditRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const EditRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<EditRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type EditRequestActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const EditRequestActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<EditRequestActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface EditRequestActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: EditRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList;
    /** A list of cookies to include. */
    include?: EditRequestActionsItemCacheKeyFieldsValueCookieIncludeList;
}
export declare const EditRequestActionsItemCacheKeyFieldsValueCookie: S.Schema<EditRequestActionsItemCacheKeyFieldsValueCookie>;
export type EditRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const EditRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<EditRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type EditRequestActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const EditRequestActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<EditRequestActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type EditRequestActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const EditRequestActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<EditRequestActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface EditRequestActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: EditRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList;
    /** A list of headers to ignore. */
    exclude?: EditRequestActionsItemCacheKeyFieldsValueHeaderExcludeList;
    /** A list of headers to include. */
    include?: EditRequestActionsItemCacheKeyFieldsValueHeaderIncludeList;
}
export declare const EditRequestActionsItemCacheKeyFieldsValueHeader: S.Schema<EditRequestActionsItemCacheKeyFieldsValueHeader>;
export type EditRequestActionsItemCacheKeyFieldsValueHost = CreateRequestActionsItemCacheKeyFieldsValueHost;
export declare const EditRequestActionsItemCacheKeyFieldsValueHost: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueHost>;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringExclude = EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | (string & {}) | EditRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const EditRequestActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type EditRequestActionsItemCacheKeyFieldsValueQueryStringInclude = EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | (string & {}) | EditRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const EditRequestActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface EditRequestActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: EditRequestActionsItemCacheKeyFieldsValueQueryStringExclude;
    /** Include all query string parameters. */
    include?: EditRequestActionsItemCacheKeyFieldsValueQueryStringInclude;
}
export declare const EditRequestActionsItemCacheKeyFieldsValueQueryString: S.Schema<EditRequestActionsItemCacheKeyFieldsValueQueryString>;
export type EditRequestActionsItemCacheKeyFieldsValueUser = CreateRequestActionsItemCacheKeyFieldsValueUser;
export declare const EditRequestActionsItemCacheKeyFieldsValueUser: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueUser>;
export interface EditRequestActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: EditRequestActionsItemCacheKeyFieldsValueCookie;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: EditRequestActionsItemCacheKeyFieldsValueHeader;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateRequestActionsItemCacheKeyFieldsValueHost;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: EditRequestActionsItemCacheKeyFieldsValueQueryString;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateRequestActionsItemCacheKeyFieldsValueUser;
}
export declare const EditRequestActionsItemCacheKeyFieldsValue: S.Schema<EditRequestActionsItemCacheKeyFieldsValue>;
export interface EditRequestActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: EditRequestActionsItemCacheKeyFieldsId | (string & {});
    value?: EditRequestActionsItemCacheKeyFieldsValue;
}
export declare const EditRequestActionsItemCacheKeyFields: S.Schema<EditRequestActionsItemCacheKeyFields>;
export type EditRequestActionsItemCacheLevelId = "cache_level";
export declare const EditRequestActionsItemCacheLevelId: any;
export type EditRequestActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const EditRequestActionsItemCacheLevelValue: any;
export interface EditRequestActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: EditRequestActionsItemCacheLevelId | (string & {});
    /** * `bypass`: Cloudflare does not cache. */
    value?: EditRequestActionsItemCacheLevelValue | (string & {});
}
export declare const EditRequestActionsItemCacheLevel: S.Schema<EditRequestActionsItemCacheLevel>;
export type EditRequestActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const EditRequestActionsItemCacheOnCookieId: any;
export interface EditRequestActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: EditRequestActionsItemCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the */
    value?: string;
}
export declare const EditRequestActionsItemCacheOnCookie: S.Schema<EditRequestActionsItemCacheOnCookie>;
export type EditRequestActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const EditRequestActionsItemCacheTTLByStatusId: any;
export type EditRequestActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const EditRequestActionsItemCacheTTLByStatusValueCase0: any;
export type EditRequestActionsItemCacheTTLByStatusValue = number | EditRequestActionsItemCacheTTLByStatusValueCase0 | (string & {});
export declare const EditRequestActionsItemCacheTTLByStatusValue: any;
export interface EditRequestActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: EditRequestActionsItemCacheTTLByStatusId | (string & {});
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: EditRequestActionsItemCacheTTLByStatusValue;
}
export declare const EditRequestActionsItemCacheTTLByStatus: S.Schema<EditRequestActionsItemCacheTTLByStatus>;
export type EditRequestActionsItemDisableAppsId = "disable_apps";
export declare const EditRequestActionsItemDisableAppsId: any;
export interface EditRequestActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: EditRequestActionsItemDisableAppsId | (string & {});
}
export declare const EditRequestActionsItemDisableApps: S.Schema<EditRequestActionsItemDisableApps>;
export type EditRequestActionsItemDisablePerformanceId = "disable_performance";
export declare const EditRequestActionsItemDisablePerformanceId: any;
export interface EditRequestActionsItemDisablePerformance {
    /** Turn off */
    id?: EditRequestActionsItemDisablePerformanceId | (string & {});
}
export declare const EditRequestActionsItemDisablePerformance: S.Schema<EditRequestActionsItemDisablePerformance>;
export type EditRequestActionsItemDisableSecurityId = "disable_security";
export declare const EditRequestActionsItemDisableSecurityId: any;
export interface EditRequestActionsItemDisableSecurity {
    /** Turn off */
    id?: EditRequestActionsItemDisableSecurityId | (string & {});
}
export declare const EditRequestActionsItemDisableSecurity: S.Schema<EditRequestActionsItemDisableSecurity>;
export type EditRequestActionsItemDisableZarazId = "disable_zaraz";
export declare const EditRequestActionsItemDisableZarazId: any;
export interface EditRequestActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: EditRequestActionsItemDisableZarazId | (string & {});
}
export declare const EditRequestActionsItemDisableZaraz: S.Schema<EditRequestActionsItemDisableZaraz>;
export type EditRequestActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const EditRequestActionsItemEdgeCacheTTLId: any;
export interface EditRequestActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: EditRequestActionsItemEdgeCacheTTLId | (string & {});
    value?: number;
}
export declare const EditRequestActionsItemEdgeCacheTTL: S.Schema<EditRequestActionsItemEdgeCacheTTL>;
export type EditRequestActionsItemEmailObfuscationId = "email_obfuscation";
export declare const EditRequestActionsItemEmailObfuscationId: any;
export type EditRequestActionsItemEmailObfuscationValue = "on" | "off";
export declare const EditRequestActionsItemEmailObfuscationValue: any;
export interface EditRequestActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: EditRequestActionsItemEmailObfuscationId | (string & {});
    /** The status of Email Obfuscation. */
    value?: EditRequestActionsItemEmailObfuscationValue | (string & {});
}
export declare const EditRequestActionsItemEmailObfuscation: S.Schema<EditRequestActionsItemEmailObfuscation>;
export type EditRequestActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const EditRequestActionsItemExplicitCacheControlId: any;
export type EditRequestActionsItemExplicitCacheControlValue = "on" | "off";
export declare const EditRequestActionsItemExplicitCacheControlValue: any;
export interface EditRequestActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: EditRequestActionsItemExplicitCacheControlId | (string & {});
    /** The status of Origin Cache Control. */
    value?: EditRequestActionsItemExplicitCacheControlValue | (string & {});
}
export declare const EditRequestActionsItemExplicitCacheControl: S.Schema<EditRequestActionsItemExplicitCacheControl>;
export type EditRequestActionsItemForwardingURLId = "forwarding_url";
export declare const EditRequestActionsItemForwardingURLId: any;
export type EditRequestActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const EditRequestActionsItemForwardingURLValueStatusCode: any;
export interface EditRequestActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: EditRequestActionsItemForwardingURLValueStatusCode | (number & {});
    /** The URL to redirect the request to. */
    url?: string;
}
export declare const EditRequestActionsItemForwardingURLValue: S.Schema<EditRequestActionsItemForwardingURLValue>;
export interface EditRequestActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: EditRequestActionsItemForwardingURLId | (string & {});
    value?: EditRequestActionsItemForwardingURLValue;
}
export declare const EditRequestActionsItemForwardingURL: S.Schema<EditRequestActionsItemForwardingURL>;
export type EditRequestActionsItemHostHeaderOverrideId = "host_header_override";
export declare const EditRequestActionsItemHostHeaderOverrideId: any;
export interface EditRequestActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: EditRequestActionsItemHostHeaderOverrideId | (string & {});
    /** The hostname to use in the `Host` header */
    value?: string;
}
export declare const EditRequestActionsItemHostHeaderOverride: S.Schema<EditRequestActionsItemHostHeaderOverride>;
export type EditRequestActionsItemIPGeolocationId = "ip_geolocation";
export declare const EditRequestActionsItemIPGeolocationId: any;
export type EditRequestActionsItemIPGeolocationValue = "on" | "off";
export declare const EditRequestActionsItemIPGeolocationValue: any;
export interface EditRequestActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: EditRequestActionsItemIPGeolocationId | (string & {});
    /** The status of adding the IP Geolocation Header. */
    value?: EditRequestActionsItemIPGeolocationValue | (string & {});
}
export declare const EditRequestActionsItemIPGeolocation: S.Schema<EditRequestActionsItemIPGeolocation>;
export type EditRequestActionsItemMirageId = "mirage";
export declare const EditRequestActionsItemMirageId: any;
export type EditRequestActionsItemMirageValue = "on" | "off";
export declare const EditRequestActionsItemMirageValue: any;
export interface EditRequestActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: EditRequestActionsItemMirageId | (string & {});
    /** The status of Mirage. */
    value?: EditRequestActionsItemMirageValue | (string & {});
}
export declare const EditRequestActionsItemMirage: S.Schema<EditRequestActionsItemMirage>;
export type EditRequestActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const EditRequestActionsItemOpportunisticEncryptionId: any;
export type EditRequestActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const EditRequestActionsItemOpportunisticEncryptionValue: any;
export interface EditRequestActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: EditRequestActionsItemOpportunisticEncryptionId | (string & {});
    /** The status of Opportunistic Encryption. */
    value?: EditRequestActionsItemOpportunisticEncryptionValue | (string & {});
}
export declare const EditRequestActionsItemOpportunisticEncryption: S.Schema<EditRequestActionsItemOpportunisticEncryption>;
export type EditRequestActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const EditRequestActionsItemOriginErrorPagePassThruId: any;
export type EditRequestActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const EditRequestActionsItemOriginErrorPagePassThruValue: any;
export interface EditRequestActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: EditRequestActionsItemOriginErrorPagePassThruId | (string & {});
    /** The status of Origin Error Page Passthru. */
    value?: EditRequestActionsItemOriginErrorPagePassThruValue | (string & {});
}
export declare const EditRequestActionsItemOriginErrorPagePassThru: S.Schema<EditRequestActionsItemOriginErrorPagePassThru>;
export type EditRequestActionsItemPolishId = "polish";
export declare const EditRequestActionsItemPolishId: any;
export type EditRequestActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const EditRequestActionsItemPolishValue: any;
export interface EditRequestActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: EditRequestActionsItemPolishId | (string & {});
    /** The level of Polish you want applied to your origin. */
    value?: EditRequestActionsItemPolishValue | (string & {});
}
export declare const EditRequestActionsItemPolish: S.Schema<EditRequestActionsItemPolish>;
export type EditRequestActionsItemResolveOverrideId = "resolve_override";
export declare const EditRequestActionsItemResolveOverrideId: any;
export interface EditRequestActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: EditRequestActionsItemResolveOverrideId | (string & {});
    /** The origin address you want to override with. */
    value?: string;
}
export declare const EditRequestActionsItemResolveOverride: S.Schema<EditRequestActionsItemResolveOverride>;
export type EditRequestActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const EditRequestActionsItemRespectStrongEtagId: any;
export type EditRequestActionsItemRespectStrongEtagValue = "on" | "off";
export declare const EditRequestActionsItemRespectStrongEtagValue: any;
export interface EditRequestActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: EditRequestActionsItemRespectStrongEtagId | (string & {});
    /** The status of Respect Strong ETags */
    value?: EditRequestActionsItemRespectStrongEtagValue | (string & {});
}
export declare const EditRequestActionsItemRespectStrongEtag: S.Schema<EditRequestActionsItemRespectStrongEtag>;
export type EditRequestActionsItemResponseBufferingId = "response_buffering";
export declare const EditRequestActionsItemResponseBufferingId: any;
export type EditRequestActionsItemResponseBufferingValue = "on" | "off";
export declare const EditRequestActionsItemResponseBufferingValue: any;
export interface EditRequestActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: EditRequestActionsItemResponseBufferingId | (string & {});
    /** The status of Response Buffering */
    value?: EditRequestActionsItemResponseBufferingValue | (string & {});
}
export declare const EditRequestActionsItemResponseBuffering: S.Schema<EditRequestActionsItemResponseBuffering>;
export type EditRequestActionsItemRocketLoaderId = "rocket_loader";
export declare const EditRequestActionsItemRocketLoaderId: any;
export type EditRequestActionsItemRocketLoaderValue = "on" | "off";
export declare const EditRequestActionsItemRocketLoaderValue: any;
export interface EditRequestActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: EditRequestActionsItemRocketLoaderId | (string & {});
    /** The status of Rocket Loader */
    value?: EditRequestActionsItemRocketLoaderValue | (string & {});
}
export declare const EditRequestActionsItemRocketLoader: S.Schema<EditRequestActionsItemRocketLoader>;
export type EditRequestActionsItemSecurityLevelId = "security_level";
export declare const EditRequestActionsItemSecurityLevelId: any;
export type EditRequestActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const EditRequestActionsItemSecurityLevelValue: any;
export interface EditRequestActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: EditRequestActionsItemSecurityLevelId | (string & {});
    value?: EditRequestActionsItemSecurityLevelValue | (string & {});
}
export declare const EditRequestActionsItemSecurityLevel: S.Schema<EditRequestActionsItemSecurityLevel>;
export type EditRequestActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const EditRequestActionsItemSortQueryStringForCacheId: any;
export type EditRequestActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const EditRequestActionsItemSortQueryStringForCacheValue: any;
export interface EditRequestActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: EditRequestActionsItemSortQueryStringForCacheId | (string & {});
    /** The status of Query String Sort */
    value?: EditRequestActionsItemSortQueryStringForCacheValue | (string & {});
}
export declare const EditRequestActionsItemSortQueryStringForCache: S.Schema<EditRequestActionsItemSortQueryStringForCache>;
export type EditRequestActionsItemSSLId = "ssl";
export declare const EditRequestActionsItemSSLId: any;
export type EditRequestActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const EditRequestActionsItemSSLValue: any;
export interface EditRequestActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: EditRequestActionsItemSSLId | (string & {});
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: EditRequestActionsItemSSLValue | (string & {});
}
export declare const EditRequestActionsItemSSL: S.Schema<EditRequestActionsItemSSL>;
export type EditRequestActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const EditRequestActionsItemTrueClientIPHeaderId: any;
export type EditRequestActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const EditRequestActionsItemTrueClientIPHeaderValue: any;
export interface EditRequestActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: EditRequestActionsItemTrueClientIPHeaderId | (string & {});
    /** The status of True Client IP Header. */
    value?: EditRequestActionsItemTrueClientIPHeaderValue | (string & {});
}
export declare const EditRequestActionsItemTrueClientIPHeader: S.Schema<EditRequestActionsItemTrueClientIPHeader>;
export type EditRequestActionsItemWAFId = "waf";
export declare const EditRequestActionsItemWAFId: any;
export type EditRequestActionsItemWAFValue = "on" | "off";
export declare const EditRequestActionsItemWAFValue: any;
export interface EditRequestActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: EditRequestActionsItemWAFId | (string & {});
    /** The status of WAF managed rules (previous version). */
    value?: EditRequestActionsItemWAFValue | (string & {});
}
export declare const EditRequestActionsItemWAF: S.Schema<EditRequestActionsItemWAF>;
export type EditRequestActionsItem = EditRequestActionsItemAlwaysUseHTTPS | EditRequestActionsItemAutomaticHTTPSRewrites | EditRequestActionsItemBrowserCacheTTL | EditRequestActionsItemBrowserCheck | EditRequestActionsItemBypassCacheOnCookie | EditRequestActionsItemCacheByDeviceType | EditRequestActionsItemCacheDeceptionArmor | EditRequestActionsItemCacheKeyFields | EditRequestActionsItemCacheLevel | EditRequestActionsItemCacheOnCookie | EditRequestActionsItemCacheTTLByStatus | EditRequestActionsItemDisableApps | EditRequestActionsItemDisablePerformance | EditRequestActionsItemDisableSecurity | EditRequestActionsItemDisableZaraz | EditRequestActionsItemEdgeCacheTTL | EditRequestActionsItemEmailObfuscation | EditRequestActionsItemExplicitCacheControl | EditRequestActionsItemForwardingURL | EditRequestActionsItemHostHeaderOverride | EditRequestActionsItemIPGeolocation | EditRequestActionsItemMirage | EditRequestActionsItemOpportunisticEncryption | EditRequestActionsItemOriginErrorPagePassThru | EditRequestActionsItemPolish | EditRequestActionsItemResolveOverride | EditRequestActionsItemRespectStrongEtag | EditRequestActionsItemResponseBuffering | EditRequestActionsItemRocketLoader | EditRequestActionsItemSecurityLevel | EditRequestActionsItemSortQueryStringForCache | EditRequestActionsItemSSL | EditRequestActionsItemTrueClientIPHeader | EditRequestActionsItemWAF;
export declare const EditRequestActionsItem: any;
export type EditRequestActionsList = Array<EditRequestActionsItem>;
export declare const EditRequestActionsList: S.Schema<EditRequestActionsList>;
export type EditRequestStatus = "active" | "disabled";
export declare const EditRequestStatus: any;
export type EditRequestTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const EditRequestTargetsItemConstraintOperator: any;
export interface EditRequestTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: EditRequestTargetsItemConstraintOperator | (string & {});
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const EditRequestTargetsItemConstraint: S.Schema<EditRequestTargetsItemConstraint>;
export type EditRequestTargetsItemTarget = "url";
export declare const EditRequestTargetsItemTarget: any;
export interface EditRequestTargetsItem {
    /** String constraint. */
    constraint?: EditRequestTargetsItemConstraint;
    /** A target based on the URL of the request. */
    target?: EditRequestTargetsItemTarget | (string & {});
}
export declare const EditRequestTargetsItem: S.Schema<EditRequestTargetsItem>;
export type EditRequestTargetsList = Array<EditRequestTargetsItem>;
export declare const EditRequestTargetsList: S.Schema<EditRequestTargetsList>;
export interface PatchPageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions?: EditRequestActionsList;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority?: number;
    /** The status of the Page Rule. */
    status?: EditRequestStatus | (string & {});
    /** The rule targets to evaluate on each request. */
    targets?: EditRequestTargetsList;
}
export declare const PatchPageRuleRequest: S.Schema<PatchPageRuleRequest>;
export type EditResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const EditResponseActionsItemAlwaysUseHTTPSId: any;
export interface EditResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: EditResponseActionsItemAlwaysUseHTTPSId | null;
}
export declare const EditResponseActionsItemAlwaysUseHTTPS: S.Schema<EditResponseActionsItemAlwaysUseHTTPS>;
export type EditResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const EditResponseActionsItemAutomaticHTTPSRewritesId: any;
export type EditResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const EditResponseActionsItemAutomaticHTTPSRewritesValue: any;
export interface EditResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: EditResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: EditResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export declare const EditResponseActionsItemAutomaticHTTPSRewrites: S.Schema<EditResponseActionsItemAutomaticHTTPSRewrites>;
export type EditResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const EditResponseActionsItemBrowserCacheTTLId: any;
export interface EditResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: EditResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. */
    value?: number | null;
}
export declare const EditResponseActionsItemBrowserCacheTTL: S.Schema<EditResponseActionsItemBrowserCacheTTL>;
export type EditResponseActionsItemBrowserCheckId = "browser_check";
export declare const EditResponseActionsItemBrowserCheckId: any;
export type EditResponseActionsItemBrowserCheckValue = "on" | "off";
export declare const EditResponseActionsItemBrowserCheckValue: any;
export interface EditResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: EditResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: EditResponseActionsItemBrowserCheckValue | null;
}
export declare const EditResponseActionsItemBrowserCheck: S.Schema<EditResponseActionsItemBrowserCheck>;
export type EditResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const EditResponseActionsItemBypassCacheOnCookieId: any;
export interface EditResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: EditResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const EditResponseActionsItemBypassCacheOnCookie: S.Schema<EditResponseActionsItemBypassCacheOnCookie>;
export type EditResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const EditResponseActionsItemCacheByDeviceTypeId: any;
export type EditResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const EditResponseActionsItemCacheByDeviceTypeValue: any;
export interface EditResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: EditResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: EditResponseActionsItemCacheByDeviceTypeValue | null;
}
export declare const EditResponseActionsItemCacheByDeviceType: S.Schema<EditResponseActionsItemCacheByDeviceType>;
export type EditResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const EditResponseActionsItemCacheDeceptionArmorId: any;
export type EditResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const EditResponseActionsItemCacheDeceptionArmorValue: any;
export interface EditResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: EditResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: EditResponseActionsItemCacheDeceptionArmorValue | null;
}
export declare const EditResponseActionsItemCacheDeceptionArmor: S.Schema<EditResponseActionsItemCacheDeceptionArmor>;
export type EditResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const EditResponseActionsItemCacheKeyFieldsId: any;
export type EditResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const EditResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<EditResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type EditResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const EditResponseActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<EditResponseActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface EditResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: EditResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: EditResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export declare const EditResponseActionsItemCacheKeyFieldsValueCookie: S.Schema<EditResponseActionsItemCacheKeyFieldsValueCookie>;
export type EditResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const EditResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<EditResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type EditResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const EditResponseActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<EditResponseActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type EditResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const EditResponseActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<EditResponseActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface EditResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: EditResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: EditResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: EditResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export declare const EditResponseActionsItemCacheKeyFieldsValueHeader: S.Schema<EditResponseActionsItemCacheKeyFieldsValueHeader>;
export type EditResponseActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export declare const EditResponseActionsItemCacheKeyFieldsValueHost: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHost>;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringExclude = EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | EditResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const EditResponseActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type EditResponseActionsItemCacheKeyFieldsValueQueryStringInclude = EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | EditResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const EditResponseActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface EditResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: EditResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: EditResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export declare const EditResponseActionsItemCacheKeyFieldsValueQueryString: S.Schema<EditResponseActionsItemCacheKeyFieldsValueQueryString>;
export type EditResponseActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export declare const EditResponseActionsItemCacheKeyFieldsValueUser: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueUser>;
export interface EditResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: EditResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: EditResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: EditResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export declare const EditResponseActionsItemCacheKeyFieldsValue: S.Schema<EditResponseActionsItemCacheKeyFieldsValue>;
export interface EditResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: EditResponseActionsItemCacheKeyFieldsId | null;
    value?: EditResponseActionsItemCacheKeyFieldsValue | null;
}
export declare const EditResponseActionsItemCacheKeyFields: S.Schema<EditResponseActionsItemCacheKeyFields>;
export type EditResponseActionsItemCacheLevelId = "cache_level";
export declare const EditResponseActionsItemCacheLevelId: any;
export type EditResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const EditResponseActionsItemCacheLevelValue: any;
export interface EditResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: EditResponseActionsItemCacheLevelId | null;
    /** * `bypass`: Cloudflare does not cache. */
    value?: EditResponseActionsItemCacheLevelValue | null;
}
export declare const EditResponseActionsItemCacheLevel: S.Schema<EditResponseActionsItemCacheLevel>;
export type EditResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const EditResponseActionsItemCacheOnCookieId: any;
export interface EditResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: EditResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const EditResponseActionsItemCacheOnCookie: S.Schema<EditResponseActionsItemCacheOnCookie>;
export type EditResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const EditResponseActionsItemCacheTTLByStatusId: any;
export type EditResponseActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const EditResponseActionsItemCacheTTLByStatusValueCase0: any;
export type EditResponseActionsItemCacheTTLByStatusValue = number | EditResponseActionsItemCacheTTLByStatusValueCase0;
export declare const EditResponseActionsItemCacheTTLByStatusValue: any;
export interface EditResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: EditResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: EditResponseActionsItemCacheTTLByStatusValue | null;
}
export declare const EditResponseActionsItemCacheTTLByStatus: S.Schema<EditResponseActionsItemCacheTTLByStatus>;
export type EditResponseActionsItemDisableAppsId = "disable_apps";
export declare const EditResponseActionsItemDisableAppsId: any;
export interface EditResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: EditResponseActionsItemDisableAppsId | null;
}
export declare const EditResponseActionsItemDisableApps: S.Schema<EditResponseActionsItemDisableApps>;
export type EditResponseActionsItemDisablePerformanceId = "disable_performance";
export declare const EditResponseActionsItemDisablePerformanceId: any;
export interface EditResponseActionsItemDisablePerformance {
    /** Turn off */
    id?: EditResponseActionsItemDisablePerformanceId | null;
}
export declare const EditResponseActionsItemDisablePerformance: S.Schema<EditResponseActionsItemDisablePerformance>;
export type EditResponseActionsItemDisableSecurityId = "disable_security";
export declare const EditResponseActionsItemDisableSecurityId: any;
export interface EditResponseActionsItemDisableSecurity {
    /** Turn off */
    id?: EditResponseActionsItemDisableSecurityId | null;
}
export declare const EditResponseActionsItemDisableSecurity: S.Schema<EditResponseActionsItemDisableSecurity>;
export type EditResponseActionsItemDisableZarazId = "disable_zaraz";
export declare const EditResponseActionsItemDisableZarazId: any;
export interface EditResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: EditResponseActionsItemDisableZarazId | null;
}
export declare const EditResponseActionsItemDisableZaraz: S.Schema<EditResponseActionsItemDisableZaraz>;
export type EditResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const EditResponseActionsItemEdgeCacheTTLId: any;
export interface EditResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: EditResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export declare const EditResponseActionsItemEdgeCacheTTL: S.Schema<EditResponseActionsItemEdgeCacheTTL>;
export type EditResponseActionsItemEmailObfuscationId = "email_obfuscation";
export declare const EditResponseActionsItemEmailObfuscationId: any;
export type EditResponseActionsItemEmailObfuscationValue = "on" | "off";
export declare const EditResponseActionsItemEmailObfuscationValue: any;
export interface EditResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: EditResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: EditResponseActionsItemEmailObfuscationValue | null;
}
export declare const EditResponseActionsItemEmailObfuscation: S.Schema<EditResponseActionsItemEmailObfuscation>;
export type EditResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const EditResponseActionsItemExplicitCacheControlId: any;
export type EditResponseActionsItemExplicitCacheControlValue = "on" | "off";
export declare const EditResponseActionsItemExplicitCacheControlValue: any;
export interface EditResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: EditResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: EditResponseActionsItemExplicitCacheControlValue | null;
}
export declare const EditResponseActionsItemExplicitCacheControl: S.Schema<EditResponseActionsItemExplicitCacheControl>;
export type EditResponseActionsItemForwardingURLId = "forwarding_url";
export declare const EditResponseActionsItemForwardingURLId: any;
export type EditResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const EditResponseActionsItemForwardingURLValueStatusCode: any;
export interface EditResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: EditResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. */
    url?: string | null;
}
export declare const EditResponseActionsItemForwardingURLValue: S.Schema<EditResponseActionsItemForwardingURLValue>;
export interface EditResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: EditResponseActionsItemForwardingURLId | null;
    value?: EditResponseActionsItemForwardingURLValue | null;
}
export declare const EditResponseActionsItemForwardingURL: S.Schema<EditResponseActionsItemForwardingURL>;
export type EditResponseActionsItemHostHeaderOverrideId = "host_header_override";
export declare const EditResponseActionsItemHostHeaderOverrideId: any;
export interface EditResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: EditResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export declare const EditResponseActionsItemHostHeaderOverride: S.Schema<EditResponseActionsItemHostHeaderOverride>;
export type EditResponseActionsItemIPGeolocationId = "ip_geolocation";
export declare const EditResponseActionsItemIPGeolocationId: any;
export type EditResponseActionsItemIPGeolocationValue = "on" | "off";
export declare const EditResponseActionsItemIPGeolocationValue: any;
export interface EditResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: EditResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: EditResponseActionsItemIPGeolocationValue | null;
}
export declare const EditResponseActionsItemIPGeolocation: S.Schema<EditResponseActionsItemIPGeolocation>;
export type EditResponseActionsItemMirageId = "mirage";
export declare const EditResponseActionsItemMirageId: any;
export type EditResponseActionsItemMirageValue = "on" | "off";
export declare const EditResponseActionsItemMirageValue: any;
export interface EditResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: EditResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: EditResponseActionsItemMirageValue | null;
}
export declare const EditResponseActionsItemMirage: S.Schema<EditResponseActionsItemMirage>;
export type EditResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const EditResponseActionsItemOpportunisticEncryptionId: any;
export type EditResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const EditResponseActionsItemOpportunisticEncryptionValue: any;
export interface EditResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: EditResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: EditResponseActionsItemOpportunisticEncryptionValue | null;
}
export declare const EditResponseActionsItemOpportunisticEncryption: S.Schema<EditResponseActionsItemOpportunisticEncryption>;
export type EditResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const EditResponseActionsItemOriginErrorPagePassThruId: any;
export type EditResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const EditResponseActionsItemOriginErrorPagePassThruValue: any;
export interface EditResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: EditResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: EditResponseActionsItemOriginErrorPagePassThruValue | null;
}
export declare const EditResponseActionsItemOriginErrorPagePassThru: S.Schema<EditResponseActionsItemOriginErrorPagePassThru>;
export type EditResponseActionsItemPolishId = "polish";
export declare const EditResponseActionsItemPolishId: any;
export type EditResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const EditResponseActionsItemPolishValue: any;
export interface EditResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: EditResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: EditResponseActionsItemPolishValue | null;
}
export declare const EditResponseActionsItemPolish: S.Schema<EditResponseActionsItemPolish>;
export type EditResponseActionsItemResolveOverrideId = "resolve_override";
export declare const EditResponseActionsItemResolveOverrideId: any;
export interface EditResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: EditResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export declare const EditResponseActionsItemResolveOverride: S.Schema<EditResponseActionsItemResolveOverride>;
export type EditResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const EditResponseActionsItemRespectStrongEtagId: any;
export type EditResponseActionsItemRespectStrongEtagValue = "on" | "off";
export declare const EditResponseActionsItemRespectStrongEtagValue: any;
export interface EditResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: EditResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: EditResponseActionsItemRespectStrongEtagValue | null;
}
export declare const EditResponseActionsItemRespectStrongEtag: S.Schema<EditResponseActionsItemRespectStrongEtag>;
export type EditResponseActionsItemResponseBufferingId = "response_buffering";
export declare const EditResponseActionsItemResponseBufferingId: any;
export type EditResponseActionsItemResponseBufferingValue = "on" | "off";
export declare const EditResponseActionsItemResponseBufferingValue: any;
export interface EditResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: EditResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: EditResponseActionsItemResponseBufferingValue | null;
}
export declare const EditResponseActionsItemResponseBuffering: S.Schema<EditResponseActionsItemResponseBuffering>;
export type EditResponseActionsItemRocketLoaderId = "rocket_loader";
export declare const EditResponseActionsItemRocketLoaderId: any;
export type EditResponseActionsItemRocketLoaderValue = "on" | "off";
export declare const EditResponseActionsItemRocketLoaderValue: any;
export interface EditResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: EditResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: EditResponseActionsItemRocketLoaderValue | null;
}
export declare const EditResponseActionsItemRocketLoader: S.Schema<EditResponseActionsItemRocketLoader>;
export type EditResponseActionsItemSecurityLevelId = "security_level";
export declare const EditResponseActionsItemSecurityLevelId: any;
export type EditResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const EditResponseActionsItemSecurityLevelValue: any;
export interface EditResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: EditResponseActionsItemSecurityLevelId | null;
    value?: EditResponseActionsItemSecurityLevelValue | null;
}
export declare const EditResponseActionsItemSecurityLevel: S.Schema<EditResponseActionsItemSecurityLevel>;
export type EditResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const EditResponseActionsItemSortQueryStringForCacheId: any;
export type EditResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const EditResponseActionsItemSortQueryStringForCacheValue: any;
export interface EditResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: EditResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: EditResponseActionsItemSortQueryStringForCacheValue | null;
}
export declare const EditResponseActionsItemSortQueryStringForCache: S.Schema<EditResponseActionsItemSortQueryStringForCache>;
export type EditResponseActionsItemSSLId = "ssl";
export declare const EditResponseActionsItemSSLId: any;
export type EditResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const EditResponseActionsItemSSLValue: any;
export interface EditResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: EditResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: EditResponseActionsItemSSLValue | null;
}
export declare const EditResponseActionsItemSSL: S.Schema<EditResponseActionsItemSSL>;
export type EditResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const EditResponseActionsItemTrueClientIPHeaderId: any;
export type EditResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const EditResponseActionsItemTrueClientIPHeaderValue: any;
export interface EditResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: EditResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: EditResponseActionsItemTrueClientIPHeaderValue | null;
}
export declare const EditResponseActionsItemTrueClientIPHeader: S.Schema<EditResponseActionsItemTrueClientIPHeader>;
export type EditResponseActionsItemWAFId = "waf";
export declare const EditResponseActionsItemWAFId: any;
export type EditResponseActionsItemWAFValue = "on" | "off";
export declare const EditResponseActionsItemWAFValue: any;
export interface EditResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: EditResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: EditResponseActionsItemWAFValue | null;
}
export declare const EditResponseActionsItemWAF: S.Schema<EditResponseActionsItemWAF>;
export type EditResponseActionsItem = EditResponseActionsItemAlwaysUseHTTPS | EditResponseActionsItemAutomaticHTTPSRewrites | EditResponseActionsItemBrowserCacheTTL | EditResponseActionsItemBrowserCheck | EditResponseActionsItemBypassCacheOnCookie | EditResponseActionsItemCacheByDeviceType | EditResponseActionsItemCacheDeceptionArmor | EditResponseActionsItemCacheKeyFields | EditResponseActionsItemCacheLevel | EditResponseActionsItemCacheOnCookie | EditResponseActionsItemCacheTTLByStatus | EditResponseActionsItemDisableApps | EditResponseActionsItemDisablePerformance | EditResponseActionsItemDisableSecurity | EditResponseActionsItemDisableZaraz | EditResponseActionsItemEdgeCacheTTL | EditResponseActionsItemEmailObfuscation | EditResponseActionsItemExplicitCacheControl | EditResponseActionsItemForwardingURL | EditResponseActionsItemHostHeaderOverride | EditResponseActionsItemIPGeolocation | EditResponseActionsItemMirage | EditResponseActionsItemOpportunisticEncryption | EditResponseActionsItemOriginErrorPagePassThru | EditResponseActionsItemPolish | EditResponseActionsItemResolveOverride | EditResponseActionsItemRespectStrongEtag | EditResponseActionsItemResponseBuffering | EditResponseActionsItemRocketLoader | EditResponseActionsItemSecurityLevel | EditResponseActionsItemSortQueryStringForCache | EditResponseActionsItemSSL | EditResponseActionsItemTrueClientIPHeader | EditResponseActionsItemWAF;
export declare const EditResponseActionsItem: any;
export type EditResponseActionsList = Array<EditResponseActionsItem>;
export declare const EditResponseActionsList: S.Schema<EditResponseActionsList>;
export type EditResponseStatus = "active" | "disabled";
export declare const EditResponseStatus: any;
export type EditResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const EditResponseTargetsItemConstraintOperator: any;
export interface EditResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: EditResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const EditResponseTargetsItemConstraint: S.Schema<EditResponseTargetsItemConstraint>;
export type EditResponseTargetsItemTarget = "url";
export declare const EditResponseTargetsItemTarget: any;
export interface EditResponseTargetsItem {
    /** String constraint. */
    constraint?: EditResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: EditResponseTargetsItemTarget | null;
}
export declare const EditResponseTargetsItem: S.Schema<EditResponseTargetsItem>;
export type EditResponseTargetsList = Array<EditResponseTargetsItem>;
export declare const EditResponseTargetsList: S.Schema<EditResponseTargetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchPageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions: EditResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority: number;
    /** The status of the Page Rule. */
    status: EditResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: EditResponseTargetsList;
}
export declare const PatchPageRuleResponse: S.Schema<PatchPageRuleResponse>;
export type UpdateRequestActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const UpdateRequestActionsItemAlwaysUseHTTPSId: any;
export interface UpdateRequestActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: UpdateRequestActionsItemAlwaysUseHTTPSId | (string & {});
}
export declare const UpdateRequestActionsItemAlwaysUseHTTPS: S.Schema<UpdateRequestActionsItemAlwaysUseHTTPS>;
export type UpdateRequestActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const UpdateRequestActionsItemAutomaticHTTPSRewritesId: any;
export type UpdateRequestActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const UpdateRequestActionsItemAutomaticHTTPSRewritesValue: any;
export interface UpdateRequestActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: UpdateRequestActionsItemAutomaticHTTPSRewritesId | (string & {});
    /** The status of Automatic HTTPS Rewrites. */
    value?: UpdateRequestActionsItemAutomaticHTTPSRewritesValue | (string & {});
}
export declare const UpdateRequestActionsItemAutomaticHTTPSRewrites: S.Schema<UpdateRequestActionsItemAutomaticHTTPSRewrites>;
export type UpdateRequestActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const UpdateRequestActionsItemBrowserCacheTTLId: any;
export interface UpdateRequestActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: UpdateRequestActionsItemBrowserCacheTTLId | (string & {});
    /** The number of seconds to cache resources for. */
    value?: number;
}
export declare const UpdateRequestActionsItemBrowserCacheTTL: S.Schema<UpdateRequestActionsItemBrowserCacheTTL>;
export type UpdateRequestActionsItemBrowserCheckId = "browser_check";
export declare const UpdateRequestActionsItemBrowserCheckId: any;
export type UpdateRequestActionsItemBrowserCheckValue = "on" | "off";
export declare const UpdateRequestActionsItemBrowserCheckValue: any;
export interface UpdateRequestActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: UpdateRequestActionsItemBrowserCheckId | (string & {});
    /** The status of Browser Integrity Check. */
    value?: UpdateRequestActionsItemBrowserCheckValue | (string & {});
}
export declare const UpdateRequestActionsItemBrowserCheck: S.Schema<UpdateRequestActionsItemBrowserCheck>;
export type UpdateRequestActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const UpdateRequestActionsItemBypassCacheOnCookieId: any;
export interface UpdateRequestActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: UpdateRequestActionsItemBypassCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the */
    value?: string;
}
export declare const UpdateRequestActionsItemBypassCacheOnCookie: S.Schema<UpdateRequestActionsItemBypassCacheOnCookie>;
export type UpdateRequestActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const UpdateRequestActionsItemCacheByDeviceTypeId: any;
export type UpdateRequestActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const UpdateRequestActionsItemCacheByDeviceTypeValue: any;
export interface UpdateRequestActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: UpdateRequestActionsItemCacheByDeviceTypeId | (string & {});
    /** The status of Cache By Device Type. */
    value?: UpdateRequestActionsItemCacheByDeviceTypeValue | (string & {});
}
export declare const UpdateRequestActionsItemCacheByDeviceType: S.Schema<UpdateRequestActionsItemCacheByDeviceType>;
export type UpdateRequestActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const UpdateRequestActionsItemCacheDeceptionArmorId: any;
export type UpdateRequestActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const UpdateRequestActionsItemCacheDeceptionArmorValue: any;
export interface UpdateRequestActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: UpdateRequestActionsItemCacheDeceptionArmorId | (string & {});
    /** The status of Cache Deception Armor. */
    value?: UpdateRequestActionsItemCacheDeceptionArmorValue | (string & {});
}
export declare const UpdateRequestActionsItemCacheDeceptionArmor: S.Schema<UpdateRequestActionsItemCacheDeceptionArmor>;
export type UpdateRequestActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const UpdateRequestActionsItemCacheKeyFieldsId: any;
export type UpdateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type UpdateRequestActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface UpdateRequestActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: UpdateRequestActionsItemCacheKeyFieldsValueCookieCheckPresenceList;
    /** A list of cookies to include. */
    include?: UpdateRequestActionsItemCacheKeyFieldsValueCookieIncludeList;
}
export declare const UpdateRequestActionsItemCacheKeyFieldsValueCookie: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueCookie>;
export type UpdateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type UpdateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type UpdateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface UpdateRequestActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: UpdateRequestActionsItemCacheKeyFieldsValueHeaderCheckPresenceList;
    /** A list of headers to ignore. */
    exclude?: UpdateRequestActionsItemCacheKeyFieldsValueHeaderExcludeList;
    /** A list of headers to include. */
    include?: UpdateRequestActionsItemCacheKeyFieldsValueHeaderIncludeList;
}
export declare const UpdateRequestActionsItemCacheKeyFieldsValueHeader: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueHeader>;
export type UpdateRequestActionsItemCacheKeyFieldsValueHost = CreateRequestActionsItemCacheKeyFieldsValueHost;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueHost: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueHost>;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExclude = UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | (string & {}) | UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type UpdateRequestActionsItemCacheKeyFieldsValueQueryStringInclude = UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | (string & {}) | UpdateRequestActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface UpdateRequestActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: UpdateRequestActionsItemCacheKeyFieldsValueQueryStringExclude;
    /** Include all query string parameters. */
    include?: UpdateRequestActionsItemCacheKeyFieldsValueQueryStringInclude;
}
export declare const UpdateRequestActionsItemCacheKeyFieldsValueQueryString: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValueQueryString>;
export type UpdateRequestActionsItemCacheKeyFieldsValueUser = CreateRequestActionsItemCacheKeyFieldsValueUser;
export declare const UpdateRequestActionsItemCacheKeyFieldsValueUser: S.Schema<CreateRequestActionsItemCacheKeyFieldsValueUser>;
export interface UpdateRequestActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: UpdateRequestActionsItemCacheKeyFieldsValueCookie;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: UpdateRequestActionsItemCacheKeyFieldsValueHeader;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateRequestActionsItemCacheKeyFieldsValueHost;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: UpdateRequestActionsItemCacheKeyFieldsValueQueryString;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateRequestActionsItemCacheKeyFieldsValueUser;
}
export declare const UpdateRequestActionsItemCacheKeyFieldsValue: S.Schema<UpdateRequestActionsItemCacheKeyFieldsValue>;
export interface UpdateRequestActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: UpdateRequestActionsItemCacheKeyFieldsId | (string & {});
    value?: UpdateRequestActionsItemCacheKeyFieldsValue;
}
export declare const UpdateRequestActionsItemCacheKeyFields: S.Schema<UpdateRequestActionsItemCacheKeyFields>;
export type UpdateRequestActionsItemCacheLevelId = "cache_level";
export declare const UpdateRequestActionsItemCacheLevelId: any;
export type UpdateRequestActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const UpdateRequestActionsItemCacheLevelValue: any;
export interface UpdateRequestActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: UpdateRequestActionsItemCacheLevelId | (string & {});
    /** * `bypass`: Cloudflare does not cache. */
    value?: UpdateRequestActionsItemCacheLevelValue | (string & {});
}
export declare const UpdateRequestActionsItemCacheLevel: S.Schema<UpdateRequestActionsItemCacheLevel>;
export type UpdateRequestActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const UpdateRequestActionsItemCacheOnCookieId: any;
export interface UpdateRequestActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: UpdateRequestActionsItemCacheOnCookieId | (string & {});
    /** The regular expression to use for matching cookie names in the */
    value?: string;
}
export declare const UpdateRequestActionsItemCacheOnCookie: S.Schema<UpdateRequestActionsItemCacheOnCookie>;
export type UpdateRequestActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const UpdateRequestActionsItemCacheTTLByStatusId: any;
export type UpdateRequestActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const UpdateRequestActionsItemCacheTTLByStatusValueCase0: any;
export type UpdateRequestActionsItemCacheTTLByStatusValue = number | UpdateRequestActionsItemCacheTTLByStatusValueCase0 | (string & {});
export declare const UpdateRequestActionsItemCacheTTLByStatusValue: any;
export interface UpdateRequestActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: UpdateRequestActionsItemCacheTTLByStatusId | (string & {});
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: UpdateRequestActionsItemCacheTTLByStatusValue;
}
export declare const UpdateRequestActionsItemCacheTTLByStatus: S.Schema<UpdateRequestActionsItemCacheTTLByStatus>;
export type UpdateRequestActionsItemDisableAppsId = "disable_apps";
export declare const UpdateRequestActionsItemDisableAppsId: any;
export interface UpdateRequestActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: UpdateRequestActionsItemDisableAppsId | (string & {});
}
export declare const UpdateRequestActionsItemDisableApps: S.Schema<UpdateRequestActionsItemDisableApps>;
export type UpdateRequestActionsItemDisablePerformanceId = "disable_performance";
export declare const UpdateRequestActionsItemDisablePerformanceId: any;
export interface UpdateRequestActionsItemDisablePerformance {
    /** Turn off */
    id?: UpdateRequestActionsItemDisablePerformanceId | (string & {});
}
export declare const UpdateRequestActionsItemDisablePerformance: S.Schema<UpdateRequestActionsItemDisablePerformance>;
export type UpdateRequestActionsItemDisableSecurityId = "disable_security";
export declare const UpdateRequestActionsItemDisableSecurityId: any;
export interface UpdateRequestActionsItemDisableSecurity {
    /** Turn off */
    id?: UpdateRequestActionsItemDisableSecurityId | (string & {});
}
export declare const UpdateRequestActionsItemDisableSecurity: S.Schema<UpdateRequestActionsItemDisableSecurity>;
export type UpdateRequestActionsItemDisableZarazId = "disable_zaraz";
export declare const UpdateRequestActionsItemDisableZarazId: any;
export interface UpdateRequestActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: UpdateRequestActionsItemDisableZarazId | (string & {});
}
export declare const UpdateRequestActionsItemDisableZaraz: S.Schema<UpdateRequestActionsItemDisableZaraz>;
export type UpdateRequestActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const UpdateRequestActionsItemEdgeCacheTTLId: any;
export interface UpdateRequestActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: UpdateRequestActionsItemEdgeCacheTTLId | (string & {});
    value?: number;
}
export declare const UpdateRequestActionsItemEdgeCacheTTL: S.Schema<UpdateRequestActionsItemEdgeCacheTTL>;
export type UpdateRequestActionsItemEmailObfuscationId = "email_obfuscation";
export declare const UpdateRequestActionsItemEmailObfuscationId: any;
export type UpdateRequestActionsItemEmailObfuscationValue = "on" | "off";
export declare const UpdateRequestActionsItemEmailObfuscationValue: any;
export interface UpdateRequestActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: UpdateRequestActionsItemEmailObfuscationId | (string & {});
    /** The status of Email Obfuscation. */
    value?: UpdateRequestActionsItemEmailObfuscationValue | (string & {});
}
export declare const UpdateRequestActionsItemEmailObfuscation: S.Schema<UpdateRequestActionsItemEmailObfuscation>;
export type UpdateRequestActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const UpdateRequestActionsItemExplicitCacheControlId: any;
export type UpdateRequestActionsItemExplicitCacheControlValue = "on" | "off";
export declare const UpdateRequestActionsItemExplicitCacheControlValue: any;
export interface UpdateRequestActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: UpdateRequestActionsItemExplicitCacheControlId | (string & {});
    /** The status of Origin Cache Control. */
    value?: UpdateRequestActionsItemExplicitCacheControlValue | (string & {});
}
export declare const UpdateRequestActionsItemExplicitCacheControl: S.Schema<UpdateRequestActionsItemExplicitCacheControl>;
export type UpdateRequestActionsItemForwardingURLId = "forwarding_url";
export declare const UpdateRequestActionsItemForwardingURLId: any;
export type UpdateRequestActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const UpdateRequestActionsItemForwardingURLValueStatusCode: any;
export interface UpdateRequestActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: UpdateRequestActionsItemForwardingURLValueStatusCode | (number & {});
    /** The URL to redirect the request to. */
    url?: string;
}
export declare const UpdateRequestActionsItemForwardingURLValue: S.Schema<UpdateRequestActionsItemForwardingURLValue>;
export interface UpdateRequestActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: UpdateRequestActionsItemForwardingURLId | (string & {});
    value?: UpdateRequestActionsItemForwardingURLValue;
}
export declare const UpdateRequestActionsItemForwardingURL: S.Schema<UpdateRequestActionsItemForwardingURL>;
export type UpdateRequestActionsItemHostHeaderOverrideId = "host_header_override";
export declare const UpdateRequestActionsItemHostHeaderOverrideId: any;
export interface UpdateRequestActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: UpdateRequestActionsItemHostHeaderOverrideId | (string & {});
    /** The hostname to use in the `Host` header */
    value?: string;
}
export declare const UpdateRequestActionsItemHostHeaderOverride: S.Schema<UpdateRequestActionsItemHostHeaderOverride>;
export type UpdateRequestActionsItemIPGeolocationId = "ip_geolocation";
export declare const UpdateRequestActionsItemIPGeolocationId: any;
export type UpdateRequestActionsItemIPGeolocationValue = "on" | "off";
export declare const UpdateRequestActionsItemIPGeolocationValue: any;
export interface UpdateRequestActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: UpdateRequestActionsItemIPGeolocationId | (string & {});
    /** The status of adding the IP Geolocation Header. */
    value?: UpdateRequestActionsItemIPGeolocationValue | (string & {});
}
export declare const UpdateRequestActionsItemIPGeolocation: S.Schema<UpdateRequestActionsItemIPGeolocation>;
export type UpdateRequestActionsItemMirageId = "mirage";
export declare const UpdateRequestActionsItemMirageId: any;
export type UpdateRequestActionsItemMirageValue = "on" | "off";
export declare const UpdateRequestActionsItemMirageValue: any;
export interface UpdateRequestActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: UpdateRequestActionsItemMirageId | (string & {});
    /** The status of Mirage. */
    value?: UpdateRequestActionsItemMirageValue | (string & {});
}
export declare const UpdateRequestActionsItemMirage: S.Schema<UpdateRequestActionsItemMirage>;
export type UpdateRequestActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const UpdateRequestActionsItemOpportunisticEncryptionId: any;
export type UpdateRequestActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const UpdateRequestActionsItemOpportunisticEncryptionValue: any;
export interface UpdateRequestActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: UpdateRequestActionsItemOpportunisticEncryptionId | (string & {});
    /** The status of Opportunistic Encryption. */
    value?: UpdateRequestActionsItemOpportunisticEncryptionValue | (string & {});
}
export declare const UpdateRequestActionsItemOpportunisticEncryption: S.Schema<UpdateRequestActionsItemOpportunisticEncryption>;
export type UpdateRequestActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const UpdateRequestActionsItemOriginErrorPagePassThruId: any;
export type UpdateRequestActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const UpdateRequestActionsItemOriginErrorPagePassThruValue: any;
export interface UpdateRequestActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: UpdateRequestActionsItemOriginErrorPagePassThruId | (string & {});
    /** The status of Origin Error Page Passthru. */
    value?: UpdateRequestActionsItemOriginErrorPagePassThruValue | (string & {});
}
export declare const UpdateRequestActionsItemOriginErrorPagePassThru: S.Schema<UpdateRequestActionsItemOriginErrorPagePassThru>;
export type UpdateRequestActionsItemPolishId = "polish";
export declare const UpdateRequestActionsItemPolishId: any;
export type UpdateRequestActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const UpdateRequestActionsItemPolishValue: any;
export interface UpdateRequestActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: UpdateRequestActionsItemPolishId | (string & {});
    /** The level of Polish you want applied to your origin. */
    value?: UpdateRequestActionsItemPolishValue | (string & {});
}
export declare const UpdateRequestActionsItemPolish: S.Schema<UpdateRequestActionsItemPolish>;
export type UpdateRequestActionsItemResolveOverrideId = "resolve_override";
export declare const UpdateRequestActionsItemResolveOverrideId: any;
export interface UpdateRequestActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: UpdateRequestActionsItemResolveOverrideId | (string & {});
    /** The origin address you want to override with. */
    value?: string;
}
export declare const UpdateRequestActionsItemResolveOverride: S.Schema<UpdateRequestActionsItemResolveOverride>;
export type UpdateRequestActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const UpdateRequestActionsItemRespectStrongEtagId: any;
export type UpdateRequestActionsItemRespectStrongEtagValue = "on" | "off";
export declare const UpdateRequestActionsItemRespectStrongEtagValue: any;
export interface UpdateRequestActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: UpdateRequestActionsItemRespectStrongEtagId | (string & {});
    /** The status of Respect Strong ETags */
    value?: UpdateRequestActionsItemRespectStrongEtagValue | (string & {});
}
export declare const UpdateRequestActionsItemRespectStrongEtag: S.Schema<UpdateRequestActionsItemRespectStrongEtag>;
export type UpdateRequestActionsItemResponseBufferingId = "response_buffering";
export declare const UpdateRequestActionsItemResponseBufferingId: any;
export type UpdateRequestActionsItemResponseBufferingValue = "on" | "off";
export declare const UpdateRequestActionsItemResponseBufferingValue: any;
export interface UpdateRequestActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: UpdateRequestActionsItemResponseBufferingId | (string & {});
    /** The status of Response Buffering */
    value?: UpdateRequestActionsItemResponseBufferingValue | (string & {});
}
export declare const UpdateRequestActionsItemResponseBuffering: S.Schema<UpdateRequestActionsItemResponseBuffering>;
export type UpdateRequestActionsItemRocketLoaderId = "rocket_loader";
export declare const UpdateRequestActionsItemRocketLoaderId: any;
export type UpdateRequestActionsItemRocketLoaderValue = "on" | "off";
export declare const UpdateRequestActionsItemRocketLoaderValue: any;
export interface UpdateRequestActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: UpdateRequestActionsItemRocketLoaderId | (string & {});
    /** The status of Rocket Loader */
    value?: UpdateRequestActionsItemRocketLoaderValue | (string & {});
}
export declare const UpdateRequestActionsItemRocketLoader: S.Schema<UpdateRequestActionsItemRocketLoader>;
export type UpdateRequestActionsItemSecurityLevelId = "security_level";
export declare const UpdateRequestActionsItemSecurityLevelId: any;
export type UpdateRequestActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const UpdateRequestActionsItemSecurityLevelValue: any;
export interface UpdateRequestActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: UpdateRequestActionsItemSecurityLevelId | (string & {});
    value?: UpdateRequestActionsItemSecurityLevelValue | (string & {});
}
export declare const UpdateRequestActionsItemSecurityLevel: S.Schema<UpdateRequestActionsItemSecurityLevel>;
export type UpdateRequestActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const UpdateRequestActionsItemSortQueryStringForCacheId: any;
export type UpdateRequestActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const UpdateRequestActionsItemSortQueryStringForCacheValue: any;
export interface UpdateRequestActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: UpdateRequestActionsItemSortQueryStringForCacheId | (string & {});
    /** The status of Query String Sort */
    value?: UpdateRequestActionsItemSortQueryStringForCacheValue | (string & {});
}
export declare const UpdateRequestActionsItemSortQueryStringForCache: S.Schema<UpdateRequestActionsItemSortQueryStringForCache>;
export type UpdateRequestActionsItemSSLId = "ssl";
export declare const UpdateRequestActionsItemSSLId: any;
export type UpdateRequestActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const UpdateRequestActionsItemSSLValue: any;
export interface UpdateRequestActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: UpdateRequestActionsItemSSLId | (string & {});
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: UpdateRequestActionsItemSSLValue | (string & {});
}
export declare const UpdateRequestActionsItemSSL: S.Schema<UpdateRequestActionsItemSSL>;
export type UpdateRequestActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const UpdateRequestActionsItemTrueClientIPHeaderId: any;
export type UpdateRequestActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const UpdateRequestActionsItemTrueClientIPHeaderValue: any;
export interface UpdateRequestActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: UpdateRequestActionsItemTrueClientIPHeaderId | (string & {});
    /** The status of True Client IP Header. */
    value?: UpdateRequestActionsItemTrueClientIPHeaderValue | (string & {});
}
export declare const UpdateRequestActionsItemTrueClientIPHeader: S.Schema<UpdateRequestActionsItemTrueClientIPHeader>;
export type UpdateRequestActionsItemWAFId = "waf";
export declare const UpdateRequestActionsItemWAFId: any;
export type UpdateRequestActionsItemWAFValue = "on" | "off";
export declare const UpdateRequestActionsItemWAFValue: any;
export interface UpdateRequestActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: UpdateRequestActionsItemWAFId | (string & {});
    /** The status of WAF managed rules (previous version). */
    value?: UpdateRequestActionsItemWAFValue | (string & {});
}
export declare const UpdateRequestActionsItemWAF: S.Schema<UpdateRequestActionsItemWAF>;
export type UpdateRequestActionsItem = UpdateRequestActionsItemAlwaysUseHTTPS | UpdateRequestActionsItemAutomaticHTTPSRewrites | UpdateRequestActionsItemBrowserCacheTTL | UpdateRequestActionsItemBrowserCheck | UpdateRequestActionsItemBypassCacheOnCookie | UpdateRequestActionsItemCacheByDeviceType | UpdateRequestActionsItemCacheDeceptionArmor | UpdateRequestActionsItemCacheKeyFields | UpdateRequestActionsItemCacheLevel | UpdateRequestActionsItemCacheOnCookie | UpdateRequestActionsItemCacheTTLByStatus | UpdateRequestActionsItemDisableApps | UpdateRequestActionsItemDisablePerformance | UpdateRequestActionsItemDisableSecurity | UpdateRequestActionsItemDisableZaraz | UpdateRequestActionsItemEdgeCacheTTL | UpdateRequestActionsItemEmailObfuscation | UpdateRequestActionsItemExplicitCacheControl | UpdateRequestActionsItemForwardingURL | UpdateRequestActionsItemHostHeaderOverride | UpdateRequestActionsItemIPGeolocation | UpdateRequestActionsItemMirage | UpdateRequestActionsItemOpportunisticEncryption | UpdateRequestActionsItemOriginErrorPagePassThru | UpdateRequestActionsItemPolish | UpdateRequestActionsItemResolveOverride | UpdateRequestActionsItemRespectStrongEtag | UpdateRequestActionsItemResponseBuffering | UpdateRequestActionsItemRocketLoader | UpdateRequestActionsItemSecurityLevel | UpdateRequestActionsItemSortQueryStringForCache | UpdateRequestActionsItemSSL | UpdateRequestActionsItemTrueClientIPHeader | UpdateRequestActionsItemWAF;
export declare const UpdateRequestActionsItem: any;
export type UpdateRequestActionsList = Array<UpdateRequestActionsItem>;
export declare const UpdateRequestActionsList: S.Schema<UpdateRequestActionsList>;
export type UpdateRequestTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const UpdateRequestTargetsItemConstraintOperator: any;
export interface UpdateRequestTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: UpdateRequestTargetsItemConstraintOperator | (string & {});
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const UpdateRequestTargetsItemConstraint: S.Schema<UpdateRequestTargetsItemConstraint>;
export type UpdateRequestTargetsItemTarget = "url";
export declare const UpdateRequestTargetsItemTarget: any;
export interface UpdateRequestTargetsItem {
    /** String constraint. */
    constraint?: UpdateRequestTargetsItemConstraint;
    /** A target based on the URL of the request. */
    target?: UpdateRequestTargetsItemTarget | (string & {});
}
export declare const UpdateRequestTargetsItem: S.Schema<UpdateRequestTargetsItem>;
export type UpdateRequestTargetsList = Array<UpdateRequestTargetsItem>;
export declare const UpdateRequestTargetsList: S.Schema<UpdateRequestTargetsList>;
export type UpdateRequestStatus = "active" | "disabled";
export declare const UpdateRequestStatus: any;
export interface UpdatePageRuleRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    pageruleId: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions: UpdateRequestActionsList;
    /** The rule targets to evaluate on each request. */
    targets: UpdateRequestTargetsList;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority?: number;
    /** The status of the Page Rule. */
    status?: UpdateRequestStatus | (string & {});
}
export declare const UpdatePageRuleRequest: S.Schema<UpdatePageRuleRequest>;
export type UpdateResponseActionsItemAlwaysUseHTTPSId = "always_use_https";
export declare const UpdateResponseActionsItemAlwaysUseHTTPSId: any;
export interface UpdateResponseActionsItemAlwaysUseHTTPS {
    /** If enabled, any `http://`` URL is converted to`https://` through a */
    id?: UpdateResponseActionsItemAlwaysUseHTTPSId | null;
}
export declare const UpdateResponseActionsItemAlwaysUseHTTPS: S.Schema<UpdateResponseActionsItemAlwaysUseHTTPS>;
export type UpdateResponseActionsItemAutomaticHTTPSRewritesId = "automatic_https_rewrites";
export declare const UpdateResponseActionsItemAutomaticHTTPSRewritesId: any;
export type UpdateResponseActionsItemAutomaticHTTPSRewritesValue = "on" | "off";
export declare const UpdateResponseActionsItemAutomaticHTTPSRewritesValue: any;
export interface UpdateResponseActionsItemAutomaticHTTPSRewrites {
    /** Turn on or off Automatic HTTPS Rewrites. */
    id?: UpdateResponseActionsItemAutomaticHTTPSRewritesId | null;
    /** The status of Automatic HTTPS Rewrites. */
    value?: UpdateResponseActionsItemAutomaticHTTPSRewritesValue | null;
}
export declare const UpdateResponseActionsItemAutomaticHTTPSRewrites: S.Schema<UpdateResponseActionsItemAutomaticHTTPSRewrites>;
export type UpdateResponseActionsItemBrowserCacheTTLId = "browser_cache_ttl";
export declare const UpdateResponseActionsItemBrowserCacheTTLId: any;
export interface UpdateResponseActionsItemBrowserCacheTTL {
    /** Control how long resources cached by client browsers remain valid. */
    id?: UpdateResponseActionsItemBrowserCacheTTLId | null;
    /** The number of seconds to cache resources for. */
    value?: number | null;
}
export declare const UpdateResponseActionsItemBrowserCacheTTL: S.Schema<UpdateResponseActionsItemBrowserCacheTTL>;
export type UpdateResponseActionsItemBrowserCheckId = "browser_check";
export declare const UpdateResponseActionsItemBrowserCheckId: any;
export type UpdateResponseActionsItemBrowserCheckValue = "on" | "off";
export declare const UpdateResponseActionsItemBrowserCheckValue: any;
export interface UpdateResponseActionsItemBrowserCheck {
    /** Inspect the visitor's browser for headers commonly associated with */
    id?: UpdateResponseActionsItemBrowserCheckId | null;
    /** The status of Browser Integrity Check. */
    value?: UpdateResponseActionsItemBrowserCheckValue | null;
}
export declare const UpdateResponseActionsItemBrowserCheck: S.Schema<UpdateResponseActionsItemBrowserCheck>;
export type UpdateResponseActionsItemBypassCacheOnCookieId = "bypass_cache_on_cookie";
export declare const UpdateResponseActionsItemBypassCacheOnCookieId: any;
export interface UpdateResponseActionsItemBypassCacheOnCookie {
    /** Bypass cache and fetch resources from the origin server if a regular */
    id?: UpdateResponseActionsItemBypassCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const UpdateResponseActionsItemBypassCacheOnCookie: S.Schema<UpdateResponseActionsItemBypassCacheOnCookie>;
export type UpdateResponseActionsItemCacheByDeviceTypeId = "cache_by_device_type";
export declare const UpdateResponseActionsItemCacheByDeviceTypeId: any;
export type UpdateResponseActionsItemCacheByDeviceTypeValue = "on" | "off";
export declare const UpdateResponseActionsItemCacheByDeviceTypeValue: any;
export interface UpdateResponseActionsItemCacheByDeviceType {
    /** Separate cached content based on the visitor's device type. */
    id?: UpdateResponseActionsItemCacheByDeviceTypeId | null;
    /** The status of Cache By Device Type. */
    value?: UpdateResponseActionsItemCacheByDeviceTypeValue | null;
}
export declare const UpdateResponseActionsItemCacheByDeviceType: S.Schema<UpdateResponseActionsItemCacheByDeviceType>;
export type UpdateResponseActionsItemCacheDeceptionArmorId = "cache_deception_armor";
export declare const UpdateResponseActionsItemCacheDeceptionArmorId: any;
export type UpdateResponseActionsItemCacheDeceptionArmorValue = "on" | "off";
export declare const UpdateResponseActionsItemCacheDeceptionArmorValue: any;
export interface UpdateResponseActionsItemCacheDeceptionArmor {
    /** Protect from web cache deception attacks while still allowing static */
    id?: UpdateResponseActionsItemCacheDeceptionArmorId | null;
    /** The status of Cache Deception Armor. */
    value?: UpdateResponseActionsItemCacheDeceptionArmorValue | null;
}
export declare const UpdateResponseActionsItemCacheDeceptionArmor: S.Schema<UpdateResponseActionsItemCacheDeceptionArmor>;
export type UpdateResponseActionsItemCacheKeyFieldsId = "cache_key_fields";
export declare const UpdateResponseActionsItemCacheKeyFieldsId: any;
export type UpdateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList = Array<string>;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList>;
export type UpdateResponseActionsItemCacheKeyFieldsValueCookieIncludeList = Array<string>;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueCookieIncludeList: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueCookieIncludeList>;
export interface UpdateResponseActionsItemCacheKeyFieldsValueCookie {
    /** A list of cookies to check for the presence of, without */
    checkPresence?: UpdateResponseActionsItemCacheKeyFieldsValueCookieCheckPresenceList | null;
    /** A list of cookies to include. */
    include?: UpdateResponseActionsItemCacheKeyFieldsValueCookieIncludeList | null;
}
export declare const UpdateResponseActionsItemCacheKeyFieldsValueCookie: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueCookie>;
export type UpdateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList = Array<string>;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList>;
export type UpdateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList = Array<string>;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList>;
export type UpdateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList = Array<string>;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList>;
export interface UpdateResponseActionsItemCacheKeyFieldsValueHeader {
    /** A list of headers to check for the presence of, without */
    checkPresence?: UpdateResponseActionsItemCacheKeyFieldsValueHeaderCheckPresenceList | null;
    /** A list of headers to ignore. */
    exclude?: UpdateResponseActionsItemCacheKeyFieldsValueHeaderExcludeList | null;
    /** A list of headers to include. */
    include?: UpdateResponseActionsItemCacheKeyFieldsValueHeaderIncludeList | null;
}
export declare const UpdateResponseActionsItemCacheKeyFieldsValueHeader: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueHeader>;
export type UpdateResponseActionsItemCacheKeyFieldsValueHost = CreateResponseActionsItemCacheKeyFieldsValueHost;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueHost: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueHost>;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum = "*";
export declare const UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum: any;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List = Array<string>;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List>;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExclude = UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeEnum | UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExcludeCase1List;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExclude: any;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum = "*";
export declare const UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum: any;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List = Array<string>;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List>;
export type UpdateResponseActionsItemCacheKeyFieldsValueQueryStringInclude = UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeEnum | UpdateResponseActionsItemCacheKeyFieldsValueQueryStringIncludeCase1List;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueQueryStringInclude: any;
export interface UpdateResponseActionsItemCacheKeyFieldsValueQueryString {
    /** Ignore all query string parameters. */
    exclude?: UpdateResponseActionsItemCacheKeyFieldsValueQueryStringExclude | null;
    /** Include all query string parameters. */
    include?: UpdateResponseActionsItemCacheKeyFieldsValueQueryStringInclude | null;
}
export declare const UpdateResponseActionsItemCacheKeyFieldsValueQueryString: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValueQueryString>;
export type UpdateResponseActionsItemCacheKeyFieldsValueUser = CreateResponseActionsItemCacheKeyFieldsValueUser;
export declare const UpdateResponseActionsItemCacheKeyFieldsValueUser: S.Schema<CreateResponseActionsItemCacheKeyFieldsValueUser>;
export interface UpdateResponseActionsItemCacheKeyFieldsValue {
    /** Controls which cookies appear in the Cache Key. */
    cookie?: UpdateResponseActionsItemCacheKeyFieldsValueCookie | null;
    /** Controls which headers go into the Cache Key. Exactly one of */
    header?: UpdateResponseActionsItemCacheKeyFieldsValueHeader | null;
    /** Determines which host header to include in the Cache Key. */
    host?: CreateResponseActionsItemCacheKeyFieldsValueHost | null;
    /** Controls which URL query string parameters go into the Cache */
    queryString?: UpdateResponseActionsItemCacheKeyFieldsValueQueryString | null;
    /** Feature fields to add features about the end-user (client) into */
    user?: CreateResponseActionsItemCacheKeyFieldsValueUser | null;
}
export declare const UpdateResponseActionsItemCacheKeyFieldsValue: S.Schema<UpdateResponseActionsItemCacheKeyFieldsValue>;
export interface UpdateResponseActionsItemCacheKeyFields {
    /** Control specifically what variables to include when deciding which */
    id?: UpdateResponseActionsItemCacheKeyFieldsId | null;
    value?: UpdateResponseActionsItemCacheKeyFieldsValue | null;
}
export declare const UpdateResponseActionsItemCacheKeyFields: S.Schema<UpdateResponseActionsItemCacheKeyFields>;
export type UpdateResponseActionsItemCacheLevelId = "cache_level";
export declare const UpdateResponseActionsItemCacheLevelId: any;
export type UpdateResponseActionsItemCacheLevelValue = "bypass" | "basic" | "simplified" | "aggressive" | "cache_everything";
export declare const UpdateResponseActionsItemCacheLevelValue: any;
export interface UpdateResponseActionsItemCacheLevel {
    /** Apply custom caching based on the option selected. */
    id?: UpdateResponseActionsItemCacheLevelId | null;
    /** * `bypass`: Cloudflare does not cache. */
    value?: UpdateResponseActionsItemCacheLevelValue | null;
}
export declare const UpdateResponseActionsItemCacheLevel: S.Schema<UpdateResponseActionsItemCacheLevel>;
export type UpdateResponseActionsItemCacheOnCookieId = "cache_on_cookie";
export declare const UpdateResponseActionsItemCacheOnCookieId: any;
export interface UpdateResponseActionsItemCacheOnCookie {
    /** Apply the Cache Everything option (Cache Level setting) based on a */
    id?: UpdateResponseActionsItemCacheOnCookieId | null;
    /** The regular expression to use for matching cookie names in the */
    value?: string | null;
}
export declare const UpdateResponseActionsItemCacheOnCookie: S.Schema<UpdateResponseActionsItemCacheOnCookie>;
export type UpdateResponseActionsItemCacheTTLByStatusId = "cache_ttl_by_status";
export declare const UpdateResponseActionsItemCacheTTLByStatusId: any;
export type UpdateResponseActionsItemCacheTTLByStatusValueCase0 = "no-cache" | "no-store";
export declare const UpdateResponseActionsItemCacheTTLByStatusValueCase0: any;
export type UpdateResponseActionsItemCacheTTLByStatusValue = number | UpdateResponseActionsItemCacheTTLByStatusValueCase0;
export declare const UpdateResponseActionsItemCacheTTLByStatusValue: any;
export interface UpdateResponseActionsItemCacheTTLByStatus {
    /** Enterprise customers can set cache time-to-live (TTL) based on the */
    id?: UpdateResponseActionsItemCacheTTLByStatusId | null;
    /** A JSON object containing status codes and their corresponding TTLs. */
    value?: UpdateResponseActionsItemCacheTTLByStatusValue | null;
}
export declare const UpdateResponseActionsItemCacheTTLByStatus: S.Schema<UpdateResponseActionsItemCacheTTLByStatus>;
export type UpdateResponseActionsItemDisableAppsId = "disable_apps";
export declare const UpdateResponseActionsItemDisableAppsId: any;
export interface UpdateResponseActionsItemDisableApps {
    /** Turn off all active [Cloudflare Apps](https://developers.cloudflare.com/support/more-dashboard-apps/cloudflare-apps/) */
    id?: UpdateResponseActionsItemDisableAppsId | null;
}
export declare const UpdateResponseActionsItemDisableApps: S.Schema<UpdateResponseActionsItemDisableApps>;
export type UpdateResponseActionsItemDisablePerformanceId = "disable_performance";
export declare const UpdateResponseActionsItemDisablePerformanceId: any;
export interface UpdateResponseActionsItemDisablePerformance {
    /** Turn off */
    id?: UpdateResponseActionsItemDisablePerformanceId | null;
}
export declare const UpdateResponseActionsItemDisablePerformance: S.Schema<UpdateResponseActionsItemDisablePerformance>;
export type UpdateResponseActionsItemDisableSecurityId = "disable_security";
export declare const UpdateResponseActionsItemDisableSecurityId: any;
export interface UpdateResponseActionsItemDisableSecurity {
    /** Turn off */
    id?: UpdateResponseActionsItemDisableSecurityId | null;
}
export declare const UpdateResponseActionsItemDisableSecurity: S.Schema<UpdateResponseActionsItemDisableSecurity>;
export type UpdateResponseActionsItemDisableZarazId = "disable_zaraz";
export declare const UpdateResponseActionsItemDisableZarazId: any;
export interface UpdateResponseActionsItemDisableZaraz {
    /** Turn off [Zaraz](https://developers.cloudflare.com/zaraz/). */
    id?: UpdateResponseActionsItemDisableZarazId | null;
}
export declare const UpdateResponseActionsItemDisableZaraz: S.Schema<UpdateResponseActionsItemDisableZaraz>;
export type UpdateResponseActionsItemEdgeCacheTTLId = "edge_cache_ttl";
export declare const UpdateResponseActionsItemEdgeCacheTTLId: any;
export interface UpdateResponseActionsItemEdgeCacheTTL {
    /** Specify how long to cache a resource in the Cloudflare global */
    id?: UpdateResponseActionsItemEdgeCacheTTLId | null;
    value?: number | null;
}
export declare const UpdateResponseActionsItemEdgeCacheTTL: S.Schema<UpdateResponseActionsItemEdgeCacheTTL>;
export type UpdateResponseActionsItemEmailObfuscationId = "email_obfuscation";
export declare const UpdateResponseActionsItemEmailObfuscationId: any;
export type UpdateResponseActionsItemEmailObfuscationValue = "on" | "off";
export declare const UpdateResponseActionsItemEmailObfuscationValue: any;
export interface UpdateResponseActionsItemEmailObfuscation {
    /** Turn on or off **Email Obfuscation**. */
    id?: UpdateResponseActionsItemEmailObfuscationId | null;
    /** The status of Email Obfuscation. */
    value?: UpdateResponseActionsItemEmailObfuscationValue | null;
}
export declare const UpdateResponseActionsItemEmailObfuscation: S.Schema<UpdateResponseActionsItemEmailObfuscation>;
export type UpdateResponseActionsItemExplicitCacheControlId = "explicit_cache_control";
export declare const UpdateResponseActionsItemExplicitCacheControlId: any;
export type UpdateResponseActionsItemExplicitCacheControlValue = "on" | "off";
export declare const UpdateResponseActionsItemExplicitCacheControlValue: any;
export interface UpdateResponseActionsItemExplicitCacheControl {
    /** Origin Cache Control is enabled by default for Free, Pro, and */
    id?: UpdateResponseActionsItemExplicitCacheControlId | null;
    /** The status of Origin Cache Control. */
    value?: UpdateResponseActionsItemExplicitCacheControlValue | null;
}
export declare const UpdateResponseActionsItemExplicitCacheControl: S.Schema<UpdateResponseActionsItemExplicitCacheControl>;
export type UpdateResponseActionsItemForwardingURLId = "forwarding_url";
export declare const UpdateResponseActionsItemForwardingURLId: any;
export type UpdateResponseActionsItemForwardingURLValueStatusCode = 301 | 302;
export declare const UpdateResponseActionsItemForwardingURLValueStatusCode: any;
export interface UpdateResponseActionsItemForwardingURLValue {
    /** The status code to use for the URL redirect. 301 is a permanent */
    statusCode?: UpdateResponseActionsItemForwardingURLValueStatusCode | null;
    /** The URL to redirect the request to. */
    url?: string | null;
}
export declare const UpdateResponseActionsItemForwardingURLValue: S.Schema<UpdateResponseActionsItemForwardingURLValue>;
export interface UpdateResponseActionsItemForwardingURL {
    /** Redirects one URL to another using an `HTTP 301/302` redirect. Refer */
    id?: UpdateResponseActionsItemForwardingURLId | null;
    value?: UpdateResponseActionsItemForwardingURLValue | null;
}
export declare const UpdateResponseActionsItemForwardingURL: S.Schema<UpdateResponseActionsItemForwardingURL>;
export type UpdateResponseActionsItemHostHeaderOverrideId = "host_header_override";
export declare const UpdateResponseActionsItemHostHeaderOverrideId: any;
export interface UpdateResponseActionsItemHostHeaderOverride {
    /** Apply a specific host header. */
    id?: UpdateResponseActionsItemHostHeaderOverrideId | null;
    /** The hostname to use in the `Host` header */
    value?: string | null;
}
export declare const UpdateResponseActionsItemHostHeaderOverride: S.Schema<UpdateResponseActionsItemHostHeaderOverride>;
export type UpdateResponseActionsItemIPGeolocationId = "ip_geolocation";
export declare const UpdateResponseActionsItemIPGeolocationId: any;
export type UpdateResponseActionsItemIPGeolocationValue = "on" | "off";
export declare const UpdateResponseActionsItemIPGeolocationValue: any;
export interface UpdateResponseActionsItemIPGeolocation {
    /** Cloudflare adds a CF-IPCountry HTTP header containing the country code that corresponds to the visitor. */
    id?: UpdateResponseActionsItemIPGeolocationId | null;
    /** The status of adding the IP Geolocation Header. */
    value?: UpdateResponseActionsItemIPGeolocationValue | null;
}
export declare const UpdateResponseActionsItemIPGeolocation: S.Schema<UpdateResponseActionsItemIPGeolocation>;
export type UpdateResponseActionsItemMirageId = "mirage";
export declare const UpdateResponseActionsItemMirageId: any;
export type UpdateResponseActionsItemMirageValue = "on" | "off";
export declare const UpdateResponseActionsItemMirageValue: any;
export interface UpdateResponseActionsItemMirage {
    /** Cloudflare Mirage reduces bandwidth used by images in mobile browsers. */
    id?: UpdateResponseActionsItemMirageId | null;
    /** The status of Mirage. */
    value?: UpdateResponseActionsItemMirageValue | null;
}
export declare const UpdateResponseActionsItemMirage: S.Schema<UpdateResponseActionsItemMirage>;
export type UpdateResponseActionsItemOpportunisticEncryptionId = "opportunistic_encryption";
export declare const UpdateResponseActionsItemOpportunisticEncryptionId: any;
export type UpdateResponseActionsItemOpportunisticEncryptionValue = "on" | "off";
export declare const UpdateResponseActionsItemOpportunisticEncryptionValue: any;
export interface UpdateResponseActionsItemOpportunisticEncryption {
    /** Opportunistic Encryption allows browsers to access HTTP URIs over an encrypted TLS channel. */
    id?: UpdateResponseActionsItemOpportunisticEncryptionId | null;
    /** The status of Opportunistic Encryption. */
    value?: UpdateResponseActionsItemOpportunisticEncryptionValue | null;
}
export declare const UpdateResponseActionsItemOpportunisticEncryption: S.Schema<UpdateResponseActionsItemOpportunisticEncryption>;
export type UpdateResponseActionsItemOriginErrorPagePassThruId = "origin_error_page_pass_thru";
export declare const UpdateResponseActionsItemOriginErrorPagePassThruId: any;
export type UpdateResponseActionsItemOriginErrorPagePassThruValue = "on" | "off";
export declare const UpdateResponseActionsItemOriginErrorPagePassThruValue: any;
export interface UpdateResponseActionsItemOriginErrorPagePassThru {
    /** Turn on or off Cloudflare error pages generated from issues sent from the origin server. If enabled, this setting triggers error pages issued by the origin. */
    id?: UpdateResponseActionsItemOriginErrorPagePassThruId | null;
    /** The status of Origin Error Page Passthru. */
    value?: UpdateResponseActionsItemOriginErrorPagePassThruValue | null;
}
export declare const UpdateResponseActionsItemOriginErrorPagePassThru: S.Schema<UpdateResponseActionsItemOriginErrorPagePassThru>;
export type UpdateResponseActionsItemPolishId = "polish";
export declare const UpdateResponseActionsItemPolishId: any;
export type UpdateResponseActionsItemPolishValue = "off" | "lossless" | "lossy";
export declare const UpdateResponseActionsItemPolishValue: any;
export interface UpdateResponseActionsItemPolish {
    /** Apply options from the Polish feature of the Cloudflare Speed app. */
    id?: UpdateResponseActionsItemPolishId | null;
    /** The level of Polish you want applied to your origin. */
    value?: UpdateResponseActionsItemPolishValue | null;
}
export declare const UpdateResponseActionsItemPolish: S.Schema<UpdateResponseActionsItemPolish>;
export type UpdateResponseActionsItemResolveOverrideId = "resolve_override";
export declare const UpdateResponseActionsItemResolveOverrideId: any;
export interface UpdateResponseActionsItemResolveOverride {
    /** Change the origin address to the value specified in this setting. */
    id?: UpdateResponseActionsItemResolveOverrideId | null;
    /** The origin address you want to override with. */
    value?: string | null;
}
export declare const UpdateResponseActionsItemResolveOverride: S.Schema<UpdateResponseActionsItemResolveOverride>;
export type UpdateResponseActionsItemRespectStrongEtagId = "respect_strong_etag";
export declare const UpdateResponseActionsItemRespectStrongEtagId: any;
export type UpdateResponseActionsItemRespectStrongEtagValue = "on" | "off";
export declare const UpdateResponseActionsItemRespectStrongEtagValue: any;
export interface UpdateResponseActionsItemRespectStrongEtag {
    /** Turn on or off byte-for-byte equivalency checks between the */
    id?: UpdateResponseActionsItemRespectStrongEtagId | null;
    /** The status of Respect Strong ETags */
    value?: UpdateResponseActionsItemRespectStrongEtagValue | null;
}
export declare const UpdateResponseActionsItemRespectStrongEtag: S.Schema<UpdateResponseActionsItemRespectStrongEtag>;
export type UpdateResponseActionsItemResponseBufferingId = "response_buffering";
export declare const UpdateResponseActionsItemResponseBufferingId: any;
export type UpdateResponseActionsItemResponseBufferingValue = "on" | "off";
export declare const UpdateResponseActionsItemResponseBufferingValue: any;
export interface UpdateResponseActionsItemResponseBuffering {
    /** Turn on or off whether Cloudflare should wait for an entire file */
    id?: UpdateResponseActionsItemResponseBufferingId | null;
    /** The status of Response Buffering */
    value?: UpdateResponseActionsItemResponseBufferingValue | null;
}
export declare const UpdateResponseActionsItemResponseBuffering: S.Schema<UpdateResponseActionsItemResponseBuffering>;
export type UpdateResponseActionsItemRocketLoaderId = "rocket_loader";
export declare const UpdateResponseActionsItemRocketLoaderId: any;
export type UpdateResponseActionsItemRocketLoaderValue = "on" | "off";
export declare const UpdateResponseActionsItemRocketLoaderValue: any;
export interface UpdateResponseActionsItemRocketLoader {
    /** Turn on or off Rocket Loader in the Cloudflare Speed app. */
    id?: UpdateResponseActionsItemRocketLoaderId | null;
    /** The status of Rocket Loader */
    value?: UpdateResponseActionsItemRocketLoaderValue | null;
}
export declare const UpdateResponseActionsItemRocketLoader: S.Schema<UpdateResponseActionsItemRocketLoader>;
export type UpdateResponseActionsItemSecurityLevelId = "security_level";
export declare const UpdateResponseActionsItemSecurityLevelId: any;
export type UpdateResponseActionsItemSecurityLevelValue = "off" | "essentially_off" | "low" | "medium" | "high" | "under_attack";
export declare const UpdateResponseActionsItemSecurityLevelValue: any;
export interface UpdateResponseActionsItemSecurityLevel {
    /** Control options for the **Security Level** feature from the **Security** app. */
    id?: UpdateResponseActionsItemSecurityLevelId | null;
    value?: UpdateResponseActionsItemSecurityLevelValue | null;
}
export declare const UpdateResponseActionsItemSecurityLevel: S.Schema<UpdateResponseActionsItemSecurityLevel>;
export type UpdateResponseActionsItemSortQueryStringForCacheId = "sort_query_string_for_cache";
export declare const UpdateResponseActionsItemSortQueryStringForCacheId: any;
export type UpdateResponseActionsItemSortQueryStringForCacheValue = "on" | "off";
export declare const UpdateResponseActionsItemSortQueryStringForCacheValue: any;
export interface UpdateResponseActionsItemSortQueryStringForCache {
    /** Turn on or off the reordering of query strings. When query strings have the same structure, caching improves. */
    id?: UpdateResponseActionsItemSortQueryStringForCacheId | null;
    /** The status of Query String Sort */
    value?: UpdateResponseActionsItemSortQueryStringForCacheValue | null;
}
export declare const UpdateResponseActionsItemSortQueryStringForCache: S.Schema<UpdateResponseActionsItemSortQueryStringForCache>;
export type UpdateResponseActionsItemSSLId = "ssl";
export declare const UpdateResponseActionsItemSSLId: any;
export type UpdateResponseActionsItemSSLValue = "off" | "flexible" | "full" | "strict" | "origin_pull";
export declare const UpdateResponseActionsItemSSLValue: any;
export interface UpdateResponseActionsItemSSL {
    /** Control options for the SSL feature of the Edge Certificates tab in the Cloudflare SSL/TLS app. */
    id?: UpdateResponseActionsItemSSLId | null;
    /** The encryption mode that Cloudflare uses to connect to your origin server. */
    value?: UpdateResponseActionsItemSSLValue | null;
}
export declare const UpdateResponseActionsItemSSL: S.Schema<UpdateResponseActionsItemSSL>;
export type UpdateResponseActionsItemTrueClientIPHeaderId = "true_client_ip_header";
export declare const UpdateResponseActionsItemTrueClientIPHeaderId: any;
export type UpdateResponseActionsItemTrueClientIPHeaderValue = "on" | "off";
export declare const UpdateResponseActionsItemTrueClientIPHeaderValue: any;
export interface UpdateResponseActionsItemTrueClientIPHeader {
    /** Turn on or off the True-Client-IP Header feature of the Cloudflare Network app. */
    id?: UpdateResponseActionsItemTrueClientIPHeaderId | null;
    /** The status of True Client IP Header. */
    value?: UpdateResponseActionsItemTrueClientIPHeaderValue | null;
}
export declare const UpdateResponseActionsItemTrueClientIPHeader: S.Schema<UpdateResponseActionsItemTrueClientIPHeader>;
export type UpdateResponseActionsItemWAFId = "waf";
export declare const UpdateResponseActionsItemWAFId: any;
export type UpdateResponseActionsItemWAFValue = "on" | "off";
export declare const UpdateResponseActionsItemWAFValue: any;
export interface UpdateResponseActionsItemWAF {
    /** Turn on or off [WAF managed rules (previous version, deprecated)](https://developers.cloudflare.com/waf/reference/legacy/old-waf-managed-rules/). */
    id?: UpdateResponseActionsItemWAFId | null;
    /** The status of WAF managed rules (previous version). */
    value?: UpdateResponseActionsItemWAFValue | null;
}
export declare const UpdateResponseActionsItemWAF: S.Schema<UpdateResponseActionsItemWAF>;
export type UpdateResponseActionsItem = UpdateResponseActionsItemAlwaysUseHTTPS | UpdateResponseActionsItemAutomaticHTTPSRewrites | UpdateResponseActionsItemBrowserCacheTTL | UpdateResponseActionsItemBrowserCheck | UpdateResponseActionsItemBypassCacheOnCookie | UpdateResponseActionsItemCacheByDeviceType | UpdateResponseActionsItemCacheDeceptionArmor | UpdateResponseActionsItemCacheKeyFields | UpdateResponseActionsItemCacheLevel | UpdateResponseActionsItemCacheOnCookie | UpdateResponseActionsItemCacheTTLByStatus | UpdateResponseActionsItemDisableApps | UpdateResponseActionsItemDisablePerformance | UpdateResponseActionsItemDisableSecurity | UpdateResponseActionsItemDisableZaraz | UpdateResponseActionsItemEdgeCacheTTL | UpdateResponseActionsItemEmailObfuscation | UpdateResponseActionsItemExplicitCacheControl | UpdateResponseActionsItemForwardingURL | UpdateResponseActionsItemHostHeaderOverride | UpdateResponseActionsItemIPGeolocation | UpdateResponseActionsItemMirage | UpdateResponseActionsItemOpportunisticEncryption | UpdateResponseActionsItemOriginErrorPagePassThru | UpdateResponseActionsItemPolish | UpdateResponseActionsItemResolveOverride | UpdateResponseActionsItemRespectStrongEtag | UpdateResponseActionsItemResponseBuffering | UpdateResponseActionsItemRocketLoader | UpdateResponseActionsItemSecurityLevel | UpdateResponseActionsItemSortQueryStringForCache | UpdateResponseActionsItemSSL | UpdateResponseActionsItemTrueClientIPHeader | UpdateResponseActionsItemWAF;
export declare const UpdateResponseActionsItem: any;
export type UpdateResponseActionsList = Array<UpdateResponseActionsItem>;
export declare const UpdateResponseActionsList: S.Schema<UpdateResponseActionsList>;
export type UpdateResponseStatus = "active" | "disabled";
export declare const UpdateResponseStatus: any;
export type UpdateResponseTargetsItemConstraintOperator = "matches" | "contains" | "equals" | "not_equal" | "not_contain";
export declare const UpdateResponseTargetsItemConstraintOperator: any;
export interface UpdateResponseTargetsItemConstraint {
    /** The matches operator can use asterisks and pipes as wildcard and 'or' operators. */
    operator: UpdateResponseTargetsItemConstraintOperator;
    /** The URL pattern to match against the current request. The pattern may contain up to four asterisks ('*') as placeholders. */
    value: string;
}
export declare const UpdateResponseTargetsItemConstraint: S.Schema<UpdateResponseTargetsItemConstraint>;
export type UpdateResponseTargetsItemTarget = "url";
export declare const UpdateResponseTargetsItemTarget: any;
export interface UpdateResponseTargetsItem {
    /** String constraint. */
    constraint?: UpdateResponseTargetsItemConstraint | null;
    /** A target based on the URL of the request. */
    target?: UpdateResponseTargetsItemTarget | null;
}
export declare const UpdateResponseTargetsItem: S.Schema<UpdateResponseTargetsItem>;
export type UpdateResponseTargetsList = Array<UpdateResponseTargetsItem>;
export declare const UpdateResponseTargetsList: S.Schema<UpdateResponseTargetsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePageRuleResponse {
    /** Identifier. */
    id: string;
    /** The set of actions to perform if the targets of this rule match the */
    actions: UpdateResponseActionsList;
    /** The timestamp of when the Page Rule was created. */
    createdOn: string;
    /** The timestamp of when the Page Rule was last modified. */
    modifiedOn: string;
    /** The priority of the rule, used to define which Page Rule is processed */
    priority: number;
    /** The status of the Page Rule. */
    status: UpdateResponseStatus;
    /** The rule targets to evaluate on each request. */
    targets: UpdateResponseTargetsList;
}
export declare const UpdatePageRuleResponse: S.Schema<UpdatePageRuleResponse>;
export type CreatePageRuleError = Forbidden | CloudflareOpError;
/** Creates a new Page Rule. */
export declare const createPageRule: API.OperationMethod<CreatePageRuleRequest, CreatePageRuleResponse, CreatePageRuleError, CloudflareOpContext>;
export type DeletePageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing Page Rule. */
export declare const deletePageRule: API.OperationMethod<DeletePageRuleRequest, DeletePageRuleResponse, DeletePageRuleError, CloudflareOpContext>;
export type GetPageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a Page Rule. */
export declare const getPageRule: API.OperationMethod<GetPageRuleRequest, GetPageRuleResponse, GetPageRuleError, CloudflareOpContext>;
export type ListPageRulesError = Forbidden | InvalidZoneIdentifier | CloudflareOpError;
/** Fetches Page Rules in a zone. */
export declare const listPageRules: API.OperationMethod<ListPageRulesRequest, ListPageRulesResponse, ListPageRulesError, CloudflareOpContext>;
export type PatchPageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Updates one or more fields of an existing Page Rule. */
export declare const patchPageRule: API.OperationMethod<PatchPageRuleRequest, PatchPageRuleResponse, PatchPageRuleError, CloudflareOpContext>;
export type UpdatePageRuleError = PageRuleNotFound | Forbidden | CloudflareOpError;
/** Replaces the configuration of an existing Page Rule. The configuration of the updated Page Rule will exactly match the data passed in the API request. */
export declare const updatePageRule: API.OperationMethod<UpdatePageRuleRequest, UpdatePageRuleResponse, UpdatePageRuleError, CloudflareOpContext>;
//# sourceMappingURL=page_rules.d.ts.map