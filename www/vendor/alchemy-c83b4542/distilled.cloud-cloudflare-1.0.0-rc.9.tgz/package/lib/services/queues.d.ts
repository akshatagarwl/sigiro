import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ConsumerAlreadyExists_base: S.Class<ConsumerAlreadyExists, S.TaggedStruct<"ConsumerAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConsumerAlreadyExists extends /*@__PURE__*/ ConsumerAlreadyExists_base {
}
declare const ConsumerNotFound_base: S.Class<ConsumerNotFound, S.TaggedStruct<"ConsumerNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ConsumerNotFound extends /*@__PURE__*/ ConsumerNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const InvalidMessageBody_base: S.Class<InvalidMessageBody, S.TaggedStruct<"InvalidMessageBody", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidMessageBody extends /*@__PURE__*/ InvalidMessageBody_base {
}
declare const InvalidQueueId_base: S.Class<InvalidQueueId, S.TaggedStruct<"InvalidQueueId", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidQueueId extends /*@__PURE__*/ InvalidQueueId_base {
}
declare const InvalidQueueName_base: S.Class<InvalidQueueName, S.TaggedStruct<"InvalidQueueName", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidQueueName extends /*@__PURE__*/ InvalidQueueName_base {
}
declare const InvalidRequestBody_base: S.Class<InvalidRequestBody, S.TaggedStruct<"InvalidRequestBody", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestBody extends /*@__PURE__*/ InvalidRequestBody_base {
}
declare const InvalidRoute_base: S.Class<InvalidRoute, S.TaggedStruct<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const QueueAlreadyExists_base: S.Class<QueueAlreadyExists, S.TaggedStruct<"QueueAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueAlreadyExists extends /*@__PURE__*/ QueueAlreadyExists_base {
}
declare const QueueHandlerMissing_base: S.Class<QueueHandlerMissing, S.TaggedStruct<"QueueHandlerMissing", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueHandlerMissing extends /*@__PURE__*/ QueueHandlerMissing_base {
}
declare const QueueInUseByEventNotification_base: S.Class<QueueInUseByEventNotification, S.TaggedStruct<"QueueInUseByEventNotification", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueInUseByEventNotification extends /*@__PURE__*/ QueueInUseByEventNotification_base {
}
declare const QueueInUseByWorkerBinding_base: S.Class<QueueInUseByWorkerBinding, S.TaggedStruct<"QueueInUseByWorkerBinding", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueInUseByWorkerBinding extends /*@__PURE__*/ QueueInUseByWorkerBinding_base {
}
declare const QueueNotFound_base: S.Class<QueueNotFound, S.TaggedStruct<"QueueNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class QueueNotFound extends /*@__PURE__*/ QueueNotFound_base {
}
declare const SubscriptionAlreadyExists_base: S.Class<SubscriptionAlreadyExists, S.TaggedStruct<"SubscriptionAlreadyExists", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SubscriptionAlreadyExists extends /*@__PURE__*/ SubscriptionAlreadyExists_base {
}
declare const SubscriptionNotFound_base: S.Class<SubscriptionNotFound, S.TaggedStruct<"SubscriptionNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class SubscriptionNotFound extends /*@__PURE__*/ SubscriptionNotFound_base {
}
declare const UnrecognizedEventType_base: S.Class<UnrecognizedEventType, S.TaggedStruct<"UnrecognizedEventType", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UnrecognizedEventType extends /*@__PURE__*/ UnrecognizedEventType_base {
}
declare const WorkerNotFound_base: S.Class<WorkerNotFound, S.TaggedStruct<"WorkerNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class WorkerNotFound extends /*@__PURE__*/ WorkerNotFound_base {
}
export interface MessagesAckRequestAcksItem {
    /** An ID that represents an "in-flight" message that has been pulled from a Queue. You must hold on to this ID and use it to acknowledge this message. */
    leaseId?: string;
}
export declare const MessagesAckRequestAcksItem: S.Schema<MessagesAckRequestAcksItem>;
export type MessagesAckRequestAcksList = Array<MessagesAckRequestAcksItem>;
export declare const MessagesAckRequestAcksList: S.Schema<MessagesAckRequestAcksList>;
export interface MessagesAckRequestRetriesItem {
    /** The number of seconds to delay before making the message available for another attempt. */
    delaySeconds?: number;
    /** An ID that represents an "in-flight" message that has been pulled from a Queue. You must hold on to this ID and use it to acknowledge this message. */
    leaseId?: string;
}
export declare const MessagesAckRequestRetriesItem: S.Schema<MessagesAckRequestRetriesItem>;
export type MessagesAckRequestRetriesList = Array<MessagesAckRequestRetriesItem>;
export declare const MessagesAckRequestRetriesList: S.Schema<MessagesAckRequestRetriesList>;
export interface AckMessageRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    acks?: MessagesAckRequestAcksList;
    retries?: MessagesAckRequestRetriesList;
}
export declare const AckMessageRequest: S.Schema<AckMessageRequest>;
export type MessagesAckResponseWarningsMap = {
    [key: string]: string | undefined;
};
export declare const MessagesAckResponseWarningsMap: S.Schema<MessagesAckResponseWarningsMap>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface AckMessageResponse {
    /** The number of messages that were succesfully acknowledged. */
    ackCount?: number | null;
    /** The number of messages that were succesfully retried. */
    retryCount?: number | null;
    /** Map of lease IDs to warning messages encountered during acknowledgement. */
    warnings?: MessagesAckResponseWarningsMap | null;
}
export declare const AckMessageResponse: S.Schema<AckMessageResponse>;
export type MessagesBulkPushRequestMessagesItemMqQueueMessageTextContentType = "text";
export declare const MessagesBulkPushRequestMessagesItemMqQueueMessageTextContentType: any;
export interface MessagesBulkPushRequestMessagesItemMqQueueMessageText {
    body?: string;
    contentType?: MessagesBulkPushRequestMessagesItemMqQueueMessageTextContentType | (string & {});
    /** The number of seconds to wait for attempting to deliver this message to consumers */
    delaySeconds?: number;
}
export declare const MessagesBulkPushRequestMessagesItemMqQueueMessageText: S.Schema<MessagesBulkPushRequestMessagesItemMqQueueMessageText>;
export type MessagesBulkPushRequestMessagesItemMqQueueMessageJsonContentType = "json";
export declare const MessagesBulkPushRequestMessagesItemMqQueueMessageJsonContentType: any;
export interface MessagesBulkPushRequestMessagesItemMqQueueMessageJson {
    body?: unknown;
    contentType?: MessagesBulkPushRequestMessagesItemMqQueueMessageJsonContentType | (string & {});
    /** The number of seconds to wait for attempting to deliver this message to consumers */
    delaySeconds?: number;
}
export declare const MessagesBulkPushRequestMessagesItemMqQueueMessageJson: S.Schema<MessagesBulkPushRequestMessagesItemMqQueueMessageJson>;
export type MessagesBulkPushRequestMessagesItem = MessagesBulkPushRequestMessagesItemMqQueueMessageText | MessagesBulkPushRequestMessagesItemMqQueueMessageJson;
export declare const MessagesBulkPushRequestMessagesItem: any;
export type MessagesBulkPushRequestMessagesList = Array<MessagesBulkPushRequestMessagesItem>;
export declare const MessagesBulkPushRequestMessagesList: S.Schema<MessagesBulkPushRequestMessagesList>;
export interface BulkPushMessagesRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** The number of seconds to wait for attempting to deliver this batch to consumers */
    delaySeconds?: number;
    messages?: MessagesBulkPushRequestMessagesList;
}
export declare const BulkPushMessagesRequest: S.Schema<BulkPushMessagesRequest>;
export interface MessagesBulkPushResponseMetadataMetrics {
    /** The size in bytes of unacknowledged messages in the queue. */
    backlogBytes: number;
    /** The number of unacknowledged messages in the queue. */
    backlogCount: number;
    /** Unix timestamp in milliseconds of the oldest unacknowledged message in the queue. Returns 0 if unknown. */
    oldestMessageTimestampMs: number;
}
export declare const MessagesBulkPushResponseMetadataMetrics: S.Schema<MessagesBulkPushResponseMetadataMetrics>;
export interface MessagesBulkPushResponseMetadata {
    /** Best-effort metrics for the queue. Values may be approximate due to the distributed nature of queues. */
    metrics?: MessagesBulkPushResponseMetadataMetrics | null;
}
export declare const MessagesBulkPushResponseMetadata: S.Schema<MessagesBulkPushResponseMetadata>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface BulkPushMessagesResponse {
    metadata?: MessagesBulkPushResponseMetadata | null;
}
export declare const BulkPushMessagesResponse: S.Schema<BulkPushMessagesResponse>;
export type ConsumersCreateRequestType = "worker" | "http_pull";
export declare const ConsumersCreateRequestType: any;
export interface ConsumersCreateRequestSettingsWorker {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number;
    /** Maximum number of concurrent consumers that may consume from this Queue. Set to `null` to automatically opt in to the platform's maximum (recommended). */
    maxConcurrency?: number;
    /** The maximum number of retries */
    maxRetries?: number;
    /** The number of milliseconds to wait for a batch to fill up before attempting to deliver it */
    maxWaitTimeMs?: number;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number;
}
export declare const ConsumersCreateRequestSettingsWorker: S.Schema<ConsumersCreateRequestSettingsWorker>;
export interface ConsumersCreateRequestSettingsHTTPPull {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number;
    /** The maximum number of retries */
    maxRetries?: number;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number;
    /** The number of milliseconds that a message is exclusively leased. After the timeout, the message becomes available for another attempt. */
    visibilityTimeoutMs?: number;
}
export declare const ConsumersCreateRequestSettingsHTTPPull: S.Schema<ConsumersCreateRequestSettingsHTTPPull>;
export type ConsumersCreateRequestSettings = ConsumersCreateRequestSettingsWorker | ConsumersCreateRequestSettingsHTTPPull;
export declare const ConsumersCreateRequestSettings: any;
export interface CreateConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** Name of a Worker */
    scriptName?: string;
    type: ConsumersCreateRequestType | (string & {});
    deadLetterQueue?: string;
    settings?: ConsumersCreateRequestSettings;
}
export declare const CreateConsumerRequest: S.Schema<CreateConsumerRequest>;
export interface ConsumersCreateResultWorkerSettings {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number | null;
    /** Maximum number of concurrent consumers that may consume from this Queue. Set to `null` to automatically opt in to the platform's maximum (recommended). */
    maxConcurrency?: number | null;
    /** The maximum number of retries */
    maxRetries?: number | null;
    /** The number of milliseconds to wait for a batch to fill up before attempting to deliver it */
    maxWaitTimeMs?: number | null;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number | null;
}
export declare const ConsumersCreateResultWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type ConsumersCreateResultWorkerType = "worker";
export declare const ConsumersCreateResultWorkerType: any;
export interface ConsumersCreateResultWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersCreateResultWorkerType | null;
}
export declare const ConsumersCreateResultWorker: S.Schema<ConsumersCreateResultWorker>;
export interface ConsumersCreateResultHTTPPullSettings {
    /** The maximum number of messages to include in a batch. */
    batchSize?: number | null;
    /** The maximum number of retries */
    maxRetries?: number | null;
    /** The number of seconds to delay before making the message available for another attempt. */
    retryDelay?: number | null;
    /** The number of milliseconds that a message is exclusively leased. After the timeout, the message becomes available for another attempt. */
    visibilityTimeoutMs?: number | null;
}
export declare const ConsumersCreateResultHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type ConsumersCreateResultHTTPPullType = "http_pull";
export declare const ConsumersCreateResultHTTPPullType: any;
export interface ConsumersCreateResultHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersCreateResultHTTPPullType | null;
}
export declare const ConsumersCreateResultHTTPPull: S.Schema<ConsumersCreateResultHTTPPull>;
export type ConsumersCreateResult = ConsumersCreateResultWorker | ConsumersCreateResultHTTPPull;
export declare const ConsumersCreateResult: any;
export type CreateConsumerResponse = ConsumersCreateResult;
export declare const CreateConsumerResponse: S.Schema<CreateConsumerResponse>;
export interface CreateQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    queueName: string;
}
export declare const CreateQueueRequest: S.Schema<CreateQueueRequest>;
export type CreateResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const CreateResponseConsumersItemWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type CreateResponseConsumersItemWorkerType = "worker";
export declare const CreateResponseConsumersItemWorkerType: any;
export interface CreateResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: CreateResponseConsumersItemWorkerType | null;
}
export declare const CreateResponseConsumersItemWorker: S.Schema<CreateResponseConsumersItemWorker>;
export type CreateResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const CreateResponseConsumersItemHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type CreateResponseConsumersItemHTTPPullType = "http_pull";
export declare const CreateResponseConsumersItemHTTPPullType: any;
export interface CreateResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: CreateResponseConsumersItemHTTPPullType | null;
}
export declare const CreateResponseConsumersItemHTTPPull: S.Schema<CreateResponseConsumersItemHTTPPull>;
export type CreateResponseConsumersItem = CreateResponseConsumersItemWorker | CreateResponseConsumersItemHTTPPull;
export declare const CreateResponseConsumersItem: any;
export type CreateResponseConsumersList = Array<CreateResponseConsumersItem>;
export declare const CreateResponseConsumersList: S.Schema<CreateResponseConsumersList>;
export type CreateResponseProducersItemMqWorkerProducerType = "worker";
export declare const CreateResponseProducersItemMqWorkerProducerType: any;
export interface CreateResponseProducersItemMqWorkerProducer {
    type?: CreateResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export declare const CreateResponseProducersItemMqWorkerProducer: S.Schema<CreateResponseProducersItemMqWorkerProducer>;
export type CreateResponseProducersItemMqR2ProducerType = "r2_bucket";
export declare const CreateResponseProducersItemMqR2ProducerType: any;
export interface CreateResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: CreateResponseProducersItemMqR2ProducerType | null;
}
export declare const CreateResponseProducersItemMqR2Producer: S.Schema<CreateResponseProducersItemMqR2Producer>;
export type CreateResponseProducersItem = CreateResponseProducersItemMqWorkerProducer | CreateResponseProducersItemMqR2Producer;
export declare const CreateResponseProducersItem: any;
export type CreateResponseProducersList = Array<CreateResponseProducersItem>;
export declare const CreateResponseProducersList: S.Schema<CreateResponseProducersList>;
export interface CreateResponseSettings {
    /** Number of seconds to delay delivery of all messages to consumers. */
    deliveryDelay?: number | null;
    /** Indicates if message delivery to consumers is currently paused. */
    deliveryPaused?: boolean | null;
    /** Number of seconds after which an unconsumed message will be delayed. */
    messageRetentionPeriod?: number | null;
}
export declare const CreateResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateQueueResponse {
    consumers?: CreateResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    modifiedOn?: string | null;
    producers?: CreateResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export declare const CreateQueueResponse: S.Schema<CreateQueueResponse>;
export type SubscriptionsCreateRequestDestinationType = "queues.queue";
export declare const SubscriptionsCreateRequestDestinationType: any;
export interface SubscriptionsCreateRequestDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsCreateRequestDestinationType | (string & {});
}
export declare const SubscriptionsCreateRequestDestination: S.Schema<SubscriptionsCreateRequestDestination>;
export type SubscriptionsCreateRequestEventsList = Array<string>;
export declare const SubscriptionsCreateRequestEventsList: S.Schema<SubscriptionsCreateRequestEventsList>;
export type SubscriptionsCreateRequestSourceMqEventSourceImagesType = "images";
export declare const SubscriptionsCreateRequestSourceMqEventSourceImagesType: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceImagesType | (string & {});
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceImages: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceImages>;
export type SubscriptionsCreateRequestSourceMqEventSourceKVType = "kv";
export declare const SubscriptionsCreateRequestSourceMqEventSourceKVType: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceKVType | (string & {});
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceKV: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceKV>;
export type SubscriptionsCreateRequestSourceMqEventSourceR2Type = "r2";
export declare const SubscriptionsCreateRequestSourceMqEventSourceR2Type: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceR2Type | (string & {});
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceR2: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceR2>;
export type SubscriptionsCreateRequestSourceMqEventSourceSuperSlurperType = "superSlurper";
export declare const SubscriptionsCreateRequestSourceMqEventSourceSuperSlurperType: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceSuperSlurperType | (string & {});
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceSuperSlurper: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceSuperSlurper>;
export type SubscriptionsCreateRequestSourceMqEventSourceVectorizeType = "vectorize";
export declare const SubscriptionsCreateRequestSourceMqEventSourceVectorizeType: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceVectorizeType | (string & {});
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceVectorize: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceVectorize>;
export type SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export declare const SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModelType: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string;
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModelType | (string & {});
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModel: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModel>;
export type SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export declare const SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorkerType: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorkerType | (string & {});
    /** Name of the worker */
    workerName?: string;
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorker: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorker>;
export type SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export declare const SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflowType: any;
export interface SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflowType | (string & {});
    /** Name of the workflow */
    workflowName?: string;
}
export declare const SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflow: S.Schema<SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflow>;
export type SubscriptionsCreateRequestSource = SubscriptionsCreateRequestSourceMqEventSourceImages | SubscriptionsCreateRequestSourceMqEventSourceKV | SubscriptionsCreateRequestSourceMqEventSourceR2 | SubscriptionsCreateRequestSourceMqEventSourceSuperSlurper | SubscriptionsCreateRequestSourceMqEventSourceVectorize | SubscriptionsCreateRequestSourceMqEventSourceWorkersAIModel | SubscriptionsCreateRequestSourceMqEventSourceWorkersBuildsWorker | SubscriptionsCreateRequestSourceMqEventSourceWorkflowsWorkflow;
export declare const SubscriptionsCreateRequestSource: any;
export interface CreateSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** Destination configuration for the subscription */
    destination?: SubscriptionsCreateRequestDestination;
    /** Whether the subscription is active */
    enabled?: boolean;
    /** List of event types this subscription handles */
    events?: SubscriptionsCreateRequestEventsList;
    /** Name of the subscription */
    name?: string;
    /** Source configuration for the subscription */
    source?: SubscriptionsCreateRequestSource;
}
export declare const CreateSubscriptionRequest: S.Schema<CreateSubscriptionRequest>;
export type SubscriptionsCreateResponseDestinationType = "queues.queue";
export declare const SubscriptionsCreateResponseDestinationType: any;
export interface SubscriptionsCreateResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsCreateResponseDestinationType;
}
export declare const SubscriptionsCreateResponseDestination: S.Schema<SubscriptionsCreateResponseDestination>;
export type SubscriptionsCreateResponseEventsList = Array<string>;
export declare const SubscriptionsCreateResponseEventsList: S.Schema<SubscriptionsCreateResponseEventsList>;
export type SubscriptionsCreateResponseSourceMqEventSourceImagesType = "images";
export declare const SubscriptionsCreateResponseSourceMqEventSourceImagesType: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceImagesType | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceImages: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceImages>;
export type SubscriptionsCreateResponseSourceMqEventSourceKVType = "kv";
export declare const SubscriptionsCreateResponseSourceMqEventSourceKVType: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceKVType | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceKV: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceKV>;
export type SubscriptionsCreateResponseSourceMqEventSourceR2Type = "r2";
export declare const SubscriptionsCreateResponseSourceMqEventSourceR2Type: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceR2Type | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceR2: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceR2>;
export type SubscriptionsCreateResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export declare const SubscriptionsCreateResponseSourceMqEventSourceSuperSlurperType: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceSuperSlurperType | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceSuperSlurper: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceSuperSlurper>;
export type SubscriptionsCreateResponseSourceMqEventSourceVectorizeType = "vectorize";
export declare const SubscriptionsCreateResponseSourceMqEventSourceVectorizeType: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceVectorizeType | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceVectorize: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceVectorize>;
export type SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export declare const SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModelType: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModelType | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModel: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModel>;
export type SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export declare const SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorkerType: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorker: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorker>;
export type SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export declare const SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflowType: any;
export interface SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export declare const SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflow: S.Schema<SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflow>;
export type SubscriptionsCreateResponseSource = SubscriptionsCreateResponseSourceMqEventSourceImages | SubscriptionsCreateResponseSourceMqEventSourceKV | SubscriptionsCreateResponseSourceMqEventSourceR2 | SubscriptionsCreateResponseSourceMqEventSourceSuperSlurper | SubscriptionsCreateResponseSourceMqEventSourceVectorize | SubscriptionsCreateResponseSourceMqEventSourceWorkersAIModel | SubscriptionsCreateResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsCreateResponseSourceMqEventSourceWorkflowsWorkflow;
export declare const SubscriptionsCreateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsCreateResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsCreateResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsCreateResponseSource;
}
export declare const CreateSubscriptionResponse: S.Schema<CreateSubscriptionResponse>;
export interface DeleteConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** A Resource identifier. */
    consumerId: string;
}
export declare const DeleteConsumerRequest: S.Schema<DeleteConsumerRequest>;
export interface DeleteConsumerResponse {
}
export declare const DeleteConsumerResponse: S.Schema<DeleteConsumerResponse>;
export interface DeleteQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export declare const DeleteQueueRequest: S.Schema<DeleteQueueRequest>;
export interface DeleteQueueResponse {
}
export declare const DeleteQueueResponse: S.Schema<DeleteQueueResponse>;
export interface DeleteSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    subscriptionId: string;
}
export declare const DeleteSubscriptionRequest: S.Schema<DeleteSubscriptionRequest>;
export type SubscriptionsDeleteResponseDestinationType = "queues.queue";
export declare const SubscriptionsDeleteResponseDestinationType: any;
export interface SubscriptionsDeleteResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsDeleteResponseDestinationType;
}
export declare const SubscriptionsDeleteResponseDestination: S.Schema<SubscriptionsDeleteResponseDestination>;
export type SubscriptionsDeleteResponseEventsList = Array<string>;
export declare const SubscriptionsDeleteResponseEventsList: S.Schema<SubscriptionsDeleteResponseEventsList>;
export type SubscriptionsDeleteResponseSourceMqEventSourceImagesType = "images";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceImagesType: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceImagesType | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceImages: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceImages>;
export type SubscriptionsDeleteResponseSourceMqEventSourceKVType = "kv";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceKVType: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceKVType | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceKV: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceKV>;
export type SubscriptionsDeleteResponseSourceMqEventSourceR2Type = "r2";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceR2Type: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceR2Type | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceR2: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceR2>;
export type SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurperType: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurperType | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurper: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurper>;
export type SubscriptionsDeleteResponseSourceMqEventSourceVectorizeType = "vectorize";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceVectorizeType: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceVectorizeType | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceVectorize: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceVectorize>;
export type SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModelType: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModelType | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModel: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModel>;
export type SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorkerType: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorker: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorker>;
export type SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export declare const SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflowType: any;
export interface SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export declare const SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflow: S.Schema<SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflow>;
export type SubscriptionsDeleteResponseSource = SubscriptionsDeleteResponseSourceMqEventSourceImages | SubscriptionsDeleteResponseSourceMqEventSourceKV | SubscriptionsDeleteResponseSourceMqEventSourceR2 | SubscriptionsDeleteResponseSourceMqEventSourceSuperSlurper | SubscriptionsDeleteResponseSourceMqEventSourceVectorize | SubscriptionsDeleteResponseSourceMqEventSourceWorkersAIModel | SubscriptionsDeleteResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsDeleteResponseSourceMqEventSourceWorkflowsWorkflow;
export declare const SubscriptionsDeleteResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsDeleteResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsDeleteResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsDeleteResponseSource;
}
export declare const DeleteSubscriptionResponse: S.Schema<DeleteSubscriptionResponse>;
export interface GetConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** A Resource identifier. */
    consumerId: string;
}
export declare const GetConsumerRequest: S.Schema<GetConsumerRequest>;
export type ConsumersGetResultWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const ConsumersGetResultWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type ConsumersGetResultWorkerType = "worker";
export declare const ConsumersGetResultWorkerType: any;
export interface ConsumersGetResultWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersGetResultWorkerType | null;
}
export declare const ConsumersGetResultWorker: S.Schema<ConsumersGetResultWorker>;
export type ConsumersGetResultHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const ConsumersGetResultHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type ConsumersGetResultHTTPPullType = "http_pull";
export declare const ConsumersGetResultHTTPPullType: any;
export interface ConsumersGetResultHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersGetResultHTTPPullType | null;
}
export declare const ConsumersGetResultHTTPPull: S.Schema<ConsumersGetResultHTTPPull>;
export type ConsumersGetResult = ConsumersGetResultWorker | ConsumersGetResultHTTPPull;
export declare const ConsumersGetResult: any;
export type GetConsumerResponse = ConsumersGetResult;
export declare const GetConsumerResponse: S.Schema<GetConsumerResponse>;
export interface GetMetricsQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export declare const GetMetricsQueueRequest: S.Schema<GetMetricsQueueRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMetricsQueueResponse {
    /** The size in bytes of unacknowledged messages in the queue. */
    backlogBytes: number;
    /** The number of unacknowledged messages in the queue. */
    backlogCount: number;
    /** Unix timestamp in milliseconds of the oldest unacknowledged message in the queue. Returns 0 if unknown. */
    oldestMessageTimestampMs: number;
}
export declare const GetMetricsQueueResponse: S.Schema<GetMetricsQueueResponse>;
export interface GetQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export declare const GetQueueRequest: S.Schema<GetQueueRequest>;
export type GetResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const GetResponseConsumersItemWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type GetResponseConsumersItemWorkerType = "worker";
export declare const GetResponseConsumersItemWorkerType: any;
export interface GetResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: GetResponseConsumersItemWorkerType | null;
}
export declare const GetResponseConsumersItemWorker: S.Schema<GetResponseConsumersItemWorker>;
export type GetResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const GetResponseConsumersItemHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type GetResponseConsumersItemHTTPPullType = "http_pull";
export declare const GetResponseConsumersItemHTTPPullType: any;
export interface GetResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: GetResponseConsumersItemHTTPPullType | null;
}
export declare const GetResponseConsumersItemHTTPPull: S.Schema<GetResponseConsumersItemHTTPPull>;
export type GetResponseConsumersItem = GetResponseConsumersItemWorker | GetResponseConsumersItemHTTPPull;
export declare const GetResponseConsumersItem: any;
export type GetResponseConsumersList = Array<GetResponseConsumersItem>;
export declare const GetResponseConsumersList: S.Schema<GetResponseConsumersList>;
export type GetResponseProducersItemMqWorkerProducerType = "worker";
export declare const GetResponseProducersItemMqWorkerProducerType: any;
export interface GetResponseProducersItemMqWorkerProducer {
    type?: GetResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export declare const GetResponseProducersItemMqWorkerProducer: S.Schema<GetResponseProducersItemMqWorkerProducer>;
export type GetResponseProducersItemMqR2ProducerType = "r2_bucket";
export declare const GetResponseProducersItemMqR2ProducerType: any;
export interface GetResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: GetResponseProducersItemMqR2ProducerType | null;
}
export declare const GetResponseProducersItemMqR2Producer: S.Schema<GetResponseProducersItemMqR2Producer>;
export type GetResponseProducersItem = GetResponseProducersItemMqWorkerProducer | GetResponseProducersItemMqR2Producer;
export declare const GetResponseProducersItem: any;
export type GetResponseProducersList = Array<GetResponseProducersItem>;
export declare const GetResponseProducersList: S.Schema<GetResponseProducersList>;
export type GetResponseSettings = CreateResponseSettings;
export declare const GetResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetQueueResponse {
    consumers?: GetResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    modifiedOn?: string | null;
    producers?: GetResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export declare const GetQueueResponse: S.Schema<GetQueueResponse>;
export interface GetSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    subscriptionId: string;
}
export declare const GetSubscriptionRequest: S.Schema<GetSubscriptionRequest>;
export type SubscriptionsGetResponseDestinationType = "queues.queue";
export declare const SubscriptionsGetResponseDestinationType: any;
export interface SubscriptionsGetResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsGetResponseDestinationType;
}
export declare const SubscriptionsGetResponseDestination: S.Schema<SubscriptionsGetResponseDestination>;
export type SubscriptionsGetResponseEventsList = Array<string>;
export declare const SubscriptionsGetResponseEventsList: S.Schema<SubscriptionsGetResponseEventsList>;
export type SubscriptionsGetResponseSourceMqEventSourceImagesType = "images";
export declare const SubscriptionsGetResponseSourceMqEventSourceImagesType: any;
export interface SubscriptionsGetResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceImagesType | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceImages: S.Schema<SubscriptionsGetResponseSourceMqEventSourceImages>;
export type SubscriptionsGetResponseSourceMqEventSourceKVType = "kv";
export declare const SubscriptionsGetResponseSourceMqEventSourceKVType: any;
export interface SubscriptionsGetResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceKVType | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceKV: S.Schema<SubscriptionsGetResponseSourceMqEventSourceKV>;
export type SubscriptionsGetResponseSourceMqEventSourceR2Type = "r2";
export declare const SubscriptionsGetResponseSourceMqEventSourceR2Type: any;
export interface SubscriptionsGetResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceR2Type | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceR2: S.Schema<SubscriptionsGetResponseSourceMqEventSourceR2>;
export type SubscriptionsGetResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export declare const SubscriptionsGetResponseSourceMqEventSourceSuperSlurperType: any;
export interface SubscriptionsGetResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceSuperSlurperType | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceSuperSlurper: S.Schema<SubscriptionsGetResponseSourceMqEventSourceSuperSlurper>;
export type SubscriptionsGetResponseSourceMqEventSourceVectorizeType = "vectorize";
export declare const SubscriptionsGetResponseSourceMqEventSourceVectorizeType: any;
export interface SubscriptionsGetResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceVectorizeType | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceVectorize: S.Schema<SubscriptionsGetResponseSourceMqEventSourceVectorize>;
export type SubscriptionsGetResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export declare const SubscriptionsGetResponseSourceMqEventSourceWorkersAIModelType: any;
export interface SubscriptionsGetResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceWorkersAIModelType | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceWorkersAIModel: S.Schema<SubscriptionsGetResponseSourceMqEventSourceWorkersAIModel>;
export type SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export declare const SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorkerType: any;
export interface SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorker: S.Schema<SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorker>;
export type SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export declare const SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflowType: any;
export interface SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export declare const SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflow: S.Schema<SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflow>;
export type SubscriptionsGetResponseSource = SubscriptionsGetResponseSourceMqEventSourceImages | SubscriptionsGetResponseSourceMqEventSourceKV | SubscriptionsGetResponseSourceMqEventSourceR2 | SubscriptionsGetResponseSourceMqEventSourceSuperSlurper | SubscriptionsGetResponseSourceMqEventSourceVectorize | SubscriptionsGetResponseSourceMqEventSourceWorkersAIModel | SubscriptionsGetResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsGetResponseSourceMqEventSourceWorkflowsWorkflow;
export declare const SubscriptionsGetResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsGetResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsGetResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsGetResponseSource;
}
export declare const GetSubscriptionResponse: S.Schema<GetSubscriptionResponse>;
export interface ListConsumersRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export declare const ListConsumersRequest: S.Schema<ListConsumersRequest>;
export type ConsumersListResultItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const ConsumersListResultItemWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type ConsumersListResultItemWorkerType = "worker";
export declare const ConsumersListResultItemWorkerType: any;
export interface ConsumersListResultItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersListResultItemWorkerType | null;
}
export declare const ConsumersListResultItemWorker: S.Schema<ConsumersListResultItemWorker>;
export type ConsumersListResultItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const ConsumersListResultItemHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type ConsumersListResultItemHTTPPullType = "http_pull";
export declare const ConsumersListResultItemHTTPPullType: any;
export interface ConsumersListResultItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersListResultItemHTTPPullType | null;
}
export declare const ConsumersListResultItemHTTPPull: S.Schema<ConsumersListResultItemHTTPPull>;
export type ConsumersListResultItem = ConsumersListResultItemWorker | ConsumersListResultItemHTTPPull;
export declare const ConsumersListResultItem: any;
export type ConsumersListResultList = Array<ConsumersListResultItem>;
export declare const ConsumersListResultList: S.Schema<ConsumersListResultList>;
export interface ListConsumersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ConsumersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListConsumersResponse: S.Schema<ListConsumersResponse>;
export interface ListQueuesRequest {
    /** A Resource identifier. */
    accountId: string;
}
export declare const ListQueuesRequest: S.Schema<ListQueuesRequest>;
export type ListResultItemConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const ListResultItemConsumersItemWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type ListResultItemConsumersItemWorkerType = "worker";
export declare const ListResultItemConsumersItemWorkerType: any;
export interface ListResultItemConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ListResultItemConsumersItemWorkerType | null;
}
export declare const ListResultItemConsumersItemWorker: S.Schema<ListResultItemConsumersItemWorker>;
export type ListResultItemConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const ListResultItemConsumersItemHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type ListResultItemConsumersItemHTTPPullType = "http_pull";
export declare const ListResultItemConsumersItemHTTPPullType: any;
export interface ListResultItemConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ListResultItemConsumersItemHTTPPullType | null;
}
export declare const ListResultItemConsumersItemHTTPPull: S.Schema<ListResultItemConsumersItemHTTPPull>;
export type ListResultItemConsumersItem = ListResultItemConsumersItemWorker | ListResultItemConsumersItemHTTPPull;
export declare const ListResultItemConsumersItem: any;
export type ListResultItemConsumersList = Array<ListResultItemConsumersItem>;
export declare const ListResultItemConsumersList: S.Schema<ListResultItemConsumersList>;
export type ListResultItemProducersItemMqWorkerProducerType = "worker";
export declare const ListResultItemProducersItemMqWorkerProducerType: any;
export interface ListResultItemProducersItemMqWorkerProducer {
    type?: ListResultItemProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export declare const ListResultItemProducersItemMqWorkerProducer: S.Schema<ListResultItemProducersItemMqWorkerProducer>;
export type ListResultItemProducersItemMqR2ProducerType = "r2_bucket";
export declare const ListResultItemProducersItemMqR2ProducerType: any;
export interface ListResultItemProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: ListResultItemProducersItemMqR2ProducerType | null;
}
export declare const ListResultItemProducersItemMqR2Producer: S.Schema<ListResultItemProducersItemMqR2Producer>;
export type ListResultItemProducersItem = ListResultItemProducersItemMqWorkerProducer | ListResultItemProducersItemMqR2Producer;
export declare const ListResultItemProducersItem: any;
export type ListResultItemProducersList = Array<ListResultItemProducersItem>;
export declare const ListResultItemProducersList: S.Schema<ListResultItemProducersList>;
export type ListResultItemSettings = CreateResponseSettings;
export declare const ListResultItemSettings: S.Schema<CreateResponseSettings>;
export interface ListResultItem {
    consumers?: ListResultItemConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    modifiedOn?: string | null;
    producers?: ListResultItemProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListQueuesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListQueuesResponse: S.Schema<ListQueuesResponse>;
export type SubscriptionsListRequestDirection = "asc" | "desc";
export declare const SubscriptionsListRequestDirection: any;
export type SubscriptionsListRequestOrder = "created_at" | "name" | "enabled" | "source";
export declare const SubscriptionsListRequestOrder: any;
export interface ListSubscriptionsRequest {
    /** A Resource identifier. */
    accountId: string;
    /** Sort direction */
    direction?: SubscriptionsListRequestDirection | (string & {});
    /** Field to sort by */
    order?: SubscriptionsListRequestOrder | (string & {});
    /** Page number for pagination */
    page?: number;
    /** Number of items per page */
    perPage?: number;
}
export declare const ListSubscriptionsRequest: S.Schema<ListSubscriptionsRequest>;
export type SubscriptionsListResultItemDestinationType = "queues.queue";
export declare const SubscriptionsListResultItemDestinationType: any;
export interface SubscriptionsListResultItemDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsListResultItemDestinationType;
}
export declare const SubscriptionsListResultItemDestination: S.Schema<SubscriptionsListResultItemDestination>;
export type SubscriptionsListResultItemEventsList = Array<string>;
export declare const SubscriptionsListResultItemEventsList: S.Schema<SubscriptionsListResultItemEventsList>;
export type SubscriptionsListResultItemSourceMqEventSourceImagesType = "images";
export declare const SubscriptionsListResultItemSourceMqEventSourceImagesType: any;
export interface SubscriptionsListResultItemSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceImagesType | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceImages: S.Schema<SubscriptionsListResultItemSourceMqEventSourceImages>;
export type SubscriptionsListResultItemSourceMqEventSourceKVType = "kv";
export declare const SubscriptionsListResultItemSourceMqEventSourceKVType: any;
export interface SubscriptionsListResultItemSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceKVType | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceKV: S.Schema<SubscriptionsListResultItemSourceMqEventSourceKV>;
export type SubscriptionsListResultItemSourceMqEventSourceR2Type = "r2";
export declare const SubscriptionsListResultItemSourceMqEventSourceR2Type: any;
export interface SubscriptionsListResultItemSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceR2Type | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceR2: S.Schema<SubscriptionsListResultItemSourceMqEventSourceR2>;
export type SubscriptionsListResultItemSourceMqEventSourceSuperSlurperType = "superSlurper";
export declare const SubscriptionsListResultItemSourceMqEventSourceSuperSlurperType: any;
export interface SubscriptionsListResultItemSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceSuperSlurperType | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceSuperSlurper: S.Schema<SubscriptionsListResultItemSourceMqEventSourceSuperSlurper>;
export type SubscriptionsListResultItemSourceMqEventSourceVectorizeType = "vectorize";
export declare const SubscriptionsListResultItemSourceMqEventSourceVectorizeType: any;
export interface SubscriptionsListResultItemSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceVectorizeType | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceVectorize: S.Schema<SubscriptionsListResultItemSourceMqEventSourceVectorize>;
export type SubscriptionsListResultItemSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export declare const SubscriptionsListResultItemSourceMqEventSourceWorkersAIModelType: any;
export interface SubscriptionsListResultItemSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceWorkersAIModelType | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceWorkersAIModel: S.Schema<SubscriptionsListResultItemSourceMqEventSourceWorkersAIModel>;
export type SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export declare const SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorkerType: any;
export interface SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorker: S.Schema<SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorker>;
export type SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export declare const SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflowType: any;
export interface SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export declare const SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflow: S.Schema<SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflow>;
export type SubscriptionsListResultItemSource = SubscriptionsListResultItemSourceMqEventSourceImages | SubscriptionsListResultItemSourceMqEventSourceKV | SubscriptionsListResultItemSourceMqEventSourceR2 | SubscriptionsListResultItemSourceMqEventSourceSuperSlurper | SubscriptionsListResultItemSourceMqEventSourceVectorize | SubscriptionsListResultItemSourceMqEventSourceWorkersAIModel | SubscriptionsListResultItemSourceMqEventSourceWorkersBuildsWorker | SubscriptionsListResultItemSourceMqEventSourceWorkflowsWorkflow;
export declare const SubscriptionsListResultItemSource: any;
export interface SubscriptionsListResultItem {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsListResultItemDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsListResultItemEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsListResultItemSource;
}
export declare const SubscriptionsListResultItem: S.Schema<SubscriptionsListResultItem>;
export type SubscriptionsListResultList = Array<SubscriptionsListResultItem>;
export declare const SubscriptionsListResultList: S.Schema<SubscriptionsListResultList>;
export interface ListSubscriptionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListSubscriptionsResponse: S.Schema<ListSubscriptionsResponse>;
export interface EditRequestSettings {
    /** Number of seconds to delay delivery of all messages to consumers. */
    deliveryDelay?: number;
    /** Indicates if message delivery to consumers is currently paused. */
    deliveryPaused?: boolean;
    /** Number of seconds after which an unconsumed message will be delayed. */
    messageRetentionPeriod?: number;
}
export declare const EditRequestSettings: S.Schema<EditRequestSettings>;
export interface PatchQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    queueName?: string;
    settings?: EditRequestSettings;
}
export declare const PatchQueueRequest: S.Schema<PatchQueueRequest>;
export type EditResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const EditResponseConsumersItemWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type EditResponseConsumersItemWorkerType = "worker";
export declare const EditResponseConsumersItemWorkerType: any;
export interface EditResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: EditResponseConsumersItemWorkerType | null;
}
export declare const EditResponseConsumersItemWorker: S.Schema<EditResponseConsumersItemWorker>;
export type EditResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const EditResponseConsumersItemHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type EditResponseConsumersItemHTTPPullType = "http_pull";
export declare const EditResponseConsumersItemHTTPPullType: any;
export interface EditResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: EditResponseConsumersItemHTTPPullType | null;
}
export declare const EditResponseConsumersItemHTTPPull: S.Schema<EditResponseConsumersItemHTTPPull>;
export type EditResponseConsumersItem = EditResponseConsumersItemWorker | EditResponseConsumersItemHTTPPull;
export declare const EditResponseConsumersItem: any;
export type EditResponseConsumersList = Array<EditResponseConsumersItem>;
export declare const EditResponseConsumersList: S.Schema<EditResponseConsumersList>;
export type EditResponseProducersItemMqWorkerProducerType = "worker";
export declare const EditResponseProducersItemMqWorkerProducerType: any;
export interface EditResponseProducersItemMqWorkerProducer {
    type?: EditResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export declare const EditResponseProducersItemMqWorkerProducer: S.Schema<EditResponseProducersItemMqWorkerProducer>;
export type EditResponseProducersItemMqR2ProducerType = "r2_bucket";
export declare const EditResponseProducersItemMqR2ProducerType: any;
export interface EditResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: EditResponseProducersItemMqR2ProducerType | null;
}
export declare const EditResponseProducersItemMqR2Producer: S.Schema<EditResponseProducersItemMqR2Producer>;
export type EditResponseProducersItem = EditResponseProducersItemMqWorkerProducer | EditResponseProducersItemMqR2Producer;
export declare const EditResponseProducersItem: any;
export type EditResponseProducersList = Array<EditResponseProducersItem>;
export declare const EditResponseProducersList: S.Schema<EditResponseProducersList>;
export type EditResponseSettings = CreateResponseSettings;
export declare const EditResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchQueueResponse {
    consumers?: EditResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    modifiedOn?: string | null;
    producers?: EditResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export declare const PatchQueueResponse: S.Schema<PatchQueueResponse>;
export type SubscriptionsUpdateRequestDestinationType = "queues.queue";
export declare const SubscriptionsUpdateRequestDestinationType: any;
export interface SubscriptionsUpdateRequestDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsUpdateRequestDestinationType | (string & {});
}
export declare const SubscriptionsUpdateRequestDestination: S.Schema<SubscriptionsUpdateRequestDestination>;
export type SubscriptionsUpdateRequestEventsList = Array<string>;
export declare const SubscriptionsUpdateRequestEventsList: S.Schema<SubscriptionsUpdateRequestEventsList>;
export interface PatchSubscriptionRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    subscriptionId: string;
    /** Destination configuration for the subscription */
    destination?: SubscriptionsUpdateRequestDestination;
    /** Whether the subscription is active */
    enabled?: boolean;
    /** List of event types this subscription handles */
    events?: SubscriptionsUpdateRequestEventsList;
    /** Name of the subscription */
    name?: string;
}
export declare const PatchSubscriptionRequest: S.Schema<PatchSubscriptionRequest>;
export type SubscriptionsUpdateResponseDestinationType = "queues.queue";
export declare const SubscriptionsUpdateResponseDestinationType: any;
export interface SubscriptionsUpdateResponseDestination {
    /** ID of the target queue */
    queueId: string;
    /** Type of destination */
    type: SubscriptionsUpdateResponseDestinationType;
}
export declare const SubscriptionsUpdateResponseDestination: S.Schema<SubscriptionsUpdateResponseDestination>;
export type SubscriptionsUpdateResponseEventsList = Array<string>;
export declare const SubscriptionsUpdateResponseEventsList: S.Schema<SubscriptionsUpdateResponseEventsList>;
export type SubscriptionsUpdateResponseSourceMqEventSourceImagesType = "images";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceImagesType: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceImages {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceImagesType | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceImages: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceImages>;
export type SubscriptionsUpdateResponseSourceMqEventSourceKVType = "kv";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceKVType: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceKV {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceKVType | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceKV: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceKV>;
export type SubscriptionsUpdateResponseSourceMqEventSourceR2Type = "r2";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceR2Type: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceR2 {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceR2Type | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceR2: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceR2>;
export type SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurperType = "superSlurper";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurperType: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurper {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurperType | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurper: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurper>;
export type SubscriptionsUpdateResponseSourceMqEventSourceVectorizeType = "vectorize";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceVectorizeType: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceVectorize {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceVectorizeType | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceVectorize: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceVectorize>;
export type SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModelType = "workersAi.model";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModelType: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModel {
    /** Name of the Workers AI model */
    modelName?: string | null;
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModelType | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModel: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModel>;
export type SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorkerType = "workersBuilds.worker";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorkerType: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorker {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorkerType | null;
    /** Name of the worker */
    workerName?: string | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorker: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorker>;
export type SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflowType = "workflows.workflow";
export declare const SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflowType: any;
export interface SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflow {
    /** Type of source */
    type?: SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflowType | null;
    /** Name of the workflow */
    workflowName?: string | null;
}
export declare const SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflow: S.Schema<SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflow>;
export type SubscriptionsUpdateResponseSource = SubscriptionsUpdateResponseSourceMqEventSourceImages | SubscriptionsUpdateResponseSourceMqEventSourceKV | SubscriptionsUpdateResponseSourceMqEventSourceR2 | SubscriptionsUpdateResponseSourceMqEventSourceSuperSlurper | SubscriptionsUpdateResponseSourceMqEventSourceVectorize | SubscriptionsUpdateResponseSourceMqEventSourceWorkersAIModel | SubscriptionsUpdateResponseSourceMqEventSourceWorkersBuildsWorker | SubscriptionsUpdateResponseSourceMqEventSourceWorkflowsWorkflow;
export declare const SubscriptionsUpdateResponseSource: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchSubscriptionResponse {
    /** Unique identifier for the subscription */
    id: string;
    /** When the subscription was created */
    createdAt: string;
    /** Destination configuration for the subscription */
    destination: SubscriptionsUpdateResponseDestination;
    /** Whether the subscription is active */
    enabled: boolean;
    /** List of event types this subscription handles */
    events: SubscriptionsUpdateResponseEventsList;
    /** When the subscription was last modified */
    modifiedAt: string;
    /** Name of the subscription */
    name: string;
    /** Source configuration for the subscription */
    source: SubscriptionsUpdateResponseSource;
}
export declare const PatchSubscriptionResponse: S.Schema<PatchSubscriptionResponse>;
export interface PullMessageRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** The maximum number of messages to include in a batch. */
    batchSize?: number;
    /** The number of milliseconds that a message is exclusively leased. After the timeout, the message becomes available for another attempt. */
    visibilityTimeoutMs?: number;
}
export declare const PullMessageRequest: S.Schema<PullMessageRequest>;
export interface MessagesPullResponseMessagesItem {
    id?: string | null;
    attempts?: number | null;
    body?: string | null;
    /** An ID that represents an "in-flight" message that has been pulled from a Queue. You must hold on to this ID and use it to acknowledge this message. */
    leaseId?: string | null;
    metadata?: unknown | null;
    timestampMs?: number | null;
}
export declare const MessagesPullResponseMessagesItem: S.Schema<MessagesPullResponseMessagesItem>;
export type MessagesPullResponseMessagesList = Array<MessagesPullResponseMessagesItem>;
export declare const MessagesPullResponseMessagesList: S.Schema<MessagesPullResponseMessagesList>;
export type MessagesPullResponseMetadataMetrics = MessagesBulkPushResponseMetadataMetrics;
export declare const MessagesPullResponseMetadataMetrics: S.Schema<MessagesBulkPushResponseMetadataMetrics>;
export type MessagesPullResponseMetadata = MessagesBulkPushResponseMetadata;
export declare const MessagesPullResponseMetadata: S.Schema<MessagesBulkPushResponseMetadata>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PullMessageResponse {
    /** The number of unacknowledged messages in the queue. */
    messageBacklogCount?: number | null;
    messages?: MessagesPullResponseMessagesList | null;
    metadata?: MessagesBulkPushResponseMetadata | null;
}
export declare const PullMessageResponse: S.Schema<PullMessageResponse>;
export interface PurgeStatusRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
}
export declare const PurgeStatusRequest: S.Schema<PurgeStatusRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PurgeStatusResponse {
    /** Indicates if the last purge operation completed successfully. */
    completed?: string | null;
    /** Timestamp when the last purge operation started. */
    startedAt?: string | null;
}
export declare const PurgeStatusResponse: S.Schema<PurgeStatusResponse>;
export type MessagesPushRequestContentType = "text" | "json";
export declare const MessagesPushRequestContentType: any;
export interface PushMessageRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    body?: unknown;
    contentType?: MessagesPushRequestContentType | (string & {});
    /** The number of seconds to wait for attempting to deliver this message to consumers */
    delaySeconds?: number;
}
export declare const PushMessageRequest: S.Schema<PushMessageRequest>;
export type MessagesPushResponseMetadataMetrics = MessagesBulkPushResponseMetadataMetrics;
export declare const MessagesPushResponseMetadataMetrics: S.Schema<MessagesBulkPushResponseMetadataMetrics>;
export type MessagesPushResponseMetadata = MessagesBulkPushResponseMetadata;
export declare const MessagesPushResponseMetadata: S.Schema<MessagesBulkPushResponseMetadata>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PushMessageResponse {
    metadata?: MessagesBulkPushResponseMetadata | null;
}
export declare const PushMessageResponse: S.Schema<PushMessageResponse>;
export interface StartPurgeRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** Confimation that all messages will be deleted permanently. */
    deleteMessagesPermanently?: boolean;
}
export declare const StartPurgeRequest: S.Schema<StartPurgeRequest>;
export type PurgeStartResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const PurgeStartResponseConsumersItemWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type PurgeStartResponseConsumersItemWorkerType = "worker";
export declare const PurgeStartResponseConsumersItemWorkerType: any;
export interface PurgeStartResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: PurgeStartResponseConsumersItemWorkerType | null;
}
export declare const PurgeStartResponseConsumersItemWorker: S.Schema<PurgeStartResponseConsumersItemWorker>;
export type PurgeStartResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const PurgeStartResponseConsumersItemHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type PurgeStartResponseConsumersItemHTTPPullType = "http_pull";
export declare const PurgeStartResponseConsumersItemHTTPPullType: any;
export interface PurgeStartResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: PurgeStartResponseConsumersItemHTTPPullType | null;
}
export declare const PurgeStartResponseConsumersItemHTTPPull: S.Schema<PurgeStartResponseConsumersItemHTTPPull>;
export type PurgeStartResponseConsumersItem = PurgeStartResponseConsumersItemWorker | PurgeStartResponseConsumersItemHTTPPull;
export declare const PurgeStartResponseConsumersItem: any;
export type PurgeStartResponseConsumersList = Array<PurgeStartResponseConsumersItem>;
export declare const PurgeStartResponseConsumersList: S.Schema<PurgeStartResponseConsumersList>;
export type PurgeStartResponseProducersItemMqWorkerProducerType = "worker";
export declare const PurgeStartResponseProducersItemMqWorkerProducerType: any;
export interface PurgeStartResponseProducersItemMqWorkerProducer {
    type?: PurgeStartResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export declare const PurgeStartResponseProducersItemMqWorkerProducer: S.Schema<PurgeStartResponseProducersItemMqWorkerProducer>;
export type PurgeStartResponseProducersItemMqR2ProducerType = "r2_bucket";
export declare const PurgeStartResponseProducersItemMqR2ProducerType: any;
export interface PurgeStartResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: PurgeStartResponseProducersItemMqR2ProducerType | null;
}
export declare const PurgeStartResponseProducersItemMqR2Producer: S.Schema<PurgeStartResponseProducersItemMqR2Producer>;
export type PurgeStartResponseProducersItem = PurgeStartResponseProducersItemMqWorkerProducer | PurgeStartResponseProducersItemMqR2Producer;
export declare const PurgeStartResponseProducersItem: any;
export type PurgeStartResponseProducersList = Array<PurgeStartResponseProducersItem>;
export declare const PurgeStartResponseProducersList: S.Schema<PurgeStartResponseProducersList>;
export type PurgeStartResponseSettings = CreateResponseSettings;
export declare const PurgeStartResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface StartPurgeResponse {
    consumers?: PurgeStartResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    modifiedOn?: string | null;
    producers?: PurgeStartResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export declare const StartPurgeResponse: S.Schema<StartPurgeResponse>;
export type ConsumersUpdateRequestType = "worker" | "http_pull";
export declare const ConsumersUpdateRequestType: any;
export type ConsumersUpdateRequestSettingsWorker = ConsumersCreateRequestSettingsWorker;
export declare const ConsumersUpdateRequestSettingsWorker: S.Schema<ConsumersCreateRequestSettingsWorker>;
export type ConsumersUpdateRequestSettingsHTTPPull = ConsumersCreateRequestSettingsHTTPPull;
export declare const ConsumersUpdateRequestSettingsHTTPPull: S.Schema<ConsumersCreateRequestSettingsHTTPPull>;
export type ConsumersUpdateRequestSettings = ConsumersCreateRequestSettingsWorker | ConsumersCreateRequestSettingsHTTPPull;
export declare const ConsumersUpdateRequestSettings: any;
export interface UpdateConsumerRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    /** A Resource identifier. */
    consumerId: string;
    /** Name of a Worker */
    scriptName?: string;
    type: ConsumersUpdateRequestType | (string & {});
    deadLetterQueue?: string;
    settings?: ConsumersUpdateRequestSettings;
}
export declare const UpdateConsumerRequest: S.Schema<UpdateConsumerRequest>;
export type ConsumersUpdateResultWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const ConsumersUpdateResultWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type ConsumersUpdateResultWorkerType = "worker";
export declare const ConsumersUpdateResultWorkerType: any;
export interface ConsumersUpdateResultWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: ConsumersUpdateResultWorkerType | null;
}
export declare const ConsumersUpdateResultWorker: S.Schema<ConsumersUpdateResultWorker>;
export type ConsumersUpdateResultHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const ConsumersUpdateResultHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type ConsumersUpdateResultHTTPPullType = "http_pull";
export declare const ConsumersUpdateResultHTTPPullType: any;
export interface ConsumersUpdateResultHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: ConsumersUpdateResultHTTPPullType | null;
}
export declare const ConsumersUpdateResultHTTPPull: S.Schema<ConsumersUpdateResultHTTPPull>;
export type ConsumersUpdateResult = ConsumersUpdateResultWorker | ConsumersUpdateResultHTTPPull;
export declare const ConsumersUpdateResult: any;
export type UpdateConsumerResponse = ConsumersUpdateResult;
export declare const UpdateConsumerResponse: S.Schema<UpdateConsumerResponse>;
export type UpdateRequestSettings = EditRequestSettings;
export declare const UpdateRequestSettings: S.Schema<EditRequestSettings>;
export interface UpdateQueueRequest {
    /** A Resource identifier. */
    accountId: string;
    /** A Resource identifier. */
    queueId: string;
    queueName?: string;
    settings?: EditRequestSettings;
}
export declare const UpdateQueueRequest: S.Schema<UpdateQueueRequest>;
export type UpdateResponseConsumersItemWorkerSettings = ConsumersCreateResultWorkerSettings;
export declare const UpdateResponseConsumersItemWorkerSettings: S.Schema<ConsumersCreateResultWorkerSettings>;
export type UpdateResponseConsumersItemWorkerType = "worker";
export declare const UpdateResponseConsumersItemWorkerType: any;
export interface UpdateResponseConsumersItemWorker {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    /** Name of a Worker */
    scriptName?: string | null;
    settings?: ConsumersCreateResultWorkerSettings | null;
    type?: UpdateResponseConsumersItemWorkerType | null;
}
export declare const UpdateResponseConsumersItemWorker: S.Schema<UpdateResponseConsumersItemWorker>;
export type UpdateResponseConsumersItemHTTPPullSettings = ConsumersCreateResultHTTPPullSettings;
export declare const UpdateResponseConsumersItemHTTPPullSettings: S.Schema<ConsumersCreateResultHTTPPullSettings>;
export type UpdateResponseConsumersItemHTTPPullType = "http_pull";
export declare const UpdateResponseConsumersItemHTTPPullType: any;
export interface UpdateResponseConsumersItemHTTPPull {
    /** A Resource identifier. */
    consumerId?: string | null;
    createdOn?: string | null;
    /** Name of the dead letter queue, or empty string if not configured */
    deadLetterQueue?: string | null;
    queueName?: string | null;
    settings?: ConsumersCreateResultHTTPPullSettings | null;
    type?: UpdateResponseConsumersItemHTTPPullType | null;
}
export declare const UpdateResponseConsumersItemHTTPPull: S.Schema<UpdateResponseConsumersItemHTTPPull>;
export type UpdateResponseConsumersItem = UpdateResponseConsumersItemWorker | UpdateResponseConsumersItemHTTPPull;
export declare const UpdateResponseConsumersItem: any;
export type UpdateResponseConsumersList = Array<UpdateResponseConsumersItem>;
export declare const UpdateResponseConsumersList: S.Schema<UpdateResponseConsumersList>;
export type UpdateResponseProducersItemMqWorkerProducerType = "worker";
export declare const UpdateResponseProducersItemMqWorkerProducerType: any;
export interface UpdateResponseProducersItemMqWorkerProducer {
    type?: UpdateResponseProducersItemMqWorkerProducerType | null;
    scriptName?: string | null;
}
export declare const UpdateResponseProducersItemMqWorkerProducer: S.Schema<UpdateResponseProducersItemMqWorkerProducer>;
export type UpdateResponseProducersItemMqR2ProducerType = "r2_bucket";
export declare const UpdateResponseProducersItemMqR2ProducerType: any;
export interface UpdateResponseProducersItemMqR2Producer {
    bucketName?: string | null;
    type?: UpdateResponseProducersItemMqR2ProducerType | null;
}
export declare const UpdateResponseProducersItemMqR2Producer: S.Schema<UpdateResponseProducersItemMqR2Producer>;
export type UpdateResponseProducersItem = UpdateResponseProducersItemMqWorkerProducer | UpdateResponseProducersItemMqR2Producer;
export declare const UpdateResponseProducersItem: any;
export type UpdateResponseProducersList = Array<UpdateResponseProducersItem>;
export declare const UpdateResponseProducersList: S.Schema<UpdateResponseProducersList>;
export type UpdateResponseSettings = CreateResponseSettings;
export declare const UpdateResponseSettings: S.Schema<CreateResponseSettings>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateQueueResponse {
    consumers?: UpdateResponseConsumersList | null;
    consumersTotalCount?: number | null;
    createdOn?: string | null;
    modifiedOn?: string | null;
    producers?: UpdateResponseProducersList | null;
    producersTotalCount?: number | null;
    queueId?: string | null;
    queueName?: string | null;
    settings?: CreateResponseSettings | null;
}
export declare const UpdateQueueResponse: S.Schema<UpdateQueueResponse>;
export type AckMessageError = InvalidRequestBody | InvalidQueueId | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Acknowledge + Retry messages from a Queue */
export declare const ackMessage: API.OperationMethod<AckMessageRequest, AckMessageResponse, AckMessageError, CloudflareOpContext>;
export type BulkPushMessagesError = InvalidMessageBody | InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Push a batch of message to a Queue */
export declare const bulkPushMessages: API.OperationMethod<BulkPushMessagesRequest, BulkPushMessagesResponse, BulkPushMessagesError, CloudflareOpContext>;
export type CreateConsumerError = InvalidRequestBody | QueueNotFound | QueueHandlerMissing | ConsumerAlreadyExists | WorkerNotFound | InvalidRoute | CloudflareOpError;
/** Creates a new consumer for a Queue */
export declare const createConsumer: API.OperationMethod<CreateConsumerRequest, CreateConsumerResponse, CreateConsumerError, CloudflareOpContext>;
export type CreateQueueError = QueueAlreadyExists | InvalidQueueName | InvalidRoute | CloudflareOpError;
/** Create a new queue */
export declare const createQueue: API.OperationMethod<CreateQueueRequest, CreateQueueResponse, CreateQueueError, CloudflareOpContext>;
export type CreateSubscriptionError = UnrecognizedEventType | SubscriptionAlreadyExists | QueueNotFound | CloudflareOpError;
/** Create a new event subscription for a queue */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type DeleteConsumerError = InvalidRequestBody | QueueNotFound | ConsumerNotFound | InvalidRoute | CloudflareOpError;
/** Deletes the consumer for a queue. */
export declare const deleteConsumer: API.OperationMethod<DeleteConsumerRequest, DeleteConsumerResponse, DeleteConsumerError, CloudflareOpContext>;
export type DeleteQueueError = QueueNotFound | QueueInUseByEventNotification | InvalidRoute | QueueInUseByWorkerBinding | CloudflareOpError;
/** Deletes a queue */
export declare const deleteQueue: API.OperationMethod<DeleteQueueRequest, DeleteQueueResponse, DeleteQueueError, CloudflareOpContext>;
export type DeleteSubscriptionError = UnrecognizedEventType | SubscriptionNotFound | CloudflareOpError;
/** Delete an existing event subscription */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type GetConsumerError = InvalidRequestBody | QueueNotFound | ConsumerNotFound | InvalidRoute | CloudflareOpError;
/** Fetches the consumer for a queue by consumer id */
export declare const getConsumer: API.OperationMethod<GetConsumerRequest, GetConsumerResponse, GetConsumerError, CloudflareOpContext>;
export type GetMetricsQueueError = CloudflareOpError;
/** Return best-effort metrics for a queue. Values may be approximate due to the distributed nature of queues. */
export declare const getMetricsQueue: API.OperationMethod<GetMetricsQueueRequest, GetMetricsQueueResponse, GetMetricsQueueError, CloudflareOpContext>;
export type GetQueueError = QueueNotFound | InvalidRoute | CloudflareOpError;
/** Get details about a specific queue. */
export declare const getQueue: API.OperationMethod<GetQueueRequest, GetQueueResponse, GetQueueError, CloudflareOpContext>;
export type GetSubscriptionError = UnrecognizedEventType | SubscriptionNotFound | Forbidden | CloudflareOpError;
/** Get details about an existing event subscription */
export declare const getSubscription: API.OperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext>;
export type ListConsumersError = InvalidRequestBody | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Returns the consumers for a Queue */
export declare const listConsumers: API.PaginatedOperationMethod<ListConsumersRequest, ListConsumersResponse, ListConsumersError, CloudflareOpContext, ConsumersListResultItem>;
export type ListQueuesError = InvalidRoute | CloudflareOpError;
/** Returns the queues owned by an account. */
export declare const listQueues: API.PaginatedOperationMethod<ListQueuesRequest, ListQueuesResponse, ListQueuesError, CloudflareOpContext, ListResultItem>;
export type ListSubscriptionsError = Forbidden | CloudflareOpError;
/** Get a paginated list of event subscriptions with optional sorting and filtering */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsRequest, ListSubscriptionsResponse, ListSubscriptionsError, CloudflareOpContext, SubscriptionsListResultItem>;
export type PatchQueueError = QueueNotFound | InvalidRoute | CloudflareOpError;
/** Updates a Queue. */
export declare const patchQueue: API.OperationMethod<PatchQueueRequest, PatchQueueResponse, PatchQueueError, CloudflareOpContext>;
export type PatchSubscriptionError = UnrecognizedEventType | SubscriptionNotFound | QueueNotFound | CloudflareOpError;
/** Update an existing event subscription */
export declare const patchSubscription: API.OperationMethod<PatchSubscriptionRequest, PatchSubscriptionResponse, PatchSubscriptionError, CloudflareOpContext>;
export type PullMessageError = InvalidRequestBody | InvalidQueueId | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Pull a batch of messages from a Queue */
export declare const pullMessage: API.OperationMethod<PullMessageRequest, PullMessageResponse, PullMessageError, CloudflareOpContext>;
export type PurgeStatusError = InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Get details about a Queue's purge status. */
export declare const purgeStatus: API.OperationMethod<PurgeStatusRequest, PurgeStatusResponse, PurgeStatusError, CloudflareOpContext>;
export type PushMessageError = InvalidMessageBody | InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Push a message to a Queue */
export declare const pushMessage: API.OperationMethod<PushMessageRequest, PushMessageResponse, PushMessageError, CloudflareOpContext>;
export type StartPurgeError = InvalidQueueId | InvalidRoute | CloudflareOpError;
/** Deletes all messages from the Queue. */
export declare const startPurge: API.OperationMethod<StartPurgeRequest, StartPurgeResponse, StartPurgeError, CloudflareOpContext>;
export type UpdateConsumerError = InvalidRequestBody | QueueNotFound | QueueHandlerMissing | ConsumerNotFound | WorkerNotFound | InvalidRoute | CloudflareOpError;
/** Updates the consumer for a queue, or creates one if it does not exist. */
export declare const updateConsumer: API.OperationMethod<UpdateConsumerRequest, UpdateConsumerResponse, UpdateConsumerError, CloudflareOpContext>;
export type UpdateQueueError = InvalidQueueName | QueueNotFound | InvalidRoute | CloudflareOpError;
/** Updates a Queue. Note that this endpoint does not support partial updates. If successful, the Queue's configuration is overwritten with the supplied configuration. */
export declare const updateQueue: API.OperationMethod<UpdateQueueRequest, UpdateQueueResponse, UpdateQueueError, CloudflareOpContext>;
//# sourceMappingURL=queues.d.ts.map