import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AccessRuleNotFound_base: S.Class<AccessRuleNotFound, S.TaggedStruct<"AccessRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AccessRuleNotFound extends /*@__PURE__*/ AccessRuleNotFound_base {
}
declare const DuplicateAccessRule_base: S.Class<DuplicateAccessRule, S.TaggedStruct<"DuplicateAccessRule", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicateAccessRule extends /*@__PURE__*/ DuplicateAccessRule_base {
}
declare const DuplicateLockdown_base: S.Class<DuplicateLockdown, S.TaggedStruct<"DuplicateLockdown", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicateLockdown extends /*@__PURE__*/ DuplicateLockdown_base {
}
declare const DuplicateUaRule_base: S.Class<DuplicateUaRule, S.TaggedStruct<"DuplicateUaRule", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class DuplicateUaRule extends /*@__PURE__*/ DuplicateUaRule_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const LockdownNotFound_base: S.Class<LockdownNotFound, S.TaggedStruct<"LockdownNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class LockdownNotFound extends /*@__PURE__*/ LockdownNotFound_base {
}
declare const UaRuleNotFound_base: S.Class<UaRuleNotFound, S.TaggedStruct<"UaRuleNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class UaRuleNotFound extends /*@__PURE__*/ UaRuleNotFound_base {
}
export interface BulkDeleteRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const BulkDeleteRulesRequest: S.Schema<BulkDeleteRulesRequest>;
export type RulesBulkDeleteResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesBulkDeleteResultItemAction: any;
export interface RulesBulkDeleteResultItemFilterFirewallFilter {
    /** The unique identifier of the filter. */
    id?: string | null;
    /** An informative summary of the filter. */
    description?: string | null;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string | null;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean | null;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string | null;
}
export declare const RulesBulkDeleteResultItemFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export interface RulesBulkDeleteResultItemFilterDeletedFilter {
    /** The unique identifier of the filter. */
    id: string;
    /** When true, indicates that the firewall rule was deleted. */
    deleted: boolean;
}
export declare const RulesBulkDeleteResultItemFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesBulkDeleteResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesBulkDeleteResultItemFilter: any;
export type RulesBulkDeleteResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesBulkDeleteResultItemProductsItem: any;
export type RulesBulkDeleteResultItemProductsList = Array<RulesBulkDeleteResultItemProductsItem>;
export declare const RulesBulkDeleteResultItemProductsList: S.Schema<RulesBulkDeleteResultItemProductsList>;
export interface RulesBulkDeleteResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesBulkDeleteResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesBulkDeleteResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesBulkDeleteResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const RulesBulkDeleteResultItem: S.Schema<RulesBulkDeleteResultItem>;
export type RulesBulkDeleteResultList = Array<RulesBulkDeleteResultItem>;
export declare const RulesBulkDeleteResultList: S.Schema<RulesBulkDeleteResultList>;
export interface BulkDeleteRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkDeleteRulesResponse: S.Schema<BulkDeleteRulesResponse>;
export interface BulkPatchRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const BulkPatchRulesRequest: S.Schema<BulkPatchRulesRequest>;
export type RulesBulkEditResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesBulkEditResultItemAction: any;
export type RulesBulkEditResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesBulkEditResultItemFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesBulkEditResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesBulkEditResultItemFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesBulkEditResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesBulkEditResultItemFilter: any;
export type RulesBulkEditResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesBulkEditResultItemProductsItem: any;
export type RulesBulkEditResultItemProductsList = Array<RulesBulkEditResultItemProductsItem>;
export declare const RulesBulkEditResultItemProductsList: S.Schema<RulesBulkEditResultItemProductsList>;
export interface RulesBulkEditResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesBulkEditResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesBulkEditResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesBulkEditResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const RulesBulkEditResultItem: S.Schema<RulesBulkEditResultItem>;
export type RulesBulkEditResultList = Array<RulesBulkEditResultItem>;
export declare const RulesBulkEditResultList: S.Schema<RulesBulkEditResultList>;
export interface BulkPatchRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkPatchRulesResponse: S.Schema<BulkPatchRulesResponse>;
export interface BulkPutRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const BulkPutRulesRequest: S.Schema<BulkPutRulesRequest>;
export type RulesBulkUpdateResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesBulkUpdateResultItemAction: any;
export type RulesBulkUpdateResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesBulkUpdateResultItemFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesBulkUpdateResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesBulkUpdateResultItemFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesBulkUpdateResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesBulkUpdateResultItemFilter: any;
export type RulesBulkUpdateResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesBulkUpdateResultItemProductsItem: any;
export type RulesBulkUpdateResultItemProductsList = Array<RulesBulkUpdateResultItemProductsItem>;
export declare const RulesBulkUpdateResultItemProductsList: S.Schema<RulesBulkUpdateResultItemProductsList>;
export interface RulesBulkUpdateResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesBulkUpdateResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesBulkUpdateResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesBulkUpdateResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const RulesBulkUpdateResultItem: S.Schema<RulesBulkUpdateResultItem>;
export type RulesBulkUpdateResultList = Array<RulesBulkUpdateResultItem>;
export declare const RulesBulkUpdateResultList: S.Schema<RulesBulkUpdateResultList>;
export interface BulkPutRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesBulkUpdateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const BulkPutRulesResponse: S.Schema<BulkPutRulesResponse>;
export type AccessRulesCreateRequestConfigurationAccessRuleIPConfigurationTarget = "ip";
export declare const AccessRulesCreateRequestConfigurationAccessRuleIPConfigurationTarget: any;
export interface AccessRulesCreateRequestConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesCreateRequestConfigurationAccessRuleIPConfigurationTarget | (string & {});
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string;
}
export declare const AccessRulesCreateRequestConfigurationAccessRuleIPConfiguration: S.Schema<AccessRulesCreateRequestConfigurationAccessRuleIPConfiguration>;
export type AccessRulesCreateRequestConfigurationIPV6ConfigurationTarget = "ip6";
export declare const AccessRulesCreateRequestConfigurationIPV6ConfigurationTarget: any;
export interface AccessRulesCreateRequestConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesCreateRequestConfigurationIPV6ConfigurationTarget | (string & {});
    /** The IPv6 address to match. */
    value?: string;
}
export declare const AccessRulesCreateRequestConfigurationIPV6Configuration: S.Schema<AccessRulesCreateRequestConfigurationIPV6Configuration>;
export type AccessRulesCreateRequestConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export declare const AccessRulesCreateRequestConfigurationAccessRuleCIDRConfigurationTarget: any;
export interface AccessRulesCreateRequestConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesCreateRequestConfigurationAccessRuleCIDRConfigurationTarget | (string & {});
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string;
}
export declare const AccessRulesCreateRequestConfigurationAccessRuleCIDRConfiguration: S.Schema<AccessRulesCreateRequestConfigurationAccessRuleCIDRConfiguration>;
export type AccessRulesCreateRequestConfigurationASNConfigurationTarget = "asn";
export declare const AccessRulesCreateRequestConfigurationASNConfigurationTarget: any;
export interface AccessRulesCreateRequestConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesCreateRequestConfigurationASNConfigurationTarget | (string & {});
    /** The AS number to match. */
    value?: string;
}
export declare const AccessRulesCreateRequestConfigurationASNConfiguration: S.Schema<AccessRulesCreateRequestConfigurationASNConfiguration>;
export type AccessRulesCreateRequestConfigurationCountryConfigurationTarget = "country";
export declare const AccessRulesCreateRequestConfigurationCountryConfigurationTarget: any;
export interface AccessRulesCreateRequestConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesCreateRequestConfigurationCountryConfigurationTarget | (string & {});
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string;
}
export declare const AccessRulesCreateRequestConfigurationCountryConfiguration: S.Schema<AccessRulesCreateRequestConfigurationCountryConfiguration>;
export type AccessRulesCreateRequestConfiguration = AccessRulesCreateRequestConfigurationAccessRuleIPConfiguration | AccessRulesCreateRequestConfigurationIPV6Configuration | AccessRulesCreateRequestConfigurationAccessRuleCIDRConfiguration | AccessRulesCreateRequestConfigurationASNConfiguration | AccessRulesCreateRequestConfigurationCountryConfiguration;
export declare const AccessRulesCreateRequestConfiguration: any;
export type AccessRulesCreateRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesCreateRequestMode: any;
export interface CreateAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** The rule configuration. */
    configuration: AccessRulesCreateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesCreateRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export declare const CreateAccessRuleForAccountRequest: S.Schema<CreateAccessRuleForAccountRequest>;
export type AccessRulesCreateResponseAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesCreateResponseAllowedModesItem: any;
export type AccessRulesCreateResponseAllowedModesList = Array<AccessRulesCreateResponseAllowedModesItem>;
export declare const AccessRulesCreateResponseAllowedModesList: S.Schema<AccessRulesCreateResponseAllowedModesList>;
export type AccessRulesCreateResponseConfigurationAccessRuleIPConfigurationTarget = "ip";
export declare const AccessRulesCreateResponseConfigurationAccessRuleIPConfigurationTarget: any;
export interface AccessRulesCreateResponseConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesCreateResponseConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export declare const AccessRulesCreateResponseConfigurationAccessRuleIPConfiguration: S.Schema<AccessRulesCreateResponseConfigurationAccessRuleIPConfiguration>;
export type AccessRulesCreateResponseConfigurationIPV6ConfigurationTarget = "ip6";
export declare const AccessRulesCreateResponseConfigurationIPV6ConfigurationTarget: any;
export interface AccessRulesCreateResponseConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesCreateResponseConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export declare const AccessRulesCreateResponseConfigurationIPV6Configuration: S.Schema<AccessRulesCreateResponseConfigurationIPV6Configuration>;
export type AccessRulesCreateResponseConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export declare const AccessRulesCreateResponseConfigurationAccessRuleCIDRConfigurationTarget: any;
export interface AccessRulesCreateResponseConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesCreateResponseConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export declare const AccessRulesCreateResponseConfigurationAccessRuleCIDRConfiguration: S.Schema<AccessRulesCreateResponseConfigurationAccessRuleCIDRConfiguration>;
export type AccessRulesCreateResponseConfigurationASNConfigurationTarget = "asn";
export declare const AccessRulesCreateResponseConfigurationASNConfigurationTarget: any;
export interface AccessRulesCreateResponseConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesCreateResponseConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export declare const AccessRulesCreateResponseConfigurationASNConfiguration: S.Schema<AccessRulesCreateResponseConfigurationASNConfiguration>;
export type AccessRulesCreateResponseConfigurationCountryConfigurationTarget = "country";
export declare const AccessRulesCreateResponseConfigurationCountryConfigurationTarget: any;
export interface AccessRulesCreateResponseConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesCreateResponseConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export declare const AccessRulesCreateResponseConfigurationCountryConfiguration: S.Schema<AccessRulesCreateResponseConfigurationCountryConfiguration>;
export type AccessRulesCreateResponseConfiguration = AccessRulesCreateResponseConfigurationAccessRuleIPConfiguration | AccessRulesCreateResponseConfigurationIPV6Configuration | AccessRulesCreateResponseConfigurationAccessRuleCIDRConfiguration | AccessRulesCreateResponseConfigurationASNConfiguration | AccessRulesCreateResponseConfigurationCountryConfiguration;
export declare const AccessRulesCreateResponseConfiguration: any;
export type AccessRulesCreateResponseMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesCreateResponseMode: any;
export type AccessRulesCreateResponseScopeType = "user" | "organization";
export declare const AccessRulesCreateResponseScopeType: any;
export interface AccessRulesCreateResponseScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesCreateResponseScopeType | null;
}
export declare const AccessRulesCreateResponseScope: S.Schema<AccessRulesCreateResponseScope>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccessRuleResponse {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesCreateResponseAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesCreateResponseConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesCreateResponseMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesCreateResponseScope | null;
}
export declare const CreateAccessRuleResponse: S.Schema<CreateAccessRuleResponse>;
export interface CreateAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** The rule configuration. */
    configuration: AccessRulesCreateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesCreateRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export declare const CreateAccessRuleForZoneRequest: S.Schema<CreateAccessRuleForZoneRequest>;
export type LockdownsCreateRequestConfigurationsLockdownIPConfigurationTarget = "ip";
export declare const LockdownsCreateRequestConfigurationsLockdownIPConfigurationTarget: any;
export interface LockdownsCreateRequestConfigurationsLockdownIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the Zone Lockdown rule. */
    target?: LockdownsCreateRequestConfigurationsLockdownIPConfigurationTarget | (string & {}) | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export declare const LockdownsCreateRequestConfigurationsLockdownIPConfiguration: S.Schema<LockdownsCreateRequestConfigurationsLockdownIPConfiguration>;
export type LockdownsCreateRequestConfigurationsLockdownCIDRConfigurationTarget = "ip_range";
export declare const LockdownsCreateRequestConfigurationsLockdownCIDRConfigurationTarget: any;
export interface LockdownsCreateRequestConfigurationsLockdownCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the Zone Lockdown rule. */
    target?: LockdownsCreateRequestConfigurationsLockdownCIDRConfigurationTarget | (string & {}) | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24`. */
    value?: string | null;
}
export declare const LockdownsCreateRequestConfigurationsLockdownCIDRConfiguration: S.Schema<LockdownsCreateRequestConfigurationsLockdownCIDRConfiguration>;
export type LockdownsCreateRequestConfigurations = LockdownsCreateRequestConfigurationsLockdownIPConfiguration | LockdownsCreateRequestConfigurationsLockdownCIDRConfiguration;
export declare const LockdownsCreateRequestConfigurations: any;
export type LockdownConfigurationsList = Array<LockdownsCreateRequestConfigurations>;
export declare const LockdownConfigurationsList: S.Schema<LockdownConfigurationsList>;
export type LockdownsCreateRequestUrlsList = Array<string>;
export declare const LockdownsCreateRequestUrlsList: S.Schema<LockdownsCreateRequestUrlsList>;
export interface CreateLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsCreateRequestUrlsList;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
    /** The priority of the rule to control the processing order. A lower number indicates higher priority. If not provided, any rules with a configured priority will be processed before rules without a priority. */
    priority?: number;
}
export declare const CreateLockdownRequest: S.Schema<CreateLockdownRequest>;
export type LockdownsCreateResponseUrlsList = Array<string>;
export declare const LockdownsCreateResponseUrlsList: S.Schema<LockdownsCreateResponseUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsCreateResponseUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export declare const CreateLockdownResponse: S.Schema<CreateLockdownResponse>;
export type RulesCreateRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const RulesCreateRequestActionMode: any;
export interface RulesCreateRequestActionResponse {
    /** The response body to return. The value must conform to the configured content type. */
    body?: string;
    /** The content type of the body. Must be one of the following: `text/plain`, `text/xml`, or `application/json`. */
    contentType?: string;
}
export declare const RulesCreateRequestActionResponse: S.Schema<RulesCreateRequestActionResponse>;
export interface RulesCreateRequestAction {
    /** The action to perform. */
    mode?: RulesCreateRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: RulesCreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number;
}
export declare const RulesCreateRequestAction: S.Schema<RulesCreateRequestAction>;
export interface RulesCreateRequestFilter {
    /** The unique identifier of the filter. */
    id?: string;
    /** An informative summary of the filter. */
    description?: string;
    /** The filter expression. For more information, refer to [Expressions](https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/). */
    expression?: string;
    /** When true, indicates that the filter is currently paused. */
    paused?: boolean;
    /** A short reference tag. Allows you to select related filters. */
    ref?: string;
}
export declare const RulesCreateRequestFilter: S.Schema<RulesCreateRequestFilter>;
export interface CreateRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: RulesCreateRequestAction;
    filter: RulesCreateRequestFilter;
}
export declare const CreateRuleRequest: S.Schema<CreateRuleRequest>;
export type RulesCreateResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesCreateResultItemAction: any;
export type RulesCreateResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesCreateResultItemFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesCreateResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesCreateResultItemFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesCreateResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesCreateResultItemFilter: any;
export type RulesCreateResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesCreateResultItemProductsItem: any;
export type RulesCreateResultItemProductsList = Array<RulesCreateResultItemProductsItem>;
export declare const RulesCreateResultItemProductsList: S.Schema<RulesCreateResultItemProductsList>;
export interface RulesCreateResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesCreateResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesCreateResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesCreateResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const RulesCreateResultItem: S.Schema<RulesCreateResultItem>;
export type RulesCreateResultList = Array<RulesCreateResultItem>;
export declare const RulesCreateResultList: S.Schema<RulesCreateResultList>;
export interface CreateRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreateRuleResponse: S.Schema<CreateRuleResponse>;
export type UaRulesCreateRequestConfigurationTarget = "ua";
export declare const UaRulesCreateRequestConfigurationTarget: any;
export interface UaRulesCreateRequestConfiguration {
    /** The configuration target. You must set the target to `ua` when specifying a user agent in the rule. */
    target?: UaRulesCreateRequestConfigurationTarget | (string & {});
    /** the user agent to exactly match */
    value?: string;
}
export declare const UaRulesCreateRequestConfiguration: S.Schema<UaRulesCreateRequestConfiguration>;
export type UaRulesCreateRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const UaRulesCreateRequestMode: any;
export interface CreateUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    configuration: UaRulesCreateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: UaRulesCreateRequestMode | (string & {});
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
}
export declare const CreateUaRuleRequest: S.Schema<CreateUaRuleRequest>;
export interface UaRulesCreateResponseConfiguration {
    /** The configuration target for this rule. You must set the target to `ua` for User Agent Blocking rules. */
    target?: string | null;
    /** The exact user agent string to match. This value will be compared to the received `User-Agent` HTTP header value. */
    value?: string | null;
}
export declare const UaRulesCreateResponseConfiguration: S.Schema<UaRulesCreateResponseConfiguration>;
export type UaRulesCreateResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
export declare const UaRulesCreateResponseMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesCreateResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export declare const CreateUaRuleResponse: S.Schema<CreateUaRuleResponse>;
export type WafOverridesCreateRequestUrlsList = Array<string>;
export declare const WafOverridesCreateRequestUrlsList: S.Schema<WafOverridesCreateRequestUrlsList>;
export interface CreateWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: WafOverridesCreateRequestUrlsList;
}
export declare const CreateWafOverrideRequest: S.Schema<CreateWafOverrideRequest>;
export type WafOverridesCreateResponseGroupsMap = {
    [key: string]: unknown | undefined;
};
export declare const WafOverridesCreateResponseGroupsMap: S.Schema<WafOverridesCreateResponseGroupsMap>;
export type WafOverridesCreateResponseRewriteActionBlock = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesCreateResponseRewriteActionBlock: any;
export type WafOverridesCreateResponseRewriteActionChallenge = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesCreateResponseRewriteActionChallenge: any;
export type WafOverridesCreateResponseRewriteActionDefault = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesCreateResponseRewriteActionDefault: any;
export type WafOverridesCreateResponseRewriteActionDisable = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesCreateResponseRewriteActionDisable: any;
export type WafOverridesCreateResponseRewriteActionSimulate = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesCreateResponseRewriteActionSimulate: any;
export interface WafOverridesCreateResponseRewriteAction {
    /** The WAF rule action to apply. */
    block?: WafOverridesCreateResponseRewriteActionBlock | null;
    /** The WAF rule action to apply. */
    challenge?: WafOverridesCreateResponseRewriteActionChallenge | null;
    /** The WAF rule action to apply. */
    default?: WafOverridesCreateResponseRewriteActionDefault | null;
    /** The WAF rule action to apply. */
    disable?: WafOverridesCreateResponseRewriteActionDisable | null;
    /** The WAF rule action to apply. */
    simulate?: WafOverridesCreateResponseRewriteActionSimulate | null;
}
export declare const WafOverridesCreateResponseRewriteAction: S.Schema<WafOverridesCreateResponseRewriteAction>;
export type WafOverridesCreateResponseRules = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesCreateResponseRules: any;
export type WafOverridesCreateResponseUrlsList = Array<string>;
export declare const WafOverridesCreateResponseUrlsList: S.Schema<WafOverridesCreateResponseUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateWafOverrideResponse {
    /** The unique identifier of the WAF override. */
    id?: string | null;
    /** An informative summary of the current URI-based WAF override. */
    description?: string | null;
    /** An object that allows you to enable or disable WAF rule groups for the current WAF override. Each key of this object must be the ID of a WAF rule group, and each value must be a valid WAF action (usually `default` or `disable`). When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    groups?: WafOverridesCreateResponseGroupsMap | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
    /** The relative priority of the current URI-based WAF override when multiple overrides match a single URL. A lower number indicates higher priority. Higher priority overrides may overwrite values set by lower priority overrides. */
    priority?: number | null;
    /** Specifies that, when a WAF rule matches, its configured action will be replaced by the action configured in this object. */
    rewriteAction?: WafOverridesCreateResponseRewriteAction | null;
    /** An object that allows you to override the action of specific WAF rules. Each key of this object must be the ID of a WAF rule, and each value must be a valid WAF action. Unless you are disabling a rule, ensure that you also enable the rule group that this WAF rule belongs to. When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    rules?: WafOverridesCreateResponseRules | null;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls?: WafOverridesCreateResponseUrlsList | null;
}
export declare const CreateWafOverrideResponse: S.Schema<CreateWafOverrideResponse>;
export interface DeleteAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
export declare const DeleteAccessRuleForAccountRequest: S.Schema<DeleteAccessRuleForAccountRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAccessRuleResponse {
    /** Defines an identifier. */
    id: string;
}
export declare const DeleteAccessRuleResponse: S.Schema<DeleteAccessRuleResponse>;
export interface DeleteAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
export declare const DeleteAccessRuleForZoneRequest: S.Schema<DeleteAccessRuleForZoneRequest>;
export interface DeleteLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the Zone Lockdown rule. */
    lockDownsId: string;
}
export declare const DeleteLockdownRequest: S.Schema<DeleteLockdownRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id?: string | null;
}
export declare const DeleteLockdownResponse: S.Schema<DeleteLockdownResponse>;
export interface DeleteRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
}
export declare const DeleteRuleRequest: S.Schema<DeleteRuleRequest>;
export type RulesDeleteResponseAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesDeleteResponseAction: any;
export type RulesDeleteResponseFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesDeleteResponseFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesDeleteResponseFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesDeleteResponseFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesDeleteResponseFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesDeleteResponseFilter: any;
export type RulesDeleteResponseProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesDeleteResponseProductsItem: any;
export type RulesDeleteResponseProductsList = Array<RulesDeleteResponseProductsItem>;
export declare const RulesDeleteResponseProductsList: S.Schema<RulesDeleteResponseProductsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRuleResponse {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesDeleteResponseAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesDeleteResponseFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesDeleteResponseProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const DeleteRuleResponse: S.Schema<DeleteRuleResponse>;
export interface DeleteUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the User Agent Blocking rule. */
    uaRuleId: string;
}
export declare const DeleteUaRuleRequest: S.Schema<DeleteUaRuleRequest>;
export type UaRulesDeleteResponseConfiguration = UaRulesCreateResponseConfiguration;
export declare const UaRulesDeleteResponseConfiguration: S.Schema<UaRulesCreateResponseConfiguration>;
export type UaRulesDeleteResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
export declare const UaRulesDeleteResponseMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesDeleteResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export declare const DeleteUaRuleResponse: S.Schema<DeleteUaRuleResponse>;
export interface DeleteWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the WAF override. */
    overridesId: string;
}
export declare const DeleteWafOverrideRequest: S.Schema<DeleteWafOverrideRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteWafOverrideResponse {
    /** The unique identifier of the WAF override. */
    id?: string | null;
}
export declare const DeleteWafOverrideResponse: S.Schema<DeleteWafOverrideResponse>;
export interface GetAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
export declare const GetAccessRuleForAccountRequest: S.Schema<GetAccessRuleForAccountRequest>;
export type AccessRulesGetResponseAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesGetResponseAllowedModesItem: any;
export type AccessRulesGetResponseAllowedModesList = Array<AccessRulesGetResponseAllowedModesItem>;
export declare const AccessRulesGetResponseAllowedModesList: S.Schema<AccessRulesGetResponseAllowedModesList>;
export type AccessRulesGetResponseConfigurationAccessRuleIPConfigurationTarget = "ip";
export declare const AccessRulesGetResponseConfigurationAccessRuleIPConfigurationTarget: any;
export interface AccessRulesGetResponseConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesGetResponseConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export declare const AccessRulesGetResponseConfigurationAccessRuleIPConfiguration: S.Schema<AccessRulesGetResponseConfigurationAccessRuleIPConfiguration>;
export type AccessRulesGetResponseConfigurationIPV6ConfigurationTarget = "ip6";
export declare const AccessRulesGetResponseConfigurationIPV6ConfigurationTarget: any;
export interface AccessRulesGetResponseConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesGetResponseConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export declare const AccessRulesGetResponseConfigurationIPV6Configuration: S.Schema<AccessRulesGetResponseConfigurationIPV6Configuration>;
export type AccessRulesGetResponseConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export declare const AccessRulesGetResponseConfigurationAccessRuleCIDRConfigurationTarget: any;
export interface AccessRulesGetResponseConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesGetResponseConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export declare const AccessRulesGetResponseConfigurationAccessRuleCIDRConfiguration: S.Schema<AccessRulesGetResponseConfigurationAccessRuleCIDRConfiguration>;
export type AccessRulesGetResponseConfigurationASNConfigurationTarget = "asn";
export declare const AccessRulesGetResponseConfigurationASNConfigurationTarget: any;
export interface AccessRulesGetResponseConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesGetResponseConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export declare const AccessRulesGetResponseConfigurationASNConfiguration: S.Schema<AccessRulesGetResponseConfigurationASNConfiguration>;
export type AccessRulesGetResponseConfigurationCountryConfigurationTarget = "country";
export declare const AccessRulesGetResponseConfigurationCountryConfigurationTarget: any;
export interface AccessRulesGetResponseConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesGetResponseConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export declare const AccessRulesGetResponseConfigurationCountryConfiguration: S.Schema<AccessRulesGetResponseConfigurationCountryConfiguration>;
export type AccessRulesGetResponseConfiguration = AccessRulesGetResponseConfigurationAccessRuleIPConfiguration | AccessRulesGetResponseConfigurationIPV6Configuration | AccessRulesGetResponseConfigurationAccessRuleCIDRConfiguration | AccessRulesGetResponseConfigurationASNConfiguration | AccessRulesGetResponseConfigurationCountryConfiguration;
export declare const AccessRulesGetResponseConfiguration: any;
export type AccessRulesGetResponseMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesGetResponseMode: any;
export type AccessRulesGetResponseScopeType = "user" | "organization";
export declare const AccessRulesGetResponseScopeType: any;
export interface AccessRulesGetResponseScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesGetResponseScopeType | null;
}
export declare const AccessRulesGetResponseScope: S.Schema<AccessRulesGetResponseScope>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccessRuleResponse {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesGetResponseAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesGetResponseConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesGetResponseMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesGetResponseScope | null;
}
export declare const GetAccessRuleResponse: S.Schema<GetAccessRuleResponse>;
export interface GetAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
}
export declare const GetAccessRuleForZoneRequest: S.Schema<GetAccessRuleForZoneRequest>;
export interface GetLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the Zone Lockdown rule. */
    lockDownsId: string;
}
export declare const GetLockdownRequest: S.Schema<GetLockdownRequest>;
export type LockdownsGetResponseUrlsList = Array<string>;
export declare const LockdownsGetResponseUrlsList: S.Schema<LockdownsGetResponseUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsGetResponseUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export declare const GetLockdownResponse: S.Schema<GetLockdownResponse>;
export interface GetRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
}
export declare const GetRuleRequest: S.Schema<GetRuleRequest>;
export type RulesGetResponseAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesGetResponseAction: any;
export type RulesGetResponseFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesGetResponseFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesGetResponseFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesGetResponseFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesGetResponseFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesGetResponseFilter: any;
export type RulesGetResponseProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesGetResponseProductsItem: any;
export type RulesGetResponseProductsList = Array<RulesGetResponseProductsItem>;
export declare const RulesGetResponseProductsList: S.Schema<RulesGetResponseProductsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRuleResponse {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesGetResponseAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesGetResponseFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesGetResponseProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const GetRuleResponse: S.Schema<GetRuleResponse>;
export interface GetUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the User Agent Blocking rule. */
    uaRuleId: string;
}
export declare const GetUaRuleRequest: S.Schema<GetUaRuleRequest>;
export type UaRulesGetResponseConfiguration = UaRulesCreateResponseConfiguration;
export declare const UaRulesGetResponseConfiguration: S.Schema<UaRulesCreateResponseConfiguration>;
export type UaRulesGetResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
export declare const UaRulesGetResponseMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesGetResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export declare const GetUaRuleResponse: S.Schema<GetUaRuleResponse>;
export interface GetWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the WAF override. */
    overridesId: string;
}
export declare const GetWafOverrideRequest: S.Schema<GetWafOverrideRequest>;
export type WafOverridesGetResponseGroupsMap = {
    [key: string]: unknown | undefined;
};
export declare const WafOverridesGetResponseGroupsMap: S.Schema<WafOverridesGetResponseGroupsMap>;
export type WafOverridesGetResponseRewriteActionBlock = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesGetResponseRewriteActionBlock: any;
export type WafOverridesGetResponseRewriteActionChallenge = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesGetResponseRewriteActionChallenge: any;
export type WafOverridesGetResponseRewriteActionDefault = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesGetResponseRewriteActionDefault: any;
export type WafOverridesGetResponseRewriteActionDisable = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesGetResponseRewriteActionDisable: any;
export type WafOverridesGetResponseRewriteActionSimulate = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesGetResponseRewriteActionSimulate: any;
export interface WafOverridesGetResponseRewriteAction {
    /** The WAF rule action to apply. */
    block?: WafOverridesGetResponseRewriteActionBlock | null;
    /** The WAF rule action to apply. */
    challenge?: WafOverridesGetResponseRewriteActionChallenge | null;
    /** The WAF rule action to apply. */
    default?: WafOverridesGetResponseRewriteActionDefault | null;
    /** The WAF rule action to apply. */
    disable?: WafOverridesGetResponseRewriteActionDisable | null;
    /** The WAF rule action to apply. */
    simulate?: WafOverridesGetResponseRewriteActionSimulate | null;
}
export declare const WafOverridesGetResponseRewriteAction: S.Schema<WafOverridesGetResponseRewriteAction>;
export type WafOverridesGetResponseRules = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesGetResponseRules: any;
export type WafOverridesGetResponseUrlsList = Array<string>;
export declare const WafOverridesGetResponseUrlsList: S.Schema<WafOverridesGetResponseUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetWafOverrideResponse {
    /** The unique identifier of the WAF override. */
    id?: string | null;
    /** An informative summary of the current URI-based WAF override. */
    description?: string | null;
    /** An object that allows you to enable or disable WAF rule groups for the current WAF override. Each key of this object must be the ID of a WAF rule group, and each value must be a valid WAF action (usually `default` or `disable`). When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    groups?: WafOverridesGetResponseGroupsMap | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
    /** The relative priority of the current URI-based WAF override when multiple overrides match a single URL. A lower number indicates higher priority. Higher priority overrides may overwrite values set by lower priority overrides. */
    priority?: number | null;
    /** Specifies that, when a WAF rule matches, its configured action will be replaced by the action configured in this object. */
    rewriteAction?: WafOverridesGetResponseRewriteAction | null;
    /** An object that allows you to override the action of specific WAF rules. Each key of this object must be the ID of a WAF rule, and each value must be a valid WAF action. Unless you are disabling a rule, ensure that you also enable the rule group that this WAF rule belongs to. When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    rules?: WafOverridesGetResponseRules | null;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls?: WafOverridesGetResponseUrlsList | null;
}
export declare const GetWafOverrideResponse: S.Schema<GetWafOverrideResponse>;
export interface GetWafPackageRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** Defines a package identifier. */
    packageId: string;
}
export declare const GetWafPackageRequest: S.Schema<GetWafPackageRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface GetWafPackageResponse {
}
export declare const GetWafPackageResponse: S.Schema<GetWafPackageResponse>;
export interface GetWafPackageGroupRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    groupId: string;
}
export declare const GetWafPackageGroupRequest: S.Schema<GetWafPackageGroupRequest>;
export type GetWafPackageGroupResponse = unknown;
export declare const GetWafPackageGroupResponse: S.Schema<GetWafPackageGroupResponse>;
export interface GetWafPackageRuleRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    ruleId: string;
}
export declare const GetWafPackageRuleRequest: S.Schema<GetWafPackageRuleRequest>;
export type GetWafPackageRuleResponse = unknown;
export declare const GetWafPackageRuleResponse: S.Schema<GetWafPackageRuleResponse>;
export type AccessRulesListRequestConfigurationTarget = "ip" | "ip_range" | "asn" | "country";
export declare const AccessRulesListRequestConfigurationTarget: any;
export interface AccessRulesListRequestConfiguration {
    /** Defines the target to search in existing rules. */
    target?: AccessRulesListRequestConfigurationTarget | (string & {});
    /** Defines the target value to search for in existing rules: an IP address, an IP address range, or a country code, depending on the provided `configuration.target`. */
    value?: string;
}
export declare const AccessRulesListRequestConfiguration: S.Schema<AccessRulesListRequestConfiguration>;
export type AccessRulesListRequestDirection = "asc" | "desc";
export declare const AccessRulesListRequestDirection: any;
export type AccessRulesListRequestMatch = "any" | "all";
export declare const AccessRulesListRequestMatch: any;
export type AccessRulesListRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesListRequestMode: any;
export type AccessRulesListRequestOrder = "configuration.target" | "configuration.value" | "mode";
export declare const AccessRulesListRequestOrder: any;
export interface ListAccessRulesForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    configuration?: AccessRulesListRequestConfiguration;
    /** Defines the direction used to sort returned rules. */
    direction?: AccessRulesListRequestDirection | (string & {});
    /** Defines the search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: AccessRulesListRequestMatch | (string & {});
    /** The action to apply to a matched request. */
    mode?: AccessRulesListRequestMode | (string & {});
    /** Defines the string to search for in the notes of existing IP Access rules. */
    notes?: string;
    /** Defines the field used to sort returned rules. */
    order?: AccessRulesListRequestOrder | (string & {});
    /** Defines the requested page within paginated list of results. */
    page?: number;
    /** Defines the maximum number of results requested. */
    perPage?: number;
}
export declare const ListAccessRulesForAccountRequest: S.Schema<ListAccessRulesForAccountRequest>;
export type AccessRulesListResultItemAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesListResultItemAllowedModesItem: any;
export type AccessRulesListResultItemAllowedModesList = Array<AccessRulesListResultItemAllowedModesItem>;
export declare const AccessRulesListResultItemAllowedModesList: S.Schema<AccessRulesListResultItemAllowedModesList>;
export type AccessRulesListResultItemConfigurationAccessRuleIPConfigurationTarget = "ip";
export declare const AccessRulesListResultItemConfigurationAccessRuleIPConfigurationTarget: any;
export interface AccessRulesListResultItemConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesListResultItemConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export declare const AccessRulesListResultItemConfigurationAccessRuleIPConfiguration: S.Schema<AccessRulesListResultItemConfigurationAccessRuleIPConfiguration>;
export type AccessRulesListResultItemConfigurationIPV6ConfigurationTarget = "ip6";
export declare const AccessRulesListResultItemConfigurationIPV6ConfigurationTarget: any;
export interface AccessRulesListResultItemConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesListResultItemConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export declare const AccessRulesListResultItemConfigurationIPV6Configuration: S.Schema<AccessRulesListResultItemConfigurationIPV6Configuration>;
export type AccessRulesListResultItemConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export declare const AccessRulesListResultItemConfigurationAccessRuleCIDRConfigurationTarget: any;
export interface AccessRulesListResultItemConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesListResultItemConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export declare const AccessRulesListResultItemConfigurationAccessRuleCIDRConfiguration: S.Schema<AccessRulesListResultItemConfigurationAccessRuleCIDRConfiguration>;
export type AccessRulesListResultItemConfigurationASNConfigurationTarget = "asn";
export declare const AccessRulesListResultItemConfigurationASNConfigurationTarget: any;
export interface AccessRulesListResultItemConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesListResultItemConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export declare const AccessRulesListResultItemConfigurationASNConfiguration: S.Schema<AccessRulesListResultItemConfigurationASNConfiguration>;
export type AccessRulesListResultItemConfigurationCountryConfigurationTarget = "country";
export declare const AccessRulesListResultItemConfigurationCountryConfigurationTarget: any;
export interface AccessRulesListResultItemConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesListResultItemConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export declare const AccessRulesListResultItemConfigurationCountryConfiguration: S.Schema<AccessRulesListResultItemConfigurationCountryConfiguration>;
export type AccessRulesListResultItemConfiguration = AccessRulesListResultItemConfigurationAccessRuleIPConfiguration | AccessRulesListResultItemConfigurationIPV6Configuration | AccessRulesListResultItemConfigurationAccessRuleCIDRConfiguration | AccessRulesListResultItemConfigurationASNConfiguration | AccessRulesListResultItemConfigurationCountryConfiguration;
export declare const AccessRulesListResultItemConfiguration: any;
export type AccessRulesListResultItemMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesListResultItemMode: any;
export type AccessRulesListResultItemScopeType = "user" | "organization";
export declare const AccessRulesListResultItemScopeType: any;
export interface AccessRulesListResultItemScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesListResultItemScopeType | null;
}
export declare const AccessRulesListResultItemScope: S.Schema<AccessRulesListResultItemScope>;
export interface AccessRulesListResultItem {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesListResultItemAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesListResultItemConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesListResultItemMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesListResultItemScope | null;
}
export declare const AccessRulesListResultItem: S.Schema<AccessRulesListResultItem>;
export type AccessRulesListResultList = Array<AccessRulesListResultItem>;
export declare const AccessRulesListResultList: S.Schema<AccessRulesListResultList>;
export interface ListAccessRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccessRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAccessRulesResponse: S.Schema<ListAccessRulesResponse>;
export interface ListAccessRulesForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    configuration?: AccessRulesListRequestConfiguration;
    /** Defines the direction used to sort returned rules. */
    direction?: AccessRulesListRequestDirection | (string & {});
    /** Defines the search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: AccessRulesListRequestMatch | (string & {});
    /** The action to apply to a matched request. */
    mode?: AccessRulesListRequestMode | (string & {});
    /** Defines the string to search for in the notes of existing IP Access rules. */
    notes?: string;
    /** Defines the field used to sort returned rules. */
    order?: AccessRulesListRequestOrder | (string & {});
    /** Defines the requested page within paginated list of results. */
    page?: number;
    /** Defines the maximum number of results requested. */
    perPage?: number;
}
export declare const ListAccessRulesForZoneRequest: S.Schema<ListAccessRulesForZoneRequest>;
export interface ListLockdownsRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The timestamp of when the rule was created. */
    createdOn?: string;
    /** A string to search for in the description of existing rules. */
    description?: string;
    /** A string to search for in the description of existing rules. */
    descriptionSearch?: string;
    /** A single IP address to search for in existing rules. */
    ip?: string;
    /** A single IP address range to search for in existing rules. */
    ipRangeSearch?: string;
    /** A single IP address to search for in existing rules. */
    ipSearch?: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string;
    /** Page number of paginated results. */
    page?: number;
    /** The maximum number of results per page. You can only set the value to `1` or to a multiple of 5 such as `5`, `10`, `15`, or `20`. */
    perPage?: number;
    /** The priority of the rule to control the processing order. A lower number indicates higher priority. If not provided, any rules with a configured priority will be processed before rules without a priority. */
    priority?: number;
    /** A single URI to search for in the list of URLs of existing rules. */
    uriSearch?: string;
}
export declare const ListLockdownsRequest: S.Schema<ListLockdownsRequest>;
export type LockdownsListResultItemUrlsList = Array<string>;
export declare const LockdownsListResultItemUrlsList: S.Schema<LockdownsListResultItemUrlsList>;
export interface LockdownsListResultItem {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsListResultItemUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export declare const LockdownsListResultItem: S.Schema<LockdownsListResultItem>;
export type LockdownsListResultList = Array<LockdownsListResultItem>;
export declare const LockdownsListResultList: S.Schema<LockdownsListResultList>;
export interface ListLockdownsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LockdownsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListLockdownsResponse: S.Schema<ListLockdownsResponse>;
export interface ListRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    id?: string;
    /** The action to search for. Must be an exact match. */
    action?: string;
    /** A case-insensitive string to find in the description. */
    description?: string;
    /** Page number of paginated results. */
    page?: number;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean;
    /** Number of firewall rules per page. */
    perPage?: number;
}
export declare const ListRulesRequest: S.Schema<ListRulesRequest>;
export type RulesListResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesListResultItemAction: any;
export type RulesListResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesListResultItemFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesListResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesListResultItemFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesListResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesListResultItemFilter: any;
export type RulesListResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesListResultItemProductsItem: any;
export type RulesListResultItemProductsList = Array<RulesListResultItemProductsItem>;
export declare const RulesListResultItemProductsList: S.Schema<RulesListResultItemProductsList>;
export interface RulesListResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesListResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesListResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesListResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const RulesListResultItem: S.Schema<RulesListResultItem>;
export type RulesListResultList = Array<RulesListResultItem>;
export declare const RulesListResultList: S.Schema<RulesListResultList>;
export interface ListRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRulesResponse: S.Schema<ListRulesResponse>;
export interface ListUaRulesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** A string to search for in the description of existing rules. */
    description?: string;
    /** Page number of paginated results. */
    page?: number;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
    /** The maximum number of results per page. You can only set the value to `1` or to a multiple of 5 such as `5`, `10`, `15`, or `20`. */
    perPage?: number;
    /** A string to search for in the user agent values of existing rules. */
    userAgent?: string;
}
export declare const ListUaRulesRequest: S.Schema<ListUaRulesRequest>;
export type UaRulesListResultItemConfiguration = UaRulesCreateResponseConfiguration;
export declare const UaRulesListResultItemConfiguration: S.Schema<UaRulesCreateResponseConfiguration>;
export type UaRulesListResultItemMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
export declare const UaRulesListResultItemMode: any;
export interface UaRulesListResultItem {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesListResultItemMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export declare const UaRulesListResultItem: S.Schema<UaRulesListResultItem>;
export type UaRulesListResultList = Array<UaRulesListResultItem>;
export declare const UaRulesListResultList: S.Schema<UaRulesListResultList>;
export interface ListUaRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: UaRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListUaRulesResponse: S.Schema<ListUaRulesResponse>;
export interface ListWafOverridesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The page number of paginated results. */
    page?: number;
    /** The number of WAF overrides per page. */
    perPage?: number;
}
export declare const ListWafOverridesRequest: S.Schema<ListWafOverridesRequest>;
export type WafOverridesListResultItemGroupsMap = {
    [key: string]: unknown | undefined;
};
export declare const WafOverridesListResultItemGroupsMap: S.Schema<WafOverridesListResultItemGroupsMap>;
export type WafOverridesListResultItemRewriteActionBlock = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesListResultItemRewriteActionBlock: any;
export type WafOverridesListResultItemRewriteActionChallenge = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesListResultItemRewriteActionChallenge: any;
export type WafOverridesListResultItemRewriteActionDefault = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesListResultItemRewriteActionDefault: any;
export type WafOverridesListResultItemRewriteActionDisable = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesListResultItemRewriteActionDisable: any;
export type WafOverridesListResultItemRewriteActionSimulate = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesListResultItemRewriteActionSimulate: any;
export interface WafOverridesListResultItemRewriteAction {
    /** The WAF rule action to apply. */
    block?: WafOverridesListResultItemRewriteActionBlock | null;
    /** The WAF rule action to apply. */
    challenge?: WafOverridesListResultItemRewriteActionChallenge | null;
    /** The WAF rule action to apply. */
    default?: WafOverridesListResultItemRewriteActionDefault | null;
    /** The WAF rule action to apply. */
    disable?: WafOverridesListResultItemRewriteActionDisable | null;
    /** The WAF rule action to apply. */
    simulate?: WafOverridesListResultItemRewriteActionSimulate | null;
}
export declare const WafOverridesListResultItemRewriteAction: S.Schema<WafOverridesListResultItemRewriteAction>;
export type WafOverridesListResultItemRules = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesListResultItemRules: any;
export type WafOverridesListResultItemUrlsList = Array<string>;
export declare const WafOverridesListResultItemUrlsList: S.Schema<WafOverridesListResultItemUrlsList>;
export interface WafOverridesListResultItem {
    /** The unique identifier of the WAF override. */
    id?: string | null;
    /** An informative summary of the current URI-based WAF override. */
    description?: string | null;
    /** An object that allows you to enable or disable WAF rule groups for the current WAF override. Each key of this object must be the ID of a WAF rule group, and each value must be a valid WAF action (usually `default` or `disable`). When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    groups?: WafOverridesListResultItemGroupsMap | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
    /** The relative priority of the current URI-based WAF override when multiple overrides match a single URL. A lower number indicates higher priority. Higher priority overrides may overwrite values set by lower priority overrides. */
    priority?: number | null;
    /** Specifies that, when a WAF rule matches, its configured action will be replaced by the action configured in this object. */
    rewriteAction?: WafOverridesListResultItemRewriteAction | null;
    /** An object that allows you to override the action of specific WAF rules. Each key of this object must be the ID of a WAF rule, and each value must be a valid WAF action. Unless you are disabling a rule, ensure that you also enable the rule group that this WAF rule belongs to. When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    rules?: WafOverridesListResultItemRules | null;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls?: WafOverridesListResultItemUrlsList | null;
}
export declare const WafOverridesListResultItem: S.Schema<WafOverridesListResultItem>;
export type WafOverridesListResultList = Array<WafOverridesListResultItem>;
export declare const WafOverridesListResultList: S.Schema<WafOverridesListResultList>;
export interface ListWafOverridesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WafOverridesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListWafOverridesResponse: S.Schema<ListWafOverridesResponse>;
export type WafPackagesGroupsListRequestDirection = "asc" | "desc";
export declare const WafPackagesGroupsListRequestDirection: any;
export type WafPackagesGroupsListRequestMatch = "any" | "all";
export declare const WafPackagesGroupsListRequestMatch: any;
export type WafPackagesGroupsListRequestMode = "on" | "off";
export declare const WafPackagesGroupsListRequestMode: any;
export type WafPackagesGroupsListRequestOrder = "mode" | "rules_count";
export declare const WafPackagesGroupsListRequestOrder: any;
export interface ListWafPackageGroupsRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the direction used to sort returned rule groups. */
    direction?: WafPackagesGroupsListRequestDirection | (string & {});
    /** Defines the condition for search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: WafPackagesGroupsListRequestMatch | (string & {});
    /** Defines the state of the rules contained in the rule group. When `on`, the rules in the group are configurable/usable. */
    mode?: WafPackagesGroupsListRequestMode | (string & {});
    /** Defines the name of the rule group. */
    name?: string;
    /** Defines the field used to sort returned rule groups. */
    order?: WafPackagesGroupsListRequestOrder | (string & {});
    /** Defines the page number of paginated results. */
    page?: number;
    /** Defines the number of rule groups per page. */
    perPage?: number;
    /** Defines the number of rules in the current rule group. */
    rulesCount?: number;
}
export declare const ListWafPackageGroupsRequest: S.Schema<ListWafPackageGroupsRequest>;
export type WafPackagesGroupsListResultItemMode = "on" | "off";
export declare const WafPackagesGroupsListResultItemMode: any;
export type WafPackagesGroupsListResultItemAllowedModesItem = "on" | "off";
export declare const WafPackagesGroupsListResultItemAllowedModesItem: any;
export type WafPackagesGroupsListResultItemAllowedModesList = Array<WafPackagesGroupsListResultItemAllowedModesItem>;
export declare const WafPackagesGroupsListResultItemAllowedModesList: S.Schema<WafPackagesGroupsListResultItemAllowedModesList>;
export interface WafPackagesGroupsListResultItem {
    /** Defines the unique identifier of the rule group. */
    id: string;
    /** Defines an informative summary of what the rule group does. */
    description: string;
    /** Defines the state of the rules contained in the rule group. When `on`, the rules in the group are configurable/usable. */
    mode: WafPackagesGroupsListResultItemMode;
    /** Defines the name of the rule group. */
    name: string;
    /** Defines the number of rules in the current rule group. */
    rulesCount: number;
    /** Defines the available states for the rule group. */
    allowedModes?: WafPackagesGroupsListResultItemAllowedModesList | null;
    /** Defines the number of rules within the group that have been modified from their default configuration. */
    modifiedRulesCount?: number | null;
    /** Defines the unique identifier of a WAF package. */
    packageId?: string | null;
}
export declare const WafPackagesGroupsListResultItem: S.Schema<WafPackagesGroupsListResultItem>;
export type WafPackagesGroupsListResultList = Array<WafPackagesGroupsListResultItem>;
export declare const WafPackagesGroupsListResultList: S.Schema<WafPackagesGroupsListResultList>;
export interface ListWafPackageGroupsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WafPackagesGroupsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListWafPackageGroupsResponse: S.Schema<ListWafPackageGroupsResponse>;
export type WafPackagesRulesListRequestDirection = "asc" | "desc";
export declare const WafPackagesRulesListRequestDirection: any;
export type WafPackagesRulesListRequestMatch = "any" | "all";
export declare const WafPackagesRulesListRequestMatch: any;
export type WafPackagesRulesListRequestMode = "DIS" | "CHL" | "BLK" | "SIM";
export declare const WafPackagesRulesListRequestMode: any;
export type WafPackagesRulesListRequestOrder = "priority" | "group_id" | "description";
export declare const WafPackagesRulesListRequestOrder: any;
export interface ListWafPackageRulesRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the public description of the WAF rule. */
    description?: string;
    /** Defines the direction used to sort returned rules. */
    direction?: WafPackagesRulesListRequestDirection | (string & {});
    /** Defines the unique identifier of the rule group. */
    groupId?: string;
    /** Defines the search requirements. When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: WafPackagesRulesListRequestMatch | (string & {});
    /** Defines the action/mode a rule has been overridden to perform. */
    mode?: WafPackagesRulesListRequestMode | (string & {});
    /** Defines the field used to sort returned rules. */
    order?: WafPackagesRulesListRequestOrder | (string & {});
    /** Defines the page number of paginated results. */
    page?: number;
    /** Defines the number of rules per page. */
    perPage?: number;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority?: string;
}
export declare const ListWafPackageRulesRequest: S.Schema<ListWafPackageRulesRequest>;
export type WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesItem = "on" | "off";
export declare const WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesItem: any;
export type WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesList = Array<WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesItem>;
export declare const WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesList: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesList>;
export interface WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup {
    /** Defines the unique identifier of the rule group. */
    id?: string | null;
    /** Defines the name of the rule group. */
    name?: string | null;
}
export declare const WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup>;
export type WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleMode = "on" | "off";
export declare const WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleMode: any;
export interface WafPackagesRulesListResultItemWAFManagedRulesAnomalyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. Applies to anomaly detection WAF rules. */
    allowedModes: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the mode anomaly. When set to `on`, the current WAF rule will be used when evaluating the request. Applies to anomaly detection WAF rules. */
    mode: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export declare const WafPackagesRulesListResultItemWAFManagedRulesAnomalyRule: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesAnomalyRule>;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesItem = "default" | "disable" | "simulate" | "block" | "challenge";
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesItem: any;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesList = Array<WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesItem>;
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesList: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesList>;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleDefaultMode = "disable" | "simulate" | "block" | "challenge";
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleDefaultMode: any;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleMode = "default" | "disable" | "simulate" | "block" | "challenge";
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleMode: any;
export interface WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the list of possible actions of the WAF rule when it is triggered. */
    allowedModes: WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleAllowedModesList;
    /** Defines the default action/mode of a rule. */
    defaultMode: WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleDefaultMode;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the action that the current WAF rule will perform when triggered. Applies to traditional (deny) WAF rules. */
    mode: WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRule: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRule>;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesItem = "on" | "off";
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesItem: any;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesList = Array<WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesItem>;
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesList: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesList>;
export type WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleMode = "on" | "off";
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleMode: any;
export interface WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. */
    allowedModes: WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** When set to `on`, the current rule will be used when evaluating the request. Applies to traditional (allow) WAF rules. */
    mode: WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export declare const WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRule: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRule>;
export type WafPackagesRulesListResultItem = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRule | WafPackagesRulesListResultItemWAFManagedRulesTraditionalDenyRule | WafPackagesRulesListResultItemWAFManagedRulesTraditionalAllowRule;
export declare const WafPackagesRulesListResultItem: any;
export type WafPackagesRulesListResultList = Array<WafPackagesRulesListResultItem>;
export declare const WafPackagesRulesListResultList: S.Schema<WafPackagesRulesListResultList>;
export interface ListWafPackageRulesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: WafPackagesRulesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListWafPackageRulesResponse: S.Schema<ListWafPackageRulesResponse>;
export type WafPackagesListRequestDirection = "asc" | "desc";
export declare const WafPackagesListRequestDirection: any;
export type WafPackagesListRequestMatch = "any" | "all";
export declare const WafPackagesListRequestMatch: any;
export type WafPackagesListRequestOrder = "name";
export declare const WafPackagesListRequestOrder: any;
export interface ListWafPackagesRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The direction used to sort returned packages. */
    direction?: WafPackagesListRequestDirection | (string & {});
    /** When set to `all`, all the search requirements must match. When set to `any`, only one of the search requirements has to match. */
    match?: WafPackagesListRequestMatch | (string & {});
    /** The name of the WAF package. */
    name?: string;
    /** The field used to sort returned packages. */
    order?: WafPackagesListRequestOrder | (string & {});
    /** The page number of paginated results. */
    page?: number;
    /** The number of packages per page. */
    perPage?: number;
}
export declare const ListWafPackagesRequest: S.Schema<ListWafPackagesRequest>;
/** Raw response payload (operation does not use the standard v4 result envelope). */
export interface ListWafPackagesResponse {
}
export declare const ListWafPackagesResponse: S.Schema<ListWafPackagesResponse>;
export type AccessRulesEditRequestConfigurationAccessRuleIPConfigurationTarget = "ip";
export declare const AccessRulesEditRequestConfigurationAccessRuleIPConfigurationTarget: any;
export interface AccessRulesEditRequestConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesEditRequestConfigurationAccessRuleIPConfigurationTarget | (string & {});
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string;
}
export declare const AccessRulesEditRequestConfigurationAccessRuleIPConfiguration: S.Schema<AccessRulesEditRequestConfigurationAccessRuleIPConfiguration>;
export type AccessRulesEditRequestConfigurationIPV6ConfigurationTarget = "ip6";
export declare const AccessRulesEditRequestConfigurationIPV6ConfigurationTarget: any;
export interface AccessRulesEditRequestConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesEditRequestConfigurationIPV6ConfigurationTarget | (string & {});
    /** The IPv6 address to match. */
    value?: string;
}
export declare const AccessRulesEditRequestConfigurationIPV6Configuration: S.Schema<AccessRulesEditRequestConfigurationIPV6Configuration>;
export type AccessRulesEditRequestConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export declare const AccessRulesEditRequestConfigurationAccessRuleCIDRConfigurationTarget: any;
export interface AccessRulesEditRequestConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesEditRequestConfigurationAccessRuleCIDRConfigurationTarget | (string & {});
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string;
}
export declare const AccessRulesEditRequestConfigurationAccessRuleCIDRConfiguration: S.Schema<AccessRulesEditRequestConfigurationAccessRuleCIDRConfiguration>;
export type AccessRulesEditRequestConfigurationASNConfigurationTarget = "asn";
export declare const AccessRulesEditRequestConfigurationASNConfigurationTarget: any;
export interface AccessRulesEditRequestConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesEditRequestConfigurationASNConfigurationTarget | (string & {});
    /** The AS number to match. */
    value?: string;
}
export declare const AccessRulesEditRequestConfigurationASNConfiguration: S.Schema<AccessRulesEditRequestConfigurationASNConfiguration>;
export type AccessRulesEditRequestConfigurationCountryConfigurationTarget = "country";
export declare const AccessRulesEditRequestConfigurationCountryConfigurationTarget: any;
export interface AccessRulesEditRequestConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesEditRequestConfigurationCountryConfigurationTarget | (string & {});
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string;
}
export declare const AccessRulesEditRequestConfigurationCountryConfiguration: S.Schema<AccessRulesEditRequestConfigurationCountryConfiguration>;
export type AccessRulesEditRequestConfiguration = AccessRulesEditRequestConfigurationAccessRuleIPConfiguration | AccessRulesEditRequestConfigurationIPV6Configuration | AccessRulesEditRequestConfigurationAccessRuleCIDRConfiguration | AccessRulesEditRequestConfigurationASNConfiguration | AccessRulesEditRequestConfigurationCountryConfiguration;
export declare const AccessRulesEditRequestConfiguration: any;
export type AccessRulesEditRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesEditRequestMode: any;
export interface PatchAccessRuleForAccountRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
    /** The rule configuration. */
    configuration: AccessRulesEditRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesEditRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export declare const PatchAccessRuleForAccountRequest: S.Schema<PatchAccessRuleForAccountRequest>;
export type AccessRulesEditResponseAllowedModesItem = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesEditResponseAllowedModesItem: any;
export type AccessRulesEditResponseAllowedModesList = Array<AccessRulesEditResponseAllowedModesItem>;
export declare const AccessRulesEditResponseAllowedModesList: S.Schema<AccessRulesEditResponseAllowedModesList>;
export type AccessRulesEditResponseConfigurationAccessRuleIPConfigurationTarget = "ip";
export declare const AccessRulesEditResponseConfigurationAccessRuleIPConfigurationTarget: any;
export interface AccessRulesEditResponseConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: AccessRulesEditResponseConfigurationAccessRuleIPConfigurationTarget | null;
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string | null;
}
export declare const AccessRulesEditResponseConfigurationAccessRuleIPConfiguration: S.Schema<AccessRulesEditResponseConfigurationAccessRuleIPConfiguration>;
export type AccessRulesEditResponseConfigurationIPV6ConfigurationTarget = "ip6";
export declare const AccessRulesEditResponseConfigurationIPV6ConfigurationTarget: any;
export interface AccessRulesEditResponseConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: AccessRulesEditResponseConfigurationIPV6ConfigurationTarget | null;
    /** The IPv6 address to match. */
    value?: string | null;
}
export declare const AccessRulesEditResponseConfigurationIPV6Configuration: S.Schema<AccessRulesEditResponseConfigurationIPV6Configuration>;
export type AccessRulesEditResponseConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export declare const AccessRulesEditResponseConfigurationAccessRuleCIDRConfigurationTarget: any;
export interface AccessRulesEditResponseConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: AccessRulesEditResponseConfigurationAccessRuleCIDRConfigurationTarget | null;
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string | null;
}
export declare const AccessRulesEditResponseConfigurationAccessRuleCIDRConfiguration: S.Schema<AccessRulesEditResponseConfigurationAccessRuleCIDRConfiguration>;
export type AccessRulesEditResponseConfigurationASNConfigurationTarget = "asn";
export declare const AccessRulesEditResponseConfigurationASNConfigurationTarget: any;
export interface AccessRulesEditResponseConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: AccessRulesEditResponseConfigurationASNConfigurationTarget | null;
    /** The AS number to match. */
    value?: string | null;
}
export declare const AccessRulesEditResponseConfigurationASNConfiguration: S.Schema<AccessRulesEditResponseConfigurationASNConfiguration>;
export type AccessRulesEditResponseConfigurationCountryConfigurationTarget = "country";
export declare const AccessRulesEditResponseConfigurationCountryConfigurationTarget: any;
export interface AccessRulesEditResponseConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: AccessRulesEditResponseConfigurationCountryConfigurationTarget | null;
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string | null;
}
export declare const AccessRulesEditResponseConfigurationCountryConfiguration: S.Schema<AccessRulesEditResponseConfigurationCountryConfiguration>;
export type AccessRulesEditResponseConfiguration = AccessRulesEditResponseConfigurationAccessRuleIPConfiguration | AccessRulesEditResponseConfigurationIPV6Configuration | AccessRulesEditResponseConfigurationAccessRuleCIDRConfiguration | AccessRulesEditResponseConfigurationASNConfiguration | AccessRulesEditResponseConfigurationCountryConfiguration;
export declare const AccessRulesEditResponseConfiguration: any;
export type AccessRulesEditResponseMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const AccessRulesEditResponseMode: any;
export type AccessRulesEditResponseScopeType = "user" | "organization";
export declare const AccessRulesEditResponseScopeType: any;
export interface AccessRulesEditResponseScope {
    /** Defines an identifier. */
    id?: string | null;
    /** The contact email address of the user. */
    email?: string | null;
    /** Defines the scope of the rule. */
    type?: AccessRulesEditResponseScopeType | null;
}
export declare const AccessRulesEditResponseScope: S.Schema<AccessRulesEditResponseScope>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAccessRuleResponse {
    /** The unique identifier of the IP Access rule. */
    id: string;
    /** The available actions that a rule can apply to a matched request. */
    allowedModes: AccessRulesEditResponseAllowedModesList;
    /** The rule configuration. */
    configuration: AccessRulesEditResponseConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesEditResponseMode;
    /** The timestamp of when the rule was created. */
    createdOn?: string | null;
    /** The timestamp of when the rule was last modified. */
    modifiedOn?: string | null;
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string | null;
    /** All zones owned by the user will have the rule applied. */
    scope?: AccessRulesEditResponseScope | null;
}
export declare const PatchAccessRuleResponse: S.Schema<PatchAccessRuleResponse>;
export interface PatchAccessRuleForZoneRequest {
    /** The Zone ID to use for this endpoint. Mutually exclusive with the Account ID. */
    zoneId: string;
    /** Unique identifier for a rule. */
    ruleId: string;
    /** The rule configuration. */
    configuration: AccessRulesEditRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: AccessRulesEditRequestMode | (string & {});
    /** An informative summary of the rule, typically used as a reminder or explanation. */
    notes?: string;
}
export declare const PatchAccessRuleForZoneRequest: S.Schema<PatchAccessRuleForZoneRequest>;
export interface PatchRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
}
export declare const PatchRuleRequest: S.Schema<PatchRuleRequest>;
export type RulesEditResultItemAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesEditResultItemAction: any;
export type RulesEditResultItemFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesEditResultItemFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesEditResultItemFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesEditResultItemFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesEditResultItemFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesEditResultItemFilter: any;
export type RulesEditResultItemProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesEditResultItemProductsItem: any;
export type RulesEditResultItemProductsList = Array<RulesEditResultItemProductsItem>;
export declare const RulesEditResultItemProductsList: S.Schema<RulesEditResultItemProductsList>;
export interface RulesEditResultItem {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesEditResultItemAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesEditResultItemFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesEditResultItemProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const RulesEditResultItem: S.Schema<RulesEditResultItem>;
export type RulesEditResultList = Array<RulesEditResultItem>;
export declare const RulesEditResultList: S.Schema<RulesEditResultList>;
export interface PatchRuleResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RulesEditResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const PatchRuleResponse: S.Schema<PatchRuleResponse>;
export type WafPackagesGroupsEditRequestMode = "on" | "off";
export declare const WafPackagesGroupsEditRequestMode: any;
export interface PatchWafPackageGroupRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    groupId: string;
    /** Defines the state of the rules contained in the rule group. When `on`, the rules in the group are configurable/usable. */
    mode?: WafPackagesGroupsEditRequestMode | (string & {});
}
export declare const PatchWafPackageGroupRequest: S.Schema<PatchWafPackageGroupRequest>;
export type PatchWafPackageGroupResponse = unknown;
export declare const PatchWafPackageGroupResponse: S.Schema<PatchWafPackageGroupResponse>;
export type WafPackagesRulesEditRequestMode = "default" | "disable" | "simulate" | "block" | "challenge" | "on" | "off";
export declare const WafPackagesRulesEditRequestMode: any;
export interface PatchWafPackageRuleRequest {
    /** Defines an identifier of a schema. */
    zoneId: string;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the unique identifier of a WAF package. */
    ruleId: string;
    /** Defines the mode/action of the rule when triggered. You must use a value from the `allowed_modes` array of the current rule. */
    mode?: WafPackagesRulesEditRequestMode | (string & {});
}
export declare const PatchWafPackageRuleRequest: S.Schema<PatchWafPackageRuleRequest>;
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesItem = "on" | "off";
export declare const WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesItem: any;
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesList = Array<WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesItem>;
export declare const WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesList: S.Schema<WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesList>;
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleGroup = WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
export declare const WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleGroup: S.Schema<WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup>;
export type WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleMode = "on" | "off";
export declare const WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleMode: any;
export interface WafPackagesRulesEditResultWAFManagedRulesAnomalyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. Applies to anomaly detection WAF rules. */
    allowedModes: WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the mode anomaly. When set to `on`, the current WAF rule will be used when evaluating the request. Applies to anomaly detection WAF rules. */
    mode: WafPackagesRulesEditResultWAFManagedRulesAnomalyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export declare const WafPackagesRulesEditResultWAFManagedRulesAnomalyRule: S.Schema<WafPackagesRulesEditResultWAFManagedRulesAnomalyRule>;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesItem = "default" | "disable" | "simulate" | "block" | "challenge";
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesItem: any;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesList = Array<WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesItem>;
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesList: S.Schema<WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesList>;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleDefaultMode = "disable" | "simulate" | "block" | "challenge";
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleDefaultMode: any;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleMode = "default" | "disable" | "simulate" | "block" | "challenge";
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleMode: any;
export interface WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the list of possible actions of the WAF rule when it is triggered. */
    allowedModes: WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleAllowedModesList;
    /** Defines the default action/mode of a rule. */
    defaultMode: WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleDefaultMode;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** Defines the action that the current WAF rule will perform when triggered. Applies to traditional (deny) WAF rules. */
    mode: WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRule: S.Schema<WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRule>;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesItem = "on" | "off";
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesItem: any;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesList = Array<WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesItem>;
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesList: S.Schema<WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesList>;
export type WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleMode = "on" | "off";
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleMode: any;
export interface WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRule {
    /** Defines the unique identifier of the WAF rule. */
    id: string;
    /** Defines the available modes for the current WAF rule. */
    allowedModes: WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleAllowedModesList;
    /** Defines the public description of the WAF rule. */
    description: string;
    /** Defines the rule group to which the current WAF rule belongs. */
    group: WafPackagesRulesListResultItemWAFManagedRulesAnomalyRuleGroup;
    /** When set to `on`, the current rule will be used when evaluating the request. Applies to traditional (allow) WAF rules. */
    mode: WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRuleMode;
    /** Defines the unique identifier of a WAF package. */
    packageId: string;
    /** Defines the order in which the individual WAF rule is executed within its rule group. */
    priority: string;
}
export declare const WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRule: S.Schema<WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRule>;
export type WafPackagesRulesEditResult = WafPackagesRulesEditResultWAFManagedRulesAnomalyRule | WafPackagesRulesEditResultWAFManagedRulesTraditionalDenyRule | WafPackagesRulesEditResultWAFManagedRulesTraditionalAllowRule;
export declare const WafPackagesRulesEditResult: any;
export type PatchWafPackageRuleResponse = WafPackagesRulesEditResult;
export declare const PatchWafPackageRuleResponse: S.Schema<PatchWafPackageRuleResponse>;
export type LockdownsUpdateRequestUrlsList = Array<string>;
export declare const LockdownsUpdateRequestUrlsList: S.Schema<LockdownsUpdateRequestUrlsList>;
export interface UpdateLockdownRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the Zone Lockdown rule. */
    lockDownsId: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsUpdateRequestUrlsList;
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
    /** The priority of the rule to control the processing order. A lower number indicates higher priority. If not provided, any rules with a configured priority will be processed before rules without a priority. */
    priority?: number;
}
export declare const UpdateLockdownRequest: S.Schema<UpdateLockdownRequest>;
export type LockdownsUpdateResponseUrlsList = Array<string>;
export declare const LockdownsUpdateResponseUrlsList: S.Schema<LockdownsUpdateResponseUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateLockdownResponse {
    /** The unique identifier of the Zone Lockdown rule. */
    id: string;
    /** A list of IP addresses or CIDR ranges that will be allowed to access the URLs specified in the Zone Lockdown rule. You can include any number of `ip` or `ip_range` configurations. */
    configurations: LockdownConfigurationsList;
    /** The timestamp of when the rule was created. */
    createdOn: string;
    /** An informative summary of the rule. */
    description: string;
    /** The timestamp of when the rule was last modified. */
    modifiedOn: string;
    /** When true, indicates that the rule is currently paused. */
    paused: boolean;
    /** The URLs to include in the rule definition. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: LockdownsUpdateResponseUrlsList;
    /** The priority of the Zone Lockdown rule, echoed on reads. */
    priority?: number | null;
}
export declare const UpdateLockdownResponse: S.Schema<UpdateLockdownResponse>;
export type RulesUpdateRequestActionMode = "simulate" | "ban" | "challenge" | "js_challenge" | "managed_challenge";
export declare const RulesUpdateRequestActionMode: any;
export type RulesUpdateRequestActionResponse = RulesCreateRequestActionResponse;
export declare const RulesUpdateRequestActionResponse: S.Schema<RulesCreateRequestActionResponse>;
export interface RulesUpdateRequestAction {
    /** The action to perform. */
    mode?: RulesUpdateRequestActionMode | (string & {});
    /** A custom content type and reponse to return when the threshold is exceeded. The custom response configured in this object will override the custom error for the zone. This object is optional. */
    response?: RulesCreateRequestActionResponse;
    /** The time in seconds during which Cloudflare will perform the mitigation action. Must be an integer value greater than or equal to the period. */
    timeout?: number;
}
export declare const RulesUpdateRequestAction: S.Schema<RulesUpdateRequestAction>;
export type RulesUpdateRequestFilter = RulesCreateRequestFilter;
export declare const RulesUpdateRequestFilter: S.Schema<RulesCreateRequestFilter>;
export interface UpdateRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the firewall rule. */
    ruleId: string;
    /** The action to perform when the threshold of matched traffic within the configured period is exceeded. */
    action: RulesUpdateRequestAction;
    filter: RulesCreateRequestFilter;
}
export declare const UpdateRuleRequest: S.Schema<UpdateRuleRequest>;
export type RulesUpdateResponseAction = "block" | "challenge" | "js_challenge" | "managed_challenge" | "allow" | "log" | "bypass";
export declare const RulesUpdateResponseAction: any;
export type RulesUpdateResponseFilterFirewallFilter = RulesBulkDeleteResultItemFilterFirewallFilter;
export declare const RulesUpdateResponseFilterFirewallFilter: S.Schema<RulesBulkDeleteResultItemFilterFirewallFilter>;
export type RulesUpdateResponseFilterDeletedFilter = RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesUpdateResponseFilterDeletedFilter: S.Schema<RulesBulkDeleteResultItemFilterDeletedFilter>;
export type RulesUpdateResponseFilter = RulesBulkDeleteResultItemFilterFirewallFilter | RulesBulkDeleteResultItemFilterDeletedFilter;
export declare const RulesUpdateResponseFilter: any;
export type RulesUpdateResponseProductsItem = "zoneLockdown" | "uaBlock" | "bic" | "hot" | "securityLevel" | "rateLimit" | "waf";
export declare const RulesUpdateResponseProductsItem: any;
export type RulesUpdateResponseProductsList = Array<RulesUpdateResponseProductsItem>;
export declare const RulesUpdateResponseProductsList: S.Schema<RulesUpdateResponseProductsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateRuleResponse {
    /** The unique identifier of the firewall rule. */
    id?: string | null;
    /** The action to apply to a matched request. The `log` action is only available on an Enterprise plan. */
    action?: RulesUpdateResponseAction | null;
    /** An informative summary of the firewall rule. */
    description?: string | null;
    filter?: RulesUpdateResponseFilter | null;
    /** When true, indicates that the firewall rule is currently paused. */
    paused?: boolean | null;
    /** The priority of the rule. Optional value used to define the processing order. A lower number indicates a higher priority. If not provided, rules with a defined priority will be processed before rules without a priority. */
    priority?: number | null;
    products?: RulesUpdateResponseProductsList | null;
    /** A short reference tag. Allows you to select related firewall rules. */
    ref?: string | null;
}
export declare const UpdateRuleResponse: S.Schema<UpdateRuleResponse>;
export type UaRulesUpdateRequestConfigurationAccessRuleIPConfigurationTarget = "ip";
export declare const UaRulesUpdateRequestConfigurationAccessRuleIPConfigurationTarget: any;
export interface UaRulesUpdateRequestConfigurationAccessRuleIPConfiguration {
    /** The configuration target. You must set the target to `ip` when specifying an IP address in the rule. */
    target?: UaRulesUpdateRequestConfigurationAccessRuleIPConfigurationTarget | (string & {});
    /** The IP address to match. This address will be compared to the IP address of incoming requests. */
    value?: string;
}
export declare const UaRulesUpdateRequestConfigurationAccessRuleIPConfiguration: S.Schema<UaRulesUpdateRequestConfigurationAccessRuleIPConfiguration>;
export type UaRulesUpdateRequestConfigurationIPV6ConfigurationTarget = "ip6";
export declare const UaRulesUpdateRequestConfigurationIPV6ConfigurationTarget: any;
export interface UaRulesUpdateRequestConfigurationIPV6Configuration {
    /** The configuration target. You must set the target to `ip6` when specifying an IPv6 address in the rule. */
    target?: UaRulesUpdateRequestConfigurationIPV6ConfigurationTarget | (string & {});
    /** The IPv6 address to match. */
    value?: string;
}
export declare const UaRulesUpdateRequestConfigurationIPV6Configuration: S.Schema<UaRulesUpdateRequestConfigurationIPV6Configuration>;
export type UaRulesUpdateRequestConfigurationAccessRuleCIDRConfigurationTarget = "ip_range";
export declare const UaRulesUpdateRequestConfigurationAccessRuleCIDRConfigurationTarget: any;
export interface UaRulesUpdateRequestConfigurationAccessRuleCIDRConfiguration {
    /** The configuration target. You must set the target to `ip_range` when specifying an IP address range in the rule. */
    target?: UaRulesUpdateRequestConfigurationAccessRuleCIDRConfigurationTarget | (string & {});
    /** The IP address range to match. You can only use prefix lengths `/16` and `/24` for IPv4 ranges, and prefix lengths `/32`, `/48`, and `/64` for IPv6 ranges. */
    value?: string;
}
export declare const UaRulesUpdateRequestConfigurationAccessRuleCIDRConfiguration: S.Schema<UaRulesUpdateRequestConfigurationAccessRuleCIDRConfiguration>;
export type UaRulesUpdateRequestConfigurationASNConfigurationTarget = "asn";
export declare const UaRulesUpdateRequestConfigurationASNConfigurationTarget: any;
export interface UaRulesUpdateRequestConfigurationASNConfiguration {
    /** The configuration target. You must set the target to `asn` when specifying an Autonomous System Number (ASN) in the rule. */
    target?: UaRulesUpdateRequestConfigurationASNConfigurationTarget | (string & {});
    /** The AS number to match. */
    value?: string;
}
export declare const UaRulesUpdateRequestConfigurationASNConfiguration: S.Schema<UaRulesUpdateRequestConfigurationASNConfiguration>;
export type UaRulesUpdateRequestConfigurationCountryConfigurationTarget = "country";
export declare const UaRulesUpdateRequestConfigurationCountryConfigurationTarget: any;
export interface UaRulesUpdateRequestConfigurationCountryConfiguration {
    /** The configuration target. You must set the target to `country` when specifying a country code in the rule. */
    target?: UaRulesUpdateRequestConfigurationCountryConfigurationTarget | (string & {});
    /** The two-letter ISO-3166-1 alpha-2 code to match. For more information, refer to [IP Access rules: Parameters](https://developers.cloudflare.com/waf/tools/ip-access-rules/parameters/#country). */
    value?: string;
}
export declare const UaRulesUpdateRequestConfigurationCountryConfiguration: S.Schema<UaRulesUpdateRequestConfigurationCountryConfiguration>;
export type UaRulesUpdateRequestConfiguration = UaRulesUpdateRequestConfigurationAccessRuleIPConfiguration | UaRulesUpdateRequestConfigurationIPV6Configuration | UaRulesUpdateRequestConfigurationAccessRuleCIDRConfiguration | UaRulesUpdateRequestConfigurationASNConfiguration | UaRulesUpdateRequestConfigurationCountryConfiguration;
export declare const UaRulesUpdateRequestConfiguration: any;
export type UaRulesUpdateRequestMode = "block" | "challenge" | "whitelist" | "js_challenge" | "managed_challenge";
export declare const UaRulesUpdateRequestMode: any;
export interface UpdateUaRuleRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the User Agent Blocking rule. */
    uaRuleId: string;
    /** The rule configuration. */
    configuration: UaRulesUpdateRequestConfiguration;
    /** The action to apply to a matched request. */
    mode: UaRulesUpdateRequestMode | (string & {});
    /** An informative summary of the rule. This value is sanitized and any tags will be removed. */
    description?: string;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean;
}
export declare const UpdateUaRuleRequest: S.Schema<UpdateUaRuleRequest>;
export type UaRulesUpdateResponseConfiguration = UaRulesCreateResponseConfiguration;
export declare const UaRulesUpdateResponseConfiguration: S.Schema<UaRulesCreateResponseConfiguration>;
export type UaRulesUpdateResponseMode = "block" | "challenge" | "js_challenge" | "managed_challenge";
export declare const UaRulesUpdateResponseMode: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateUaRuleResponse {
    /** The unique identifier of the User Agent Blocking rule. */
    id?: string | null;
    /** The configuration object for the current rule. */
    configuration?: UaRulesCreateResponseConfiguration | null;
    /** An informative summary of the rule. */
    description?: string | null;
    /** The action to apply to a matched request. */
    mode?: UaRulesUpdateResponseMode | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
}
export declare const UpdateUaRuleResponse: S.Schema<UpdateUaRuleResponse>;
export type WafOverridesUpdateRequestRewriteActionBlock = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateRequestRewriteActionBlock: any;
export type WafOverridesUpdateRequestRewriteActionChallenge = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateRequestRewriteActionChallenge: any;
export type WafOverridesUpdateRequestRewriteActionDefault = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateRequestRewriteActionDefault: any;
export type WafOverridesUpdateRequestRewriteActionDisable = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateRequestRewriteActionDisable: any;
export type WafOverridesUpdateRequestRewriteActionSimulate = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateRequestRewriteActionSimulate: any;
export interface WafOverridesUpdateRequestRewriteAction {
    /** The WAF rule action to apply. */
    block?: WafOverridesUpdateRequestRewriteActionBlock | (string & {});
    /** The WAF rule action to apply. */
    challenge?: WafOverridesUpdateRequestRewriteActionChallenge | (string & {});
    /** The WAF rule action to apply. */
    default?: WafOverridesUpdateRequestRewriteActionDefault | (string & {});
    /** The WAF rule action to apply. */
    disable?: WafOverridesUpdateRequestRewriteActionDisable | (string & {});
    /** The WAF rule action to apply. */
    simulate?: WafOverridesUpdateRequestRewriteActionSimulate | (string & {});
}
export declare const WafOverridesUpdateRequestRewriteAction: S.Schema<WafOverridesUpdateRequestRewriteAction>;
export type WafOverridesUpdateRequestRules = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateRequestRules: any;
export type WafOverridesUpdateRequestUrlsList = Array<string>;
export declare const WafOverridesUpdateRequestUrlsList: S.Schema<WafOverridesUpdateRequestUrlsList>;
export interface UpdateWafOverrideRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The unique identifier of the WAF override. */
    overridesId: string;
    /** Defines an identifier. */
    id: string;
    /** Specifies that, when a WAF rule matches, its configured action will be replaced by the action configured in this object. */
    rewriteAction: WafOverridesUpdateRequestRewriteAction;
    /** An object that allows you to override the action of specific WAF rules. Each key of this object must be the ID of a WAF rule, and each value must be a valid WAF action. Unless you are disabling a rule, ensure that you also enable the rule group that this WAF rule belongs to. When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    rules: WafOverridesUpdateRequestRules | (string & {});
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls: WafOverridesUpdateRequestUrlsList;
}
export declare const UpdateWafOverrideRequest: S.Schema<UpdateWafOverrideRequest>;
export type WafOverridesUpdateResponseGroupsMap = {
    [key: string]: unknown | undefined;
};
export declare const WafOverridesUpdateResponseGroupsMap: S.Schema<WafOverridesUpdateResponseGroupsMap>;
export type WafOverridesUpdateResponseRewriteActionBlock = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateResponseRewriteActionBlock: any;
export type WafOverridesUpdateResponseRewriteActionChallenge = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateResponseRewriteActionChallenge: any;
export type WafOverridesUpdateResponseRewriteActionDefault = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateResponseRewriteActionDefault: any;
export type WafOverridesUpdateResponseRewriteActionDisable = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateResponseRewriteActionDisable: any;
export type WafOverridesUpdateResponseRewriteActionSimulate = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateResponseRewriteActionSimulate: any;
export interface WafOverridesUpdateResponseRewriteAction {
    /** The WAF rule action to apply. */
    block?: WafOverridesUpdateResponseRewriteActionBlock | null;
    /** The WAF rule action to apply. */
    challenge?: WafOverridesUpdateResponseRewriteActionChallenge | null;
    /** The WAF rule action to apply. */
    default?: WafOverridesUpdateResponseRewriteActionDefault | null;
    /** The WAF rule action to apply. */
    disable?: WafOverridesUpdateResponseRewriteActionDisable | null;
    /** The WAF rule action to apply. */
    simulate?: WafOverridesUpdateResponseRewriteActionSimulate | null;
}
export declare const WafOverridesUpdateResponseRewriteAction: S.Schema<WafOverridesUpdateResponseRewriteAction>;
export type WafOverridesUpdateResponseRules = "challenge" | "block" | "simulate" | "disable" | "default";
export declare const WafOverridesUpdateResponseRules: any;
export type WafOverridesUpdateResponseUrlsList = Array<string>;
export declare const WafOverridesUpdateResponseUrlsList: S.Schema<WafOverridesUpdateResponseUrlsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateWafOverrideResponse {
    /** The unique identifier of the WAF override. */
    id?: string | null;
    /** An informative summary of the current URI-based WAF override. */
    description?: string | null;
    /** An object that allows you to enable or disable WAF rule groups for the current WAF override. Each key of this object must be the ID of a WAF rule group, and each value must be a valid WAF action (usually `default` or `disable`). When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    groups?: WafOverridesUpdateResponseGroupsMap | null;
    /** When true, indicates that the rule is currently paused. */
    paused?: boolean | null;
    /** The relative priority of the current URI-based WAF override when multiple overrides match a single URL. A lower number indicates higher priority. Higher priority overrides may overwrite values set by lower priority overrides. */
    priority?: number | null;
    /** Specifies that, when a WAF rule matches, its configured action will be replaced by the action configured in this object. */
    rewriteAction?: WafOverridesUpdateResponseRewriteAction | null;
    /** An object that allows you to override the action of specific WAF rules. Each key of this object must be the ID of a WAF rule, and each value must be a valid WAF action. Unless you are disabling a rule, ensure that you also enable the rule group that this WAF rule belongs to. When creating a new URI-based WAF override, you must provide a `groups` object or a `rules` object. */
    rules?: WafOverridesUpdateResponseRules | null;
    /** The URLs to include in the current WAF override. You can use wildcards. Each entered URL will be escaped before use, which means you can only use simple wildcard patterns. */
    urls?: WafOverridesUpdateResponseUrlsList | null;
}
export declare const UpdateWafOverrideResponse: S.Schema<UpdateWafOverrideResponse>;
export type BulkDeleteRulesError = CloudflareOpError;
/** Deletes existing firewall rules. */
export declare const bulkDeleteRules: API.PaginatedOperationMethod<BulkDeleteRulesRequest, BulkDeleteRulesResponse, BulkDeleteRulesError, CloudflareOpContext, RulesBulkDeleteResultItem>;
export type BulkPatchRulesError = CloudflareOpError;
/** Updates the priority of existing firewall rules. */
export declare const bulkPatchRules: API.PaginatedOperationMethod<BulkPatchRulesRequest, BulkPatchRulesResponse, BulkPatchRulesError, CloudflareOpContext, RulesBulkEditResultItem>;
export type BulkPutRulesError = CloudflareOpError;
/** Updates one or more existing firewall rules. */
export declare const bulkPutRules: API.PaginatedOperationMethod<BulkPutRulesRequest, BulkPutRulesResponse, BulkPutRulesError, CloudflareOpContext, RulesBulkUpdateResultItem>;
export type CreateAccessRuleForAccountError = DuplicateAccessRule | Forbidden | CloudflareOpError;
/** Creates a new IP Access rule for an account or zone. The rule will apply to all zones in the account or zone. Note: To create an IP Access rule that applies to a single zone, refer to the [IP Access rules for a zone](#ip-access-rules-for-a-zone) endpoints. */
export declare const createAccessRuleForAccount: API.OperationMethod<CreateAccessRuleForAccountRequest, CreateAccessRuleResponse, CreateAccessRuleForAccountError, CloudflareOpContext>;
export type CreateAccessRuleForZoneError = DuplicateAccessRule | Forbidden | CloudflareOpError;
/** Creates a new IP Access rule for an account or zone. The rule will apply to all zones in the account or zone. Note: To create an IP Access rule that applies to a single zone, refer to the [IP Access rules for a zone](#ip-access-rules-for-a-zone) endpoints. */
export declare const createAccessRuleForZone: API.OperationMethod<CreateAccessRuleForZoneRequest, CreateAccessRuleResponse, CreateAccessRuleForZoneError, CloudflareOpContext>;
export type CreateLockdownError = DuplicateLockdown | Forbidden | CloudflareOpError;
/** Creates a new Zone Lockdown rule. */
export declare const createLockdown: API.OperationMethod<CreateLockdownRequest, CreateLockdownResponse, CreateLockdownError, CloudflareOpContext>;
export type CreateRuleError = CloudflareOpError;
/** Create one or more firewall rules. */
export declare const createRule: API.PaginatedOperationMethod<CreateRuleRequest, CreateRuleResponse, CreateRuleError, CloudflareOpContext, RulesCreateResultItem>;
export type CreateUaRuleError = DuplicateUaRule | Forbidden | CloudflareOpError;
/** Creates a new User Agent Blocking rule in a zone. */
export declare const createUaRule: API.OperationMethod<CreateUaRuleRequest, CreateUaRuleResponse, CreateUaRuleError, CloudflareOpContext>;
export type CreateWafOverrideError = CloudflareOpError;
/** Creates a URI-based WAF override for a zone. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const createWafOverride: API.OperationMethod<CreateWafOverrideRequest, CreateWafOverrideResponse, CreateWafOverrideError, CloudflareOpContext>;
export type DeleteAccessRuleForAccountError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const deleteAccessRuleForAccount: API.OperationMethod<DeleteAccessRuleForAccountRequest, DeleteAccessRuleResponse, DeleteAccessRuleForAccountError, CloudflareOpContext>;
export type DeleteAccessRuleForZoneError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const deleteAccessRuleForZone: API.OperationMethod<DeleteAccessRuleForZoneRequest, DeleteAccessRuleResponse, DeleteAccessRuleForZoneError, CloudflareOpContext>;
export type DeleteLockdownError = LockdownNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing Zone Lockdown rule. */
export declare const deleteLockdown: API.OperationMethod<DeleteLockdownRequest, DeleteLockdownResponse, DeleteLockdownError, CloudflareOpContext>;
export type DeleteRuleError = CloudflareOpError;
/** Deletes an existing firewall rule. */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest, DeleteRuleResponse, DeleteRuleError, CloudflareOpContext>;
export type DeleteUaRuleError = UaRuleNotFound | Forbidden | CloudflareOpError;
/** Deletes an existing User Agent Blocking rule. */
export declare const deleteUaRule: API.OperationMethod<DeleteUaRuleRequest, DeleteUaRuleResponse, DeleteUaRuleError, CloudflareOpContext>;
export type DeleteWafOverrideError = CloudflareOpError;
/** Deletes an existing URI-based WAF override. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const deleteWafOverride: API.OperationMethod<DeleteWafOverrideRequest, DeleteWafOverrideResponse, DeleteWafOverrideError, CloudflareOpContext>;
export type GetAccessRuleForAccountError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of an IP Access rule defined. */
export declare const getAccessRuleForAccount: API.OperationMethod<GetAccessRuleForAccountRequest, GetAccessRuleResponse, GetAccessRuleForAccountError, CloudflareOpContext>;
export type GetAccessRuleForZoneError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of an IP Access rule defined. */
export declare const getAccessRuleForZone: API.OperationMethod<GetAccessRuleForZoneRequest, GetAccessRuleResponse, GetAccessRuleForZoneError, CloudflareOpContext>;
export type GetLockdownError = LockdownNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a Zone Lockdown rule. */
export declare const getLockdown: API.OperationMethod<GetLockdownRequest, GetLockdownResponse, GetLockdownError, CloudflareOpContext>;
export type GetRuleError = CloudflareOpError;
/** Fetches the details of a firewall rule. */
export declare const getRule: API.OperationMethod<GetRuleRequest, GetRuleResponse, GetRuleError, CloudflareOpContext>;
export type GetUaRuleError = UaRuleNotFound | Forbidden | CloudflareOpError;
/** Fetches the details of a User Agent Blocking rule. */
export declare const getUaRule: API.OperationMethod<GetUaRuleRequest, GetUaRuleResponse, GetUaRuleError, CloudflareOpContext>;
export type GetWafOverrideError = CloudflareOpError;
/** Fetches the details of a URI-based WAF override. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const getWafOverride: API.OperationMethod<GetWafOverrideRequest, GetWafOverrideResponse, GetWafOverrideError, CloudflareOpContext>;
export type GetWafPackageError = CloudflareOpError;
/** Fetches the details of a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const getWafPackage: API.OperationMethod<GetWafPackageRequest, GetWafPackageResponse, GetWafPackageError, CloudflareOpContext>;
export type GetWafPackageGroupError = CloudflareOpError;
/** Fetches the details of a WAF rule group. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const getWafPackageGroup: API.OperationMethod<GetWafPackageGroupRequest, GetWafPackageGroupResponse, GetWafPackageGroupError, CloudflareOpContext>;
export type GetWafPackageRuleError = CloudflareOpError;
/** Fetches the details of a WAF rule in a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const getWafPackageRule: API.OperationMethod<GetWafPackageRuleRequest, GetWafPackageRuleResponse, GetWafPackageRuleError, CloudflareOpContext>;
export type ListAccessRulesForAccountError = Forbidden | CloudflareOpError;
/** Fetches IP Access rules of an account or zone. These rules apply to all the zones in the account or zone. You can filter the results using several optional parameters. */
export declare const listAccessRulesForAccount: API.PaginatedOperationMethod<ListAccessRulesForAccountRequest, ListAccessRulesResponse, ListAccessRulesForAccountError, CloudflareOpContext, AccessRulesListResultItem>;
export type ListAccessRulesForZoneError = Forbidden | CloudflareOpError;
/** Fetches IP Access rules of an account or zone. These rules apply to all the zones in the account or zone. You can filter the results using several optional parameters. */
export declare const listAccessRulesForZone: API.PaginatedOperationMethod<ListAccessRulesForZoneRequest, ListAccessRulesResponse, ListAccessRulesForZoneError, CloudflareOpContext, AccessRulesListResultItem>;
export type ListLockdownsError = Forbidden | CloudflareOpError;
/** Fetches Zone Lockdown rules. You can filter the results using several optional parameters. */
export declare const listLockdowns: API.PaginatedOperationMethod<ListLockdownsRequest, ListLockdownsResponse, ListLockdownsError, CloudflareOpContext, LockdownsListResultItem>;
export type ListRulesError = CloudflareOpError;
/** Fetches firewall rules in a zone. You can filter the results using several optional parameters. */
export declare const listRules: API.PaginatedOperationMethod<ListRulesRequest, ListRulesResponse, ListRulesError, CloudflareOpContext, RulesListResultItem>;
export type ListUaRulesError = Forbidden | CloudflareOpError;
/** Fetches User Agent Blocking rules in a zone. You can filter the results using several optional parameters. */
export declare const listUaRules: API.PaginatedOperationMethod<ListUaRulesRequest, ListUaRulesResponse, ListUaRulesError, CloudflareOpContext, UaRulesListResultItem>;
export type ListWafOverridesError = CloudflareOpError;
/** Fetches the URI-based WAF overrides in a zone. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const listWafOverrides: API.PaginatedOperationMethod<ListWafOverridesRequest, ListWafOverridesResponse, ListWafOverridesError, CloudflareOpContext, WafOverridesListResultItem>;
export type ListWafPackageGroupsError = CloudflareOpError;
/** Fetches the WAF rule groups in a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const listWafPackageGroups: API.PaginatedOperationMethod<ListWafPackageGroupsRequest, ListWafPackageGroupsResponse, ListWafPackageGroupsError, CloudflareOpContext, WafPackagesGroupsListResultItem>;
export type ListWafPackageRulesError = CloudflareOpError;
/** Fetches WAF rules in a WAF package. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const listWafPackageRules: API.PaginatedOperationMethod<ListWafPackageRulesRequest, ListWafPackageRulesResponse, ListWafPackageRulesError, CloudflareOpContext, WafPackagesRulesListResultItem>;
export type ListWafPackagesError = CloudflareOpError;
/** Fetches WAF packages for a zone. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const listWafPackages: API.OperationMethod<ListWafPackagesRequest, ListWafPackagesResponse, ListWafPackagesError, CloudflareOpContext>;
export type PatchAccessRuleForAccountError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Updates an IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const patchAccessRuleForAccount: API.OperationMethod<PatchAccessRuleForAccountRequest, PatchAccessRuleResponse, PatchAccessRuleForAccountError, CloudflareOpContext>;
export type PatchAccessRuleForZoneError = AccessRuleNotFound | Forbidden | CloudflareOpError;
/** Updates an IP Access rule defined. Note: This operation will affect all zones in the account or zone. */
export declare const patchAccessRuleForZone: API.OperationMethod<PatchAccessRuleForZoneRequest, PatchAccessRuleResponse, PatchAccessRuleForZoneError, CloudflareOpContext>;
export type PatchRuleError = CloudflareOpError;
/** Updates the priority of an existing firewall rule. */
export declare const patchRule: API.PaginatedOperationMethod<PatchRuleRequest, PatchRuleResponse, PatchRuleError, CloudflareOpContext, RulesEditResultItem>;
export type PatchWafPackageGroupError = CloudflareOpError;
/** Updates a WAF rule group. You can update the state (`mode` parameter) of a rule group. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const patchWafPackageGroup: API.OperationMethod<PatchWafPackageGroupRequest, PatchWafPackageGroupResponse, PatchWafPackageGroupError, CloudflareOpContext>;
export type PatchWafPackageRuleError = CloudflareOpError;
/** Updates a WAF rule. You can only update the mode/action of the rule. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const patchWafPackageRule: API.OperationMethod<PatchWafPackageRuleRequest, PatchWafPackageRuleResponse, PatchWafPackageRuleError, CloudflareOpContext>;
export type UpdateLockdownError = LockdownNotFound | DuplicateLockdown | Forbidden | CloudflareOpError;
/** Updates an existing Zone Lockdown rule. */
export declare const updateLockdown: API.OperationMethod<UpdateLockdownRequest, UpdateLockdownResponse, UpdateLockdownError, CloudflareOpContext>;
export type UpdateRuleError = CloudflareOpError;
/** Updates an existing firewall rule. */
export declare const updateRule: API.OperationMethod<UpdateRuleRequest, UpdateRuleResponse, UpdateRuleError, CloudflareOpContext>;
export type UpdateUaRuleError = UaRuleNotFound | DuplicateUaRule | Forbidden | CloudflareOpError;
/** Updates an existing User Agent Blocking rule. */
export declare const updateUaRule: API.OperationMethod<UpdateUaRuleRequest, UpdateUaRuleResponse, UpdateUaRuleError, CloudflareOpContext>;
export type UpdateWafOverrideError = CloudflareOpError;
/** Updates an existing URI-based WAF override. **Note:** Applies only to the [previous version of WAF managed rules](https://developers.cloudflare.com/support/firewall/managed-rules-web-application-firewall-waf/understanding-waf-managed-rules-web-application-firewall/). */
export declare const updateWafOverride: API.OperationMethod<UpdateWafOverrideRequest, UpdateWafOverrideResponse, UpdateWafOverrideError, CloudflareOpContext>;
//# sourceMappingURL=firewall.d.ts.map