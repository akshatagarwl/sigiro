import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetEntitlementRequest {
    tenantId: string;
}
export declare const GetEntitlementRequest: S.Schema<GetEntitlementRequest>;
export type EntitlementsGetResponseAllowAddSubdomainType = "bool";
export declare const EntitlementsGetResponseAllowAddSubdomainType: any;
export interface EntitlementsGetResponseAllowAddSubdomain {
    type: EntitlementsGetResponseAllowAddSubdomainType;
    value: boolean;
}
export declare const EntitlementsGetResponseAllowAddSubdomain: S.Schema<EntitlementsGetResponseAllowAddSubdomain>;
export type EntitlementsGetResponseAllowAutoAcceptInvitesType = "bool";
export declare const EntitlementsGetResponseAllowAutoAcceptInvitesType: any;
export interface EntitlementsGetResponseAllowAutoAcceptInvites {
    type: EntitlementsGetResponseAllowAutoAcceptInvitesType;
    value: boolean;
}
export declare const EntitlementsGetResponseAllowAutoAcceptInvites: S.Schema<EntitlementsGetResponseAllowAutoAcceptInvites>;
export type EntitlementsGetResponseCnameSetupAllowedType = "bool";
export declare const EntitlementsGetResponseCnameSetupAllowedType: any;
export interface EntitlementsGetResponseCnameSetupAllowed {
    type: EntitlementsGetResponseCnameSetupAllowedType;
    value: boolean;
}
export declare const EntitlementsGetResponseCnameSetupAllowed: S.Schema<EntitlementsGetResponseCnameSetupAllowed>;
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocationType = "max_count";
export declare const EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocationType: any;
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocationType;
    value: number;
}
export declare const EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation: S.Schema<EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation>;
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocationType = "bool";
export declare const EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocationType: any;
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocationType;
    value: boolean;
}
export declare const EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation: S.Schema<EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation>;
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocationType = "";
export declare const EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocationType: any;
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocationType;
    value?: unknown | null;
}
export declare const EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation: S.Schema<EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation>;
export type EntitlementsGetResponseCustomEntitlementsItemAllocation = EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation | EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation | EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation;
export declare const EntitlementsGetResponseCustomEntitlementsItemAllocation: any;
export interface EntitlementsGetResponseCustomEntitlementsItemFeature {
    key: string;
}
export declare const EntitlementsGetResponseCustomEntitlementsItemFeature: S.Schema<EntitlementsGetResponseCustomEntitlementsItemFeature>;
export interface EntitlementsGetResponseCustomEntitlementsItem {
    allocation: EntitlementsGetResponseCustomEntitlementsItemAllocation;
    feature: EntitlementsGetResponseCustomEntitlementsItemFeature;
}
export declare const EntitlementsGetResponseCustomEntitlementsItem: S.Schema<EntitlementsGetResponseCustomEntitlementsItem>;
export type EntitlementsGetResponseCustomEntitlementsList = Array<EntitlementsGetResponseCustomEntitlementsItem>;
export declare const EntitlementsGetResponseCustomEntitlementsList: S.Schema<EntitlementsGetResponseCustomEntitlementsList>;
export type EntitlementsGetResponseMhsCertificateCountType = "max_count";
export declare const EntitlementsGetResponseMhsCertificateCountType: any;
export interface EntitlementsGetResponseMhsCertificateCount {
    type: EntitlementsGetResponseMhsCertificateCountType;
    value: number;
}
export declare const EntitlementsGetResponseMhsCertificateCount: S.Schema<EntitlementsGetResponseMhsCertificateCount>;
export type EntitlementsGetResponsePartialSetupAllowedType = "bool";
export declare const EntitlementsGetResponsePartialSetupAllowedType: any;
export interface EntitlementsGetResponsePartialSetupAllowed {
    type: EntitlementsGetResponsePartialSetupAllowedType;
    value: boolean;
}
export declare const EntitlementsGetResponsePartialSetupAllowed: S.Schema<EntitlementsGetResponsePartialSetupAllowed>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEntitlementResponse {
    allowAddSubdomain: EntitlementsGetResponseAllowAddSubdomain;
    allowAutoAcceptInvites: EntitlementsGetResponseAllowAutoAcceptInvites;
    cnameSetupAllowed: EntitlementsGetResponseCnameSetupAllowed;
    customEntitlements: EntitlementsGetResponseCustomEntitlementsList;
    mhsCertificateCount: EntitlementsGetResponseMhsCertificateCount;
    partialSetupAllowed: EntitlementsGetResponsePartialSetupAllowed;
}
export declare const GetEntitlementResponse: S.Schema<GetEntitlementResponse>;
export interface GetTenantRequest {
    tenantId: string;
}
export declare const GetTenantRequest: S.Schema<GetTenantRequest>;
export interface GetResponseTenantContacts {
    email?: string | null;
    website?: string | null;
}
export declare const GetResponseTenantContacts: S.Schema<GetResponseTenantContacts>;
export type GetResponseTenantLabelsList = Array<string>;
export declare const GetResponseTenantLabelsList: S.Schema<GetResponseTenantLabelsList>;
export interface GetResponseTenantMetadataDnsNsPool {
    primary?: string | null;
    secondary?: string | null;
}
export declare const GetResponseTenantMetadataDnsNsPool: S.Schema<GetResponseTenantMetadataDnsNsPool>;
export interface GetResponseTenantMetadataDns {
    nsPool: GetResponseTenantMetadataDnsNsPool;
}
export declare const GetResponseTenantMetadataDns: S.Schema<GetResponseTenantMetadataDns>;
export interface GetResponseTenantMetadata {
    dns?: GetResponseTenantMetadataDns | null;
}
export declare const GetResponseTenantMetadata: S.Schema<GetResponseTenantMetadata>;
export type GetResponseTenantUnitsItemUnitMembershipsList = Array<unknown>;
export declare const GetResponseTenantUnitsItemUnitMembershipsList: S.Schema<GetResponseTenantUnitsItemUnitMembershipsList>;
export interface GetResponseTenantUnitsItem {
    unitMemberships: GetResponseTenantUnitsItemUnitMembershipsList;
    unitMetadata: unknown;
    unitName: string;
    unitStatus: string;
    unitTag: string;
}
export declare const GetResponseTenantUnitsItem: S.Schema<GetResponseTenantUnitsItem>;
export type GetResponseTenantUnitsList = Array<GetResponseTenantUnitsItem>;
export declare const GetResponseTenantUnitsList: S.Schema<GetResponseTenantUnitsList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTenantResponse {
    cdate: string;
    edate: string;
    tenantContacts: GetResponseTenantContacts;
    tenantLabels: GetResponseTenantLabelsList;
    tenantMetadata: GetResponseTenantMetadata;
    tenantName: string;
    tenantNetwork: unknown;
    tenantStatus: string;
    tenantTag: string;
    tenantType: string;
    tenantUnits: GetResponseTenantUnitsList;
    customerId?: string | null;
}
export declare const GetTenantResponse: S.Schema<GetTenantResponse>;
export interface ListAccountsRequest {
    tenantId: string;
}
export declare const ListAccountsRequest: S.Schema<ListAccountsRequest>;
export interface AccountsListResultItemSettings {
    abuseContactEmail: string;
    accessApprovalExpiry: string;
    apiAccessEnabled: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    defaultNameservers: string;
    enforceTwofactor: boolean;
    /** Use [DNS Settings](https://developers.cloudflare.com/api/operations/dns-settings-for-an-account-list-dns-settings) instead. Deprecated. */
    useAccountCustomNsByDefault: boolean;
}
export declare const AccountsListResultItemSettings: S.Schema<AccountsListResultItemSettings>;
export type AccountsListResultItemType = "standard" | "enterprise";
export declare const AccountsListResultItemType: any;
export interface AccountsListResultItem {
    id: string;
    createdOn: string;
    name: string;
    settings: AccountsListResultItemSettings;
    type: AccountsListResultItemType;
}
export declare const AccountsListResultItem: S.Schema<AccountsListResultItem>;
export type AccountsListResultList = Array<AccountsListResultItem>;
export declare const AccountsListResultList: S.Schema<AccountsListResultList>;
export interface ListAccountsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccountsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAccountsResponse: S.Schema<ListAccountsResponse>;
export interface ListAccountTypesRequest {
    tenantId: string;
}
export declare const ListAccountTypesRequest: S.Schema<ListAccountTypesRequest>;
export type AccountTypesListResultList = Array<string>;
export declare const AccountTypesListResultList: S.Schema<AccountTypesListResultList>;
export interface ListAccountTypesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccountTypesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListAccountTypesResponse: S.Schema<ListAccountTypesResponse>;
export interface ListMembershipsRequest {
    tenantId: string;
}
export declare const ListMembershipsRequest: S.Schema<ListMembershipsRequest>;
export interface MembershipsListResultItem {
    userEmail: string;
    userName: string;
    userTag: string;
}
export declare const MembershipsListResultItem: S.Schema<MembershipsListResultItem>;
export type MembershipsListResultList = Array<MembershipsListResultItem>;
export declare const MembershipsListResultList: S.Schema<MembershipsListResultList>;
export interface ListMembershipsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MembershipsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListMembershipsResponse: S.Schema<ListMembershipsResponse>;
export type GetEntitlementError = CloudflareOpError;
/** List of innate entitlements available for the Tenant. */
export declare const getEntitlement: API.OperationMethod<GetEntitlementRequest, GetEntitlementResponse, GetEntitlementError, CloudflareOpContext>;
export type GetTenantError = CloudflareOpError;
/** Retrieves a Tenant by Tenant ID. */
export declare const getTenant: API.OperationMethod<GetTenantRequest, GetTenantResponse, GetTenantError, CloudflareOpContext>;
export type ListAccountsError = CloudflareOpError;
/** List of accounts for the Tenant. */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, CloudflareOpContext, AccountsListResultItem>;
export type ListAccountTypesError = CloudflareOpError;
/** List of account types available for the Tenant to provision accounts. */
export declare const listAccountTypes: API.PaginatedOperationMethod<ListAccountTypesRequest, ListAccountTypesResponse, ListAccountTypesError, CloudflareOpContext, string>;
export type ListMembershipsError = CloudflareOpError;
/** List of active members (Cloudflare users) for the Tenant. */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, CloudflareOpContext, MembershipsListResultItem>;
//# sourceMappingURL=tenants.d.ts.map