import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AdvancedCertificateManagerRequired_base: S.Class<AdvancedCertificateManagerRequired, S.TaggedStruct<"AdvancedCertificateManagerRequired", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class AdvancedCertificateManagerRequired extends /*@__PURE__*/ AdvancedCertificateManagerRequired_base {
}
declare const CertificatePackNotFound_base: S.Class<CertificatePackNotFound, S.TaggedStruct<"CertificatePackNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class CertificatePackNotFound extends /*@__PURE__*/ CertificatePackNotFound_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export type AnalyzeCreateRequestBundleMethod = "ubiquitous" | "optimal" | "force";
export declare const AnalyzeCreateRequestBundleMethod: any;
export interface CreateAnalyzeRequest {
    /** Identifier. */
    zoneId: string;
    /** A ubiquitous bundle has the highest probability of being verified everywhere, even by clients using outdated or unusual trust stores. An optimal bundle uses the shortest chain and newest intermediates. And the force bundle verifies the chain, but does not otherwise modify it. */
    bundleMethod?: AnalyzeCreateRequestBundleMethod | (string & {});
    /** The zone's SSL certificate or certificate and the intermediate(s). */
    certificate?: string;
}
export declare const CreateAnalyzeRequest: S.Schema<CreateAnalyzeRequest>;
export type CreateAnalyzeResponse = unknown;
export declare const CreateAnalyzeResponse: S.Schema<CreateAnalyzeResponse>;
export type CertificatePacksCreateRequestCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const CertificatePacksCreateRequestCertificateAuthority: any;
export type CertificatePacksCreateRequestHostsList = Array<string>;
export declare const CertificatePacksCreateRequestHostsList: S.Schema<CertificatePacksCreateRequestHostsList>;
export type CertificatePacksCreateRequestType = "advanced";
export declare const CertificatePacksCreateRequestType: any;
export type CertificatePacksCreateRequestValidationMethod = "txt" | "http" | "email";
export declare const CertificatePacksCreateRequestValidationMethod: any;
export type CertificatePacksCreateRequestValidityDays = 14 | 30 | 90 | 365;
export declare const CertificatePacksCreateRequestValidityDays: any;
export interface CreateCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority: CertificatePacksCreateRequestCertificateAuthority | (string & {});
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksCreateRequestHostsList;
    /** Type of certificate pack. */
    type: CertificatePacksCreateRequestType | (string & {});
    /** Validation Method selected for the order. */
    validationMethod: CertificatePacksCreateRequestValidationMethod | (string & {});
    /** Validity Days selected for the order. */
    validityDays: CertificatePacksCreateRequestValidityDays | (number & {});
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean;
}
export declare const CreateCertificatePackRequest: S.Schema<CreateCertificatePackRequest>;
export type CertificatePacksCreateResponseCertificatesItemHostsList = Array<string>;
export declare const CertificatePacksCreateResponseCertificatesItemHostsList: S.Schema<CertificatePacksCreateResponseCertificatesItemHostsList>;
export type CertificatePacksCreateResponseCertificatesItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export declare const CertificatePacksCreateResponseCertificatesItemGeoRestrictionsLabel: any;
export interface CertificatePacksCreateResponseCertificatesItemGeoRestrictions {
    label?: CertificatePacksCreateResponseCertificatesItemGeoRestrictionsLabel | null;
}
export declare const CertificatePacksCreateResponseCertificatesItemGeoRestrictions: S.Schema<CertificatePacksCreateResponseCertificatesItemGeoRestrictions>;
export interface CertificatePacksCreateResponseCertificatesItem {
    /** Certificate identifier. */
    id: string;
    /** Hostnames covered by this certificate. */
    hosts: CertificatePacksCreateResponseCertificatesItemHostsList;
    /** Certificate status. */
    status: string;
    /** Certificate bundle method. */
    bundleMethod?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally. */
    geoRestrictions?: CertificatePacksCreateResponseCertificatesItemGeoRestrictions | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The order/priority in which the certificate will be used. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
    /** Identifier. */
    zoneId?: string | null;
}
export declare const CertificatePacksCreateResponseCertificatesItem: S.Schema<CertificatePacksCreateResponseCertificatesItem>;
export type CertificatePacksCreateResponseCertificatesList = Array<CertificatePacksCreateResponseCertificatesItem>;
export declare const CertificatePacksCreateResponseCertificatesList: S.Schema<CertificatePacksCreateResponseCertificatesList>;
export type CertificatePacksCreateResponseHostsList = Array<string>;
export declare const CertificatePacksCreateResponseHostsList: S.Schema<CertificatePacksCreateResponseHostsList>;
export type CertificatePacksCreateResponseStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export declare const CertificatePacksCreateResponseStatus: any;
export type CertificatePacksCreateResponseType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export declare const CertificatePacksCreateResponseType: any;
export type CertificatePacksCreateResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const CertificatePacksCreateResponseCertificateAuthority: any;
export type CertificatePacksCreateResponseDcvDelegationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksCreateResponseDcvDelegationRecordsItemEmailsList: S.Schema<CertificatePacksCreateResponseDcvDelegationRecordsItemEmailsList>;
export interface CertificatePacksCreateResponseDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksCreateResponseDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksCreateResponseDcvDelegationRecordsItem: S.Schema<CertificatePacksCreateResponseDcvDelegationRecordsItem>;
export type CertificatePacksCreateResponseDcvDelegationRecordsList = Array<CertificatePacksCreateResponseDcvDelegationRecordsItem>;
export declare const CertificatePacksCreateResponseDcvDelegationRecordsList: S.Schema<CertificatePacksCreateResponseDcvDelegationRecordsList>;
export interface CertificatePacksCreateResponseValidationErrorsItem {
    /** A domain validation error. */
    message?: string | null;
}
export declare const CertificatePacksCreateResponseValidationErrorsItem: S.Schema<CertificatePacksCreateResponseValidationErrorsItem>;
export type CertificatePacksCreateResponseValidationErrorsList = Array<CertificatePacksCreateResponseValidationErrorsItem>;
export declare const CertificatePacksCreateResponseValidationErrorsList: S.Schema<CertificatePacksCreateResponseValidationErrorsList>;
export type CertificatePacksCreateResponseValidationMethod = "txt" | "http" | "email";
export declare const CertificatePacksCreateResponseValidationMethod: any;
export type CertificatePacksCreateResponseValidationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksCreateResponseValidationRecordsItemEmailsList: S.Schema<CertificatePacksCreateResponseValidationRecordsItemEmailsList>;
export interface CertificatePacksCreateResponseValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksCreateResponseValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksCreateResponseValidationRecordsItem: S.Schema<CertificatePacksCreateResponseValidationRecordsItem>;
export type CertificatePacksCreateResponseValidationRecordsList = Array<CertificatePacksCreateResponseValidationRecordsItem>;
export declare const CertificatePacksCreateResponseValidationRecordsList: S.Schema<CertificatePacksCreateResponseValidationRecordsList>;
export type CertificatePacksCreateResponseValidityDays = 14 | 30 | 90 | 365;
export declare const CertificatePacksCreateResponseValidityDays: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateCertificatePackResponse {
    /** Identifier. */
    id: string;
    /** Array of certificates in this pack. */
    certificates: CertificatePacksCreateResponseCertificatesList;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksCreateResponseHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksCreateResponseStatus;
    /** Type of certificate pack. */
    type: CertificatePacksCreateResponseType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksCreateResponseCertificateAuthority | null;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePacksCreateResponseDcvDelegationRecordsList | null;
    /** Identifier of the primary certificate in a pack. */
    primaryCertificate?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePacksCreateResponseValidationErrorsList | null;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksCreateResponseValidationMethod | null;
    /** Certificates' validation records. */
    validationRecords?: CertificatePacksCreateResponseValidationRecordsList | null;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksCreateResponseValidityDays | null;
}
export declare const CreateCertificatePackResponse: S.Schema<CreateCertificatePackResponse>;
export interface DeleteCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificatePackId: string;
}
export declare const DeleteCertificatePackRequest: S.Schema<DeleteCertificatePackRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteCertificatePackResponse {
    /** Identifier. */
    id?: string | null;
}
export declare const DeleteCertificatePackResponse: S.Schema<DeleteCertificatePackResponse>;
export interface GetAutomaticUpgraderRequest {
    zoneId: string;
}
export declare const GetAutomaticUpgraderRequest: S.Schema<GetAutomaticUpgraderRequest>;
export type GetAutomaticUpgraderResponseValue = "auto" | "custom";
export declare const GetAutomaticUpgraderResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAutomaticUpgraderResponse {
    id: string;
    /** Whether this setting can be updated or not. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
    /** Current setting of the automatic SSL/TLS. */
    value: GetAutomaticUpgraderResponseValue;
    /** Next time this zone will be scanned by the Automatic SSL/TLS. */
    nextScheduledScan?: string | null;
}
export declare const GetAutomaticUpgraderResponse: S.Schema<GetAutomaticUpgraderResponse>;
export interface GetAutoOriginTlsKexRequest {
    zoneId: string;
}
export declare const GetAutoOriginTlsKexRequest: S.Schema<GetAutoOriginTlsKexRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAutoOriginTlsKexResponse {
    id: string;
    /** Whether Auto-Origin TLS KEX selection is enabled for the zone. */
    enabled: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
}
export declare const GetAutoOriginTlsKexResponse: S.Schema<GetAutoOriginTlsKexResponse>;
export interface GetCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificatePackId: string;
}
export declare const GetCertificatePackRequest: S.Schema<GetCertificatePackRequest>;
export type CertificatePacksGetResponseCertificatesItemHostsList = Array<string>;
export declare const CertificatePacksGetResponseCertificatesItemHostsList: S.Schema<CertificatePacksGetResponseCertificatesItemHostsList>;
export type CertificatePacksGetResponseCertificatesItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export declare const CertificatePacksGetResponseCertificatesItemGeoRestrictionsLabel: any;
export interface CertificatePacksGetResponseCertificatesItemGeoRestrictions {
    label?: CertificatePacksGetResponseCertificatesItemGeoRestrictionsLabel | null;
}
export declare const CertificatePacksGetResponseCertificatesItemGeoRestrictions: S.Schema<CertificatePacksGetResponseCertificatesItemGeoRestrictions>;
export interface CertificatePacksGetResponseCertificatesItem {
    /** Certificate identifier. */
    id: string;
    /** Hostnames covered by this certificate. */
    hosts: CertificatePacksGetResponseCertificatesItemHostsList;
    /** Certificate status. */
    status: string;
    /** Certificate bundle method. */
    bundleMethod?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally. */
    geoRestrictions?: CertificatePacksGetResponseCertificatesItemGeoRestrictions | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The order/priority in which the certificate will be used. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
    /** Identifier. */
    zoneId?: string | null;
}
export declare const CertificatePacksGetResponseCertificatesItem: S.Schema<CertificatePacksGetResponseCertificatesItem>;
export type CertificatePacksGetResponseCertificatesList = Array<CertificatePacksGetResponseCertificatesItem>;
export declare const CertificatePacksGetResponseCertificatesList: S.Schema<CertificatePacksGetResponseCertificatesList>;
export type CertificatePacksGetResponseHostsList = Array<string>;
export declare const CertificatePacksGetResponseHostsList: S.Schema<CertificatePacksGetResponseHostsList>;
export type CertificatePacksGetResponseStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export declare const CertificatePacksGetResponseStatus: any;
export type CertificatePacksGetResponseType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export declare const CertificatePacksGetResponseType: any;
export type CertificatePacksGetResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const CertificatePacksGetResponseCertificateAuthority: any;
export type CertificatePacksGetResponseDcvDelegationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksGetResponseDcvDelegationRecordsItemEmailsList: S.Schema<CertificatePacksGetResponseDcvDelegationRecordsItemEmailsList>;
export interface CertificatePacksGetResponseDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksGetResponseDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksGetResponseDcvDelegationRecordsItem: S.Schema<CertificatePacksGetResponseDcvDelegationRecordsItem>;
export type CertificatePacksGetResponseDcvDelegationRecordsList = Array<CertificatePacksGetResponseDcvDelegationRecordsItem>;
export declare const CertificatePacksGetResponseDcvDelegationRecordsList: S.Schema<CertificatePacksGetResponseDcvDelegationRecordsList>;
export type CertificatePacksGetResponseValidationErrorsItem = CertificatePacksCreateResponseValidationErrorsItem;
export declare const CertificatePacksGetResponseValidationErrorsItem: S.Schema<CertificatePacksCreateResponseValidationErrorsItem>;
export type CertificatePacksGetResponseValidationErrorsList = Array<CertificatePacksCreateResponseValidationErrorsItem>;
export declare const CertificatePacksGetResponseValidationErrorsList: S.Schema<CertificatePacksGetResponseValidationErrorsList>;
export type CertificatePacksGetResponseValidationMethod = "txt" | "http" | "email" | "cname";
export declare const CertificatePacksGetResponseValidationMethod: any;
export type CertificatePacksGetResponseValidationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksGetResponseValidationRecordsItemEmailsList: S.Schema<CertificatePacksGetResponseValidationRecordsItemEmailsList>;
export interface CertificatePacksGetResponseValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksGetResponseValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksGetResponseValidationRecordsItem: S.Schema<CertificatePacksGetResponseValidationRecordsItem>;
export type CertificatePacksGetResponseValidationRecordsList = Array<CertificatePacksGetResponseValidationRecordsItem>;
export declare const CertificatePacksGetResponseValidationRecordsList: S.Schema<CertificatePacksGetResponseValidationRecordsList>;
export type CertificatePacksGetResponseValidityDays = 14 | 30 | 90 | 365;
export declare const CertificatePacksGetResponseValidityDays: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCertificatePackResponse {
    /** Identifier. */
    id: string;
    /** Array of certificates in this pack. */
    certificates: CertificatePacksGetResponseCertificatesList;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksGetResponseHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksGetResponseStatus;
    /** Type of certificate pack. */
    type: CertificatePacksGetResponseType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksGetResponseCertificateAuthority | null;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePacksGetResponseDcvDelegationRecordsList | null;
    /** Identifier of the primary certificate in a pack. */
    primaryCertificate?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePacksGetResponseValidationErrorsList | null;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksGetResponseValidationMethod | null;
    /** Certificates' validation records. */
    validationRecords?: CertificatePacksGetResponseValidationRecordsList | null;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksGetResponseValidityDays | null;
}
export declare const GetCertificatePackResponse: S.Schema<GetCertificatePackResponse>;
export interface GetCertificatePackQuotaRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetCertificatePackQuotaRequest: S.Schema<GetCertificatePackQuotaRequest>;
export interface CertificatePacksQuotaGetResponseAdvanced {
    /** Quantity Allocated. */
    allocated?: number | null;
    /** Quantity Used. */
    used?: number | null;
}
export declare const CertificatePacksQuotaGetResponseAdvanced: S.Schema<CertificatePacksQuotaGetResponseAdvanced>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetCertificatePackQuotaResponse {
    advanced?: CertificatePacksQuotaGetResponseAdvanced | null;
}
export declare const GetCertificatePackQuotaResponse: S.Schema<GetCertificatePackQuotaResponse>;
export interface GetUniversalSettingRequest {
    /** Identifier. */
    zoneId: string;
}
export declare const GetUniversalSettingRequest: S.Schema<GetUniversalSettingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetUniversalSettingResponse {
    /** Disabling Universal SSL removes any currently active Universal SSL certificates for your zone from the edge and prevents any future Universal SSL certificates from being ordered. If there are no advanced certificates or custom certificates uploaded for the domain, visitors will be unable to access the domain over HTTPS. */
    enabled?: boolean | null;
}
export declare const GetUniversalSettingResponse: S.Schema<GetUniversalSettingResponse>;
export interface GetVerificationRequest {
    /** Identifier. */
    zoneId: string;
    /** Immediately retry SSL Verification. */
    retry?: boolean;
}
export declare const GetVerificationRequest: S.Schema<GetVerificationRequest>;
export type VerificationGetResultItemCertificateStatus = "initializing" | "authorizing" | "active" | "expired" | "issuing" | "timing_out" | "pending_deployment";
export declare const VerificationGetResultItemCertificateStatus: any;
export type VerificationGetResultItemSignature = "ECDSAWithSHA256" | "SHA1WithRSA" | "SHA256WithRSA";
export declare const VerificationGetResultItemSignature: any;
export type VerificationGetResultItemValidationMethod = "http" | "cname" | "txt";
export declare const VerificationGetResultItemValidationMethod: any;
export type VerificationGetResultItemVerificationInfoRecordName = "record_name" | "http_url" | "cname" | "txt_name";
export declare const VerificationGetResultItemVerificationInfoRecordName: any;
export type VerificationGetResultItemVerificationInfoRecordTarget = "record_value" | "http_body" | "cname_target" | "txt_value";
export declare const VerificationGetResultItemVerificationInfoRecordTarget: any;
export interface VerificationGetResultItemVerificationInfo {
    /** Name of CNAME record. */
    recordName?: VerificationGetResultItemVerificationInfoRecordName | null;
    /** Target of CNAME record. */
    recordTarget?: VerificationGetResultItemVerificationInfoRecordTarget | null;
}
export declare const VerificationGetResultItemVerificationInfo: S.Schema<VerificationGetResultItemVerificationInfo>;
export type VerificationGetResultItemVerificationType = "cname" | "meta tag";
export declare const VerificationGetResultItemVerificationType: any;
export interface VerificationGetResultItem {
    /** Current status of certificate. */
    certificateStatus: VerificationGetResultItemCertificateStatus;
    /** Certificate Authority is manually reviewing the order. */
    brandCheck?: boolean | null;
    /** Certificate Pack UUID. */
    certPackUuid?: string | null;
    /** Certificate's signature algorithm. */
    signature?: VerificationGetResultItemSignature | null;
    /** Validation method in use for a certificate pack order. */
    validationMethod?: VerificationGetResultItemValidationMethod | null;
    /** Certificate's required verification information. */
    verificationInfo?: VerificationGetResultItemVerificationInfo | null;
    /** Status of the required verification information, omitted if verification status is unknown. */
    verificationStatus?: boolean | null;
    /** Method of verification. */
    verificationType?: VerificationGetResultItemVerificationType | null;
}
export declare const VerificationGetResultItem: S.Schema<VerificationGetResultItem>;
export type VerificationGetResultList = Array<VerificationGetResultItem>;
export declare const VerificationGetResultList: S.Schema<VerificationGetResultList>;
export type GetVerificationResponse = VerificationGetResultList;
export declare const GetVerificationResponse: S.Schema<GetVerificationResponse>;
export type CertificatePacksListRequestDeploy = "staging" | "production";
export declare const CertificatePacksListRequestDeploy: any;
export type CertificatePacksListRequestStatus = "all";
export declare const CertificatePacksListRequestStatus: any;
export interface ListCertificatePacksRequest {
    /** Identifier. */
    zoneId: string;
    /** Specify the deployment environment for the certificate packs. */
    deploy?: CertificatePacksListRequestDeploy | (string & {});
    /** Page number of paginated results. */
    page?: number;
    /** Number of certificate packs per page. */
    perPage?: number;
    /** Include Certificate Packs of all statuses, not just active ones. */
    status?: CertificatePacksListRequestStatus | (string & {});
}
export declare const ListCertificatePacksRequest: S.Schema<ListCertificatePacksRequest>;
export type CertificatePacksListResultItemCertificatesItemHostsList = Array<string>;
export declare const CertificatePacksListResultItemCertificatesItemHostsList: S.Schema<CertificatePacksListResultItemCertificatesItemHostsList>;
export type CertificatePacksListResultItemCertificatesItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export declare const CertificatePacksListResultItemCertificatesItemGeoRestrictionsLabel: any;
export interface CertificatePacksListResultItemCertificatesItemGeoRestrictions {
    label?: CertificatePacksListResultItemCertificatesItemGeoRestrictionsLabel | null;
}
export declare const CertificatePacksListResultItemCertificatesItemGeoRestrictions: S.Schema<CertificatePacksListResultItemCertificatesItemGeoRestrictions>;
export interface CertificatePacksListResultItemCertificatesItem {
    /** Certificate identifier. */
    id: string;
    /** Hostnames covered by this certificate. */
    hosts: CertificatePacksListResultItemCertificatesItemHostsList;
    /** Certificate status. */
    status: string;
    /** Certificate bundle method. */
    bundleMethod?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally. */
    geoRestrictions?: CertificatePacksListResultItemCertificatesItemGeoRestrictions | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The order/priority in which the certificate will be used. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
    /** Identifier. */
    zoneId?: string | null;
}
export declare const CertificatePacksListResultItemCertificatesItem: S.Schema<CertificatePacksListResultItemCertificatesItem>;
export type CertificatePacksListResultItemCertificatesList = Array<CertificatePacksListResultItemCertificatesItem>;
export declare const CertificatePacksListResultItemCertificatesList: S.Schema<CertificatePacksListResultItemCertificatesList>;
export type CertificatePacksListResultItemHostsList = Array<string>;
export declare const CertificatePacksListResultItemHostsList: S.Schema<CertificatePacksListResultItemHostsList>;
export type CertificatePacksListResultItemStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export declare const CertificatePacksListResultItemStatus: any;
export type CertificatePacksListResultItemType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export declare const CertificatePacksListResultItemType: any;
export type CertificatePacksListResultItemCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const CertificatePacksListResultItemCertificateAuthority: any;
export type CertificatePacksListResultItemDcvDelegationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksListResultItemDcvDelegationRecordsItemEmailsList: S.Schema<CertificatePacksListResultItemDcvDelegationRecordsItemEmailsList>;
export interface CertificatePacksListResultItemDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksListResultItemDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksListResultItemDcvDelegationRecordsItem: S.Schema<CertificatePacksListResultItemDcvDelegationRecordsItem>;
export type CertificatePacksListResultItemDcvDelegationRecordsList = Array<CertificatePacksListResultItemDcvDelegationRecordsItem>;
export declare const CertificatePacksListResultItemDcvDelegationRecordsList: S.Schema<CertificatePacksListResultItemDcvDelegationRecordsList>;
export type CertificatePacksListResultItemValidationErrorsItem = CertificatePacksCreateResponseValidationErrorsItem;
export declare const CertificatePacksListResultItemValidationErrorsItem: S.Schema<CertificatePacksCreateResponseValidationErrorsItem>;
export type CertificatePacksListResultItemValidationErrorsList = Array<CertificatePacksCreateResponseValidationErrorsItem>;
export declare const CertificatePacksListResultItemValidationErrorsList: S.Schema<CertificatePacksListResultItemValidationErrorsList>;
export type CertificatePacksListResultItemValidationMethod = "txt" | "http" | "email";
export declare const CertificatePacksListResultItemValidationMethod: any;
export type CertificatePacksListResultItemValidationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksListResultItemValidationRecordsItemEmailsList: S.Schema<CertificatePacksListResultItemValidationRecordsItemEmailsList>;
export interface CertificatePacksListResultItemValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksListResultItemValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksListResultItemValidationRecordsItem: S.Schema<CertificatePacksListResultItemValidationRecordsItem>;
export type CertificatePacksListResultItemValidationRecordsList = Array<CertificatePacksListResultItemValidationRecordsItem>;
export declare const CertificatePacksListResultItemValidationRecordsList: S.Schema<CertificatePacksListResultItemValidationRecordsList>;
export type CertificatePacksListResultItemValidityDays = 14 | 30 | 90 | 365;
export declare const CertificatePacksListResultItemValidityDays: any;
export interface CertificatePacksListResultItem {
    /** Identifier. */
    id: string;
    /** Array of certificates in this pack. */
    certificates: CertificatePacksListResultItemCertificatesList;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksListResultItemHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksListResultItemStatus;
    /** Type of certificate pack. */
    type: CertificatePacksListResultItemType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksListResultItemCertificateAuthority | null;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePacksListResultItemDcvDelegationRecordsList | null;
    /** Identifier of the primary certificate in a pack. */
    primaryCertificate?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePacksListResultItemValidationErrorsList | null;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksListResultItemValidationMethod | null;
    /** Certificates' validation records. */
    validationRecords?: CertificatePacksListResultItemValidationRecordsList | null;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksListResultItemValidityDays | null;
}
export declare const CertificatePacksListResultItem: S.Schema<CertificatePacksListResultItem>;
export type CertificatePacksListResultList = Array<CertificatePacksListResultItem>;
export declare const CertificatePacksListResultList: S.Schema<CertificatePacksListResultList>;
export interface ListCertificatePacksResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: CertificatePacksListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListCertificatePacksResponse: S.Schema<ListCertificatePacksResponse>;
export type PatchAutomaticUpgraderRequestValue = "auto" | "custom";
export declare const PatchAutomaticUpgraderRequestValue: any;
export interface PatchAutomaticUpgraderRequest {
    zoneId: string;
    /** Controls enablement of Automatic SSL/TLS. */
    value: PatchAutomaticUpgraderRequestValue | (string & {});
}
export declare const PatchAutomaticUpgraderRequest: S.Schema<PatchAutomaticUpgraderRequest>;
export type PatchAutomaticUpgraderResponseValue = "auto" | "custom";
export declare const PatchAutomaticUpgraderResponseValue: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAutomaticUpgraderResponse {
    id: string;
    /** Whether this setting can be updated or not. */
    editable: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
    /** Current setting of the automatic SSL/TLS. */
    value: PatchAutomaticUpgraderResponseValue;
    /** Next time this zone will be scanned by the Automatic SSL/TLS. */
    nextScheduledScan?: string | null;
}
export declare const PatchAutomaticUpgraderResponse: S.Schema<PatchAutomaticUpgraderResponse>;
export interface PatchAutoOriginTlsKexRequest {
    zoneId: string;
    /** Controls enablement of Auto-Origin TLS KEX selection for the zone. */
    enabled: boolean;
}
export declare const PatchAutoOriginTlsKexRequest: S.Schema<PatchAutoOriginTlsKexRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchAutoOriginTlsKexResponse {
    id: string;
    /** Whether Auto-Origin TLS KEX selection is enabled for the zone. */
    enabled: boolean;
    /** Last time this setting was modified. */
    modifiedOn: string;
}
export declare const PatchAutoOriginTlsKexResponse: S.Schema<PatchAutoOriginTlsKexResponse>;
export interface PatchCertificatePackRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    certificatePackId: string;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean;
}
export declare const PatchCertificatePackRequest: S.Schema<PatchCertificatePackRequest>;
export type CertificatePacksEditResponseCertificatesItemHostsList = Array<string>;
export declare const CertificatePacksEditResponseCertificatesItemHostsList: S.Schema<CertificatePacksEditResponseCertificatesItemHostsList>;
export type CertificatePacksEditResponseCertificatesItemGeoRestrictionsLabel = "us" | "eu" | "highest_security";
export declare const CertificatePacksEditResponseCertificatesItemGeoRestrictionsLabel: any;
export interface CertificatePacksEditResponseCertificatesItemGeoRestrictions {
    label?: CertificatePacksEditResponseCertificatesItemGeoRestrictionsLabel | null;
}
export declare const CertificatePacksEditResponseCertificatesItemGeoRestrictions: S.Schema<CertificatePacksEditResponseCertificatesItemGeoRestrictions>;
export interface CertificatePacksEditResponseCertificatesItem {
    /** Certificate identifier. */
    id: string;
    /** Hostnames covered by this certificate. */
    hosts: CertificatePacksEditResponseCertificatesItemHostsList;
    /** Certificate status. */
    status: string;
    /** Certificate bundle method. */
    bundleMethod?: string | null;
    /** When the certificate from the authority expires. */
    expiresOn?: string | null;
    /** Specify the region where your private key can be held locally. */
    geoRestrictions?: CertificatePacksEditResponseCertificatesItemGeoRestrictions | null;
    /** The certificate authority that issued the certificate. */
    issuer?: string | null;
    /** When the certificate was last modified. */
    modifiedOn?: string | null;
    /** The order/priority in which the certificate will be used. */
    priority?: number | null;
    /** The type of hash used for the certificate. */
    signature?: string | null;
    /** When the certificate was uploaded to Cloudflare. */
    uploadedOn?: string | null;
    /** Identifier. */
    zoneId?: string | null;
}
export declare const CertificatePacksEditResponseCertificatesItem: S.Schema<CertificatePacksEditResponseCertificatesItem>;
export type CertificatePacksEditResponseCertificatesList = Array<CertificatePacksEditResponseCertificatesItem>;
export declare const CertificatePacksEditResponseCertificatesList: S.Schema<CertificatePacksEditResponseCertificatesList>;
export type CertificatePacksEditResponseHostsList = Array<string>;
export declare const CertificatePacksEditResponseHostsList: S.Schema<CertificatePacksEditResponseHostsList>;
export type CertificatePacksEditResponseStatus = "initializing" | "pending_validation" | "deleted" | "pending_issuance" | "pending_deployment" | "pending_deletion" | "pending_expiration" | "expired" | "active" | "initializing_timed_out" | "validation_timed_out" | "issuance_timed_out" | "deployment_timed_out" | "deletion_timed_out" | "pending_cleanup" | "staging_deployment" | "staging_active" | "deactivating" | "inactive" | "backup_issued" | "holding_deployment";
export declare const CertificatePacksEditResponseStatus: any;
export type CertificatePacksEditResponseType = "mh_custom" | "managed_hostname" | "sni_custom" | "universal" | "advanced" | "total_tls" | "keyless" | "legacy_custom";
export declare const CertificatePacksEditResponseType: any;
export type CertificatePacksEditResponseCertificateAuthority = "google" | "lets_encrypt" | "ssl_com";
export declare const CertificatePacksEditResponseCertificateAuthority: any;
export type CertificatePacksEditResponseDcvDelegationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksEditResponseDcvDelegationRecordsItemEmailsList: S.Schema<CertificatePacksEditResponseDcvDelegationRecordsItemEmailsList>;
export interface CertificatePacksEditResponseDcvDelegationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksEditResponseDcvDelegationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksEditResponseDcvDelegationRecordsItem: S.Schema<CertificatePacksEditResponseDcvDelegationRecordsItem>;
export type CertificatePacksEditResponseDcvDelegationRecordsList = Array<CertificatePacksEditResponseDcvDelegationRecordsItem>;
export declare const CertificatePacksEditResponseDcvDelegationRecordsList: S.Schema<CertificatePacksEditResponseDcvDelegationRecordsList>;
export type CertificatePacksEditResponseValidationErrorsItem = CertificatePacksCreateResponseValidationErrorsItem;
export declare const CertificatePacksEditResponseValidationErrorsItem: S.Schema<CertificatePacksCreateResponseValidationErrorsItem>;
export type CertificatePacksEditResponseValidationErrorsList = Array<CertificatePacksCreateResponseValidationErrorsItem>;
export declare const CertificatePacksEditResponseValidationErrorsList: S.Schema<CertificatePacksEditResponseValidationErrorsList>;
export type CertificatePacksEditResponseValidationMethod = "txt" | "http" | "email";
export declare const CertificatePacksEditResponseValidationMethod: any;
export type CertificatePacksEditResponseValidationRecordsItemEmailsList = Array<string>;
export declare const CertificatePacksEditResponseValidationRecordsItemEmailsList: S.Schema<CertificatePacksEditResponseValidationRecordsItemEmailsList>;
export interface CertificatePacksEditResponseValidationRecordsItem {
    /** The CNAME record hostname for DCV delegation. */
    cname?: string | null;
    /** The CNAME record target value for DCV delegation. */
    cnameTarget?: string | null;
    /** The set of email addresses that the certificate authority (CA) will use to complete domain validation. */
    emails?: CertificatePacksEditResponseValidationRecordsItemEmailsList | null;
    /** The content that the certificate authority (CA) will expect to find at the http_url during the domain validation. */
    httpBody?: string | null;
    /** The url that will be checked during domain validation. */
    httpUrl?: string | null;
    /** Status of the validation record. */
    status?: string | null;
    /** The hostname that the certificate authority (CA) will check for a TXT record during domain validation . */
    txtName?: string | null;
    /** The TXT record that the certificate authority (CA) will check during domain validation. */
    txtValue?: string | null;
}
export declare const CertificatePacksEditResponseValidationRecordsItem: S.Schema<CertificatePacksEditResponseValidationRecordsItem>;
export type CertificatePacksEditResponseValidationRecordsList = Array<CertificatePacksEditResponseValidationRecordsItem>;
export declare const CertificatePacksEditResponseValidationRecordsList: S.Schema<CertificatePacksEditResponseValidationRecordsList>;
export type CertificatePacksEditResponseValidityDays = 14 | 30 | 90 | 365;
export declare const CertificatePacksEditResponseValidityDays: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchCertificatePackResponse {
    /** Identifier. */
    id: string;
    /** Array of certificates in this pack. */
    certificates: CertificatePacksEditResponseCertificatesList;
    /** Comma separated list of valid host names for the certificate packs. Must contain the zone apex, may not contain more than 50 hosts, and may not be empty. */
    hosts: CertificatePacksEditResponseHostsList;
    /** Status of certificate pack. */
    status: CertificatePacksEditResponseStatus;
    /** Type of certificate pack. */
    type: CertificatePacksEditResponseType;
    /** Certificate Authority selected for the order. For information on any certificate authority specific details or restrictions [see this page for more details](https://developers.cloudflare.com/ssl/reference/certificate-authorities). */
    certificateAuthority?: CertificatePacksEditResponseCertificateAuthority | null;
    /** Whether or not to add Cloudflare Branding for the order. This will add a subdomain of sni.cloudflaressl.com as the Common Name if set to true. */
    cloudflareBranding?: boolean | null;
    /** DCV Delegation records for domain validation. */
    dcvDelegationRecords?: CertificatePacksEditResponseDcvDelegationRecordsList | null;
    /** Identifier of the primary certificate in a pack. */
    primaryCertificate?: string | null;
    /** Domain validation errors that have been received by the certificate authority (CA). */
    validationErrors?: CertificatePacksEditResponseValidationErrorsList | null;
    /** Validation Method selected for the order. */
    validationMethod?: CertificatePacksEditResponseValidationMethod | null;
    /** Certificates' validation records. */
    validationRecords?: CertificatePacksEditResponseValidationRecordsList | null;
    /** Validity Days selected for the order. */
    validityDays?: CertificatePacksEditResponseValidityDays | null;
}
export declare const PatchCertificatePackResponse: S.Schema<PatchCertificatePackResponse>;
export interface PatchUniversalSettingRequest {
    /** Identifier. */
    zoneId: string;
    /** Disabling Universal SSL removes any currently active Universal SSL certificates for your zone from the edge and prevents any future Universal SSL certificates from being ordered. If there are no advanced certificates or custom certificates uploaded for the domain, visitors will be unable to access the domain over HTTPS. */
    enabled?: boolean;
}
export declare const PatchUniversalSettingRequest: S.Schema<PatchUniversalSettingRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchUniversalSettingResponse {
    /** Disabling Universal SSL removes any currently active Universal SSL certificates for your zone from the edge and prevents any future Universal SSL certificates from being ordered. If there are no advanced certificates or custom certificates uploaded for the domain, visitors will be unable to access the domain over HTTPS. */
    enabled?: boolean | null;
}
export declare const PatchUniversalSettingResponse: S.Schema<PatchUniversalSettingResponse>;
export type VerificationEditRequestValidationMethod = "http" | "cname" | "txt" | "email";
export declare const VerificationEditRequestValidationMethod: any;
export interface PatchVerificationRequest {
    /** Identifier. */
    zoneId: string;
    /** Certificate Pack UUID. */
    certificatePackId: string;
    /** Desired validation method. */
    validationMethod: VerificationEditRequestValidationMethod | (string & {});
}
export declare const PatchVerificationRequest: S.Schema<PatchVerificationRequest>;
export type VerificationEditResponseValidationMethod = "http" | "cname" | "txt" | "email";
export declare const VerificationEditResponseValidationMethod: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchVerificationResponse {
    /** Result status. */
    status?: string | null;
    /** Desired validation method. */
    validationMethod?: VerificationEditResponseValidationMethod | null;
}
export declare const PatchVerificationResponse: S.Schema<PatchVerificationResponse>;
export type CreateAnalyzeError = CloudflareOpError;
/** Returns the set of hostnames, the signature algorithm, and the expiration date of the certificate. */
export declare const createAnalyze: API.OperationMethod<CreateAnalyzeRequest, CreateAnalyzeResponse, CreateAnalyzeError, CloudflareOpContext>;
export type CreateCertificatePackError = AdvancedCertificateManagerRequired | Forbidden | CloudflareOpError;
/** For a given zone, order an advanced certificate pack. */
export declare const createCertificatePack: API.OperationMethod<CreateCertificatePackRequest, CreateCertificatePackResponse, CreateCertificatePackError, CloudflareOpContext>;
export type DeleteCertificatePackError = CertificatePackNotFound | Forbidden | CloudflareOpError;
/** For a given zone, delete an advanced certificate pack. */
export declare const deleteCertificatePack: API.OperationMethod<DeleteCertificatePackRequest, DeleteCertificatePackResponse, DeleteCertificatePackError, CloudflareOpContext>;
export type GetAutomaticUpgraderError = CloudflareOpError;
/** If the system is enabled, the response will include next_scheduled_scan, representing the next time this zone will be scanned and the zone's ssl/tls encryption mode is potentially upgraded by the system. If the system is disabled, next_scheduled_scan will not be present in the response body. */
export declare const getAutomaticUpgrader: API.OperationMethod<GetAutomaticUpgraderRequest, GetAutomaticUpgraderResponse, GetAutomaticUpgraderError, CloudflareOpContext>;
export type GetAutoOriginTlsKexError = CloudflareOpError;
/** When enabled, Cloudflare automatically selects the preferred TLS key-exchange algorithm to use when establishing the TLS connection to the zone's origin, picking from the algorithms permitted by the zone's `origin_tls_compliance_modes` setting. When disabled, the default key-exchange ordering is used. */
export declare const getAutoOriginTlsKex: API.OperationMethod<GetAutoOriginTlsKexRequest, GetAutoOriginTlsKexResponse, GetAutoOriginTlsKexError, CloudflareOpContext>;
export type GetCertificatePackError = CertificatePackNotFound | Forbidden | CloudflareOpError;
/** For a given zone, get a certificate pack. */
export declare const getCertificatePack: API.OperationMethod<GetCertificatePackRequest, GetCertificatePackResponse, GetCertificatePackError, CloudflareOpContext>;
export type GetCertificatePackQuotaError = CloudflareOpError;
/** For a given zone, list certificate pack quotas. */
export declare const getCertificatePackQuota: API.OperationMethod<GetCertificatePackQuotaRequest, GetCertificatePackQuotaResponse, GetCertificatePackQuotaError, CloudflareOpContext>;
export type GetUniversalSettingError = Forbidden | CloudflareOpError;
/** Get Universal SSL Settings for a Zone. */
export declare const getUniversalSetting: API.OperationMethod<GetUniversalSettingRequest, GetUniversalSettingResponse, GetUniversalSettingError, CloudflareOpContext>;
export type GetVerificationError = CloudflareOpError;
/** Get SSL Verification Info for a Zone. */
export declare const getVerification: API.OperationMethod<GetVerificationRequest, GetVerificationResponse, GetVerificationError, CloudflareOpContext>;
export type ListCertificatePacksError = Forbidden | CloudflareOpError;
/** For a given zone, list all active certificate packs. */
export declare const listCertificatePacks: API.PaginatedOperationMethod<ListCertificatePacksRequest, ListCertificatePacksResponse, ListCertificatePacksError, CloudflareOpContext, CertificatePacksListResultItem>;
export type PatchAutomaticUpgraderError = CloudflareOpError;
/** The automatic system is enabled when this endpoint is hit with value in the request body is set to "auto", and disabled when the request body value is set to "custom". */
export declare const patchAutomaticUpgrader: API.OperationMethod<PatchAutomaticUpgraderRequest, PatchAutomaticUpgraderResponse, PatchAutomaticUpgraderError, CloudflareOpContext>;
export type PatchAutoOriginTlsKexError = CloudflareOpError;
/** Enable or disable Auto-Origin TLS KEX selection for the zone by sending `{"enabled": true}` or `{"enabled": false}`. When enabled, Cloudflare runs a periodic scan of the zone's origins to determine the preferred key-exchange algorithm and writes that preference to the edge so it is sent first in the TLS ClientHello to the origin. */
export declare const patchAutoOriginTlsKex: API.OperationMethod<PatchAutoOriginTlsKexRequest, PatchAutoOriginTlsKexResponse, PatchAutoOriginTlsKexError, CloudflareOpContext>;
export type PatchCertificatePackError = CertificatePackNotFound | Forbidden | CloudflareOpError;
/** For a given zone, restart validation or add cloudflare branding for an advanced certificate pack. The former is only a validation operation for a Certificate Pack in a validation_timed_out status. */
export declare const patchCertificatePack: API.OperationMethod<PatchCertificatePackRequest, PatchCertificatePackResponse, PatchCertificatePackError, CloudflareOpContext>;
export type PatchUniversalSettingError = Forbidden | CloudflareOpError;
/** Patch Universal SSL Settings for a Zone. */
export declare const patchUniversalSetting: API.OperationMethod<PatchUniversalSettingRequest, PatchUniversalSettingResponse, PatchUniversalSettingError, CloudflareOpContext>;
export type PatchVerificationError = CloudflareOpError;
/** Edit SSL validation method for a certificate pack. A PATCH request will request an immediate validation check on any certificate, and return the updated status. If a validation method is provided, the validation will be immediately attempted using that method. */
export declare const patchVerification: API.OperationMethod<PatchVerificationRequest, PatchVerificationResponse, PatchVerificationError, CloudflareOpContext>;
//# sourceMappingURL=ssl.d.ts.map