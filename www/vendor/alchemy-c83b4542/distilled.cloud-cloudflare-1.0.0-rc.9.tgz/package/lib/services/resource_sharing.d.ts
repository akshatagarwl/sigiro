import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const ShareNotFound_base: S.Class<ShareNotFound, S.TaggedStruct<"ShareNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ShareNotFound extends /*@__PURE__*/ ShareNotFound_base {
}
declare const ShareRecipientNotFound_base: S.Class<ShareRecipientNotFound, S.TaggedStruct<"ShareRecipientNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ShareRecipientNotFound extends /*@__PURE__*/ ShareRecipientNotFound_base {
}
declare const ShareResourceNotFound_base: S.Class<ShareResourceNotFound, S.TaggedStruct<"ShareResourceNotFound", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ShareResourceNotFound extends /*@__PURE__*/ ShareResourceNotFound_base {
}
export interface CreateRecipientRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Organization identifier. */
    organizationId?: string;
    /** The account that will receive the share. */
    recipientAccountId?: string;
}
export declare const CreateRecipientRequest: S.Schema<CreateRecipientRequest>;
export type RecipientsCreateResponseAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export declare const RecipientsCreateResponseAssociationStatus: any;
export interface RecipientsCreateResponseResourcesItem {
    /** Share Recipient error message. */
    error: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Version. */
    resourceVersion: number;
    /** Whether the error is terminal or will be continually retried. */
    terminal: boolean;
}
export declare const RecipientsCreateResponseResourcesItem: S.Schema<RecipientsCreateResponseResourcesItem>;
export type RecipientsCreateResponseResourcesList = Array<RecipientsCreateResponseResourcesItem>;
export declare const RecipientsCreateResponseResourcesList: S.Schema<RecipientsCreateResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRecipientResponse {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** Share Recipient association status. */
    associationStatus: RecipientsCreateResponseAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsCreateResponseResourcesList | null;
}
export declare const CreateRecipientResponse: S.Schema<CreateRecipientResponse>;
export type ResourcesCreateRequestResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ResourcesCreateRequestResourceType: any;
export interface CreateResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Resource Metadata. */
    meta: unknown;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesCreateRequestResourceType | (string & {});
}
export declare const CreateResourceRequest: S.Schema<CreateResourceRequest>;
export type ResourcesCreateResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ResourcesCreateResponseResourceType: any;
export type ResourcesCreateResponseStatus = "active" | "deleting" | "deleted";
export declare const ResourcesCreateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesCreateResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesCreateResponseStatus;
}
export declare const CreateResourceResponse: S.Schema<CreateResourceResponse>;
export interface CreateRequestRecipientsItem {
    /** Deprecated alias for `recipient_account_id`. Use `recipient_account_id` instead. */
    accountId?: string;
    /** Organization identifier. */
    organizationId?: string;
    /** The account that will receive the share. */
    recipientAccountId?: string;
}
export declare const CreateRequestRecipientsItem: S.Schema<CreateRequestRecipientsItem>;
export type CreateRequestRecipientsList = Array<CreateRequestRecipientsItem>;
export declare const CreateRequestRecipientsList: S.Schema<CreateRequestRecipientsList>;
export type CreateRequestResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const CreateRequestResourcesItemResourceType: any;
export interface CreateRequestResourcesItem {
    /** Resource Metadata. */
    meta: unknown;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: CreateRequestResourcesItemResourceType | (string & {});
}
export declare const CreateRequestResourcesItem: S.Schema<CreateRequestResourcesItem>;
export type CreateRequestResourcesList = Array<CreateRequestResourcesItem>;
export declare const CreateRequestResourcesList: S.Schema<CreateRequestResourcesList>;
export interface CreateResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** The name of the share. */
    name: string;
    recipients: CreateRequestRecipientsList;
    resources: CreateRequestResourcesList;
}
export declare const CreateResourceSharingRequest: S.Schema<CreateResourceSharingRequest>;
export type CreateResponseStatus = "active" | "deleting" | "deleted";
export declare const CreateResponseStatus: any;
export type CreateResponseTargetType = "account" | "organization";
export declare const CreateResponseTargetType: any;
export type CreateResponseKind = "sent" | "received";
export declare const CreateResponseKind: any;
export type CreateResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const CreateResponseResourcesItemResourceType: any;
export type CreateResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export declare const CreateResponseResourcesItemStatus: any;
export interface CreateResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: CreateResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: CreateResponseResourcesItemStatus;
}
export declare const CreateResponseResourcesItem: S.Schema<CreateResponseResourcesItem>;
export type CreateResponseResourcesList = Array<CreateResponseResourcesItem>;
export declare const CreateResponseResourcesList: S.Schema<CreateResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: CreateResponseStatus;
    targetType: CreateResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: CreateResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: CreateResponseResourcesList | null;
}
export declare const CreateResourceSharingResponse: S.Schema<CreateResourceSharingResponse>;
export interface DeleteRecipientRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Recipient identifier tag. */
    recipientId: string;
}
export declare const DeleteRecipientRequest: S.Schema<DeleteRecipientRequest>;
export type RecipientsDeleteResponseAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export declare const RecipientsDeleteResponseAssociationStatus: any;
export type RecipientsDeleteResponseResourcesItem = RecipientsCreateResponseResourcesItem;
export declare const RecipientsDeleteResponseResourcesItem: S.Schema<RecipientsCreateResponseResourcesItem>;
export type RecipientsDeleteResponseResourcesList = Array<RecipientsCreateResponseResourcesItem>;
export declare const RecipientsDeleteResponseResourcesList: S.Schema<RecipientsDeleteResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteRecipientResponse {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** Share Recipient association status. */
    associationStatus: RecipientsDeleteResponseAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsDeleteResponseResourcesList | null;
}
export declare const DeleteRecipientResponse: S.Schema<DeleteRecipientResponse>;
export interface DeleteResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Resource identifier. */
    shareResourceId: string;
}
export declare const DeleteResourceRequest: S.Schema<DeleteResourceRequest>;
export type ResourcesDeleteResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ResourcesDeleteResponseResourceType: any;
export type ResourcesDeleteResponseStatus = "active" | "deleting" | "deleted";
export declare const ResourcesDeleteResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesDeleteResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesDeleteResponseStatus;
}
export declare const DeleteResourceResponse: S.Schema<DeleteResourceResponse>;
export interface DeleteResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
}
export declare const DeleteResourceSharingRequest: S.Schema<DeleteResourceSharingRequest>;
export type DeleteResponseStatus = "active" | "deleting" | "deleted";
export declare const DeleteResponseStatus: any;
export type DeleteResponseTargetType = "account" | "organization";
export declare const DeleteResponseTargetType: any;
export type DeleteResponseKind = "sent" | "received";
export declare const DeleteResponseKind: any;
export type DeleteResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const DeleteResponseResourcesItemResourceType: any;
export type DeleteResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export declare const DeleteResponseResourcesItemStatus: any;
export interface DeleteResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: DeleteResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: DeleteResponseResourcesItemStatus;
}
export declare const DeleteResponseResourcesItem: S.Schema<DeleteResponseResourcesItem>;
export type DeleteResponseResourcesList = Array<DeleteResponseResourcesItem>;
export declare const DeleteResponseResourcesList: S.Schema<DeleteResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: DeleteResponseStatus;
    targetType: DeleteResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: DeleteResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: DeleteResponseResourcesList | null;
}
export declare const DeleteResourceSharingResponse: S.Schema<DeleteResourceSharingResponse>;
export interface GetRecipientRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Recipient identifier tag. */
    recipientId: string;
    /** Include resources in the response. */
    includeResources?: boolean;
}
export declare const GetRecipientRequest: S.Schema<GetRecipientRequest>;
export type RecipientsGetResponseAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export declare const RecipientsGetResponseAssociationStatus: any;
export type RecipientsGetResponseResourcesItem = RecipientsCreateResponseResourcesItem;
export declare const RecipientsGetResponseResourcesItem: S.Schema<RecipientsCreateResponseResourcesItem>;
export type RecipientsGetResponseResourcesList = Array<RecipientsCreateResponseResourcesItem>;
export declare const RecipientsGetResponseResourcesList: S.Schema<RecipientsGetResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRecipientResponse {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** Share Recipient association status. */
    associationStatus: RecipientsGetResponseAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsGetResponseResourcesList | null;
}
export declare const GetRecipientResponse: S.Schema<GetRecipientResponse>;
export interface GetResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Resource identifier. */
    shareResourceId: string;
}
export declare const GetResourceRequest: S.Schema<GetResourceRequest>;
export type ResourcesGetResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ResourcesGetResponseResourceType: any;
export type ResourcesGetResponseStatus = "active" | "deleting" | "deleted";
export declare const ResourcesGetResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesGetResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesGetResponseStatus;
}
export declare const GetResourceResponse: S.Schema<GetResourceResponse>;
export interface GetResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Include recipient counts in the response. */
    includeRecipientCounts?: boolean;
    /** Include resources in the response. */
    includeResources?: boolean;
}
export declare const GetResourceSharingRequest: S.Schema<GetResourceSharingRequest>;
export type GetResponseStatus = "active" | "deleting" | "deleted";
export declare const GetResponseStatus: any;
export type GetResponseTargetType = "account" | "organization";
export declare const GetResponseTargetType: any;
export type GetResponseKind = "sent" | "received";
export declare const GetResponseKind: any;
export type GetResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const GetResponseResourcesItemResourceType: any;
export type GetResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export declare const GetResponseResourcesItemStatus: any;
export interface GetResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: GetResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: GetResponseResourcesItemStatus;
}
export declare const GetResponseResourcesItem: S.Schema<GetResponseResourcesItem>;
export type GetResponseResourcesList = Array<GetResponseResourcesItem>;
export declare const GetResponseResourcesList: S.Schema<GetResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: GetResponseStatus;
    targetType: GetResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: GetResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: GetResponseResourcesList | null;
}
export declare const GetResourceSharingResponse: S.Schema<GetResourceSharingResponse>;
export interface ListRecipientsRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Include resources in the response. */
    includeResources?: boolean;
    /** Page number. Defaults to `1` when `per_page` is supplied without */
    page?: number;
    /** Number of objects to return per page. Defaults to `20` when `page` */
    perPage?: number;
}
export declare const ListRecipientsRequest: S.Schema<ListRecipientsRequest>;
export type RecipientsListResultItemAssociationStatus = "associating" | "associated" | "disassociating" | "disassociated";
export declare const RecipientsListResultItemAssociationStatus: any;
export type RecipientsListResultItemResourcesItem = RecipientsCreateResponseResourcesItem;
export declare const RecipientsListResultItemResourcesItem: S.Schema<RecipientsCreateResponseResourcesItem>;
export type RecipientsListResultItemResourcesList = Array<RecipientsCreateResponseResourcesItem>;
export declare const RecipientsListResultItemResourcesList: S.Schema<RecipientsListResultItemResourcesList>;
export interface RecipientsListResultItem {
    /** Share Recipient identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** Share Recipient association status. */
    associationStatus: RecipientsListResultItemAssociationStatus;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    resources?: RecipientsListResultItemResourcesList | null;
}
export declare const RecipientsListResultItem: S.Schema<RecipientsListResultItem>;
export type RecipientsListResultList = Array<RecipientsListResultItem>;
export declare const RecipientsListResultList: S.Schema<RecipientsListResultList>;
export interface ListRecipientsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RecipientsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListRecipientsResponse: S.Schema<ListRecipientsResponse>;
export type ResourcesListRequestResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ResourcesListRequestResourceType: any;
export type ResourcesListRequestStatus = "active" | "deleting" | "deleted";
export declare const ResourcesListRequestStatus: any;
export interface ListResourcesRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Page number. Defaults to `1` when `per_page` is supplied without */
    page?: number;
    /** Number of objects to return per page. Defaults to `20` when `page` */
    perPage?: number;
    /** Filter share resources by resource_type. */
    resourceType?: ResourcesListRequestResourceType | (string & {});
    /** Filter share resources by status. */
    status?: ResourcesListRequestStatus | (string & {});
}
export declare const ListResourcesRequest: S.Schema<ListResourcesRequest>;
export type ResourcesListResultItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ResourcesListResultItemResourceType: any;
export type ResourcesListResultItemStatus = "active" | "deleting" | "deleted";
export declare const ResourcesListResultItemStatus: any;
export interface ResourcesListResultItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesListResultItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesListResultItemStatus;
}
export declare const ResourcesListResultItem: S.Schema<ResourcesListResultItem>;
export type ResourcesListResultList = Array<ResourcesListResultItem>;
export declare const ResourcesListResultList: S.Schema<ResourcesListResultList>;
export interface ListResourcesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ResourcesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListResourcesResponse: S.Schema<ListResourcesResponse>;
export type ListRequestDirection = "asc" | "desc";
export declare const ListRequestDirection: any;
export type ListRequestKind = "sent" | "received";
export declare const ListRequestKind: any;
export type ListRequestOrder = "name" | "created";
export declare const ListRequestOrder: any;
export type ListRequestResourceTypes = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ListRequestResourceTypes: any;
export type ListRequestResourceTypesList = Array<ListRequestResourceTypes | (string & {})>;
export declare const ListRequestResourceTypesList: S.Schema<ListRequestResourceTypesList>;
export type ListRequestStatus = "active" | "deleting" | "deleted";
export declare const ListRequestStatus: any;
export type ListRequestTagList = Array<string>;
export declare const ListRequestTagList: S.Schema<ListRequestTagList>;
export type ListRequestTargetType = "account" | "organization";
export declare const ListRequestTargetType: any;
export interface ListResourceSharingsRequest {
    /** Account identifier. */
    accountId: string;
    /** Direction to sort objects. */
    direction?: ListRequestDirection | (string & {});
    /** Include recipient counts in the response. */
    includeRecipientCounts?: boolean;
    /** Include resources in the response. */
    includeResources?: boolean;
    /** Filter shares by kind. */
    kind?: ListRequestKind | (string & {});
    /** Order shares by values in the given field. */
    order?: ListRequestOrder | (string & {});
    /** Page number. Defaults to `1` when `per_page` is supplied without */
    page?: number;
    /** Number of objects to return per page. Defaults to `20` when `page` */
    perPage?: number;
    /** Filter share resources by resource_types. */
    resourceTypes?: ListRequestResourceTypesList;
    /** Filter shares by status. */
    status?: ListRequestStatus | (string & {});
    /** Filter shares by tag. Each value is either `key=value` (matches shares whose tags contain that key/value pair) or `key` alone (matches shares that have any value for that key). May be repeated; multiple `tag` parameters are ANDed together. Maximum 20 `tag` parameters per request. */
    tag?: ListRequestTagList;
    /** Filter shares by target_type. */
    targetType?: ListRequestTargetType | (string & {});
}
export declare const ListResourceSharingsRequest: S.Schema<ListResourceSharingsRequest>;
export type ListResultItemStatus = "active" | "deleting" | "deleted";
export declare const ListResultItemStatus: any;
export type ListResultItemTargetType = "account" | "organization";
export declare const ListResultItemTargetType: any;
export type ListResultItemKind = "sent" | "received";
export declare const ListResultItemKind: any;
export type ListResultItemResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ListResultItemResourcesItemResourceType: any;
export type ListResultItemResourcesItemStatus = "active" | "deleting" | "deleted";
export declare const ListResultItemResourcesItemStatus: any;
export interface ListResultItemResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ListResultItemResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ListResultItemResourcesItemStatus;
}
export declare const ListResultItemResourcesItem: S.Schema<ListResultItemResourcesItem>;
export type ListResultItemResourcesList = Array<ListResultItemResourcesItem>;
export declare const ListResultItemResourcesList: S.Schema<ListResultItemResourcesList>;
export interface ListResultItem {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: ListResultItemStatus;
    targetType: ListResultItemTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: ListResultItemKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: ListResultItemResourcesList | null;
}
export declare const ListResultItem: S.Schema<ListResultItem>;
export type ListResultList = Array<ListResultItem>;
export declare const ListResultList: S.Schema<ListResultList>;
export interface ListResourceSharingsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListResourceSharingsResponse: S.Schema<ListResourceSharingsResponse>;
export interface UpdateResourceRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** Share Resource identifier. */
    shareResourceId: string;
    /** Resource Metadata. */
    meta: unknown;
}
export declare const UpdateResourceRequest: S.Schema<UpdateResourceRequest>;
export type ResourcesUpdateResponseResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const ResourcesUpdateResponseResourceType: any;
export type ResourcesUpdateResponseStatus = "active" | "deleting" | "deleted";
export declare const ResourcesUpdateResponseStatus: any;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResourceResponse {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: ResourcesUpdateResponseResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: ResourcesUpdateResponseStatus;
}
export declare const UpdateResourceResponse: S.Schema<UpdateResourceResponse>;
export interface UpdateResourceSharingRequest {
    /** Account identifier. */
    accountId: string;
    /** Share identifier tag. */
    shareId: string;
    /** The name of the share. */
    name: string;
}
export declare const UpdateResourceSharingRequest: S.Schema<UpdateResourceSharingRequest>;
export type UpdateResponseStatus = "active" | "deleting" | "deleted";
export declare const UpdateResponseStatus: any;
export type UpdateResponseTargetType = "account" | "organization";
export declare const UpdateResponseTargetType: any;
export type UpdateResponseKind = "sent" | "received";
export declare const UpdateResponseKind: any;
export type UpdateResponseResourcesItemResourceType = "custom-ruleset" | "gateway-policy" | "gateway-destination-ip" | "gateway-block-page-settings" | "gateway-extended-email-matching" | "idp-federation-grant";
export declare const UpdateResponseResourcesItemResourceType: any;
export type UpdateResponseResourcesItemStatus = "active" | "deleting" | "deleted";
export declare const UpdateResponseResourcesItemStatus: any;
export interface UpdateResponseResourcesItem {
    /** Share Resource identifier. */
    id: string;
    /** When the share was created. */
    created: string;
    /** Resource Metadata. */
    meta: unknown;
    /** When the share was modified. */
    modified: string;
    /** Account identifier. */
    resourceAccountId: string;
    /** Share Resource identifier. */
    resourceId: string;
    /** Resource Type. */
    resourceType: UpdateResponseResourcesItemResourceType;
    /** Resource Version. */
    resourceVersion: number;
    /** Resource Status. */
    status: UpdateResponseResourcesItemStatus;
}
export declare const UpdateResponseResourcesItem: S.Schema<UpdateResponseResourcesItem>;
export type UpdateResponseResourcesList = Array<UpdateResponseResourcesItem>;
export declare const UpdateResponseResourcesList: S.Schema<UpdateResponseResourcesList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResourceSharingResponse {
    /** Share identifier tag. */
    id: string;
    /** Account identifier. */
    accountId: string;
    /** The display name of an account. */
    accountName: string;
    /** When the share was created. */
    created: string;
    /** When the share was modified. */
    modified: string;
    /** The name of the share. */
    name: string;
    /** Organization identifier. */
    organizationId: string;
    status: UpdateResponseStatus;
    targetType: UpdateResponseTargetType;
    /** The number of recipients in the 'associated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatedRecipientCount?: number | null;
    /** The number of recipients in the 'associating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    associatingRecipientCount?: number | null;
    /** The number of recipients in the 'disassociated' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatedRecipientCount?: number | null;
    /** The number of recipients in the 'disassociating' state. This field is only included when requested via the 'include_recipient_counts' parameter. */
    disassociatingRecipientCount?: number | null;
    kind?: UpdateResponseKind | null;
    /** A list of resources that are part of the share. This field is only included when requested via the 'include_resources' parameter. */
    resources?: UpdateResponseResourcesList | null;
}
export declare const UpdateResourceSharingResponse: S.Schema<UpdateResourceSharingResponse>;
export type CreateRecipientError = ShareNotFound | Forbidden | CloudflareOpError;
/** Adds a recipient to a resource share, granting them access to the shared resources. */
export declare const createRecipient: API.OperationMethod<CreateRecipientRequest, CreateRecipientResponse, CreateRecipientError, CloudflareOpContext>;
export type CreateResourceError = ShareNotFound | Forbidden | CloudflareOpError;
/** Adds a resource to an existing share, making it available to share recipients. */
export declare const createResource: API.OperationMethod<CreateResourceRequest, CreateResourceResponse, CreateResourceError, CloudflareOpContext>;
export type CreateResourceSharingError = Forbidden | CloudflareOpError;
/** Creates a new resource share for sharing Cloudflare resources with other accounts or organizations. */
export declare const createResourceSharing: API.OperationMethod<CreateResourceSharingRequest, CreateResourceSharingResponse, CreateResourceSharingError, CloudflareOpContext>;
export type DeleteRecipientError = ShareRecipientNotFound | Forbidden | CloudflareOpError;
/** Deletion is not immediate, an updated share recipient object with a new status will be returned. */
export declare const deleteRecipient: API.OperationMethod<DeleteRecipientRequest, DeleteRecipientResponse, DeleteRecipientError, CloudflareOpContext>;
export type DeleteResourceError = ShareResourceNotFound | Forbidden | CloudflareOpError;
/** Deletion is not immediate, an updated share resource object with a new status will be returned. */
export declare const deleteResource: API.OperationMethod<DeleteResourceRequest, DeleteResourceResponse, DeleteResourceError, CloudflareOpContext>;
export type DeleteResourceSharingError = ShareNotFound | Forbidden | CloudflareOpError;
/** Deletion is not immediate, an updated share object with a new status will be returned. */
export declare const deleteResourceSharing: API.OperationMethod<DeleteResourceSharingRequest, DeleteResourceSharingResponse, DeleteResourceSharingError, CloudflareOpContext>;
export type GetRecipientError = ShareRecipientNotFound | Forbidden | CloudflareOpError;
/** Get share recipient by ID. */
export declare const getRecipient: API.OperationMethod<GetRecipientRequest, GetRecipientResponse, GetRecipientError, CloudflareOpContext>;
export type GetResourceError = ShareResourceNotFound | Forbidden | CloudflareOpError;
/** Get share resource by ID. */
export declare const getResource: API.OperationMethod<GetResourceRequest, GetResourceResponse, GetResourceError, CloudflareOpContext>;
export type GetResourceSharingError = ShareNotFound | Forbidden | CloudflareOpError;
/** Fetches share by ID. */
export declare const getResourceSharing: API.OperationMethod<GetResourceSharingRequest, GetResourceSharingResponse, GetResourceSharingError, CloudflareOpContext>;
export type ListRecipientsError = ShareNotFound | Forbidden | CloudflareOpError;
/** List share recipients by share ID. */
export declare const listRecipients: API.PaginatedOperationMethod<ListRecipientsRequest, ListRecipientsResponse, ListRecipientsError, CloudflareOpContext, RecipientsListResultItem>;
export type ListResourcesError = ShareNotFound | Forbidden | CloudflareOpError;
/** List share resources by share ID. */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest, ListResourcesResponse, ListResourcesError, CloudflareOpContext, ResourcesListResultItem>;
export type ListResourceSharingsError = Forbidden | CloudflareOpError;
/** Lists all account shares. */
export declare const listResourceSharings: API.PaginatedOperationMethod<ListResourceSharingsRequest, ListResourceSharingsResponse, ListResourceSharingsError, CloudflareOpContext, ListResultItem>;
export type UpdateResourceError = ShareResourceNotFound | Forbidden | CloudflareOpError;
/** Update is not immediate, an updated share resource object with a new status will be returned. */
export declare const updateResource: API.OperationMethod<UpdateResourceRequest, UpdateResourceResponse, UpdateResourceError, CloudflareOpContext>;
export type UpdateResourceSharingError = ShareNotFound | Forbidden | CloudflareOpError;
/** Updating is not immediate, an updated share object with a new status will be returned. */
export declare const updateResourceSharing: API.OperationMethod<UpdateResourceSharingRequest, UpdateResourceSharingResponse, UpdateResourceSharingError, CloudflareOpContext>;
//# sourceMappingURL=resource_sharing.d.ts.map