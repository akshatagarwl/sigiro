import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface DeleteManagedTransformRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export declare const DeleteManagedTransformRequest: S.Schema<DeleteManagedTransformRequest>;
export interface DeleteManagedTransformResponse {
}
export declare const DeleteManagedTransformResponse: S.Schema<DeleteManagedTransformResponse>;
export interface ListManagedTransformsRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export declare const ListManagedTransformsRequest: S.Schema<ListManagedTransformsRequest>;
export type ListResponseManagedRequestHeadersItemConflictsWithList = Array<string>;
export declare const ListResponseManagedRequestHeadersItemConflictsWithList: S.Schema<ListResponseManagedRequestHeadersItemConflictsWithList>;
export interface ListResponseManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: ListResponseManagedRequestHeadersItemConflictsWithList | null;
}
export declare const ListResponseManagedRequestHeadersItem: S.Schema<ListResponseManagedRequestHeadersItem>;
export type ListResponseManagedRequestHeadersList = Array<ListResponseManagedRequestHeadersItem>;
export declare const ListResponseManagedRequestHeadersList: S.Schema<ListResponseManagedRequestHeadersList>;
export type ListResponseManagedResponseHeadersItemConflictsWithList = Array<string>;
export declare const ListResponseManagedResponseHeadersItemConflictsWithList: S.Schema<ListResponseManagedResponseHeadersItemConflictsWithList>;
export interface ListResponseManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: ListResponseManagedResponseHeadersItemConflictsWithList | null;
}
export declare const ListResponseManagedResponseHeadersItem: S.Schema<ListResponseManagedResponseHeadersItem>;
export type ListResponseManagedResponseHeadersList = Array<ListResponseManagedResponseHeadersItem>;
export declare const ListResponseManagedResponseHeadersList: S.Schema<ListResponseManagedResponseHeadersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListManagedTransformsResponse {
    /** The list of Managed Request Transforms. */
    managedRequestHeaders: ListResponseManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders: ListResponseManagedResponseHeadersList;
}
export declare const ListManagedTransformsResponse: S.Schema<ListManagedTransformsResponse>;
export type EditRequestManagedRequestHeadersItemConflictsWithList = Array<string>;
export declare const EditRequestManagedRequestHeadersItemConflictsWithList: S.Schema<EditRequestManagedRequestHeadersItemConflictsWithList>;
export interface EditRequestManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict?: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditRequestManagedRequestHeadersItemConflictsWithList;
}
export declare const EditRequestManagedRequestHeadersItem: S.Schema<EditRequestManagedRequestHeadersItem>;
export type EditRequestManagedRequestHeadersList = Array<EditRequestManagedRequestHeadersItem>;
export declare const EditRequestManagedRequestHeadersList: S.Schema<EditRequestManagedRequestHeadersList>;
export type EditRequestManagedResponseHeadersItemConflictsWithList = Array<string>;
export declare const EditRequestManagedResponseHeadersItemConflictsWithList: S.Schema<EditRequestManagedResponseHeadersItemConflictsWithList>;
export interface EditRequestManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict?: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditRequestManagedResponseHeadersItemConflictsWithList;
}
export declare const EditRequestManagedResponseHeadersItem: S.Schema<EditRequestManagedResponseHeadersItem>;
export type EditRequestManagedResponseHeadersList = Array<EditRequestManagedResponseHeadersItem>;
export declare const EditRequestManagedResponseHeadersList: S.Schema<EditRequestManagedResponseHeadersList>;
export interface PatchManagedTransformRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    /** The list of Managed Request Transforms. */
    managedRequestHeaders?: EditRequestManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders?: EditRequestManagedResponseHeadersList;
}
export declare const PatchManagedTransformRequest: S.Schema<PatchManagedTransformRequest>;
export type EditResponseManagedRequestHeadersItemConflictsWithList = Array<string>;
export declare const EditResponseManagedRequestHeadersItemConflictsWithList: S.Schema<EditResponseManagedRequestHeadersItemConflictsWithList>;
export interface EditResponseManagedRequestHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditResponseManagedRequestHeadersItemConflictsWithList | null;
}
export declare const EditResponseManagedRequestHeadersItem: S.Schema<EditResponseManagedRequestHeadersItem>;
export type EditResponseManagedRequestHeadersList = Array<EditResponseManagedRequestHeadersItem>;
export declare const EditResponseManagedRequestHeadersList: S.Schema<EditResponseManagedRequestHeadersList>;
export type EditResponseManagedResponseHeadersItemConflictsWithList = Array<string>;
export declare const EditResponseManagedResponseHeadersItemConflictsWithList: S.Schema<EditResponseManagedResponseHeadersItemConflictsWithList>;
export interface EditResponseManagedResponseHeadersItem {
    /** The human-readable identifier of the Managed Transform. */
    id: string;
    /** Whether the Managed Transform is enabled. */
    enabled: boolean;
    /** Whether the Managed Transform conflicts with the currently-enabled Managed Transforms. */
    hasConflict: boolean;
    /** The Managed Transforms that this Managed Transform conflicts with. */
    conflictsWith?: EditResponseManagedResponseHeadersItemConflictsWithList | null;
}
export declare const EditResponseManagedResponseHeadersItem: S.Schema<EditResponseManagedResponseHeadersItem>;
export type EditResponseManagedResponseHeadersList = Array<EditResponseManagedResponseHeadersItem>;
export declare const EditResponseManagedResponseHeadersList: S.Schema<EditResponseManagedResponseHeadersList>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchManagedTransformResponse {
    /** The list of Managed Request Transforms. */
    managedRequestHeaders: EditResponseManagedRequestHeadersList;
    /** The list of Managed Response Transforms. */
    managedResponseHeaders: EditResponseManagedResponseHeadersList;
}
export declare const PatchManagedTransformResponse: S.Schema<PatchManagedTransformResponse>;
export type DeleteManagedTransformError = Forbidden | CloudflareOpError;
/** Disables all Managed Transforms. */
export declare const deleteManagedTransform: API.OperationMethod<DeleteManagedTransformRequest, DeleteManagedTransformResponse, DeleteManagedTransformError, CloudflareOpContext>;
export type ListManagedTransformsError = Forbidden | CloudflareOpError;
/** Fetches a list of all Managed Transforms. */
export declare const listManagedTransforms: API.OperationMethod<ListManagedTransformsRequest, ListManagedTransformsResponse, ListManagedTransformsError, CloudflareOpContext>;
export type PatchManagedTransformError = Forbidden | CloudflareOpError;
/** Updates the status of one or more Managed Transforms. */
export declare const patchManagedTransform: API.OperationMethod<PatchManagedTransformRequest, PatchManagedTransformResponse, PatchManagedTransformError, CloudflareOpContext>;
//# sourceMappingURL=managed_transforms.d.ts.map