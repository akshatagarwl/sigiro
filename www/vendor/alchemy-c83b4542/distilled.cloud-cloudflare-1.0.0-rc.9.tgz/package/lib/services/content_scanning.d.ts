import * as S from "@distilled.cloud/core/schema";
import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
import { ResultInfo } from "../pagination.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const ContentScanningNotEnabled_base: S.Class<ContentScanningNotEnabled, S.TaggedStruct<"ContentScanningNotEnabled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ContentScanningNotEnabled extends /*@__PURE__*/ ContentScanningNotEnabled_base {
}
declare const ContentScanningNotEntitled_base: S.Class<ContentScanningNotEntitled, S.TaggedStruct<"ContentScanningNotEntitled", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class ContentScanningNotEntitled extends /*@__PURE__*/ ContentScanningNotEntitled_base {
}
declare const Forbidden_base: S.Class<Forbidden, S.TaggedStruct<"Forbidden", {
    readonly code: any;
    readonly message: any;
}>, import("effect/Cause").YieldableError>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export type CreateRequestValue = "enabled" | "disabled";
export declare const CreateRequestValue: any;
export interface CreateContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The status value for Content Scanning. */
    value: CreateRequestValue | (string & {});
}
export declare const CreateContentScanningRequest: S.Schema<CreateContentScanningRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateContentScanningResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export declare const CreateContentScanningResponse: S.Schema<CreateContentScanningResponse>;
export interface PayloadsCreateRequestBodyItem {
    /** Defines the ruleset expression to use in matching content objects. */
    payload: string;
}
export declare const PayloadsCreateRequestBodyItem: S.Schema<PayloadsCreateRequestBodyItem>;
export type PayloadsCreateRequestBodyList = Array<PayloadsCreateRequestBodyItem>;
export declare const PayloadsCreateRequestBodyList: S.Schema<PayloadsCreateRequestBodyList>;
export interface CreatePayloadRequest {
    /** Defines an identifier. */
    zoneId: string;
    body: PayloadsCreateRequestBodyList;
}
export declare const CreatePayloadRequest: S.Schema<CreatePayloadRequest>;
export interface PayloadsCreateResultItem {
    /** defines the unique ID for this custom scan expression. */
    id?: string | null;
    /** Defines the ruleset expression to use in matching content objects. */
    payload?: string | null;
}
export declare const PayloadsCreateResultItem: S.Schema<PayloadsCreateResultItem>;
export type PayloadsCreateResultList = Array<PayloadsCreateResultItem>;
export declare const PayloadsCreateResultList: S.Schema<PayloadsCreateResultList>;
export interface CreatePayloadResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PayloadsCreateResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const CreatePayloadResponse: S.Schema<CreatePayloadResponse>;
export interface DeletePayloadRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** defines the unique ID for this custom scan expression. */
    expressionId: string;
}
export declare const DeletePayloadRequest: S.Schema<DeletePayloadRequest>;
export type PayloadsDeleteResultItem = PayloadsCreateResultItem;
export declare const PayloadsDeleteResultItem: S.Schema<PayloadsCreateResultItem>;
export type PayloadsDeleteResultList = Array<PayloadsCreateResultItem>;
export declare const PayloadsDeleteResultList: S.Schema<PayloadsDeleteResultList>;
export interface DeletePayloadResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PayloadsDeleteResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const DeletePayloadResponse: S.Schema<DeletePayloadResponse>;
export interface DisableContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const DisableContentScanningRequest: S.Schema<DisableContentScanningRequest>;
export type DisableContentScanningResponse = unknown;
export declare const DisableContentScanningResponse: S.Schema<DisableContentScanningResponse>;
export interface EnableContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const EnableContentScanningRequest: S.Schema<EnableContentScanningRequest>;
export type EnableContentScanningResponse = unknown;
export declare const EnableContentScanningResponse: S.Schema<EnableContentScanningResponse>;
export interface GetContentScanningRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const GetContentScanningRequest: S.Schema<GetContentScanningRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetContentScanningResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export declare const GetContentScanningResponse: S.Schema<GetContentScanningResponse>;
export interface GetSettingsRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const GetSettingsRequest: S.Schema<GetSettingsRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetSettingsResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export declare const GetSettingsResponse: S.Schema<GetSettingsResponse>;
export interface ListPayloadsRequest {
    /** Defines an identifier. */
    zoneId: string;
}
export declare const ListPayloadsRequest: S.Schema<ListPayloadsRequest>;
export type PayloadsListResultItem = PayloadsCreateResultItem;
export declare const PayloadsListResultItem: S.Schema<PayloadsCreateResultItem>;
export type PayloadsListResultList = Array<PayloadsCreateResultItem>;
export declare const PayloadsListResultList: S.Schema<PayloadsListResultList>;
export interface ListPayloadsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PayloadsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null;
}
export declare const ListPayloadsResponse: S.Schema<ListPayloadsResponse>;
export type UpdateRequestValue = "enabled" | "disabled";
export declare const UpdateRequestValue: any;
export interface UpdateRequest {
    /** Defines an identifier. */
    zoneId: string;
    /** The status value for Content Scanning. */
    value: UpdateRequestValue | (string & {});
}
export declare const UpdateRequest: S.Schema<UpdateRequest>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateResponse {
    /** Defines the last modification date (ISO 8601) of the Content Scanning status. */
    modified?: string | null;
    /** Defines the status of Content Scanning. */
    value?: string | null;
}
export declare const UpdateResponse: S.Schema<UpdateResponse>;
export type CreateContentScanningError = ContentScanningNotEntitled | Forbidden | CloudflareOpError;
/** Update the Content Scanning status. */
export declare const createContentScanning: API.OperationMethod<CreateContentScanningRequest, CreateContentScanningResponse, CreateContentScanningError, CloudflareOpContext>;
export type CreatePayloadError = ContentScanningNotEnabled | ContentScanningNotEntitled | Forbidden | CloudflareOpError;
/** Add custom scan expressions for Content Scanning. */
export declare const createPayload: API.PaginatedOperationMethod<CreatePayloadRequest, CreatePayloadResponse, CreatePayloadError, CloudflareOpContext, PayloadsCreateResultItem>;
export type DeletePayloadError = ContentScanningNotEnabled | Forbidden | CloudflareOpError;
/** Delete a Content Scan Custom Expression. */
export declare const deletePayload: API.PaginatedOperationMethod<DeletePayloadRequest, DeletePayloadResponse, DeletePayloadError, CloudflareOpContext, PayloadsCreateResultItem>;
export type DisableContentScanningError = CloudflareOpError;
/** Disable Content Scanning. */
export declare const disableContentScanning: API.OperationMethod<DisableContentScanningRequest, DisableContentScanningResponse, DisableContentScanningError, CloudflareOpContext>;
export type EnableContentScanningError = CloudflareOpError;
/** Enable Content Scanning. */
export declare const enableContentScanning: API.OperationMethod<EnableContentScanningRequest, EnableContentScanningResponse, EnableContentScanningError, CloudflareOpContext>;
export type GetContentScanningError = Forbidden | CloudflareOpError;
/** Retrieve the current status of Content Scanning. */
export declare const getContentScanning: API.OperationMethod<GetContentScanningRequest, GetContentScanningResponse, GetContentScanningError, CloudflareOpContext>;
export type GetSettingsError = Forbidden | CloudflareOpError;
/** Retrieve the current status of Content Scanning. */
export declare const getSettings: API.OperationMethod<GetSettingsRequest, GetSettingsResponse, GetSettingsError, CloudflareOpContext>;
export type ListPayloadsError = ContentScanningNotEnabled | Forbidden | CloudflareOpError;
/** Get a list of existing custom scan expressions for Content Scanning. */
export declare const listPayloads: API.PaginatedOperationMethod<ListPayloadsRequest, ListPayloadsResponse, ListPayloadsError, CloudflareOpContext, PayloadsCreateResultItem>;
export type UpdateError = ContentScanningNotEntitled | Forbidden | CloudflareOpError;
/** Update the Content Scanning status. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
export declare const getSetting: API.OperationMethod<GetContentScanningRequest, GetContentScanningResponse, GetContentScanningError, CloudflareOpContext>;
export type GetSettingRequest = GetContentScanningRequest;
export type GetSettingResponse = GetContentScanningResponse;
export type GetSettingError = GetContentScanningError;
export declare const putContentScanning: API.OperationMethod<CreateContentScanningRequest, CreateContentScanningResponse, CreateContentScanningError, CloudflareOpContext>;
export type PutContentScanningRequest = CreateContentScanningRequest;
export type PutContentScanningResponse = CreateContentScanningResponse;
export type PutContentScanningError = CreateContentScanningError;
//# sourceMappingURL=content_scanning.d.ts.map